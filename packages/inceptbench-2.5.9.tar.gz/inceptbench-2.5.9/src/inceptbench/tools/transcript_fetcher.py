"""
Transcript fetching for video content.

This module provides utilities for fetching transcripts from video URLs,
primarily YouTube videos. Transcripts are used for content classification
and decomposition - NOT for evaluation (evaluators watch the actual video).

Key design principles:
1. Transcripts are for DECOMPOSITION only (understanding structure)
2. Evaluators receive video URLs, not transcripts
3. The extracted_text is stored for debugging/review purposes
4. Transcripts are cached to avoid duplicate fetches
"""

import asyncio
import logging
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import NoTranscriptFound, TranscriptsDisabled

from inceptbench.tools.video_utils import extract_video_urls, is_youtube_url

logger = logging.getLogger(__name__)


@dataclass
class TranscriptSegment:
    """A segment of transcript with timing information."""
    text: str
    start: float  # Start time in seconds
    duration: float  # Duration in seconds
    
    @property
    def end(self) -> float:
        """End time in seconds."""
        return self.start + self.duration
    
    @property
    def start_timestamp(self) -> str:
        """Format start time as MM:SS or HH:MM:SS."""
        return _format_timestamp(self.start)
    
    @property
    def end_timestamp(self) -> str:
        """Format end time as MM:SS or HH:MM:SS."""
        return _format_timestamp(self.end)


@dataclass
class VideoTranscript:
    """
    Transcript extracted from a video.
    
    Contains the full extracted_text for decomposition purposes,
    plus timing information if available.
    """
    video_url: str
    extracted_text: str  # Full transcript text for decomposition/debugging
    available: bool  # Whether transcript was successfully fetched
    language: Optional[str] = None
    segments: List[TranscriptSegment] = field(default_factory=list)
    error_message: Optional[str] = None
    
    def get_text_at_timestamp(self, start_seconds: float, end_seconds: float) -> str:
        """
        Get transcript text for a specific time range.
        
        Useful for extracting scope-specific content during decomposition.
        """
        if not self.segments:
            return ""
        
        relevant_segments = [
            seg for seg in self.segments
            if seg.start >= start_seconds and seg.start < end_seconds
        ]
        return " ".join(seg.text for seg in relevant_segments)
    
    def find_segment_for_text(self, search_text: str) -> Optional[TranscriptSegment]:
        """
        Find the segment containing specific text.
        
        Useful for locating content mentioned in decomposition.
        """
        search_lower = search_text.lower()
        for seg in self.segments:
            if search_lower in seg.text.lower():
                return seg
        return None


def _format_timestamp(seconds: float) -> str:
    """Format seconds as MM:SS or HH:MM:SS."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def _extract_youtube_video_id(url: str) -> Optional[str]:
    """Extract video ID from a YouTube URL."""
    patterns = [
        r'(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/v/)([a-zA-Z0-9_-]{11})',
        r'youtube\.com/shorts/([a-zA-Z0-9_-]{11})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


class TranscriptFetcher:
    """
    Fetches and caches video transcripts.
    
    Transcripts are used for content classification and decomposition.
    The cache ensures each video URL is fetched only once, providing
    consistency across the evaluation pipeline.
    
    IMPORTANT: Transcripts are for decomposition only. Evaluators
    receive the original video URLs and watch videos themselves.
    """
    
    def __init__(self):
        """Initialize the transcript fetcher with an empty cache."""
        self._cache: Dict[str, VideoTranscript] = {}
    
    def get_cached(self, video_url: str) -> Optional[VideoTranscript]:
        """Get a cached transcript if available."""
        return self._cache.get(video_url)
    
    def get_all_transcripts(self) -> Dict[str, VideoTranscript]:
        """Get all cached transcripts (for debugging/extracted_text access)."""
        return self._cache.copy()
    
    async def fetch_transcript(self, video_url: str) -> VideoTranscript:
        """
        Fetch transcript for a video URL.
        
        Returns cached result if available. For YouTube videos,
        attempts to fetch the transcript via YouTube's API.
        For non-YouTube videos, returns an unavailable transcript.
        
        Args:
            video_url: The video URL to fetch transcript for
            
        Returns:
            VideoTranscript with extracted_text (may be empty if unavailable)
        """
        # Check cache first
        if video_url in self._cache:
            logger.debug(f"Using cached transcript for: {video_url[:50]}...")
            return self._cache[video_url]
        
        # Fetch based on video type
        if is_youtube_url(video_url):
            transcript = await self._fetch_youtube_transcript(video_url)
        else:
            # Non-YouTube videos: transcript not available
            logger.info(f"Non-YouTube video, transcript not available: {video_url[:50]}...")
            transcript = VideoTranscript(
                video_url=video_url,
                extracted_text="",
                available=False,
                error_message="Transcripts only available for YouTube videos"
            )
        
        # Cache and return
        self._cache[video_url] = transcript
        return transcript
    
    async def fetch_all_transcripts(self, content: str) -> Dict[str, VideoTranscript]:
        """
        Fetch transcripts for all videos in content.
        
        Args:
            content: Content potentially containing video URLs
            
        Returns:
            Dict mapping video URLs to their transcripts
        """
        video_urls = extract_video_urls(content)
        
        if not video_urls:
            return {}
        
        logger.info(f"Fetching transcripts for {len(video_urls)} video(s)...")
        
        # Fetch all transcripts (could parallelize, but YouTube may rate limit)
        for url in video_urls:
            await self.fetch_transcript(url)
        
        return self.get_all_transcripts()
    
    async def _fetch_youtube_transcript(self, video_url: str) -> VideoTranscript:
        """
        Fetch transcript from YouTube.
        
        Uses youtube-transcript-api to get the transcript.
        Runs in executor since the library is synchronous.
        """
        video_id = _extract_youtube_video_id(video_url)
        
        if not video_id:
            logger.warning(f"Could not extract video ID from: {video_url}")
            return VideoTranscript(
                video_url=video_url,
                extracted_text="",
                available=False,
                error_message="Could not extract video ID"
            )
        
        def _fetch_sync():
            """Synchronous fetch function to run in executor."""
            # New API (v1.0+): create instance and call fetch()
            api = YouTubeTranscriptApi()
            return api.fetch(video_id, languages=['en'])
        
        try:
            # Run sync API in executor
            loop = asyncio.get_event_loop()
            fetched_transcript = await loop.run_in_executor(None, _fetch_sync)
            
            # Convert to our format
            # New API returns FetchedTranscript which is iterable
            segments = []
            for item in fetched_transcript:
                segments.append(TranscriptSegment(
                    text=item.text,
                    start=item.start,
                    duration=item.duration
                ))
            
            # Combine all text
            full_text = " ".join(seg.text for seg in segments)
            
            logger.info(
                f"Fetched transcript for {video_id}: "
                f"{len(segments)} segments, {len(full_text)} chars"
            )
            
            return VideoTranscript(
                video_url=video_url,
                extracted_text=full_text,
                available=True,
                language="en",
                segments=segments
            )
            
        except NoTranscriptFound:
            logger.warning(f"No transcript found for video: {video_id}")
            return VideoTranscript(
                video_url=video_url,
                extracted_text="",
                available=False,
                error_message="No transcript available for this video"
            )
            
        except TranscriptsDisabled:
            logger.warning(f"Transcripts disabled for video: {video_id}")
            return VideoTranscript(
                video_url=video_url,
                extracted_text="",
                available=False,
                error_message="Transcripts are disabled for this video"
            )
            
        except Exception as e:
            logger.error(f"Error fetching transcript for {video_id}: {e}")
            return VideoTranscript(
                video_url=video_url,
                extracted_text="",
                available=False,
                error_message=str(e)
            )
    
    def create_decomposition_content(
        self,
        original_content: str,
        transcripts: Optional[Dict[str, VideoTranscript]] = None
    ) -> str:
        """
        Create content view for decomposition by substituting transcripts.
        
        For each video URL in the content, if a transcript is available,
        the URL is augmented with the transcript text. This allows the
        classifier and decomposer to understand video structure.
        
        Important: We add a [VIDEO_SOURCE: url] marker that survives decomposition.
        This ensures child nodes (extracted from video content) retain the video
        source information needed for evaluation.
        
        Args:
            original_content: The original content with video URLs
            transcripts: Optional dict of transcripts (uses cache if not provided)
            
        Returns:
            Content with video URLs augmented by transcripts
        """
        if transcripts is None:
            transcripts = self._cache
        
        if not transcripts:
            return original_content
        
        result = original_content
        
        for video_url, transcript in transcripts.items():
            if transcript.available and transcript.extracted_text:
                # Create the decomposition view with transcript
                # Format includes VIDEO_SOURCE marker that survives decomposition
                # so child nodes retain video source info for evaluation
                replacement = (
                    f"[VIDEO_SOURCE: {video_url}]\n"
                    f"[TRANSCRIPT START]\n"
                    f"{transcript.extracted_text}\n"
                    f"[TRANSCRIPT END]"
                )
                result = result.replace(video_url, replacement)
            else:
                # No transcript available - still add source marker
                replacement = f"[VIDEO_SOURCE: {video_url}]"
                result = result.replace(video_url, replacement)
        
        return result
    
    def create_evaluation_content(
        self,
        node_content: str,
        scope_description: Optional[str] = None
    ) -> str:
        """
        Create content view for evaluation (strips transcripts).
        
        Evaluators should see the video URL, NOT the transcript.
        This ensures they actually watch the video.
        
        Args:
            node_content: The node's content (may contain transcript markers)
            scope_description: Unused, kept for API compatibility
            
        Returns:
            Clean content with video URL, no transcript
        """
        result = re.sub(
            r'\[TRANSCRIPT START\].*?\[TRANSCRIPT END\]',
            '',
            node_content,
            flags=re.DOTALL
        )
        
        result = re.sub(r'\n{3,}', '\n\n', result).strip()
        
        return result
    
    def clear_cache(self) -> None:
        """Clear the transcript cache."""
        self._cache.clear()
