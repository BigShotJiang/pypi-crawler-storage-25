"""
Utility tools for the educational content evaluation system.

This module provides various utility functions including:
- API client management (legacy, prefer src.llm)
- Curriculum search functionality
- Object counting in images
- Image utilities
- Video utilities
- Audio utilities
- Deterministic math verification (SymPy)
"""

# Note: API clients are legacy - prefer using src.llm.LLMFactory
from .api_client import get_async_anthropic_client, get_async_openai_client
from .math_verifier import extract_and_verify_math
from .video_utils import (
    extract_video_urls,
    has_video_content,
    is_video_url,
    is_youtube_url,
    prepare_video_for_gemini,
    VideoInputMethod,
)
from .audio_utils import (
    extract_audio_urls,
    extract_audio_data_uris,
    has_audio_content,
    is_audio_url,
    prepare_audio_for_gemini,
    AudioInputMethod,
)
from .variety_check import VarietyChecker, compute_variety_score

__all__ = [
    "get_async_openai_client",
    "get_async_anthropic_client",
    "extract_and_verify_math",
    # Video utilities
    "extract_video_urls",
    "has_video_content",
    "is_video_url",
    "is_youtube_url",
    "prepare_video_for_gemini",
    "VideoInputMethod",
    # Audio utilities
    "extract_audio_urls",
    "extract_audio_data_uris",
    "has_audio_content",
    "is_audio_url",
    "prepare_audio_for_gemini",
    "AudioInputMethod",
    # Variety check
    "VarietyChecker",
    "compute_variety_score",
]

