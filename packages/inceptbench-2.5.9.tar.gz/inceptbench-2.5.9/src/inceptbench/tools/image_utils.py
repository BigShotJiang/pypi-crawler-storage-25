"""
Image utility functions for educational content evaluation.

This module provides utilities for extracting image URLs from content,
downloading images, encoding them for API use, and handling inline SVG content.
"""

import base64
import io
import logging
import math
import re
import statistics
import time
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

IMAGE_PREP_MAX_RETRIES = 3
IMAGE_PREP_BASE_DELAY = 1.5


class ImagePreparationError(RuntimeError):
    """Raised when an image cannot be prepared for LLM vision input."""


def _clean_image_url(url: str) -> str:
    """
    Clean an extracted image URL by removing any trailing description or garbage.
    
    Handles formats like:
    - 'https://example.com/image.png "description"' -> 'https://example.com/image.png'
    - 'https://example.com/image.png \\"description\\"' -> 'https://example.com/image.png'
    - 'https://example.com/image.png)' -> 'https://example.com/image.png'
    """
    if not url:
        return url
    
    # Strip leading/trailing whitespace
    url = url.strip()
    
    # Find where the actual URL ends - look for image extension followed by optional query string
    # Pattern: .ext or .ext?query but nothing after that except valid URL chars
    extension_match = re.search(
        r'(\.(?:jpg|jpeg|png|gif|bmp|svg|webp))(\?[^\s"\'\\]*)?',
        url, 
        re.IGNORECASE
    )
    
    if extension_match:
        # URL ends at the extension (plus any query string)
        end_pos = extension_match.end()
        url = url[:end_pos]
    
    # Also handle Supabase URLs that might not have extensions visible
    # Stop at common "end of URL" indicators
    for stop_char in [' "', ' \\"', ' \\\"', '\t', ' \'', '\\n', '\n']:
        if stop_char in url:
            url = url.split(stop_char)[0]
    
    # Remove trailing punctuation that's not part of URLs
    url = url.rstrip('"\'\\ \t\n,;:)>')
    
    # URL-encode spaces (common issue with S3 URLs that have spaces in filenames)
    url = url.replace(' ', '%20')
    
    return url


# Public alias for cross-module use (avoids coupling callers to the private name).
clean_image_url = _clean_image_url


def extract_image_urls(content: str) -> List[str]:
    """
    Extract image URLs from content.
    
    Args:
        content: The content to extract URLs from
        
    Returns:
        List of unique image URLs found in the content
    """
    # Pattern to match common image URL formats
    # Matches URLs ending in common image extensions
    # Note: [^\s<>"\\] excludes backslash to handle escaped quotes like \"
    url_pattern = r'https?://[^\s<>"\\]+?\.(?:jpg|jpeg|png|gif|bmp|svg|webp)(?:\?[^\s<>"\\]*)?'
    
    # Also match Supabase storage URLs (common in this codebase)
    # Be more restrictive - stop at spaces, quotes, or backslashes
    supabase_pattern = r'https://[^\s<>"\\]*supabase[^\s<>"\\]*storage[^\s<>"\\]*\.(?:jpg|jpeg|png|gif|bmp|svg|webp)'
    
    urls = []
    urls.extend(re.findall(url_pattern, content, re.IGNORECASE))
    urls.extend(re.findall(supabase_pattern, content, re.IGNORECASE))

    # Extract markdown image syntax: ![alt](url)
    markdown_image_matches = re.findall(r'!\[.*?\]\((.*?)\)', content)
    urls.extend(markdown_image_matches)

    # Extract HTML image tags
    html_image_matches = re.findall(r'<img[^>]+src=["\']([^"\']+)["\']', content, re.IGNORECASE)
    urls.extend(html_image_matches)

    # Clean all extracted URLs and remove any that are now invalid
    cleaned_urls = []
    for url in urls:
        cleaned = _clean_image_url(url)
        if cleaned and cleaned.startswith('http'):
            cleaned_urls.append(cleaned)
        else:
            logger.debug(f"Discarded invalid URL after cleaning: {url} -> {cleaned}")

    # Remove duplicates while preserving order
    seen = set()
    unique_urls = []
    for url in cleaned_urls:
        if url not in seen:
            seen.add(url)
            unique_urls.append(url)
    
    logger.debug(f"Extracted {len(unique_urls)} unique image URLs from content")
    return unique_urls


def download_and_encode_image(image_url: str, timeout: int = 30) -> str:
    """
    Download an image and encode it as a base64 data URL.
    
    This helps avoid timeout issues when OpenAI's servers try to download
    external URLs directly. Falls back to the original URL if download fails.
    
    Args:
        image_url: The URL of the image to download and encode
        timeout: Request timeout in seconds (default: 30)
        
    Returns:
        Base64-encoded data URL (data:image/...;base64,...) or (for non-SVG only)
        original URL if all download attempts fail.

    Raises:
        ImagePreparationError: If an SVG cannot be downloaded/converted after retries.
    """
    # Clean the URL to remove any trailing description text
    cleaned_url = _clean_image_url(image_url)
    if cleaned_url != image_url:
        logger.debug(f"Cleaned image URL before download: {image_url} -> {cleaned_url}")
    
    last_error: Optional[Exception] = None
    for attempt in range(1, IMAGE_PREP_MAX_RETRIES + 1):
        try:
            response = requests.get(cleaned_url, timeout=timeout)
            response.raise_for_status()
            image_bytes = response.content
            if not image_bytes:
                raise ImagePreparationError(f"Empty response body for image URL: {cleaned_url}")

            content_type = response.headers.get('content-type', 'image/png')
            is_svg = 'svg' in content_type or cleaned_url.lower().endswith('.svg')

            if is_svg:
                # Convert SVG to PNG — LLM APIs (OpenAI, Anthropic, Gemini) don't accept SVG
                svg_text = image_bytes.decode('utf-8', errors='replace')
                png_bytes = convert_svg_to_png(svg_text)
                if not png_bytes:
                    raise ImagePreparationError(f"SVG conversion failed for {cleaned_url}")
                image_base64 = base64.b64encode(png_bytes).decode('utf-8')
                logger.info(f"Converted SVG URL to PNG for API: {cleaned_url}")
                return f"data:image/png;base64,{image_base64}"

            image_base64 = base64.b64encode(image_bytes).decode("utf-8")

            # Determine the appropriate MIME type
            if 'jpeg' in content_type or 'jpg' in content_type:
                return f"data:image/jpeg;base64,{image_base64}"
            if 'png' in content_type:
                return f"data:image/png;base64,{image_base64}"
            if 'gif' in content_type:
                return f"data:image/gif;base64,{image_base64}"
            if 'webp' in content_type:
                return f"data:image/webp;base64,{image_base64}"
            # Default to PNG for unknown types
            return f"data:image/png;base64,{image_base64}"

        except Exception as e:
            last_error = e
            if attempt < IMAGE_PREP_MAX_RETRIES:
                delay = IMAGE_PREP_BASE_DELAY * (2 ** (attempt - 1))
                logger.warning(
                    "Image prep failed (%s/%s) for %s: %s. Retrying in %.1fs...",
                    attempt,
                    IMAGE_PREP_MAX_RETRIES,
                    cleaned_url,
                    e,
                    delay,
                )
                time.sleep(delay)
            else:
                logger.warning(
                    "Image prep failed after %s attempts for %s: %s",
                    IMAGE_PREP_MAX_RETRIES,
                    cleaned_url,
                    e,
                )

    # After retries: throw for SVGs (don't pass raw SVG URL to model), fallback to URL for non-SVG.
    if cleaned_url.lower().endswith('.svg'):
        raise ImagePreparationError(
            f"Unable to prepare SVG image after retries: {cleaned_url}"
        ) from last_error
    return cleaned_url


def prepare_images_for_api(image_urls: List[str]) -> List[dict]:
    """
    Prepare a list of image URLs for API consumption.
    
    Downloads and encodes each image, then returns them in the format
    expected by the OpenAI Vision API.
    
    Args:
        image_urls: List of image URLs to prepare
        
    Returns:
        List of dictionaries in the format:
        [{"type": "input_image", "image_url": "data:image/...;base64,..."}]
    """
    prepared_images = []
    
    for image_url in image_urls:
        encoded_url = download_and_encode_image(image_url)
        prepared_images.append({
            "type": "input_image",
            "image_url": encoded_url
        })
        
        if encoded_url.startswith("data:"):
            logger.info(f"Prepared image (base64 encoded): {image_url}")
        else:
            logger.info(f"Prepared image (direct URL): {image_url}")
    
    return prepared_images


def build_llm_content_with_images(text: str, image_urls: List[str], encode_base64: bool = False) -> List[dict]:
    """
    Build LLM message content array with text and images for vision-capable models.

    Args:
        text: The text content to include
        image_urls: List of image URLs to include
        encode_base64: If True, download and encode images as base64

    Returns:
        List of content blocks in OpenAI message format
    """
    content = [{"type": "text", "text": text}]

    for url in image_urls:
        # Clean the URL to remove any trailing description text
        cleaned_url = _clean_image_url(url)
        
        if encode_base64:
            encoded_url = download_and_encode_image(cleaned_url)
        else:
            encoded_url = cleaned_url
        content.append({
            "type": "image_url",
            "image_url": {"url": encoded_url}
        })

    return content


# =============================================================================
# SVG Extraction and Conversion
# =============================================================================

def extract_svg_content(content: str) -> List[Dict[str, any]]:
    """
    Extract inline SVG XML content from text.
    
    Handles both regular text and JSON-stringified content where quotes may be escaped.
    Looks for SVG tags with their complete content, typically marked with
    [SVG Image] or similar markers in the educational content.
    
    Args:
        content: The content to extract SVGs from (may be JSON-stringified)
        
    Returns:
        List of dictionaries containing SVG data:
        [{"index": 0, "content": "<svg>...</svg>", "marker": "[SVG Image]"}]
    """
    # First, try to parse as JSON to get unescaped content
    # This handles the case where content is json.dumps() output
    try:
        import json
        parsed = json.loads(content)
        # If it's a dict, recursively search all string values for SVGs
        if isinstance(parsed, dict):
            # Flatten all string values from the dict
            content_strings = []
            def collect_strings(obj):
                if isinstance(obj, str):
                    content_strings.append(obj)
                elif isinstance(obj, dict):
                    for value in obj.values():
                        collect_strings(value)
                elif isinstance(obj, list):
                    for item in obj:
                        collect_strings(item)
            
            collect_strings(parsed)
            # Process each string for SVGs
            all_svgs = []
            for text in content_strings:
                all_svgs.extend(_extract_svg_from_text(text))
            
            # Re-index to ensure sequential indices
            for i, svg in enumerate(all_svgs):
                svg['index'] = i
            
            return all_svgs
    except (json.JSONDecodeError, TypeError):
        # Not JSON, treat as regular text
        pass
    
    # Regular text extraction
    return _extract_svg_from_text(content)


def _extract_svg_from_text(text: str) -> List[Dict[str, any]]:
    """
    Helper function to extract SVGs from a plain text string.
    
    Handles nested SVG tags by counting opening/closing tags to find
    the complete outermost SVG element.
    
    Args:
        text: Plain text (not JSON-escaped) to extract SVGs from
        
    Returns:
        List of SVG dictionaries
    """
    svgs = []
    i = 0
    
    while i < len(text):
        # Find next opening <svg tag (case insensitive)
        match = re.search(r'<svg[\s>]', text[i:], re.IGNORECASE)
        if not match:
            break
        
        start_pos = i + match.start()
        
        # Find the end of the opening tag
        tag_end = text.find('>', start_pos)
        if tag_end == -1:
            break
        
        # Count nested svg tags to find the matching closing tag
        depth = 1
        pos = tag_end + 1
        
        while pos < len(text) and depth > 0:
            # Look for next svg tag (opening or closing)
            next_open = re.search(r'<svg[\s>]', text[pos:], re.IGNORECASE)
            next_close = re.search(r'</svg\s*>', text[pos:], re.IGNORECASE)
            
            if next_close is None:
                # No closing tag found
                break
            
            close_pos = pos + next_close.start()
            
            # Check if there's an opening tag before the closing tag
            if next_open and (pos + next_open.start()) < close_pos:
                # Found nested opening tag first
                depth += 1
                pos = pos + next_open.start() + 4  # Move past '<svg'
            else:
                # Found closing tag
                depth -= 1
                if depth == 0:
                    # Found matching closing tag
                    end_pos = close_pos + len(next_close.group(0))
                    svg_content = text[start_pos:end_pos]
                    
                    # Try to find any marker text before the SVG (like [SVG Image])
                    marker_pattern = r'\[SVG[^\]]*\]'
                    context_before = text[max(0, start_pos - 50):start_pos]
                    marker_match = re.search(marker_pattern, context_before, re.IGNORECASE)
                    marker = marker_match.group(0) if marker_match else None
                    
                    svgs.append({
                        "index": len(svgs),
                        "content": svg_content,
                        "marker": marker,
                        "position": start_pos
                    })
                    
                    i = end_pos
                    break
                else:
                    pos = close_pos + len(next_close.group(0))
        
        if depth > 0:
            # Couldn't find matching closing tag, skip this svg
            i = start_pos + 1
        
    if svgs:
        logger.info(f"Extracted {len(svgs)} inline SVG(s) from text")
    else:
        logger.debug("No inline SVGs found in text")
    
    return svgs


def convert_svg_to_png(svg_content: str, width: int = 800, height: int = 600) -> Optional[bytes]:
    """
    Convert SVG XML string to PNG image bytes.
    
    Tries multiple conversion methods in order:
    1. cairosvg (requires system cairo libraries)
    2. svglib + reportlab (pure Python, but also needs cairo)
    
    Args:
        svg_content: SVG XML string (complete <svg>...</svg> tag)
        width: Output PNG width in pixels (default: 800)
        height: Output PNG height in pixels (default: 600)
        
    Returns:
        PNG image as bytes, or None if conversion fails
    """
    # Method 1: Try cairosvg first (if available)
    try:
        import cairosvg
        
        svg_fixed = svg_content

        svg_fixed = re.sub(r'\s+width="100%"', '', svg_fixed)
        svg_fixed = re.sub(r'\s+height="auto"', '', svg_fixed)

        png_bytes = cairosvg.svg2png(
            bytestring=svg_fixed.encode('utf-8'),
            output_width=width,
            output_height=height,
            background_color="white",
        )
        png_bytes = _flatten_alpha_to_white(png_bytes)
        logger.debug(f"Successfully converted SVG to PNG using cairosvg ({len(png_bytes)} bytes)")
        return png_bytes
        
    except (ImportError, OSError) as e:
        logger.debug(f"cairosvg not available: {e}")
    except Exception as e:
        logger.error(f"cairosvg conversion failed: {e}")
        logger.error(f"SVG content length: {len(svg_content)}")
        logger.error(f"SVG first 200 chars: {repr(svg_content[:200])}")
    
    # Method 2: Try svglib + reportlab
    try:
        from svglib.svglib import svg2rlg
        from reportlab.graphics import renderPM
        from io import BytesIO, StringIO
        
        # Convert SVG string to drawing
        drawing = svg2rlg(StringIO(svg_content))
        
        if drawing:
            # Scale to desired dimensions
            scale_x = width / drawing.width if drawing.width > 0 else 1
            scale_y = height / drawing.height if drawing.height > 0 else 1
            scale = min(scale_x, scale_y)
            
            drawing.width = drawing.width * scale
            drawing.height = drawing.height * scale
            drawing.scale(scale, scale)
            
            # Render to PNG
            png_data = BytesIO()
            renderPM.drawToFile(drawing, png_data, fmt='PNG')
            png_bytes = png_data.getvalue()
            png_bytes = _flatten_alpha_to_white(png_bytes)
            
            logger.debug(f"Successfully converted SVG to PNG using svglib ({len(png_bytes)} bytes)")
            return png_bytes
            
    except ImportError:
        logger.debug("svglib/reportlab not available")
    except Exception as e:
        logger.debug(f"svglib conversion failed: {e}")
    
    # No conversion method available
    logger.warning(
        "No SVG conversion library available. SVG images will be skipped.\n"
        "To enable SVG support, install cairo system libraries + cairosvg:\n"
        "  - Linux/Docker: apt-get install libcairo2-dev\n"
        "  - Windows: install GTK3 runtime (winget install tschoonj.GTKForWindows)\n"
        "  - macOS: brew install cairo\n"
        "\nFor now, only external image URLs will be analyzed."
    )
    return None


def _flatten_alpha_to_white(png_bytes: bytes) -> bytes:
    """
    Convert transparent PNG output into opaque white-background PNG.

    Some SVG renderers return RGBA images with transparent backgrounds even when
    source SVGs specify a white background via CSS. Vision models can interpret
    transparency as black, so we flatten alpha to white before analysis.
    """
    try:
        from PIL import Image

        with Image.open(io.BytesIO(png_bytes)) as img:
            # Handle palette images that may carry transparency via tRNS.
            if img.mode == "P" and "transparency" in img.info:
                img = img.convert("RGBA")

            if img.mode in {"RGBA", "LA"}:
                rgba_img = img.convert("RGBA")
                white_bg = Image.new("RGBA", rgba_img.size, (255, 255, 255, 255))
                flattened = Image.alpha_composite(white_bg, rgba_img).convert("RGB")
                output = io.BytesIO()
                flattened.save(output, format="PNG")
                return output.getvalue()

        return png_bytes
    except Exception as e:
        logger.debug(f"Alpha flattening skipped due to error: {e}")
        return png_bytes


def prepare_svgs_for_analysis(svgs: List[Dict[str, any]], width: int = 800, height: int = 600) -> List[Dict[str, any]]:
    """
    Convert SVG content to base64-encoded PNG images for analysis.
    
    Args:
        svgs: List of SVG dictionaries from extract_svg_content()
        width: PNG width in pixels (default: 800)
        height: PNG height in pixels (default: 600)
        
    Returns:
        List of dictionaries in format:
        [{
            "type": "input_image",
            "image_url": "data:image/png;base64,...",
            "source": "svg",
            "original_index": 0,
            "marker": "[SVG Image]"
        }]
    """
    prepared = []
    
    for svg_item in svgs:
        try:
            png_bytes = convert_svg_to_png(svg_item['content'], width, height)
            
            if png_bytes:
                png_base64 = base64.b64encode(png_bytes).decode('utf-8')
                prepared.append({
                    "type": "input_image",
                    "image_url": f"data:image/png;base64,{png_base64}",
                    "source": "svg",
                    "original_index": svg_item['index'],
                    "marker": svg_item.get('marker'),
                    "position": svg_item.get('position')
                })
                logger.info(f"Prepared SVG {svg_item['index']} for analysis")
            else:
                logger.warning(f"Skipping SVG {svg_item['index']}: conversion returned None")
                
        except Exception as e:
            logger.warning(f"Failed to prepare SVG {svg_item['index']}: {e}")
            continue
    
    return prepared


def extract_all_images(content: str) -> Dict[str, any]:
    """
    Extract both image URLs and inline SVGs from content.
    
    This is the main entry point for comprehensive image extraction that
    handles both external image URLs and inline SVG content.
    
    Args:
        content: The content to extract images from
        
    Returns:
        Dictionary with:
        {
            'urls': List[str],              # Regular image URLs
            'svgs': List[Dict],             # SVG data from extract_svg_content()
            'svg_images': List[Dict]        # Prepared SVG images (base64 PNG)
        }
    """
    result = {
        'urls': extract_image_urls(content),
        'svgs': extract_svg_content(content),
        'svg_images': []
    }
    
    # Convert SVGs to images if any were found
    if result['svgs']:
        result['svg_images'] = prepare_svgs_for_analysis(result['svgs'])
    
    total_images = len(result['urls']) + len(result['svg_images'])
    logger.info(
        f"Extracted {total_images} total image(s): "
        f"{len(result['urls'])} URL(s), {len(result['svg_images'])} SVG(s)"
    )
    
    return result


def get_all_image_urls_for_analysis(content: str) -> List[str]:
    """
    Get all image URLs ready for analysis, including converted SVGs.
    
    This is a convenience function that returns a flat list of all image URLs
    (both external URLs and base64-encoded converted SVGs) ready to pass to
    the unified image analyzer.
    
    Args:
        content: The content to extract images from
        
    Returns:
        List of image URLs (external URLs + base64 data URLs from SVGs)
    """
    image_data = extract_all_images(content)
    
    # Start with external URLs
    all_urls = list(image_data['urls'])
    
    # Add converted SVG data URLs
    for svg_image in image_data['svg_images']:
        all_urls.append(svg_image['image_url'])
    
    return all_urls


def extract_svg_clock_time(svg_content: str) -> Optional[str]:
    """
    Extract time from an analog clock SVG by reading hand geometry.

    Detects the two clock hands (longer lines from center) and computes the
    time from their angles. Returns a formatted authoritative string, or None
    if this SVG is not a clock or extraction fails.
    """
    try:

        # Clock center is always at SVG coordinate 1500,1500
        cx, cy = 1500.0, 1500.0

        lines_raw = re.findall(
            r'<line\s+x1="([\d.]+)"\s+y1="([\d.]+)"\s+x2="([\d.]+)"\s+y2="([\d.]+)"\s+stroke="([^"]+)"\s+stroke-width="([^"]+)"[^/]*/>', 
            svg_content
        )
        if not lines_raw:
            return None

        hands = []
        for l in lines_raw:
            x1, y1, x2, y2 = float(l[0]), float(l[1]), float(l[2]), float(l[3])
            width = float(l[5])
            length = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
            if length > 50:  # clock hands are long; tick marks are short (~14px)
                d1 = math.sqrt((x1 - cx) ** 2 + (y1 - cy) ** 2)
                d2 = math.sqrt((x2 - cx) ** 2 + (y2 - cy) ** 2)
                tip_x, tip_y = (x1, y1) if d1 > d2 else (x2, y2)
                angle = math.degrees(math.atan2(tip_x - cx, -(tip_y - cy)))
                if angle < 0:
                    angle += 360
                hands.append({'length': length, 'width': width, 'angle': angle})

        # A clock has exactly 2 hands (hour + minute)
        if len(hands) != 2:
            return None

        # Quick sanity: both hands must start near the center
        # (eliminates non-clock SVGs that happen to have 2 long lines)
        for l in lines_raw:
            x1, y1, x2, y2 = float(l[0]), float(l[1]), float(l[2]), float(l[3])
            length = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
            if length > 50:
                d1 = math.sqrt((x1 - cx) ** 2 + (y1 - cy) ** 2)
                d2 = math.sqrt((x2 - cx) ** 2 + (y2 - cy) ** 2)
                min_dist = min(d1, d2)
                if min_dist > 30:  # hand doesn't start near center → not a clock
                    return None

        hands.sort(key=lambda h: h['length'])
        hour_hand, minute_hand = hands[0], hands[1]

        minutes = round(minute_hand['angle'] / 6)
        if minutes == 60:
            minutes = 0
        minutes = (minutes // 5) * 5

        hour = int(hour_hand['angle'] / 30) % 12
        if hour == 0:
            hour = 12

        time_str = f"{hour}:{minutes:02d}"

        return (
            f"SVG CLOCK ANALYSIS (authoritative - trust over visual estimation):\n"
            f"Detected: Analog clock\n"
            f"Hour hand angle: {hour_hand['angle']:.1f}° (length {hour_hand['length']:.0f}px)\n"
            f"Minute hand angle: {minute_hand['angle']:.1f}° (length {minute_hand['length']:.0f}px)\n"
            f"Time shown on clock: {time_str}\n"
            f"CRITICAL: This time is computed EXACTLY from SVG hand geometry. "
            f"Trust this over visual estimation by the vision model."
        )

    except Exception as e:
        logger.debug(f"SVG clock time extraction failed: {e}")
        return None


def _is_clock_svg(svg_content: str) -> bool:
    """
    Heuristic: return True if this SVG appears to be an analog clock.
    Clocks have a large circle (the face) and exactly two long lines (hands)
    that both originate near the center.
    """
    return extract_svg_clock_time(svg_content) is not None


def extract_svg_math_coordinates(svg_content: str) -> Optional[str]:
    """
    Extract exact math coordinates from SVG circle elements (plotted points).

    Reads cx/cy pixel values from circle elements and maps them back to math
    coordinates using labeled axis tick positions. Handles both coordinate plane
    and number line diagrams.

    Returns a formatted string with programmatic analysis results, or None if
    the SVG has no circles or if the coordinate scale cannot be determined.
    """
    try:
        import xml.etree.ElementTree as ET

        # Guard: clock SVGs also have circles and lines but represent a different
        # kind of diagram. Bail out early so we don't misidentify them.
        if _is_clock_svg(svg_content):
            return None

        # Strip XML namespace declarations so ElementTree uses plain tag names
        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        # Collapse namespace-prefixed tags: <svg:circle> → <circle>
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)

        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag: str) -> str:
            """Strip {namespace} prefix from ElementTree tag name."""
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name: str):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        # --- Circles (plotted points) ---
        circles = iter_by_tag(root, 'circle')
        if not circles:
            return None

        circle_data = []
        for c in circles:
            try:
                cx = float(c.get('cx', 0))
                cy = float(c.get('cy', 0))
                r = float(c.get('r', 0))
                circle_data.append({'cx': cx, 'cy': cy, 'r': r, '_elem': c})
            except (ValueError, TypeError):
                continue

        if not circle_data:
            return None

        # --- Text elements (axis labels and point labels) ---
        text_elems = iter_by_tag(root, 'text')
        text_data = []
        for t in text_elems:
            content = ''.join(t.itertext()).strip()
            if not content:
                continue
            try:
                x = float(t.get('x', 0))
                y = float(t.get('y', 0))
            except (ValueError, TypeError):
                x, y = 0.0, 0.0
            text_data.append({'content': content, 'x': x, 'y': y})

        # --- Integer axis labels ---
        axis_labels = []
        for t in text_data:
            try:
                val = int(t['content'])
                axis_labels.append({'value': val, 'x': t['x'], 'y': t['y']})
            except ValueError:
                continue

        if len(axis_labels) < 2:
            return None

        y_vals = [l['y'] for l in axis_labels]
        x_vals = [l['x'] for l in axis_labels]
        y_spread = max(y_vals) - min(y_vals)

        is_number_line = y_spread < 30

        # --- Number line diagram ---
        if is_number_line:
            sorted_labels = sorted(axis_labels, key=lambda l: l['x'])
            scale_estimates = []
            for i in range(1, len(sorted_labels)):
                dp = sorted_labels[i]['x'] - sorted_labels[i - 1]['x']
                dv = sorted_labels[i]['value'] - sorted_labels[i - 1]['value']
                if dv != 0 and dp > 0:
                    scale_estimates.append(dp / dv)
            if not scale_estimates:
                return None
            scale_x = sum(scale_estimates) / len(scale_estimates)
            origin_x = sum(l['x'] - l['value'] * scale_x for l in sorted_labels) / len(sorted_labels)
            origin_y = sum(y_vals) / len(y_vals)

            lines = [
                "SVG PROGRAMMATIC ANALYSIS (authoritative - trust over visual estimation):",
                "Detected: Number line diagram",
                "Plotted points (from SVG source cx/cy attributes):",
            ]
            for i, cd in enumerate(circle_data):
                lines.append(f"  - Point {i + 1}: SVG pixel ({cd['cx']}, {cd['cy']})")
            lines.append(f"Axis scale: 1 coordinate unit = {scale_x:.1f} SVG pixels")
            lines.append(f"Origin at SVG pixel: ({origin_x:.1f}, {origin_y:.1f})")
            lines.append("Computed math coordinates:")
            for i, cd in enumerate(circle_data):
                math_x = (cd['cx'] - origin_x) / scale_x
                lines.append(f"  - Point {i + 1}: x = {math_x:.6g} [exact from SVG geometry]")
            lines.append(
                "CRITICAL: These coordinates are EXACT from SVG source. "
                "Points that appear visually ON a grid line may actually be at decimal positions. "
                "Trust this over visual appearance."
            )
            return '\n'.join(lines)

        # --- Coordinate plane diagram ---
        # Cluster integer labels by y-position to identify x-axis row
        y_clusters: dict = {}
        for l in axis_labels:
            placed = False
            for ky in list(y_clusters.keys()):
                if abs(l['y'] - ky) < 30:
                    y_clusters[ky].append(l)
                    placed = True
                    break
            if not placed:
                y_clusters[l['y']] = [l]

        x_axis_labels = max(y_clusters.values(), key=len) if y_clusters else []

        # Cluster integer labels by x-position to identify y-axis column
        x_clusters: dict = {}
        for l in axis_labels:
            placed = False
            for kx in list(x_clusters.keys()):
                if abs(l['x'] - kx) < 30:
                    x_clusters[kx].append(l)
                    placed = True
                    break
            if not placed:
                x_clusters[l['x']] = [l]

        y_axis_labels = max(x_clusters.values(), key=len) if x_clusters else []

        if len(x_axis_labels) < 2:
            return None

        # X scale
        x_axis_sorted = sorted(x_axis_labels, key=lambda l: l['x'])
        scale_x_estimates = []
        for i in range(1, len(x_axis_sorted)):
            dp = x_axis_sorted[i]['x'] - x_axis_sorted[i - 1]['x']
            dv = x_axis_sorted[i]['value'] - x_axis_sorted[i - 1]['value']
            if dv != 0 and dp > 0:
                scale_x_estimates.append(dp / dv)
        if not scale_x_estimates:
            return None
        scale_x = sum(scale_x_estimates) / len(scale_x_estimates)
        origin_x = sum(l['x'] - l['value'] * scale_x for l in x_axis_sorted) / len(x_axis_sorted)

        # Y scale (SVG y increases downward, math y increases upward)
        if len(y_axis_labels) >= 2:
            y_axis_sorted = sorted(y_axis_labels, key=lambda l: l['y'])
            scale_y_estimates = []
            for i in range(1, len(y_axis_sorted)):
                dp = y_axis_sorted[i]['y'] - y_axis_sorted[i - 1]['y']
                dv = y_axis_sorted[i]['value'] - y_axis_sorted[i - 1]['value']
                if dv != 0:
                    scale_y_estimates.append(dp / dv)  # Expected to be negative
            if scale_y_estimates:
                scale_y_raw = sum(scale_y_estimates) / len(scale_y_estimates)
                scale_y = abs(scale_y_raw)
                origin_y = sum(l['y'] - l['value'] * scale_y_raw for l in y_axis_sorted) / len(y_axis_sorted)
            else:
                scale_y = scale_x
                origin_y = sum(l['y'] for l in x_axis_labels) / len(x_axis_labels)
        else:
            scale_y = scale_x
            origin_y = sum(l['y'] for l in x_axis_labels) / len(x_axis_labels)

        # Associate single-uppercase-letter labels with nearby circles
        alpha_texts = [t for t in text_data if re.match(r'^[A-Z]$', t['content'])]
        point_labels = {}
        for cd in circle_data:
            best_label = None
            best_dist = float('inf')
            for t in alpha_texts:
                dist = ((t['x'] - cd['cx']) ** 2 + (t['y'] - cd['cy']) ** 2) ** 0.5
                if dist < 50 and dist < best_dist:
                    best_dist = dist
                    best_label = t['content']
            point_labels[id(cd)] = best_label

        lines = [
            "SVG PROGRAMMATIC ANALYSIS (authoritative - trust over visual estimation):",
            "Detected: Coordinate plane diagram",
            "Plotted points (from SVG source cx/cy attributes):",
        ]
        for i, cd in enumerate(circle_data):
            label = point_labels.get(id(cd)) or f"Point {i + 1}"
            lines.append(f"  - {label}: SVG pixel ({cd['cx']}, {cd['cy']})")
        lines.append(f"Axis scale: 1 coordinate unit = {scale_x:.1f} SVG pixels")
        lines.append(f"Origin at SVG pixel: ({origin_x:.1f}, {origin_y:.1f})")
        lines.append("Computed math coordinates:")
        for i, cd in enumerate(circle_data):
            label = point_labels.get(id(cd)) or f"Point {i + 1}"
            math_x = (cd['cx'] - origin_x) / scale_x
            math_y = -(cd['cy'] - origin_y) / scale_y
            lines.append(f"  - {label}: ({math_x:.6g}, {math_y:.6g}) [exact from SVG geometry]")
        lines.append(
            "CRITICAL: These coordinates are EXACT from SVG source. "
            "Points that appear visually ON a grid line may actually be at decimal positions. "
            "Trust this over visual appearance."
        )
        return '\n'.join(lines)

    except Exception as e:
        logger.debug(f"SVG coordinate extraction failed: {e}")
        return None


def extract_svg_tick_intervals(svg_content: str) -> Optional[str]:
    """
    Count tick marks on ruler/number-line SVGs to determine interval denominator.

    Parses <line> elements and <text> integer labels to count how many equal
    divisions exist between consecutive integers on the ruler/number line.
    Returns authoritative denominator info, or None if not a ruler/number-line SVG.
    """
    try:
        import xml.etree.ElementTree as ET

        if _is_clock_svg(svg_content):
            return None

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)
        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag):
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        # Get text labels — find integer labels
        text_elems = iter_by_tag(root, 'text')
        text_data = []
        for t in text_elems:
            content = ''.join(t.itertext()).strip()
            try:
                x = float(t.get('x', 0))
                y = float(t.get('y', 0))
            except (ValueError, TypeError):
                x, y = 0.0, 0.0
            text_data.append({'content': content, 'x': x, 'y': y})

        # Find integer labels
        int_labels = []
        for t in text_data:
            try:
                val = int(t['content'])
                int_labels.append({'value': val, 'x': t['x'], 'y': t['y']})
            except ValueError:
                continue

        if len(int_labels) < 2:
            return None

        # Check if this looks like a horizontal ruler or number line
        y_vals = [l['y'] for l in int_labels]
        y_spread = max(y_vals) - min(y_vals)
        # For number lines: labels are roughly at same y; for rulers: similar
        if y_spread > 100:
            return None  # Looks like coordinate plane labels, not a ruler

        sorted_labels = sorted(int_labels, key=lambda l: l['x'])

        # Get all line elements
        line_elems = iter_by_tag(root, 'line')
        lines_data = []
        for ln in line_elems:
            try:
                x1 = float(ln.get('x1', 0))
                y1 = float(ln.get('y1', 0))
                x2 = float(ln.get('x2', 0))
                y2 = float(ln.get('y2', 0))
                lines_data.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2})
            except (ValueError, TypeError):
                continue

        if not lines_data:
            return None

        # Tick marks are short vertical lines. The baseline/axis is horizontal.
        # Filter: tick marks have small x-extent (dx < 5) and notable y-extent (dy > 3)
        tick_lines = [l for l in lines_data if abs(l['x2'] - l['x1']) < 10 and abs(l['y2'] - l['y1']) > 3]

        if len(tick_lines) < 2:
            return None

        # Count ticks between consecutive integer labels
        results = []
        for i in range(len(sorted_labels) - 1):
            left_x = sorted_labels[i]['x']
            right_x = sorted_labels[i + 1]['x']
            left_val = sorted_labels[i]['value']
            right_val = sorted_labels[i + 1]['value']

            if right_val - left_val != 1:
                continue  # Only analyze unit intervals

            # Count tick marks strictly between left and right label x positions
            ticks_in_range = [
                t for t in tick_lines
                if left_x < (t['x1'] + t['x2']) / 2 < right_x
            ]

            # De-duplicate by x position (within 2px)
            unique_xs = []
            for t in sorted(ticks_in_range, key=lambda tt: (tt['x1'] + tt['x2']) / 2):
                mx = (t['x1'] + t['x2']) / 2
                if not unique_xs or abs(mx - unique_xs[-1]) > 2:
                    unique_xs.append(mx)

            n_ticks = len(unique_xs)

            # Heuristic: if tick at left_x or right_x position exists, subtract those
            endpoint_ticks = sum(1 for x in unique_xs if abs(x - left_x) < 5 or abs(x - right_x) < 5)
            internal_ticks = n_ticks - endpoint_ticks
            intervals = internal_ticks + 1

            results.append({
                'from': left_val,
                'to': right_val,
                'internal_ticks': internal_ticks,
                'total_ticks_including_endpoints': n_ticks,
                'intervals': intervals,
            })

        if not results:
            return None

        # Determine consensus interval count
        interval_counts = [r['intervals'] for r in results]
        from collections import Counter
        most_common_intervals = Counter(interval_counts).most_common(1)[0][0]

        # Object length detection: many ruler-measurement questions place an
        # object (nail, crayon, pencil) on top of the ruler. The object is
        # typically rendered as a path or a long, thin rect that is NOT a tick
        # mark. Find its left/right extents and convert to inches/units using
        # the integer-label scale.
        object_info: Optional[dict] = None
        try:
            min_x = sorted_labels[0]['x']
            max_x = sorted_labels[-1]['x']
            unit_px = (max_x - min_x) / max(
                1, sorted_labels[-1]['value'] - sorted_labels[0]['value']
            )
            if unit_px > 0:
                # Collect candidate object x-extents.
                candidates: list[tuple[float, float]] = []
                for r in iter_by_tag(root, 'rect'):
                    try:
                        rx = float(r.get('x', 0))
                        ry = float(r.get('y', 0))
                        rw = float(r.get('width', 0))
                        rh = float(r.get('height', 0))
                    except (ValueError, TypeError):
                        continue
                    if rw <= 0 or rh <= 0:
                        continue
                    # Skip the ruler itself: very large rect aligned with the
                    # ruler band, with rw > 80% of ruler span.
                    fill = (r.get('fill') or '').strip().lower()
                    if rw > 0.8 * (max_x - min_x) and rh > unit_px * 0.5:
                        continue
                    if rw < 0.05 * unit_px:
                        continue
                    # data-part hints make this trivial when present.
                    dp = (r.get('data-part') or '').lower()
                    if dp and 'tick' in dp:
                        continue
                    candidates.append((rx, rx + rw))
                for p in iter_by_tag(root, 'path'):
                    d = p.get('d') or ''
                    # Trace the path command-by-command. Each command's final
                    # numeric pair is the new (x, y) point; we sample those
                    # endpoints (and the M start point) as the object outline.
                    # This avoids confusing Q/C/A control-point numbers with
                    # actual path vertices.
                    cmd_args = {
                        'M': 2, 'm': 2, 'L': 2, 'l': 2,
                        'H': 1, 'h': 1, 'V': 1, 'v': 1,
                        'T': 2, 't': 2,
                        'Q': 4, 'q': 4, 'S': 4, 's': 4,
                        'C': 6, 'c': 6,
                        'A': 7, 'a': 7,
                        'Z': 0, 'z': 0,
                    }
                    xs: list[float] = []
                    cur_x = 0.0
                    cur_y = 0.0
                    start_x = 0.0
                    tokens = re.findall(
                        r"([MmLlHhVvTtQqSsCcAaZz])|(-?\d*\.?\d+(?:[eE][-+]?\d+)?)",
                        d,
                    )
                    cmd: Optional[str] = None
                    arg_buffer: list[float] = []
                    pending_n = 0
                    for cmd_tok, num_tok in tokens:
                        if cmd_tok:
                            cmd = cmd_tok
                            arg_buffer = []
                            pending_n = cmd_args.get(cmd, 0)
                            if cmd in ('Z', 'z'):
                                cur_x, cur_y = start_x, cur_y
                                continue
                            continue
                        if cmd is None or pending_n == 0:
                            continue
                        try:
                            arg_buffer.append(float(num_tok))
                        except ValueError:
                            continue
                        if len(arg_buffer) < pending_n:
                            continue
                        # Process one full command instance.
                        if cmd in ('M', 'L', 'T'):
                            cur_x, cur_y = arg_buffer[-2], arg_buffer[-1]
                        elif cmd in ('m', 'l', 't'):
                            cur_x += arg_buffer[-2]
                            cur_y += arg_buffer[-1]
                        elif cmd == 'H':
                            cur_x = arg_buffer[-1]
                        elif cmd == 'h':
                            cur_x += arg_buffer[-1]
                        elif cmd == 'V':
                            cur_y = arg_buffer[-1]
                        elif cmd == 'v':
                            cur_y += arg_buffer[-1]
                        elif cmd in ('Q', 'S', 'C'):
                            cur_x, cur_y = arg_buffer[-2], arg_buffer[-1]
                        elif cmd in ('q', 's', 'c'):
                            cur_x += arg_buffer[-2]
                            cur_y += arg_buffer[-1]
                        elif cmd == 'A':
                            cur_x, cur_y = arg_buffer[-2], arg_buffer[-1]
                        elif cmd == 'a':
                            cur_x += arg_buffer[-2]
                            cur_y += arg_buffer[-1]
                        if cmd in ('M', 'm'):
                            start_x = cur_x
                            # After M, subsequent implicit pairs are L/l
                            cmd = 'L' if cmd == 'M' else 'l'
                            pending_n = cmd_args[cmd]
                        xs.append(cur_x)
                        arg_buffer = []
                    if not xs:
                        continue
                    px_lo, px_hi = min(xs), max(xs)
                    if px_hi - px_lo < 0.1 * unit_px:
                        continue
                    candidates.append((px_lo, px_hi))
                if candidates:
                    # Combine fragments of the same object: rulers commonly
                    # split the body and the tip into separate elements
                    # (wrapper rect + arrow path). Use single-link clustering
                    # over candidate intervals \u2014 two intervals are linked when
                    # they touch or overlap (within a small slack relative to
                    # the unit length). Pick the cluster whose left edge is
                    # nearest the "0" tick.
                    slack = max(2.0, unit_px * 0.05)
                    sorted_cands = sorted(candidates, key=lambda c: c[0])
                    clusters: list[list[tuple[float, float]]] = []
                    for c in sorted_cands:
                        if clusters and c[0] - max(x[1] for x in clusters[-1]) <= slack:
                            clusters[-1].append(c)
                        else:
                            clusters.append([c])
                    cluster_extents = [
                        (min(x[0] for x in cl), max(x[1] for x in cl))
                        for cl in clusters
                    ]
                    cluster_extents.sort(key=lambda e: abs(e[0] - min_x))
                    obj_lo, obj_hi = cluster_extents[0]
                    length_units = (obj_hi - obj_lo) / unit_px
                    # Round to nearest fraction with the detected denominator.
                    denom = most_common_intervals
                    rounded_numer = round(length_units * denom)
                    rounded = rounded_numer / denom
                    object_info = {
                        'length_raw': length_units,
                        'rounded': rounded,
                        'denom': denom,
                        'numer': rounded_numer,
                    }
        except Exception:
            object_info = None

        lines_out = [
            "SVG TICK INTERVAL ANALYSIS (authoritative - trust over visual estimation):",
            "Detected: Ruler or number line with tick marks",
            f"Number of equal intervals between consecutive integers: {most_common_intervals}",
            f"This means the denominator of the smallest fraction unit is: {most_common_intervals}",
            "Per-segment breakdown:",
        ]
        for r in results:
            lines_out.append(
                f"  - Between {r['from']} and {r['to']}: {r['internal_ticks']} internal ticks "
                f"\u2192 {r['intervals']} equal intervals (denominator = {r['intervals']})"
            )
        if object_info:
            length_str: str
            denom = object_info['denom']
            numer = object_info['numer']
            if denom > 1 and numer % denom != 0:
                whole = numer // denom
                rem = numer - whole * denom
                length_str = (
                    f"{whole} {rem}/{denom}" if whole > 0 else f"{rem}/{denom}"
                )
            else:
                length_str = str(numer // denom)
            lines_out.extend([
                "Object length (object on the ruler):",
                f"  - Measured raw length: {object_info['length_raw']:.3f} units",
                f"  - Snapped to ruler grid: {length_str} unit(s)",
                "  - This is the deterministic measurement of the object's "
                "extent relative to the labeled tick scale. Trust this over "
                "visual estimation of the object's endpoint.",
            ])
        lines_out.append(
            "CRITICAL: This denominator is computed from SVG tick mark elements. "
            "If the question uses a different denominator, the SVG ruler does NOT match the question."
        )
        return '\n'.join(lines_out)

    except Exception as e:
        logger.debug(f"SVG tick interval extraction failed: {e}")
        return None


def extract_svg_fraction_model_analysis(svg_content: str) -> Optional[str]:
    """
    Analyze fraction model shapes in SVG MCQ images.

    Finds labeled regions (A/B/C/D), counts total vs shaded parts per region,
    and flags if any two regions show the same fraction (duplicate correct answers).
    Returns None if this doesn't look like a fraction model SVG.
    """
    try:
        import xml.etree.ElementTree as ET
        from collections import defaultdict

        if _is_clock_svg(svg_content):
            return None

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)
        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag):
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        # Find text labels A, B, C, D
        text_elems = iter_by_tag(root, 'text')
        option_labels = []
        for t in text_elems:
            content = ''.join(t.itertext()).strip()
            if re.match(r'^[A-D]$', content):
                try:
                    x = float(t.get('x', 0))
                    y = float(t.get('y', 0))
                    option_labels.append({'label': content, 'x': x, 'y': y})
                except (ValueError, TypeError):
                    pass

        if len(option_labels) < 2:
            return None  # Not a multi-option MCQ image

        # Sort labels left-to-right (or top-to-bottom)
        option_labels.sort(key=lambda l: (l['x'], l['y']))

        # Find all filled shapes (rect, polygon, path, circle, ellipse)
        shape_tags = ['rect', 'polygon', 'path', 'circle', 'ellipse']
        all_shapes = []
        for tag in shape_tags:
            for elem in iter_by_tag(root, tag):
                fill = elem.get('fill', '').strip().lower()
                if fill in ('none', '', 'transparent'):
                    continue

                # Get approximate bounding box center
                cx_val, cy_val = None, None
                if tag == 'rect':
                    try:
                        cx_val = float(elem.get('x', 0)) + float(elem.get('width', 0)) / 2
                        cy_val = float(elem.get('y', 0)) + float(elem.get('height', 0)) / 2
                    except (ValueError, TypeError):
                        pass
                elif tag == 'circle':
                    try:
                        cx_val = float(elem.get('cx', 0))
                        cy_val = float(elem.get('cy', 0))
                    except (ValueError, TypeError):
                        pass
                elif tag == 'polygon':
                    points_str = elem.get('points', '')
                    pts = re.findall(r'([\d.]+),([\d.]+)', points_str)
                    if pts:
                        xs = [float(p[0]) for p in pts]
                        ys = [float(p[1]) for p in pts]
                        cx_val = sum(xs) / len(xs)
                        cy_val = sum(ys) / len(ys)

                # For path/ellipse: skip detailed parsing
                if cx_val is None:
                    continue

                is_shaded = fill not in ('white', '#ffffff', '#fff', 'rgb(255,255,255)')
                all_shapes.append({'cx': cx_val, 'cy': cy_val, 'fill': fill, 'is_shaded': is_shaded, 'tag': tag})

        if not all_shapes or not option_labels:
            return None

        # Assign shapes to nearest option label (by x-proximity if horizontal layout)
        sorted_by_x = sorted(option_labels, key=lambda l: l['x'])
        label_regions = []
        for i, lbl in enumerate(sorted_by_x):
            if i == 0:
                x_min = 0
            else:
                x_min = (sorted_by_x[i - 1]['x'] + lbl['x']) / 2
            if i == len(sorted_by_x) - 1:
                x_max = float('inf')
            else:
                x_max = (lbl['x'] + sorted_by_x[i + 1]['x']) / 2
            label_regions.append({'label': lbl['label'], 'x_min': x_min, 'x_max': x_max, 'x_center': lbl['x']})

        region_shapes = defaultdict(list)
        for shape in all_shapes:
            for region in label_regions:
                if region['x_min'] <= shape['cx'] < region['x_max']:
                    region_shapes[region['label']].append(shape)
                    break

        if not any(region_shapes.values()):
            return None

        # Analyze each region
        region_analysis = {}
        for region in label_regions:
            lbl = region['label']
            shapes = region_shapes[lbl]
            if not shapes:
                continue
            total = len(shapes)
            shaded = sum(1 for s in shapes if s['is_shaded'])
            region_analysis[lbl] = {'total': total, 'shaded': shaded, 'fraction': f"{shaded}/{total}"}

        if len(region_analysis) < 2:
            return None

        # Detect duplicates (same shaded/total)
        fraction_map = defaultdict(list)
        for lbl, info in region_analysis.items():
            fraction_map[info['fraction']].append(lbl)
        duplicates = {frac: labels for frac, labels in fraction_map.items() if len(labels) > 1}

        lines_out = [
            "SVG FRACTION MODEL ANALYSIS (authoritative - trust over visual estimation):",
            "Detected: MCQ fraction model image with multiple labeled regions",
            "Fraction analysis per option:",
        ]
        for lbl in sorted(region_analysis.keys()):
            info = region_analysis[lbl]
            lines_out.append(
                f"  Option {lbl}: {info['shaded']} shaded part(s) out of {info['total']} total \u2192 fraction = {info['fraction']}"
            )
        if duplicates:
            lines_out.append("\u26a0\ufe0f DUPLICATE FRACTIONS DETECTED (multiple correct answers):")
            for frac, labels in duplicates.items():
                lines_out.append(f"  Options {', '.join(labels)} all show {frac} \u2014 this creates multiple correct answers!")
        else:
            lines_out.append("\u2713 All options show distinct fractions (no duplicates detected).")
        lines_out.append(
            "CRITICAL: These counts are from SVG element attributes. "
            "Trust this over visual estimation, especially for shapes that look similar."
        )
        return '\n'.join(lines_out)

    except Exception as e:
        logger.debug(f"SVG fraction model analysis failed: {e}")
        return None


def extract_svg_protractor_angle(svg_content: str) -> Optional[str]:
    """
    Extract the measured angle from a protractor SVG.

    Identifies degree-label text elements (0–180) to confirm a protractor,
    estimates the baseline center, then finds the longest line emanating from
    that center as the measurement ray and computes its angle.

    Uses xml.etree.ElementTree for SVG parsing (NOT regex).

    Returns a formatted string, or None if no protractor is detected or
    extraction fails.
    """
    try:
        import xml.etree.ElementTree as ET

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)

        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag: str) -> str:
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name: str):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        # Collect degree labels
        text_elems = iter_by_tag(root, 'text')
        degree_labels = []
        for t in text_elems:
            txt = ''.join(t.itertext()).strip()
            try:
                val = int(txt)
                if 0 <= val <= 360:
                    degree_labels.append({
                        'value': val,
                        'x': float(t.get('x', 0)),
                        'y': float(t.get('y', 0)),
                    })
            except (ValueError, TypeError):
                continue

        if len(degree_labels) < 3:
            return None

        zero_label = next((l for l in degree_labels if l['value'] == 0), None)
        label_180 = next((l for l in degree_labels if l['value'] == 180), None)
        if zero_label is None:
            return None

        # Center: midpoint of 0° and 180° labels, or average of all labels
        if label_180:
            cx = (zero_label['x'] + label_180['x']) / 2
            cy = (zero_label['y'] + label_180['y']) / 2
        else:
            cx = sum(l['x'] for l in degree_labels) / len(degree_labels)
            cy = sum(l['y'] for l in degree_labels) / len(degree_labels)

        # Find the longest ray from center among line elements
        line_elems = iter_by_tag(root, 'line')
        best_angle = None
        best_length = 0.0
        for ln in line_elems:
            try:
                x1 = float(ln.get('x1', 0))
                y1 = float(ln.get('y1', 0))
                x2 = float(ln.get('x2', 0))
                y2 = float(ln.get('y2', 0))
                d1 = math.sqrt((x1 - cx) ** 2 + (y1 - cy) ** 2)
                d2 = math.sqrt((x2 - cx) ** 2 + (y2 - cy) ** 2)
                length = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
                if min(d1, d2) < 20 and length > best_length:
                    best_length = length
                    tip_x = x1 if d1 > d2 else x2
                    tip_y = y1 if d1 > d2 else y2
                    # Standard math angle: 0° = east, positive = CCW
                    angle = math.degrees(math.atan2(-(tip_y - cy), tip_x - cx))
                    if angle < 0:
                        angle += 180
                    best_angle = angle
            except (ValueError, TypeError):
                continue

        if best_angle is None:
            return None

        return (
            "SVG PROGRAMMATIC ANALYSIS (authoritative - trust over visual estimation):\n"
            "Detected: Protractor\n"
            f"Measured angle: {round(best_angle)}°\n"
            "CRITICAL: This angle is computed EXACTLY from SVG ray geometry. "
            "Trust this over visual estimation by the vision model."
        )
    except Exception as e:
        logger.debug(f"SVG protractor angle extraction failed: {e}")
        return None


def extract_svg_grid_area(svg_content: str) -> Optional[str]:
    """
    Count shaded unit squares in grid area SVGs.

    Identifies the most common rect size as the unit cell, then groups cells
    by non-background fill color and counts them per region (labeled A, B, …).

    Uses xml.etree.ElementTree for SVG parsing (NOT regex).

    Returns a formatted string, or None if no grid with shaded cells is
    detected or extraction fails.
    """
    try:
        import xml.etree.ElementTree as ET

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)

        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag: str) -> str:
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name: str):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        def _resolve_fill(elem) -> str:
            style = elem.get('style', '')
            m = re.search(r'fill\s*:\s*([^;]+)', style)
            return (m.group(1).strip() if m else elem.get('fill', '')).lower()

        rect_elems = iter_by_tag(root, 'rect')
        if len(rect_elems) < 4:
            return None

        cell_sizes: dict = {}
        rects_data = []
        for r in rect_elems:
            try:
                w = round(float(r.get('width', 0)), 1)
                h = round(float(r.get('height', 0)), 1)
                if w <= 0 or h <= 0:
                    continue
                fill = _resolve_fill(r)
                rects_data.append({'w': w, 'h': h, 'fill': fill})
                cell_sizes[(w, h)] = cell_sizes.get((w, h), 0) + 1
            except (ValueError, TypeError):
                continue

        if not rects_data or not cell_sizes:
            return None

        unit_size = max(cell_sizes, key=cell_sizes.get)
        unit_rects = [r for r in rects_data if (r['w'], r['h']) == unit_size]
        if len(unit_rects) < 4:
            return None

        _bg = {'white', '#ffffff', '#fff', 'none', '', 'transparent'}
        fill_counts: dict = {}
        for r in unit_rects:
            f = r['fill']
            if f not in _bg:
                fill_counts[f] = fill_counts.get(f, 0) + 1

        if not fill_counts:
            return None

        lines = [
            "SVG PROGRAMMATIC ANALYSIS (authoritative - trust over visual estimation):",
            f"Detected: Grid area diagram ({len(unit_rects)} unit cells, "
            f"cell size {unit_size[0]}×{unit_size[1]}px)",
        ]
        for i, (fill_color, count) in enumerate(sorted(fill_counts.items())):
            label = chr(ord('A') + i)
            lines.append(f"Region {label}: {count} unit squares (fill: {fill_color}).")
        lines.append(f"Total shaded unit squares: {sum(fill_counts.values())}.")
        lines.append(
            "CRITICAL: These square counts are EXACT from SVG geometry. "
            "Trust this over visual estimation by the vision model."
        )
        return "\n".join(lines)
    except Exception as e:
        logger.debug(f"SVG grid area extraction failed: {e}")
        return None


def extract_svg_box_whisker(svg_content: str) -> Optional[str]:
    """
    Extract five-number summary from a box-and-whisker plot SVG.

    Identifies the axis scale from integer tick labels, then reads the box
    (rect element), median line, and whisker endpoints to compute min, Q1,
    median, Q3, max.  Returns an authoritative context string, or None if
    the SVG is not a recognisable box plot.
    """
    try:
        if _is_clock_svg(svg_content):
            return None

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)
        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag: str) -> str:
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name: str):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        # --- Axis labels (integer text elements) ---
        text_elems = iter_by_tag(root, 'text')
        int_labels: list[dict] = []
        for t in text_elems:
            content = ''.join(t.itertext()).strip()
            try:
                val = int(content)
            except ValueError:
                continue
            try:
                x = float(t.get('x', 0))
                y = float(t.get('y', 0))
            except (ValueError, TypeError):
                continue
            int_labels.append({'value': val, 'x': x, 'y': y})

        if len(int_labels) < 2:
            return None

        y_vals = [l['y'] for l in int_labels]
        if max(y_vals) - min(y_vals) > 50:
            return None

        sorted_labels = sorted(int_labels, key=lambda l: l['x'])
        scale_estimates = []
        for i in range(1, len(sorted_labels)):
            dp = sorted_labels[i]['x'] - sorted_labels[i - 1]['x']
            dv = sorted_labels[i]['value'] - sorted_labels[i - 1]['value']
            if dv != 0 and dp > 0:
                scale_estimates.append(dp / dv)
        if not scale_estimates:
            return None
        px_per_unit = statistics.mean(scale_estimates)
        origin_x = statistics.mean(
            l['x'] - l['value'] * px_per_unit for l in sorted_labels
        )

        def px_to_val(px: float) -> float:
            return (px - origin_x) / px_per_unit

        # --- Box (rect element above the axis) ---
        axis_y = statistics.mean(y_vals)
        rects = iter_by_tag(root, 'rect')
        box_rect = None
        for r in rects:
            try:
                rx = float(r.get('x', 0))
                ry = float(r.get('y', 0))
                rw = float(r.get('width', 0))
                rh = float(r.get('height', 0))
            except (ValueError, TypeError):
                continue
            cy = ry + rh / 2
            if rw > 10 and rh > 5 and cy < axis_y:
                box_rect = {'x': rx, 'y': ry, 'w': rw, 'h': rh}
                break

        if box_rect is None:
            return None

        q1_val = px_to_val(box_rect['x'])
        q3_val = px_to_val(box_rect['x'] + box_rect['w'])

        # --- Median line (vertical line inside the box) ---
        lines = iter_by_tag(root, 'line')
        median_val = None
        box_left = box_rect['x']
        box_right = box_rect['x'] + box_rect['w']
        box_top = box_rect['y']
        box_bottom = box_rect['y'] + box_rect['h']

        for ln in lines:
            try:
                x1 = float(ln.get('x1', 0))
                y1 = float(ln.get('y1', 0))
                x2 = float(ln.get('x2', 0))
                y2 = float(ln.get('y2', 0))
            except (ValueError, TypeError):
                continue
            if (
                abs(x1 - x2) < 2
                and box_left < x1 < box_right
                and min(y1, y2) <= box_top + 5
                and max(y1, y2) >= box_bottom - 5
            ):
                median_val = px_to_val((x1 + x2) / 2)
                break

        if median_val is None:
            return None

        # --- Whisker endpoints (horizontal lines extending from the box) ---
        box_cy = box_rect['y'] + box_rect['h'] / 2
        whisker_min_x = box_left
        whisker_max_x = box_right

        for ln in lines:
            try:
                x1 = float(ln.get('x1', 0))
                y1 = float(ln.get('y1', 0))
                x2 = float(ln.get('x2', 0))
                y2 = float(ln.get('y2', 0))
            except (ValueError, TypeError):
                continue
            if abs(y1 - y2) < 3 and abs((y1 + y2) / 2 - box_cy) < 15:
                lx, rx = min(x1, x2), max(x1, x2)
                if rx <= box_left + 2:
                    whisker_min_x = min(whisker_min_x, lx)
                elif lx >= box_right - 2:
                    whisker_max_x = max(whisker_max_x, rx)

        min_val = px_to_val(whisker_min_x)
        max_val = px_to_val(whisker_max_x)

        def _r(v: float) -> str:
            rounded = round(v)
            if abs(v - rounded) < 0.3:
                return str(rounded)
            return f"{v:.1f}"

        iqr = q3_val - q1_val
        full_range = max_val - min_val

        lines_out = [
            "SVG BOX-AND-WHISKER ANALYSIS (authoritative - trust over visual estimation):",
            "Detected: Box-and-whisker (box plot) diagram",
            "Five-number summary (computed from SVG geometry):",
            f"  Minimum:  {_r(min_val)}",
            f"  Q1:       {_r(q1_val)}",
            f"  Median:   {_r(median_val)}",
            f"  Q3:       {_r(q3_val)}",
            f"  Maximum:  {_r(max_val)}",
            "Derived statistics:",
            f"  IQR (Q3 - Q1):    {_r(iqr)}",
            f"  Range (Max - Min): {_r(full_range)}",
            "CRITICAL: These values are computed EXACTLY from SVG element positions "
            "and axis labels. Trust this over visual estimation. If the answer "
            "explanation references different min/max/median/IQR values, the "
            "explanation contradicts the SVG.",
        ]
        return '\n'.join(lines_out)

    except Exception as e:
        logger.debug(f"SVG box-whisker extraction failed: {e}")
        return None


def extract_svg_box_whisker_values(svg_content: str) -> Optional[Dict]:
    """
    Like extract_svg_box_whisker but returns raw numeric values.

    Returns dict with keys: min, q1, median, q3, max, iqr, range.
    Returns None if the SVG is not a box plot.
    """
    ctx = extract_svg_box_whisker(svg_content)
    if ctx is None:
        return None
    vals: Dict[str, float] = {}
    for line in ctx.splitlines():
        line = line.strip()
        if line.startswith("Minimum:"):
            vals["min"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("Q1:"):
            vals["q1"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("Median:"):
            vals["median"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("Q3:"):
            vals["q3"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("Maximum:"):
            vals["max"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("IQR"):
            vals["iqr"] = float(line.split(":", 1)[1].strip())
        elif line.startswith("Range"):
            vals["range"] = float(line.split(":", 1)[1].strip())
    if len(vals) < 5:
        return None
    return vals


def cross_reference_box_whisker(
    svg_values: Dict, content_text: str
) -> Optional[str]:
    """
    Compare SVG box-plot values against number sequences in content text.

    Scans for parenthesized comma-separated number lists (e.g. a fabricated
    dataset in an answer explanation) and flags when their min/max contradict
    the SVG's whisker endpoints.
    """
    dataset_pattern = re.compile(
        r'\(\s*'
        r'(\d+(?:\.\d+)?)'
        r'(?:\s*,\s*\d+(?:\.\d+)?){3,}'
        r'\s*\)'
    )
    # Strip SVG tags so we only search the prose
    prose = re.sub(r'<svg[\s\S]*?</svg>', '', content_text, flags=re.IGNORECASE)

    contradictions: list[str] = []
    svg_min = svg_values.get("min")
    svg_max = svg_values.get("max")

    for match in dataset_pattern.finditer(prose):
        nums = [float(n) for n in re.findall(r'\d+(?:\.\d+)?', match.group())]
        if len(nums) < 4:
            continue
        ds_min, ds_max = min(nums), max(nums)
        if svg_min is not None and abs(ds_min - svg_min) > 0.5:
            contradictions.append(
                f"Explanation dataset min={int(ds_min)} but SVG shows Minimum={int(svg_min)}"
            )
        if svg_max is not None and abs(ds_max - svg_max) > 0.5:
            contradictions.append(
                f"Explanation dataset max={int(ds_max)} but SVG shows Maximum={int(svg_max)}"
            )

    # Also check for explicit "Q1 = X" or "Q3 = X" claims that conflict.
    # Use negative lookbehind to avoid matching subtraction expressions
    # like "Q3 - Q1 = 55" where 55 is the IQR, not Q1.
    for label, key, pattern_str in [
        ("Q1", "q1", r'(?<![–\-]\s)Q1\s*[=:]\s*(\d+(?:\.\d+)?)'),
        ("Q3", "q3", r'(?<![–\-]\s)Q3\s*[=:]\s*(\d+(?:\.\d+)?)'),
        ("median", "median", r'median\s+(?:is|=|:)\s*(\d+(?:\.\d+)?)'),
    ]:
        svg_val = svg_values.get(key)
        if svg_val is None:
            continue
        for m in re.finditer(pattern_str, prose, re.IGNORECASE):
            claimed = float(m.group(1))
            if abs(claimed - svg_val) > 0.5:
                contradictions.append(
                    f"Explanation claims {label}={int(claimed)} but SVG shows {label}={int(svg_val)}"
                )

    if not contradictions:
        return None

    lines = [
        "## SVG vs EXPLANATION CONTRADICTION (AUTHORITATIVE)",
        "",
        "The answer explanation contains numerical claims that CONTRADICT "
        "the SVG box-and-whisker plot geometry:",
    ]
    for c in contradictions:
        lines.append(f"  - {c}")
    lines.extend([
        "",
        "The SVG geometry is the ground truth. The explanation fabricates or "
        "misrepresents the underlying data.",
        "This is a CONFIRMED factual inconsistency. You MUST score "
        "factual_accuracy = 0.0 for this content.",
    ])
    return "\n".join(lines)


def extract_svg_diagram_context(svg_content: str) -> Optional[str]:
    """
    Extract deterministic structural context for non-coordinate educational SVGs.

    Supports:
    - Unit-square shape sets (areas of panels A-D via grid geometry)
    - Rectangular arrays (rows x columns)
    - Number line/fraction models (interval counts per panel)

    Returns formatted authoritative context, or None when extraction is not
    confidently available.
    """
    try:
        if _is_clock_svg(svg_content):
            return None

        svg_clean = re.sub(r'\sxmlns(?::\w+)?="[^"]*"', '', svg_content)
        svg_clean = re.sub(r'<(\w+):(\w+)', r'<\2', svg_clean)
        svg_clean = re.sub(r'</(\w+):(\w+)', r'</\2', svg_clean)
        try:
            root = ET.fromstring(svg_clean)
        except ET.ParseError:
            root = ET.fromstring(svg_content)

        def strip_ns(tag: str) -> str:
            return re.sub(r'\{[^}]+\}', '', tag)

        def iter_by_tag(node, tag_name: str):
            return [e for e in node.iter() if strip_ns(e.tag) == tag_name]

        def _f(elem, key: str, default: float = 0.0) -> float:
            try:
                return float(elem.get(key, default))
            except (TypeError, ValueError):
                return default

        def _cluster(values: List[float], tol: float = 1e-2) -> List[float]:
            if not values:
                return []
            vals = sorted(values)
            groups: List[List[float]] = [[vals[0]]]
            for v in vals[1:]:
                if abs(v - groups[-1][-1]) <= tol:
                    groups[-1].append(v)
                else:
                    groups.append([v])
            return [sum(g) / len(g) for g in groups]

        def _interval_covered(intervals: List[tuple[float, float]], a: float, b: float, tol: float = 1e-2) -> bool:
            lo, hi = min(a, b), max(a, b)
            for i_lo, i_hi in intervals:
                if i_lo <= lo + tol and i_hi >= hi - tol:
                    return True
            return False

        panel_svgs = [s for s in iter_by_tag(root, "svg") if s is not root]

        def _panel_label(panel) -> Optional[str]:
            """Return the A-D option label rendered inside a nested SVG panel."""
            # Anchor on expected label formats only — avoid matching stray
            # single letters that appear inside ordinary text content.
            label_patterns = (
                re.compile(r"^Shape\s+([A-E])$"),
                re.compile(r"^Number line\s+([A-E])$"),
                re.compile(r"^([A-E])$"),
            )
            for t in iter_by_tag(panel, "text"):
                text = "".join(t.itertext()).strip()
                for pat in label_patterns:
                    match = pat.match(text)
                    if match:
                        return match.group(1).upper()
            return None

        panel_label_records = [
            {
                "index": idx,
                "label": label,
                "x": _f(panel, "x", 0.0),
                "y": _f(panel, "y", 0.0),
            }
            for idx, panel in enumerate(panel_svgs)
            for label in [_panel_label(panel)]
            if label is not None
        ]

        def _label_for_panel_index(panel_idx: int) -> Optional[str]:
            """Associate data panels with the closest preceding label panel."""
            previous = [r for r in panel_label_records if r["index"] < panel_idx]
            if not previous:
                return None
            return max(previous, key=lambda r: r["index"])["label"]

        def _has_unique_labels(infos: List[dict]) -> bool:
            labels = [p.get("label") for p in infos]
            return all(labels) and len(set(labels)) == len(labels)

        def _has_complete_unique_labels(infos: List[dict]) -> bool:
            labels = [p.get("label") for p in infos]
            if None in labels:
                return False
            return sorted(labels) == ["A", "B", "C", "D"]

        def _order_panels_row_major(panels: List[dict]) -> List[dict]:
            """
            Sort panels in reading order (top-to-bottom, then left-to-right).

            Cluster by y first (with tolerance based on the y-spread), then sort
            each row by x. Plain (y, x)-sort confuses 2x2 layouts (top-right vs
            bottom-left collide), so we cluster rows explicitly.
            """
            if not panels:
                return []
            ys = sorted(p["y"] for p in panels)
            spread = ys[-1] - ys[0]
            tol = max(5.0, spread * 0.25)
            sorted_by_y = sorted(panels, key=lambda p: p["y"])
            rows: List[List[dict]] = [[sorted_by_y[0]]]
            for p in sorted_by_y[1:]:
                if abs(p["y"] - rows[-1][-1]["y"]) <= tol:
                    rows[-1].append(p)
                else:
                    rows.append([p])
            ordered: List[dict] = []
            for row in rows:
                ordered.extend(sorted(row, key=lambda p: p["x"]))
            return ordered

        def _parse_points(points: str) -> List[tuple[float, float]]:
            parsed = []
            for x, y in re.findall(r"(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)", points or ""):
                parsed.append((float(x), float(y)))
            return parsed

        def _path_points(d_attr: str) -> List[tuple[float, float]]:
            # Generated polygonal shape paths use M/L commands followed by Z.
            # Ignore curves/arcs here; they are not quadrilateral answer shapes.
            if "Z" not in (d_attr or "").upper():
                return []
            parsed = []
            for cmd, x, y in re.findall(
                r"([ML])\s*(-?\d+(?:\.\d+)?),?\s*(-?\d+(?:\.\d+)?)",
                d_attr or "",
                flags=re.IGNORECASE,
            ):
                parsed.append((float(x), float(y)))
            return parsed

        def _rect_points(rect_elem) -> List[tuple[float, float]]:
            x, y = _f(rect_elem, "x"), _f(rect_elem, "y")
            w, h = _f(rect_elem, "width"), _f(rect_elem, "height")
            return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]

        def _side_lengths(points: List[tuple[float, float]]) -> List[float]:
            return [
                math.hypot(
                    points[(i + 1) % len(points)][0] - points[i][0],
                    points[(i + 1) % len(points)][1] - points[i][1],
                )
                for i in range(len(points))
            ]

        def _parallel(v1: tuple[float, float], v2: tuple[float, float], tol: float = 0.08) -> bool:
            cross = abs(v1[0] * v2[1] - v1[1] * v2[0])
            mag = ((v1[0] ** 2 + v1[1] ** 2) * (v2[0] ** 2 + v2[1] ** 2)) ** 0.5
            return mag > 0 and cross / mag <= tol

        def _tighter_parallel(v1: tuple[float, float], v2: tuple[float, float]) -> bool:
            # Tighter parallelism check used when classifying quadrilaterals
            # for rhombus/parallelogram MCQs — matches the magnitude-relative
            # tolerance used in #367's classifier.
            cross = v1[0] * v2[1] - v1[1] * v2[0]
            scale = max(1e-6, math.hypot(*v1) * math.hypot(*v2))
            return abs(cross) / scale < 0.02

        def _classify_quadrilateral(
            points: List[tuple[float, float]],
            side_marks: Optional[List[int]] = None,
        ) -> Optional[dict]:
            """
            Classify a 4-vertex polygon as rhombus/parallelogram.

            When ``side_marks`` is provided (per-side equal-length markers from
            tick marks or matched numeric labels), it is authoritative — equal
            markers ⇒ equal sides. Otherwise we fall back to vector/length
            geometry computed directly from the path.
            """
            if len(points) != 4:
                return None
            sides = _side_lengths(points)
            vectors = [
                (
                    points[(i + 1) % 4][0] - points[i][0],
                    points[(i + 1) % 4][1] - points[i][1],
                )
                for i in range(4)
            ]
            med = statistics.median(sides)
            all_equal_geom = med > 0 and max(abs(s - med) for s in sides) <= max(2.0, med * 0.08)
            pair_top_bottom = _tighter_parallel(vectors[0], vectors[2])
            pair_left_right = _tighter_parallel(vectors[1], vectors[3])
            is_parallelogram_geom = pair_top_bottom and pair_left_right and (
                abs(sides[0] - sides[2]) <= max(1.0, 0.05 * max(sides[0], sides[2]))
                and abs(sides[1] - sides[3]) <= max(1.0, 0.05 * max(sides[1], sides[3]))
            )
            is_rhombus_geom = is_parallelogram_geom and all_equal_geom

            is_rhombus_marked: Optional[bool] = None
            is_parallelogram_marked: Optional[bool] = None
            marker_source = "geometry"
            if side_marks and any(m > 0 for m in side_marks) and len(side_marks) == 4:
                all_same = all(m == side_marks[0] and m > 0 for m in side_marks)
                opposite_pairs = (
                    side_marks[0] == side_marks[2] > 0
                    and side_marks[1] == side_marks[3] > 0
                )
                is_rhombus_marked = all_same
                is_parallelogram_marked = opposite_pairs
                marker_source = "labels"

            is_rhombus = (
                is_rhombus_marked if is_rhombus_marked is not None else is_rhombus_geom
            )
            is_parallelogram = (
                is_parallelogram_marked
                if is_parallelogram_marked is not None
                else is_parallelogram_geom
            )

            return {
                "is_rhombus": is_rhombus,
                "is_parallelogram": is_parallelogram,
                "side_lengths": sides,
                "side_marks": list(side_marks) if side_marks else [0, 0, 0, 0],
                "marker_source": marker_source,
            }

        def _collect_side_marks(
            container, vertices: List[tuple[float, float]]
        ) -> List[int]:
            """
            Per-side tick mark count: short lines whose midpoint is near each
            side midpoint and whose direction is roughly perpendicular to the
            side. Returns a 4-element list aligned with sides[i] = (v[i], v[(i+1)%4]).
            """
            side_marks = [0, 0, 0, 0]
            sides = [(vertices[i], vertices[(i + 1) % 4]) for i in range(4)]
            for ln in iter_by_tag(container, "line"):
                x1, y1 = _f(ln, "x1"), _f(ln, "y1")
                x2, y2 = _f(ln, "x2"), _f(ln, "y2")
                seg_len = math.hypot(x2 - x1, y2 - y1)
                if seg_len <= 0 or seg_len > 25:
                    continue
                mx, my = (x1 + x2) / 2.0, (y1 + y2) / 2.0
                tdx, tdy = x2 - x1, y2 - y1
                best_idx = -1
                best_dist = float("inf")
                for i, (a, b) in enumerate(sides):
                    amx, amy = (a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0
                    d = math.hypot(mx - amx, my - amy)
                    if d < best_dist:
                        best_dist = d
                        best_idx = i
                if best_idx < 0:
                    continue
                a, b = sides[best_idx]
                sdx, sdy = b[0] - a[0], b[1] - a[1]
                slen = math.hypot(sdx, sdy)
                if slen < 1e-6:
                    continue
                if best_dist > 0.5 * slen:
                    continue
                dot = abs(sdx * tdx + sdy * tdy) / (slen * seg_len)
                if dot > 0.6:
                    continue
                side_marks[best_idx] += 1
            return side_marks

        def _collect_side_marks_from_labels(container) -> Optional[List[int]]:
            """
            Numeric label fallback: when the panel emits 4 "<n> cm/m/in" texts,
            translate equal-value groups into per-side marker counts so the
            classifier treats matching numeric labels identically to matching
            tick marks. Returns None when there aren't exactly 4 numeric labels.
            """
            text_values: List[str] = []
            for t in iter_by_tag(container, "text"):
                txt = "".join(t.itertext()).strip()
                if re.match(r"^\d+(?:\.\d+)?\s*(?:cm|m|in|inches|mm|ft)?\s*$", txt):
                    text_values.append(txt)
            if len(text_values) != 4:
                return None

            def _norm(v: str) -> str:
                m = re.match(r"^(\d+(?:\.\d+)?)", v)
                return m.group(1) if m else v

            normalized = [_norm(v) for v in text_values]
            unique_groups: Dict[str, int] = {}
            for n in normalized:
                unique_groups[n] = unique_groups.get(n, 0) + 1
            value_to_marker: Dict[str, int] = {
                v: idx + 1 for idx, v in enumerate(unique_groups)
            }
            return [value_to_marker[n] for n in normalized]

        # ------------------------------------------------------------------
        # General quadrilateral option sets (rhombus/parallelogram prompts).
        # ------------------------------------------------------------------
        quad_infos: List[dict] = []
        for group in iter_by_tag(root, "g"):
            texts = ["".join(t.itertext()).strip() for t in iter_by_tag(group, "text")]
            label = None
            shape_num = None
            for text in texts:
                num_match = re.search(r"\bShape\s+(\d+)\b", text, flags=re.IGNORECASE)
                letter_match = re.search(r"\bShape\s+([A-E])\b", text, flags=re.IGNORECASE)
                if num_match:
                    shape_num = int(num_match.group(1))
                    if 1 <= shape_num <= 5:
                        label = chr(ord("A") + shape_num - 1)
                    break
                if letter_match:
                    label = letter_match.group(1).upper()
                    break
            if label is None:
                continue

            shape_points = None
            polygons = iter_by_tag(group, "polygon")
            rects = [
                r for r in iter_by_tag(group, "rect")
                if _f(r, "width") > 0 and _f(r, "height") > 0
            ]
            paths = [
                p for p in iter_by_tag(group, "path")
                if len(_path_points(p.get("d") or "")) == 4
            ]
            if len(polygons) + len(rects) + len(paths) != 1:
                continue
            if polygons:
                shape_points = _parse_points(polygons[0].get("points", ""))
            elif rects:
                # Ignore full-canvas/background rectangles by using grouped
                # rectangles attached to a "Shape X" label.
                shape_points = _rect_points(rects[0])
            elif paths:
                shape_points = _path_points(paths[0].get("d") or "")

            if not shape_points:
                continue
            side_marks = _collect_side_marks_from_labels(group)
            if side_marks is None and len(shape_points) == 4:
                tick_marks = _collect_side_marks(group, shape_points)
                if any(m > 0 for m in tick_marks):
                    side_marks = tick_marks
            classification = _classify_quadrilateral(shape_points, side_marks)
            if not classification:
                continue
            quad_infos.append(
                {
                    "label": label,
                    "shape_name": f"Shape {shape_num}" if shape_num else f"Shape {label}",
                    **classification,
                }
            )

        existing_quad_labels = {q["label"] for q in quad_infos}
        for panel_idx, panel in enumerate(panel_svgs):
            label = _label_for_panel_index(panel_idx)
            if not label or label in existing_quad_labels:
                continue
            polygons = iter_by_tag(panel, "polygon")
            rects = [
                r for r in iter_by_tag(panel, "rect")
                if _f(r, "width") > 0 and _f(r, "height") > 0
            ]
            paths = [
                p for p in iter_by_tag(panel, "path")
                if len(_path_points(p.get("d") or "")) == 4
            ]
            if len(polygons) + len(rects) + len(paths) != 1:
                continue
            if polygons:
                shape_points = _parse_points(polygons[0].get("points", ""))
            elif rects:
                shape_points = _rect_points(rects[0])
            else:
                shape_points = _path_points(paths[0].get("d") or "")
            side_marks = _collect_side_marks_from_labels(panel)
            if side_marks is None and shape_points and len(shape_points) == 4:
                tick_marks = _collect_side_marks(panel, shape_points)
                if any(m > 0 for m in tick_marks):
                    side_marks = tick_marks
            classification = _classify_quadrilateral(shape_points, side_marks)
            if not classification:
                continue
            quad_infos.append(
                {
                    "label": label,
                    "shape_name": f"Shape {label}",
                    **classification,
                }
            )
            existing_quad_labels.add(label)

        if len(quad_infos) >= 3 and _has_unique_labels(quad_infos):
            ordered = sorted(quad_infos, key=lambda p: p["label"])
            lines = ["SVG QUADRILATERAL ANALYSIS (authoritative):"]
            lines.append("Detected labeled quadrilateral options from exact SVG geometry.")
            rhombuses = []
            parallelograms = []
            for q in ordered:
                if q["is_rhombus"]:
                    rhombuses.append(q["label"])
                if q["is_parallelogram"]:
                    parallelograms.append(q["label"])
                side_text = ", ".join(f"{s:.1f}" for s in q["side_lengths"])
                lines.append(
                    f"  - Option {q['label']} ({q['shape_name']}): "
                    f"rhombus={'yes' if q['is_rhombus'] else 'no'}, "
                    f"parallelogram={'yes' if q['is_parallelogram'] else 'no'}, "
                    f"side lengths px=[{side_text}]"
                )
            lines.append("Rhombus options from exact SVG geometry: " + (", ".join(rhombuses) or "none"))
            lines.append("Parallelogram options from exact SVG geometry: " + (", ".join(parallelograms) or "none"))
            return "\n".join(lines)

        # Protractor items with explicit ray geometry.
        protractor_groups = [g for g in iter_by_tag(root, "g") if g.get("data-component") == "protractor"]
        for pg in protractor_groups:
            ray1 = None
            ray2 = None
            arc_path = None
            for ln in iter_by_tag(pg, "line"):
                part = (ln.get("data-part") or "").strip().lower()
                if part == "ray1":
                    ray1 = ln
                elif part == "ray2":
                    ray2 = ln
            for p in iter_by_tag(pg, "path"):
                if (p.get("data-part") or "").strip().lower() == "ray-arc":
                    arc_path = p
                    break

            if ray1 is None:
                continue

            cx, cy = _f(ray1, "x1"), _f(ray1, "y1")

            def _tip(line_elem):
                x1, y1, x2, y2 = _f(line_elem, "x1"), _f(line_elem, "y1"), _f(line_elem, "x2"), _f(line_elem, "y2")
                d1 = (x1 - cx) ** 2 + (y1 - cy) ** 2
                d2 = (x2 - cx) ** 2 + (y2 - cy) ** 2
                return (x1, y1) if d1 > d2 else (x2, y2)

            def _angle_deg(x: float, y: float) -> float:
                a = math.degrees(math.atan2(-(y - cy), x - cx))
                if a < 0:
                    a += 360.0
                return a

            t1x, t1y = _tip(ray1)
            a1 = _angle_deg(t1x, t1y)

            if ray2 is not None:
                t2x, t2y = _tip(ray2)
                a2 = _angle_deg(t2x, t2y)
                raw_delta = (a2 - a1) % 360.0
                minor = min(raw_delta, 360.0 - raw_delta)
                supplementary = 180.0 - minor if minor <= 180.0 else None

                shown = minor
                if arc_path is not None:
                    d_attr = arc_path.get("d") or ""
                    nums = re.findall(r"[-+]?\d*\.?\d+", d_attr)
                    if len(nums) >= 2:
                        try:
                            ex, ey = float(nums[-2]), float(nums[-1])
                            ae = _angle_deg(ex, ey)
                            shown = min((ae - a1) % 360.0, (a1 - ae) % 360.0)
                        except (TypeError, ValueError):
                            pass

                lines = [
                    "SVG PROTRACTOR ANALYSIS (authoritative):",
                    f"Ray1 baseline angle: {a1:.2f}°; ray2 angle: {a2:.2f}°.",
                    f"Measured angle between rays (minor): {round(minor):.0f}°.",
                    f"Highlighted arc indicates approximately: {round(shown):.0f}°.",
                ]
                if supplementary is not None:
                    lines.append(f"Supplementary angle: {round(supplementary):.0f}°.")
                lines.append("CRITICAL: Angles are computed from exact SVG ray coordinates.")
                return "\n".join(lines)

        # ------------------------------------------------------------------
        # Specialized component-aware extraction (high-confidence)
        # ------------------------------------------------------------------
        # Fraction model options rendered as partitioned rectangles.
        partition_panels = []
        for panel_idx, panel in enumerate(panel_svgs):
            groups = [g for g in iter_by_tag(panel, "g") if g.get("data-component") == "partitionedShape"]
            if not groups:
                continue
            g = groups[0]
            px = _f(panel, "x", 0.0)
            py = _f(panel, "y", 0.0)

            rects = iter_by_tag(g, "rect")
            paths = iter_by_tag(g, "path")
            circles = iter_by_tag(g, "circle")
            shape_lines = iter_by_tag(g, "line")
            border_candidates = []
            fill_rects = []
            for r in rects:
                fill = (r.get("fill") or "").strip().lower()
                x, y = _f(r, "x"), _f(r, "y")
                w, h = _f(r, "width"), _f(r, "height")
                if w <= 0 or h <= 0:
                    continue
                if fill in {"", "none"}:
                    border_candidates.append((x, y, w, h))
                else:
                    fill_rects.append((x, y, w, h))
            equal_parts = False
            fraction_str = ""

            if border_candidates:
                bx, by, bw, bh = max(border_candidates, key=lambda b: b[2] * b[3])
                if bw <= 0 or bh <= 0:
                    continue

                # Partition separators from vertical lines crossing the border.
                separators = []
                for ln in shape_lines:
                    x1, y1, x2, y2 = _f(ln, "x1"), _f(ln, "y1"), _f(ln, "x2"), _f(ln, "y2")
                    if abs(x1 - x2) > 1e-6:
                        continue
                    if min(y1, y2) <= by + 0.5 and max(y1, y2) >= by + bh - 0.5:
                        if bx < x1 < bx + bw:
                            separators.append(x1)
                separators = sorted(_cluster(separators, tol=0.5))
                cuts = [bx] + separators + [bx + bw]
                seg_widths = [
                    cuts[i + 1] - cuts[i]
                    for i in range(len(cuts) - 1)
                    if cuts[i + 1] - cuts[i] > 1e-6
                ]

                # Filled area fraction.
                filled_area = 0.0
                for fx, fy, fw, fh in fill_rects:
                    ix0 = max(bx, fx)
                    iy0 = max(by, fy)
                    ix1 = min(bx + bw, fx + fw)
                    iy1 = min(by + bh, fy + fh)
                    if ix1 > ix0 and iy1 > iy0:
                        filled_area += (ix1 - ix0) * (iy1 - iy0)
                frac = max(0.0, min(1.0, filled_area / (bw * bh)))
                fraction_str = f"{frac:.3f}"

                if len(seg_widths) >= 2:
                    med = statistics.median(seg_widths)
                    if med > 0:
                        spread = max(seg_widths) - min(seg_widths)
                        equal_parts = spread <= max(1.0, med * 0.08)
                        if equal_parts:
                            denom = len(seg_widths)
                            numer = int(round(frac * denom))
                            numer = max(0, min(denom, numer))
                            fraction_str = f"{numer}/{denom}"
            elif circles and shape_lines:
                # Circular fraction models use radial boundary lines and one
                # filled path per shaded sector.
                cx, cy = _f(circles[0], "cx"), _f(circles[0], "cy")
                boundary_r = _f(circles[0], "r", 0.0)
                # Reject degenerate near-center artifacts: require the far end
                # to reach at least ~40% of the boundary radius. Falls back to
                # a fixed pixel floor when the boundary radius is unknown.
                min_tip_dist_sq = (boundary_r * 0.4) ** 2 if boundary_r > 0 else 100.0
                radial_angles: List[float] = []

                for ln in shape_lines:
                    x1, y1, x2, y2 = _f(ln, "x1"), _f(ln, "y1"), _f(ln, "x2"), _f(ln, "y2")
                    d1 = (x1 - cx) ** 2 + (y1 - cy) ** 2
                    d2 = (x2 - cx) ** 2 + (y2 - cy) ** 2
                    if min(d1, d2) > 4.0:
                        continue
                    if max(d1, d2) < min_tip_dist_sq:
                        continue
                    tip_x, tip_y = (x1, y1) if d1 > d2 else (x2, y2)
                    angle = math.degrees(math.atan2(tip_y - cy, tip_x - cx)) % 360.0
                    radial_angles.append(round(angle, 1))
                unique_angles = sorted(set(radial_angles))
                denom = len(unique_angles)
                shaded = sum(
                    1
                    for p in paths
                    if (p.get("fill") or "").strip().lower() not in {"", "none", "transparent", "#ffffff", "#fff", "white"}
                )
                if denom >= 2 and shaded > 0:
                    gaps = [
                        (unique_angles[(i + 1) % denom] - unique_angles[i]) % 360.0
                        for i in range(denom)
                    ]
                    med_gap = statistics.median(gaps)
                    equal_parts = (
                        med_gap > 0
                        and max(abs(g - med_gap) for g in gaps) <= max(5.0, med_gap * 0.08)
                    )
                    fraction_str = f"{shaded}/{denom}" if equal_parts else f"unequal:{shaded}/{denom}"
                else:
                    continue
            else:
                continue

            partition_panels.append(
                {
                    "x": px,
                    "y": py,
                    "label": _label_for_panel_index(panel_idx),
                    "fraction": fraction_str,
                    "equal_parts": equal_parts,
                }
            )

        if len(partition_panels) >= 2:
            if _has_unique_labels(partition_panels):
                ordered = sorted(partition_panels, key=lambda p: p["label"])
                labels = [p["label"] for p in ordered]
                mapping_line = "Detected labeled panels mapped by visible option labels."
            else:
                ordered = sorted(partition_panels, key=lambda p: (p["y"], p["x"]))[:4]
                labels = [chr(ord("A") + i) for i in range(len(ordered))]
                mapping_line = "Detected panels mapped by inferred reading order."
            lines = ["SVG PARTITIONED-SHAPE ANALYSIS (authoritative):"]
            lines.append(mapping_line)
            frac_to_labels: Dict[str, List[str]] = {}
            for idx, p in enumerate(ordered):
                lbl = labels[idx]
                eq = "equal partitions" if p["equal_parts"] else "unequal partitions"
                lines.append(f"  - Option {lbl}: shaded fraction {p['fraction']} ({eq})")
                frac_to_labels.setdefault(p["fraction"], []).append(lbl)
            duplicate_groups = [
                f"{frac}: {','.join(lbls)}"
                for frac, lbls in frac_to_labels.items()
                if len(lbls) > 1
            ]
            if duplicate_groups:
                lines.append("Duplicate visual models detected: " + "; ".join(duplicate_groups))
            else:
                lines.append("No duplicate visual models detected among A-D.")
            lines.append("CRITICAL: Fractions are computed from exact SVG partition geometry.")
            return "\n".join(lines)

        # Isometric prism composed of unit-cube faces.
        prism_groups = [g for g in iter_by_tag(root, "g") if g.get("data-component") == "isometricPrism"]
        for pg in prism_groups:
            polys = iter_by_tag(pg, "polygon")
            top_faces = sum(1 for p in polys if (p.get("data-part") or "").strip() == "top-face")
            right_faces = sum(1 for p in polys if (p.get("data-part") or "").strip() == "right-face")
            left_faces = sum(1 for p in polys if (p.get("data-part") or "").strip() == "left-face")
            if top_faces <= 0:
                continue

            volume_est = float(top_faces)
            detail = f"top-face unit cubes = {top_faces}"
            if right_faces > 0 and left_faces > 0:
                h_est = ((right_faces * left_faces) / max(1.0, top_faces)) ** 0.5
                h_round = max(1, int(round(h_est)))
                if abs(h_est - h_round) <= 0.25:
                    length = max(1, int(round(right_faces / h_round)))
                    width = max(1, int(round(left_faces / h_round)))
                    volume_est = float(length * width * h_round)
                    detail = (
                        f"dimensions inferred from faces: {length} x {width} x {h_round} "
                        f"(top={top_faces}, right={right_faces}, left={left_faces})"
                    )
            lines = [
                "SVG ISOMETRIC-PRISM ANALYSIS (authoritative):",
                f"Detected unit-cube prism; {detail}.",
                f"Estimated volume: {int(round(volume_est))} cubic units.",
                "CRITICAL: Volume is computed deterministically from SVG unit-cube faces.",
            ]
            return "\n".join(lines)

        # Repeated icon-grid arrays (e.g., multiplication arrays rendered as cube icons).
        icon_positions: List[tuple[float, float]] = []
        for g in iter_by_tag(root, "g"):
            transform = (g.get("transform") or "").strip()
            if not transform.startswith("translate("):
                continue
            m = re.match(r"translate\(\s*([-\d.]+)\s*,\s*([-\d.]+)\s*\)", transform)
            if not m:
                continue
            children = [c for c in list(g) if strip_ns(c.tag) == "g"]
            if len(children) != 1:
                continue
            child_tf = (children[0].get("transform") or "").lower()
            if "scale(" not in child_tf:
                continue
            # Heuristic signature used by generated icon tiles in this dataset.
            if "translate(-64" not in child_tf:
                continue
            icon_positions.append((float(m.group(1)), float(m.group(2))))

        if len(icon_positions) >= 8:
            xs = _cluster([p[0] for p in icon_positions], tol=1.0)
            ys = _cluster([p[1] for p in icon_positions], tol=1.0)
            rows = len(ys)
            cols = len(xs)
            total_icons = len(icon_positions)
            if rows >= 2 and cols >= 2 and total_icons >= int(0.8 * rows * cols):
                lines = [
                    "SVG ICON-ARRAY ANALYSIS (authoritative):",
                    f"Detected repeated icon grid: {rows} rows x {cols} columns = {rows * cols} icons.",
                    f"Observed icon instances: {total_icons}.",
                    "CRITICAL: Array dimensions are computed deterministically from SVG transforms.",
                ]
                return "\n".join(lines)

        panel_infos: List[dict] = []
        for panel_idx, panel in enumerate(panel_svgs):
            px = _f(panel, "x", 0.0)
            py = _f(panel, "y", 0.0)
            lines = iter_by_tag(panel, "line")
            rects = [
                r for r in iter_by_tag(panel, "rect")
                if (r.get("fill") or "").strip().lower() in {"", "none"}
            ]
            if not lines and not rects:
                continue

            vertical_segments: Dict[float, List[tuple[float, float]]] = {}
            horizontal_segments: Dict[float, List[tuple[float, float]]] = {}
            x_points: List[float] = []
            y_points: List[float] = []

            for ln in lines:
                x1, y1, x2, y2 = _f(ln, "x1"), _f(ln, "y1"), _f(ln, "x2"), _f(ln, "y2")
                if abs(x1 - x2) <= 1e-6:
                    x = round((x1 + x2) / 2.0, 3)
                    y_lo, y_hi = sorted((y1, y2))
                    vertical_segments.setdefault(x, []).append((y_lo, y_hi))
                    x_points.append(x)
                    y_points.extend([y_lo, y_hi])
                elif abs(y1 - y2) <= 1e-6:
                    y = round((y1 + y2) / 2.0, 3)
                    x_lo, x_hi = sorted((x1, x2))
                    horizontal_segments.setdefault(y, []).append((x_lo, x_hi))
                    y_points.append(y)
                    x_points.extend([x_lo, x_hi])

            # Include border rectangles as explicit edge segments.
            for r in rects:
                rx, ry = _f(r, "x"), _f(r, "y")
                rw, rh = _f(r, "width"), _f(r, "height")
                if rw <= 0 or rh <= 0:
                    continue
                x0, x1 = round(rx, 3), round(rx + rw, 3)
                y0, y1 = round(ry, 3), round(ry + rh, 3)
                vertical_segments.setdefault(x0, []).append((y0, y1))
                vertical_segments.setdefault(x1, []).append((y0, y1))
                horizontal_segments.setdefault(y0, []).append((x0, x1))
                horizontal_segments.setdefault(y1, []).append((x0, x1))
                x_points.extend([x0, x1])
                y_points.extend([y0, y1])

            if len(x_points) < 2 or len(y_points) < 2:
                continue

            x_coords = _cluster(x_points, tol=0.5)
            y_coords = _cluster(y_points, tol=0.5)
            if len(x_coords) < 2:
                continue

            x_diffs = [x_coords[i] - x_coords[i - 1] for i in range(1, len(x_coords))]
            x_diffs = [d for d in x_diffs if d > 1.0]
            step = statistics.median(x_diffs) if x_diffs else None

            # Count unit cells by requiring all four edges present over candidate cell interval.
            cell_count = 0
            if step and step > 1.0 and len(y_coords) >= 2:
                for i in range(len(x_coords) - 1):
                    x_left, x_right = x_coords[i], x_coords[i + 1]
                    if abs((x_right - x_left) - step) > max(1.0, step * 0.4):
                        continue
                    for j in range(len(y_coords) - 1):
                        y_top, y_bottom = y_coords[j], y_coords[j + 1]
                        if abs((y_bottom - y_top) - step) > max(1.0, step * 0.4):
                            continue

                        left_edges = vertical_segments.get(round(x_left, 3), [])
                        right_edges = vertical_segments.get(round(x_right, 3), [])
                        top_edges = horizontal_segments.get(round(y_top, 3), [])
                        bottom_edges = horizontal_segments.get(round(y_bottom, 3), [])

                        has_left = _interval_covered(left_edges, y_top, y_bottom)
                        has_right = _interval_covered(right_edges, y_top, y_bottom)
                        has_top = _interval_covered(top_edges, x_left, x_right)
                        has_bottom = _interval_covered(bottom_edges, x_left, x_right)
                        if has_left and has_right and has_top and has_bottom:
                            cell_count += 1

            # Number-line intervals fallback from unique vertical tick positions.
            intervals = 0
            if len(x_coords) >= 2:
                baseline_y = None
                max_h_len = -1.0
                for y, segs in horizontal_segments.items():
                    for s_lo, s_hi in segs:
                        seg_len = s_hi - s_lo
                        if seg_len > max_h_len:
                            max_h_len = seg_len
                            baseline_y = y
                if baseline_y is not None and max_h_len > 20:
                    ticks = []
                    for x, segs in vertical_segments.items():
                        for y_lo, y_hi in segs:
                            if y_lo - 0.5 <= baseline_y <= y_hi + 0.5:
                                ticks.append(x)
                                break
                    ticks = _cluster(ticks, tol=0.5)
                    if len(ticks) >= 2:
                        intervals = len(ticks) - 1

            panel_infos.append(
                {
                    "x": px,
                    "y": py,
                    "label": _label_for_panel_index(panel_idx),
                    "cell_count": cell_count,
                    "intervals": intervals,
                    "element": panel,
                }
            )

        if not panel_infos:
            return None

        context_lines: List[str] = []

        # A-D style shape area prompts.
        cell_panels = [p for p in panel_infos if p["cell_count"] > 0]
        if len(cell_panels) >= 4:
            label_complete = _has_complete_unique_labels(cell_panels)
            if label_complete:
                ordered = sorted(cell_panels, key=lambda p: p["label"])
                labels = [p["label"] for p in ordered]
                context_lines.append("SVG UNIT-GRID ANALYSIS (authoritative):")
                context_lines.append("Detected 4 panels mapped by visible A-D labels.")
            else:
                ordered = _order_panels_row_major(cell_panels)[:4]
                labels = ["A", "B", "C", "D"]
                context_lines.append("SVG UNIT-GRID ANALYSIS (label mapping uncertain):")
                context_lines.append("Detected 4 panels mapped by inferred reading order.")
            areas = [int(p["cell_count"]) for p in ordered]
            equal_pairs = []
            for i in range(4):
                for j in range(i + 1, 4):
                    if areas[i] == areas[j]:
                        equal_pairs.append(f"{labels[i]}-{labels[j]} ({areas[i]})")
            for i, area in enumerate(areas):
                context_lines.append(f"  - Shape {labels[i]} area: {area} unit squares")
            if equal_pairs:
                if label_complete:
                    context_lines.append("Equal-area pairs from exact SVG line geometry: " + ", ".join(equal_pairs))
                else:
                    context_lines.append("Equal-area pairs from inferred panel order: " + ", ".join(equal_pairs))
            else:
                context_lines.append("No equal-area pair detected across A-D.")
            context_lines.append("CRITICAL: Areas are computed deterministically from SVG edges.")
            return "\n".join(context_lines)

        # Number-line prompts.
        interval_panels = [p for p in panel_infos if p["intervals"] > 0]
        if len(interval_panels) >= 4:
            label_complete = _has_complete_unique_labels(interval_panels)
            if label_complete:
                ordered = sorted(interval_panels, key=lambda p: p["label"])
                labels = [p["label"] for p in ordered]
                context_lines.append("SVG NUMBER LINE ANALYSIS (authoritative):")
                context_lines.append("Detected 4 panels mapped by visible A-D labels.")
            else:
                ordered = _order_panels_row_major(interval_panels)[:4]
                labels = ["A", "B", "C", "D"]
                context_lines.append("SVG NUMBER LINE ANALYSIS (label mapping uncertain):")
                context_lines.append("Detected 4 panels mapped by inferred reading order.")
            for i, p in enumerate(ordered):
                # Best-effort colored-segment fraction. The number-line
                # template draws the highlighted segment as a thick line
                # (stroke-width >= 5) along the same baseline, with the
                # integer endpoints "0" and "1" labeled as text. When both
                # signals are present we report n/d with the panel's interval
                # count as denominator.
                colored_frac: Optional[str] = None
                panel_elem = p.get("element")
                if panel_elem is not None:
                    try:
                        text_x_by_value: Dict[str, float] = {}
                        for t in iter_by_tag(panel_elem, "text"):
                            for piece in (t.text or "").split():
                                if piece in {"0", "1"}:
                                    text_x_by_value[piece] = _f(t, "x")
                        if "0" in text_x_by_value and "1" in text_x_by_value:
                            zero_x = text_x_by_value["0"]
                            one_x = text_x_by_value["1"]
                            unit_px = one_x - zero_x
                            if unit_px > 0:
                                # Find the thickest horizontal line as the
                                # highlighted segment.
                                best_thick = None
                                for ln in iter_by_tag(panel_elem, "line"):
                                    sw = float(ln.get("stroke-width", "0") or 0)
                                    x1 = _f(ln, "x1")
                                    y1 = _f(ln, "y1")
                                    x2 = _f(ln, "x2")
                                    y2 = _f(ln, "y2")
                                    if abs(y1 - y2) > 0.5:
                                        continue  # only horizontal
                                    if sw < 5:
                                        continue
                                    if best_thick is None or sw > best_thick[0]:
                                        best_thick = (sw, min(x1, x2), max(x1, x2))
                                if best_thick is not None:
                                    seg_len = best_thick[2] - best_thick[1]
                                    raw = seg_len / unit_px
                                    denom = int(p["intervals"])
                                    numer = round(raw * denom)
                                    if denom > 0 and 0 <= numer <= denom:
                                        g = math.gcd(numer, denom) or 1
                                        colored_frac = (
                                            f"{numer // g}/{denom // g}" if numer > 0 else "0"
                                        )
                    except Exception:
                        colored_frac = None
                line = f"  - Number line {labels[i]} has {int(p['intervals'])} equal intervals"
                if colored_frac:
                    line += f"; highlighted segment length = {colored_frac}"
                context_lines.append(line)
            context_lines.append(
                "CRITICAL: Interval counts and highlighted-segment lengths are computed deterministically from SVG ticks and lines."
            )

        return "\n".join(context_lines) if context_lines else None
    except Exception as e:
        logger.debug(f"SVG diagram context extraction failed: {e}")
        return None


def extract_raster_diagram_context(image_bytes: bytes) -> Optional[str]:
    """
    Deterministically extract grid/array/number-line structure from raster images.

    This runs after any SVG->PNG conversion, so it can handle both original raster
    assets and converted SVG diagrams with one pipeline.
    """
    try:
        import cv2
        import numpy as np
    except ImportError:
        return None

    try:
        arr = np.frombuffer(image_bytes, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return None

        # Line-art friendly binarization and slight dilation for thin SVG strokes.
        blur = cv2.GaussianBlur(img, (3, 3), 0)
        _, bw = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        bw = cv2.dilate(bw, np.ones((2, 2), np.uint8), iterations=1)

        h, w = bw.shape
        if h < 50 or w < 50:
            return None

        def _cluster_index_positions(indices: List[int], tol: int = 3) -> List[float]:
            if not indices:
                return []
            indices = sorted(indices)
            groups: List[List[int]] = [[indices[0]]]
            for val in indices[1:]:
                if val - groups[-1][-1] <= tol:
                    groups[-1].append(val)
                else:
                    groups.append([val])
            return [float(sum(g)) / len(g) for g in groups]

        col_sum = np.sum(bw > 0, axis=0)
        row_sum = np.sum(bw > 0, axis=1)

        vertical_idx = np.where(col_sum >= max(20, int(h * 0.18)))[0].tolist()
        if len(vertical_idx) < 2:
            return None
        x_lines = _cluster_index_positions(vertical_idx, tol=4)
        if len(x_lines) < 2:
            return None

        # Dominant cell spacing from repeated grid/tick distances.
        x_diffs = [x_lines[i] - x_lines[i - 1] for i in range(1, len(x_lines))]
        x_diffs = [d for d in x_diffs if 6 <= d <= max(350, w * 0.35)]
        if not x_diffs:
            return None
        cell = float(statistics.median(x_diffs))
        if cell < 6:
            return None

        panel_x_groups: List[List[float]] = []
        current_group = [x_lines[0]]
        for x in x_lines[1:]:
            diff = x - current_group[-1]
            if abs(diff - cell) <= max(5.0, cell * 0.35):
                current_group.append(x)
            else:
                if len(current_group) >= 2:
                    panel_x_groups.append(current_group)
                current_group = [x]
        if len(current_group) >= 2:
            panel_x_groups.append(current_group)

        panel_x_groups = [g for g in panel_x_groups if len(g) >= 2]
        if not panel_x_groups:
            return None

        panel_areas: List[int] = []
        panel_intervals: List[int] = []

        for group in panel_x_groups[:8]:
            x_left = int(max(0, round(min(group) - 2)))
            x_right = int(min(w - 1, round(max(group) + 2)))
            if x_right <= x_left:
                continue
            width_span = x_right - x_left
            if width_span < cell * 0.8:
                continue
            cols = max(1, int(round(width_span / cell)))

            panel_bw = bw[:, x_left : x_right + 1]
            panel_row_sum = np.sum(panel_bw > 0, axis=1)
            y_idx = np.where(panel_row_sum >= max(8, int(panel_bw.shape[1] * 0.45)))[0].tolist()
            y_lines = _cluster_index_positions(y_idx, tol=3)

            # Confidence gate: use deterministic output only when geometry is coherent.
            if len(y_lines) >= 2:
                y_span = max(y_lines) - min(y_lines)
                rows = max(1, int(round(y_span / cell)))
                if 1 <= rows <= 40 and 1 <= cols <= 40:
                    panel_areas.append(cols * rows)
            elif 1 <= cols <= 40:
                panel_intervals.append(cols)

        context_lines: List[str] = []
        if len(panel_areas) >= 4:
            labels = ["A", "B", "C", "D"]
            areas = panel_areas[:4]
            equal_pairs: List[str] = []
            for i in range(4):
                for j in range(i + 1, 4):
                    if areas[i] == areas[j]:
                        equal_pairs.append(f"{labels[i]}-{labels[j]} ({areas[i]})")

            context_lines.append(
                "RASTER GRID ANALYSIS (deterministic - trust over visual estimation):"
            )
            context_lines.append("Detected 4 left-to-right panels mapped to A, B, C, D.")
            for i, area in enumerate(areas):
                context_lines.append(f"  - Shape {labels[i]} area: {area} unit squares")
            if equal_pairs:
                context_lines.append("Equal-area pairs: " + ", ".join(equal_pairs))
            else:
                context_lines.append("No equal-area pair detected across A-D.")
            context_lines.append(
                "CRITICAL: Areas are computed from raster geometry after image conversion."
            )
        elif len(panel_intervals) >= 4:
            labels = ["A", "B", "C", "D"]
            context_lines.append(
                "RASTER NUMBER LINE ANALYSIS (deterministic - trust over visual estimation):"
            )
            context_lines.append("Detected 4 left-to-right panels mapped to A, B, C, D.")
            for i, intervals in enumerate(panel_intervals[:4]):
                context_lines.append(
                    f"  - Number line {labels[i]} has {intervals} equal intervals"
                )
            context_lines.append(
                "CRITICAL: Interval counts are computed from raster tick geometry."
            )

        return "\n".join(context_lines) if context_lines else None
    except Exception as e:
        logger.debug(f"Raster diagram context extraction failed: {e}")
        return None


def remove_svg_from_content(content: str) -> str:
    """
    Remove inline SVG XML code from content, leaving only text markers.
    
    Since SVGs are separately analyzed as converted images, the raw SVG code
    is redundant and consumes large amounts of tokens. This function removes
    the SVG XML while preserving any surrounding text markers like [SVG Image].
    
    Handles nested SVG tags by properly tracking depth and removing complete
    outermost SVG blocks.
    
    Args:
        content: The content potentially containing inline SVG tags
        
    Returns:
        Content with SVG XML code removed
    """
    result = []
    i = 0
    
    while i < len(content):
        # Find next opening <svg tag (case insensitive)
        match = re.search(r'<svg[\s>]', content[i:], re.IGNORECASE)
        if not match:
            # No more SVGs, append rest of content
            result.append(content[i:])
            break
        
        start_pos = i + match.start()
        
        # Append content before this SVG
        result.append(content[i:start_pos])
        
        # Find the end of the opening tag
        tag_end = content.find('>', start_pos)
        if tag_end == -1:
            # Malformed SVG, skip it
            result.append(content[start_pos:start_pos + 4])  # Just append '<svg'
            i = start_pos + 4
            continue
        
        # Count nested svg tags to find the matching closing tag
        depth = 1
        pos = tag_end + 1
        
        while pos < len(content) and depth > 0:
            # Look for next svg tag (opening or closing)
            next_open = re.search(r'<svg[\s>]', content[pos:], re.IGNORECASE)
            next_close = re.search(r'</svg\s*>', content[pos:], re.IGNORECASE)
            
            if next_close is None:
                # No closing tag found, malformed SVG
                break
            
            close_pos = pos + next_close.start()
            
            # Check if there's an opening tag before the closing tag
            if next_open and (pos + next_open.start()) < close_pos:
                # Found nested opening tag first
                depth += 1
                pos = pos + next_open.start() + 4  # Move past '<svg'
            else:
                # Found closing tag
                depth -= 1
                if depth == 0:
                    # Found matching closing tag for the outermost SVG
                    end_pos = close_pos + len(next_close.group(0))
                    
                    # Replace entire SVG block with placeholder
                    result.append('[SVG converted to image for analysis]')
                    
                    i = end_pos
                    break
                else:
                    pos = close_pos + len(next_close.group(0))
        
        if depth > 0:
            # Couldn't find matching closing tag, treat as malformed
            # Just append the opening tag and continue
            result.append(content[start_pos:start_pos + 4])
            i = start_pos + 4
    
    cleaned = ''.join(result)
    logger.debug(f"Removed SVG code from content (original: {len(content)} chars, cleaned: {len(cleaned)} chars)")
    
    return cleaned
