"""
Independent factual-accuracy audit grounded in Wikipedia passages.

Runs in parallel with the main question evaluation. The ``factual_grounding`` LLM task
(typically a different model than ``evaluator``) receives:

- A self-contained audit preamble with a 3-gate correction test (see ``_AUDIT_PREAMBLE``
  and ``_RAG_AUDIT_PREAMBLE``) — no rubric is sliced from the evaluator prompt
- Wikipedia RAG passages when available (grade-appropriate variant), or the plain
  preamble when ``FACTUAL_AUDIT_SKIP_WIKIPEDIA=1`` is set
- The **same** programmatic, curriculum, image, full_context, and subcontent contexts

The audit result is **merged** into the main evaluator's ``factual_accuracy`` score
via ``min(main, audit)`` — if either the main evaluator or the audit catches a factual
error, the question fails.  The overall score is recomputed deterministically after
the merge.  The raw audit result is also stored in ``result.factual_audit`` for
visibility in dashboards.
"""

from __future__ import annotations

import logging
import math
import os
from typing import TYPE_CHECKING, Any, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from inceptbench.config.constants import FACTUAL_AUDIT_SUBJECTS
from inceptbench.core.input_models import RequestMetadata
from inceptbench.llm import LLMFactory, LLMMessage
from inceptbench.models import QuestionEvaluationResult
from inceptbench.tools.image_utils import remove_svg_from_content
from inceptbench.tools.wiki_retriever import (
    _select_wiki_variant,
    extract_multiple_search_terms,
    fetch_wikipedia_passages,
)

if TYPE_CHECKING:
    from inceptbench.evaluators.base import BaseEvaluator
    from inceptbench.models.article import ArticleEvaluationResult
    from inceptbench.models.base import BaseEvaluationResult

logger = logging.getLogger(__name__)


_DEFAULT_ARTICLE_AUDIT_CONSENSUS_RUNS = 3



def should_run_audit(request_metadata: Optional[RequestMetadata]) -> bool:
    """Decide whether the factual-accuracy audit should run for this item.

    Returns ``True`` when ``FACTUAL_AUDIT_SUBJECTS`` is ``None`` (all subjects)
    or when the item's subject matches an enabled entry.
    Respects ``DISABLE_FACTUAL_AUDIT=1`` to skip the audit entirely.
    """
    if os.environ.get("DISABLE_FACTUAL_AUDIT", "").strip().lower() in ("1", "true", "yes"):
        return False
    if FACTUAL_AUDIT_SUBJECTS is None:
        return True
    if not request_metadata or not request_metadata.subject:
        return False
    normalized = request_metadata.subject.strip().lower().replace("-", "_").replace(" ", "_")
    return normalized in FACTUAL_AUDIT_SUBJECTS

# Slice the factual metric block from the combined prompt (same text main evaluator sees).

_AUDIT_PREAMBLE = """You are an independent **factual-accuracy auditor** for educational questions.

Evaluate **only** the **factual_accuracy** metric. Do not score any other metrics.

**Answer-key consistency — apply the right check for the question type:**

- **MCQ / fill-in:** Check whether `answer_explanation` is consistent with the labeled correct option.
- **MSQ:** Check whether `answer_explanation` is consistent with ALL labeled-correct options.
- **Match:** Check whether `answer_evaluation` accurately describes each `correct_category` assignment.
- **Sequence:** Identify the labeled `correct_order` and item contents. Check whether
  `answer_explanation` is consistent with the stated ordering. Score 0.0 only if the explanation
  directly contradicts the stated order or contains a clear factual error about the events.
  Do NOT apply MCQ key-consistency checks to sequence questions.

**Mandatory interpretations (closed-ended / field consistency — same as main evaluator):**

1. **`accepted_answers`, answer key, and MCQ/MSQ correct labels** are part of factual ground truth.
   Set **factual_accuracy = 0.0** if (and generally **only if**) misgrading is **unambiguous**:
   - Any **accepted answer** would mark as correct a response that is **clearly wrong** for this stem **and** the explanation (wrong literary/scientific **genre**, wrong entity, a **quantity or label** offered as the "name" of something when it is not, answers that complete the blank in a **grammatically or logically broken** way, etc.).
   - The key **omits** a response that the stem or explanation **clearly** marks as correct (e.g. explanation centers on an exact term like "ka" or "li" but `accepted_answers` omits it).
   - The labeled **correct option** is wrong, or the key **flatly contradicts** the stem/explanation.

2. **`answer_explanation` (and similar explanation fields)** must be **factually accurate**.
   Set **factual_accuracy = 0.0** for **clear factual errors** in those fields (wrong dates, wrong causal claims, misstated geography, "first ever" myths, incorrect characterization of groups or laws, wrong option references, etc.) — even if the keyed answer might still be acceptable in isolation.

3. **FIELD MISMATCH** between explanation, options, and `accepted_answers` is a **factual_accuracy** failure when it would **unambiguously misgrade** or **mislead**.

4. Do **not** fail for minor stylistic preference; only **concrete** wrong facts, wrong keys, or grading contradictions.

**Calibration — prefer 1.0 when the call is debatable:**

- **Synonym lists:** Do **not** fail solely because a listed synonym is **pedantically narrower or broader** than a historian would prefer if it still denotes the **same classroom concept** the explanation teaches (e.g., common exonyms or modern region names students see in textbooks for an ancient area **unless** the accepted answer refers to a **different** place, period, or political entity than the stem).
- **Colloquial vs technical terms:** If students routinely use a casual label for the **same** invention/substance the explanation names (e.g., everyday "cement" vs "concrete"), treat as **acceptable** unless the accepted answer names a **materially different** substance or phenomenon than the explanation (e.g., **mortar** vs **hydraulic concrete** when the text is about large Roman monolithic concrete).
- **Tie-breaker:** If expert disagreement is plausible or the answer is a **reasonable grade-level paraphrase**, default to **factual_accuracy = 1.0** for the key. Reserve **0.0** for cases where a credited answer is **clearly** wrong, incoherent in context, or a **different category** from what the item teaches.

**Mandatory self-check before scoring 0.0 (the "correction test"):**

Before assigning score 0.0, you MUST pass ALL THREE of these gates for at least one
claim. If any gate fails, you must score 1.0.

  Gate 1 — **State the error and correction.** Write: "The content says [X]. The
  established fact is [Y]." Both X and Y must be specific and concrete. If you cannot
  fill in Y with a definite, widely-agreed-upon correction, do not score 0.0.

  Gate 2 — **Confirm the correction is in your reliable knowledge.** Your correction
  must be something widely documented and unambiguous — a well-known date, a major
  historical event, a scientific law, a mathematical fact, a geographic reality.
  You MUST NOT score 0.0 based on:
  - Claims that a specific document, artwork, engraving, manuscript, or edition
    "does not exist" or "is fabricated" or "is not canonical." You cannot reliably
    determine whether specific historical items exist in archives or collections.
  - Claims that a specific passage, quote, or description is "not found in" or
    "does not match" a named primary source. You do not have reliable verbatim
    recall of historical texts and cannot verify what a source does or does not say.
  - Claims that a specific royal decree, order, law, or policy "is not documented"
    or "is not a known historical event." Absence of recall is not absence of fact.
  - Claims that a cultural practice, architectural form, or technology was exclusive
    to one group when it may have been shared across related groups.
  - Simplified role titles, institutional attributions, or authorship shorthands in
    educational materials (these are standard pedagogical simplifications, not errors,
    unless they fundamentally misidentify who did what).
  - Bibliographic metadata disputes (exact publication year within a narrow range,
    exact ship or location of writing, exact co-authorship or regency details) where
    scholars themselves disagree or where the simplification is standard in textbooks.

  Gate 3 — **Confirm student harm.** Would a student who learns from this content
  walk away with a **substantively wrong understanding** of the topic? Apply these
  tests:
  - If the error is about **when** something happened: would the student place the
    event in the **wrong century or wrong historical period**? A few years off within
    the same period/context is NOT student harm.
  - If the error is about **who** did something: would the student **credit the wrong
    person or nation entirely**? Simplified attribution (sole monarch vs regent,
    approximate title) is NOT student harm if the right person/entity is named.
  - If the error is about **what** happened: would the student believe a **different
    event occurred** or misunderstand the **nature** of the event? Minor metadata
    (exact manuscript completion date, exact ship name) is NOT student harm.
  - If you cannot clearly articulate what wrong belief the student would form, the
    error fails Gate 3 and you must score 1.0.

**Output rules:**
- `contradiction_found`: set `true` if a factual error was found (passes all 3 gates); `false` otherwise.
- `score`: exactly **0.0** if `contradiction_found` is `true`; exactly **1.0** if `false`.
  These two fields MUST be consistent.
- `reasoning`: clear, human-readable; start with `[FactualAccuracyAudit] `.
- `suggested_improvements`: required when score is 0.0; omit or null when 1.0.

Use all supporting context blocks (math verification, images, curriculum, etc.) the same way
the main evaluator would when judging factual accuracy.
"""

# ---------------------------------------------------------------------------
# RAG audit prompt — used when Wikipedia passages are available
# ---------------------------------------------------------------------------

_RAG_AUDIT_PREAMBLE = """You are a factual accuracy checker for educational questions.

## Step 1 — Answer-key consistency (no Wikipedia needed)

Before consulting the passages, perform this self-consistency check. The question format
determines what "the answer key" means — apply the right check for the type:

**MCQ / fill-in:** Identify the labeled correct answer option (e.g. `"answer": "A"`) and the
text of that option. Check whether `answer_explanation` is consistent with that option.

**MSQ (multi-select):** Identify all correct answer options (e.g. `"answer": ["A", "C"]`).
Check whether `answer_explanation` is consistent with ALL of the labeled-correct options.
Do NOT fail because explanation mentions only some of the correct options if the facts stated
are still accurate.

**Match:** There is no single `"answer"` key. Instead check whether `answer_evaluation`
accurately describes why each item belongs to its stated `correct_category`. Score 0.0 only if
`answer_evaluation` directly contradicts a `correct_category` assignment for a specific item
(e.g. item says `correct_category: "c1"` but explanation says "this belongs to c2").

**Sequence:** Identify the labeled `correct_order` and the item contents. Check whether
`answer_explanation` is consistent with the stated ordering. Score 0.0 only if the explanation
directly contradicts the stated order or contains a clear factual error about the events.

Score **0.0 immediately** (skip the Wikipedia check) if:
- For MCQ/fill-in: The explanation clearly describes a different fact/entity/concept as the
  correct answer than what the labeled option says — a direct key-explanation mismatch.
- For MSQ: The explanation contradicts the correctness of one of the labeled-correct options.
- For match: `answer_evaluation` directly contradicts a stated `correct_category` assignment.
- The labeled answer/key text is factually incompatible with what the explanation teaches.

Do NOT flag for:
- Explanation that provides richer context beyond the answer text (that is fine).
- Slight wording differences between answer and explanation when they refer to the same thing.
- Distractor / wrong options that are incorrect — only labeled-correct content is checked here.
- Match: items whose explanation simply restates the category label rather than explaining it.

If the key and explanation are consistent → proceed to Step 2.

## Step 2 — Wikipedia contradiction check

You have been given Wikipedia passages about the question's topic. Check whether the question \
contains a factual claim that is DIRECTLY CONTRADICTED by the provided passages.

**Rules:**
1. If the passages do NOT address a specific claim → score **1.0** (no evidence to judge)
2. If the passages SUPPORT or are consistent with the claim → score **1.0**
3. Score **0.0** ONLY if a passage clearly and directly contradicts a specific factual claim \
in the CORRECT answer or its explanation
4. Grade-level simplifications are acceptable — do not flag unless a passage says something \
directly opposite
5. Distractor/wrong answer options are expected to be wrong — NEVER score 0.0 because an \
unkeyed option contains an incorrect fact
6. Only the correct answer's explanation can fail

**Before scoring 0.0 for a Wikipedia contradiction**, you must be able to complete this template:
  "The content says [X]. The passage says [Y]. These directly contradict."
If you cannot fill this in using actual text from the passages → score 1.0.

**CRITICAL — Score must match your own reasoning:**
Your `score` field must be consistent with your conclusion in `reasoning`.
- If your reasoning says "no contradiction found", "no contradiction to cite", "passage does not \
address", "passage supports the claim", or any equivalent → you MUST output score **1.0**.
- If your own reasoning concludes there is no contradiction but you output 0.0, that is a \
self-contradiction and is treated as an evaluator error. Do not override your own conclusion.
- The ONLY valid reason to output 0.0 is when you can fill in "The content says [X]. The passage \
says [Y]. These directly contradict." with actual quoted text from both sources.

**Output — three fields, all required:**
- `contradiction_found`: boolean — set `true` ONLY if you can fill in "The content says [X]. \
The passage says [Y]. These directly contradict." with actual quoted text. Set `false` for \
everything else (passages don't address the claim, passages support the claim, Step 1 passed).
- `score`: exactly 0.0 if `contradiction_found` is `true`; exactly 1.0 if `contradiction_found` \
is `false`. These two fields MUST be consistent — they will be validated and an inconsistency \
will be treated as an evaluator error.
- `reasoning`: start with `[FactualAccuracyAudit] `; if Step 1 failed, state the key-explanation \
mismatch; if Step 2 failed, cite which passage contradicts which claim; otherwise confirm no \
contradiction found
- `suggested_improvements`: required only when `contradiction_found` is `true`

[WIKIPEDIA PASSAGES]
{passages}
[/WIKIPEDIA PASSAGES]
"""


class FactualAccuracyAuditLLMOutput(BaseModel):
    """Schema for structured output from the auditor LLM only (no ``skipped`` field).

    ``skipped`` must never be model-controlled: if it were in the JSON schema, the
    model could skip the merge and preserve a false pass from the main evaluator.

    ``contradiction_found`` is the primary decision field. ``score`` must be consistent
    with it: 0.0 iff contradiction_found=True, 1.0 iff contradiction_found=False.
    The cross-field validator enforces this — any mismatch raises a validation error
    that triggers a retry rather than silently producing a wrong score.
    """

    contradiction_found: bool = Field(
        ...,
        description=(
            "True ONLY if a clear factual error was found in the content. "
            "The auditor must be able to state: 'The content says [X]. The established fact is [Y]. "
            "These directly contradict.' False for all other cases."
        ),
    )
    score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str = Field(..., description="Human-readable; should begin with [FactualAccuracyAudit]")
    suggested_improvements: Optional[str] = Field(
        None, description="Concrete fixes when contradiction_found is true"
    )

    @field_validator("score", mode="before")
    @classmethod
    def binary_factual(cls, v: object) -> float:
        if isinstance(v, bool):
            return 1.0 if v else 0.0
        x = float(v)  # type: ignore[arg-type]
        if abs(x - 1.0) < 1e-6:
            return 1.0
        if abs(x - 0.0) < 1e-6:
            return 0.0
        raise ValueError("factual audit score must be 0.0 or 1.0")

    @model_validator(mode="after")
    def score_matches_contradiction_found(self) -> "FactualAccuracyAuditLLMOutput":
        """Enforce that score is consistent with contradiction_found.

        contradiction_found=True  → score must be 0.0
        contradiction_found=False → score must be 1.0

        A mismatch means the model filled the fields incoherently. Raising here
        causes generate_structured() to retry the LLM call rather than returning
        a self-contradictory result.
        """
        expected = 0.0 if self.contradiction_found else 1.0
        if abs(self.score - expected) > 1e-6:
            raise ValueError(
                f"contradiction_found={self.contradiction_found} requires score={expected}, "
                f"but got score={self.score}. Fields are inconsistent."
            )
        return self


class FactualAccuracyAuditResponse(BaseModel):
    """Full audit result after a run (includes ``skipped`` for fail-open paths only)."""

    score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str = Field(..., description="Human-readable; should begin with [FactualAccuracyAudit]")
    suggested_improvements: Optional[str] = Field(
        None, description="Concrete fixes when score is 0.0"
    )
    skipped: bool = Field(
        False,
        description="True when the audit did not actually run (fail-open). "
        "The main evaluator's score should be preserved.",
    )

    @classmethod
    def from_llm_output(cls, out: FactualAccuracyAuditLLMOutput) -> "FactualAccuracyAuditResponse":
        """Build a non-skipped response from successful structured output."""
        return cls(
            score=out.score,
            reasoning=out.reasoning,
            suggested_improvements=out.suggested_improvements,
            skipped=False,
        )



def apply_factual_audit_to_result(
    result: "BaseEvaluationResult",
    audit: FactualAccuracyAuditResponse,
) -> "BaseEvaluationResult":
    """Merge the audit into scoring for any BaseEvaluationResult subclass.

    When the audit finds a factual error (score=0.0) that the main evaluator
    missed, ``factual_accuracy`` is downgraded via ``min(main, audit)``.
    The overall score is then recomputed deterministically from the updated
    metric pattern.
    """
    from inceptbench.models.base import MetricResult

    updates: dict = {}

    if not audit.skipped:
        main_score = result.factual_accuracy.score
        merged_score = min(main_score, audit.score)

        if merged_score != main_score:
            logger.info(
                "Factual audit override: main=%.1f, audit=%.1f → merged=%.1f",
                main_score, audit.score, merged_score,
            )
            updates["factual_accuracy"] = MetricResult(
                internal_reasoning=result.factual_accuracy.internal_reasoning,
                score=merged_score,
                reasoning=(
                    f"{result.factual_accuracy.reasoning} "
                    f"[Audit: {audit.reasoning or 'factual error detected'}]"
                ),
                suggested_improvements=(
                    audit.suggested_improvements
                    or result.factual_accuracy.suggested_improvements
                ),
            )
        else:
            logger.debug("Factual audit agrees with main evaluator: %.1f", audit.score)

    if not updates:
        return result

    # Deep-copy so recomputing overall does not mutate the original result
    # through shared nested MetricResult references.
    updated = result.model_copy(update=updates, deep=True)
    updated.overall.score = updated.constrained_overall_score()
    return updated


def apply_factual_audit_to_question_result(
    result: QuestionEvaluationResult,
    audit: FactualAccuracyAuditResponse,
) -> QuestionEvaluationResult:
    """Merge the audit into scoring and store it for visibility.

    When the audit finds a factual error (score=0.0) that the main evaluator
    missed, ``factual_accuracy`` is downgraded via ``min(main, audit)``.
    The overall score is then recomputed deterministically from the updated
    metric pattern.  The raw audit result is also stored in
    ``result.factual_audit`` for dashboards.
    """
    from inceptbench.models.question import FactualAuditResult
    from inceptbench.models.base import MetricResult

    advisory = FactualAuditResult(
        score=audit.score,
        reasoning=audit.reasoning or "",
        suggested_improvements=audit.suggested_improvements,
        skipped=audit.skipped,
    )

    # First apply the generic merge (no factual_audit field on base)
    result = apply_factual_audit_to_result(result, audit)

    # Then attach the advisory record for dashboard visibility.
    # The generic merge already recomputes overall.score when needed.
    updated = result.model_copy(update={"factual_audit": advisory})

    return updated


def apply_factual_audit_to_article_result(
    result: "ArticleEvaluationResult",
    audit: FactualAccuracyAuditResponse,
) -> "ArticleEvaluationResult":
    """Merge the audit into scoring and store it for article diagnostics."""
    from inceptbench.models.question import FactualAuditResult

    advisory = FactualAuditResult(
        score=audit.score,
        reasoning=audit.reasoning or "",
        suggested_improvements=audit.suggested_improvements,
        skipped=audit.skipped,
    )

    result = apply_factual_audit_to_result(result, audit)
    return result.model_copy(update={"factual_audit": advisory})


def _get_consensus_runs() -> int:
    """Return the number of consensus runs from FACTUAL_AUDIT_CONSENSUS_RUNS.

    When set to N>1, the audit runs N times and only overrides if ALL runs
    agree on a factual error. This filters out noisy false-positives while
    preserving consistently-detected real errors.

    Returns 1 (no consensus, legacy behaviour) when unset or invalid.
    """
    raw = os.environ.get("FACTUAL_AUDIT_CONSENSUS_RUNS", "").strip()
    if raw:
        try:
            n = int(raw)
            if n >= 1:
                return n
        except ValueError:
            pass
    return 1


def _parse_positive_int_env(name: str) -> Optional[int]:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return None
    try:
        value = int(raw)
    except ValueError:
        return None
    return value if value >= 1 else None


def _get_article_audit_consensus_runs() -> int:
    """Return article audit consensus runs.

    ``FACTUAL_AUDIT_CONSENSUS_RUNS`` remains the explicit audit override. When
    it is unset, article audits inherit ``ARTICLE_EVALUATOR_CONSENSUS_RUNS`` so
    the audit and main article evaluator default to the same N=3 filtering.
    """
    return (
        _parse_positive_int_env("FACTUAL_AUDIT_CONSENSUS_RUNS")
        or _parse_positive_int_env("ARTICLE_EVALUATOR_CONSENSUS_RUNS")
        or _DEFAULT_ARTICLE_AUDIT_CONSENSUS_RUNS
    )


def _has_consensus_failure(
    failures: list[FactualAccuracyAuditResponse],
    non_skipped: list[FactualAccuracyAuditResponse],
    n: int,
) -> bool:
    """Return True when usable runs unanimously fail with enough support."""
    if not failures or len(failures) != len(non_skipped):
        return False
    required_failures = max(1, math.ceil(n / 2))
    return len(failures) >= required_failures


async def run_consensus_factual_accuracy_audit(
    evaluator: "BaseEvaluator",
    *,
    content: str,
    curriculum: str,
    full_context: Optional[str],
    subcontent_results: Optional[List[Any]],
    request_metadata: Optional[RequestMetadata],
    analyzed_image_urls: Optional[set],
    curriculum_version: Optional[str],
) -> FactualAccuracyAuditResponse:
    """Run the factual audit N times and require unanimous agreement.

    Only returns score=0.0 when ALL N runs independently flag a factual
    error. If any run passes (1.0) or is skipped, the final result passes.
    This dramatically reduces false-positive variance while preserving
    detection of consistently-identified real errors.
    """
    import asyncio as _asyncio

    n = _get_consensus_runs()
    if n <= 1:
        return await run_factual_accuracy_audit(
            evaluator,
            content=content,
            curriculum=curriculum,
            full_context=full_context,
            subcontent_results=subcontent_results,
            request_metadata=request_metadata,
            analyzed_image_urls=analyzed_image_urls,
            curriculum_version=curriculum_version,
        )

    audit_coros = [
        run_factual_accuracy_audit(
            evaluator,
            content=content,
            curriculum=curriculum,
            full_context=full_context,
            subcontent_results=subcontent_results,
            request_metadata=request_metadata,
            analyzed_image_urls=analyzed_image_urls,
            curriculum_version=curriculum_version,
        )
        for _ in range(n)
    ]
    results: list[FactualAccuracyAuditResponse] = await _asyncio.gather(*audit_coros)

    failures = [r for r in results if not r.skipped and r.score < 0.5]
    non_skipped = [r for r in results if not r.skipped]

    # Require unanimity across usable runs, with enough successful failures to
    # represent a real consensus. This preserves 2/3 fail + 1 skipped while
    # preventing 1 fail + 2 skipped from downgrading content.
    if _has_consensus_failure(failures, non_skipped, n):
        logger.info(
            "Consensus audit: %d/%d usable runs agree on factual error "
            "(%d configured) - flagging.",
            len(failures), len(non_skipped), n,
        )
        best = max(failures, key=lambda r: len(r.reasoning or ""))
        return FactualAccuracyAuditResponse(
            score=0.0,
            reasoning=(
                f"[FactualAccuracyAudit] CONSENSUS "
                f"({len(failures)}/{len(non_skipped)} usable runs agree; {n} configured): "
                + (best.reasoning or "").replace("[FactualAccuracyAudit] ", "", 1)
            ),
            suggested_improvements=best.suggested_improvements,
            skipped=False,
        )

    passes = [r for r in non_skipped if r.score >= 0.5]
    logger.info(
        "Consensus audit: %d/%d flagged, %d/%d passed — no consensus, preserving main score.",
        len(failures), n, len(passes), n,
    )
    best_pass = (
        max(passes, key=lambda r: len(r.reasoning or ""))
        if passes
        else FactualAccuracyAuditResponse(
            score=1.0,
            reasoning=f"[FactualAccuracyAudit] No consensus ({len(failures)}/{n} flagged) — preserving main score.",
            skipped=True,
        )
    )
    return FactualAccuracyAuditResponse(
        score=1.0,
        reasoning=(
            f"[FactualAccuracyAudit] No consensus ({len(failures)}/{n} flagged): "
            + (best_pass.reasoning or "").replace("[FactualAccuracyAudit] ", "", 1)
        ),
        suggested_improvements=None,
        skipped=True,
    )


_ARTICLE_AUDIT_PREAMBLE = """You are an independent **factual-accuracy auditor** for educational articles.

Evaluate **only** the **factual_accuracy** metric. Do not score any other metrics.

Your task is to check whether the article's factual claims (in the body text, section explanations,
and any worked examples or practice problems) are accurate. Focus on:

1. **Factual claims in article text** — dates, names, events, scientific facts, mathematical
   statements, geographic facts. A claim is wrong if it directly contradicts well-established
   educational knowledge.

2. **Mathematical content** — if the article includes worked examples or practice problems,
   check that the calculations and answers are correct.

3. **Curriculum alignment accuracy** — if the article references specific standards, formulas,
   or concepts, check that they are correctly described.

**Mandatory self-check before scoring 0.0 (the "correction test"):**

Before assigning score 0.0, you MUST pass ALL THREE of these gates for at least one claim.
If any gate fails, you must score 1.0.

  Gate 1 — **State the error and correction.** Write: "The article says [X]. The established
  fact is [Y]." Both X and Y must be specific and concrete.

  Gate 2 — **Confirm the correction is in your reliable knowledge.** Your correction must be
  something widely documented and unambiguous. You MUST NOT score 0.0 based on claims that
  a specific document "does not exist" or "is not canonical", or on bibliographic metadata
  disputes where scholars disagree.

  Gate 3 — **Confirm student harm.** Would a student who learns from this article walk away
  with a substantively wrong understanding of the topic? Minor simplifications that are
  standard for the grade level are NOT student harm.

**Output rules:**
- `contradiction_found`: true if a factual error was found (passes all 3 gates); false otherwise.
- `score`: exactly 0.0 if contradiction_found=true; exactly 1.0 if false.
- `reasoning`: clear, human-readable; start with `[FactualAccuracyAudit] `.
- `suggested_improvements`: required when score is 0.0; omit or null when 1.0.

Use all supporting context blocks (math verification, curriculum, etc.) the same way the main
evaluator would when judging factual accuracy.
"""

_ARTICLE_RAG_AUDIT_PREAMBLE = """You are a factual accuracy checker for educational articles.

## Step 1 — Self-consistency check

Check whether the article's own factual claims are internally consistent: dates, names,
cause-effect relationships, mathematical statements, and descriptions of concepts.

Score **0.0 immediately** (skip the Wikipedia check) if:
- The article contains a direct internal contradiction (e.g., states two incompatible dates
  for the same event, or provides a mathematical example with an incorrect answer).
- A mathematical worked example contains a clear arithmetic error.

## Step 2 — Wikipedia contradiction check

You have been given Wikipedia passages about the article's topic. Check whether the article
contains a factual claim that is DIRECTLY CONTRADICTED by the provided passages.

**Rules:**
1. If the passages do NOT address a specific claim → score **1.0** (no evidence to judge)
2. If the passages SUPPORT or are consistent with the claim → score **1.0**
3. Score **0.0** ONLY if a passage clearly and directly contradicts a specific factual claim
   in the article body text or its explanations
4. Grade-level simplifications are acceptable — do not flag unless a passage says something
   directly opposite
5. Focus only on claims presented as factual truths in the article, not on pedagogical choices

**Before scoring 0.0 for a Wikipedia contradiction**, you must be able to complete this template:
  "The article says [X]. The passage says [Y]. These directly contradict."
If you cannot fill this in using actual text from the passages → score 1.0.

**CRITICAL — Score must match your own reasoning:**
Your `score` field must be consistent with your conclusion in `reasoning`.
- If your reasoning says "no contradiction found" or equivalent → you MUST output score **1.0**.
- The ONLY valid reason to output 0.0 is when you can fill in the template above.

**Output — three fields, all required:**
- `contradiction_found`: boolean — true ONLY if you can fill in the template above with quoted text.
- `score`: exactly 0.0 if contradiction_found=true; exactly 1.0 if false.
- `reasoning`: start with `[FactualAccuracyAudit] `; state what you found or confirmed
- `suggested_improvements`: required only when contradiction_found=true

[WIKIPEDIA PASSAGES]
{passages}
[/WIKIPEDIA PASSAGES]
"""


async def run_consensus_factual_accuracy_audit_for_article(
    evaluator: "BaseEvaluator",
    *,
    content: str,
    curriculum: str,
    full_context: Optional[str],
    subcontent_results: Optional[List[Any]],
    request_metadata: Optional[RequestMetadata],
    analyzed_image_urls: Optional[set],
    curriculum_version: Optional[str],
) -> FactualAccuracyAuditResponse:
    """Run the factual audit for articles using article-specific preamble.

    Uses ``_ARTICLE_AUDIT_PREAMBLE`` / ``_ARTICLE_RAG_AUDIT_PREAMBLE`` which
    focus on checking factual claims in article body text and explanations
    rather than answer-key consistency (which is question-specific).

    Suppresses wiki injection inside ``ArticleEvaluator._get_programmatic_context``
    for the duration of the audit, since the audit's RAG preamble already
    carries its own Wikipedia passages and including them twice wastes tokens
    and confuses the model.
    """
    import asyncio as _asyncio

    from inceptbench.evaluators.article import (
        _suppress_wiki_in_programmatic_context,
    )

    wiki_token = _suppress_wiki_in_programmatic_context.set(True)
    try:
        n = _get_article_audit_consensus_runs()
        if n <= 1:
            return await run_factual_accuracy_audit(
                evaluator,
                content=content,
                curriculum=curriculum,
                full_context=full_context,
                subcontent_results=subcontent_results,
                request_metadata=request_metadata,
                analyzed_image_urls=analyzed_image_urls,
                curriculum_version=curriculum_version,
                preamble_override=_ARTICLE_AUDIT_PREAMBLE,
                rag_preamble_override=_ARTICLE_RAG_AUDIT_PREAMBLE,
            )

        audit_coros = [
            run_factual_accuracy_audit(
                evaluator,
                content=content,
                curriculum=curriculum,
                full_context=full_context,
                subcontent_results=subcontent_results,
                request_metadata=request_metadata,
                analyzed_image_urls=analyzed_image_urls,
                curriculum_version=curriculum_version,
                preamble_override=_ARTICLE_AUDIT_PREAMBLE,
                rag_preamble_override=_ARTICLE_RAG_AUDIT_PREAMBLE,
            )
            for _ in range(n)
        ]
        results: list[FactualAccuracyAuditResponse] = await _asyncio.gather(*audit_coros)
    finally:
        _suppress_wiki_in_programmatic_context.reset(wiki_token)

    failures = [r for r in results if not r.skipped and r.score < 0.5]
    non_skipped = [r for r in results if not r.skipped]

    # Require unanimity across usable runs, with enough successful failures to
    # represent a real consensus. This preserves 2/3 fail + 1 skipped while
    # preventing 1 fail + 2 skipped from downgrading content.
    if _has_consensus_failure(failures, non_skipped, n):
        logger.info(
            "Article consensus audit: %d/%d usable runs agree on factual error "
            "(%d configured) - flagging.",
            len(failures), len(non_skipped), n,
        )
        best = max(failures, key=lambda r: len(r.reasoning or ""))
        return FactualAccuracyAuditResponse(
            score=0.0,
            reasoning=(
                f"[FactualAccuracyAudit] CONSENSUS "
                f"({len(failures)}/{len(non_skipped)} usable runs agree; {n} configured): "
                + (best.reasoning or "").replace("[FactualAccuracyAudit] ", "", 1)
            ),
            suggested_improvements=best.suggested_improvements,
            skipped=False,
        )

    passes = [r for r in non_skipped if r.score >= 0.5]
    logger.info(
        "Article consensus audit: %d/%d flagged, %d/%d passed — no consensus.",
        len(failures), n, len(passes), n,
    )
    best_pass = (
        max(passes, key=lambda r: len(r.reasoning or ""))
        if passes
        else FactualAccuracyAuditResponse(
            score=1.0,
            reasoning=f"[FactualAccuracyAudit] No consensus ({len(failures)}/{n} flagged) — preserving main score.",
            skipped=True,
        )
    )
    return FactualAccuracyAuditResponse(
        score=1.0,
        reasoning=(
            f"[FactualAccuracyAudit] No consensus ({len(failures)}/{n} flagged): "
            + (best_pass.reasoning or "").replace("[FactualAccuracyAudit] ", "", 1)
        ),
        suggested_improvements=None,
        skipped=True,
    )


async def run_factual_accuracy_audit(
    evaluator: "BaseEvaluator",
    *,
    content: str,
    curriculum: str,
    full_context: Optional[str],
    subcontent_results: Optional[List[Any]],
    request_metadata: Optional[RequestMetadata],
    analyzed_image_urls: Optional[set],
    curriculum_version: Optional[str],
    preamble_override: Optional[str] = None,
    rag_preamble_override: Optional[str] = None,
) -> FactualAccuracyAuditResponse:
    """
    Build the same context stack as the main evaluator and call the
    ``factual_grounding`` LLM. On failure, returns ``skipped=True``
    (caller preserves the main evaluator's factual score; overall unchanged).

    ``preamble_override`` replaces ``_AUDIT_PREAMBLE`` (plain mode).
    ``rag_preamble_override`` replaces ``_RAG_AUDIT_PREAMBLE`` (RAG mode).
    Pass both to customize for content types other than questions (e.g. articles).
    """
    import asyncio

    skip_images = analyzed_image_urls or set()
    try:
        programmatic_context, curriculum_context, image_analysis_context = await asyncio.gather(
            evaluator._get_programmatic_context(content, curriculum, request_metadata),
            evaluator._get_curriculum_context(content, curriculum, request_metadata, curriculum_version),
            evaluator._get_unified_image_analysis_context(content, skip_images=skip_images),
        )
    except Exception as e:
        logger.warning("Factual audit: context gather failed (%s) -- fail-open.", e)
        return FactualAccuracyAuditResponse(
            score=1.0,
            reasoning="[FactualAccuracyAudit] Skipped: could not build evaluation context.",
            skipped=True,
        )

    generation_prompt_context = ""
    if request_metadata:
        prompt_text = request_metadata.to_generation_prompt()
        generation_prompt_context = evaluator._format_generation_prompt_context(prompt_text)

    # ------------------------------------------------------------------
    # RAG: fetch Wikipedia passages for this question
    # ------------------------------------------------------------------
    skip_wikipedia = os.environ.get("FACTUAL_AUDIT_SKIP_WIKIPEDIA", "").strip().lower() in ("1", "true", "yes")
    wikipedia_passages = ""

    if skip_wikipedia:
        logger.debug("Factual audit: Wikipedia disabled via FACTUAL_AUDIT_SKIP_WIKIPEDIA.")
    else:
        grade = getattr(request_metadata, "grade", None) if request_metadata else None
        wiki_variant = _select_wiki_variant(str(grade) if grade is not None else None)
        search_term_list = await extract_multiple_search_terms(content)
        if search_term_list:
            try:
                per_query_budget = 3000 // max(len(search_term_list), 1)
                fetches = [
                    fetch_wikipedia_passages(term, variant=wiki_variant, max_tokens=per_query_budget)
                    for term in search_term_list[:3]
                ]
                results = await asyncio.gather(*fetches, return_exceptions=True)
                passage_parts = [r for r in results if isinstance(r, str) and r]
                wikipedia_passages = "\n\n---\n\n".join(passage_parts)
            except Exception as wiki_exc:
                logger.warning("Factual audit: Wikipedia fetch failed (%s) -- fail-open.", wiki_exc)

    if not wikipedia_passages and not skip_wikipedia:
        logger.debug("Factual audit: no Wikipedia passages retrieved -- skipping (fail-open).")
        return FactualAccuracyAuditResponse(
            score=1.0,
            reasoning="[FactualAccuracyAudit] Skipped: no Wikipedia passages retrieved for this topic.",
            skipped=True,
        )

    active_rag_preamble = rag_preamble_override or _RAG_AUDIT_PREAMBLE
    active_plain_preamble = preamble_override or _AUDIT_PREAMBLE
    if wikipedia_passages:
        system_prompt = active_rag_preamble.format(passages=wikipedia_passages)
    else:
        system_prompt = active_plain_preamble

    if full_context and full_context != content:
        cleaned_full_context = remove_svg_from_content(full_context)
        context_note = (
            "\n\n## FULL CONTEXT\n\n"
            "This content is part of a larger educational resource.\n\n"
            f"{cleaned_full_context}\n\n---\n\n"
            "You are auditing factual accuracy of the SPECIFIC content in the user message."
        )
        system_prompt = context_note + "\n\n" + system_prompt

    if subcontent_results:
        subcontent_context = evaluator._format_subcontent_results(subcontent_results)
        system_prompt = subcontent_context + "\n\n" + system_prompt

    if programmatic_context:
        system_prompt = programmatic_context + "\n\n" + system_prompt
    if image_analysis_context:
        system_prompt = image_analysis_context + "\n\n" + system_prompt
    if curriculum_context:
        system_prompt = curriculum_context + "\n\n" + system_prompt
    if generation_prompt_context:
        system_prompt = generation_prompt_context + "\n\n" + system_prompt

    audit_content = "Audit factual_accuracy for this question content only:\n\n" + content
    try:
        from baml_client import b as _baml
        baml_result = await _baml.AuditFactualAccuracy(
            system_prompt=system_prompt,
            content=audit_content,
        )
        parsed = FactualAccuracyAuditLLMOutput(
            score=float(getattr(baml_result, 'score', 0.0)),
            reasoning=getattr(baml_result, 'reasoning', '[FactualAccuracyAudit] No reasoning.'),
            suggested_improvements=getattr(baml_result, 'suggested_improvements', None),
        )
        return FactualAccuracyAuditResponse.from_llm_output(parsed)
    except Exception as e:
        logger.warning("Factual audit: BAML failed (%s) -- fail-open.", e)
        return FactualAccuracyAuditResponse(
            score=1.0,
            reasoning=f"[FactualAccuracyAudit] Skipped due to auditor error: {e}",
            skipped=True,
        )
