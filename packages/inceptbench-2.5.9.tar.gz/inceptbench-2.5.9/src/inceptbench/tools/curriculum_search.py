"""
Curriculum standards search functionality.

This module provides tools for searching curriculum standards via the
incept-curriculum service (/fetch and /search endpoints).
"""

import logging
import json
from typing import Optional, Tuple

from inceptbench.core.input_models import RequestMetadata
from inceptbench.tools.curriculum_client import (
    CurriculumAPIError,
    fetch_curriculum,
    format_curriculum_for_llm,
    map_curriculum_name,
    resolve_course_for_curriculum,
    search_curriculum,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers carried over from the old module (still needed)
# ---------------------------------------------------------------------------

def _is_meaningful(value) -> bool:
    """Check if a value has meaningful content (not empty/null/garbage)."""
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict)):
        return len(value) > 0
    return True


def _skills_to_query(skills, metadata: Optional[RequestMetadata] = None) -> str:
    """
    Convert a skills field to a search query string.

    Used as the search_key for the /search endpoint when no exact item_id
    is available.
    """
    parts = []

    if isinstance(skills, dict):
        for key in [
            "id",
            "standard_id",
            "standardId",
            "substandard_id",
            "code",
            "standard_code",
            "name",
            "title",
            "lesson_title",
            "description",
            "substandard_description",
            "skill",
        ]:
            if key in skills and skills[key]:
                parts.append(str(skills[key]))

        if not parts:
            parts.append(json.dumps(skills))

    elif isinstance(skills, str):
        parts.append(skills)

    elif isinstance(skills, list):
        for item in skills:
            if isinstance(item, dict):
                for key in ["id", "standard_id", "name"]:
                    if key in item and item[key]:
                        parts.append(str(item[key]))
                        break
                else:
                    parts.append(json.dumps(item))
            elif item:
                parts.append(str(item))

    if metadata:
        if metadata.grade:
            parts.append(f"Grade {metadata.grade}")
        if metadata.subject:
            parts.append(metadata.subject)

    return " ".join(parts)


def _extract_item_id(skills) -> Optional[str]:
    """
    Extract the best candidate item ID from skills payload.

    Checks standard_id, substandard_id, and other common key patterns.
    Returns the first non-empty match, or None.
    """
    if isinstance(skills, dict):
        for key in (
            "substandard_id",
            "standard_id",
            "standardId",
            "id",
            "code",
            "standard_code",
        ):
            value = skills.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    elif isinstance(skills, str):
        stripped = skills.strip()
        if stripped:
            return stripped
    return None


def _split_curriculum_result_sections(results: str) -> list[str]:
    """
    Split curriculum API text results into per-standard sections.

    The API typically starts each standard block with a line that begins with
    "Subject:". If that pattern is not found, treat the full response as one
    section.
    """
    if not results or not results.strip():
        return []

    lines = results.splitlines()
    sections = []
    current_section = []

    for line in lines:
        if line.startswith("Subject:") and current_section:
            sections.append("\n".join(current_section).strip())
            current_section = [line]
        else:
            current_section.append(line)

    if current_section:
        sections.append("\n".join(current_section).strip())

    return [section for section in sections if section]


def _extract_standard_id_from_section(section: str) -> Optional[str]:
    """Extract the Standard ID value from a section."""
    for line in section.splitlines():
        if line.startswith("Standard ID:"):
            return line.replace("Standard ID:", "", 1).strip()
    return None


def _filter_to_single_result(results: str, substandard_id: Optional[str] = None) -> str:
    """
    Reduce curriculum API results to one standard section.

    Behavior:
    - If substandard_id is provided, keep only the exact matching Standard ID.
      If no exact match exists, log a warning and return the first section
      (the RAG results are still relevant context even when the ID doesn't
      match, e.g. state-standard IDs queried against Common Core).
    - If substandard_id is not provided, keep only the first section.
    """
    sections = _split_curriculum_result_sections(results)
    if not sections:
        return results

    if substandard_id:
        for section in sections:
            standard_id = _extract_standard_id_from_section(section)
            if standard_id == substandard_id:
                return section
        found_ids = [_extract_standard_id_from_section(s) for s in sections]
        logger.warning(
            "substandard_id '%s' not found in curriculum API results "
            "(returned IDs: %s); using best RAG match instead",
            substandard_id,
            found_ids,
        )

    return sections[0]


def _determine_curriculum_confidence(
    content: str,
    request_metadata: Optional[RequestMetadata] = None,
) -> Tuple[str, str, str]:
    """
    Determine the confidence level for curriculum targeting and build the
    search query / item_id.

    Returns:
        Tuple of (confidence_level, search_query, source_description)
    """
    if request_metadata:
        # Priority 1: Explicit skills metadata
        if request_metadata.skills and _is_meaningful(request_metadata.skills):
            search_query = _skills_to_query(request_metadata.skills, request_metadata)
            return ("GUARANTEED", search_query, "explicit skills metadata")

        # Priority 2: Generation prompt (instructions field)
        if request_metadata.instructions and _is_meaningful(request_metadata.instructions):
            query_parts = []
            if request_metadata.grade:
                query_parts.append(f"Grade {request_metadata.grade}")
            if request_metadata.subject:
                query_parts.append(request_metadata.subject)
            query_parts.append(request_metadata.instructions)
            search_query = " ".join(query_parts)
            return ("HARD", search_query, "generation prompt")

    # Priority 3: Fallback to content inference
    if request_metadata:
        context_parts = []
        if request_metadata.grade:
            context_parts.append(f"Grade {request_metadata.grade}")
        if request_metadata.subject:
            context_parts.append(request_metadata.subject)
        if context_parts:
            return ("SOFT", f"{' '.join(context_parts)}\n\n{content}", "content with grade/subject context")

    return ("SOFT", content, "content inference")


def _format_curriculum_context(results: str, confidence: str, source: str) -> str:
    """Wrap formatted curriculum text in the CURRICULUM CONTEXT header block."""
    return f"""## CURRICULUM CONTEXT
Confidence: {confidence}
Source: {source}

{results}"""


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def get_curriculum_context(
    content: str,
    curriculum: str = "common_core",
    request_metadata: Optional[RequestMetadata] = None,
    curriculum_version: Optional[str] = None,
) -> str:
    """
    Get curriculum context for LLM evaluation.

    Routes to the incept-curriculum /fetch endpoint (exact ID) when a
    standard/substandard ID is available, otherwise falls back to /search.

    Returns:
        Formatted ``## CURRICULUM CONTEXT`` block, or empty string when the
        API returns no results for a valid ancestry.

    Raises:
        CurriculumAPIError: When the curriculum slug cannot be mapped to an
            API abbreviation, or when the upstream API returns a
            non-retriable error / exhausts retries.
    """
    confidence, search_query, source = _determine_curriculum_confidence(
        content, request_metadata,
    )

    # Map curriculum slug -> API abbreviation
    curriculum_abbrev = map_curriculum_name(curriculum)
    if not curriculum_abbrev:
        # Loudly fail rather than silently dropping curriculum context.
        raise CurriculumAPIError(
            f"Unknown curriculum slug '{curriculum}'. Add it to "
            f"CURRICULUM_NAME_TO_ABBREVIATION or fix the input.",
            status_code=None,
            detail=f"unknown curriculum slug '{curriculum}'",
        )

    # Derive course from grade
    grade = request_metadata.grade if request_metadata else None
    subject = request_metadata.subject if request_metadata else None
    course = resolve_course_for_curriculum(
        grade=grade,
        curriculum=curriculum_abbrev,
        subject=subject,
        curriculum_version=curriculum_version,
    )

    version_info = f", version={curriculum_version}" if curriculum_version else ""
    logger.info(
        "Curriculum lookup: curriculum=%s, confidence=%s, source=%s, "
        "subject=%s, course=%s%s",
        curriculum_abbrev, confidence, source, subject, course, version_info,
    )

    # Try exact fetch when we have an item ID (GUARANTEED confidence)
    item_id = _extract_item_id(
        request_metadata.skills if request_metadata else None,
    )

    api_response = None

    if item_id:
        api_response = await fetch_curriculum(
            item_id=item_id,
            curriculum=curriculum_abbrev,
            subject=subject,
            course=course,
            version=curriculum_version,
        )

    # Fallback to search when fetch didn't yield results
    if not api_response:
        # Build a concise search key from the query
        search_key = search_query[:200]  # keep it reasonable
        api_response = await search_curriculum(
            search_key=search_key,
            curriculum=curriculum_abbrev,
            subject=subject,
            course=course,
            version=curriculum_version,
        )

    if not api_response:
        logger.warning("No curriculum context found (curriculum=%s)", curriculum)
        return ""

    formatted = format_curriculum_for_llm(api_response)
    if not formatted:
        return ""

    return _format_curriculum_context(formatted, confidence, source)
