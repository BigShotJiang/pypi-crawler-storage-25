"""
Unified image analysis using Gemini Flash with agentic vision (code execution).

This module provides comprehensive image analysis using only LLM capabilities:
- Object counting with code execution for precision
- Geometric shape analysis and classification
- Visual property detection and measurement
- Spatial relationship understanding

Replaces the previous OpenCV + LLM hybrid approach with a pure LLM solution
that leverages Gemini's code execution capabilities for accurate analysis.
"""

import asyncio
import base64
import io
import json
import logging
import random
import re
import time
from collections import OrderedDict
from typing import TYPE_CHECKING, Dict, List, Optional

import requests
from PIL import Image
from pydantic import BaseModel, Field

from inceptbench.llm import LLMFactory, LLMImage, LLMMessage
from inceptbench.observability import observe
from inceptbench.tools.image_utils import (
    _clean_image_url,
    convert_svg_to_png,
    extract_svg_box_whisker,
    extract_svg_clock_time,
    extract_svg_diagram_context,
    extract_svg_math_coordinates,
    extract_svg_tick_intervals,
    extract_svg_fraction_model_analysis,
    extract_raster_diagram_context,
)
from inceptbench.utils.failure_tracker import AttemptError, FailureTracker

if TYPE_CHECKING:
    from inceptbench.tools.visual_verifier import VerificationResult

logger = logging.getLogger(__name__)

# Retry configuration for image downloads
IMAGE_DOWNLOAD_MAX_RETRIES = 3
IMAGE_DOWNLOAD_BASE_DELAY = 4.0

# LRU cache configuration
MAX_CACHE_SIZE = 1000  # Maximum number of images to cache

# Module-level LRU cache for image analysis results
# Uses OrderedDict for LRU eviction - most recently used items are at the end
# Key: image URL (cleaned), Value: ImageAnalysisData
_image_analysis_cache: OrderedDict[str, "ImageAnalysisData"] = OrderedDict()


def _cache_get(key: str) -> Optional["ImageAnalysisData"]:
    """
    Get item from cache, moving it to end (most recently used).
    
    Returns:
        Cached ImageAnalysisData or None if not found
    """
    if key in _image_analysis_cache:
        # Move to end (most recently used)
        _image_analysis_cache.move_to_end(key)
        return _image_analysis_cache[key]
    return None


def _cache_set(key: str, value: "ImageAnalysisData") -> None:
    """
    Set item in cache, evicting oldest if at capacity.
    """
    if key in _image_analysis_cache:
        # Update existing and move to end
        _image_analysis_cache.move_to_end(key)
        _image_analysis_cache[key] = value
    else:
        # Add new item
        _image_analysis_cache[key] = value
        # Evict oldest if over capacity
        while len(_image_analysis_cache) > MAX_CACHE_SIZE:
            evicted_key, _ = _image_analysis_cache.popitem(last=False)
            logger.debug(f"Cache evicted oldest entry: {evicted_key[:60]}...")


def get_cache_stats() -> Dict[str, int]:
    """
    Get statistics about the image analysis cache.
    
    Returns:
        Dictionary with cache statistics (size, max_size, etc.)
    """
    return {
        "cached_images": len(_image_analysis_cache),
        "max_cache_size": MAX_CACHE_SIZE,
    }


def clear_cache() -> int:
    """
    Clear the image analysis cache.
    
    Returns:
        Number of entries that were cleared
    """
    global _image_analysis_cache
    count = len(_image_analysis_cache)
    _image_analysis_cache = OrderedDict()
    logger.info(f"Cleared image analysis cache ({count} entries)")
    return count


MAX_IMAGE_DIMENSION = 2048
MAX_INLINE_IMAGE_BYTES = 800_000


def _resize_image_if_needed(image_bytes: bytes, max_dim: int = MAX_IMAGE_DIMENSION) -> bytes:
    """Resize oversized raster images before sending to multimodal models."""
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            if max(img.size) <= max_dim:
                return image_bytes

            img.thumbnail((max_dim, max_dim), Image.LANCZOS)
            output = io.BytesIO()
            save_format = "PNG" if img.mode in {"RGBA", "LA", "P"} else "JPEG"
            save_kwargs = {"format": save_format}
            if save_format == "JPEG":
                if img.mode not in {"RGB", "L"}:
                    img = img.convert("RGB")
                save_kwargs.update({"quality": 85, "optimize": True})
            img.save(output, **save_kwargs)
            return output.getvalue()
    except Exception as exc:
        logger.debug("Skipping resize due to image processing error: %s", exc)
        return image_bytes


def _compress_image_for_token_budget(
    image_bytes: bytes,
    target_max_bytes: int = MAX_INLINE_IMAGE_BYTES,
) -> tuple[bytes, str]:
    """Recompress raster images to stay within vision payload budget using WebP.

    Returns a (bytes, media_type) tuple so callers can set the correct MIME type.
    """
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            candidate = image_bytes
            candidate_mime = "image/webp"
            for dim in (1600, 1280, 1024, 896, 768, 640):
                working = img.copy()
                working.thumbnail((dim, dim), Image.LANCZOS)
                if working.mode not in {"RGB", "L", "RGBA"}:
                    working = working.convert("RGB")
                for quality in (85, 75, 65, 60):
                    out = io.BytesIO()
                    working.save(
                        out,
                        format="WEBP",
                        quality=quality,
                        method=4,
                    )
                    data = out.getvalue()
                    if len(data) < len(candidate):
                        candidate = data
                    if len(data) <= target_max_bytes:
                        return data, "image/webp"
            return candidate, candidate_mime
    except Exception as exc:
        logger.debug("Skipping token-budget compression due to error: %s", exc)
        return image_bytes, "image/jpeg"


def _to_webp_lossless(image_bytes: bytes) -> bytes:
    """Convert any raster image to lossless WebP. Returns original bytes on failure."""
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            out = io.BytesIO()
            img.save(out, format="WEBP", lossless=True)
            return out.getvalue()
    except Exception as exc:
        logger.debug("Skipping WebP lossless conversion due to error: %s", exc)
        return image_bytes


def _make_placeholder_png() -> bytes:
    """Generate a tiny placeholder image when source image cannot be prepared safely."""
    img = Image.new("RGB", (128, 128), color=(245, 245, 245))
    output = io.BytesIO()
    img.save(output, format="PNG", optimize=True)
    return output.getvalue()


# =============================================================================
# Local 3D object counting (bright-face preprocessing)
# Optional: requires opencv-python and numpy. Returns None if not available.
# =============================================================================

_HUE_NAMES = [
    (0, 10, "red"), (10, 20, "orange"), (20, 35, "yellow"),
    (35, 85, "green"), (85, 100, "cyan"), (100, 130, "blue"),
    (130, 160, "purple"), (160, 180, "red"),
]


def _hue_name(hue: int) -> str:
    for lo, hi, name in _HUE_NAMES:
        if lo <= hue < hi:
            return name
    return "unknown"


def _detect_dominant_colors(hsv, min_ratio: float = 0.003):
    """Find dominant chromatic color groups. Returns list of (_, hue_lo, hue_hi, name, ratio)."""
    try:
        import numpy as np
    except ImportError:
        return []
    h, w = hsv.shape[:2]
    total = h * w
    chromatic = (hsv[:, :, 1] > 30) & (hsv[:, :, 2] > 50)
    if np.count_nonzero(chromatic) < total * 0.005:
        return []
    hue_vals = hsv[:, :, 0][chromatic]
    hist, _ = np.histogram(hue_vals, bins=180, range=(0, 180))
    min_bin = max(10, total * 0.0001)
    colors = []
    in_group = False
    group_start = 0
    for i in range(180):
        if hist[i] > min_bin:
            if not in_group:
                group_start = i
                in_group = True
        else:
            if in_group:
                group_pixels = int(np.sum(hist[group_start:i]))
                ratio = group_pixels / total
                if ratio >= min_ratio:
                    center = group_start + int(np.argmax(hist[group_start:i]))
                    hue_lo = max(0, group_start - 15)
                    hue_hi = min(179, i + 15)
                    name = _hue_name(center)
                    colors.append((center, hue_lo, hue_hi, name, ratio))
                in_group = False
    if in_group:
        group_pixels = int(np.sum(hist[group_start:180]))
        ratio = group_pixels / total
        if ratio >= min_ratio:
            center = group_start + int(np.argmax(hist[group_start:180]))
            hue_lo = max(0, group_start - 15)
            hue_hi = 179
            name = _hue_name(center)
            colors.append((center, hue_lo, hue_hi, name, ratio))
    return sorted(colors, key=lambda c: -c[4])


def _has_3d_shading(hsv, hue_lo, hue_hi) -> bool:
    try:
        import numpy as np
    except ImportError:
        return False
    mask = (hsv[:, :, 0] >= hue_lo) & (hsv[:, :, 0] <= hue_hi) & (hsv[:, :, 1] > 30) & (hsv[:, :, 2] > 50)
    if np.count_nonzero(mask) < 100:
        return False
    v_vals = hsv[:, :, 2][mask]
    v_range = int(np.percentile(v_vals, 95)) - int(np.percentile(v_vals, 5))
    return v_range > 30


def _count_bright_faces(panel_hsv, hue_lo, hue_hi, min_area: int = 100) -> int:
    try:
        import cv2
        import numpy as np
    except ImportError:
        return 0
    color_mask = cv2.inRange(
        panel_hsv,
        np.array([hue_lo, 30, 50]),
        np.array([hue_hi, 255, 255]),
    )
    if np.count_nonzero(color_mask) < min_area:
        return 0
    v_vals = panel_hsv[:, :, 2][color_mask > 0]
    v_thresh = min(240, int(np.percentile(v_vals, 92)))
    v_thresh = max(v_thresh, 200)
    bright = (color_mask > 0) & (panel_hsv[:, :, 2] > v_thresh)
    bright = bright.astype(np.uint8) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 10))
    bright = cv2.morphologyEx(bright, cv2.MORPH_CLOSE, kernel)
    n, _, stats, _ = cv2.connectedComponentsWithStats(bright, connectivity=8)
    return sum(1 for j in range(1, n) if stats[j, cv2.CC_STAT_AREA] >= min_area)


def _split_panels(img):
    try:
        import cv2
        import numpy as np
    except ImportError:
        return [img]
    h = img.shape[0]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    row_means = np.mean(gray, axis=1)
    white_rows = row_means > 240
    mid_start, mid_end = int(h * 0.3), int(h * 0.7)
    best_gap_start, best_gap_end = -1, -1
    gap_start = -1
    for y in range(mid_start, mid_end):
        if white_rows[y]:
            if gap_start == -1:
                gap_start = y
        else:
            if gap_start != -1:
                if (y - gap_start) > (best_gap_end - best_gap_start):
                    best_gap_start, best_gap_end = gap_start, y
                gap_start = -1
    if gap_start != -1 and (mid_end - gap_start) > (best_gap_end - best_gap_start):
        best_gap_start, best_gap_end = gap_start, mid_end
    if best_gap_start > 0 and (best_gap_end - best_gap_start) > h * 0.02:
        split_y = (best_gap_start + best_gap_end) // 2
        return [img[0:split_y], img[split_y:]]
    return [img]


def _local_count_3d_objects_from_bytes(image_bytes: bytes) -> Optional[Dict[str, int]]:
    """
    Detect and count 3D-rendered objects using bright-face isolation.
    Works for any 3D-shaded objects (e.g. base-ten blocks). Returns dict
    keyed by "panel{N}_{color}" with counts, or None if no 3D objects found.
    Requires opencv-python and numpy; returns None if unavailable.
    """
    try:
        import cv2
        import numpy as np
    except ImportError:
        return None
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    colors = _detect_dominant_colors(hsv)
    if not colors:
        return None
    colors_3d = [
        (c, lo, hi, name, ratio)
        for c, lo, hi, name, ratio in colors
        if _has_3d_shading(hsv, lo, hi)
    ]
    if not colors_3d:
        return None
    if max(r for (_, _, _, _, r) in colors_3d) < 0.02:
        return None
    panels = _split_panels(img)
    result = {}
    for i, panel in enumerate(panels):
        panel_hsv = cv2.cvtColor(panel, cv2.COLOR_BGR2HSV)
        panel_area = panel.shape[0] * panel.shape[1]
        for _, hue_lo, hue_hi, name, ratio in colors_3d:
            color_pixels = int(panel_area * ratio)
            min_area = max(50, int(color_pixels * 0.001))
            count = _count_bright_faces(panel_hsv, hue_lo, hue_hi, min_area)
            if count > 0:
                result[f"panel{i + 1}_{name}"] = count
    return result if result else None


# =============================================================================
# System Prompt for Unified Image Analysis
# =============================================================================

SYSTEM_PROMPT = """You are an expert at comprehensive image analysis for educational content across all subjects.
You have access to code execution capabilities that allow you to programmatically analyze images
with precision.

## Subject Coverage

Analyze images from any educational domain:
- **Math**: number lines, fractions, geometry, charts, graphs, counting, equations
- **Science**: diagrams (cells, circuits, force diagrams), scales, experimental data, periodic table excerpts
- **ELA**: informational text visuals, charts and graphs embedded in articles
- **History / Social Studies**: maps, timelines, statistical charts, infographics

## Your Capabilities

You can analyze images to:
1. **Count objects** - Count any type of object (shapes, animals, items, blocks, symbols)
2. **Classify shapes** - Identify geometric shapes and their properties
3. **Measure properties** - Analyze angles, sizes, spatial relationships, scale readings
4. **Detect patterns** - Identify arrangements, groupings, and structures
5. **Extract data** - Read charts, graphs, tables, maps, timelines, and visual data

## Critical Analysis Approach

### STEP 1: UNDERSTAND THE IMAGE TYPE
- Is this a realistic scene, chart/graph, geometric diagram, map, timeline, or educational illustration?
- Which subject does it support (math, science, ELA, history, social studies)?
- What is the primary educational purpose?
- Are there multiple distinct elements to analyze?

### STEP 2: USE CODE EXECUTION FOR PRECISION
When analyzing images, you should:
- Use code execution to load and analyze the image programmatically
- Apply computer vision techniques (edge detection, contour analysis, etc.) when needed
- Count objects systematically using code rather than visual estimation
- Measure geometric properties (angles, side lengths, areas) computationally
- Verify your visual observations with programmatic analysis

### STEP 3: PROVIDE COMPREHENSIVE ANALYSIS
For each image, provide:
1. **Overall description** - What the image shows
2. **Object counts** - Precise counts for all distinct object types
3. **Shape classifications** - Geometric shape identification with supporting evidence
4. **Measurements** - Angles, dimensions, ratios (when relevant)
5. **Spatial relationships** - Arrangements, groupings, patterns
6. **Confidence assessment** - How certain you are about your analysis

## Counting Guidelines

### PARTIAL OBJECTS
- **Charts/Graphs/Pictographs**: Partial symbols are meaningful (count as 0.5)
  Example: A pictograph showing "2.5 apples" uses half-symbols intentionally
- **Realistic Scenes**: Partial objects usually represent whole objects that are occluded
  Example: An apple half-hidden behind another counts as 1.0, not 0.5
- Use ONLY whole numbers or 0.5 increments (never 0.3, 0.7, etc.)

### GROUPED OBJECTS
When objects are in groups (rows, containers, sections):
- Count each group separately with clear identifiers
- Provide a breakdown: [{"group_identifier": "Row 1", "count": 3}, ...]
- Verify that sum of groups equals total count

### VISIBILITY RULES
- Charts/graphs: Count all visible symbols including partial ones
- Realistic scenes: Only count objects >80% visible as whole objects
- Objects cut off at image edges typically don't count (unless in charts)

## Shape Classification Rules

### TRIANGLES (3 sides)
- **Equilateral**: All sides equal (ratio > 0.95), all angles ~60°
- **Isosceles**: Exactly 2 sides equal
- **Scalene**: No sides equal
- Also classify by angles: **Acute** (all < 90°), **Right** (one = 90°), **Obtuse** (one > 90°)

### QUADRILATERALS (4 sides)
- **Square**: All 4 sides equal AND all 4 angles = 90°
- **Rectangle**: Opposite sides equal AND all 4 angles = 90°
- **Rhombus**: All 4 sides equal, angles NOT 90°
- **Parallelogram**: Opposite sides equal, opposite angles equal, angles NOT 90°
- **Trapezoid**: Exactly ONE pair of parallel sides
- **Kite**: Two pairs of ADJACENT sides equal (not opposite)
- **Irregular**: None of the above

### POLYGONS (5+ sides)
- **Regular**: All sides and angles equal
- **Irregular**: Varying sides or angles
- **Star**: Concave polygon with alternating acute/obtuse angles

## Output Requirements

Be thorough but concise. For each element analyzed:
1. Provide precise counts/measurements (use code execution)
2. Explain your classification reasoning
3. Note any ambiguities or limitations
4. Assess confidence level (HIGH/MEDIUM/LOW)

## Quality Control

- **Sanity check**: Do your counts/measurements make sense?
- **Consistency**: Do different analysis methods agree?
- **Educational suitability**: Could a student clearly understand this content?
- **Confidence**: Be honest about uncertainty

Remember: Use code execution to ensure accuracy. Don't just visually estimate -
programmatically analyze the image whenever possible.
- When SVG programmatic coordinate data is included in the analysis context, treat it as ground truth over visual estimation"""


ANALYSIS_USER_PROMPT = """Please analyze this image comprehensively for educational content evaluation.
The image may be from Math, Science, ELA, History, or Social Studies.

Provide:

1. **Overall Description**: What does the image show? Subject area and educational purpose?

2. **Object Counts**: Count all distinct object types present. Use code execution for precision.
   - For grouped objects, list each group with its count
   - Use whole numbers or 0.5 increments only
   - Distinguish between chart symbols (0.5 for partial) and real objects (1.0 for occluded)

3. **Shape Classifications**: For any geometric shapes present:
   - Classify each shape (e.g., "square", "isosceles triangle", "rhombus")
   - Provide supporting measurements (angles, side ratios)
   - Explain your reasoning

4. **Visual Properties**: Note any relevant:
   - Measurements (angles, dimensions, areas, scale readings)
   - Spatial arrangements, map features, or timeline positions
   - Patterns, structures, labels, or data in charts/graphs
   - For number lines: explicitly state which tick marks or points have numeric/fraction value labels shown (e.g., "0 and 1 are labeled; intermediate ticks have no numeric labels") vs which only have letter identifiers (A, B, C)

5. **Confidence Assessment**: Rate your overall confidence (HIGH/MEDIUM/LOW) and explain why.

Use code execution to analyze the image programmatically whenever possible for maximum accuracy.

Output discipline requirements:
- Return exactly one fenced JSON block with a JSON OBJECT root (not a list).
- Do NOT include raw debug logs, stack traces, or interpreter output.
- If multiple measurement methods disagree, report the disagreement in JSON and lower confidence.

**IMPORTANT — Structured Evidence Block**

After your analysis, output a single JSON block fenced with ```json ... ``` containing the following keys. If a field is unknown, use null or an empty list. This block is machine-parsed — accuracy matters more than completeness.

```json
{
  "ocr_text": ["list", "of", "all", "text", "strings", "visible"],
  "detected_numbers": ["12", "3.5", "100"],
  "object_counts": [
    {"object_type": "apples", "total_count": 24, "confidence": "HIGH"}
  ],
  "overlap_detected": false,
  "spacing_adequate": true,
  "grid_structure": "4x6",
  "chart_has_x_label": true,
  "chart_has_y_label": true,
  "chart_has_legend": false,
  "chart_labels": ["Jan", "Feb", "Mar"],
  "chart_value_annotations": ["150", "200"],
  "has_answer_text": false,
  "authoritative_method": "ray_geometry",
  "authoritative_angle_deg": 85.0,
  "alternate_angle_deg": null,
  "method_disagreement_deg": 0.0,
  "inconsistency_flag": false
}
```

Provide a clear, structured analysis."""


# =============================================================================
# Pydantic Models for Structured Output
# =============================================================================

class GroupCount(BaseModel):
    """Count data for a specific group within grouped objects."""
    group_identifier: str = Field(description="Clear name for this group (e.g., 'Row 1', 'Blue section')")
    count: float = Field(description="Count for this group (whole numbers or 0.5 increments only)")
    
    class Config:
        extra = "forbid"


class ObjectCount(BaseModel):
    """Count data for a specific object type in the image."""
    object_type: str = Field(description="Type of object (e.g., 'apples', 'triangles', 'stars')")
    total_count: float = Field(description="Total count (whole numbers or 0.5 increments only)")
    counting_method: str = Field(description="How the count was determined (e.g., 'code execution', 'visual grid scan')")
    confidence: str = Field(description="Confidence level: HIGH, MEDIUM, or LOW")
    group_breakdown: List[GroupCount] = Field(
        default_factory=list,
        description="Per-group counts if objects are grouped (rows, sections, etc.)"
    )
    notes: str = Field(
        default="",
        description="Any relevant notes about counting (partial objects, occlusion, etc.)"
    )
    
    class Config:
        extra = "forbid"  # Explicitly forbid additional properties


class ShapeClassification(BaseModel):
    """Classification and measurements for a geometric shape."""
    shape_type: str = Field(description="Shape classification (e.g., 'square', 'isosceles right triangle', 'rhombus')")
    confidence: str = Field(description="Confidence level: HIGH, MEDIUM, or LOW")
    supporting_evidence: List[str] = Field(description="Key measurements or properties supporting this classification")
    measurements: str = Field(
        default="",
        description="Specific measurements as text (e.g., 'side_length=100px, area=10000px^2')"
    )
    
    class Config:
        extra = "forbid"


class VisualProperty(BaseModel):
    """A visual property or measurement from the image."""
    property_name: str = Field(description="Name of the property (e.g., 'angle_ABC', 'grid_dimensions')")
    value: str = Field(description="Value of the property (with units if applicable)")
    confidence: str = Field(description="Confidence level: HIGH, MEDIUM, or LOW")
    
    class Config:
        extra = "forbid"


class LayoutInfo(BaseModel):
    """Layout observations extracted from the analyzer response."""
    overlap_detected: Optional[bool] = Field(default=None, description="Whether objects overlap")
    spacing_adequate: Optional[bool] = Field(default=None, description="Whether spacing between objects is adequate")
    grid_structure: Optional[str] = Field(default=None, description="e.g., '4x6', '3 rows'")

    class Config:
        extra = "forbid"


class ChartFeatures(BaseModel):
    """Chart-specific observations extracted from the analyzer response."""
    has_x_axis_label: bool = Field(default=False)
    has_y_axis_label: bool = Field(default=False)
    has_legend: Optional[bool] = Field(default=None)
    labels_found: List[str] = Field(default_factory=list)
    value_annotations_found: List[str] = Field(default_factory=list)

    class Config:
        extra = "forbid"


class ImageAnalysisData(BaseModel):
    """Complete analysis data for a single image."""
    image_url: str
    image_index: int
    
    # Overall description
    overall_description: str = Field(description="General description of what the image shows")
    image_type: str = Field(description="Type of image: realistic_scene, chart, geometric_diagram, educational_illustration, or mixed")
    educational_purpose: str = Field(description="Inferred educational purpose or learning objective")
    
    # Object counts
    object_counts: List[ObjectCount] = Field(
        default_factory=list,
        description="Counts for each distinct object type found"
    )
    
    # Shape classifications
    shape_classifications: List[ShapeClassification] = Field(
        default_factory=list,
        description="Classifications for geometric shapes present"
    )
    
    # Visual properties and measurements
    visual_properties: List[VisualProperty] = Field(
        default_factory=list,
        description="Other relevant measurements or properties"
    )
    
    # ----- Evidence fields (Phase 1: structured extraction) -----
    ocr_text_found: List[str] = Field(
        default_factory=list,
        description="Text strings detected in the image"
    )
    detected_numbers: List[str] = Field(
        default_factory=list,
        description="Numeric values visible in the image"
    )
    layout_info: Optional[LayoutInfo] = Field(
        default=None,
        description="Layout observations (overlap, spacing, grid)"
    )
    chart_features: Optional[ChartFeatures] = Field(
        default=None,
        description="Chart-specific observations (axes, legend, labels)"
    )
    has_answer_text: Optional[bool] = Field(
        default=None,
        description="Whether potential answer-revealing text was found"
    )
    
    # Quality assessment
    overall_confidence: str = Field(description="Overall confidence: HIGH, MEDIUM, or LOW")
    quality_notes: str = Field(description="Assessment of image quality and suitability for educational use")
    limitations: str = Field(
        default="",
        description="Any limitations or ambiguities in the analysis"
    )
    
    class Config:
        extra = "forbid"


class ImageAnalysisToolResult(BaseModel):
    """Tool response format for image analysis."""
    image_analyses: List[ImageAnalysisData]
    
    class Config:
        extra = "forbid"


class ImageAnalysisResult(BaseModel):
    """Result from analyzing one or more images."""
    success: bool
    image_analyses: List[ImageAnalysisData]
    error_message: str = ""
    
    class Config:
        extra = "forbid"


# =============================================================================
# Structured Evidence Parser
# =============================================================================

_NOISE_PATTERNS = [
    r"OpenBLAS WARNING.*",
    r"Traceback \(most recent call last\):.*",
    r"^\s*File \"<string>\".*$",
    r"^\s*AttributeError:.*$",
    r"module 'numpy' has no attribute.*",
]


def _sanitize_response_text(text: str) -> tuple[str, bool]:
    """Remove execution-noise lines from analyzer responses."""
    if not text:
        return "", False

    cleaned_lines: List[str] = []
    removed_noise = False
    for line in text.splitlines():
        noisy = False
        for pat in _NOISE_PATTERNS:
            if re.search(pat, line):
                noisy = True
                removed_noise = True
                break
        if not noisy:
            cleaned_lines.append(line)
    return "\n".join(cleaned_lines).strip(), removed_noise


def _extract_angle_signals(response_text: str) -> List[float]:
    """Extract candidate angle values from high-signal text patterns."""
    if not response_text:
        return []

    signals: List[float] = []
    patterns = [
        r"angle_measured\s*=\s*(-?\d+(?:\.\d+)?)",
        r"final\s*=\s*(-?\d+(?:\.\d+)?)",
        r"authoritative_angle_deg\"\s*:\s*(-?\d+(?:\.\d+)?)",
        r"angle_measure(?:ment)?\"\s*:\s*\"?\s*(-?\d+(?:\.\d+)?)\s*(?:degrees|degree|°)?",
        r"\"label\"\s*:\s*\"[^\"]*angle[^\"]*\"[^\\n]*?\"answer\"\s*:\s*\"?\s*(-?\d+(?:\.\d+)?)\s*(?:degrees|degree|°)?",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, response_text, flags=re.IGNORECASE):
            try:
                signals.append(float(match.group(1)))
            except (ValueError, TypeError):
                continue
    return signals


def _has_angle_conflict(response_text: str, tolerance_degrees: float = 3.0) -> bool:
    """Detect major disagreement between angle values emitted by analyzer."""
    signals = _extract_angle_signals(response_text)
    if len(signals) < 2:
        return False
    return (max(signals) - min(signals)) > tolerance_degrees


def _extract_json_block(text: str) -> Optional[dict]:
    """Extract the first ```json ... ``` fenced block from LLM output."""
    import re as _re
    match = _re.search(r"```json\s*\n(.*?)\n```", text, _re.DOTALL)
    if not match:
        match = _re.search(r"```\s*\n(\{.*?\})\s*\n```", text, _re.DOTALL)
    if not match:
        return None
    try:
        parsed = json.loads(match.group(1))
        if isinstance(parsed, dict):
            return parsed
        if isinstance(parsed, list) and len(parsed) == 1 and isinstance(parsed[0], dict):
            return parsed[0]
        logger.debug("JSON block parsed but root type is unsupported: %s", type(parsed).__name__)
        return None
    except (json.JSONDecodeError, ValueError):
        logger.debug("JSON block found but failed to parse")
        return None


def _parse_structured_evidence(
    response_text: str,
    image_url: str,
    image_index: int,
) -> ImageAnalysisData:
    """
    Parse the LLM response into an ImageAnalysisData with structured fields.

    Attempts to extract the JSON evidence block. If parsing fails, falls back
    to the prose-only representation (empty structured fields).
    """
    sanitized_text, removed_noise = _sanitize_response_text(response_text or "")
    base_desc = sanitized_text[:500] if sanitized_text else "Analysis completed"

    parsed = _extract_json_block(sanitized_text) if sanitized_text else None

    # --- Object counts ---
    object_counts: List[ObjectCount] = []
    if parsed and isinstance(parsed.get("object_counts"), list):
        for entry in parsed["object_counts"]:
            if isinstance(entry, dict) and "object_type" in entry:
                try:
                    object_counts.append(ObjectCount(
                        object_type=str(entry["object_type"]),
                        total_count=float(entry.get("total_count", 0)),
                        counting_method="llm_code_execution",
                        confidence=str(entry.get("confidence", "MEDIUM")),
                    ))
                except (ValueError, TypeError):
                    pass

    # --- OCR text ---
    ocr_text: List[str] = []
    if parsed and isinstance(parsed.get("ocr_text"), list):
        ocr_text = [str(t) for t in parsed["ocr_text"] if t]

    # --- Detected numbers ---
    detected_numbers: List[str] = []
    if parsed and isinstance(parsed.get("detected_numbers"), list):
        detected_numbers = [str(n) for n in parsed["detected_numbers"] if n is not None]

    # --- Layout info ---
    layout_info: Optional[LayoutInfo] = None
    if parsed:
        overlap = parsed.get("overlap_detected")
        spacing = parsed.get("spacing_adequate")
        grid = parsed.get("grid_structure")
        if overlap is not None or spacing is not None or grid is not None:
            layout_info = LayoutInfo(
                overlap_detected=overlap if isinstance(overlap, bool) else None,
                spacing_adequate=spacing if isinstance(spacing, bool) else None,
                grid_structure=str(grid) if grid else None,
            )

    # --- Chart features ---
    chart_features: Optional[ChartFeatures] = None
    if parsed:
        has_x = parsed.get("chart_has_x_label")
        has_y = parsed.get("chart_has_y_label")
        has_legend = parsed.get("chart_has_legend")
        labels = parsed.get("chart_labels", [])
        vals = parsed.get("chart_value_annotations", [])
        if any(v is not None for v in [has_x, has_y, has_legend]):
            chart_features = ChartFeatures(
                has_x_axis_label=bool(has_x) if has_x is not None else False,
                has_y_axis_label=bool(has_y) if has_y is not None else False,
                has_legend=has_legend if isinstance(has_legend, bool) else None,
                labels_found=[str(label) for label in labels] if isinstance(labels, list) else [],
                value_annotations_found=[str(v) for v in vals] if isinstance(vals, list) else [],
            )

    # --- Answer text flag ---
    has_answer_text: Optional[bool] = None
    if parsed and parsed.get("has_answer_text") is not None:
        has_answer_text = bool(parsed["has_answer_text"])

    # --- Overall confidence ---
    overall_confidence = "MEDIUM"
    if parsed and isinstance(parsed.get("overall_confidence"), str):
        candidate = parsed["overall_confidence"].strip().upper()
        if candidate in {"HIGH", "MEDIUM", "LOW"}:
            overall_confidence = candidate
    elif sanitized_text:
        # Best-effort extraction from prose output if no explicit JSON field.
        import re as _re
        conf_match = _re.search(
            r"(?:overall\s+confidence|confidence\s+assessment)\s*[:\-]?\s*(HIGH|MEDIUM|LOW)",
            sanitized_text,
            flags=_re.IGNORECASE,
        )
        if conf_match:
            overall_confidence = conf_match.group(1).upper()

    angle_conflict = _has_angle_conflict(sanitized_text)
    limitation_notes: List[str] = []
    if removed_noise:
        limitation_notes.append("execution_noise_removed")
    if angle_conflict:
        limitation_notes.append("inconsistent_angle_measurements_detected")
        overall_confidence = "LOW"

    evidence_available = bool(parsed)
    if evidence_available:
        logger.debug("Structured evidence block parsed successfully for image %d", image_index)
    else:
        logger.debug("No structured evidence block found for image %d; using prose fallback", image_index)
        limitation_notes.append("structured_evidence_extraction_failed_prose_only")

    limitations = "; ".join(limitation_notes)
    return ImageAnalysisData(
        image_url=image_url,
        image_index=image_index,
        overall_description=base_desc,
        image_type="mixed",
        educational_purpose="Educational content analysis",
        object_counts=object_counts,
        shape_classifications=[],
        visual_properties=[],
        ocr_text_found=ocr_text,
        detected_numbers=detected_numbers,
        layout_info=layout_info,
        chart_features=chart_features,
        has_answer_text=has_answer_text,
        overall_confidence=overall_confidence,
        quality_notes=sanitized_text if sanitized_text else "Analysis completed with code execution",
        limitations=limitations,
    )


def _derive_deterministic_visual_properties(context_blocks: List[str]) -> List[VisualProperty]:
    """
    Convert deterministic context text into machine-readable visual properties.

    This avoids brittle downstream parsing of free-form notes.
    """
    properties: List[VisualProperty] = []
    if not context_blocks:
        return properties

    merged_text = "\n".join(context_blocks)

    # Equal-area pair extraction, e.g. "A-C (10), B-D (8)"
    pair_line_match = re.search(
        r"Equal-area pairs from exact SVG line geometry:\s*(.+)",
        merged_text,
        flags=re.IGNORECASE,
    )
    if pair_line_match:
        pairs = []
        for token in pair_line_match.group(1).split(","):
            m = re.search(r"\b([A-D])\s*-\s*([A-D])\b", token.strip(), flags=re.IGNORECASE)
            if m:
                a, b = m.group(1).upper(), m.group(2).upper()
                pairs.append("-".join(sorted((a, b))))
        if pairs:
            properties.append(
                VisualProperty(
                    property_name="deterministic_equal_area_pairs",
                    value=",".join(sorted(set(pairs))),
                    confidence="HIGH",
                )
            )

    # Shape area extraction for A-D panels.
    area_matches = re.findall(
        r"Shape\s+([A-D])\s+area:\s+(\d+)\s+unit squares",
        merged_text,
        flags=re.IGNORECASE,
    )
    if area_matches:
        area_map = {}
        for label, area in area_matches:
            area_map[label.upper()] = area
        serialized = ",".join(f"{k}={area_map[k]}" for k in sorted(area_map.keys()))
        properties.append(
            VisualProperty(
                property_name="deterministic_shape_areas",
                value=serialized,
                confidence="HIGH",
            )
        )

    # Number-line interval extraction for labeled A-D panels.
    interval_matches = re.findall(
        r"Number line\s+([A-D])\s+has\s+(\d+)\s+equal intervals",
        merged_text,
        flags=re.IGNORECASE,
    )
    if interval_matches:
        interval_map = {}
        for label, intervals in interval_matches:
            interval_map[label.upper()] = intervals
        serialized = ",".join(
            f"{k}={interval_map[k]}" for k in sorted(interval_map.keys())
        )
        properties.append(
            VisualProperty(
                property_name="deterministic_number_line_intervals",
                value=serialized,
                confidence="HIGH",
            )
        )

    # Icon-array dimensions.
    icon_match = re.search(
        r"Detected repeated icon grid:\s*(\d+)\s+rows\s*x\s*(\d+)\s+columns\s*=\s*(\d+)\s+icons",
        merged_text,
        flags=re.IGNORECASE,
    )
    if icon_match:
        rows, cols, total = icon_match.group(1), icon_match.group(2), icon_match.group(3)
        properties.append(
            VisualProperty(
                property_name="deterministic_icon_array_dims",
                value=f"rows={rows},cols={cols},total={total}",
                confidence="HIGH",
            )
        )

    # Protractor angle extraction.
    angle_match = re.search(
        r"Measured angle between rays \(minor\):\s*(\d+)\D",
        merged_text,
        flags=re.IGNORECASE,
    )
    if angle_match:
        properties.append(
            VisualProperty(
                property_name="deterministic_protractor_minor_angle_deg",
                value=angle_match.group(1),
                confidence="HIGH",
            )
        )

    return properties


# =============================================================================
# Per-Image Analysis Helper
# =============================================================================

async def _analyze_single_image(
    llm,
    image: LLMImage,
    image_url: str,
    image_index: int,
    local_counts: Optional[Dict[str, int]] = None,
    raster_diagram_context: Optional[str] = None,
) -> ImageAnalysisData:
    """
    Analyze a single image using Gemini Flash with code execution.
    
    Each image gets its own LLM call so the analysis is specific to that image,
    avoiding the duplication problem of sharing a single response across images.
    
    Parameters
    ----------
    llm : LLMInterface
        The LLM instance to use for analysis
    image : LLMImage
        The prepared image (base64 or URL)
    image_url : str
        The cleaned image URL (used for logging and as the stored URL)
    image_index : int
        1-based index of this image in the analysis batch
    local_counts : dict, optional
        Precise 3D object counts from local bright-face preprocessing (injected into prompt)
        
    Returns
    -------
    ImageAnalysisData
        Analysis data specific to this single image
    """
    user_content = ANALYSIS_USER_PROMPT
    if local_counts:
        user_content += (
            "\n\nIMPORTANT — Precise object counts from local image analysis "
            "(trust these over your visual impression):\n"
            + json.dumps(local_counts, indent=2)
        )
    if raster_diagram_context:
        user_content = (
            "CRITICAL CONTEXT - RASTER PROGRAMMATIC DATA (authoritative):\n"
            + raster_diagram_context
            + "\n\n"
            + user_content
        )

    # Inject programmatic SVG coordinate data when the source is an SVG
    svg_coord_context = None
    try:
        svg_text = None
        if image_url.lower().endswith('.svg'):
            resp = requests.get(image_url, timeout=10)
            resp.raise_for_status()
            svg_text = resp.content.decode('utf-8', errors='replace')
        elif image_url.startswith('data:image/svg'):
            if ';base64,' in image_url:
                _, encoded = image_url.split(';base64,', 1)
                svg_text = base64.b64decode(encoded).decode('utf-8', errors='replace')
        if svg_text:
            svg_coord_context = (
                extract_svg_clock_time(svg_text)
                or extract_svg_math_coordinates(svg_text)
                or extract_svg_diagram_context(svg_text)
            )
    except Exception as _svg_exc:
        logger.debug("SVG coordinate extraction skipped for image %d: %s", image_index, _svg_exc)

    if svg_coord_context:
        user_content = "CRITICAL CONTEXT - SVG PROGRAMMATIC DATA (authoritative):\n" + svg_coord_context + "\n\n" + user_content

    # Inject tick interval data for ruler/number-line SVGs
    svg_interval_context = None
    try:
        if svg_text:
            svg_interval_context = extract_svg_tick_intervals(svg_text)
    except Exception as _exc:
        logger.debug("SVG tick interval extraction skipped: %s", _exc)
    if svg_interval_context:
        user_content = "CRITICAL CONTEXT - SVG TICK INTERVAL DATA (authoritative):\n" + svg_interval_context + "\n\n" + user_content

    # Inject fraction model analysis for MCQ shape SVGs
    svg_fraction_context = None
    try:
        if svg_text:
            svg_fraction_context = extract_svg_fraction_model_analysis(svg_text)
    except Exception as _exc:
        logger.debug("SVG fraction model analysis skipped: %s", _exc)
    if svg_fraction_context:
        user_content = "CRITICAL CONTEXT - SVG FRACTION MODEL ANALYSIS (authoritative):\n" + svg_fraction_context + "\n\n" + user_content

    # Inject box-and-whisker five-number summary for box plot SVGs
    svg_boxplot_context = None
    try:
        if svg_text:
            svg_boxplot_context = extract_svg_box_whisker(svg_text)
    except Exception as _exc:
        logger.debug("SVG box-whisker extraction skipped: %s", _exc)
    if svg_boxplot_context:
        user_content = "CRITICAL CONTEXT - SVG BOX PLOT DATA (authoritative):\n" + svg_boxplot_context + "\n\n" + user_content

    try:
        response_text = await llm.generate_with_vision(
            messages=[
                LLMMessage(role="system", content=SYSTEM_PROMPT),
                LLMMessage(role="user", content=user_content),
            ],
            images=[image],
            response_schema=None,  # Text mode — Gemini code-execution requires it
            enable_code_execution=True,
        )
    except Exception as exc:
        logger.warning(
            "Image %d analysis failed: %s. Returning degraded empty analysis for this image.",
            image_index,
            exc,
        )
        response_text = ""

    parsed = _parse_structured_evidence(response_text, image_url, image_index)
    deterministic_blocks: List[str] = []
    if svg_coord_context:
        deterministic_blocks.append(svg_coord_context)
    if svg_interval_context:
        deterministic_blocks.append(svg_interval_context)
    if svg_fraction_context:
        deterministic_blocks.append(svg_fraction_context)
    if svg_boxplot_context:
        deterministic_blocks.append(svg_boxplot_context)
    if raster_diagram_context:
        deterministic_blocks.append(raster_diagram_context)
    if deterministic_blocks:
        deterministic_note = "\n\n".join(dict.fromkeys(deterministic_blocks))
        augmented_notes = (
            "## DETERMINISTIC EXTRACTION CONTEXT\n"
            + deterministic_note
            + "\n\n"
            + parsed.quality_notes
        )
        deterministic_props = _derive_deterministic_visual_properties(deterministic_blocks)
        merged_props = list(parsed.visual_properties)
        seen = {(p.property_name, p.value) for p in merged_props}
        for prop in deterministic_props:
            key = (prop.property_name, prop.value)
            if key not in seen:
                merged_props.append(prop)
                seen.add(key)

        parsed = parsed.model_copy(
            update={
                "quality_notes": augmented_notes,
                "visual_properties": merged_props,
            }
        )
    return parsed


# =============================================================================
# Main Analysis Function
# =============================================================================

@observe(name="analyze_images")
async def analyze_images(image_urls: List[str]) -> ImageAnalysisResult:
    """
    Analyze images using Gemini Flash with code execution (agentic vision).
    
    This unified approach replaces the previous OpenCV + LLM hybrid with a pure
    LLM solution that leverages code execution for precision.
    
    Parameters
    ----------
    image_urls : List[str]
        List of image URLs to analyze
        
    Returns
    -------
    ImageAnalysisResult
        Comprehensive analysis results including counts, classifications, and measurements
    """
    if not image_urls:
        return ImageAnalysisResult(
            success=True,
            image_analyses=[],
            error_message=""
        )
    
    start_time = time.time()
    
    # Clean all URLs first
    cleaned_urls = []
    for image_url in image_urls:
        cleaned_url = _clean_image_url(image_url)
        if cleaned_url != image_url:
            logger.debug(f"Cleaned image URL: {image_url} -> {cleaned_url}")
        cleaned_urls.append(cleaned_url)
    
    # Check cache for each image
    cached_results: Dict[str, ImageAnalysisData] = {}
    uncached_urls: List[str] = []
    uncached_indices: List[int] = []
    
    for i, cleaned_url in enumerate(cleaned_urls):
        cached_result = _cache_get(cleaned_url)
        if cached_result is not None:
            cached_results[cleaned_url] = cached_result
            logger.debug(f"Cache hit for image: {cleaned_url[:60]}...")
        else:
            uncached_urls.append(cleaned_url)
            uncached_indices.append(i)
    
    cache_hits = len(cached_results)
    cache_misses = len(uncached_urls)
    
    if cache_hits > 0:
        logger.info(f"Image analysis cache: {cache_hits} hit(s), {cache_misses} miss(es)")
    
    # If all images are cached, return cached results
    if not uncached_urls:
        logger.info(f"All {cache_hits} image(s) found in cache, skipping LLM call")
        # Build result list in original order
        all_results = []
        for i, cleaned_url in enumerate(cleaned_urls):
            result = cached_results[cleaned_url]
            # Update image_index to match current request order
            result_copy = result.model_copy(update={"image_index": i + 1})
            all_results.append(result_copy)
        
        return ImageAnalysisResult(
            success=True,
            image_analyses=all_results,
            error_message=""
        )
    
    # Process uncached images
    try:
        logger.info(f"Analyzing {len(uncached_urls)} uncached image(s) with Gemini Flash (agentic vision)...")
        
        llm = LLMFactory.create("unified_image_analyzer")
        
        # Download and prepare uncached images with retry logic
        images = []
        local_counts_list: List[Optional[Dict[str, int]]] = []
        raster_context_list: List[Optional[str]] = []
        for i, cleaned_url in enumerate(uncached_urls):
            image_bytes = None
            content_type = 'image/png'
            download_success = False
            attempt_errors: List[AttemptError] = []
            
            # Check if this is a base64 data URL (from SVG conversion)
            if cleaned_url.startswith('data:'):
                try:
                    # Parse data URL format: data:[<mediatype>][;base64],<data>
                    if ';base64,' in cleaned_url:
                        header, encoded = cleaned_url.split(';base64,', 1)
                        content_type = header.split(':', 1)[1] if ':' in header else 'image/png'
                        image_bytes = base64.b64decode(encoded)
                        download_success = True
                        logger.debug(f"Image {i+1}: Decoded base64 data URL ({len(image_bytes)} bytes)")
                    else:
                        logger.warning(f"Image {i+1}: Data URL without base64 encoding, skipping")
                        # Append None to maintain list alignment with uncached_urls
                        images.append(None)
                        local_counts_list.append(None)
                        raster_context_list.append(None)
                        continue
                except Exception as e:
                    logger.error(f"Image {i+1}: Failed to decode data URL: {e}")
                    # Append None to maintain list alignment with uncached_urls
                    images.append(None)
                    local_counts_list.append(None)
                    raster_context_list.append(None)
                    continue
            else:
                # Regular URL - download it
                for attempt in range(IMAGE_DOWNLOAD_MAX_RETRIES + 1):
                    try:
                        await asyncio.sleep(0.2)  # Small delay between requests
                        image_response = requests.get(cleaned_url, timeout=30)
                        image_response.raise_for_status()
                        image_bytes = image_response.content
                        content_type = image_response.headers.get('content-type', 'image/png')
                        download_success = True
                        
                        # Record recovery if this wasn't the first attempt
                        if attempt > 0:
                            FailureTracker.record_recovered(
                                component="unified_image_analyzer.download",
                                message=f"Succeeded on attempt {attempt + 1}/{IMAGE_DOWNLOAD_MAX_RETRIES + 1}",
                                context={"image_index": i + 1, "url": cleaned_url[:100]},
                                attempt_errors=attempt_errors if attempt_errors else None
                            )
                            logger.info(f"Image {i+1} download succeeded on attempt {attempt + 1}")
                        break
                        
                    except Exception as e:
                        attempt_errors.append(AttemptError(
                            attempt=attempt + 1,
                            error_message=str(e)
                        ))
                        
                        if attempt < IMAGE_DOWNLOAD_MAX_RETRIES:
                            delay = IMAGE_DOWNLOAD_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                            logger.warning(
                                f"Image {i+1} download failed (attempt {attempt + 1}/"
                                f"{IMAGE_DOWNLOAD_MAX_RETRIES + 1}): {e}. Retrying in {delay:.1f}s..."
                            )
                            await asyncio.sleep(delay)
                        else:
                            # All retries exhausted
                            logger.error(f"Image {i+1} download failed after all retries: {e}")
                            FailureTracker.record_exhausted(
                                component="unified_image_analyzer.download",
                                error_message=str(e),
                                context={"image_index": i + 1, "url": cleaned_url[:100], "attempts": attempt + 1},
                            attempt_errors=attempt_errors
                        )
            
            if download_success and image_bytes:
                is_svg = 'svg' in content_type or cleaned_url.lower().endswith('.svg')
                if is_svg:
                    svg_text = image_bytes.decode('utf-8', errors='replace')
                    png_bytes = convert_svg_to_png(svg_text)
                    if png_bytes:
                        logger.info(f"Image {i+1}: Converted SVG URL to PNG for analysis")
                        image_bytes = png_bytes
                        content_type = 'image/png'
                    else:
                        logger.warning(f"Image {i+1}: SVG conversion failed, using placeholder")
                        image_bytes = _make_placeholder_png()
                        content_type = 'image/png'

                image_bytes = _resize_image_if_needed(image_bytes)
                image_bytes = _to_webp_lossless(image_bytes)
                content_type = 'image/webp'
                if len(image_bytes) > MAX_INLINE_IMAGE_BYTES:
                    before = len(image_bytes)
                    image_bytes, content_type = _compress_image_for_token_budget(image_bytes)
                    logger.info(
                        f"Image {i+1}: Compressed payload for token budget ({before} -> {len(image_bytes)} bytes)"
                    )

                if len(image_bytes) > MAX_INLINE_IMAGE_BYTES:
                    is_svg_url = 'svg' in content_type or cleaned_url.lower().endswith('.svg')
                    if cleaned_url.startswith("data:") or is_svg_url:
                        logger.warning(
                            f"Image {i+1}: Image still large after compression ({len(image_bytes)} bytes), "
                            "sending best-effort compressed payload inline"
                        )
                    else:
                        logger.warning(
                            f"Image {i+1}: Inline payload still too large ({len(image_bytes)} bytes), using URL fallback"
                        )
                        images.append(LLMImage(url=cleaned_url))
                        local_counts_list.append(None)
                        raster_context_list.append(None)
                        continue

                image_base64 = base64.b64encode(image_bytes).decode("utf-8")
                if 'webp' in content_type:
                    media_type = "image/webp"
                elif 'jpeg' in content_type or 'jpg' in content_type:
                    media_type = "image/jpeg"
                else:
                    media_type = "image/png"
                images.append(LLMImage(
                    base64_data=image_base64,
                    media_type=media_type
                ))
                local_counts_list.append(_local_count_3d_objects_from_bytes(image_bytes))
                raster_context_list.append(extract_raster_diagram_context(image_bytes))
            else:
                # Download failed — URL fallback, but never for SVGs
                is_svg_url = 'svg' in content_type or cleaned_url.lower().endswith('.svg')
                if is_svg_url or cleaned_url.startswith("data:"):
                    logger.warning(f"Image {i+1}: Download failed for SVG/data URL, using placeholder")
                    placeholder = _make_placeholder_png()
                    image_base64 = base64.b64encode(placeholder).decode("utf-8")
                    images.append(LLMImage(base64_data=image_base64, media_type="image/png"))
                else:
                    logger.warning(f"Image {i+1}: Using URL fallback after download failure")
                    images.append(LLMImage(url=cleaned_url))
                local_counts_list.append(None)
                raster_context_list.append(None)

        # Analyze each image individually so every image gets its own
        # dedicated LLM response (avoids duplicating one response across all).
        # Calls are parallelised with asyncio.gather for throughput.
        # Skip None entries (malformed data URLs)
        analysis_tasks = [
            _analyze_single_image(
                llm=llm,
                image=images[i],
                image_url=uncached_urls[i],
                image_index=i + 1,
                local_counts=local_counts_list[i] if i < len(local_counts_list) else None,
                raster_diagram_context=raster_context_list[i] if i < len(raster_context_list) else None,
            )
            for i in range(len(uncached_urls))
            if images[i] is not None  # Skip malformed data URLs
        ]
        image_analyses: List[ImageAnalysisData] = list(
            await asyncio.gather(*analysis_tasks)
        )
        
        logger.info(
            f"Received analysis responses for {len(image_analyses)} image(s)"
        )
        
        tool_result = ImageAnalysisToolResult(image_analyses=image_analyses)
        
        logger.info(
            f"Successfully analyzed {len(tool_result.image_analyses)} image(s) "
            f"in {time.time() - start_time:.2f}s"
        )
        
        # Cache the new results (with LRU eviction if at capacity)
        for result in tool_result.image_analyses:
            # Use the cleaned URL as cache key
            idx = result.image_index - 1  # Convert to 0-based
            if idx < len(uncached_urls):
                cache_key = uncached_urls[idx]
                _cache_set(cache_key, result)
                logger.debug(f"Cached analysis for: {cache_key[:60]}...")
        
        # Merge cached and new results in original order
        new_results_by_url = {
            uncached_urls[r.image_index - 1]: r for r in tool_result.image_analyses
        }
        
        all_results = []
        for i, cleaned_url in enumerate(cleaned_urls):
            if cleaned_url in cached_results:
                result = cached_results[cleaned_url]
            elif cleaned_url in new_results_by_url:
                result = new_results_by_url[cleaned_url]
            else:
                # Shouldn't happen, but handle gracefully
                logger.warning(f"Missing result for image: {cleaned_url[:60]}...")
                continue
            
            # Update image_index to match current request order
            result_copy = result.model_copy(update={"image_index": i + 1})
            all_results.append(result_copy)
        
        return ImageAnalysisResult(
            success=True,
            image_analyses=all_results,
            error_message=""
        )
        
    except Exception as e:
        logger.error(f"Error analyzing images after {time.time() - start_time:.2f}s: {e}")
        return ImageAnalysisResult(
            success=False,
            image_analyses=[],
            error_message=str(e)
        )


# =============================================================================
# Formatting Functions for Prompt Inclusion
# =============================================================================

def format_analysis_for_prompt(analysis_result: ImageAnalysisResult) -> str:
    """
    Format analysis results into a readable string for inclusion in evaluation prompts.
    
    Parameters
    ----------
    analysis_result : ImageAnalysisResult
        The analysis results to format
        
    Returns
    -------
    str
        Formatted string describing the analysis
    """
    if not analysis_result.success:
        return f"\n\nImage Analysis Failed: {analysis_result.error_message}"
    
    if not analysis_result.image_analyses:
        return ""
    
    # Check if any image has structured (programmatic) results
    has_structured = any(
        img.object_counts or img.shape_classifications or img.visual_properties
        for img in analysis_result.image_analyses
    )

    output_parts = ["\n\n## COMPREHENSIVE IMAGE ANALYSIS (Gemini Flash + Code Execution)"]
    if has_structured:
        output_parts.append("\nProgrammatic image analysis with LLM reasoning and code execution.")
        output_parts.append("AUTHORITATIVE FOR: Object counts, shape classifications, measurements, spatial relationships.")
        output_parts.append("Use this data as ground truth for visual content verification.\n")
    else:
        output_parts.append("\nLLM-based visual interpretation (no structured CV data extracted).")
        output_parts.append("IMPORTANT: This analysis reflects the LLM's visual interpretation of the image.")
        output_parts.append("It may contain errors, especially for precise positions, exact numeric readings,")
        output_parts.append("or fine details in complex diagrams (Venn diagrams, nested sets, number line positions).")
        output_parts.append("Do NOT override a mathematically/logically sound answer solely based on this analysis.")
        output_parts.append("If this analysis contradicts the content's answer, consider BOTH possibilities before concluding.\n")
    
    for img_data in analysis_result.image_analyses:
        if len(analysis_result.image_analyses) > 1:
            output_parts.append(f"\n### Image {img_data.image_index}")
        
        output_parts.append(f"**Description**: {img_data.overall_description}")
        output_parts.append(f"**Type**: {img_data.image_type}")
        output_parts.append(f"**Educational Purpose**: {img_data.educational_purpose}")
        output_parts.append(f"**Overall Confidence**: {img_data.overall_confidence}")
        
        # Object counts
        if img_data.object_counts:
            output_parts.append("\n**Object Counts**:")
            for obj_count in img_data.object_counts:
                output_parts.append(f"- **{obj_count.object_type}**: {obj_count.total_count}")
                output_parts.append(f"  - Method: {obj_count.counting_method}")
                output_parts.append(f"  - Confidence: {obj_count.confidence}")
                
                if obj_count.group_breakdown:
                    output_parts.append("  - Group Breakdown:")
                    for group in obj_count.group_breakdown:
                        output_parts.append(f"    * {group.group_identifier}: {group.count}")
                
                if obj_count.notes:
                    output_parts.append(f"  - Notes: {obj_count.notes}")
        
        # Shape classifications
        if img_data.shape_classifications:
            output_parts.append("\n**Shape Classifications**:")
            for shape in img_data.shape_classifications:
                output_parts.append(f"- **{shape.shape_type}** (Confidence: {shape.confidence})")
                output_parts.append(f"  - Evidence: {', '.join(shape.supporting_evidence)}")
                
                if shape.measurements:
                    output_parts.append(f"  - Measurements: {shape.measurements}")
        
        # Visual properties
        if img_data.visual_properties:
            output_parts.append("\n**Visual Properties**:")
            for prop in img_data.visual_properties:
                output_parts.append(f"- {prop.property_name}: {prop.value} (Confidence: {prop.confidence})")
        
        # Quality assessment
        output_parts.append(f"\n**Quality Assessment**: {img_data.quality_notes}")
        if img_data.limitations:
            output_parts.append(f"**Limitations**: {img_data.limitations}")
    
    return "\n".join(output_parts)


def format_evidence_for_prompt(
    analysis_result: ImageAnalysisResult,
    verification_result: Optional["VerificationResult"] = None,
) -> str:
    """
    Format structured evidence + verification checks for the evaluator LLM.

    Sections emitted (in order):
    1. Verified Checks — deterministic pass/fail results (advisory, high-signal)
    2. Tier-0 Advisory Signals — concise scoring guidance from high-confidence checks
    3. Uncertain Observations — things the verifier couldn't confirm (evaluator should investigate)
    4. Structured Evidence Summary — counts, OCR, chart features
    5. Raw Image Description — prose fallback from quality_notes

    Parameters
    ----------
    analysis_result : ImageAnalysisResult
        Structured analysis data from the image analyzer.
    verification_result : VerificationResult, optional
        Outcome of deterministic constraint checks.

    Returns
    -------
    str
        Formatted context string for the system prompt.
    """
    if not analysis_result.success:
        return f"\n\nImage Analysis Failed: {analysis_result.error_message}"

    if not analysis_result.image_analyses:
        return ""

    parts: List[str] = ["\n\n## IMAGE EVIDENCE SUMMARY"]

    # ---- Section 1 & 2: Verification checks ----
    if verification_result and verification_result.checks:
        passed = [c for c in verification_result.checks if c.status == "pass"]
        failed = [c for c in verification_result.checks if c.status == "fail"]
        uncertain = [c for c in verification_result.checks if c.status == "uncertain"]

        parts.append(
            f"\n**Check Summary**: pass={verification_result.passed_count}, "
            f"fail={verification_result.failed_count}, uncertain={verification_result.uncertain_count}"
        )

        if passed or failed:
            parts.append("\n### DETERMINISTIC CROSS-REFERENCE CHECKS")
            for c in passed:
                line = f"- ✓ **{c.check_name}**: PASS"
                if c.observed:
                    line += f" ({c.observed})"
                parts.append(line)
            for c in failed:
                line = f"- ✗ **{c.check_name}**: FAIL"
                if c.expected and c.observed:
                    line += f" — expected {c.expected}, observed {c.observed}"
                elif c.detail:
                    line += f" — {c.detail}"
                parts.append(line)

        if uncertain:
            parts.append("\n### UNCERTAIN OBSERVATIONS (deterministic check unavailable)")
            for c in uncertain:
                line = f"- ? **{c.check_name}**"
                if c.detail:
                    line += f": {c.detail}"
                parts.append(line)

        high_conf = [c for c in verification_result.checks if c.confidence == "high"]
        if high_conf:
            parts.append("\n### TIER-0 ADVISORY SIGNALS (NON-BINDING)")
            parts.append(
                "- Treat high-confidence deterministic checks as strong evidence, "
                "then make final metric decisions using full item context."
            )
            for c in high_conf:
                if c.check_name == "option_key_consistency" and c.status == "pass":
                    parts.append(
                        "- Advisory: keyed-option geometry is consistent; avoid failing "
                        "`factual_accuracy` or `stimulus_quality` unless there is separate "
                        "clear contradiction evidence."
                    )
                elif c.check_name == "option_key_consistency" and c.status == "fail":
                    parts.append(
                        "- Advisory: keyed-option geometry is contradicted; strongly consider "
                        "failing `factual_accuracy`, and fail `stimulus_quality` only when "
                        "the contradiction materially impairs solving the item."
                    )
                elif c.status == "fail":
                    parts.append(
                        f"- Advisory: high-confidence `{c.check_name}` failed; treat as a "
                        "strong risk signal for relevant metrics."
                    )

        if verification_result.auto_reject:
            parts.append(
                "\n**POTENTIAL CRITICAL ISSUE**: A hard-fail gate was triggered with high confidence. "
                "Inspect the image directly before assigning factual penalties."
            )

    # ---- Section 3: Structured evidence per image ----
    for img_data in analysis_result.image_analyses:
        if len(analysis_result.image_analyses) > 1:
            parts.append(f"\n### Image {img_data.image_index}")

        parts.append(f"\n**Description**: {img_data.overall_description}")
        parts.append(f"**Overall Confidence**: {img_data.overall_confidence}")
        if img_data.limitations and (
            "inconsistent_angle_measurements_detected" in img_data.limitations
            or "execution_noise_removed" in img_data.limitations
        ):
            parts.append(
                "**Analyzer Reliability Note**: The analyzer output included conflicting "
                "or noisy signals. Treat angle-specific claims as uncertain unless "
                "independently verified."
            )

        if img_data.object_counts:
            parts.append("\n**Object Counts**:")
            for oc in img_data.object_counts:
                parts.append(f"- {oc.object_type}: {oc.total_count} (confidence: {oc.confidence})")

        if img_data.ocr_text_found:
            parts.append(f"\n**Text Found in Image (OCR)**: {', '.join(img_data.ocr_text_found[:30])}")

        if img_data.detected_numbers:
            parts.append(f"**Numbers Found**: {', '.join(img_data.detected_numbers[:30])}")

        if img_data.layout_info:
            li = img_data.layout_info
            layout_parts = []
            if li.overlap_detected is not None:
                layout_parts.append(f"overlap={'yes' if li.overlap_detected else 'no'}")
            if li.spacing_adequate is not None:
                layout_parts.append(f"spacing={'ok' if li.spacing_adequate else 'poor'}")
            if li.grid_structure:
                layout_parts.append(f"grid={li.grid_structure}")
            if layout_parts:
                parts.append(f"**Layout**: {', '.join(layout_parts)}")

        if img_data.chart_features:
            cf = img_data.chart_features
            chart_parts = []
            chart_parts.append(f"x-axis label={'yes' if cf.has_x_axis_label else 'no'}")
            chart_parts.append(f"y-axis label={'yes' if cf.has_y_axis_label else 'no'}")
            if cf.has_legend is not None:
                chart_parts.append(f"legend={'yes' if cf.has_legend else 'no'}")
            if cf.labels_found:
                chart_parts.append(f"labels: {', '.join(cf.labels_found[:10])}")
            parts.append(f"**Chart Features**: {', '.join(chart_parts)}")

        if img_data.shape_classifications:
            parts.append("\n**Shape Classifications**:")
            for shape in img_data.shape_classifications:
                parts.append(f"- {shape.shape_type} (confidence: {shape.confidence})")

        if img_data.visual_properties:
            parts.append("\n**Visual Properties**:")
            for prop in img_data.visual_properties:
                parts.append(f"- {prop.property_name}: {prop.value} (confidence: {prop.confidence})")

    # ---- Section 4: Raw prose fallback ----
    has_structured = any(
        img.object_counts or img.ocr_text_found or img.detected_numbers
        or img.layout_info or img.chart_features
        for img in analysis_result.image_analyses
    )

    parts.append("\n### RAW ANALYSIS NOTES")
    if not has_structured:
        parts.append(
            "IMPORTANT: No structured evidence was extracted. The notes below "
            "are LLM visual interpretation and may contain errors, especially "
            "for exact counts, positions, or fine details."
        )
        parts.append(
            "Do NOT override a mathematically/logically sound answer solely based on these notes."
        )

    for img_data in analysis_result.image_analyses:
        if len(analysis_result.image_analyses) > 1:
            parts.append(f"\n*Image {img_data.image_index} notes:*")
        notes = img_data.quality_notes
        if len(notes) > 3000:
            notes = notes[:3000] + "\n... (truncated)"
        parts.append(notes)

    return "\n".join(parts)
