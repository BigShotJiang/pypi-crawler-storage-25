"""
Expected visual specification extraction from content and metadata.

Extracts what an image is SUPPOSED to satisfy based on the question text,
answer values, and request metadata. This is entirely non-LLM: rule-based
parsing and pattern matching on the textual content.
"""

import logging
import re
from typing import Any
from typing import List, Optional

from pydantic import BaseModel, Field

from inceptbench.core.input_models import RequestMetadata

logger = logging.getLogger(__name__)


# =============================================================================
# Models
# =============================================================================

class ExpectedCount(BaseModel):
    """An object count that the image is expected to contain."""
    object_type: str = Field(description="Detected object type keyword (e.g., 'apples', 'blocks')")
    count: float = Field(description="Expected count extracted from content")
    source: str = Field(default="content_text", description="Where this expectation came from")


class TextRule(BaseModel):
    """A rule about text that should or should not appear in the image."""
    rule: str = Field(description="Rule identifier (e.g., 'no_answer_leakage', 'no_descriptive_text')")
    detail: str = Field(default="", description="Human-readable explanation")
    forbidden_values: List[str] = Field(
        default_factory=list,
        description="Specific text/number values that must NOT appear in the image"
    )


class ExpectedVisualSpec(BaseModel):
    """
    What an image is expected to satisfy, extracted from content and metadata.

    This is produced by non-LLM rule-based parsing, not by a vision model.
    """
    expected_object_counts: List[ExpectedCount] = Field(default_factory=list)
    layout_constraints: List[str] = Field(default_factory=list)
    text_rules: List[TextRule] = Field(default_factory=list)
    diagram_constraints: List[str] = Field(default_factory=list)
    image_role: str = Field(default="accompaniment")
    detected_diagram_type: Optional[str] = Field(
        default=None,
        description="Detected diagram category: chart, number_line, geometry, venn, counting, other"
    )
    answer_values: List[str] = Field(
        default_factory=list,
        description="Known answer values that should NOT be leaked in the image"
    )
    answer_option_labels: List[str] = Field(
        default_factory=list,
        description="Parsed option-label answers (A-D), e.g., ['A','C'] for MSQ"
    )


# =============================================================================
# Counting-pattern regexes
# =============================================================================

_COUNT_PATTERNS = [
    # "show 24 apples", "draw 12 circles", "display 6 blocks"
    re.compile(
        r"\b(?:show|draw|display|arrange|place|put|render|create|make|has|have|contains?|with)\s+"
        r"(\d+)\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)",
        re.IGNORECASE,
    ),
    # "24 apples", "12 red circles"  (start of sentence or after punctuation)
    re.compile(
        r"(?:^|[.!?;,]\s+)(\d+)\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)",
        re.IGNORECASE | re.MULTILINE,
    ),
    # "groups of 4", "rows of 6"
    re.compile(
        r"\b(?:groups?|rows?|columns?|sets?)\s+of\s+(\d+)\b",
        re.IGNORECASE,
    ),
]

_LAYOUT_PATTERNS = [
    # "4 rows x 6 columns", "3 rows of 5"
    re.compile(r"(\d+)\s*(?:rows?)\s*(?:x|×|by|of)\s*(\d+)\s*(?:columns?)?", re.IGNORECASE),
    # "arranged in a grid", "in a line", "in rows"
    re.compile(r"\b(?:arranged?|organized?|placed?)\s+(?:in\s+)?(?:a\s+)?(grid|line|row|column|circle|array)", re.IGNORECASE),
]

_DIAGRAM_TYPE_KEYWORDS = {
    "number_line": ["number line", "numberline"],
    "chart": ["bar chart", "bar graph", "pie chart", "line graph", "histogram", "pictograph"],
    "venn": ["venn diagram", "venn"],
    "geometry": ["triangle", "rectangle", "square", "circle", "polygon", "angle", "parallel lines", "perpendicular"],
    "counting": ["count", "how many", "counting"],
}

_NOISE_WORDS = {"the", "a", "an", "of", "in", "on", "to", "and", "or", "is", "are", "it", "that", "this", "with"}
_TRAILING_OBJECT_QUALIFIERS = {"arranged", "placed", "shown", "displayed", "drawn", "rendered"}


def _clean_object_type(raw: str) -> Optional[str]:
    """Strip noise words and return a reasonable object-type string, or None."""
    words = raw.strip().lower().split()
    words = [w for w in words if w not in _NOISE_WORDS and len(w) > 1]
    while words and words[-1] in _TRAILING_OBJECT_QUALIFIERS:
        words.pop()
    if not words:
        return None
    result = " ".join(words)
    if len(result) > 40:
        return None
    return result


# =============================================================================
# Main extraction function
# =============================================================================

def extract_visual_spec(
    content: str,
    request_metadata: Optional[RequestMetadata] = None,
) -> ExpectedVisualSpec:
    """
    Extract expected visual constraints from content and metadata.

    This is entirely non-LLM. It parses textual inputs for:
    - numeric requirements ("show 24 apples")
    - layout constraints ("arrange in 4 rows of 6")
    - diagram type hints ("number line", "bar chart")
    - answer values that should not be leaked
    - text rules based on image role
    Sources include content plus selected request_metadata fields
    (currently instructions and structured skills values).

    Parameters
    ----------
    content : str
        The educational content / question text.
    request_metadata : RequestMetadata, optional
        Structured metadata (grade, subject, type, etc.)

    Returns
    -------
    ExpectedVisualSpec
    """
    spec = ExpectedVisualSpec()

    if not content:
        return spec

    def _metadata_text(meta: RequestMetadata) -> str:
        chunks: List[str] = []
        if meta.instructions and isinstance(meta.instructions, str):
            chunks.append(meta.instructions)

        def _walk(value: Any) -> None:
            if value is None:
                return
            if isinstance(value, str):
                chunks.append(value)
                return
            if isinstance(value, (int, float, bool)):
                chunks.append(str(value))
                return
            if isinstance(value, dict):
                for k, v in value.items():
                    chunks.append(str(k))
                    _walk(v)
                return
            if isinstance(value, list):
                for item in value:
                    _walk(item)

        _walk(meta.skills)
        return "\n".join(chunks)

    sources = [content]
    if request_metadata:
        meta_text = _metadata_text(request_metadata).strip()
        if meta_text:
            sources.append(meta_text)
    source_text = "\n".join(sources)

    # -----------------------------------------------------------------
    # 1. Detect diagram type
    # -----------------------------------------------------------------
    source_text_lower = source_text.lower()
    for dtype, keywords in _DIAGRAM_TYPE_KEYWORDS.items():
        if any(kw in source_text_lower for kw in keywords):
            spec.detected_diagram_type = dtype
            break

    # -----------------------------------------------------------------
    # 2. Extract expected counts
    # -----------------------------------------------------------------
    seen_counts: set = set()
    for pattern in _COUNT_PATTERNS:
        for match in pattern.finditer(source_text):
            groups = match.groups()
            if len(groups) >= 2:
                count_str, obj_raw = groups[0], groups[1]
            elif len(groups) == 1:
                count_str = groups[0]
                obj_raw = "objects"
            else:
                continue
            obj_type = _clean_object_type(obj_raw)
            if obj_type is None:
                continue
            try:
                count_val = float(count_str)
            except ValueError:
                continue
            key = (obj_type, count_val)
            if key not in seen_counts:
                seen_counts.add(key)
                spec.expected_object_counts.append(
                    ExpectedCount(object_type=obj_type, count=count_val)
                )

    # -----------------------------------------------------------------
    # 3. Extract layout constraints
    # -----------------------------------------------------------------
    for pattern in _LAYOUT_PATTERNS:
        for match in pattern.finditer(source_text):
            spec.layout_constraints.append(match.group(0).strip())

    # -----------------------------------------------------------------
    # 4. Extract answer values (for leakage detection)
    # -----------------------------------------------------------------
    answer_match = re.search(
        r'"answer"\s*:\s*"([^"]+)"', content, re.IGNORECASE
    )
    if answer_match:
        spec.answer_values.append(answer_match.group(1).strip())

    answer_match_bare = re.search(
        r'\banswer\s*(?:is|=|:)\s*([A-Za-z0-9./]+)', content, re.IGNORECASE
    )
    if answer_match_bare:
        val = answer_match_bare.group(1).strip().rstrip(".")
        if val and val not in spec.answer_values:
            spec.answer_values.append(val)

    if request_metadata and isinstance(request_metadata.skills, dict):
        for key in ("answer", "correct_answer", "correctAnswer", "answer_value", "correctOption"):
            raw = request_metadata.skills.get(key)
            if raw is None:
                continue
            val = str(raw).strip()
            if val and val not in spec.answer_values:
                spec.answer_values.append(val)

    # Extract option-label answer keys from serialized content text.
    # Supports:
    # - "answer": ["A","C"]
    # - "answer": "D"
    # - "accepted_answers": [["A","C"]]
    label_candidates: List[str] = []
    answer_array_match = re.search(
        r'"answer"\s*:\s*\[([^\]]+)\]',
        content,
        flags=re.IGNORECASE,
    )
    if answer_array_match:
        label_candidates.extend(re.findall(r'"\s*([A-Z])\s*"', answer_array_match.group(1).upper()))
    answer_array_single_quote_match = re.search(
        r"'answer'\s*:\s*\[([^\]]+)\]",
        content,
        flags=re.IGNORECASE,
    )
    if answer_array_single_quote_match:
        label_candidates.extend(re.findall(r"'\s*([A-Z])\s*'", answer_array_single_quote_match.group(1).upper()))
    answer_scalar_match = re.search(
        r'"answer"\s*:\s*"([A-Z])"',
        content,
        flags=re.IGNORECASE,
    )
    if answer_scalar_match:
        label_candidates.append(answer_scalar_match.group(1).upper())
    answer_scalar_single_quote_match = re.search(
        r"'answer'\s*:\s*'([A-Z])'",
        content,
        flags=re.IGNORECASE,
    )
    if answer_scalar_single_quote_match:
        label_candidates.append(answer_scalar_single_quote_match.group(1).upper())

    accepted_match = re.search(
        r'"accepted_answers"\s*:\s*\[\s*\[([^\]]+)\]\s*\]',
        content,
        flags=re.IGNORECASE,
    )
    if accepted_match:
        label_candidates.extend(re.findall(r'"\s*([A-Z])\s*"', accepted_match.group(1).upper()))
    accepted_single_quote_match = re.search(
        r"'accepted_answers'\s*:\s*\[\s*\[([^\]]+)\]\s*\]",
        content,
        flags=re.IGNORECASE,
    )
    if accepted_single_quote_match:
        label_candidates.extend(re.findall(r"'\s*([A-Z])\s*'", accepted_single_quote_match.group(1).upper()))

    dedup_labels: List[str] = []
    for lbl in label_candidates:
        if lbl not in dedup_labels:
            dedup_labels.append(lbl)
    if dedup_labels:
        spec.answer_option_labels = dedup_labels

    # -----------------------------------------------------------------
    # 5. Build text rules
    # -----------------------------------------------------------------
    has_question_text = bool(re.search(r'\?', content))
    if has_question_text:
        spec.image_role = "accompaniment"
    else:
        spec.image_role = "standalone"

    spec.text_rules.append(TextRule(
        rule="no_answer_leakage",
        detail="Image must not reveal answers, totals, or derived values students should compute",
        forbidden_values=list(spec.answer_values),
    ))

    if spec.image_role == "standalone":
        spec.text_rules.append(TextRule(
            rule="no_descriptive_text",
            detail="Standalone images should not contain descriptive labels or words",
        ))

    # -----------------------------------------------------------------
    # 6. Diagram-specific constraints
    # NOTE: Only emit constraints with deterministic verifier support.
    # -----------------------------------------------------------------
    if spec.detected_diagram_type == "chart":
        spec.diagram_constraints.append("axis_labels_required")
        spec.diagram_constraints.append("legend_if_multiple_series")

    elif spec.detected_diagram_type == "counting":
        spec.diagram_constraints.append("no_overlap")
        spec.diagram_constraints.append("adequate_spacing")

    return spec
