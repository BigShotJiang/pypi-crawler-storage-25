"""
Client for the incept-curriculum service.

Provides structured curriculum data lookups via the /fetch and /search
endpoints, with grade-to-course mapping, subject normalization, and
JSON-to-text formatting for LLM consumption.
"""

import logging
import time
import asyncio
import random
import re
from typing import Any, Optional

import httpx

from inceptbench.config import settings
from inceptbench.config.constants import (
    CURRICULUM_NAME_TO_ABBREVIATION,
    SUBJECT_NAME_MAPPING,
)

logger = logging.getLogger(__name__)

_MAX_ATTEMPTS = 3
_BASE_DELAY_SECONDS = 2.0
_GRADE_RE = re.compile(
    r"^(?:grade\s+(\d{1,2})(?:st|nd|rd|th)?|(\d{1,2})(?:st|nd|rd|th)?(?:\s+grade)?)$",
    re.IGNORECASE,
)
_LONG_GRADE_COURSE_RE = re.compile(
    r"^(?:grade\s*)?(\d{1,2})(?:st|nd|rd|th)?\s+grade\s*[:\-].+$",
    re.IGNORECASE,
)
_STANDARDIZED_COURSE_VERSION = (1, 7, 0)


class CurriculumAPIError(Exception):
    """Raised when the curriculum API returns an error or is unreachable.

    Carries the upstream HTTP status (when available) and the API-provided
    detail message so callers can surface it verbatim instead of silently
    dropping curriculum context from the evaluation.
    """

    def __init__(self, message: str, status_code: int | None = None, detail: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail or message


def _extract_api_detail(response) -> str:
    """Pull the FastAPI-style ``detail`` field from an error response when
    present, falling back to the raw body."""
    try:
        body = response.json()
    except Exception:
        return response.text or ""
    if isinstance(body, dict) and "detail" in body:
        return str(body["detail"])
    return response.text or ""


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------

def map_curriculum_name(slug: str) -> Optional[str]:
    """Map an InceptBench curriculum slug to the new API abbreviation.

    Normalises spaces/hyphens to underscores so that both ``"common_core"``
    and ``"common core"`` resolve to ``"CC"``.

    Returns None for unknown slugs (caller should skip or warn).
    """
    key = (slug or "").lower().strip().replace(" ", "_").replace("-", "_")
    return CURRICULUM_NAME_TO_ABBREVIATION.get(key)


def map_subject(subject: str) -> Optional[str]:
    """Normalise a subject name to the value expected by the curriculum API."""
    if not subject:
        return None
    key = subject.strip().lower()
    return SUBJECT_NAME_MAPPING.get(key, subject.strip())


def normalize_grade_key(grade: Optional[str]) -> Optional[str]:
    """Normalise user grade input to the curriculum's canonical grade key."""
    if not grade:
        return None

    g = " ".join(str(grade).strip().split())
    key = g.lower()
    if key in {"k", "kindergarten", "grade k"}:
        return "K"

    match = _GRADE_RE.match(g) or _LONG_GRADE_COURSE_RE.match(g)
    if not match:
        return None

    grade_number = next((group for group in match.groups() if group), None)
    if not grade_number:
        return None

    n = int(grade_number)
    if n < 1 or n > 12:
        return None
    return str(n)


def _ordinal_grade_course(grade_key: str) -> Optional[str]:
    if grade_key == "K":
        return "Kindergarten"

    try:
        n = int(grade_key)
    except ValueError:
        return None

    if n < 1 or n > 12:
        return None

    suffix = "th"
    if n % 100 not in (11, 12, 13):
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix} Grade"


def map_grade_to_course(grade: Optional[str]) -> Optional[str]:
    """Convert a grade string to its pre-1.7 Common Core course name.

    Examples:
        "3"  -> "3rd Grade"
        "K"  -> "Kindergarten"
        "11" -> "11th Grade"
    """
    grade_key = normalize_grade_key(grade)
    if not grade_key:
        return None
    return _ordinal_grade_course(grade_key)


def _grade_range(*grades: str) -> set[str]:
    return set(grades)


_STANDARDIZED_CC_COURSES_BY_SUBJECT: dict[str, set[str]] = {
    "American History": _grade_range("K", "1", "2", "3", "4", "5", "6", "7"),
    "Language": _grade_range("K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"),
    "Math": _grade_range("1", "2", "3", "4", "5", "6", "7", "8"),
    "Music": _grade_range("K", "1", "2", "3", "4", "5", "6", "7", "8"),
    "Reading": _grade_range("2", "3", "4", "5", "6", "7"),
    "Science": _grade_range("K", "1", "2", "3", "4", "5", "6", "7", "8"),
    "Social Studies": _grade_range("K", "1", "2", "3", "4", "5", "6", "7", "8"),
    "Visual Arts": _grade_range("K", "1", "2", "3", "4", "5", "6", "7", "8"),
    "World History": _grade_range("K", "1", "2", "3", "4", "5", "6", "8"),
}

_STANDARDIZED_ATHENA_CC_COURSES_BY_SUBJECT: dict[str, set[str]] = {
    "Math": _grade_range("1", "2", "3", "4", "5", "6", "7", "8"),
}

_CC_OLD_COURSES_BY_SUBJECT: dict[str, dict[str, str]] = {
    "American History": {
        grade: f"CK Grade {grade} American History" for grade in ("K", "1", "2", "3", "4", "5", "6", "7")
    },
    "Language": {
        "K": "Kindergarten",
        **{grade: _ordinal_grade_course(grade) for grade in map(str, range(1, 13))},
    },
    "Math": {grade: _ordinal_grade_course(grade) for grade in map(str, range(1, 9))},
    "Music": {
        grade: f"CK Grade {grade} Music" for grade in ("K", "1", "2", "3", "4", "5", "6", "7", "8")
    },
    "Reading": {grade: _ordinal_grade_course(grade) for grade in map(str, range(2, 8))},
    "Science": {
        "K": "Kindergarten",
        **{grade: _ordinal_grade_course(grade) for grade in map(str, range(1, 9))},
    },
    "Social Studies": {
        "5": "5th Grade: US History (1491-1850)",
        "6": "6th Grade: Ancient World History",
        "7": "7th Grade: Medieval & Early Modern World History",
        "8": "8th Grade: US History (1787-1898)",
    },
    "Visual Arts": {
        grade: f"CK Grade {grade} Visual Arts" for grade in ("K", "1", "2", "3", "4", "5", "6", "7", "8")
    },
    "World History": {
        grade: f"CK Grade {grade} World History" for grade in ("K", "1", "2", "3", "4", "5", "6", "8")
    },
}

_ATHENA_CC_OLD_COURSES_BY_SUBJECT: dict[str, dict[str, str]] = {
    "Math": {grade: _ordinal_grade_course(grade) for grade in map(str, range(1, 9))},
}

_TEKS_COURSES_BY_SUBJECT: dict[str, dict[str, str]] = {
    "Math": {
        "3": "3rd Grade TEKS",
        "4": "4th Grade TEKS",
        "5": "5th Grade TEKS",
        "6": "6th Grade TEKS",
        "7": "7th Grade",
        "8": "8th Grade TEKS",
    },
}


def _canonical_curriculum_key(curriculum: str) -> str:
    key = (curriculum or "").strip().lower().replace("_", "-").replace(" ", "-")
    if key in {"cc", "common-core"}:
        return "CC"
    if key in {"athena-cc", "athena-common-core"}:
        return "ATHENA-CC"
    if key == "teks":
        return "TEKS"
    return (curriculum or "").strip()


def _parse_version(version: Optional[str]) -> Optional[tuple[int, int, int]]:
    if not version:
        return None

    match = re.search(r"v?(\d+)(?:\.(\d+))?(?:\.(\d+))?", version.strip(), re.IGNORECASE)
    if not match:
        return None

    major = int(match.group(1))
    minor = int(match.group(2) or 0)
    patch = int(match.group(3) or 0)
    return (major, minor, patch)


def _uses_standardized_cc_courses(version: Optional[str]) -> bool:
    """Return True when the curriculum version uses 1.7.0+ course names.

    Omitted or unparsable versions are treated as latest, matching the live
    curriculum API's default-version behavior.
    """
    parsed = _parse_version(version)
    if parsed is None:
        return True
    return parsed >= _STANDARDIZED_COURSE_VERSION


def _lookup_known_subject_course(
    subject: Optional[str],
    grade_key: str,
    courses_by_subject: dict[str, dict[str, str]],
) -> Optional[str]:
    if subject:
        subject_courses = courses_by_subject.get(subject)
        if subject_courses is not None:
            return subject_courses.get(grade_key)
        return None

    if len(courses_by_subject) == 1:
        return next(iter(courses_by_subject.values())).get(grade_key)

    return _ordinal_grade_course(grade_key)


def _lookup_standardized_course(
    subject: Optional[str],
    grade_key: str,
    grades_by_subject: dict[str, set[str]],
) -> Optional[str]:
    if subject:
        subject_grades = grades_by_subject.get(subject)
        if subject_grades is not None:
            return grade_key if grade_key in subject_grades else None
        return None

    if len(grades_by_subject) == 1:
        return grade_key if grade_key in next(iter(grades_by_subject.values())) else None

    return grade_key


def resolve_course_for_curriculum(
    grade: Optional[str],
    curriculum: str,
    subject: Optional[str] = None,
    curriculum_version: Optional[str] = None,
) -> Optional[str]:
    """Resolve user grade input to the course name for a curriculum version."""
    grade_key = normalize_grade_key(grade)
    if not grade_key:
        return None

    curriculum_key = _canonical_curriculum_key(curriculum)
    mapped_subject = map_subject(subject) if subject else None

    if curriculum_key == "CC":
        if _uses_standardized_cc_courses(curriculum_version):
            return _lookup_standardized_course(
                mapped_subject,
                grade_key,
                _STANDARDIZED_CC_COURSES_BY_SUBJECT,
            )
        return _lookup_known_subject_course(
            mapped_subject,
            grade_key,
            _CC_OLD_COURSES_BY_SUBJECT,
        )

    if curriculum_key == "ATHENA-CC":
        if _uses_standardized_cc_courses(curriculum_version):
            return _lookup_standardized_course(
                mapped_subject,
                grade_key,
                _STANDARDIZED_ATHENA_CC_COURSES_BY_SUBJECT,
            )
        return _lookup_known_subject_course(
            mapped_subject,
            grade_key,
            _ATHENA_CC_OLD_COURSES_BY_SUBJECT,
        )

    if curriculum_key == "TEKS":
        return _lookup_known_subject_course(
            mapped_subject,
            grade_key,
            _TEKS_COURSES_BY_SUBJECT,
        )

    return None


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _is_retriable(status_code: int) -> bool:
    return status_code in (408, 429) or 500 <= status_code <= 599


def _headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    if settings.INCEPT_CURRICULUM_API_KEY:
        headers["X-API-Key"] = settings.INCEPT_CURRICULUM_API_KEY
    return headers


def _base_url() -> str:
    return settings.INCEPT_CURRICULUM_API_URL.rstrip("/")


async def _post(path: str, payload: dict, version: Optional[str] = None) -> dict:
    """POST to the curriculum service with retries and exponential backoff.

    Raises ``CurriculumAPIError`` on a non-retriable HTTP error or after
    retry exhaustion so callers fail loudly instead of returning empty
    curriculum context.
    """
    url = f"{_base_url()}{path}"
    if version:
        url = f"{url}?version={version}"

    start = time.time()
    last_error: Optional[CurriculumAPIError] = None

    for attempt in range(_MAX_ATTEMPTS):
        try:
            async with httpx.AsyncClient(timeout=settings.CURRICULUM_SEARCH_TIMEOUT) as client:
                resp = await client.post(url, json=payload, headers=_headers())
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            code = exc.response.status_code
            detail = _extract_api_detail(exc.response)
            err = CurriculumAPIError(
                f"Curriculum API {path} returned {code}: {detail}",
                status_code=code,
                detail=detail,
            )
            if not _is_retriable(code):
                logger.error(
                    "Curriculum API %s returned %s after %.2fs: %s",
                    path, code, time.time() - start, detail,
                )
                raise err
            last_error = err
            if attempt == _MAX_ATTEMPTS - 1:
                logger.error(
                    "Curriculum API %s returned %s after %.2fs (retries exhausted): %s",
                    path, code, time.time() - start, detail,
                )
                raise err
        except Exception as exc:
            last_error = CurriculumAPIError(
                f"Curriculum API {path} request failed: {exc}",
                status_code=None,
                detail=str(exc),
            )
            if attempt == _MAX_ATTEMPTS - 1:
                logger.warning(
                    "Curriculum API %s failed after %.2fs: %s",
                    path, time.time() - start, exc,
                )
                raise last_error

        delay = _BASE_DELAY_SECONDS * (2 ** attempt) + random.uniform(0, 1)
        logger.warning(
            "Curriculum API attempt %d/%d for %s failed; retrying in %.1fs",
            attempt + 1, _MAX_ATTEMPTS, path, delay,
        )
        await asyncio.sleep(delay)

    # Unreachable: every loop iteration either returns or raises.
    raise last_error or CurriculumAPIError(f"Curriculum API {path} failed")


# ---------------------------------------------------------------------------
# Public fetch / search
# ---------------------------------------------------------------------------

async def fetch_curriculum(
    item_id: str,
    curriculum: str,
    subject: Optional[str] = None,
    course: Optional[str] = None,
    version: Optional[str] = None,
) -> Optional[dict]:
    """Fetch a curriculum item by exact ID with ancestry filtering.

    Tries with course in ancestry first.  If that yields no results,
    retries without course (broader search).
    """
    mapped_subject = map_subject(subject)

    ancestry: dict[str, Any] = {"curriculum": curriculum}
    if mapped_subject:
        ancestry["subject"] = mapped_subject
    if course:
        ancestry["course"] = course

    payload = {
        "item_id": item_id,
        "target_level": "leaf",
        "ancestry": ancestry,
    }

    data = await _post("/fetch", payload, version=version)

    # If we got results, return
    if data and data.get("count", 0) > 0:
        return data

    # Fallback: drop course and retry (only if we had a course)
    if course:
        logger.info(
            "Curriculum fetch with course=%s returned 0 results; retrying without course",
            course,
        )
        ancestry.pop("course", None)
        payload["ancestry"] = ancestry
        data = await _post("/fetch", payload, version=version)
        if data and data.get("count", 0) > 0:
            return data

    return None


async def search_curriculum(
    search_key: str,
    curriculum: str,
    subject: Optional[str] = None,
    course: Optional[str] = None,
    version: Optional[str] = None,
) -> Optional[dict]:
    """Search curriculum items by substring with ancestry filtering.

    Same course-fallback strategy as fetch_curriculum.
    """
    mapped_subject = map_subject(subject)

    ancestry: dict[str, Any] = {"curriculum": curriculum}
    if mapped_subject:
        ancestry["subject"] = mapped_subject
    if course:
        ancestry["course"] = course

    payload = {
        "search_key": search_key,
        "target_level": "leaf",
        "ancestry": ancestry,
    }

    data = await _post("/search", payload, version=version)

    if data and data.get("count", 0) > 0:
        return data

    if course:
        logger.info(
            "Curriculum search with course=%s returned 0 results; retrying without course",
            course,
        )
        ancestry.pop("course", None)
        payload["ancestry"] = ancestry
        data = await _post("/search", payload, version=version)
        if data and data.get("count", 0) > 0:
            return data

    return None


# ---------------------------------------------------------------------------
# JSON -> LLM-readable text formatting
# ---------------------------------------------------------------------------

def format_curriculum_for_llm(api_response: dict) -> str:
    """Convert a /fetch or /search API response into readable text for the LLM.

    Takes the **first** result when multiple are returned.
    """
    results = api_response.get("results")
    if not results:
        return ""

    item_data = results[0]
    return _format_single_result(item_data)


def _format_single_result(result: dict) -> str:
    """Format one result entry into LLM-readable curriculum context."""
    lines: list[str] = []
    ancestry = result.get("ancestry", {})
    item = result.get("item", {})
    item_level = result.get("item_level", "")

    # --- Hierarchy context ---
    subject_name = (ancestry.get("subject") or {}).get("name")
    if subject_name:
        lines.append(f"Subject: {subject_name}")

    course_name = (ancestry.get("course") or {}).get("name")
    if course_name:
        lines.append(f"Course: {course_name}")

    domain = ancestry.get("domain")
    if domain:
        lines.append(f"Domain: {domain.get('domain_name', '')}")

    cluster = ancestry.get("cluster")
    if cluster:
        lines.append(f"Cluster: {cluster.get('cluster_name', '')}")

    # --- Standard / Substandard identity ---
    if item_level == "substandard":
        # Show parent standard from ancestry
        parent_std = ancestry.get("standard")
        if parent_std:
            parent_id = parent_std.get("standard_id", "")
            parent_desc = parent_std.get("standard_description", "")
            if parent_id:
                lines.append(f"Parent Standard ID: {parent_id}")
            if parent_desc:
                lines.append(f"Parent Standard Description: {parent_desc}")
        lines.append(f"Substandard ID: {item.get('substandard_id', '')}")
        lines.append(f"Substandard Description: {item.get('substandard_description', '')}")
    else:
        # Leaf standard (or other level)
        sid = item.get("standard_id", "")
        sdesc = item.get("standard_description", "")
        if sid:
            lines.append(f"Standard ID: {sid}")
        if sdesc:
            lines.append(f"Standard Description: {sdesc}")

    # --- Attributes ---
    attributes = item.get("attributes") or {}
    if not attributes:
        return "\n".join(lines)

    lines.append("")  # blank separator

    lesson = attributes.get("lesson_name")
    if lesson:
        lines.append(f"Lesson Name: {lesson}")

    # Key Concepts
    lines.append("")
    key_concepts = attributes.get("key_concepts")
    lines.append("Key Concepts:")
    if key_concepts:
        for kc in key_concepts:
            lines.append(f"* {kc}")
    else:
        lines.append("*None specified*")

    # Learning Objectives
    lines.append("")
    objectives = attributes.get("learning_objectives")
    lines.append("Learning Objectives:")
    if objectives:
        for obj in objectives:
            lines.append(f"* {obj}")
    else:
        lines.append("*None specified*")

    # Assessment Boundaries
    lines.append("")
    boundaries = attributes.get("assessment_boundaries")
    lines.append("Assessment Boundaries:")
    if boundaries:
        for ab in boundaries:
            lines.append(f"* {ab}")
    else:
        lines.append("*None specified*")

    # Common Misconceptions
    lines.append("")
    misconceptions = attributes.get("common_misconceptions")
    lines.append("Common Misconceptions:")
    if misconceptions:
        for cm in misconceptions:
            lines.append(f"* {cm}")
    else:
        lines.append("*None specified*")

    # Difficulty Definitions
    lines.append("")
    diff_defs = attributes.get("difficulty_definitions") or {}
    lines.append("Difficulty Definitions:")
    for level in ("easy", "medium", "hard"):
        val = diff_defs.get(level)
        if val:
            lines.append(f"* {level.capitalize()}:\n  {val}")
        else:
            lines.append(f"* {level.capitalize()}:\n  <unspecified>")

    return "\n".join(lines)
