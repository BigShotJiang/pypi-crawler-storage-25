"""
Hybrid detector for visual-reference/stimulus mismatches.

This module detects when question text references an illustration/diagram/image
but no actual visual stimulus is provided. It uses:

1) Regex fast-pass (free, low latency)
2) LLM fallback extraction (only when regex is inconclusive)
3) Deterministic stimulus-presence checks
"""

import asyncio
import json
import logging
import random
import re
from pathlib import Path
from typing import Any, Literal, Optional

from inceptbench.llm.base import LLMMessage
from inceptbench.llm.factory import LLMFactory
from inceptbench.models.stimulus_reference import (
    PromiseMedium,
    StimulusPromise,
    StimulusPromiseExtraction,
    StimulusReferenceExtraction,
    StimulusReferenceResult,
    UnsatisfiedPromise,
)
from inceptbench.observability import observe
from inceptbench.tools.audio_utils import extract_audio_data_uris, extract_audio_urls
from inceptbench.tools.image_utils import extract_image_urls, extract_svg_content
from inceptbench.tools.video_utils import extract_video_urls
from inceptbench.utils.failure_tracker import AttemptError, FailureTracker

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
BASE_DELAY = 4.0

# Only unambiguously visual media types. Words like "map", "table", "model",
# "diagram", "visual", "representation" are excluded here because they frequently
# appear as concept words in ELA answer options ("A map showing migration routes")
# or inside story/passage text ("According to the map, the cave was...") without
# requiring an actual image to be present.  They are re-introduced only in the
# stricter _DIRECTIVE_VISUAL_NOUNS set below when paired with explicit directive
# language.
_STRICT_VISUAL_NOUNS = (
    r"image|figure|picture|illustration|photograph|photo|drawing|graphic|"
    r"number\s+line|coordinate\s+(?:plane|grid)|grid"
)

# Broader set used ONLY with mandatory spatial/directive qualifiers
# (e.g., "the diagram below", "use the chart provided").
_DIRECTIVE_VISUAL_NOUNS = (
    r"image|diagram|figure|chart|table|picture|illustration|graph|map|drawing|"
    r"photograph|photo|graphic|visual|number\s+line|coordinate\s+(?:plane|grid)|grid"
)

_REFERENCE_PATTERNS = [
    # "look at the image/diagram/..." — explicit directive to view something
    re.compile(
        rf"\blook\s+at\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\b"
        rf"(?:\s+(?:below|above|provided|shown|given|following|here))?",
        re.IGNORECASE,
    ),
    # "examine/observe/study/consider the image/figure/..." — explicit directive verbs
    re.compile(
        rf"\b(?:examine|observe)\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\b"
        rf"(?:\s+(?:below|above|provided|shown|given|following|here))?",
        re.IGNORECASE,
    ),
    # "use the chart/graph/map provided/below" — requires positional or availability qualifier
    re.compile(
        rf"\b(?:refer\s+to|use)\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\b"
        rf"\s+(?:below|above|provided|shown|given|following|here)\b",
        re.IGNORECASE,
    ),
    # "shown/depicted/displayed in the figure/diagram/..."
    re.compile(
        rf"\b(?:shown|depicted|displayed)\s+in\s+"
        rf"(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\b",
        re.IGNORECASE,
    ),
    # "in/on the diagram/chart/graph below/above/provided"
    # Requires spatial qualifier so "in the map" inside a passage doesn't trigger.
    re.compile(
        rf"\b(?:in|on)\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\s+"
        rf"(?:below|above|provided|shown|given|following|here)\b",
        re.IGNORECASE,
    ),
    # "the image/figure/picture below/above/provided" — strict visual nouns with spatial qualifier
    re.compile(
        rf"\b(?:the\s+)?(?:{_STRICT_VISUAL_NOUNS})\s+"
        rf"(?:below|above|provided|shown|displayed|given|following|here)\b",
        re.IGNORECASE,
    ),
    # "the diagram/chart/graph below/above/provided" — directive nouns MUST have spatial qualifier
    re.compile(
        rf"\b(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\s+"
        rf"(?:below|above|provided|shown|displayed|given|following|here)\b",
        re.IGNORECASE,
    ),
    # "as shown/seen/depicted/illustrated" — only flag when followed by a
    # spatial/positional indicator or a visual noun, NOT historical comparisons
    # like "as seen under the British monarchy" or "as seen during the Civil War".
    re.compile(
        rf"\bas\s+(?:shown|seen|depicted|illustrated)\s+"
        rf"(?:in\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS})\b"  # "as seen in the diagram"
        rf"|(?:below|above|here|on\s+(?:the\s+)?(?:{_DIRECTIVE_VISUAL_NOUNS}))\b)",  # "as shown below"
        re.IGNORECASE,
    ),
]

# Inline text stimulus patterns: these indicate a text-based stimulus is embedded
# directly in the question (glossary, dictionary entry, passage, poem, etc.).
# When these match, the "stimulus" is present as text — no image is required.
_INLINE_TEXT_STIMULUS_PATTERNS = [
    re.compile(
        r"\bread\s+(?:the\s+)?(?:following\s+)?"
        r"(?:dictionary\s+entry|glossary|passage|paragraph|poem|excerpt|"
        r"sentence|sentences|story|article|text|script|play\s+script|"
        r"index|table\s+of\s+contents|thesaurus\s+entry|entry|definition|"
        r"announcement|letter|diary|journal|speech|transcript)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:the\s+)?(?:dictionary\s+entry|thesaurus\s+entry|glossary|index|"
        r"play\s+script|passage|poem|excerpt|sentence|story|article)\s+"
        r"(?:below|above|provided|shown|following|here)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bbased\s+on\s+(?:the\s+)?(?:dictionary\s+entry|thesaurus\s+entry|"
        r"glossary|index|passage|poem|excerpt|sentence|story|article|entry|"
        r"play\s+script|text|script)\b",
        re.IGNORECASE,
    ),
    # "Complete the table", "Fill in the table", "Use the table below" —
    # these indicate an HTML/text table is embedded inline in the question.
    re.compile(
        r"\b(?:complete|fill\s+in|fill\s+out|use)\s+(?:the\s+)?table\b",
        re.IGNORECASE,
    ),
    # "the table below", "the data table below", "the following table" —
    # used when a Markdown/text table is present inline in the question stem
    # or inside a blockquote.  The table data IS the stimulus; no image needed.
    re.compile(
        r"\b(?:the\s+)?(?:\w+\s+)?table\s+(?:below|above|provided|shown|following|here)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bthe\s+following\s+(?:\w+\s+)?table\b",
        re.IGNORECASE,
    ),
    # "the data below", "the information below", "the following data/information" —
    # generic data-as-text stimulus phrases common in science/math questions.
    re.compile(
        r"\b(?:the\s+)?(?:data|information|observations?|results?|records?)"
        r"\s+(?:below|above|provided|shown|following|here)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bthe\s+following\s+(?:data|information|observations?|results?|records?)\b",
        re.IGNORECASE,
    ),
    # "Look at the array / equation / expression below" — LaTeX/math inline stimuli
    re.compile(
        r"\blook\s+at\s+(?:the\s+)?(?:array|equation|expression|formula|"
        r"number\s+sentence|calculation|problem)\s+(?:below|above|provided|shown|following|here)\b",
        re.IGNORECASE,
    ),
    # "Use the equation/expression/formula below"
    re.compile(
        r"\b(?:use|refer\s+to)\s+(?:the\s+)?(?:equation|expression|formula|"
        r"number\s+sentence|calculation)\s+(?:below|above|provided|shown|following|here)\b",
        re.IGNORECASE,
    ),
]

_STUDENT_FACING_KEYS = {
    "question",
    "stem",
    "prompt",
    "content",
    "text",
    "body",
    "passage",
    "scenario",
    "title",
    "instruction",
    "instructions",
    "options",
    "answer_options",
    "choices",
}

_METADATA_KEYWORDS = {
    "answer_information",
    "correct_answer",
    "answer_key",
    "answer_explanation",
    "solution",
    "explanation",
    "teacher_notes",
    "rubric",
    "feedback",
    "insight",
    "hint",
    "help",
    "rationale",
    "suggested_improvements",
    "internal_reasoning",
    "reasoning",
    "metadata",
}

_STIMULUS_KEY_PATTERN = re.compile(
    r"(?:^|_)(?:image|figure|diagram|chart|graph|visual|stimulus|media)(?:_url|_urls|url|urls)?$",
    re.IGNORECASE,
)

# HTML tags that constitute a renderable stimulus embedded in question text.
# <table> covers "Complete the table" cases; <figure>, <canvas>, <math> cover
# other embedded visual/interactive content.
_HTML_STIMULUS_TAGS = re.compile(
    r"<\s*(?:table|figure|canvas|math|svg|iframe|video|audio|img)\b",
    re.IGNORECASE,
)

# Markdown inline stimulus patterns — any of these signals that the data the
# student needs IS present as inline formatted text, so no separate image/visual
# asset is required.
#
# Covered constructs:
#   - Pipe tables:      | col | col |   (plain or blockquote-prefixed "> | col |")
#   - Fenced code blocks: ``` ... ```  or  ~~~ ... ~~~  (data/code presented inline)
#   - Multi-line blockquotes: two or more consecutive "> " lines (structured data
#     presented in a block-quote, e.g. the pendulum-table questions).  A single
#     "> " line is intentionally excluded — that is just a pull-quote or hint.
# Require at least two pipe-delimited columns so single-pipe math expressions
# like |x| or |5 - 3| are not misidentified as tables.
_MARKDOWN_TABLE_PATTERN = re.compile(
    r"(?:^|(?<=\n))\s*>?\s*\|[^|\n]+\|[^|\n]*\|",
    re.MULTILINE,
)

_MARKDOWN_FENCED_CODE_PATTERN = re.compile(
    r"(?:^|(?<=\n))\s*(?:```|~~~).+?(?:```|~~~)",
    re.MULTILINE | re.DOTALL,
)

# Two or more consecutive blockquote lines indicate structured data, not a
# single decorative quote.  We require at least two "> …" lines in a row.
_MARKDOWN_MULTILINE_BLOCKQUOTE_PATTERN = re.compile(
    r"(?:^|(?<=\n))\s*>[ \t]*.+\n\s*>[ \t]*.+",
    re.MULTILINE,
)

# Single blockquote-line capture used to gate "is this a passage?" — short
# decorative quotes ("> Be brave!") are excluded by the word-count threshold
# in _has_substantial_blockquote.
_BLOCKQUOTE_LINE_PATTERN = re.compile(
    r"(?:^|(?<=\n))\s*>[ \t]+(.+)",
    re.MULTILINE,
)
_BLOCKQUOTE_PASSAGE_MIN_WORDS = 10

# LaTeX blocks that constitute a renderable visual stimulus.
# Covers display math (\[...\], $$...$$), named environments (array, matrix,
# pmatrix, bmatrix, tabular, tikzpicture, etc.) that produce visible output
# the student is expected to look at.
_LATEX_STIMULUS_PATTERN = re.compile(
    r"(?:"
    r"\\\[|"                                   # \[ display math open
    r"\$\$|"                                   # $$ display math
    r"\\begin\s*\{"
    r"(?:array|matrix|pmatrix|bmatrix|vmatrix|"
    r"Bmatrix|smallmatrix|cases|tabular|"
    r"tikzpicture|equation\*?|align\*?|"
    r"gather\*?|multline\*?|eqnarray\*?)"
    r"\})",
    re.IGNORECASE,
)


def _load_extraction_prompt() -> str:
    """Load the (legacy) stimulus reference extraction prompt from file."""
    prompt_path = (
        Path(__file__).parent.parent / "prompts" / "stimulus_reference_extraction.txt"
    )
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def _load_promise_extraction_prompt() -> str:
    """Load the structured promise-extraction prompt from file."""
    prompt_path = (
        Path(__file__).parent.parent / "prompts" / "stimulus_promise_extraction.txt"
    )
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def _normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _parse_possible_json(content: str) -> Optional[Any]:
    """Parse JSON when content is JSON-encoded text, else return None."""
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, (dict, list)) else None


def _collect_student_facing_strings(obj: Any, parent_key: Optional[str] = None) -> list[str]:
    """Collect likely student-facing strings from structured content."""
    collected: list[str] = []

    if isinstance(obj, str):
        text = _normalize_whitespace(obj)
        if text:
            collected.append(text)
        return collected

    if isinstance(obj, list):
        for item in obj:
            collected.extend(_collect_student_facing_strings(item, parent_key=parent_key))
        return collected

    if isinstance(obj, dict):
        for key, value in obj.items():
            key_norm = str(key).strip().lower()
            if key_norm in _METADATA_KEYWORDS:
                continue

            # Known student-facing keys are always included.
            if key_norm in _STUDENT_FACING_KEYS:
                collected.extend(_collect_student_facing_strings(value, parent_key=key_norm))
                continue

            # Unknown keys: recurse only through containers to discover nested
            # student-facing blocks, but avoid treating arbitrary metadata
            # leaf strings as student-facing.
            if isinstance(value, (dict, list)):
                collected.extend(_collect_student_facing_strings(value, parent_key=key_norm))

    return collected


def _get_student_facing_text(content: str) -> str:
    """Return normalized student-facing text for reference detection."""
    parsed = _parse_possible_json(content)
    if parsed is None:
        return _normalize_whitespace(content)

    strings = _collect_student_facing_strings(parsed)
    if not strings:
        return _normalize_whitespace(content)

    return "\n".join(strings)


def _extract_visual_references_regex(text: str) -> list[str]:
    """Extract candidate visual-reference phrases via regex patterns."""
    if not text:
        return []

    references: list[str] = []
    seen: set[str] = set()

    for pattern in _REFERENCE_PATTERNS:
        for match in pattern.finditer(text):
            phrase = _normalize_whitespace(match.group(0))
            if not phrase:
                continue
            phrase_key = phrase.lower()
            if phrase_key in seen:
                continue
            seen.add(phrase_key)
            references.append(phrase)

    return references


def _filter_llm_visual_references(references: list[str]) -> list[str]:
    """
    Keep only LLM fallback references that actually name a visual stimulus.

    The fallback model occasionally returns answer keys or option labels (for
    example "B", "D") as references. Those are not visual-reference phrases and
    must not create a missing-stimulus failure.
    """
    filtered: list[str] = []
    visual_noun_pattern = re.compile(rf"\b(?:{_DIRECTIVE_VISUAL_NOUNS})\b", re.IGNORECASE)
    positional_visual_pattern = re.compile(
        r"\bas\s+(?:shown|seen|depicted|illustrated)\s+(?:below|above|here)\b",
        re.IGNORECASE,
    )
    option_label_pattern = re.compile(r"^\(?[A-Za-z]\)?[.)]?$")
    for ref in references:
        normalized = _normalize_whitespace(ref)
        if not normalized:
            continue
        if option_label_pattern.fullmatch(normalized):
            continue
        if (
            visual_noun_pattern.search(normalized)
            or positional_visual_pattern.search(normalized)
        ):
            filtered.append(normalized)
    return filtered


def _has_html_stimulus(text: str) -> bool:
    """
    Detect whether a renderable HTML element is embedded in the question text.

    An HTML <table>, <figure>, <canvas>, <math>, <svg>, etc. is a real visual
    stimulus present inline.  Questions like "Complete the table" that include
    a <table> block do not have a mismatch even if no image_url is provided.
    """
    return bool(_HTML_STIMULUS_TAGS.search(text)) if text else False


def _scan_markdown_inline_patterns(text: str) -> bool:
    """Scan a single raw string for any inline Markdown stimulus pattern."""
    if not text:
        return False
    return (
        bool(_MARKDOWN_TABLE_PATTERN.search(text))
        or bool(_MARKDOWN_FENCED_CODE_PATTERN.search(text))
        or bool(_MARKDOWN_MULTILINE_BLOCKQUOTE_PATTERN.search(text))
    )


def _has_markdown_table_stimulus(content: str) -> bool:
    """
    Detect whether any Markdown inline stimulus is embedded in the question
    text.  Covers pipe tables, fenced code blocks, and multi-line blockquotes
    — all line-anchored patterns that depend on real newlines.

    JSON-encoded payloads are parsed first so the line boundaries survive —
    searching the JSON string directly fails because ``\\n`` inside a JSON
    value is the two-character escape ``\\n``, not a real newline, and the
    whitespace-normalised student-facing string collapses every newline to
    a space.
    """
    if not content:
        return False
    parsed = _parse_possible_json(content)
    if parsed is None:
        return _scan_markdown_inline_patterns(content)
    for s in _collect_student_facing_strings_raw(parsed):
        if _scan_markdown_inline_patterns(s):
            return True
    return False


has_markdown_table_stimulus = _has_markdown_table_stimulus


def _has_latex_stimulus(text: str) -> bool:
    """
    Detect whether a LaTeX visual block is embedded in the question text.

    Display-math environments (\\[...\\], $$...$$) and named environments like
    array, matrix, tabular, tikzpicture etc. produce rendered visuals that the
    student is expected to read.  These are valid inline stimuli — no separate
    image asset is required.
    """
    return bool(_LATEX_STIMULUS_PATTERN.search(text)) if text else False


def _has_inline_text_stimulus(text: str) -> bool:
    """
    Detect whether a text-based stimulus is embedded inline in the question.

    When a question presents content like a dictionary entry, glossary, passage,
    poem, index, or play script directly in the question text, that IS the stimulus
    — it is present as inline text, not as an image.  These questions do not have
    a mismatch even if no image URL is provided.
    """
    if not text:
        return False
    for pattern in _INLINE_TEXT_STIMULUS_PATTERNS:
        if pattern.search(text):
            return True
    return False


def _scan_blockquote_lines(text: str) -> bool:
    """Scan a single raw string for a substantial ``>``-prefixed line."""
    if not text:
        return False
    for line in _BLOCKQUOTE_LINE_PATTERN.findall(text):
        # Strip markdown emphasis so "**Sam**" counts as one word, not three.
        plain = re.sub(r"[*_`]", "", line).strip()
        if len(plain.split()) >= _BLOCKQUOTE_PASSAGE_MIN_WORDS:
            return True
    return False


def _collect_student_facing_strings_raw(
    obj: Any, parent_key: Optional[str] = None
) -> list[str]:
    """Like ``_collect_student_facing_strings`` but preserves whitespace.

    Used by checks whose patterns depend on line boundaries (e.g.,
    ``>`` blockquote detection).  ``_normalize_whitespace`` would collapse
    newlines and hide the boundary.
    """
    collected: list[str] = []

    if isinstance(obj, str):
        if obj.strip():
            collected.append(obj)
        return collected

    if isinstance(obj, list):
        for item in obj:
            collected.extend(_collect_student_facing_strings_raw(item, parent_key))
        return collected

    if isinstance(obj, dict):
        for key, value in obj.items():
            key_norm = str(key).strip().lower()
            if key_norm in _METADATA_KEYWORDS:
                continue
            if key_norm in _STUDENT_FACING_KEYS:
                collected.extend(_collect_student_facing_strings_raw(value, key_norm))
                continue
            if isinstance(value, (dict, list)):
                collected.extend(_collect_student_facing_strings_raw(value, key_norm))

    return collected


def _has_substantial_blockquote(content: str) -> bool:
    """
    Detect a markdown blockquote line carrying a real passage.

    A "> …" line with ≥ _BLOCKQUOTE_PASSAGE_MIN_WORDS words counts as the
    inline passage stimulus — short decorative pull-quotes ("> Be brave!")
    do not, and remain excluded.

    JSON-encoded payloads are parsed first so the ``>`` line boundary
    survives — searching the JSON string directly fails because ``\\n``
    inside a JSON value is the two-character escape ``\\n``, not a real
    newline.
    """
    parsed = _parse_possible_json(content)
    if parsed is None:
        return _scan_blockquote_lines(content)
    for s in _collect_student_facing_strings_raw(parsed):
        if _scan_blockquote_lines(s):
            return True
    return False


def _has_nonempty_stimulus_value(value: Any) -> bool:
    """Determine if a structured value appears to contain a real stimulus reference."""
    if value is None:
        return False

    if isinstance(value, str):
        v = value.strip()
        if not v:
            return False
        lowered = v.lower()
        if lowered in {"none", "null", "n/a", "na"}:
            return False
        if lowered.startswith("http://") or lowered.startswith("https://"):
            return True
        if lowered.startswith("data:image/"):
            return True
        if re.search(r"\.(?:jpg|jpeg|png|gif|bmp|svg|webp)(?:\?|$)", lowered):
            return True
        # Non-empty string under an explicit stimulus key is likely intentional.
        return True

    if isinstance(value, list):
        return any(_has_nonempty_stimulus_value(item) for item in value)

    return False


def _has_structured_stimulus_field(obj: Any) -> bool:
    """Check structured payloads for explicit stimulus fields."""
    if isinstance(obj, list):
        return any(_has_structured_stimulus_field(item) for item in obj)

    if not isinstance(obj, dict):
        return False

    for key, value in obj.items():
        key_norm = str(key).strip().lower()
        if _STIMULUS_KEY_PATTERN.search(key_norm) and _has_nonempty_stimulus_value(value):
            return True
        if isinstance(value, (dict, list)) and _has_structured_stimulus_field(value):
            return True

    return False


# Stimulus kinds, used to ensure that when the parent context is consulted as
# a fallback, it satisfies the SAME kind of visual reference the child asks
# about. A parent that has only a <table> should not credit a child that
# references "the figure below"; a parent with only images should not credit
# a child that references "the table below".
_KIND_IMAGE = "image"
_KIND_TABLE = "table"
_KIND_TEXT = "text_stimulus"
_KIND_ANY = "any"

_REF_TABLE_NOUN = re.compile(r"\btable\b", re.IGNORECASE)
_REF_IMAGE_NOUN = re.compile(
    r"\b(?:image|figure|picture|illustration|photograph|photo|drawing|graphic|"
    r"diagram|chart|graph|map|visual|model|representation|number\s+line|"
    r"coordinate\s+(?:plane|grid)|grid)\b",
    re.IGNORECASE,
)
_REF_TEXT_NOUN = re.compile(
    r"\b(?:passage|paragraph|poem|excerpt|sentence|sentences|story|article|"
    r"text|script|play\s+script|dictionary\s+entry|thesaurus\s+entry|glossary|"
    r"index|table\s+of\s+contents|entry|definition|announcement|letter|"
    r"diary|journal|speech|transcript|equation|expression|formula|"
    r"number\s+sentence|calculation|problem|array|data|information|"
    r"observations?|results?|records?)\b",
    re.IGNORECASE,
)


def _classify_reference_kinds(references: list[str]) -> set[str]:
    """Map regex/LLM-extracted reference phrases to stimulus kinds.

    Per phrase, only the MOST SPECIFIC kind is recorded
    (image > table > text-stimulus). A phrase like
    ``"Use the data in the table below"`` matches both ``_REF_TABLE_NOUN``
    (``"table"``) and ``_REF_TEXT_NOUN`` (``"data"``); without specificity
    ranking, the resulting ``{TABLE, TEXT}`` would let any text-only parent
    satisfy the table reference via the intersection check downstream.
    Ranking ensures the parent must cover the most specific kind the child
    actually asked about.
    """
    kinds: set[str] = set()
    for ref in references:
        if not ref:
            continue
        # Specificity order: image (most specific concrete visual) >
        # table (specific structured visual) > text-stimulus (generic).
        if _REF_IMAGE_NOUN.search(ref):
            kinds.add(_KIND_IMAGE)
        elif _REF_TABLE_NOUN.search(ref):
            kinds.add(_KIND_TABLE)
        elif _REF_TEXT_NOUN.search(ref):
            kinds.add(_KIND_TEXT)
    if not kinds:
        # No noun matched (rare — usually the regex pattern guarantees one).
        # Fall back to "any" so we don't lock out legitimate cases. This is
        # a coarse over-approximation, so log it to surface gaps in the
        # reference-noun vocabulary.
        logger.warning(
            "Stimulus reference classification: no kind-noun matched in %r; "
            "falling back to _KIND_ANY (any-stimulus parent will satisfy).",
            references,
        )
        kinds.add(_KIND_ANY)
    return kinds


_HTML_TABLE_RE = re.compile(r"<\s*table\b", re.IGNORECASE)
_HTML_IMAGEY_RE = re.compile(
    r"<\s*(?:img|figure|svg|canvas|math|iframe|video)\b", re.IGNORECASE
)


def _stimulus_kinds_in(content: str) -> set[str]:
    """Return the set of stimulus kinds actually present in ``content``.

    Mirrors the categories that ``_has_actual_stimulus`` already detects, but
    keeps each kind separate so the fallback path can require a matching kind.
    """
    kinds: set[str] = set()

    if (
        extract_image_urls(content)
        or extract_svg_content(content)
        or "[SVG converted to image for analysis]" in content
    ):
        kinds.add(_KIND_IMAGE)

    parsed = _parse_possible_json(content)
    if parsed is not None and _has_structured_stimulus_field(parsed):
        kinds.add(_KIND_IMAGE)

    student_facing_text = _get_student_facing_text(content)

    if _HTML_TABLE_RE.search(student_facing_text):
        kinds.add(_KIND_TABLE)
    if _HTML_IMAGEY_RE.search(student_facing_text):
        kinds.add(_KIND_IMAGE)

    if _has_latex_stimulus(student_facing_text):
        kinds.add(_KIND_IMAGE)

    if _has_markdown_table_stimulus(content) or _has_markdown_table_stimulus(student_facing_text):
        kinds.add(_KIND_TABLE)

    if _has_inline_text_stimulus(student_facing_text):
        kinds.add(_KIND_TEXT)

    return kinds


def _has_actual_stimulus(content: str) -> bool:
    """
    Programmatic check for whether a stimulus of any medium exists in content.

    Delegates to the per-medium artifact helpers used by
    ``detect_stimulus_reference_mismatch`` so the two paths cannot drift —
    if a new stimulus form is recognised by ``_has_text_artifact`` (e.g.
    substantial single-line blockquotes), it is recognised here too.
    """
    student_facing_text = _get_student_facing_text(content)
    return (
        _has_visual_artifact(content, student_facing_text)
        or _has_audio_artifact(content)
        or _has_video_artifact(content)
        or _has_text_artifact(content, student_facing_text)
    )


@observe(name="extract_stimulus_references")
async def _extract_visual_references_llm(text: str) -> Optional[StimulusReferenceExtraction]:
    """LLM fallback extractor for visual-reference phrases."""
    from inceptbench.llm.config import get_llm_config
    config = get_llm_config("stimulus_reference_extractor")

    system_prompt = _load_extraction_prompt()

    attempt_errors: list[AttemptError] = []

    for attempt in range(MAX_RETRIES + 1):
        try:
            from baml_client import b as _baml
            baml_result = await _baml.ExtractStimulusReferences(
                system_prompt=system_prompt,
                content=text,
            )
            extraction = StimulusReferenceExtraction(
                has_visual_references=getattr(baml_result, 'has_visual_references', False),
                references_found=list(getattr(baml_result, 'references_found', [])),
            )
            if extraction is not None:
                if attempt > 0:
                    FailureTracker.record_recovered(
                        component="stimulus_reference_detector.extract",
                        message=f"Succeeded on attempt {attempt + 1}/{MAX_RETRIES + 1}",
                        context={"model": config.model},
                        attempt_errors=attempt_errors if attempt_errors else None,
                    )
                return extraction
            raise ValueError("No parsed output from LLM")

        except Exception as e:
            attempt_errors.append(AttemptError(attempt=attempt + 1, error_message=str(e)))
            if attempt < MAX_RETRIES:
                delay = BASE_DELAY * (2**attempt) + random.uniform(0, 1)
                logger.warning(
                    f"Stimulus extraction error (attempt {attempt + 1}/{MAX_RETRIES + 1}): {e}. "
                    f"Retrying in {delay:.1f}s..."
                )
                await asyncio.sleep(delay)
            else:
                FailureTracker.record_exhausted(
                    component="stimulus_reference_detector.extract",
                    error_message=str(e),
                    context={"model": config.model, "attempts": MAX_RETRIES + 1},
                    attempt_errors=attempt_errors,
                )
                logger.error(
                    f"Stimulus extraction failed after {MAX_RETRIES + 1} attempts: {e}"
                )

    return None


@observe(name="extract_stimulus_promises")
async def _extract_stimulus_promises_llm(text: str) -> Optional[StimulusPromiseExtraction]:
    """LLM-based extractor for the structured list of promised stimuli."""
    from inceptbench.llm.config import get_llm_config
    config = get_llm_config("stimulus_reference_extractor")

    system_prompt = _load_promise_extraction_prompt()

    attempt_errors: list[AttemptError] = []

    for attempt in range(MAX_RETRIES + 1):
        try:
            from baml_client import b as _baml
            baml_result = await _baml.ExtractStimulusPromises(
                system_prompt=system_prompt,
                content=text,
            )
            promises_raw = list(getattr(baml_result, "promises", []) or [])
            normalized: list[StimulusPromise] = []
            for p in promises_raw:
                kind = _normalize_whitespace(getattr(p, "kind", "") or "")
                medium_raw = (getattr(p, "medium_required", "") or "").strip().lower()
                phrase = _normalize_whitespace(getattr(p, "exact_phrase", "") or "")
                medium = _normalize_medium(medium_raw, kind)
                if not kind:
                    continue
                normalized.append(
                    StimulusPromise(
                        kind=kind,
                        medium_required=medium,
                        exact_phrase=phrase,
                    )
                )
            extraction = StimulusPromiseExtraction(promises=normalized)
            if attempt > 0:
                FailureTracker.record_recovered(
                    component="stimulus_reference_detector.extract_promises",
                    message=f"Succeeded on attempt {attempt + 1}/{MAX_RETRIES + 1}",
                    context={"model": config.model},
                    attempt_errors=attempt_errors if attempt_errors else None,
                )
            return extraction

        except Exception as e:
            attempt_errors.append(AttemptError(attempt=attempt + 1, error_message=str(e)))
            if attempt < MAX_RETRIES:
                delay = BASE_DELAY * (2**attempt) + random.uniform(0, 1)
                logger.warning(
                    f"Stimulus promise extraction error (attempt {attempt + 1}/{MAX_RETRIES + 1}): {e}. "
                    f"Retrying in {delay:.1f}s..."
                )
                await asyncio.sleep(delay)
            else:
                FailureTracker.record_exhausted(
                    component="stimulus_reference_detector.extract_promises",
                    error_message=str(e),
                    context={"model": config.model, "attempts": MAX_RETRIES + 1},
                    attempt_errors=attempt_errors,
                )
                logger.error(
                    f"Stimulus promise extraction failed after {MAX_RETRIES + 1} attempts: {e}"
                )

    return None


_VISUAL_KIND_HINTS = {
    "chart", "graph", "illustration", "diagram", "figure", "map", "picture",
    "photo", "photograph", "image", "drawing", "infographic", "table",
    "number_line", "coordinate_plane", "coordinate_grid", "grid",
}
_AUDIO_KIND_HINTS = {
    "audio", "audio_recording", "oral", "oral_announcement", "announcement",
    "speech", "transcript", "recording", "podcast",
}
_VIDEO_KIND_HINTS = {"video", "video_version", "movie", "film", "clip"}
_MULTIMEDIA_KIND_HINTS = {
    "multimedia", "multimedia_presentation", "video_presentation",
    "video_version_of_the_poem", "presentation",
}
_TEXT_KIND_HINTS = {
    "passage", "poem", "article", "story", "excerpt", "paragraph",
    "dictionary_entry", "thesaurus_entry", "glossary", "play_script",
    "script", "letter", "diary", "journal", "index",
    "table_of_contents", "definition",
}


def _normalize_medium(raw: str, kind: str) -> PromiseMedium:
    """Normalize the medium_required string returned by the LLM."""
    raw = (raw or "").strip().lower()
    if raw in {"visual", "image", "graphic", "picture"}:
        return "visual"
    if raw in {"audio", "oral", "sound", "speech"}:
        return "audio"
    if raw == "video":
        return "video"
    if raw in {"multimedia", "av", "audiovisual"}:
        return "multimedia"
    if raw in {"text", "written", "inline_text"}:
        return "text"

    # Fall back to kind-based inference if the LLM returned something unexpected.
    kind_norm = (kind or "").strip().lower().replace(" ", "_").replace("-", "_")
    if kind_norm in _MULTIMEDIA_KIND_HINTS:
        return "multimedia"
    if kind_norm in _VIDEO_KIND_HINTS:
        return "video"
    if kind_norm in _AUDIO_KIND_HINTS:
        return "audio"
    if kind_norm in _VISUAL_KIND_HINTS:
        return "visual"
    if kind_norm in _TEXT_KIND_HINTS:
        return "text"
    # Default: assume the most strict requirement so we err toward catching
    # real artifacts the question promised but didn't provide.
    return "visual"


def _filter_implausible_promises(
    promises: list[StimulusPromise],
) -> list[StimulusPromise]:
    """Drop visual promises whose cited phrase does not actually reference a visual."""
    visual_noun_pattern = re.compile(rf"\b(?:{_DIRECTIVE_VISUAL_NOUNS})\b", re.IGNORECASE)
    positional_visual_pattern = re.compile(
        r"\bas\s+(?:shown|seen|depicted|illustrated)\s+(?:below|above|here)\b",
        re.IGNORECASE,
    )
    filtered: list[StimulusPromise] = []
    for promise in promises:
        if promise.medium_required != "visual":
            filtered.append(promise)
            continue

        phrase = _normalize_whitespace(promise.exact_phrase)
        if (
            visual_noun_pattern.search(phrase)
            or positional_visual_pattern.search(phrase)
        ):
            filtered.append(promise)
            continue

        logger.info(
            "Discarding implausible visual promise without visual reference phrase: "
            "kind=%r exact_phrase=%r",
            promise.kind,
            promise.exact_phrase,
        )
    return filtered


def _promise_to_fallback_kind(promise: "UnsatisfiedPromise") -> str:
    """Map a promise's (kind, medium) to the parent-fallback stimulus-kind.

    Used by the kind-matched parent-context fallback in
    ``detect_stimulus_reference_mismatch``.  Returns ``_KIND_ANY`` when no
    parent kind is appropriate (audio / video / multimedia) — those promises
    are never satisfied by parent fallback.
    """
    kind_norm = (promise.kind or "").strip().lower().replace(" ", "_").replace("-", "_")
    if "table" in kind_norm:
        return _KIND_TABLE
    if promise.medium_required == "text":
        return _KIND_TEXT
    if promise.medium_required == "visual":
        return _KIND_IMAGE
    return _KIND_ANY


def _has_visual_artifact(content: str, student_facing_text: str) -> bool:
    """
    True iff a real visual artifact (image / SVG / renderable structured visual)
    is present in the content.  A prose paragraph that DESCRIBES a visual is NOT
    a visual artifact — only the rendered artifact itself counts.
    """
    if extract_image_urls(content):
        return True
    if extract_svg_content(content):
        return True
    if "[SVG converted to image for analysis]" in content:
        return True

    parsed = _parse_possible_json(content)
    if parsed is not None and _has_structured_stimulus_field(parsed):
        return True

    if _has_html_stimulus(student_facing_text):
        return True
    if _has_latex_stimulus(student_facing_text):
        return True
    if _has_markdown_table_stimulus(content) or _has_markdown_table_stimulus(student_facing_text):
        return True

    return False


def _has_audio_artifact(content: str) -> bool:
    """True iff a real audio asset is referenced in the content."""
    if extract_audio_urls(content):
        return True
    if extract_audio_data_uris(content):
        return True
    return False


def _has_video_artifact(content: str) -> bool:
    """True iff a real video asset (or YouTube link) is referenced."""
    return bool(extract_video_urls(content))


def _has_text_artifact(content: str, student_facing_text: str) -> bool:
    """
    True iff an inline text-based stimulus (passage, poem, dictionary entry,
    or a substantial blockquote passage) is genuinely embedded in the
    student-facing text.

    Blockquote detection runs against the raw ``content`` because
    ``student_facing_text`` is whitespace-normalized — newlines collapse and
    the ``>`` line boundary disappears — so a single ``>``-prefixed passage
    would otherwise be invisible to the pattern.
    """
    return (
        _has_inline_text_stimulus(student_facing_text)
        or _has_substantial_blockquote(content)
    )


def _verify_promises(
    content: str,
    student_facing_text: str,
    promises: list[StimulusPromise],
) -> list[UnsatisfiedPromise]:
    """
    For each promised stimulus, check whether the content actually carries an
    artifact in the required medium.  Returns the list of unsatisfied promises.

    A `visual` promise is satisfied by a real image/SVG/rendered table — NOT by
    a prose `Illustration: …` block.  An `audio` promise needs an actual audio
    asset.  A `video`/`multimedia` promise needs an actual video/audio asset.
    """
    has_visual = _has_visual_artifact(content, student_facing_text)
    has_audio = _has_audio_artifact(content)
    has_video = _has_video_artifact(content)
    has_text = _has_text_artifact(content, student_facing_text)

    unsatisfied: list[UnsatisfiedPromise] = []
    for promise in promises:
        medium = promise.medium_required
        if medium == "visual":
            if has_visual:
                continue
            reason = (
                "Question promises a visual artifact (chart/illustration/diagram/etc.) "
                "but no real image, SVG, rendered table, or LaTeX visual is present. "
                "A prose description of the artifact does not count."
            )
        elif medium == "audio":
            if has_audio:
                continue
            reason = (
                "Question promises an oral/audio source but no audio URL or audio "
                "asset is attached. A written transcript is not a substitute when "
                "the standard requires an oral medium."
            )
        elif medium == "video":
            if has_video:
                continue
            reason = (
                "Question promises a video but no video URL (or YouTube link) is "
                "attached. A prose description of a video is not a substitute."
            )
        elif medium == "multimedia":
            if has_video or (has_visual and has_audio):
                continue
            reason = (
                "Question promises a multimedia presentation (video + audio) but "
                "no video/audio asset is attached. A prose description of the "
                "multimedia version is not a substitute."
            )
        elif medium == "text":
            # Text promises are auto-satisfied.  The "fool the evaluator with
            # a prose description" attack pattern targets visual / audio /
            # video / multimedia promises only — those have a real medium
            # mismatch when the artifact is faked as text.  For a text
            # promise the stimulus inherently IS text, so as long as the LLM
            # judged a text artifact was implied, the inline question content
            # covers it.  Variations like "Read the draft passage", "Read the
            # two sentences", "Read these letters", or "Read the word: Ball"
            # otherwise produce false positives because the keyword-gated
            # regex misses common phrasings.
            continue
        else:
            continue

        unsatisfied.append(
            UnsatisfiedPromise(
                kind=promise.kind,
                medium_required=medium,
                exact_phrase=promise.exact_phrase,
                reason=reason,
            )
        )

    return unsatisfied


async def detect_stimulus_reference_mismatch(
    content: str,
    fallback_context: Optional[str] = None,
) -> StimulusReferenceResult:
    """
    Detect whether content references stimuli that are not actually provided.

    Promise-driven flow:
    1) LLM extracts a structured list of promised stimuli (visual / audio /
       video / multimedia / text), one entry per artifact the question
       references.
    2) For each promise, verify locally that an artifact in the required
       medium is present in ``content`` (image URL / SVG / HTML or markdown
       table / LaTeX visual / audio URL / video URL / inline text passage).
    3) Kind-matched parent-context fallback. For each promise that is
       unsatisfied locally, consult ``fallback_context`` (the parent of a
       decomposed child). The parent only counts when it carries a stimulus
       of the SAME kind (image vs. table vs. text) the promise asks about —
       a parent with only a ``<table>`` does not satisfy a "figure below"
       promise. Recursive decomposition often splits a parent into children
       whose slice excludes a sibling-region image; this fallback resolves
       those false positives without papering over real mismatches. Audio /
       video / multimedia promises are not fallback-eligible (the parent
       check tracks visual + text kinds only).
    4) Any promise that remains unsatisfied is reported as a mismatch.

    The legacy regex fast-path is still consulted to populate
    ``references_found`` and ``has_visual_references`` for backwards
    compatibility, but the authoritative mismatch decision is now driven by
    the per-promise check.
    """
    student_facing_text = _get_student_facing_text(content)

    # Legacy bookkeeping (kept for backwards compatibility with consumers that
    # still read ``has_visual_references`` / ``references_found``).
    regex_refs = _extract_visual_references_regex(student_facing_text)
    legacy_has_visual = bool(regex_refs)
    legacy_refs: list[str] = list(regex_refs)
    legacy_method: Literal["regex", "llm", "promise", "none"] = (
        "regex" if regex_refs else "none"
    )

    extraction = await _extract_stimulus_promises_llm(student_facing_text)
    promises: list[StimulusPromise] = list(extraction.promises) if extraction else []
    promises = _filter_implausible_promises(promises)

    unsatisfied = _verify_promises(content, student_facing_text, promises)
    has_actual_stimulus = (
        _has_visual_artifact(content, student_facing_text)
        or _has_audio_artifact(content)
        or _has_video_artifact(content)
        or _has_text_artifact(content, student_facing_text)
    )

    # Parent-context fallback (kind-matched).  Decomposed children can
    # reference "the figure below" while the actual figure lives in a
    # sibling slice of the parent.  When ``fallback_context`` is supplied
    # and an unsatisfied promise's medium is covered by a stimulus of the
    # SAME kind in the parent, drop that promise from the mismatch list.
    # A parent with only a ``<table>`` does not satisfy a "figure below"
    # promise; a parent with only images does not satisfy a "table below"
    # promise.  Audio / video / multimedia promises are NOT fallback-
    # eligible — the parent check tracks visual + text kinds only.
    if unsatisfied and fallback_context and fallback_context != content:
        parent_kinds = _stimulus_kinds_in(fallback_context)
        if parent_kinds:
            still_unsatisfied: list[UnsatisfiedPromise] = []
            for up in unsatisfied:
                promise_kind = _promise_to_fallback_kind(up)
                if promise_kind == _KIND_ANY:
                    # Medium not coverable by parent fallback (audio/video/
                    # multimedia) or unclassifiable — keep as unsatisfied.
                    still_unsatisfied.append(up)
                    continue
                if promise_kind in parent_kinds:
                    continue
                still_unsatisfied.append(up)
            unsatisfied = still_unsatisfied

    if extraction is None and legacy_has_visual:
        # LLM extractor exhausted retries; without it we have no structured
        # promises and ``unsatisfied`` is empty even when the regex fast-path
        # already saw a real visual reference.  Fall back to the legacy
        # coarse check so a "Look at the chart" with no chart is still
        # flagged when the LLM is unavailable.  Apply main's kind-matched
        # parent-context fallback against the regex references so a
        # decomposed child whose parent carries the matching stimulus is
        # still credited.
        legacy_refs = _filter_llm_visual_references(legacy_refs)
        legacy_has_visual = bool(legacy_refs)
        if not legacy_has_visual:
            legacy_method = "none"
            is_mismatch = False
        else:
            legacy_satisfied = has_actual_stimulus
            if (
                not legacy_satisfied
                and fallback_context
                and fallback_context != content
            ):
                parent_kinds = _stimulus_kinds_in(fallback_context)
                if parent_kinds:
                    ref_kinds = _classify_reference_kinds(legacy_refs)
                    if _KIND_ANY in ref_kinds or ref_kinds.issubset(parent_kinds):
                        legacy_satisfied = True
            is_mismatch = not legacy_satisfied
    else:
        is_mismatch = bool(unsatisfied)

    # If the promise extractor surfaced a visual/multimedia/video promise we
    # didn't catch via regex, surface it in the legacy fields too so existing
    # logging and downstream context is informative.
    if not legacy_has_visual:
        for promise in promises:
            if promise.medium_required in ("visual", "video", "multimedia"):
                legacy_has_visual = True
                legacy_method = "promise"
                break
    if not legacy_refs:
        legacy_refs = [p.exact_phrase or p.kind for p in promises if p.exact_phrase or p.kind][:5]

    return StimulusReferenceResult(
        has_visual_references=legacy_has_visual,
        references_found=legacy_refs,
        has_actual_stimulus=has_actual_stimulus,
        is_mismatch=is_mismatch,
        detection_method=legacy_method,
        unsatisfied_promises=unsatisfied,
        promises=promises,
    )
