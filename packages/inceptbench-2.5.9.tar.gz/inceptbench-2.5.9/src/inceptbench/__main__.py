"""
Main entry point for the inceptbench CLI.

This allows running the CLI with:
    python -m inceptbench evaluate ...
    python -m inceptbench example

Instead of:
    python -m inceptbench.cli.main evaluate ...
"""

import sys
from .cli import main as cli_main


if __name__ == "__main__":
    sys.exit(cli_main())

