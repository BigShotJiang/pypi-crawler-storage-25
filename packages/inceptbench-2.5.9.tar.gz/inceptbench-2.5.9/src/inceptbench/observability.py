"""
Observability helpers for Langfuse integration.

Provides safe ``observe`` and ``propagate_attributes`` wrappers that
become no-ops when the ``langfuse`` package is not installed or when
Langfuse credentials are not configured.

Usage in any module::

    from inceptbench.observability import observe, propagate_attributes

    class MyService:
        @observe(name="my_operation")
        async def do_work(self, ...):
            with propagate_attributes(tags=["eval"], metadata={"v": "1"}):
                ...
"""

import os
from contextlib import contextmanager


def _langfuse_configured() -> bool:
    """Check whether Langfuse credentials are present before importing the SDK."""
    return bool(os.getenv("LANGFUSE_SECRET_KEY") and os.getenv("LANGFUSE_PUBLIC_KEY"))


def _noop_observe(name: str = "", **kwargs):
    """No-op fallback for @observe."""
    def wrapper(fn):
        return fn
    return wrapper


@contextmanager
def _noop_propagate_attributes(**kwargs):
    """No-op fallback for propagate_attributes."""
    yield


if _langfuse_configured():
    try:
        from langfuse import observe
    except Exception:
        try:
            from langfuse.decorators import observe
        except Exception:
            observe = _noop_observe

    try:
        from langfuse import propagate_attributes
    except Exception:
        propagate_attributes = _noop_propagate_attributes
else:
    observe = _noop_observe
    propagate_attributes = _noop_propagate_attributes
