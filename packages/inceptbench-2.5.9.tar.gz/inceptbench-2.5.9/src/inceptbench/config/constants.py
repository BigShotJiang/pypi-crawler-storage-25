"""
Shared project constants.
"""

from typing import Optional

# AP curriculum identifiers
AP_CURRICULUMS = frozenset(
    {
        "ap",
        "ap_us_history",
        "ap_world_history",
        "ap_european_history",
        "ap_government",
        "ap_human_geography",
        "ap_macroeconomics",
        "ap_microeconomics",
        "college_board",
    }
)

# Subjects that require the independent factual-accuracy audit.
# Use None to audit all subjects; a frozenset to restrict.
FACTUAL_AUDIT_SUBJECTS: Optional[frozenset[str]] = frozenset({
    "social_studies",
})

# Mapping from AP curriculum key to course code used in AP facts JSON
AP_CURRICULUM_TO_COURSE = {
    "ap_us_history": "APUSH",
    "ap_world_history": "APWH",
    "ap_european_history": "APEURO",
    "ap_government": "APGOV",
    "ap_human_geography": "APHG",
    "ap_macroeconomics": "APMAC",
    "ap_microeconomics": "APMIC",
}

# ---------------------------------------------------------------------------
# New curriculum service mappings
# ---------------------------------------------------------------------------

# InceptBench slug -> curriculum API abbreviation
CURRICULUM_NAME_TO_ABBREVIATION: dict[str, str] = {
    "cc": "CC",
    "common_core": "CC",
    "athena_cc": "Athena-CC",
    "teks": "TEKS",
    "sat": "SAT",
    "ap": "AP",
    "college_board": "AP",
    "ap_us_history": "AP",
    "ap_world_history": "AP",
    "ap_european_history": "AP",
    "ap_government": "AP",
    "ap_human_geography": "AP",
    "ap_macroeconomics": "AP",
    "ap_microeconomics": "AP",
}

# Curriculum API abbreviation -> canonical InceptBench slug.
# Used by the /curriculums endpoint to map API abbreviations back to
# InceptBench keys.  Many-to-one slugs (all AP variants → "AP") resolve to
# the canonical bare slug.
CURRICULUM_ABBREVIATION_TO_SLUG: dict[str, str] = {
    "CC": "common_core",
    "Athena-CC": "athena_cc",
    "TEKS": "teks",
    "SAT": "sat",
    "AP": "ap",
}

# Normalise subject names to the values the curriculum API expects
SUBJECT_NAME_MAPPING: dict[str, str] = {
    "american history": "American History",
    "american_history": "American History",
    "ela": "Language",
    "english": "Language",
    "english language arts": "Language",
    "language arts": "Language",
    "language": "Language",
    "mathematics": "Math",
    "math": "Math",
    "music": "Music",
    "reading": "Reading",
    "science": "Science",
    "social studies": "Social Studies",
    "social_studies": "Social Studies",
    "visual arts": "Visual Arts",
    "visual_arts": "Visual Arts",
    "world history": "World History",
    "world_history": "World History",
}
