"""
Configuration settings for the Educational Content Evaluator.

This module manages environment variables, API keys, model configurations,
and other system-wide settings.
"""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Load environment variables from .env file in project root.
# __file__ is src/inceptbench/config/settings.py — walk up four levels to repo root.
env_path = Path(__file__).parent.parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)


class Settings:
    """Application settings and configuration."""

    @staticmethod
    def _get_bool_env(name: str, default: bool = False) -> bool:
        value = os.getenv(name)
        if value is None:
            return default
        return value.strip().lower() in {"1", "true", "yes", "on"}
    
    # API Keys (loaded from .env file)
    OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")
    ANTHROPIC_API_KEY: Optional[str] = os.getenv("ANTHROPIC_API_KEY")
    GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY")
    INCEPT_API_KEY: Optional[str] = os.getenv("INCEPT_API_KEY")
    
    # Timeouts (in seconds)
    DEFAULT_TIMEOUT: float = 300.0
    CLASSIFIER_TIMEOUT: float = 60.0
    CURRICULUM_SEARCH_TIMEOUT: float = 90.0

    # Gemini service tier: "flex" (default, 50% cost) or "standard"
    GEMINI_SERVICE_TIER: str = os.getenv("GEMINI_SERVICE_TIER", "flex").strip().lower()

    # Optional request-level token usage reporting (segmented by model)
    INCLUDE_COST: bool = _get_bool_env.__func__("INCEPTBENCH_INCLUDE_COST", False)
    
    # Curriculum Configuration
    DEFAULT_CURRICULUM: str = "common_core"
    
    # Curriculum service (incept-curriculum)
    INCEPT_CURRICULUM_API_URL: str = os.getenv(
        "INCEPT_CURRICULUM_API_URL",
        "https://api.curriculum.inceptapi.com",
    )
    INCEPT_CURRICULUM_API_KEY: Optional[str] = os.getenv("INCEPT_CURRICULUM_API_KEY")
    
    @classmethod
    def validate_api_keys(cls) -> None:
        """
        Validate that required API keys are present.

        Raises:
            ValueError: If any required API key is missing.
        """
        required = {
            "OPENAI_API_KEY": cls.OPENAI_API_KEY,
            "GEMINI_API_KEY": cls.GEMINI_API_KEY,
            "INCEPT_CURRICULUM_API_KEY": cls.INCEPT_CURRICULUM_API_KEY,
        }
        missing = [name for name, value in required.items() if not value]
        if missing:
            raise ValueError(
                f"Required environment variable(s) not set: {', '.join(missing)}"
            )


# Create singleton instance
settings = Settings()

