"""
Content enrichment for media-rich content.

Note: The VideoEnricher has been replaced by a simpler transcript-based
approach. For video content processing, see:
- inceptbench.tools.transcript_fetcher.TranscriptFetcher

The transcript-based approach is simpler and automatically inherits
content type knowledge from the existing classifier/decomposer prompts.
"""

# This module is kept for backward compatibility but no longer exports
# the VideoEnricher. Use TranscriptFetcher from tools.transcript_fetcher instead.

__all__ = []
