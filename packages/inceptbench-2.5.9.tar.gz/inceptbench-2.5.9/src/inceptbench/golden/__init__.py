"""Golden dataset regression test package."""
