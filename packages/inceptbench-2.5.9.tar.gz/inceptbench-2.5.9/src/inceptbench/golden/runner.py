"""
Golden dataset regression test runner.

Loads curated educational content items from golden_dataset.json,
re-evaluates each one, and compares the new verdict against the
expected verdict to detect regressions.

Enhanced to capture detailed per-metric results for failure analysis.

Supports multi-run stability testing: run evals N times and aggregate
per-item pass/fail statistics to surface flaky or borderline items.
"""

import asyncio
import json
import logging
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..service import EvaluationService
from ..core.input_models import RequestMetadata
from ..models.base import MetricResult

logger = logging.getLogger(__name__)

GOLDEN_DATASET_PATH = Path(__file__).parent / "golden_dataset.json"

# Verdicts that count as "passing" quality
_PASS_VERDICTS = {"ACCEPTABLE", "SUPERIOR"}

_SKIP_METRIC_FIELDS = frozenset({"content_type", "subcontent_evaluations", "overall"})

# Metrics that appear on all content types
_UNIVERSAL_METRICS = [
    "factual_accuracy",
    "educational_effectiveness",
    "localization_quality",
]

# Content-type-specific metrics
_CONTENT_TYPE_METRICS = {
    "instructional_question": ["clarity", "difficulty_alignment", "distractor_quality", "stimulus_quality"],
    "assessment_question": ["clarity", "difficulty_alignment", "distractor_quality", "stimulus_quality"],
    "quiz": ["concept_coverage", "difficulty_distribution", "non_repetitiveness", "answer_balance", "stimulus_quality"],
    "article": ["clarity", "follows_direct_instruction"],
    "reading_passage": ["reading_level_match", "text_quality"],
    "other": ["clarity"],
}


def _enum_to_str(val) -> str:
    """Safely convert an enum or string value to a plain string."""
    return val.value if hasattr(val, 'value') else str(val) if val else ""


@dataclass
class MetricDetail:
    """Detailed result for a single metric."""
    name: str
    score: float
    reasoning: str = ""
    suggested_improvements: str = ""


@dataclass
class GoldenTestResult:
    """Result of a single golden dataset item evaluation."""

    item_id: str
    expected_verdict: str
    actual_verdict: str
    actual_score: float
    passed: bool  # True if expected == actual verdict category
    error: Optional[str] = None
    # Detailed metric results
    content_type: str = ""
    metrics: list[MetricDetail] = field(default_factory=list)
    overall_reasoning: str = ""
    overall_improvements: str = ""
    # Item metadata for context
    metadata: dict = field(default_factory=dict)


@dataclass
class GoldenTestReport:
    """Aggregated report for the full golden dataset run."""

    total: int
    passed: int
    failed: int
    errors: int
    pass_rate: float
    threshold: float
    threshold_met: bool
    results: list[GoldenTestResult] = field(default_factory=list)
    duration_seconds: float = 0.0

    @property
    def regressions(self) -> list[GoldenTestResult]:
        """Return items that regressed (wrong verdict, excluding errors)."""
        return [r for r in self.results if not r.passed and r.error is None]


def _load_golden_dataset() -> dict:
    """Load and return the golden dataset JSON."""
    with open(GOLDEN_DATASET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


_MOJIBAKE_MAP = {
    '\u00e2\u20ac\u201d': '\u2014',   # em-dash —
    '\u00e2\u20ac\u201c': '\u2013',   # en-dash –
    '\u00e2\u20ac\u2122': '\u2019',   # right single quote '
    '\u00e2\u20ac\u0153': '\u201c',   # left double quote "
    '\u00e2\u20ac\u009d': '\u201d',   # right double quote "
    '\u00e2\u20ac\u00a2': '\u2022',   # bullet •
    '\u00e2\u20ac\u02dc': '\u2018',   # left single quote '
    '\u00e2\u20ac\u2026': '\u2026',   # horizontal ellipsis …
    '\u00c3\u2014': '\u00d7',         # multiplication sign ×
    '\u00c3\u00b7': '\u00f7',         # division sign ÷
    '\u00c3\u00a9': '\u00e9',         # é
    '\u00c3\u00ad': '\u00ed',         # í
    '\u00c3\u00b3': '\u00f3',         # ó
    '\u00c3\u00ba': '\u00fa',         # ú
    '\u00c3\u00b1': '\u00f1',         # ñ
    '\u00c2\u00a0': '\u00a0',         # non-breaking space
    '\u00cc\u2026': '\u0305',         # combining overline
}


def _fix_mojibake(text: str) -> str:
    """Fix common UTF-8 to CP1252 to UTF-8 double-encoding artifacts."""
    for garbled, clean in _MOJIBAKE_MAP.items():
        text = text.replace(garbled, clean)
    return text


def _fix_mojibake_recursive(value):
    """Recursively fix mojibake in all string values within a data structure."""
    if isinstance(value, str):
        return _fix_mojibake(value)
    elif isinstance(value, dict):
        return {k: _fix_mojibake_recursive(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [_fix_mojibake_recursive(item) for item in value]
    return value


def _content_to_string(generated_content) -> str:
    """Convert generated_content to a string suitable for evaluation.

    Fixes common mojibake (double-encoded UTF-8) before serialization
    so the evaluator sees the intended characters rather than garbled
    encoding artifacts.
    """
    if isinstance(generated_content, dict):
        return json.dumps(_fix_mojibake_recursive(generated_content), indent=2)
    return _fix_mojibake(str(generated_content))


def _build_request_metadata(raw_metadata: Optional[dict]) -> Optional[RequestMetadata]:
    """Build a RequestMetadata instance from a raw dict, or None."""
    if raw_metadata is None:
        return None
    return RequestMetadata(**raw_metadata)


def _verdicts_match(expected: str, actual: str) -> bool:
    """
    Compare expected and actual verdicts by category.

    Both ACCEPTABLE and SUPERIOR count as the "pass" category.
    INFERIOR is the "fail" category.
    """
    expected_passes = expected.upper() in _PASS_VERDICTS
    actual_passes = actual.upper() in _PASS_VERDICTS
    return expected_passes == actual_passes


def _extract_metrics(result) -> tuple[list[MetricDetail], str, str]:
    """Extract all metric details from an evaluation result.

    Dynamically discovers metrics from the result model's fields so that
    every MetricResult field (regardless of content type) is captured.
    """
    metrics = []
    for field_name in type(result).model_fields:
        if field_name in _SKIP_METRIC_FIELDS:
            continue
        value = getattr(result, field_name, None)
        if isinstance(value, MetricResult):
            metrics.append(MetricDetail(
                name=field_name,
                score=value.score,
                reasoning=getattr(value, 'reasoning', '') or '',
                suggested_improvements=getattr(value, 'suggested_improvements', '') or '',
            ))

    overall_obj = getattr(result, 'overall', None)
    overall_reasoning = ''
    overall_improvements = ''
    if overall_obj:
        overall_reasoning = getattr(overall_obj, 'reasoning', '') or ''
        overall_improvements = getattr(overall_obj, 'suggested_improvements', '') or ''

    return metrics, overall_reasoning, overall_improvements


ITEM_TIMEOUT_SECONDS = 600  # 10-minute hard ceiling per item evaluation


async def _evaluate_single_item(
    item: dict,
    service: EvaluationService,
    semaphore: asyncio.Semaphore,
) -> GoldenTestResult:
    """Evaluate a single golden dataset item under semaphore control."""
    item_id = item.get("id", "unknown")
    expected_verdict = item.get("expected_verdict", "UNKNOWN")
    item_metadata = item.get("metadata", {})

    async with semaphore:
        try:
            # Reconstruct the content string
            content_str = _content_to_string(item.get("generated_content", ""))

            # Build request metadata if present
            request_metadata = _build_request_metadata(
                item.get("request_metadata")
            )

            # Curriculum is now inside request_metadata (request.curriculum)
            curriculum = (
                request_metadata.curriculum if request_metadata else None
            ) or item.get("metadata", {}).get("curriculum")

            # Run evaluation with hard timeout failsafe
            result = await asyncio.wait_for(
                service.evaluate(
                    content=content_str,
                    request_metadata=request_metadata,
                    curriculum=curriculum,
                ),
                timeout=ITEM_TIMEOUT_SECONDS,
            )

            actual_verdict = _enum_to_str(result.overall_rating)
            actual_score = result.overall.score
            passed = _verdicts_match(expected_verdict, actual_verdict)

            # Extract detailed metrics
            content_type = _enum_to_str(result.content_type)
            metrics, overall_reasoning, overall_improvements = _extract_metrics(result)

            return GoldenTestResult(
                item_id=item_id,
                expected_verdict=expected_verdict,
                actual_verdict=actual_verdict,
                actual_score=actual_score,
                passed=passed,
                content_type=content_type,
                metrics=metrics,
                overall_reasoning=overall_reasoning,
                overall_improvements=overall_improvements,
                metadata=item_metadata,
            )

        except Exception as e:
            logger.error(f"Error evaluating golden item {item_id}: {e}")
            return GoldenTestResult(
                item_id=item_id,
                expected_verdict=expected_verdict,
                actual_verdict="ERROR",
                actual_score=0.0,
                passed=False,
                error=str(e),
                metadata=item_metadata,
            )


async def run_golden_test(
    threshold: float = 0.98,
    max_concurrent: int = 5,
    verbose: bool = False,
    on_progress: Optional[callable] = None,
) -> GoldenTestReport:
    """
    Run the golden dataset regression test.

    Loads every item from golden_dataset.json, re-evaluates it, and
    compares the new overall_rating against the expected_verdict.

    Args:
        threshold: Minimum pass rate (0.0-1.0) to consider the test passing.
        max_concurrent: Maximum number of concurrent evaluations.
        verbose: If True, log extra detail per item.
        on_progress: Optional callback(completed, total) called after each item.

    Returns:
        GoldenTestReport with full results and aggregate statistics.
    """
    dataset = _load_golden_dataset()
    items = dataset.get("items", [])
    total = len(items)

    if total == 0:
        return GoldenTestReport(
            total=0,
            passed=0,
            failed=0,
            errors=0,
            pass_rate=1.0,
            threshold=threshold,
            threshold_met=True,
        )

    service = EvaluationService()
    semaphore = asyncio.Semaphore(max_concurrent)
    start_time = time.time()

    # Track progress with a mutable counter
    completed = [0]

    async def _run_and_track(item: dict) -> GoldenTestResult:
        result = await _evaluate_single_item(item, service, semaphore)
        completed[0] += 1
        if verbose:
            status = "PASS" if result.passed else ("ERROR" if result.error else "FAIL")
            logger.info(
                f"[{completed[0]}/{total}] {result.item_id}: {status} "
                f"(expected={result.expected_verdict}, actual={result.actual_verdict})"
            )
        if on_progress is not None:
            on_progress(completed[0], total)
        return result

    # Run all evaluations concurrently (bounded by semaphore)
    tasks = [_run_and_track(item) for item in items]
    results = await asyncio.gather(*tasks)

    duration = time.time() - start_time

    # Aggregate statistics
    passed = sum(1 for r in results if r.passed)
    errors = sum(1 for r in results if r.error is not None)
    failed = total - passed - errors
    # Count errored items as misses for the release gate. A green golden run
    # should mean enough of the whole dataset passed, not just the subset that
    # completed without provider/runtime errors.
    pass_rate = (passed / total) if total > 0 else 0.0

    return GoldenTestReport(
        total=total,
        passed=passed,
        failed=failed,
        errors=errors,
        pass_rate=pass_rate,
        threshold=threshold,
        threshold_met=pass_rate >= threshold,
        results=list(results),
        duration_seconds=round(duration, 2),
    )


# ---------------------------------------------------------------------------
# Multi-run stability testing
# ---------------------------------------------------------------------------


def _std_dev(values: list[float]) -> float:
    """Population standard deviation for a list of floats."""
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    return math.sqrt(sum((v - mean) ** 2 for v in values) / len(values))


@dataclass
class MetricStats:
    """Aggregated score statistics for a single metric across multiple runs."""
    name: str
    mean: float
    min: float
    max: float
    std_dev: float
    scores: list[float] = field(default_factory=list)


@dataclass
class ItemStabilityResult:
    """Per-item statistics aggregated across N evaluation runs."""
    item_id: str
    expected_verdict: str
    metadata: dict
    num_runs: int
    pass_count: int
    fail_count: int
    error_count: int
    pass_rate: float
    verdicts: list[str] = field(default_factory=list)
    overall_scores: list[float] = field(default_factory=list)
    score_mean: float = 0.0
    score_std_dev: float = 0.0
    metric_stats: list[MetricStats] = field(default_factory=list)
    run_results: list[GoldenTestResult] = field(default_factory=list)

    @property
    def is_stable(self) -> bool:
        """True if the item passed or failed consistently (never mixed)."""
        return self.pass_rate == 0.0 or self.pass_rate == 1.0

    @property
    def is_flaky(self) -> bool:
        return not self.is_stable


@dataclass
class StabilityReport:
    """Aggregated report for a multi-run stability test."""
    num_runs: int
    num_items: int
    per_run_reports: list[GoldenTestReport]
    item_results: list[ItemStabilityResult]
    duration_seconds: float = 0.0

    @property
    def stable_pass_items(self) -> list[ItemStabilityResult]:
        return [r for r in self.item_results if r.pass_rate == 1.0]

    @property
    def stable_fail_items(self) -> list[ItemStabilityResult]:
        return [r for r in self.item_results if r.pass_rate == 0.0 and r.error_count == 0]

    @property
    def flaky_items(self) -> list[ItemStabilityResult]:
        return [r for r in self.item_results if r.is_flaky]

    @property
    def run_pass_rates(self) -> list[float]:
        return [r.pass_rate for r in self.per_run_reports]

    @property
    def mean_pass_rate(self) -> float:
        rates = self.run_pass_rates
        return sum(rates) / len(rates) if rates else 0.0


def _aggregate_item_results(
    item_id: str,
    expected_verdict: str,
    metadata: dict,
    run_results: list[GoldenTestResult],
) -> ItemStabilityResult:
    """Combine results for a single item across multiple runs."""
    num_runs = len(run_results)
    pass_count = sum(1 for r in run_results if r.passed)
    error_count = sum(1 for r in run_results if r.error is not None)
    fail_count = num_runs - pass_count - error_count
    evaluated = num_runs - error_count
    pass_rate = (pass_count / evaluated) if evaluated > 0 else 0.0

    verdicts = [r.actual_verdict for r in run_results]
    overall_scores = [r.actual_score for r in run_results if r.error is None]

    score_mean = (sum(overall_scores) / len(overall_scores)) if overall_scores else 0.0
    score_sd = _std_dev(overall_scores)

    metric_scores: dict[str, list[float]] = {}
    for r in run_results:
        if r.error is not None:
            continue
        for m in r.metrics:
            metric_scores.setdefault(m.name, []).append(m.score)

    metric_stats = []
    for name, scores in sorted(metric_scores.items()):
        metric_stats.append(MetricStats(
            name=name,
            mean=sum(scores) / len(scores),
            min=min(scores),
            max=max(scores),
            std_dev=_std_dev(scores),
            scores=scores,
        ))

    return ItemStabilityResult(
        item_id=item_id,
        expected_verdict=expected_verdict,
        metadata=metadata,
        num_runs=num_runs,
        pass_count=pass_count,
        fail_count=fail_count,
        error_count=error_count,
        pass_rate=round(pass_rate, 4),
        verdicts=verdicts,
        overall_scores=overall_scores,
        score_mean=round(score_mean, 4),
        score_std_dev=round(score_sd, 4),
        metric_stats=metric_stats,
        run_results=run_results,
    )


async def run_golden_stability_test(
    num_runs: int = 10,
    threshold: float = 0.98,
    max_concurrent: int = 5,
    verbose: bool = False,
    on_run_complete: Optional[callable] = None,
    on_item_progress: Optional[callable] = None,
) -> StabilityReport:
    """
    Run the golden dataset evaluation multiple times and aggregate
    per-item stability statistics.

    Args:
        num_runs: How many times to run the full evaluation suite.
        threshold: Pass-rate threshold forwarded to each individual run.
        max_concurrent: Maximum concurrent evaluations per run.
        verbose: If True, log extra detail per item.
        on_run_complete: Optional callback(run_number, num_runs, run_report)
                         called after each completed run.
        on_item_progress: Optional callback(completed_items, total_items)
                          called after each item within a run.

    Returns:
        StabilityReport with per-item pass rates, score distributions,
        and flaky-item identification.
    """
    start_time = time.time()
    per_run_reports: list[GoldenTestReport] = []

    for run_idx in range(1, num_runs + 1):
        if verbose:
            logger.info(f"Starting stability run {run_idx}/{num_runs}")

        report = await run_golden_test(
            threshold=threshold,
            max_concurrent=max_concurrent,
            verbose=verbose,
            on_progress=on_item_progress,
        )
        per_run_reports.append(report)

        if on_run_complete is not None:
            on_run_complete(run_idx, num_runs, report)

    duration = time.time() - start_time
    return build_stability_report(per_run_reports, num_runs, duration)


def build_stability_report(
    per_run_reports: list[GoldenTestReport],
    num_runs: int,
    duration: float,
) -> StabilityReport:
    """Build a StabilityReport from a list of completed run reports.

    This is separated from the run loop so callers (e.g. the CLI) can
    build a partial report from whatever runs completed before an
    interruption.
    """
    item_run_results: dict[str, list[GoldenTestResult]] = {}
    item_expected: dict[str, str] = {}
    item_metadata: dict[str, dict] = {}

    for report in per_run_reports:
        for r in report.results:
            item_run_results.setdefault(r.item_id, []).append(r)
            item_expected[r.item_id] = r.expected_verdict
            item_metadata[r.item_id] = r.metadata

    item_results = [
        _aggregate_item_results(
            item_id,
            item_expected[item_id],
            item_metadata[item_id],
            results,
        )
        for item_id, results in item_run_results.items()
    ]
    item_results.sort(key=lambda r: (r.is_stable, r.pass_rate))

    return StabilityReport(
        num_runs=num_runs,
        num_items=len(item_results),
        per_run_reports=per_run_reports,
        item_results=item_results,
        duration_seconds=round(duration, 2),
    )
