"""
Base classes and interfaces for LLM abstraction layer.

This module defines the core abstractions that all LLM providers must implement,
providing a unified interface regardless of the underlying API.
"""

from abc import ABC, abstractmethod
from contextvars import ContextVar
from typing import Any, Dict, List, Literal, Optional, Tuple, Type, Union

from pydantic import BaseModel, Field


class LLMMessage(BaseModel):
    """
    Standard message format for LLM conversations.
    
    Attributes:
        role: Message role - "system", "user", or "assistant"
        content: The message content (text)
    """
    role: str = Field(..., description="Message role: system, user, or assistant")
    content: str = Field(..., description="Message content")
    
    def to_dict(self) -> dict:
        """Convert to dictionary format."""
        return {"role": self.role, "content": self.content}


class LLMImage(BaseModel):
    """
    Image input for vision-enabled models.
    
    Provide either a URL or base64-encoded data.
    
    Attributes:
        url: Direct URL to the image
        base64_data: Base64-encoded image data
        media_type: MIME type (e.g., "image/png", "image/jpeg")
    """
    url: Optional[str] = Field(None, description="Image URL")
    base64_data: Optional[str] = Field(None, description="Base64-encoded image data")
    media_type: str = Field("image/png", description="Image MIME type")
    
    def __init__(self, **data):
        super().__init__(**data)
        if not self.url and not self.base64_data:
            raise ValueError("Either url or base64_data must be provided")


class LLMInterface(ABC):
    """
    Abstract interface for LLM providers.
    
    All providers (OpenAI, Anthropic, etc.) must implement this interface
    to provide a consistent API regardless of the underlying implementation.
    
    The interface abstracts away provider-specific details like:
    - Authentication and API keys
    - Request/response formats
    - Tool calling mechanisms
    - Image handling
    - Structured output generation
    
    Subclasses should encapsulate all provider-specific logic within
    their implementations, keeping the interface clean and simple.
    """
    
    def __init__(
        self,
        model: str,
        api_key: str,
        timeout: float = 60.0,
        temperature: float = 0.0,
        max_tokens: int = 16384,
        thinking_level: Optional[str] = None,
        service_tier: Optional[str] = None
    ):
        """
        Initialize the LLM interface.

        Args:
            model: Model identifier (e.g., "gpt-5", "claude-sonnet-4-5")
            api_key: API key for the provider
            timeout: Request timeout in seconds
            temperature: Sampling temperature (0.0 = deterministic)
            max_tokens: Maximum tokens in response
            thinking_level: Thinking/reasoning level ("MINIMAL", "LOW",
                "MEDIUM", "HIGH"). Only used by the Gemini adapter;
                ignored by OpenAI and Anthropic adapters.
            service_tier: Inference tier ("flex", "standard", or None).
                "flex" uses off-peak capacity at 50% cost with higher latency.
                Only used by the Gemini adapter.
        """
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.thinking_level = thinking_level
        self.service_tier = service_tier
        self._last_usage: Optional[dict] = None
    
    @abstractmethod
    async def generate_text(
        self,
        messages: List[LLMMessage],
        **kwargs
    ) -> str:
        """
        Generate plain text response from the model.
        
        Args:
            messages: Conversation messages (system, user, etc.)
            **kwargs: Provider-specific parameter overrides
            
        Returns:
            Generated text string
            
        Raises:
            Exception: Provider-specific errors should be caught and
                      re-raised as standard exceptions
        """
        pass
    
    @abstractmethod
    async def generate_structured(
        self,
        messages: List[LLMMessage],
        response_schema: Type[BaseModel],
        **kwargs
    ) -> BaseModel:
        """
        Generate structured output matching a Pydantic schema.
        
        This method ensures the model returns output that conforms to
        the specified schema, using provider-specific mechanisms like
        structured output APIs or tool calling.
        
        Args:
            messages: Conversation messages
            response_schema: Pydantic model class defining the output structure
            **kwargs: Provider-specific parameter overrides
            
        Returns:
            Instance of response_schema populated with model output
            
        Raises:
            ValueError: If schema cannot be satisfied or parsing fails
            Exception: Provider-specific errors
        """
        pass
    
    @abstractmethod
    async def generate_with_vision(
        self,
        messages: List[LLMMessage],
        images: List[LLMImage],
        response_schema: Optional[Type[BaseModel]] = None,
        **kwargs
    ) -> Union[str, BaseModel]:
        """
        Generate response with image inputs (vision models).
        
        Args:
            messages: Conversation messages
            images: List of images to analyze
            response_schema: Optional schema for structured output
            **kwargs: Provider-specific parameter overrides
            
        Returns:
            Text string if no schema provided, otherwise instance of response_schema
            
        Raises:
            NotImplementedError: If model doesn't support vision
            ValueError: If images cannot be processed
            Exception: Provider-specific errors
        """
        pass
    
    async def generate_with_media(
        self,
        messages: List[LLMMessage],
        media_url: Optional[str] = None,
        media_bytes: Optional[bytes] = None,
        media_mime_type: str = "video/mp4",
        images: Optional[List[LLMImage]] = None,
        response_schema: Optional[Type[BaseModel]] = None,
        additional_media: Optional[List[Tuple[bytes, str]]] = None,
        **kwargs
    ) -> Union[str, BaseModel]:
        """
        Generate response with media input — video or audio (Gemini-only).

        Not all providers support media. The default implementation raises
        NotImplementedError; only GeminiAdapter overrides this.

        Gemini treats video and audio identically at the API level — both
        are passed as Part objects with inline_data or file_data.

        Args:
            messages: Conversation messages
            media_url: YouTube URL or direct media URL
            media_bytes: Raw media bytes (for inline or File API)
            media_mime_type: MIME type of the media (video/* or audio/*)
            images: Optional list of images to include alongside the media
            response_schema: Optional schema for structured output
            additional_media: Extra media files as (bytes, mime_type) tuples,
                each added as a separate Part alongside the primary media.
            **kwargs: Provider-specific parameter overrides

        Returns:
            Text string if no schema, otherwise instance of response_schema

        Raises:
            NotImplementedError: If the provider does not support media
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support media input"
        )

    @property
    def supports_media(self) -> bool:
        """
        Check if this model supports video/audio media inputs.

        Returns:
            True if model can process video/audio, False otherwise
        """
        return False

    @property
    @abstractmethod
    def supports_vision(self) -> bool:
        """
        Check if this model supports image inputs.
        
        Returns:
            True if model can process images, False otherwise
        """
        pass
    
    @property
    @abstractmethod
    def supports_structured_output(self) -> bool:
        """
        Check if this model supports native structured output.
        
        Returns:
            True if model has native structured output support
        """
        pass
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"{self.__class__.__name__}(model='{self.model}')"


_request_usage_var: ContextVar[Optional[Dict[str, Dict[str, int]]]] = ContextVar(
    "inceptbench_request_usage",
    default=None,
)


def init_usage_tracking() -> None:
    """Reset request-scoped token usage tracking."""
    _request_usage_var.set({})


def _safe_int(value: Any) -> int:
    try:
        return int(value) if value is not None else 0
    except Exception:
        return 0


def record_llm_usage(model: str, usage: Optional[dict]) -> None:
    """Aggregate token usage (by model) into the current request context."""
    tracked = _request_usage_var.get()
    if tracked is None or not usage:
        return

    model_usage = tracked.get(model)
    if model_usage is None:
        model_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        tracked[model] = model_usage

    model_usage["input_tokens"] += _safe_int(usage.get("input"))
    model_usage["output_tokens"] += _safe_int(usage.get("output"))
    total = usage.get("total")
    if total is None:
        total = _safe_int(usage.get("input")) + _safe_int(usage.get("output"))
    model_usage["total_tokens"] += _safe_int(total)


def get_usage_summary() -> Optional[list[dict]]:
    """Return aggregated token usage by model for the current request context."""
    tracked = _request_usage_var.get()
    if tracked is None:
        return None
    items = [
        {"model": model, **usage}
        for model, usage in tracked.items()
    ]
    items.sort(key=lambda x: x["model"])
    return items


class UsageTrackedLLM(LLMInterface):
    """Wrapper that aggregates adapter token usage into request-scoped totals."""

    def __init__(self, inner: LLMInterface):
        self._inner = inner
        self.model = inner.model
        self.api_key = inner.api_key
        self.timeout = inner.timeout
        self.temperature = inner.temperature
        self.max_tokens = inner.max_tokens
        self.thinking_level = getattr(inner, "thinking_level", None)
        self.service_tier = getattr(inner, "service_tier", None)
        self._last_usage: Optional[dict] = None

    def _capture_and_record_usage(self) -> None:
        usage = getattr(self._inner, "_last_usage", None)
        if usage:
            self._inner._last_usage = None
            cleaned = {k: v for k, v in usage.items() if v is not None}
            self._last_usage = cleaned or None
            record_llm_usage(self.model, self._last_usage)
        else:
            self._last_usage = None

    async def generate_text(self, messages: List[LLMMessage], **kwargs) -> str:
        result = await self._inner.generate_text(messages, **kwargs)
        self._capture_and_record_usage()
        return result

    async def generate_structured(
        self,
        messages: List[LLMMessage],
        response_schema: Type[BaseModel],
        **kwargs
    ) -> BaseModel:
        result = await self._inner.generate_structured(messages, response_schema, **kwargs)
        self._capture_and_record_usage()
        return result

    async def generate_with_vision(
        self,
        messages: List[LLMMessage],
        images: List[LLMImage],
        response_schema: Optional[Type[BaseModel]] = None,
        **kwargs
    ) -> Union[str, BaseModel]:
        result = await self._inner.generate_with_vision(messages, images, response_schema, **kwargs)
        self._capture_and_record_usage()
        return result

    async def generate_with_media(
        self,
        messages: List[LLMMessage],
        media_url: Optional[str] = None,
        media_bytes: Optional[bytes] = None,
        media_mime_type: str = "video/mp4",
        images: Optional[List[LLMImage]] = None,
        response_schema: Optional[Type[BaseModel]] = None,
        additional_media: Optional[List[Tuple[bytes, str]]] = None,
        **kwargs
    ) -> Union[str, BaseModel]:
        result = await self._inner.generate_with_media(
            messages, media_url=media_url, media_bytes=media_bytes,
            media_mime_type=media_mime_type, images=images,
            response_schema=response_schema,
            additional_media=additional_media, **kwargs
        )
        self._capture_and_record_usage()
        return result

    @property
    def supports_media(self) -> bool:
        return self._inner.supports_media

    @property
    def supports_vision(self) -> bool:
        return self._inner.supports_vision

    @property
    def supports_structured_output(self) -> bool:
        return self._inner.supports_structured_output

