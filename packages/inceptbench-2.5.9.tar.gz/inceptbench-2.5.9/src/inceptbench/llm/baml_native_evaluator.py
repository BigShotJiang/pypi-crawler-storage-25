"""
BAML native evaluator — calls Gemini through BAML's client directly.

This module provides BAML-native evaluation functions as the DEFAULT path for
all content types in BaseEvaluator._call_llm_evaluator(). BAML replaces
generate_structured() and handles all content types including those with images
and SVGs (passed as baml_py.Image objects).

How it works:
  BAML calls Gemini directly using its own GeminiFlash client.
  It injects {{ ctx.output_format }} into the prompt for schema-guided output.
  It handles JSON parsing and type coercion internally.
  Images (SVGs rendered to PNG, URL images) are passed natively via baml_py.Image.

What is preserved:
  The full evaluation system prompt (curriculum context, image analysis,
  programmatic checks, generation prompt context, etc.) is passed as
  `system_prompt` — the same prompt built by BaseEvaluator is used verbatim.
"""

import asyncio
import logging
import random
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

BAML_MAX_RETRIES = 3
BAML_BASE_DELAY = 4.0

# Consensus scoring: for borderline overall scores in this range, run a second
# BAML call and average. If the two runs disagree on bucket, run a 3rd tiebreaker.
CONSENSUS_SCORE_RANGE = (0.75, 0.90)
CONSENSUS_RUNS = 2


def _merge_binary_metrics(results: List[Any], winner: Any) -> None:
    """Majority-vote binary metric scores across all collected results.

    Inspects every metric-like attribute (objects with a ``.score``) on the
    winner. For binary metrics (scores are exactly 0.0 or 1.0) where the
    collected results disagree, copies the majority-vote metric onto the
    winner and logs the override.

    Non-binary metrics (continuous scores) and the ``overall`` metric are
    left untouched.
    """
    if not results or len(results) < 2:
        return

    from collections import Counter

    # Collect metric-like field names using Pydantic model registry
    metric_fields: set = set()
    for r in results:
        field_names = (
            r.model_fields.keys()           # Pydantic v2
            if hasattr(r, "model_fields")
            else getattr(r, "__fields__", {}).keys()  # Pydantic v1
        )
        for attr in field_names:
            if attr == "overall":
                continue
            val = getattr(r, attr, None)
            if val is not None and hasattr(val, "score"):
                metric_fields.add(attr)

    for field in metric_fields:
        scores = []
        score_to_result = {}
        for r in results:
            val = getattr(r, field, None)
            if val is not None and hasattr(val, "score"):
                scores.append(val.score)
                score_to_result[val.score] = r

        if len(set(scores)) <= 1:
            continue  # unanimous

        # Only merge binary metrics (exactly 0.0 or 1.0)
        if not all(s in (0.0, 1.0) for s in scores):
            continue

        counter = Counter(scores)
        majority_score, majority_count = counter.most_common(1)[0]

        if majority_count > len(scores) / 2:
            winner_metric = getattr(winner, field, None)
            if winner_metric is not None and winner_metric.score != majority_score:
                logger.info(
                    "Per-metric consensus override: %s flipped (%s) "
                    "→ majority %.0f",
                    field,
                    ", ".join(f"{s:.0f}" for s in scores),
                    majority_score,
                )
                majority_result = score_to_result[majority_score]
                setattr(winner, field, getattr(majority_result, field))
        # else: tie — keep winner's value


def _score_bucket(score: float) -> str:
    """Classify a score into a verdict bucket for consensus comparison."""
    if score >= 0.99:
        return "SUPERIOR"
    elif score >= 0.85:
        return "ACCEPTABLE"
    else:
        return "INFERIOR"


def _baml_metric_to_dict(metric: Any) -> dict:
    """Convert a BAML MetricResult object to a plain dict for Pydantic validation."""
    return {
        "internal_reasoning": getattr(metric, "internal_reasoning", None),
        "reasoning": getattr(metric, "reasoning", "No issues found."),
        "suggested_improvements": getattr(metric, "suggested_improvements", None),
        "score": float(getattr(metric, "score", 0.0)),
    }


def _baml_article_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML ArticleEvaluationResult to a plain dict for ArticleEvaluationResult(**d).

    Used by the offline parser smoke-test in ``tests/test_e2e_sample.py``;
    no production caller — articles route through
    ``BaseEvaluator._call_llm_evaluator`` → ``GeminiAdapter.generate_structured``,
    not through BAML's native ``EvaluateArticle``.
    """
    required_fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "curriculum_alignment",
        "teaching_quality",
        "stimulus_quality",
        "diction_and_sentence_structure",
        "integrity_check",
    )
    optional_fields = (
        "interest_relevance",
        "worked_examples",
        "practice_problems",
        "follows_direct_instruction",
        "historical_significance",
        "cause_and_effect_clarity",
        "reflection_quality",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "article"),
        "overall_rating": getattr(baml_result, "overall_rating", None),
    }
    for field in required_fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    for field in optional_fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    return d


def _baml_question_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML QuestionEvaluationResult to a plain dict for QuestionEvaluationResult(**d)."""
    required_fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "curriculum_alignment",
        "clarity_precision",
        "specification_compliance",
        "reveals_misconceptions",
        "difficulty_alignment",
        "passage_reference",
        "distractor_quality",
        "stimulus_quality",
        "mastery_learning_alignment",
        "integrity_check",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "question"),
    }
    for field in required_fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    # Optional field
    interest = getattr(baml_result, "interest_relevance", None)
    if interest is not None:
        d["interest_relevance"] = _baml_metric_to_dict(interest)
    return d


async def _single_baml_question_call(
    system_prompt: str,
    content: str,
    images: Optional[List[Any]],
    max_retries: int,
) -> "Any":
    """Run a single BAML question evaluation call with retries. Returns raw Pydantic result."""
    from inceptbench.models.question import QuestionEvaluationResult
    from baml_client import b

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            baml_result = await b.EvaluateQuestion(
                system_prompt=system_prompt,
                content=content,
                images=images or None,
            )
            d = _baml_question_to_dict(baml_result)
            result = QuestionEvaluationResult(**d)
            result.overall.score = result.constrained_overall_score()
            return result
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = BAML_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "BAML question eval failed (attempt %d/%d): %s. Retrying in %.1fs...",
                    attempt + 1, max_retries + 1, e, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BAML question eval exhausted retries (%d attempts): %s",
                    max_retries + 1, e,
                )

    raise RuntimeError(
        f"BAML question evaluation failed after {max_retries + 1} attempts: {last_error}"
    )


async def call_baml_question(
    system_prompt: str,
    content: str,
    max_retries: int = BAML_MAX_RETRIES,
    images: Optional[List[Any]] = None,
) -> "Any":  # -> QuestionEvaluationResult (deferred import)
    """
    Evaluate a question via BAML native call.

    For borderline overall scores (CONSENSUS_SCORE_RANGE), runs a second call
    and averages the scores. If the two runs disagree on bucket verdict, runs a
    3rd tiebreaker and majority-votes.

    Binary metric flips across consensus runs are majority-voted back to the
    winner to reduce per-metric drift that drives overall-score variance.

    Args:
        system_prompt: Full evaluation context from BaseEvaluator.
        content: The question content to evaluate.
        max_retries: Maximum retry attempts on failure.
        images: Optional list of baml_py.Image objects (SVGs/URL images).

    Returns:
        QuestionEvaluationResult Pydantic instance.
    """
    all_results: List[Any] = []

    result1 = await _single_baml_question_call(system_prompt, content, images, max_retries)
    all_results.append(result1)
    score1 = result1.overall.score

    low, high = CONSENSUS_SCORE_RANGE
    if not (low <= score1 <= high):
        # Outside borderline range — return immediately.
        # Idempotent safety net: re-apply constrained score in case a future
        # _single_baml_*_call forgets to do so.
        if hasattr(result1, "constrained_overall_score"):
            result1.overall.score = result1.constrained_overall_score()
        return result1

    # Borderline: run a second call
    logger.info(
        "Borderline score %.3f in consensus range [%.2f, %.2f] — running second BAML call",
        score1, low, high,
    )
    result2 = await _single_baml_question_call(system_prompt, content, images, max_retries)
    all_results.append(result2)
    score2 = result2.overall.score

    bucket1 = _score_bucket(score1)
    bucket2 = _score_bucket(score2)

    if bucket1 == bucket2:
        # Agreement: average the overall score, majority-vote binary metrics
        avg_score = round((score1 + score2) / 2, 4)
        logger.info(
            "Consensus agreement (%s): averaging scores %.3f + %.3f = %.3f",
            bucket1, score1, score2, avg_score,
        )
        result1.overall.score = avg_score
        _merge_binary_metrics(all_results, result1)
        if hasattr(result1, "constrained_overall_score"):
            result1.overall.score = result1.constrained_overall_score()
        return result1

    # Disagreement: run a tiebreaker 3rd call
    logger.info(
        "Consensus disagreement (%s vs %s): running tiebreaker call",
        bucket1, bucket2,
    )
    result3 = await _single_baml_question_call(system_prompt, content, images, max_retries)
    all_results.append(result3)
    score3 = result3.overall.score
    bucket3 = _score_bucket(score3)

    # Majority vote: pick the bucket that appears at least twice
    buckets = [bucket1, bucket2, bucket3]
    scores = [score1, score2, score3]
    if bucket3 == bucket1:
        # bucket1 wins (result1 + result3 agree)
        avg_score = round((score1 + score3) / 2, 4)
        logger.info("Tiebreaker: %s wins (runs 1+3), avg %.3f", bucket1, avg_score)
        result1.overall.score = avg_score
        _merge_binary_metrics(all_results, result1)
        if hasattr(result1, "constrained_overall_score"):
            result1.overall.score = result1.constrained_overall_score()
        return result1
    else:
        # bucket2 wins (result2 + result3 agree, or all disagree → pick median)
        avg_score = round((score2 + score3) / 2, 4)
        logger.info("Tiebreaker: %s wins (runs 2+3), avg %.3f", bucket2, avg_score)
        result2.overall.score = avg_score
        _merge_binary_metrics(all_results, result2)
        if hasattr(result2, "constrained_overall_score"):
            result2.overall.score = result2.constrained_overall_score()
        return result2


def _baml_quiz_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML QuizEvaluationResult to a plain dict for QuizEvaluationResult(**d)."""
    fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "concept_coverage",
        "difficulty_distribution",
        "non_repetitiveness",
        "test_preparedness",
        "answer_balance",
        "stimulus_quality",
        "integrity_check",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "quiz"),
    }
    for field in fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    return d


def _baml_mcqset_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML McqSetEvaluationResult to a plain dict for McqSetEvaluationResult(**d)."""
    fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "concept_coverage",
        "difficulty_distribution",
        "stimulus_quality",
        "non_repetitiveness",
        "test_preparedness",
        "answer_balance",
        "integrity_check",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "mcq_set"),
    }
    for field in fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    return d


def _baml_reading_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML ReadingEvaluationResult to a plain dict for ReadingEvaluationResult(**d)."""
    fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "reading_level_match",
        "length_appropriateness",
        "topic_focus",
        "engagement",
        "accuracy_and_logic",
        "question_quality",
        "stimulus_quality",
        "integrity_check",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "reading"),
    }
    for field in fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    return d


def _baml_other_to_dict(baml_result: Any) -> Dict[str, Any]:
    """Convert a BAML OtherEvaluationResult to a plain dict for OtherEvaluationResult(**d)."""
    fields = (
        "overall",
        "factual_accuracy",
        "educational_accuracy",
        "localization_quality",
        "educational_value",
        "direct_instruction_alignment",
        "content_appropriateness",
        "clarity_and_organization",
        "engagement",
        "stimulus_quality",
        "integrity_check",
    )
    d: Dict[str, Any] = {
        "content_type": getattr(baml_result, "content_type", "other"),
    }
    for field in fields:
        metric = getattr(baml_result, field, None)
        if metric is not None:
            d[field] = _baml_metric_to_dict(metric)
    return d


async def call_baml_quiz(
    system_prompt: str,
    content: str,
    max_retries: int = BAML_MAX_RETRIES,
    images: Optional[List[Any]] = None,
) -> "Any":  # -> QuizEvaluationResult (deferred import)
    """Evaluate a quiz via BAML native call."""
    from inceptbench.models.quiz import QuizEvaluationResult
    from baml_client import b

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            baml_result = await b.EvaluateQuiz(
                system_prompt=system_prompt,
                content=content,
                images=images or None,
            )
            d = _baml_quiz_to_dict(baml_result)
            result = QuizEvaluationResult(**d)
            result.overall.score = result.constrained_overall_score()
            return result
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = BAML_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "BAML quiz eval failed (attempt %d/%d): %s. Retrying in %.1fs...",
                    attempt + 1, max_retries + 1, e, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BAML quiz eval exhausted retries (%d attempts): %s",
                    max_retries + 1, e,
                )

    raise RuntimeError(
        f"BAML quiz evaluation failed after {max_retries + 1} attempts: {last_error}"
    )


async def call_baml_mcqset(
    system_prompt: str,
    content: str,
    max_retries: int = BAML_MAX_RETRIES,
    images: Optional[List[Any]] = None,
) -> "Any":  # -> McqSetEvaluationResult (deferred import)
    """Evaluate an MCQ set via BAML native call."""
    from inceptbench.models.mcq_set import McqSetEvaluationResult
    from baml_client import b

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            baml_result = await b.EvaluateMcqSet(
                system_prompt=system_prompt,
                content=content,
                images=images or None,
            )
            d = _baml_mcqset_to_dict(baml_result)
            result = McqSetEvaluationResult(**d)
            result.overall.score = result.constrained_overall_score()
            return result
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = BAML_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "BAML mcqset eval failed (attempt %d/%d): %s. Retrying in %.1fs...",
                    attempt + 1, max_retries + 1, e, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BAML mcqset eval exhausted retries (%d attempts): %s",
                    max_retries + 1, e,
                )

    raise RuntimeError(
        f"BAML mcqset evaluation failed after {max_retries + 1} attempts: {last_error}"
    )


async def call_baml_reading(
    system_prompt: str,
    content: str,
    max_retries: int = BAML_MAX_RETRIES,
    images: Optional[List[Any]] = None,
) -> "Any":  # -> ReadingEvaluationResult (deferred import)
    """Evaluate a reading passage via BAML native call."""
    from inceptbench.models.reading import ReadingEvaluationResult
    from baml_client import b

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            baml_result = await b.EvaluateReading(
                system_prompt=system_prompt,
                content=content,
                images=images or None,
            )
            d = _baml_reading_to_dict(baml_result)
            result = ReadingEvaluationResult(**d)
            result.overall.score = result.constrained_overall_score()
            return result
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = BAML_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "BAML reading eval failed (attempt %d/%d): %s. Retrying in %.1fs...",
                    attempt + 1, max_retries + 1, e, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BAML reading eval exhausted retries (%d attempts): %s",
                    max_retries + 1, e,
                )

    raise RuntimeError(
        f"BAML reading evaluation failed after {max_retries + 1} attempts: {last_error}"
    )


async def call_baml_other(
    system_prompt: str,
    content: str,
    max_retries: int = BAML_MAX_RETRIES,
    images: Optional[List[Any]] = None,
) -> "Any":  # -> OtherEvaluationResult (deferred import)
    """Evaluate general educational content via BAML native call."""
    from inceptbench.models.other import OtherEvaluationResult
    from baml_client import b

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            baml_result = await b.EvaluateOther(
                system_prompt=system_prompt,
                content=content,
                images=images or None,
            )
            d = _baml_other_to_dict(baml_result)
            result = OtherEvaluationResult(**d)
            result.overall.score = result.constrained_overall_score()
            return result
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = BAML_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "BAML other eval failed (attempt %d/%d): %s. Retrying in %.1fs...",
                    attempt + 1, max_retries + 1, e, delay,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BAML other eval exhausted retries (%d attempts): %s",
                    max_retries + 1, e,
                )

    raise RuntimeError(
        f"BAML other evaluation failed after {max_retries + 1} attempts: {last_error}"
    )
