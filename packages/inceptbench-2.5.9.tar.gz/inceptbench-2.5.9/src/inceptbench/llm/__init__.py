"""
LLM abstraction layer for unified model access.

This module provides a provider-agnostic interface for interacting with
different LLM providers (OpenAI, Anthropic, Gemini) through a common API.

Evaluation paths are routed through BAML (see ``baml_native_evaluator``
and the ``call_baml_*`` functions) rather than the raw adapter methods
on ``LLMInterface``. The ``LLMFactory`` / ``LLMInterface`` objects
exported here remain available for non-evaluation utilities
(factory smoke checks, ad-hoc tooling).
"""

from .base import LLMImage, LLMInterface, LLMMessage
from .config import LLMConfig, get_llm_config
from .factory import LLMFactory
from .tracing import LangfuseTracedLLM, is_langfuse_enabled, flush as langfuse_flush

__all__ = [
    "LLMFactory",
    "LLMInterface",
    "LLMMessage",
    "LLMImage",
    "LLMConfig",
    "get_llm_config",
    "LangfuseTracedLLM",
    "is_langfuse_enabled",
    "langfuse_flush",
]

