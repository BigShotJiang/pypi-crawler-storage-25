"""
Compatibility shim for baml_article_parser.

This module was removed in the BAML-sole-path refactor (commit 15b8b5a).
parse_article_result() is re-exposed here using the new b.parse.EvaluateArticle()
path so tests and any external callers don't break.
"""

from typing import Any, Dict

from baml_client import b
from inceptbench.models.article import ArticleEvaluationResult


def _baml_metric_to_dict(metric: Any) -> Dict[str, Any]:
    """Convert a BAML MetricResult to a plain dict for Pydantic."""
    return {
        "internal_reasoning": getattr(metric, "internal_reasoning", None),
        "reasoning": getattr(metric, "reasoning", "No issues found."),
        "suggested_improvements": getattr(metric, "suggested_improvements", None),
        "score": float(getattr(metric, "score", 0.0)),
    }


def _parse_with_baml(raw_text: str):
    """Parse raw LLM text into an ArticleEvaluationResult dict via BAML coercion."""
    from inceptbench.llm.baml_native_evaluator import _baml_article_to_dict
    baml_result = b.parse.EvaluateArticle(raw_text)
    return _baml_article_to_dict(baml_result)


def _parse_with_json_repair(raw_text: str):
    """json-repair was removed; delegates to BAML coercion."""
    return _parse_with_baml(raw_text)


def parse_article_result(raw_text: str) -> ArticleEvaluationResult:
    """
    Parse a raw LLM response string into an ArticleEvaluationResult.
    Uses BAML native coercion (b.parse.EvaluateArticle) as the sole path.
    """
    d = _parse_with_baml(raw_text)
    return ArticleEvaluationResult(**d)
