"""
Google Gemini adapter for the LLM abstraction layer.

This module provides an adapter for Google's Gemini models
that implements the LLMInterface.

Includes retry logic with exponential backoff for transient errors
(timeouts, rate limits, empty responses).

Retry configuration: 3 retries with 4s exponential backoff.
"""

import asyncio
import base64
import json
import re
import logging
import random
from typing import List, Optional, Tuple, Type, Union

from google import genai
from google.genai import types

# ServiceTier was added in google-genai 1.70+; guard for older SDK versions.
try:
    _GEMINI_FLEX_TIER = types.ServiceTier.FLEX
    _HAS_SERVICE_TIER = True
except AttributeError:
    _GEMINI_FLEX_TIER = None
    _HAS_SERVICE_TIER = False
from pydantic import BaseModel, ValidationError

from inceptbench.llm.base import LLMImage, LLMInterface, LLMMessage
from inceptbench.llm.config import get_service_tier_override
from inceptbench.utils.failure_tracker import AttemptError, FailureTracker

logger = logging.getLogger(__name__)

# Retry configuration: 5 retries with 4s exponential backoff. The earlier
# 3-retry budget was tight enough that long-form article evaluations on the
# issue-#392 fixture could exhaust all attempts during a regional Gemini
# 504/UNAVAILABLE spike. Cap is bounded by ``GEMINI_BASE_DELAY * 2^5 ≈ 128s``
# of accumulated backoff.
GEMINI_MAX_RETRIES = 5
GEMINI_BASE_DELAY = 4.0

# Flex tier: first N attempts use flex, remaining fall back to standard
FLEX_MAX_ATTEMPTS = 2
FLEX_BASE_DELAY = 15.0  # longer delay for flex retries (capacity may open up)

# Fixed seed for reproducible outputs. Gemini makes a "best effort" to
# return the same response for repeated requests when seed is fixed and
# temperature is 0.  Claude and OpenAI don't support seed, so this is
# Gemini-specific.
GEMINI_FIXED_SEED = 42

# ---------------------------------------------------------------------------
# Generalized prompts for two-pass agentic vision (all educational subjects)
# ---------------------------------------------------------------------------

_VISION_PASS_SUFFIX = """

Do NOT write code. Use only your visual understanding.

Return ONLY a JSON object (no markdown fences):
{"description": "what the image shows", "needs_measurement": true/false, "items": [{"label": "A", "answer": "...", "explanation": "..."}, ...]}

Set needs_measurement to true if the answer requires: counting evenly-spaced divisions; measuring fractions, ratios, or lengths; reading exact values from charts/graphs/maps; extracting scale readings; or any precision measurement (math, science, history, ELA). Set to false for counting discrete objects, identifying shapes/labels, or reading clear text/equations."""

_MEASUREMENT_PROMPT = """You previously analyzed this image visually and found:
{vision_result}

Now verify and refine the answers using Python code execution for precise measurement. Load the image with OpenCV/PIL and measure pixel distances, ratios, or other quantities that require precision.

Subject-specific guidance:
- Math: fractions (denominator = number of PARTS, not dividers), number lines, bar/pie chart values (read y-axis labels first for scale), geometry angles/lengths/areas.
- Science: diagram scales, experimental data from charts, axis values.
- History/Social Studies: map distances, timeline positions, statistical chart values.
- ELA: chart/graph values in informational contexts.

For bar charts: read the ACTUAL axis tick labels to establish scale, then measure bar positions. For divided regions: N vertical dividers create N+1 segments; N marks including endpoints create N-1 segments. Do NOT re-count discrete objects — trust the visual counts. Only use code for measurement precision.

Your code must end by printing the final JSON so it is captured: print(json.dumps(result)). The array must be of the form [{"label": "CategoryName", "answer": "value", "explanation": "..."}, ...]."""


def _check_needs_measurement(text: str) -> bool:
    """Parse Pass 1 JSON response for needs_measurement flag."""
    if not text or not text.strip():
        return False
    clean = re.sub(r"^```\w*\n(.*)\n```$", r"\1", text.strip(), flags=re.DOTALL).strip()
    try:
        data = json.loads(clean)
        if isinstance(data, dict):
            return bool(data.get("needs_measurement", False))
        return False
    except (json.JSONDecodeError, Exception):
        return '"needs_measurement": true' in text.lower() or '"needs_measurement":true' in text.lower()


def _clean_schema_for_gemini(schema: dict) -> dict:
    """
    Recursively strip fields that Gemini's API doesn't support from a
    JSON Schema dict (e.g. ``additionalProperties``, ``$defs``, ``title``,
    ``$ref``, ``default``).

    Pydantic v2 emits these by default in ``model_json_schema()`` and the
    Google GenAI SDK converts them to snake_case (``additional_properties``)
    which Gemini rejects with ``INVALID_ARGUMENT``.
    """
    STRIP_KEYS = {"additionalProperties", "title", "$defs", "$ref", "default"}
    if isinstance(schema, dict):
        cleaned = {}
        for k, v in schema.items():
            if k in STRIP_KEYS:
                continue
            cleaned[k] = _clean_schema_for_gemini(v)
        return cleaned
    if isinstance(schema, list):
        return [_clean_schema_for_gemini(item) for item in schema]
    return schema


def _pydantic_to_gemini_schema(model_class: Type[BaseModel]) -> dict:
    """
    Convert a Pydantic model class to a Gemini-compatible JSON schema dict.

    Handles Pydantic v2's ``anyOf`` pattern for ``Optional`` fields by
    inlining the non-null type and marking the field ``nullable``.
    """
    raw = model_class.model_json_schema()

    # Resolve $defs references first
    defs = raw.pop("$defs", {})

    def _resolve_refs(obj, _resolving=None):
        if _resolving is None:
            _resolving = set()
        if isinstance(obj, dict):
            if "$ref" in obj:
                ref_path = obj["$ref"]  # e.g. "#/$defs/SomeModel"
                ref_name = ref_path.split("/")[-1]
                if ref_name in _resolving:
                    # Circular reference — break the cycle with a generic object
                    return {"type": "object"}
                if ref_name in defs:
                    _resolving.add(ref_name)
                    result = _resolve_refs(defs[ref_name], _resolving)
                    _resolving.discard(ref_name)
                    return result
                logger.warning(
                    "Unresolvable $ref %r (available defs: %s)",
                    ref_path,
                    list(defs.keys()),
                )
                remaining = {k: v for k, v in obj.items() if k != "$ref"}
                return _resolve_refs(remaining, _resolving) if remaining else {}
            return {k: _resolve_refs(v, _resolving) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_resolve_refs(item, _resolving) for item in obj]
        return obj

    resolved = _resolve_refs(raw, set())

    # Convert anyOf[type, null] patterns to nullable
    def _fix_optional(obj):
        if isinstance(obj, dict):
            if "anyOf" in obj:
                variants = obj["anyOf"]
                non_null = [v for v in variants if v.get("type") != "null"]
                has_null = any(v.get("type") == "null" for v in variants)
                if has_null and len(non_null) == 1:
                    merged = {**obj, **non_null[0]}
                    merged.pop("anyOf", None)
                    merged["nullable"] = True
                    return {k: _fix_optional(v) for k, v in merged.items()}
            return {k: _fix_optional(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_fix_optional(item) for item in obj]
        return obj

    fixed = _fix_optional(resolved)
    return _clean_schema_for_gemini(fixed)


class GeminiAdapter(LLMInterface):
    """
    Adapter for Google Gemini API.
    
    This adapter handles all Gemini-specific details:
    - Authentication and API client setup
    - Request/response format conversion
    - Structured output via response schemas
    - Vision input handling
    - Error handling and retries
    """
    
    def __init__(
        self,
        model: str,
        api_key: str,
        timeout: float = 60.0,
        temperature: float = 0.0,
        max_tokens: int = 16384,
        thinking_level: Optional[str] = None,
        service_tier: Optional[str] = None
    ):
        """
        Initialize Gemini adapter.

        Args:
            model: Model identifier (e.g., "gemini-3-pro-preview")
            api_key: Google AI API key
            timeout: Request timeout in seconds
            temperature: Sampling temperature (0.0 = deterministic)
            max_tokens: Maximum tokens in response
            thinking_level: Thinking level for Gemini 3+ models.
                One of "MINIMAL", "LOW", "MEDIUM", "HIGH", or None to
                use the model's default.
            service_tier: Inference tier ("flex" or None/standard).
                "flex" uses off-peak capacity at 50% cost. Controlled via
                GEMINI_SERVICE_TIER env var; can be overridden per-request.
        """
        super().__init__(
            model=model,
            api_key=api_key,
            timeout=timeout,
            temperature=temperature,
            max_tokens=max_tokens,
            thinking_level=thinking_level,
            service_tier=service_tier,
        )
        # Pass an HTTP timeout to the SDK so stalled streams raise
        # DeadlineExceeded instead of blocking forever. HttpOptions.timeout is
        # in milliseconds; self.timeout is set at construction time (default 60s).
        self.client = genai.Client(
            api_key=self.api_key,
            http_options=types.HttpOptions(timeout=int(self.timeout * 1000)),
        )

        # Build ThinkingConfig if a thinking level was requested.
        # The `thinking_level` kwarg was added in google-genai >=1.x;
        # older versions only expose `include_thoughts: bool`.
        self._thinking_config = None
        if self.thinking_level:
            try:
                self._thinking_config = types.ThinkingConfig(
                    thinking_level=self.thinking_level,
                )
            except Exception:
                self._thinking_config = types.ThinkingConfig(
                    include_thoughts=True,
                )
                logger.warning(
                    "google-genai version does not support thinking_level=%s; "
                    "falling back to include_thoughts=True",
                    self.thinking_level,
                )
            logger.debug(f"Gemini thinking enabled: level={self.thinking_level}")

        if self.service_tier:
            logger.info(f"Gemini service tier: {self.service_tier}")
        logger.debug(f"Gemini adapter initialized: {self.model}")

    # ----- Flex tier helpers -----

    def _resolve_service_tier(self) -> Optional[str]:
        """Get effective service tier (per-request override > init-time config).

        Returns "flex", "standard", or None (= standard/default).
        """
        override = get_service_tier_override()
        if override is not None:
            return override if override != "standard" else None
        return self.service_tier if self.service_tier != "standard" else None

    def _tier_for_attempt(self, attempt: int) -> Optional[str]:
        """Return the service tier to use for a given retry attempt.

        When running in flex mode, the first FLEX_MAX_ATTEMPTS use flex;
        subsequent attempts fall back to standard (None).
        """
        tier = self._resolve_service_tier()
        if tier == "flex" and attempt >= FLEX_MAX_ATTEMPTS:
            return None  # standard fallback
        return tier

    def _retry_delay(self, attempt: int, tier: Optional[str]) -> float:
        """Compute exponential-backoff delay, longer when using flex."""
        if tier == "flex":
            return FLEX_BASE_DELAY * (2 ** attempt) + random.uniform(0, 2)
        return GEMINI_BASE_DELAY * (2 ** attempt) + random.uniform(0, 1)

    def _capture_usage(self, response):
        """Extract token usage from Gemini response and store in _last_usage."""
        self._last_usage = None
        try:
            meta = getattr(response, "usage_metadata", None)
            if meta:
                self._last_usage = {
                    "input": getattr(meta, "prompt_token_count", None),
                    "output": getattr(meta, "candidates_token_count", None),
                    "total": getattr(meta, "total_token_count", None),
                }
        except Exception:
            pass

    @staticmethod
    def _safe_extract_text(response) -> str:
        """Extract text from a GenerateContentResponse without using .text property.

        The SDK's .text property can raise KeyError on responses whose JSON
        contains keys like "label". Manually walking the parts avoids this.
        """
        if response is None:
            return ""
        try:
            return (response.text or "").strip()
        except Exception:
            pass
        # Fallback: walk parts manually
        text_parts = []
        try:
            for candidate in (response.candidates or []):
                for part in (candidate.content.parts or []):
                    try:
                        t = part.text
                        if t:
                            text_parts.append(t)
                    except Exception:
                        pass
                    try:
                        cer = part.code_execution_result
                        if cer and cer.output:
                            text_parts.append(cer.output)
                    except Exception:
                        pass
        except Exception:
            pass
        return "".join(text_parts).strip()

    async def _stream_and_collect(
        self,
        contents: list,
        config: types.GenerateContentConfig,
    ) -> Tuple[str, Optional[str]]:
        """
        Run Gemini generate_content_stream in a thread and collect full response text.
        Used for vision calls to avoid blocking/timeouts on long code-execution runs.
        Returns concatenated text from all parts (including code execution output).
        Also captures token usage and finish reason from the final streaming chunk.
        """
        adapter = self

        def _run_stream():
            text_parts = []
            last_chunk = None
            finish_reason = None
            for chunk in adapter.client.models.generate_content_stream(
                model=adapter.model,
                contents=contents,
                config=config,
            ):
                last_chunk = chunk
                if not chunk.candidates:
                    continue
                for candidate in chunk.candidates:
                    try:
                        cand_finish_reason = getattr(candidate, "finish_reason", None)
                        if cand_finish_reason is not None:
                            finish_reason = str(cand_finish_reason)
                    except Exception:
                        pass
                    try:
                        parts = candidate.content.parts or []
                    except Exception:
                        continue
                    for part in parts:
                        try:
                            t = part.text
                            if t:
                                text_parts.append(t)
                        except Exception:
                            pass
                        try:
                            cer = part.code_execution_result
                            if cer and cer.output:
                                text_parts.append(cer.output)
                        except Exception:
                            pass
            if last_chunk is not None:
                adapter._capture_usage(last_chunk)
            return "".join(text_parts).strip(), finish_reason

        return await asyncio.to_thread(_run_stream)

    async def generate_text(
        self,
        messages: List[LLMMessage],
        **kwargs
    ) -> str:
        """
        Generate plain text using Gemini API.
        
        Includes retry logic with exponential backoff for transient errors.
        
        Args:
            messages: Conversation messages
            **kwargs: Override temperature, max_tokens, etc.
            
        Returns:
            Generated text string
        """
        # Extract system instruction if present
        system_instruction = next(
            (msg.content for msg in messages if msg.role == "system"),
            None
        )
        
        # Build contents from non-system messages
        contents = []
        for msg in messages:
            if msg.role != "system":
                role = "user" if msg.role == "user" else "model"
                contents.append(types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=msg.content)]
                ))
        
        last_error = None
        attempt_errors: List[AttemptError] = []

        for attempt in range(GEMINI_MAX_RETRIES + 1):
            effective_tier = self._tier_for_attempt(attempt)

            try:
                config = types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=kwargs.get("temperature", self.temperature),
                    max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                    seed=GEMINI_FIXED_SEED,
                    thinking_config=self._thinking_config,
                )
                if effective_tier == "flex" and _HAS_SERVICE_TIER:
                    config.service_tier = _GEMINI_FLEX_TIER

                response = await self.client.aio.models.generate_content(
                    model=self.model,
                    contents=contents,
                    config=config,
                )

                # Use safe extractor to avoid KeyError when response JSON contains
                # keys like "label" (common in match questions with categories[].label)
                text = self._safe_extract_text(response)
                if not text:
                    raise ValueError("Gemini returned empty response")

                self._capture_usage(response)

                # Record recovery if this wasn't the first attempt
                if attempt > 0:
                    FailureTracker.record_recovered(
                        component="gemini_adapter.generate_text",
                        message=f"Succeeded on attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}",
                        context={"model": self.model, "service_tier": effective_tier or "standard"},
                        attempt_errors=attempt_errors if attempt_errors else None
                    )

                return text

            except Exception as e:
                last_error = e
                error_str = str(e).lower()

                # Record this attempt's error
                attempt_errors.append(AttemptError(
                    attempt=attempt + 1,
                    error_message=f"[tier={effective_tier or 'standard'}] {e}"
                ))

                # Check if error is retryable. Includes Gemini's 504
                # ``DEADLINE_EXCEEDED`` ("Deadline expired before operation
                # could complete.") — load-spike deadlines and the
                # provider-side timeout are both transient.
                is_retryable = any(keyword in error_str for keyword in [
                    "timeout", "rate", "quota", "429", "503", "500", "504",
                    "overloaded", "empty response", "none",
                    "deadline", "service unavailable",
                ])

                if is_retryable and attempt < GEMINI_MAX_RETRIES:
                    next_tier = self._tier_for_attempt(attempt + 1)
                    if effective_tier == "flex" and next_tier != "flex":
                        logger.warning(
                            f"Flex tier exhausted after {attempt + 1} attempts, "
                            f"falling back to standard tier"
                        )
                    delay = self._retry_delay(attempt, effective_tier)
                    logger.warning(
                        f"Gemini text generation error (attempt {attempt + 1}/"
                        f"{GEMINI_MAX_RETRIES + 1}, tier={effective_tier or 'standard'}): "
                        f"{e}. Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Gemini text generation failed after all retries: {e}")
                    FailureTracker.record_exhausted(
                        component="gemini_adapter.generate_text",
                        error_message=str(e),
                        context={"model": self.model, "attempts": attempt + 1},
                        attempt_errors=attempt_errors
                    )
                    raise

        # Should not reach here, but just in case
        raise last_error

    async def generate_structured(
        self,
        messages: List[LLMMessage],
        response_schema: Type[BaseModel],
        **kwargs
    ) -> BaseModel:
        """
        Generate structured output using Gemini's native JSON mode.
        
        Includes retry logic with exponential backoff for transient errors.
        
        Args:
            messages: Conversation messages
            response_schema: Pydantic model class for output structure
            **kwargs: Override temperature, max_tokens, etc.
            
        Returns:
            Instance of response_schema with model output
        """
        # Extract system instruction if present
        system_instruction = next(
            (msg.content for msg in messages if msg.role == "system"),
            None
        )
        
        # Build contents from non-system messages
        contents = []
        for msg in messages:
            if msg.role != "system":
                role = "user" if msg.role == "user" else "model"
                contents.append(types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=msg.content)]
                ))
        
        last_error = None
        attempt_errors: List[AttemptError] = []

        # Convert Pydantic schema to Gemini-compatible dict
        gemini_schema = _pydantic_to_gemini_schema(response_schema)

        for attempt in range(GEMINI_MAX_RETRIES + 1):
            effective_tier = self._tier_for_attempt(attempt)

            try:
                config = types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    temperature=kwargs.get("temperature", self.temperature),
                    max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                    response_mime_type="application/json",
                    response_schema=gemini_schema,
                    seed=GEMINI_FIXED_SEED,
                    thinking_config=self._thinking_config,
                )
                if effective_tier == "flex" and _HAS_SERVICE_TIER:
                    config.service_tier = _GEMINI_FLEX_TIER

                response = await self.client.aio.models.generate_content(
                    model=self.model,
                    contents=contents,
                    config=config,
                )

                # Use safe extractor to avoid KeyError when response JSON contains
                # keys like "label" (common in match questions with categories[].label)
                structured_text = self._safe_extract_text(response)
                if not structured_text:
                    raise ValueError("Gemini returned empty response (None)")

                self._capture_usage(response)

                # Detect truncation from thinking consuming the output budget
                if response.candidates:
                    fr = getattr(response.candidates[0], "finish_reason", None)
                    if fr and "max_tokens" in str(fr).lower():
                        logger.warning(
                            "Gemini structured response truncated (finish_reason=%s); "
                            "max_output_tokens=%s may be too low with thinking_level=%s. "
                            "Response length: %d chars",
                            fr, config.max_output_tokens, self.thinking_level,
                            len(structured_text),
                        )
                        raise ValueError(
                            f"Gemini response truncated (finish_reason={fr}). "
                            f"Increase max_output_tokens (currently {config.max_output_tokens})"
                        )

                # Parse the JSON response into the schema
                parsed_data = json.loads(structured_text)

                # Record recovery if this wasn't the first attempt
                if attempt > 0:
                    FailureTracker.record_recovered(
                        component="gemini_adapter.generate_structured",
                        message=f"Succeeded on attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}",
                        context={"model": self.model, "schema": response_schema.__name__, "service_tier": effective_tier or "standard"},
                        attempt_errors=attempt_errors if attempt_errors else None
                    )

                return response_schema(**parsed_data)

            except Exception as e:
                last_error = e
                error_str = str(e).lower()

                # Record this attempt's error
                attempt_errors.append(AttemptError(
                    attempt=attempt + 1,
                    error_message=f"[tier={effective_tier or 'standard'}] {e}"
                ))

                # Check if error is retryable. Includes Gemini's 504
                # ``DEADLINE_EXCEEDED`` ("Deadline expired before operation
                # could complete.") and ``UNAVAILABLE`` — both transient
                # provider-side throttling.
                is_retryable = any(keyword in error_str for keyword in [
                    "timeout", "rate", "quota", "429", "503", "500", "504",
                    "overloaded", "empty response", "none", "nonetype",
                    "non-parseable", "truncated", "unparseable json",
                    "deadline", "unavailable",
                ])

                if is_retryable and attempt < GEMINI_MAX_RETRIES:
                    next_tier = self._tier_for_attempt(attempt + 1)
                    if effective_tier == "flex" and next_tier != "flex":
                        logger.warning(
                            f"Flex tier exhausted after {attempt + 1} attempts, "
                            f"falling back to standard tier"
                        )
                    delay = self._retry_delay(attempt, effective_tier)
                    logger.warning(
                        f"Gemini structured output error (attempt {attempt + 1}/"
                        f"{GEMINI_MAX_RETRIES + 1}, tier={effective_tier or 'standard'}): "
                        f"{e}. Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"Gemini structured output generation failed for "
                        f"{response_schema.__name__} after all retries: {e}"
                    )
                    FailureTracker.record_exhausted(
                        component="gemini_adapter.generate_structured",
                        error_message=str(e),
                        context={"model": self.model, "schema": response_schema.__name__, "attempts": attempt + 1},
                        attempt_errors=attempt_errors
                    )
                    raise

        # Should not reach here, but just in case
        raise last_error

    async def generate_with_vision(
        self,
        messages: List[LLMMessage],
        images: List[LLMImage],
        response_schema: Optional[Type[BaseModel]] = None,
        enable_code_execution: bool = False,
        **kwargs
    ) -> Union[str, BaseModel]:
        """
        Generate response with image inputs (Gemini vision).
        
        Handles both plain text and structured output with vision.
        Images can be provided as URLs or base64-encoded data.
        Includes retry logic with exponential backoff for transient errors.
        
        Args:
            messages: Conversation messages
            images: List of images to analyze
            response_schema: Optional schema for structured output
            enable_code_execution: Enable code execution tool for agentic vision
            **kwargs: Override temperature, max_tokens, etc.
            
        Returns:
            Text string if no schema, otherwise instance of response_schema
        """
        if not self.supports_vision:
            raise NotImplementedError(
                f"Model {self.model} does not support vision inputs"
            )
        
        # Extract system instruction if present
        system_instruction = next(
            (msg.content for msg in messages if msg.role == "system"),
            None
        )
        
        # Build parts list with text and images (image_parts kept for two-pass reuse)
        text_parts = []
        for msg in messages:
            if msg.role == "user":
                text_parts.append(types.Part.from_text(text=msg.content))
        image_parts = []
        for img in images:
            if img.url:
                image_parts.append(types.Part.from_uri(
                    file_uri=img.url,
                    mime_type=img.media_type or "image/png"
                ))
            elif img.base64_data:
                image_bytes = base64.b64decode(img.base64_data)
                image_parts.append(types.Part.from_bytes(
                    data=image_bytes,
                    mime_type=img.media_type or "image/png"
                ))
        parts = text_parts + image_parts
        contents = [types.Content(role="user", parts=parts)]

        def _parse_final_response(response_text: str):
            """Parse final response into response_schema if requested."""
            if not response_schema:
                return response_text.strip()
            try:
                data = json.loads(response_text)
                return response_schema(**data)
            except ValidationError:
                # Pydantic ValidationError means the JSON was valid but the schema
                # didn't match — retrying won't help, re-raise as-is.
                raise
            except (ValueError, Exception) as exc:
                raise ValueError(
                    "Gemini vision returned non-parseable structured output. "
                    f"Response preview: {response_text[:300]!r}"
                ) from exc

        last_error = None
        attempt_errors: List[AttemptError] = []

        for attempt in range(GEMINI_MAX_RETRIES + 1):
            effective_tier = self._tier_for_attempt(attempt)

            try:
                if enable_code_execution:
                    # Two-pass agentic vision: Pass 1 visual only, Pass 2 code exec if needed
                    user_text = "\n\n".join(msg.content for msg in messages if msg.role == "user")
                    pass1_parts = [types.Part.from_text(text=user_text + _VISION_PASS_SUFFIX)] + image_parts
                    pass1_contents = [types.Content(role="user", parts=pass1_parts)]
                    config_pass1 = types.GenerateContentConfig(
                        system_instruction=system_instruction,
                        temperature=kwargs.get("temperature", self.temperature),
                        max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                        seed=GEMINI_FIXED_SEED,
                        thinking_config=self._thinking_config,
                    )
                    if effective_tier == "flex" and _HAS_SERVICE_TIER:
                        config_pass1.service_tier = _GEMINI_FLEX_TIER

                    # Pass 1 uses non-streaming async API (no code exec, fast)
                    pass1_response = await self.client.aio.models.generate_content(
                        model=self.model,
                        contents=pass1_contents,
                        config=config_pass1,
                    )
                    pass1_text = self._safe_extract_text(pass1_response)
                    self._capture_usage(pass1_response)
                    if not pass1_text:
                        raise ValueError("Gemini returned empty response (Pass 1)")

                    if not _check_needs_measurement(pass1_text):
                        if attempt > 0:
                            FailureTracker.record_recovered(
                                component="gemini_adapter.generate_with_vision",
                                message=f"Succeeded on attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}",
                                context={"model": self.model, "image_count": len(images), "service_tier": effective_tier or "standard"},
                                attempt_errors=attempt_errors if attempt_errors else None,
                            )
                        return _parse_final_response(pass1_text)

                    # Pass 2: measurement with code execution.
                    # Use LOW thinking to prevent thought-signature accumulation
                    # across code-execution turns from exceeding the context window.
                    # Pass 1 already did the deep visual reasoning; pass 2 just
                    # needs to write and run measurement code.
                    measure_text = _MEASUREMENT_PROMPT.replace("{vision_result}", pass1_text)
                    pass2_parts = [types.Part.from_text(text=measure_text)] + image_parts
                    pass2_contents = [types.Content(role="user", parts=pass2_parts)]
                    pass2_thinking = types.ThinkingConfig(thinking_level="LOW")
                    config_pass2 = types.GenerateContentConfig(
                        system_instruction=system_instruction,
                        temperature=kwargs.get("temperature", self.temperature),
                        max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                        tools=[types.Tool(code_execution=types.ToolCodeExecution())],
                        seed=GEMINI_FIXED_SEED,
                        thinking_config=pass2_thinking,
                    )
                    if effective_tier == "flex" and _HAS_SERVICE_TIER:
                        config_pass2.service_tier = _GEMINI_FLEX_TIER

                    pass2_text, pass2_finish_reason = await self._stream_and_collect(pass2_contents, config_pass2)
                    if pass2_finish_reason and "too_many_tool_calls" in pass2_finish_reason.lower():
                        logger.warning(
                            "Gemini code execution hit TOO_MANY_TOOL_CALLS; "
                            "using partial response (%d chars)",
                            len(pass2_text),
                        )
                        if not pass2_text:
                            logger.warning(
                                "Pass 2 returned empty text after TOO_MANY_TOOL_CALLS; "
                                "falling back to Pass 1 response"
                            )
                            pass2_text = pass1_text
                    if not pass2_text:
                        raise ValueError("Gemini returned empty response (Pass 2)")
                    response_text = pass2_text
                else:
                    # Single pass, streaming (no code exec)
                    config = types.GenerateContentConfig(
                        system_instruction=system_instruction,
                        temperature=kwargs.get("temperature", self.temperature),
                        max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                        seed=GEMINI_FIXED_SEED,
                        thinking_config=self._thinking_config,
                    )
                    if effective_tier == "flex" and _HAS_SERVICE_TIER:
                        config.service_tier = _GEMINI_FLEX_TIER
                    if response_schema:
                        config.response_mime_type = "application/json"
                        config.response_schema = _pydantic_to_gemini_schema(response_schema)
                    response_text, finish_reason = await self._stream_and_collect(contents, config)
                    if not response_text:
                        raise ValueError("Gemini returned empty response (None)")
                    if finish_reason and "max_tokens" in finish_reason.lower():
                        logger.warning(
                            "Gemini response truncated (finish_reason=%s); "
                            "max_output_tokens=%s may be too low with thinking_level=%s. "
                            "Response length: %d chars",
                            finish_reason,
                            config.max_output_tokens,
                            self.thinking_level,
                            len(response_text),
                        )
                        raise ValueError(
                            f"Gemini response truncated (finish_reason={finish_reason}). "
                            f"Increase max_output_tokens (currently {config.max_output_tokens})"
                        )

                if attempt > 0:
                    FailureTracker.record_recovered(
                        component="gemini_adapter.generate_with_vision",
                        message=f"Succeeded on attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}",
                        context={"model": self.model, "image_count": len(images), "service_tier": effective_tier or "standard"},
                        attempt_errors=attempt_errors if attempt_errors else None,
                    )

                return _parse_final_response(response_text)

            except Exception as e:
                last_error = e
                error_str = str(e).lower()
                attempt_errors.append(AttemptError(
                    attempt=attempt + 1,
                    error_message=f"[tier={effective_tier or 'standard'}] {e}"
                ))
                is_retryable = any(keyword in error_str for keyword in [
                    "timeout", "rate", "quota", "429", "503", "500", "504",
                    "overloaded", "empty response", "none", "nonetype",
                    "non-parseable", "truncated", "unparseable json",
                    "deadline", "unavailable",
                ])
                if is_retryable and attempt < GEMINI_MAX_RETRIES:
                    next_tier = self._tier_for_attempt(attempt + 1)
                    if effective_tier == "flex" and next_tier != "flex":
                        logger.warning(
                            f"Flex tier exhausted after {attempt + 1} attempts, "
                            f"falling back to standard tier"
                        )
                    delay = self._retry_delay(attempt, effective_tier)
                    logger.warning(
                        f"Gemini vision error (attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}, "
                        f"tier={effective_tier or 'standard'}): {e}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Gemini vision generation failed after all retries: {e}")
                    FailureTracker.record_exhausted(
                        component="gemini_adapter.generate_with_vision",
                        error_message=str(e),
                        context={"model": self.model, "image_count": len(images), "attempts": attempt + 1},
                        attempt_errors=attempt_errors,
                    )
                    raise

        raise last_error

    @property
    def supports_vision(self) -> bool:
        """Check if this model supports vision inputs."""
        # Most Gemini models support vision
        return "gemini" in self.model.lower()

    @property
    def supports_media(self) -> bool:
        """Check if this model supports video/audio media inputs."""
        return "gemini" in self.model.lower()

    def _build_schema_hint(self, schema: Type[BaseModel]) -> str:
        """
        Build a human-readable schema hint for inclusion in prompts.

        Creates a simplified JSON example showing the expected structure
        for Gemini to follow, since we can't use response_schema for complex
        recursive types (like subcontent_evaluations).
        """
        visible_props = set(
            schema.model_json_schema().get("properties", {}).keys()
        )

        fields = {
            name: info
            for name, info in schema.model_fields.items()
            if name in visible_props
        }

        example = {}
        notes = []

        for field_name, field_info in fields.items():
            annotation = field_info.annotation

            if field_name == "subcontent_evaluations":
                example[field_name] = None
            elif field_name == "content_type":
                if field_info.default is not None and hasattr(field_info.default, 'value'):
                    example[field_name] = str(field_info.default.value)
                else:
                    example[field_name] = "article"
                notes.append(
                    "content_type MUST be exactly one of: "
                    "'question', 'quiz', 'fiction_reading', 'nonfiction_reading', 'article', 'other'. "
                    "Do NOT use 'video' or any other value."
                )
            elif "MetricResult" in str(annotation):
                example[field_name] = {
                    "score": 1.0,
                    "internal_reasoning": "Detailed step-by-step analysis...",
                    "reasoning": "Human-readable explanation of the score",
                    "suggested_improvements": None
                }
            else:
                example[field_name] = f"<{field_name}>"

        result = json.dumps(example, indent=2)
        if notes:
            result += "\n\nIMPORTANT NOTES:\n" + "\n".join(f"- {note}" for note in notes)
        return result

    async def generate_with_media(
        self,
        messages: List[LLMMessage],
        media_url: Optional[str] = None,
        media_bytes: Optional[bytes] = None,
        media_mime_type: str = "video/mp4",
        images: Optional[List[LLMImage]] = None,
        response_schema: Optional[Type[BaseModel]] = None,
        additional_media: Optional[List[Tuple[bytes, str]]] = None,
        **kwargs
    ) -> Union[str, BaseModel]:
        """
        Generate response with media input — video or audio.

        Gemini treats video and audio identically at the API level.
        Both are passed as Part objects with inline_data or file_data.

        Handles media input following Gemini documentation:
        - YouTube URLs: pass directly via file_data
        - Inline bytes: for media <20MB
        - File API: for media >20MB (uploads, uses, then deletes)

        Per Gemini best practices, the text prompt is placed AFTER the media.

        For complex schemas with recursive types (like subcontent_evaluations),
        we use JSON mode with schema hints in the system instruction instead of
        response_schema, since Gemini can't resolve recursive $ref definitions.

        Args:
            messages: Conversation messages
            media_url: YouTube URL or direct media URL
            media_bytes: Raw media bytes (for inline or File API)
            media_mime_type: MIME type of the media (video/* or audio/*)
            images: Optional list of images to include
            response_schema: Optional schema for structured output
            **kwargs: Override temperature, max_tokens, etc.

        Returns:
            Text string if no schema, otherwise instance of response_schema

        Raises:
            ValueError: If neither media_url nor media_bytes provided
        """
        if not media_url and not media_bytes:
            raise ValueError("Either media_url or media_bytes must be provided")

        system_instruction = next(
            (msg.content for msg in messages if msg.role == "system"),
            None
        )

        parts = []
        uploaded_file = None

        try:
            if media_url:
                logger.info(f"Adding media URL to request: {media_url[:80]}...")
                parts.append(types.Part(
                    file_data=types.FileData(
                        file_uri=media_url,
                        mime_type=media_mime_type
                    )
                ))
            elif media_bytes:
                media_size_mb = len(media_bytes) / (1024 * 1024)

                if len(media_bytes) <= 20 * 1024 * 1024:
                    logger.info(f"Adding inline media ({media_size_mb:.1f}MB, {media_mime_type})")
                    parts.append(types.Part(
                        inline_data=types.Blob(
                            data=media_bytes,
                            mime_type=media_mime_type
                        )
                    ))
                else:
                    logger.info(f"Uploading media via File API ({media_size_mb:.1f}MB, {media_mime_type})")
                    uploaded_file = await self._upload_media_file(media_bytes, media_mime_type)
                    parts.append(types.Part(
                        file_data=types.FileData(
                            file_uri=uploaded_file.uri,
                            mime_type=media_mime_type
                        )
                    ))

            if additional_media:
                for extra_bytes, extra_mime in additional_media:
                    extra_size_mb = len(extra_bytes) / (1024 * 1024)
                    logger.info(f"Adding additional media ({extra_size_mb:.1f}MB, {extra_mime})")
                    parts.append(types.Part(
                        inline_data=types.Blob(
                            data=extra_bytes,
                            mime_type=extra_mime
                        )
                    ))

            if images:
                for img in images:
                    if img.url:
                        parts.append(types.Part.from_uri(
                            file_uri=img.url,
                            mime_type=img.media_type or "image/png"
                        ))
                    elif img.base64_data:
                        image_bytes = base64.b64decode(img.base64_data)
                        parts.append(types.Part.from_bytes(
                            data=image_bytes,
                            mime_type=img.media_type or "image/png"
                        ))

            for msg in messages:
                if msg.role == "user":
                    parts.append(types.Part.from_text(text=msg.content))

            contents = [types.Content(role="user", parts=parts)]

            enhanced_system_instruction = system_instruction
            if response_schema and system_instruction:
                is_evaluation_schema = (
                    hasattr(response_schema, 'model_fields')
                    and 'content_type' in response_schema.model_fields
                    and 'subcontent_evaluations' in response_schema.model_fields
                )

                if is_evaluation_schema:
                    schema_hint = self._build_schema_hint(response_schema)

                    content_type_default = "article"
                    ct_field = response_schema.model_fields['content_type']
                    if ct_field.default is not None and hasattr(ct_field.default, 'value'):
                        content_type_default = ct_field.default.value

                    enhanced_system_instruction = (
                        f"{system_instruction}\n\n"
                        f"## OUTPUT FORMAT\n"
                        f"You MUST respond with valid JSON matching this structure:\n"
                        f"```json\n{schema_hint}\n```\n\n"
                        f"CRITICAL RULES:\n"
                        f"- Do NOT include any text outside the JSON object.\n"
                        f"- Set content_type to exactly \"{content_type_default}\" "
                        f"(this is media content being evaluated as an {content_type_default}).\n"
                        f"- Set subcontent_evaluations to null (media content has no subcontent).\n"
                        f"- For score fields: use 1.0 for pass, 0.0 for fail (binary metrics), "
                        f"or 0.0-1.0 for 'overall'."
                    )

            thinking_config = None
            if self._thinking_config:
                thinking_config = self._thinking_config

            config = types.GenerateContentConfig(
                system_instruction=enhanced_system_instruction,
                temperature=kwargs.get("temperature", self.temperature),
                max_output_tokens=kwargs.get("max_tokens", self.max_tokens),
                response_mime_type="application/json" if response_schema else None,
                thinking_config=thinking_config,
            )

            last_error = None
            attempt_errors: List[AttemptError] = []

            for attempt in range(GEMINI_MAX_RETRIES + 1):
                effective_tier = self._tier_for_attempt(attempt)

                try:
                    response = await self.client.aio.models.generate_content(
                        model=self.model,
                        contents=contents,
                        config=config
                    )
                    self._capture_usage(response)

                    response_text = self._safe_extract_text(response)
                    if not response_text:
                        raise ValueError("Gemini returned empty response")

                    if attempt > 0:
                        FailureTracker.record_recovered(
                            component="gemini_adapter.generate_with_media",
                            message=f"Succeeded on attempt {attempt + 1}/{GEMINI_MAX_RETRIES + 1}",
                            context={"model": self.model},
                            attempt_errors=attempt_errors if attempt_errors else None
                        )

                    if response_schema:
                        parsed_data = json.loads(response_text)
                        return response_schema.model_validate(parsed_data)
                    else:
                        return response_text

                except Exception as e:
                    last_error = e
                    error_str = str(e).lower()

                    attempt_errors.append(AttemptError(
                        attempt=attempt + 1,
                        error_message=str(e)
                    ))

                    is_retryable = any(keyword in error_str for keyword in [
                        "timeout", "rate", "quota", "429", "503", "500",
                        "overloaded", "empty response", "none", "nonetype",
                        "unterminated", "json", "decode", "parse",
                    ])

                    if is_retryable and attempt < GEMINI_MAX_RETRIES:
                        delay = self._retry_delay(attempt, effective_tier)
                        logger.warning(
                            f"Gemini media error (attempt {attempt + 1}/"
                            f"{GEMINI_MAX_RETRIES + 1}, tier={effective_tier or 'standard'}): "
                            f"{e}. Retrying in {delay:.1f}s..."
                        )
                        await asyncio.sleep(delay)
                    else:
                        logger.error(f"Gemini media generation failed after all retries: {e}")
                        FailureTracker.record_exhausted(
                            component="gemini_adapter.generate_with_media",
                            error_message=str(e),
                            context={"model": self.model, "attempts": attempt + 1},
                            attempt_errors=attempt_errors
                        )
                        raise

            raise last_error

        finally:
            if uploaded_file is not None:
                await self._delete_uploaded_file(uploaded_file)

    async def _upload_media_file(self, media_bytes: bytes, mime_type: str):
        """
        Upload media to Gemini File API for files >20MB.

        Writes to a temp file (SDK expects a file path), uploads, then cleans up.
        Works for both video and audio content.
        """
        import tempfile
        import os

        mime_to_ext = {
            "video/mp4": ".mp4", "video/webm": ".webm", "video/mpeg": ".mpeg",
            "audio/mp3": ".mp3", "audio/wav": ".wav", "audio/flac": ".flac",
            "audio/aac": ".aac", "audio/ogg": ".ogg", "audio/aiff": ".aiff",
        }
        suffix = mime_to_ext.get(mime_type, ".bin")

        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
                f.write(media_bytes)
                temp_path = f.name

            uploaded = self.client.files.upload(file=temp_path)
            logger.info(f"Uploaded media to File API: {uploaded.uri}")
            return uploaded

        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)

    async def _delete_uploaded_file(self, uploaded_file) -> None:
        """Delete an uploaded file from Gemini File API."""
        try:
            self.client.files.delete(name=uploaded_file.name)
            logger.info(f"Deleted uploaded file: {uploaded_file.name}")
        except Exception as e:
            logger.warning(f"Failed to delete uploaded file {uploaded_file.name}: {e}")

    @property
    def supports_structured_output(self) -> bool:
        """Check if this model supports native structured output."""
        # Gemini supports JSON mode with response schemas
        return True

