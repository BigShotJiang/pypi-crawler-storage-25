"""
Langfuse tracing integration for the LLM abstraction layer.

Provides a transparent wrapper around any LLMInterface that records
every LLM call as a Langfuse "generation" event with full input/output
detail, model metadata, latency, token usage, and error status.

The wrapper is injected by LLMFactory when LANGFUSE_SECRET_KEY is set
in the environment.  No adapter or consumer code needs to change.

Environment variables (all read by the Langfuse SDK automatically):
    LANGFUSE_SECRET_KEY   - project secret key (required to enable)
    LANGFUSE_PUBLIC_KEY   - project public key
    LANGFUSE_BASE_URL     - Langfuse server URL (e.g. https://cloud.langfuse.com)
"""

import logging
import os
from typing import List, Optional, Type, Union

from pydantic import BaseModel

from inceptbench.llm.base import LLMImage, LLMInterface, LLMMessage

logger = logging.getLogger(__name__)

_langfuse_available: Optional[bool] = None


def _get_client():
    """Return the singleton Langfuse client via ``get_client()``.

    Returns None when Langfuse is not configured or the SDK is missing.
    """
    global _langfuse_available

    if _langfuse_available is False:
        return None

    if not (os.getenv("LANGFUSE_SECRET_KEY") and os.getenv("LANGFUSE_PUBLIC_KEY")):
        _langfuse_available = False
        return None

    try:
        from langfuse import get_client
        client = get_client()
        if _langfuse_available is None:
            _langfuse_available = True
            logger.info("Langfuse tracing enabled")
        return client
    except Exception as e:
        logger.warning(f"Langfuse SDK not available, tracing disabled: {e}")
        _langfuse_available = False
        return None


def is_langfuse_enabled() -> bool:
    """Return True if Langfuse tracing is configured and available."""
    return _get_client() is not None


def flush():
    """Flush any pending Langfuse events. Call at shutdown."""
    client = _get_client()
    if client is not None:
        try:
            client.flush()
        except Exception as exc:
            logger.debug(f"Langfuse flush failed (non-fatal): {exc}")


class LangfuseTracedLLM(LLMInterface):
    """Transparent wrapper that adds Langfuse generation tracing to any LLMInterface.

    Delegates every call to the wrapped adapter while recording:
    - input messages and image count
    - model name and provider task
    - output (text or structured)
    - token usage (input/output/total) when available from the adapter
    - model_parameters (temperature, max_tokens)
    - wall-clock latency
    - errors (level=ERROR)

    Uses the Langfuse v3 ``start_as_current_observation(as_type="generation")``
    context manager so generations automatically nest inside any active
    ``@observe()`` span.
    """

    def __init__(self, inner: LLMInterface, task: str):
        self._inner = inner
        self._task = task
        self.model = inner.model
        self.api_key = inner.api_key
        self.timeout = inner.timeout
        self.temperature = inner.temperature
        self.max_tokens = inner.max_tokens
        self.thinking_level = getattr(inner, "thinking_level", None)
        self.service_tier = getattr(inner, "service_tier", None)

    def _collect_usage(self) -> Optional[dict]:
        """Read and clear token usage from the inner adapter if available."""
        usage = getattr(self._inner, "_last_usage", None)
        if usage:
            self._inner._last_usage = None
            return {k: v for k, v in usage.items() if v is not None}
        return None

    # ------------------------------------------------------------------
    # LLMInterface implementation
    # ------------------------------------------------------------------

    async def generate_text(self, messages: List[LLMMessage], **kwargs) -> str:
        client = _get_client()
        if client is None:
            return await self._inner.generate_text(messages, **kwargs)

        with client.start_as_current_observation(
            as_type="generation",
            name=f"{self._task}/generate_text",
            model=self._inner.model,
            input=[m.to_dict() for m in messages],
            metadata={"task": self._task},
            model_parameters={"temperature": self._inner.temperature, "max_tokens": self._inner.max_tokens},
        ) as gen:
            try:
                result = await self._inner.generate_text(messages, **kwargs)
                usage = self._collect_usage()
                gen.update(output=result, **({"usage_details": usage} if usage else {}))
                return result
            except Exception as e:
                gen.update(output=str(e), level="ERROR")
                raise

    async def generate_structured(
        self,
        messages: List[LLMMessage],
        response_schema: Type[BaseModel],
        **kwargs,
    ) -> BaseModel:
        client = _get_client()
        if client is None:
            return await self._inner.generate_structured(messages, response_schema, **kwargs)

        with client.start_as_current_observation(
            as_type="generation",
            name=f"{self._task}/generate_structured",
            model=self._inner.model,
            input=[m.to_dict() for m in messages],
            metadata={"task": self._task, "schema": response_schema.__name__},
            model_parameters={"temperature": self._inner.temperature, "max_tokens": self._inner.max_tokens},
        ) as gen:
            try:
                result = await self._inner.generate_structured(messages, response_schema, **kwargs)
                output = result.model_dump() if hasattr(result, "model_dump") else str(result)
                usage = self._collect_usage()
                gen.update(output=output, **({"usage_details": usage} if usage else {}))
                return result
            except Exception as e:
                gen.update(output=str(e), level="ERROR")
                raise

    async def generate_with_vision(
        self,
        messages: List[LLMMessage],
        images: List[LLMImage],
        response_schema: Optional[Type[BaseModel]] = None,
        **kwargs,
    ) -> Union[str, BaseModel]:
        client = _get_client()
        if client is None:
            return await self._inner.generate_with_vision(messages, images, response_schema, **kwargs)

        with client.start_as_current_observation(
            as_type="generation",
            name=f"{self._task}/generate_with_vision",
            model=self._inner.model,
            input=[m.to_dict() for m in messages],
            metadata={
                "task": self._task,
                "image_count": len(images),
                "schema": response_schema.__name__ if response_schema else None,
            },
            model_parameters={"temperature": self._inner.temperature, "max_tokens": self._inner.max_tokens},
        ) as gen:
            try:
                result = await self._inner.generate_with_vision(messages, images, response_schema, **kwargs)
                output = result.model_dump() if hasattr(result, "model_dump") else result
                usage = self._collect_usage()
                gen.update(output=output, **({"usage_details": usage} if usage else {}))
                return result
            except Exception as e:
                gen.update(output=str(e), level="ERROR")
                raise

    async def generate_with_media(
        self,
        messages: List[LLMMessage],
        media_url: Optional[str] = None,
        media_bytes: Optional[bytes] = None,
        media_mime_type: str = "video/mp4",
        images: Optional[List["LLMImage"]] = None,
        response_schema: Optional[Type[BaseModel]] = None,
        additional_media=None,
        **kwargs,
    ) -> Union[str, BaseModel]:
        client = _get_client()
        if client is None:
            return await self._inner.generate_with_media(
                messages, media_url=media_url, media_bytes=media_bytes,
                media_mime_type=media_mime_type, images=images,
                response_schema=response_schema,
                additional_media=additional_media, **kwargs
            )

        with client.start_as_current_observation(
            as_type="generation",
            name=f"{self._task}/generate_with_media",
            model=self._inner.model,
            input=[m.to_dict() for m in messages],
            metadata={
                "task": self._task,
                "media_url": media_url[:80] if media_url else None,
                "has_media_bytes": media_bytes is not None,
                "media_mime_type": media_mime_type,
                "image_count": len(images) if images else 0,
                "schema": response_schema.__name__ if response_schema else None,
            },
            model_parameters={"temperature": self._inner.temperature, "max_tokens": self._inner.max_tokens},
        ) as gen:
            try:
                result = await self._inner.generate_with_media(
                    messages, media_url=media_url, media_bytes=media_bytes,
                    media_mime_type=media_mime_type, images=images,
                    response_schema=response_schema,
                    additional_media=additional_media, **kwargs
                )
                output = result.model_dump() if hasattr(result, "model_dump") else result
                usage = self._collect_usage()
                gen.update(output=output, **({"usage_details": usage} if usage else {}))
                return result
            except Exception as e:
                gen.update(output=str(e), level="ERROR")
                raise

    @property
    def supports_media(self) -> bool:
        return self._inner.supports_media

    @property
    def supports_vision(self) -> bool:
        return self._inner.supports_vision

    @property
    def supports_structured_output(self) -> bool:
        return self._inner.supports_structured_output

    def __repr__(self) -> str:
        return f"LangfuseTracedLLM({self._inner!r}, task='{self._task}')"
