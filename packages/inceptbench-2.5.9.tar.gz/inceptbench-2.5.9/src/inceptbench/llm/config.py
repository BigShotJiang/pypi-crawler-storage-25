"""
Configuration and registry for LLM model assignments.

This module centralizes all model-to-task assignments, making it easy to
experiment with different models for different roles in the system.

To change which model handles a specific task, simply edit the
LLM_TASK_REGISTRY dictionary below.
"""

from contextvars import ContextVar
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class LLMConfig:
    """
    Configuration for a specific LLM instance.

    Attributes:
        provider: Provider name ("openai", "anthropic", "gemini", etc.)
        model: Model identifier (e.g., "gpt-5", "claude-sonnet-4-5")
        timeout: Request timeout in seconds
        temperature: Sampling temperature (default 1.0). Gemini 3 recommends
            1.0 — lower values may cause looping/degraded reasoning.
        max_tokens: Maximum tokens in response
        thinking_level: Thinking/reasoning level for models that support it.
            Gemini 3+: "MINIMAL", "LOW", "MEDIUM", "HIGH" (via ThinkingConfig).
            Ignored by OpenAI and Anthropic adapters.
    """
    provider: str
    model: str
    timeout: float = 60.0
    temperature: float = 1.0
    max_tokens: int = 16384
    thinking_level: Optional[str] = None
    service_tier: Optional[str] = None

    def __post_init__(self):
        """Validate configuration."""
        if self.provider not in ["openai", "anthropic", "gemini"]:
            raise ValueError(
                f"Unknown provider: {self.provider}. "
                f"Supported: openai, anthropic, gemini"
            )
        if self.timeout <= 0:
            raise ValueError(f"Timeout must be positive, got {self.timeout}")
        if not 0.0 <= self.temperature <= 2.0:
            raise ValueError(f"Temperature must be in [0.0, 2.0], got {self.temperature}")
        if self.max_tokens <= 0:
            raise ValueError(f"max_tokens must be positive, got {self.max_tokens}")
        valid_thinking_levels = {None, "MINIMAL", "LOW", "MEDIUM", "HIGH"}
        if self.thinking_level not in valid_thinking_levels:
            raise ValueError(
                f"thinking_level must be one of {valid_thinking_levels - {None}}, "
                f"got {self.thinking_level}"
            )
        valid_service_tiers = {None, "flex", "standard"}
        if self.service_tier not in valid_service_tiers:
            raise ValueError(
                f"service_tier must be one of {valid_service_tiers - {None}}, "
                f"got {self.service_tier}"
            )


# =============================================================================
# TASK REGISTRY - Single source of truth for model assignments
# =============================================================================
#
# This is the ONLY place you need to edit to change which model handles
# which task. All other code uses these assignments automatically.
#
# To experiment with different models:
# 1. Change the provider and/or model for any task
# 2. Adjust timeout/temperature as needed
# 3. Test - no other code changes required!
#
# =============================================================================

LLM_TASK_REGISTRY: Dict[str, LLMConfig] = {
    # Content Classification
    # Determines the type of educational content (question, quiz, passage, etc.)
    "classifier": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=30.0,
        temperature=1.0,
        thinking_level="LOW",
    ),

    # Content Decomposition
    # Breaks down hierarchical content (e.g., quiz -> questions)
    # Note: Higher timeout (5 min) for complex articles with many images or very long content
    "decomposer": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=300.0,
        temperature=1.0,
        thinking_level="MEDIUM",
    ),

    # Content Evaluation
    # Main evaluator for all content types
    # max_tokens: gemini-3-flash-preview has a hard output cap of 65,536 tokens.
    # Setting higher is silently capped by the model. With HIGH thinking, thinking
    # tokens count toward this budget, leaving fewer tokens for the response.
    # For long-form articles (60k+ char responses), HIGH thinking may cause truncation.
    # If truncation occurs in production, reduce thinking_level to MEDIUM or LOW.
    "evaluator": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        # 300s timeout (was 120s) — long-form social-studies articles plus
        # HIGH thinking budget plus N=3 consensus runs were tripping the
        # provider-side 504 DEADLINE_EXCEEDED on the issue #392 fixture.
        # temperature=1.0 is intentional for articles: the N=3 consensus loop
        # needs sampling diversity to filter noisy divergent runs.
        # BAML-dispatched types (Question, Quiz, McqSet) use their own config
        # and are unaffected by this setting.
        timeout=300.0,
        temperature=1.0,
        max_tokens=65536,  # actual model cap (131072 was silently capped)
        thinking_level="HIGH",
    ),

    # Independent factual_accuracy audit (parallel with main question eval).
    # Uses the same factual rubric excerpt as the main evaluator; different model.
    "factual_grounding": LLMConfig(
        provider="openai",
        model="gpt-5.4-mini",
        timeout=120.0,
        temperature=0.0,
        max_tokens=16384,
    ),

    # Wikipedia Search Term Extraction (RAG factual audit)
    # Extracts 3–5 key search terms from a question stem for Wikipedia lookup.
    # Cheap fast model — output is just a few words.
    "wiki_search": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=15.0,
        temperature=0.0,
    ),

    # Answer Choice Extraction (Quiz)
    # Extracts correct/incorrect answer patterns from quizzes
    "answer_extractor": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=60.0,
        temperature=1.0,
        thinking_level="LOW",
    ),


    # Unified Image Analyzer (Vision + Code Execution)
    # Comprehensive image analysis using Gemini Flash with agentic vision
    # Replaces OpenCV + LLM hybrid with pure LLM approach using code execution
    # Handles: object counting, shape classification, measurements, spatial analysis
    "unified_image_analyzer": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=300.0,
        temperature=1.0,
        max_tokens=16384,
        thinking_level="HIGH",
    ),
    
    # Math Content Extraction
    # Extracts structured mathematical expressions from educational content
    # for deterministic SymPy verification.
    # Using Gemini 3 Flash -- fast, cost-effective, supports structured JSON output.
    "math_extractor": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=30.0,
        temperature=1.0,
        thinking_level="LOW",
    ),

    # Media Evaluation (Video / Audio)
    # For content containing video or audio, uses Gemini Pro for best multimodal quality
    "media_evaluator": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=300.0,
        temperature=1.0,
        max_tokens=16384,
        thinking_level="HIGH",
    ),

    # Media Transcription (Audio → Text for decomposition)
    # Uses Flash for cost-efficient transcription before classification/decomposition.
    # Only used for audio files — video transcripts come from YouTube's API.
    "media_transcriber": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=120.0,
        temperature=0.0,
        max_tokens=16384,
    ),

    # Stimulus Reference Extraction
    # Detects whether student-facing text references a visual stimulus.
    # Used as a fallback when regex detection is inconclusive.
    # Simple binary classification — use cheapest model, no thinking needed.
    "stimulus_reference_extractor": LLMConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
        timeout=15.0,
        temperature=0.0,
    ),
}


def get_llm_config(task: str) -> LLMConfig:
    """
    Get the LLM configuration for a specific task.

    Supports env-var overrides for the factual_grounding task:
      FACTUAL_AUDIT_MODEL  — e.g. "gpt-5.2" (default: registry value)
      FACTUAL_AUDIT_PROVIDER — e.g. "openai" (default: registry value)
    
    Args:
        task: Task name from LLM_TASK_REGISTRY
        
    Returns:
        LLMConfig for the specified task
        
    Raises:
        ValueError: If task is not registered
    """
    import os

    if task not in LLM_TASK_REGISTRY:
        available = ", ".join(sorted(LLM_TASK_REGISTRY.keys()))
        raise ValueError(
            f"Unknown task: '{task}'. "
            f"Available tasks: {available}"
        )
    config = LLM_TASK_REGISTRY[task]

    if task == "factual_grounding":
        model_override = os.environ.get("FACTUAL_AUDIT_MODEL", "").strip()
        provider_override = os.environ.get("FACTUAL_AUDIT_PROVIDER", "").strip()
        if model_override or provider_override:
            config = LLMConfig(
                provider=provider_override or config.provider,
                model=model_override or config.model,
                timeout=config.timeout,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                thinking_level=config.thinking_level,
            )

    if task == "evaluator":
        model_override = os.environ.get("EVALUATOR_MODEL", "").strip()
        provider_override = os.environ.get("EVALUATOR_PROVIDER", "").strip()
        temp_override = os.environ.get("EVALUATOR_TEMPERATURE", "").strip()
        if model_override or provider_override or temp_override:
            config = LLMConfig(
                provider=provider_override or config.provider,
                model=model_override or config.model,
                timeout=config.timeout,
                temperature=float(temp_override) if temp_override else config.temperature,
                max_tokens=config.max_tokens,
                thinking_level=config.thinking_level,
            )

    return config


def list_tasks() -> list[str]:
    """
    Get list of all registered tasks.
    
    Returns:
        Sorted list of task names
    """
    return sorted(LLM_TASK_REGISTRY.keys())


def get_task_info(task: str) -> str:
    """
    Get human-readable information about a task's model assignment.
    
    Args:
        task: Task name
        
    Returns:
        Formatted string describing the assignment
        
    Example:
        >>> print(get_task_info("classifier"))
        classifier: openai/gpt-5 (timeout: 30.0s, temp: 0.0)
    """
    config = get_llm_config(task)
    return (
        f"{task}: {config.provider}/{config.model} "
        f"(timeout: {config.timeout}s, temp: {config.temperature})"
    )


# =============================================================================
# Per-request service tier override (set by API, read by GeminiAdapter)
# =============================================================================

_service_tier_override: ContextVar[Optional[str]] = ContextVar(
    "gemini_service_tier_override", default=None
)


def set_service_tier_override(tier: Optional[str]) -> None:
    """Set per-request Gemini service tier override (e.g., 'standard' to bypass flex)."""
    _service_tier_override.set(tier)


def get_service_tier_override() -> Optional[str]:
    """Get per-request service tier override. None means use env var default."""
    return _service_tier_override.get()

