"""
AP curriculum data access package.
"""

