"""JSON repository for AP curriculum facts."""

import json
import logging
import random
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class RepositoryError(Exception):
    """Exception raised for repository operations."""


class JSONFileCurriculumRepository:
    """Loads AP curriculum data from a local JSON file."""

    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            self.data_dir = Path(__file__).parent
        else:
            self.data_dir = Path(data_dir)

        self._curriculum: Optional[List[Dict[str, Any]]] = None
        self._by_course: Dict[str, List[Dict[str, Any]]] = {}

    def _load_curriculum(self) -> List[Dict[str, Any]]:
        if self._curriculum is not None:
            return self._curriculum

        facts_file = self.data_dir / "curriculum_facts.json"
        if not facts_file.exists():
            raise RepositoryError(f"Curriculum data file not found: {facts_file}")

        try:
            with open(facts_file, "r", encoding="utf-8") as f:
                self._curriculum = json.load(f)

            for fact in self._curriculum:
                course = fact.get("course", "APUSH")
                if course not in self._by_course:
                    self._by_course[course] = []
                self._by_course[course].append(fact)

            logger.info("Loaded %s curriculum facts from %s", len(self._curriculum), facts_file)
            return self._curriculum
        except json.JSONDecodeError as e:
            raise RepositoryError(f"Invalid JSON in curriculum file: {e}") from e
        except Exception as e:
            raise RepositoryError(f"Error loading curriculum file: {e}") from e

    def _format_standard(self, fact: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "node_id": str(fact.get("node_id", "")),
            "course": fact.get("course", "APUSH"),
            "unit": int(fact.get("unit", 1)) if fact.get("unit") else 1,
            "topic": fact.get("cluster", fact.get("topic", "")) or "",
            "learning_objective": fact.get("learning_objective", "") or "",
            "curriculum_fact": fact.get("historical_development", fact.get("statement", "")) or "",
            "time_period": fact.get("date", fact.get("time_period", "")) or "",
            "theme": fact.get("theme", "") or "",
        }

    def get_random_standard(self, course: Optional[str] = None, unit: Optional[int] = None) -> Optional[Dict[str, Any]]:
        try:
            curriculum = self._load_curriculum()
            filtered = curriculum
            if course:
                filtered = [f for f in filtered if f.get("course", "").upper() == course.upper()]
            if unit:
                filtered = [f for f in filtered if f.get("unit") == unit]

            if not filtered:
                return None

            return self._format_standard(random.choice(filtered))
        except RepositoryError:
            raise
        except Exception as e:
            logger.error("Error getting random standard: %s", e)
            raise RepositoryError(f"Failed to get random standard: {e}") from e

    def get_random_standards(self, count: int = 5, course: Optional[str] = None) -> List[Dict[str, Any]]:
        try:
            curriculum = self._load_curriculum()
            count = min(count, 50)

            filtered = curriculum
            if course:
                filtered = [f for f in filtered if f.get("course", "").upper() == course.upper()]

            if len(filtered) <= count:
                selected = filtered
            else:
                selected = random.sample(filtered, count)

            return [self._format_standard(f) for f in selected]
        except RepositoryError:
            raise
        except Exception as e:
            logger.error("Error getting random standards: %s", e)
            raise RepositoryError(f"Failed to get random standards: {e}") from e

    def get_standard_by_id(self, node_id: str, course: Optional[str] = None) -> Optional[Dict[str, Any]]:
        try:
            curriculum = self._load_curriculum()
            for fact in curriculum:
                if course and fact.get("course", "").upper() != course.upper():
                    continue
                if fact.get("node_id") == node_id:
                    return self._format_standard(fact)
            return None
        except RepositoryError:
            raise
        except Exception as e:
            logger.error("Error getting standard by ID: %s", e)
            raise RepositoryError(f"Failed to get standard: {e}") from e

    def search_standards(self, query: str, course: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        try:
            curriculum = self._load_curriculum()
            query_lower = query.lower()
            results = []

            for fact in curriculum:
                if course and fact.get("course", "").upper() != course.upper():
                    continue

                searchable = " ".join(
                    [
                        str(fact.get("topic", "")),
                        str(fact.get("learning_objective", "")),
                        str(fact.get("historical_development", "")),
                        str(fact.get("cluster", "")),
                    ]
                ).lower()

                if query_lower in searchable:
                    results.append(self._format_standard(fact))
                    if len(results) >= limit:
                        break

            return results
        except RepositoryError:
            raise
        except Exception as e:
            logger.error("Error searching standards: %s", e)
            raise RepositoryError(f"Failed to search standards: {e}") from e

    def get_total_count(self, course: Optional[str] = None) -> int:
        try:
            curriculum = self._load_curriculum()
            if course:
                return len([f for f in curriculum if f.get("course", "").upper() == course.upper()])
            return len(curriculum)
        except RepositoryError:
            raise
        except Exception as e:
            logger.error("Error getting count: %s", e)
            raise RepositoryError(f"Failed to get count: {e}") from e

