################################################################
#                                                              #
# Curriculum:      Texas Essential Knowledge and Skills (TEKS) #
# Version:         1.4                                         #
# Snapshot Date:   February 26, 2026 21:55:58                  #
#                                                              #
################################################################

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.3+1
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Fair Shares as Fractions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.E
Standard Description: Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Solving Real World Array Multiplication Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.D
Standard Description: Solve a real-world problem involving the total number of objects arranged in an array.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Solving Real World Array Multiplication Problems
Lesson Order: 137.0
Standard ID: TEKS.MATH.CONTENT.3.4.D+1
Standard Description: Solve a real-world problem involving the total number of objects arranged in an array.

Key Concepts:
*None specified*

Learning Objectives:
* Solve multiplication word problems involving equal groups shown in a visual context

Assessment Boundaries:
* Assessment is restricted to: 
  • Each image has at most 9 objects (first factor of the multiplication)
  • There at most 9 pages/panels, the thing the image represents (second factor of the multiplication)
  • Show either portraits or electrical outlets
  • Questions ask the student how many objects there would if there are X pages/panels etc.

Common Misconceptions:
* Student ignores the number of groups and simply reporting the count of objects in one image
* Student miscounts the number of objects in the image and then multiplying with the wrong first factor.
* Student multiplies the number of objects by itself or the number of groups by itself
* Students adds the two numbers instead of multiplying them.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  MCQ with stimulus, 1 image of up to 9 objects. Question asks for a multiplication up to 9 x 9
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Identifying Even and Odd Numbers with Divisibility Rules
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.I
Standard Description: Identify whether a number is even or odd using divisibility rules.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Decomposing Fraction Based on Images
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.D
Standard Description: Identify the decomposition of a fraction into unit fractions based on a given image of a real world situation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Decomposing Fraction Based on Images
Lesson Order: 142.0
Standard ID: TEKS.MATH.CONTENT.3.3.D+1
Standard Description: Identify the decomposition of a fraction into unit fractions based on a given image of a real world situation.

Key Concepts:
*None specified*

Learning Objectives:
* Represent a fraction shown in a visual model as a sum of unit fractions with the same denominator.

Assessment Boundaries:
* Assessment is restricted to:

Fractions less than or equal to 1 whole.

Denominators 2, 3, 4, 6, 8

Students represent a fraction as a sum of unit fractions

Common Misconceptions:
* Adding Numerators Incorrectly
* Assuming Each Person Represents 1 Whole
* Counting Total Parts Instead of Shaded Parts
* Using the Wrong Denominator

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Models of Equivalent Fractions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.F
Standard Description: Identify models of equivalent fractions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Models of Equivalent Fractions
Lesson Order: 144.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+2
Standard Description: Identify models of equivalent fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Select the equivalent fractions and understand why they are equivalent, given a fractional number line with a point
* Select the equivalent pair among fractional bar graph models

Assessment Boundaries:
* Assessment must be restricted to:
- Fractions must have denominators of 2, 3, 4, 6, or 8.
- All fractions must be less than one (proper fractions only).
- No use of mixed numbers or improper fractions.
- No use of variables or algebraic symbols; only numeric fractions and visual models.
- Students are not required to generate equivalent fractions; they select or identify models that represent equivalent fractions.
- Easy questions use fraction bar models only; medium questions use number line models only.
- No simplifying fractions as a standalone task; simplifying is used only as a strategy within the context of identifying equivalence.
- No comparing or ordering fractions beyond identifying whether two fractions are equivalent.
- Number lines run from 0 to 1 only.
- Bar models show one whole partitioned into equal parts with some parts shaded.
- Distractors may include fractions with matching numerators or matching denominators that are not equivalent, as well as incorrect explanations of why fractions are equivalent.

Common Misconceptions:
* Students believe fractions with the same denominator are automatically equivalent, ignoring that different numerators represent different amounts of the whole.
* Students believe fractions with the same numerator are automatically equivalent, ignoring that different denominators change the size of each part.
* Students believe two fractions are equivalent whenever they look similar in a model, without verifying that the shaded portions represent the same amount of the whole.
* Students count tick marks instead of intervals on a number line, resulting in an incorrect denominator and misidentified fractions.

Difficulty Definitions:
* Easy:
  Uses bar model representation
Shows multiple fraction bar graphs
Student selects which bar graphs represent the same fraction
Denominators of 2, 3, 4, 6, and 8
* Medium:
  Uses number line representation
Student selects which fractions represent the given point on the number line
Denominators of 2, 3, 4, 6, and 8
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Number Lines
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.H
Standard Description: Use number lines to compare fractions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Fair Shares as Fractions
Lesson Order: 143.0
Standard ID: TEKS.MATH.CONTENT.3.3.E+1
Standard Description: Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Key Concepts:
*None specified*

Learning Objectives:
* Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to solve problems involving partitioning a set of objects (>=2) among recipients and expressing one recipient's share as a fraction.
- MUST use standard multiple-choice question (MCQ) format.
- MUST use specific names for recipients (e.g., "Leo and Mia" or "Sam, Zoe, and Max") rather than generic grouping nouns like "friends" in the prompt.
- Numbers MUST result in fractions with denominators of exactly 2, 3, 4, 6, or 8.
- Variable Constraints MUST ensure the Number of Recipients is carefully chosen (e.g., 2 or 3) so the resulting distractors form plausible fractions that students might naturally confuse.              -The stimulus_description is a parametric rendering schema

Common Misconceptions:
* Confuses total objects with denominator instead of using number of recipients.
* Uses number of recipients as numerator and total objects as denominator.
* Uses objects per recipient as numerator with 1 as denominator.
* Uses objects per recipient for both numerator and denominator.

Difficulty Definitions:
* Easy:
  All questions are at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Multiple Equivalent Fractions
Lesson Order: 136.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+1
Standard Description: Identify two fractions equivalent to the point shown on the number line.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment must be restricted to:

- Fractions are between 0 and 1 (proper fractions).
- Denominators MUST be limited to: 2, 3, 4, 6, 8.
- Items MUST use a pictorial model (number line or objects/set model such as counters).
- Prompt asks for two equivalent fractions that match the same value shown by the model.
- MCQ with 4 answer choices; each answer choice is a pair of fractions (“___ and ___”).
- Exactly one answer choice contains two fractions that are equivalent AND match the model’s value.
- No procedures requiring formal simplification algorithms; equivalence is derived from the model (partitioning, grouping, counting).

Common Misconceptions:
* Assumes equivalent fractions must have the same numerator regardless of denominator.
* Compares part to part instead of part to whole when modeling fractions.
* Counts tick marks on the number line instead of intervals between marks.
* Identifies one correct fraction but pairs it with a non-equivalent fraction.

Difficulty Definitions:
* Easy:
  Identifying two equivalent fractions from a pictorial set model (counters). Relies on counting individual items vs grouping them into columns/rows.
* Medium:
  Identifying two equivalent fractions from a point on a number line. Relies on understanding intervals and visualizing subdivided marks (e.g., midpoints).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Multiple Equivalent Fractions
Lesson Order: 136.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+1_S
Standard Description: Identify two fractions equivalent to the point shown on the number line.

Key Concepts:
*None specified*

Learning Objectives:
* Given an image of a set of items, identify two equivalent fractions that represent the shaded portion.

Assessment Boundaries:
* Assessment must be restricted to:

- Fractions are between 0 and 1 (proper fractions).
- Denominators MUST be limited to: 2, 3, 4, 6, 8.
- Items MUST use a pictorial model (number line or objects/set model such as counters).
- Prompt asks for two equivalent fractions that match the same value shown by the model.
- MCQ with 4 answer choices; each answer choice is a pair of fractions (“___ and ___”).
- Exactly one answer choice contains two fractions that are equivalent AND match the model’s value.
- No procedures requiring formal simplification algorithms; equivalence is derived from the model (partitioning, grouping, counting).

Common Misconceptions:
* Assumes equivalent fractions must have the same numerator regardless of denominator.
* Compares part to part instead of part to whole when modeling fractions.
* Counts tick marks on the number line instead of intervals between marks.
* Identifies one correct fraction but pairs it with a non-equivalent fraction.

Difficulty Definitions:
* Easy:
  Identifying two equivalent fractions from a pictorial set model (counters). Relies on counting individual items vs grouping them into columns/rows.
* Medium:
  Identifying two equivalent fractions from a point on a number line. Relies on understanding intervals and visualizing subdivided marks (e.g., midpoints).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Fraction Strips
Lesson Order: 133.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+2
Standard Description: Compare fractions using fraction strips.

Key Concepts:
*None specified*

Learning Objectives:
* Compare two unit fractions using fraction strips.
* Determine whether two fractions represented by strips are equivalent and justify the reasoning.
* Identify which fraction is equivalent to a given fraction using fraction strips.

Assessment Boundaries:
* Assessment is restricted to:

Proper fractions only (numerator less than denominator).

Whole numbers limited to 1 whole.

Visual models must be fraction strips of equal length.

Fractions share either:

The same numerator, OR
The same denominator, OR
Represent equivalent fractions.

Students compare fractions using <, >, = Or verbal justification.

Denominators limited to 2, 3, 4, 6, 8

No computation using common denominators.

Reasoning must rely on visual size and part relationships.

Common Misconceptions:
* Assuming More Pieces Means More Area
* Comparing Only Numerators
* Counting Pieces Instead of Size
* Larger Denominator Means Larger Fraction

Difficulty Definitions:
* Easy:
  Determine whether two fractions represented by strips are equivalent and justify the reasoning.
Identify which fraction is equivalent to a given fraction using fraction strips.
* Medium:
  Compare two unit fractions using fraction strips.
Determine whether two fractions represented by strips are equivalent and justify the reasoning.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with the Same Numerator or Denominator: Word Problems
Lesson Order: 145.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+3
Standard Description: Solve a real world problem involving comparing fractions with the same numerator or the same denominator.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem involving two fractions with the same numerator or the same denominator, determine the true comparative statement

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to compare two fractions in a real-world word problem.
- MUST use two fractions that have EITHER the same numerator OR the same denominator.
- MUST NOT use fractions where both the numerators and denominators are different.
- Allowed Denominators: Up to 9 (e.g., 2, 3, 4, 5, 6, 7, 8, 9).
- Response Type: MCQ with exactly 4 options.
- Option Format: Sentences describing the comparison using words (e.g., "is greater than", "is equal to").
- Distractors must be around common misconceptions

Common Misconceptions:
* Believes larger denominator means larger fraction when numerators are the same.
* Claims insufficient information exists to compare fractions with same numerator or denominator.
* Concludes fractions are equal because they share the same numerator or denominator.
* Reverses the inequality relationship when comparing fractions with same denominator or numerator.

Difficulty Definitions:
* Easy:
  All at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 147.0
Standard ID: -
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal-sized groups (base-10 blocks), equal jumps on a number line, or skip counting
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 options. Options must mix visual models (number lines, base-10 block drawings) and numeric lists (skip counting).
- Distractor Logic MUST reflect :Identifying a skip-counting pattern that adds the correct amount but incorrectly starts at the first factor (e.g., for 7*11, starting at 7 instead of 11).Misinterpreting base-10 strips (tens) and units (ones) as single equivalent blocks.Failing to recognize that equal jumps on a number line directly represent multiplication.
- Items may ask for the correct representation OR the one representation that is NOT correct.

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the matching representation among several (array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.E
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 147.0
Standard ID: TEKS.MATH.CONTENT.3.4.E+1
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal-sized groups (base-10 blocks), equal jumps on a number line, or skip counting
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 options. Options must mix visual models (number lines, base-10 block drawings) and numeric lists (skip counting).
- Distractor Logic MUST reflect :Identifying a skip-counting pattern that adds the correct amount but incorrectly starts at the first factor (e.g., for 7*11, starting at 7 instead of 11).Misinterpreting base-10 strips (tens) and units (ones) as single equivalent blocks.Failing to recognize that equal jumps on a number line directly represent multiplication.
- Items may ask for the correct representation OR the one representation that is NOT correct.

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the matching representation among several (array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 147.0
Standard ID: TEKS.MATH.CONTENT.3.4.E+1_S
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
* Determine which representation is a correct method for a given multiplication fact.
* Given a point plotted on a number line, identify two equivalent fractions that represent the location of the point.

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal-sized groups (base-10 blocks), equal jumps on a number line, or skip counting
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 options. Options must mix visual models (number lines, base-10 block drawings) and numeric lists (skip counting).
- Distractor Logic MUST reflect :Identifying a skip-counting pattern that adds the correct amount but incorrectly starts at the first factor (e.g., for 7*11, starting at 7 instead of 11).Misinterpreting base-10 strips (tens) and units (ones) as single equivalent blocks.Failing to recognize that equal jumps on a number line directly represent multiplication.
- Items may ask for the correct representation OR the one representation that is NOT correct.

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the matching representation among several (array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Identifying Even and Odd Numbers with Divisibility Rules
Lesson Order: 149.0
Standard ID: TEKS.MATH.CONTENT.3.4.I+1
Standard Description: Identify whether a number is even or odd using divisibility rules.

Key Concepts:
*None specified*

Learning Objectives:
* Given a 2-digit number, determine its parity to select the correct rationale statement based on the ones place.
* Given a 3-digit even number, determine its parity to select the correct rationale statement based on divisibility by 2, guarding against hundreds and tens place traps.

Assessment Boundaries:
* Assessment restricted to:
- MUST assess identifying a whole number as even or odd and correctly justifying it using the digit in the ones place OR the divisibility rule for 2.
- MUST use standard Multiple Choice (MCQ) format.
- MUST NOT require actual computation of long division; the focus is on applying the rule of divisibility and place value identification.
- Numbers MUST be whole numbers between 10 and 999.
- Exactly one correct answer per item.
- Distractors MUST specifically target misconceptions for example (bit not limited to)
 a) Looking at the tens or hundreds place instead of the ones place.
 b) Applying the wrong divisibility rule (e.g., dividing by 3 or 9).
 c) Confusing the definitions of even and odd (e.g., saying a number is odd because it divides by 2 evenly).
- Distractors must be centered around common misconceptions.

Common Misconceptions:
* Assumes a number is even or odd based on whether the entire number "looks" even or odd visually.
* Confuses the definitions of even and odd, labeling numbers divisible by 2 as odd.
* Looks at the tens or hundreds digit instead of the ones digit to determine even or odd.
* Misapplies divisibility rules for 3, 5, or 9 to determine even or odd status.

Difficulty Definitions:
* Easy:
  Given: A 2-digit whole number (10–99).
Missing: The correct even/odd classification and its rationale.
Reasoning required: Direct lookup of the ones place digit to determine parity.
Trap strength: Plausible distractors using the tens place digit or a common factor (like 9), but minimal visual overload.
No near-boundary ambiguity: Number length is short, reducing cognitive load when identifying the rightmost digit.
* Medium:
  Given: A 3-digit whole number (100–999).
Missing: The correct even/odd classification and its rationale.
Reasoning required: Must ignore the hundreds and tens places, focusing solely on the ones place or the divisibility rule for 2.
Trap strength: Stronger distractors leveraging the hundreds place, tens place, and divisibility by 3 (which commonly confuses students with "odd").
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Missing Factors in Multiplication and Division Equations
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.D
Standard Description: Determine the unknown whole number in a multiplication or division equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2-Staging
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Missing Factors in Multiplication and Division Equations
Lesson Order: 152.0
Standard ID: TEKS.MATH.CONTENT.3.5.D+1
Standard Description: Determine the unknown whole number in a multiplication or division equation.

Key Concepts:
*None specified*

Learning Objectives:
* Complete the missing factor in a division equation
* Complete the missing factor in a multiplication equation

Assessment Boundaries:
* Assessment is restricted to:
- Unknown factors MUST be single-digit (1–10)
- Multipications up to 100
- No real-world problems.
- No use of variables (e.g., a, n, x); use ONLY the box symbol (□, \square) for unknown values.
- Question stem should ONLY be "What number goes in the $\square$ to make the equation true? \n $$\square (\div or \times) __ = __$$"

Common Misconceptions:
* Incorrectly does the multiplication and finds the answer +/- 1
* Treats × as + and solves with addition
* Treats × as - and solves with subtraction

Difficulty Definitions:
* Easy:
  Factors 1-5
* Medium:
  Factors larger than 5
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1-Staging
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Classifying 2D Shapes
Lesson Order: 141.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+3
Standard Description: Classify a group of 2D shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Geometry: Classify 3D-shapes (Prisms vs Non-Prisms)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.A
Standard Description: Classify and sort three-dimensional shapes, distinguishing between prisms and non-prisms, based on their geometric properties

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Word Problems Involving Measuring Area with Unit Squares
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.C
Standard Description: Solve real world perimeter problems involving a stimulus.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6-Staging
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Area Covering a Grid
Lesson Order: 135.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+3
Standard Description: Identify the area of a shaded figure on a grid.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the area of a rectangle by multiplying its side lengths without images
* Calculate the area of a rectangle by multiplying its side lengths, including interpreting side lengths/rows from unit-square representations.
* Determine the area of a composite figure formed by rectangles by decomposing it into non-overlapping rectangles and adding their areas.

Assessment Boundaries:
* Assessment is restricted to:
- area of rectangles with whole-number side lengths using multiplication as rows × unit squares per row, or
- area of composite figures formed by rectangles using additive property of area (sum of rectangle areas).
- Side lengths must be whole numbers between 2 and 10 for images, and 2 and 20 for text-only questions
- All areas must be whole numbers; no fractional/decimal areas.
- Only multiplication of whole numbers for rectangle area (A = l×w)
- Composite area must be solvable by decomposing into 2 non-overlapping rectangles and adding their areas
- Figures allowed: Rectangles (including squares) aligned to grid lines. Composite rectilinear figures that can be partitioned into 2 rectangles with edges on grid lines (e.g., L-shapes, T-shapes).
- Figures excluded: Any figures requiring non-rectangular area formulas (triangles, circles), rotated rectangles (not aligned to grid), overlapping sub-rectangles, or shapes with curved boundaries.
- Representations allowed: Unit-square grids where each square represents exactly 1 square unit of area. Tiling/array word descriptions explicitly giving “rows” and “squares per row,” with each tile covering 1 square unit.
- Context constraints: Context may reference real objects (lawn, card, floor, ceiling) but must not require any measurement conversion; the unit-square legend or tile coverage must be exactly 1 square unit per square.
- Question stem for EASY questions must be exactly: "The shaded figure on the grid represents [someone]'s rectangular [something].\nWhat is the area in square [units] of [someone]'s [something]?" Replace only the bracketed sections with real world question context.
- Question stem for HARD questions must be exactly: "The shaded figure on the grid represents [something].\nThe [something] has two rectangular sections.\nWhat is the area of the [something] in square [units]?" Replace only the bracketed sections with real world question context.
The worked example generator will use the stimulus description JSON to determine height and width and ignore the existing text completely.

Common Misconceptions:
* Confuses perimeter with area, adding side lengths instead of multiplying.
* Misapplies additive area, adding side lengths of rectangles instead of areas.
* Miscounts unit squares on a grid, especially when starting off-by-one.
* Treats rows × squares per row as addition, counting only rows or columns.

Difficulty Definitions:
* Easy:
  non-transparent rectangle on grid
Sides between 2 and 10 units long (total size below 50)
* Medium:
  Text-only description of an object with rectangular shape
Sides between 2 and 20 units long (total size below 80)
* Hard:
  Transparent compound shape decomposable into 2 rectangles on a grid
Sides between 2 and 10 units long (total size below 50)

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Representing Fractions with Jumps on the Number Line
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.A
Standard Description: Match number line models of jumps with fractions that they represent.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Real World Fraction Segments on the Number Line
Lesson Order: 140.0
Standard ID: TEKS.MATH.CONTENT.3.7.A+2
Standard Description: Given a real-world situation represented by a segment on a number line, determine the fraction represented.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:
- Distractor options with the same simplified value are not allowed (e.g. if 1/3 is correct, a 2/6 distractor is disallowed)
- Fractions (Allowed): Proper fractions strictly between 0 and 1 with denominators in the set {2, 3, 4, 5, 6, 8, 10}.
- Numerators (Allowed): Integers (n) such that (1 \le n \le d-1) for denominator (d \in {2,4,8}).
- Fraction Meaning: Fraction interpreted as a distance from 0 on a number line (position).
- Number Line Interval: Number lines represent a single unit interval from 0 to 1.
- Point Placement: The target point must be located exactly on a tick mark corresponding to a fraction of the form ( \frac{n}{d} ) (no points between tick marks).
- Labels: The point is identified by a single capital letter (e.g., J, A).
- Context (Allowed): Real-world “distance traveled from a starting location” situations (e.g., bike ride, ant crawl) with a named unit (e.g., miles, yards). (Units are contextual only; computation does not require conversions.)
- Exclusions: No mixed numbers, improper fractions, decimals, negative numbers, or intervals other than 0 to 1.

Common Misconceptions:
* Confuses denominator with number of tick marks, not equal intervals.
* Counts from 1 backward instead of from 0 as starting point.
* Miscounts fractional steps, placing point on the wrong tick, though selecting a number line with the right partitioning.
* Treats numerator as the denominator and selects that partitioning.

Difficulty Definitions:
* Easy:
  Denominators 2, 3, 4
Numerators 1 or 2
Distractors may use any allowable denominator (2, 3, 4, 5, 6, 8, 10)
* Medium:
  Denominators 5, 6, 8, 10
Any numerator value
Distractors may use any allowable denominator (2, 3, 4, 5, 6, 8, 10)
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Problems Involving Complex Shapes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.B
Standard Description: Solve perimeter problems involving complex shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Appropriate Units of Measurements
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.E
Standard Description: Determine liquid volume (capacity) or weight using appropriate units and tools.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Word Problems Involving Images
Lesson Order: 134.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+4
Standard Description: Given an image of a real-world situation, calculate the perimeter.

Key Concepts:
*None specified*

Learning Objectives:
* Given an image of a rectangular real-world object with the length and width labeled, calculate the perimeter
* Given an image of a square real-world object with one side labeled, calculate the perimeter
* Given the perimeter and one dimension of a rectangular or square real-world object, determine the missing side length
* Given the perimeter of a regular 3–8 sided polygon, determine the missing side length

Assessment Boundaries:
* Assessment is restricted to:
- MUST assess perimeter- or a missing length- that is determined using perimeter.
- MUST use a 2-D polygon image- (real-world object/outline).
- Allowed polygons: 3–8 straight sides- only.
- All given lengths MUST be whole numbers- and use one unit- per item (cm / in. / ft).
- NO unit conversions.
- NO measuring from the picture (all needed info comes from labels and/or a statement).
- If the problem uses “all sides are the same length”, it MUST be stated in text and the polygon’s side count must be clearly countable.
- Exactly one correct answer- per question.

Common Misconceptions:
* - Confuses perimeter with area by multiplying side lengths instead of adding them.
* Counts only the labeled sides and ignores unlabeled sides when calculating perimeter.
* Divides the perimeter by the number of sides instead of multiplying when finding perimeter.
* Multiplies one side length by two instead of adding all sides around the polygon.

Difficulty Definitions:
* Easy:
  3–6 side polygon with all sides labelled.
* Medium:
  3–6 side polygon where it’s stated all sides are same- (NON squares and rectangles).
Square - labelled one side.
Rectangle - length and width.
* Hard:
  3–8 polygons where perimeter is given- and students find the missing length.

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Appropriate Units of Measurements
Lesson Order: 153.0
Standard ID: TEKS.MATH.CONTENT.3.7.E+1
Standard Description: Determine liquid volume (capacity) or weight using appropriate units and tools.

Key Concepts:
*None specified*

Learning Objectives:
* Relative Scale Estimation: Use a provided visual stimulus to determine the most reasonable whole-number quantity for an object's capacity or weight based on its real-world size.
* Unit Category Identification: Discriminate between different types of measurement (e.g., volume vs. weight vs. length) to select the correct unit type for a given liquid or solid object.

Assessment Boundaries:
* Assessment is restricted to:

Context: Word problems must involve a relatable real-world object (e.g., a bottle of water, a juice box).

Stimulus Requirements:

Unit Identification: No visual stimulus is required; the object is identified by text only.

Scale Estimation: A visual stimulus (image) of the object must be provided to establish a sense of scale.

Unit Types:

Liquid Volume (Capacity): Milliliters, Liters, Fluid ounces, Cups, Pints, Quarts, Gallons.

Weight/Mass: Grams, Kilograms, Ounces, Pounds.

Distractor Logic:

Include incorrect unit types (e.g., using "inches" for volume) to test category knowledge.

Include incorrect magnitudes (e.g., "2 liters" vs. "200 milliliters" for a juice box) to test scale.

Formatting: All units must be spelled out in full; no unit conversions or complex calculations are allowed.

Common Misconceptions:
* Assumes larger numbers always represent larger objects regardless of the unit's actual size.
* Confuses weight and liquid volume units when identifying the correct measurement category.
* Misapplies small units like grams to measure the weight of heavy, everyday objects.
* Treats milliliters and liters as interchangeable, ignoring the significant difference in their scale.

Difficulty Definitions:
* Easy:
  Unit Identification: Identify the correct type of unit for an object without a visual aid (e.g., fluid ounces for a bottle of water).
* Medium:
  Scale Estimation: Use a visual stimulus to select the most reasonable measurement quantity for an object (e.g., 200 milliliters for a juice box).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Creating Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.8.A
Standard Description: Create dot plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Dot Plots
Lesson Order: 154.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+4
Standard Description: Represent a data set with a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Given a dot plot with a key, identify the list of numbers that the dot plot represents by reading the value below each dot, including repeated values.

Assessment Boundaries:
* Assessment is restricted to:
- Whole number data only.
- range of up to 10
- Data sets containing 8–16 values.
- At least one value must appear more than once (so frequency matters).
- Non consecutive data values.
- At least one value on the number line must have zero dots.

Common Misconceptions:
* Students confuse the number line labels with data points — they treat every number on the axis as a data value. When reading a dot plot, they list every number printed on the axis whether or not it has dots above it. When choosing a dot plot, they pick one that places dots above every labeled value on the axis, including values not in the data set.
* Students correctly identify which values appear in the data but miscount the frequency of one or more values. They pick a dot plot where the dot counts for most values are correct but one or two values have dots swapped or miscounted (e.g., showing 2 dots instead of 3 for one value and 3 instead of 2 for another).
* Students correctly identify which values have dots but include extra values from the number line boundary. They list each unique value that has dots once (ignoring stacked dots) and also include the endpoint of the number line (e.g., 10) even though it has no dots above it.
* Students ignore frequency — they treat each distinct data value as appearing exactly once. When reading a dot plot, they list each number that has dots only once, regardless of how many dots are stacked above it. When choosing a dot plot, they pick one with exactly one dot per unique value.

Difficulty Definitions:
* Easy:
  range 8
number of values 9-12
* Medium:
  range 10
number of values 13-16
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Multi-Step Problem Solving with Bar Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.8.B
Standard Description: Solve multi-step problems using categorical data represented with a bar graph with scaled intervals

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Multi-Step Problem Solving with Bar Graphs
Lesson Order: 155.0
Standard ID: TEKS.MATH.CONTENT.3.8.B+1
Standard Description: Solve multi-step problems using categorical data represented with a bar graph with scaled intervals

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the total value of all data in a 4-bar vertical graph by identifying the numerical value of each category from a scaled interval and finding their sum.
* Match a comprehensive list of five categorical values to a 5-bar horizontal bar graph by verifying each bar's length against unlabeled intermediate grid lines.

Assessment Boundaries:
* Assessment is restricted to:

Data Representation: Vertical graphs must contain exactly four categories; horizontal graphs must contain exactly five categories.

Scale Logic: Unlabeled grid lines always represent the exact midpoint of numbered intervals.

Operational Limits: Identification of data points and summation of all categories.

Numerical Limits: Individual values within 100; grand totals within 1,000.

Graph Orientation: Vertical bars for 4-category questions; horizontal bars for 5-category questions.

Exclusions: No bars ending between grid lines; all bars must align exactly with a numbered or unlabeled line.

Common Misconceptions:
* Assumes unlabeled grid lines represent increments of one regardless of the actual scale.
* Commits regrouping or place-value errors when summing three or more two-digit data points.
* Identifies the value of the single tallest bar instead of summing all categories.
* Misreads unlabeled grid lines as the nearest labeled numerical value on the axis.

Difficulty Definitions:
* Easy:
  Finding the total sum of four categories where values are identified from a vertical graph with numbered and unlabeled grid lines.
* Medium:
  Matching a 5-item list to a horizontal graph where multiple values must be identified from unlabeled grid lines and verified against distractors.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Saving Money
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.E
Standard Description: List reasons to save and explain the benefit of a savings plan, including for college

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Availability of Resources Versus Cost
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.B
Standard Description: Describe the relationship between the availability or scarcity of resources and how that impacts cost

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Availability of Resources Versus Cost
Lesson Order: 156.0
Standard ID: TEKS.MATH.CONTENT.3.9.B+1
Standard Description: Describe the relationship between the availability or scarcity of resources and how that impacts cost

Key Concepts:
*None specified*

Learning Objectives:
* Use a table showing the number of items available and the number of expected customers to determine which situation would most likely result in the highest price based on supply and demand.

Assessment Boundaries:
* Assessment is restricted to:
Real-world contexts involving supply (amount available) and demand (number of buyers).
Qualitative reasoning only (no multi-step arithmetic required).
Students determine how availability compared to demand affects price:
Fewer items than customers → price most likely higher.
More items than customers → price most likely lower.
Equal items and customers → price likely stable.
One comparison variable at a time (no multi-factor economic reasoning).
Whole numbers only.
No percentages, ratios, or unit-rate calculations required.
Students interpret data rather than compute exact prices.
Items should be one of: Small Retail Items (Hats Sunglasses Scarves Backpacks Notebooks Keychains Bracelets), Craft / Handmade Items (Paintings Handmade cards Soap bars Candles Jewelry Knitted hats Tote bags), Farm / Outdoor Items (Flowers Plants Herb pots Seed packets Pumpkins Hay bales), Food & Produce (Oranges Bananas Watermelons Strawberries Corn Pumpkins Lemons Tomatoes)

Common Misconceptions:
* Students may assume the week with the largest numbers overall results in the highest price.
* Students may assume the week with the most customers automatically has the highest price without comparing supply.
* Students may confuse rows
* Students may select the week with the fewest pineapples without considering the number of customers.

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging-2
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Saving Money
Lesson Order: 157.0
Standard ID: TEKS.MATH.CONTENT.3.9.E+1
Standard Description: List reasons to save and explain the benefit of a savings plan, including for college

Key Concepts:
*None specified*

Learning Objectives:
* Select two benefits of saving money

Assessment Boundaries:
* Assessment is restricted to:
Question stem should ALWAYS ask: "What are some benefits of saving money?"
Real-world contexts involving personal saving decisions.
Identifying benefits of saving money.
Situations appropriate for Grade 3 (college, emergencies, future purchases).
Multi-select format.
Qualitative reasoning only (no numbers).
Concepts limited to:
Saving for future goals
Saving for unexpected expenses

Common Misconceptions:
* Students may believe saving increases interest on bills rather than earning interest.
* Students may choose options that describe financial harm rather than benefit.
* Students may misunderstand debt as something that grows automatically regardless of saving behavior.
* Students may think saving helps you spend money faster.

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fact Families and Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.A
Standard Description: Identify multiple facts that can be used to solve addition and subtraction word problems up to 1,000.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Using Compatible Numbers to Estimate Sums and Differences
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.B
Standard Description: Use compatible numbers to estimate the sum or difference of two numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Using Compatible Numbers to Estimate Sums and Differences
Lesson Order: 146.0
Standard ID: TEKS.MATH.CONTENT.3.4.B+1
Standard Description: Use compatible numbers to estimate the sum or difference of two numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Given a table image of three numbers, use compatible numbers or rounding to the nearest hundred to estimate the sum, and select the best estimate from the given answer choices.
* Given a table image of three numbers, use compatible numbers or rounding to the nearest ten to estimate the sum, and select the best estimate from the given answer choices.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world contexts only.
- All values must be whole numbers up to 1,000.
- Each addend is a 3-digit number.
- Estimation strategy: rounding to the nearest hundred or ten.
- The sum involves 3 addends.
- the sum must be 3 digit as well.

Common Misconceptions:
* Students round all numbers to the same inflated value or always round up to the next hundred regardless of the tens digit, grossly overestimating. For example, rounding 123 up to 300 because the other addends are near 300, or treating every number as if it rounds up.
* Students round one or more numbers to the wrong hundred — rounding up when the tens digit is below 5 (e.g., 123 → 200 instead of 100) — resulting in an overestimate by 100.
* Students truncate each number to its hundreds digit (dropping the tens and ones) instead of rounding to the nearest hundred, consistently producing an underestimate. For example, 273 → 200 instead of 300 because the student keeps only the hundreds digit and replaces the rest with zeros.

Difficulty Definitions:
* Easy:
  3 digit numbers.
round to nearest 100
* Medium:
  3 digit numbers.
round to nearest 10.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers using the Standard Algorithm
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.G
Standard Description: Solve mathematical problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fair-Share Division with Models
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.H
Standard Description: Find how many are in each group when a set of objects is split into equal groups (shared equally).

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multistep Word Problems Involving Multiplication and Division
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.K
Standard Description: Solve two step problems involving multiplication and division.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Using Strip Diagrams to Solve Two-Step Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.A
Standard Description: Use strip diagrams to solve two step word problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multi-step Word Problems: Solve or Represent with an Equation
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.B
Standard Description: Solve multi-step word problems by representing them with equations and using various mathematical operations and models

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.B
Standard Description: Identify equivalent place value models.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value Models
Lesson Order: 115.0
Standard ID: TEKS.MATH.CONTENT.3.2.B+1
Standard Description: Identify equivalent place value models.

Key Concepts:
*None specified*

Learning Objectives:
* Given three base-ten block models that each use a single type of block in varying quantities, determine which two models represent the same number by recognizing equivalences between place values.
* Given three base-ten block models that use different combinations of flats, rods, and units, determine which two models represent the same number by calculating the total value of each model.

Assessment Boundaries:
* Assessment is restricted to:
- All represented numbers must be whole numbers up to 200
- Each question presents exactly 3 models as images with labels. Exactly 2 of the 3 models must represent the same number (there is always one correct pair).
- Answer options are text descriptions that name a pair of models and include a "because" clause explaining the equivalence reasoning; one option is always "None of the models" / "None of these.". Do not give a "because" clause for "None of these" or "None of the models".
- LO1: At least one model must use a mix of block types (hundreds + tens, tens + ones, or hundreds + tens + ones); equivalence arises from regrouping across place values (e.g., 1 ten + 10 ones = 20 ones = 2 tens).
- LO2: Each model uses only one type of block (all ones, all tens, or all hundreds); equivalence arises from place value conversion (e.g., 20 tens = 2 hundreds = 200).
- number of ones in a model may go up to 50, so 50 in value
- number of tens in a model may go up to 20, so 200 in value
- number of hundreds in a model may go up to 2, so 200 in value
- do not use bullet points anywhere is question stem
- do not describe the image in question stem
- do not use "flats", "rods", "units". use "hundreds", "tens", "ones".
- do not use multiplication in worked examples. for eg, if you what to show 2 hundreds write 200 directly instead of 2 x100 or 100+100.

Common Misconceptions:
* Students compare only the count of blocks between models without considering that different block types represent different place values (e.g., equating "20 ones" with "20 tens" because both involve the number 20, ignoring that 20 ones = 20 while 20 tens = 200).
* Students do not understand the fundamental values of base-ten blocks (hundred = 100, ten = 10, one = 1) and cannot correctly calculate the total value of any model, leading them to conclude that no models represent the same number.
* Students fail to recognize that different types and quantities of blocks can represent the same number through place value equivalence (e.g., 20 tens = 2 hundreds), incorrectly concluding that none of the models match even when a valid pair exists.
* Students misidentify the type of base-ten block in a model (e.g., counting ones as tens or interpreting ones blocks as tens blocks), leading to an incorrect total value for that model and a wrong pairing (e.g., treating Kareena's 2 ones as 2 tens to get 120 instead of 102, or reading Model X's 20 ones as 20 tens).

Difficulty Definitions:
* Easy:
  Given three base-ten block models that each use a single type of block in varying quantities, determine which two models represent the same number by recognizing equivalences between place values.
* Medium:
  Given three base-ten block models that use different combinations of flats, rods, and units, determine which two models represent the same number by calculating the total value of each model.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Ordering Numbers in the Thousands
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.D
Standard Description: Order a list of numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Ordering Numbers in the Thousands
Lesson Order: 131.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+4
Standard Description: Order a list of numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Determine whether numbers fall within a given interval by comparing each number to the interval’s endpoints
* Identify whether a list of numbers is correctly ordered in ascending or descending order by comparing place values
* Order numbers in ascending or descending order and determine which statement about their relative positions is true

Assessment Boundaries:
* Assessment is restricted to: 
- Numbers (Allowed Range): Every number shown anywhere in the item (stimulus, stem, and answer choices) must be a whole number with 1,000 ≤ n ≤ 100,000.
- Number Type (Only): Use integers only. No decimals, fractions, negative numbers, or mixed numbers.
- Digit Length: All numbers must be 4 or 5 digits .
- Notation: Numbers must be written as base-10 numerals using digits 0–9 with optional commas for thousands (e.g., 9,975). No word form.
- Leading Zeros: Not allowed (e.g., 01,234 is invalid).
- Exclusions (Not Assessed): Do not require rounding, estimation, addition/subtraction, multiplication/division, or converting to expanded/word form.

Common Misconceptions:
* Students compare 4-digit numbers by the ones digit instead of thousands/hundreds
* Students misalign place values across digit lengths, treating 6,092 as 60,019-like
* Students place the only 5-digit number first, then compare remaining numbers by the ones digit
* Students reverse the ordering direction (choose least→greatest when asked greatest→least)

Difficulty Definitions:
* Easy:
  Place-value tightness (ordering/comparison): in the set being compared/ordered (3-number list or 4-student cards), all numbers have distinct floor(n/1000) (no two numbers in the same 1,000-block), so order is decided at the thousands place or higher.
* Medium:
  Place-value tightness (ordering/comparison): the set contains at least one pair with the same floor(n/1000) (same 1,000-block), so comparison must use the hundreds place.
For all such same-block pairs in the set, enforce abs(a-b) ≥ 400 (close, but not “tightest”).
* Hard:
  Place-value tightness (ordering/comparison): the set contains at least one pair in the same 1,000-block with abs(a-b) ≤ 300 (tight comparison like 98,087 vs 98,300), requiring hundreds-place decisions under close spacing.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with the Same Numerator or Denominator: Word Problems
Lesson Order: 145.0
Standard ID: TEKS.MATH.CONTENT.3.3+1
Standard Description: Solve a real world problem involving comparing fractions with the same numerator or the same denominator.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem involving two fractions with the same numerator or the same denominator, determine the true comparative statement

Assessment Boundaries:
* Assessment must be restricted to:

- MUST assess the student's ability to compare two fractions in a real-world word problem.
- MUST use two fractions that have EITHER the same numerator OR the same denominator.
- MUST NOT use fractions where both the numerators and denominators are different.
- Allowed Denominators: Up to 9 (e.g., 2, 3, 4, 5, 6, 7, 8, 9).
- Response Type: MCQ with exactly 4 options.
- Option Format: Sentences describing the comparison using words (e.g., "is greater than", "is equal to").
- Distractors must be around common misconceptions

Common Misconceptions:
* Believes larger denominator means larger fraction when numerators are the same.
* Claims insufficient information exists to compare fractions with same numerator or denominator.
* Concludes fractions are equal because they share the same numerator or denominator.
* Reverses the inequality relationship when comparing fractions with same denominator or numerator.

Difficulty Definitions:
* Easy:
  All at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Number Lines
Lesson Order: 117.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+1
Standard Description: Use number lines to compare fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the fraction modeled by each number line (from the jumps and intervals) and select the **true comparison statement**.
* Given two number line models with labelled fractions on the number lines, compare the two fractions (provided in the prompt) and choose the correct symbol **( <,>,=)**.

Assessment Boundaries:
* Assessment is restricted to:
- MUST compare **two fractions** that have the **same numerator OR the same denominator**.
- MUST use **number line models from 0 to 1** (one whole).
- Fractions on the number line MUST be represented using **jumps (arcs)** starting at 0.
- The number line MUST be partitioned into **equal intervals**.
- Comparisons MUST use only **<, >, =**.
- No fraction computation beyond interpreting the model (no adding/subtracting, no converting to decimals, no cross-multiplying).
- Leave fractions **unsimplified**

Common Misconceptions:
* Assumes any single interior tick splits 0–1 evenly, even when off-center.
* Confuses the point’s position with nearby tick marks instead of equal partitions.
* Counts tick marks rather than equal segments to determine the fraction value.

Difficulty Definitions:
* Easy:
  Show two number lines. **State the fraction each number line represents (unsimplified)** and ask students to choose the symbol **(<, >, =)**.
MCQ with three options.
* Medium:
  Two number lines model two fractions with **jumps** from 0 to 1. Ask: **“Which comparison of these fractions is true?”** (4-option MCQ).
MCQ with four options.
Fractios are not called out should be inferred from the stimulus.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fact Families and Word Problems
Lesson Order: 119.0
Standard ID: TEKS.MATH.CONTENT.3.4.A+1
Standard Description: Identify multiple facts that can be used to solve addition and subtraction word problems up to 1,000.

Key Concepts:
*None specified*

Learning Objectives:
* Find missing addition and subtraction facts from the same fact family in word problems when given one fact.
* Find missing addition and subtraction facts from the same fact family in word problems.
* Find the statement which is or is NOT a suitable fact to model an addition and subtraction word problem.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no remainders, fractions, decimals, or negative numbers
- Addition and subtraction word problems with numbers up to 1,000
- One-step word problems involving a part-whole or start-change-result structure
- Problems involve finding an unknown part (not the whole)
- Students identify equivalent equations from the same fact family
- Context is mandatory; items must be embedded in word problems or real-world scenarios
- No visual models required; problems are text-based with equation answer choices
- Multiselect questions require selecting exactly two correct equations
- Multiple choice questions asking which equation can NOT be used must have NOT capitalized
- Easy questions provide one equation and ask for two other equivalent equations; all numbers are 2-digit
- Medium questions do not provide an initial equation; all numbers are 2-digit
- Hard questions do not provide an initial equation; equations include one 3-digit number
- Hard questions may also be MCQ format asking which equation can NOT be used
- Distractors include equations that reverse the relationship (e.g., part − [ ] = whole) or add the two known quantities
- Never show negative numbers

Common Misconceptions:
* Students add the two given quantities (part and whole) instead of finding the unknown part, selecting the equation that sums those two numbers or failing to identify it as the one that can NOT be used.
* Students assume the situation can only be represented with subtraction and reject or overlook the valid addition equation (part + unknown = whole), treating "sold" or "gave away" as requiring subtraction only.
* Students confuse the roles of whole, part left, and unknown in the part-whole situation, treating the sum of part and whole as the answer or misplacing quantities in equations, leading to incorrect selection of which equation can NOT be used.
* Students reverse the task by selecting an equation that correctly fits the situation instead of identifying the single equation that does NOT fit, answering which equation can be used rather than which can NOT be used.

Difficulty Definitions:
* Easy:
  MSQ only. Word problem, problem gives them one equation and asks which other equations can be used and MS the other equations in the fact family.
Numbers are all 2 digits
* Medium:
  MCQ: Word problem. Numbers are all 2 digits. Select ANY member of the fact family
* Hard:
  MCQ: Word problem. Equations include one three digit number (and not both). Select ANY member of the fact family.
MCQ: Word problem. Question doesn’t give the first equation and it includes problems with NOT - numbers can be all two digits or one can be a three digit number. The NOT must be capitalized.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fair-Share Division with Models
Lesson Order: 102.0
Standard ID: TEKS.MATH.CONTENT.3.4.H+1
Standard Description: Find how many are in each group when a set of objects is split into equal groups (shared equally).

Key Concepts:
*None specified*

Learning Objectives:
* Divide a given quantity into a known number of groups to find the size of each group where the visual shows the given quantity.
* Divide a given quantity into a known number of groups to find the size of each group where the visual shows the number of groups.

Assessment Boundaries:
* Assessment is restricted to:
- Whole number dividend ≤ 100
- Single-digit divisor 2–9
- NO remainders, fractions, decimals, or mixed numbers
- NO variables / algebraic notation
- Must be equal-sharing/partitioning (partitive division), NOT measurement division or repeated subtraction
- Must ask for “how many in EACH group”, NOT “how many groups”
- Wrong answers must be grounded in one or more misconceptions
- The explanation for each wrong answer must be coherent and correct

Common Misconceptions:
* Students add the total and the number of groups instead of dividing
* Students interpret “equal groups” as multiplication and multiply the total by the number of groups
* Students solve for “how many groups” instead of “how many are in each group"
* Students subtract the numbers instead of dividing

Difficulty Definitions:
* Easy:
  Dividends up to 25 with divisors 2-5 (e.g., 12 ÷ 3, 16 ÷ 4, 8 ÷ 2)
* Medium:
  Dividends 21-100 with divisors 2-9 (e.g., 36 ÷ 4, 42 ÷ 6, 35 ÷ 5)
* Hard:
  Dividends 51-100 with divisors 2-9 yeilding quotients between 11 and 15 (e.g., 77 ÷ 7, 84 ÷ 6, 65 ÷ 5)

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multistep Word Problems Involving Multiplication and Division
Lesson Order: 123.0
Standard ID: TEKS.MATH.CONTENT.3.4.K+1
Standard Description: Solve two step problems involving multiplication and division.

Key Concepts:
*None specified*

Learning Objectives:
* Students will solve real-world, 2-step problems (including one multiplication or division step, with results within 100) where the numerical values appear in the text in the same order they are used to calculate the solution.

Assessment Boundaries:
* Assessment is restricted to:

Operational Limits: Problems must require exactly two steps (Addition, Subtraction, Multiplication, or Division), and include at least one multiplication or division operation.

Numerical Limits: All products and dividends must be within 100.

Placeholders: No use of letter variables (e.g., x, y, n); unknowns must be represented by a box [ ], question mark (?), or blank line (__).

Context: Real-world scenarios are required for all items.

Exclusions: No remainders; all division must result in a whole number. No fractions, decimals, or money involving cents (whole dollar amounts only).

Logic: Problems must require two steps to reach the final solution.

Common Misconceptions:
* Confuses the total amount with the group size when interpreting division word problems.
* Ignores the necessary grouping and performs operations in a strict left-to-right sequence.
* Misapplies addition or subtraction instead of multiplication or division due to key words.
* Performs only the first step of the problem and ignores the second requirement.

Difficulty Definitions:
* Easy:
  All easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Using Strip Diagrams to Solve Two-Step Word Problems
Lesson Order: 122.0
Standard ID: TEKS.MATH.CONTENT.3.5.A+1
Standard Description: Use strip diagrams to solve two step word problems.

Key Concepts:
*None specified*

Learning Objectives:
* (LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
* (LO2) Given a two-step word problem involving addition where one quantity is described relative to another, identify the strip diagram that correctly represents the relationship between the parts to find the total.
* (LO3) Given a word problem involving equal groups, identify the strip diagram that correctly represents the groups and their sizes.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world contexts only.
- All values must be whole numbers up to 1,000.
- The unknown value must be represented by a "?" in the model.
- No use of variables like x or n; use "?" for the unknown.
- Strip diagram (bar model) must clearly show the whole as a single bar and the parts as smaller segments that combine to equal the whole.
- LO1: Problems must involve a known total and two or more known parts with one unknown part (subtraction relationship).
- LO2: Problems must describe one quantity and a second quantity relative to the first (e.g., "75 more than"); the strip diagram must represent the total of all parts.
- LO3: Problems must involve equal groups; each group is represented as a separate strip with identical structure. Limited to 2 groups with up to 4 cells per strip.

Common Misconceptions:
* Students confuse group size with the number of groups in equal-group representations, using the wrong number for cell values or the wrong number of cells per strip (e.g., showing cells of 3 instead of 10, or showing 1 cell per strip instead of 3).
* Students fail to compute a derived quantity from a relational statement — when one value is described as "more than" another, they use only the explicitly stated numbers without computing the actual value (e.g., modeling 339 + 75 = ? instead of 339 + (339 + 75) = ?).
* Students swap the total and a part in the strip diagram, placing a part value as the whole (top row) and the actual total as one of the parts (e.g., putting 196 as the whole instead of 294).
* Students treat all given numbers as addends, placing every number including the total into the parts row so the unknown becomes the grand total (e.g., showing 294 + 196 + 49 = ? instead of 294 = 196 + 49 + ?).

Difficulty Definitions:
* Easy:
  1 and 2 digit numbers only
LO3 and LO1 only
(LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
(LO3) Given a word problem involving equal groups, identify the strip diagram that correctly represents the groups and their sizes.
* Medium:
  2 and 3 digit numbers only
LO1 only
(LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
* Hard:
  2 and 3 digit numbers only
LO2 only
(LO2) Given a two-step word problem involving addition where one quantity is described relative to another, identify the strip diagram that correctly represents the relationship between the parts to find the total.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Model Multiplication and Division Word Problems
Lesson Order: 120.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+2
Standard Description: Identify arrays that can be used to solve one step multiplication and division word problems.

Key Concepts:
*None specified*

Learning Objectives:
* Given a one-step division word problem, identify the array that models the situation.
* Given a one-step division word problem, identify the group model that matches the situation.
* Given a one-step multiplication word problem, identify the array that models the situation.

Assessment Boundaries:
* Assessment is restricted to:
- One-step multiplication and division word problems within 100
- Products and dividends within the 10 × 10 multiplication table
- Arrays as visual models only (no strip diagrams or equations required)
- Whole numbers only; no remainders, fractions, or decimals
- Real-world contexts involving equal groups, rows, or repeated sets
- No use of variables (e.g., a, n, x); problems present visual array choices
- Students select the correct array from multiple choice options; they do not construct arrays
- No multi-step problems or problems requiring both multiplication and division
- Context is madatory; items must be embedded in word problems or real-world scenarios.
- Visual support is mandatory.
- The correct answer will always be an integer multiplication or an even division, but distractor options are not required to depict even divisions or full multiplications
- Due to the cummutative property of multiplication, distractors may NOT use inverted rows and columns

Common Misconceptions:
* Students add the two quantities in the word problem instead of multiplying, selecting an array that represents the sum rather than the product.
* Students confuse the roles of the quantities in the word problem (number of groups versus number in each group), selecting an array where only one dimension matches or where the dimensions are misinterpreted.
* Students perform incorrect multi-step reasoning by first adding the quantities and then applying another operation, leading to selection of an array that does not represent the original word problem.
* Students select an array with the correct number of rows but fail to verify that the number of objects in each row also matches the word problem, only partially modeling the multiplication or division situation.

Difficulty Definitions:
* Easy:
  Both factors are 5 or less (products up to 25)
Groups and items per group must be readily interpretable from the context
* Medium:
  At least one factor is between 6 and 10 (products up to 100)
Groups and items per group must be readily interpretable from the context
* Hard:
  Up to one factor is between 6 and 10 (products up to 100)
Multiplication or division problems
Using grouped models, not array models
Groups and items per group must be readily interpretable from the context

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Modeling Two-Step Word Problems
Lesson Order: 121.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+3
Standard Description: Represent two step word problems with models.

Key Concepts:
*None specified*

Learning Objectives:
* Connect visual array and equal-group models to two-step number sentences involving multiplication and division

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no remainders, fractions, decimals, or mixed numbers
- Products and dividends within the 10 × 10 multiplication table
- Two-step problems involving only multiplication and division operations. The first operation is division. The second is multiplication or division
- Allowed visual models are arrays or equal groups of an abstract representation of the objects being discussed.
- Exact representations of the visual objects are not allowed; abstract representations only.
- Problems may include: two multiplication steps, two division steps, multiplication then division, or division then multiplication
- Context is madatory; items must be embedded in word problems or real-world scenarios.
- Due to the cummutative property of multiplication, distractors may NOT use inverted rows and columns

Mapping of stimulus_specification to image (this is done deterministically and has been validated):
The first operation is division, and the first_values represent [dividend, divisor]. The students will see <divisor> groups of <quotient> objects. The expected first equation is "groups of (dividend ÷ divisor)" or "(divided ÷ quotient) groups/equal groups"
If the second operation is multiplication, then the second_values represent [number of groups, groups of how many] of crossed-out objects, where the "groups of how many" should be the quotient from the first operation. The students will see these groups crossed out. The expected correct first equation is (number of groups x groups of how many).
If the second operation is division, then the second_values represent [dividend, divisor] where the dividend is the quotient of the first operation. The students will see each group divided into <divisor> smaller groups. The expected correct second equation is "groups of (dividend ÷ divisor)" or "(divided ÷ quotient) groups/equal groups". Alternatively, the second operation is mentioned as a single further division of the first grouping, e.g. "each bag is divided into 2 bags of 3"

Common Misconceptions:
* Students misinterpret the distribution/partitioning shown in the model as subtraction instead of division. When they see groups being removed or separated (such as bags crossed out), they interpret it as subtraction rather than understanding it represents division or equal sharing, leading to answers that mix operations incorrectly.
* Students reverse which operation comes first by reading the visual model in the wrong sequence. They might start with the final arrangement shown and work backward, or they identify the operations correctly but place them in reverse order in the number sentence, leading to expressions like "divided first, then multiplied" when the model shows "multiplied first, then divided."
* Students use the number of items in each group to set up the distribution instead of using the number of groups.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  Simple equal-groups or array contexts
Numbers up to 10 x 10
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Attributes of 2D Shapes
Lesson Order: 124.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+2
Standard Description: Classify and sort two-dimensional figures based on attributes.

Key Concepts:
*None specified*

Learning Objectives:
* (LO1) Given a table of groups defined by geometric attributes, select the true statement about which shape(s) belong to which group(s).
* (LO2) Select the table (from image options showing shapes and attributes) that correctly shows which attributes apply to each shape.
* (LO3) Given a set of shapes, count how many shapes have a specific attribute.
* (LO4) Given a set of shapes, identify which attribute or statement is true about ALL of them.

Assessment Boundaries:
* Assessment is restricted to:
- 2D shapes only.
- Shapes referenced by name in answer options (LO1, LO2): triangle, square, rectangle, pentagon, hexagon, circle, parallelogram only.
- Shapes shown visually in stimulus images (LO3, LO4): any 2D shapes including triangles (all types), squares, rectangles, rhombuses, parallelograms, trapezoids, irregular quadrilaterals, pentagons (regular/irregular), hexagons (regular/irregular), irregular polygons up to 8 sides, circles, and other non-polygon curved shapes.
- Attributes must use formal geometric language: polygon, quadrilateral, vertices, sides, congruent sides, parallel sides, etc.
- Groups are defined by attributes (not by shape names).
- A shape may belong to multiple groups if it satisfies all attributes of those groups.
- May include non-polygon figures (curves) for students to identify and exclude.
- No measurement or numerical values for side lengths.
- please dont say "example image" in worked examples, they are not example image, they are actual iamge to refer.
- for worked examples with image, do not include any extra lines than the article worked examples. do not include any conversational lines and do not include any addition equations.

Common Misconceptions:
* Students confuse "quadrilateral" (exactly 4 sides) with "polygon" (3+ sides), classifying triangles as quadrilaterals.
* Students confuse two-dimensional polygons with three-dimensional prisms.
* Students do not consider all attributes or all shapes when evaluating a statement, checking only some figures or some criteria before selecting an answer.
* Students do not recognize that a polygon must be a closed figure with all straight sides (line segments), incorrectly including curved figures or excluding valid polygons.

Difficulty Definitions:
* Easy:
  (LO3) Given a set of shapes, count how many shapes have a specific attribute.
* Medium:
  (LO2) Select the table (from image options showing shapes and attributes) that correctly shows which attributes apply to each shape.
(LO4) Given a set of shapes, identify which attribute or statement is true about ALL of them.
* Hard:
  (LO1) Given a table of groups defined by geometric attributes, select the true statement about which shape(s) belong to which group(s).

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Drawing Unit Squares to Find Area
Lesson Order: 125.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+1
Standard Description: Solve area problems using models with one row and one column of unit squares.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the area of a tiled rectangular region by using the number of tiles along the length and width.
* Find the area of a rectangle by extending a partially shown array of unit squares.
* Find the area of a rectangle by using unit markers along two sides to determine its length and width.
* Identify which rectangles match a given area by calculating the area of each rectangle.
* Select rectangles that satisfy an area requirement by inferring dimensions from unit-square placement and comparing areas.

Assessment Boundaries:
* Assessment is restricted to:
Whole-number side lengths inferred by counting unit squares; allowable side lengths 1–10 units.
Whole-number areas found by multiplication; allowable areas 1–100 square units.
Must use multiplication conceptually as (number of rows) × (number of unit squares in each row); addition/counting is allowed only to determine dimensions, not as the main method for area.
No fractional side lengths, no fractional unit squares, no missing-unit ambiguity (unit square size must be explicitly defined), no perimeter-only questions.

Common Misconceptions:
* Assumes the missing interior is not included, counting only placed unit squares.
* Confuses area with perimeter by adding side lengths or counting edge squares.
* Misapplies rows × squares-per-row by multiplying incorrect row/column counts.
* Treats the shown border unit squares as the total area.

Difficulty Definitions:
* Easy:
  Find the area of a rectangle by extending a partially shown array of unit squares.
* Medium:
  Determine the area of a tiled rectangular region by using the number of tiles along the length and width.
Find the area of a rectangle by using unit markers along two sides to determine its length and width.
* Hard:
  Identify which rectangles match a given area by calculating the area of each rectangle.
Select rectangles that satisfy an area requirement by inferring dimensions from unit-square placement and comparing areas.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Word Problems Involving Measuring Area with Unit Squares
Lesson Order: 126.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+2
Standard Description: Solve word problems to find the area of rectangular surfaces in real-world contexts using a provided grid model.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem and a visual of a rectangular surface partitioned into unit squares, determine the total area by identifying the number of rows and the number of unit squares in each row from the provided information.

Assessment Boundaries:
* Assessment is restricted to:

Rectangles and squares only; no irregular or composite shapes.

Word problems must involve a real-world context of covering a surface (e.g., tiling a floor, laying a rug, or paving a patio).

A visual MUST be provided showing a rectangle fully partitioned into a grid or clearly defined rows and columns of unit squares.

Easy problems must use plain/empty grids; Medium problems must use grids with internal designs (e.g., tile patterns, brick textures, or smiley faces).

The number of rows and the number of unit squares in each row may be provided in the text or must be identified by the student using the visual.

Factors (side lengths) must be whole numbers.

Side lengths should make sense in real world. For example you can't say that a chair is of 100 feet length.

Total area (product) is limited to a maximum of 50 square units.

All units must be spelled out (e.g., "square feet," "square inches").

No abbreviations (e.g., "cm," "sq cm") or exponential notation (e.g., "m^2").

No use of variables like x or n. Questions should end with a standard question mark or a blank line for the answer.

Single-step problems only.

Every question stem must follow this exact 3-step sequence and follow the 4th rule:
1) Context: Introduce a character and a real-world object (e.g., "Sam is making a tiled tabletop").
2) The Model (Bridge): Explicitly state: "The [object] is modeled by this rectangle."
3) The Question: "What is the area of the [object] in square [units]?"
4) Do not state dimensions in the text; students must identify rows, columns, and units (e.g., "1 foot") from the image labels.

Common Misconceptions:
* Confuses area with perimeter by adding the number of rows and the number of unit squares in each row.
* Inaccurately identifies dimensions by miscounting the number of unit squares in a row or column within the visual model.
* Miscalculates the total surface by adding the lengths of all four sides of the rectangle.
* Mistakes the operation by adding the dimensions together instead of using multiplication to find the product.

Difficulty Definitions:
* Easy:
  Solve area word problems using a plain unit square grid for totals up to 25 square units.
* Medium:
  Solve area word problems using a grid with internal designs/patterns for totals up to 50 square units.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Fractions of Congruent Shapes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.E
Standard Description: Identify equivalent fraction models

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Fractions of Congruent Shapes
Lesson Order: 118.0
Standard ID: TEKS.MATH.CONTENT.3.6.E+1
Standard Description: Identify equivalent fraction models

Key Concepts:
*None specified*

Learning Objectives:
* Given a unit fraction **1/n**, select the option where **two congruent wholes** each show **exactly 1/n** shaded (one equal share shaded).

Assessment Boundaries:
* Assessment is restricted to:
- 2-D figures only.
- If figures are said to be **congruent**, they MUST be **same size and same shape**.
- Unit fractions only.
- Within any figure, partitions MUST be **equal area** (shares may differ in shape across figures).
- **MCQ: exactly 4 options, exactly 1 best answer.**
- No measurement tools, coordinate geometry, or numeric area computation.

Common Misconceptions:
* Assumes figures show equivalent fractions only when partitions have identical shapes.
* Compares visual appearance of shaded regions instead of equal-area relationships between parts.
* Confuses number of shaded parts with fractional amount, ignoring total partition count.
* Ignores that congruent wholes ensure same-size parts even when partition shapes differ.

Difficulty Definitions:
* Easy:
  Unit fraction is **given** (1/n).
Pick the pair where both congruent wholes show **exactly 1/n** shaded.
Distractors: wrong denominator; shading not exactly one share; unequal-share partition.
* Medium:
  Unit fraction **not given**; infer from model.
“CAN/CANNOT” format.
Includes at least one option with same-looking part count but **unequal areas**.
* Hard:
  Different partition styles across congruent wholes (not limited to triangles/rectangles).
Requires reasoning: congruent whole split into **k equal-area parts ⇒ each part = 1/k**, regardless of part shape.
Distractors target “looks bigger” and wrong fraction claims.
The image shows only plain congruent outlines (no partition lines drawn)
Partition details are described in the question stem text only
Answer options are text statements, not images

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Representing Fractions with Jumps on the Number Line
Lesson Order: 116.0
Standard ID: TEKS.MATH.CONTENT.3.7.A+1
Standard Description: Match number line models of jumps with fractions that they represent.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the fraction represented by a point on a number line by comparing its distance from 0 to the length of the whole interval

Assessment Boundaries:
* * Use proper fractions ( \frac{a}{b} ) where integers (a,b) satisfy 1 ≤ a < b and b is 2,4 or 8.
* All number lines represent exactly one whole unit interval from 0 to 1 (inclusive).
* If interior tick marks are present, they must create equal-length partitions of the 0–1 interval (i.e., all segments between consecutive ticks/endpoints are equal).
* The representation uses a single jump that starts at 0 and ends at the labeled point (no multiple sequential jumps).
* Choose a unit randomly from one of these: centimeter, meter, kilometer, feet, inches only

Common Misconceptions:
* -
* Assumes any single interior tick splits 0–1 evenly, even when off-center.
* Confuses the point’s position with nearby tick marks instead of equal partitions.
* Counts tick marks rather than equal segments to determine the fraction value.

Difficulty Definitions:
* Easy:
  All questions are easy.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Problems Involving Complex Shapes
Lesson Order: 127.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+1
Standard Description: Solve perimeter problems involving complex shapes.

Key Concepts:
*None specified*

Learning Objectives:
* Use structure cues to infer **exactly four** unlabeled exterior side lengths, then compute the **perimeter** by adding all exterior side lengths and enter the answer as a whole number.

Assessment Boundaries:
* Assessment is restricted to:
- Items MUST use a **composite figure made from at least TWO/THREE polygons** (joined/attached).
- Items MUST ask for the **perimeter of the composite outline**.
- **Text Entry only**: student enters **one whole number** as the perimeter.
- Perimeter MUST be the **outside boundary only**:
  - Missing side lengths MUST be **determined by structure cues**.
- Side lengths MUST be **whole numbers** and the stem should have units in full form (abbreviations not allowed).
- The perimeter value MUST be **uniquely determined** from the diagram + stated structure (no ambiguity).
- Stems MUST have real-world contexts and include the unit in the question (e.g., "in inches/feet").

Common Misconceptions:
* Adds area and perimeter or confuses perimeter with counting total sides.
* Assumes missing side lengths without using congruence or shape properties given.
* Counts all visible side lengths including those inside the composite figure.
* Includes interior shared edges when counting perimeter instead of only outside boundary.

Difficulty Definitions:
* Easy:
  0** or **1** exterior side is missing.
One direct inference using a single structure cue.
Fewer perimeter segments; boundary is straightforward.
Must not use the term congruence/congruent. Use same/ equal instead.
* Medium:
  Exactly **2** exterior sides are missing.
Two inferences; more addends.
May use the term congruent.
* Hard:
  3-4 exterior sides are missing.
MUST use the term congruent.
Multiple correspondences across the figure (often includes two congruent polygons plus another polygon).
Many addends; common pitfall is missing a side or stopping early on the outline.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Finding Errors in Perimeter Problems
Lesson Order: 128.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+2
Standard Description: Identify the error in a given worked perimeter problem.

Key Concepts:
*None specified*

Learning Objectives:
* Select the single statement that correctly describes the mistake (or correctly states there is no mistake). for a table with one or two shapes
* Select the single statement that correctly describes the mistake (or correctly states there is no mistake). for a table with three shapes

Assessment Boundaries:
* Assessment is restricted to:                                                                                     - Items MUST show a **table** with :

  * **Figure** name (e.g., square, triangle, rectangle),
  * **Side Lengths** listed (same unit),
  * A stated **Perimeter** value.
- Prompt MUST ask which **mistake, if any**, was made (STAAR tone), and answers MUST be **statements**.
- Students MUST determine the correct choice by using the definition: **perimeter = sum of all side lengths**.
- **MCQ MUST have exactly 4 options** and **exactly 1 correct**.
- Table MUST be designed so that:

  * **Either** exactly **one** figure’s perimeter is incorrect,
  * **Or** all perimeters are correct (so “no mistake” can be the correct answer, only when intended).
- Numbers MUST be **whole numbers**; one consistent unit (yards/feet/inches); **no conversions**; no decimals/fractions.
- Options MUST be STAAR-parallel statements:

  * At least **one** option states the **correct corrected perimeter** for the figure with the error (e.g., “The perimeter of the rectangle should be 24 yards.”).
  * The other options MUST include plausible incorrect statements such as:

    * naming the wrong figure and giving an incorrect corrected perimeter,
    * “no mistake” when there is a mistake (or vice versa when intended).
- Do NOT assess area or formulas like (2l+2w); no multi-step beyond adding the given side lengths.
- Exactly one best answer must be uniquely determined from the table.

Common Misconceptions:
* Assumes opposite sides are equal for all figures, not just rectangles
* Confuses perimeter with area by multiplying two dimensions instead of adding all sides
* Multiplies the number of sides by one side length instead of summing all side lengths
* Omits one or more sides when adding to find the total perimeter

Difficulty Definitions:
* Easy:
  Table in the stem includes one or two row only.
* Medium:
  Table in the stem includes **three rows**.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Using Rulers to Solve Perimeter Problems
Lesson Order: 139.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+3
Standard Description: Use a ruler to measure side lengths to find the perimeter of a given shape.

Key Concepts:
*None specified*

Learning Objectives:
* Use a ruler to measure side lengths and find the perimeter of a given object
* Use a ruler to measure side lengths and find the perimeter of a given rectangle
* Use a ruler to measure side lengths and find the perimeter of a given square

Assessment Boundaries:
* Assessment is restricted to: 
  • Must have side lengths less than or equal to 20 cm / 8 inch
  • The sizes of the real world objects should be realistic
  • Must require measuring length to nearest centimeter/inch and identifying the perimeter in centimeters/inches.
  • Triangles and other polygons are not allowed except square and rectangle
  • Unit labels should be consistent throughout the problem
  • All answer options must be rooted in one or more misconceptions

Common Misconceptions:
* Students add the length and width only one time instead of adding all four sides around the shape. Distractor formula: L + W for a rectangle, or s + s for a square.
* Students forget to include one side length when adding to find the perimeter. Distractor formula: L + L + W (missing one width) or L + W + W (missing one length) for a rectangle, or s + s + s for a square.
* Students misread the ruler by starting at 1 instead of 0, so each side they measure is 1 unit longer than it really is. Distractor formula: 2(L + 1) + 2(W + 1) for a rectangle, or 4(s + 1) for a square. This always adds 4 to the correct perimeter.
* Students multiply the side lengths to find the area instead of adding them to find the perimeter. Distractor formula: L × W for a rectangle, or s × s for a square.

Difficulty Definitions:
* Easy:
  Side lengths ≤ 8 cm or ≤ 3 inch
* Medium:
  Side lengths ≤ 15 cm or ≤ 6 inch
Atleast one side ≥ 9 cm or ≥ 4 inch
* Hard:
  Side lengths ≤ 20 cm or ≤ 8 inch
Atleast one side ≥ 16 cm or ≥ 7 inch

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Creating Dot Plots
Lesson Order: 129.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+1
Standard Description: Create dot plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of data values, identify the dot plot that correctly represents the frequency of each value in the data set.
* Given images of coins, identify the dot plot that correctly represents the value (in cents) of each coin.

Assessment Boundaries:
* Assessment is restricted to:
- question stem should have real world scenarios only.
- values must be <= 50
- only whole number values
- if the question stem lists values, the values must be an unordered list.
- for the question that shows images of coins, the question stem first line must be a real world context and the second line should be asking about the dot plot.
- In worked example or answer option explanations for question that shows images of coins, do not use symbol of cents (¢), use the word "cents" instead.
- frequency of values (in question stem and answer choices) always must be <=8.
- for questions that do not show an image of coins, the range of values must be atleast 7 and atmost 10 for easy questions and atleast 10 and atmost 12 for medium questions.

Common Misconceptions:
* Students count the total number of items and place that many dots across arbitrary positions, disregarding the proper values and the proper count for each value.
* Students fail to place additional dots when a value appears multiple times in the data set, resulting in only one dot per unique value rather than one dot per occurrence.
* Students misread the number line scale and place dots at incorrect positions, especially when values fall on unlabeled tick marks (e.g., placing dots at 30 instead of 25).
* Students place dots for values that do not appear in the data set, add extra dots, or omit dots for values that do appear, resulting in an incorrect total number of dots.

Difficulty Definitions:
* Easy:
  5 to 10 (both inclusive) values - straightforward (no coins)
range of values at least 7 and at most 10
* Medium:
  10 to 18 (both inclusive) values (no coins)
range of values at least 10 and at most 12
* Hard:
  10 to 12 (both inclusive) values and use coins

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Dot Plots with Tally Marks
Lesson Order: 132.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+2
Standard Description: Given a frequency table that uses tally marks, identify the matching dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Convert tally-mark frequency data into a dot plot by placing the correct number of dots above each data value.

Assessment Boundaries:
* Assessment is restricted to:
* Questions must assess matching/representing frequency data from a tally-mark table to a dot plot.
* Exactly 1 categorical/measurement variable with exactly 5 distinct x-values (as in the example’s 5 columns of distances).
* X-values (Numbers): Allowed x-values must be whole numbers and/or half units (values ending in .0 or .5).
* X-values (Range): a must be a whole number from 0 to 10 (so x-values stay within 0 to 12).
* Frequencies (Counts): Each category frequency must be a whole number from 0 to 10.
* Total Observations: Total frequency (sum across the 5 x-values) must be between 10 and 25 inclusive and may be stated explicitly in the stem.

Common Misconceptions:
* Confuses each tally mark with one full group of five.
* Ignores half-unit x-values, placing those dots on neighboring whole numbers.
* Miscounts tally groups, treating the diagonal slash as an extra item.
* Treats each x-value as one dot, regardless of the tally frequency.

Difficulty Definitions:
* Easy:
  All the category are whole numbers.
* Medium:
  Category include fractions with halves like 1 1/2
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: The Relationship Between Work and Income
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.A
Standard Description: Given a problem, explain the connection between human capital/labor and income.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: The Relationship Between Work and Income
Lesson Order: 130.0
Standard ID: TEKS.MATH.CONTENT.3.9.A+1
Standard Description: Given a problem, explain the connection between human capital/labor and income.

Key Concepts:
*None specified*

Learning Objectives:
* Distinguish between factors that affect income from labor and factors that are unrelated to income.
* Identify situations that involve both labor (work performed) and income (money earned) versus situations that involve only spending, volunteering, or personal expenses.
* Identify the most reasonable statement about how a person’s earnings change when they are paid by the hour and work more or fewer hours.
* Identify which factors are relevant to determining how much income a person earns from work.

Assessment Boundaries:
* Assessment is restricted to:
Real-world contexts involving labor (work performed) and income (money earned)
Situations where income is determined by work-related factors, such as:
Hours worked
Experience, skills, or education
Questions that require students to:
Identify which factors do affect how much a person is paid for work, or
Identify which factors do not affect pay (e.g., personal or household characteristics)
Scenarios may involve:
Hourly work with a constant rate (explicitly stated or implied), or
General descriptions of employment where pay depends on work-related qualifications
Income may change only due to work-related causes, not personal spending, family size, or saving habits
Exactly one causal relationship is assessed per question:
More or higher-quality work-related factors → more income
Fewer or unrelated factors → no increase in income
No calculations, equations, or multi-step reasoning
Students reason qualitatively about cause-and-effect relationships between labor and income

Common Misconceptions:
* Student assumes pay changes randomly rather than depending on hours worked
* Student believes working fewer hours can result in earning more money
* Student confuses income earned with effort given (e.g., more hours means less labor)
* Student ignores the idea of a constant hourly rate

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Number Line Estimation:  Rounding to Nearest Thousand
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.C
Standard Description: Use a number line to accurately round numbers to the nearest thousand by interpreting points, identifying benchmarks, and determining proximity using midpoints

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value & Number Comparison (within 10,000s/100,000s)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.C
Standard Description: Analyze and manipulate numbers up to 100,000 through place value understanding, number comparison, and conversion between different numerical forms

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Rounding on the Number Line: Word Problems
Lesson Order: 109.0
Standard ID: TEKS.MATH.CONTENT.3.2.C+1
Standard Description: Use a number line to accurately round numbers to the nearest ten, hundred or thousand by interpreting points, identifying benchmarks, and determining proximity using midpoints

Key Concepts:
*None specified*

Learning Objectives:
* Identify the point on a number line that best represents a given approximate value in real-world situations.
* Interpret a point’s position on a number line to determine which benchmark value it is closest to and describe the approximate amount using real-world contexts.
* Use a number line to round numbers to the nearest ten, hundred, or thousand by identifying benchmark numbers and the midpoint.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only, from 0 to 20,000.
- No negative numbers, fractions, or decimals.
- No questions about Point A, Point B, etc. all must be real-world context
- All rounding is to the nearest ten or hundred
- Focus is solely on interpreting and estimating; no calculation, addition, or subtraction required.
- Real-world contexts (e.g., money, population, distance)
- Question stem must introduce context (e.g. "The point on the number line represents the amount needed to build a garage \n What statement best describes the amount needed to build a garage?" or "The points on the number line show the number of miles four track team members
ran during the week. \n Which track member ran about 40 miles?")

Common Misconceptions:
* Students assume rounding always means go up.
* Students focus on absolute size instead of relative closeness.
* Students ignore scale and spacing on the number line.
* Students misinterpret the midpoint on a number line.

Difficulty Definitions:
* Easy:
  Use a number line with increments of 1,000 to round numbers that are already close to a thousand mark.
Identify the nearest thousand for numbers ending in 500 or 0 using a number line.
* Medium:
  Use a number line with increments of 100 to round numbers to the nearest thousand.
Determine the midpoint between two thousand marks on a number line and decide which thousand a given number is closer to.
Point can be in midpoint
* Hard:
  N/a

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value Words
Lesson Order: 103.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+1
Standard Description: Analyze and manipulate numbers up to 100,000 through place value understanding

Key Concepts:
*None specified*

Learning Objectives:
* Convert a place-value description to a correct number  with numbers from 10000 upto 100000 and choose the best option.
* Convert a place-value description to a correct number  with numbers in the thousands and choose the best option.

Assessment Boundaries:
* Assessment is restricted to:                                                                                     1) Number types & ranges

- Only whole numbers- (no decimals, fractions, or negatives).
- Values range from the hundreds up to 100,000.
- Standard-form numbers must use commas correctly, e.g. `4,728`, `52,068`, `90,241`.

---

2) Representations allowed

- Standard form- with commas.
- Place-value descriptions in words*, e.g.

  - “three ten-thousands, five thousands, eight hundreds, two tens, and four ones”
  - “seven thousands and fourteen tens”.

---

3) Question types allowed

(Each with example question + required answer format)

##3.1 “Write the number using digits.” (MCQ)

- Stem pattern:

  - “How do you write this number using digits?”
- Options: 4 numbers; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`, `B`, `C`, or `D`.


---

##3.2 “Write the number using digits.” (MCQ)

- Stem pattern:

  - “How do you write this number using words?”
- Options: 4 numbers; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`–`D`.

##3.3 Represent numbers with real-world problems with proper english names ( MCQ)

- Stem pattern:

  - “Evie has 70 hundreds, 1 ten, and 15 ones.
Which number does this represent?”
- Noah has 3 thousands, 27 tens, and 14 ones.
Which number does this represent?
- 4 word descriptions; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`–`D`.

---

4) Operations

- No computation required beyond interpreting place-value language.
- No subtraction, multiplication, or division between multi-digit numbers.

---
5) Answers shoud be such that the “ending” (e.g., last two digits) isn’t a giveaway:
 -- At least two options should share the same ending.
 -- Sometimes the correct answer should share its ending with one or more incorrect options.
 -- Other times, the option(s) that share an ending should be incorrect, so the ending alone can’t determine the answer.
 -- Exactly one correct answer only
6) Language and clarity (double negatives)

- Avoid double negatives in all items.
- If the stem is negative (e.g., “does NOT describe”), answer choices must be written as clear, positive descriptions (do not include “not/never/except” in options).

Common Misconceptions:
* Confuses the digit's position with its place value when describing numbers in words.
* Ignores or misinterprets zeros as placeholders when translating between standard and word form.
* Reverses the order of place-value units when reading or writing multi-digit numbers.
* Treats commas as indicators to say "hundred" instead of "thousand" in place-value descriptions.

Difficulty Definitions:
* Easy:
  .
Choose the option that correctly matches a 5 digit place-value description to a number (thousands/hundreds/tens/ones).
Question types expected:
b) "How do you write this number using digits?" (4 digits at max)
Distractors should:
a) Swap one place (hundreds ↔ tens, tens ↔ ones)
b) Keep digits similar so it’s not obvious
* Medium:
  Choose the option that correctly matches a 5-digit number to a place-value description including ten-thousands
Question types expected:
b) How do you write this number using words?
Distractors should:
a) Target **internal-zero mistakes** (e.g., treating 54,060 like 54,600)
b) Use **one-place shift** traps (thousands vs ten-thousands)
* Hard:
  Represent numbers with real-world problems.
Using groups of ten to bundle or unbundle without changing the total.
Question types expected:
a) Evie has 70 hundreds, 1 ten, and 15 ones.
Which number does this represent?
b) Noah has 3 thousands, 27 tens, and 14 ones.
Which number does this represent?
Distractors should:
a) Include **3 incorrect descriptions**(off by one place / regrouping error) and **1 correct**

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Expanded Notation
Lesson Order: 104.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+2
Standard Description: Analyze and manipulate numbers up to 100,000 through conversion between different numerical forms

Key Concepts:
*None specified*

Learning Objectives:
* Spot an incorrect place-value decomposition/description of a number with numbers up to 100,000, including cases with zeros in a place and choose the best option.

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Comparing Numbers
Lesson Order: 104.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+3
Standard Description: Analyze and manipulate numbers up to 100,000 through number comparisons

Key Concepts:
*None specified*

Learning Objectives:
* Determine whether a comparison is true or not true by comparing digits from left to right with numbers ranging upto 1000
* Use a 2-column table (1000<numbers <100000) to choose the TRUE/FALSE comparison
* Use a 2-column table (numbers <10000) to choose the TRUE/FALSE comparison

Assessment Boundaries:
* 1) Number types & ranges

- Only whole numbers- (no decimals, fractions, or negatives).
- Values range from the hundreds up to 100,000.
- Standard-form numbers must use commas correctly, e.g. `4,728`, `52,068`, `90,241`.

---

2) Representations allowed

- Standard form- with commas.
- Comparison statements- using `>`, `<`, `=`.
- Bullet-point clues- mixing inequalities and digit conditions
  (e.g., “greater than 32,500”, “less than 32,900”, “hundreds digit is 7”).
- One-way tables- with:

  - A label column- (parks, cities, theaters, animals, etc.).
  - A numeric column- (area, population, tickets sold, weight, etc.).

---

3) Table constraints (structure + answer format)

Table questions MUST embed the table inside `$.question` using HTML** in this exact structure:

  * Intro sentence, then two line breaks (`\n\n`), then a **bold title line** using `<strong>…</strong>`, then two line breaks, then the `<table …>` block, then two line breaks, then the final question sentence.
  * Required layout (exact tags/attributes):

    * `<table style="border-collapse: collapse; width: 100%; max-width: 400px;">`
    * `<thead>` with a single header row `<tr>` containing **exactly 2 `<th>` cells**
    * `<tbody>` containing **exactly 4 rows** (`<tr>`), each with **exactly 2 `<td>` cells**
    * Every `<th>` and `<td>` MUST use **this exact inline style**:
      `style="border: 1px solid #000; padding: 4px; text-align: left;"`

#Answer format for table items (MCQ only)

- Stem patterns:

  - “Which comparison of these ___ is true?”
  - “Which comparison of these ___ is NOT true?”
- Exactly 4 answer options.
- Each option is a numeric comparison built from numbers in the table only, in the form:

  - `number 1 < number 2`
  - `number 1 > number 2`
  - `number 1 = number 2`
- Do not restate the context in the option (“The population of City A is less than…”). Options are just number–symbol–number.
- For “Which comparison … is true?” → exactly one option true; the other three false.
- For “Which comparison … is NOT true?” → exactly one option false; the other three true.
- Avoid double negatives in options (no “not”, “never”, “except” inside answer choices).
- If options are stored/rendered as HTML, encode `<` and `>` as `&lt;` and `&gt;` in the content string.

---

4) Question types allowed

(Each with example question + required answer format)

##4.5 Clue-based number identification (bullet clues MCQ)

- Stem pattern:

  - “The list shows clues about a number… Which of these could be the number described?”
- Prompts use 3 bullet clues:

  - 2 range clues (`>`, `<`)
  - 1 digit-condition clue (place + value).
- Options: 4 numerals- in standard form.

Answer format: Single letter- `A`–`D`.
- Clue list formatting (required): The prompt must include a bullet list written as either:


- HTML: a <ul> containing exactly three <li>
---

##4.6 Direct comparisons (no table, MCQ)

- Stem patterns:

  - “Which comparison is true?”
  - “Which comparison is NOT true?”
- Options: 4 comparison statements- using `>`, `<`, `=` between two multi-digit numbers.

Answer format: Single letter- `A`–`D`.

---

##4.7 Table comparisons (MCQ with table)

- Stem patterns:

  - “Which comparison of these ___ is true?”
  - “Which comparison of these ___ is NOT true?”
- Uses a 2-column table- (see section 3). Options compare table numbers only- with `>`, `<`, `=`.

Answer format: Single letter- `A`–`D`.

---

5) Operations

- No arithmetic beyond comparing digits by place value.
- No subtraction, multiplication, or division between multi-digit numbers.

---

6) Language and clarity (double negatives)

- Avoid double negatives in all items.
- If the stem is negative (e.g., “NOT true”), then answer choices must be written as clear, positive comparisons (no negatives inside options).
- Items should not feel like trick questions; wording should test comparison/place-value understanding.

Common Misconceptions:
* Assumes the number with more digits is always smaller because it "looks longer."
* Compares only the leftmost digits and ignores place value when numbers have different digit counts.
* Reads multi-digit numbers left-to-right as separate single digits rather than understanding place value.
* Reverses the meaning of inequality symbols, treating less-than as greater-than and vice versa.

Difficulty Definitions:
* Easy:
  1)Clues

  - Range + one digit-in-place condition

  - Numbers ≤ 10,000 (prefer 3 digits; allow 4 digits only if still “low thousands”)

  - Distractors violate exactly one clue (too high/low OR wrong digit place)

2) Direct comparisons (false statement)

  - 3–4 digit comparisons (within 1,000s)

  - Exactly one statement false

  - Distractors: same leading digit(s), differ in tens/ones; sign-direction trap

3) Table (true)

  - Table values all within 1,000s (3-digit or low 4-digit)

  - Stem: “Which comparison is true?”

  - Distractors: sign flip or swapped entity pair (numbers must come from table)

  - Table to have real world context.
* Medium:
  1) Clues

  - Numbers > 10,000

  - Same structure; digit condition may target thousands/hundreds/tens/ones

2) Direct comparisons (false statement)

  - 4-digit comparisons across thousands (0–9,999)

  - Near-miss distractors (share thousands digit; differ in hundreds/tens)

3) Table (NOT true)

  - Allowed only if max(table_value) ≤ 9,999

  - Distractors: sign flip / swapped pair using table values only

  - Table to have real world context.
* Hard:
  1) Direct comparisons (false statement)

  - Values up to 100,000

  - Near-miss distractors with shared leading digits

2) Table (true OR NOT true)

  - If any table value ≥ 10,000 →

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Money: Represent and Count
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.C
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Money: Represent and Count
Lesson Order: 105.0
Standard ID: TEKS.MATH.CONTENT.3.4.C+1
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Representing and Counting Money
Lesson Order: 108.0
Standard ID: TEKS.MATH.CONTENT.3.4.C+1
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:
Currency types: U.S. coins (penny, nickel, dime, quarter) and bills ($1, $5, $10, $20).
No use of $50 or $100 bills, foreign currency, or nonstandard coins.
Totals must not exceed $20 and no more than 5 of the same currency.
Calculations are limited to addition only (no subtraction, multiplication, or division).
No use of fractions or decimals; all coin values appear in standard U.S. currency format (e.g., $0.25, not ¼).
Each item is embedded in a real-world context (e.g., shopping, saving, receiving change).
The context must not require inference beyond money recognition (e.g., no multi-step transactions or tax calculation).
“Does not match” questions must include one clearly incorrect image whose total differs by at least $0.25.
No problems that involve mixed equivalences (e.g., “two nickels equal one dime”).
No requirement to convert between dollars and cents.
All currency symbols follow standard format (e.g., $1.25).
No use of algebraic symbols, tables, or word equations.
No requirement to interpret written number words (e.g., “five dollars”).
No mention of "image", should just say "which of the following"/"amount shown"
Never write the explicit amount of bills and coins in the questions stem (e.g. She has 5 quarters, etc.)

Common Misconceptions:
* Students confuse coin denominations or misremember values.
* Students count coins as individual units instead of aggregating value.
* Students rely on visual quantity rather than numerical value.
* Students struggle to combine mixed denominations correctly.

Difficulty Definitions:
* Easy:
  Identify the total value of a set of coins (pennies, nickels, dimes) up to $1.
Match a simple real-world situation with an image of coins and bills totaling less than $5.
Select the correct image of coins and bills for a given amount under $5.
* Medium:
  Identify the total value of a set of mixed coins and bills up to $10.
Match a real-world situation with an image of coins and bills totaling between $5 and $10.
Determine which image of coins and bills does not match a given amount under $10.
* Hard:
  Identify the total value of a set of mixed coins and bills up to $20.
Match a more complex real-world situation with an image of coins and bills totaling between $10 and $20.
Determine which image of coins and bills does not match a given amount between $10 and $20.

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+5
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers using the Standard Algorithm
Lesson Order: 106.0
Standard ID: TEKS.MATH.CONTENT.3.4.G+1
Standard Description: Solve mathematical problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Multiply a two-digit whole number by a one-digit whole number.

Assessment Boundaries:
* Assessment is restricted to:
- NO regrouping at all
- Whole numbers only
- Question stem should ONLY be "Multiply:", no question marks
- Two-digit number MUST be on top
- Vertical Multiplication MUST have format: <br><br>$\\begin{array}{r}\\phantom{\\times}xx\\\\\\times\\,xx\\\\\\hline &\\vphantom{\\mathtt{0}} \\\\ \\end{array}$ <br><blank>

Common Misconceptions:
* Student forgets to regroup when the product of the ones digits is greater than 9
* Student misaligns digits in the vertical algorithm, causing place value errors
* Student multiplies only the ones digit and ignores the tens digit
* Student regroups but adds the carried value to the wrong place value

Difficulty Definitions:
* Easy:
  Both digits of the two-digit number are less than 5
The one-digit multiplier is less than 5
No regrouping
* Medium:
  Both digits of the two-digit number are less than 5
The one-digit multiplier is greater than or equal to 5
Regrouping may be required in the ones place
* Hard:
  Both digits of the two-digit number are greater than or equal to 5
The one-digit multiplier is greater than or equal to 5
Regrouping is required and must be applied correctly across places

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+5
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers: Word Problems
Lesson Order: 107.0
Standard ID: TEKS.MATH.CONTENT.3.4.G+2
Standard Description: Solve real-world problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Solve one-step word problems by multiplying a two-digit whole number by a one-digit whole number.

Assessment Boundaries:
* Assessment is restricted to:
Whole numbers only
One-step word problems that require multiplying a one-digit number by a two-digit number
Contexts limited to familiar Grade 3 situations (e.g., money, groups of items, repeated quantities)
Answers are required as whole numbers with appropriate units when provided (e.g., dollars, items)
No estimation, no multi-step reasoning, and no division

Common Misconceptions:
* Student forgets to regroup when the product of the ones digits is greater than 9
* Student misaligns digits in the vertical algorithm, causing place value errors
* Student multiplies only the ones digit and ignores the tens digit
* Student regroups but adds the carried value to the wrong place value

Difficulty Definitions:
* Easy:
  No regrouping
* Medium:
  Regrouping required
* Hard:
  N/a

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multi-step Word Problems: Solve or Represent with an Equation
Lesson Order: 105.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+1
Standard Description: Solve multi-step word problems by representing them with equations and using various mathematical operations and models

Key Concepts:
*None specified*

Learning Objectives:
* Combine deposits and withdrawals in one equation.
(e.g., Stem: “Freddie had $256 in his bank account. On Monday he put $50 more into his account. On Tuesday he took out $87 to buy a bicycle. Which equation can be used to find the amount of money Freddie had in his bank account after he took out money on Tuesday?” → 256 + 50 − 87)
* Compare a combined total to a single amount.
(e.g., Stem: “Wanda traveled on an airplane three times last year. She traveled 278 mi in January, 652 mi in April, and 767 mi in September. How many more miles did Wanda travel in January and April combined than she traveled in September?” → 163 mi)
* Find the difference between one quantity and the sum of two others.
(e.g., Stem: “Samantha, Gordon, and Diego each brought an ice chest to a picnic. Samantha’s ice chest weighed 83 lb. Gordon’s weighed 28 lb. Diego’s weighed 37 lb. What was the difference in pounds between the weight of Samantha’s ice chest and the combined weight of Gordon’s and Diego’s ice chests?” → 18 lb)
* Given a strip model, form an equation to find the difference between a total cost and savings.
(Question should always be in this format(but shouldn't be exactly the same) e.g.: “Timothy wants to buy a camera that costs $75. He has saved $23. Which equation can be used to find how much more money Timothy needs?” → 75 − 23)
* Given a strip model, form an equation to find the difference between a total cost and savings.
(e.g., Stem: “Timothy wants to buy a camera that costs $75. <<Strip model>>. He has saved $23. Which equation can be used to find how much more money Timothy needs?” → 75 − 23)
* Identify and add the two largest values from a table.
(e.g., Stem: “The table shows the numbers of puzzle pieces in four puzzles. Derek put together the two puzzles that had the greatest numbers of pieces. What is the total number of pieces in these two puzzles?” → Not here – the correct sum (498 + 473 = 971) isn’t one of the listed answers)
* Identify and add the two largest values from a table. (e.g., Stem: “The table shows the numbers of puzzle pieces in four puzzles. Derek put together the two puzzles that had the greatest numbers of pieces. What is the total number of pieces in these two puzzles?” → The answer choices should always be whole number and not equations.)
* Identify the incorrect equation for finding a sold amount.
(e.g., Stem: “Tyrese had 572 baseball cards. He sold some of the baseball cards and then had 98 baseball cards left. Which equation could NOT be used to find the number of baseball cards Tyrese sold?” → 98 + 572 = □)
* Model repeated multiplication and division.
(e.g., Stem: “To make posters, 6 students each collected 8 pictures of animals. The students put 4 animal pictures on each poster they made. Which equation shows one way to find the number of posters the students made?” → 6 × 8 ÷ 4)
* Solve for a missing addend given the total.
(e.g., Stem: “A cafeteria sold a total of 313 drinks on Wednesday. The table shows the number of each type of drink that was sold, but the number of bottles of milk is missing. Which set of equations can be used to find the number of bottles of milk sold?” → add the known drink counts and subtract from the total; e.g., 172 + ? + 263 = 313 and ? = 313 − 172 − 263)
* Use multiplication to represent doubling an equal‑groups scenario.
(e.g., Stem: “A classroom currently contains 6 rows of chairs with 5 chairs per row. On parents’ night the classroom had twice as many chairs. Which number sentence can be used to find the number of chairs in the classroom on parents’ night?” → 6 × 5 × 2)
* Write an equation to model a two‑step addition/subtraction situation.
(e.g., Stem: “An art teacher had 736 crayons. She threw away 197 broken crayons. Then she bought 150 more crayons. Which equation shows how to find the number of crayons the art teacher has now?” → 736 − 197 + 150)

Assessment Boundaries:
* Assessment is restricted to:
* Whole numbers only (0–1,000).
* Multi-step problems involving addition, subtraction, multiplication, and division.
* Addition and subtraction limited to 3-digit numbers (e.g., 767 – 652).
* Multiplication and division limited to basic facts and single-digit factors (e.g., $6 \times 8 \div 4$).
* Questions primarily require identifying the correct equation/number sentence rather than just the final calculation.
* Unknown quantities must be represented by a symbol (box $\square$ or question mark).
* Currency is treated as whole numbers only (e.g., $75); no decimals or cent values.
* No fractions, decimals, remainders in division, or negative numbers.
* Real-world scenarios are limited to countable inventory (crayons, ribbons), measurement (miles, pounds), and whole-dollar banking.

Common Misconceptions:
* Students add the known part to the total instead of subtracting to find the difference.
* Students assign incorrect signs to sequential events (e.g., adding a loss or subtracting a gain).
* Students select operations based on isolated keywords (e.g., "more" implies addition) rather than the problem's logic.
* Students treat all numbers as addends, ignoring multiplication or division contexts.

Difficulty Definitions:
* Easy:
  Write an equation for a two-step addition/subtraction problem using simple numbers (e.g., under 100).
Identify and add the two largest values from a table with small numbers.
Use multiplication to represent doubling with small numbers (e.g., 2 rows of 3 chairs).
Solve for a missing addend with small numbers and a simple total.
* Medium:
  Write an equation to model a two-step addition/subtraction situation with larger numbers (e.g., three-digit numbers).
Use multiplication to represent doubling an equal-groups scenario with moderate numbers (e.g., 6 rows of 5 chairs).
Given a strip model, form an equation to find the difference between a total cost and savings with moderate numbers.
Combine deposits and withdrawals in one equation with moderate numbers.
* Hard:
  Model repeated multiplication and division with larger numbers (e.g., 6 students, 8 pictures each, 4 pictures per poster).
Compare a combined total to a single amount with larger numbers and multiple steps.
Identify the incorrect equation for finding a sold amount with complex numbers.
Find the difference between one quantity and the sum of two others with larger numbers and multiple steps.

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Input-Output : Rule from a Table (Functional Pattern)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.E
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Input-Output : Rule from a Table (Functional Pattern)
Lesson Order: 107.0
Standard ID: TEKS.MATH.CONTENT.3.5.E+1
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

PART 1: TABLE FORMAT (MANDATORY - READ FIRST)
Table Structure (MUST be HTML):
Tables contain 3 to 5 rows of data and MUST have 3 columns (first column CANNOT be days of the week, should be letters or names)
Column headers must be labeled with real-world context (e.g., “Number of Books” and “Sale Price”).
Any table appearing in the question (stem or answer option) MUST follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and Temperature</h5>\n\n<table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n  <thead>\n    <tr>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Day</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Monday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Tuesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Wednesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Thursday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">25 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n    </tr>\n  </tbody>\n</table>
"""

PART 2: CONTENT CONSTRAINTS
All values in tables are whole numbers only.
No decimals, fractions, negative numbers, or mixed numbers.
All operations are limited to a single addition, subtraction, and multiplication (no division).

Numerical Ranges:
Numbers in tables range from 1 to 200.
Sums, differences, or products must not exceed 500.
Additive relationships must use constants no greater than 25.
Multiplicative relationships must use single-digit or small double-digit factors (2–12).

Context and Realism:
Every item must have a real-world context (e.g., prices, quantities, scores, items, plants, or objects).
Contexts must represent familiar, age-appropriate scenarios (e.g., store purchases, classroom scores, or collections).
No abstract, algebraic, or purely numerical tables without context.
No multi-step operations

Question Structure:
Question stems MUST be one of: 
1. <<sentence setting up context>>The table shows the relationships....<<table>>Which of these describes the relatioship in the table?
2. <<sentence setting up context>> Which of table shows <<relationship>>?
Each question stem must clearly specify whether the task is to identify, apply, or describe the relationship.
All numerical values should include appropriate units when relevant (e.g., “dollars,” “points,” “flowers”).
No symbolic algebra or equation writing (e.g., “y = 3x”).   

PART 3: ANSWER OPTION FORMAT (MANDATORY)

All answer choices MUST be complete explanatory statements, not short conclusions.

Each answer choice MUST:

State a constant value (e.g., item cost).

Explicitly describe the operation relating the two columns (e.g., “amount paid minus ___ equals change”).

Use the word “because” to justify the relationship.

Answer choices MUST follow one of these exact templates (no deviation):

Subtraction relationship template:

“Each item costs ___ dollars, because the amount paid minus ___ equals the change received.”

Addition relationship template (if applicable):

“Each item costs ___ dollars, because the change received plus ___ equals the amount paid.”

All incorrect answer choices MUST:

Use the same sentence structure as the correct answer.

Contain a plausible but incorrect constant.

Answer choices MUST NOT:

Ask the student to compute.

Refer to specific rows by letter.

Introduce new numbers not present or inferable from the table.

Use symbolic notation or equations.

Common Misconceptions:
* - Students confuse additive and multiplicative relationships.
* - Students focus only on surface-level number changes rather than identifying the consistent rule.
* Students fail to verify consistency across all rows of the table.
* Students reverse the relationship direction between quantities.

Difficulty Definitions:
* Easy:
  Identify a simple addition or subtraction rule in a table with small numbers.
Recognize a table that matches a straightforward multiplication relationship with small numbers.
* Medium:
  Determine a rule involving addition or subtraction with larger numbers in a given context.
Identify a table that represents a multiplication relationship using larger numbers.
Analyze a table to determine which statement about a real-world relationship is true.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Finding Rules from Tables
Lesson Order: 110.0
Standard ID: TEKS.MATH.CONTENT.3.5.E+1
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
* Given a context, identify a rule in a table. (e.g., “Mr. Morales gives bonus points… Which of these describes the relationship shown in the table?” where test scores before and after a bonus are shown as 79→83, 81→85, etc. → The test score before bonus points plius 4 equals the test score after the bonus points.)
* Given a table of real world relationship, deetermine which statement regarding the relationship is true? (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3 × as many yellow flowers as red flowers in each vase.)
* Given a table of real world relationship, determine which statement regarding the relationship is true? (division or subtraction) (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3 less yellow flowers than red flowers in each vase.)
* Given a table of real world relationship, determine which statement regarding the relationship is true? (multiplication and addition) (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3  more yellow flowers than red flowers in each vase.)
* Given a table showing an amount paid and the corresponding change received, determine the constant cost of an item by identifying and justifying the additive relationship between the two quantities.
* Identify a table that represents a given real world relationship.(e.g., “Kacie sold bracelets… She sold 3 bracelets for $1… Which table represents the numbers of bracelets that would be sold for different numbers of dollars?” → Multiply the number of dollars by 3.)
* Identify a table that represents a given relationship described in a real world situation.(e.g.,  “A store is having a sale… The sale price of each book is $6 less than the regular price… Which table shows prices of different books?” → The sale price is regular price – $6.)
* Identify from 4 table answer options, which table represents a given real world relationship (multiplication or addition).(e.g., “Kacie sold bracelets… She sold 3 bracelets for $1… Which table represents the numbers of bracelets that would be sold for different numbers of dollars?”)
* Identify from 4 table answer options, which table represents a given real world relationship. (division or subtraction) (e.g., “Kacie sold bracelets discounted… Each discounted bracelet was $3 less than regular price… Which table represents the price of the bracelets sold by Kacie?”)

Assessment Boundaries:
* Assessment is restricted to:

PART 1: TABLE FORMAT (MANDATORY - READ FIRST)
Table Structure (MUST be HTML):
Tables contain 3 to 5 rows of data and MUST have 3 columns (first column CANNOT be days of the week, should be letters or names)
Column headers must be labeled with real-world context (e.g., “Number of Books” and “Sale Price”).
Any table appearing in the question (stem or answer option) MUST follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and Temperature</h5>\n\n<table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n  <thead>\n    <tr>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Day</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Monday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Tuesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Wednesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Thursday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">25 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n    </tr>\n  </tbody>\n</table>
"""

PART 2: CONTENT CONSTRAINTS
All values in tables are whole numbers only.
No decimals, fractions, negative numbers, or mixed numbers.
All operations are limited to a single addition, subtraction, and multiplication (no division).

Numerical Ranges:
Numbers in tables range from 1 to 200.
Sums, differences, or products must not exceed 500.
Additive relationships must use constants no greater than 25.
Multiplicative relationships must use single-digit or small double-digit factors (2–12).

Context and Realism:
Every item must have a real-world context (e.g., prices, quantities, scores, items, plants, or objects).
Contexts must represent familiar, age-appropriate scenarios (e.g., store purchases, classroom scores, or collections).
No abstract, algebraic, or purely numerical tables without context.
No multi-step operations

Question Structure:
Question stems MUST be one of: 
1. <<sentence setting up context>>The table shows the relationships....<<table>>Which of these describes the relatioship in the table?
2. <<sentence setting up context>> Which of table shows <<relationship>>?
Each question stem must clearly specify whether the task is to identify, apply, or describe the relationship.
All numerical values should include appropriate units when relevant (e.g., “dollars,” “points,” “flowers”).
No symbolic algebra or equation writing (e.g., “y = 3x”).   

PART 3: ANSWER OPTION FORMAT (MANDATORY)

All answer choices MUST be complete explanatory statements, not short conclusions.

Each answer choice MUST:

State a constant value (e.g., item cost).

Explicitly describe the operation relating the two columns (e.g., “amount paid minus ___ equals change”).

Use the word “because” to justify the relationship.

Answer choices MUST follow one of these exact templates (no deviation):

Subtraction relationship template:

“Each item costs ___ dollars, because the amount paid minus ___ equals the change received.”

Addition relationship template (if applicable):

“Each item costs ___ dollars, because the change received plus ___ equals the amount paid.”

All incorrect answer choices MUST:

Use the same sentence structure as the correct answer.

Contain a plausible but incorrect constant.

Answer choices MUST NOT:

Ask the student to compute.

Refer to specific rows by letter.

Introduce new numbers not present or inferable from the table.

Use symbolic notation or equations.

Common Misconceptions:
* - Students confuse additive and multiplicative relationships.
* - Students focus only on surface-level number changes rather than identifying the consistent rule.
* Students fail to verify consistency across all rows of the table.
* Students reverse the relationship direction between quantities.

Difficulty Definitions:
* Easy:
  Identify a simple addition or subtraction rule in a table with small numbers.
Recognize a table that matches a straightforward multiplication relationship with small numbers.
* Medium:
  Determine a rule involving addition or subtraction with larger numbers in a given context.
Identify a table that represents a multiplication relationship using larger numbers.
Analyze a table to determine which statement about a real-world relationship is true.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Classify 3D-Shapes
Lesson Order: 111.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+1
Standard Description: Classify and sort three-dimensional shapes, distinguishing between prisms and non-prisms, based on their geometric properties

Key Concepts:
*None specified*

Learning Objectives:
* Given two images with sorted shapes, identify a statement about the sorted figures that is true.

Assessment Boundaries:
* Global Assessment Boundaries (Applies to all tasks):

Allowed Shapes: Figures are strictly limited to cubes, rectangular prisms, triangular prisms, cylinders, cones, and spheres.

Constraint: Pyramids (such as square or triangular pyramids) may be included as distractors or as examples of non-prisms, but students are not required to identify the figure specifically as a "pyramid."

Classification Criteria: The core assessment must focus on the following 3rd-grade attributes: the presence of flat faces/edges/vertices (polyhedra) vs. curved surfaces (non-polyhedra), and the distinction between a prism and a non-prism.

Vocabulary: Questions must use formal geometric language for the shape names (e.g., "prism," "cylinder," "sphere," "cone," "rectangular prism," "cube," "non-prism"). Informal terms are not allowed.

Stimulus Variety: Stimuli may include both drawings of geometric figures and real-world objects. Real-world objects must be clear representations of the allowed 3D shapes.

Exclusions: No assessment of attributes beyond grade 3 is allowed (e.g., volume, surface area, nets). Students are not required to use or identify formal vocabulary beyond the shape names (e.g., face, edge, vertex) for the purpose of classification.

II. Task-Specific Assessment Boundaries: A. Task Type: Grouping and Classification Tables

Question Stem: Must require the student to analyze a pre-sorted set of figures and choose the correct grouping table.

Item Count: Questions must use a total of exactly 4 figures/objects.

Table Grouping Constraint: For the correct answer option, the table MUST consist of exactly two groups with an unbalanced 3/1 split (exactly 3 objects in one group and 1 object in the other). Tables with a 2/2 split are strictly prohibited for the correct answer.

Grouping Rationale: The sorting rationale must involve core classification: Prisms vs. Non-Prisms OR Shapes with curved surfaces vs. shapes with flat faces.

Distractor Requirement: All distractors must also utilize a 3/1 structural split to mirror the correct answer. Distractors must be incorrect based on geometric properties (e.g., misclassifying an object) or mathematical counts (e.g., listing a shape that wasn't in the stimulus).

B. Task Type: Identify Prism vs. Non-Prism

Question Stem: Must ask either "Which figure CAN be classified as a prism?" or "Which figure CANNOT be classified as a prism?"

Stimulus Mix: Each question must provide four answer options using a mix of figures:

For "CANNOT be a prism" questions: Provide three prisms and one non-prism.

For "CAN be a prism" questions: Provide three non-prisms and one prism.

Focus: The question tests the fundamental understanding of the definition of a prism versus a non-prism based on the presence of flat faces vs. curved surfaces.

C. Bin Sorting (For LO - Given two images with sorted shapes, identify a statement about the sorted figures that is true.)
Question Stem: The question must strictly ask: "Which statement about the figures in Bin A and Bin B is true?"

Stimulus Requirement:

The stimulus must present two clearly labeled containers: Bin A and Bin B.

Each bin must contain a set of figures sorted by a specific geometric attribute.

Mandatory Answer Choice Phrasing: All four answer options (A, B, C, D) must strictly use the syntax: "All the figures in bin [Label] are [Classification/Shape]".

Approved "True" Classification Categories: The correct answer must be limited to one of the following specific statements:


"All the figures in bin [X] are cylinders"

"All the figures in bin [X] are cones"

"All the figures in bin [X] are triangular prisms"

"All the figures in bin [X] are spheres"


Distractor Requirement:

All distractors must utilize the same mandatory syntax to remain indistinguishable in structure from the correct answer.

Distractors should misclassify the shapes in the bins (e.g., claiming a bin of varied rectangular prisms contains "all cubes").

All figures used in the bins must be selected from the Allowed Shapes list: cubes, rectangular prisms, triangular prisms, cylinders, cones, and spheres.

Common Misconceptions:
* Assumes a shape must have rectangular faces to be classified as a prism.
* Classifies any non-prism with a flat face (e.g., cone, pyramid) as a prism.
* Confuses cylinders and cones with prisms, treating them all as having rectangular sides.
* Treats cubes and rectangular prisms as distinct from the general category of "prisms."

Difficulty Definitions:
* Easy:
  - Identify a statement about sorted figures from two images with clearly distinct shapes.
  - Determine which shape can be classified as a prism from a simple list of common shapes.
* Medium:
  - Given six figures of 3D shapes, determine which list shows a correct way to group the figures based on basic properties.
  - Determine which shape cannot be classified as a prism using familiar shapes like cubes and pyramids.
* Hard:
  - Given four figures of 3D shapes, determine which table shows a correct way to group the figures, requiring understanding of less common shapes and properties.
  - Identify a true statement about sorted figures that involves more complex reasoning or less familiar shapes

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Comparing Fractions Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.D
Standard Description: Compare fractions in word problems to develop problem-solving skills at the rigor of standardized assessments.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Identifying Correct Fraction Comparisons
Lesson Order: 129.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+1
Standard Description: Identify correct inequality statements comparing two or more fractions presented in visual models, word problems, or tables.

Key Concepts:
*None specified*

Learning Objectives:
* Given a table with multiple fraction values, determine which comparison statement is true
* Given a word problem, determine which inequality statement correctly compares fractions.
* Given two fraction circles with custom shading (one uses non-consecutive sector shading), determine which inequality statement correctly compares the two fractions.

Assessment Boundaries:
* Assessment is restricted to:

Questions present two or more rational values (fractions and/or mixed numbers) and ask students to identify the TRUE comparison statement.
Answer choices are comparison statements using only these symbols: >, <, =, or "None of this".
Values in the answers (not in the stimulus requirements) must be written using LaTeX:
Proper or improper fractions: \frac{numerator}{denominator}
Mixed numbers: whole\frac{numerator}{denominator}
Denominators are limited to: 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20.
Improper fractions are allowed in word-problem and table questions, and may also appear in answer choices.
Constraint for grade-level rigor: if an improper fraction is used, it must represent a value less than 10 and use an allowed denominator.
Fraction-models must use proper fractions only in the stimulus because the model generator requires numerator <= denominator.

Contexts may be:
Visual fraction circles (models),
Short real-world word problems (numbers),
Tables of names/items with fraction values (tables).

Items must be solvable using grade-appropriate strategies (benchmarks, equivalence, common denominators, mixed-number comparison).

Common Misconceptions:
* Students assume a fraction with a larger denominator is always smaller, without considering the numerator
* Students compare only numerators or only denominators instead of comparing the overall fraction values
* Students misread visual fraction models, either counting total sections incorrectly or miscounting shaded parts
* Students select "equal" when fractions look similar but have different values, failing to convert to common denominators to verify

Difficulty Definitions:
* Easy:
  **

  - Two visual fraction models (shaded circles) are shown
  - Students determine which inequality correctly compares the two fractions
  - Answer choices are three comparison statements (>, =, <) plus "None of these"
  - Fractions can be read directly from the visual model
  - Stem exactly:
Each circle represents a fraction.<br/><br/>
Which statement correctly compares the two fractions?


**
* Medium:
  **

A word problem includes 2–3 values as fractions and/or mixed numbers (improper fractions allowed).
Students choose the true comparison statement among the options.
Requires comparing values with different denominators and/or values greater than 1.

**
* Hard:
  **

A table shows 4–6 names/items with fraction/mixed-number values.
Students choose the true comparison statement referencing specific table rows.
Requires selecting the correct pair from multiple values and comparing accurately.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Comparing Multiple Fractions
Lesson Order: 130.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+2
Standard Description: Find fractions or identify items that satisfy a given comparison relationship in word problems and tables.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

- Questions present a reference fraction and ask students to find a value that is greater/less than it
- Answer choices are individual fraction VALUES (not inequality statements)
- OR answer choices are NAMES/ITEMS that satisfy the comparison (qualitative answers)
- Contexts include real-world scenarios: measurements, task completion percentages, amounts

Common Misconceptions:
* Students assume a smaller denominator always means a larger fraction, leading them to incorrect conclusions (e.g., thinking 2/3 > 3/4 because 3 < 4).
* Students compare correctly but select a value satisfying the inverse relationship—choosing a larger value when asked for "less than" or a smaller value when asked for "greater than."
* Students fail to recognize that fractions like 10/15 and 2/3, or 6/8 and 3/4, are equal—leading to incorrect comparisons when unsimplified fractions appear.
* Students select a fraction equal to the reference value when asked for "greater than" or "less than," failing to understand that equality does not satisfy a strict inequality.

Difficulty Definitions:
* Easy:
  **

  - Word problem states a reference fraction and a comparison relationship (greater than, less than)
  - Students select which fraction value could satisfy the relationship
  - Answer choices are 4 individual fraction values
  - Single comparison required
  - Contexts: thickness, weight, volume, time, amounts

**
* Medium:
  **

  - Table presents 4+ people/items with fraction values
  - Question asks which people/items are greater than (or less than) a reference fraction
  - Answer choices are qualitative: names or groups (e.g., "Nate and Marc only", "Rudy only")
  - Requires comparing multiple fractions to the reference value
  - Contexts: task completion, survey results, test scores

**
* Hard:
  **

  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Multi-Step Fraction Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.F
Standard Description: Solve multi-step word problems involving the addition and subtraction of fractions with like denominators to meet STAAR-level rigor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Subtraction Word Problems Involving Fraction Models
Lesson Order: 131.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+1
Standard Description: Subtract fractions using visual models.

Key Concepts:
*None specified*

Learning Objectives:
* Find the answer to a subtraction using one fraction model.
* Write a subtraction expression using one fraction model.
* Write a subtraction expression using two fraction models.

Assessment Boundaries:
* - Subtraction of fractions with like denominators (same denominator)
- Denominators from 4 to 12
- Proper fractions only (numerator < denominator)
- Real-world contexts: pizza, ribbon, book, trail, etc.

Common Misconceptions:
* Changing the denominator incorrectly when writing the expression (e.g., writing 16/40 − 13/40 instead of keeping the common denominator of 20).
* Confusing the combined fraction with one person's fraction in one-model problems (e.g., if the model shows 5/9 combined and Darrell ate 2/9, mistakenly thinking 5/9 is Nani's fraction instead of the combined amount).
* Confusing the denominator with the numerator when reading the fraction from the model (e.g., if 13 out of 20 parts are shaded, writing 20/13 instead of 13/20).
* Writing the fractions in the wrong order when setting up a subtraction expression (e.g., writing 13/20 − 16/20 instead of 16/20 − 13/20 when finding the difference between a larger and smaller fraction).

Difficulty Definitions:
* Easy:
  - TWO labeled fraction models (pie or bar)
  - Question asks "Which expression can be used to find the difference?"
  - Student reads fractions from both models
* Medium:
  - ONE unlabeled fraction model
  - One fraction stated in stem
  - Question asks "Which expression can be used to find the fraction that [Person B] [action]?"
* Hard:
  - ONE unlabeled fraction model
  - One fraction stated in stem
  - Question asks "What fraction did [Person B] [action]?"

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Determining the Remaining Fraction of a Whole
Lesson Order: 132.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+2
Standard Description: Determining the remaining fraction of a whole

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

**General Constraints:**
- All items are MCQ with exactly four answer options
- Fractions have denominators from 4 to 12
- All fractions are proper fractions (numerator < denominator)

**Question Format:**

Type 1 (EASY - With Visual Model):
- Stimulus: Circular fraction model with shaded and unshaded sections
- Shaded sections represent the given part; unshaded sections represent the remaining part
- Question asks for the remaining (unshaded) fraction
- Answer options: Four fractions with the same denominator
- Model clearly shows equal division lines
- Shaded sections MUST align exactly with division lines (no partial shading)

Type 2 (MEDIUM - Without Visual Model):
- NO visual stimulus
- Word problem provides a fraction representing part of a whole
- Question asks for the remaining fraction
- Student must convert 1 to n/n and subtract
- Answer options: Four fractions with the same denominator as the given fraction

If there is a fraction in answer options, it should be written as $\frac{_}{_}$, $\frac{_}{_}$

Common Misconceptions:
* Confusing which part the question asks for—the given part versus the remaining part—especially with varied wording like "left," "remains," or "not used."
* Making arithmetic errors when subtracting from 1, such as forgetting to convert 1 to n/n or subtracting incorrectly
* Miscounting the shaded or unshaded sections in the visual model, especially when the model has many divisions.
* Stating the given fraction as the answer instead of finding the remaining fraction

Difficulty Definitions:
* Easy:
  - Visual fraction model (circular) provided
  - Shaded sections represent the given part
  - Student counts unshaded sections to find remaining fraction
* Medium:
  - NO visual model
  - Word problem states a fraction representing part of a whole
  - Student calculates: 1 − (given fraction) = remaining fraction
  - Must convert 1 to equivalent fraction (n/n) before subtracting
* Hard:
  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Comparing Fractions to Benchmarks
Lesson Order: 133.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+3
Standard Description: Finding the remaining fraction and comparing it to benchmark fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Find the remaining fraction of a whole and identify the closest benchmark from multiple options (1/4, 1/2)

Assessment Boundaries:
* **General Constraints:**
- All items are MCQ with exactly four answer options
- NO visual stimulus/models
- All fractions are proper fractions (numerator < denominator)
- Denominators range from 3 to 15
- Benchmark fractions: 1/4, 1/2, 3/4
- Exactly ONE answer option is correct
- All distractors must be strictly incorrect (no “also true” statements)
- Answer options must be mutually exclusive (no overlaps / subset relationships)
- Prohibit “None left / 0 left” options
- Prohibit mixing “About [benchmark] …” with “Exactly [benchmark] …” in the same option set
- Stem type must match choice type:
  - If stem says “closest,” all options must be benchmark-comparison candidates for closeness (not generic truth statements)
  - If stem says “Which statement is true?”, options must be truth-evaluable and constructed so only one is true
- Consistent fraction formatting across stem, options, and explanations (do not mix LaTeX and plain slash notation)
- Answer options are statements comparing the remaining amount to benchmark(s)
- Questions ask "Which is closest to the fraction left?" or "Which statement is true?"

**Fraction Constraints by Level:**
- EASY/MEDIUM: One fraction given; student finds complement (1 − fraction)
- HARD: Two fractions given; student adds them, then finds complement

**Answer Option Format:**
- "Less than [benchmark] of the [item] was left."
- "About [benchmark] of the [item] was left."
- "More than [benchmark] of the [item] was left."
- "[Person] will have more/less than half [item] left."
- "Exactly [benchmark] of the [item] was left."

**Context Requirements:**
- Food items: cereal, pizza, pie, cake, chips
- Collections: cards, stickers, coins, books
- Tasks: homework, project, book pages
- Products: chip flavors, muffin types
- Use diverse names from various backgrounds

Common Misconceptions:
* Confusing what remains with what was used/given away, especially when answer options include statements about both (e.g., selecting "Greg will sell more than half" when asked about what's left).
* Forgetting to add both fractions before subtracting from 1, or making errors when converting unlike denominators to find a common denominator.
* Incorrectly comparing the remaining fraction to benchmark fractions
* Stating the given fraction as the remaining fraction instead of finding the complement

Difficulty Definitions:
* Easy:
  **
  - ONE fraction given representing portion used/consumed
  - Find remaining: 1 − (given fraction)
  - Compare to ONE benchmark: 1/2 only
  - Answer options reference 1/2: "more than half," "less than half," "exactly half", 1/3 or 1/4.
  - Denominators: 3, 4, 5, 6, 8
  - Like denominators only (no conversion needed for comparison)

**
* Medium:
  **
  - ONE fraction given representing portion used/consumed
  - Find remaining: 1 − (given fraction)
  - Compare to TWO benchmarks: 1/4 and 1/2
  - Answer options reference both 1/4 and 1/2: "Less than 1/4," "About 1/4," "Less than 1/2," "About 1/2"
  - Denominators: 5, 6, 8, 9, 10, 12
  - Student must determine which benchmark is closest

**
* Hard:
  **
  - TWO fractions given representing different portions
  - Add the fractions (may require finding common denominator)
  - Find remaining: 1 − (sum of fractions)
  - Compare to ONE benchmark: 1/2
  - Answer options are statements: "more than half left," "less than half left," "exactly half left," etc.
  - Denominators: 3, 4, 5, 6, 8, 10, 12, 15
  - May have like or unlike denominators
  - Sum of fractions must be < 1

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Multi-Step Word Problems with Money
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.4.A
Standard Description: Solve multi-step word problems involving the addition and subtraction of money using decimals to the hundredths place.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Multi-Step Word Problems with Money
Lesson Order: 121.0
Standard ID: TEKS.MATH.CONTENT.4.4.A+1
Standard Description: Solve multi-step word problems involving the addition and subtraction of money using decimals to the hundredths place.

Key Concepts:
*None specified*

Learning Objectives:
* Solve multi-step word problems involving money by calculating profit. Problems require understanding that profit is the difference between the amount received from selling and the amount spent on buying.

Assessment Boundaries:
* Assessment is restricted to:

- Question stem must be a real-world scenario and 20-120 words in length.
- Monetary amounts must be in U.S. dollars and cents using decimal notation.
- All amounts must be positive and less than or equal to $1,000.00.
- Contexts must be real world, age and grade appropriate.
- Answers must include the dollar sign and two decimal places for cents.
- For currency representation with dollar symbol ($), use forward slash (/) to escape it so it is not interpreted as LaTeX (e.g., use \$ instead of $).


CHARACTER NAMES (Randomly select from this name list):
Emma, Olivia, Noah, Ethan, Mason, Isabella, Lucas, Aiden, Jackson, Amelia, Sebastian, Harper, Mateo, Evelyn, Benjamin, Abigail, James, Emily, Alexander, Ella, William, Scarlett, Daniel, Grace, Henry, Chloe, Michael, Victoria, Owen, Riley, Samuel, Aria, David, Lily, Joseph, Zoey, Carter, Penelope, Wyatt, Layla, John, Nora, Luke, Hannah, Gabriel, Sofia, Leo, Camila, Nathan, Aurora, Caleb, Luna, Elijah, Stella, Isaac, Violet, Ryan, Hazel, Jack, Ivy, Dylan, Ruby, Jaxon, Maya, Levi, Aaliyah, Adrian, Savannah, Kai, Paisley, Jayden, Elena, Eli, Naomi, Marcus

Common Misconceptions:
* Adding buying cost instead of subtracting: Students may incorrectly add the buying cost to the total selling amount instead of subtracting it, resulting in a larger amount than the correct answer. This reflects a misunderstanding of what profit means.
* Confusing buying cost with profit: Students may select the buying cost as the answer, confusing the amount spent with the amount earned. This indicates a fundamental misunderstanding of the profit concept.
* Forgetting to subtract buying cost: Students may correctly calculate the total selling amount by adding all three selling prices, but forget to subtract the buying cost, resulting in selecting the total selling amount as the answer instead of the profit.
* Making addition errors when totaling selling prices: Students may understand the profit calculation process but make mistakes when adding the three individual selling prices together, such as misaligning decimal places, forgetting to carry over, or adding incorrectly.

Difficulty Definitions:
* Easy:
  -Solve multi-step word problems involving money by calculating total costs using repeated addition (adding the unit price the required number of times) combined with addition.
* Medium:
  -Solve multi-step word problems involving money by calculating remaining money after a purchase. Problems require adding different denominations of money (bills and coins) to find the initial total, then subtracting the purchase cost to find how much money remains. Denominations MUST be described using proper monetary terminology (e.g., "two $10 bills", "one $5 bill", "four dimes", "six pennies", "three quarters", "two nickels") OR 
  -Solve multi-step word problems involving money by calculating change from a bill or gift card. Problems involve purchasing 2-3 items (with at least one item having a quantity greater than 1), requiring multiplication (unit price × quantity), addition (sum of all items), and subtraction (change from the amount paid).
* Hard:
  -Solve multi-step word problems involving money by calculating profit. Problems require understanding that profit is the difference between the amount received from selling and the amount spent on buying.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.5
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Additive Area Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.5.D
Standard Description: Solve real-world problems by calculating the area of shapes using given models and side lengths.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.5
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Compound Area Problems with Missing Side Lengths
Lesson Order: 126.0
Standard ID: TEKS.MATH.CONTENT.4.5.D+1
Standard Description: Solve real-world problems by calculating the area of shapes using given models and side lengths.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real world context and a side-by-side rectangles model for the context, find the area of the left shaded rectangle
* Given a real world context and a side-by-side rectangles model for the context, find the area of the right shaded rectangle
* Given a real world context and a stacked rectangles model for the context, find the area of the bottom shaded rectangle
* Given a real world context and a stacked rectangles model for the context, find the area of the top shaded rectangle

Assessment Boundaries:
* Assessment is restricted to:
- All shapes mentioned must be squares or rectangles.
- All side lengths must be single-digit or double-digit integers.

Common Misconceptions:
* Confuses area with perimeter, adding side lengths instead of multiplying length and width.
* Counts squares along one side only, ignoring two-dimensional coverage.
* Subtracts given lengths incorrectly to find missing side of a rectangular section.
* Uses entire model’s dimensions rather than the specific rectangular section’s dimensions.

Difficulty Definitions:
* Easy:
  - All side lengths are single-digits
* Medium:
  - Involves single-digit and double-digit side lengths
* Hard:
  - All side lengths are double-digits

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Lines of Symmetry
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.6.B
Standard Description: Identify and classify figures based on the number of lines of symmetry they possess.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Lines of Symmetry
Lesson Order: 122.0
Standard ID: TEKS.MATH.CONTENT.4.6.B+1
Standard Description: Identify and classify figures based on the number of lines of symmetry they possess.

Key Concepts:
*None specified*

Learning Objectives:
* Identify which line is NOT a line of symmetry

Assessment Boundaries:
* Two-dimensional figures only, including basic shapes (triangles, rectangles, squares, 
circles, parallelograms, trapezoids, pentagons, hexagons, octagons) and compound shapes 
made by combining basic shapes.

Figures presented as visual images without measurements or coordinates.

Students count or compare the number of lines of symmetry, not draw or construct them.

Questions ask students to identify or select figures based on symmetry criteria such as:
  • Exactly n lines of symmetry (e.g., exactly 2)
  • At least n lines of symmetry (e.g., at least 1)
  • n or more lines of symmetry (e.g., 2 or more)
  • Fewer than n lines of symmetry
  • Zero lines of symmetry
  • Has horizontal but NOT vertical line of symmetry

For MEDIUM questions ONLY this question: 
Which figures have a horizontal line of symmetry but NOT a vertical line of symmetry?

No three-dimensional shapes or rotational symmetry (only reflection symmetry).

Common Misconceptions:
* Students assume all regular-looking or "balanced" shapes have lines of symmetry (missing that parallelograms and scalene triangles have zero), or believe that having a vertical line of symmetry means the shape must also have a horizontal one
* Students either stop counting after finding one or two obvious lines (missing diagonal lines in squares or additional lines in regular polygons), or double-count by treating the same fold from opposite directions as two separate lines
* Students identify any line that divides a shape into two equal areas as a line of symmetry, without verifying that the halves are exact mirror images when folded along that line
* Students mix up vertical (up-down) and horizontal (left-right) orientations, misclassify diagonal lines as vertical or horizontal, or fail to recognize symmetry orientation when figures are rotated

Difficulty Definitions:
* Easy:
  - Identify or select one or more figures based on a specified symmetry criterion.
  - Questions may involve selecting a single figure that matches the criterion OR selecting all figures from a set that satisfy the condition.
  - Figures include basic shapes (squares, rectangles, circles, triangles, parallelograms, trapezoids, pentagons, hexagons, octagons) and compound shapes made by combining basic shapes.
  - Figures may be oriented in any direction (not always vertical/horizontal alignment).
  - Criteria use clear language such as: "exactly n lines of symmetry," "at least n lines of symmetry," "n or more lines of symmetry," "fewer than n lines of symmetry," or "zero lines of symmetry."
  - Typically 2-6 answer choices; may have single or multiple correct selections.
  - Students count lines of symmetry for each figure and apply the criterion to determine valid selection(s).
* Medium:
  - Questions may use compound criteria requiring students to evaluate multiple 
  symmetry conditions:
 Override: Only this question:
Which figures have a horizontal line of symmetry but NOT a vertical line of symmetry?
* Hard:
  - Given a shape with labeled lines drawn through it, students must identify which ONE line is NOT a true line of symmetry. The shape displays actual symmetry line(s) plus one distractor (fake line).
  - The question should follow this pattern: "[N] lines are drawn through this shape. One of the lines is not a true line of symmetry. Which line is NOT a line of symmetry?"

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Classifying 2D Shapes by Properties
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.6.D
Standard Description: Classify 2D shapes by identifying their properties, including angles and side relationships.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Classifying 2D Shapes by Properties
Lesson Order: 120.0
Standard ID: TEKS.MATH.CONTENT.4.6.D+1
Standard Description: Classify 2D shapes by identifying their properties, including angles and side relationships.

Key Concepts:
*None specified*

Learning Objectives:
* Given a description of a shape that a student has drawn, identify or classify a polygon based on the number of certain angles.
* Given a description of a shape that a student has drawn, identify shapes with "at least" or "exactly" a given number of perpendicular or parallel opposite sides

Assessment Boundaries:
* Assessment is restricted to:
- Shapes to include are limited to: Acute triangle, Right triangle, Obtuse triangle, Rhombus, Parallelogram, Square, Rectangle, Trapezoid, Right trapezoid, Pentagon
- The correct answer should be one of the following: Square, or Rectangle
- It should be assumed that students know geometric terms like acute angle, obtuse angle, parallelogram, trapezoid, pentagon, etc.
- Specific angle measurements must not be included. A right angle should only be refered to as "right angle".
- Only simple versions of each shape type are to be considered. Questions must not require consideration of abstract variations of shape types.

Common Misconceptions:
* Assumes all shapes with right angles must be rectangles or squares.
* Confuses perpendicular sides with parallel sides when classifying quadrilaterals.
* Counts visual orientation instead of angle measures when identifying right angles.
* Treats any shape with one parallel pair as a trapezoid, ignoring other properties.

Difficulty Definitions:
* Easy:
  - The description gives one characteristics (ie exactly two right angles, exactly one pair of perpendicular sides, no acute angles)
* Medium:
  - The description gives more than one characteristics for sides or angles (ie. exactly one pair of opposite sides that are parallel. None of the sides are perpendicular to each other)
* Hard:
  N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Trapezoids
Lesson Order: 119.0
Standard ID: TEKS.MATH.CONTENT.4.6.D+2
Standard Description: Identify trapezoids and right trapezoids.

Key Concepts:
*None specified*

Learning Objectives:
* Identify all images of valid right trapezoids from a list of 3 or 4 options.
* Identify all images of valid right trapezoids from a list of 6 options.
* Identify all images of valid trapezoids from a list of 3 or 4 options.
* Identify all images of valid trapezoids from a list of 6 options.
* Identify if a given quadrilateral is a right trapezoid.
* Identify if a given quadrilateral is a trapezoid.

Assessment Boundaries:
* Assessment is restricted to:
- All shapes included in questions are quadrilaterals.
- Questions only required students to determine if the image(s) provided are trapezoids, right trapezoids, or neither.
- Stimulus descriptions are simple by design and will only capture the type of shape that will be displayed. This is intentional, and it is not a valid reason fro failure.

Common Misconceptions:
* Assumes trapezoids must have exactly one pair of parallel sides.
* Confuses trapezoids with any quadrilateral having slanted sides.
* Ignores right angles when identifying right trapezoids.
* Treats orientation as defining, rejecting trapezoids that are tilted or rotated.

Difficulty Definitions:
* Easy:
  - The questions stems asks "Is this quadrilateral a trapezoid?" and the answer options are "Yes" or "No"
* Medium:
  - The questions stems asks "Is this quadrilateral a right trapezoid?" and the answer options are "Yes" or "No"
  - The question stems prompts the student to "Select all the trapezoids." and there are 3-4 options available
* Hard:
  - The question stems prompts the student to "Select all right trapezoids." and there are 3-4 options available
  - The question stems prompts the student to "Select all the trapezoids." and there are 6 options available
  - The question stems prompts the student to "Select all right trapezoids." and there are 6 options available

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.8
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Multiplicative Patterns in Tables: Conversions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.8.B
Standard Description: Identify and apply multiplicative patterns for converting customary measurements.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.8
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Using Patterns in Tables for Conversions
Lesson Order: 125.0
Standard ID: TEKS.MATH.CONTENT.4.8.B+1
Standard Description: Identify patterns in tables and use them to convert units.

Key Concepts:
*None specified*

Learning Objectives:
* Identify and apply the multiplicative pattern in conversion tables using division (first column values are larger than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Yards Conversions").
* Identify and apply the multiplicative pattern in conversion tables using division when given a value from the second column (larger values) to find the equivalent value in the first column (smaller values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Yards-to-Feet Conversions"). The question provides a value in the second column and asks for the equivalent value in the first column.
* Identify and apply the multiplicative pattern in conversion tables using multiplication (first column values are smaller than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Inches Conversions").
* Identify the set of expressions that represents the relationship between the position of a number in a pattern and its value, where expressions use a single-step operation (addition, subtraction, multiplication, or division) and are written in the form n + k, n - k, n × k, or n ÷ k, where n represents the Position.

Assessment Boundaries:
* Assessment is restricted to:
- Tables must display 4 rows 
- All values in tables must be whole numbers.
- No mixed units in the same question.
- Only units of lenght are allowed


QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must follow this structure with explicit line breaks:

  [Introductory Sentence]: "The table shows different numbers of [first column unit] and the equivalent numbers of [second column unit]."
  [Question Sentence]: "[Person/Character] [action verb] [value] [unit from second column]. How many [unit from first column] did [person/character] [action verb]?"


Generate questions using diverse scenarios from the SCENARIO CONTEXT BANK. Each scenario includes character names and action verbs:

1. Construction - Characters: [Marcus, Hector, Diana, Rosa]; Actions: [measured, cut]
2. Sewing - Characters: [Sophie, Anna, Claire, Nadia]; Actions: [cut, measured]
3. Gardening - Characters: [Maya, Oscar, Felix, Violet]; Actions: [measured, dug]
4. Travel - Characters: [Nathan, Priya, Tara, Derek]; Actions: [walked, hiked, traveled]
5. Sports - Characters: [Jordan, Ryan, Casey, Morgan]; Actions: [ran, jogged, sprinted]
6. Art - Characters: [Iris, Pablo, Jade, Kai]; Actions: [measured, sketched]
7. School - Characters: [Liam, Grace, Owen, Zoe]; Actions: [walked, measured]
8. Pet Care - Characters: [Lucas, Chloe, Bella, Tucker]; Actions: [walked]
9. Home - Characters: [Sophia, James, Isabella, Ethan]; Actions: [measured, cut]
10. Transportation - Characters: [Kevin, Nicole, Victor, Paula]; Actions: [drove, traveled]
11. Nature - Characters: [Dr. Chen, Dr. Patel, Dr. Kim, Dr. Martinez]; Actions: [hiked, walked, measured]
12. Crafts - Characters: [Ella, Logan, Ruby, Finn]; Actions: [cut, measured]
13. Infrastructure - Characters: [Mr. Adams, Mr. Clark, Ms. Rivera, Ms. Nguyen]; Actions: [measured, walked]
14. Delivery - Characters: [Carlos, Elena, Brian, Laura]; Actions: [drove, traveled]
15. Recreation - Characters: [Tyler, Hannah, Cole, Paige]; Actions: [swam, walked, ran]
16. Animal Science - Characters: [Zara, Kyle, Leah, Evan]; Actions: [measured, walked]
17. Baking - Characters: [Megan, Henry, Nora, Jack]; Actions: [rolled, measured]
18. Camping - Characters: [Hunter, Sierra, Blake, Autumn]; Actions: [hiked, walked]
19. City Planning - Characters: [Robert, Maria, Steven, Jessica]; Actions: [measured, walked]
20. Fishing - Characters: [Wade, Pearl, Reed, Marina]; Actions: [cast, walked]
21. Furniture - Characters: [Carter, Hazel, Mason, Ivy]; Actions: [measured, cut]
22. Music - Characters: [Melody, Harper, Lyric, Quinn]; Actions: [measured]
23. Space - Characters: [Dr. Brooks, Dr. Santos, Dr. Wong, Dr. Hayes]; Actions: [traveled, measured]
24. Weather - Characters: [Mr. Stone, Mr. Wells, Ms. Lane, Ms. Frost]; Actions: [climbed, measured]
25. Winter Sports - Characters: [Aspen, Everest, Shawn, Brooke]; Actions: [skied, sledded, traveled]

Usage Guidelines:
- Select one scenario from the list above
- Choose a character name from the corresponding character list
- Choose an action verb from the corresponding action list
- Ensure the character name and action verb are contextually appropriate for the selected scenario
- Vary character names and action verbs across different questions to ensure diversity

Common Misconceptions:
* Added instead of divided: Student adds the conversion factor to the given value instead of dividing (e.g., 333 + 3 = 336 instead of 333 ÷ 3 = 111).
* Multiplied instead of divided: Student multiplies the given value by the conversion factor instead of dividing (e.g., 333 × 3 = 999 instead of 333 ÷ 3 = 111).
* Selected value from table: Student picks a value directly from the table that appears close to or related to the given value, rather than applying the pattern to the new value.
* Used wrong conversion factor: Student uses a related but incorrect conversion factor (e.g., using 12 instead of 3 when converting feet to yards, resulting in 333 ÷ 12 ≈ 28).

Difficulty Definitions:
* Easy:
  Identify the set of expressions that represents the relationship between Position and Value, where expressions use a single-step operation (addition, subtraction, multiplication, or division) with whole numbers. Multipliers are 4th grade appropriate. For subtraction, Position is greater than the subtrahend. For division, results are whole numbers with no remainders
* Medium:
  Identify and apply the multiplicative pattern in conversion tables using multiplication (first column values are smaller than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Inches Conversions").
* Hard:
  Identify and apply the multiplicative pattern in conversion tables using division when given a value from the second column (larger values) to find the equivalent value in the first column (smaller values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Yards-to-Feet Conversions"). The question provides a value in the second column and asks for the equivalent value in the first column.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: 122.0
Standard ID: Interpreting Stem-and-Leaf Plots
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit, e.g., 84, 96, 105, 117)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., "1|5 means 1.5")
- For whole numbers: stem = tens place, leaf = ones (e.g., "9|6 means 96")

PROBLEM TYPES:
Per the standard, students must solve one- and two-step problems:

1. ONE-STEP PROBLEMS:
   - Identify maximum or minimum value
   - Count total number of data points
   - Count data points in a specific range

2. TWO-STEP PROBLEMS:
   - Calculate range (find max, find min, subtract)
   - Calculate total sum of all values
   - Determine which plot correctly displays given data

QUESTION FORMATS:
Three question types based on STAAR examples:

1. CALCULATE FROM PLOT (Sum):
   - "What is the total number of [items]?"
   - Format: MCQ with 4 numerical options
   - Distractors: partial sum (missed a value), sum of stems only, calculation errors

2. CALCULATE FROM PLOT (Range):
   - "What is the difference between the highest and lowest [value]?"
   - Format: MCQ with 4 numerical options
   - Distractors: subtracted stems only, misread leaf digit, decimal place errors

3. CREATE/MATCH PLOT:
   - "Which stem-and-leaf plot displays these data?"
   - Format: MCQ with 4 plot options
   - Distractors: leaves out of order, missing data points, wrong stem for 3-digit numbers, reversed stem/leaf

REQUIRED ELEMENTS:
- Each plot includes a key (e.g., "9|6 means 96 tickets" or "1|5 means a score of 1.5")
- Real-world, grade-appropriate contexts
- Plots have 4-6 rows (stems)
- Data sets contain 7-15 values
- No mean or median calculations
- Students select correct plots, not draw them by hand

DISTRACTOR DESIGN GUIDANCE:
Vary the concept tested in each answer option - Don't just change numbers in the same format!

For calculation questions, distractors should reflect different misconceptions:
- One option: correct answer
- One option: partial calculation (skipped a data point)
- One option: misread the notation (stems only, or decimal place error)
- One option: computation error (close to correct but off by small amount)

For match-plot questions, distractors should include:
- Correct plot
- Plot with leaves in wrong order
- Plot with missing data point(s)
- Plot with stem/leaf reversal or wrong stem for 100s

LATEX STRUCTURE:

Never put \n inside LaTeX $$ ... $$! Strictly prohibited.

For CALCULATE questions (Sum):

Example:
The stem-and-leaf plot shows the numbers of tickets Stephen won when he played games at a carnival.

$$
\begin{array}{c}
\text{Number of Tickets Won}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
8 & 4\ 8 \\
9 & 0\ 6\ 8 \\
10 & 5\ 5 \\
11 & 7 \\
\end{array}
$$

$$
\boxed{\text{9|6 means 96 tickets}}
$$

What is the total number of tickets that Stephen won at the carnival?

A. 783
B. 178
C. 81
D. 678

For CALCULATE questions (Range with Decimals):

Example:
The stem-and-leaf plot shows the scores given to the dogs at a dog show. Possible scores were between 0.1 and 5.0.

$$
\begin{array}{c}
\text{Dog Show Scores}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
0 & 8 \\
1 & 2\ 5 \\
2 & 2\ 4\ 8 \\
3 & 0\ 3\ 6\ 8 \\
4 & 0\ 5\ 5 \\
\end{array}
$$

$$
\boxed{\text{1|5 means a score of 1.5}}
$$

What is the difference between the highest score and the lowest score shown in the stem-and-leaf plot?

A. 4.3
B. 3.7
C. 0.25
D. 0.47

For CREATE/MATCH questions:

Example:
The table shows the total numbers of runs different baseball teams scored in one season.

$$
\begin{array}{|c|c|}
\hline
\text{Team} & \text{Total Number of Runs Scored} \\
\hline
R & 61 \\
S & 92 \\
T & 100 \\
U & 65 \\
V & 72 \\
W & 64 \\
X & 84 \\
\hline
\end{array}
$$

Which stem-and-leaf plot displays these data?

[Four plot options A, B, C, D with variations]

REAL-WORLD CONTEXTS (Grade 4 appropriate):

Sports & Games:
- Carnival game tickets won
- Arcade tickets collected
- Video game points scored
- Basketball free throws made
- Soccer goals scored in a season
- Baseball runs scored
- Board game wins during family game night
- Bowling scores
- Mini golf scores
- Race times (in seconds)

School & Learning:
- Minutes spent reading
- Pages read in a week
- Books read in a month
- Spelling test scores
- Math quiz scores
- Science project scores
- Homework completion times (minutes)
- Library books checked out

Animals & Nature:
- Dog show scores (decimals)
- Pet weights (pounds or kilograms)
- Plant heights in science lab (centimeters, decimals)
- Fish lengths caught during fishing trip
- Bird species counted during bird watching
- Eggs collected from chicken coop

Daily Life:
- Steps walked in a day
- Minutes of exercise
- Pieces of candy collected (Halloween, party)
- Stickers in a collection
- Trading cards owned
- Glasses of water drunk in a week
- Hours of sleep

Food & Money:
- Cups of lemonade sold at a stand
- Cookies baked for a sale
- Money earned from chores (dollars)
- Fruit pieces in lunchboxes
- Ice cream scoops sold

Creative & Building:
- LEGO bricks used in a build
- Blocks in a tower-building contest
- Puzzle completion times (minutes)
- Drawing contest scores
- Craft supplies used

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also misread individual leaf digits (e.g., reading 8 as 2, leading to 4.3 instead of 3.7 for a range calculation).
* When calculating range with decimals, students subtract stems and leaves separately (e.g., for 4.5 − 0.8: doing 4−0=4 and 5−8=−3, then combining incorrectly to get 0.47) instead of subtracting full decimal values to get 3.7. Students may also use wrong values for max or min due to misreading leaves.
* When calculating totals, students skip data points (e.g., missing one "105" gives 678 instead of 783), add only some rows instead of all values, or count the number of data points instead of summing the actual values.
* When matching data to plots, students select plots with leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), plots missing data points, plots with three-digit numbers under wrong stems (e.g., 100 placed under stem "1" instead of stem "10"), or plots with stem and leaf positions reversed.

Difficulty Definitions:
* Easy:
  - Identify a single value (maximum, minimum) directly from the plot
  - Count the number of data points in the plot
  - Whole numbers only
  - Stem values: single digits (1-9)
  - Leaf values: single digits, primarily 0-5
  - 4-5 rows (stems)
  - 6-8 data points
  - One-step problems
  - 4-option MCQ format
* Medium:
  - Calculate range (find max, find min, subtract)
  - Match raw data to correct stem-and-leaf plot
  - Whole numbers OR decimals with one decimal place
  - Stem values: any single digits (0-9) or two digits (10, 11)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 7-10 data points
  - Two-step problems
  - 4-option MCQ format
* Hard:
  - Calculate total (sum) of all values in the plot
  - Decimals with one decimal place in calculation problems
  - Stem values: any, including two-digit stems (10, 11)
  - Leaf values: any single digits (0-9)
  - 5-6 rows (stems)
  - 10-15 data points
  - Multi-step problems requiring careful tracking of all values
  - 4-option MCQ format
  - May combine skills (e.g., find sum, then compare)

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Frequency Tables
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.9.A
Standard Description: Interpret frequency tables to identify corresponding data sets.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Create Frequency Tables
Lesson Order: 127.0
Standard ID: TEKS.MATH.CONTENT.4.9.A+1
Standard Description: Create or update frequency tables from data sets.

Key Concepts:
*None specified*

Learning Objectives:
* Identify the data set that matches a given frequency table.
* Identify which row in a frequency table is incomplete by comparing it to the original data set.
* Select the frequency table that represents a given data set.

Assessment Boundaries:
* Assessment is restricted to:

**General Constraints:**

- All items are MCQ with exactly four answer choices
- Frequency tables display tally marks (the `draw_frequency_table` function automatically renders numeric frequency values as visual tally marks)
- Tally mark convention: | = 1, || = 2, ||| = 3, |||| = 4, |||| with diagonal strike = 5
- All data values are whole numbers (0–20 range)
- Total data points: 8–20 items per data set

**Technical Note on Tally Marks:**
The stimulus schema uses numeric `frequency` values (integers 0-20). These are automatically converted to visual tally marks by the drawing function. For example, `"frequency": 7` renders as |||| || (a group of 5 with diagonal strike plus 2 marks). This is the correct behavior - the schema stores counts, the renderer displays tally marks.

**Difficulty Progression (Scaffolded):**

The difficulty progression is designed to build skills incrementally:

1. **Easy (Type 1)**: Students start with concrete data and find the matching table - more scaffolded
2. **Medium (Type 2)**: Students interpret tally marks to reconstruct data - requires reading visual representation
3. **Hard (Type 3)**: Students compare data to an incomplete table - requires both skills plus error detection

**Question Types:**

Type 1 (Data → Table) - EASY ONLY:
- Stimulus: Data list provided as comma-separated values in question stem
- Question asks: "Which frequency table represents all of the data in the list?"
- Answer options: Four frequency table images with identical structure but different tally counts
- Note: StimulusRequired = FALSE (images are in answers only)
- Scaffolding: Student works from concrete data to visual representation

Type 2 (Table → Data) - MEDIUM ONLY:
- Stimulus: Frequency table image with tally marks in question stem
- Question asks: "Which set of data could the frequency table represent?"
- Answer options: Four data lists as comma-separated values
- Note: StimulusRequired = TRUE (image is in question)
- Challenge: Student must interpret tally marks to identify matching data

Type 3 (Incomplete Row) - HARD ONLY:
- Stimulus: Data list AND incomplete frequency table (one row has wrong count) in question stem
- Question asks: "Which row of the frequency table is incomplete?"
- Answer options: Four row labels (e.g., "The row showing 0 to 4 books")
- Note: StimulusRequired = TRUE (image is in question)
- Challenge: Student must count data per interval AND compare to tally marks

**Category Constraints:**

Easy (Type 1):
- Categories can be single numbers (0, 1, 2, 3, 4, 5) OR ranges
- 4–6 categories in the table
- Each category may have 0–6 occurrences

Medium (Type 2):
- Categories can be single numbers OR ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
- 4–6 categories/intervals
- Data list has 10–16 values

Hard (Type 3):
- Categories are ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
- 4 intervals with equal width (typically 5)
- Exactly ONE row is incomplete (has fewer tallies than actual count)
- The error is 1–2 tallies off

**Distractor Design:**

Type 1 Distractors:
- Miscounted tallies (off by 1–2 in one or more categories)
- Swapped counts between adjacent categories
- Boundary errors for range categories

Type 2 Distractors:
- Data lists with wrong counts per interval
- Data lists with values outside the table's range
- Data lists with boundary values in wrong intervals

Type 3 Distractors:
- Rows that are actually complete (correct count)
- Row with highest frequency (students assume "most = incomplete")
- Edge rows (first or last interval)

**Context Requirements:**

- Every question must include a real-life context
- Use diverse contexts: books read, goals scored, pets owned, volunteer hours, etc.
- Use diverse character names: Mr. Westley, Sofia, Jamal, Mei, Carlos, etc.
- Avoid repeating contexts in consecutive questions

Common Misconceptions:
* Confusing the interval labels with the frequency counts (e.g., thinking "5 to 9" means 5 items instead of checking how many data values fall in that range).
* Forgetting to count a data value when creating tally marks, especially when values repeat many times in the list.
* Miscounting tally marks, especially when groups of 5 are involved (e.g., counting |||| with strike as 4 instead of 5, or losing track when counting multiple groups like |||| |||| || as 10 instead of 12).
* Misplacing data values at interval boundaries (e.g., placing a value of 5 in the "0 to 4" interval instead of "5 to 9", or placing 10 in "5 to 9" instead of "10 to 14").

Difficulty Definitions:
* Easy:
  - Question Type: Type 1 (Data → Table)
  - Given a data list, select the matching frequency table from 4 MCQ options
  - Category type: Single numbers (0, 1, 2, 3, 4, 5) OR ranges
  - Images appear in ANSWER OPTIONS (student sees data, picks table)
  - Data list has 8–12 values
  - 4–6 unique categories
  - Tally marks per category: 1–6
  - Distractors have miscounted tallies (off by 1–2) or swapped counts
  - Scaffolding: Student works from concrete data to visual representation
* Medium:
  - Question Type: Type 2 (Table → Data)
  - Given a frequency table image, select the matching data set from 4 MCQ options
  - Category type: Single numbers OR ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
  - Image appears in QUESTION STEM (student reads table, picks data list)
  - Data list has 10–16 values
  - 4–6 categories/intervals
  - Requires interpreting tally marks to reconstruct data
  - Distractors have wrong counts per category or boundary errors
* Hard:
  - Question Type: Type 3 (Incomplete Row)
  - Given a data list AND an incomplete frequency table image, identify which row is incomplete
  - Category type: Ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
  - MCQ with 4 row labels as answer options
  - Data list has 12–20 values
  - Exactly one row has incorrect tally count (off by 1–2 tallies)
  - Other rows are completely correct
  - Requires counting data per interval and comparing to tally marks

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Frequency Tables
Lesson Order: 128.0
Standard ID: TEKS.MATH.CONTENT.4.9.A+2
Standard Description: Interpret frequency tables and their corresponding data sets.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the sum or difference of two frequency values from a frequency table.
(REQUIRES operation on TWO values — addition OR subtraction — never single-value lookup)
* Read and identify a single frequency value from a frequency table.
(DIRECT LOOKUP ONLY — NO operations, NO "difference", NO "total", NO two-category questions)

Assessment Boundaries:
* ## Table Constraints
- Frequency tables must contain between 4 and 6 categories.
- All frequency values must be whole numbers between 0 and 20.
- Text entry response format (single whole number answer).
- All categories must be numeric values or numeric ranges. E.g: "1","2","3" or "1-3","5-6". Not qualitative categories such as "vanilla", "chocolate", etc

## Difficulty Levels
- **Easy (LO1):** Direct lookup from one category. Answer MUST appear in the table.
- **Medium (LO2):** Addition or subtraction of two categories. Computed answer must NOT appear as any frequency value.

## Formatting Rules
- In question stems, use `\n` for line breaks. Never use `<br/>` or HTML tags.
- Every stem must start with "The frequency table shows [context]."

## Explanation Rules
- **LO1 (Direct Lookup):** "The frequency table shows [X] [subjects] [action] [category]."
- **LO2 (Operations):** "The frequency table shows [X] [subjects] [action] [cat1] and [Y] [subjects] [action] [cat2]. Add/Subtract: [X] + [Y] = [answer]." or "[X] − [Y] = [answer]."
- Use plain numbers in explanations (no LaTeX).

## Professional Wording (STAAR Format)
- **Subtraction:** "What is the difference between the number of [subjects] who [action] [category1] and the number who [action] [category2]?"
- **Addition:** "How many [subjects] [action] [category1] or [category2] in total?"

## Validator Notes
- The stimulus_description schema uses numeric frequency values (integers). The draw_frequency_table function automatically renders these as visual tally marks.
- For LO1: The answer MUST match a frequency in the table (that's the whole point of direct lookup).
- For LO2: If the computed answer matches a frequency value, the generator MUST retry with different values.

Common Misconceptions:
* Confuses the category label with the frequency count (answering "3" for "How many students watched 3 movies?" because 3 is in the question).
* Miscounts tally marks when groups of 5 are present (counting |||| with strike as 4 instead of 5).
* Reads the wrong row in the frequency table (looks at an adjacent category by mistake).
* When asked for a difference, adds instead of subtracts or subtracts in the wrong order.

Difficulty Definitions:
* Easy:
  - Question asks "How many [subjects] [action] [category]?"
  - Student reads a single frequency value directly from the table
  - Text entry response (single whole number)
* Medium:
  - Question asks "What is the difference between..." or "How many total..."
  - Student reads two frequency values and performs addition or subtraction
  - Text entry response (single whole number)
* Hard:
  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.9.B
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Creating Stem-and-Leaf Plots
Lesson Order: 123.0
Standard ID: TEKS.MATH.CONTENT.4.9.B+1
Standard Description: Organize and represent data by constructing stem-and-leaf plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of whole numbers that includes three-digit values (100-119), identify the stem-and-leaf plot that correctly displays the data using two-digit stems.

Assessment Boundaries:
* Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit: 30-99, three-digit: 100-119)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., "1|5 means 1.5")
- For whole numbers: stem = tens place, leaf = ones (e.g., "9|6 means 96")
- For 100s: stem = "10" or "11", leaf = ones (e.g., "10|5 means 105")

PROBLEM TYPE - ONLY THIS ONE IS ALLOWED:
- Match a data set to the correct stem-and-leaf plot (MCQ with 4 plot options)

EXPLICITLY NOT ALLOWED - DO NOT GENERATE THESE:
- Calculate total/sum questions (this is B+2)
- Calculate difference/range questions (this is B+2)
- Count questions (e.g., "How many values are greater than X?")
- Max/min identification questions
- Complete the plot / fill in the blank questions (separate LOs)

CONTENT CONSTRAINTS:
- Data sets contain 6-8 values
- Plots have 3-5 rows (stems)
- Real-world, grade-appropriate contexts

DISTRACTOR DESIGN (4 options required):
- ONE correct plot - leaves in ascending order (smallest to largest)
- ONE plot with leaves in DESCENDING order (largest to smallest) - tests ordering rule
- ONE plot missing one data point - tests completeness
- ONE plot with error based on data type:
  * For 100s: value placed under wrong stem (e.g., 100 under stem "1" instead of "10")
  * For decimals: stem and leaf reversed
  * For 2-digit: extra value not in data set

REAL-WORLD CONTEXTS (Grade 4 appropriate):
- Minutes spent reading
- Points scored in games
- Stickers collected
- Tickets won at arcade/carnival
- Books read
- Baseball runs scored
- Video game points
- Race times (for decimals)
- Plant heights (for decimals)
- Puppy weights (for decimals)

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also reverse stem and leaf positions (e.g., writing 61 as stem 1, leaf 6 instead of stem 6, leaf 1).
* When creating or matching plots, students miss data points (e.g., a plot showing only 6 values when the data set has 7), add extra values that don't exist in the data, or include duplicate leaves when the original data has no duplicates.
* When organizing data into a plot, students place leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), forgetting that leaves must be arranged from smallest to largest within each stem row.
* When working with three-digit numbers (100-119), students place values under the wrong stem (e.g., placing 100 under stem "1" instead of stem "10", or placing 105 under stem "1" with leaf "05" instead of stem "10" with leaf "5").

Difficulty Definitions:
* Easy:
  - Match a data set to the correct stem-and-leaf plot 
  - Whole numbers only (two-digit: 30-99 range)
  - Stem values: single digits (3-9)
  - Leaf values: single digits (0-9)
  - 3-4 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, extra value
* Medium:
  - Match a data set to the correct stem-and-leaf plot 
  - Whole numbers including three-digit (100-119)
  - Stem values: single digits (6-9) AND two digits (10, 11)
  - Leaf values: single digits (0-9)
  - 4-5 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, 100 under wrong stem
* Hard:
  - Match a decimal data set to the correct stem-and-leaf plot 
  - Decimals with one decimal place (e.g., 1.2, 1.5, 2.3)
  - Stem = ones place, Leaf = tenths place
  - Stem values: 0-4 typically
  - Leaf values: single digits (0-9)
  - 3-4 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, stem/leaf reversed

NOT ALLOWED AT ANY DIFFICULTY:
  - Sum/total questions
  - Difference/range questions
  - Count questions
  - Max/min questions
  - Complete the plot questions

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: 124.0
Standard ID: TEKS.MATH.CONTENT.4.9.B+2
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
* Given a stem-and-leaf plot with decimals (one decimal place), calculate the difference between the highest and lowest values OR calculate the total sum of all values.
* Given a stem-and-leaf plot with whole numbers, calculate the difference between the highest and lowest values OR calculate the total sum of all values.
* Given a stem-and-leaf plot, determine how many values fall above, below, or within a given threshold.

Assessment Boundaries:
* "Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit, e.g., 84, 96, 105, 117)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., ""1|5 means 1.5"")
- For whole numbers: stem = tens place, leaf = ones (e.g., ""9|6 means 96"")

PROBLEM TYPES - ONLY THESE TWO ARE ALLOWED:
1. Calculate total sum of all values
2. Calculate difference between highest and lowest values

EXPLICITLY NOT ALLOWED - DO NOT GENERATE THESE:
- Count questions (e.g., ""How many values are greater than X?"")
- Max/min identification (e.g., ""What is the highest value?"")
- Match data to plot (this is B+1, not B+2)
- Any question asking students to count data points

QUESTION FORMATS:

1. CALCULATE FROM PLOT (Sum):
   - ""What is the total number of [items]?""
   - Format: MCQ with 4 numerical options

2. CALCULATE FROM PLOT (Difference):
   - ""What is the difference between the highest and lowest [value]?""
   - NEVER use the word ""range""
   - Format: MCQ with 4 numerical options

REQUIRED ELEMENTS:

1. PLOT TITLE (MANDATORY): Every stem-and-leaf plot MUST have a centered title above it showing what the data represents WITH UNITS:

$$
\begin{array}{c}
\text{Plant Heights (m)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
...
\end{array}
$$

Examples of titles WITH units:
- \text{Plant Heights (m)}
- \text{Race Times (seconds)}
- \text{Dog Show Scores}
- \text{Stickers Collected}
- \text{Points Scored}
- \text{Puppy Weights (kg)}

2. KEY: Each plot includes a key below (e.g., ""9|6 means 96 tickets"" or ""1|5 means 1.5 m"")

3. Real-world, grade-appropriate contexts

4. Plots have 4-5 rows (stems) - MAXIMUM 5 rows for Grade 4

5. Data sets contain 8-10 values

6. No mean or median calculations

DISTRACTOR DESIGN:

For SUM questions:
- Correct answer
- Partial sum (skipped a data point)
- Misread notation (stems only, or decimal place error)
- Computation error

For DIFFERENCE questions:
- Correct answer
- Subtracted stems only
- Misread leaf digit
- Decimal place error

LATEX STRUCTURE:

Never put \n inside LaTeX $$ ... $$!

CORRECT FORMAT (with title):

$$
\begin{array}{c}
\text{Plant Heights (m)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
0 & 6\ 7 \\
1 & 1\ 5 \\
2 & 0\ 4\ 8 \\
3 & 2\ 6 \\
\end{array}
$$

$$
\boxed{\text{1|5 means 1.5 m}}
$$

REAL-WORLD CONTEXTS (Grade 4 appropriate):
[Keep existing list]"

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also misread individual leaf digits (e.g., reading 8 as 2, leading to 4.3 instead of 3.7 for a range calculation).
* When calculating range with decimals, students subtract stems and leaves separately (e.g., for 4.5 − 0.8: doing 4−0=4 and 5−8=−3, then combining incorrectly to get 0.47) instead of subtracting full decimal values to get 3.7. Students may also use wrong values for max or min due to misreading leaves.
* When calculating totals, students skip data points (e.g., missing one "105" gives 678 instead of 783), add only some rows instead of all values, or count the number of data points instead of summing the actual values.
* When matching data to plots, students select plots with leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), plots missing data points, plots with three-digit numbers under wrong stems (e.g., 100 placed under stem "1" instead of stem "10"), or plots with stem and leaf positions reversed.

Difficulty Definitions:
* Easy:
  - Calculate difference between highest and lowest values
  - Calculate total (sum) of all values in the plot
  - Whole numbers only
  - Stem values: single digits (1-9) or two digits (10, 11)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 6-10 data points
  - Two-step problems
  - 4-option MCQ format
* Medium:
  - Calculate difference between highest and lowest values
  - Calculate total (sum) of all values in the plot
  - Decimals with one decimal place only
  - Stem values: single digits (0-9)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 6-10 data points
  - Two-step problems
  - 4-option MCQ format
* Hard:
  Not applicable for this standard. All questions should be Easy (whole numbers) or Medium (decimals).

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Taxes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.A
Standard Description: Define income tax, payroll tax, sales tax, and property tax

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Taxes
Lesson Order: 158.0
Standard ID: TEKS.MATH.CONTENT.5.10.A+1
Standard Description: Define income tax, payroll tax, sales tax, and property tax

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Students should be able to match tax types with everyday examples (e.g., buying goods → sales tax).

Common Misconceptions:
* Assuming any owned item is subject to property tax.
* Confusing who pays the tax — employer, employee, or consumer.
* Mistaking sales tax as a tax on income instead of purchases.
* Mixing up what is being taxed — income, property, or purchases.

Difficulty Definitions:
* Easy:
  Given a statement that describes a type of tasks, identify which term best fits the definition. Definitions may include payroll, property, income, or sales tax.
* Medium:
  Determine which statement is IS or IS NOT an example of a property tax.
Determine which statement is IS or IS NOT an example of a sales tax.
Determine which statement is IS or IS NOT an example of a payroll tax.
Determine which statement is IS or IS NOT an example of a income tax.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.E
Standard Description: Describe actions that might be taken to balance a budget when expenses exceed incom

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: 157.0
Standard ID: TEKS.MATH.CONTENT.5.10.E+1
Standard Description: Describe actions that might be taken to balance a budget when expenses exceed income

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Question Should contain:
* A simple budget table with clearly labeled income and expenses.
* Whole-number amounts (no decimals, no percentages).
* A single month or single time period (not multi-month or yearly).
* Expenses that are everyday, familiar, age-appropriate, such as: cell phone, allowance, entertainment, snacks, chores income, savings.
* A prompt that asks the student to:
    * Determine if the budget is balanced, OR
    * Decide how to adjust one item to make it balanced.
* Only one change needs to be made (e.g., adjust savings, reduce an expense, increase income).

Question should NOT contain:
* Decimals, percentages, fractions, or calculations involving interest.
* Multiple changes required at once (only one variable should change).
* Budgets involving adult-only financial concepts, such as: taxes, insurance, mortgages, loans, credit cards, investment earnings, rent.
* Situations requiring multi-step adjustments (e.g., change two expenses AND one income).
* Complex charts, graphs, or multi-category budgets (e.g., weekly + monthly + yearly).
* Any financial terms beyond 5th-grade TEKS, such as: interest rate, debit, credit, fees, deductions, balance forward, deposits.

Question should always be in format as shown below with an example (The values and scenario should change but the format should always be the same).
"""
Jordan needs to balance her May budget.<br><br><strong>Jordan’s May Budget</strong><br>\n  <h5 style=\"margin: 8px 0 4px;\">Income</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Source</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Allowance</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$35</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Pet-sitting</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$22</td>\n      </tr>\n    </tbody>\n  </table>\n\n  <h5 style=\"margin: 12px 0 4px;\">Expenses</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Expense</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Cell phone</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$15</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Snacks</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$9</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Entertainment</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$18</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Savings</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$19</td>\n      </tr>\n    </tbody>\n  </table><br>What can she do so that her budget is balanced?
"""

Common Misconceptions:
* Student guess the change instead of recalculating both sides.
* Students confuse “balanced” with “having money leftover.”
* Students forget that money saved still reduces the total money available.
* Students mix up the purpose of the totals.

Difficulty Definitions:
* Easy:
  - All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Solving Verbal Numerical Expressions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.B
Standard Description: Write numerical expressions from real world situations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Writing and Simplifying Numerical Expressions
Lesson Order: 153.0
Standard ID: TEKS.MATH.CONTENT.5.3.B+1
Standard Description: Write numerical expressions and equations from real world situations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - All problems are set in an explicit real-world context, described either as a story or with clear bullet points.
- Never say step1 , step 2 and so on in the quetsion stem.
- Problems use only whole numbers (no decimals, fractions, or negative numbers).
- Only the four operations: addition, subtraction, multiplication, division. No exponentiation or advanced operations.

- All required multiplication must be up to three-digit × two-digit (e.g., 435 × 22).

- Expressions may involve up to two grouping symbols/levels (e.g., parentheses).

- Each problem contains all needed numbers and steps — no missing information.

- No problems require variables or algebraic manipulation unless specifically asking students to write an equation for a scenario.

- Question types must match one of three models:

  a) Verbal prompt—compute value.

  b) Real-world scenario (with or without bullets)—write the numerical expression.

  c) Write an equation (expression set equal to a variable) to model a word problem.

- No multi-step scenario chains (no “first do A, then for the answer to A do B…”); each problem is independent.

- All contexts, objects, and verbs are appropriate for 5th-grade reading and math readiness (school, food, home, money, sports, etc.).

- No context requiring interpreting a graph, table, or data set.

- No exponents, squares, roots, or advanced operators.

Common Misconceptions:
* - Confuses additive and multiplicative language, writing 3 + 8 instead of 3 × 8 for “3 boxes of 8.”
* - Ignores story order and writes operations in reading order, not reflecting “then” or “after.”
* - Misplaces grouping symbols, failing to show “add to the product” or “subtract after multiplying.”
* - Treats “each/per” situations as repeated addition of listed numbers instead of multiplication.

Difficulty Definitions:
* Easy:
  - Compute the requested value from a verbally stated problem involving addition and multiplication, ensuring any three-digit × two-digit multiplication is done.
Example:
"Nick added 55 to the product of 553 and 12. What is the sum?"
"A student multiplied 435 by the sum of 42 and 9. what is the product?"
* Medium:
  - Write the numerical expression for a real-world scenario described in three bullets, with each bullet representing one step of a three-step calculation. Always use a name never start sentences bare and never use step 1 , step 2 etc in quetsion stem.
Example:
"Margaret opened a new case of lightbulbs.

The case contained 3 boxes of lightbulbs with 8 lightbulbs in each box.

Margaret threw 2 of these lightbulbs in the trash because they were damaged.

Then she took 7 of the lightbulbs out of the case.

Which expression can be used to show the number of lightbulbs still in the case?

A. 3 × 8 - 2 + 7

B. 3(8) - 2(7)

C. 3 × 8 - (2 + 7)

D. 3 + 8 - 2 + 7"
* Hard:
  - Write an equation for a real-world scenario in which a numertical expression is set equal to a variable.
Example:
"An elementary school had 90 boxes of glue sticks. Each box had 36 glue sticks. Teachers put 6 glue sticks into each bag.
Which equation can be used to find b, the number of bags they can fill?

A. 90 × 36 ÷ 6 = b

B. 90 ÷ 6 + 36 = b

C. 36 × 90 + 6 = b

D. 36 × 6 × 90 = b"

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Muli-Digit Division Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.C
Standard Description: Divide with quotients of up to a four-digit dividend by a two-digit divisor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Multi-Digit Division Word Problems
Lesson Order: 149.0
Standard ID: TEKS.MATH.CONTENT.5.3.C+1
Standard Description: Divide with quotients of up to a four-digit dividend by a two-digit divisor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Single-step division problems
- Whole numbers only; no decimals or fractions.
- Must have real world context
- Dividing numbers may NOT have a remainder

Common Misconceptions:
* Confuses regrouping steps during standard multi-digit division.
* Ignores "each" context, misinterpreting real-world division setups.
* Misapplies place value by misaligning dividend digits with divisor.
* Treats dividend digits as independent numbers, ignoring grouping.

Difficulty Definitions:
* Easy:
  2 digits divided by 2 digits
* Medium:
  3 digits divided by 2 digits
* Hard:
  4 digits divided by 2 digits

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Decimal Multiplication & Division: Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.E
Standard Description: Solve real world problems regarding multiplying and dividing decimal numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Decimal Multiplication & Division: Word Problems
Lesson Order: 152.0
Standard ID: TEKS.MATH.CONTENT.5.3.E+1
Standard Description: Solve real world problems regarding multiplying and dividing decimal numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Must be word problems with 3 sentences
- Decimals in question stem and answer up to thousandths
- Multiplication and division problems
- Includes questions involving money
- Any money amount has decimals up to hundredths
- No rounding
- Do not use ratio vocabulary, avoid the word “per”

Common Misconceptions:
* Confuses multiplication and division
* Ignores decimal place values when dividing or multiplying decimals.
* Misinterprets "each" in money division problems.
* Misplaces the decimal point when multiplying decimals.

Difficulty Definitions:
* Easy:
  ×: Two-digit decimal (<10) × two-digit whole number
÷: Decimal dollar amount (<$100) ÷ two-digit whole number
* Medium:
  ×: Three-digit decimal (<10) × two-digit whole number
×: Whole number × money amount (<$1)
÷: Decimal dollar amount (<$100, to hundredths) ÷ two-digit whole number
* Hard:
  ×: Three-digit decimal × three-digit decimal (both <10)
×: Three-digit decimal × two-digit number (one <10, one two-digit whole)
÷: Decimal dollar amount (<$100, with remainder → decimal) ÷ two-digit whole number

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions with Unlike Denominators: Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.K
Standard Description: Solve word problems that involve adding and subtracting fractions with unlike denominators.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions and Decimals
Lesson Order: 150.0
Standard ID: TEKS.MATH.CONTENT.5.3.K+1
Standard Description: Solve word problems that involve adding and subtracting numbers when one is in decimal form and the other is in fractional form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Number Types: Students will add either a mixed number and a decimal or a proper fraction with a decimal.
- All the numbers used should be less than 100.
- Answers must be reduced to lowest terms.
- The answer option would only be in a fraction.
- May require regrouping.
- All questions should be real-world word problems.

Common Misconceptions:
* Students convert a fraction to a decimal but put the digits in the wrong place value
* Students round a mixed number to the nearest whole number before calculating instead of using its exact value
* Students select the wrong operation (addition instead of subtraction or vice versa)
* Students treat a mixed number as if it were only its whole-number part and completely ignore the fractional part in the calculation

Difficulty Definitions:
* Easy:
  - proper fractions only
* Medium:
  - mixed numbers
* Hard:
  - N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions with Unlike Denominators: Word Problems
Lesson Order: 151.0
Standard ID: TEKS.MATH.CONTENT.5.3.K+2
Standard Description: Solve word problems that involve adding and subtracting fractions with unlike denominators.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Answers must always be positive
- The word problem should consist of three sentences, which are all in a single paragraph. The first sentence should present the first number, the next sentence should present the next number, and the last sentence should state what this question is calculating.
- The word problem should not directly give context of if the student needs to add/subtract by saying "total" or "in all," but the student has to understand the context from the question stem.
- For example, a question should be like(not exactly the same but have different scenarios): "A park bench is located 16 3/4 feet due north of an elm tree. A fountain is located 9 1/2 feet due south of the elm tree. What is the difference between the park bench and the fountain?"

Common Misconceptions:
* Adds or subtracts the numerators and also the denominators.
* Finds a common denominator but fails to create equivalent numerators.
* Subtracts the smaller fraction from the larger, ignoring the need to regroup.

Difficulty Definitions:
* Easy:
  - no regrouping any denominators are up to 5
* Medium:
  - may involve regrouping and at least one denominator is up to 10
* Hard:
  - may involve regrouping and any denominators are up to 10

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions and Decimals
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3K
Standard Description: Add and subtract numbers when one is in decimal form and the other is in fractional form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.4
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Area and Perimeter Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.4.H
Standard Description: Apply area and perimeter to solve problems involving 2 and 3 dimensional shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.4
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Area, Perimeter and Volume Word Problems
Lesson Order: 154.0
Standard ID: TEKS.MATH.CONTENT.5.4.H+1
Standard Description: Apply area, perimeter  and volume to solve problems involving 2 and 3 dimensional shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - MCQ options must include "Not here" as one option.
**Allowed Concepts**:
- Area: A = A = s × s
- Perimeter: P = 4s
- Volume:V= s x s x s

**Units** (No abbreviated form):
- Length/Width/Height: inches, feet, meters, centimeters, yards (full words only, never in, ft, m, cm, yd)
- Area: square inches, square feet, square meters, square centimeters, square yards
- Volume: cubic inches, cubic feet, cubic meters, cubic centimeters, cubic yards

**Decimal Constraints**:
- Maximum 2 decimal places
- Whole numbers: 1–1000

**Question Types by Concept**:

### Area Questions
**Type 1: Direct Calculation (Given l and w, find A)**
- Formula: A = l × w
- Task: Substitute and multiply
- Example: "A rectangle is 36 inches long and 24 inches wide. What is the area?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Working Backwards (Given A and one dimension, find other dimension)**
- Formula: l = A ÷ w (or w = A ÷ l)
- Task: Rearrange formula; divide
- Example: "A garden has an area of 48 square meters and width 6 meters. Find the length."
- Response: Numeric MCQ (select from 4 options)

***

### Perimeter Questions
**Type 1: Direct Calculation (Given l and w, find P)**
- Formula: P = 2(l + w) or P = (2 × l) + (2 × w)
- Task: Add dimensions, multiply by 2
- Example: "A rectangular rug is 2.5 meters long and 1.5 meters wide. What is the perimeter?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Working Backwards (Given P and one dimension, find other dimension)**
- Formula: w = (P ÷ 2) − l (or l = (P ÷ 2) − w)
- Task: Rearrange formula; divide, subtract
- Example: "A rug has a perimeter of 2.4 meters and length 0.8 meters. Find the width."
- Response: Numeric MCQ (select from 4 options)

***

### Volume Questions
**Type 1: Direct Calculation (Given l, w, h, find V)**
- Formula: V = l × w × h
- Task: Substitute and multiply three factors
- Example: "A cabinet is 15 feet long, 7 feet wide, and 9 feet high. What is the volume?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Finding Base Area from Volume (Given V and h, find B or base dimensions)**
- Formula: B = V ÷ h; then infer base arrangement
- Task: Divide; identify unit-cube base model
- Example: "A rectangular prism has volume 96 cubic inches and height 6 inches. Which model shows the base?"
- Response: Visual model matching (select from 4 isometric unit-cube base models)

**Type 3: Working Backwards (Given V and two dimensions, find third)**
- Formula: h = V ÷ (l × w) (or solve for l or w)
- Task: Rearrange; divide
- Example: "A box has volume 120 cubic meters, length 10 meters, width 4 meters. Find height."
- Response: Numeric MCQ (select from 4 options)

***

**Representations**:
- Unit cubes (isometric view, single-layer base models)
- 3D rectangular prisms with labeled dimensions and shaded floor
- Written dimensions (numbers with full unit names)
- Word problems with real-world contexts (dog crates, cabinets, gardens, rugs, boxes)

**Response Formats**:
- Multiple choice (4 options: A, B, C, D)
- Model selection (visual matching from 4 isometric grid options)
- Numeric answers with full unit names
- never mentions what is being asked in the options 
Ex: what is the area in square centimeters of the shaded floor of the prism?
Incorrect - 384 square centimeters of the shaded floor
Correct - 384 square centimeters

**Excluded (Out of Scope)**:
- Composite shapes
- Surface area calculations
- Non-rectangular prisms
- Unit conversions (feet to inches, etc.)
- Negative or zero dimensions
- Volumes exceeding 1000 cubic units
- Abbreviated units (in, ft, m, cm, yd, in², ft², m², in³, ft³, m³)

Common Misconceptions:
* Calculates perimeter by summing length and width only once.
* Calculates volume by adding dimensions instead of multiplying them.
* Confuses area and perimeter formulas by applying incorrect operation.
* Solves for missing dimension by subtracting known side from total perimeter.

Difficulty Definitions:
* Easy:
  - Image given. Unit squares or unit cubes visual model provided.
  - Number type: Whole numbers only (derived from unit count).
  - Uses unit squares/cubes: Yes, always.
  - Concepts asked: Area, Volume, or Perimeter (single concept per question).
  - Calculation complexity: Division or direct counting (e.g., 96 ÷ 6 = 16).
  - Response format: Select 1 of 4 visual models OR select numeric answer.
  - Examples:
VOLUME (Unit Cubes - SELECT MODEL)
Example 1:

"A rectangular prism is built from unit cubes. The volume is 96 cubic inches and the height is 6 inches. Which model could represent the base?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

Example 2:

"A box is made using unit cubes. The volume is 24 cubic units and the height is 2 layers. Which model could represent the base of this box?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

Example 3:

"A storage bin is filled with unit cubes. The volume is 120 cubic meters and the height is 5 meters. Which model shows the base?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

AREA (Unit Squares - Shaded Grid - COUNT FROM IMAGE)
Example 1:

"A rectangular floor is covered with shaded unit squares. What is the total area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 16 square units, B. 18 square units, C. 20 square units, D. 24 square units

Example 2:

"A rectangular garden is outlined with shaded unit squares. What is the area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 30 square units, B. 40 square units, C. 42 square units, D. 50 square units

Example 3:

"A poster is covered with shaded unit squares. What is the total area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 30 square units, B. 40 square units, C. 45 square units, D. 50 square units

PERIMETER (Unit Squares - Border Outline - COUNT FROM IMAGE)
Example 1:

"A rectangular picture frame outline is made with shaded unit squares around the edge. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 16 units, B. 18 units, C. 20 units, D. 24 units

Example 2:

"A rectangular garden border uses shaded unit squares all around the edge. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 20 units, B. 26 units, C. 32 units, D. 40 units

Example 3:

"A rectangular mat outline is made with shaded unit squares. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 16 units, B. 18 units, C. 20 units, D. 22 units
* Medium:
  - No image of unit squares/cubes.
  - Number type: Whole numbers only (no decimals).
  - Concepts asked: Area, Volume, or Perimeter (single concept per question).
  - Calculation complexity: Direct formula application (multiply or add); multi-digit arithmetic acceptable.
  - Response format: Select correct numeric answer from 4 MCQ options.
  - Examples:
  - Example Q: "Gabriel's dog crate is 36 inches long, 24 inches wide, and 30 inches high. What is the area of the shaded floor in square inches?"
  - Example Q: "A cabinet is 15 feet long, 7 feet wide, and 9 feet high. What is the volume in cubic feet?"
AREA (Direct Calculation)
Example 1:

"Gabriel bought a dog crate shaped like a rectangular prism. The length is 36 inches and the width is 24 inches. What is the area of the floor in square inches?"

Answer options: A. 720 square inches, B. 864 square inches, C. 960 square inches, D. 1080 square inches

Example 2:

"A rectangular swimming pool is 50 feet long and 25 feet wide. What is the area in square feet?"

Answer options: A. 750 square feet, B. 1,000 square feet, C. 1,250 square feet, D. 1,500 square feet

Example 3:

"A kitchen tile floor is 12 feet long and 10 feet wide. What is the total area in square feet?"

Answer options: A. 44 square feet, B. 100 square feet, C. 120 square feet, D. 220 square feet

VOLUME (Direct Calculation)
Example 1:

"Priscilla built a cabinet 15 feet long, 7 feet wide, and 9 feet high. What is the volume of the cabinet?"

Answer options: A. 499 cubic feet, B. 630 cubic feet, C. 945 cubic feet, D. 1,260 cubic feet

Example 2:

"A shipping box measures 20 inches long, 15 inches wide, and 12 inches high. What is the volume in cubic inches?"

Answer options: A. 1,200 cubic inches, B. 2,400 cubic inches, C. 3,600 cubic inches, D. 4,800 cubic inches

Example 3:

"A storage container is 8 meters long, 6 meters wide, and 4 meters tall. What is the volume in cubic meters?"

Answer options: A. 96 cubic meters, B. 192 cubic meters, C. 288 cubic meters, D. 384 cubic meters

PERIMETER (Direct Calculation)
Example 1:

"A rectangular garden is 35 meters long and 20 meters wide. What is the perimeter in meters?"

Answer options: A. 55 meters, B. 70 meters, C. 110 meters, D. 220 meters

Example 2:

"A room is 18 feet long and 14 feet wide. What is the perimeter in feet?"

Answer options: A. 32 feet, B. 46 feet, C. 64 feet, D. 128 feet

Example 3:

"A rectangular playground is 60 yards long and 40 yards wide. What is the perimeter in yards?"

Answer options: A. 100 yards, B. 150 yards, C. 200 yards, D. 2,400 yards
* Hard:
  - No image required. Text-based word problem.
  - Should use decimals (maximum 2 decimal places) AND whole numbers.
  - Concepts asked: May ask for side length (missing dimension) OR area of a surface. Often requires formula rearrangement.
  - Calculation complexity: Inverse operations (÷ for ×, − for +); multi-step logic; decimal arithmetic.
  - Response format: Select correct answer from 4 MCQ options.
  - Examples:
  - Example Q: "A rectangular rug has a perimeter of 2.4 meters and length 0.8 meters. What is the width in meters?"
  - Example Q: "A rectangular garden has an area of 48 square meters. The width is 6 meters. What is the length in meters?"
AREA (Missing Dimension - Decimals)
Example 1:

"A rectangular rug covers 24.5 square feet. The length is 7 feet. What is the width in feet?"

Answer options: A. 3.0 feet, B. 3.5 feet, C. 17.5 feet, D. 31.5 feet

Example 2:

"A wall panel has an area of 60.75 square inches. The width is 7.5 inches. What is the length in inches?"

Answer options: A. 8 inches, B. 8.1 inches, C. 9 inches, D. 10.5 inches

Example 3:

"A rectangular tile covers 12.6 square meters. The length is 4.2 meters. What is the width in meters?"

Answer options: A. 2 meters, B. 3 meters, C. 3.5 meters, D. 4 meters

VOLUME (Missing Dimension - Decimals)
Example 1:

"A rectangular box has a volume of 54.4 cubic feet. The length is 8 feet and the width is 4 feet. What is the height in feet?"

Answer options: A. 1.7 feet, B. 1.8 feet, C. 1.9 feet, D. 2 feet

Example 2:

"A fish tank has a volume of 97.5 cubic inches. The length is 9 inches and the width is 5 inches. What is the height in inches?"

Answer options: A. 2.0 inches, B. 2.1 inches, C. 2.2 inches, D. 2.5 inches

Example 3:

"A storage container has a volume of 144.9 cubic meters. The length is 10.5 meters and the width is 6 meters. What is the height in meters?"

Answer options: A. 2.2 meters, B. 2.3 meters, C. 2.4 meters, D. 2.5 meters

PERIMETER (Missing Dimension - Decimals)
Example 1:

"A rectangular rug has a perimeter of 2.4 meters. The length is 0.8 meters. What is the width in meters?"

Answer options: A. 0.4 m, B. 0.8 m, C. 1.2 m, D. 1.6 m

Example 2:

"A picture frame has a perimeter of 15.6 feet. The length is 4.5 feet. What is the width in feet?"

Answer options: A. 2.5 feet, B. 3 feet, C. 3.3 feet, D. 4 feet

Example 3:

"A rectangular mat has a perimeter of 8.2 meters. The length is 2.5 meters. What is the width in meters?"

Answer options: A. 1.6 meters, B. 1.7 meters, C. 1.8 meters, D. 1.9 meters

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Scatterplots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.9.B
Standard Description: Solve problems based on data presented in scatterplots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Scatterplots
Lesson Order: 156.0
Standard ID: TEKS.MATH.CONTENT.5.9.B+1
Standard Description: Solve problems based on data presented in scatterplots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Real world context only
Use whole numbers only
Each problem contains all needed numbers and steps — no missing information.
Dots must be on whole coordinates/scale units
No ratios
Scatterplot MUST have context (e.g. "The scatterplot shows ...\n")
Any table appearing in the question (stem or answer option) must follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and
Temperature</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n      </tr>\n    </tbody>
"""

Common Misconceptions:
* Assumes correlation implies causation when interpreting scatterplot data.
* Misapplies real world context by ignoring scatterplot data's paired nature.
* Treats unconnected dots as a continuous line in scatterplot problems.

Difficulty Definitions:
* Easy:
  - Match table to scatterplot
* Medium:
  - Identify the most common amount.
  - Interpret a point in context.
  - Determine how many more or how many less of something.
  - Determine the x value for the greatest or least y-value in context of the situation.
* Hard:
  - What fraction of a category had a value of a specific range.
  - Determine how many of the y variable there was when there were more than a given amount on the x variable in the context of the situation.

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Interpret Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.9.C
Standard Description: Solve problems using given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Interpret Graphs
Lesson Order: 155.0
Standard ID: TEKS.MATH.CONTENT.5.9.C+1
Standard Description: Solve problems using given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Real world context only
- Use whole numbers only
- Each problem contains all needed numbers and steps — no missing information.

Bar graphs:
- All bars must reach an exact scale unit or be exactly in the middle of two. Each graph must have at least one bar in the middle.
- Use a maximum of 6 categories

Dot plots:
- Use 15-25 points

Stem-and-left plots
- Use 10-20 points
- Consecutive stems only

Generate ONLY questions with BAR GRAPHS.

Common Misconceptions:
* Adds or compares only some of the required values, not all specified by the problem.
* Confuses the heights or positions of bars/dots with category labels or axis values when extracting data.
* Misinterprets “at least,” “more than,” or “both” as “exactly” or just one condition in multi-step questions.
* Uses the graph’s order or visual proximity rather than precise values when combining or selecting data.

Difficulty Definitions:
* Easy:
  - One-step problem
* Medium:
  - Two-step problem
* Hard:
  - Bar graphs only,

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Reading Box Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.12(A)
Standard Description: Represent numeric data with box plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Reading Box Plots
Lesson Order: 14.0
Standard ID: TEKS.MATH.CONTENT.6.12(A)+1
Standard Description: Represent numeric data with box plots.

Key Concepts:
*None specified*

Learning Objectives:
* Identify the minimum, maximum, median, and quartiles (Q1, Q3) from a given numerical data set to determine the five-number summary.
* Match a given numerical data set to the correct box plot by calculating the five-number summary and comparing it to answer choices with straightforward differences.
* Match a given numerical data set to the correct box plot when answer choices have subtle differences, requiring analysis of data distribution, skew, or clustering patterns.

Assessment Boundaries:
* Assessment is restricted to:
- Numerical data sets consisting only of whole numbers (no decimals or fractions in the source data) within a single real-world context.
- Data sets must always be presented in ordered format (from least to greatest).


QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must strictly follow this three-part structure:
  1. Context Sentence: "The list shows [description of data context] of [number] [subjects] [timeframe/condition]."
  2. Data Display: [List of numbers separated by commas]
  3. Question: "Which box plot best displays a summary of these data?"
- The context sentence must clearly state what the numbers represent and the total count of values in the set.

Common Misconceptions:
* Assuming the whiskers show the full spread of all individual data points rather than only minimum and maximum.
* Believing the spacing on the box plot reflects the number of data values rather than the position of quartiles.
* Confusing the median with the mean and selecting a box plot based on an average instead of the middle value.
* Incorrectly identifying Q1 or Q3 by splitting the data set at the wrong point or miscounting values.

Difficulty Definitions:
* Easy:
  - The data set is presented in strictly ordered format (least to greatest).
  - Data set size: 10 to 12 values.
  - Values may be distinct or include simple repeats (common in small data sets).
  - Task: Match the data set to the correct box plot (emphasizing clear position of min/max/median).
* Medium:
  - The data set is presented in ordered format (least to greatest).
  - Data set size: 13 to 15 values.
  - Values may include some repeats.
  - Task: Calculate Q1 and Q3 (requires finding the median of halves).
* Hard:
  - The data set is presented in ordered format (least to greatest) with clusters or significant skew.
  - Data set size: 16 to 20 values.
  - Values include multiple repeats (clusters) or outliers.
  - Task: Precision matching of skewed distributions.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Interpreting Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.12(B)
Standard Description: Use the graphical representation of numeric data to describe the center, spread, and shape of the data distribution in a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Interpreting Dot Plots
Lesson Order: 17.0
Standard ID: TEKS.MATH.CONTENT.6.12(B)+1
Standard Description: Use the graphical representation of numeric data to describe the center, spread, and shape of the data distribution in a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate statistical measures (range, interquartile range) and interpret complex proportional relationships
* Compare frequencies across groups and describe distribution patterns (symmetry, proportional comparisons)
* Identify visible features of a dot plot distribution (peak, gaps, clustering, total count)

Assessment Boundaries:
* Assessment is restricted to:
- Questions format (MCQ):
  Sentence 1: "The dot plot shows ... " <br><br>
  Sentence 2 (from the next line!): "Which statement best describes the data?" or "Which statement is supported by the data?"
- Questions format (Multi-Select, 6 options):
  Sentence 1: "The dot plot shows ... " <br><br>
  Sentence 2 (from the next line!): "Choose TWO correct statements about the data."
Dot plots with up to 9 dots at any single value and up to 12 values total.
Word problems set in clear, coherent, and realistic contexts.
Tasks that are appropriate and familiar for 6th-grade students and relevant to dot plots.
A variety of questions with logically sound correct answers and plausible distractors, covering:
Distribution features: symmetric, skewed.
Data features: interquartile range, clustering, gaps, range, peaks.
Compound comparisons: “less than half,” “more than half,” “there are more ___ with ___ than ___,” etc.

Common Misconceptions:
* Students claim gaps exist when all consecutive values have dots, or claim no gaps when clear missing values are present, by not systematically checking the number line
* Students identify the tallest stack of dots but name the wrong value on the number line, misreading the peak location
* Students incorrectly calculate interquartile range by misidentifying Q1 or Q3 positions, using wrong quartile formulas, or making arithmetic errors in the subtraction; students also calculate mean incorrectly by summing unique values instead of all data points
* Students reverse comparison results, claiming "more in group A than B" when actually B has more dots than A, due to careless counting or misreading the question

Difficulty Definitions:
* Easy:
  MCQ questions, no Multi-Select questions
  - Identify single, visible features: peak location, presence/absence of gaps, clustering area, or total count
  - Straightforward visual inspection, no calculations required
* Medium:
  MCQ questions, no Multi-Select questions
  - Compare frequencies between two specific values or ranges
  - Describe distribution patterns (symmetry, clustering)
  - Requires counting and comparing across multiple categories
  - Distractors show reversed comparisons or incorrect proportional statements
* Hard:
  Multi-Select Questions
  - Identify exact numerical values: peak, range, or interquartile range
  - Identify distribution shape: symmetrical, clustered
  - Answer options format: 6 total options presenting numerical values and distribution descriptions as complete statements
  - Distractors show common calculation errors:
  * Peak: off by 1-2
  * Interquartile range: wrong quartile positions, subtraction errors
  * Distribution: claiming symmetry when skewed

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Interpreting Box Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.13(A)
Standard Description: Interpret numeric data summarized in box plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Interpreting Box Plots
Lesson Order: 15.0
Standard ID: TEKS.MATH.CONTENT.6.13(A)+1
Standard Description: Interpret numeric data summarized in box plots.

Key Concepts:
*None specified*

Learning Objectives:
* Compare two box plots and evaluate statements about their relative ranges, interquartile ranges, or median positions.
* Evaluate statements about data distribution using proportional reasoning based on the quartile structure of a single box plot.
* Read and identify specific values from a box plot, including minimum, maximum, median, Q1, Q3, range, and interquartile range.

Assessment Boundaries:
* Assessment is restricted to:
- Represent data from diverse real-world contexts, appropriate for grade 6 students(Example, Backpack Weight (Pounds)). 
- UNITS: Always use full unit names as introduced in the context. DO NOT use abbreviations unless explicitly defined in the stimulus.
- ANSWER OPTIONS: Must include specific numerical values derived from the graph or precise quantitative comparisons. Avoid vague qualitative statements.
- SCALE: Ensure the number line scale is clearly visible and readable, with appropriate spacing between tick marks to avoid overcrowding. 

QUESTION STEM STRUCTURE REQUIREMENT:
For single box plot interpretation questions:
- Line 1: The box plot summarizes [context description including measurement unit and real-world scenario].
- Line 2: Which statement is best supported by the data in the box plot?

For two box plot comparison questions:
- Line 1: The box plots summarize the [context description including contexts being compared and number of observations].
- Line 2: Which statement best describes the data represented in the box plots?

Common Misconceptions:
* Calculating the difference between the Median and an endpoint (e.g., Median - Minimum) or a Quartile and an endpoint (e.g., Q3 - Maximum) instead of the correct IQR formula (Q3 - Q1).
* Calculating the total Range (Maximum - Minimum) when the question asks for the Interquartile Range (IQR), or vice versa.
* Confusing the value of a quartile (e.g., "18") with the percentage of data (e.g., "18% of students"), or incorrectly stating "most" data (implying >50%) falls in a single quartile section.
* Incorrectly claiming that a physically wider section of the box plot contains "more" data points (e.g., "Since the right whisker is longer, more data is there"), failing to recognize that each section holds exactly 25% of the data.

Difficulty Definitions:
* Easy:
  - Structure: ONE Box Plot.
  - Task: Direct identification of a single specific value (Min, Max, Median, Q1, Q3) or a single calculation (Range or IQR).
  - Constraint: The question targets ONE specific attribute.
  - Answer Options: Numerical values (e.g., "12") OR simple identification sentences (e.g., "The median is 12").
  - Example: "What is the median height?" (Options: 55, 60, 65, 70)
* Medium:
  - Structure: ONE Box Plot.
  - Task: Analyze the data distribution, percentages (25%/50%/75%), or evaluate the validity of descriptive statements.
  - Constraint: Requires understanding the quartile structure or checking multiple properties.
  - Answer Options: Descriptive sentences involving proportional reasoning (e.g., "50% of the data is between 10 and 20").
  - Example: "Which statement about the data is best supported?" (Option: "The interquartile range is 10, representing the middle 50% of data.")
* Hard:
  - Structure: TWO Box Plots.
  - Task: Compare two data distributions (centers, spreads, shapes) or evaluate complex statements comparing Range/IQR.
  - Constraint: Involves comparative language or calculations across two plots.
  - Answer Options: Comparative statements (e.g., "The range of Class A is greater than Class B").
  - Example: "Which statement best compares the data?" (Option: "The median of Group A is equal to the upper quartile of Group B.")

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Stem and Leaf Plots
Lesson Order: 16.0
Standard ID: TEKS.MATH.CONTENT.6.13(A)+2
Standard Description: Interpret numeric data summarized in stem-and-leaf plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a stem-and-leaf plot, compare counts of data points across different value ranges.
* Given a stem-and-leaf plot, identify basic statistical measures (maximum, minimum, range, or mode).
* Given a stem-and-leaf plot, interpret complex relationships involving percentages, ratios, or proportional statements.

Assessment Boundaries:
* Assessment is restricted to:
- Stem-and-leaf plots only (no other plot types in this standard)
- Whole number data values only (no decimals or fractions)
- Plots with 4-7 rows (stems)
- Questions presented as "Which statement is true?" or "Which statement is best supported by the data?"
- Answer choices are 2 options or 4 options
- Each stem-and-leaf plot includes a key explaining the notation (e.g., "3|5 means 35")
- No questions requiring students to create or draw stem-and-leaf plots
- No questions requiring calculation of mean or median
- Real-world contexts
- Students must interpret the plot, not create it

Question MUST follow the structure:

Never put \n inside LaTeX $$ ... $$! It is Strictly Prohibited!

The stem-and-leaf plot shows ________.

$$
\begin{array}{c}
\text{______}
\end{array}
$$

$$
\begin{array}{r|l}
\text{___} & \text{____} \\
\hline
x & x\ x\ x\ x \\
x & x\ x\ x\ x\ x \\
\end{array}
$$

$$
\boxed{\text{x|x means xx years}}
$$

Which statement is _______.

Strictly prohibited to put \n inside LaTeX $$ ... $$.

Example:
The stem-and-leaf plot shows the number of minutes each student spent reading during a weekend.

$$
\begin{array}{c}
\text{Reading Time (minutes)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
2 & 0\ 5\ 8 \\
3 & 1\ 4\ 4\ 7\ 9 \\
4 & 0\ 2\ 6\ 8 \\
5 & 1\ 3\ 3\ 6 \\
6 & 0\ 5 \\
\end{array}
$$

$$
\boxed{\text{3|4 means 34 minutes}}
$$

Which statement is true?

A. More students read between 40 and 49 minutes than between 30 and 39 minutes.  
B. The most common reading time is 33 minutes.  
C. Half of the students read less than 40 minutes.  
D. The range of reading times is 45 minutes.

==

Vary the concept tested in each answer option - Don't just change numbers in the same format (!)
Include different types of statements:

Statistical measures
Comparisons between ranges (e.g., "more students in 30-39 than 40-49")
Proportional statements (e.g., "half the students", "more than 75%")
Counting statements (e.g., "eight students scored above 80")
Specific value claims (e.g., "the most common value was 32")

===

Real world context to use:

Video Game Tournament
Scores from one round of a popular game (number of points each player earned).

Daily Steps Challenge
Number of steps each student recorded on a fitness tracker during a school day.

Comic Book Collection
How many comic books each friend owns.

Basketball Free Throws
Number of free throws each team member made out of 20 attempts at practice.

Reading Marathon
Number of pages each student read in a week.

Lunchbox Fruit Count
How many pieces of fruit each student brought in their lunch on Friday.

Sticker Trading Club
Number of new stickers each kid traded for during recess.

School Bus Arrival Times
Arrival times (in minutes past 8:00) of the buses over several days.

Soccer Goals in a Season
Number of goals scored by each player on a soccer team.

Video Watch Time
Minutes each student spent watching educational videos for homework.

Pen/Pencil Lengths
Lengths of pencils in a classroom, measured to the nearest centimeter.

Plant Growth in Science Lab
Heights of bean plants after three weeks of growth.

Roller-Skating Speeds
Laps per 10 minutes each student completed at the skating rink.

Board Game Wins
Number of times each family member won a board game during game night week.

Pet Weights
Weights of classmates’ pets (cats, dogs, hamsters, etc.) to the nearest pound or kilogram.

Movie Night Ratings
Out-of-10 ratings students give for a set of movies.

Snowball Fight Scores
Number of snowballs each kid successfully hit a target with.

Summer Lemonade Stand
Number of cups of lemonade sold per day over a two-week period.

Arcade Tickets Collected
Number of prize tickets each kid earned at the arcade.

Roller Coaster Wait Times
Minutes groups waited in line for one popular ride.

Bike Ride Distances
Kilometers/miles each student biked during a weekend challenge.

Music Practice Minutes
Daily instrument-practice minutes for each member of the school band.

Blocks in Tower-Building Contest
Number of blocks used in each group’s tallest stable tower.

Ice Cream Scoops Sold
Number of scoops each flavor sold in a school fundraiser.

Steps to Climb the Playground Slide
Number of steps each student counts while going up different slides.

Puzzle Completion Times
Minutes it took each pair of students to finish the same jigsaw puzzle.

Birthday Party Guests’ Candy Count
Number of candies each guest collected from a piñata.

Recyclables Collected
Number of plastic bottles each class collected for an eco-project.

Classroom Temperatures
Temperatures measured in different rooms at the same time of day.

Rocket-Launch Distances (STEM Activity)
Distances paper rockets travel when launched with the same launcher.

Common Misconceptions:
* Students count stems instead of individual leaf values when finding totals, miss data points when counting across multiple stems for ranges like "50 and above", or confuse "more than X" with "X or more" when setting boundaries
* Students incorrectly calculate range by subtracting stem values (6-2=4) instead of actual values (69-20=49), or identify the mode as the stem with most leaves rather than the most frequently appearing individual value
* Students miscount when comparing groups across different stems, fail to add all qualifying leaves when a range spans multiple stems, or compare only the number of stems rather than the total count of leaves in each range
* Students misread the stem-and-leaf notation, treating 3|5 as "3 and 5" instead of "35", or identify extremes by looking only at first/last stems rather than combining stems with their smallest/largest leaves

Difficulty Definitions:
* Easy:
  - Identify or calculate a single, straightforward statistic (maximum, minimum, range, mode)
  - Simple counting of frequency for a specific value
  - 2-option format: Choose between two different basic statistics (e.g., max vs. range)
  - 4-option format: Choose the correct value for one statistic (e.g., which value is the mode)
  - Stem values: 1-4; Leaf values: primarily 0, 5, or simple single digits
  - Plot has 4-5 rows
  - Override: don't put Peak as the correct answer.
* Medium:
  - Compare counts across 2 distinct groups or value ranges
  - Determine which group/range has more or fewer data points
  - May combine group comparison with mode identification
  - 2-option format: Choose between two group comparison statements OR between a group comparison and a mode statement
  - 4-option format: Choose among multiple group comparison statements or mode candidates
  - Stem values: any single digits; Leaf values: any single digits
  - Plot has 5-6 rows
* Hard:
  - Interpret complex relationships involving percentages
  - Understand proportional language ("half," "three times as many")
  - May require interpreting stem-leaf values as percentages
  - Any stem and leaf values
  - Plot has 5-7 rows
  - May involve percentage interpretation

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Debit and Credit Cards
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(B)
Standard Description: Distinguish between debit cards and credit cards

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Debit and Credit Cards
Lesson Order: 19.0
Standard ID: TEKS.MATH.CONTENT.6.14(B)+1
Standard Description: Distinguish between debit cards and credit cards

Key Concepts:
*None specified*

Learning Objectives:
* Given a real world scenario describing someone considering a transaction, identify the optional action that is not possible for the person to take. Four answer options.
* Given a real world scenario where the type of card used (credit or debit) is explicitly mentioned, identify which statement is true. Four answer options.
* Given a real world scenario, answer Yes or No to a question specific to credit or debit card characteristics. Two answer options.
* Given a real world scenario, identify characteristics, comparative advantages, or shared features of credit cards and/or debit cards. Three answer options.
* Identify if a credit card or debit card was used based on a description of a real world scenario. Two answer options.

Assessment Boundaries:
* Assessment is limited to: 
- Question stem must contain real world context and be written from a third person perspective.
- The question must be answerable without any calculations. 
- Answer option should not contain "possibly with interest".

Common Misconceptions:
* Students may believe a credit card pulls money directly from the bank account.
* Students may believe a debit card can be paid off at a later date.
* Students may believe credit cards never charge interest if you make any payment.
* Students may think a debit card can be used to purchase items even if they do not have enough money in their account.

Difficulty Definitions:
* Easy:
  - Given a real world scenario, answer Yes or No to a question specific to credit
or debit card characteristics.
  - Identify if a credit card or debit card was used based on a description of a
real world scenario.
  - Given a real world scenario, identify characteristics, comparative advantages, or shared features of credit cards and/or debit cards.
* Medium:
  - Given a real world scenario where the type of card used (credit or debit) is explicitly mentioned, identify which
statement is true.
  - Given a real world scenario describing someone about to make a purchase with a specific payment method (credit or debit card), identify which statement describes what the payment method does not allow or what does not happen when using it at the time of the transaction.
* Hard:
  - N/A

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Check Registers
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(C)
Standard Description: Balance a check register that includes deposits, withdrawals, and transfers

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Check Registers
Lesson Order: 18.0
Standard ID: TEKS.MATH.CONTENT.6.14(C)+1
Standard Description: Balance a check register that includes deposits, withdrawals, and transfers

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the missing balance in a check register
* Calculate the missing balance in a check register when previous balance values are blank
* Complete a row in a provided check register
* Select all true statements for a given check register

Assessment Boundaries:
* Assessment is limited to:
- Table headings must be Check #, Date, Transaction, Withdrawal, Deposit, and Balance
- Transaction values are short 2-3 word descriptions of the transaction
- Date values are in mm/dd format.
- All dollar sign symbols that are not intended as latex delimiters must use the hexadecimal numeric entity format &#36;

Common Misconceptions:
* Students may confuse the check number for a dollar amount that should be considered.
* Students may confuse the value in the balance column for a deposit or a withdrawl.
* Students may confuse the withdrawl and deposit columns and how they effect the balance.
* Students may treat the balance column as a one time calculation rather than a running total.

Difficulty Definitions:
* Easy:
  - Calculate the missing balance in a check register.
  - Question stem follows this format: "A portion of [name]'s check register is shown. [His/Her] checking account had a balance of &#36;[amount] on [date].[newline character][newline character]Based on the information in the check register, what was the balance of [name]'s checking account after the transaction on [date] in dollars and cents?"
  - Table includes 3 rows.
  - The missing value is the balance in the final row of the table.
  - Withdrawl and Deposit values are less than 300.
* Medium:
  - Complete a row in a provided check register.
  - Question stem follows this format: "A portion of [name]'s check register is shown. Before [name] made [his/her] [transaction description] on [date], the balance of [his/her] account was &#36;[amount].[newline character][newline character]Based on the information in the check register, complete the row for the transaction on [date]."
  - Table includes 3 rows.
  - The third row is the row that must be completed. The blanks are in the Withdrawl, Deposit, and Balance columns
  - Withdrawl and Deposit values are less than 600.
* Hard:
  - Calculate the missing balance in a check register when previous balance values are blank.
  - Question stem must follow this format exactly: "A portion of [name]'s check register is shown. [His/Her] checking account had a balance of &#36;[amount] before the transaction on [date].[newline character][newline character]Based on the information in the check register, what was the balance of [name]'s checking account after the transaction on [date] in dollars and cents?"
  - Table includes 3 rows.
  - The missing value is the balance in the final row of the table.
  - Withdrawl and Deposit values are less than 600.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Credit Reports
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(E)
Standard Description: Describe the information in a credit report and how long it is retained

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Credit Reports
Lesson Order: 20.0
Standard ID: TEKS.MATH.CONTENT.6.14(E)+1
Standard Description: Describe the information in a credit report and how long it is retained

Key Concepts:
*None specified*

Learning Objectives:
* Given a scenario describing negative information on a credit report, identify the typical timeframe that negative information remains on credit reports.
* Given a scenario involving a loan application or bank decision, identify how banks use credit reports to make lending decisions.
* Given a scenario or list of information types, identify which information is or is not included in a credit report.

Assessment Boundaries:
* Assessment is limited to:
- Basic information about credit reports and what they include.
- Worked examples should use newline characters to break up the text when a step has more than two sentences.
- Hints do not need to be used in answer option explantions, but if they are used, they must provide unique guidance and not simply restate the explanation
- Subject matter must be in one of the following categories:
    - Personal information: This includes your name, date of birth, addresses, telephone numbers, and employers.
    - Credit history: This is a list of your credit accounts, such as loans or credit cards. It also includes account balances, dates the accounts were opened, and payment history for the last 7 years.
    - Credit requests: This is a list of lenders, such as banks or credit card companies, that have requested your credit report in the last 2 years.
    - Public information: This is financial information about you that is found in public records, such as bankruptcies or past-due debt.

Common Misconceptions:
* Students may think all credit report information lasts forever.
* Students may think banks use credit reports to check education level or other non-financial information.
* Students may think credit reports include grades, test scores, or school performance.
* Students may think credit reports show current account balances or how much money someone has.

Difficulty Definitions:
* Easy:
  Answer questions about information in credit reports and how long it is retained
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.3
Cluster Name: The student applies mathematical process standards to represent addition, subtraction, multiplication, and division while solving problems and justifying solutions

The student applies mathematical process standards to develop concepts of expressions and
Lesson Name: Using Algebra Tiles to Represent Expressions and Equations
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.3(C)
Standard Description: Use algebra tiles to represent expressions and equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.3
Cluster Name: The student applies mathematical process standards to represent addition, subtraction, multiplication, and division while solving problems and justifying solutions

The student applies mathematical process standards to develop concepts of expressions and
Lesson Name: Using Algebra Models to Represent Expressions and Equations
Lesson Order: 7.0
Standard ID: TEKS.MATH.CONTENT.6.3(C)+1
Standard Description: Use algebra tiles to represent expressions and equations.

Key Concepts:
*None specified*

Learning Objectives:
* Identify algebra models from equations or expressions
* Identify equations or expressions from algebra models
* Simplify algebra models

Assessment Boundaries:
* - Items are **MCQ only**, with or without visual algebra-tile models.

- **MANDATORY QUESTION STEMS BY DIFFICULTY:**

  - **EASY:** "Which model shows two equal expressions when the value of $x$ is $4$?"

  - **MEDIUM:** "The circles in the model represent positive and negative units. Which equation is true based on the model?"

  - **HARD:** "The model represents an expression. Which model represents an equivalent expression?"

- **Algebra tiles must reflect STAAR conventions:**

  - Unshaded shape (triangle/square/rectangle/circle) = positive value ($+x$ or $+1$)

  - Shaded shape = negative value ($-x$ or $-1$)

  - Shape types:

    - Squares/Rectangles for variables ($x$) and constants ($1$).

    - Circles for integer units (+1/-1).

    - Triangles/Squares for variable ($x$) and constant ($1$) mixes.

- **Expressions and equations include:**

  - Linear expressions with positive or negative coefficients

  - Addition/subtraction of variables and constants

  - Single-step linear equations or expressions on both sides

- **Exclusions:**

  - No multi-step equation solving or variable isolation.

  - No quadratics ($x^2$).

  - No multiplication of variables.

- **Formatting:**

  - NO instructions field.

  - Use LaTeX for all math expressions.

  - **NEVER** use "dark/light" or "black/white" terminology—use **"shaded/unshaded"** only.

Common Misconceptions:
* Choosing a distractor that matches the numbers but not the signs or tile types.
* Incorrectly counting tiles or combining like terms.
* Misinterpreting tile signs (e.g: treating −x as +x).
* Treating x-tiles and unit tiles as equivalent or interchangeable.

Difficulty Definitions:
* Easy:
  - **Stem (STRICT):** "Which model shows two equal expressions when the value of $x$ is $4$?"; x is a number between 1 and 10
  - **Model Content:** 
  - Squares representing $x$ and $1$.
  - Equation setup: Expression with $x$ tiles = Expression with $1$ tiles (or mixed).
  - Example: $4x = 4$ or $x + 2 = 6$.
  - Total tiles ≤ 10.
  - Context is checking equivalence by substitution (visualized).
* Medium:
  - **Stem (STRICT):** "The circles in the model represent positive and negative units. Which equation is true based on the model?"
  - **Model Content:** 
  - Circles ONLY (Unshaded = +1, Shaded = -1).
  - Represents integer addition/subtraction equations.
  - Example: 3 unshaded circles and 5 shaded circles.
  - Count: Between 10 and 15 circles total.
  - Arrangement can be irregular.
* Hard:
  - **Stem (STRICT):** "The model represents an expression. Which model represents an equivalent expression?"
  - **Model Content:** 
  - Geometric shapes (Triangles, Squares) representing variables and constants.
  - Example: Unshaded Triangle = $x$, Shaded Triangle = $-x$, Unshaded Square = $1$, Shaded Square = $-1$.
  - Task: Simplify an expression by cancelling zero pairs (positive + negative).
  - Total shapes: 10 to 15.
  - Requires recognizing equivalent simplified forms.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Identifying Situations for One-Step Inequalities
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.9(A)
Standard Description: Identify situations that represent given inequalities.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Identifying Situations for One-Step Inequalities.
Lesson Order: 10.0
Standard ID: TEKS.MATH.CONTENT.6.9(A)+1
Standard Description: Identify situations that represent given inequalities..

Key Concepts:
*None specified*

Learning Objectives:
* Identify situations that represent given inequalities

Assessment Boundaries:
* - Items are **MCQ only**, with **exactly four answer choices**.

- All items match the STAAR pattern:  
  "Which situation is best represented by this inequality?"  
  or  
  "Which situation can be represented by the inequality…?"

- Inequalities:
  -- Single-variable, one-step inequalities:  
    --- Division: `x/k ≤ b`, `x/k ≥ b`, `x/k < b`, `x/k > b`  
    --- Multiplication: `kx ≤ b`, `kx ≥ b` ,  `kx < b`, `kx > b`
    --- Addition/subtraction: `x + a ≤ b`, `x – a ≥ b` , `x + a < b`, `x - a > b`
  -- No two-step inequalities, no compound inequalities, no multi-variable expressions.

- Coefficients and constants:
  -- Whole numbers or money values up to two decimals (STAAR-like values: 17.35, 624.60, etc.).
  -- Positive quantities only; no negative numbers.

- Contextual constraints:
  -- Contexts must be simple, concrete, and familiar: grouping items, sharing items, hourly pay, unit costs.
  -- Situations must follow STAAR style:
    --- "x items shared into k groups… no more than…"
    --- "Earning $a per hour… at least…"
    --- "Placed into k stacks… at most…"

- Language constraints:
  -- Must match STAAR phrasing:  
    "at least," "at most," "no more than," "no less than,"  
    "more than," "fewer than," "each," "per hour," "in each stack,"  
    "brought her total to…", etc.

- **Answer Option Formatting Requirements:**
  -- ALL four answer options MUST use identical grammatical structure (all statements OR all questions, never mixed).
  -- If using question format: "A person earns $X per hour. How many hours…?"
  -- If using statement format: "A person earns $X per hour and needs to work enough hours to…"
  -- All options must be the same number of sentences and follow parallel phrasing.

- **Context Diversity Requirement (MANDATORY):**
  -- Each of the four answer options MUST describe a DIFFERENT real-world context.
  -- NO two options may share the same noun/object (e.g., if option A uses "stickers," options B, C, and D must each use a different noun such as "tickets," "crayons," "boxes," "cakes," etc.).
  -- All four contexts must make real-world sense for the inequality structure.
  -- Example valid set: Option A = stickers divided into piles; Option B = tickets split among friends; Option C = crayons placed in boxes; Option D = cookies shared into bags.
  -- Example INVALID set: All four options about "stickers" (even with different numbers or phrasing).

- **Distractor Requirements:**
  -- Each distractor must be valid English and plausible, but incorrect because it:
    --- Uses the wrong inequality symbol meaning.
    --- Reverses multiplication/division roles.
    --- Misrepresents what x stands for.
    --- Switches "per group" and "total."
  -- ALL distractors MUST represent mathematically DISTINCT inequalities (no duplicates or overlaps).
  -- Do NOT create distractors where > and ≥ are both present with the same expression (these overlap).
  -- Do NOT create distractors where < and ≤ are both present with the same expression (these overlap).
  -- Ensure at least TWO distractors represent HIGH-LEVEL conceptual errors (e.g., confusing division vs multiplication, misidentifying variable role), not just simple symbol reversals.

- **Explanation Requirements (CRITICAL):**
  -- EVERY explanation (correct and incorrect) MUST include at least ONE scenario noun from the problem context (e.g., "hours," "crayons," "boxes," "dollars," "servers," "bags," "tamales").
  -- NEVER use inequality symbols (≥, ≤, >, <, =) in explanations; always spell out comparisons: "at least," "at most," "more than," "less than," "equal to."
  -- NEVER use praise language in the correct explanation (no "Great job!", "Excellent!", "Correct!").
  -- Correct explanation must GUIDE the student through the matching process using key terms from Direct Instruction.
  -- Incorrect explanations must provide EXPLICIT corrective steps that reference the article's anchor chart and walk through how to identify the correct structure.
  -- All explanations must be single paragraphs (no bullet lists).

- No requirement that students solve the inequality.

- Students only identify the **matching situation**, not the solution.

- Example stems:
  -- Jamal wrote the inequality x/16 ≤ 6. Which situation is best represented by this inequality?
  -- Which situation can be represented by 17.35x > 624.60?
  -- Which situation is best represented by the inequality x/12 ≥ 7?

Common Misconceptions:
* Choosing distractors that use the correct numbers but attach them to the wrong quantities or reversed inequality meanings.
* Confusing comparison phrases (e.g., reading “at most” as ≥ or “at least” as ≤).
* Misidentifying the variable’s role (treating x as the number per group instead of the total, or vice versa).
* Mixing up operations (interpreting x/k as kx or interpreting a rate situation as division instead of multiplication).

Difficulty Definitions:
* Easy:
  - Inequalities involve division of the form x/k ≤ b or x/k ≥ b or x/k < b or x/k > b
  - k is a small whole number (4–20); b is a small whole number (3–10).
  - Contexts: equal sharing or splitting (stacks, groups, piles).
  - Inequality meaning is signaled by explicit phrases: “no more than,” “at least.”
  - Distractors: wrong group size, wrong inequality phrase, wrong sharing direction.
* Medium:
  - Multiplication inequalities of the form ax ≥ b or ax ≤ b or ax > b or ax < b
  - a is a whole number or decimal money value (e.g., 9, 12.5, 14.5).
  - b up to three digits or money with decimals.
  - STAAR-style pay-rate or price-rate contexts.
  - Distractors mix up rate vs. total or flip ≥ / ≤ / > / <.
* Hard:
  - Inequalities involve division of the form x/k ≤ b or x/k ≥ b or x/k < b or x/k > b or multiplication of the form ax ≥ b or ax ≤ b or ax > b or ax < b
  - Numbers are larger: k up to 50; b up to 20; decimal rates such as 17.35, 19.95, or 22.80; totals in the hundreds or low thousands.
  - Contexts: same simple sharing, grouping, earning-per-hour, or price-per-item scenarios seen in STAAR, but with larger values.
  - Inequality meaning is still signaled by direct phrases such as “at least,” “at most,” “more than,” “no more than.”
  - Distractors include reversed inequality symbols, confusion between rate and total, or incorrect operation (multiplying instead of dividing, or vice versa).

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Writing Inequality Word Problems.
Lesson Order: 9.0
Standard ID: TEKS.MATH.CONTENT.6.9(A)+2
Standard Description: Write one-step inequalities to represent real-world situations.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the set of possible values for a variable given a one-step inequality representing a real-world situation.
* Identify one-step inequalities that represent real-world situations.

Assessment Boundaries:
* - Items are **MCQ only** with exactly four answer choices.

- The assessment consists of two distinct item types:

  **Type A: Inequality Formulation (Setup)**
  - The student reads a real-world scenario.
  - The student selects the one-step inequality that models the situation.
  - The inequality to solve is NOT provided—the student must write it.

  **Type B: Solution Determination (Solving)**
  - The student reads a real-world scenario AND is given the modeling inequality.
  - The student must identify the solution inequality (the range of possible values for the variable).
  - The inequality to solve is ALWAYS provided in the question stem.

---

## Mandatory Stem Formats (STRICT)

### Type A Stem Format:
```
[Scenario describing the situation without defining the variable.]
Which inequality can be used to find [var], the [description of what var represents]?
```

**Example:**
```
Ms. Chen's car can travel no more than 510 miles on one full tank of gasoline. After filling up the tank, she traveled 194 miles. Which inequality can be used to find $m$, the number of miles Ms. Chen can travel with the remaining gasoline?
```

### Type B Stem Format:
```
[Scenario describing the situation without defining the variable.] The inequality shown can be used to find [var], the [description of what var represents].

[Inequality displayed on its own line, e.g., $x + 5 \leq 25$]

Which inequality represents all possible values of [var]?
```

**Example:**
```
Sarah walks no more than 25 dogs on Mondays. Mr. Jones has 5 dogs that Sarah walks. The inequality shown can be used to find $x$, the number of dogs Sarah can walk on Monday in addition to Mr. Jones's dogs.

$x + 5 \leq 25$

Which inequality represents all possible values of $x$?
```

---

## Variable Definition Rule

- **NEVER** define the variable in the scenario text (e.g., do NOT say "walks $x$ dogs" or "traveled $m$ miles").
- **ALWAYS** define the variable in the question stem (e.g., "to find $m$, the number of miles...").

---

## Allowed Inequality Forms

### Type A Answer Options (Setup Inequalities):
- Addition: $a + x \leq b$, $x + a \leq b$, $a + x \geq b$
- Subtraction: $a - x \leq b$, $x - a \leq b$, $x - a \geq b$
- Multiplication: $kx \leq b$, $kx \geq b$
- Division: $x/k \leq b$, $x/k \geq b$

### Type B Answer Options (Solution Inequalities):
- $x \leq c$, $x \geq c$ (for problems with ≤ or ≥)
- $x < c$, $x > c$ (for problems with < or >)

---

## Distractor Requirements

### Type A Distractors:
- Reversing inequality direction (≤ vs ≥).
- Incorrect operation (+ vs −, × vs ÷).
- Misplacing constants (e.g., $x - a$ vs $a - x$).
- All four options must represent mathematically distinct inequalities.

### Type B Distractors (CRITICAL):
- **Symbol consistency rule:**
  - If the given inequality uses **≤ or ≥**, ALL four answer options use ONLY ≤ or ≥ (never < or >).
  - If the given inequality uses **< or >**, ALL four answer options use ONLY < or > (never ≤ or ≥).
- **Symbol distribution rule:**
  - The correct symbol (e.g., ≤) appears in exactly **2** answer options.
  - The incorrect symbol (e.g., ≥) appears in exactly **2** answer options.
- **Value distribution rule:**
  - The correct value appears in exactly **2** answer options (one with correct symbol, one with incorrect symbol).
  - One incorrect value appears in exactly **2** answer options (one with correct symbol, one with incorrect symbol).
- **Common incorrect values:** Result of adding instead of subtracting (or vice versa), result of incorrect inverse operation.

**Type B Distractor Pattern Example:**
Given inequality: $x + 5 \leq 25$ → Correct answer: $x \leq 20$

| Option | Symbol | Value | Error Type |
|--------|--------|-------|------------|
| A | ≥ | 20 | Wrong direction |
| B | ≤ | 20 | **CORRECT** |
| C | ≥ | 30 | Wrong direction + wrong value (added instead of subtracted) |
| D | ≤ | 30 | Wrong value (added instead of subtracted) |

---

## Context and Language Constraints

- All quantities are nonnegative; no negative numbers appear.
- Context types follow STAAR patterns:
  - Capacity limits (tanks, containers, shelves)
  - Distance/travel (miles, fuel)
  - Quantity limits (dogs, cans, items)
  - Budget/spending (dollars)
  - Area/geometry (base × height)

- Language must match STAAR constructions:
  - "at least" → ≥
  - "at most" → ≤
  - "no more than" → ≤
  - "no less than" → ≥
  - "more than" → >
  - "fewer than" → <

---

## Example Items

### Type A Example:
**Stem:** A large water tank holds no more than 400 gallons of water. It currently contains 125 gallons. Which inequality can be used to find $w$, the number of gallons of water that can be added to the tank?

**Options:**
- A. $125 + w \leq 400$ ✓
- B. $125 + w \geq 400$
- C. $w - 125 \leq 400$
- D. $400 + w \leq 125$

### Type B Example:
**Stem:** A student needs to collect at least 50 cans for a recycling drive. He has already collected 15 cans. The inequality shown can be used to find $c$, the number of cans he still needs to collect.

$c + 15 \geq 50$

Which inequality represents all possible values of $c$?

**Options:**
- A. $c \geq 35$ ✓
- B. $c \leq 35$
- C. $c \geq 65$
- D. $c \leq 65$

Common Misconceptions:
* Choosing inequalities that incorrectly change the operation (e.g., using multiplication instead of subtraction, or addition instead of multiplication).
* Misplacing fixed amounts (treating starting amounts as variable or putting them on the wrong side of the inequality).
* Reversing the inequality direction when translating phrases like “at least,” “no more than,” or “more than.”
* Selecting distractors that use the right numbers but represent the wrong quantity or situation.

Difficulty Definitions:
* Easy:
  ### Type A (Setup):
  - **Operations:** Addition or subtraction only.
  - **Context:** Direct accumulation or usage (e.g., "has X, gets more", "has X, uses some").
  - **Keywords:** Explicit, direct phrases: "at least", "at most", "no more than", "no less than".
  - **Numbers:** Small whole numbers (1–50).

**Type A Examples:**
  - "A jar holds no more than 30 marbles. It has 12 marbles. Find $m$, the number of marbles that can be added."
  - "Tina needs at least 25 stickers. She has 10. Find $s$, the number of stickers she still needs."

### Type B (Solving):
  - **Inequality forms:** $x + a \leq b$, $x + a \geq b$, $a + x \leq b$, $a + x \geq b$
  - **Numbers:** Small whole numbers; solution is a small positive integer (1–50).
  - **Solving:** One-step subtraction to isolate variable.

**Type B Examples:**
  - Given: $x + 8 \leq 20$ → Solve for $x$
  - Given: $15 + c \geq 40$ → Solve for $c$
* Medium:
  ### Type A (Setup):
  - **Operations:** Addition, subtraction, OR simple multiplication/division.
  - **Context:** 
  - Addition/subtraction with moderate numbers.
  - Rates (price per item, miles per hour, items per box).
  - Two-part scenarios (e.g., "bought some and received more").
  - **Keywords:** Mix of explicit and slightly varied: "at least", "at most", "up to", "meet or exceed", "needs to have".
  - **Numbers:** Moderate whole numbers (20–150).

**Type A Examples:**
  - "Movie tickets cost $12 each. Maria has $80. Find $t$, the number of tickets she can buy." → $12t \leq 80$
  - "A shelf can hold up to 100 books. There are already 45 books. Find $b$, the number of additional books." → $45 + b \leq 100$
  - "A runner needs to run at least 60 miles this week. She has already run 25 miles. Find $m$, the additional miles needed." → $25 + m \geq 60$

### Type B (Solving):
  - **Inequality forms:** 
  - Addition/subtraction: $x + a \leq b$, $a + x \geq b$ (with moderate numbers)
  - Multiplication: $kx \leq b$, $kx \geq b$ (where $k$ is a small factor: 2–10)
  - Division: $x/k \leq b$, $x/k \geq b$
  - **Numbers:** Moderate range (20–150); solutions may be 2-digit numbers.
  - **Solving:** One-step operation (subtract, divide, or multiply).

**Type B Examples:**
  - Given: $x + 35 \leq 100$ → Solve for $x$
  - Given: $5x \leq 75$ → Solve for $x$
  - Given: $8t \geq 96$ → Solve for $t$
* Hard:
  ### Type A (Setup):
  - **Operations:** Any one-step operation, including subtraction from a starting amount ("left after" scenarios).
  - **Context:** 
  - "Left after" / remainder problems (e.g., "started with $X$, spent some, needs at least $Y$ left").
  - Area/geometry problems (area = base × height with constraints).
  - Multi-layer contexts requiring careful reading.
  - **Keywords:** Implicit or contextual limits: "remaining", "left over", "budget", "capacity", "savings", "allowance".
  - **Numbers:** Larger whole numbers (50–1000).

**Type A Examples:**
  - "Jake has $200. After spending money on supplies, he wants at least $75 left. Find $s$, the amount he can spend." → $200 - s \geq 75$
  - "A rectangular garden must have an area of at least 150 square feet. The width is 10 feet. Find $l$, the length." → $10l \geq 150$
  - "A truck can carry no more than 500 pounds. Find $w$, the weight of cargo if equipment weighing 180 pounds is already loaded." → $180 + w \leq 500$

### Type B (Solving):
  - **Inequality forms:** Any form, including $a - x \leq b$, $kx \geq b$ with larger numbers.
  - **Numbers:** Larger range (50–1000); solutions may require careful computation.
  - **Solving:** Requires careful attention to inequality direction, especially with subtraction or "left after" contexts.

**Type B Examples:**
  - Given: $200 - x \geq 75$ → Solve for $x$
  - Given: $4x \geq 340$ → Solve for $x$
  - Given: $x + 275 \leq 500$ → Solve for $x$

## Distribution Guidelines

  - Both **Type A** and **Type B** items should appear at **every difficulty level**.
  - Within each difficulty, aim for approximately equal distribution between Type A and Type B.
  - Ensure variety in contexts within each difficulty tier (don't repeat the same scenario type).

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 9
Unit Name: Rational Numbers, Number Lines and the Coordinate Plane
Cluster ID: TEKS.MATH.CONTENT.6.2
Cluster Name: The student applies mathematical process standards to represent and use rational numbers in a variety of forms
Lesson Name: Classifying Rational Numbers
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.2(A)
Standard Description: Classify whole numbers, integers, and rational numbers using a visual representation such as a Venn diagram to describe relationships between sets of numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 9
Unit Name: Rational Numbers, Number Lines and the Coordinate Plane
Cluster ID: TEKS.MATH.CONTENT.6.2
Cluster Name: The student applies mathematical process standards to represent and use rational numbers in a variety of forms
Lesson Name: Classifying Rational Numbers
Lesson Order: 1.0
Standard ID: TEKS.MATH.CONTENT.6.2(A)+1
Standard Description: Classify whole numbers, integers, and rational numbers using a visual representation such as a Venn diagram to describe relationships between sets of numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Analyze a set of multiple numbers and identify how each fits into a hierarchical number–set structure.
* Classify rational numbers, integers, and whole numbers based on their set relationships.
* Determine the correct placement of a given number within nested numerical sets using Venn diagrams.

Assessment Boundaries:
* Assessment is restricted to:
- Numbers limited to rational numbers, including integers, whole numbers, terminating decimals, repeating decimals, and fractions.
- Venn diagrams consisting of nested sets in the order: whole numbers inside integers, integers inside rational numbers.
- Tasks involving identification of membership in these sets without use of operations, equations, or transformations of the numbers.
- Graphic organizers limited to hierarchical or nested representations of number sets with 2–3 layers of inclusion.
- Answer choices presented only as diagrams or numbers; no open-ended explanations.
- Lists of numbers in the question stem must be separated by commas for readability.

QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must strictly follow the sentence pattern corresponding to its Learning Objective (LO):

  For LO1 (Identify number for a region):
  1. Context: "The Venn diagram shows the relationships among different sets of numbers."
  2. Question: "Which number would be located in the shaded part of the diagram?"

  For LO2 (Identify diagram for a single number):
  1. Question: "Which Venn diagram shows the correct relationship among different sets of numbers and the correct placement of [number]?"

  For LO3 (Identify diagram for a list of numbers):
  1. Question: "Which graphic organizer best represents the relationship among the numbers in the list?"
  2. Data Display: [number], [number], [number], and [number]

Common Misconceptions:
* Assuming that any decimal number cannot be rational.
* Believing that negative numbers cannot be integers.
* Believing that whole numbers include negative integers.
* Thinking that fractions are always placed outside rational numbers rather than being part of them.

Difficulty Definitions:
* Easy:
  - Identification of whether a number is a whole number, integer, or rational number using a two-set Venn diagram.
  - Selection of a single number that belongs exclusively to the region outside whole numbers but within integers or rational numbers.
  - 4 Answer Option
* Medium:
  - Determination of the correct placement of one specific number within a three-set nested Venn diagram.
  - Distinguishing whether the given number belongs to whole numbers, integers, or only rational numbers based on sign and form.
  - 2 Answer Options Only
* Hard:
  - Classification of a set of multiple numbers across multiple numerical sets simultaneously.
  - Determination of which multi-set diagram correctly organizes all given numbers in accordance with their membership.
  - 4 Answer Options ONLY

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Compare Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.12(A)
Standard Description: Compare two groups of numeric data using comparative dot
plots by comparing their shapes, centers, and
spreads.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Comparing Dot Plots
Lesson Order: 219.0
Standard ID: TEKS.MATH.CONTENT.7.12.A+1
Standard Description: Compare two groups of numeric data using comparative dot plots by comparing their shapes, centers, and spreads

Key Concepts:
*None specified*

Learning Objectives:
* - given two dot plots select a statement that is best supported by the two plots.
* - given two dot plots that do not display numbers on every tick of number line, select a statement that is best supported by the two plots.

Assessment Boundaries:
* - the question stem must have a real world scenario for the data.
- number of dots in the plot must be <= 30 and can be whole numbers or decimal with 0.5 precision.
- range of values can be maximum 18.
- values on the dot plot must be < 100
- the statements must be about comparing either of these - median, mode, variability, range, least, greatest, shape of distribution. It should never be about mean.
- distribution/shape comparisons are limited to symmetric, skewed right, skewed left or uniform.
- for comparison use any of these - "same", "different", "equal to", "less than", or "greater than".
- for range use the word "range". no use of spread or variability.
- difficulty definition must be strictly followed
- if data has even 1 decimal number (with 0.5 precision) then the range can be maximum 10.
- Never start question stem with a number or spelled out numbers like "Two groups" or "Two classes" or "2 groups" or "2 classes" etc.
- The question stem must have the word "dot plots" in it.
- in the dataset there should never be more than one mode i.e. only a single value should have the highest frequency.

Common Misconceptions:
* Assumes taller stacks median larger values, ignoring x-axis positions.
* Confuses center with extremes, comparing range instead of median.
* Ignores spread, concluding “more consistent” from symmetry rather than variability.
* Misapplies median by averaging two middle x-values without ordering all dots.

Difficulty Definitions:
* Easy:
  number of dots in each plot are between 10 and 15 (inclusive)
range is < 10
mcq answer options compasion statements must only use "same" or "different" (for eg, "the median of the data is the same for both data sets" or "the two populations have different median weights" etc.) At least two options must be both about "same" or "different". One option should be about the shape of the distribution (for eg, "plots have same skews", or "different skews" or "distribution of the data is symmetrical for both" / "uniform" / "left skewed" / "right skewed" etc. The remaing option can be either about distribution or about comparing (same / different) a statistic value.
if option related to skew is correct, then it should be obvious. since dots are less. let's keep range < 7 and number of dots exactly 15 whenever opiton related to skew is correct.
* Medium:
  number of dots in each plot are anywhere between 15 and 25 (inclusive).
range is either <=10 if data has a decimal value or between 10 and 15 (inclusive) if data has only whole numbers.
values may or may not have decimals with 0.5 precision
all mcq answer options must be comparison of either median, mode, range, least, or greatest using "less than", "greater than" or "equal to" or "equal for" or similar phrases.
* Hard:
  number of dots in each plot are anywhere between 20 and 30 (inclusive).
range is either <=10 (if data has decimal values) or between 14 and 17 if data is whole numbers only (inclusive).
values may or may not have decimals with 0.5 precision
all mcq answer options must be comparison of either median, mode, range, least, or greatest using "less than", "greater than" or "equal to" or "equal for" or similar phrases.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Comparing Box Plots
Lesson Order: 218.0
Standard ID: TEKS.MATH.CONTENT.7.12.A+2
Standard Description: Compare two groups of numeric data using comparative box plots by comparing their shapes, centers, and
spreads.

Key Concepts:
*None specified*

Learning Objectives:
* given two box plots select a statement that is best supported by the two plots.

Assessment Boundaries:
* - the question stem must have a real world scenario for the data.
- values must be < 100 and whole numbers or decimal with 0.5 precision.
- the answer options must be about comparing any of these - min, max, median, first quartile, third quartile, interquartile range, range.
- comparison must use "greater than" or "less than" or "equal to".
- answer options must be in this format "The <statistic> of the data for <category> is/was <comparison> the <statistic> of the data for <category>"
- The order of category in the comparison statements across the answer options may not be same.
- if decimal values are used (0.5 precision) then the whole range (max(max1, max2) - min(min1, min2) must be <=15
- in worked example, if a value is already calculated in while explaining a previous option, then do not recalculate. just state it directly

Common Misconceptions:
* Assumes the mean equals the median, using the median line to compare means.
* Confuses IQR with range, comparing whisker-to-whisker instead of box width.
* Misinterprets “spread” as the median’s position, not variability (IQR/range).
* Treats the longest whisker as the maximum value, ignoring the axis scale.

Difficulty Definitions:
* Easy:
  - the mcq answer options are only about two values from these: min, max, median, first quartile, third quartile, interquartile range, range. Two options for each value.
* Medium:
  - the mcq answer options are about four different values from these: min, max, median, first quartile, third quartile, interquartile range, range. 
  - values may or may not have decimals with 0.5 precision
* Hard:
  - the mcq answer options are about four different values from these: min, max, median, first quartile, third quartile, interquartile range, range. 
  - One option should be something which cannot be determined from box plot. (eg. comparing total number of data points of the two categories etc.) 
  - values may have decimals with 0.5 precision

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Net Worth
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.13(C)
Standard Description: Create and organize a financial assets and liabilities record and construct a net worth statement

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Family Budget
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.13(D)
Standard Description: Use a family budget estimator to determine the minimum household budget and average hourly
wage needed for a family to meet its basic needs in the student’s city or another large city nearby

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Net Worth
Lesson Order: 228.0
Standard ID: TEKS.MATH.CONTENT.7.13.C+1
Standard Description: Create and organize a financial assets and liabilities record and construct a net worth statement

Key Concepts:
*None specified*

Learning Objectives:
* Find the missing value in a table of assets and liabilities given the net worth.
* Find the net worth given a table of assets and liabilities.

Assessment Boundaries:
* Individual amounts must be <=$100,000.
Amount values must be whole numbers only.
Real world scenarios only, all tables must have real world context (e.g. "___ created the net worth statement shown." or "The table shows ___'s net worth statement."
Do NOT make Missing amount be to find value of car or house 
There must be negative numbers in answer options but there CANNOT be inverses of each other (e.g. 1000 is correct and -1000 is an answer option
Tables can have at most 6 rows for the entire question stem
Question should always be in one of 2 formats (Net Worth calculation or Missing amount calcularion) as shown below with an example (The values and scenario should change but the format should always be the same).
Net Worth:
"""
<h5 style="margin: 8px 0 4px;">Assets</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Assets</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">House (current value)</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$85,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Checking account</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$2,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Automobile</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$18,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Investments</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$7,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;"><strong>Total Assets</strong></td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$113,000</td> </tr> </tbody> </table> <h5 style="margin: 12px 0 4px;">Liabilities</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Liabilities</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Mortgage</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$62,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Credit card debt</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$9,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;"><strong>Total Liabilities</strong></td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$71,500</td> </tr> </tbody> </table>
"""
Missing Amount
"""
<h5 style="margin: 8px 0 4px;">Net Worth Statement</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Item</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Bank accounts</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$3,900</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Car (current value)</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">?</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Credit card debt</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">−$2,950</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Real estate</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$37,425</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Student loans</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">−$1,700</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Investments</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$4,600</td> </tr> </tbody> </table>
"""

Common Misconceptions:
* Confuses net worth as assets plus liabilities, not assets minus liabilities.
* Misreads “total assets” or “total liabilities” as one line item, not a sum.
* Reverses the standard net worth formula
* Subtracts liabilities from each asset separately instead of from total assets.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  find the net worth given a table (image) of assets and liabilities.
* Hard:
  find the missing value in a table (image) of assets and liabilities given the net worth.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Budgets
Lesson Order: 229.0
Standard ID: TEKS.MATH.CONTENT.7.13.D+1
Standard Description: Use a family budget estimator to determine the minimum household budget and average hourly wage needed for a family to meet its basic needs in the student’s city or another large city nearby

Key Concepts:
*None specified*

Learning Objectives:
* Given a table of monthly budget for categories, find all categories individually representing more than x% of the total budget.
* Given a table of monthly budget select the equation to find the minimum family earnings needed annually. Correct answer must be in format b = 12 x ____

Assessment Boundaries:
* Question Should contain:
* A simple budget table with clearly labeled income and expenses.
* A single month or single time period (not multi-month or yearly).
* Expenses that are everyday, familiar, age-appropriate

Question should always be in format as shown below with an example (The values and scenario should change but the format should always be the same). Either Amounts or Percentages
Money Amounts:
"""
A monthly budget for a small family is shown.\n\n<h5 style=\"margin: 8px 0 4px;\">Monthly Budget</h5>\n <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n <thead>\n <tr>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Category</th>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n </tr>\n </thead>\n <tbody>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Cell phone</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$150</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Food</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$300</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Transportation</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$200</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Entertainment</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Savings</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$100</td>\n </tr>\n </tbody>\n </table>
"""
Percentage
"""
A monthly budget for a small family is shown.\n\n<h5 style=\"margin: 8px 0 4px;\">Monthly Budget</h5>\n <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n <thead>\n <tr>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Category</th>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Percentage</th>\n </tr>\n </thead>\n <tbody>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Cell phone</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15%</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Food</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20%</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Transportation</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">25%</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Entertainment</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10%</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Savings</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">30%</td>\n </tr>\n </tbody>\n </table>
"""

Common Misconceptions:
* - Confuses monthly and annual amounts, multiplying by 52 weeks instead of 12 months.
* - Ignores converting annual income to hourly wage using hours worked per year.
* - Misapplies percent-of-income, using percent of a category instead of total income.
* - Treats budget percentages as dollar amounts, adding percents directly to totals.

Difficulty Definitions:
* Easy:
  Given a table of monthly budget select the equation to find the minimum family earnings needed annually. Must be in format b = ____
* Medium:
  Given a table of monthly budget percentages for categories, select the statement that is supported by the table data.
Given a table of monthly budget for categories, find the percentage of total budget for a category..
* Hard:
  given a table of monthly budget for categories, find all categories individually representing more than x% of the total budget.
Given a table of monthly budget percentages for categories, select the statement that is NOT supported by the table data.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.5
Cluster Name: The student applies mathematical process standards to use geometry to describe or solve problems involving proportional relationships.
Lesson Name: Solving Similar Triangles
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.5(C)
Standard Description: Solve real-world problems involving finding measurements of similar triangles.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.5
Cluster Name: The student applies mathematical process standards to use geometry to describe or solve problems involving proportional relationships.
Lesson Name: Solving Similar Shapes
Lesson Order: 203.0
Standard ID: TEKS.MATH.CONTENT.7.5.C.1+1
Standard Description: Solve real-world problems involving finding measurements of similar triangles

Key Concepts:
*None specified*

Learning Objectives:
* given a pair of similar pentagons find the unknown side.
* given a pair of similar quadrilaterals find the unknown side.
* given a pair of similar triangles find an unknown side.
* given a pair of similar triangles or quadrilaterals, select the correct proportion equation to find out the side length.
* given a pair of similar triangles or quadrilaterals,select the correct statement about  those.
* given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.
* given nested triangles find the unknown side.

Assessment Boundaries:
* - scale factor from larger shape to smaller shape must always be a fraction where numerator and denominator are single digits or a decimal number with single digit. (ignore this rule for task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.)
- side length values must be less than 100.
- The variable is a lowercase letter representing the unknown side. variables must be from this list - a,b,c,i,j,k,x,y,z only. don't use letter "l" as it may look like 1 and confuse students. never use units with variables on stimulus image. for eg, do not use  like "x cm" or "y ft" etc.
- MCQ question stem for finding unknown side must always be "<ShapeType(for eg, Triangle)> <shape1 (for eg, ABC)> is similar to <shape2 (for eg, DEF)> in the image. What is the value of <variable> in <unit (for eg, centimeters)>" (ignore this rule for task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.)
- MCQ question stem about selecting proportion equation must always be "<ShapeType(for eg, Triangle> <shape (for eg, ABC)> is similar to <shape 2 (for eg, DEF)>. Which proportion can be used to find the length of <side (for eg, (\overline{DE}))> in centimeters?" (ignore this rule for task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.)
- refer to trapezoids as "quadrilateral" in question stem and answer options. in stimulus description you can refer it as trapezoids.
- multi select questions must mention number of correct options in the stem. for eg, "Select TWO correct answers." or "Select THREE correct answers."
- use decimal values with 0.5 or 0.25 precision only for this learning objective - given a pair of similar triangles or quadrilaterals, select the correct proportion equation to find out a side length
- you may use decimal values with 0.5 precision for these learning objective as well - given a pair of similar triangles find an unknown side, given a pair of similar quadrilaterals find an unknown side but the condition is that only 1 side across both the shapes must have that decimal point and it should not be the unknown side. don't use that decimal side in the worked example.
- for this learning objective - given a pair of similar triangles or quadrilaterals, select the correct proportion equation to find out a side length, do not label the unknown side with a variable. keep the label empty string because the question stem and answer option refers to the unknown side using the vertices.
- never use multiplication symbol use parenthesis instead. fore g, no use of 5 x 2; use 5 (2). No use of dot notation as well. only parenthesis.
- note for validator: for the task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle., even if the stimulus has values for inner and outer height and width, the label is what is rendered in the image, so if value is 10 and label is "x mm" then the student sees "x mm" and not "10 mm" for that side
- flipping can only be done to triangle shape and trapezoid shapes. triangle must only be horizontally flipped. trapezoid shapes must only be either vertically flipped or "both" flipped.
- dont use "x" for variable. use other letters like "a", "b", "c", "y", "z", "i", "j", "k"

Common Misconceptions:
* Confuses corresponding sides, matching wrong vertices when setting up proportions.
* Misapplies scale factor direction, using larger-to-smaller ratio when finding larger side.
* Sets up proportion with inconsistent order, mixing numerator/denominator across shapes.
* Treats similarity as additive, adding/subtracting a constant instead of multiplying by scale factor.

Difficulty Definitions:
* Easy:
  Setting up the proportion and not solving it
All side lengths are whole numbers
Shapes are not nested and are not reflections of one another
* Medium:
  Setting up the proportion without solving it with side lengths including at least 1 decimal.
The scale factor is a whole number or unit fraction
Solving for the missing side length and all side lengths are whole numbers
* Hard:
  Solving for the missing side length and side lengths include at least one decimal
May include Include scale factors that are not a whole number or unit fraction
Shapes may be nested
Shapes may be flipped

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Solving Problems Using Data from Graphs Like Bar Graphs and Circle Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.6(G)
Standard Description: Solve problems using data represented in bar graphs, dot
plots, and circle graphs, including part-to-whole and part-topart comparisons and equivalents

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Solving Problems from Bar Graphs and Circle Graphs
Lesson Order: 230.0
Standard ID: TEKS.MATH.CONTENT.7.6.G+1
Standard Description: Solve problems using data represented in bar graphs, dot plots, and circle graphs, including part-to-whole and part-topart comparisons and equivalents

Key Concepts:
*None specified*

Learning Objectives:
* Given a bar graph and a target percentage of the total, determine which combination of categories equals that percentage.
* Given a bar graph showing counts/values, calculate the total and determine what percentage a specific category represents.
* Given a circle graph where exactly one percentage is not shown, calculate the missing percentage by subtracting the shown percentages from 100%, then use it to find the actual value or compare categories.
* Given a circle graph where some percentages are shown and others are not, use relationships provided in the question stem (e.g., "twice as many", "same as") to determine the unknown percentages/values, then verify which statements are true/false (multi-select).
* Given a circle graph with all percentages shown, and a total provided in the question stem, find how many more/fewer items one category has compared to another.
* Given a grouped bar graph comparing two data series across multiple categories, read values and perform calculations to determine which statement is true.

Assessment Boundaries:
* - Single bar graphs must contain between 4 and 8 categories.
- Grouped bar graphs must have 4 to 6 time periods (e.g., Year 1, Year 2..., Week 1, Week 2..., Day 1, Day 2...) on the x-axis.
- The circle graph must contain between 4 and 6 categories.
- All category values shown in the graphs must be whole numbers.
- All percentages shown in the graphs must be whole numbers.
- Bar graph and grouped bar graph values must have the same order of magnitude (they can go up to 10⁵). And they must always be [whole-number] x [power of 10]. 310, 1520, 3200 not allowed. 300, 2000, 3000 allowed.
- Grouped bar graph answer options must use ONLY these comparison types: simple multipliers ("twice", "2 times"), percentage increase/decrease ("[N]% more/less than"), absolute differences ("[N] more/less than"), equality ("equal to"), trend statements ("increased by [N] each [period]"), combined values comparisons, or total comparisons across time periods.
- Grouped bar graph answer options must NOT use: ratios (e.g., 5:4), fractions of totals (e.g., 1/4 of the total), or percentage of total (e.g., "makes 30% of the total").
- In answer options, the numbers or fractions or equations or percentages may or may not be in latex. answer options can be a mix of latex and non latex.
- stimulus description can contain whole numbers writtern in decimal format. 
- In question stem, answer options and worked example use numbers with commas whenever number is >=1,000 (no need to follow this in stimulus description. there the number must be without comma)
- never use multiplicaiton symbols use parenthesis insted. fore g, no use of 5/10 x 100; use 5/10 (100). no use of dot notation.
- multi select questions must mention number of correct options in the stem. for eg, "Select TWO correct answers." or "Select THREE correct answers.".
- always use latex for fractions, never backslashes
- the grouped bar questions must not be about ticket sales.
- Question stems must include an introductory context sentence before the actual question. Use these templates as a guide (adjust naturally as needed):
  - For grouped bar graphs: "[Entity] tracked/recorded [data type 1] and [data type 2] [time period context]. The bar graph shows [what is measured] for each [time unit]. Which statement is supported by the information in the graph?"
  - For single bar graphs: "[Context sentence about who was surveyed or what was tracked]. The bar graph shows [what the graph displays]. [Question]"
  - For circle graphs: "A survey of [N] [people] asked about [topic]. The results are shown in the circle graph. [Question]"
- The introductory context must match the graph's title and categories (e.g., if graph title is "Favorite Activities", don't say "favorite hobbies" in the stem).
- When the graph uses specific category names (like month names or labels), the question stem should reference them consistently.

Common Misconceptions:
* - Assumes combined categories’ percent is averaged, not added from the graph.
* - Confuses part-to-part comparisons with part-to-whole when finding percentages.
* - Misreads bar-graph scale, counting tick marks instead of using equal-division values.
* - Treats circle-graph percent as the count, ignoring the total number surveyed.

Difficulty Definitions:
* Easy:
  - Given a circle graph where exactly one percentage is not shown, calculate the missing percentage by subtracting the shown percentages from 100%, then use it to find the actual value or compare categories.
  - Given a bar graph showing counts/values, calculate the total and determine what percentage a specific category represents.
* Medium:
  - Given a circle graph with all percentages shown, and a total provided in the question stem, find how many more/fewer items one category has compared to another.
  - Given a bar graph and a target percentage of the total, determine which combination of categories equals that percentage.
* Hard:
  - Given a circle graph where some percentages are shown and others are not, use relationships provided in the question stem (e.g., "twice as many", "same as") to determine the unknown percentages/values, then verify which statements are true/false (multi-select).
  - Given a grouped bar graph comparing two data series across multiple categories, read values and perform calculations to determine which statement is true.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Real-World Problems Involving Scale Drawings
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.6.G+2
Standard Description: Solve scale drawing real world problems

Key Concepts:
*None specified*

Learning Objectives:
* Identify the scale (unit rate / ratio) or scale factor from corresponding lengths (determine the scale statement) and choose the best option.

Assessment Boundaries:
* - MUST assess **linear scaling only**: length, height, distance.

  a) NOT allowed: area scaling, volume scaling, similarity with angle measures, perimeter/area of scaled figures.
- MUST use a **scale relationship*- in one of these forms:

  a) “1 unit on the drawing/map/model represents (k) units in real life”
  b) “(a) units represent (b) units”
  c) “scale factor” only if the direction is explicit (**drawing → actual*- or **actual → drawing**) and units are aligned.
- MUST use **authentic real-world contexts*- (STAAR-like), such as:

  a) map distances between locations
  b) architect/engineer scale drawings (floor plans, building dimensions)
  c) scale drawings/models of real structures/landmarks
- MUST clearly state which measurement is **drawing/map/model*- and which is **actual/real**.
- MAY use metric and/or customary units. If mixed units appear, the item MUST be solvable with **one clear Grade-7 conversion step*- (e.g., feet↔inches, meters↔centimeters).
- Allowed solution methods: equivalent ratios, unit rates, multiplication/division, or a simple proportion.
- Allowed question types:

  a) **MCQ (exactly 4 options)**
  b) **Numeric Response / Gridded (text entry)**: student enters one number; prompt may say “Record your answer” / “use the correct place value.”
- Numbers may include whole numbers and terminating decimals.

  a) If the stem says **“closest to”**, estimation/rounding is allowed and options must bracket the computed value.
  b) Otherwise, expect an exact value (whole number or terminating decimal).
- MUST be framed in a clear real-world context (STAAR-like) using a varied set of scenarios (not limited to architect/engineer).

  a) Allowed contexts include, but are not limited to: maps and travel routes, city planning, parks/trails, school campus layouts, event venue layouts, construction/renovation plans, room/floor plans, sports fields/courts, bridges/roads, evacuation routes, utility layouts, museum/zoo layouts, hiking distance markers, landmark/structure replicas, or any other realistic situation where a scale drawing/model/map is used.

  b) NOT allowed: vague/abstract prompts such as “A drawing is made…” or “A figure is scaled…” without a specific scenario, identified objects/locations, and clear quantities.

Common Misconceptions:
* - Confuses drawing-to-actual direction, using the reciprocal scale factor.
* - Ignores unit conversion (inches↔feet, cm↔m) before applying the scale.
* - Sets up proportion with mismatched units (drawing units paired with real units).
* - Treats “a units represent b units” as b−a or b+a instead of ratio.

Difficulty Definitions:
* Easy:
  Ratio-form scale (e.g., “2 in represent 30 ft”) and/or decimals in measurements or scale.
May require **one*- unit conversion step.
Includes “identify the scale” items with common inverse-unit distractors.
MUST use MCQ only.
Decimals not allowed.
* Medium:
  Scale is given in clean unit-rate form (e.g., “1 cm represents 20 km”).
One-step multiply or divide; minimal/no unit conversion.
Straightforward map or scale drawing/model scenario.
* Hard:
  Two-Step Proportionality:*- Find the scale (unit rate / scale factor) from one corresponding pair (Pair A), then apply the same scale to a different dimension (Dimension B), including any required unit conversion.
May include “closest to” prompts requiring compute-then-compare.
Distractors combine errors (ratio inversion + conversion mistake + place-value shift).

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface and Lateral Area of a Rectangular Prism
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.9(D)
Standard Description: Solve problems involving the lateral and total surface area of a rectangular prism.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface and Lateral Area of a Triangular Prism
Lesson Order: 215.0
Standard ID: TEKS.MATH.CONTENT.7.9.D+1
Standard Description: Solve problems involving the lateral and total surface area of a triangular prism

Key Concepts:
*None specified*

Learning Objectives:
* find the lateral surface area given an image of a net of a triangular prism with dimensions
* find the total surface area given an image of a net of a triangular prism with dimensions

Assessment Boundaries:
* - Side length values are between 1 and 19 (inclusive)
- Side length values can be whole numbers or decimals with 0.1 precision
- in question stem and answer options the units must be in short form (m/mm/cm/yd/in/ft.) and area units must use superscript m²/mm²/cm²/yd²/in²/ft² etc. or "square units" when no units are provided in side lengths.
- no use of variables in the question stem.
- the question stem must always be of this format "The net of a triangular prism and its dimensions are shown in the diagram.<new line after this>
What is the <total surface/lateral surface> area of the triangular prism in <area unit>?"
- for equilateral triangles the question stem must mention "equilatera" for eg, "The net of an equilateral triangular prism". Don't do this for isosceles or scalene.
- if you're approximating height of triangle mention that the height is approximate in the question stem. don't mention the value just let the student know the height is approximate.
- always use latex for fractions, never backslashes.
- no use of dot notation for multiplication
- for lateral surface area question use only this variant - STRIP_VERTICAL_OPPOSITE

Common Misconceptions:
* Confuses lateral area with total area, omitting both triangular bases.
* Ignores that three different rectangles match triangle side lengths, using one repeatedly.
* Misapplies rectangle areas, using base area × prism length instead of perimeters.
* Treats the triangular base area as perimeter, using side sums instead.

Difficulty Definitions:
* Easy:
  - one side is >= 10
  - asks total surface area only
  - trianglular bases are scalene only
* Medium:
  - two sides are >= 10
  - asks total surface area only
  - trianglular bases are isosceles or equilateral.
  - trianglular base's height may be a decimal with one decimal place.
* Hard:
  - two sides are >= 10
  - asks lateral surface area only
  - trianglular bases are scalene, or isosceles or equilateral
  - trianglular base's height may be a decimal with one decimal place.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: 214.0
Standard ID: TEKS.MATH.CONTENT.7.9.D+2
Standard Description: Solve problems involving the total surface area of a rectangular prism

Key Concepts:
*None specified*

Learning Objectives:
* - find the total surface area given an image of a net of a rectangular prism with dimensions

Assessment Boundaries:
* - Side length values are between 1 and 19 (inclusive)
- Side length values can be whole numbers or decimals with 0.5 precision
- in question stem and answer options the units must be in short form (m/mm/cm/yd/in/ft.) and area units must use superscript m²/mm²/cm²/yd²/in²/ft² etc. or "square units" when no units are provided in side lengths.
- no use of variables in the question stem.
- the question stem must always be of this format "The net of a rectangular prism and its dimensions are shown in the diagram.<new line after this>
What is the total surface area of the rectangular prism in <area unit>?"

Common Misconceptions:
* Student adds areas of only 3 or 5 faces from the net, assuming some faces are not part of the prism or overlooking a matching opposite face.
* Student adds side lengths (or computes 2(l+w)) and may multiply by a height, producing a perimeter/lateral-perimeter style result rather than total surface area.
* Student assigns the wrong side lengths to a face in the net (e.g., swaps which measurement belongs to that rectangle) or makes an arithmetic error with 0.5 decimals when finding areas.
* Student treats total surface area as the number of faces (or an unweighted sum of side lengths) rather than the sum of the areas of all 6 faces.

Difficulty Definitions:
* Easy:
  - one side is >= 10
* Medium:
  - two sides are >= 10
* Hard:
  - two sides are >= 10
  - up to two sides may use decimals with 0.5 precision.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Rigid Transformations: Preserved Properties
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.10.C
Standard Description: Determine whether a transformation on the coordinate plane preserves congruence—and justify why—recognizing that rotations, reflections, and translations preserve congruence while dilations do not.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Rigid Transformations: Preserved Properties
Lesson Order: 42.0
Standard ID: TEKS.MATH.CONTENT.8.10.C+7
Standard Description: Determine whether a transformation on the coordinate plane preserves congruence—and justify why—recognizing that rotations, reflections, and translations preserve congruence while dilations do not.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of named transformations, identify which transformation does NOT preserve congruence.
* Given a named rigid transformation applied to a polygon on a coordinate grid, select the true statement about which properties of the original figure are preserved.
* Given a verbally described rigid transformation applied to a named polygon, select the true statement about which properties of the original figure are preserved.
* Given an algebraic rule (x, y) → (expression, expression), identify which transformation type the rule represents by selecting from four named transformation options.

Assessment Boundaries:
* - Transformations on a coordinate plane centered at or relative to the origin
- Given an algebraic rule (x, y) → (expression, expression), student identifies the transformation type
- Transformation types tested:
  - Translation: (x, y) → (x + a, y + b)
  - Reflection across x-axis: (x, y) → (x, −y)
  - Reflection across y-axis: (x, y) → (−x, y)
  - 90° clockwise rotation about origin: (x, y) → (y, −x)
  - 180° rotation about origin: (x, y) → (−x, −y)
  - 270° clockwise rotation about origin: (x, y) → (−y, x)
  - Dilation from origin: (x, y) → (kx, ky) where k ≠ 1
- Given a named transformation applied to a polygon, student identifies which properties are preserved
- All questions are MCQ with 4 options
- Answer options are transformation descriptions in plain text OR property statements
- Polygons used: triangles, trapezoids, rectangles, pentagons, quadrilaterals
- EASY: rules involve whole numbers only; named transformation identification
- MEDIUM: rules involve fractions or decimals; or coordinate grid with original polygon and image shown
- HARD: verbally described transformation with property statements; no coordinate grid

Common Misconceptions:
* Confusing 180° rotation (x, y) → (−x, −y) with a reflection — not recognizing that both coordinates change sign in a rotation, whereas a reflection changes only one coordinate's sign.
* Confusing 90° clockwise rotation (x, y) → (y, −x) with 270° clockwise rotation (x, y) → (−y, x) — swapping the direction of rotation or misremembering which coordinate gets the negative sign.
* Confusing a dilation (x, y) → (kx, ky) with a translation (x, y) → (x + k, y + k) — not distinguishing between multiplying coordinates (dilation) and adding to coordinates (translation).
* Identifying a reflection across the x-axis (x, y) → (x, −y) as a reflection across the y-axis (x, y) → (−x, y), or vice versa — confusing which axis corresponds to which coordinate sign change.

Difficulty Definitions:
* Easy:
  Named transformation identification — "which does NOT preserve congruence?"
OR algebraic rule uses whole numbers only
Translation values are integers (e.g., x + 3, y − 5)
Dilation scale factors are whole numbers (e.g., 2x, 3y)
No stimulus; no coordinate grid
MCQ with 4 options
* Medium:
  Algebraic rule uses fractions or decimals (e.g., x + 1/2, y − 0.5, 3/4 x, 0.5y)
OR coordinate grid showing original polygon and its image after a named rigid transformation; "Which statement is true?"
Same transformation types as EASY
MCQ with 4 options
* Hard:
  Named rigid transformation described verbally (no algebraic rule, no coordinate grid)
"Which statement is true?" with property statements distinguishing side lengths, angle measures, area, perimeter, congruence
MCQ with 4 options

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Dilations: Effects on Area and Perimeter
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.10.D
Standard Description: Model the effect on linear and area measurements of dilated two-dimensional shapes

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Dilations: Effects on Area and Perimeter
Lesson Order: 40.0
Standard ID: TEKS.MATH.CONTENT.8.10.D+1
Standard Description: Model the effect on linear and area measurements of dilated two-dimensional shapes

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the new perimeter or area of a dilated figure given numerical values and a scale factor.
* Calculate the new perimeter or area of a dilated figure using the correct scaling relationship (k for perimeter, k² for area).

Assessment Boundaries:
* Assessment is restricted to:

- Shapes: generic "geometric figure" (EASY), named polygons (MEDIUM)
- Scale factors: positive whole numbers (EASY), fractions or whole numbers (MEDIUM)
- Allowed scale factors for MEDIUM: 2/3, 3/4, 2/5, 3/5, 4/5, 1/2, 1/3, 1/4, 3/2, 4/3, 5/3, 5/2, 5/4, 2, 3, 4, 5
- Do NOT use fractions with denominators > 5 (e.g., 8/13, 3/11, 5/12 are FORBIDDEN)
- Key relationships:
  - Perimeter scales by k (linear measure)
  - Area scales by k² (square measure)
- Non-stimulus based (text only, no graphs or images)
- All questions are MCQ with 4 options
- EASY uses numerical values; MEDIUM uses variable expressions
- Perimeter and area values are positive whole numbers (EASY) or variable expressions (MEDIUM)
- All EASY answers are whole numbers
- No dilation rules (x,y) → (kx, ky) — that belongs in standard +13

Common Misconceptions:
* Applying area scaling (k²) when perimeter scaling (k) is needed, or vice versa — e.g., computing perimeter × k² instead of perimeter × k.
* Over-scaling area: multiplying by k³ or k⁴ instead of k² — e.g., computing 12 × 3³ = 324 instead of 12 × 3² = 108, or applying k² twice to get 12 × 3⁴ = 972.
* Thinking dilation does not change the measurement — selecting the original perimeter or area unchanged.
* Using the reciprocal of the scale factor — e.g., dividing by k instead of multiplying, or using 4/3 instead of 3/4.

Difficulty Definitions:
* Easy:
  Numerical perimeter or area given (no variables)
Scale factor is a positive whole number (2, 3, 4, 5)
Question asks for the NEW perimeter or area after dilation
For perimeter: multiply by k
For area: multiply by k²
All answers are whole numbers with units
* Medium:
  Perimeter or area given as a variable expression
Scale factor given as fraction or whole number
Question asks for the NEW perimeter or area after dilation
For perimeter: multiply by k
For area: multiply by k²
Student must distinguish linear vs square scaling
* Hard:
  N/A

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.11
Cluster Name: The student applies mathematical process standards to use statistical procedures to describe data.
Lesson Name: Mean Absolute Deviation
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.11.B
Standard Description: Calculate the mean absolute deviation of a data set.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.11
Cluster Name: The student applies mathematical process standards to use statistical procedures to describe data.
Lesson Name: Mean Absolute Deviation
Lesson Order: 61.0
Standard ID: TEKS.MATH.CONTENT.8.11.B+1
Standard Description: Calculate the mean absolute deviation of a data set.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the mean absolute deviation from a pre-filled table that shows data values, the mean, differences from the mean, absolute values of the differences, and their sum.
* Calculate the mean absolute deviation of a decimal data set presented in a word problem context.
Select the correct MAD value from multiple choices.
* Calculate the mean absolute deviation of a whole-number data set presented in a word problem context.
Select the correct MAD value from multiple choices.

Assessment Boundaries:
* Assessment is restricted to:
- Assess only calculation of mean absolute deviation for a single data set.
- Data sets must contain no more than 10 data points.
- All data values must be non-negative.
- Require the complete MAD calculation process: find the mean, compute deviations from the mean, take absolute values, and compute the average of the absolute values.
- Forbid combining MAD with other statistical measures in the same item.
- Forbid data sets with negative values.
- Forbid use of technology or calculator-dependent steps.
- Keep all arithmetic within grade-appropriate ranges.

Common Misconceptions:
* Students calculate the mean of the data set and report it as the mean absolute deviation.
* Students calculate the median of the data set instead of the mean absolute deviation.
* Students perform an extra arithmetic step after finding the MAD, such as subtracting the MAD from the mean.
* Students sum values without completing the final division — either summing the absolute deviations or the raw data — and report that total as the MAD.

Difficulty Definitions:
* Easy:
  Provide a pre-filled table showing Data, Mean, Difference, and Absolute Value columns with all values computed and the Sum of absolute values shown.
Student only needs to divide the sum of absolute deviations by the number of data points to find the MAD.
Use whole number data values.
Use Constructed Response (Numeric Entry) format.
* Medium:
  Present a raw data list with whole numbers in a word problem context.
Student must calculate MAD from scratch: find the mean, compute each deviation, find absolute values, sum them, and divide by the count.
Use MCQ format with 4 answer choices.
* Hard:
  Present a raw data list with decimal values in a word problem context.
Student must calculate MAD from scratch with decimal arithmetic.
Use MCQ format with 4 answer choices.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Compound Interest
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.12.D
Standard Description: Calculate compound interest.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Simple Interest
Lesson Order: 56.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+1
Standard Description: Calculate simple interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the ending balance of a simple interest account.
* Calculate the interest earned on a simple interest account.
* Determine the annual simple interest rate of an account.

Assessment Boundaries:
* Assessment is restricted to:
- Simple interest only
- All scenarios involve a single lump-sum principal with no additional deposits or withdrawals
- Contexts include savings accounts, investment accounts, and insurance/life insurance policies
- Interest rate is expressed as an annual (yearly) rate
- Time is measured in whole number years
- Dollar amount answers must be expressed in dollars and cents
- Principal amounts range from hundreds to low thousands of dollars 
- Time periods range from 4 to 15 years
- Interest rates do not go beyond two decimal place values in percent form
- No calculations require rounding

Common Misconceptions:
* Applies the compound interest formula A = P(1 + r)^t instead of simple interest I = Prt
* Confuses "balance" (P + I) with "interest earned" (I alone)
* Leaves the time variable out for calculations
* Multiplies by the percent number instead of its decimal equivalent (e.g., uses 8.5 instead of 0.085)

Difficulty Definitions:
* Easy:
  Task: find the ending balance, AND
Interest rate is a whole number percent
* Medium:
  Task: find the annual interest rate, AND
Interest rate is a whole number percent
* Hard:
  Finding the balance, finding the interest rate, or finding the interest earned, AND Interest rate is a decimal (non-whole-number) percent

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Understanding and Comparing Simple Interest
Lesson Order: 57.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+2
Standard Description: Calculate and compare simple interest earnings across different loan or investment scenarios.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate simple interest for multiple loan or investment options using I = Prt and compare the results to determine the least, greatest, or difference in interest.
* Identify which statement correctly describes how interest and deposits change an account balance over time, using data from a table of account activity.

Assessment Boundaries:
* Assessment is restricted to:
- Calculation is limited to simple interest; compound interest not assessed
- All contexts are financial: loans, savings accounts, or investment accounts
- Interest rates are stated as annual percentages
- Principal amounts are whole dollar values
- All monetary values are in U.S. dollars
- No more than four loan or investment options are compared in a single question

Common Misconceptions:
* Assumes the lowest interest rate always produces the least total interest
* Assumes the shortest loan term always produces the least total interest
* Attributes balance growth to only deposits or only interest, ignoring the other
* Omits time or misconverts the percent to a decimal in I = Prt

Difficulty Definitions:
* Easy:
  Conceptual and interpretive; no formula calculations required
Student reads a table of account activity and selects the statement that correctly describes how interest and deposits affect the balance
* Medium:
  Comparing two interest payments
* Hard:
  Comparing four interest payments

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Compound Interest
Lesson Order: 58.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+3
Standard Description: Calculate compound interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate compound interest earned at the end of individual years.
* Calculate the total balance of a compound interest account.

Assessment Boundaries:
* - Annual compounding only — no quarterly, monthly, daily, or continuous compounding
- No additional deposits or withdrawals after initial principal
- No negative amounts or debt/loan scenarios
- No variables — all values given numerically
- Students are NOT given the formula; they must know A = P(1 + r)^t
- No rates below 1% or above 15%
- No fractional years
- Principal range: $1,000–$25,000
- Time range: 1–10 years
- Answer format: dollar format rounded to nearest cent ($X,XXX.XX); stems may use "closest to" language
- Question types: MCQ (4 options), Drag & Drop (dollar amounts into blanks)
- Contexts: savings accounts, investment accounts, retirement accounts (real-world required)

Common Misconceptions:
* Calculates interest for only the first year (P × r) and ignores the compounding effect over multiple years.
* Confuses interest earned with total balance — when asked for interest, gives the full balance A; when asked for balance, gives only A − P.
* Converts percent to decimal incorrectly — divides by 1,000 instead of 100 (e.g., writes 9% as 0.009 instead of 0.09), producing a much smaller answer.
* Uses simple interest formula (I = P × r × t) instead of compound interest formula A = P(1 + r)^t. Produces a linear result instead of exponential growth.

Difficulty Definitions:
* Easy:
  Find the interest earned (not the balance)
Whole number percent (e.g., 5%, 8%, 9%)
Single time period — calculate A then subtract P
Principal: round amounts ($1,000–$10,000)
Time: 2–5 years
MCQ with 4 options
* Medium:
  Find the interest earned at the end of individual years (year 1 and year 2)
May use decimal percent (e.g., 2.5%, 3.5%)
Requires computing A for multiple values of t and subtracting P for each
Principal: round amounts ($1,000–$25,000)
Drag & Drop format (more options than blanks; not all used)
* Hard:
  Find the total balance (not just the interest)
Whole number or decimal percent (e.g., 6.5%, 4.25%)
Single computation of A = P(1 + r)^t
Principal: $1,000–$25,000
Time: 2–5 years
MCQ with 4 options

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Comparing Simple and Compound Interest
Lesson Order: 59.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+4
Standard Description: Compare simple and compound interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the difference between simple interest and compound interest amounts.
* Calculate the difference between the balances of a simple interest account and a compound interest account.
* Compare the balances of a simple interest account and a compound interest account
      with the same interest rate.
* Compare the interest earned by a simple interest account and a compound interest account with different interest rates.

Assessment Boundaries:
* - No quarterly, monthly, daily, or continuous compounding — annual only
- No additional deposits or withdrawals after initial deposit
- No negative amounts or debt/loan scenarios
- No variables — all values given numerically
- Students must know both I = Prt and A = P(1 + r)^t
- No rates below 1% or above 10%
- No fractional years
- Hard difficulty: N/A — not assessed for this substandard
- Answer format: dollar format rounded to nearest cent ($X,XXX.XX); stems may use "closest to" language
- Question types: MCQ (4 options)
- Contexts: savings accounts, bank accounts (real-world required)
- Principal range: $1,000–$5,000
- Time range: 2–5 years
- Interest rate range: whole number percent for Easy (1–10%); decimal percent for Medium (same or different rates across accounts)

Common Misconceptions:
* Adds the interest amounts from both accounts instead of subtracting to find the difference —
gives the sum of both interests when asked how much MORE one account earns than the other.
Distractor pattern: SI + CI instead of |CI − SI|
* Confuses "difference in interest" with "difference in balances" — when asked for the
difference in interest earned, gives the difference in total balances, or vice versa.
Distractor pattern: Gives balance-based answer when interest-based was asked
* Converts percent to decimal incorrectly — divides by 1,000 instead of 100
(e.g., writes 4% as 0.004 instead of 0.04), producing much smaller interest values for both accounts.
Distractor pattern: Uses r/10 in both formulas
* Uses simple interest formula (I = Prt) for both accounts — calculates Account II as if
it also earns simple interest, missing the compounding effect.
Distractor pattern: Both balances computed as P + Prt

Difficulty Definitions:
* Easy:
  Whole number percent (e.g., 4%, 5%, 8%)
Principal ≤ $5,000
Same interest rate for both accounts
Time: 2–5 years
Asks for the sum of both account balances or individual balances
MCQ with 4 options
Cognitive demand: DOK2
Example stem: "What is the sum of the balances of Account I and Account II at the end of 3 years?"
* Medium:
  Decimal percent (e.g., 1.5%, 2.75%, 3.5%) — same or different rates across accounts
Principal ≤ $5,000
Time: 2–5 years
Asks for the difference between interest amounts, difference between balances, or which statement about the accounts is true
MCQ with 4 options
Cognitive demand: DOK2
Example stem: "Which amount is closest to the difference between the interest earned in Account I and the interest earned in Account II at the end of 2 years?"
* Hard:
  Decimal percent (e.g., 2.75%, 3.5%, 4.5%)
Same interest rate for both accounts
Principal $1,000–$5,000
Time: 2–5 years
Asks for the difference between the balances of both accounts
MCQ with 4 options
Cognitive demand: DOK2
Example stem: "Which amount is closest to the difference between the balances of the two accounts at the end of 3 years?"

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Calculating Savings
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.12.G
Standard Description: Solve problems involving savings.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Calculating Savings
Lesson Order: 60.0
Standard ID: TEKS.MATH.CONTENT.8.12.G+1
Standard Description: Solve problems involving savings.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:
- All questions involve real-world financial scenarios related to saving for education or college costs.
- All monetary amounts must be positive and use the dollar sign ($) with values to the hundredths place when cents are involved.
- Total costs and savings amounts must be whole numbers or values to the hundredths place, not exceeding $50,000.
- Operations are limited to addition, subtraction, multiplication, and division of whole numbers and decimals.
- Fractional deductions are limited to unit fractions ($\frac{1}{2}$, $\frac{1}{3}$, $\frac{1}{4}$) or simple non-unit fractions.
- Questions may include tabular data presenting financial information (costs, deposit amounts, projected values).
- No tax calculations, compound interest formulas, percentage-based discounts, or interest rate computations.
- No algebraic expressions, equations, or variables.
- Question stems must be real-world scenarios between 20 and 120 words in length.
- Each question has exactly one correct answer and three plausible distractors.
- Distractors must result from applying common procedural errors to the same problem (not from unrelated calculations).
- At Easy difficulty, all information is given directly in the stem with no table. At Medium and Hard difficulties, a table is provided in the stem.

Common Misconceptions:
* Applying deductions in the wrong order — subtracting a fixed dollar amount before applying a fractional deduction to the total cost (or vice versa), which produces a different remaining balance and an incorrect monthly savings amount.
* Failing to determine the correct target amount before comparing with table values — not multiplying the annual cost by the required number of years to find the total needed, or comparing savings to a single year's cost instead of the multi-year total.
* Incorrectly computing total accumulated savings — multiplying the monthly deposit by both the number of months and the number of years (double-counting the time period), or forgetting to add existing savings to the monthly accumulation.
* Misreading or misinterpreting table data — dividing an annual cost by the number of years in the program label instead of using the per-year cost directly, or reading the wrong row or column from the table.

Difficulty Definitions:
* Easy:
  Sequential Deduction and Monthly Savings Calculation
A single total cost is given along with 2 to 3 deductions (one fractional and one or more fixed-dollar amounts).
The student applies deductions in the correct order to find the remaining cost, then divides by a number of months to find the minimum monthly savings.
All information is presented directly in the question stem (no table required).
The total cost is between $5,000 and $30,000.
The number of months is 12 or 24.
Answer choices are monetary values in dollars and cents.
* Medium:
  Total Savings Calculation with Table Comparison
The student is given current savings and a monthly savings plan, and must calculate total accumulated savings.
A table of 3 to 5 cost categories (with labels and dollar amounts) is provided in the question stem.
The student compares total savings against table values to evaluate which option is affordable.
Answer choices are statements about affordability that the student must evaluate as true or false; exactly one statement is true.
Monthly savings amounts are between $25 and $200, and savings periods are between 24 and 72 months.
* Hard:
  Goal-Based Minimum Deposit from a Projection Table
The student is given an annual cost, a number of years, existing savings, and a table showing projected future account values based on different monthly deposit amounts.
The student must first calculate the total amount needed (annual cost multiplied by the number of years), then compare this target to the projected values in the table to identify the minimum monthly deposit.
The projection table has 3 to 5 columns of deposit scenarios with corresponding future values.
Answer choices are monthly deposit amounts taken from the table.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.7.B
Standard Description: Calculate the surface area of rectangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: 50.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+1
Standard Description: Calculate the surface area of rectangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the total surface area of a rectangular prism when a diagram is provided.
* Given a rectangular prism, identify another rectangular prism with the same total surface area.
* Given real-world context, calculate the missing dimension of a rectangular prism.
* Given real-world context, calculate the total surface area of a rectangular prism.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = Ph + 2B$
- Decimals are limited to values in the tenths place.
- All dimensions of prisms are less than 40 units.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses total surface area with volume by multiplying three dimensions.
* Ignores the (2B) term, calculating only lateral area (Ph).
* Misapplies (S=Ph+2B) by using base area instead of base perimeter.
* Treats each dimension as a face area and adds (l+w+h) (not (lw+lh+wh)).

Difficulty Definitions:
* Easy:
  Calculate total surface area when a visual model of the prism is provided.
* Medium:
  Calculate total surface area or a missing dimension without a visual model.
* Hard:
  Identify which rectangular prism has the same total surface area as the rectangular prism provided in the question.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface and Lateral Area of a Cylinder
Lesson Order: 51.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+2
Standard Description: Calculate the surface area and lateral area of cylinders.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the lateral surface area of a cylinder when a diagram is provided.
* Calculate the total surface area of a cylinder when a diagram is provided.
* Given a table with the dimensions of three cylinders, identify which two cylinders have the same lateral surface area.
* Given a table with the dimensions of three cylinders, identify which two cylinders have the same total surface area.
* Given real-world context, calculate the total surface area of a cylinder.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = 2 \pi r h + 2 \pi r^2$
- Lateral surface area formula is $S = 2 \pi r h$
- Decimal values are limited to the tenths or hundreths place.
- Dimension values are less than 20.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses diameter with radius when substituting into ($2\pi rh$) or ($2\pi r^2$).
* Omits one base area term, using ($2\pi rh+\pi r^2$) for total surface area.
* Treats ($2\pi r$) as ($\pi r$), forgetting the factor of 2 in circumference.
* Uses total surface area formula when asked for lateral surface area.

Difficulty Definitions:
* Easy:
  Calculate the total surface area of a cylinder.
All dimension values are integers.
* Medium:
  Calculate the lateral surface area of a cylinder when a diagram is provided.
* Hard:
  Identify which two cylinders have the same total surface area or the same lateral surface area.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface and Lateral Area of a Triangular Prism
Lesson Order: 52.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+3
Standard Description: Calculate the surface area and lateral area of triangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the lateral surface area of a triangular prism when a diagram is provided.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = Ph + 2B$
- Lateral surface area formula is $S = Ph$
- Decimal values are limited to the place.
- Dimension values are less than 20.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses total surface area with lateral area; uses S = Ph only.
* Ignores 2B term; adds just one triangular base area.
* Treats prism height h as triangle height in perimeter-times-height product Ph.
* Uses triangle side length as triangle height when finding base area B.

Difficulty Definitions:
* Easy:
  Calculate the total surface area of a triangular prism when a diagram is provided.
All dimension values are integers.
* Medium:
  Calculate the lateral surface area of a triangular prism when a diagram is provided.
* Hard:
  Given real-world context and a partial diagram, calculate the total or lateral surface area of a triangular prism.
