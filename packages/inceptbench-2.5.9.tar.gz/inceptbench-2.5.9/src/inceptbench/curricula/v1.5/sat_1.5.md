##################################################
#                                                #
# Curriculum:      SAT Prep                      #
# Version:         1.5                           #
# Snapshot Date:   March 17, 2026 23:34:45       #
#                                                #
##################################################

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.1 - R&W
Cluster Name: Central Ideas and Details
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Central Ideas
Standard Description: The generated question must ask the student to identify the answer choice that best describes the main idea of the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.1 - R&W
Cluster Name: Central Ideas and Details
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Details
Standard Description: The generated question must ask the student to identify the answer choice that provides a detail from the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.2 - R&W
Cluster Name: Command of Evidence: Quantitative
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quantitative
Standard Description: The generated question must ask the student to identify the answer choice that most effectively uses data from the graph/table to complete an assertion/example presented in the passage.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.3 - R&W
Cluster Name: Command of Evidence: Textual
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Findings that Support
Standard Description: The generated question must ask the student to identify the answer choice that, if true, would most strongly/directly support a claim/hypothesis/conclusion presented in the passage or most effectively illustrate the claim presented in the passage.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.3 - R&W
Cluster Name: Command of Evidence: Textual
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Findings that Weaken
Standard Description: The generated question must ask the student to identify the answer choice that, if true, would most strongly/directly weaken a claim/hypothesis/conclusion presented in the passage or most effectively weaken the claim presented in the passage.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.3 - R&W
Cluster Name: Command of Evidence: Textual
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quotations
Standard Description: The generated question must ask the student to identify the quote from the answer choices that, if true, would most strongly/directly illustrate the claim presented in the passage.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 1 - R&W
Unit Name: Information and Ideas
Cluster ID: SAT Topic 1.4 - R&W
Cluster Name: Inferences
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Inferences
Standard Description: The generated question must ask the student to identify the answer choice that most logically completes the text with an inference.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 2 - R&W
Unit Name: Craft and Structure
Cluster ID: SAT Topic 2.1 - R&W
Cluster Name: Cross-Text Connections
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Cross Text Connections
Standard Description: The generated question must ask the student to identify which choice reflects the position of the author of passage 2 (Text 2) with respect to the claims made by the author of passage 1 (Text 1).

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 2 - R&W
Unit Name: Craft and Structure
Cluster ID: SAT Topic 2.2 - R&W
Cluster Name: Text Structure and Purpose
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Function of a Sentence
Standard Description: The generated question must ask the student to identify which choice best states the function of the underlined sentence in the text as a whole.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 2 - R&W
Unit Name: Craft and Structure
Cluster ID: SAT Topic 2.2 - R&W
Cluster Name: Text Structure and Purpose
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Main Purpose
Standard Description: The generated question must ask the student to identify which choice best states the overall main purpose of the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 2 - R&W
Unit Name: Craft and Structure
Cluster ID: SAT Topic 2.2 - R&W
Cluster Name: Text Structure and Purpose
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Structure
Standard Description: The generated question must ask the student to identify which choice best describes the overall structure of the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 2 - R&W
Unit Name: Craft and Structure
Cluster ID: SAT Topic 2.3 - R&W
Cluster Name: Words in Context
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Words In Context
Standard Description: The generated question must ask the student to identify which choice completes the text with the most logical and precise word or phrase.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 3 - R&W
Unit Name: Expression of Ideas
Cluster ID: SAT Topic 3.1 - R&W
Cluster Name: Rhetorical Synthesis
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Rhetorical Synthesis
Standard Description: The generated question must contain bullet point notes from research on a specific topic and then ask the student to identify which choice most effectively uses relevant information from the notes to accomplish a specific goal.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 3 - R&W
Unit Name: Expression of Ideas
Cluster ID: SAT Topic 3.2 - R&W
Cluster Name: Transitions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Transitions
Standard Description: The generated question must ask the student to identify which choice completes the text with the most logical transition.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.1 - R&W
Cluster Name: Boundaries
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linking Clauses
Standard Description: The generated question must ask the student to identify the answer choice that most logically links the clauses in the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.1 - R&W
Cluster Name: Boundaries
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Punctuation: Colons
Standard Description: The generated question must ask the student to identify the answer choice that introduces the proper use of colons and most logically completes the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.1 - R&W
Cluster Name: Boundaries
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Punctuation: The Dash
Standard Description: The generated question must ask the student to identify the answer choice that introduces the proper use of dashes and most logically completes the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.1 - R&W
Cluster Name: Boundaries
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Run-ons and Fragments
Standard Description: The generated question must ask the student to identify the answer choice that corrects a run-on sentence or a sentence fragment and most logically completes the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.1 - R&W
Cluster Name: Boundaries
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Supplements
Standard Description: The generated question must ask the student to identify the answer choice that most logically adds supplemental information to the text.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.2 - R&W
Cluster Name: Form, Structure, and Sense
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Modifiers
Standard Description: The generated question must ask the student to identify the answer choice that most logically completes the text with the proper placement of a subject-modifier.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.2 - R&W
Cluster Name: Form, Structure, and Sense
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Plurals And Possessives
Standard Description: The generated question must ask the student to identify the answer choice that will logically complete the text with plural and possessive nouns.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.2 - R&W
Cluster Name: Form, Structure, and Sense
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Pronoun Agreement
Standard Description: The generated question must ask the student to identify the answer choice that most logically completes the text with the proper pronoun so that it conforms to the conventions of Standard English.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.2 - R&W
Cluster Name: Form, Structure, and Sense
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Subject Verb Agreement
Standard Description: The generated question must ask the student to identify the answer choice that most logically completes the text with the answer choice that presents the proper subject-verb agreement.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 4 - R&W
Unit Name: Standard English Conventions
Cluster ID: SAT Topic 4.2 - R&W
Cluster Name: Form, Structure, and Sense
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Verb Tense
Standard Description: The generated question must ask the student to identify the answer choice that most logically completes the text with the proper verb tense so that it conforms to the conventions of Standard English.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.1 - Math
Cluster Name: Graphs of linear systems and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Diagram
Standard Description: Questions in this category (Diagram) require students to utilize their knowledge of graphs to find the solution to systems of linear equations and inequalities.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.1 - Math
Cluster Name: Graphs of linear systems and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Graph
Standard Description: Questions in this category (Solve with Graphing Calculator) require students to use their calculator to graph a given function and determine specific features of the graph.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Elements
Standard Description: Questions in this category (Determine meaning of coefficients in a linear equation) require students to utilize their knowledge of linear equations in order to determine the meaning of the coefficients in a given linear equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Equation Points
Standard Description: Questions in this category (Create y = mx + b equation based on two points in function form) require students to utilize their knowledge of linear equations in order to write an equation in slope-intercept form given two points in function form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Equation Slope with Point
Standard Description: Questions in this category (Create y = mx + b equation based on point and slope) require students to utilize their knowledge of linear equations in order to write an equation in slope-intercept form given a point and the slope.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Intercepts
Standard Description: Questions in this category (Finding x- and/or y-intercept) require students to utilize their knowledge of linear equations in order to identify the x and/or y intercept of a given equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Perpendicular
Standard Description: Questions in this category (Find the Slope of perpendicular lines) require students to utilize their knowledge of the slopes of perpendicular lines in order to correctly identify the equation of a line.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Plugin
Standard Description: Questions in this category (Plugin Information Provided in Question) require students to plug in information given in the question in order to solve linear equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.2 - Math
Cluster Name: Linear equation word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Slope
Standard Description: Questions in this category (Find the Slope of parallel lines and interpret y = mx + b) require students to utilize their knowledge of the slopes of parallel lines in order to correctly identify the equation of a line.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.3 - Math
Cluster Name: Linear inequality word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Inequality Word Problem
Standard Description: Questions in this category (Translate Word Problem) require students to use their knowledge of inequalities in order to translate word problems into an inequality.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Perimeter
Standard Description: Questions in this category (Plugin Picture + Perimeter) require students to utilize their knowledge of perimeter in order to find the perimeter of a given geometrical figure.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Plugin Word Problem
Standard Description: Questions in this category (Translate Word Problem + Plug-In Your Own Number) require students to use their knowledge of linear relationships in order to translate word problems into an equation and then plug in a relevant number in order to determine which of the given equations is correct.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Plugin Word Problem 2
Standard Description: Questions in this category (Translate Word Problem + Plugin Answers) require students to use their knowledge of linear relationships in order to translate word problems into an equation and then plug in the answers to determine which is correct.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Proportions
Standard Description: Questions in this category (Proportions) require the student to utilize their knowledge of proportions in order to identify which answer choice presents a solution to an unknown variable based upon its proportional relationship to a given fixed ratio.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Variables
Standard Description: Questions in this category (Interpret Variables) require students to use their knowledge of linear relationships in order to determine the meaning of one of the two variables presented in the problem.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.4 - Math
Cluster Name: Linear relationship word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Word Problem
Standard Description: Questions in this category (Translate Word Problem) require students to use their knowledge of linear relationships in order to translate word problems into an equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.5 - Math
Cluster Name: Solving systems of linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System
Standard Description: Questions in this category (System of Linear Equations) require students to use their knowledge of systems of linear equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.5 - Math
Cluster Name: Solving systems of linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Inequalities
Standard Description: Questions in this category (System of Linear Inequalities) require students to use their knowledge of systems of linear inequalities.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Equation Multiple
Standard Description: Questions in this category (Find the Multiple) require students to use their knowledge of multiples in order to identify which choice represents the value of the multiple of an expression.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Inequality Test Answers
Standard Description: Questions in this category (Plugin Information provided in the Question into the Answer Choices) require students to recognize the information given in the question as direct substitution elements to determine the correct answer

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Inequality Word Problem Solve
Standard Description: Questions in this category (Plugin Information provided in Question) require students to plug in information provided in the question in order to solve a linear equation or inequality.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Simplify
Standard Description: Questions in this category (Simplify) require students to utilize their knowledge of algebraic manipulation in order to simplify a linear equation or inequality.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Solve
Standard Description: Questions in this category (Algebra) require students to utilize their knowledge of algebraic manipulation in order to solve a linear equation or inequality.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.6 - Math
Cluster Name: Solving linear equations and inequalities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Solve X Y Intercept
Standard Description: Questions in this category (Find the x- and/or y-intercept) require students to utilize their knowledge of linear equations in order to find the x and/or y intercept of a linear equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.7 - Math
Cluster Name: Systems of linear equations word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Elimination
Standard Description: Questions in this category (System of Linear Equations + Elimination Method) require students to use their knowledge of systems of linear equalities and their ability to implement elimination method.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.7 - Math
Cluster Name: Systems of linear equations word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Equalities
Standard Description: Questions in this category (Simplify Answers + Understand No Solution to a System of Equations) require students to utilize their knowledge of linear equations to recognize when two linear equations are equivalent.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.7 - Math
Cluster Name: Systems of linear equations word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Plugin
Standard Description: Questions in this category (System of Linear Equations + Plugin Determined Answer) require students to use their knowledge of systems of linear inequalities and their ability to plug in a determined answer.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.7 - Math
Cluster Name: Systems of linear equations word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear System Substitution
Standard Description: Questions in this category (System of Linear Equations + Substitution Method) require students to use their knowledge of systems of linear inequalities and their ability to implement substitution method.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 5 - Math
Unit Name: Algebra
Cluster ID: SAT Topic 5.7 - Math
Cluster Name: Systems of linear equations word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear Word Problems
Standard Description: Questions in this category (Translate Word Problem) require students to utilize their knowledge of linear equations in order to translate word problems into equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.1 - Math
Cluster Name: Operations with polynomials
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Factoring Polynomials
Standard Description: Questions in this category (Factoring) require a student to utilize their knowledge of factoring out the greatest common factor to rewrite a polynomial in its factored form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.1 - Math
Cluster Name: Operations with polynomials
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Polynomial Simplify
Standard Description: Questions in this category (Simplify) require a student to utilize their knowledge of algebra by simplifying polynomials.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.10 - Math
Cluster Name: Solving quadratic equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Discriminant Roots
Standard Description: Questions in this category (Using the Discriminant) require students to utilize their knowledge of the discriminant of the quadratic formula and how that relates to the number of solutions an equation has.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.10 - Math
Cluster Name: Solving quadratic equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Simplify
Standard Description: Questions in this category (Simplify) require students to utilize their knowledge of algebraic manipulation to simplify quadratic equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.10 - Math
Cluster Name: Solving quadratic equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Solve
Standard Description: Questions in this category (Using the Quadratic Formula) require students to utilize their knowledge of the quadratic formula to solve quadratic equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.11 - Math
Cluster Name: Solving system of quadratic and linear equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Nonlinear and Linear System
Standard Description: Questions in this category (Solve with Graphing Calculator) require students to use their understanding of intersecting nonlinear and linear functions to find solutions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.2 - Math
Cluster Name: Isolating quantities
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Isolating Variables
Standard Description: Questions in this category (Isolating Variables) require a student to utilize their knowledge of algebraic manipulation to isolate a variable in a polynomial equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.3 - Math
Cluster Name: Nonlinear functions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Nonlinear Plugin
Standard Description: Questions in this category (Plugin Information provided in Question) require a student to utilize their knowledge of function notation to either substitute f(x) or x in the provided function by the value representative of one of these terms also provided in the question.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.3 - Math
Cluster Name: Nonlinear functions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Nonlinear Translation
Standard Description: Questions in this category (Graph Translation) require students to utilize their knowledge of graph transformations to rewrite functions reflecting a transformation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.4 - Math
Cluster Name: Operations with rational expressions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Rational Simplify
Standard Description: Questions in this category (Simplify + Factoring) require students to simplify and factor rational expressions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.5 - Math
Cluster Name: Polynomial and other nonlinear graphs
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Nonlinear Diagram
Standard Description: Questions in this category (Diagram) require students to utilize their knowledge of graphs on a coordinate plane to identify the locus of a specific feature of the graph.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.5 - Math
Cluster Name: Polynomial and other nonlinear graphs
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Nonlinear Transform
Standard Description: Questions in this category (Graph Transformations) require students to utilize their knowledge of graph transformations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Discriminant Manipulation
Standard Description: Questions in this category (Using the Discriminant) require students to utilize their knowledge of the discriminant of the quadratic formula in order to determine how many solutions a given polynomial equation has.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Exponential Elements
Standard Description: Questions in this category (Interpreting Exponential Equations) require students to utilize their knowledge of quadratic exponential equations to interpret the meaning of a given value in the equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Exponential Solving
Standard Description: Questions in this category (Solving Exponential Equations) require students to utilize their knowledge of quadratic exponential equations in order to solve.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Exponential Word Problem
Standard Description: Questions in this category (Writing Exponential Equations) require students to utilize their knowledge of exponential equations in order to write an exponential equation based on the information given in the problem.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Factoring
Standard Description: Questions in this category (Factoring) require students to use their understanding of factoring to solve for some component of a polynomial.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Elements
Standard Description: Questions in this category (Interpreting Quadratic Equations) require students to utilize their knowledge of quadratic equations to interpret the meaning of a given value in the equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Plugin
Standard Description: Questions in this category (Plugin Information Provided in Question) require students to plug-in data provided in the question to determine the correct answer.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.6 - Math
Cluster Name: Quadratic and exponential word problems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Word Problem
Standard Description: Questions in this category (Translate Word Problem) require students to utilize their knowledge of the structure of quadratic equations to write an equation given the information provided.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.7 - Math
Cluster Name: Quadratic graphs
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Quadratic Graph
Standard Description: Questions in this category (Solve with Graphing Calculator) require students to use their calculator to graph a given function and determine specific features of the quadratic graph.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.8 - Math
Cluster Name: Radical, rational, and absolute value equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Absolute Value
Standard Description: Questions in this category (Absolute Value Equations) require students to utilize their knowledge of absolute value to solve equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.8 - Math
Cluster Name: Radical, rational, and absolute value equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Radicals
Standard Description: Questions in this category (Solving Radical Equations) require students to utilize their knowledge of radicals to solve equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 6 - Math
Unit Name: Advanced Math
Cluster ID: SAT Topic 6.9 - Math
Cluster Name: Radicals and rational exponents
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Exponent to Radical
Standard Description: Questions in this category (Rational Exponent to Radical Conversion) require students to utilize their knowledge of rational exponents and their connection to radicals.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.1 - Math
Cluster Name: Center, spread, and shape of distributions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Diagram
Standard Description: Questions in this category (Diagram) require students to utilize their knowledge of graphs, tables and charts to determine statistical information from the data presented.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.1 - Math
Cluster Name: Center, spread, and shape of distributions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Mean
Standard Description: Questions in this category (Mean) require students to use their knowledge of means in order to find or manipulate the mean of a data set.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.1 - Math
Cluster Name: Center, spread, and shape of distributions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Mean Word Problem
Standard Description: Questions in this category (Translate Word Problem + Mean) require students to translate word problems and utilize their knowledge of means in order to find or manipulate the mean of a data set.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.1 - Math
Cluster Name: Center, spread, and shape of distributions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Median
Standard Description: Questions in this category (Median) require students to use their knowledge of medians in order to find or manipulate the median of a data set.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.2 - Math
Cluster Name: Data inferences
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Error
Standard Description: Questions in this category (Margin of Error) require students to utilize their knowledge of margin of error in order to make inferences about given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.2 - Math
Cluster Name: Data inferences
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Word Problem
Standard Description: Questions in this category (Translate Word Problem + Proportion) require students to translate word problems and utilize their knowledge of proportions in order make inferences about given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.3 - Math
Cluster Name: Data representations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Data Diagram
Standard Description: Questions in this category (Diagram) require students to utilize their knowledge of graphs, tables and charts to extract information from the data presented.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.4 - Math
Cluster Name: Linear and exponential growth
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Linear And Exponential
Standard Description: Questions in this category (Linear vs Exponential + Percents) require students to utilize their knowledge of linear, exponential, increasing, and decreasing as well as percentages.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.5 - Math
Cluster Name: Percentages
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Percents
Standard Description: Questions in this category (Percents) require students to utilize their knowledge of percents in order find a missing value.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.5 - Math
Cluster Name: Percentages
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Percents Word Problem
Standard Description: Questions in this category (Translate Word Problem + Percents) require students to utilize their knowledge of percents in order find a missing value.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.6 - Math
Cluster Name: Probability and relative frequency
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Probability
Standard Description: Questions in this category (Probability) require students to utilize their knowledge of probability.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.6 - Math
Cluster Name: Probability and relative frequency
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Probability Diagram
Standard Description: Questions in this category (Diagram) require students to utilize their understanding of tables, charts, and graphs to find the probability of an outcome.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.7 - Math
Cluster Name: Ratios, rates, and proportions
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Proportion Word Problem
Standard Description: Questions in this category (Translate Word Problem) require students to understand a description of a proportional relationship

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.8 - Math
Cluster Name: Scatterplots
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Stats Scatterplot
Standard Description: Questions in this category (Diagram) require students to utilize their knowledge of scatterplots to identify information from the data presented.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.9 - Math
Cluster Name: Unit conversion
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Unit Conversion
Standard Description: Questions in this category (Unit Conversion) require students to utilize their knowledge of unit conversion in order to convert a given value into a different set of units.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.9 - Math
Cluster Name: Unit conversion
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Unit Conversion Area
Standard Description: Questions in this category (Unit Conversion + Area) require students to utilize their knowledge of area and unit conversion in order to convert an area into different units.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 7 - Math
Unit Name: Problem-Solving and Data Analysis
Cluster ID: SAT Topic 7.9 - Math
Cluster Name: Unit conversion
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Unit Conversion Volume
Standard Description: Questions in this category (Unit Conversion + Volume) require students to utilize their knowledge of volumes and unit conversion in order to convert a volume into different units.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Area Polygon
Standard Description: Questions in this category (Finding Area) require students to utilize their knowledge of area formulas.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Area Transformation
Standard Description: Questions in this category (Area Transformation) require students to utilize their knowledge of the relationship between 1D and 2D values between similar figures.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Perimeter
Standard Description: Questions in this category (Perimeter) require students to utilize their knowledge of perimeter.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Surface Area
Standard Description: Questions in this category (Surface Area) require students to utilize their knowledge of surface area.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Volume Difference
Standard Description: Questions in this category (Remaining Volume) require students to utilize their knowledge of volume and understand relationships between solids without a visual provided.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.1 - Math
Cluster Name: Area and volume
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Volume Solids
Standard Description: Questions in this category (Finding Volume) require students to utilize their knowledge of volume.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.2 - Math
Cluster Name: Circle equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Circle Complete Square
Standard Description: Questions in this category (Completing the Square) require students to utilize their knowledge of completing the square in order to transform polynomial equations into the correct circle equation form, and then identify features of the represented circle.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.2 - Math
Cluster Name: Circle equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Circle Equation
Standard Description: Questions in this category (Understanding the circle equation) require students to utilize their knowledge of the circle equation in order to find a feature of the circle described by the equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.2 - Math
Cluster Name: Circle equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Circle Graph
Standard Description: Questions in this category (Solve with Graphing Calculator) require students to utilize their calculator to graph a circle and identify features of that graph.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.2 - Math
Cluster Name: Circle equations
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Circle Transform
Standard Description: Questions in this category (Circle Graph Transformations) require students to utilize their knowledge of transformations in order to apply transformations to a circle equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.3 - Math
Cluster Name: Circle theorems
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Circle Arc Angle
Standard Description: Questions in this category (Arc-Central Angle Connection) require students to utilize their knowledge of the connection between the measurement of the arc of a circle and its central angle.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.4 - Math
Cluster Name: Congruence, similarity, and angle relationships
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Transversals
Standard Description: Questions in this category (Transversals) require students to utilize their knowledge of the relationships between angles created by a transversal line that crosses a set of parallel lines.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.4 - Math
Cluster Name: Congruence, similarity, and angle relationships
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Angle Sum
Standard Description: Questions in this category (Triangle Angle Sum) require students to utilize their knowledge of the sum of angles within a triangle.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.4 - Math
Cluster Name: Congruence, similarity, and angle relationships
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Congruent
Standard Description: Questions in this category (Congruent Triangles) require students to utilize their knowledge of congruent triangles to determine the measurement required to make two triangles congruent to each other.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.4 - Math
Cluster Name: Congruence, similarity, and angle relationships
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Similar
Standard Description: Questions in this category (Similar Triangle Angles) require students to utilize their knowledge of similar triangles to determine the measurement of an angle.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.4 - Math
Cluster Name: Congruence, similarity, and angle relationships
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Similar Right
Standard Description: Questions in this category (Similar Triangle Trigonometry) require students to utilize their knowledge of similar triangles and trigonometry to determine the missing element of a right triangle.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.5 - Math
Cluster Name: Right triangle trigonometry
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Function Relationships
Standard Description: Questions in this category (Trigonometric Functions) require students to utilize their knowledge of sine, cosine and tangent to find a missing value.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.5 - Math
Cluster Name: Right triangle trigonometry
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Pythagorean
Standard Description: Questions in this category (Pythagorean Theorem) require students to utilize their knowledge of the pythagorean theorem in order to find a missing value.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.5 - Math
Cluster Name: Right triangle trigonometry
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Trig Special Right
Standard Description: Questions in this category (Special Right Triangles) require students to utilize their knowledge of Special Right Triangles in order to find a missing value.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: SAT Prep
Course: SAT Prep
Unit ID: SAT Unit 8 - Math
Unit Name: Geometry and Trigonometry
Cluster ID: SAT Topic 8.6 - Math
Cluster Name: Unit circle trigonometry
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: Radian Degree
Standard Description: Questions in this category (Radian-Degree Conversions) require students to utilize their knowledge of radian-degree conversions in order to switch between units.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>
