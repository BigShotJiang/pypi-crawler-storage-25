################################################################
#                                                              #
# Curriculum:      Texas Essential Knowledge and Skills (TEKS) #
# Version:         1.5                                         #
# Snapshot Date:   March 17, 2026 23:34:45                     #
#                                                              #
################################################################

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.3+1
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Fair Shares as Fractions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.E
Standard Description: Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Using Compatible Numbers to Estimate Sums and Differences
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.B
Standard Description: Use compatible numbers to estimate the sum or difference of two numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Solving Real World Array Multiplication Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.D
Standard Description: Solve a real-world problem involving the total number of objects arranged in an array.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Identifying Even and Odd Numbers with Divisibility Rules
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.I
Standard Description: Identify whether a number is even or odd using divisibility rules.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Using Strip Diagrams to Solve Two-Step Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.A
Standard Description: Use strip diagrams to solve two step word problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Geometry: Classify 3D-shapes (Prisms vs Non-Prisms)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.A
Standard Description: Classify and sort three-dimensional shapes, distinguishing between prisms and non-prisms, based on their geometric properties

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Word Problems Involving Measuring Area with Unit Squares
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.C
Standard Description: Solve real world perimeter problems involving a stimulus.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Decomposing Fraction Based on Images
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.D
Standard Description: Identify the decomposition of a fraction into unit fractions based on a given image of a real world situation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Decomposed Fractions
Lesson Order: 142.0
Standard ID: TEKS.MATH.CONTENT.3.3.D+1
Standard Description: Identify the decomposition of a fraction into unit fractions based on a given image of a real world situation.

Key Concepts:
*None specified*

Learning Objectives:
* Represent a fraction shown in a visual model as a sum of unit fractions with the same denominator.

Assessment Boundaries:
* Assessment is restricted to:

Fractions less than or equal to 1 whole.

Denominators 2, 3, 4, 5, 6, 8

Students represent a fraction as a sum of unit fractions

Common Misconceptions:
* Adding Numerators Incorrectly
* Assuming Each Person Represents 1 Whole
* Counting Total Parts Instead of Shaded Parts
* Using the Wrong Denominator

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Models of Equivalent Fractions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.F
Standard Description: Identify models of equivalent fractions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Number Lines
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.3.H
Standard Description: Use number lines to compare fractions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Fair Shares as Fractions
Lesson Order: 143.0
Standard ID: TEKS.MATH.CONTENT.3.3.E+1
Standard Description: Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Key Concepts:
*None specified*

Learning Objectives:
* Solve problems involving partitioning an object or a set of objects among two or more recipients using pictorial representations of fractions with denominators of 2, 3, 4, 6, and 8

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to solve problems involving partitioning a set of objects (>=2) among recipients and expressing one recipient's share as a fraction.
- MUST use standard multiple-choice question (MCQ) format.
- MUST use specific names for recipients (e.g., "Leo and Mia" or "Sam, Zoe, and Max") rather than generic grouping nouns like "friends" in the prompt.
- Numbers MUST result in fractions with denominators of exactly 2, 3, 4, 6, or 8.
- Variable Constraints MUST ensure the Number of Recipients is carefully chosen (e.g., 2 or 3) so the resulting distractors form plausible fractions that students might naturally confuse.              -The stimulus_description is a parametric rendering schema

Common Misconceptions:
* Confuses total objects with denominator instead of using number of recipients.
* Uses number of recipients as numerator and total objects as denominator.
* Uses objects per recipient as numerator with 1 as denominator.
* Uses objects per recipient for both numerator and denominator.

Difficulty Definitions:
* Easy:
  All questions are at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Multiple Equivalent Fractions
Lesson Order: 136.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+1
Standard Description: Identify two fractions equivalent to the point shown on the number line.

Key Concepts:
*None specified*

Learning Objectives:
* Given a point plotted on a number line, identify two equivalent fractions that represent the location of the point.

Assessment Boundaries:
* Assessment must be restricted to:

- Fractions are between 0 and 1 (proper fractions).
- Denominators MUST be limited to: 2, 3, 4, 6, 8.
- Items MUST use a pictorial model (number line or objects/set model such as counters).
- Prompt asks for two equivalent fractions that match the same value shown by the model.
- MCQ with 4 answer choices; each answer choice is a pair of fractions (“___ and ___”).
- Exactly one answer choice contains two fractions that are equivalent AND match the model’s value.
- No procedures requiring formal simplification algorithms; equivalence is derived from the model (partitioning, grouping, counting).

Common Misconceptions:
* Assumes equivalent fractions must have the same numerator regardless of denominator.
* Compares part to part instead of part to whole when modeling fractions.
* Counts tick marks on the number line instead of intervals between marks.
* Identifies one correct fraction but pairs it with a non-equivalent fraction.

Difficulty Definitions:
* Easy:
  Identifying two equivalent fractions from a pictorial set model (counters). Relies on counting individual items vs grouping them into columns/rows.
* Medium:
  Identifying two equivalent fractions from a point on a number line. Relies on understanding intervals and visualizing subdivided marks (e.g., midpoints).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Multiple Equivalent Fractions
Lesson Order: 136.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+1_S
Standard Description: Identify two fractions equivalent to the point shown on the number line.

Key Concepts:
*None specified*

Learning Objectives:
* Given an image of a set of items, identify two equivalent fractions that represent the shaded portion.

Assessment Boundaries:
* Assessment must be restricted to:

- Fractions are between 0 and 1 (proper fractions).
- Denominators MUST be limited to: 2, 3, 4, 6, 8.
- Items MUST use a pictorial model (number line or objects/set model such as counters).
- Prompt asks for two equivalent fractions that match the same value shown by the model.
- MCQ with 4 answer choices; each answer choice is a pair of fractions (“___ and ___”).
- Exactly one answer choice contains two fractions that are equivalent AND match the model’s value.
- No procedures requiring formal simplification algorithms; equivalence is derived from the model (partitioning, grouping, counting).

Common Misconceptions:
* Assumes equivalent fractions must have the same numerator regardless of denominator.
* Compares part to part instead of part to whole when modeling fractions.
* Counts tick marks on the number line instead of intervals between marks.
* Identifies one correct fraction but pairs it with a non-equivalent fraction.

Difficulty Definitions:
* Easy:
  Identifying two equivalent fractions from a pictorial set model (counters). Relies on counting individual items vs grouping them into columns/rows.
* Medium:
  Identifying two equivalent fractions from a point on a number line. Relies on understanding intervals and visualizing subdivided marks (e.g., midpoints).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Models of Equivalent Fractions
Lesson Order: 144.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+2
Standard Description: Identify models of equivalent fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Select the equivalent fractions and understand why they are equivalent, given a fractional number line with a point
* Select the equivalent pair among fractional bar graph models

Assessment Boundaries:
* Assessment must be restricted to:
- Fractions must have denominators of 2, 3, 4, 6, or 8.
- All fractions must be less than one (proper fractions only).
- No use of mixed numbers or improper fractions.
- No use of variables or algebraic symbols; only numeric fractions and visual models.
- Students are not required to generate equivalent fractions; they select or identify models that represent equivalent fractions.
- Easy questions use fraction bar models only; medium questions use number line models only.
- No simplifying fractions as a standalone task; simplifying is used only as a strategy within the context of identifying equivalence.
- No comparing or ordering fractions beyond identifying whether two fractions are equivalent.
- Number lines run from 0 to 1 only.
- Bar models show one whole partitioned into equal parts with some parts shaded.
- Distractors may include fractions with matching numerators or matching denominators that are not equivalent, as well as incorrect explanations of why fractions are equivalent.

Common Misconceptions:
* Students believe fractions with the same denominator are automatically equivalent, ignoring that different numerators represent different amounts of the whole.
* Students believe fractions with the same numerator are automatically equivalent, ignoring that different denominators change the size of each part.
* Students believe two fractions are equivalent whenever they look similar in a model, without verifying that the shaded portions represent the same amount of the whole.

Difficulty Definitions:
* Easy:
  Uses bar model representation
Shows multiple fraction bar graphs
Student selects which bar graphs represent the same fraction
Denominators of 2, 3, 4, 6, and 8
* Medium:
  Uses number line representation
Student selects which fractions represent the given point on the number line
Denominators of 2, 3, 4, 6, and 8
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Identifying Equivalent Fractions on Number Lines
Lesson Order: 145.0
Standard ID: TEKS.MATH.CONTENT.3.3.F+3
Standard Description: Identify equivalent fractions on a number line

Key Concepts:
*None specified*

Learning Objectives:
* Select the equivalent fractions and understand why they are equivalent, given a fractional number line with a point

Assessment Boundaries:
* Assessment must be restricted to:
- Fractions must have denominators of 2, 3, 4, 6, or 8.
- All fractions must be less than one (proper fractions only).
- No use of mixed numbers or improper fractions.
- No use of variables or algebraic symbols; only numeric fractions and visual models.
- Students are not required to generate equivalent fractions; they select or identify models that represent equivalent fractions.
- No simplifying fractions as a standalone task; simplifying is used only as a strategy within the context of identifying equivalence.
- No comparing or ordering fractions beyond identifying whether two fractions are equivalent.
- Number lines run from 0 to 1 only.
- Distractors may include fractions with matching numerators or matching denominators that are not equivalent, as well as incorrect explanations of why fractions are equivalent.

Common Misconceptions:
* Students count tick marks instead of intervals on a number line, resulting in an incorrect denominator and misidentified fractions.

Difficulty Definitions:
* Easy:
  All easy questions
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Fraction Strips
Lesson Order: 133.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+2
Standard Description: Compare fractions using fraction strips.

Key Concepts:
*None specified*

Learning Objectives:
* Compare two unit fractions using fraction strips.
* Determine whether two fractions represented by strips are equivalent and justify the reasoning.
* Identify which fraction is equivalent to a given fraction using fraction strips.

Assessment Boundaries:
* Assessment is restricted to:

Proper fractions only (numerator less than denominator).

Whole numbers limited to 1 whole.

Visual models must be fraction strips of equal length.

Fractions share either:

The same numerator, OR
The same denominator, OR
Represent equivalent fractions.

Students compare fractions using <, >, = Or verbal justification.

Denominators limited to 2, 3, 4, 6, 8

No computation using common denominators.

Reasoning must rely on visual size and part relationships.

Common Misconceptions:
* Assuming More Pieces Means More Area
* Comparing Only Numerators
* Counting Pieces Instead of Size
* Larger Denominator Means Larger Fraction

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3-Staging
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with the Same Numerator or Denominator: Word Problems
Lesson Order: 146.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+3
Standard Description: Solve a real world problem involving comparing fractions with the same numerator or the same denominator.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem involving two fractions with the same numerator or the same denominator, determine the true comparative statement

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to compare two fractions in a real-world word problem.
- MUST use two fractions that have EITHER the same numerator OR the same denominator.
- MUST NOT use fractions where both the numerators and denominators are different.
- Allowed Denominators: Up to 9 (e.g., 2, 3, 4, 5, 6, 7, 8, 9).
- Response Type: MCQ with exactly 4 options.
- Option Format: Sentences describing the comparison using words (e.g., "is greater than", "is equal to").
- Distractors must be around common misconceptions

Common Misconceptions:
* Believes larger denominator means larger fraction when numerators are the same.
* Claims insufficient information exists to compare fractions with same numerator or denominator.
* Concludes fractions are equal because they share the same numerator or denominator.
* Reverses the inequality relationship when comparing fractions with same denominator or numerator.

Difficulty Definitions:
* Easy:
  All at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 147.0
Standard ID: -
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal-sized groups (base-10 blocks), equal jumps on a number line, or skip counting
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 options. Options must mix visual models (number lines, base-10 block drawings) and numeric lists (skip counting).
- Distractor Logic MUST reflect :Identifying a skip-counting pattern that adds the correct amount but incorrectly starts at the first factor (e.g., for 7*11, starting at 7 instead of 11).Misinterpreting base-10 strips (tens) and units (ones) as single equivalent blocks.Failing to recognize that equal jumps on a number line directly represent multiplication.
- Items may ask for the correct representation OR the one representation that is NOT correct.

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the matching representation among several (array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Using Compatible Numbers to Estimate Sums and Differences
Lesson Order: 147.0
Standard ID: TEKS.MATH.CONTENT.3.4.B+1
Standard Description: Use compatible numbers to estimate the sum or difference of two numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Given a table image of three numbers, use compatible numbers or rounding to the nearest hundred to estimate how much more or fewer is one quantity than the other from the given answer choices.
* Given a table image of three numbers, use compatible numbers or rounding to the nearest ten to estimate how much more or fewer is one quantity than the other from the given answer choices.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world contexts only.
- All values must be whole numbers up to 1,000.
- Estimation strategy: rounding to the nearest hundred or ten.
- The sum or difference must be 3 digit as well.
- Do not add tables in question stem string.
- All 3 numbers must be 3 digit.

Common Misconceptions:
* For difference (subtraction) problems, students subtract the exact values first and then round the result, instead of rounding each number first and then subtracting. Example: 384 − 276 = 108, then round to 110. Correct approach: round first (380 − 280 = 100). This produces an answer close to but different from the correct estimate. This error does not apply to sum (addition) problems.
* Students round all numbers to the same inflated value or always round up to the next hundred (or ten) regardless of the deciding digit, grossly overestimating. For nearest hundred: rounding 123 up to 200 or even 300 because the other addends are near 300, or treating every number as if it rounds up. For nearest ten: rounding 214 up to 220 and 362 up to 370 even though both should round down. This inflates sums and skews differences.
* Students round one or more numbers in the wrong direction — rounding up when the deciding digit is below 5, or down when it is 5 or above. For nearest hundred: 123 → 200 instead of 100 (tens digit 2 < 5, should round down). For nearest ten: 384 → 390 instead of 380 (ones digit 4 < 5, should round down). This shifts the estimate by one unit of the rounding place value.
* Students truncate each number instead of rounding — they keep the leading digit(s) and replace the rest with zeros. For nearest hundred: 273 → 200 instead of 300 (keeps hundreds digit only). For nearest ten: 276 → 270 instead of 280 (keeps tens digit, zeros out ones). This consistently produces underestimates in both sum and difference problems.

Difficulty Definitions:
* Easy:
  3 digit numbers.
round to nearest 100
* Medium:
  3 digit numbers.
round to nearest 10.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Solving Real World Multiplication Problems
Lesson Order: 137.0
Standard ID: TEKS.MATH.CONTENT.3.4.D+1
Standard Description: Solve a real-world problem involving the total number of objects arranged in an array.

Key Concepts:
*None specified*

Learning Objectives:
* Solve multiplication word problems involving equal groups shown in a visual context

Assessment Boundaries:
* Assessment is restricted to: 
  • Each image has at most 9 objects (first factor of the multiplication)
  • There at most 9 pages/panels, the thing the image represents (second factor of the multiplication)
  • Show either portraits or electrical outlets
  • Questions ask the student how many objects there would if there are X pages/panels etc.

Common Misconceptions:
* Student ignores the number of groups and simply reporting the count of objects in one image
* Student miscounts the number of objects in the image and then multiplying with the wrong first factor.
* Student multiplies the number of objects by itself or the number of groups by itself
* Students adds the two numbers instead of multiplying them.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  MCQ with stimulus, 1 image of up to 9 objects. Question asks for a multiplication up to 9 x 9
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.E
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 148.0
Standard ID: TEKS.MATH.CONTENT.3.4.E+1
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
* Determine which representation is NOT a correct method for a given multiplication fact.

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal jumps on a number line, or skip counting sequences.
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 image-based answer options and exactly 1 correct answer.
- All 4 answer options are rendered as images. No text-only answer options.
- Items may ask "Which is a correct method?" (1 correct representation, 3 incorrect) OR "Which is NOT a correct method?" (1 incorrect representation, 3 correct). In BOTH cases, exactly 1 option must be marked correct: true.
- Distractor Logic MUST reflect:
  a) A skip-counting pattern that adds the correct increment but incorrectly starts at the wrong factor (e.g., for 7 × 11, starting at 7 instead of 11).
  b) A number line with the wrong number of jumps or wrong jump size.
  c) An array with incorrect dimensions (wrong rows or columns).

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the correct representation among incorrect ones(array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A\

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Represent Multiplication in Multiple Ways
Lesson Order: 147.0
Standard ID: TEKS.MATH.CONTENT.3.4.E+1_S
Standard Description: Represent a multiplication fact in a variety of ways.

Key Concepts:
*None specified*

Learning Objectives:
* Determine which representation is a correct method for a given multiplication fact.
* Given a point plotted on a number line, identify two equivalent fractions that represent the location of the point.

Assessment Boundaries:
* Assessment must be restricted to:
- MUST assess the student's ability to represent a multiplication fact using arrays, equal-sized groups (base-10 blocks), equal jumps on a number line, or skip counting
- Multiplication facts use whole numbers, factors typically 0–15.
- Response Type: MCQ with exactly 4 options. Options must mix visual models (number lines, base-10 block drawings) and numeric lists (skip counting).
- Distractor Logic MUST reflect :Identifying a skip-counting pattern that adds the correct amount but incorrectly starts at the first factor (e.g., for 7*11, starting at 7 instead of 11).Misinterpreting base-10 strips (tens) and units (ones) as single equivalent blocks.Failing to recognize that equal jumps on a number line directly represent multiplication.
- Items may ask for the correct representation OR the one representation that is NOT correct.

Common Misconceptions:
* Confuses repeated addition with single jumps that don't represent equal groups or factors.
* Misidentifies the number of jumps or groups needed to match the given multiplication fact.
* Starts skip-counting sequence at the first factor instead of zero or the jump size.
* Treats each base-10 strip as one unit rather than ten individual units.

Difficulty Definitions:
* Easy:
  Given a multiplication equation, choose the matching representation among several (array vs number line jumps vs repeated addition vs skip counting).
* Medium:
  “NOT correct method” style: multiple representations are shown, and the incorrect one contains a subtle flaw (wrong starting value, wrong number of jumps, mismatched total, or misinterpreted groups).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4-Staging
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Identifying Even and Odd Numbers with Divisibility Rules
Lesson Order: 149.0
Standard ID: TEKS.MATH.CONTENT.3.4.I+1
Standard Description: Identify whether a number is even or odd using divisibility rules.

Key Concepts:
*None specified*

Learning Objectives:
* Given a 2-digit number, determine its parity to select the correct rationale statement based on the ones place.
* Given a 3-digit even number, determine its parity to select the correct rationale statement based on divisibility by 2, guarding against hundreds and tens place traps.

Assessment Boundaries:
* Assessment restricted to:
- MUST assess identifying a whole number as even or odd and correctly justifying it using the digit in the ones place OR the divisibility rule for 2.
- MUST use standard Multiple Choice (MCQ) format.
- MUST NOT require actual computation of long division; the focus is on applying the rule of divisibility and place value identification.
- Numbers MUST be whole numbers between 10 and 999.
- Exactly one correct answer per item.
- Distractors MUST specifically target misconceptions for example (bit not limited to)
 a) Looking at the tens or hundreds place instead of the ones place.
 b) Applying the wrong divisibility rule (e.g., dividing by 3 or 9).
 c) Confusing the definitions of even and odd (e.g., saying a number is odd because it divides by 2 evenly).
- Distractors must be centered around common misconceptions.

Common Misconceptions:
* Assumes a number is even or odd based on whether the entire number "looks" even or odd visually.
* Confuses the definitions of even and odd, labeling numbers divisible by 2 as odd.
* Looks at the tens or hundreds digit instead of the ones digit to determine even or odd.
* Misapplies divisibility rules for 3, 5, or 9 to determine even or odd status.

Difficulty Definitions:
* Easy:
  Given: A 2-digit whole number (10–99).
Missing: The correct even/odd classification and its rationale.
Reasoning required: Direct lookup of the ones place digit to determine parity.
Trap strength: Plausible distractors using the tens place digit or a common factor (like 9), but minimal visual overload.
No near-boundary ambiguity: Number length is short, reducing cognitive load when identifying the rightmost digit.
* Medium:
  Given: A 3-digit whole number (100–999).
Missing: The correct even/odd classification and its rationale.
Reasoning required: Must ignore the hundreds and tens places, focusing solely on the ones place or the divisibility rule for 2.
Trap strength: Stronger distractors leveraging the hundreds place, tens place, and divisibility by 3 (which commonly confuses students with "odd").
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Missing Factors in Multiplication and Division Equations
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.D
Standard Description: Determine the unknown whole number in a multiplication or division equation.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2-Staging
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Representing Addition with Models, Number Lines and Equations
Lesson Order: 150.0
Standard ID: TEKS.MATH.CONTENT.3.5.A+2
Standard Description: Represent one step addition and subtraction problems with number lines, fraction strups, and equations.

Key Concepts:
*None specified*

Learning Objectives:
* Given a one-step word problem involving subtraction of whole numbers where the start and the result are known but the change is unknown, select the equation, strip diagram, or number line that correctly represents the relationship by identifying the whole (start), the known part (result), and the unknown part (change).

Assessment Boundaries:
* Assessment is restricted to:
- All numbers must be whole numbers up to 1,000.
- Do not include more than one step in the problem — restrict to one-step problems only.
- Number line should always have step size either 50 or 100 and minor_ticks_between should always be 4.
- Number line number of tick steps should be always between 3 and 8 (inclusive) (including the 0th tick and max_value tick)
- Distractors across different representation types (equation, strip diagram, number line) are allowed to evaluate to the same underlying numerical value, since students are selecting a model, not a number.

Common Misconceptions:
* Students cannot correctly identify the whole (total) in a word problem — in subtraction contexts they treat the unknown as the whole instead of the starting amount (e.g., representing "had 280, sold some, 130 left" as ? = 280 + 130); This leads to a representation with an incorrect part-whole structure. For equations and strip diagrams, apply this by swapping which value is the whole. For number lines, do NOT apply this misconception by changing the total — instead, keep the correct total and change part1 to a wrong value that reflects the student confusing which quantity is the known part.
* Students choose the correct operation but apply it to the wrong pair of quantities or swap the known values — they may write the correct type of equation or draw the correct type of model, but mislabel which number is which, leading to a representation that does not match the specific scenario described in the word problem. For number lines, this is the preferred way to create a distractor: keep the correct total and use a wrong part1 value (e.g., if total=530 and remaining=210, a distractor number line could show total=530 with part1=320 or part1=250 instead of the correct part1=210).
* Students reverse the positions of known and unknown quantities in a representation — in subtraction they write □ − whole = part instead of whole − □ = part (e.g., □ − 280 = 130 instead of 280 − □ = 130); producing a structure where the total is smaller than one of its parts. This indicates the student does not understand how to correctly position quantities in an equation or model.
* Students select the wrong operation because they do not connect the action words in the problem to the correct mathematical operation — in subtraction contexts (sold, gave away, ate, lost) they default to addition. The student needs to focus on matching the context of the problem to the appropriate operation.

Difficulty Definitions:
* Easy:
  Both known values in the problem are multiples of either 50 or 100.
Value may be 2 digit number.
* Medium:
  Both known values in the problem are all three-digit numbers.
Both known values are multiple of 10 but not a multiple of 50 (if number line step size is 50) OR a multiple of 20 but not a multiple of 100 (if number line step size is 100).
* Hard:
  Both known values values in the problem are three-digit numbers.
Either one of the known values is a multiple of 20 + 10, the other is a multiple of 20.
number line step size should be 100 only. (not 50)

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2-Staging
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multiplicative Comparisons
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.C
Standard Description: Describe a multiplication expression as a comparison.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2-Staging
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multiplicative Comparisons
Lesson Order: 151.0
Standard ID: TEKS.MATH.CONTENT.3.5.C+1
Standard Description: Describe a multiplication expression as a comparison.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world context where one quantity is described by a multiplication expression involving another quantity, complete a comparison statement by placing the correct name, multiplier, and comparison phrase into the appropriate blanks.
* Given a real-world context where one quantity is described by a multiplication expression involving another quantity, select the true comparison statement from options that include both multiplicative ("times as many") and additive ("more than") phrasings with correct and reversed subjects.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world contexts only.
- All quantities must be whole numbers with products up to 100.
- The multiplier must be a single-digit number from 2 through 9.
- The base must be a single-digit number from 2 through 9.
- The expression always represents the quantity of the second person mentioned; the first person's quantity is stated directly in the stem.
- Comparison language is limited to "times as many [noun] as" (multiplicative) and "more [noun] than" (additive, used only in distractors).
- Only two people are involved in each question.

Common Misconceptions:
* Students both confuse additive with multiplicative language AND reverse the direction of comparison (e.g., saying "Haruko did 2 more sit-ups than Tom" when the expression 2 × 9 represents Tom's sit-ups).
* Students confuse additive comparison language ("more [noun] than") with multiplicative comparison language ("times as many [noun] as") — they interpret the multiplication expression as describing an additive relationship (e.g., saying "Tom did 2 more sit-ups than Haruko" instead of "Tom did 2 times as many sit-ups as Haruko").
* Students misidentify which factor in the multiplication expression is the multiplier — they select the base quantity as the scale factor instead of the actual multiplier (e.g., in 8 × 3 where 8 is the base and 3 is the multiplier, the student says "8 times as many" instead of "3 times as many").
* Students reverse the direction of the multiplicative comparison — they attribute "times as many" to the person with the base quantity instead of the person with the multiplied quantity (e.g., saying "Haruko did 2 times as many sit-ups as Tom" when the expression 2 × 9 represents Tom's sit-ups, not Haruko's).

Difficulty Definitions:
* Easy:
  The multiplier is 2, 3, 4 or 5
The base is a single-digit number
* Medium:
  The multiplier is moderate 6 through 9
The base is a single-digit number
* Hard:
  Base and multiplier are both single digit between 2-9
Multi select only

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2-Staging
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Missing Factors in Multiplication and Division Equations
Lesson Order: 152.0
Standard ID: TEKS.MATH.CONTENT.3.5.D+1
Standard Description: Determine the unknown whole number in a multiplication or division equation.

Key Concepts:
*None specified*

Learning Objectives:
* Complete the missing factor in a division equation
* Complete the missing factor in a multiplication equation

Assessment Boundaries:
* Assessment is restricted to:
- Unknown factors MUST be single-digit (1–10)
- Multipications up to 100
- No real-world problems.
- No use of variables (e.g., a, n, x); use ONLY the box symbol (□, \square) for unknown values.
- Question stem should ONLY be "What number goes in the $\square$ to make the equation true? \n $$\square (\div or \times) __ = __$$"

Common Misconceptions:
* Incorrectly does the multiplication and finds the answer +/- 1
* Treats × as + and solves with addition
* Treats × as - and solves with subtraction

Difficulty Definitions:
* Easy:
  Factors 1-5
* Medium:
  Factors larger than 5
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1-Staging
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Classifying 2D Shapes
Lesson Order: 141.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+3
Standard Description: Classify a group of 2D shapes.

Key Concepts:
*None specified*

Learning Objectives:
* Given a set of 2D figures, classify and group them by their attributes (number of sides) to determine the correct count of triangles, quadrilaterals, pentagons, and/or hexagons in the set.

Assessment Boundaries:
* Assessment is restricted to:
- 2D polygon figures only (triangles, quadrilaterals, pentagons, hexagons).
- Classification is based on the number of sides only (not angle measures, symmetry, or side lengths).
- Each set contains between 4 and 6 figures.
- Shape categories used: triangles (3 sides), quadrilaterals (4 sides), pentagons (5 sides), hexagons (6 sides).
- At least two different shape categories must be present in each set in the question.
- Answer options list the count of each shape category in the set.
- only 1 of the answer options may contain a single shape, other 3 should have atleast 2 shapes.
- Do not use the names of specific quadrilaterals (e.g., "rectangle," "rhombus," "trapezoid") in the answer options — use only "quadrilaterals".
- Answer options should never mention 0 frequency shape.

Common Misconceptions:
* Students classify shapes by overall visual appearance or prototype matching rather than systematically counting sides. For example, a rotated square (diamond orientation) may not be recognized as a quadrilateral, or an irregular polygon may be misclassified because it does not match the student's mental image of that shape category.
* Students miscount sides on concave or irregular polygons where sides meet at unusual angles, leading to an error of ±1 in their side count. This is especially common with irregular quadrilaterals that resemble trapezoids or pentagons, and with irregular pentagons that have a nearly straight angle making them look like quadrilaterals.
* Students overcount the sides of a polygon by 1, classifying it as the next-higher category — for example, counting a quadrilateral (4 sides) as a pentagon (5 sides), or a pentagon (5 sides) as a hexagon (6 sides). The student may count a vertex twice or misjudge where one side ends and another begins.
* Students undercount the sides of a polygon by 1, classifying it as the next-lower category — for example, counting a quadrilateral (4 sides) as a triangle (3 sides), or a pentagon (5 sides) as a quadrilateral (4 sides). This happens when the shape has one very short side the student overlooks, or when an irregular outline appears visually similar to a shape with fewer sides.

Difficulty Definitions:
* Easy:
  4 shapes
2 categories only.
* Medium:
  6 shapes
3 categories only.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1-Staging
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Area Covering a Grid
Lesson Order: 135.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+3
Standard Description: Identify the area of a shaded figure on a grid.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the area of a rectangle by multiplying its side lengths without images
* Calculate the area of a rectangle by multiplying its side lengths, including interpreting side lengths/rows from unit-square representations.
* Determine the area of a composite figure formed by rectangles by decomposing it into non-overlapping rectangles and adding their areas.

Assessment Boundaries:
* Assessment is restricted to:
- area of rectangles with whole-number side lengths using multiplication as rows × unit squares per row, or
- area of composite figures formed by rectangles using additive property of area (sum of rectangle areas).
- Side lengths must be whole numbers between 2 and 10 for images, and 2 and 16 for text-only questions
- All areas must be whole numbers; no fractional/decimal areas.
- Only multiplication of whole numbers for rectangle area (A = l×w)
- Composite area must be solvable by decomposing into 2 non-overlapping rectangles and adding their areas
- Figures allowed: Rectangles (including squares) aligned to grid lines. Composite rectilinear figures that can be partitioned into 2 rectangles with edges on grid lines (e.g., L-shapes, T-shapes).
- Figures excluded: Any figures requiring non-rectangular area formulas (triangles, circles), rotated rectangles (not aligned to grid), overlapping sub-rectangles, or shapes with curved boundaries.
- Representations allowed: Unit-square grids where each square represents exactly 1 square unit of area. Tiling/array word descriptions explicitly giving “rows” and “squares per row,” with each tile covering 1 square unit.
- Context constraints: Context may reference real objects (lawn, card, floor, ceiling) but must not require any measurement conversion; the unit-square legend or tile coverage must be exactly 1 square unit per square.

Common Misconceptions:
* Confuses perimeter with area, adding side lengths instead of multiplying.
* Misapplies additive area, adding side lengths of rectangles instead of areas.
* Miscounts unit squares on a grid, especially when starting off-by-one.
* Treats rows × squares per row as addition, counting only rows or columns.

Difficulty Definitions:
* Easy:
  non-transparent rectangle on grid
Sides between 2 and 10 units long (total size below 50)
* Medium:
  Text-only description of an object with rectangular shape
Sides between 2 and 16 units long (total size between 10 and 80)
<TEMPORARY>- Medium questions do NOT have a stimulus and are NOT grid based. NEVER fail medium questions based on Easy/Hard criteria.
* Hard:
  Transparent compound shape decomposable into 2 rectangles on a grid
Sides between 2 and 10 units long (total size below 50)

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Representing Fractions with Jumps on the Number Line
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.A
Standard Description: Match number line models of jumps with fractions that they represent.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Problems Involving Complex Shapes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.B
Standard Description: Solve perimeter problems involving complex shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Appropriate Units of Measurements
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.7.E
Standard Description: Determine liquid volume (capacity) or weight using appropriate units and tools.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Real World Fraction Segments on the Number Line
Lesson Order: 140.0
Standard ID: TEKS.MATH.CONTENT.3.7.A+2
Standard Description: Given a real-world situation represented by a segment on a number line, determine the fraction represented.

Key Concepts:
*None specified*

Learning Objectives:
* Match a real world fraction problem to an illustrated number line

Assessment Boundaries:
* Assessment is restricted to:
- Distractor options with the same simplified value are not allowed (e.g. if 1/3 is correct, a 2/6 distractor is disallowed)
- Fractions (Allowed): Proper fractions strictly between 0 and 1 with denominators in the set {2, 3, 4, 5, 6, 8, 10}.
- Numerators (Allowed): Integers (n) such that (1 \le n \le d-1) for denominator (d \in {2, 3, 4, 5, 6, 8, 10}).
- Fraction Meaning: Fraction interpreted as a distance from 0 on a number line (position).
- Number Line Interval: Number lines represent a single unit interval from 0 to 1.
- Point Placement: The target point must be located exactly on a tick mark corresponding to a fraction of the form ( \frac{n}{d} ) (no points between tick marks).
- Labels: The point is identified by a single capital letter (e.g., J, A).
- Context (Allowed): Real-world “distance traveled from a starting location” situations (e.g., bike ride, ant crawl) with a named unit (e.g., miles, yards). (Units are contextual only; computation does not require conversions.)
- Exclusions: No mixed numbers, improper fractions, decimals, negative numbers, or intervals other than 0 to 1.

Common Misconceptions:
* Confuses denominator with number of tick marks, not equal intervals.
* Counts from 1 backward instead of from 0 as starting point.
* Miscounts fractional steps, placing point on the wrong tick, though selecting a number line with the right partitioning.
* Treats numerator as the denominator and selects that partitioning.

Difficulty Definitions:
* Easy:
  Denominators 2, 3, 4
Numerators 1 or 2
Distractors may use any allowable denominator (2, 3, 4, 5, 6, 8, 10)
* Medium:
  Denominators 5, 6, 8, 10
Any numerator value
Distractors may use any allowable denominator (2, 3, 4, 5, 6, 8, 10)
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Word Problems Involving Images
Lesson Order: 134.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+4
Standard Description: Given an image of a real-world situation, calculate the perimeter.

Key Concepts:
*None specified*

Learning Objectives:
* Given an image of a rectangular real-world object with the length and width labeled, calculate the perimeter
* Given an image of a square real-world object with one side labeled, calculate the perimeter
* Given the perimeter and one dimension of a rectangular or square real-world object, determine the missing side length
* Given the perimeter of a regular 3–8 sided polygon, determine the missing side length

Assessment Boundaries:
* Assessment is restricted to:
- MUST assess perimeter- or a missing length- that is determined using perimeter.
- MUST use a 2-D polygon image- (real-world object/outline).
- Allowed polygons: 3–8 straight sides- only.
- All given lengths MUST be whole numbers- and use one unit- per item (cm / in. / ft).
- NO unit conversions.
- NO measuring from the picture (all needed info comes from labels and/or a statement).
- If the problem uses “all sides are the same length”, it MUST be stated in text and the polygon’s side count must be clearly countable.
- Exactly one correct answer- per question.

Common Misconceptions:
* - Confuses perimeter with area by multiplying side lengths instead of adding them.
* Counts only the labeled sides and ignores unlabeled sides when calculating perimeter.
* Divides the perimeter by the number of sides instead of multiplying when finding perimeter.
* Multiplies one side length by two instead of adding all sides around the polygon.

Difficulty Definitions:
* Easy:
  3–6 side polygon with all sides labelled.
* Medium:
  3–6 side polygon where it’s stated all sides are same- (NON squares and rectangles).
Square - labelled one side.
Rectangle - length and width.
* Hard:
  3–8 polygons where perimeter is given- and students find the missing length.

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Appropriate Units of Measurements
Lesson Order: 153.0
Standard ID: TEKS.MATH.CONTENT.3.7.E+1
Standard Description: Determine liquid volume (capacity) or weight using appropriate units and tools.

Key Concepts:
*None specified*

Learning Objectives:
* Relative Scale Estimation: Use a provided visual stimulus to determine the most reasonable whole-number quantity for an object's capacity or weight based on its real-world size.
* Unit Category Identification: Discriminate between different types of measurement (e.g., volume vs. weight vs. length) to select the correct unit type for a given liquid or solid object.

Assessment Boundaries:
* Assessment is restricted to:

Context: Word problems must involve a relatable real-world object (e.g., a bottle of water, a juice box).

Stimulus Requirements:

Unit Identification: No visual stimulus is required; the object is identified by text only.

Scale Estimation: A visual stimulus (image) of the object must be provided to establish a sense of scale.

Unit Types:

Liquid Volume (Capacity): Milliliters, Liters, Fluid ounces, Cups, Pints, Quarts, Gallons.

Weight/Mass: Grams, Kilograms, Ounces, Pounds.

Distractor Logic:

Include incorrect unit types (e.g., using "inches" for volume) to test category knowledge.

Include incorrect magnitudes (e.g., "2 liters" vs. "200 milliliters" for a juice box) to test scale.

Formatting: All units must be spelled out in full; no unit conversions or complex calculations are allowed.

Common Misconceptions:
* Assumes larger numbers always represent larger objects regardless of the unit's actual size.
* Confuses weight and liquid volume units when identifying the correct measurement category.
* Misapplies small units like grams to measure the weight of heavy, everyday objects.
* Treats milliliters and liters as interchangeable, ignoring the significant difference in their scale.

Difficulty Definitions:
* Easy:
  Unit Identification: Identify the correct type of unit for an object without a visual aid (e.g., fluid ounces for a bottle of water).
* Medium:
  Scale Estimation: Use a visual stimulus to select the most reasonable measurement quantity for an object (e.g., 200 milliliters for a juice box).
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Creating Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.8.A
Standard Description: Create dot plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Multiple Data Representations
Lesson Order: 138.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+3
Standard Description: Represent data with a variety of data representations.

Key Concepts:
*None specified*

Learning Objectives:
* Select the correct data representation image for a given frequency graph

Assessment Boundaries:
* Assessment is restricted to:
- Question stem must have real-world scenarios only.
- Data values must be whole numbers; values in each category must be below 50.
- Exactly one table (frequency table or tally-style table) is given per question; students choose among four image answer options.
- Use numbers which are scalable in each question and question option so they can be represented by 12 or less scaled units.
- No decimals or fractions in category counts.
- Question stem must state either "Which answer choice represents the information in the table?" (Easy) or "Which answer choice does NOT represent the information in the table?" (Medium).

Common Misconceptions:
* Applies the scale incorrectly, leading to a wrong conclusion
* Confuses which category is wrong and picks an option that matches the table.
* Matches only some categories and misses the one that is different in the image.
* Reads the table incorrectly and compares against the wrong numbers.

Difficulty Definitions:
* Easy:
  Which answer choice represents the information in the table?
Student identifies the one image that matches the table (all category counts correct).
One correct, three distractors with at least one category value wrong.
Whole numbers only; values below 50; 4 categories; real-world context.
* Medium:
  Which answer choice does NOT represent the information in the table?
Student identifies the one image that has at least one category count wrong.
Four image options; three match the table, one does not (one value changed).
Whole numbers only; values below 50; 4 categories; real-world context.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Dot Plots
Lesson Order: 154.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+4
Standard Description: Represent a data set with a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Given a dot plot with a key, identify the list of numbers that the dot plot represents by reading the value below each dot, including repeated values.
* Given a list of data values, identify which dot plot correctly represents the data

Assessment Boundaries:
* Assessment is restricted to:
- Whole number data only.
- Range of up to 10.
- Data sets containing 8–16 values.
- At least one value must appear more than once (so frequency matters).
- Non consecutive data values.
- At least one value on the number line must have zero dots.

Common Misconceptions:
* Students confuse the number line labels with data points — they treat every number on the axis as a data value. When reading a dot plot, they list every number printed on the axis whether or not it has dots above it. When choosing a dot plot, they pick one that places dots above every labeled value on the axis, including values not in the data set.
* Students correctly identify which values appear in the data but miscount the frequency of one or more values. They pick a dot plot where the dot counts for most values are correct but one or two values have dots swapped or miscounted (e.g., showing 2 dots instead of 3 for one value and 3 instead of 2 for another).
* Students correctly identify which values have dots but include extra values from the number line boundary. They list each unique value that has dots once (ignoring stacked dots) and also include the endpoint of the number line (e.g., 10) even though it has no dots above it.
* Students ignore frequency — they treat each distinct data value as appearing exactly once. When reading a dot plot, they list each number that has dots only once, regardless of how many dots are stacked above it. When choosing a dot plot, they pick one with exactly one dot per unique value.

Difficulty Definitions:
* Easy:
  range 8
number of values 9-12
* Medium:
  range 10
number of values 13-20
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Multi-Step Problem Solving with Bar Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.8.B
Standard Description: Solve multi-step problems using categorical data represented with a bar graph with scaled intervals

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8-Staging
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Multi-Step Problem Solving with Bar Graphs
Lesson Order: 155.0
Standard ID: TEKS.MATH.CONTENT.3.8.B+1
Standard Description: Solve multi-step problems using categorical data represented with a bar graph with scaled intervals

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the difference between two specific categories on a bar graph to determine "how many more" or "how many less."
* Calculate the total value of all data in a 5-bar horizontal bar graph by identifying the numerical value of each category from a scaled interval and finding their sum.
* Execute multi-step comparisons by calculating the combined sum of two or more categories and finding the difference between that sum and other data points.

Assessment Boundaries:
* Assessment is restricted to:
Data Representation: Vertical graphs contain exactly four categories; horizontal graphs contain exactly five categories.

Scale Logic: Unlabeled grid lines always represent the exact midpoint of numbered intervals.

Operational Limits: Identification of data points and execution of addition and/or subtraction.

Numerical Limits: Individual values within 100; grand totals within 1,000.

Graph Orientation: Used interchangeably for all problem types.

Exclusions: No bars ending between grid lines; all bars must align exactly with a numbered or unlabeled midpoint line.

Common Misconceptions:
* Assumes unlabeled grid lines represent increments of one regardless of the actual scale.
* Commits regrouping or place-value errors when summing three or more two-digit data points.
* Identifies the value of the single tallest bar instead of summing all categories.
* Misreads unlabeled grid lines as the nearest labeled numerical value on the axis.

Difficulty Definitions:
* Easy:
  (Single Comparison) - Find the difference between two categories (A - B).
* Medium:
  (Total Sum) - Find the sum of all categories (A + B + C + D + E).
* Hard:
  (Compound Comparison) - Compare the sum of two categories to the sum of others (A + B) - (C + D).

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Saving Money
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.E
Standard Description: List reasons to save and explain the benefit of a savings plan, including for college

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Availability of Resources Versus Cost
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.B
Standard Description: Describe the relationship between the availability or scarcity of resources and how that impacts cost

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Availability of Resources Versus Cost
Lesson Order: 156.0
Standard ID: TEKS.MATH.CONTENT.3.9.B+1
Standard Description: Describe the relationship between the availability or scarcity of resources and how that impacts cost

Key Concepts:
*None specified*

Learning Objectives:
* Analyze real-world scenarios to identify when demand is greater than supply.
* Interpret a situation comparing the number of items available with the number of orders to determine whether demand is high or low.
* Use a table showing the number of items available and the number of expected customers to determine which situation would most likely result in the highest price based on supply and demand.
* Use information about changes in supply to determine how the price of a product will most likely change.

Assessment Boundaries:
* Assessment is restricted to:
Real-world contexts involving supply (amount available) and demand (number of buyers).
Qualitative reasoning only (no multi-step arithmetic required).
Students determine how availability compared to demand affects price:
Fewer items than customers → price most likely higher.
More items than customers → price most likely lower.
Equal items and customers → price likely stable.
Whole numbers only (all number should be in numeric form and NEVER spelled out)
No percentages, ratios, or unit-rate calculations required.
Students interpret data rather than compute exact prices.
Items should be one of: Small Retail Items (Hats Sunglasses Scarves Backpacks Notebooks Keychains Bracelets), Craft / Handmade Items (Paintings Handmade cards Soap bars Candles Jewelry Knitted hats Tote bags), Farm / Outdoor Items (Flowers Plants Herb pots Seed packets Pumpkins Hay bales), Food & Produce (Oranges Bananas Watermelons Strawberries Corn Pumpkins Lemons Tomatoes)

Common Misconceptions:
* Students may assume the week with the largest numbers overall results in the highest price.
* Students may assume the week with the most customers automatically has the highest price without comparing supply.
* Students may confuse rows
* Students may select the week with the fewest pineapples without considering the number of customers.

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Staging
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9-Staging-2
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: Saving Money
Lesson Order: 157.0
Standard ID: TEKS.MATH.CONTENT.3.9.E+1
Standard Description: List reasons to save and explain the benefit of a savings plan, including for college

Key Concepts:
*None specified*

Learning Objectives:
* Distinguish saving behaviors from spending or donating behaviors by identifying actions that DON'T involve setting aside money for future use.
* Distinguish saving behaviors from spending or donating behaviors by identifying actions that involve setting aside money for future use.
* Evaluate stated purposes for saving money and determine which option does NOT logically relate to financial saving goals.
* Identify the most effective saving strategy to achieve a long-term financial goal (e.g., college) by selecting behaviors that involve regularly depositing money instead of spending it.
* Select two benefits of saving money

Assessment Boundaries:
* Assessment is restricted to:
Real-world contexts involving personal saving decisions.
Identifying benefits of saving money.
Qualitative reasoning only (no calculations).

Common Misconceptions:
* Students may believe saving increases interest on bills rather than earning interest.
* Students may choose options that describe financial harm rather than benefit.
* Students may misunderstand debt as something that grows automatically regardless of saving behavior.
* Students may think saving helps you spend money faster.

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/a
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fact Families and Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.A
Standard Description: Identify multiple facts that can be used to solve addition and subtraction word problems up to 1,000.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers using the Standard Algorithm
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.G
Standard Description: Solve mathematical problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fair-Share Division with Models
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.H
Standard Description: Find how many are in each group when a set of objects is split into equal groups (shared equally).

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multistep Word Problems Involving Multiplication and Division
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.K
Standard Description: Solve two step problems involving multiplication and division.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multi-step Word Problems: Solve or Represent with an Equation
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.B
Standard Description: Solve multi-step word problems by representing them with equations and using various mathematical operations and models

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Fractions of Congruent Shapes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.6.E
Standard Description: Identify equivalent fraction models

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: *None specified*
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.B
Standard Description: Identify equivalent place value models.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value Models
Lesson Order: 115.0
Standard ID: TEKS.MATH.CONTENT.3.2.B+1
Standard Description: Identify equivalent place value models.

Key Concepts:
*None specified*

Learning Objectives:
* Given three base-ten block models that each use a single type of block in varying quantities, determine which two models represent the same number by recognizing equivalences between place values.
* Given three base-ten block models that use different combinations of flats, rods, and units, determine which two models represent the same number by calculating the total value of each model.

Assessment Boundaries:
* Assessment is restricted to:
- All represented numbers must be whole numbers up to 200.
- Each question presents exactly 3 models as images with labels. Exactly 2 of the 3 models must represent the same number (there is always one correct pair).
- Number of ones in a model may go up to 50, so 50 in value.
- Number of tens in a model may go up to 20, so 200 in value.
- Number of hundreds in a model may go up to 2, so 200 in value.
- Note: LO1 and LO2 constraints are independent. When generating or validating for a specific LO, apply only the rules labeled for that LO.

Common Misconceptions:
* Students compare only the count of blocks between models without considering that different block types represent different place values (e.g., equating "20 ones" with "20 tens" because both involve the number 20, ignoring that 20 ones = 20 while 20 tens = 200).
* Students do not understand the fundamental values of base-ten blocks (hundred = 100, ten = 10, one = 1) and cannot correctly calculate the total value of any model, leading them to conclude that no models represent the same number.
* Students fail to recognize that different types and quantities of blocks can represent the same number through place value equivalence (e.g., 20 tens = 2 hundreds), incorrectly concluding that none of the models match even when a valid pair exists.
* Students misidentify the type of base-ten block in a model (e.g., counting ones as tens or interpreting ones blocks as tens blocks), leading to an incorrect total value for that model and a wrong pairing (e.g., treating Kareena's 2 ones as 2 tens to get 120 instead of 102, or reading Model X's 20 ones as 20 tens).

Difficulty Definitions:
* Easy:
  Given three base-ten block models that each use a single type of block in varying quantities, determine which two models represent the same number by recognizing equivalences between place values.
* Medium:
  Given three base-ten block models that use different combinations of flats, rods, and units, determine which two models represent the same number by calculating the total value of each model.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Ordering Numbers in the Thousands
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.D
Standard Description: Order a list of numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.2+1
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Ordering Numbers in the Thousands
Lesson Order: 131.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+4
Standard Description: Order a list of numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Determine whether numbers fall within a given interval by comparing each number to the interval's endpoints.
* Identify whether a list of numbers is correctly ordered in ascending or descending order by comparing place values.
* Order numbers in ascending or descending order and determine which statement about their relative positions is true.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers from 1,000 to 100,000
- Standard notation with comma separators (e.g., 5,746)
- No decimals, fractions, or negative numbers
- No expanded form, word form, or scientific notation
- Ordering and range identification only; no comparison symbols (>, <, or =)

Common Misconceptions:
* Assumes numbers with the same leading digit occupy the same place value
* Compares digits from the rightmost place instead of the leftmost place value.
* Includes endpoint values when checking if numbers fall within a range.
* Reverses ordering direction, sorting least to greatest instead of greatest to least.

Difficulty Definitions:
* Easy:
  Numbers have clearly different digit counts (e.g., a mix of 4-digit and 5-digit numbers).
Ordering can be determined primarily by comparing the number of digits.
At most 2 numbers share the same digit count.
* Medium:
  Most or all numbers share the same digit count.
Numbers differ in the leading one or two digits, requiring place-value comparison from the leftmost digit.
Differences are apparent at the thousands or ten-thousands place.
* Hard:
  All numbers share the same digit count and the same leading digit(s).
Numbers are close in value, requiring comparison across 3 or more place-value positions.
Values near boundaries require precise digit-by-digit comparison.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with the Same Numerator or Denominator: Word Problems
Lesson Order: 145.0
Standard ID: TEKS.MATH.CONTENT.3.3+1
Standard Description: Solve a real world problem involving comparing fractions with the same numerator or the same denominator.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem involving two fractions with the same numerator or the same denominator, determine the true comparative statement

Assessment Boundaries:
* Assessment must be restricted to:

- MUST assess the student's ability to compare two fractions in a real-world word problem.
- MUST use two fractions that have EITHER the same numerator OR the same denominator.
- MUST NOT use fractions where both the numerators and denominators are different.
- Allowed Denominators: Up to 9 (e.g., 2, 3, 4, 5, 6, 7, 8, 9).
- Response Type: MCQ with exactly 4 options.
- Option Format: Sentences describing the comparison using words (e.g., "is greater than", "is equal to").
- Distractors must be around common misconceptions

Common Misconceptions:
* Believes larger denominator means larger fraction when numerators are the same.
* Claims insufficient information exists to compare fractions with same numerator or denominator.
* Concludes fractions are equal because they share the same numerator or denominator.
* Reverses the inequality relationship when comparing fractions with same denominator or numerator.

Difficulty Definitions:
* Easy:
  All at one level.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.3
Cluster Name: The student applies mathematical process standards to represent and explain fractional units.
Lesson Name: Comparing Fractions with Number Lines
Lesson Order: 117.0
Standard ID: TEKS.MATH.CONTENT.3.3.H+1
Standard Description: Use number lines to compare fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the fraction modeled by each number line (from the jumps and intervals) and select the **true comparison statement**.
* Given two number line models with labelled fractions on the number lines, compare the two fractions (provided in the prompt) and choose the correct symbol **( <,>,=)**.

Assessment Boundaries:
* Assessment is restricted to:
- MUST compare **two fractions** that have the **same numerator OR the same denominator**.
- MUST use **number line models from 0 to 1** (one whole).
- Fractions on the number line MUST be represented using **jumps (arcs)** starting at 0.
- The number line MUST be partitioned into **equal intervals**.
- Comparisons MUST use only **<, >, =**.
- No fraction computation beyond interpreting the model (no adding/subtracting, no converting to decimals, no cross-multiplying).
- Leave fractions **unsimplified**

Common Misconceptions:
* Assumes any single interior tick splits 0–1 evenly, even when off-center.
* Confuses the point’s position with nearby tick marks instead of equal partitions.
* Counts tick marks rather than equal segments to determine the fraction value.

Difficulty Definitions:
* Easy:
  Show two number lines. **State the fraction each number line represents (unsimplified)** and ask students to choose the symbol **(<, >, =)**.
MCQ with three options.
* Medium:
  Two number lines model two fractions with **jumps** from 0 to 1. Ask: **“Which comparison of these fractions is true?”** (4-option MCQ).
MCQ with four options.
Fractios are not called out should be inferred from the stimulus.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fact Families and Word Problems
Lesson Order: 119.0
Standard ID: TEKS.MATH.CONTENT.3.4.A+1
Standard Description: Identify multiple facts that can be used to solve addition and subtraction word problems up to 1,000.

Key Concepts:
*None specified*

Learning Objectives:
* Find missing addition and subtraction facts from the same fact family in word problems when given one fact.
* Find missing addition and subtraction facts from the same fact family in word problems.
* Find the statement which is or is NOT a suitable fact to model an addition and subtraction word problem.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no remainders, fractions, decimals, or negative numbers
- Addition and subtraction word problems with numbers up to 1,000
- One-step word problems involving a part-whole or start-change-result structure
- Problems involve finding an unknown part (not the whole)
- Students identify equivalent equations from the same fact family
- Context is mandatory; items must be embedded in word problems or real-world scenarios
- No visual models required; problems are text-based with equation answer choices
- Multiselect questions require selecting exactly two correct equations
- Multiple choice questions asking which equation can NOT be used must have NOT capitalized
- Easy questions provide one equation and ask for two other equivalent equations; all numbers are 2-digit
- Medium questions do not provide an initial equation; all numbers are 2-digit
- Hard questions do not provide an initial equation; equations include one 3-digit number
- Hard questions may also be MCQ format asking which equation can NOT be used
- Distractors include equations that reverse the relationship (e.g., part − [ ] = whole) or add the two known quantities
- Never show negative numbers

Common Misconceptions:
* Students add the two given quantities (part and whole) instead of finding the unknown part, selecting the equation that sums those two numbers or failing to identify it as the one that can NOT be used.
* Students assume the situation can only be represented with subtraction and reject or overlook the valid addition equation (part + unknown = whole), treating "sold" or "gave away" as requiring subtraction only.
* Students confuse the roles of whole, part left, and unknown in the part-whole situation, treating the sum of part and whole as the answer or misplacing quantities in equations, leading to incorrect selection of which equation can NOT be used.
* Students reverse the task by selecting an equation that correctly fits the situation instead of identifying the single equation that does NOT fit, answering which equation can be used rather than which can NOT be used.

Difficulty Definitions:
* Easy:
  MSQ only. Word problem, problem gives them one equation and asks which other equations can be used and MS the other equations in the fact family.
Numbers are all 2 digits
* Medium:
  MCQ: Word problem. Numbers are all 2 digits. Select ANY member of the fact family
* Hard:
  MCQ: Word problem. Equations include one three digit number (and not both). Select ANY member of the fact family.
MCQ: Word problem. Question doesn’t give the first equation and it includes problems with NOT - numbers can be all two digits or one can be a three digit number. The NOT must be capitalized.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Fair-Share Division with Models
Lesson Order: 102.0
Standard ID: TEKS.MATH.CONTENT.3.4.H+1
Standard Description: Find how many are in each group when a set of objects is split into equal groups (shared equally).

Key Concepts:
*None specified*

Learning Objectives:
* Divide a given quantity into a known number of groups to find the size of each group where the visual shows the given quantity.
* Divide a given quantity into a known number of groups to find the size of each group where the visual shows the number of groups.

Assessment Boundaries:
* Assessment is restricted to:
- Whole number dividend ≤ 100
- Single-digit divisor 2–9
- NO remainders, fractions, decimals, or mixed numbers
- NO variables / algebraic notation
- Must be equal-sharing/partitioning (partitive division), NOT measurement division or repeated subtraction
- Must ask for “how many in EACH group”, NOT “how many groups”
- Wrong answers must be grounded in one or more misconceptions
- The explanation for each wrong answer must be coherent and correct

Common Misconceptions:
* Students add the total and the number of groups instead of dividing
* Students interpret “equal groups” as multiplication and multiply the total by the number of groups
* Students solve for “how many groups” instead of “how many are in each group"
* Students subtract the numbers instead of dividing

Difficulty Definitions:
* Easy:
  Dividends up to 25 with divisors 2-5 (e.g., 12 ÷ 3, 16 ÷ 4, 8 ÷ 2)
* Medium:
  Dividends 21-100 with divisors 2-9 (e.g., 36 ÷ 4, 42 ÷ 6, 35 ÷ 5)
* Hard:
  Dividends 51-100 with divisors 2-9 yeilding quotients between 11 and 15 (e.g., 77 ÷ 7, 84 ÷ 6, 65 ÷ 5)

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.4+6
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multistep Word Problems Involving Multiplication and Division
Lesson Order: 123.0
Standard ID: TEKS.MATH.CONTENT.3.4.K+1
Standard Description: Solve two step problems involving multiplication and division.

Key Concepts:
*None specified*

Learning Objectives:
* Students will solve real-world, 2-step problems (including one multiplication or division step, with results within 100) where the numerical values appear in the text in the same order they are used to calculate the solution.

Assessment Boundaries:
* Assessment is restricted to:

Operational Limits: Problems must require exactly two steps (Addition, Subtraction, Multiplication, or Division), and include at least one multiplication or division operation.

Numerical Limits: All products and dividends must be within 100.

Placeholders: No use of letter variables (e.g., x, y, n); unknowns must be represented by a box [ ], question mark (?), or blank line (__).

Context: Real-world scenarios are required for all items.

Exclusions: No remainders; all division must result in a whole number. No fractions, decimals, or money involving cents (whole dollar amounts only).

Logic: Problems must require two steps to reach the final solution.

Common Misconceptions:
* Confuses the total amount with the group size when interpreting division word problems.
* Ignores the necessary grouping and performs operations in a strict left-to-right sequence.
* Misapplies addition or subtraction instead of multiplication or division due to key words.
* Performs only the first step of the problem and ignores the second requirement.

Difficulty Definitions:
* Easy:
  All easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Using Strip Diagrams to Solve Two-Step Word Problems
Lesson Order: 122.0
Standard ID: TEKS.MATH.CONTENT.3.5.A+1
Standard Description: Use strip diagrams to solve two step word problems.

Key Concepts:
*None specified*

Learning Objectives:
* (LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
* (LO2) Given a two-step word problem involving addition where one quantity is described relative to another, identify the strip diagram that correctly represents the relationship between the parts to find the total.
* (LO3) Given a word problem involving equal groups, identify the strip diagram that correctly represents the groups and their sizes.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world contexts only.
- All values must be whole numbers up to 1,000.
- The unknown value must be represented by a "?" in the model.
- No use of variables like x or n; use "?" for the unknown.
- Strip diagram (bar model) must clearly show the whole as a single bar and the parts as smaller segments that combine to equal the whole.

Common Misconceptions:
* Students confuse group size with the number of groups in equal-group representations, using the wrong number for cell values or the wrong number of cells per strip (e.g., showing cells of 3 instead of 10, or showing 1 cell per strip instead of 3).
* Students fail to compute a derived quantity from a relational statement — when one value is described as "more than" another, they use only the explicitly stated numbers without computing the actual value (e.g., modeling 339 + 75 = ? instead of 339 + (339 + 75) = ?).
* Students swap the total and a part in the strip diagram, placing a part value as the whole (top row) and the actual total as one of the parts (e.g., putting 196 as the whole instead of 294).
* Students treat all given numbers as addends, placing every number including the total into the parts row so the unknown becomes the grand total (e.g., showing 294 + 196 + 49 = ? instead of 294 = 196 + 49 + ?).

Difficulty Definitions:
* Easy:
  1 and 2 digit numbers only
LO3 and LO1 only
(LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
(LO3) Given a word problem involving equal groups, identify the strip diagram that correctly represents the groups and their sizes.
* Medium:
  2 and 3 digit numbers only
LO1 only
(LO1) Given a two-step word problem involving subtraction, identify the strip diagram that correctly represents the relationship between the total and its parts to find an unknown part.
* Hard:
  2 and 3 digit numbers only
LO2 only
(LO2) Given a two-step word problem involving addition where one quantity is described relative to another, identify the strip diagram that correctly represents the relationship between the parts to find the total.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Model Multiplication and Division Word Problems
Lesson Order: 120.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+2
Standard Description: Identify arrays that can be used to solve one step multiplication and division word problems.

Key Concepts:
*None specified*

Learning Objectives:
* Given a one-step division word problem, identify the array that models the situation.
* Given a one-step division word problem, identify the group model that matches the situation.
* Given a one-step multiplication word problem, identify the array that models the situation.

Assessment Boundaries:
* Assessment is restricted to:
- One-step multiplication and division word problems within 100
- Products and dividends within the 10 × 10 multiplication table
- Arrays as visual models only (no strip diagrams or equations required)
- Whole numbers only; no remainders, fractions, or decimals
- Real-world contexts involving equal groups, rows, or repeated sets
- No use of variables (e.g., a, n, x); problems present visual array choices
- Students select the correct array from multiple choice options; they do not construct arrays
- No multi-step problems or problems requiring both multiplication and division
- Context is madatory; items must be embedded in word problems or real-world scenarios.
- Visual support is mandatory.
- The correct answer will always be an integer multiplication or an even division, but distractor options are not required to depict even divisions or full multiplications
- Due to the cummutative property of multiplication, distractors may NOT use inverted rows and columns

Common Misconceptions:
* Students add the two quantities in the word problem instead of multiplying, selecting an array that represents the sum rather than the product.
* Students confuse the roles of the quantities in the word problem (number of groups versus number in each group), selecting an array where only one dimension matches or where the dimensions are misinterpreted.
* Students perform incorrect multi-step reasoning by first adding the quantities and then applying another operation, leading to selection of an array that does not represent the original word problem.
* Students select an array with the correct number of rows but fail to verify that the number of objects in each row also matches the word problem, only partially modeling the multiplication or division situation.

Difficulty Definitions:
* Easy:
  Both factors are 5 or less (products up to 25)
Groups and items per group must be readily interpretable from the context
* Medium:
  At least one factor is between 6 and 10 (products up to 100)
Groups and items per group must be readily interpretable from the context
* Hard:
  Up to one factor is between 6 and 10 (products up to 100)
Multiplication or division problems
Using grouped models, not array models
Groups and items per group must be readily interpretable from the context

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.5+2
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Modeling Two-Step Word Problems
Lesson Order: 121.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+3
Standard Description: Represent two step word problems with models.

Key Concepts:
*None specified*

Learning Objectives:
* Connect visual array and equal-group models to two-step number sentences involving multiplication and division

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no remainders, fractions, decimals, or mixed numbers
- Products and dividends within the 10 × 10 multiplication table
- Two-step problems involving only multiplication and division operations. The first operation is division. The second is multiplication or division
- Allowed visual models are arrays or equal groups of an abstract representation of the objects being discussed.
- Exact representations of the visual objects are not allowed; abstract representations only.
- Problems may include: two multiplication steps, two division steps, multiplication then division, or division then multiplication
- Context is madatory; items must be embedded in word problems or real-world scenarios.
- Due to the cummutative property of multiplication, distractors may NOT use inverted rows and columns

Mapping of stimulus_specification to image (this is done deterministically and has been validated):
The first operation is division, and the first_values represent [dividend, divisor]. The students will see <divisor> groups of <quotient> objects. The expected first equation is "groups of (dividend ÷ divisor)" or "(divided ÷ quotient) groups/equal groups"
If the second operation is multiplication, then the second_values represent [number of groups, groups of how many] of crossed-out objects, where the "groups of how many" should be the quotient from the first operation. The students will see these groups crossed out. The expected correct first equation is (number of groups x groups of how many).
If the second operation is division, then the second_values represent [dividend, divisor] where the dividend is the quotient of the first operation. The students will see each group divided into <divisor> smaller groups. The expected correct second equation is "groups of (dividend ÷ divisor)" or "(divided ÷ quotient) groups/equal groups". Alternatively, the second operation is mentioned as a single further division of the first grouping, e.g. "each bag is divided into 2 bags of 3"

Common Misconceptions:
* Students misinterpret the distribution/partitioning shown in the model as subtraction instead of division. When they see groups being removed or separated (such as bags crossed out), they interpret it as subtraction rather than understanding it represents division or equal sharing, leading to answers that mix operations incorrectly.
* Students reverse which operation comes first by reading the visual model in the wrong sequence. They might start with the final arrangement shown and work backward, or they identify the operations correctly but place them in reverse order in the number sentence, leading to expressions like "divided first, then multiplied" when the model shows "multiplied first, then divided."
* Students use the number of items in each group to set up the distribution instead of using the number of groups.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  Simple equal-groups or array contexts
Numbers up to 10 x 10
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Attributes of 2D Shapes
Lesson Order: 124.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+2
Standard Description: Classify and sort two-dimensional figures based on attributes.

Key Concepts:
*None specified*

Learning Objectives:
* (LO1) Given a table of groups defined by geometric attributes, select the true statement about which shape(s) belong to which group(s).
* (LO2) Select the table (from image options showing shapes and attributes) that correctly shows which attributes apply to each shape.
* (LO3) Given a set of shapes, count how many shapes have a specific attribute.
* (LO4) Given a set of shapes, identify which attribute or statement is true about ALL of them.

Assessment Boundaries:
* Assessment is restricted to:
- 2D shapes only.
- Attributes must use formal geometric language: polygon, quadrilateral, vertices, sides, congruent sides, parallel sides, etc.
- Groups are defined by attributes (not by shape names).
- A shape may belong to multiple groups if it satisfies all attributes of those groups.
- May include non-polygon figures (curves) for students to identify and exclude.
- No measurement or numerical values for side lengths.
- Shapes referenced by name in answer options: triangle, square, rectangle, pentagon, hexagon, circle, parallelogram only.
- Don't say "example image" in worked examples; they are not example images, they are actual images to refer.
- For worked examples with image, do not include any extra lines than the article worked examples. Do not include any conversational lines and do not include any additional equations.

Common Misconceptions:
* Students confuse "quadrilateral" (exactly 4 sides) with "polygon" (3+ sides), classifying triangles as quadrilaterals.
* Students confuse two-dimensional polygons with three-dimensional prisms.
* Students do not consider all attributes or all shapes when evaluating a statement, checking only some figures or some criteria before selecting an answer.
* Students do not recognize that a polygon must be a closed figure with all straight sides (line segments), incorrectly including curved figures or excluding valid polygons.

Difficulty Definitions:
* Easy:
  (LO3) Given a set of shapes, count how many shapes have a specific attribute.
* Medium:
  (LO2) Select the table (from image options showing shapes and attributes) that correctly shows which attributes apply to each shape.
(LO4) Given a set of shapes, identify which attribute or statement is true about ALL of them.
* Hard:
  (LO1) Given a table of groups defined by geometric attributes, select the true statement about which shape(s) belong to which group(s).

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Drawing Unit Squares to Find Area
Lesson Order: 125.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+1
Standard Description: Solve area problems using models with one row and one column of unit squares.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the area of a tiled rectangular region by using the number of tiles along the length and width.
* Find the area of a rectangle by extending a partially shown array of unit squares.
* Find the area of a rectangle by using unit markers along two sides to determine its length and width.
* Identify which rectangles match a given area by calculating the area of each rectangle.
* Select rectangles that satisfy an area requirement by inferring dimensions from unit-square placement and comparing areas.

Assessment Boundaries:
* Assessment is restricted to:
Whole-number side lengths inferred by counting unit squares; allowable side lengths 1–10 units.
Whole-number areas found by multiplication; allowable areas 1–100 square units.
Must use multiplication conceptually as (number of rows) × (number of unit squares in each row); addition/counting is allowed only to determine dimensions, not as the main method for area.
No fractional side lengths, no fractional unit squares, no missing-unit ambiguity (unit square size must be explicitly defined), no perimeter-only questions.

Common Misconceptions:
* Assumes the missing interior is not included, counting only placed unit squares.
* Confuses area with perimeter by adding side lengths or counting edge squares.
* Misapplies rows × squares-per-row by multiplying incorrect row/column counts.
* Treats the shown border unit squares as the total area.

Difficulty Definitions:
* Easy:
  Find the area of a rectangle by extending a partially shown array of unit squares.
* Medium:
  Determine the area of a tiled rectangular region by using the number of tiles along the length and width.
Find the area of a rectangle by using unit markers along two sides to determine its length and width.
* Hard:
  Identify which rectangles match a given area by calculating the area of each rectangle.
Select rectangles that satisfy an area requirement by inferring dimensions from unit-square placement and comparing areas.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+1
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Word Problems Involving Measuring Area with Unit Squares
Lesson Order: 126.0
Standard ID: TEKS.MATH.CONTENT.3.6.C+2
Standard Description: Solve word problems to find the area of rectangular surfaces in real-world contexts using a provided grid model.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world word problem and a visual of a rectangular surface partitioned into unit squares, determine the total area by identifying the number of rows and the number of unit squares in each row from the provided information.

Assessment Boundaries:
* Assessment is restricted to:

Rectangles and squares only; no irregular or composite shapes.

Word problems must involve a real-world context of covering a surface (e.g., tiling a floor, laying a rug, or paving a patio).

A visual MUST be provided showing a rectangle fully partitioned into a grid or clearly defined rows and columns of unit squares.

Easy problems must use plain/empty grids; Medium problems must use grids with internal designs (e.g., tile patterns, brick textures, or smiley faces).

The number of rows and the number of unit squares in each row may be provided in the text or must be identified by the student using the visual.

Factors (side lengths) must be whole numbers.

Side lengths should make sense in real world. For example you can't say that a chair is of 100 feet length.

Total area (product) is limited to a maximum of 50 square units.

All units must be spelled out (e.g., "square feet," "square inches").

No abbreviations (e.g., "cm," "sq cm") or exponential notation (e.g., "m^2").

No use of variables like x or n. Questions should end with a standard question mark or a blank line for the answer.

Single-step problems only.

Every question stem must follow this exact 3-step sequence and follow the 4th rule:
1) Context: Introduce a character and a real-world object (e.g., "Sam is making a tiled tabletop").
2) The Model (Bridge): Explicitly state: "The [object] is modeled by this rectangle."
3) The Question: "What is the area of the [object] in square [units]?"
4) Do not state dimensions in the text; students must identify rows, columns, and units (e.g., "1 foot") from the image labels.

Common Misconceptions:
* Confuses area with perimeter by adding the number of rows and the number of unit squares in each row.
* Inaccurately identifies dimensions by miscounting the number of unit squares in a row or column within the visual model.
* Miscalculates the total surface by adding the lengths of all four sides of the rectangle.
* Mistakes the operation by adding the dimensions together instead of using multiplication to find the product.

Difficulty Definitions:
* Easy:
  Solve area word problems using a plain unit square grid for totals up to 25 square units.
* Medium:
  Solve area word problems using a grid with internal designs/patterns for totals up to 50 square units.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.6+6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Fractions of Congruent Shapes
Lesson Order: 118.0
Standard ID: TEKS.MATH.CONTENT.3.6.E+1
Standard Description: Identify equivalent fraction models

Key Concepts:
*None specified*

Learning Objectives:
* Given a unit fraction **1/n**, select the option where **two congruent wholes** each show **exactly 1/n** shaded (one equal share shaded).

Assessment Boundaries:
* Assessment is restricted to:
- 2-D figures only.
- If figures are said to be **congruent**, they MUST be **same size and same shape**.
- Unit fractions only.
- Within any figure, partitions MUST be **equal area** (shares may differ in shape across figures).
- **MCQ: exactly 4 options, exactly 1 best answer.**
- No measurement tools, coordinate geometry, or numeric area computation.

Common Misconceptions:
* Assumes figures show equivalent fractions only when partitions have identical shapes.
* Compares visual appearance of shaded regions instead of equal-area relationships between parts.
* Confuses number of shaded parts with fractional amount, ignoring total partition count.
* Ignores that congruent wholes ensure same-size parts even when partition shapes differ.

Difficulty Definitions:
* Easy:
  Unit fraction is **given** (1/n).
Pick the pair where both congruent wholes show **exactly 1/n** shaded.
Distractors: wrong denominator; shading not exactly one share; unequal-share partition.
* Medium:
  Unit fraction **not given**; infer from model.
“CAN/CANNOT” format.
Includes at least one option with same-looking part count but **unequal areas**.
* Hard:
  Different partition styles across congruent wholes (not limited to triangles/rectangles).
Requires reasoning: congruent whole split into **k equal-area parts ⇒ each part = 1/k**, regardless of part shape.
Distractors target “looks bigger” and wrong fraction claims.
The image shows only plain congruent outlines (no partition lines drawn)
Partition details are described in the question stem text only
Answer options are text statements, not images

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Representing Fractions with Jumps on the Number Line
Lesson Order: 116.0
Standard ID: TEKS.MATH.CONTENT.3.7.A+1
Standard Description: Match number line models of jumps with fractions that they represent.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the fraction represented by a point on a number line by comparing its distance from 0 to the length of the whole interval

Assessment Boundaries:
* * Use proper fractions ( \frac{a}{b} ) where integers (a,b) satisfy 1 ≤ a < b and b is 2,4 or 8.
* All number lines represent exactly one whole unit interval from 0 to 1 (inclusive).
* If interior tick marks are present, they must create equal-length partitions of the 0–1 interval (i.e., all segments between consecutive ticks/endpoints are equal).
* The representation uses a single jump that starts at 0 and ends at the labeled point (no multiple sequential jumps).
* Choose a unit randomly from one of these: centimeter, meter, kilometer, feet, inches only

Common Misconceptions:
* -
* Assumes any single interior tick splits 0–1 evenly, even when off-center.
* Confuses the point’s position with nearby tick marks instead of equal partitions.
* Counts tick marks rather than equal segments to determine the fraction value.

Difficulty Definitions:
* Easy:
  All questions are easy.
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Perimeter Problems Involving Complex Shapes
Lesson Order: 127.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+1
Standard Description: Solve perimeter problems involving complex shapes.

Key Concepts:
*None specified*

Learning Objectives:
* Use structure cues to infer **exactly four** unlabeled exterior side lengths, then compute the **perimeter** by adding all exterior side lengths and enter the answer as a whole number.

Assessment Boundaries:
* Assessment is restricted to:
- Items MUST use a **composite figure made from at least TWO/THREE polygons** (joined/attached).
- Items MUST ask for the **perimeter of the composite outline**.
- **Text Entry only**: student enters **one whole number** as the perimeter.
- Perimeter MUST be the **outside boundary only**:
  - Missing side lengths MUST be **determined by structure cues**.
- Side lengths MUST be **whole numbers** and the stem should have units in full form (abbreviations not allowed).
- The perimeter value MUST be **uniquely determined** from the diagram + stated structure (no ambiguity).
- Stems MUST have real-world contexts and include the unit in the question (e.g., "in inches/feet").

Common Misconceptions:
* Adds area and perimeter or confuses perimeter with counting total sides.
* Assumes missing side lengths without using congruence or shape properties given.
* Counts all visible side lengths including those inside the composite figure.
* Includes interior shared edges when counting perimeter instead of only outside boundary.

Difficulty Definitions:
* Easy:
  0** or **1** exterior side is missing.
One direct inference using a single structure cue.
Fewer perimeter segments; boundary is straightforward.
Must not use the term congruence/congruent. Use same/ equal instead.
* Medium:
  Exactly **2** exterior sides are missing.
Two inferences; more addends.
May use the term congruent.
* Hard:
  3-4 exterior sides are missing.
MUST use the term congruent.
Multiple correspondences across the figure (often includes two congruent polygons plus another polygon).
Many addends; common pitfall is missing a side or stopping early on the outline.

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Finding Errors in Perimeter Problems
Lesson Order: 128.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+2
Standard Description: Identify the error in a given worked perimeter problem.

Key Concepts:
*None specified*

Learning Objectives:
* Select the single statement that correctly describes the mistake (or correctly states there is no mistake). for a table with one or two shapes
* Select the single statement that correctly describes the mistake (or correctly states there is no mistake). for a table with three shapes

Assessment Boundaries:
* Assessment is restricted to:                                                                                     - Items MUST show a **table** with :

  * **Figure** name (e.g., square, triangle, rectangle),
  * **Side Lengths** listed (same unit),
  * A stated **Perimeter** value.
- Prompt MUST ask which **mistake, if any**, was made (STAAR tone), and answers MUST be **statements**.
- Students MUST determine the correct choice by using the definition: **perimeter = sum of all side lengths**.
- **MCQ MUST have exactly 4 options** and **exactly 1 correct**.
- Table MUST be designed so that:

  * **Either** exactly **one** figure’s perimeter is incorrect,
  * **Or** all perimeters are correct (so “no mistake” can be the correct answer, only when intended).
- Numbers MUST be **whole numbers**; one consistent unit (yards/feet/inches); **no conversions**; no decimals/fractions.
- Options MUST be STAAR-parallel statements:

  * At least **one** option states the **correct corrected perimeter** for the figure with the error (e.g., “The perimeter of the rectangle should be 24 yards.”).
  * The other options MUST include plausible incorrect statements such as:

    * naming the wrong figure and giving an incorrect corrected perimeter,
    * “no mistake” when there is a mistake (or vice versa when intended).
- Do NOT assess area or formulas like (2l+2w); no multi-step beyond adding the given side lengths.
- Exactly one best answer must be uniquely determined from the table.

Common Misconceptions:
* Assumes opposite sides are equal for all figures, not just rectangles
* Confuses perimeter with area by multiplying two dimensions instead of adding all sides
* Multiplies the number of sides by one side length instead of summing all side lengths
* Omits one or more sides when adding to find the total perimeter

Difficulty Definitions:
* Easy:
  Table in the stem includes one or two row only.
* Medium:
  Table in the stem includes **three rows**.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.7-Staging
Cluster Name: The student applies mathematical process standards to select appropriate units, strategies, and tools to solve problems involving customary and metric measurement.
Lesson Name: Using Rulers to Solve Perimeter Problems
Lesson Order: 139.0
Standard ID: TEKS.MATH.CONTENT.3.7.B+3
Standard Description: Use a ruler to measure side lengths to find the perimeter of a given shape.

Key Concepts:
*None specified*

Learning Objectives:
* Use a ruler to measure side lengths and find the perimeter of a given object

Assessment Boundaries:
* Assessment is restricted to: 
  • Must have side lengths less than or equal to 20 cm / 8 inch
  • The sizes of the real world objects should be realistic
  • Must require measuring length to nearest centimeter/inch and identifying the perimeter in centimeters/inches.
  • Triangles and other polygons are not allowed except square and rectangle
  • Unit labels should be consistent throughout the problem
  • All answer options must be rooted in one or more misconceptions

Common Misconceptions:
* Students add the length and width only one time instead of adding all four sides around the shape. Distractor formula: L + W for a rectangle, or s + s for a square.
* Students forget to include one side length when adding to find the perimeter. Distractor formula: L + L + W (missing one width) or L + W + W (missing one length) for a rectangle, or s + s + s for a square.
* Students misread the ruler by starting at 1 instead of 0, so each side they measure is 1 unit longer than it really is. Distractor formula: 2(L + 1) + 2(W + 1) for a rectangle, or 4(s + 1) for a square. This always adds 4 to the correct perimeter.
* Students multiply the side lengths to find the area instead of adding them to find the perimeter. Distractor formula: L × W for a rectangle, or s × s for a square.

Difficulty Definitions:
* Easy:
  ALL side lengths ≤ 8 cm (or ≤ 3 inch). No side exceeds 8 cm.
* Medium:
  At least one side ≥ 9 cm AND all sides ≤ 15 cm (or at least one ≥ 4 inch AND all ≤ 6 inch).
* Hard:
  At least one side ≥ 16 cm AND all sides ≤ 20 cm (or at least one ≥ 7 inch AND all ≤ 8 inch).

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Creating Dot Plots
Lesson Order: 129.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+1
Standard Description: Create dot plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of data values, identify the dot plot that correctly represents the frequency of each value in the data set.
* Given images of coins, identify the dot plot that correctly represents the value (in cents) of each coin.

Assessment Boundaries:
* Assessment is restricted to:
- Values must be ≤ 50.
- Only whole number values.
- Frequency of values (in question stem and answer choices) always must be ≤ 8.
- Question stem should have real world scenarios only.
- If the question stem lists values, the values must be an unordered list.
- For questions that do not show an image of coins, the range of values must be at least 7 and at most 10 for easy questions and at least 10 and at most 12 for medium questions.

Common Misconceptions:
* Students count the total number of items and place that many dots across arbitrary positions, disregarding the proper values and the proper count for each value.
* Students fail to place additional dots when a value appears multiple times in the data set, resulting in only one dot per unique value rather than one dot per occurrence.
* Students misread the number line scale and place dots at incorrect positions, especially when values fall on unlabeled tick marks (e.g., placing dots at 30 instead of 25).
* Students place dots for values that do not appear in the data set, add extra dots, or omit dots for values that do appear, resulting in an incorrect total number of dots.

Difficulty Definitions:
* Easy:
  5 to 10 (both inclusive) values - straightforward (no coins)
range of values at least 7 and at most 10
* Medium:
  10 to 18 (both inclusive) values (no coins)
range of values at least 10 and at most 12
* Hard:
  10 to 12 (both inclusive) values and use coins

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.8
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data.
Lesson Name: Dot Plots with Tally Marks
Lesson Order: 132.0
Standard ID: TEKS.MATH.CONTENT.3.8.A+2
Standard Description: Given a frequency table that uses tally marks, identify the matching dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Convert tally-mark frequency data into a dot plot by placing the correct number of dots above each data value.

Assessment Boundaries:
* Assessment is restricted to:
* Questions must assess matching/representing frequency data from a tally-mark table to a dot plot.
* Exactly 1 categorical/measurement variable with exactly 5 distinct x-values (as in the example’s 5 columns of distances).
* X-values (Numbers): Allowed x-values must be whole numbers and/or half units (values ending in .0 or .5).
* X-values (Range): a must be a whole number from 0 to 10 (so x-values stay within 0 to 12).
* Frequencies (Counts): Each category frequency must be a whole number from 0 to 10.
* Total Observations: Total frequency (sum across the 5 x-values) must be between 10 and 25 inclusive and may be stated explicitly in the stem.

Common Misconceptions:
* Confuses each tally mark with one full group of five.
* Ignores half-unit x-values, placing those dots on neighboring whole numbers.
* Miscounts tally groups, treating the diagonal slash as an extra item.
* Treats each x-value as one dot, regardless of the tally frequency.

Difficulty Definitions:
* Easy:
  All the category are whole numbers.
* Medium:
  Category include fractions with halves like 1 1/2
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: The Relationship Between Work and Income
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.9.A
Standard Description: Given a problem, explain the connection between human capital/labor and income.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade Supporting Lessons
Unit ID: Math Grade 3 Unit 14
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.3.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security
Lesson Name: The Relationship Between Work and Income
Lesson Order: 130.0
Standard ID: TEKS.MATH.CONTENT.3.9.A+1
Standard Description: Given a problem, explain the connection between human capital/labor and income.

Key Concepts:
*None specified*

Learning Objectives:
* Distinguish between factors that affect income from labor and factors that are unrelated to income.
* Identify situations that involve both labor (work performed) and income (money earned) versus situations that involve only spending, volunteering, or personal expenses.
* Identify the most reasonable statement about how a person’s earnings change when they are paid by the hour and work more or fewer hours.
* Identify which factors are relevant to determining how much income a person earns from work.

Assessment Boundaries:
* Assessment is restricted to:
Real-world contexts involving labor (work performed) and income (money earned)
Situations where income is determined by work-related factors, such as:
Hours worked
Experience, skills, or education
Questions that require students to:
Identify which factors do affect how much a person is paid for work, or
Identify which factors do not affect pay (e.g., personal or household characteristics)
Scenarios may involve:
Hourly work with a constant rate (explicitly stated or implied), or
General descriptions of employment where pay depends on work-related qualifications
Income may change only due to work-related causes, not personal spending, family size, or saving habits
Exactly one causal relationship is assessed per question:
More or higher-quality work-related factors → more income
Fewer or unrelated factors → no increase in income
No calculations, equations, or multi-step reasoning
Students reason qualitatively about cause-and-effect relationships between labor and income

Common Misconceptions:
* Student assumes pay changes randomly rather than depending on hours worked
* Student believes working fewer hours can result in earning more money
* Student confuses income earned with effort given (e.g., more hours means less labor)
* Student ignores the idea of a constant hourly rate

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value & Number Comparison (within 10,000s/100,000s)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.C
Standard Description: Analyze and manipulate numbers up to 100,000 through place value understanding, number comparison, and conversion between different numerical forms

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Number Line Estimation:  Rounding to Nearest Thousand
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.2.C
Standard Description: Use a number line to accurately round numbers to the nearest thousand by interpreting points, identifying benchmarks, and determining proximity using midpoints

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Rounding on the Number Line: Word Problems
Lesson Order: 109.0
Standard ID: TEKS.MATH.CONTENT.3.2.C+1
Standard Description: Use a number line to accurately round numbers to the nearest ten, hundred or thousand by interpreting points, identifying benchmarks, and determining proximity using midpoints

Key Concepts:
*None specified*

Learning Objectives:
* Identify the point on a number line that best represents a given approximate value in real-world situations.
* Interpret a point’s position on a number line to determine which benchmark value it is closest to and describe the approximate amount using real-world contexts.
* Use a number line to round numbers to the nearest ten, hundred, or thousand by identifying benchmark numbers and the midpoint.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only, from 0 to 20,000.
- No negative numbers, fractions, or decimals.
- No questions about Point A, Point B, etc. all must be real-world context
- All rounding is to the nearest ten or hundred
- Focus is solely on interpreting and estimating; no calculation, addition, or subtraction required.
- Real-world contexts (e.g., money, population, distance)
- Question stem must introduce context (e.g. "The point on the number line represents the amount needed to build a garage \n What statement best describes the amount needed to build a garage?" or "The points on the number line show the number of miles four track team members
ran during the week. \n Which track member ran about 40 miles?")

Common Misconceptions:
* Students assume rounding always means go up.
* Students focus on absolute size instead of relative closeness.
* Students ignore scale and spacing on the number line.
* Students misinterpret the midpoint on a number line.

Difficulty Definitions:
* Easy:
  Use a number line with increments of 1,000 to round numbers that are already close to a thousand mark.
Identify the nearest thousand for numbers ending in 500 or 0 using a number line.
* Medium:
  Use a number line with increments of 100 to round numbers to the nearest thousand.
Determine the midpoint between two thousand marks on a number line and decide which thousand a given number is closer to.
Point can be in midpoint
* Hard:
  N/a

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Place Value Words
Lesson Order: 103.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+1
Standard Description: Analyze and manipulate numbers up to 100,000 through place value understanding

Key Concepts:
*None specified*

Learning Objectives:
* Convert a place-value description to a correct number  with numbers from 10000 upto 100000 and choose the best option.
* Convert a place-value description to a correct number  with numbers in the thousands and choose the best option.

Assessment Boundaries:
* Assessment is restricted to:                                                                                     1) Number types & ranges

- Only whole numbers- (no decimals, fractions, or negatives).
- Values range from the hundreds up to 100,000.
- Standard-form numbers must use commas correctly, e.g. `4,728`, `52,068`, `90,241`.

---

2) Representations allowed

- Standard form- with commas.
- Place-value descriptions in words*, e.g.

  - “three ten-thousands, five thousands, eight hundreds, two tens, and four ones”
  - “seven thousands and fourteen tens”.

---

3) Question types allowed

(Each with example question + required answer format)

##3.1 “Write the number using digits.” (MCQ)

- Stem pattern:

  - “How do you write this number using digits?”
- Options: 4 numbers; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`, `B`, `C`, or `D`.


---

##3.2 “Write the number using digits.” (MCQ)

- Stem pattern:

  - “How do you write this number using words?”
- Options: 4 numbers; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`–`D`.

##3.3 Represent numbers with real-world problems with proper english names ( MCQ)

- Stem pattern:

  - “Evie has 70 hundreds, 1 ten, and 15 ones.
Which number does this represent?”
- Noah has 3 thousands, 27 tens, and 14 ones.
Which number does this represent?
- 4 word descriptions; exactly 1- matches the given number and other 3 confusing distractors.

Answer format: Single letter- `A`–`D`.

---

4) Operations

- No computation required beyond interpreting place-value language.
- No subtraction, multiplication, or division between multi-digit numbers.

---
5) Answers shoud be such that the “ending” (e.g., last two digits) isn’t a giveaway:
 -- At least two options should share the same ending.
 -- Sometimes the correct answer should share its ending with one or more incorrect options.
 -- Other times, the option(s) that share an ending should be incorrect, so the ending alone can’t determine the answer.
 -- Exactly one correct answer only
6) Language and clarity (double negatives)

- Avoid double negatives in all items.
- If the stem is negative (e.g., “does NOT describe”), answer choices must be written as clear, positive descriptions (do not include “not/never/except” in options).

Common Misconceptions:
* Confuses the digit's position with its place value when describing numbers in words.
* Ignores or misinterprets zeros as placeholders when translating between standard and word form.
* Reverses the order of place-value units when reading or writing multi-digit numbers.
* Treats commas as indicators to say "hundred" instead of "thousand" in place-value descriptions.

Difficulty Definitions:
* Easy:
  .
Choose the option that correctly matches a 5 digit place-value description to a number (thousands/hundreds/tens/ones).
Question types expected:
b) "How do you write this number using digits?" (4 digits at max)
Distractors should:
a) Swap one place (hundreds ↔ tens, tens ↔ ones)
b) Keep digits similar so it’s not obvious
* Medium:
  Choose the option that correctly matches a 5-digit number to a place-value description including ten-thousands
Question types expected:
b) How do you write this number using words?
Distractors should:
a) Target **internal-zero mistakes** (e.g., treating 54,060 like 54,600)
b) Use **one-place shift** traps (thousands vs ten-thousands)
* Hard:
  Represent numbers with real-world problems.
Using groups of ten to bundle or unbundle without changing the total.
Question types expected:
a) Evie has 70 hundreds, 1 ten, and 15 ones.
Which number does this represent?
b) Noah has 3 thousands, 27 tens, and 14 ones.
Which number does this represent?
Distractors should:
a) Include **3 incorrect descriptions**(off by one place / regrouping error) and **1 correct**

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Expanded Notation
Lesson Order: 104.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+2
Standard Description: Analyze and manipulate numbers up to 100,000 through conversion between different numerical forms

Key Concepts:
*None specified*

Learning Objectives:
* Spot an incorrect place-value decomposition/description of a number with numbers up to 100,000, including cases with zeros in a place and choose the best option.

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.2
Cluster Name: The student applies mathematical process standards to represent and compare whole numbers and understand relationships related to place value.
Lesson Name: Comparing Numbers
Lesson Order: 104.0
Standard ID: TEKS.MATH.CONTENT.3.2.D+3
Standard Description: Analyze and manipulate numbers up to 100,000 through number comparisons

Key Concepts:
*None specified*

Learning Objectives:
* Determine whether a comparison is true or not true by comparing digits from left to right with numbers ranging upto 1000
* Use a 2-column table (1000<numbers <100000) to choose the TRUE/FALSE comparison
* Use a 2-column table (numbers <10000) to choose the TRUE/FALSE comparison

Assessment Boundaries:
* 1) Number types & ranges

- Only whole numbers- (no decimals, fractions, or negatives).
- Values range from the hundreds up to 100,000.
- Standard-form numbers must use commas correctly, e.g. `4,728`, `52,068`, `90,241`.

---

2) Representations allowed

- Standard form- with commas.
- Comparison statements- using `>`, `<`, `=`.
- Bullet-point clues- mixing inequalities and digit conditions
  (e.g., “greater than 32,500”, “less than 32,900”, “hundreds digit is 7”).
- One-way tables- with:

  - A label column- (parks, cities, theaters, animals, etc.).
  - A numeric column- (area, population, tickets sold, weight, etc.).

---

3) Table constraints (structure + answer format)

Table questions MUST embed the table inside `$.question` using HTML** in this exact structure:

  * Intro sentence, then two line breaks (`\n\n`), then a **bold title line** using `<strong>…</strong>`, then two line breaks, then the `<table …>` block, then two line breaks, then the final question sentence.
  * Required layout (exact tags/attributes):

    * `<table style="border-collapse: collapse; width: 100%; max-width: 400px;">`
    * `<thead>` with a single header row `<tr>` containing **exactly 2 `<th>` cells**
    * `<tbody>` containing **exactly 4 rows** (`<tr>`), each with **exactly 2 `<td>` cells**
    * Every `<th>` and `<td>` MUST use **this exact inline style**:
      `style="border: 1px solid #000; padding: 4px; text-align: left;"`

#Answer format for table items (MCQ only)

- Stem patterns:

  - “Which comparison of these ___ is true?”
  - “Which comparison of these ___ is NOT true?”
- Exactly 4 answer options.
- Each option is a numeric comparison built from numbers in the table only, in the form:

  - `number 1 < number 2`
  - `number 1 > number 2`
  - `number 1 = number 2`
- Do not restate the context in the option (“The population of City A is less than…”). Options are just number–symbol–number.
- For “Which comparison … is true?” → exactly one option true; the other three false.
- For “Which comparison … is NOT true?” → exactly one option false; the other three true.
- Avoid double negatives in options (no “not”, “never”, “except” inside answer choices).
- If options are stored/rendered as HTML, encode `<` and `>` as `&lt;` and `&gt;` in the content string.

---

4) Question types allowed

(Each with example question + required answer format)

##4.5 Clue-based number identification (bullet clues MCQ)

- Stem pattern:

  - “The list shows clues about a number… Which of these could be the number described?”
- Prompts use 3 bullet clues:

  - 2 range clues (`>`, `<`)
  - 1 digit-condition clue (place + value).
- Options: 4 numerals- in standard form.

Answer format: Single letter- `A`–`D`.
- Clue list formatting (required): The prompt must include a bullet list written as either:


- HTML: a <ul> containing exactly three <li>
---

##4.6 Direct comparisons (no table, MCQ)

- Stem patterns:

  - “Which comparison is true?”
  - “Which comparison is NOT true?”
- Options: 4 comparison statements- using `>`, `<`, `=` between two multi-digit numbers.

Answer format: Single letter- `A`–`D`.

---

##4.7 Table comparisons (MCQ with table)

- Stem patterns:

  - “Which comparison of these ___ is true?”
  - “Which comparison of these ___ is NOT true?”
- Uses a 2-column table- (see section 3). Options compare table numbers only- with `>`, `<`, `=`.

Answer format: Single letter- `A`–`D`.

---

5) Operations

- No arithmetic beyond comparing digits by place value.
- No subtraction, multiplication, or division between multi-digit numbers.

---

6) Language and clarity (double negatives)

- Avoid double negatives in all items.
- If the stem is negative (e.g., “NOT true”), then answer choices must be written as clear, positive comparisons (no negatives inside options).
- Items should not feel like trick questions; wording should test comparison/place-value understanding.

Common Misconceptions:
* Assumes the number with more digits is always smaller because it "looks longer."
* Compares only the leftmost digits and ignores place value when numbers have different digit counts.
* Reads multi-digit numbers left-to-right as separate single digits rather than understanding place value.
* Reverses the meaning of inequality symbols, treating less-than as greater-than and vice versa.

Difficulty Definitions:
* Easy:
  1)Clues

  - Range + one digit-in-place condition

  - Numbers ≤ 10,000 (prefer 3 digits; allow 4 digits only if still “low thousands”)

  - Distractors violate exactly one clue (too high/low OR wrong digit place)

2) Direct comparisons (false statement)

  - 3–4 digit comparisons (within 1,000s)

  - Exactly one statement false

  - Distractors: same leading digit(s), differ in tens/ones; sign-direction trap

3) Table (true)

  - Table values all within 1,000s (3-digit or low 4-digit)

  - Stem: “Which comparison is true?”

  - Distractors: sign flip or swapped entity pair (numbers must come from table)

  - Table to have real world context.
* Medium:
  1) Clues

  - Numbers > 10,000

  - Same structure; digit condition may target thousands/hundreds/tens/ones

2) Direct comparisons (false statement)

  - 4-digit comparisons across thousands (0–9,999)

  - Near-miss distractors (share thousands digit; differ in hundreds/tens)

3) Table (NOT true)

  - Allowed only if max(table_value) ≤ 9,999

  - Distractors: sign flip / swapped pair using table values only

  - Table to have real world context.
* Hard:
  1) Direct comparisons (false statement)

  - Values up to 100,000

  - Near-miss distractors with shared leading digits

2) Table (true OR NOT true)

  - If any table value ≥ 10,000 →

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Money: Represent and Count
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.4.C
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Money: Represent and Count
Lesson Order: 105.0
Standard ID: TEKS.MATH.CONTENT.3.4.C+1
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Representing and Counting Money
Lesson Order: 108.0
Standard ID: TEKS.MATH.CONTENT.3.4.C+1
Standard Description: Determine the value of mixed coins and bills in various real-world contexts by identifying matching and non-matching amounts and calculating totals up to $20

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:
Currency types: U.S. coins (penny, nickel, dime, quarter) and bills ($1, $5, $10, $20).
No use of $50 or $100 bills, foreign currency, or nonstandard coins.
Totals must not exceed $20 and no more than 5 of the same currency.
Calculations are limited to addition only (no subtraction, multiplication, or division).
No use of fractions or decimals; all coin values appear in standard U.S. currency format (e.g., $0.25, not ¼).
Each item is embedded in a real-world context (e.g., shopping, saving, receiving change).
The context must not require inference beyond money recognition (e.g., no multi-step transactions or tax calculation).
“Does not match” questions must include one clearly incorrect image whose total differs by at least $0.25.
No problems that involve mixed equivalences (e.g., “two nickels equal one dime”).
No requirement to convert between dollars and cents.
All currency symbols follow standard format (e.g., $1.25).
No use of algebraic symbols, tables, or word equations.
No requirement to interpret written number words (e.g., “five dollars”).
No mention of "image", should just say "which of the following"/"amount shown"
Never write the explicit amount of bills and coins in the questions stem (e.g. She has 5 quarters, etc.)

Common Misconceptions:
* Students confuse coin denominations or misremember values.
* Students count coins as individual units instead of aggregating value.
* Students rely on visual quantity rather than numerical value.
* Students struggle to combine mixed denominations correctly.

Difficulty Definitions:
* Easy:
  Identify the total value of a set of coins (pennies, nickels, dimes) up to $1.
Match a simple real-world situation with an image of coins and bills totaling less than $5.
Select the correct image of coins and bills for a given amount under $5.
* Medium:
  Identify the total value of a set of mixed coins and bills up to $10.
Match a real-world situation with an image of coins and bills totaling between $5 and $10.
Determine which image of coins and bills does not match a given amount under $10.
* Hard:
  Identify the total value of a set of mixed coins and bills up to $20.
Match a more complex real-world situation with an image of coins and bills totaling between $10 and $20.
Determine which image of coins and bills does not match a given amount between $10 and $20.

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+5
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers using the Standard Algorithm
Lesson Order: 106.0
Standard ID: TEKS.MATH.CONTENT.3.4.G+1
Standard Description: Solve mathematical problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Multiply a two-digit whole number by a one-digit whole number.

Assessment Boundaries:
* Assessment is restricted to:
- NO regrouping at all
- Whole numbers only
- Question stem should ONLY be "Multiply:", no question marks
- Two-digit number MUST be on top
- Vertical Multiplication MUST have format: <br><br>$\\begin{array}{r}\\phantom{\\times}xx\\\\\\times\\,xx\\\\\\hline &\\vphantom{\\mathtt{0}} \\\\ \\end{array}$ <br><blank>

Common Misconceptions:
* Student forgets to regroup when the product of the ones digits is greater than 9
* Student misaligns digits in the vertical algorithm, causing place value errors
* Student multiplies only the ones digit and ignores the tens digit
* Student regroups but adds the carried value to the wrong place value

Difficulty Definitions:
* Easy:
  Both digits of the two-digit number are less than 5
The one-digit multiplier is less than 5
No regrouping
* Medium:
  Both digits of the two-digit number are less than 5
The one-digit multiplier is greater than or equal to 5
Regrouping may be required in the ones place
* Hard:
  Both digits of the two-digit number are greater than or equal to 5
The one-digit multiplier is greater than or equal to 5
Regrouping is required and must be applied correctly across places

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.4+5
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations in order to solve problems with efficiency and accuracy
Lesson Name: Multiplying Two-Digit Numbers by One Digit Numbers: Word Problems
Lesson Order: 107.0
Standard ID: TEKS.MATH.CONTENT.3.4.G+2
Standard Description: Solve real-world problems involving using the standard algorithm to multiply two-digit numbers by one-digit numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Solve one-step word problems by multiplying a two-digit whole number by a one-digit whole number.

Assessment Boundaries:
* Assessment is restricted to:
Whole numbers only
One-step word problems that require multiplying a one-digit number by a two-digit number
Contexts limited to familiar Grade 3 situations (e.g., money, groups of items, repeated quantities)
Answers are required as whole numbers with appropriate units when provided (e.g., dollars, items)
No estimation, no multi-step reasoning, and no division

Common Misconceptions:
* Student forgets to regroup when the product of the ones digits is greater than 9
* Student misaligns digits in the vertical algorithm, causing place value errors
* Student multiplies only the ones digit and ignores the tens digit
* Student regroups but adds the carried value to the wrong place value

Difficulty Definitions:
* Easy:
  No regrouping
* Medium:
  Regrouping required
* Hard:
  N/a

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Multi-step Word Problems: Solve or Represent with an Equation
Lesson Order: 105.0
Standard ID: TEKS.MATH.CONTENT.3.5.B+1
Standard Description: Solve multi-step word problems by representing them with equations and using various mathematical operations and models

Key Concepts:
*None specified*

Learning Objectives:
* Combine deposits and withdrawals in one equation.
(e.g., Stem: “Freddie had $256 in his bank account. On Monday he put $50 more into his account. On Tuesday he took out $87 to buy a bicycle. Which equation can be used to find the amount of money Freddie had in his bank account after he took out money on Tuesday?” → 256 + 50 − 87)
* Compare a combined total to a single amount.
(e.g., Stem: “Wanda traveled on an airplane three times last year. She traveled 278 mi in January, 652 mi in April, and 767 mi in September. How many more miles did Wanda travel in January and April combined than she traveled in September?” → 163 mi)
* Find the difference between one quantity and the sum of two others.
(e.g., Stem: “Samantha, Gordon, and Diego each brought an ice chest to a picnic. Samantha’s ice chest weighed 83 lb. Gordon’s weighed 28 lb. Diego’s weighed 37 lb. What was the difference in pounds between the weight of Samantha’s ice chest and the combined weight of Gordon’s and Diego’s ice chests?” → 18 lb)
* Given a strip model, form an equation to find the difference between a total cost and savings.
(Question should always be in this format(but shouldn't be exactly the same) e.g.: “Timothy wants to buy a camera that costs $75. He has saved $23. Which equation can be used to find how much more money Timothy needs?” → 75 − 23)
* Given a strip model, form an equation to find the difference between a total cost and savings.
(e.g., Stem: “Timothy wants to buy a camera that costs $75. <<Strip model>>. He has saved $23. Which equation can be used to find how much more money Timothy needs?” → 75 − 23)
* Identify and add the two largest values from a table.
(e.g., Stem: “The table shows the numbers of puzzle pieces in four puzzles. Derek put together the two puzzles that had the greatest numbers of pieces. What is the total number of pieces in these two puzzles?” → Not here – the correct sum (498 + 473 = 971) isn’t one of the listed answers)
* Identify and add the two largest values from a table. (e.g., Stem: “The table shows the numbers of puzzle pieces in four puzzles. Derek put together the two puzzles that had the greatest numbers of pieces. What is the total number of pieces in these two puzzles?” → The answer choices should always be whole number and not equations.)
* Identify the incorrect equation for finding a sold amount.
(e.g., Stem: “Tyrese had 572 baseball cards. He sold some of the baseball cards and then had 98 baseball cards left. Which equation could NOT be used to find the number of baseball cards Tyrese sold?” → 98 + 572 = □)
* Model repeated multiplication and division.
(e.g., Stem: “To make posters, 6 students each collected 8 pictures of animals. The students put 4 animal pictures on each poster they made. Which equation shows one way to find the number of posters the students made?” → 6 × 8 ÷ 4)
* Solve for a missing addend given the total.
(e.g., Stem: “A cafeteria sold a total of 313 drinks on Wednesday. The table shows the number of each type of drink that was sold, but the number of bottles of milk is missing. Which set of equations can be used to find the number of bottles of milk sold?” → add the known drink counts and subtract from the total; e.g., 172 + ? + 263 = 313 and ? = 313 − 172 − 263)
* Use multiplication to represent doubling an equal‑groups scenario.
(e.g., Stem: “A classroom currently contains 6 rows of chairs with 5 chairs per row. On parents’ night the classroom had twice as many chairs. Which number sentence can be used to find the number of chairs in the classroom on parents’ night?” → 6 × 5 × 2)
* Write an equation to model a two‑step addition/subtraction situation.
(e.g., Stem: “An art teacher had 736 crayons. She threw away 197 broken crayons. Then she bought 150 more crayons. Which equation shows how to find the number of crayons the art teacher has now?” → 736 − 197 + 150)

Assessment Boundaries:
* Assessment is restricted to:
* Whole numbers only (0–1,000).
* Multi-step problems involving addition, subtraction, multiplication, and division.
* Addition and subtraction limited to 3-digit numbers (e.g., 767 – 652).
* Multiplication and division limited to basic facts and single-digit factors (e.g., $6 \times 8 \div 4$).
* Questions primarily require identifying the correct equation/number sentence rather than just the final calculation.
* Unknown quantities must be represented by a symbol (box $\square$ or question mark).
* Currency is treated as whole numbers only (e.g., $75); no decimals or cent values.
* No fractions, decimals, remainders in division, or negative numbers.
* Real-world scenarios are limited to countable inventory (crayons, ribbons), measurement (miles, pounds), and whole-dollar banking.

Common Misconceptions:
* Students add the known part to the total instead of subtracting to find the difference.
* Students assign incorrect signs to sequential events (e.g., adding a loss or subtracting a gain).
* Students select operations based on isolated keywords (e.g., "more" implies addition) rather than the problem's logic.
* Students treat all numbers as addends, ignoring multiplication or division contexts.

Difficulty Definitions:
* Easy:
  Write an equation for a two-step addition/subtraction problem using simple numbers (e.g., under 100).
Identify and add the two largest values from a table with small numbers.
Use multiplication to represent doubling with small numbers (e.g., 2 rows of 3 chairs).
Solve for a missing addend with small numbers and a simple total.
* Medium:
  Write an equation to model a two-step addition/subtraction situation with larger numbers (e.g., three-digit numbers).
Use multiplication to represent doubling an equal-groups scenario with moderate numbers (e.g., 6 rows of 5 chairs).
Given a strip model, form an equation to find the difference between a total cost and savings with moderate numbers.
Combine deposits and withdrawals in one equation with moderate numbers.
* Hard:
  Model repeated multiplication and division with larger numbers (e.g., 6 students, 8 pictures each, 4 pictures per poster).
Compare a combined total to a single amount with larger numbers and multiple steps.
Identify the incorrect equation for finding a sold amount with complex numbers.
Find the difference between one quantity and the sum of two others with larger numbers and multiple steps.

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Input-Output : Rule from a Table (Functional Pattern)
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.3.5.E
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Input-Output : Rule from a Table (Functional Pattern)
Lesson Order: 107.0
Standard ID: TEKS.MATH.CONTENT.3.5.E+1
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

PART 1: TABLE FORMAT (MANDATORY - READ FIRST)
Table Structure (MUST be HTML):
Tables contain 3 to 5 rows of data and MUST have 3 columns (first column CANNOT be days of the week, should be letters or names)
Column headers must be labeled with real-world context (e.g., “Number of Books” and “Sale Price”).
Any table appearing in the question (stem or answer option) MUST follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and Temperature</h5>\n\n<table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n  <thead>\n    <tr>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Day</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Monday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Tuesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Wednesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Thursday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">25 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n    </tr>\n  </tbody>\n</table>
"""

PART 2: CONTENT CONSTRAINTS
All values in tables are whole numbers only.
No decimals, fractions, negative numbers, or mixed numbers.
All operations are limited to a single addition, subtraction, and multiplication (no division).

Numerical Ranges:
Numbers in tables range from 1 to 200.
Sums, differences, or products must not exceed 500.
Additive relationships must use constants no greater than 25.
Multiplicative relationships must use single-digit or small double-digit factors (2–12).

Context and Realism:
Every item must have a real-world context (e.g., prices, quantities, scores, items, plants, or objects).
Contexts must represent familiar, age-appropriate scenarios (e.g., store purchases, classroom scores, or collections).
No abstract, algebraic, or purely numerical tables without context.
No multi-step operations

Question Structure:
Question stems MUST be one of: 
1. <<sentence setting up context>>The table shows the relationships....<<table>>Which of these describes the relatioship in the table?
2. <<sentence setting up context>> Which of table shows <<relationship>>?
Each question stem must clearly specify whether the task is to identify, apply, or describe the relationship.
All numerical values should include appropriate units when relevant (e.g., “dollars,” “points,” “flowers”).
No symbolic algebra or equation writing (e.g., “y = 3x”).   

PART 3: ANSWER OPTION FORMAT (MANDATORY)

All answer choices MUST be complete explanatory statements, not short conclusions.

Each answer choice MUST:

State a constant value (e.g., item cost).

Explicitly describe the operation relating the two columns (e.g., “amount paid minus ___ equals change”).

Use the word “because” to justify the relationship.

Answer choices MUST follow one of these exact templates (no deviation):

Subtraction relationship template:

“Each item costs ___ dollars, because the amount paid minus ___ equals the change received.”

Addition relationship template (if applicable):

“Each item costs ___ dollars, because the change received plus ___ equals the amount paid.”

All incorrect answer choices MUST:

Use the same sentence structure as the correct answer.

Contain a plausible but incorrect constant.

Answer choices MUST NOT:

Ask the student to compute.

Refer to specific rows by letter.

Introduce new numbers not present or inferable from the table.

Use symbolic notation or equations.

Common Misconceptions:
* - Students confuse additive and multiplicative relationships.
* - Students focus only on surface-level number changes rather than identifying the consistent rule.
* Students fail to verify consistency across all rows of the table.
* Students reverse the relationship direction between quantities.

Difficulty Definitions:
* Easy:
  Identify a simple addition or subtraction rule in a table with small numbers.
Recognize a table that matches a straightforward multiplication relationship with small numbers.
* Medium:
  Determine a rule involving addition or subtraction with larger numbers in a given context.
Identify a table that represents a multiplication relationship using larger numbers.
Analyze a table to determine which statement about a real-world relationship is true.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.5
Cluster Name: The student applies mathematical process standards to analyze and create patterns and relationships.
Lesson Name: Finding Rules from Tables
Lesson Order: 110.0
Standard ID: TEKS.MATH.CONTENT.3.5.E+1
Standard Description: Identify and apply arithmetic rules to analyze and construct tables that represent real-world relationships

Key Concepts:
*None specified*

Learning Objectives:
* Given a context, identify a rule in a table. (e.g., “Mr. Morales gives bonus points… Which of these describes the relationship shown in the table?” where test scores before and after a bonus are shown as 79→83, 81→85, etc. → The test score before bonus points plius 4 equals the test score after the bonus points.)
* Given a table of real world relationship, deetermine which statement regarding the relationship is true? (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3 × as many yellow flowers as red flowers in each vase.)
* Given a table of real world relationship, determine which statement regarding the relationship is true? (division or subtraction) (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3 less yellow flowers than red flowers in each vase.)
* Given a table of real world relationship, determine which statement regarding the relationship is true? (multiplication and addition) (e.g., “The table shows the numbers of yellow and red flowers in four vases… Which statement is true?” → There are 3  more yellow flowers than red flowers in each vase.)
* Given a table showing an amount paid and the corresponding change received, determine the constant cost of an item by identifying and justifying the additive relationship between the two quantities.
* Identify a table that represents a given real world relationship.(e.g., “Kacie sold bracelets… She sold 3 bracelets for $1… Which table represents the numbers of bracelets that would be sold for different numbers of dollars?” → Multiply the number of dollars by 3.)
* Identify a table that represents a given relationship described in a real world situation.(e.g.,  “A store is having a sale… The sale price of each book is $6 less than the regular price… Which table shows prices of different books?” → The sale price is regular price – $6.)
* Identify from 4 table answer options, which table represents a given real world relationship (multiplication or addition).(e.g., “Kacie sold bracelets… She sold 3 bracelets for $1… Which table represents the numbers of bracelets that would be sold for different numbers of dollars?”)
* Identify from 4 table answer options, which table represents a given real world relationship. (division or subtraction) (e.g., “Kacie sold bracelets discounted… Each discounted bracelet was $3 less than regular price… Which table represents the price of the bracelets sold by Kacie?”)

Assessment Boundaries:
* Assessment is restricted to:

PART 1: TABLE FORMAT (MANDATORY - READ FIRST)
Table Structure (MUST be HTML):
Tables contain 3 to 5 rows of data and MUST have 3 columns (first column CANNOT be days of the week, should be letters or names)
Column headers must be labeled with real-world context (e.g., “Number of Books” and “Sale Price”).
Any table appearing in the question (stem or answer option) MUST follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and Temperature</h5>\n\n<table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n  <thead>\n    <tr>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Day</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n      <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Monday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Tuesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Wednesday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n    </tr>\n    <tr>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Thursday</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">25 F</td>\n      <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n    </tr>\n  </tbody>\n</table>
"""

PART 2: CONTENT CONSTRAINTS
All values in tables are whole numbers only.
No decimals, fractions, negative numbers, or mixed numbers.
All operations are limited to a single addition, subtraction, and multiplication (no division).

Numerical Ranges:
Numbers in tables range from 1 to 200.
Sums, differences, or products must not exceed 500.
Additive relationships must use constants no greater than 25.
Multiplicative relationships must use single-digit or small double-digit factors (2–12).

Context and Realism:
Every item must have a real-world context (e.g., prices, quantities, scores, items, plants, or objects).
Contexts must represent familiar, age-appropriate scenarios (e.g., store purchases, classroom scores, or collections).
No abstract, algebraic, or purely numerical tables without context.
No multi-step operations

Question Structure:
Question stems MUST be one of: 
1. <<sentence setting up context>>The table shows the relationships....<<table>>Which of these describes the relatioship in the table?
2. <<sentence setting up context>> Which of table shows <<relationship>>?
Each question stem must clearly specify whether the task is to identify, apply, or describe the relationship.
All numerical values should include appropriate units when relevant (e.g., “dollars,” “points,” “flowers”).
No symbolic algebra or equation writing (e.g., “y = 3x”).   

PART 3: ANSWER OPTION FORMAT (MANDATORY)

All answer choices MUST be complete explanatory statements, not short conclusions.

Each answer choice MUST:

State a constant value (e.g., item cost).

Explicitly describe the operation relating the two columns (e.g., “amount paid minus ___ equals change”).

Use the word “because” to justify the relationship.

Answer choices MUST follow one of these exact templates (no deviation):

Subtraction relationship template:

“Each item costs ___ dollars, because the amount paid minus ___ equals the change received.”

Addition relationship template (if applicable):

“Each item costs ___ dollars, because the change received plus ___ equals the amount paid.”

All incorrect answer choices MUST:

Use the same sentence structure as the correct answer.

Contain a plausible but incorrect constant.

Answer choices MUST NOT:

Ask the student to compute.

Refer to specific rows by letter.

Introduce new numbers not present or inferable from the table.

Use symbolic notation or equations.

Common Misconceptions:
* - Students confuse additive and multiplicative relationships.
* - Students focus only on surface-level number changes rather than identifying the consistent rule.
* Students fail to verify consistency across all rows of the table.
* Students reverse the relationship direction between quantities.

Difficulty Definitions:
* Easy:
  Identify a simple addition or subtraction rule in a table with small numbers.
Recognize a table that matches a straightforward multiplication relationship with small numbers.
* Medium:
  Determine a rule involving addition or subtraction with larger numbers in a given context.
Identify a table that represents a multiplication relationship using larger numbers.
Analyze a table to determine which statement about a real-world relationship is true.
* Hard:
  N/A

---

Subject: Math
Course: 3rd Grade TEKS
Unit ID: Math Grade 3 Unit 13
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.3.6
Cluster Name: The student applies mathematical process standards to analyze attributes of two-dimensional geometric figures to develop generalizations about their properties.
Lesson Name: Classify 3D-Shapes
Lesson Order: 111.0
Standard ID: TEKS.MATH.CONTENT.3.6.A+1
Standard Description: Classify and sort three-dimensional shapes, distinguishing between prisms and non-prisms, based on their geometric properties

Key Concepts:
*None specified*

Learning Objectives:
* Given two images with sorted shapes, identify a statement about the sorted figures that is true.

Assessment Boundaries:
* Global Assessment Boundaries (Applies to all tasks):

Allowed Shapes: Figures are strictly limited to cubes, rectangular prisms, triangular prisms, cylinders, cones, and spheres.

Constraint: Pyramids (such as square or triangular pyramids) may be included as distractors or as examples of non-prisms, but students are not required to identify the figure specifically as a "pyramid."

Classification Criteria: The core assessment must focus on the following 3rd-grade attributes: the presence of flat faces/edges/vertices (polyhedra) vs. curved surfaces (non-polyhedra), and the distinction between a prism and a non-prism.

Vocabulary: Questions must use formal geometric language for the shape names (e.g., "prism," "cylinder," "sphere," "cone," "rectangular prism," "cube," "non-prism"). Informal terms are not allowed.

Stimulus Variety: Stimuli may include both drawings of geometric figures and real-world objects. Real-world objects must be clear representations of the allowed 3D shapes.

Exclusions: No assessment of attributes beyond grade 3 is allowed (e.g., volume, surface area, nets). Students are not required to use or identify formal vocabulary beyond the shape names (e.g., face, edge, vertex) for the purpose of classification.

II. Task-Specific Assessment Boundaries: A. Task Type: Grouping and Classification Tables

Question Stem: Must require the student to analyze a pre-sorted set of figures and choose the correct grouping table.

Item Count: Questions must use a total of exactly 4 figures/objects.

Table Grouping Constraint: For the correct answer option, the table MUST consist of exactly two groups with an unbalanced 3/1 split (exactly 3 objects in one group and 1 object in the other). Tables with a 2/2 split are strictly prohibited for the correct answer.

Grouping Rationale: The sorting rationale must involve core classification: Prisms vs. Non-Prisms OR Shapes with curved surfaces vs. shapes with flat faces.

Distractor Requirement: All distractors must also utilize a 3/1 structural split to mirror the correct answer. Distractors must be incorrect based on geometric properties (e.g., misclassifying an object) or mathematical counts (e.g., listing a shape that wasn't in the stimulus).

B. Task Type: Identify Prism vs. Non-Prism

Question Stem: Must ask either "Which figure CAN be classified as a prism?" or "Which figure CANNOT be classified as a prism?"

Stimulus Mix: Each question must provide four answer options using a mix of figures:

For "CANNOT be a prism" questions: Provide three prisms and one non-prism.

For "CAN be a prism" questions: Provide three non-prisms and one prism.

Focus: The question tests the fundamental understanding of the definition of a prism versus a non-prism based on the presence of flat faces vs. curved surfaces.

C. Bin Sorting (For LO - Given two images with sorted shapes, identify a statement about the sorted figures that is true.)
Question Stem: The question must strictly ask: "Which statement about the figures in Bin A and Bin B is true?"

Stimulus Requirement:

The stimulus must present two clearly labeled containers: Bin A and Bin B.

Each bin must contain a set of figures sorted by a specific geometric attribute.

Mandatory Answer Choice Phrasing: All four answer options (A, B, C, D) must strictly use the syntax: "All the figures in bin [Label] are [Classification/Shape]".

Approved "True" Classification Categories: The correct answer must be limited to one of the following specific statements:


"All the figures in bin [X] are cylinders"

"All the figures in bin [X] are cones"

"All the figures in bin [X] are triangular prisms"

"All the figures in bin [X] are spheres"


Distractor Requirement:

All distractors must utilize the same mandatory syntax to remain indistinguishable in structure from the correct answer.

Distractors should misclassify the shapes in the bins (e.g., claiming a bin of varied rectangular prisms contains "all cubes").

All figures used in the bins must be selected from the Allowed Shapes list: cubes, rectangular prisms, triangular prisms, cylinders, cones, and spheres.

Common Misconceptions:
* Assumes a shape must have rectangular faces to be classified as a prism.
* Classifies any non-prism with a flat face (e.g., cone, pyramid) as a prism.
* Confuses cylinders and cones with prisms, treating them all as having rectangular sides.
* Treats cubes and rectangular prisms as distinct from the general category of "prisms."

Difficulty Definitions:
* Easy:
  - Identify a statement about sorted figures from two images with clearly distinct shapes.
  - Determine which shape can be classified as a prism from a simple list of common shapes.
* Medium:
  - Given six figures of 3D shapes, determine which list shows a correct way to group the figures based on basic properties.
  - Determine which shape cannot be classified as a prism using familiar shapes like cubes and pyramids.
* Hard:
  - Given four figures of 3D shapes, determine which table shows a correct way to group the figures, requiring understanding of less common shapes and properties.
  - Identify a true statement about sorted figures that involves more complex reasoning or less familiar shapes

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Comparing Fractions Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.D
Standard Description: Compare fractions in word problems to develop problem-solving skills at the rigor of standardized assessments.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Multi-Step Word Problems with Money
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.4.A
Standard Description: Solve multi-step word problems involving the addition and subtraction of money using decimals to the hundredths place.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Fixed and Variable Expenses
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.10.A
Standard Description: Distinguish between fixed and variable expenses by analyzing real-world scenarios and expense tables.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Fixed and Variable Expenses
Lesson Order: 169.0
Standard ID: TEKS.MATH.CONTENT.4.10.A+1
Standard Description: Distinguish between fixed and variable expenses by analyzing real-world scenarios and expense tables.

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate statements about whether expenses in a table are fixed or variable.
* Identify which expenses from a table are fixed expenses.
* Identify which expenses from a table are variable expenses.

Assessment Boundaries:
* Assessment is restricted to:
- Expense tables with dollar amounts showing multiple expense categories across multiple months
- Classification only — no arithmetic calculations are required
- Fixed expense = same dollar amount each month; variable expense = different dollar amounts across months

Common Misconceptions:
* Classifies expenses as variable based on being wants rather than needs.
* Compares amounts between expense types instead of across months for one expense.
* Confuses the definitions of fixed and variable expenses.
* Labels an expense as fixed because one amount repeats in the list.

Difficulty Definitions:
* Easy:
  2-3 expense categories, 3 months
Dollar amounts are round numbers (no cents)
Amounts that are fixed are clearly the same; amounts that are variable are clearly different
* Medium:
  4-5 expense categories, 3-6 months
Dollar amounts include cents
Some variable amounts may be close in value but still different across months
* Hard:
  N/A

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Interpreting Relationships Between Place Values
Lesson Order: 134.0
Standard ID: TEKS.MATH.CONTENT.4.2.A+1
Standard Description: Interpret the value of each place-value position as 10 times the position to the right and as one-tenth of the value of the place to its left

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate which statement about a "10 times" or "one-tenth" relationship involving decimal place values is true.
* Given a whole number, evaluate multiple statements about "10 times" and "one-tenth" relationships between adjacent place values and select all that are true.
* Given multiple whole numbers with identified digits, determine which numbers satisfy a stated place value relationship.

Assessment Boundaries:
* Assessment is restricted to:
    - Whole numbers with up to 5 digits (ones through ten-thousands place)
    - Decimals limited to tenths and hundredths places
    - Place value relationships restricted to adjacent positions only ("10 times" and "one-tenth")

Common Misconceptions:
* Applies a 10-times or one-tenth relationship to values that are not in adjacent place-value positions on the chart.
* Misidentifies the place-value position of a digit, especially in numbers with zeros or repeated digits.
* Misidentifies which digit is in a named place-value position.
* Reverses the left/right place-value relationship between adjacent places. For example, treats a value to the left on the chart as one-tenth instead of 10 times, or treats a value to the right as 10 times instead of one-tenth.

Difficulty Definitions:
* Easy:
  MCQ format: pick 1 true statement from 4 options
No context number; abstract comparison statements
Statements involve decimal place values (tenths, hundredths) alongside whole-number places
All four options use the same digit appearing in different numbers spanning hundredths through hundreds
Distractors reverse the "one-tenth" or "10 times" direction
* Medium:
  Multi-Select with image answer options: pick 3 correct from 6 numbers
Given 6 whole numbers, each with one digit circled and one digit underlined
Determine which numbers have the circled digit worth 10 times (or one-tenth) the underlined digit
Correct numbers have the same digit in adjacent places with the correct relationship
Distractor numbers have digits in non-adjacent places or the wrong direction
* Hard:
  Multi-Select format: pick 2-3 correct from 5 statements
Given a whole number (with at least two pairs of adjacent places sharing the same digit) in a real-world context
Evaluate multiple statements about adjacent place value relationships using "10 times" and "one-tenth"
Distractors reverse relationship directions

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Writing Decimals in Words, Standard and Expanded Form
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.B
Standard Description: Convert between standard form, word form, and expanded notation for whole numbers through hundred-thousands and decimals to the hundredths place

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Writing Decimals in Words, Standard and Expanded Form
Lesson Order: 135.0
Standard ID: TEKS.MATH.CONTENT.4.2.B+1
Standard Description: Convert between standard form, word form, and expanded notation for whole numbers through hundred-thousands and decimals to the hundredths place

Key Concepts:
*None specified*

Learning Objectives:
* Convert a number in standard form to its expanded notation.
* Given a digit value in expanded form, select all numbers from a list where that digit has the stated value.
* Given a number in a real-world context, select its correct expanded notation.
* Given a number in word form within a real-world context, find the value of a specific digit.
* Given a number in word form within a real-world context, select its correct expanded notation.
* Given digit-value clues about a number, select the matching standard-form number.
* Given expanded notation of a number in a real-world context, select the number in standard form.
* Given expanded notation of a number, compute and write the number in standard form.
* Given expanded notation, select the correct word form of the number.

Assessment Boundaries:
* Assessment is restricted to:
    - Whole numbers with up to 6 digits (ones through hundred-thousands)
    - Decimals limited to tenths and hundredths places
    - Numbers may contain zero in any position (zero placeholders)
    - Expanded notation omits zero-value terms

Common Misconceptions:
* Confuses tenths and hundredths when writing expanded notation or word form.
* Reads the decimal portion of word form as a whole number.
* Shifts digits to the wrong place value position in expanded notation.

Difficulty Definitions:
* Easy:
  No real-world context
Direct conversion between expanded notation and standard form
Numbers with up to 4-digit whole-number part and up to 2 decimal places
Identifies the value of a single named digit
* Medium:
  Real-world context requiring word problem parsing
Conversion involving word form or digit-value clues
Numbers with up to 6-digit whole-number part and up to 2 decimal places
Numbers may include zero placeholders
Selects from multiple representations to identify digit-value matches
* Hard:
  Compound task: expanded notation to word form
Must correctly use "and" to separate whole and decimal parts
Must name the rightmost decimal place ("tenths" or "hundredths")

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Ordering Whole Numbers up to 1,000,000,000
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.C
Standard Description: Order whole numbers up to 1,000,000,000 and represent the comparison using the inequality symbols.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Ordering Whole Numbers up to 1,000,000,000
Lesson Order: 140.0
Standard ID: TEKS.MATH.CONTENT.4.2.C+1
Standard Description: Order whole numbers up to 1,000,000,000 and represent the comparison using the inequality symbols.

Key Concepts:
*None specified*

Learning Objectives:
* Order whole numbers in a real-world context and identify the value at a specific position.
* Select the correct comparison of whole numbers using inequality symbols.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers with 4 to 9 digits (1,000 to 999,999,999)
- No decimals, fractions, or negative numbers

Common Misconceptions:
* Confuses least to greatest with greatest to least when ordering.
* Misreads the less-than symbol as greater-than, reversing the order.
* Orders numbers correctly but identifies the wrong position in the list.
* Skips the first differing place value and compares at a lower one.

Difficulty Definitions:
* Easy:
  3 items, 6 digit whole numbers
* Medium:
  3 items, 7-9 digit whole numbers OR 4 items, 4-digit whole numbers
* Hard:
  N/A

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Rounding Whole Numbers
Lesson Order: 151.0
Standard ID: TEKS.MATH.CONTENT.4.2.D+1
Standard Description: Round whole numbers to a given place value through the hundred thousands place.

Key Concepts:
*None specified*

Learning Objectives:
* Round a given whole number to a specified place value.
* Round a whole number to a specified place value within a word-problem context

Assessment Boundaries:
* ## In Scope

- Whole numbers only (no decimals)
- Place values: tens, hundreds, thousands, ten thousands, hundred thousands
- Numbers from 100 to 999,999
- The digit to the right of the rounding place may be any digit 0-9, including the critical digit-5 case
- All numbers ≥ 1,000 use commas in stems and answers (e.g., 239,000)
- STAAR numeral formatting: stems use numerals, not spelled-out numbers

## Out of Scope

- Rounding decimals
- Rounding to the nearest million or beyond
- Rounding negative numbers
- Estimating sums or differences using rounding
- Multi-step rounding (round twice)
- Numbers less than 100

## Question Formats

### Easy — MCQ with 4 Text Options
- Exactly 4 answer options (A, B, C, D), all text (no images)
- Single correct answer
- Distractors are plausible wrong answers based on common misconceptions

### Medium — Text Entry NSB
- Student types a single number as the answer
- No answer options provided
- The answer is the correctly rounded whole number

Common Misconceptions:
* Confuses place values and rounds to an adjacent place (e.g., asked for nearest thousand but rounds to nearest ten thousand: 238,855 becomes 240,000 instead of 239,000).
* Incorrectly modifies digits to the left of the target place value, producing a number in a different magnitude (e.g., 238,855 rounded to the nearest thousand becomes 230,000 instead of 239,000).
* Rounds down when the digit to the right of the rounding place is exactly 5, instead of rounding up (e.g., 238,855 rounded to the nearest thousand becomes 238,000 instead of 239,000).
* Truncates the number by replacing digits to the right of the rounding place with zeros without adjusting the rounding digit (e.g., 557 rounded to nearest ten becomes 550 instead of 560).

Difficulty Definitions:
* Easy:
  Direct rounding questions with no word-problem context
Stem pattern: "What is the value of [number] when rounded to the nearest [place value]?"
Numbers: 3-digit to 6-digit whole numbers (up to 999,999)
Place values: tens, hundreds, thousands, ten thousands, hundred thousands
Distractors reflect common rounding errors: wrong direction, wrong place value, truncation
* Medium:
  Word-problem context requiring rounding
Stem pattern: "[Real-world context sentence]. What is this number rounded to the nearest [place value]?"
Numbers: 3-digit to 6-digit whole numbers (up to 999,999)
Place values: tens, hundreds, thousands, ten thousands, hundred thousands
Contexts: distances, populations, money, quantities, measurements
* Hard:
  NA

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Modeling Decimals
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.E
Standard Description: Represent decimals, including tenths and hundredths, using concrete and visual models.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Modeling Decimals
Lesson Order: 137.0
Standard ID: TEKS.MATH.CONTENT.4.2.E+1
Standard Description: Represent decimals, including tenths and hundredths, using concrete and visual models.

Key Concepts:
*None specified*

Learning Objectives:
* Identify the decimal value of a labeled point on a number line.
* Identify the decimal value represented by a shaded grid model.
* Identify which number line shows a point at a given decimal distance from zero.
* Select the grid model that represents a given decimal value.

Assessment Boundaries:
* Assessment is restricted to:
- Decimals limited to tenths and hundredths place values only (no thousandths or beyond).
- Grid models represent values less than 1 whole (0.01 to 0.99).
- Grid models use 10-by-10 grids where each column is one tenth and each small square is one hundredth.
- Number lines use whole numbers from 0 to 13, with intervals divided into 10 equal parts.
- Distance-from-zero number lines span up to 4 whole numbers (e.g., 0 to 4).
- Answers may be in numeric form or word form.
- No operations with decimals (no addition, subtraction, multiplication, or division).
- No conversion between fractions and decimals.
- No money contexts to represent decimals.

Common Misconceptions:
* Confuses tenths and hundredths when reading or naming a decimal value.
* Confuses tenths tick marks with hundredths on a number line.
* Miscounts shaded squares on grids or tick marks on number lines.
* Reads digits separately as a whole number instead of a decimal.

Difficulty Definitions:
* Easy:
  Tenths only or clear hundredths with values less than 1 (e.g., 0.4, 0.27).
Single grid model shown; student reads shaded parts directly.
Number line spans 2 whole numbers with tenths clearly marked.
Numeric form answers.
At least one obviously wrong distractor.
Single-step reasoning: count shaded parts and write the decimal.
* Medium:
  Hundredths values requiring careful counting (e.g., 0.53, 0.35).
Multiple grid models to compare and evaluate.
Word form answers with place-value naming (e.g., twenty-seven-hundredths).
Number line ranges spanning 3 or more whole numbers.
Distance-from-zero interpretation with tenths or hundredths.
Distractors that are numerically close (e.g., 8.2 vs 8.02).
Two-step reasoning: break apart the decimal, then match or compare.
* Hard:
  Hundredths on extended number lines with ranges spanning 4 or more whole numbers.
Decimal values very close together in distractors (e.g., 2.98 vs 2.89 vs 2.9).
Word form answers with place-value confusion traps (tenths vs hundredths naming).
Grid models requiring precise counting of both columns and extra squares.
Multiple reasoning steps: break apart, locate on the model, and verify.
Whole numbers up to 13 on number lines.

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Ordering Decimals using Models
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.F
Standard Description: Compare and order decimals using concrete and visual models to the hundredths.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Ordering Decimals using Models
Lesson Order: 139.0
Standard ID: TEKS.MATH.CONTENT.4.2.F+1
Standard Description: Compare and order decimals using concrete and visual models to the hundredths.

Key Concepts:
*None specified*

Learning Objectives:
* Determine which decimals from four grid models fall within a given range.
* Order three decimals represented by grid models from greatest to least.
* Order three decimals represented by grid models from least to greatest.

Assessment Boundaries:
* Assessment is restricted to:
- Decimals limited to tenths and hundredths place values only (no thousandths or beyond).
- Grid models use 10-by-10 grids where each column is one tenth and each small square is one hundredth.
- Values may be less than 1 (single grid) or between 1 and 2 (two grids side by side, first fully shaded for 1 whole).
- Ordering involves exactly 3 decimal values for least-to-greatest and greatest-to-least tasks.
- Range comparison involves exactly 4 grid models compared to two boundary values.
- Boundary values for range comparisons are given as decimals to the tenths or hundredths (e.g., greater than 1.60 but less than 1.90).
- No operations with decimals (no addition, subtraction, multiplication, or division).
- No conversion between fractions and decimals.
- Answers are in numeric form only (no word form).

Common Misconceptions:
* Compares hundredths digits without first comparing the tenths digits.
* Includes or excludes a boundary value when comparing to a range.
* Miscounts shaded columns or extra squares when reading a grid model.
* Reverses the order direction, writing greatest to least instead of least to greatest.

Difficulty Definitions:
* Easy:
  Order three decimals from least to greatest using grid models.
Values less than 1 (single grid per value).
Decimal values have different tenths digits (e.g., 0.35, 0.58, 0.72), so no hundredths comparison needed.
Grid models have clear, countable shading.
At least one obviously wrong distractor in answer options.
Single-pass reasoning: read models, compare tenths digits, write order.
* Medium:
  Order three decimals from greatest to least using grid models.
Values less than 1 (single grid per value).
At least two decimal values share the same tenths digit (e.g., 0.41 and 0.47), requiring hundredths comparison.
Distractors include reversed order (least to greatest instead of greatest to least) and orders reflecting miscounted shading.
Two-step reasoning: read models, compare tenths, then compare hundredths when tied.
* Hard:
  Determine which decimals from four grid models fall within a given range.
Values may be greater than 1 (two grids per value, first fully shaded for 1 whole).
Must compare each decimal to two boundary values and determine inclusion or exclusion.
At least one value below the lower boundary and at least one value above the upper boundary.
Distractors include one extra value (over-inclusion) or one missing value (under-inclusion).
Multi-step reasoning: read four models, compare each to two boundaries, filter qualifying values.

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Relating Decimals to Fractions with Tenths and Hundredths
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.G
Standard Description: Represent and explain the relationship between decimals and fractions with denominators of 10 and 100.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Relating Decimals to Fractions with Tenths and Hundredths
Lesson Order: 142.0
Standard ID: TEKS.MATH.CONTENT.4.2.G+1
Standard Description: Represent and explain the relationship between decimals and fractions with denominators of 10 and 100.

Key Concepts:
*None specified*

Learning Objectives:
* Convert a decimal to the fraction or mixed number with the same value using a denominator of 10 or 100.
* Convert a fraction or mixed number with a denominator of 10 or 100 to the decimal with the same value.
* Identify which number sentence correctly shows a decimal and fraction with the same value.

Assessment Boundaries:
* Assessment is restricted to:
- Fractions are limited to denominators of 10 and 100
- Whole number parts of decimals and mixed numbers do not exceed 100
- No operations beyond conversion (no adding, subtracting, multiplying, or dividing fractions or decimals)
- No simplification to denominators other than 10 or 100

Common Misconceptions:
* Confuses tenths with hundredths when determining the denominator.
* Places extra digits after the decimal based on denominator digit count.
* Splits the numerator into separate whole and decimal parts incorrectly.
* Uses decimal digits as the numerator without considering place value.

Difficulty Definitions:
* Easy:
  Convert between a decimal with one decimal place (tenths) and a fraction with a denominator of 10
Whole number parts are less than 20
No zeros as placeholders in the decimal
* Medium:
  Convert between a decimal with two decimal places (hundredths) and a fraction with a denominator of 100
Whole number parts up to 100
May include a zero in the tenths place as a placeholder (e.g., 0.04 = 4/100)
May include real-world context
* Hard:
  Evaluate multiple decimal-fraction equations to determine which is correct
May involve improper fractions with denominators of 10 or 100 that require rewriting as mixed numbers (e.g., 170/100 = 1.7)

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Decimals on the Number Line
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.H
Standard Description: Determine the corresponding decimal to the tenths or hundredths place of a specified point on a number line.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Decimals on the Number Line
Lesson Order: 138.0
Standard ID: TEKS.MATH.CONTENT.4.2.H+1
Standard Description: Determine the corresponding decimal to the tenths or hundredths place of a specified point on a number line.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the decimal to the hundredths place of a point on a number line.
* Determine the decimal to the tenths place of a point on a number line.
* Identify which number line shows a given decimal in hundredths as a distance from zero.
* Identify which number line shows a given decimal in tenths as a distance from zero.

Assessment Boundaries:
* Assessment is restricted to:
- Decimals limited to tenths and hundredths place values only (no thousandths or beyond).
- Number lines use whole numbers from 0 to 13, with intervals divided into 10 equal parts for tenths.
- Hundredths number lines zoom into a section between two consecutive tenths, divided into 10 equal parts.
- Distance-from-zero number lines span up to 4 whole numbers (e.g., 0 to 4).
- Answers are in numeric form only (no word form).
- No operations with decimals (no addition, subtraction, multiplication, or division).
- No conversion between fractions and decimals.
- No money contexts to represent decimals.

Common Misconceptions:
* Confuses tenths and hundredths when reading a point on a number line.
* Confuses the direction of counting from zero on a number line.
* Miscounts tick marks on a number line to determine the decimal value.
* Reads the wrong whole number section of the number line for the point.

Difficulty Definitions:
* Easy:
  Tenths only: determine the decimal to the tenths place of a point, or identify the correct number line for a given tenths decimal.
Number line spans 2 whole numbers with 10 clearly marked equal parts.
Whole numbers from 0 to 11. Single-step reasoning.
* Medium:
  Hundredths: determine the decimal to the hundredths place on a zoomed-in number line.
Number line spans 2 tenths values with 10 equal parts.
Distractors numerically close. Two-step reasoning.
* Hard:
  Hundredths distance from zero: identify which number line shows a hundredths decimal.
Number line spans up to 4 whole numbers. Multiple reasoning steps.
Whole numbers up to 13 on number lines.

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2
Cluster Name: The student applies mathematical process standards to represent, compare, and order whole numbers and decimals and understand relationships related to place value.
Lesson Name: Interpreting Relationships Between Place Values
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2A
Standard Description: Interpret the value of each place-value position as 10 times the position to the right and as one-tenth of the value of the place to its left

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.2+1
Cluster Name: The student applies mathematical process standards to solve problems involving whole number operations.
Lesson Name: Rounding Whole Numbers
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.2.D
Standard Description: Round whole numbers to a given place value through the hundred thousands place.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Decomposing Fractions without Models
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.A
Standard Description: Decompose a fraction into a sum of fractions with the same denominator without models.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Decomposing Fractions without Models
Lesson Order: 144.0
Standard ID: TEKS.MATH.CONTENT.4.3.A+1
Standard Description: Decompose a fraction into a sum of fractions with the same denominator without models.

Key Concepts:
*None specified*

Learning Objectives:
* Identify an equivalent expression that decomposes a fraction as a sum of unit fractions with the same denominator.

Assessment Boundaries:
* Assessment is restricted to:
- Fractions a/b where b is a whole number from 2 to 10
- Numerators a range from 2 to 12
- Includes improper fractions (a > b)
- Decomposition is exclusively into unit fractions (each addend is 1/b with the same denominator as the original fraction)
- No visual models, area models, fraction bars, or number lines

Common Misconceptions:
* Confuses numerator and denominator, writing unit fractions with the numerator as denominator.
* Uses fractions with different denominators instead of the same denominator.
* Uses non-unit fractions as addends instead of decomposing into unit fractions.
* Writes the wrong count of unit fractions or uses non-unit fraction addends.

Difficulty Definitions:
* Easy:
  Proper fractions (a ≤ b) or simple improper fractions with denominators 2–8
Numerators 2–8
At least one distractor uses a different denominator or is obviously incorrect
* Medium:
  Improper fractions (a > b) with denominators 2–10
Numerators up to 12
All distractors use the same denominator, requiring careful counting of unit fractions
* Hard:
  N/A

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Decomposing Fractions Greater than One with Models
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.B
Standard Description: Break apart fractions into smaller equal parts using visual models to show equivalent representations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Decomposing Fractions Greater than One with Models
Lesson Order: 143.0
Standard ID: TEKS.MATH.CONTENT.4.3.B+1
Standard Description: Break apart fractions into smaller equal parts using visual models to show equivalent representations.

Key Concepts:
*None specified*

Learning Objectives:
* Given a blank fraction bar model and an improper fraction, identify the number sentence that shows two different ways the fraction can be represented as sums of fractions with like denominators.
* Given a composite fraction bar model representing a whole number greater than one, identify the expression that CANNOT be used to represent the number as a sum of fractions with like denominators.
* Given a fraction value and a blank model, identify the expression that does NOT represent the fraction as a sum of fractions with like denominators.
* Given a shaded fraction strip model representing a mixed number greater than 1, identify the equation that shows two different decompositions of the mixed number as sums of fractions with like denominators.

Assessment Boundaries:
* Assessment is restricted to:
- Fractions with denominators of 2, 3, 4, 5, 6, 8, and 10
- Fraction values greater than 1 (improper fractions, mixed numbers, or whole numbers expressed as improper fractions)
- Decompositions use only fractions with the same denominator as the original fraction
- No operations beyond addition of fractions with like denominators
- Models are fraction strip or fraction bar models showing equal parts

Common Misconceptions:
* Adds numerators and denominators instead of only the numerators.
* Counts the number of addends instead of computing the sum.
* Misreads the shaded model and determines the wrong fraction value.
* Verifies only one side of an equation instead of both sides.

Difficulty Definitions:
* Easy:
  Fraction value is stated in the question stem (blank model provided)
Each answer choice is a single expression (sum of fractions)
2 to 4 addends per expression
Denominators 2 to 6
* Medium:
  Fraction value may need to be derived from a shaded or composite model
Answer choices may be equations (sum = sum) or single expressions
Up to 5 addends per expression or per side of an equation
Denominators 2 to 10
* Hard:
  Fraction value must be derived from a pre-shaded model
Answer choices are equations with two decompositions (sum = sum)
Both sides of the equation must be verified against the model value
Up to 7 addends per expression or per side

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Comparing Fractions with Models
Lesson Order: 145.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+3
Standard Description: Compare two fractions with different numerators and denominators using area models and number lines.

Key Concepts:
*None specified*

Learning Objectives:
* Given an area model representing a fraction, identify a fraction less than the value shown.
* Given an area model representing a fraction, identify all fractions less than the value shown.
* Given two area models representing fractions, select the statement that correctly compares them using >, =, or <.

Assessment Boundaries:
* Assessment is restricted to:
- Fractions with denominators of 2, 3, 4, 5, 6, 8, 10, and 12
- Proper fractions and fractions equal to 1 whole (e.g., 10/10)
- Comparison using >, =, or < symbols only (no operations on fractions)
- Area models include rectangular (bar/grid) and circular models

Common Misconceptions:
* Compares only numerators and ignores denominators when fractions have unlike denominators.
* Miscounts shaded parts or total parts when reading a fraction from an area model.
* Reverses the same-numerator comparison rule, thinking a smaller denominator means a smaller fraction.

Difficulty Definitions:
* Easy:
  One area model provided with clearly shaded parts.
Compare the model's fraction to fractions with the same denominator or to benchmark fractions (0, 1/2, 1).
Single comparison needed.
* Medium:
  One area model provided.
Compare the model's fraction to fractions with different denominators.
Requires reasoning about relative sizes of fractions with unlike denominators.
* Hard:
  Two area models provided, each representing a different fraction with a different denominator.
Select the correct comparison statement using >, =, or <.
Must accurately read both models and compare the resulting fractions.

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.3+1
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Comparing Fractions without Models
Lesson Order: 146.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+4
Standard Description: Compare fractions with different numerators and denominators by creating common denominators or using benchmark fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Given a table of fraction values, determine which comparison statement is true.
* Given a word problem with improper fractions or mixed numbers, determine which comparison statement is true.
* Select the fraction that satisfies a given comparison with a reference fraction.

Assessment Boundaries:
* Assessment is restricted to:
- Fractions with different numerators and different denominators
- Denominators limited to: 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20
- Improper fractions allowed when value is less than 10
- Mixed numbers allowed
- No visual fraction models (circles, bars, area models) as stimuli
- Comparison using >, <, or = symbols only

Common Misconceptions:
* Assumes a larger denominator always means a smaller fraction, ignoring the numerator.
* Compares only numerators or only denominators instead of the overall fraction values.
* Reverses the comparison direction, selecting a value that satisfies the inverse relationship.
* Uses estimation shortcuts instead of finding common denominators: compares the difference between numerator and denominator (gap reasoning), or rounds fractions to the nearest whole number and concludes that fractions rounding to the same whole are equal.

Difficulty Definitions:
* Easy:
  Single comparison: select a fraction that is greater than or less than a reference fraction
Proper fractions only
Answer choices are 4 individual fraction values
One comparison required
* Medium:
  Table or list presents 3-5 items with fraction values
Student evaluates 4 comparison statements to find the true one
Proper fractions, may include unsimplified or equivalent fractions
Multiple comparisons required to eliminate distractors
* Hard:
  Word problem or table with improper fractions and/or mixed numbers
May require converting between improper fractions and mixed numbers before comparing
May involve verifying multiple pre-written comparisons (which are true?)
Includes equivalence recognition (fractions that equal each other)

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.4+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Adding and Subtracting Whole Numbers and Decimals: Word Problems
Lesson Order: 141.0
Standard ID: TEKS.MATH.CONTENT.4.4.A+2
Standard Description: Solve multi-step word problems involving addition and subtraction of whole numbers and decimals.

Key Concepts:
*None specified*

Learning Objectives:
* Solve a four-step word problem using addition and subtraction of whole numbers and decimals.
* Solve a one-step word problem using addition or subtraction of whole numbers and decimals given data in a table.
* Solve a one-step word problem using addition or subtraction of whole numbers and decimals.
* Solve a three-step word problem using addition and subtraction of whole numbers and decimals.
* Solve a two-step word problem combining addition and subtraction of whole numbers and decimals.

Assessment Boundaries:
* Assessment is restricted to:
- Addition and subtraction only
- Whole numbers up to 6 digits (values under 100,000)
- Decimal numbers up to 5 digits (values under 10,000)
- Decimals only to tenths and hundredths place
- Numbers may have different numbers of decimal places requiring alignment (e.g., tenths + hundredths, whole number + decimal)

Common Misconceptions:
* Adds values instead of subtracting when the problem asks for a difference.
* Fails to regroup correctly when adding or subtracting across place values.
* Ignores part of the given information and performs an incomplete calculation.
* Misaligns place values by right-aligning instead of aligning by decimal point.

Difficulty Definitions:
* Easy:
  One-step problem (single addition or subtraction)
Whole numbers only, each with at most 4 digits
At most one regrouping required
* Medium:
  One-step with decimals (to hundredths; may have different decimal places requiring alignment)
OR one-step with large whole numbers (5+ digits)
OR two-step problem (two operations) with whole numbers only
May include reading values from a table
At least one regrouping required
* Hard:
  Two-step problem (two operations) with decimals or a mix of whole numbers and decimals
OR multi-step problem (3 or more operations) with any number type
Multiple regroupings required

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.4+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Multiplying by 10 or 100
Lesson Order: 153.0
Standard ID: TEKS.MATH.CONTENT.4.4.B+1
Standard Description: Multiply by 10 or 100.

Key Concepts:
*None specified*

Learning Objectives:
* Find the product of a whole number and 10 or 100
* Solve a word problem that requires multiplying a whole number by 10 or 100

Assessment Boundaries:
* ## In Scope

- Whole numbers only (no decimals, no fractions)
- Multiplying by exactly 10 or exactly 100 (not by other multiples of 10)
- Numbers from 1 to 999,999 as the multiplicand
- Numbers with trailing zeros in the multiplicand (e.g., 476,500 x 100)
- All numbers >= 1,000 use commas in stems and answers (e.g., 47,650,000)
- STAAR numeral formatting: stems and options use numerals, not spelled-out numbers
- The word "product" in Easy stems; real-world context in Medium stems

## Out of Scope

- Multiplying by numbers other than 10 or 100 (no x1000, no x20, no x50)
- Division by 10 or 100
- Decimals or fractions in any operand or answer
- Multi-step problems (multiply then add, etc.)
- Algebraic expressions or variables
- Negative numbers

## Question Formats

### Easy -- MCQ NSB with 4 Text Options
- No stimulus image
- Exactly 4 answer options (A, B, C, D), all text (plain numbers)
- Single correct answer

### Medium -- MCQ NSB with 4 Text Options
- No stimulus image
- Exactly 4 answer options (A, B, C, D), all text (plain numbers)
- Single correct answer
- Word-problem context

Common Misconceptions:
* Adds the two numbers instead of multiplying them (e.g., 26 x 100 = 126 instead of 2,600).
* Appends too many or too few zeros to the product, misunderstanding the place-value shift (e.g., 476,500 x 100 = 476,500,000 instead of 47,650,000).
* Confuses multiplying by 10 with multiplying by 100, shifting digits one place instead of two or vice versa (e.g., 45 x 100 = 450 instead of 4,500).
* Loses trailing zeros from the original number when appending new zeros for the multiplication (e.g., 120 x 100 = 1,200 instead of 12,000).

Difficulty Definitions:
* Easy:
  Direct multiplication questions with no word-problem context
Stem pattern: "What is the product of [number] and [10 or 100]?"
Numbers: 1-digit to 6-digit whole numbers, including numbers with trailing zeros (e.g., 476,500)
Multiplier: 10 or 100
Distractors reflect common errors: addition instead of multiplication, wrong number of zeros, confusing x10 with x100
* Medium:
  Word-problem context requiring multiplication by 10 or 100
Stem pattern: "[Context sentence with a quantity and groups of 10 or 100]. How many [total items]?"
Numbers: 2-digit to 4-digit whole numbers multiplied by 10 or 100
Contexts: packs, boxes, sets, cases, bags with 10 or 100 items each
Distractors reflect common errors: addition instead of multiplication, wrong number of zeros, confusing x10 with x100
* Hard:
  NA

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.4+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Using Rounding to Estimate Solutions
Lesson Order: 152.0
Standard ID: TEKS.MATH.CONTENT.4.4.G+1
Standard Description: Round to the nearest 10, 100 or 1000 to estimate solutions for whole number operations.

Key Concepts:
*None specified*

Learning Objectives:
* Estimate the total of a set of whole numbers shown in a table by rounding and adding
* Identify which expression has a result closest to a given estimate

Assessment Boundaries:
* ## In Scope

- Whole numbers only (no decimals, no fractions)
- Rounding to the nearest 10, 100, or 1000 to produce estimates
- Operations: addition (summing table values for Easy), division, multiplication, addition, subtraction (for Medium)
- "Best estimate" and "about" language in stems
- Table-based data for Easy (stimulus image); expression-based for Medium (no stimulus)
- All numbers ≥ 1,000 use commas in stems and answers (e.g., 1,100 not 1100)
- STAAR numeral formatting: stems and options use numerals, not spelled-out numbers
- Each Easy question uses values of similar magnitude so a single rounding place applies to all

## Out of Scope

- Exact computation (questions ask for estimates, not exact answers)
- Decimals or fractions in any operand or answer
- Rounding to places beyond thousands (no ten thousands, no hundred thousands)
- Multi-step estimation (estimate, then estimate the estimate)
- Mixed operations within a single expression (e.g., no "3 × 5 + 2")
- Negative numbers
- Expressions with more than two operands

## Question Formats

### Easy — MCQ SB (Stimulus-Based) with 4 Text Options
- Stimulus: table image rendered by `draw_data_table`
- Exactly 4 answer options, each a rounded estimate (plain number with units if applicable)
- Single correct answer

### Medium — MCQ NSB (No Stimulus) with 4 Text Options
- No stimulus image
- Each of the 4 answer options is a math expression (e.g., "36 ÷ 5")
- Single correct answer (the expression whose result is closest to the target)

Common Misconceptions:
* Computes the exact total of all values in the table instead of rounding each value first, selecting the exact sum when it appears as a distractor.
* Rounds only one value in the table and uses exact values for the rest, producing an incorrect mixed estimate that is close to but not equal to the correct answer.
* Rounds to the wrong place value when estimating (e.g., rounds to the nearest 10 when nearest 100 is appropriate, producing an estimate that is too precise or too rough).
* When estimating quotients or products, picks an expression where one operand equals the target number rather than one where the result approximates it (e.g., for "quotient of about 7," selects 7 ÷ 2 instead of 36 ÷ 5).

Difficulty Definitions:
* Easy:
  Table showing real-world data (3-8 rows, 2-3 columns including a numeric column)
Stem asks for the best estimate of a combined or total value from the table
Student rounds each numeric value to the nearest 10, 100, or 1000, then sums
Rounding place determined by the magnitude of values: nearest 100 for 3-digit values, nearest 1,000 for 4-digit values
Contexts: travel distances, items sold per day, quantities collected, event attendance
* Medium:
  Each answer option is a math expression (e.g., 36 ÷ 5, 23 × 8)
Stem: "Which expression has a [quotient/product/sum/difference] of about [target number]?"
Student estimates each expression using rounding or mental math to find the one closest to the target
Operations: division, multiplication, addition, or subtraction of whole numbers
All operands are whole numbers between 2 and 999
* Hard:
  NA

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.4+2
Cluster Name: The student applies mathematical process standards to solve problems involving whole number operations.
Lesson Name: Multiplying by 10 or 100
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.4.B
Standard Description: Multiply by 10 or 100.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.4+2
Cluster Name: The student applies mathematical process standards to solve problems involving whole number operations.
Lesson Name: Using Rounding to Estimate Solutions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.4.G
Standard Description: Round to the nearest 10, 100 or 1000 to estimate solutions for whole number operations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.5+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: MultiStep Problems Using Strip Diagrams
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.5.A
Standard Description: Solve multistep problems using strip diagrams.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade Supporting Lessons
Unit ID: Math Grade 4 Unit 17
Unit Name: Hole-Filling Lessons
Cluster ID: TEKS.MATH.CONTENT.4.5+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: MultiStep Problems Using Strip Diagrams
Lesson Order: 160.0
Standard ID: TEKS.MATH.CONTENT.4.5.A+1
Standard Description: Solve multistep problems using strip diagrams.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real-world problem, identify the strip diagram that represents a multi-step situation involving a times-as-many relationship and combining.
* Given a real-world problem, identify the strip diagram that represents a multi-step situation involving combining amounts and then dividing equally.
* Given a real-world problem, identify the strip diagram that represents a multi-step situation involving removing a part (by subtraction or by finding a fraction of the total) and then dividing equally.
* Given a real-world problem, identify the strip diagram that represents a multi-step subtraction situation to find a remaining quantity.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only (no fractions, decimals, or negative numbers)
- All values in the problem and in intermediate calculations are less than 200
- Problems involve exactly two operations from the four operations (+, −, ×, ÷)
- Strip diagrams use a single letter to represent the unknown quantity
- All problems are set in real-world contexts
- STAAR may use select-two (multiselect) format combining strip diagram and equation representations

Common Misconceptions:
* Adds all given quantities instead of identifying which to subtract.
* Completes only the first operation and omits the second step in the strip diagram.
* Reverses the roles of the known values and the unknown in the strip diagram.
* Selects the wrong operation for one step in the multi-step problem.

Difficulty Definitions:
* Easy:
  Two operations of the same type (e.g., subtract then subtract) or a straightforward combine-then-identify pattern
Strip diagram shows a clear part-part-whole structure with no equal-group subdivision
All values in the problem are less than 50
The unknown is a remaining part or a simple total
* Medium:
  Two operations of different types (e.g., subtract then divide, or add then divide)
Strip diagram combines a partition or combination step with an equal-groups step
All values in the problem are less than 100
The unknown may be a per-unit quantity (rate) or a computed total
* Hard:
  Two operations of different types with a less direct relationship (e.g., divide then divide, or a times-as-many comparison combined with addition)
May require identifying multiple correct representations (strip diagrams and equations)
Values in the problem may exceed 100
Strip diagram structure requires recognizing an implicit intermediate step (e.g., finding half before subdividing further)

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Identifying Correct Fraction Comparisons
Lesson Order: 129.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+1
Standard Description: Identify correct inequality statements comparing two or more fractions presented in visual models, word problems, or tables.

Key Concepts:
*None specified*

Learning Objectives:
* Given a table with multiple fraction values, determine which comparison statement is true
* Given a word problem, determine which inequality statement correctly compares fractions.
* Given two fraction circles with custom shading (one uses non-consecutive sector shading), determine which inequality statement correctly compares the two fractions.

Assessment Boundaries:
* Assessment is restricted to:

Questions present two or more rational values (fractions and/or mixed numbers) and ask students to identify the TRUE comparison statement.
Answer choices are comparison statements using only these symbols: >, <, =, or "None of this".
Values in the answers (not in the stimulus requirements) must be written using LaTeX:
Proper or improper fractions: \frac{numerator}{denominator}
Mixed numbers: whole\frac{numerator}{denominator}
Denominators are limited to: 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20.
Improper fractions are allowed in word-problem and table questions, and may also appear in answer choices.
Constraint for grade-level rigor: if an improper fraction is used, it must represent a value less than 10 and use an allowed denominator.
Fraction-models must use proper fractions only in the stimulus because the model generator requires numerator <= denominator.

Contexts may be:
Visual fraction circles (models),
Short real-world word problems (numbers),
Tables of names/items with fraction values (tables).

Items must be solvable using grade-appropriate strategies (benchmarks, equivalence, common denominators, mixed-number comparison).

Common Misconceptions:
* Students assume a fraction with a larger denominator is always smaller, without considering the numerator
* Students compare only numerators or only denominators instead of comparing the overall fraction values
* Students misread visual fraction models, either counting total sections incorrectly or miscounting shaded parts
* Students select "equal" when fractions look similar but have different values, failing to convert to common denominators to verify

Difficulty Definitions:
* Easy:
  **

  - Two visual fraction models (shaded circles) are shown
  - Students determine which inequality correctly compares the two fractions
  - Answer choices are three comparison statements (>, =, <) plus "None of these"
  - Fractions can be read directly from the visual model
  - Stem exactly:
Each circle represents a fraction.<br/><br/>
Which statement correctly compares the two fractions?


**
* Medium:
  **

A word problem includes 2–3 values as fractions and/or mixed numbers (improper fractions allowed).
Students choose the true comparison statement among the options.
Requires comparing values with different denominators and/or values greater than 1.

**
* Hard:
  **

A table shows 4–6 names/items with fraction/mixed-number values.
Students choose the true comparison statement referencing specific table rows.
Requires selecting the correct pair from multiple values and comparing accurately.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Comparing Multiple Fractions
Lesson Order: 130.0
Standard ID: TEKS.MATH.CONTENT.4.3.D+2
Standard Description: Find fractions or identify items that satisfy a given comparison relationship in word problems and tables.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

- Questions present a reference fraction and ask students to find a value that is greater/less than it
- Answer choices are individual fraction VALUES (not inequality statements)
- OR answer choices are NAMES/ITEMS that satisfy the comparison (qualitative answers)
- Contexts include real-world scenarios: measurements, task completion percentages, amounts

Common Misconceptions:
* Students assume a smaller denominator always means a larger fraction, leading them to incorrect conclusions (e.g., thinking 2/3 > 3/4 because 3 < 4).
* Students compare correctly but select a value satisfying the inverse relationship—choosing a larger value when asked for "less than" or a smaller value when asked for "greater than."
* Students fail to recognize that fractions like 10/15 and 2/3, or 6/8 and 3/4, are equal—leading to incorrect comparisons when unsimplified fractions appear.
* Students select a fraction equal to the reference value when asked for "greater than" or "less than," failing to understand that equality does not satisfy a strict inequality.

Difficulty Definitions:
* Easy:
  **

  - Word problem states a reference fraction and a comparison relationship (greater than, less than)
  - Students select which fraction value could satisfy the relationship
  - Answer choices are 4 individual fraction values
  - Single comparison required
  - Contexts: thickness, weight, volume, time, amounts

**
* Medium:
  **

  - Table presents 4+ people/items with fraction values
  - Question asks which people/items are greater than (or less than) a reference fraction
  - Answer choices are qualitative: names or groups (e.g., "Nate and Marc only", "Rudy only")
  - Requires comparing multiple fractions to the reference value
  - Contexts: task completion, survey results, test scores

**
* Hard:
  **

  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Multi-Step Fraction Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.3.F
Standard Description: Solve multi-step word problems involving the addition and subtraction of fractions with like denominators to meet STAAR-level rigor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Subtraction Word Problems Involving Fraction Models
Lesson Order: 131.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+1
Standard Description: Subtract fractions using visual models.

Key Concepts:
*None specified*

Learning Objectives:
* Find the answer to a subtraction using one fraction model.
* Write a subtraction expression using one fraction model.
* Write a subtraction expression using two fraction models.

Assessment Boundaries:
* - Subtraction of fractions with like denominators (same denominator)
- Denominators from 4 to 12
- Proper fractions only (numerator < denominator)
- Real-world contexts: pizza, ribbon, book, trail, etc.

Common Misconceptions:
* Changing the denominator incorrectly when writing the expression (e.g., writing 16/40 − 13/40 instead of keeping the common denominator of 20).
* Confusing the combined fraction with one person's fraction in one-model problems (e.g., if the model shows 5/9 combined and Darrell ate 2/9, mistakenly thinking 5/9 is Nani's fraction instead of the combined amount).
* Confusing the denominator with the numerator when reading the fraction from the model (e.g., if 13 out of 20 parts are shaded, writing 20/13 instead of 13/20).
* Writing the fractions in the wrong order when setting up a subtraction expression (e.g., writing 13/20 − 16/20 instead of 16/20 − 13/20 when finding the difference between a larger and smaller fraction).

Difficulty Definitions:
* Easy:
  - TWO labeled fraction models (pie or bar)
  - Question asks "Which expression can be used to find the difference?"
  - Student reads fractions from both models
* Medium:
  - ONE unlabeled fraction model
  - One fraction stated in stem
  - Question asks "Which expression can be used to find the fraction that [Person B] [action]?"
* Hard:
  - ONE unlabeled fraction model
  - One fraction stated in stem
  - Question asks "What fraction did [Person B] [action]?"

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Determining the Remaining Fraction of a Whole
Lesson Order: 132.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+2
Standard Description: Determining the remaining fraction of a whole

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

**General Constraints:**
- All items are MCQ with exactly four answer options
- Fractions have denominators from 4 to 12
- All fractions are proper fractions (numerator < denominator)

**Question Format:**

Type 1 (EASY - With Visual Model):
- Stimulus: Circular fraction model with shaded and unshaded sections
- Shaded sections represent the given part; unshaded sections represent the remaining part
- Question asks for the remaining (unshaded) fraction
- Answer options: Four fractions with the same denominator
- Model clearly shows equal division lines
- Shaded sections MUST align exactly with division lines (no partial shading)

Type 2 (MEDIUM - Without Visual Model):
- NO visual stimulus
- Word problem provides a fraction representing part of a whole
- Question asks for the remaining fraction
- Student must convert 1 to n/n and subtract
- Answer options: Four fractions with the same denominator as the given fraction

If there is a fraction in answer options, it should be written as $\frac{_}{_}$, $\frac{_}{_}$

Common Misconceptions:
* Confusing which part the question asks for—the given part versus the remaining part—especially with varied wording like "left," "remains," or "not used."
* Making arithmetic errors when subtracting from 1, such as forgetting to convert 1 to n/n or subtracting incorrectly
* Miscounting the shaded or unshaded sections in the visual model, especially when the model has many divisions.
* Stating the given fraction as the answer instead of finding the remaining fraction

Difficulty Definitions:
* Easy:
  - Visual fraction model (circular) provided
  - Shaded sections represent the given part
  - Student counts unshaded sections to find remaining fraction
* Medium:
  - NO visual model
  - Word problem states a fraction representing part of a whole
  - Student calculates: 1 − (given fraction) = remaining fraction
  - Must convert 1 to equivalent fraction (n/n) before subtracting
* Hard:
  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.3
Cluster Name: The student applies mathematical process standards to represent and generate fractions to solve problems.
Lesson Name: Word Problems Involving Comparing Fractions to Benchmarks
Lesson Order: 133.0
Standard ID: TEKS.MATH.CONTENT.4.3.F+3
Standard Description: Finding the remaining fraction and comparing it to benchmark fractions.

Key Concepts:
*None specified*

Learning Objectives:
* Find the remaining fraction of a whole and identify the closest benchmark from multiple options (1/4, 1/2)

Assessment Boundaries:
* **General Constraints:**
- All items are MCQ with exactly four answer options
- NO visual stimulus/models
- All fractions are proper fractions (numerator < denominator)
- Denominators range from 3 to 15
- Benchmark fractions: 1/4, 1/2, 3/4
- Exactly ONE answer option is correct
- All distractors must be strictly incorrect (no “also true” statements)
- Answer options must be mutually exclusive (no overlaps / subset relationships)
- Prohibit “None left / 0 left” options
- Prohibit mixing “About [benchmark] …” with “Exactly [benchmark] …” in the same option set
- Stem type must match choice type:
  - If stem says “closest,” all options must be benchmark-comparison candidates for closeness (not generic truth statements)
  - If stem says “Which statement is true?”, options must be truth-evaluable and constructed so only one is true
- Consistent fraction formatting across stem, options, and explanations (do not mix LaTeX and plain slash notation)
- Answer options are statements comparing the remaining amount to benchmark(s)
- Questions ask "Which is closest to the fraction left?" or "Which statement is true?"

**Fraction Constraints by Level:**
- EASY/MEDIUM: One fraction given; student finds complement (1 − fraction)
- HARD: Two fractions given; student adds them, then finds complement

**Answer Option Format:**
- "Less than [benchmark] of the [item] was left."
- "About [benchmark] of the [item] was left."
- "More than [benchmark] of the [item] was left."
- "[Person] will have more/less than half [item] left."
- "Exactly [benchmark] of the [item] was left."

**Context Requirements:**
- Food items: cereal, pizza, pie, cake, chips
- Collections: cards, stickers, coins, books
- Tasks: homework, project, book pages
- Products: chip flavors, muffin types
- Use diverse names from various backgrounds

Common Misconceptions:
* Confusing what remains with what was used/given away, especially when answer options include statements about both (e.g., selecting "Greg will sell more than half" when asked about what's left).
* Forgetting to add both fractions before subtracting from 1, or making errors when converting unlike denominators to find a common denominator.
* Incorrectly comparing the remaining fraction to benchmark fractions
* Stating the given fraction as the remaining fraction instead of finding the complement

Difficulty Definitions:
* Easy:
  **
  - ONE fraction given representing portion used/consumed
  - Find remaining: 1 − (given fraction)
  - Compare to ONE benchmark: 1/2 only
  - Answer options reference 1/2: "more than half," "less than half," "exactly half", 1/3 or 1/4.
  - Denominators: 3, 4, 5, 6, 8
  - Like denominators only (no conversion needed for comparison)

**
* Medium:
  **
  - ONE fraction given representing portion used/consumed
  - Find remaining: 1 − (given fraction)
  - Compare to TWO benchmarks: 1/4 and 1/2
  - Answer options reference both 1/4 and 1/2: "Less than 1/4," "About 1/4," "Less than 1/2," "About 1/2"
  - Denominators: 5, 6, 8, 9, 10, 12
  - Student must determine which benchmark is closest

**
* Hard:
  **
  - TWO fractions given representing different portions
  - Add the fractions (may require finding common denominator)
  - Find remaining: 1 − (sum of fractions)
  - Compare to ONE benchmark: 1/2
  - Answer options are statements: "more than half left," "less than half left," "exactly half left," etc.
  - Denominators: 3, 4, 5, 6, 8, 10, 12, 15
  - May have like or unlike denominators
  - Sum of fractions must be < 1

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.4
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for whole number computations and decimal sums and differences in order to solve problems with efficiency and accuracy.
Lesson Name: Multi-Step Word Problems with Money
Lesson Order: 121.0
Standard ID: TEKS.MATH.CONTENT.4.4.A+1
Standard Description: Solve multi-step word problems involving the addition and subtraction of money using decimals to the hundredths place.

Key Concepts:
*None specified*

Learning Objectives:
* Solve multi-step word problems involving money by calculating profit. Problems require understanding that profit is the difference between the amount received from selling and the amount spent on buying.

Assessment Boundaries:
* Assessment is restricted to:

- Question stem must be a real-world scenario and 20-120 words in length.
- Monetary amounts must be in U.S. dollars and cents using decimal notation.
- All amounts must be positive and less than or equal to $1,000.00.
- Contexts must be real world, age and grade appropriate.
- Answers must include the dollar sign and two decimal places for cents.
- For currency representation with dollar symbol ($), use forward slash (/) to escape it so it is not interpreted as LaTeX (e.g., use \$ instead of $).


CHARACTER NAMES (Randomly select from this name list):
Emma, Olivia, Noah, Ethan, Mason, Isabella, Lucas, Aiden, Jackson, Amelia, Sebastian, Harper, Mateo, Evelyn, Benjamin, Abigail, James, Emily, Alexander, Ella, William, Scarlett, Daniel, Grace, Henry, Chloe, Michael, Victoria, Owen, Riley, Samuel, Aria, David, Lily, Joseph, Zoey, Carter, Penelope, Wyatt, Layla, John, Nora, Luke, Hannah, Gabriel, Sofia, Leo, Camila, Nathan, Aurora, Caleb, Luna, Elijah, Stella, Isaac, Violet, Ryan, Hazel, Jack, Ivy, Dylan, Ruby, Jaxon, Maya, Levi, Aaliyah, Adrian, Savannah, Kai, Paisley, Jayden, Elena, Eli, Naomi, Marcus

Common Misconceptions:
* Adding buying cost instead of subtracting: Students may incorrectly add the buying cost to the total selling amount instead of subtracting it, resulting in a larger amount than the correct answer. This reflects a misunderstanding of what profit means.
* Confusing buying cost with profit: Students may select the buying cost as the answer, confusing the amount spent with the amount earned. This indicates a fundamental misunderstanding of the profit concept.
* Forgetting to subtract buying cost: Students may correctly calculate the total selling amount by adding all three selling prices, but forget to subtract the buying cost, resulting in selecting the total selling amount as the answer instead of the profit.
* Making addition errors when totaling selling prices: Students may understand the profit calculation process but make mistakes when adding the three individual selling prices together, such as misaligning decimal places, forgetting to carry over, or adding incorrectly.

Difficulty Definitions:
* Easy:
  -Solve multi-step word problems involving money by calculating total costs using repeated addition (adding the unit price the required number of times) combined with addition.
* Medium:
  -Solve multi-step word problems involving money by calculating remaining money after a purchase. Problems require adding different denominations of money (bills and coins) to find the initial total, then subtracting the purchase cost to find how much money remains. Denominations MUST be described using proper monetary terminology (e.g., "two $10 bills", "one $5 bill", "four dimes", "six pennies", "three quarters", "two nickels") OR 
  -Solve multi-step word problems involving money by calculating change from a bill or gift card. Problems involve purchasing 2-3 items (with at least one item having a quantity greater than 1), requiring multiplication (unit price × quantity), addition (sum of all items), and subtraction (change from the amount paid).
* Hard:
  -Solve multi-step word problems involving money by calculating profit. Problems require understanding that profit is the difference between the amount received from selling and the amount spent on buying.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.5
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Additive Area Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.5.D
Standard Description: Solve real-world problems by calculating the area of shapes using given models and side lengths.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.5
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Compound Area Problems with Missing Side Lengths
Lesson Order: 126.0
Standard ID: TEKS.MATH.CONTENT.4.5.D+1
Standard Description: Solve real-world problems by calculating the area of shapes using given models and side lengths.

Key Concepts:
*None specified*

Learning Objectives:
* Given a real world context and a side-by-side rectangles model for the context, find the area of the left shaded rectangle
* Given a real world context and a side-by-side rectangles model for the context, find the area of the right shaded rectangle
* Given a real world context and a stacked rectangles model for the context, find the area of the bottom shaded rectangle
* Given a real world context and a stacked rectangles model for the context, find the area of the top shaded rectangle

Assessment Boundaries:
* Assessment is restricted to:
- All shapes mentioned must be squares or rectangles.
- All side lengths must be single-digit or double-digit integers.

Common Misconceptions:
* Confuses area with perimeter, adding side lengths instead of multiplying length and width.
* Counts squares along one side only, ignoring two-dimensional coverage.
* Subtracts given lengths incorrectly to find missing side of a rectangular section.
* Uses entire model’s dimensions rather than the specific rectangular section’s dimensions.

Difficulty Definitions:
* Easy:
  - All side lengths are single-digits
* Medium:
  - Involves single-digit and double-digit side lengths
* Hard:
  - All side lengths are double-digits

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Lines of Symmetry
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.6.B
Standard Description: Identify and classify figures based on the number of lines of symmetry they possess.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Lines of Symmetry
Lesson Order: 122.0
Standard ID: TEKS.MATH.CONTENT.4.6.B+1
Standard Description: Identify and classify figures based on the number of lines of symmetry they possess.

Key Concepts:
*None specified*

Learning Objectives:
* Identify which line is NOT a line of symmetry

Assessment Boundaries:
* Two-dimensional figures only, including basic shapes (triangles, rectangles, squares, 
circles, parallelograms, trapezoids, pentagons, hexagons, octagons) and compound shapes 
made by combining basic shapes.

Figures presented as visual images without measurements or coordinates.

Students count or compare the number of lines of symmetry, not draw or construct them.

Questions ask students to identify or select figures based on symmetry criteria such as:
  • Exactly n lines of symmetry (e.g., exactly 2)
  • At least n lines of symmetry (e.g., at least 1)
  • n or more lines of symmetry (e.g., 2 or more)
  • Fewer than n lines of symmetry
  • Zero lines of symmetry
  • Has horizontal but NOT vertical line of symmetry

For MEDIUM questions ONLY this question: 
Which figures have a horizontal line of symmetry but NOT a vertical line of symmetry?

No three-dimensional shapes or rotational symmetry (only reflection symmetry).

Common Misconceptions:
* Students assume all regular-looking or "balanced" shapes have lines of symmetry (missing that parallelograms and scalene triangles have zero), or believe that having a vertical line of symmetry means the shape must also have a horizontal one
* Students either stop counting after finding one or two obvious lines (missing diagonal lines in squares or additional lines in regular polygons), or double-count by treating the same fold from opposite directions as two separate lines
* Students identify any line that divides a shape into two equal areas as a line of symmetry, without verifying that the halves are exact mirror images when folded along that line
* Students mix up vertical (up-down) and horizontal (left-right) orientations, misclassify diagonal lines as vertical or horizontal, or fail to recognize symmetry orientation when figures are rotated

Difficulty Definitions:
* Easy:
  - Identify or select one or more figures based on a specified symmetry criterion.
  - Questions may involve selecting a single figure that matches the criterion OR selecting all figures from a set that satisfy the condition.
  - Figures include basic shapes (squares, rectangles, circles, triangles, parallelograms, trapezoids, pentagons, hexagons, octagons) and compound shapes made by combining basic shapes.
  - Figures may be oriented in any direction (not always vertical/horizontal alignment).
  - Criteria use clear language such as: "exactly n lines of symmetry," "at least n lines of symmetry," "n or more lines of symmetry," "fewer than n lines of symmetry," or "zero lines of symmetry."
  - Typically 2-6 answer choices; may have single or multiple correct selections.
  - Students count lines of symmetry for each figure and apply the criterion to determine valid selection(s).
* Medium:
  - Questions may use compound criteria requiring students to evaluate multiple 
  symmetry conditions:
 Override: Only this question:
Which figures have a horizontal line of symmetry but NOT a vertical line of symmetry?
* Hard:
  - Given a shape with labeled lines drawn through it, students must identify which ONE line is NOT a true line of symmetry. The shape displays actual symmetry line(s) plus one distractor (fake line).
  - The question should follow this pattern: "[N] lines are drawn through this shape. One of the lines is not a true line of symmetry. Which line is NOT a line of symmetry?"

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Classifying 2D Shapes by Properties
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.6.D
Standard Description: Classify 2D shapes by identifying their properties, including angles and side relationships.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Classifying 2D Shapes by Properties
Lesson Order: 120.0
Standard ID: TEKS.MATH.CONTENT.4.6.D+1
Standard Description: Classify 2D shapes by identifying their properties, including angles and side relationships.

Key Concepts:
*None specified*

Learning Objectives:
* Given a description of a shape that a student has drawn, identify or classify a polygon based on the number of certain angles.
* Given a description of a shape that a student has drawn, identify shapes with "at least" or "exactly" a given number of perpendicular or parallel opposite sides

Assessment Boundaries:
* Assessment is restricted to:
- Shapes to include are limited to: Acute triangle, Right triangle, Obtuse triangle, Rhombus, Parallelogram, Square, Rectangle, Trapezoid, Right trapezoid, Pentagon
- The correct answer should be one of the following: Square, or Rectangle
- It should be assumed that students know geometric terms like acute angle, obtuse angle, parallelogram, trapezoid, pentagon, etc.
- Specific angle measurements must not be included. A right angle should only be refered to as "right angle".
- Only simple versions of each shape type are to be considered. Questions must not require consideration of abstract variations of shape types.

Common Misconceptions:
* Assumes all shapes with right angles must be rectangles or squares.
* Confuses perpendicular sides with parallel sides when classifying quadrilaterals.
* Counts visual orientation instead of angle measures when identifying right angles.
* Treats any shape with one parallel pair as a trapezoid, ignoring other properties.

Difficulty Definitions:
* Easy:
  - The description gives one characteristics (ie exactly two right angles, exactly one pair of perpendicular sides, no acute angles)
* Medium:
  - The description gives more than one characteristics for sides or angles (ie. exactly one pair of opposite sides that are parallel. None of the sides are perpendicular to each other)
* Hard:
  N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.6
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Trapezoids
Lesson Order: 119.0
Standard ID: TEKS.MATH.CONTENT.4.6.D+2
Standard Description: Identify trapezoids and right trapezoids.

Key Concepts:
*None specified*

Learning Objectives:
* Identify all images of valid right trapezoids from a list of 3 or 4 options.
* Identify all images of valid right trapezoids from a list of 6 options.
* Identify all images of valid trapezoids from a list of 3 or 4 options.
* Identify all images of valid trapezoids from a list of 6 options.
* Identify if a given quadrilateral is a right trapezoid.
* Identify if a given quadrilateral is a trapezoid.

Assessment Boundaries:
* Assessment is restricted to:
- All shapes included in questions are quadrilaterals.
- Questions only required students to determine if the image(s) provided are trapezoids, right trapezoids, or neither.
- Stimulus descriptions are simple by design and will only capture the type of shape that will be displayed. This is intentional, and it is not a valid reason fro failure.

Common Misconceptions:
* Assumes trapezoids must have exactly one pair of parallel sides.
* Confuses trapezoids with any quadrilateral having slanted sides.
* Ignores right angles when identifying right trapezoids.
* Treats orientation as defining, rejecting trapezoids that are tilted or rotated.

Difficulty Definitions:
* Easy:
  - The questions stems asks "Is this quadrilateral a trapezoid?" and the answer options are "Yes" or "No"
* Medium:
  - The questions stems asks "Is this quadrilateral a right trapezoid?" and the answer options are "Yes" or "No"
  - The question stems prompts the student to "Select all the trapezoids." and there are 3-4 options available
* Hard:
  - The question stems prompts the student to "Select all right trapezoids." and there are 3-4 options available
  - The question stems prompts the student to "Select all the trapezoids." and there are 6 options available
  - The question stems prompts the student to "Select all right trapezoids." and there are 6 options available

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.8
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Multiplicative Patterns in Tables: Conversions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.8.B
Standard Description: Identify and apply multiplicative patterns for converting customary measurements.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.8
Cluster Name: The student applies mathematical process standards to select appropriate customary and metric units, strategies, and tools to solve problems involving measurement.
Lesson Name: Using Patterns in Tables for Conversions
Lesson Order: 125.0
Standard ID: TEKS.MATH.CONTENT.4.8.B+1
Standard Description: Identify patterns in tables and use them to convert units.

Key Concepts:
*None specified*

Learning Objectives:
* Identify and apply the multiplicative pattern in conversion tables using division (first column values are larger than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Yards Conversions").
* Identify and apply the multiplicative pattern in conversion tables using division when given a value from the second column (larger values) to find the equivalent value in the first column (smaller values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Yards-to-Feet Conversions"). The question provides a value in the second column and asks for the equivalent value in the first column.
* Identify and apply the multiplicative pattern in conversion tables using multiplication (first column values are smaller than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Inches Conversions").
* Identify the set of expressions that represents the relationship between the position of a number in a pattern and its value, where expressions use a single-step operation (addition, subtraction, multiplication, or division) and are written in the form n + k, n - k, n × k, or n ÷ k, where n represents the Position.

Assessment Boundaries:
* Assessment is restricted to:
- Tables must display 4 rows 
- All values in tables must be whole numbers.
- No mixed units in the same question.
- Only units of lenght are allowed


QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must follow this structure with explicit line breaks:

  [Introductory Sentence]: "The table shows different numbers of [first column unit] and the equivalent numbers of [second column unit]."
  [Question Sentence]: "[Person/Character] [action verb] [value] [unit from second column]. How many [unit from first column] did [person/character] [action verb]?"


Generate questions using diverse scenarios from the SCENARIO CONTEXT BANK. Each scenario includes character names and action verbs:

1. Construction - Characters: [Marcus, Hector, Diana, Rosa]; Actions: [measured, cut]
2. Sewing - Characters: [Sophie, Anna, Claire, Nadia]; Actions: [cut, measured]
3. Gardening - Characters: [Maya, Oscar, Felix, Violet]; Actions: [measured, dug]
4. Travel - Characters: [Nathan, Priya, Tara, Derek]; Actions: [walked, hiked, traveled]
5. Sports - Characters: [Jordan, Ryan, Casey, Morgan]; Actions: [ran, jogged, sprinted]
6. Art - Characters: [Iris, Pablo, Jade, Kai]; Actions: [measured, sketched]
7. School - Characters: [Liam, Grace, Owen, Zoe]; Actions: [walked, measured]
8. Pet Care - Characters: [Lucas, Chloe, Bella, Tucker]; Actions: [walked]
9. Home - Characters: [Sophia, James, Isabella, Ethan]; Actions: [measured, cut]
10. Transportation - Characters: [Kevin, Nicole, Victor, Paula]; Actions: [drove, traveled]
11. Nature - Characters: [Dr. Chen, Dr. Patel, Dr. Kim, Dr. Martinez]; Actions: [hiked, walked, measured]
12. Crafts - Characters: [Ella, Logan, Ruby, Finn]; Actions: [cut, measured]
13. Infrastructure - Characters: [Mr. Adams, Mr. Clark, Ms. Rivera, Ms. Nguyen]; Actions: [measured, walked]
14. Delivery - Characters: [Carlos, Elena, Brian, Laura]; Actions: [drove, traveled]
15. Recreation - Characters: [Tyler, Hannah, Cole, Paige]; Actions: [swam, walked, ran]
16. Animal Science - Characters: [Zara, Kyle, Leah, Evan]; Actions: [measured, walked]
17. Baking - Characters: [Megan, Henry, Nora, Jack]; Actions: [rolled, measured]
18. Camping - Characters: [Hunter, Sierra, Blake, Autumn]; Actions: [hiked, walked]
19. City Planning - Characters: [Robert, Maria, Steven, Jessica]; Actions: [measured, walked]
20. Fishing - Characters: [Wade, Pearl, Reed, Marina]; Actions: [cast, walked]
21. Furniture - Characters: [Carter, Hazel, Mason, Ivy]; Actions: [measured, cut]
22. Music - Characters: [Melody, Harper, Lyric, Quinn]; Actions: [measured]
23. Space - Characters: [Dr. Brooks, Dr. Santos, Dr. Wong, Dr. Hayes]; Actions: [traveled, measured]
24. Weather - Characters: [Mr. Stone, Mr. Wells, Ms. Lane, Ms. Frost]; Actions: [climbed, measured]
25. Winter Sports - Characters: [Aspen, Everest, Shawn, Brooke]; Actions: [skied, sledded, traveled]

Usage Guidelines:
- Select one scenario from the list above
- Choose a character name from the corresponding character list
- Choose an action verb from the corresponding action list
- Ensure the character name and action verb are contextually appropriate for the selected scenario
- Vary character names and action verbs across different questions to ensure diversity

Common Misconceptions:
* Added instead of divided: Student adds the conversion factor to the given value instead of dividing (e.g., 333 + 3 = 336 instead of 333 ÷ 3 = 111).
* Multiplied instead of divided: Student multiplies the given value by the conversion factor instead of dividing (e.g., 333 × 3 = 999 instead of 333 ÷ 3 = 111).
* Selected value from table: Student picks a value directly from the table that appears close to or related to the given value, rather than applying the pattern to the new value.
* Used wrong conversion factor: Student uses a related but incorrect conversion factor (e.g., using 12 instead of 3 when converting feet to yards, resulting in 333 ÷ 12 ≈ 28).

Difficulty Definitions:
* Easy:
  Identify the set of expressions that represents the relationship between Position and Value, where expressions use a single-step operation (addition, subtraction, multiplication, or division) with whole numbers. Multipliers are 4th grade appropriate. For subtraction, Position is greater than the subtrahend. For division, results are whole numbers with no remainders
* Medium:
  Identify and apply the multiplicative pattern in conversion tables using multiplication (first column values are smaller than second column values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Feet-to-Inches Conversions").
* Hard:
  Identify and apply the multiplicative pattern in conversion tables using division when given a value from the second column (larger values) to find the equivalent value in the first column (smaller values). Tables must include a descriptive header/title based on the conversions (e.g., "Equivalent Distances" or "Yards-to-Feet Conversions"). The question provides a value in the second column and asks for the equivalent value in the first column.

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: 122.0
Standard ID: Interpreting Stem-and-Leaf Plots
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit, e.g., 84, 96, 105, 117)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., "1|5 means 1.5")
- For whole numbers: stem = tens place, leaf = ones (e.g., "9|6 means 96")

PROBLEM TYPES:
Per the standard, students must solve one- and two-step problems:

1. ONE-STEP PROBLEMS:
   - Identify maximum or minimum value
   - Count total number of data points
   - Count data points in a specific range

2. TWO-STEP PROBLEMS:
   - Calculate range (find max, find min, subtract)
   - Calculate total sum of all values
   - Determine which plot correctly displays given data

QUESTION FORMATS:
Three question types based on STAAR examples:

1. CALCULATE FROM PLOT (Sum):
   - "What is the total number of [items]?"
   - Format: MCQ with 4 numerical options
   - Distractors: partial sum (missed a value), sum of stems only, calculation errors

2. CALCULATE FROM PLOT (Range):
   - "What is the difference between the highest and lowest [value]?"
   - Format: MCQ with 4 numerical options
   - Distractors: subtracted stems only, misread leaf digit, decimal place errors

3. CREATE/MATCH PLOT:
   - "Which stem-and-leaf plot displays these data?"
   - Format: MCQ with 4 plot options
   - Distractors: leaves out of order, missing data points, wrong stem for 3-digit numbers, reversed stem/leaf

REQUIRED ELEMENTS:
- Each plot includes a key (e.g., "9|6 means 96 tickets" or "1|5 means a score of 1.5")
- Real-world, grade-appropriate contexts
- Plots have 4-6 rows (stems)
- Data sets contain 7-15 values
- No mean or median calculations
- Students select correct plots, not draw them by hand

DISTRACTOR DESIGN GUIDANCE:
Vary the concept tested in each answer option - Don't just change numbers in the same format!

For calculation questions, distractors should reflect different misconceptions:
- One option: correct answer
- One option: partial calculation (skipped a data point)
- One option: misread the notation (stems only, or decimal place error)
- One option: computation error (close to correct but off by small amount)

For match-plot questions, distractors should include:
- Correct plot
- Plot with leaves in wrong order
- Plot with missing data point(s)
- Plot with stem/leaf reversal or wrong stem for 100s

LATEX STRUCTURE:

Never put \n inside LaTeX $$ ... $$! Strictly prohibited.

For CALCULATE questions (Sum):

Example:
The stem-and-leaf plot shows the numbers of tickets Stephen won when he played games at a carnival.

$$
\begin{array}{c}
\text{Number of Tickets Won}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
8 & 4\ 8 \\
9 & 0\ 6\ 8 \\
10 & 5\ 5 \\
11 & 7 \\
\end{array}
$$

$$
\boxed{\text{9|6 means 96 tickets}}
$$

What is the total number of tickets that Stephen won at the carnival?

A. 783
B. 178
C. 81
D. 678

For CALCULATE questions (Range with Decimals):

Example:
The stem-and-leaf plot shows the scores given to the dogs at a dog show. Possible scores were between 0.1 and 5.0.

$$
\begin{array}{c}
\text{Dog Show Scores}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
0 & 8 \\
1 & 2\ 5 \\
2 & 2\ 4\ 8 \\
3 & 0\ 3\ 6\ 8 \\
4 & 0\ 5\ 5 \\
\end{array}
$$

$$
\boxed{\text{1|5 means a score of 1.5}}
$$

What is the difference between the highest score and the lowest score shown in the stem-and-leaf plot?

A. 4.3
B. 3.7
C. 0.25
D. 0.47

For CREATE/MATCH questions:

Example:
The table shows the total numbers of runs different baseball teams scored in one season.

$$
\begin{array}{|c|c|}
\hline
\text{Team} & \text{Total Number of Runs Scored} \\
\hline
R & 61 \\
S & 92 \\
T & 100 \\
U & 65 \\
V & 72 \\
W & 64 \\
X & 84 \\
\hline
\end{array}
$$

Which stem-and-leaf plot displays these data?

[Four plot options A, B, C, D with variations]

REAL-WORLD CONTEXTS (Grade 4 appropriate):

Sports & Games:
- Carnival game tickets won
- Arcade tickets collected
- Video game points scored
- Basketball free throws made
- Soccer goals scored in a season
- Baseball runs scored
- Board game wins during family game night
- Bowling scores
- Mini golf scores
- Race times (in seconds)

School & Learning:
- Minutes spent reading
- Pages read in a week
- Books read in a month
- Spelling test scores
- Math quiz scores
- Science project scores
- Homework completion times (minutes)
- Library books checked out

Animals & Nature:
- Dog show scores (decimals)
- Pet weights (pounds or kilograms)
- Plant heights in science lab (centimeters, decimals)
- Fish lengths caught during fishing trip
- Bird species counted during bird watching
- Eggs collected from chicken coop

Daily Life:
- Steps walked in a day
- Minutes of exercise
- Pieces of candy collected (Halloween, party)
- Stickers in a collection
- Trading cards owned
- Glasses of water drunk in a week
- Hours of sleep

Food & Money:
- Cups of lemonade sold at a stand
- Cookies baked for a sale
- Money earned from chores (dollars)
- Fruit pieces in lunchboxes
- Ice cream scoops sold

Creative & Building:
- LEGO bricks used in a build
- Blocks in a tower-building contest
- Puzzle completion times (minutes)
- Drawing contest scores
- Craft supplies used

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also misread individual leaf digits (e.g., reading 8 as 2, leading to 4.3 instead of 3.7 for a range calculation).
* When calculating range with decimals, students subtract stems and leaves separately (e.g., for 4.5 − 0.8: doing 4−0=4 and 5−8=−3, then combining incorrectly to get 0.47) instead of subtracting full decimal values to get 3.7. Students may also use wrong values for max or min due to misreading leaves.
* When calculating totals, students skip data points (e.g., missing one "105" gives 678 instead of 783), add only some rows instead of all values, or count the number of data points instead of summing the actual values.
* When matching data to plots, students select plots with leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), plots missing data points, plots with three-digit numbers under wrong stems (e.g., 100 placed under stem "1" instead of stem "10"), or plots with stem and leaf positions reversed.

Difficulty Definitions:
* Easy:
  - Identify a single value (maximum, minimum) directly from the plot
  - Count the number of data points in the plot
  - Whole numbers only
  - Stem values: single digits (1-9)
  - Leaf values: single digits, primarily 0-5
  - 4-5 rows (stems)
  - 6-8 data points
  - One-step problems
  - 4-option MCQ format
* Medium:
  - Calculate range (find max, find min, subtract)
  - Match raw data to correct stem-and-leaf plot
  - Whole numbers OR decimals with one decimal place
  - Stem values: any single digits (0-9) or two digits (10, 11)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 7-10 data points
  - Two-step problems
  - 4-option MCQ format
* Hard:
  - Calculate total (sum) of all values in the plot
  - Decimals with one decimal place in calculation problems
  - Stem values: any, including two-digit stems (10, 11)
  - Leaf values: any single digits (0-9)
  - 5-6 rows (stems)
  - 10-15 data points
  - Multi-step problems requiring careful tracking of all values
  - 4-option MCQ format
  - May combine skills (e.g., find sum, then compare)

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Frequency Tables
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.9.A
Standard Description: Interpret frequency tables to identify corresponding data sets.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Create Frequency Tables
Lesson Order: 127.0
Standard ID: TEKS.MATH.CONTENT.4.9.A+1
Standard Description: Create or update frequency tables from data sets.

Key Concepts:
*None specified*

Learning Objectives:
* Identify the data set that matches a given frequency table.
* Identify which row in a frequency table is incomplete by comparing it to the original data set.
* Select the frequency table that represents a given data set.

Assessment Boundaries:
* Assessment is restricted to:

**General Constraints:**

- All items are MCQ with exactly four answer choices
- Frequency tables display tally marks (the `draw_frequency_table` function automatically renders numeric frequency values as visual tally marks)
- Tally mark convention: | = 1, || = 2, ||| = 3, |||| = 4, |||| with diagonal strike = 5
- All data values are whole numbers (0–20 range)
- Total data points: 8–20 items per data set

**Technical Note on Tally Marks:**
The stimulus schema uses numeric `frequency` values (integers 0-20). These are automatically converted to visual tally marks by the drawing function. For example, `"frequency": 7` renders as |||| || (a group of 5 with diagonal strike plus 2 marks). This is the correct behavior - the schema stores counts, the renderer displays tally marks.

**Difficulty Progression (Scaffolded):**

The difficulty progression is designed to build skills incrementally:

1. **Easy (Type 1)**: Students start with concrete data and find the matching table - more scaffolded
2. **Medium (Type 2)**: Students interpret tally marks to reconstruct data - requires reading visual representation
3. **Hard (Type 3)**: Students compare data to an incomplete table - requires both skills plus error detection

**Question Types:**

Type 1 (Data → Table) - EASY ONLY:
- Stimulus: Data list provided as comma-separated values in question stem
- Question asks: "Which frequency table represents all of the data in the list?"
- Answer options: Four frequency table images with identical structure but different tally counts
- Note: StimulusRequired = FALSE (images are in answers only)
- Scaffolding: Student works from concrete data to visual representation

Type 2 (Table → Data) - MEDIUM ONLY:
- Stimulus: Frequency table image with tally marks in question stem
- Question asks: "Which set of data could the frequency table represent?"
- Answer options: Four data lists as comma-separated values
- Note: StimulusRequired = TRUE (image is in question)
- Challenge: Student must interpret tally marks to identify matching data

Type 3 (Incomplete Row) - HARD ONLY:
- Stimulus: Data list AND incomplete frequency table (one row has wrong count) in question stem
- Question asks: "Which row of the frequency table is incomplete?"
- Answer options: Four row labels (e.g., "The row showing 0 to 4 books")
- Note: StimulusRequired = TRUE (image is in question)
- Challenge: Student must count data per interval AND compare to tally marks

**Category Constraints:**

Easy (Type 1):
- Categories can be single numbers (0, 1, 2, 3, 4, 5) OR ranges
- 4–6 categories in the table
- Each category may have 0–6 occurrences

Medium (Type 2):
- Categories can be single numbers OR ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
- 4–6 categories/intervals
- Data list has 10–16 values

Hard (Type 3):
- Categories are ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
- 4 intervals with equal width (typically 5)
- Exactly ONE row is incomplete (has fewer tallies than actual count)
- The error is 1–2 tallies off

**Distractor Design:**

Type 1 Distractors:
- Miscounted tallies (off by 1–2 in one or more categories)
- Swapped counts between adjacent categories
- Boundary errors for range categories

Type 2 Distractors:
- Data lists with wrong counts per interval
- Data lists with values outside the table's range
- Data lists with boundary values in wrong intervals

Type 3 Distractors:
- Rows that are actually complete (correct count)
- Row with highest frequency (students assume "most = incomplete")
- Edge rows (first or last interval)

**Context Requirements:**

- Every question must include a real-life context
- Use diverse contexts: books read, goals scored, pets owned, volunteer hours, etc.
- Use diverse character names: Mr. Westley, Sofia, Jamal, Mei, Carlos, etc.
- Avoid repeating contexts in consecutive questions

Common Misconceptions:
* Confusing the interval labels with the frequency counts (e.g., thinking "5 to 9" means 5 items instead of checking how many data values fall in that range).
* Forgetting to count a data value when creating tally marks, especially when values repeat many times in the list.
* Miscounting tally marks, especially when groups of 5 are involved (e.g., counting |||| with strike as 4 instead of 5, or losing track when counting multiple groups like |||| |||| || as 10 instead of 12).
* Misplacing data values at interval boundaries (e.g., placing a value of 5 in the "0 to 4" interval instead of "5 to 9", or placing 10 in "5 to 9" instead of "10 to 14").

Difficulty Definitions:
* Easy:
  - Question Type: Type 1 (Data → Table)
  - Given a data list, select the matching frequency table from 4 MCQ options
  - Category type: Single numbers (0, 1, 2, 3, 4, 5) OR ranges
  - Images appear in ANSWER OPTIONS (student sees data, picks table)
  - Data list has 8–12 values
  - 4–6 unique categories
  - Tally marks per category: 1–6
  - Distractors have miscounted tallies (off by 1–2) or swapped counts
  - Scaffolding: Student works from concrete data to visual representation
* Medium:
  - Question Type: Type 2 (Table → Data)
  - Given a frequency table image, select the matching data set from 4 MCQ options
  - Category type: Single numbers OR ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
  - Image appears in QUESTION STEM (student reads table, picks data list)
  - Data list has 10–16 values
  - 4–6 categories/intervals
  - Requires interpreting tally marks to reconstruct data
  - Distractors have wrong counts per category or boundary errors
* Hard:
  - Question Type: Type 3 (Incomplete Row)
  - Given a data list AND an incomplete frequency table image, identify which row is incomplete
  - Category type: Ranges (0 to 4, 5 to 9, 10 to 14, 15 to 19)
  - MCQ with 4 row labels as answer options
  - Data list has 12–20 values
  - Exactly one row has incorrect tally count (off by 1–2 tallies)
  - Other rows are completely correct
  - Requires counting data per interval and comparing to tally marks

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Frequency Tables
Lesson Order: 128.0
Standard ID: TEKS.MATH.CONTENT.4.9.A+2
Standard Description: Interpret frequency tables and their corresponding data sets.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the sum or difference of two frequency values from a frequency table.
(REQUIRES operation on TWO values — addition OR subtraction — never single-value lookup)
* Read and identify a single frequency value from a frequency table.
(DIRECT LOOKUP ONLY — NO operations, NO "difference", NO "total", NO two-category questions)

Assessment Boundaries:
* ## Table Constraints
- Frequency tables must contain between 4 and 6 categories.
- All frequency values must be whole numbers between 0 and 20.
- Text entry response format (single whole number answer).
- All categories must be numeric values or numeric ranges. E.g: "1","2","3" or "1-3","5-6". Not qualitative categories such as "vanilla", "chocolate", etc

## Difficulty Levels
- **Easy (LO1):** Direct lookup from one category. Answer MUST appear in the table.
- **Medium (LO2):** Addition or subtraction of two categories. Computed answer must NOT appear as any frequency value.

## Formatting Rules
- In question stems, use `\n` for line breaks. Never use `<br/>` or HTML tags.
- Every stem must start with "The frequency table shows [context]."

## Explanation Rules
- **LO1 (Direct Lookup):** "The frequency table shows [X] [subjects] [action] [category]."
- **LO2 (Operations):** "The frequency table shows [X] [subjects] [action] [cat1] and [Y] [subjects] [action] [cat2]. Add/Subtract: [X] + [Y] = [answer]." or "[X] − [Y] = [answer]."
- Use plain numbers in explanations (no LaTeX).

## Professional Wording (STAAR Format)
- **Subtraction:** "What is the difference between the number of [subjects] who [action] [category1] and the number who [action] [category2]?"
- **Addition:** "How many [subjects] [action] [category1] or [category2] in total?"

## Validator Notes
- The stimulus_description schema uses numeric frequency values (integers). The draw_frequency_table function automatically renders these as visual tally marks.
- For LO1: The answer MUST match a frequency in the table (that's the whole point of direct lookup).
- For LO2: If the computed answer matches a frequency value, the generator MUST retry with different values.

Common Misconceptions:
* Confuses the category label with the frequency count (answering "3" for "How many students watched 3 movies?" because 3 is in the question).
* Miscounts tally marks when groups of 5 are present (counting |||| with strike as 4 instead of 5).
* Reads the wrong row in the frequency table (looks at an adjacent category by mistake).
* When asked for a difference, adds instead of subtracts or subtracts in the wrong order.

Difficulty Definitions:
* Easy:
  - Question asks "How many [subjects] [action] [category]?"
  - Student reads a single frequency value directly from the table
  - Text entry response (single whole number)
* Medium:
  - Question asks "What is the difference between..." or "How many total..."
  - Student reads two frequency values and performs addition or subtraction
  - Text entry response (single whole number)
* Hard:
  - N/A

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.4.9.B
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Creating Stem-and-Leaf Plots
Lesson Order: 123.0
Standard ID: TEKS.MATH.CONTENT.4.9.B+1
Standard Description: Organize and represent data by constructing stem-and-leaf plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of whole numbers that includes three-digit values (100-119), identify the stem-and-leaf plot that correctly displays the data using two-digit stems.

Assessment Boundaries:
* Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit: 30-99, three-digit: 100-119)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., "1|5 means 1.5")
- For whole numbers: stem = tens place, leaf = ones (e.g., "9|6 means 96")
- For 100s: stem = "10" or "11", leaf = ones (e.g., "10|5 means 105")

PROBLEM TYPE - ONLY THIS ONE IS ALLOWED:
- Match a data set to the correct stem-and-leaf plot (MCQ with 4 plot options)

EXPLICITLY NOT ALLOWED - DO NOT GENERATE THESE:
- Calculate total/sum questions (this is B+2)
- Calculate difference/range questions (this is B+2)
- Count questions (e.g., "How many values are greater than X?")
- Max/min identification questions
- Complete the plot / fill in the blank questions (separate LOs)

CONTENT CONSTRAINTS:
- Data sets contain 6-8 values
- Plots have 3-5 rows (stems)
- Real-world, grade-appropriate contexts

DISTRACTOR DESIGN (4 options required):
- ONE correct plot - leaves in ascending order (smallest to largest)
- ONE plot with leaves in DESCENDING order (largest to smallest) - tests ordering rule
- ONE plot missing one data point - tests completeness
- ONE plot with error based on data type:
  * For 100s: value placed under wrong stem (e.g., 100 under stem "1" instead of "10")
  * For decimals: stem and leaf reversed
  * For 2-digit: extra value not in data set

REAL-WORLD CONTEXTS (Grade 4 appropriate):
- Minutes spent reading
- Points scored in games
- Stickers collected
- Tickets won at arcade/carnival
- Books read
- Baseball runs scored
- Video game points
- Race times (for decimals)
- Plant heights (for decimals)
- Puppy weights (for decimals)

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also reverse stem and leaf positions (e.g., writing 61 as stem 1, leaf 6 instead of stem 6, leaf 1).
* When creating or matching plots, students miss data points (e.g., a plot showing only 6 values when the data set has 7), add extra values that don't exist in the data, or include duplicate leaves when the original data has no duplicates.
* When organizing data into a plot, students place leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), forgetting that leaves must be arranged from smallest to largest within each stem row.
* When working with three-digit numbers (100-119), students place values under the wrong stem (e.g., placing 100 under stem "1" instead of stem "10", or placing 105 under stem "1" with leaf "05" instead of stem "10" with leaf "5").

Difficulty Definitions:
* Easy:
  - Match a data set to the correct stem-and-leaf plot 
  - Whole numbers only (two-digit: 30-99 range)
  - Stem values: single digits (3-9)
  - Leaf values: single digits (0-9)
  - 3-4 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, extra value
* Medium:
  - Match a data set to the correct stem-and-leaf plot 
  - Whole numbers including three-digit (100-119)
  - Stem values: single digits (6-9) AND two digits (10, 11)
  - Leaf values: single digits (0-9)
  - 4-5 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, 100 under wrong stem
* Hard:
  - Match a decimal data set to the correct stem-and-leaf plot 
  - Decimals with one decimal place (e.g., 1.2, 1.5, 2.3)
  - Stem = ones place, Leaf = tenths place
  - Stem values: 0-4 typically
  - Leaf values: single digits (0-9)
  - 3-4 rows (stems)
  - 6-8 data points
  - 4-option MCQ format
  - Distractors: wrong leaf order, missing value, stem/leaf reversed

NOT ALLOWED AT ANY DIFFICULTY:
  - Sum/total questions
  - Difference/range questions
  - Count questions
  - Max/min questions
  - Complete the plot questions

---

Subject: Math
Course: 4th Grade TEKS
Unit ID: Math Grade 4 Unit 16
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.4.9
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Interpreting Stem-and-Leaf Plots
Lesson Order: 124.0
Standard ID: TEKS.MATH.CONTENT.4.9.B+2
Standard Description: Interpret and analyze data using stem-and-leaf plots to draw conclusions and solve problems.

Key Concepts:
*None specified*

Learning Objectives:
* Given a stem-and-leaf plot with decimals (one decimal place), calculate the difference between the highest and lowest values OR calculate the total sum of all values.
* Given a stem-and-leaf plot with whole numbers, calculate the difference between the highest and lowest values OR calculate the total sum of all values.
* Given a stem-and-leaf plot, determine how many values fall above, below, or within a given threshold.

Assessment Boundaries:
* "Assessment is restricted to:

DATA TYPES:
- Whole numbers (two-digit, e.g., 84, 96, 105, 117)
- Decimals with one decimal place (e.g., 0.8, 1.5, 3.7)
- No fractions in stem-and-leaf plots
- For decimals: stem = ones place, leaf = tenths (e.g., ""1|5 means 1.5"")
- For whole numbers: stem = tens place, leaf = ones (e.g., ""9|6 means 96"")

PROBLEM TYPES - ONLY THESE TWO ARE ALLOWED:
1. Calculate total sum of all values
2. Calculate difference between highest and lowest values

EXPLICITLY NOT ALLOWED - DO NOT GENERATE THESE:
- Count questions (e.g., ""How many values are greater than X?"")
- Max/min identification (e.g., ""What is the highest value?"")
- Match data to plot (this is B+1, not B+2)
- Any question asking students to count data points

QUESTION FORMATS:

1. CALCULATE FROM PLOT (Sum):
   - ""What is the total number of [items]?""
   - Format: MCQ with 4 numerical options

2. CALCULATE FROM PLOT (Difference):
   - ""What is the difference between the highest and lowest [value]?""
   - NEVER use the word ""range""
   - Format: MCQ with 4 numerical options

REQUIRED ELEMENTS:

1. PLOT TITLE (MANDATORY): Every stem-and-leaf plot MUST have a centered title above it showing what the data represents WITH UNITS:

$$
\begin{array}{c}
\text{Plant Heights (m)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
...
\end{array}
$$

Examples of titles WITH units:
- \text{Plant Heights (m)}
- \text{Race Times (seconds)}
- \text{Dog Show Scores}
- \text{Stickers Collected}
- \text{Points Scored}
- \text{Puppy Weights (kg)}

2. KEY: Each plot includes a key below (e.g., ""9|6 means 96 tickets"" or ""1|5 means 1.5 m"")

3. Real-world, grade-appropriate contexts

4. Plots have 4-5 rows (stems) - MAXIMUM 5 rows for Grade 4

5. Data sets contain 8-10 values

6. No mean or median calculations

DISTRACTOR DESIGN:

For SUM questions:
- Correct answer
- Partial sum (skipped a data point)
- Misread notation (stems only, or decimal place error)
- Computation error

For DIFFERENCE questions:
- Correct answer
- Subtracted stems only
- Misread leaf digit
- Decimal place error

LATEX STRUCTURE:

Never put \n inside LaTeX $$ ... $$!

CORRECT FORMAT (with title):

$$
\begin{array}{c}
\text{Plant Heights (m)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
0 & 6\ 7 \\
1 & 1\ 5 \\
2 & 0\ 4\ 8 \\
3 & 2\ 6 \\
\end{array}
$$

$$
\boxed{\text{1|5 means 1.5 m}}
$$

REAL-WORLD CONTEXTS (Grade 4 appropriate):
[Keep existing list]"

Common Misconceptions:
* Students misread stem-and-leaf notation, treating 3|5 as "3 and 5" (sum of 8) instead of "35", or for decimals, reading 1|5 as "15" instead of "1.5". Students may also misread individual leaf digits (e.g., reading 8 as 2, leading to 4.3 instead of 3.7 for a range calculation).
* When calculating range with decimals, students subtract stems and leaves separately (e.g., for 4.5 − 0.8: doing 4−0=4 and 5−8=−3, then combining incorrectly to get 0.47) instead of subtracting full decimal values to get 3.7. Students may also use wrong values for max or min due to misreading leaves.
* When calculating totals, students skip data points (e.g., missing one "105" gives 678 instead of 783), add only some rows instead of all values, or count the number of data points instead of summing the actual values.
* When matching data to plots, students select plots with leaves in wrong order (e.g., 5, 4, 1 instead of 1, 4, 5), plots missing data points, plots with three-digit numbers under wrong stems (e.g., 100 placed under stem "1" instead of stem "10"), or plots with stem and leaf positions reversed.

Difficulty Definitions:
* Easy:
  - Calculate difference between highest and lowest values
  - Calculate total (sum) of all values in the plot
  - Whole numbers only
  - Stem values: single digits (1-9) or two digits (10, 11)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 6-10 data points
  - Two-step problems
  - 4-option MCQ format
* Medium:
  - Calculate difference between highest and lowest values
  - Calculate total (sum) of all values in the plot
  - Decimals with one decimal place only
  - Stem values: single digits (0-9)
  - Leaf values: any single digits (0-9)
  - 4-6 rows (stems)
  - 6-10 data points
  - Two-step problems
  - 4-option MCQ format
* Hard:
  Not applicable for this standard. All questions should be Easy (whole numbers) or Medium (decimals).

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Solving Verbal Numerical Expressions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.B
Standard Description: Write numerical expressions from real world situations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Muli-Digit Division Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.C
Standard Description: Divide with quotients of up to a four-digit dividend by a two-digit divisor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.10+1
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Gross and Net Income
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.B
Standard Description: Explain the difference between gross income and net income.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.10+1
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Gross and Net Income
Lesson Order: 183.0
Standard ID: TEKS.MATH.CONTENT.5.10.B+1
Standard Description: Explain the difference between gross income and net income.

Key Concepts:
*None specified*

Learning Objectives:
* Given a person's gross income and net income, complete a statement that correctly identifies the relationship between them and explains that taxes and deductions are subtracted from gross income to determine net income.
* Given information to calculate a person's gross income, determine which statement correctly compares their gross income and net income.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world employment contexts only (part-time jobs, weekly salaries).
- Weekly time period only.
- All monetary amounts must be whole dollar values.
- No actual tax or deduction amounts need to be calculated — students only need to understand the directional relationship (net income < gross income because taxes/deductions are subtracted).
- LO1: Both gross income (salary) and net income (take-home pay) are given directly. The student identifies terminology and the deduction relationship.
- LO2: Gross income must be calculated from hours worked × hourly rate. The student then reasons about the gross-to-net relationship.
- Hourly rates should be single-digit whole numbers ($5–$9).
- Weekly hours should produce an easily calculable product (e.g., 10, 12, 15, 20, 25 hours).
- Gross income values should not exceed $500.

Common Misconceptions:
* Students confuse the definitions of gross and net income and believe gross income is less than the calculated earnings — they do not understand that gross income equals total earnings before any deductions (hours × rate or stated salary). They may think some deductions occur before gross income is determined, leading them to select "gross income is less than [amount]" when the calculated earnings ARE the gross income.
* Students correctly calculate total earnings (hours × rate) but misidentify the result as net income instead of gross income. Since they may also correctly know that gross income is larger than net income, they conclude that gross income must be more than the calculated amount — when in fact the calculated amount IS the gross income.
* Students do not understand that taxes and deductions are subtracted from gross income to determine net income — they think taxes and deductions are added to gross income, or they apply the subtraction to the wrong income type (e.g., "subtracted from her net income" instead of "subtracted from her gross income"). This shows a fundamental misunderstanding of how deductions reduce earnings.
* Students swap the definitions of gross income and net income — they believe "gross income" means the amount received after taxes and deductions (take-home pay), and "net income" means total earnings before deductions. When completing a statement, they label take-home pay as "gross income." When evaluating comparison statements, they think the calculated amount (hours × rate) represents net income and select "net income is more than [amount]."

Difficulty Definitions:
* Easy:
  Gross income is stated directly (weekly salary given). Student only needs to identify the correct terminology (net income vs. gross income) and the deduction relationship. No calculation required.
MIDDLE:
Gross income must be calculated from hours × hourly rate. Student must compute first, then reason about the gross-to-net relationship using comparison language ("more than" / "less than").
* Medium:
  <unspecified>
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.10+1
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.F
Standard Description: Balance a simple budget.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.10+1
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: 184.0
Standard ID: TEKS.MATH.CONTENT.5.10.F+1
Standard Description: Balance a simple budget.

Key Concepts:
*None specified*

Learning Objectives:
* Given a budget with one missing expense category and a total income, determine the missing amount that balances the budget.

Assessment Boundaries:
* Assessment is restricted to:
- Real-world budget contexts only (personal or family budgets).
- Monthly time period only.
- Income values must be whole dollar amounts, up to $6,000.
- Expense values must be whole dollar amounts.
- Each budget table has 4–6 expense categories with exactly 1 category missing.
- "Balanced budget" means total expenses equal total income (no surplus, no deficit).
- Income may be referred to as "income" or "net income."
- No tax or deduction calculations — the income amount is given directly.
- The missing category can be any expense type (savings, entertainment, other, etc.).

Common Misconceptions:
* Students make a regrouping error when adding the known expenses — they do not carry over correctly when the sum of digits in a column exceeds 9 (e.g., missing the carry from ones to tens), resulting in a total that is off by $10 or $100. This produces a missing amount that is slightly too high or too low (e.g., getting expenses = 2,900 instead of 2,910, then computing 3,620 − 2,900 = 720 instead of 710).
* Students make a regrouping error when subtracting total expenses from income — they subtract the lesser digit from the greater digit in each place value regardless of which number it belongs to (e.g., in 3,620 − 2,910, they compute hundreds as 9 − 6 = 3 instead of regrouping from thousands). This produces an answer that is significantly larger than the correct amount.
* Students round each expense to the nearest hundred (and possibly round the income as well) instead of computing with exact values. They subtract rounded totals, producing an estimated answer rather than the exact amount needed to balance the budget. This indicates the student does not recognize that a budget problem requires an exact solution, not an estimate.
* Students use the wrong operation — they add the income to the total known expenses instead of subtracting, producing an answer much larger than the income itself. This indicates the student does not understand that a balanced budget requires total expenses to equal income, and that the missing amount is the difference between income and the sum of known expenses.

Difficulty Definitions:
* Easy:
  3–4 known expense categories; expenses are multiples of 10 or 100 (simpler addition); income under $3,000; open response format.
* Medium:
  5–6 known expense categories; expenses are not all round numbers (require careful regrouping); income $3,000–$6,000; MCQ format with computation-error distractors.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.2+1
Cluster Name: The student applies mathematical process standards to represent, compare, and order positive rational numbers and understand relationships as related to place value.
Lesson Name: Decimals in Expanded Notation
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.2.A
Standard Description: Represent, read, and write decimals through the thousandths using expanded notation, word form, and standard form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.2+1
Cluster Name: The student applies mathematical process standards to represent, compare, and order positive rational numbers and understand relationships as related to place value.
Lesson Name: Decimals in Expanded Notation
Lesson Order: 167.0
Standard ID: TEKS.MATH.CONTENT.5.2.A+1
Standard Description: Represent, read, and write decimals through the thousandths using expanded notation, word form, and standard form.

Key Concepts:
*None specified*

Learning Objectives:
* Convert a decimal written as a sum of (digit × place value) expressions to word form
* Given (digit × place value) expressions for a subset of digit positions, identify the decimal number that contains those digits in the corresponding place-value positions
* Given real-world context, convert a decimal written as a sum of (digit × place value) expressions to a numeral in standard form

Assessment Boundaries:
* Assessment is restricted to:
- Decimals through the thousandths (tenths, hundredths, thousandths)
- Expanded notation in (digit × place value) format only
- Whole number part limited to tens and ones (no hundreds or beyond)
- No operations beyond conversion between representations (no adding, subtracting, multiplying, or dividing decimals)

Common Misconceptions:
* Confuses adjacent decimal place-value names such as tenths and hundredths.
* Confuses whole-number place-value positions such as tens and hundreds.
* Ignores a skipped place value and reads the decimal digits as a smaller number.
* Omits the place-value denominator when converting a decimal to word form.

Difficulty Definitions:
* Easy:
  Expanded notation contains 2 terms
Decimal portion extends to tenths only
No place-value positions are skipped in the expanded notation
* Medium:
  Expanded notation contains 3–4 terms
Decimal portion extends to hundredths or thousandths
No place-value positions are skipped in the expanded notation
* Hard:
  Expanded notation contains 3–4 terms
Decimal portion extends to thousandths
One or more place-value positions are skipped (e.g., no hundredths term between tenths and thousandths)

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.3+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Multiplication Word Problems
Lesson Order: 160.0
Standard ID: TEKS.MATH.CONTENT.5.3.B+2
Standard Description: Solve real-world multiplication problems involving multi-digit whole numbers using the standard algorithm.

Key Concepts:
*None specified*

Learning Objectives:
* Solve a real-world problems that requires multiplying a three-digit number by a two-digit number (or two-digit by three-digit)

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- One factor up to three digits and one factor up to two digits.
- Products do not exceed 10,000.
- Multiplication using the standard algorithm only.
- Real-world word problems with clear "number of groups" and "number in each group" (or rows × items per row) structure.
- No formulas provided in the question stem.
- Numbers must be in numeric form, not spelled out

Common Misconceptions:
* Does not regroup correctly when multiplying multi-digit numbers, leading to an incorrect final product.
* Fails to use a zero placeholder when multiplying by the tens digit, causing partial products to be misaligned.
* Incorrectly decomposes a number by multiplying only part of it (e.g., multiplying by 100 and then adding the remaining digits) instead of applying the standard multiplication algorithm.
* Misaligns place values when writing or adding partial products, resulting in an incorrect sum of the partial products.

Difficulty Definitions:
* Easy:
  All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.3+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Multiplication and Division Word Problems
Lesson Order: 162.0
Standard ID: TEKS.MATH.CONTENT.5.3.B+3
Standard Description: Determine whether a real-world problem requires multiplication or division and solve using multi-digit whole numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Solve a real-world problems that requires multiplying a three-digit number by a two-digit number (or two-digit by three-digit)
* Solve real-world problems involving division of whole numbers to find the quotient with a single numeric answer.
* Solve real-world problems involving division to find the greatest number of complete groups (result only; remainder discarded).

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Multiplication: One factor up to three digits and one factor up to two digits; products do not exceed 10,000.
- Division: Dividend up to four digits and divisor up to two digits.
- Real-world word problems with clear "number of groups" and "number in each group" (or rows × items per row) structure; includes finding a total (multiplication), finding how many groups or how many per group (division), or interpreting remainder.
- No formulas or key words provided in the question stem.

Common Misconceptions:
* Confuses the meaning of the remainder (e.g., uses remainder as the answer).
* Misaligns place value when writing or adding partial products, or in long division.
* Omits a partial product or rounds up instead of using complete groups only.
* Uses the wrong operation (multiply instead of divide or vice versa).

Difficulty Definitions:
* Easy:
  Multiplication: two 2-digit factors, products ≤ 1,000. Division: 2-digit ÷ 2-digit or 3-digit ÷ 2-digit, small result.
Familiar context with minimal wording.
* Medium:
  Multiplication: one factor up to 3 digits and one up to 2 digits; products up to 10,000.
Division: 3-digit or 4-digit ÷ 2-digit; may have remainder or require interpreting remainder / complete groups only.
Real-world context with clear "groups" or "in each" phrasing.
Same number ranges; less obvious whether to multiply or divide; or distractors include wrong operation.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.3+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Division Word Problems with Remainders
Lesson Order: 161.0
Standard ID: TEKS.MATH.CONTENT.5.3.C+2
Standard Description: Solve division problems involving up to four-digit dividends and two-digit divisors, interpret remainders appropriately, and explain what the remainder represents in context.

Key Concepts:
*None specified*

Learning Objectives:
* Solve division problems and interpret the remainder in context (two-part: answer and meaning of remainder).
* Solve real-world problems involving division of whole numbers to find the quotient with a single numeric answer.
* Solve real-world problems involving division to find the greatest number of complete groups (result only; remainder discarded).

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Dividend up to four digits and divisor up to two digits
- Real-world word problems: finding how many groups, how many per group, or interpreting quotient and remainder.
- No formulas or key words provided in the question stem.

Common Misconceptions:
* Makes procedural errors while performing the long division algorithm, such as miscalculating multiplication or subtraction steps, bringing down digits incorrectly, or selecting the wrong digit for the quotient.
* Misinterprets the remainder, treating it as the final answer or ignoring its meaning in the context of the problem instead of recognizing it represents leftover items that do not form a complete group.
* Rounds the quotient up instead of using only complete groups, misinterpreting the meaning of the remainder in situations that require whole groups.
* Uses the wrong operation (adds or subtracts the numbers) instead of dividing to determine the number of groups or how many times one quantity fits into another.

Difficulty Definitions:
* Easy:
  Division with 2-digit ÷ 2-digit or 3-digit ÷ 2-digit; quotient is a small whole number.
Familiar context with clear total and "per group" or "each."
Single-step interpretation (find the quotient only).
No remainder
* Medium:
  4-digit ÷ 2-digit; quotient must have remainder.
May require interpreting remainder (e.g., left over) or finding greatest number of complete groups.
* Hard:
  N/a

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.3+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Modeling Decimal Division with Area Pictoral Model
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.F
Standard Description: Represent quotients of decimals by whole numbers using pictorial models.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.3+1
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Modeling Decimal Division with Area Pictoral Model
Lesson Order: 181.0
Standard ID: TEKS.MATH.CONTENT.5.3.F+2
Standard Description: Represent quotients of decimals by whole numbers using pictorial models.

Key Concepts:
*None specified*

Learning Objectives:
* Complete a decimal division number sentence to represent a pictorial model
* Select the equation that represents division of a decimal by a whole number shown in a model of objects
* Select the expression that represents division of a decimal by a whole number shown in a tape diagram

Assessment Boundaries:
* Assessment is restricted to:
- Dividends are decimals to the hundredths, with values not exceeding 20
- Divisors are whole numbers from 2 to 9
- Quotients are decimals to the hundredths
- A pictorial model MUST be provided as a stimulus (objects, tape diagram, or area/grid model)
- No multi-step operations beyond identifying the division relationship

Common Misconceptions:
* Adds the number of groups to the total instead of dividing
* Divides by a number other than the number of equal groups in the model
* Multiplies instead of divides when equal groups are shown
* Subtracts the number of groups from the total instead of dividing

Difficulty Definitions:
* Easy:
  Select the correct division expression or equation from multiple choices given a pictorial model
Dividends are decimals to the tenths or hundredths
Single-digit divisors (2-5)
* Medium:
  Complete the full division number sentence to represent a pictorial model
Dividends are decimals to the tenths or hundredths
Single-digit divisors (2-9)
Student must determine all parts of the number sentence from the model
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Solving Equations with Two Levels of Grouping
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.4.B
Standard Description: Solve multi-step equations involving two levels of grouping with whole numbers, both with and without word problems.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Solving Equations with Two Levels of Grouping
Lesson Order: 164.0
Standard ID: TEKS.MATH.CONTENT.5.4.B+1
Standard Description: Solve multi-step equations involving two levels of grouping with whole numbers, both with and without word problems.

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate an equation with two levels of grouping
* Evaluate an equation with two levels of grouping with a real world context

Assessment Boundaries:
* Assessment is restricted to:
- Equations with exactly two levels of grouping (e.g., parentheses inside brackets).
- Whole numbers only; four operations (addition, subtraction, multiplication, division).
- A letter standing for the unknown quantity.
- No exponents.

Common Misconceptions:
* Chooses "None of these" where the correct answer is among the other options
* Disregards operations after solving for grouped calculations.
* Ignores outer or inner grouping and calculates left to right.
* Makes a mistake in a sub-calculation such as dividing by the wrong number or using the wrong place value

Difficulty Definitions:
* Easy:
  Solve without context (no word problem); equation or expression given directly.
The question stem does not have real world context.
Two levels of grouping with 4 terms inside groupings; whole numbers within 1–1000.
All (partial) results stay below 1000
* Medium:
  Solve with a word problem; the equation or expression is always given in the stem.
The real world context describes the equation in words in the question stem
Two levels of grouping with 4 terms; whole numbers within 1–1000.
All (partial) results stay below 1000
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Writing Equations with Variables
Lesson Order: 166.0
Standard ID: TEKS.MATH.CONTENT.5.4.B+2
Standard Description: Write and solve equations using variables to represent unknown quantities in real-world problems.

Key Concepts:
*None specified*

Learning Objectives:
* Choose the equation which can be used to find the unknown (given a word problem and a variable definition).
* Complete an equation that can be used to find an unknown by placing the correct operation symbols in the blanks for a word problem

Assessment Boundaries:
* Assessment is restricted to:
- Multi-step real-world problems involving the four operations with whole numbers.
- One letter standing for the unknown quantity.
- Equations of the form total = expression (e.g., 94 = 32 × b + 30).
- Whole numbers only; no fractions, decimals, or exponents.
- Totals and amounts 1–200; factors and addends 1–100.

Common Misconceptions:
* Confuses addition and multiplication when building the equation.
* Subtracts one known amount from the total in the equation.
* Subtracts the unknown from the sum instead of adding it.
* Uses subtraction for the remainder when total equals parts plus remainder.

Difficulty Definitions:
* Easy:
  Select which equation finds the unknown when the situation is "total = part + part + unknown" with direct wording (e.g., spends $X on A, $Y on B, rest on C).
Numbers are whole numbers; totals and amounts within 100.
* Medium:
  Complete the equation by placing operation symbols in blanks (given a word problem and equation frame).
Select which equation finds the unknown when one part involves multiplication (e.g., total = (amount per item × number) + remainder).
Numbers may be up to 3 digits; multi-step with two operations.
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Order of Operations
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.4.E
Standard Description: Apply the order of operations to evaluate and compare numerical expressions, including identifying errors in incorrect solutions.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Order of Operations
Lesson Order: 163.0
Standard ID: TEKS.MATH.CONTENT.5.4.E+1
Standard Description: Apply the order of operations to evaluate and compare numerical expressions, including identifying errors in incorrect solutions.

Key Concepts:
*None specified*

Learning Objectives:
* Describe what a set of parentheses or brackets indicates in a numerical expression (what should be done first in that grouping).
* Identify the first step in which an error appears when given a table showing an incorrect simplification of a numerical expression.
* Identify which operation should be performed first when simplifying a numerical expression that includes parentheses or brackets.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Expressions with parentheses and/or brackets and at least two operations (addition, subtraction, multiplication, division).
- No exponents; no variables.
- Focus on interpreting what parentheses or brackets indicate (what to do first), not on full evaluation of the expression.
- Up to two levels of grouping (e.g., parentheses inside brackets).
- Numbers in expressions are typically 1–3 digits.

Common Misconceptions:
* Confuses which grouping to simplify first when both parentheses and brackets appear.
* Thinks left-to-right order applies before doing parentheses.
* Thinks multiplication or division is always done before addition or subtraction, even when addition or subtraction is inside parentheses.
* Thinks the first operation written (leftmost) is the first operation to perform.

Difficulty Definitions:
* Easy:
  Describe what one set of parentheses or brackets indicates in an expression with two or three operations; numbers within 50.
Single grouping; no nesting.
* Medium:
  Identify which operation should be performed first in an expression with grouping; numbers within 100.
Describe what parentheses or brackets indicate when more than one operation appears outside the grouping.
* Hard:
  Identify where the error first appears.

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Evaluate Expressions
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.4.F
Standard Description: Evaluate numerical expressions using parentheses and the order of operations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Evaluate Expressions
Lesson Order: 159.0
Standard ID: TEKS.MATH.CONTENT.5.4.F+1
Standard Description: Evaluate numerical expressions using parentheses and the order of operations.

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate a single numerical expression and find its value when the expression is given in the stem (no word problem).
* Evaluate an expression in a real-world context when the equation is given.
* Given multiple expressions, identify which has (or does not have) a given value.
* Identify expressions equivalent to a given expression (select two correct answers).

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Expressions with up to two levels of grouping (parentheses and brackets).
- Operations: addition, subtraction, multiplication, and division.

Common Misconceptions:
* Evaluates inside grouping symbols incorrectly or ignores parentheses.
* Omits a step (e.g., forgets to add or subtract the final term).
* Performs addition or subtraction before multiplication or division.
* Uses the wrong operation (e.g., adds instead of subtracts).

Difficulty Definitions:
* Easy:
  No word problems and 2 or 3 steps.
* Medium:
  No word problem with 4 or 5 steps/operations.
Word problems with 2 steps.
* Hard:
  Word problems with more than two steps.
Multi-select.

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Writing Equations with Two Levels of Grouping
Lesson Order: 165.0
Standard ID: TEKS.MATH.CONTENT.5.4.F+2
Standard Description: Write numerical expressions and equations with two levels of grouping to represent real-world situations.

Key Concepts:
*None specified*

Learning Objectives:
* Select the equation in which a given variable represents the quantity in a multi-step situation with two levels of grouping.
* Select the expression that correctly represents a multi-step situation using two levels of grouping when the target value is given in the stem.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Expressions or equations with exactly two levels of grouping (e.g., parentheses inside brackets, or multiple grouped terms).
- Operations: addition, subtraction, multiplication, and division.
- Real world word problem that require writing the expression or equation that models the scenario (not evaluating a given expression).

Common Misconceptions:
* Applies division or final step to only part of the total.
* Applies per-group amount once to total instead of per group.
* Reverses add and subtract for amounts that increase or decrease the total.
* Uses addition instead of multiplication for repeated groups (e.g., 5+3 instead of 5×3).

Difficulty Definitions:
* Easy:
  Word problem with 2 steps and two level of grouping.
* Medium:
  Word problem with 3 or 4 steps and two levels of grouping.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade Supporting Lessons
Unit ID: Math Grade 5 Unit 15
Unit Name: Hole Filling
Cluster ID: TEKS.MATH.CONTENT.5.4+1
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Order of Operations Involving Decimals and Fraction
Lesson Order: 182.0
Standard ID: TEKS.MATH.CONTENT.5.4.F+3
Standard Description: Use order of operations to simplify numerical expressions.

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate a numerical expression with grouping symbols that is given in a real-world context with a list of quantities.
* Evaluate an abstract numerical expression using order of operations with up to two levels of grouping symbols (parentheses and/or brackets) to find its value.
* Identify which expression is equivalent to a given numerical expression with grouping symbols.

Assessment Boundaries:
* Assessment is restricted to:
- Numerical expressions that do NOT involve exponents.
- Up to two levels of grouping (parentheses and brackets).
- Operations: addition, subtraction, multiplication, division with whole numbers, decimals (tenths and hundredths), and fractions.
- Numbers and results stay within grade 5 scope.
- Numbers are limited to whole numbers and decimals (tenths and hundredths).
- No more than 5 operations per expression.

Common Misconceptions:
* Does addition or subtraction before multiplication or division
* Miscounts or misapplies the second level of grouping when brackets are present.
* Multiplies or divides only the number next to the grouping, not the whole value.
* Works left to right ignoring grouping and does operations in the order they appear.

Difficulty Definitions:
* Easy:
  Expression has one level of grouping (parentheses only).
Uses 2–3 operations with whole numbers or simple decimals (tenths).
Expression is given in context with a short bullet-point list (2–3 items).
Straightforward evaluation: evaluate inside grouping, then left to right.
* Medium:
  Expression has one or two levels of grouping (parentheses inside brackets).
Uses 3–4 operations with decimals (tenths or hundredths).
May involve multiple grouped sub-expressions added together, e.g.,
5.75(6 + 5) + 8.50(2 × 4).
Context may require tracking multiple rates and quantities from a
bullet-point list.
May involve fractions.
* Hard:
  Expression has two levels of grouping (parentheses inside brackets), e.g.,
[2(3.50 − 0.80) + 4.85 + 2.40] − 3.00.
Uses 4–5 operations with decimals.
Expression structure makes left-to-right shortcuts tempting but incorrect.
Distractors closely mimic common order-of-operations errors.
Equivalent-expression questions require recognizing simplification without
evaluating the full expression.

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Taxes
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.A
Standard Description: Define income tax, payroll tax, sales tax, and property tax

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Taxes
Lesson Order: 158.0
Standard ID: TEKS.MATH.CONTENT.5.10.A+1
Standard Description: Define income tax, payroll tax, sales tax, and property tax

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Students should be able to match tax types with everyday examples (e.g., buying goods → sales tax).

Common Misconceptions:
* Assuming any owned item is subject to property tax.
* Confusing who pays the tax — employer, employee, or consumer.
* Mistaking sales tax as a tax on income instead of purchases.
* Mixing up what is being taxed — income, property, or purchases.

Difficulty Definitions:
* Easy:
  Given a statement that describes a type of tasks, identify which term best fits the definition. Definitions may include payroll, property, income, or sales tax.
* Medium:
  Determine which statement is IS or IS NOT an example of a property tax.
Determine which statement is IS or IS NOT an example of a sales tax.
Determine which statement is IS or IS NOT an example of a payroll tax.
Determine which statement is IS or IS NOT an example of a income tax.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.10.E
Standard Description: Describe actions that might be taken to balance a budget when expenses exceed incom

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.10
Cluster Name: The student applies mathematical process standards to manage one's financial resources effectively for lifetime financial security.
Lesson Name: Balancing a Budget
Lesson Order: 157.0
Standard ID: TEKS.MATH.CONTENT.5.10.E+1
Standard Description: Describe actions that might be taken to balance a budget when expenses exceed income

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Question Should contain:
* A simple budget table with clearly labeled income and expenses.
* Whole-number amounts (no decimals, no percentages).
* A single month or single time period (not multi-month or yearly).
* Expenses that are everyday, familiar, age-appropriate, such as: cell phone, allowance, entertainment, snacks, chores income, savings.
* A prompt that asks the student to:
    * Determine if the budget is balanced, OR
    * Decide how to adjust one item to make it balanced.
* Only one change needs to be made (e.g., adjust savings, reduce an expense, increase income).

Question should NOT contain:
* Decimals, percentages, fractions, or calculations involving interest.
* Multiple changes required at once (only one variable should change).
* Budgets involving adult-only financial concepts, such as: taxes, insurance, mortgages, loans, credit cards, investment earnings, rent.
* Situations requiring multi-step adjustments (e.g., change two expenses AND one income).
* Complex charts, graphs, or multi-category budgets (e.g., weekly + monthly + yearly).
* Any financial terms beyond 5th-grade TEKS, such as: interest rate, debit, credit, fees, deductions, balance forward, deposits.

Question should always be in format as shown below with an example (The values and scenario should change but the format should always be the same).
"""
Jordan needs to balance her May budget.<br><br><strong>Jordan’s May Budget</strong><br>\n  <h5 style=\"margin: 8px 0 4px;\">Income</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Source</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Allowance</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$35</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Pet-sitting</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$22</td>\n      </tr>\n    </tbody>\n  </table>\n\n  <h5 style=\"margin: 12px 0 4px;\">Expenses</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Expense</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Cell phone</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$15</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Snacks</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$9</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Entertainment</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$18</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Savings</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$19</td>\n      </tr>\n    </tbody>\n  </table><br>What can she do so that her budget is balanced?
"""

Common Misconceptions:
* Student guess the change instead of recalculating both sides.
* Students confuse “balanced” with “having money leftover.”
* Students forget that money saved still reduces the total money available.
* Students mix up the purpose of the totals.

Difficulty Definitions:
* Easy:
  - All questions are easy
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Writing and Simplifying Numerical Expressions
Lesson Order: 153.0
Standard ID: TEKS.MATH.CONTENT.5.3.B+1
Standard Description: Write numerical expressions and equations from real world situations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - All problems are set in an explicit real-world context, described either as a story or with clear bullet points.
- Never say step1 , step 2 and so on in the quetsion stem.
- Problems use only whole numbers (no decimals, fractions, or negative numbers).
- Only the four operations: addition, subtraction, multiplication, division. No exponentiation or advanced operations.

- All required multiplication must be up to three-digit × two-digit (e.g., 435 × 22).

- Expressions may involve up to two grouping symbols/levels (e.g., parentheses).

- Each problem contains all needed numbers and steps — no missing information.

- No problems require variables or algebraic manipulation unless specifically asking students to write an equation for a scenario.

- Question types must match one of three models:

  a) Verbal prompt—compute value.

  b) Real-world scenario (with or without bullets)—write the numerical expression.

  c) Write an equation (expression set equal to a variable) to model a word problem.

- No multi-step scenario chains (no “first do A, then for the answer to A do B…”); each problem is independent.

- All contexts, objects, and verbs are appropriate for 5th-grade reading and math readiness (school, food, home, money, sports, etc.).

- No context requiring interpreting a graph, table, or data set.

- No exponents, squares, roots, or advanced operators.

Common Misconceptions:
* - Confuses additive and multiplicative language, writing 3 + 8 instead of 3 × 8 for “3 boxes of 8.”
* - Ignores story order and writes operations in reading order, not reflecting “then” or “after.”
* - Misplaces grouping symbols, failing to show “add to the product” or “subtract after multiplying.”
* - Treats “each/per” situations as repeated addition of listed numbers instead of multiplication.

Difficulty Definitions:
* Easy:
  - Compute the requested value from a verbally stated problem involving addition and multiplication, ensuring any three-digit × two-digit multiplication is done.
Example:
"Nick added 55 to the product of 553 and 12. What is the sum?"
"A student multiplied 435 by the sum of 42 and 9. what is the product?"
* Medium:
  - Write the numerical expression for a real-world scenario described in three bullets, with each bullet representing one step of a three-step calculation. Always use a name never start sentences bare and never use step 1 , step 2 etc in quetsion stem.
Example:
"Margaret opened a new case of lightbulbs.

The case contained 3 boxes of lightbulbs with 8 lightbulbs in each box.

Margaret threw 2 of these lightbulbs in the trash because they were damaged.

Then she took 7 of the lightbulbs out of the case.

Which expression can be used to show the number of lightbulbs still in the case?

A. 3 × 8 - 2 + 7

B. 3(8) - 2(7)

C. 3 × 8 - (2 + 7)

D. 3 + 8 - 2 + 7"
* Hard:
  - Write an equation for a real-world scenario in which a numertical expression is set equal to a variable.
Example:
"An elementary school had 90 boxes of glue sticks. Each box had 36 glue sticks. Teachers put 6 glue sticks into each bag.
Which equation can be used to find b, the number of bags they can fill?

A. 90 × 36 ÷ 6 = b

B. 90 ÷ 6 + 36 = b

C. 36 × 90 + 6 = b

D. 36 × 6 × 90 = b"

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Two-Step Expressions Involving Multiplication of 3 Digit Numbers by 2 Digit Numbers
Lesson Order: 185.0
Standard ID: TEKS.MATH.CONTENT.5.3.B+4
Standard Description: Solve multi-step numerical expressions and word problems involving multiplication of whole numbers (up to 3-digit by 2-digit) and addition or subtraction.

Key Concepts:
*None specified*

Learning Objectives:
* Evaluate a two-step expression: add or subtract to get a sum or difference, then multiply a 3-digit number by that result; give the product.
* Evaluate a two-step expression: multiply a 3-digit number by a 2-digit number, then add or subtract a number; give the result.

Assessment Boundaries:
* Assessment is restricted to:
- Whole numbers only; no decimals or fractions.
- Two-step expressions only: one multiplication (3-digit by 2-digit or 2-digit by 3-digit) and one addition or subtraction.
- Multiplication uses exactly one 3-digit and one 2-digit factor.

Common Misconceptions:
* Makes a place-value or regrouping error in the multiplication step.
* Makes an error in the addition or subtraction step.
* Multiplies before finding the sum or difference first.
* Stops after the product and omits the add or subtract step.

Difficulty Definitions:
* Easy:
  Two-step word problem with multiplication (3-digit by 2-digit) then add or subtract; numbers yield products under 10,000.
Sum or difference doesn't require regrouping
* Medium:
  Two-step word problem with larger products > 10,000 or 3-digit sum/difference before multiplying.
Numbers may require regrouping.
* Hard:
  N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Multi-Digit Division Word Problems
Lesson Order: 149.0
Standard ID: TEKS.MATH.CONTENT.5.3.C+1
Standard Description: Divide with quotients of up to a four-digit dividend by a two-digit divisor.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Single-step division problems
- Whole numbers only; no decimals or fractions.
- Must have real world context
- Dividing numbers may NOT have a remainder

Common Misconceptions:
* Confuses regrouping steps during standard multi-digit division.
* Ignores "each" context, misinterpreting real-world division setups.
* Misapplies place value by misaligning dividend digits with divisor.
* Treats dividend digits as independent numbers, ignoring grouping.

Difficulty Definitions:
* Easy:
  2 digits divided by 2 digits
* Medium:
  3 digits divided by 2 digits
* Hard:
  4 digits divided by 2 digits

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Decimal Multiplication & Division: Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.E
Standard Description: Solve real world problems regarding multiplying and dividing decimal numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Decimal Multiplication & Division: Word Problems
Lesson Order: 152.0
Standard ID: TEKS.MATH.CONTENT.5.3.E+1
Standard Description: Solve real world problems regarding multiplying and dividing decimal numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Must be word problems with 3 sentences
- Decimals in question stem and answer up to thousandths
- Multiplication and division problems
- Includes questions involving money
- Any money amount has decimals up to hundredths
- No rounding
- Do not use ratio vocabulary, avoid the word “per”

Common Misconceptions:
* Confuses multiplication and division
* Ignores decimal place values when dividing or multiplying decimals.
* Misinterprets "each" in money division problems.
* Misplaces the decimal point when multiplying decimals.

Difficulty Definitions:
* Easy:
  ×: Two-digit decimal (<10) × two-digit whole number
÷: Decimal dollar amount (<$100) ÷ two-digit whole number
* Medium:
  ×: Three-digit decimal (<10) × two-digit whole number
×: Whole number × money amount (<$1)
÷: Decimal dollar amount (<$100, to hundredths) ÷ two-digit whole number
* Hard:
  ×: Three-digit decimal × three-digit decimal (both <10)
×: Three-digit decimal × two-digit number (one <10, one two-digit whole)
÷: Decimal dollar amount (<$100, with remainder → decimal) ÷ two-digit whole number

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions with Unlike Denominators: Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3.K
Standard Description: Solve word problems that involve adding and subtracting fractions with unlike denominators.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions and Decimals
Lesson Order: 150.0
Standard ID: TEKS.MATH.CONTENT.5.3.K+1
Standard Description: Solve word problems that involve adding and subtracting numbers when one is in decimal form and the other is in fractional form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Number Types: Students will add either a mixed number and a decimal or a proper fraction with a decimal.
- All the numbers used should be less than 100.
- Answers must be reduced to lowest terms.
- The answer option would only be in a fraction.
- May require regrouping.
- All questions should be real-world word problems.

Common Misconceptions:
* Students convert a fraction to a decimal but put the digits in the wrong place value
* Students round a mixed number to the nearest whole number before calculating instead of using its exact value
* Students select the wrong operation (addition instead of subtraction or vice versa)
* Students treat a mixed number as if it were only its whole-number part and completely ignore the fractional part in the calculation

Difficulty Definitions:
* Easy:
  - proper fractions only
* Medium:
  - mixed numbers
* Hard:
  - N/A

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions with Unlike Denominators: Word Problems
Lesson Order: 151.0
Standard ID: TEKS.MATH.CONTENT.5.3.K+2
Standard Description: Solve word problems that involve adding and subtracting fractions with unlike denominators.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Answers must always be positive
- The word problem should consist of three sentences, which are all in a single paragraph. The first sentence should present the first number, the next sentence should present the next number, and the last sentence should state what this question is calculating.
- The word problem should not directly give context of if the student needs to add/subtract by saying "total" or "in all," but the student has to understand the context from the question stem.
- For example, a question should be like(not exactly the same but have different scenarios): "A park bench is located 16 3/4 feet due north of an elm tree. A fountain is located 9 1/2 feet due south of the elm tree. What is the difference between the park bench and the fountain?"

Common Misconceptions:
* Adds or subtracts the numerators and also the denominators.
* Finds a common denominator but fails to create equivalent numerators.
* Subtracts the smaller fraction from the larger, ignoring the need to regroup.

Difficulty Definitions:
* Easy:
  - no regrouping any denominators are up to 5
* Medium:
  - may involve regrouping and at least one denominator is up to 10
* Hard:
  - may involve regrouping and any denominators are up to 10

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.3
Cluster Name: The student applies mathematical process standards to develop and use strategies and methods for positive rational number computations in order to solve problems with efficiency and
accuracy.
Lesson Name: Adding and Subtracting Fractions and Decimals
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.3K
Standard Description: Add and subtract numbers when one is in decimal form and the other is in fractional form.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.4
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Area and Perimeter Word Problems
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.4.H
Standard Description: Apply area and perimeter to solve problems involving 2 and 3 dimensional shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.4
Cluster Name: The student applies mathematical process standards to develop concepts of expressions and equations.
Lesson Name: Area, Perimeter and Volume Word Problems
Lesson Order: 154.0
Standard ID: TEKS.MATH.CONTENT.5.4.H+1
Standard Description: Apply area, perimeter  and volume to solve problems involving 2 and 3 dimensional shapes.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - MCQ options must include "Not here" as one option.
**Allowed Concepts**:
- Area: A = A = s × s
- Perimeter: P = 4s
- Volume:V= s x s x s

**Units** (No abbreviated form):
- Length/Width/Height: inches, feet, meters, centimeters, yards (full words only, never in, ft, m, cm, yd)
- Area: square inches, square feet, square meters, square centimeters, square yards
- Volume: cubic inches, cubic feet, cubic meters, cubic centimeters, cubic yards

**Decimal Constraints**:
- Maximum 2 decimal places
- Whole numbers: 1–1000

**Question Types by Concept**:

### Area Questions
**Type 1: Direct Calculation (Given l and w, find A)**
- Formula: A = l × w
- Task: Substitute and multiply
- Example: "A rectangle is 36 inches long and 24 inches wide. What is the area?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Working Backwards (Given A and one dimension, find other dimension)**
- Formula: l = A ÷ w (or w = A ÷ l)
- Task: Rearrange formula; divide
- Example: "A garden has an area of 48 square meters and width 6 meters. Find the length."
- Response: Numeric MCQ (select from 4 options)

***

### Perimeter Questions
**Type 1: Direct Calculation (Given l and w, find P)**
- Formula: P = 2(l + w) or P = (2 × l) + (2 × w)
- Task: Add dimensions, multiply by 2
- Example: "A rectangular rug is 2.5 meters long and 1.5 meters wide. What is the perimeter?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Working Backwards (Given P and one dimension, find other dimension)**
- Formula: w = (P ÷ 2) − l (or l = (P ÷ 2) − w)
- Task: Rearrange formula; divide, subtract
- Example: "A rug has a perimeter of 2.4 meters and length 0.8 meters. Find the width."
- Response: Numeric MCQ (select from 4 options)

***

### Volume Questions
**Type 1: Direct Calculation (Given l, w, h, find V)**
- Formula: V = l × w × h
- Task: Substitute and multiply three factors
- Example: "A cabinet is 15 feet long, 7 feet wide, and 9 feet high. What is the volume?"
- Response: Numeric MCQ (select from 4 options)

**Type 2: Finding Base Area from Volume (Given V and h, find B or base dimensions)**
- Formula: B = V ÷ h; then infer base arrangement
- Task: Divide; identify unit-cube base model
- Example: "A rectangular prism has volume 96 cubic inches and height 6 inches. Which model shows the base?"
- Response: Visual model matching (select from 4 isometric unit-cube base models)

**Type 3: Working Backwards (Given V and two dimensions, find third)**
- Formula: h = V ÷ (l × w) (or solve for l or w)
- Task: Rearrange; divide
- Example: "A box has volume 120 cubic meters, length 10 meters, width 4 meters. Find height."
- Response: Numeric MCQ (select from 4 options)

***

**Representations**:
- Unit cubes (isometric view, single-layer base models)
- 3D rectangular prisms with labeled dimensions and shaded floor
- Written dimensions (numbers with full unit names)
- Word problems with real-world contexts (dog crates, cabinets, gardens, rugs, boxes)

**Response Formats**:
- Multiple choice (4 options: A, B, C, D)
- Model selection (visual matching from 4 isometric grid options)
- Numeric answers with full unit names
- never mentions what is being asked in the options 
Ex: what is the area in square centimeters of the shaded floor of the prism?
Incorrect - 384 square centimeters of the shaded floor
Correct - 384 square centimeters

**Excluded (Out of Scope)**:
- Composite shapes
- Surface area calculations
- Non-rectangular prisms
- Unit conversions (feet to inches, etc.)
- Negative or zero dimensions
- Volumes exceeding 1000 cubic units
- Abbreviated units (in, ft, m, cm, yd, in², ft², m², in³, ft³, m³)

Common Misconceptions:
* Calculates perimeter by summing length and width only once.
* Calculates volume by adding dimensions instead of multiplying them.
* Confuses area and perimeter formulas by applying incorrect operation.
* Solves for missing dimension by subtracting known side from total perimeter.

Difficulty Definitions:
* Easy:
  - Image given. Unit squares or unit cubes visual model provided.
  - Number type: Whole numbers only (derived from unit count).
  - Uses unit squares/cubes: Yes, always.
  - Concepts asked: Area, Volume, or Perimeter (single concept per question).
  - Calculation complexity: Division or direct counting (e.g., 96 ÷ 6 = 16).
  - Response format: Select 1 of 4 visual models OR select numeric answer.
  - Examples:
VOLUME (Unit Cubes - SELECT MODEL)
Example 1:

"A rectangular prism is built from unit cubes. The volume is 96 cubic inches and the height is 6 inches. Which model could represent the base?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

Example 2:

"A box is made using unit cubes. The volume is 24 cubic units and the height is 2 layers. Which model could represent the base of this box?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

Example 3:

"A storage bin is filled with unit cubes. The volume is 120 cubic meters and the height is 5 meters. Which model shows the base?"

Image: 4 unit cube base models

Response: Select A, B, C, or D

AREA (Unit Squares - Shaded Grid - COUNT FROM IMAGE)
Example 1:

"A rectangular floor is covered with shaded unit squares. What is the total area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 16 square units, B. 18 square units, C. 20 square units, D. 24 square units

Example 2:

"A rectangular garden is outlined with shaded unit squares. What is the area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 30 square units, B. 40 square units, C. 42 square units, D. 50 square units

Example 3:

"A poster is covered with shaded unit squares. What is the total area in square units?"

Image: Shaded unit square grid (student counts the squares)

Response: A. 30 square units, B. 40 square units, C. 45 square units, D. 50 square units

PERIMETER (Unit Squares - Border Outline - COUNT FROM IMAGE)
Example 1:

"A rectangular picture frame outline is made with shaded unit squares around the edge. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 16 units, B. 18 units, C. 20 units, D. 24 units

Example 2:

"A rectangular garden border uses shaded unit squares all around the edge. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 20 units, B. 26 units, C. 32 units, D. 40 units

Example 3:

"A rectangular mat outline is made with shaded unit squares. What is the perimeter in units?"

Image: Shaded unit square border outline (student counts the border)

Response: A. 16 units, B. 18 units, C. 20 units, D. 22 units
* Medium:
  - No image of unit squares/cubes.
  - Number type: Whole numbers only (no decimals).
  - Concepts asked: Area, Volume, or Perimeter (single concept per question).
  - Calculation complexity: Direct formula application (multiply or add); multi-digit arithmetic acceptable.
  - Response format: Select correct numeric answer from 4 MCQ options.
  - Examples:
  - Example Q: "Gabriel's dog crate is 36 inches long, 24 inches wide, and 30 inches high. What is the area of the shaded floor in square inches?"
  - Example Q: "A cabinet is 15 feet long, 7 feet wide, and 9 feet high. What is the volume in cubic feet?"
AREA (Direct Calculation)
Example 1:

"Gabriel bought a dog crate shaped like a rectangular prism. The length is 36 inches and the width is 24 inches. What is the area of the floor in square inches?"

Answer options: A. 720 square inches, B. 864 square inches, C. 960 square inches, D. 1080 square inches

Example 2:

"A rectangular swimming pool is 50 feet long and 25 feet wide. What is the area in square feet?"

Answer options: A. 750 square feet, B. 1,000 square feet, C. 1,250 square feet, D. 1,500 square feet

Example 3:

"A kitchen tile floor is 12 feet long and 10 feet wide. What is the total area in square feet?"

Answer options: A. 44 square feet, B. 100 square feet, C. 120 square feet, D. 220 square feet

VOLUME (Direct Calculation)
Example 1:

"Priscilla built a cabinet 15 feet long, 7 feet wide, and 9 feet high. What is the volume of the cabinet?"

Answer options: A. 499 cubic feet, B. 630 cubic feet, C. 945 cubic feet, D. 1,260 cubic feet

Example 2:

"A shipping box measures 20 inches long, 15 inches wide, and 12 inches high. What is the volume in cubic inches?"

Answer options: A. 1,200 cubic inches, B. 2,400 cubic inches, C. 3,600 cubic inches, D. 4,800 cubic inches

Example 3:

"A storage container is 8 meters long, 6 meters wide, and 4 meters tall. What is the volume in cubic meters?"

Answer options: A. 96 cubic meters, B. 192 cubic meters, C. 288 cubic meters, D. 384 cubic meters

PERIMETER (Direct Calculation)
Example 1:

"A rectangular garden is 35 meters long and 20 meters wide. What is the perimeter in meters?"

Answer options: A. 55 meters, B. 70 meters, C. 110 meters, D. 220 meters

Example 2:

"A room is 18 feet long and 14 feet wide. What is the perimeter in feet?"

Answer options: A. 32 feet, B. 46 feet, C. 64 feet, D. 128 feet

Example 3:

"A rectangular playground is 60 yards long and 40 yards wide. What is the perimeter in yards?"

Answer options: A. 100 yards, B. 150 yards, C. 200 yards, D. 2,400 yards
* Hard:
  - No image required. Text-based word problem.
  - Should use decimals (maximum 2 decimal places) AND whole numbers.
  - Concepts asked: May ask for side length (missing dimension) OR area of a surface. Often requires formula rearrangement.
  - Calculation complexity: Inverse operations (÷ for ×, − for +); multi-step logic; decimal arithmetic.
  - Response format: Select correct answer from 4 MCQ options.
  - Examples:
  - Example Q: "A rectangular rug has a perimeter of 2.4 meters and length 0.8 meters. What is the width in meters?"
  - Example Q: "A rectangular garden has an area of 48 square meters. The width is 6 meters. What is the length in meters?"
AREA (Missing Dimension - Decimals)
Example 1:

"A rectangular rug covers 24.5 square feet. The length is 7 feet. What is the width in feet?"

Answer options: A. 3.0 feet, B. 3.5 feet, C. 17.5 feet, D. 31.5 feet

Example 2:

"A wall panel has an area of 60.75 square inches. The width is 7.5 inches. What is the length in inches?"

Answer options: A. 8 inches, B. 8.1 inches, C. 9 inches, D. 10.5 inches

Example 3:

"A rectangular tile covers 12.6 square meters. The length is 4.2 meters. What is the width in meters?"

Answer options: A. 2 meters, B. 3 meters, C. 3.5 meters, D. 4 meters

VOLUME (Missing Dimension - Decimals)
Example 1:

"A rectangular box has a volume of 54.4 cubic feet. The length is 8 feet and the width is 4 feet. What is the height in feet?"

Answer options: A. 1.7 feet, B. 1.8 feet, C. 1.9 feet, D. 2 feet

Example 2:

"A fish tank has a volume of 97.5 cubic inches. The length is 9 inches and the width is 5 inches. What is the height in inches?"

Answer options: A. 2.0 inches, B. 2.1 inches, C. 2.2 inches, D. 2.5 inches

Example 3:

"A storage container has a volume of 144.9 cubic meters. The length is 10.5 meters and the width is 6 meters. What is the height in meters?"

Answer options: A. 2.2 meters, B. 2.3 meters, C. 2.4 meters, D. 2.5 meters

PERIMETER (Missing Dimension - Decimals)
Example 1:

"A rectangular rug has a perimeter of 2.4 meters. The length is 0.8 meters. What is the width in meters?"

Answer options: A. 0.4 m, B. 0.8 m, C. 1.2 m, D. 1.6 m

Example 2:

"A picture frame has a perimeter of 15.6 feet. The length is 4.5 feet. What is the width in feet?"

Answer options: A. 2.5 feet, B. 3 feet, C. 3.3 feet, D. 4 feet

Example 3:

"A rectangular mat has a perimeter of 8.2 meters. The length is 2.5 meters. What is the width in meters?"

Answer options: A. 1.6 meters, B. 1.7 meters, C. 1.8 meters, D. 1.9 meters

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Scatterplots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.9.B
Standard Description: Solve problems based on data presented in scatterplots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Scatterplots
Lesson Order: 156.0
Standard ID: TEKS.MATH.CONTENT.5.9.B+1
Standard Description: Solve problems based on data presented in scatterplots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* Real world context only
Use whole numbers only
Each problem contains all needed numbers and steps — no missing information.
Dots must be on whole coordinates/scale units
No ratios
Scatterplot MUST have context (e.g. "The scatterplot shows ...\n")
Any table appearing in the question (stem or answer option) must follow the exact HTML structure and inline style format shown below — no deviation is allowed.
""" <h5 style=\"margin: 12px 0 4px;\">Hot Cocoa Sales and
Temperature</h5>\n  <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n    <thead>\n      <tr>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">High Temperature</th>\n        <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Hot Cocoa Sales</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">10 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$400</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">15 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$350</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n      </tr>\n      <tr>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">20 F</td>\n        <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$450</td>\n      </tr>\n    </tbody>
"""

Common Misconceptions:
* Assumes correlation implies causation when interpreting scatterplot data.
* Misapplies real world context by ignoring scatterplot data's paired nature.
* Treats unconnected dots as a continuous line in scatterplot problems.

Difficulty Definitions:
* Easy:
  - Match table to scatterplot
* Medium:
  - Identify the most common amount.
  - Interpret a point in context.
  - Determine how many more or how many less of something.
  - Determine the x value for the greatest or least y-value in context of the situation.
* Hard:
  - What fraction of a category had a value of a specific range.
  - Determine how many of the y variable there was when there were more than a given amount on the x variable in the context of the situation.

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Interpret Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.5.9.C
Standard Description: Solve problems using given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 5th Grade TEKS
Unit ID: Math Grade 5 Unit 14
Unit Name: TEK Supplemental
Cluster ID: TEKS.MATH.CONTENT.5.9
Cluster Name: The student applies mathematical process standards to solve problems by collecting, organizing, displaying, and interpreting data
Lesson Name: Interpret Graphs
Lesson Order: 155.0
Standard ID: TEKS.MATH.CONTENT.5.9.C+1
Standard Description: Solve problems using given data.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
* - Real world context only
- Use whole numbers only
- Each problem contains all needed numbers and steps — no missing information.

Bar graphs:
- All bars must reach an exact scale unit or be exactly in the middle of two. Each graph must have at least one bar in the middle.
- Use a maximum of 6 categories

Dot plots:
- Use 15-25 points

Stem-and-left plots
- Use 10-20 points
- Consecutive stems only

Generate ONLY questions with BAR GRAPHS.

Common Misconceptions:
* Adds or compares only some of the required values, not all specified by the problem.
* Confuses the heights or positions of bars/dots with category labels or axis values when extracting data.
* Misinterprets “at least,” “more than,” or “both” as “exactly” or just one condition in multi-step questions.
* Uses the graph’s order or visual proximity rather than precise values when combining or selecting data.

Difficulty Definitions:
* Easy:
  - One-step problem
* Medium:
  - Two-step problem
* Hard:
  - Bar graphs only,

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Reading Box Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.12(A)
Standard Description: Represent numeric data with box plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Reading Box Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.12(A)
Standard Description: Represent numeric data with box plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Reading Box Plots
Lesson Order: 14.0
Standard ID: TEKS.MATH.CONTENT.6.12(A)+1
Standard Description: Represent numeric data with box plots.

Key Concepts:
*None specified*

Learning Objectives:
* Identify the minimum, maximum, median, and quartiles (Q1, Q3) from a given numerical data set to determine the five-number summary.
* Match a given numerical data set to the correct box plot by calculating the five-number summary and comparing it to answer choices with straightforward differences.
* Match a given numerical data set to the correct box plot when answer choices have subtle differences, requiring analysis of data distribution, skew, or clustering patterns.

Assessment Boundaries:
* Assessment is restricted to:
- Numerical data sets consisting only of whole numbers (no decimals or fractions in the source data) within a single real-world context.
- Data sets must always be presented in ordered format (from least to greatest).


QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must strictly follow this three-part structure:
  1. Context Sentence: "The list shows [description of data context] of [number] [subjects] [timeframe/condition]."
  2. Data Display: [List of numbers separated by commas]
  3. Question: "Which box plot best displays a summary of these data?"
- The context sentence must clearly state what the numbers represent and the total count of values in the set.

Common Misconceptions:
* Assuming the whiskers show the full spread of all individual data points rather than only minimum and maximum.
* Believing the spacing on the box plot reflects the number of data values rather than the position of quartiles.
* Confusing the median with the mean and selecting a box plot based on an average instead of the middle value.
* Incorrectly identifying Q1 or Q3 by splitting the data set at the wrong point or miscounting values.

Difficulty Definitions:
* Easy:
  The data set is presented in strictly ordered format (least to greatest).
Data set size: 10 to 12 values.
Values may be distinct or include simple repeats (common in small data sets).
Task: Match the data set to the correct box plot (emphasizing clear position of min/max/median).
* Medium:
  The data set is presented in ordered format (least to greatest).
Data set size: 13 to 15 values.
Values may include some repeats.
Task: Calculate Q1 and Q3 (requires finding the median of halves).
* Hard:
  The data set is presented in ordered format (least to greatest) with clusters or significant skew.
Data set size: 16 to 20 values.
Values include multiple repeats (clusters) or outliers.
Task: Precision matching of skewed distributions.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Interpreting Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.12(B)
Standard Description: Use the graphical representation of numeric data to describe the center, spread, and shape of the data distribution in a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.12
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to analyze problems.
Lesson Name: Interpreting Dot Plots
Lesson Order: 17.0
Standard ID: TEKS.MATH.CONTENT.6.12(B)+1
Standard Description: Use the graphical representation of numeric data to describe the center, spread, and shape of the data distribution in a dot plot.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate statistical measures (range, interquartile range) and interpret complex proportional relationships
* Compare frequencies across groups and describe distribution patterns (symmetry, proportional comparisons)
* Identify visible features of a dot plot distribution (peak, gaps, clustering, total count)

Assessment Boundaries:
* Assessment is restricted to:
- Questions format (MCQ):
  Sentence 1: "The dot plot shows ... " <br><br>
  Sentence 2 (from the next line!): "Which statement best describes the data?" or "Which statement is supported by the data?"
- Questions format (Multi-Select, 6 options):
  Sentence 1: "The dot plot shows ... " <br><br>
  Sentence 2 (from the next line!): "Choose TWO correct statements about the data."
Dot plots with up to 9 dots at any single value and up to 12 values total.
Word problems set in clear, coherent, and realistic contexts.
Tasks that are appropriate and familiar for 6th-grade students and relevant to dot plots.
A variety of questions with logically sound correct answers and plausible distractors, covering:
Distribution features: symmetric, skewed.
Data features: interquartile range, clustering, gaps, range, peaks.
Compound comparisons: “less than half,” “more than half,” “there are more ___ with ___ than ___,” etc.

Common Misconceptions:
* Students claim gaps exist when all consecutive values have dots, or claim no gaps when clear missing values are present, by not systematically checking the number line
* Students identify the tallest stack of dots but name the wrong value on the number line, misreading the peak location
* Students incorrectly calculate interquartile range by misidentifying Q1 or Q3 positions, using wrong quartile formulas, or making arithmetic errors in the subtraction; students also calculate mean incorrectly by summing unique values instead of all data points
* Students reverse comparison results, claiming "more in group A than B" when actually B has more dots than A, due to careless counting or misreading the question

Difficulty Definitions:
* Easy:
  MCQ questions, no Multi-Select questions
  - Identify single, visible features: peak location, presence/absence of gaps, clustering area, or total count
  - Straightforward visual inspection, no calculations required
* Medium:
  MCQ questions, no Multi-Select questions
  - Compare frequencies between two specific values or ranges
  - Describe distribution patterns (symmetry, clustering)
  - Requires counting and comparing across multiple categories
  - Distractors show reversed comparisons or incorrect proportional statements
* Hard:
  Multi-Select Questions
  - Identify exact numerical values: peak, range, or interquartile range
  - Identify distribution shape: symmetrical, clustered
  - Answer options format: 6 total options presenting numerical values and distribution descriptions as complete statements
  - Distractors show common calculation errors:
  * Peak: off by 1-2
  * Interquartile range: wrong quartile positions, subtraction errors
  * Distribution: claiming symmetry when skewed

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Interpreting Box Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.13(A)
Standard Description: Interpret numeric data summarized in box plots.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Interpreting Box Plots
Lesson Order: 15.0
Standard ID: TEKS.MATH.CONTENT.6.13(A)+1
Standard Description: Interpret numeric data summarized in box plots.

Key Concepts:
*None specified*

Learning Objectives:
* Compare two box plots and evaluate statements about their relative ranges, interquartile ranges, or median positions.
* Evaluate statements about data distribution using proportional reasoning based on the quartile structure of a single box plot.
* Read and identify specific values from a box plot, including minimum, maximum, median, Q1, Q3, range, and interquartile range.

Assessment Boundaries:
* Assessment is restricted to:
- Represent data from diverse real-world contexts, appropriate for grade 6 students(Example, Backpack Weight (Pounds)). 
- UNITS: Always use full unit names as introduced in the context. DO NOT use abbreviations unless explicitly defined in the stimulus.
- ANSWER OPTIONS: Must include specific numerical values derived from the graph or precise quantitative comparisons. Avoid vague qualitative statements.
- SCALE: Ensure the number line scale is clearly visible and readable, with appropriate spacing between tick marks to avoid overcrowding. 

QUESTION STEM STRUCTURE REQUIREMENT:
For single box plot interpretation questions:
- Line 1: The box plot summarizes [context description including measurement unit and real-world scenario].
- Line 2: Which statement is best supported by the data in the box plot?

For two box plot comparison questions:
- Line 1: The box plots summarize the [context description including contexts being compared and number of observations].
- Line 2: Which statement best describes the data represented in the box plots?

Common Misconceptions:
* Calculating the difference between the Median and an endpoint (e.g., Median - Minimum) or a Quartile and an endpoint (e.g., Q3 - Maximum) instead of the correct IQR formula (Q3 - Q1).
* Calculating the total Range (Maximum - Minimum) when the question asks for the Interquartile Range (IQR), or vice versa.
* Confusing the value of a quartile (e.g., "18") with the percentage of data (e.g., "18% of students"), or incorrectly stating "most" data (implying >50%) falls in a single quartile section.
* Incorrectly claiming that a physically wider section of the box plot contains "more" data points (e.g., "Since the right whisker is longer, more data is there"), failing to recognize that each section holds exactly 25% of the data.

Difficulty Definitions:
* Easy:
  - Structure: ONE Box Plot.
  - Task: Direct identification of a single specific value (Min, Max, Median, Q1, Q3) or a single calculation (Range or IQR).
  - Constraint: The question targets ONE specific attribute.
  - Answer Options: Numerical values (e.g., "12") OR simple identification sentences (e.g., "The median is 12").
  - Example: "What is the median height?" (Options: 55, 60, 65, 70)
* Medium:
  - Structure: ONE Box Plot.
  - Task: Analyze the data distribution, percentages (25%/50%/75%), or evaluate the validity of descriptive statements.
  - Constraint: Requires understanding the quartile structure or checking multiple properties.
  - Answer Options: Descriptive sentences involving proportional reasoning (e.g., "50% of the data is between 10 and 20").
  - Example: "Which statement about the data is best supported?" (Option: "The interquartile range is 10, representing the middle 50% of data.")
* Hard:
  - Structure: TWO Box Plots.
  - Task: Compare two data distributions (centers, spreads, shapes) or evaluate complex statements comparing Range/IQR.
  - Constraint: Involves comparative language or calculations across two plots.
  - Answer Options: Comparative statements (e.g., "The range of Class A is greater than Class B").
  - Example: "Which statement best compares the data?" (Option: "The median of Group A is equal to the upper quartile of Group B.")

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.13
Cluster Name: The student applies mathematical process standards to use numerical or graphical representations to solve problems.
Lesson Name: Stem and Leaf Plots
Lesson Order: 16.0
Standard ID: TEKS.MATH.CONTENT.6.13(A)+2
Standard Description: Interpret numeric data summarized in stem-and-leaf plots.

Key Concepts:
*None specified*

Learning Objectives:
* Given a stem-and-leaf plot, compare counts of data points across different value ranges.
* Given a stem-and-leaf plot, identify basic statistical measures (maximum, minimum, range, or mode).
* Given a stem-and-leaf plot, interpret complex relationships involving percentages, ratios, or proportional statements.

Assessment Boundaries:
* Assessment is restricted to:
- Stem-and-leaf plots only (no other plot types in this standard)
- Whole number data values only (no decimals or fractions)
- Plots with 4-7 rows (stems)
- Questions presented as "Which statement is true?" or "Which statement is best supported by the data?"
- Answer choices are 2 options or 4 options
- Each stem-and-leaf plot includes a key explaining the notation (e.g., "3|5 means 35")
- No questions requiring students to create or draw stem-and-leaf plots
- No questions requiring calculation of mean or median
- Real-world contexts
- Students must interpret the plot, not create it

Question MUST follow the structure:

Never put \n inside LaTeX $$ ... $$! It is Strictly Prohibited!

The stem-and-leaf plot shows ________.

$$
\begin{array}{c}
\text{______}
\end{array}
$$

$$
\begin{array}{r|l}
\text{___} & \text{____} \\
\hline
x & x\ x\ x\ x \\
x & x\ x\ x\ x\ x \\
\end{array}
$$

$$
\boxed{\text{x|x means xx years}}
$$

Which statement is _______.

Strictly prohibited to put \n inside LaTeX $$ ... $$.

Example:
The stem-and-leaf plot shows the number of minutes each student spent reading during a weekend.

$$
\begin{array}{c}
\text{Reading Time (minutes)}
\end{array}
$$

$$
\begin{array}{r|l}
\text{Stem} & \text{Leaf} \\
\hline
2 & 0\ 5\ 8 \\
3 & 1\ 4\ 4\ 7\ 9 \\
4 & 0\ 2\ 6\ 8 \\
5 & 1\ 3\ 3\ 6 \\
6 & 0\ 5 \\
\end{array}
$$

$$
\boxed{\text{3|4 means 34 minutes}}
$$

Which statement is true?

A. More students read between 40 and 49 minutes than between 30 and 39 minutes.  
B. The most common reading time is 33 minutes.  
C. Half of the students read less than 40 minutes.  
D. The range of reading times is 45 minutes.

==

Vary the concept tested in each answer option - Don't just change numbers in the same format (!)
Include different types of statements:

Statistical measures
Comparisons between ranges (e.g., "more students in 30-39 than 40-49")
Proportional statements (e.g., "half the students", "more than 75%")
Counting statements (e.g., "eight students scored above 80")
Specific value claims (e.g., "the most common value was 32")

===

Real world context to use:

Video Game Tournament
Scores from one round of a popular game (number of points each player earned).

Daily Steps Challenge
Number of steps each student recorded on a fitness tracker during a school day.

Comic Book Collection
How many comic books each friend owns.

Basketball Free Throws
Number of free throws each team member made out of 20 attempts at practice.

Reading Marathon
Number of pages each student read in a week.

Lunchbox Fruit Count
How many pieces of fruit each student brought in their lunch on Friday.

Sticker Trading Club
Number of new stickers each kid traded for during recess.

School Bus Arrival Times
Arrival times (in minutes past 8:00) of the buses over several days.

Soccer Goals in a Season
Number of goals scored by each player on a soccer team.

Video Watch Time
Minutes each student spent watching educational videos for homework.

Pen/Pencil Lengths
Lengths of pencils in a classroom, measured to the nearest centimeter.

Plant Growth in Science Lab
Heights of bean plants after three weeks of growth.

Roller-Skating Speeds
Laps per 10 minutes each student completed at the skating rink.

Board Game Wins
Number of times each family member won a board game during game night week.

Pet Weights
Weights of classmates’ pets (cats, dogs, hamsters, etc.) to the nearest pound or kilogram.

Movie Night Ratings
Out-of-10 ratings students give for a set of movies.

Snowball Fight Scores
Number of snowballs each kid successfully hit a target with.

Summer Lemonade Stand
Number of cups of lemonade sold per day over a two-week period.

Arcade Tickets Collected
Number of prize tickets each kid earned at the arcade.

Roller Coaster Wait Times
Minutes groups waited in line for one popular ride.

Bike Ride Distances
Kilometers/miles each student biked during a weekend challenge.

Music Practice Minutes
Daily instrument-practice minutes for each member of the school band.

Blocks in Tower-Building Contest
Number of blocks used in each group’s tallest stable tower.

Ice Cream Scoops Sold
Number of scoops each flavor sold in a school fundraiser.

Steps to Climb the Playground Slide
Number of steps each student counts while going up different slides.

Puzzle Completion Times
Minutes it took each pair of students to finish the same jigsaw puzzle.

Birthday Party Guests’ Candy Count
Number of candies each guest collected from a piñata.

Recyclables Collected
Number of plastic bottles each class collected for an eco-project.

Classroom Temperatures
Temperatures measured in different rooms at the same time of day.

Rocket-Launch Distances (STEM Activity)
Distances paper rockets travel when launched with the same launcher.

Common Misconceptions:
* Students count stems instead of individual leaf values when finding totals, miss data points when counting across multiple stems for ranges like "50 and above", or confuse "more than X" with "X or more" when setting boundaries
* Students incorrectly calculate range by subtracting stem values (6-2=4) instead of actual values (69-20=49), or identify the mode as the stem with most leaves rather than the most frequently appearing individual value
* Students miscount when comparing groups across different stems, fail to add all qualifying leaves when a range spans multiple stems, or compare only the number of stems rather than the total count of leaves in each range
* Students misread the stem-and-leaf notation, treating 3|5 as "3 and 5" instead of "35", or identify extremes by looking only at first/last stems rather than combining stems with their smallest/largest leaves

Difficulty Definitions:
* Easy:
  - Identify or calculate a single, straightforward statistic (maximum, minimum, range, mode)
  - Simple counting of frequency for a specific value
  - 2-option format: Choose between two different basic statistics (e.g., max vs. range)
  - 4-option format: Choose the correct value for one statistic (e.g., which value is the mode)
  - Stem values: 1-4; Leaf values: primarily 0, 5, or simple single digits
  - Plot has 4-5 rows
  - Override: don't put Peak as the correct answer.
* Medium:
  - Compare counts across 2 distinct groups or value ranges
  - Determine which group/range has more or fewer data points
  - May combine group comparison with mode identification
  - 2-option format: Choose between two group comparison statements OR between a group comparison and a mode statement
  - 4-option format: Choose among multiple group comparison statements or mode candidates
  - Stem values: any single digits; Leaf values: any single digits
  - Plot has 5-6 rows
* Hard:
  - Interpret complex relationships involving percentages
  - Understand proportional language ("half," "three times as many")
  - May require interpreting stem-leaf values as percentages
  - Any stem and leaf values
  - Plot has 5-7 rows
  - May involve percentage interpretation

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Debit and Credit Cards
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(B)
Standard Description: Distinguish between debit cards and credit cards

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Debit and Credit Cards
Lesson Order: 19.0
Standard ID: TEKS.MATH.CONTENT.6.14(B)+1
Standard Description: Distinguish between debit cards and credit cards

Key Concepts:
*None specified*

Learning Objectives:
* Given a real world scenario describing someone considering a transaction, identify the optional action that is not possible for the person to take. Four answer options.
* Given a real world scenario where the type of card used (credit or debit) is explicitly mentioned, identify which statement is true. Four answer options.
* Given a real world scenario, answer Yes or No to a question specific to credit or debit card characteristics. Two answer options.
* Given a real world scenario, identify characteristics, comparative advantages, or shared features of credit cards and/or debit cards. Three answer options.
* Identify if a credit card or debit card was used based on a description of a real world scenario. Two answer options.

Assessment Boundaries:
* Assessment is limited to: 
- Question stem must contain real world context and be written from a third person perspective.
- The question must be answerable without any calculations. 
- Answer option should not contain "possibly with interest".

Common Misconceptions:
* Students may believe a credit card pulls money directly from the bank account.
* Students may believe a debit card can be paid off at a later date.
* Students may believe credit cards never charge interest if you make any payment.
* Students may think a debit card can be used to purchase items even if they do not have enough money in their account.

Difficulty Definitions:
* Easy:
  - Given a real world scenario, answer Yes or No to a question specific to credit
or debit card characteristics.
  - Identify if a credit card or debit card was used based on a description of a
real world scenario.
  - Given a real world scenario, identify characteristics, comparative advantages, or shared features of credit cards and/or debit cards.
* Medium:
  - Given a real world scenario where the type of card used (credit or debit) is explicitly mentioned, identify which
statement is true.
  - Given a real world scenario describing someone about to make a purchase with a specific payment method (credit or debit card), identify which statement describes what the payment method does not allow or what does not happen when using it at the time of the transaction.
* Hard:
  - N/A

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Check Registers
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(C)
Standard Description: Balance a check register that includes deposits, withdrawals, and transfers

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Check Registers
Lesson Order: 18.0
Standard ID: TEKS.MATH.CONTENT.6.14(C)+1
Standard Description: Balance a check register that includes deposits, withdrawals, and transfers

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the missing balance in a check register
* Calculate the missing balance in a check register when previous balance values are blank
* Complete a row in a provided check register
* Select all true statements for a given check register

Assessment Boundaries:
* Assessment is limited to:
- Table headings must be Check #, Date, Transaction, Withdrawal, Deposit, and Balance
- Transaction values are short 2-3 word descriptions of the transaction
- Date values are in mm/dd format.
- All dollar sign symbols that are not intended as latex delimiters must use the hexadecimal numeric entity format &#36;

Common Misconceptions:
* Students may confuse the check number for a dollar amount that should be considered.
* Students may confuse the value in the balance column for a deposit or a withdrawl.
* Students may confuse the withdrawl and deposit columns and how they effect the balance.
* Students may treat the balance column as a one time calculation rather than a running total.

Difficulty Definitions:
* Easy:
  - Calculate the missing balance in a check register.
  - Question stem follows this format: "A portion of [name]'s check register is shown. [His/Her] checking account had a balance of &#36;[amount] on [date].[newline character][newline character]Based on the information in the check register, what was the balance of [name]'s checking account after the transaction on [date] in dollars and cents?"
  - Table includes 3 rows.
  - The missing value is the balance in the final row of the table.
  - Withdrawl and Deposit values are less than 300.
* Medium:
  - Complete a row in a provided check register.
  - Question stem follows this format: "A portion of [name]'s check register is shown. Before [name] made [his/her] [transaction description] on [date], the balance of [his/her] account was &#36;[amount].[newline character][newline character]Based on the information in the check register, complete the row for the transaction on [date]."
  - Table includes 3 rows.
  - The third row is the row that must be completed. The blanks are in the Withdrawl, Deposit, and Balance columns
  - Withdrawl and Deposit values are less than 600.
* Hard:
  - Calculate the missing balance in a check register when previous balance values are blank.
  - Question stem must follow this format exactly: "A portion of [name]'s check register is shown. [His/Her] checking account had a balance of &#36;[amount] before the transaction on [date].[newline character][newline character]Based on the information in the check register, what was the balance of [name]'s checking account after the transaction on [date] in dollars and cents?"
  - Table includes 3 rows.
  - The missing value is the balance in the final row of the table.
  - Withdrawl and Deposit values are less than 600.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Credit Reports
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.14(E)
Standard Description: Describe the information in a credit report and how long it is retained

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.14
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Credit Reports
Lesson Order: 20.0
Standard ID: TEKS.MATH.CONTENT.6.14(E)+1
Standard Description: Describe the information in a credit report and how long it is retained

Key Concepts:
*None specified*

Learning Objectives:
* Given a scenario describing negative information on a credit report, identify the typical timeframe that negative information remains on credit reports.
* Given a scenario involving a loan application or bank decision, identify how banks use credit reports to make lending decisions.
* Given a scenario or list of information types, identify which information is or is not included in a credit report.

Assessment Boundaries:
* Assessment is limited to:
- Basic information about credit reports and what they include.
- Worked examples should use newline characters to break up the text when a step has more than two sentences.
- Hints do not need to be used in answer option explantions, but if they are used, they must provide unique guidance and not simply restate the explanation
- Subject matter must be in one of the following categories:
    - Personal information: This includes your name, date of birth, addresses, telephone numbers, and employers.
    - Credit history: This is a list of your credit accounts, such as loans or credit cards. It also includes account balances, dates the accounts were opened, and payment history for the last 7 years.
    - Credit requests: This is a list of lenders, such as banks or credit card companies, that have requested your credit report in the last 2 years.
    - Public information: This is financial information about you that is found in public records, such as bankruptcies or past-due debt.

Common Misconceptions:
* Students may think all credit report information lasts forever.
* Students may think banks use credit reports to check education level or other non-financial information.
* Students may think credit reports include grades, test scores, or school performance.
* Students may think credit reports show current account balances or how much money someone has.

Difficulty Definitions:
* Easy:
  Answer questions about information in credit reports and how long it is retained
* Medium:
  N/A
* Hard:
  N/A

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.3
Cluster Name: The student applies mathematical process standards to represent addition, subtraction, multiplication, and division while solving problems and justifying solutions

The student applies mathematical process standards to develop concepts of expressions and
Lesson Name: Using Algebra Tiles to Represent Expressions and Equations
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.3(C)
Standard Description: Use algebra tiles to represent expressions and equations.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.3
Cluster Name: The student applies mathematical process standards to represent addition, subtraction, multiplication, and division while solving problems and justifying solutions

The student applies mathematical process standards to develop concepts of expressions and
Lesson Name: Using Algebra Models to Represent Expressions and Equations
Lesson Order: 7.0
Standard ID: TEKS.MATH.CONTENT.6.3(C)+1
Standard Description: Use algebra tiles to represent expressions and equations.

Key Concepts:
*None specified*

Learning Objectives:
* Identify algebra models from equations or expressions
* Identify equations or expressions from algebra models
* Simplify algebra models

Assessment Boundaries:
* - Items are **MCQ only**, with or without visual algebra-tile models.

- **MANDATORY QUESTION STEMS BY DIFFICULTY:**

  - **EASY:** "Which model shows two equal expressions when the value of $x$ is $4$?"

  - **MEDIUM:** "The circles in the model represent positive and negative units. Which equation is true based on the model?"

  - **HARD:** "The model represents an expression. Which model represents an equivalent expression?"

- **Algebra tiles must reflect STAAR conventions:**

  - Unshaded shape (triangle/square/rectangle/circle) = positive value ($+x$ or $+1$)

  - Shaded shape = negative value ($-x$ or $-1$)

  - Shape types:

    - Squares/Rectangles for variables ($x$) and constants ($1$).

    - Circles for integer units (+1/-1).

    - Triangles/Squares for variable ($x$) and constant ($1$) mixes.

- **Expressions and equations include:**

  - Linear expressions with positive or negative coefficients

  - Addition/subtraction of variables and constants

  - Single-step linear equations or expressions on both sides

- **Exclusions:**

  - No multi-step equation solving or variable isolation.

  - No quadratics ($x^2$).

  - No multiplication of variables.

- **Formatting:**

  - NO instructions field.

  - Use LaTeX for all math expressions.

  - **NEVER** use "dark/light" or "black/white" terminology—use **"shaded/unshaded"** only.

Common Misconceptions:
* Choosing a distractor that matches the numbers but not the signs or tile types.
* Incorrectly counting tiles or combining like terms.
* Misinterpreting tile signs (e.g: treating −x as +x).
* Treating x-tiles and unit tiles as equivalent or interchangeable.

Difficulty Definitions:
* Easy:
  - **Stem (STRICT):** "Which model shows two equal expressions when the value of $x$ is $4$?"; x is a number between 1 and 10
  - **Model Content:** 
  - Squares representing $x$ and $1$.
  - Equation setup: Expression with $x$ tiles = Expression with $1$ tiles (or mixed).
  - Example: $4x = 4$ or $x + 2 = 6$.
  - Total tiles ≤ 10.
  - Context is checking equivalence by substitution (visualized).
* Medium:
  - **Stem (STRICT):** "The circles in the model represent positive and negative units. Which equation is true based on the model?"
  - **Model Content:** 
  - Circles ONLY (Unshaded = +1, Shaded = -1).
  - Represents integer addition/subtraction equations.
  - Example: 3 unshaded circles and 5 shaded circles.
  - Count: Between 10 and 15 circles total.
  - Arrangement can be irregular.
* Hard:
  - **Stem (STRICT):** "The model represents an expression. Which model represents an equivalent expression?"
  - **Model Content:** 
  - Geometric shapes (Triangles, Squares) representing variables and constants.
  - Example: Unshaded Triangle = $x$, Shaded Triangle = $-x$, Unshaded Square = $1$, Shaded Square = $-1$.
  - Task: Simplify an expression by cancelling zero pairs (positive + negative).
  - Total shapes: 10 to 15.
  - Requires recognizing equivalent simplified forms.

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Identifying Situations for One-Step Inequalities
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.9(A)
Standard Description: Identify situations that represent given inequalities.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Identifying Situations for One-Step Inequalities.
Lesson Order: 10.0
Standard ID: TEKS.MATH.CONTENT.6.9(A)+1
Standard Description: Identify situations that represent given inequalities..

Key Concepts:
*None specified*

Learning Objectives:
* Identify situations that represent given inequalities

Assessment Boundaries:
* - Items are **MCQ only**, with **exactly four answer choices**.

- All items match the STAAR pattern:  
  "Which situation is best represented by this inequality?"  
  or  
  "Which situation can be represented by the inequality…?"

- Inequalities:
  -- Single-variable, one-step inequalities:  
    --- Division: `x/k ≤ b`, `x/k ≥ b`, `x/k < b`, `x/k > b`  
    --- Multiplication: `kx ≤ b`, `kx ≥ b` ,  `kx < b`, `kx > b`
    --- Addition/subtraction: `x + a ≤ b`, `x – a ≥ b` , `x + a < b`, `x - a > b`
  -- No two-step inequalities, no compound inequalities, no multi-variable expressions.

- Coefficients and constants:
  -- Whole numbers or money values up to two decimals (STAAR-like values: 17.35, 624.60, etc.).
  -- Positive quantities only; no negative numbers.

- Contextual constraints:
  -- Contexts must be simple, concrete, and familiar: grouping items, sharing items, hourly pay, unit costs.
  -- Situations must follow STAAR style:
    --- "x items shared into k groups… no more than…"
    --- "Earning $a per hour… at least…"
    --- "Placed into k stacks… at most…"

- Language constraints:
  -- Must match STAAR phrasing:  
    "at least," "at most," "no more than," "no less than,"  
    "more than," "fewer than," "each," "per hour," "in each stack,"  
    "brought her total to…", etc.

- **Answer Option Formatting Requirements:**
  -- ALL four answer options MUST use identical grammatical structure (all statements OR all questions, never mixed).
  -- If using question format: "A person earns $X per hour. How many hours…?"
  -- If using statement format: "A person earns $X per hour and needs to work enough hours to…"
  -- All options must be the same number of sentences and follow parallel phrasing.

- **Context Diversity Requirement (MANDATORY):**
  -- Each of the four answer options MUST describe a DIFFERENT real-world context.
  -- NO two options may share the same noun/object (e.g., if option A uses "stickers," options B, C, and D must each use a different noun such as "tickets," "crayons," "boxes," "cakes," etc.).
  -- All four contexts must make real-world sense for the inequality structure.
  -- Example valid set: Option A = stickers divided into piles; Option B = tickets split among friends; Option C = crayons placed in boxes; Option D = cookies shared into bags.
  -- Example INVALID set: All four options about "stickers" (even with different numbers or phrasing).

- **Distractor Requirements:**
  -- Each distractor must be valid English and plausible, but incorrect because it:
    --- Uses the wrong inequality symbol meaning.
    --- Reverses multiplication/division roles.
    --- Misrepresents what x stands for.
    --- Switches "per group" and "total."
  -- ALL distractors MUST represent mathematically DISTINCT inequalities (no duplicates or overlaps).
  -- Do NOT create distractors where > and ≥ are both present with the same expression (these overlap).
  -- Do NOT create distractors where < and ≤ are both present with the same expression (these overlap).
  -- Ensure at least TWO distractors represent HIGH-LEVEL conceptual errors (e.g., confusing division vs multiplication, misidentifying variable role), not just simple symbol reversals.

- **Explanation Requirements (CRITICAL):**
  -- EVERY explanation (correct and incorrect) MUST include at least ONE scenario noun from the problem context (e.g., "hours," "crayons," "boxes," "dollars," "servers," "bags," "tamales").
  -- NEVER use inequality symbols (≥, ≤, >, <, =) in explanations; always spell out comparisons: "at least," "at most," "more than," "less than," "equal to."
  -- NEVER use praise language in the correct explanation (no "Great job!", "Excellent!", "Correct!").
  -- Correct explanation must GUIDE the student through the matching process using key terms from Direct Instruction.
  -- Incorrect explanations must provide EXPLICIT corrective steps that reference the article's anchor chart and walk through how to identify the correct structure.
  -- All explanations must be single paragraphs (no bullet lists).

- No requirement that students solve the inequality.

- Students only identify the **matching situation**, not the solution.

- Example stems:
  -- Jamal wrote the inequality x/16 ≤ 6. Which situation is best represented by this inequality?
  -- Which situation can be represented by 17.35x > 624.60?
  -- Which situation is best represented by the inequality x/12 ≥ 7?

Common Misconceptions:
* Choosing distractors that use the correct numbers but attach them to the wrong quantities or reversed inequality meanings.
* Confusing comparison phrases (e.g., reading “at most” as ≥ or “at least” as ≤).
* Misidentifying the variable’s role (treating x as the number per group instead of the total, or vice versa).
* Mixing up operations (interpreting x/k as kx or interpreting a rate situation as division instead of multiplication).

Difficulty Definitions:
* Easy:
  - Inequalities involve division of the form x/k ≤ b or x/k ≥ b or x/k < b or x/k > b
  - k is a small whole number (4–20); b is a small whole number (3–10).
  - Contexts: equal sharing or splitting (stacks, groups, piles).
  - Inequality meaning is signaled by explicit phrases: “no more than,” “at least.”
  - Distractors: wrong group size, wrong inequality phrase, wrong sharing direction.
* Medium:
  - Multiplication inequalities of the form ax ≥ b or ax ≤ b or ax > b or ax < b
  - a is a whole number or decimal money value (e.g., 9, 12.5, 14.5).
  - b up to three digits or money with decimals.
  - STAAR-style pay-rate or price-rate contexts.
  - Distractors mix up rate vs. total or flip ≥ / ≤ / > / <.
* Hard:
  - Inequalities involve division of the form x/k ≤ b or x/k ≥ b or x/k < b or x/k > b or multiplication of the form ax ≥ b or ax ≤ b or ax > b or ax < b
  - Numbers are larger: k up to 50; b up to 20; decimal rates such as 17.35, 19.95, or 22.80; totals in the hundreds or low thousands.
  - Contexts: same simple sharing, grouping, earning-per-hour, or price-per-item scenarios seen in STAAR, but with larger values.
  - Inequality meaning is still signaled by direct phrases such as “at least,” “at most,” “more than,” “no more than.”
  - Distractors include reversed inequality symbols, confusion between rate and total, or incorrect operation (multiplying instead of dividing, or vice versa).

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 14
Unit Name: TEKS Supplement
Cluster ID: TEKS.MATH.CONTENT.6.9
Cluster Name: The student applies mathematical process standards to use equations and inequalities to represent situations.
Lesson Name: Writing Inequality Word Problems.
Lesson Order: 9.0
Standard ID: TEKS.MATH.CONTENT.6.9(A)+2
Standard Description: Write one-step inequalities to represent real-world situations.

Key Concepts:
*None specified*

Learning Objectives:
* Determine the set of possible values for a variable given a one-step inequality representing a real-world situation.
* Identify one-step inequalities that represent real-world situations.

Assessment Boundaries:
* - Items are **MCQ only** with exactly four answer choices.

- The assessment consists of two distinct item types:

  **Type A: Inequality Formulation (Setup)**
  - The student reads a real-world scenario.
  - The student selects the one-step inequality that models the situation.
  - The inequality to solve is NOT provided—the student must write it.

  **Type B: Solution Determination (Solving)**
  - The student reads a real-world scenario AND is given the modeling inequality.
  - The student must identify the solution inequality (the range of possible values for the variable).
  - The inequality to solve is ALWAYS provided in the question stem.

---

## Mandatory Stem Formats (STRICT)

### Type A Stem Format:
```
[Scenario describing the situation without defining the variable.]
Which inequality can be used to find [var], the [description of what var represents]?
```

**Example:**
```
Ms. Chen's car can travel no more than 510 miles on one full tank of gasoline. After filling up the tank, she traveled 194 miles. Which inequality can be used to find $m$, the number of miles Ms. Chen can travel with the remaining gasoline?
```

### Type B Stem Format:
```
[Scenario describing the situation without defining the variable.] The inequality shown can be used to find [var], the [description of what var represents].

[Inequality displayed on its own line, e.g., $x + 5 \leq 25$]

Which inequality represents all possible values of [var]?
```

**Example:**
```
Sarah walks no more than 25 dogs on Mondays. Mr. Jones has 5 dogs that Sarah walks. The inequality shown can be used to find $x$, the number of dogs Sarah can walk on Monday in addition to Mr. Jones's dogs.

$x + 5 \leq 25$

Which inequality represents all possible values of $x$?
```

---

## Variable Definition Rule

- **NEVER** define the variable in the scenario text (e.g., do NOT say "walks $x$ dogs" or "traveled $m$ miles").
- **ALWAYS** define the variable in the question stem (e.g., "to find $m$, the number of miles...").

---

## Allowed Inequality Forms

### Type A Answer Options (Setup Inequalities):
- Addition: $a + x \leq b$, $x + a \leq b$, $a + x \geq b$
- Subtraction: $a - x \leq b$, $x - a \leq b$, $x - a \geq b$
- Multiplication: $kx \leq b$, $kx \geq b$
- Division: $x/k \leq b$, $x/k \geq b$

### Type B Answer Options (Solution Inequalities):
- $x \leq c$, $x \geq c$ (for problems with ≤ or ≥)
- $x < c$, $x > c$ (for problems with < or >)

---

## Distractor Requirements

### Type A Distractors:
- Reversing inequality direction (≤ vs ≥).
- Incorrect operation (+ vs −, × vs ÷).
- Misplacing constants (e.g., $x - a$ vs $a - x$).
- All four options must represent mathematically distinct inequalities.

### Type B Distractors (CRITICAL):
- **Symbol consistency rule:**
  - If the given inequality uses **≤ or ≥**, ALL four answer options use ONLY ≤ or ≥ (never < or >).
  - If the given inequality uses **< or >**, ALL four answer options use ONLY < or > (never ≤ or ≥).
- **Symbol distribution rule:**
  - The correct symbol (e.g., ≤) appears in exactly **2** answer options.
  - The incorrect symbol (e.g., ≥) appears in exactly **2** answer options.
- **Value distribution rule:**
  - The correct value appears in exactly **2** answer options (one with correct symbol, one with incorrect symbol).
  - One incorrect value appears in exactly **2** answer options (one with correct symbol, one with incorrect symbol).
- **Common incorrect values:** Result of adding instead of subtracting (or vice versa), result of incorrect inverse operation.

**Type B Distractor Pattern Example:**
Given inequality: $x + 5 \leq 25$ → Correct answer: $x \leq 20$

| Option | Symbol | Value | Error Type |
|--------|--------|-------|------------|
| A | ≥ | 20 | Wrong direction |
| B | ≤ | 20 | **CORRECT** |
| C | ≥ | 30 | Wrong direction + wrong value (added instead of subtracted) |
| D | ≤ | 30 | Wrong value (added instead of subtracted) |

---

## Context and Language Constraints

- All quantities are nonnegative; no negative numbers appear.
- Context types follow STAAR patterns:
  - Capacity limits (tanks, containers, shelves)
  - Distance/travel (miles, fuel)
  - Quantity limits (dogs, cans, items)
  - Budget/spending (dollars)
  - Area/geometry (base × height)

- Language must match STAAR constructions:
  - "at least" → ≥
  - "at most" → ≤
  - "no more than" → ≤
  - "no less than" → ≥
  - "more than" → >
  - "fewer than" → <

---

## Example Items

### Type A Example:
**Stem:** A large water tank holds no more than 400 gallons of water. It currently contains 125 gallons. Which inequality can be used to find $w$, the number of gallons of water that can be added to the tank?

**Options:**
- A. $125 + w \leq 400$ ✓
- B. $125 + w \geq 400$
- C. $w - 125 \leq 400$
- D. $400 + w \leq 125$

### Type B Example:
**Stem:** A student needs to collect at least 50 cans for a recycling drive. He has already collected 15 cans. The inequality shown can be used to find $c$, the number of cans he still needs to collect.

$c + 15 \geq 50$

Which inequality represents all possible values of $c$?

**Options:**
- A. $c \geq 35$ ✓
- B. $c \leq 35$
- C. $c \geq 65$
- D. $c \leq 65$

Common Misconceptions:
* Choosing inequalities that incorrectly change the operation (e.g., using multiplication instead of subtraction, or addition instead of multiplication).
* Misplacing fixed amounts (treating starting amounts as variable or putting them on the wrong side of the inequality).
* Reversing the inequality direction when translating phrases like “at least,” “no more than,” or “more than.”
* Selecting distractors that use the right numbers but represent the wrong quantity or situation.

Difficulty Definitions:
* Easy:
  ### Type A (Setup):
  - **Operations:** Addition or subtraction only.
  - **Context:** Direct accumulation or usage (e.g., "has X, gets more", "has X, uses some").
  - **Keywords:** Explicit, direct phrases: "at least", "at most", "no more than", "no less than".
  - **Numbers:** Small whole numbers (1–50).

**Type A Examples:**
  - "A jar holds no more than 30 marbles. It has 12 marbles. Find $m$, the number of marbles that can be added."
  - "Tina needs at least 25 stickers. She has 10. Find $s$, the number of stickers she still needs."

### Type B (Solving):
  - **Inequality forms:** $x + a \leq b$, $x + a \geq b$, $a + x \leq b$, $a + x \geq b$
  - **Numbers:** Small whole numbers; solution is a small positive integer (1–50).
  - **Solving:** One-step subtraction to isolate variable.

**Type B Examples:**
  - Given: $x + 8 \leq 20$ → Solve for $x$
  - Given: $15 + c \geq 40$ → Solve for $c$
* Medium:
  ### Type A (Setup):
  - **Operations:** Addition, subtraction, OR simple multiplication/division.
  - **Context:** 
  - Addition/subtraction with moderate numbers.
  - Rates (price per item, miles per hour, items per box).
  - Two-part scenarios (e.g., "bought some and received more").
  - **Keywords:** Mix of explicit and slightly varied: "at least", "at most", "up to", "meet or exceed", "needs to have".
  - **Numbers:** Moderate whole numbers (20–150).

**Type A Examples:**
  - "Movie tickets cost $12 each. Maria has $80. Find $t$, the number of tickets she can buy." → $12t \leq 80$
  - "A shelf can hold up to 100 books. There are already 45 books. Find $b$, the number of additional books." → $45 + b \leq 100$
  - "A runner needs to run at least 60 miles this week. She has already run 25 miles. Find $m$, the additional miles needed." → $25 + m \geq 60$

### Type B (Solving):
  - **Inequality forms:** 
  - Addition/subtraction: $x + a \leq b$, $a + x \geq b$ (with moderate numbers)
  - Multiplication: $kx \leq b$, $kx \geq b$ (where $k$ is a small factor: 2–10)
  - Division: $x/k \leq b$, $x/k \geq b$
  - **Numbers:** Moderate range (20–150); solutions may be 2-digit numbers.
  - **Solving:** One-step operation (subtract, divide, or multiply).

**Type B Examples:**
  - Given: $x + 35 \leq 100$ → Solve for $x$
  - Given: $5x \leq 75$ → Solve for $x$
  - Given: $8t \geq 96$ → Solve for $t$
* Hard:
  ### Type A (Setup):
  - **Operations:** Any one-step operation, including subtraction from a starting amount ("left after" scenarios).
  - **Context:** 
  - "Left after" / remainder problems (e.g., "started with $X$, spent some, needs at least $Y$ left").
  - Area/geometry problems (area = base × height with constraints).
  - Multi-layer contexts requiring careful reading.
  - **Keywords:** Implicit or contextual limits: "remaining", "left over", "budget", "capacity", "savings", "allowance".
  - **Numbers:** Larger whole numbers (50–1000).

**Type A Examples:**
  - "Jake has $200. After spending money on supplies, he wants at least $75 left. Find $s$, the amount he can spend." → $200 - s \geq 75$
  - "A rectangular garden must have an area of at least 150 square feet. The width is 10 feet. Find $l$, the length." → $10l \geq 150$
  - "A truck can carry no more than 500 pounds. Find $w$, the weight of cargo if equipment weighing 180 pounds is already loaded." → $180 + w \leq 500$

### Type B (Solving):
  - **Inequality forms:** Any form, including $a - x \leq b$, $kx \geq b$ with larger numbers.
  - **Numbers:** Larger range (50–1000); solutions may require careful computation.
  - **Solving:** Requires careful attention to inequality direction, especially with subtraction or "left after" contexts.

**Type B Examples:**
  - Given: $200 - x \geq 75$ → Solve for $x$
  - Given: $4x \geq 340$ → Solve for $x$
  - Given: $x + 275 \leq 500$ → Solve for $x$

## Distribution Guidelines

  - Both **Type A** and **Type B** items should appear at **every difficulty level**.
  - Within each difficulty, aim for approximately equal distribution between Type A and Type B.
  - Ensure variety in contexts within each difficulty tier (don't repeat the same scenario type).

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 9
Unit Name: Rational Numbers, Number Lines and the Coordinate Plane
Cluster ID: TEKS.MATH.CONTENT.6.2
Cluster Name: The student applies mathematical process standards to represent and use rational numbers in a variety of forms
Lesson Name: Classifying Rational Numbers
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.6.2(A)
Standard Description: Classify whole numbers, integers, and rational numbers using a visual representation such as a Venn diagram to describe relationships between sets of numbers.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 6th Grade TEKS
Unit ID: Math Grade 6 Unit 9
Unit Name: Rational Numbers, Number Lines and the Coordinate Plane
Cluster ID: TEKS.MATH.CONTENT.6.2
Cluster Name: The student applies mathematical process standards to represent and use rational numbers in a variety of forms
Lesson Name: Classifying Rational Numbers
Lesson Order: 1.0
Standard ID: TEKS.MATH.CONTENT.6.2(A)+1
Standard Description: Classify whole numbers, integers, and rational numbers using a visual representation such as a Venn diagram to describe relationships between sets of numbers.

Key Concepts:
*None specified*

Learning Objectives:
* Analyze a set of multiple numbers and identify how each fits into a hierarchical number–set structure.
* Classify rational numbers, integers, and whole numbers based on their set relationships.
* Determine the correct placement of a given number within nested numerical sets using Venn diagrams.

Assessment Boundaries:
* Assessment is restricted to:
- Numbers limited to rational numbers, including integers, whole numbers, terminating decimals, repeating decimals, and fractions.
- Venn diagrams consisting of nested sets in the order: whole numbers inside integers, integers inside rational numbers.
- Tasks involving identification of membership in these sets without use of operations, equations, or transformations of the numbers.
- Graphic organizers limited to hierarchical or nested representations of number sets with 2–3 layers of inclusion.
- Answer choices presented only as diagrams or numbers; no open-ended explanations.
- Lists of numbers in the question stem must be separated by commas for readability.

QUESTION STEM STRUCTURE REQUIREMENT (Most Important Part)
- Every question must strictly follow the sentence pattern corresponding to its Learning Objective (LO):

  For LO1 (Identify number for a region):
  1. Context: "The Venn diagram shows the relationships among different sets of numbers."
  2. Question: "Which number would be located in the shaded part of the diagram?"

  For LO2 (Identify diagram for a single number):
  1. Question: "Which Venn diagram shows the correct relationship among different sets of numbers and the correct placement of [number]?"

  For LO3 (Identify diagram for a list of numbers):
  1. Question: "Which graphic organizer best represents the relationship among the numbers in the list?"
  2. Data Display: [number], [number], [number], and [number]

Common Misconceptions:
* Assuming that any decimal number cannot be rational.
* Believing that negative numbers cannot be integers.
* Believing that whole numbers include negative integers.
* Thinking that fractions are always placed outside rational numbers rather than being part of them.

Difficulty Definitions:
* Easy:
  - Identification of whether a number is a whole number, integer, or rational number using a two-set Venn diagram.
  - Selection of a single number that belongs exclusively to the region outside whole numbers but within integers or rational numbers.
  - 4 Answer Option
* Medium:
  - Determination of the correct placement of one specific number within a three-set nested Venn diagram.
  - Distinguishing whether the given number belongs to whole numbers, integers, or only rational numbers based on sign and form.
  - 2 Answer Options Only
* Hard:
  - Classification of a set of multiple numbers across multiple numerical sets simultaneously.
  - Determination of which multi-set diagram correctly organizes all given numbers in accordance with their membership.
  - 4 Answer Options ONLY

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Compare Dot Plots
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.12(A)
Standard Description: Compare two groups of numeric data using comparative dot
plots by comparing their shapes, centers, and
spreads.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Comparing Dot Plots
Lesson Order: 219.0
Standard ID: TEKS.MATH.CONTENT.7.12.A+1
Standard Description: Compare two groups of numeric data using comparative dot plots by comparing their shapes, centers, and spreads

Key Concepts:
*None specified*

Learning Objectives:
* - given two dot plots select a statement that is best supported by the two plots.
* - given two dot plots that do not display numbers on every tick of number line, select a statement that is best supported by the two plots.

Assessment Boundaries:
* - the question stem must have a real world scenario for the data.
- number of dots in the plot must be <= 30 and can be whole numbers or decimal with 0.5 precision.
- range of values can be maximum 18.
- values on the dot plot must be < 100
- the statements must be about comparing either of these - median, mode, variability, range, least, greatest, shape of distribution. It should never be about mean.
- distribution/shape comparisons are limited to symmetric, skewed right, skewed left or uniform.
- for comparison use any of these - "same", "different", "equal to", "less than", or "greater than".
- for range use the word "range". no use of spread or variability.
- difficulty definition must be strictly followed
- if data has even 1 decimal number (with 0.5 precision) then the range can be maximum 10.
- Never start question stem with a number or spelled out numbers like "Two groups" or "Two classes" or "2 groups" or "2 classes" etc.
- The question stem must have the word "dot plots" in it.
- in the dataset there should never be more than one mode i.e. only a single value should have the highest frequency.
- While generating worked examples please look at the stimulus description json values to accurately calculate the median, mode, least, greatest and range values.

Common Misconceptions:
* Assumes taller stacks median larger values, ignoring x-axis positions.
* Confuses center with extremes, comparing range instead of median.
* Ignores spread, concluding “more consistent” from symmetry rather than variability.
* Misapplies median by averaging two middle x-values without ordering all dots.

Difficulty Definitions:
* Easy:
  number of dots in each plot are between 10 and 15 (inclusive)
range is < 10
mcq answer options compasion statements must only use "same" or "different" (for eg, "the median of the data is the same for both data sets" or "the two populations have different median weights" etc.) At least two options must be both about "same" or "different". One option should be about the shape of the distribution (for eg, "plots have same skews", or "different skews" or "distribution of the data is symmetrical for both" / "uniform" / "left skewed" / "right skewed" etc. The remaing option can be either about distribution or about comparing (same / different) a statistic value.
if option related to skew is correct, then it should be obvious. since dots are less. let's keep range < 7 and number of dots exactly 15 whenever opiton related to skew is correct.
* Medium:
  number of dots in each plot are anywhere between 15 and 25 (inclusive).
range is either <=10 if data has a decimal value or between 10 and 15 (inclusive) if data has only whole numbers.
values may or may not have decimals with 0.5 precision
all mcq answer options must be comparison of either median, mode, range, least, or greatest using "less than", "greater than" or "equal to" or "equal for" or similar phrases.
* Hard:
  number of dots in each plot are anywhere between 20 and 30 (inclusive).
range is either <=10 (if data has decimal values) or between 14 and 17 if data is whole numbers only (inclusive).
values may or may not have decimals with 0.5 precision
all mcq answer options must be comparison of either median, mode, range, least, or greatest using "less than", "greater than" or "equal to" or "equal for" or similar phrases.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.12
Cluster Name: The student applies mathematical process standards to use statistical representations to analyze data.
Lesson Name: Comparing Box Plots
Lesson Order: 218.0
Standard ID: TEKS.MATH.CONTENT.7.12.A+2
Standard Description: Compare two groups of numeric data using comparative box plots by comparing their shapes, centers, and
spreads.

Key Concepts:
*None specified*

Learning Objectives:
* given two box plots select a statement that is best supported by the two plots.

Assessment Boundaries:
* - the question stem must have a real world scenario for the data.
- values must be < 100 and whole numbers or decimal with 0.5 precision.
- the answer options must be about comparing any of these - min, max, median, first quartile, third quartile, interquartile range, range.
- comparison must use "greater than" or "less than" or "equal to".
- answer options must be in this format "The <statistic> of the data for <category> is/was <comparison> the <statistic> of the data for <category>"
- The order of category in the comparison statements across the answer options may not be same.
- if decimal values are used (0.5 precision) then the whole range (max(max1, max2) - min(min1, min2) must be <=15
- in worked example, if a value is already calculated in while explaining a previous option, then do not recalculate. just state it directly

Common Misconceptions:
* Assumes the mean equals the median, using the median line to compare means.
* Confuses IQR with range, comparing whisker-to-whisker instead of box width.
* Misinterprets “spread” as the median’s position, not variability (IQR/range).
* Treats the longest whisker as the maximum value, ignoring the axis scale.

Difficulty Definitions:
* Easy:
  - the mcq answer options are only about two values from these: min, max, median, first quartile, third quartile, interquartile range, range. Two options for each value.
* Medium:
  - the mcq answer options are about four different values from these: min, max, median, first quartile, third quartile, interquartile range, range. 
  - values may or may not have decimals with 0.5 precision
* Hard:
  - the mcq answer options are about four different values from these: min, max, median, first quartile, third quartile, interquartile range, range. 
  - One option should be something which cannot be determined from box plot. (eg. comparing total number of data points of the two categories etc.) 
  - values may have decimals with 0.5 precision

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Net Worth
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.13(C)
Standard Description: Create and organize a financial assets and liabilities record and construct a net worth statement

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Family Budget
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.13(D)
Standard Description: Use a family budget estimator to determine the minimum household budget and average hourly
wage needed for a family to meet its basic needs in the student’s city or another large city nearby

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Net Worth
Lesson Order: 228.0
Standard ID: TEKS.MATH.CONTENT.7.13.C+1
Standard Description: Create and organize a financial assets and liabilities record and construct a net worth statement

Key Concepts:
*None specified*

Learning Objectives:
* Find the missing value in a table of assets and liabilities given the net worth.
* Find the net worth given a table of assets and liabilities.

Assessment Boundaries:
* Individual amounts must be <=$100,000.
Amount values must be whole numbers only.
Real world scenarios only, all tables must have real world context (e.g. "___ created the net worth statement shown." or "The table shows ___'s net worth statement."
Do NOT make Missing amount be to find value of car or house 
There must be negative numbers in answer options but there CANNOT be inverses of each other (e.g. 1000 is correct and -1000 is an answer option
Tables can have at most 6 rows for the entire question stem
Question should always be in one of 2 formats (Net Worth calculation or Missing amount calcularion) as shown below with an example (The values and scenario should change but the format should always be the same).
Net Worth:
"""
<h5 style="margin: 8px 0 4px;">Assets</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Assets</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">House (current value)</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$85,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Checking account</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$2,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Automobile</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$18,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Investments</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$7,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;"><strong>Total Assets</strong></td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$113,000</td> </tr> </tbody> </table> <h5 style="margin: 12px 0 4px;">Liabilities</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Liabilities</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Mortgage</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$62,000</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Credit card debt</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$9,500</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;"><strong>Total Liabilities</strong></td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$71,500</td> </tr> </tbody> </table>
"""
Missing Amount
"""
<h5 style="margin: 8px 0 4px;">Net Worth Statement</h5> <table style="border-collapse: collapse; width: 100%; max-width: 400px;"> <thead> <tr> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Item</th> <th style="border: 1px solid #000; padding: 4px; text-align: left;">Value</th> </tr> </thead> <tbody> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Bank accounts</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$3,900</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Car (current value)</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">?</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Credit card debt</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">−$2,950</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Real estate</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$37,425</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Student loans</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">−$1,700</td> </tr> <tr> <td style="border: 1px solid #000; padding: 4px; text-align: left;">Investments</td> <td style="border: 1px solid #000; padding: 4px; text-align: left;">$4,600</td> </tr> </tbody> </table>
"""

Common Misconceptions:
* Confuses net worth as assets plus liabilities, not assets minus liabilities.
* Misreads “total assets” or “total liabilities” as one line item, not a sum.
* Reverses the standard net worth formula
* Subtracts liabilities from each asset separately instead of from total assets.

Difficulty Definitions:
* Easy:
  N/A
* Medium:
  find the net worth given a table (image) of assets and liabilities.
* Hard:
  find the missing value in a table (image) of assets and liabilities given the net worth.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.13
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Budgets
Lesson Order: 229.0
Standard ID: TEKS.MATH.CONTENT.7.13.D+1
Standard Description: Use a family budget estimator to determine the minimum household budget and average hourly wage needed for a family to meet its basic needs in the student’s city or another large city nearby

Key Concepts:
*None specified*

Learning Objectives:
* Given a table of monthly budget for categories, find all categories individually representing more than x% of the total budget.
* Given a table of monthly budget select the equation to find the minimum family earnings needed annually.

Assessment Boundaries:
* Assessment Boundary
* A simple budget table with clearly labeled expenses.
* A single month or single time period (not multi-month or yearly).
* Expenses that are everyday, familiar, and age-appropriate.
* The total monthly cost may be implied and calculated by adding the values in the table. The total does NOT need to be explicitly shown in the stimulus.
* Derived values (such as the monthly total or annual total) may appear in answer choices even if they are not explicitly written in the table, as long as they can be logically calculated from the provided expenses.


Question should always be in format as shown below with an example (The values and scenario should change but the format should always be the same). Either Amounts or Percentages
Money Amounts:
"""
A monthly budget for a small family is shown.\n\n<h5 style=\"margin: 8px 0 4px;\">Monthly Budget</h5>\n <table style=\"border-collapse: collapse; width: 100%; max-width: 400px;\">\n <thead>\n <tr>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Category</th>\n <th style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Amount</th>\n </tr>\n </thead>\n <tbody>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Cell phone</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$150</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Food</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$300</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Transportation</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$200</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Entertainment</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$250</td>\n </tr>\n <tr>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">Savings</td>\n <td style=\"border: 1px solid #000; padding: 4px; text-align: left;\">$100</td>\n </tr>\n </tbody>\n </table>
"""

Common Misconceptions:
* - Confuses monthly and annual amounts, multiplying by 52 weeks instead of 12 months.
* - Ignores converting annual income to hourly wage using hours worked per year.
* - Misapplies percent-of-income, using percent of a category instead of total income.
* - Treats budget percentages as dollar amounts, adding percents directly to totals.

Difficulty Definitions:
* Easy:
  Given a table of monthly budget select the equation to find the minimum family earnings needed annually. Must be in format b = ____
* Medium:
  Given a table of monthly budget percentages for categories, select the statement that is supported by the table data.
Given a table of monthly budget for categories, find the percentage of total budget for a category..
* Hard:
  given a table of monthly budget for categories, find all categories individually representing more than x% of the total budget.
Given a table of monthly budget percentages for categories, select the statement that is NOT supported by the table data.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.5
Cluster Name: The student applies mathematical process standards to use geometry to describe or solve problems involving proportional relationships.
Lesson Name: Solving Similar Triangles
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.5(C)
Standard Description: Solve real-world problems involving finding measurements of similar triangles.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.5
Cluster Name: The student applies mathematical process standards to use geometry to describe or solve problems involving proportional relationships.
Lesson Name: Solving Similar Shapes
Lesson Order: 203.0
Standard ID: TEKS.MATH.CONTENT.7.5.C.1+1
Standard Description: Solve real-world problems involving finding measurements of similar triangles

Key Concepts:
*None specified*

Learning Objectives:
* given a pair of similar pentagons find the unknown side.
* given a pair of similar quadrilaterals find the unknown side.
* given a pair of similar triangles find an unknown side.
* given a pair of similar triangles or quadrilaterals, select the correct proportion equation to find out the side length.
* given a pair of similar triangles or quadrilaterals,select the correct statement about  those.
* given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.
* given nested triangles find the unknown side.

Assessment Boundaries:
* - scale factor from larger shape to smaller shape must always be a decimal representation of a fraction where numerator and denominator are <=10. (ignore this rule for task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle.)
- side length values must be less than 100.
- The variable is a lowercase letter representing the unknown side. variables must be from this list - a,b,c,i,j,k,x,y,z only. don't use letter "l" as it may look like 1 and confuse students. never use units with variables on stimulus image. for eg, do not use  like "x cm" or "y ft" etc.
- refer to trapezoids as "quadrilateral" in question stem and answer options. in stimulus description you can refer it as trapezoids.
- multi select questions must mention number of correct options in the stem. for eg, "Select TWO correct answers." or "Select THREE correct answers."
- never use multiplication symbol or dot notation. Use parenthesis instead (for eg, 5(10) ). Multiplication is allowed but using symbol is not.
- note for validator: for the task - given fully nested rectangles described in a real world scenario, find the unknown height (or length) or width of inner or outer rectangle., even if the stimulus has values for inner and outer height and width, the label is what is rendered in the image, so if value is 10 and label is "x mm" then the student sees "x mm" and not "10 mm" for that side
- flipping can only be done to triangle shape and trapezoid shapes. triangle must only be horizontally flipped. trapezoid shapes must only be either vertically flipped or "both" flipped.
- dont use "x" for variable. use other letters like "a", "b", "c", "y", "z", "i", "j", "k"
- Note to validators - the scale factor is never displayed to user.
- Note to validators - even if the question can be solved without the stimulus, the stimulus is still needed to give a visual guide to the student, so please do not fail for reasons like stimulus not required to solve.
- in worked example always use dfrac.
- in wokred example, when a line uses dfrac then use double new lines (\n\n) before moving on to next line.
- if worked example checks each option, then use double new lines (\n\n) before moving on to next option.

Common Misconceptions:
* Confuses corresponding sides by matching sides that appear in the same visual position (e.g., both at the top or both on the right of their shape) rather than using the vertex order from the similarity statement. Example: pairs the top-left side of triangle 1 with the top-left side of triangle 2 instead of using the vertex correspondence, resulting in an incorrect proportion.
* Matches corresponding angles based on visual position in the figures rather than the vertex correspondence from the similarity statement (e.g., claims angle NKL is congruent to angle XYZ because both appear at the top-left, ignoring that K corresponds to W).
* Sets up a proportion with correct corresponding sides but inverts (flips) the numerator and denominator of one ratio, creating an inconsistent equation (e.g., writes KL/WX = WZ/KN instead of KL/WX = KN/WZ). Example: writes 9/15 = a/30 instead of 9/15 = 30/a, getting a = 18 instead of a = 50.
* Treats similarity as additive, adding/subtracting a constant instead of multiplying by scale factor. Example: if the scale factor is 2 and a small side is 9 in., the student adds 2 to get 11 in. instead of multiplying to get 18 in.

Difficulty Definitions:
* Easy:
  Setting up the proportion and not solving it
All side lengths are whole numbers
Shapes are not nested and are not reflections of one another
* Medium:
  Setting up the proportion without solving it with side lengths including at least 1 decimal.
The scale factor is a whole number or unit fraction
Solving for the missing side length and all side lengths are whole numbers
* Hard:
  Solving for the missing side length and side lengths include at least one decimal
May include Include scale factors that are not a whole number or unit fraction
Shapes may be nested
Shapes may be flipped

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Solving Problems Using Data from Graphs Like Bar Graphs and Circle Graphs
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.6(G)
Standard Description: Solve problems using data represented in bar graphs, dot
plots, and circle graphs, including part-to-whole and part-topart comparisons and equivalents

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Solving Problems from Bar Graphs and Circle Graphs
Lesson Order: 230.0
Standard ID: TEKS.MATH.CONTENT.7.6.G+1
Standard Description: Solve problems using data represented in bar graphs, dot plots, and circle graphs, including part-to-whole and part-topart comparisons and equivalents

Key Concepts:
*None specified*

Learning Objectives:
* Given a bar graph showing counts/values, calculate the total and determine what percentage a specific category represents.
* Given a circle graph where exactly one percentage is not shown, calculate the missing percentage by subtracting the shown percentages from 100%, then use it to find the actual value or compare categories.
* Given a circle graph with all percentages shown, and a total provided in the question stem, find how many more/fewer items one category has compared to another.

Assessment Boundaries:
* - Single bar graphs must contain between 4 and 8 categories.
- Grouped bar graphs must have 4 to 6 time periods (e.g., Year 1, Year 2..., Week 1, Week 2..., Day 1, Day 2...) on the x-axis.
- The circle graph must contain between 4 and 6 categories.
- All category values shown in the graphs must be whole numbers.
- All percentages shown in the graphs must be whole numbers.
- Bar graph and grouped bar graph values must have the same order of magnitude (they can go up to 10⁵). And they must always be [whole-number] x [power of 10]. 310, 1520, 3200 not allowed. 300, 2000, 3000 allowed.
- Grouped bar graph answer options must use ONLY these comparison types: simple multipliers ("twice", "2 times"), percentage increase/decrease ("[N]% more/less than"), absolute differences ("[N] more/less than"), equality ("equal to"), trend statements ("increased by [N] each [period]"), combined values comparisons, or total comparisons across time periods.
- Grouped bar graph answer options must NOT use: ratios (e.g., 5:4), fractions of totals (e.g., 1/4 of the total), or percentage of total (e.g., "makes 30% of the total").
- In answer options, the numbers or fractions or equations or percentages may or may not be in latex. answer options can be a mix of latex and non latex.
- stimulus description can contain whole numbers writtern in decimal format. 
- In question stem, answer options and worked example use numbers with commas whenever number is >=1,000 (no need to follow this in stimulus description. there the number must be without comma)
- never use multiplicaiton symbols use parenthesis insted. fore g, no use of 5/10 x 100; use 5/10 (100). no use of dot notation.
- multi select questions must mention number of correct options in the stem. for eg, "Select TWO correct answers." or "Select THREE correct answers.".
- always use latex for fractions, never backslashes
- the grouped bar questions must not be about ticket sales.
- Question stems must include an introductory context sentence before the actual question. Use these templates as a guide (adjust naturally as needed):
  - For grouped bar graphs: "[Entity] tracked/recorded [data type 1] and [data type 2] [time period context]. The bar graph shows [what is measured] for each [time unit]. Which statement is supported by the information in the graph?"
  - For single bar graphs: "[Context sentence about who was surveyed or what was tracked]. The bar graph shows [what the graph displays]. [Question]"
  - For circle graphs: "A survey of [N] [people] asked about [topic]. The results are shown in the circle graph. [Question]"
- The introductory context must match the graph's title and categories (e.g., if graph title is "Favorite Activities", don't say "favorite hobbies" in the stem).
- When the graph uses specific category names (like month names or labels), the question stem should reference them consistently.
- in worked example first step should be "Find the missing percentage"

Common Misconceptions:
* - Assumes combined categories’ percent is averaged, not added from the graph.
* - Confuses part-to-part comparisons with part-to-whole when finding percentages.
* - Misreads bar-graph scale, counting tick marks instead of using equal-division values.
* - Treats circle-graph percent as the count, ignoring the total number surveyed.

Difficulty Definitions:
* Easy:
  Given a circle graph where exactly one percentage is not shown, calculate the missing percentage by subtracting the shown percentages from 100%, then use it to find the actual value or compare categories.
Given a bar graph showing counts/values, calculate the total and determine what percentage a specific category represents.
* Medium:
  Given a circle graph with all percentages shown, and a total provided in the question stem, find how many more/fewer items one category has compared to another.
Given a bar graph and a target percentage of the total, determine which combination of categories equals that percentage.
* Hard:
  Given a circle graph where some percentages are shown and others are not, use relationships provided in the question stem (e.g., "twice as many", "same as") to determine the unknown percentages/values, then verify which statements are true/false (multi-select).
Given a grouped bar graph comparing two data series across multiple categories, read values and perform calculations to determine which statement is true.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.6
Cluster Name: The student applies mathematical process standards to use probability and statistics to describe or solve problems involving proportional relationships.
Lesson Name: Real-World Problems Involving Scale Drawings
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.6.G+2
Standard Description: Solve scale drawing real world problems

Key Concepts:
*None specified*

Learning Objectives:
* Identify the scale (unit rate / ratio) or scale factor from corresponding lengths (determine the scale statement) and choose the best option.

Assessment Boundaries:
* - MUST assess **linear scaling only**: length, height, distance.

  a) NOT allowed: area scaling, volume scaling, similarity with angle measures, perimeter/area of scaled figures.
- MUST use a **scale relationship*- in one of these forms:

  a) “1 unit on the drawing/map/model represents (k) units in real life”
  b) “(a) units represent (b) units”
  c) “scale factor” only if the direction is explicit (**drawing → actual*- or **actual → drawing**) and units are aligned.
- MUST use **authentic real-world contexts*- (STAAR-like), such as:

  a) map distances between locations
  b) architect/engineer scale drawings (floor plans, building dimensions)
  c) scale drawings/models of real structures/landmarks
- MUST clearly state which measurement is **drawing/map/model*- and which is **actual/real**.
- MAY use metric and/or customary units. If mixed units appear, the item MUST be solvable with **one clear Grade-7 conversion step*- (e.g., feet↔inches, meters↔centimeters).
- Allowed solution methods: equivalent ratios, unit rates, multiplication/division, or a simple proportion.
- Allowed question types:

  a) **MCQ (exactly 4 options)**
  b) **Numeric Response / Gridded (text entry)**: student enters one number; prompt may say “Record your answer” / “use the correct place value.”
- Numbers may include whole numbers and terminating decimals.

  a) If the stem says **“closest to”**, estimation/rounding is allowed and options must bracket the computed value.
  b) Otherwise, expect an exact value (whole number or terminating decimal).
- MUST be framed in a clear real-world context (STAAR-like) using a varied set of scenarios (not limited to architect/engineer).

  a) Allowed contexts include, but are not limited to: maps and travel routes, city planning, parks/trails, school campus layouts, event venue layouts, construction/renovation plans, room/floor plans, sports fields/courts, bridges/roads, evacuation routes, utility layouts, museum/zoo layouts, hiking distance markers, landmark/structure replicas, or any other realistic situation where a scale drawing/model/map is used.

  b) NOT allowed: vague/abstract prompts such as “A drawing is made…” or “A figure is scaled…” without a specific scenario, identified objects/locations, and clear quantities.

Common Misconceptions:
* - Confuses drawing-to-actual direction, using the reciprocal scale factor.
* - Ignores unit conversion (inches↔feet, cm↔m) before applying the scale.
* - Sets up proportion with mismatched units (drawing units paired with real units).
* - Treats “a units represent b units” as b−a or b+a instead of ratio.

Difficulty Definitions:
* Easy:
  Ratio-form scale (e.g., “2 in represent 30 ft”) and/or decimals in measurements or scale.
May require **one*- unit conversion step.
Includes “identify the scale” items with common inverse-unit distractors.
MUST use MCQ only.
Decimals not allowed.
* Medium:
  Scale is given in clean unit-rate form (e.g., “1 cm represents 20 km”).
One-step multiply or divide; minimal/no unit conversion.
Straightforward map or scale drawing/model scenario.
* Hard:
  Two-Step Proportionality:*- Find the scale (unit rate / scale factor) from one corresponding pair (Pair A), then apply the same scale to a different dimension (Dimension B), including any required unit conversion.
May include “closest to” prompts requiring compute-then-compare.
Distractors combine errors (ratio inversion + conversion mistake + place-value shift).

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface and Lateral Area of a Rectangular Prism
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.7.9(D)
Standard Description: Solve problems involving the lateral and total surface area of a rectangular prism.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface and Lateral Area of a Triangular Prism
Lesson Order: 215.0
Standard ID: TEKS.MATH.CONTENT.7.9.D+1
Standard Description: Solve problems involving the lateral and total surface area of a triangular prism

Key Concepts:
*None specified*

Learning Objectives:
* - find the lateral surface area given an image of a net of a triangular prism with dimensions
* - find the total surface area given an image of a net of a triangular prism with dimensions

Assessment Boundaries:
* - Side length values are between 1 and 19 (inclusive)
- Side length values can be whole numbers or decimals with 0.1 precision
- units must be in short form (m, mm, cm, yd, in, ft) — for inches use "in" without a period
- area units must use superscript notation — write area units fully inside a single LaTeX math expression such as $\text{cm}^2$ (not cm$^2$). Do NOT split the unit text and superscript into separate math blocks. If no units then use "sqaure units" and not $\text{units}^2$.
- no use of variables in the question stem.
- the question stem must always be of this format "The net of a triangular prism and its dimensions are shown in the diagram.<new line after this>
What is the <total surface/lateral surface> area of the triangular prism in <area unit>?"
- for equilateral triangles the question stem must mention "equilatera" for eg, "The net of an equilateral triangular prism". Don't do this for isosceles or scalene.
- if you're approximating height of triangle mention that the height is approximate in the question stem. don't mention the value just let the student know the height is approximate.
- always use latex for fractions, never backslashes.
- no use of dot notation for multiplication
- Note: In the stimulus_description, label_all_sides=False is correct and expected. When use_net_labels=True, all unique dimensions are labeled once on the net, providing sufficient information to compute surface area.
- in worked example, every = sign on a new line.

Common Misconceptions:
* Student computes only the three rectangle areas (lateral surface area) and reports that as total surface area, omitting both triangular bases entirely. Error formula: TSA_wrong = prism_length × side_1 + prism_length × side_2 + prism_length × side_3 (missing the 2 × (1/2 × base × height) term).
* Student counts only one triangular base instead of two. Error formula: TSA_wrong = lateral_area + (1/2 × base × height) instead of lateral_area + 2 × (1/2 × base × height). This is exactly one triangle area less than the correct total.
* Student forgets to divide by 2 when computing the triangular base area, using A = base × height instead of A = (1/2) × base × height. Error formula: TSA_wrong = lateral_area + 2 × (base × height) instead of lateral_area + 2 × (1/2 × base × height). This adds one extra triangle area to the correct answer.
* Student replaces the triangle area formula with the triangle perimeter. Instead of computing A = (1/2) × base × height for each triangular base, the student adds the three side lengths and uses that sum as the "area" of one triangle. Error formula: TSA_wrong = lateral_area + 2 × (side_1 + side_2 + side_3).

Difficulty Definitions:
* Easy:
  one side is >= 10
asks total surface area only
trianglular bases are scalene only
* Medium:
  two sides are >= 10
asks total surface area only
trianglular bases are isosceles or equilateral.
trianglular base's height may be a decimal with one decimal place.
* Hard:
  two sides are >= 10
asks lateral surface area only
trianglular bases are scalene, or isosceles or equilateral
trianglular base's height may be a decimal with one decimal place.

---

Subject: Math
Course: 7th Grade
Unit ID: Math Grade 7 Unit 20
Unit Name: TEKS Supplementary
Cluster ID: TEKS.MATH.CONTENT.7.9
Cluster Name: The student applies mathematical process standards to solve geometric problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: 214.0
Standard ID: TEKS.MATH.CONTENT.7.9.D+2
Standard Description: Solve problems involving the total surface area of a rectangular prism

Key Concepts:
*None specified*

Learning Objectives:
* - find the total surface area given an image of a net of a rectangular prism with dimensions

Assessment Boundaries:
* - Side length values are between 1 and 19 (inclusive)
- Side length values can be whole numbers or decimals with 0.5 precision
- in question stem and answer options the units must be in short form (m/mm/cm/yd/in/ft.)
- area units must use superscript notation — write area units fully inside a single LaTeX math expression such as $\text{cm}^2$ (not cm$^2$). Do NOT split the unit text and superscript into separate math blocks. If no units then use "sqaure units" and not $\text{units}^2$.
- no use of variables in the question stem.
- the question stem must always be of this format "The net of a rectangular prism and its dimensions are shown in the diagram.<new line after this>
What is the total surface area of the rectangular prism in <area unit>?"

Common Misconceptions:
* Student adds areas of only 3 or 5 faces from the net, assuming some faces are not part of the prism or overlooking a matching opposite face.
* Student adds side lengths (or computes 2(l+w)) and may multiply by a height, producing a perimeter/lateral-perimeter style result rather than total surface area.
* Student assigns the wrong side lengths to a face in the net (e.g., swaps which measurement belongs to that rectangle) or makes an arithmetic error with 0.5 decimals when finding areas.
* Student treats total surface area as the number of faces (or an unweighted sum of side lengths) rather than the sum of the areas of all 6 faces.

Difficulty Definitions:
* Easy:
  one side is >= 10
* Medium:
  two sides are >= 10
* Hard:
  two sides are >= 10
up to two sides may use decimals with 0.5 precision.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Rigid Transformations: Preserved Properties
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.10.C
Standard Description: Determine whether a transformation on the coordinate plane preserves congruence—and justify why—recognizing that rotations, reflections, and translations preserve congruence while dilations do not.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Rigid Transformations: Preserved Properties
Lesson Order: 42.0
Standard ID: TEKS.MATH.CONTENT.8.10.C+7
Standard Description: Determine whether a transformation on the coordinate plane preserves congruence—and justify why—recognizing that rotations, reflections, and translations preserve congruence while dilations do not.

Key Concepts:
*None specified*

Learning Objectives:
* Given a list of named transformations, identify which transformation does NOT preserve congruence.
* Given a named rigid transformation applied to a polygon on a coordinate grid, select the true statement about which properties of the original figure are preserved
* Given a named rigid transformation applied to a polygon on a coordinate grid, select the true statement about which properties of the original figure are preserved.
* Given a verbally described rigid transformation applied to a named polygon, select the true statement about which properties of the original figure are preserved.
* Given an algebraic rule (x, y) → (expression, expression), identify which transformation type the rule represents by selecting from four named transformation options.

Assessment Boundaries:
* - Transformations on a coordinate plane centered at or relative to the origin
- Given an algebraic rule (x, y) → (expression, expression), student identifies the transformation type
- Transformation types tested:
  - Translation: (x, y) → (x + a, y + b)
  - Reflection across x-axis: (x, y) → (x, −y)
  - Reflection across y-axis: (x, y) → (−x, y)
  - 90° clockwise rotation about origin: (x, y) → (y, −x)
  - 180° rotation about origin: (x, y) → (−x, −y)
  - 270° clockwise rotation about origin: (x, y) → (−y, x)
  - Dilation from origin: (x, y) → (kx, ky) where k ≠ 1
- Given a named transformation applied to a polygon, student identifies which properties are preserved
- All questions are MCQ with 4 options
- Answer options are transformation descriptions in plain text OR property statements
- Polygons used: triangles, trapezoids, rectangles, pentagons, quadrilaterals
- EASY: rules involve whole numbers only; named transformation identification
- MEDIUM: rules involve fractions or decimals; or coordinate grid with original polygon and image shown
- HARD: verbally described transformation with property statements; no coordinate grid

Common Misconceptions:
* Confusing 180° rotation (x, y) → (−x, −y) with a reflection — not recognizing that both coordinates change sign in a rotation, whereas a reflection changes only one coordinate's sign.
* Confusing 90° clockwise rotation (x, y) → (y, −x) with 270° clockwise rotation (x, y) → (−y, x) — swapping the direction of rotation or misremembering which coordinate gets the negative sign.
* Confusing a dilation (x, y) → (kx, ky) with a translation (x, y) → (x + k, y + k) — not distinguishing between multiplying coordinates (dilation) and adding to coordinates (translation).
* Identifying a reflection across the x-axis (x, y) → (x, −y) as a reflection across the y-axis (x, y) → (−x, y), or vice versa — confusing which axis corresponds to which coordinate sign change.

Difficulty Definitions:
* Easy:
  Named transformation identification — "which does NOT preserve congruence?"
OR algebraic rule uses whole numbers only
Translation values are integers (e.g., x + 3, y − 5)
Dilation scale factors are whole numbers (e.g., 2x, 3y)
No stimulus; no coordinate grid
MCQ with 4 options
* Medium:
  Algebraic rule uses fractions or decimals (e.g., x + 1/2, y − 0.5, 3/4 x, 0.5y)
OR coordinate grid showing original polygon and its image after a named rigid transformation; "Which statement is true?"
Same transformation types as EASY
MCQ with 4 options
* Hard:
  Named rigid transformation described verbally (no algebraic rule, no coordinate grid)
"Which statement is true?" with property statements distinguishing side lengths, angle measures, area, perimeter, congruence
MCQ with 4 options

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Dilations: Effects on Area and Perimeter
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.10.D
Standard Description: Model the effect on linear and area measurements of dilated two-dimensional shapes

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.10
Cluster Name: The student applies mathematical process standards to develop transformational geometry concepts.
Lesson Name: Dilations: Effects on Area and Perimeter
Lesson Order: 40.0
Standard ID: TEKS.MATH.CONTENT.8.10.D+1
Standard Description: Model the effect on linear and area measurements of dilated two-dimensional shapes

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the new perimeter or area of a dilated figure given numerical values and a scale factor.
* Calculate the new perimeter or area of a dilated figure using the correct scaling relationship (k for perimeter, k² for area).

Assessment Boundaries:
* Assessment is restricted to:

- Shapes: generic "geometric figure" (EASY), named polygons (MEDIUM)
- Scale factors: positive whole numbers (EASY), fractions or whole numbers (MEDIUM)
- Allowed scale factors for MEDIUM: 2/3, 3/4, 2/5, 3/5, 4/5, 1/2, 1/3, 1/4, 3/2, 4/3, 5/3, 5/2, 5/4, 2, 3, 4, 5
- Do NOT use fractions with denominators > 5 (e.g., 8/13, 3/11, 5/12 are FORBIDDEN)
- Key relationships:
  - Perimeter scales by k (linear measure)
  - Area scales by k² (square measure)
- Non-stimulus based (text only, no graphs or images)
- All questions are MCQ with 4 options
- EASY uses numerical values; MEDIUM uses variable expressions
- Perimeter and area values are positive whole numbers (EASY) or variable expressions (MEDIUM)
- All EASY answers are whole numbers
- No dilation rules (x,y) → (kx, ky) — that belongs in standard +13

Common Misconceptions:
* Applying area scaling (k²) when perimeter scaling (k) is needed, or vice versa — e.g., computing perimeter × k² instead of perimeter × k.
* Over-scaling area: multiplying by k³ or k⁴ instead of k² — e.g., computing 12 × 3³ = 324 instead of 12 × 3² = 108, or applying k² twice to get 12 × 3⁴ = 972.
* Thinking dilation does not change the measurement — selecting the original perimeter or area unchanged.
* Using the reciprocal of the scale factor — e.g., dividing by k instead of multiplying, or using 4/3 instead of 3/4.

Difficulty Definitions:
* Easy:
  Numerical perimeter or area given (no variables)
Scale factor is a positive whole number (2, 3, 4, 5)
Question asks for the NEW perimeter or area after dilation
For perimeter: multiply by k
For area: multiply by k²
All answers are whole numbers with units
* Medium:
  Perimeter or area given as a variable expression
Scale factor given as fraction or whole number
Question asks for the NEW perimeter or area after dilation
For perimeter: multiply by k
For area: multiply by k²
Student must distinguish linear vs square scaling
* Hard:
  N/A

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.11
Cluster Name: The student applies mathematical process standards to use statistical procedures to describe data.
Lesson Name: Mean Absolute Deviation
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.11.B
Standard Description: Calculate the mean absolute deviation of a data set.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.11
Cluster Name: The student applies mathematical process standards to use statistical procedures to describe data.
Lesson Name: Mean Absolute Deviation
Lesson Order: 61.0
Standard ID: TEKS.MATH.CONTENT.8.11.B+1
Standard Description: Calculate the mean absolute deviation of a data set.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the mean absolute deviation from a pre-filled table that shows data values, the mean, differences from the mean, absolute values of the differences, and their sum.
* Calculate the mean absolute deviation of a decimal data set presented in a word problem context.
Select the correct MAD value from multiple choices.
* Calculate the mean absolute deviation of a whole-number data set presented in a word problem context.
Select the correct MAD value from multiple choices.

Assessment Boundaries:
* Assessment is restricted to:
- Assess only calculation of mean absolute deviation for a single data set.
- Data sets must contain no more than 10 data points.
- All data values must be non-negative.
- Require the complete MAD calculation process: find the mean, compute deviations from the mean, take absolute values, and compute the average of the absolute values.
- Forbid combining MAD with other statistical measures in the same item.
- Forbid data sets with negative values.
- Forbid use of technology or calculator-dependent steps.
- Keep all arithmetic within grade-appropriate ranges.
- Answer format constraint (unambiguous): Answer choices must be displayed as a whole number or a terminating decimal with at most 2 decimal places. The keyed correct option must equal the MAD rounded to 2 decimal places, even if the exact MAD has more decimals. No rounding instruction may appear in the question. Ensure exactly one answer choice matches the rounded-to-2-decimals MAD (no collisions).

Common Misconceptions:
* Student divides the sum of the absolute deviations by double the number of data points (2n instead of n), giving exactly half the correct MAD.
* Students calculate the mean of the data set and report it as the mean absolute deviation.
* Students perform an extra arithmetic step after finding the MAD, such as subtracting the MAD from the mean.
* Students sum values without completing the final division — either summing the absolute deviations or the raw data — and report that total as the MAD.

Difficulty Definitions:
* Easy:
  Provide a pre-filled table showing Data, Mean, Difference, and Absolute Value columns with all values computed and the Sum of absolute values shown.
Student only needs to divide the sum of absolute deviations by the number of data points to find the MAD.
Use whole number data values.
Use Constructed Response (Numeric Entry) format.
* Medium:
  Present a raw data list with whole numbers in a word problem context.
Student must calculate MAD from scratch: find the mean, compute each deviation, find absolute values, sum them, and divide by the count.
Use MCQ format with 4 answer choices.
* Hard:
  Present a raw data list with decimal values in a word problem context.
Student must calculate MAD from scratch with decimal arithmetic.
Use MCQ format with 4 answer choices.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Compound Interest
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.12.D
Standard Description: Calculate compound interest.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Simple Interest
Lesson Order: 56.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+1
Standard Description: Calculate simple interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the ending balance of a simple interest account.
* Calculate the interest earned on a simple interest account.
* Determine the annual simple interest rate of an account.

Assessment Boundaries:
* Assessment is restricted to:
- Simple interest only
- All scenarios involve a single lump-sum principal with no additional deposits or withdrawals
- Contexts include savings accounts, investment accounts, and insurance/life insurance policies
- Interest rate is expressed as an annual (yearly) rate
- Time is measured in whole number years
- Dollar amount answers must be expressed in dollars and cents
- Principal amounts range from hundreds to low thousands of dollars 
- Time periods range from 4 to 15 years
- Interest rates do not go beyond two decimal place values in percent form
- No calculations require rounding
- No formulas or expressions containing variables other than I = Prt in the answer option explanations

Common Misconceptions:
* Applies the compound interest formula A = P(1 + r)^t instead of simple interest I = Prt
* Confuses "balance" (P + I) with "interest earned" (I alone)
* Leaves the time variable out for calculations
* Multiplies by the percent number instead of its decimal equivalent (e.g., uses 8.5 instead of 0.085)

Difficulty Definitions:
* Easy:
  Task: find the ending balance, AND
Interest rate is a whole number percent
* Medium:
  Task: find the annual interest rate, AND
Interest rate is a whole number percent
* Hard:
  Finding the balance, finding the interest rate, or finding the interest earned, AND Interest rate is a decimal (non-whole-number) percent

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Understanding and Comparing Simple Interest
Lesson Order: 57.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+2
Standard Description: Calculate and compare simple interest earnings across different loan or investment scenarios.

Key Concepts:
*None specified*

Learning Objectives:
* Compare simple interest for multiple loan or investment options to determine the difference in interest paid.
* Compare simple interest for multiple loan or investment options to determine the greatest amount of interest paid.
* Compare simple interest for multiple loan or investment options to determine the least amount of interest paid.
* Determine which statement correctly describes how the ending balance changes each year.
* Identify which statement correctly explains why an account balance has grown.

Assessment Boundaries:
* Assessment is restricted to:
- Calculation is limited to simple interest
- All contexts are financial: loans, savings accounts, or investment accounts
- Interest rates are stated as annual percentages
- Deposit (principal) amounts are whole dollar values; interest rates, interest earned, and account balance may include decimal values
- All monetary values are in U.S. dollars

Common Misconceptions:
* Draws a conclusion from partial data — checks only one row of a table, one option in a set, or one variable — and assumes the pattern holds without verifying the rest
* Isolates a single factor (e.g., only the interest rate, only the loan term, or only deposits) and ignores how multiple variables jointly determine the total interest or account balance
* Misapplies the simple interest calculation — omits a variable, incorrectly converts a percent to a decimal, or uses the wrong value as the base for computing interest
* Reverses or misidentifies what the question asks — for example, finds the greatest instead of the least, or attributes growth to the wrong cause

Difficulty Definitions:
* Easy:
  Conceptual and interpretive; no formula calculations required
Student reads a table of account activity and selects the statement that correctly describes how interest and deposits affect the balance
* Medium:
  Comparing two interest payments
* Hard:
  Comparing four interest payments

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Compound Interest
Lesson Order: 59.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+3
Standard Description: Calculate compound interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the total balance of a compound interest account.

Assessment Boundaries:
* - Annual compounding only — no quarterly, monthly, daily, or continuous compounding
- No additional deposits or withdrawals after initial principal
- No negative amounts or debt/loan scenarios
- No variables — all values given numerically
- Students are NOT given the formula; they must know A = P(1 + r)^t
- No rates below 1% or above 15%
- No fractional years
- Principal range: $1,000–$25,000
- Time range: 1–10 years
- Answer format: dollar format rounded to nearest cent ($X,XXX.XX); stems may use "closest to" language
- Question types: MCQ, Multi-Select
- Contexts: savings accounts, investment accounts, retirement accounts (real-world required)

Common Misconceptions:
* Calculates interest for only the first year (P × r) and ignores the compounding effect over multiple years.
* Computes only the second-year interest increment (the interest earned during year 2 alone, A₂ − A₁) and reports it as the total interest after 2 years, instead of computing cumulative interest (A₂ − P).
* Converts percent to decimal incorrectly — divides by 1,000 instead of 100 (e.g., writes 9% as 0.009 instead of 0.09), producing a much smaller answer.
* Uses simple interest formula (I = P × r × t) instead of compound interest formula A = P(1 + r)^t. Produces a linear result instead of exponential growth.

Difficulty Definitions:
* Easy:
  Find the total balance (not just the interest)
Whole number or decimal percent (e.g., 6.5%, 4.25%)
Single computation of A = P(1 + r)^t
Principal: $1,000-$25,000
Time: 2-5 years
MCQ with 4 options
* Medium:
  Find the interest earned (not the balance)
Whole number percent (e.g., 5%, 8%, 9%)
Single time period - calculate A then subtract P
Principal: round amounts ($1,000-$10,000)
Time: 2-5 years
MCQ with 4 options
* Hard:
  Find the interest earned at the end of individual years (year 1 and year 2)
May use decimal percent (e.g., 2.5%, 3.5%)
Requires computing A for multiple values of t and subtracting P for each
Principal: round amounts ($1,000-$25,000)
Multiselect format

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Comparing Simple and Compound Interest
Lesson Order: 60.0
Standard ID: TEKS.MATH.CONTENT.8.12.D+4
Standard Description: Compare simple and compound interest.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the difference between simple interest and compound interest amounts.
* Compare the balances of a simple interest account and a compound interest account
      with the same interest rate.

Assessment Boundaries:
* - No quarterly, monthly, daily, or continuous compounding — annual only
- No additional deposits or withdrawals after initial deposit
- No negative amounts or debt/loan scenarios
- No variables — all values given numerically
- Students must know both I = Prt and A = P(1 + r)^t
- No rates below 1% or above 10%
- No fractional years
- Hard difficulty: N/A — not assessed for this substandard
- Answer format: dollar format rounded to nearest cent ($X,XXX.XX); stems may use "closest to" language
- Question types: MCQ (4 options)
- Contexts: savings accounts, bank accounts (real-world required)
- Principal range: $1,000–$5,000
- Time range: 2–5 years
- Interest rate range: whole number percent for Easy (1–10%); decimal percent for Medium (same or different rates across accounts)

Common Misconceptions:
* Applies the wrong interest formula — uses SI for both accounts or CI for both; may also report only one account's value instead of combining
* Miscounts the time period — uses t+1 or t-1 years, misreading when the interest starts or ends
* Misidentifies the interest rate — uses a rate ±1 percentage point from what's stated, or confuses the rate with another number in the problem
* Performs the wrong operation — adds both interest amounts instead of subtracting to find the difference, or vice versa

Difficulty Definitions:
* Easy:
  Whole number percent (e.g., 4%, 5%, 8%)
Principal ≤ $5,000
Same interest rate for both accounts
Time: 2–5 years
Asks for the sum of both account balances or individual balances
MCQ with 4 options
Cognitive demand: DOK2
Example stem: "What is the sum of the balances of Account I and Account II at the end of 3 years?"
* Medium:
  Common constraints:
Decimal percent (e.g., 1.5%, 2.75%, 3.5%, 4.5%)
Principal $1,000–$5,000
Time: 2–5 years
MCQ with 4 options
Cognitive demand: DOK2
Three question types:
Type 1 — Difference in interest (LO-2):
Same interest rate for both accounts
Asks how much more interest one account earns than the other
Example stem: "What is the difference in interest earned in Account I and the interest earned in Account II at the end of 2 years?"
Type 2 — Statement comparison (LO-3):
Different interest rates across accounts (e.g., 2.1% simple, 3.0% compound)
Asks which statement correctly describes the accounts
Example stem: "Which of the following correctly describes these accounts at the end of 5 years?"
Type 3 — Difference in balances (LO-4):
Same interest rate for both accounts
Asks for the difference between account balances
Example stem: "What is the approximate difference in balances of the two accounts at the end of 3 years?"
* Hard:
  N/A

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Calculating Savings
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.12.G
Standard Description: Solve problems involving savings.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.12
Cluster Name: The student applies mathematical process standards to develop an economic way of thinking and problem solving useful in one's life as a knowledgeable consumer and investor.
Lesson Name: Calculating Savings
Lesson Order: 61.0
Standard ID: TEKS.MATH.CONTENT.8.12.G+1
Standard Description: Solve problems involving savings.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the minimum monthly savings needed to reach a financial goal by applying sequential deductions (one fractional and one or more fixed-dollar amounts) to a total cost and dividing the remaining balance by the number of months
* Calculate total accumulated savings from a current balance and a monthly deposit plan, then compare the total against a table of cost options to identify which option(s) are affordable.
* Determine the minimum monthly deposit that meets a multi-year savings goal by calculating the total amount needed (annual cost × years), accounting for existing savings, and identifying the smallest deposit amount in a projection table whose projected value meets or exceeds the adjusted target.

Assessment Boundaries:
* Assessment is restricted to:
- All questions involve real-world financial scenarios related to saving for education or college costs.
- All monetary amounts must be positive and use the dollar sign ($) with values to the hundredths place when cents are involved.
- Total costs and savings amounts must be whole numbers or values to the hundredths place, not exceeding $50,000.
- Operations are limited to addition, subtraction, multiplication, and division of whole numbers and decimals.
- Fractional deductions are limited to unit fractions ($\frac{1}{2}$, $\frac{1}{3}$, $\frac{1}{4}$) or simple non-unit fractions.
- Questions may include tabular data presenting financial information (costs, deposit amounts, projected values).
- No tax calculations, compound interest formulas, percentage-based discounts, or interest rate computations.
- No algebraic expressions, equations, or variables.
- Question stems must be real-world scenarios between 20 and 120 words in length.
- Each question has exactly one correct answer and three plausible distractors.
- Distractors must result from applying common procedural errors to the same problem (not from unrelated calculations).
- At Easy difficulty, all information is given directly in the stem with no table. At Medium and Hard difficulties, a table is provided in the stem.

Common Misconceptions:
* Student does not follow the correct sequence of steps — applies operations in the wrong order (e.g., deducting before computing the total) or stops before checking all options (e.g., picks a qualifying deposit without verifying it is the smallest).
* Student miscalculates the target amount — forgets to multiply annual cost by the number of years, or confuses the savings projection period with the education cost period.
* Student miscalculates total savings — forgets to include starting balance, or double-counts the time period when computing accumulated deposits.
* Student misreads table data — selects the wrong row or column value when looking up costs, deposits, or projected amounts.

Difficulty Definitions:
* Easy:
  Sequential Deduction and Monthly Savings Calculation
A single total cost is given along with 2 to 3 deductions (one fractional and one or more fixed-dollar amounts).
The student applies deductions in the correct order to find the remaining cost, then divides by a number of months to find the minimum monthly savings.
All information is presented directly in the question stem (no table required).
The total cost is between $5,000 and $30,000.
The number of months is 12 or 24.
Answer choices are monetary values in dollars and cents.
* Medium:
  Total Savings Calculation with Table Comparison
The student is given current savings and a monthly savings plan, and must calculate total accumulated savings.
A table of 3 to 5 cost categories (with labels and dollar amounts) is provided in the question stem.
The student compares total savings against table values to evaluate which option is affordable.
Answer choices are statements about affordability that the student must evaluate as true or false; exactly one statement is true.
Monthly savings amounts are between $25 and $200, and savings periods are between 24 and 72 months.
* Hard:
  Goal-Based Minimum Deposit from a Projection Table
The student is given an annual cost, a number of years, existing savings, and a table showing projected future account values based on different monthly deposit amounts.
The student must first calculate the total amount needed (annual cost multiplied by the number of years), then compare this target to the projected values in the table to identify the minimum monthly deposit.
The projection table has 3 to 5 columns of deposit scenarios with corresponding future values.
Answer choices are monthly deposit amounts taken from the table.
Existing savings must be between $1,000 and $5,000 (must be greater than $0).

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: *None specified*
Standard ID: TEKS.MATH.CONTENT.8.7.B
Standard Description: Calculate the surface area of rectangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
*None specified*

Assessment Boundaries:
*None specified*

Common Misconceptions:
*None specified*

Difficulty Definitions:
* Easy:
  <unspecified>
* Medium:
  <unspecified>
* Hard:
  <unspecified>

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface Area of a Rectangular Prism
Lesson Order: 50.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+1
Standard Description: Calculate the surface area of rectangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the total surface area of a rectangular prism when a diagram is provided.
* Given a rectangular prism, identify another rectangular prism with the same total surface area.
* Given real-world context, calculate the missing dimension of a rectangular prism.
* Given real-world context, calculate the total surface area of a rectangular prism.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = Ph + 2B$
- Decimals are limited to values in the tenths place.
- All dimensions of prisms are less than 40 units.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses total surface area with volume by multiplying three dimensions.
* Ignores the (2B) term, calculating only lateral area (Ph).
* Misapplies (S=Ph+2B) by using base area instead of base perimeter.
* Treats each dimension as a face area and adds (l+w+h) (not (lw+lh+wh)).

Difficulty Definitions:
* Easy:
  Calculate total surface area when a visual model of the prism is provided.
* Medium:
  Calculate total surface area or a missing dimension without a visual model.
* Hard:
  Identify which rectangular prism has the same total surface area as the rectangular prism provided in the question.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface and Lateral Area of a Cylinder
Lesson Order: 51.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+2
Standard Description: Calculate the surface area and lateral area of cylinders.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the lateral surface area of a cylinder when a diagram is provided.
* Calculate the total surface area of a cylinder when a diagram is provided.
* Given a table with the dimensions of three cylinders, identify which two cylinders have the same lateral surface area.
* Given a table with the dimensions of three cylinders, identify which two cylinders have the same total surface area.
* Given real-world context, calculate the total surface area of a cylinder.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = 2 \pi r h + 2 \pi r^2$
- Lateral surface area formula is $S = 2 \pi r h$
- Decimal values are limited to the tenths or hundreths place.
- Dimension values are less than 20.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses diameter with radius when substituting into ($2\pi rh$) or ($2\pi r^2$).
* Omits one base area term, using ($2\pi rh+\pi r^2$) for total surface area.
* Treats ($2\pi r$) as ($\pi r$), forgetting the factor of 2 in circumference.
* Uses total surface area formula when asked for lateral surface area.

Difficulty Definitions:
* Easy:
  Calculate the total surface area of a cylinder.
All dimension values are integers.
* Medium:
  Calculate the lateral surface area of a cylinder when a diagram is provided.
* Hard:
  Identify which two cylinders have the same total surface area or the same lateral surface area.

---

Subject: Math
Course: 8th Grade TEKS
Unit ID: Math Grade 8 Unit 1
Unit Name: TEKS Supplemental
Cluster ID: TEKS.MATH.CONTENT.8.7
Cluster Name: The student applies mathematical process standards to use geometry to solve problems.
Lesson Name: Surface and Lateral Area of a Triangular Prism
Lesson Order: 52.0
Standard ID: TEKS.MATH.CONTENT.8.7.B+3
Standard Description: Calculate the surface area and lateral area of triangular prisms.

Key Concepts:
*None specified*

Learning Objectives:
* Calculate the lateral surface area of a triangular prism when a diagram is provided.
* Calculate the total surface area of a triangular prism when a diagram is provided.
* Given real-world context and a partial diagram, calculate the lateral surface area of a triangular prism.
* Given real-world context and a partial diagram, calculate the total surface area of a triangular prism.

Assessment Boundaries:
* Assessment is restricted to:
- Total surface area formula is $S = Ph + 2B$
- Lateral surface area formula is $S = Ph$
- Decimal values are limited to the place.
- Dimension values are less than 20.
- Formulas must not be provided in the question stem.

Common Misconceptions:
* Confuses total surface area with lateral area; uses S = Ph only.
* Ignores 2B term; adds just one triangular base area.
* Treats prism height h as triangle height in perimeter-times-height product Ph.
* Uses triangle side length as triangle height when finding base area B.

Difficulty Definitions:
* Easy:
  Calculate the total surface area of a triangular prism when a diagram is provided.
All dimension values are integers.
* Medium:
  Calculate the lateral surface area of a triangular prism when a diagram is provided.
* Hard:
  Given real-world context and a partial diagram, calculate the total or lateral surface area of a triangular prism.
