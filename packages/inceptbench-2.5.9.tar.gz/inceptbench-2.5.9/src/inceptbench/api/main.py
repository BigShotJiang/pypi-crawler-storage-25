"""
InceptBench REST API.

This module provides a REST API for evaluating educational content across
multiple dimensions including accuracy, curriculum alignment, and engagement.

Designed for Cloud Run and traditional server deployments (Docker, etc.).
"""

import asyncio
import logging
import os
import time
from contextlib import asynccontextmanager
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse

from .dependencies import EvaluationServiceDep, APIKeyDep
from .models import (
    CostSummary,
    CurriculumsResponse,
    CurriculumInfo,
    CurriculumVersion,
    ErrorResponse,
    EvaluationRequest,
    EvaluationResponse,
    FailedItem,
    HealthResponse,
    VersionsResponse,
)
from ..core.processor import BatchProcessor
from ..config.settings import settings
from ..config.constants import CURRICULUM_ABBREVIATION_TO_SLUG, CURRICULUM_NAME_TO_ABBREVIATION
from .. import __version__
from ..llm.base import get_usage_summary, init_usage_tracking
from ..llm.config import set_service_tier_override

logger = logging.getLogger(__name__)

# API Version - imported from package __init__.py
API_VERSION = __version__

# Concurrency control - max parallel evaluations per request
MAX_CONCURRENT_EVALUATIONS = int(
    os.getenv("MAX_CONCURRENT_EVALUATIONS", "10")
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for FastAPI application.
    
    Handles startup and shutdown events.
    """
    # Startup
    logger.info(f"Starting InceptBench API v{API_VERSION}")
    logger.info(f"Max concurrent evaluations: {MAX_CONCURRENT_EVALUATIONS}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down InceptBench API")


# Create FastAPI application
app = FastAPI(
    title="InceptBench API",
    description=(
        "AI-powered educational content evaluation service that assesses "
        "questions, quizzes, reading passages, and other educational "
        "materials across **11+ quality dimensions** including accuracy, "
        "curriculum alignment, clarity, misconception detection, and more."
        "\n\n"
        "## Useful Links\n\n"
        "- [Website](https://www.inceptbench.com/) - Official InceptBench site\n"
        "- [Benchmarks](https://benchmark.inceptbench.com/) - Benchmark results\n"
        "- [PyPI Package](https://pypi.org/project/inceptbench/) - Python package\n"
        "- [GitHub](https://github.com/trilogy-group/inceptbench) - Source code\n\n"
        "---\n\n"
        "## Authentication\n\n"
        "All evaluation endpoints require an API key. "
        "Click the **Authorize** button to enter your API key.\n\n"
        "---\n\n"
        "## Input Format\n\n"
        "All requests use a single array-based format:\n\n"
        "```json\n"
        '{\n'
        '  "generated_content": [\n'
        '    {\n'
        '      "id": "q1",\n'
        '      "request": {\n'
        '        "curriculum": "common_core",\n'
        '        "grade": "7",\n'
        '        "subject": "mathematics",\n'
        '        "type": "mcq",\n'
        '        "instructions": "A real-world problem involving congruent and similar triangles"\n'
        '      },\n'
        '      "content": "What is 2 + 2?"\n'
        '    }\n'
        '  ],\n'
        '  "curriculum_version": "1.2"\n'
        "}\n"
        "```\n\n"
        "### Top-level Fields\n\n"
        "| Field | Required | Default | Description |\n"
        "|-------|----------|---------|-------------|\n"
        "| `generated_content` | Yes | - | Array of content items (one or more) |\n"
        "| `curriculum_version` | No | Latest | Curriculum version (e.g., '1.2') |\n\n"
        "### Content Item Fields\n\n"
        "| Field | Required | Default | Description |\n"
        "|-------|----------|---------|-------------|\n"
        "| `content` | Yes | - | Content to evaluate (string or JSON) |\n"
        "| `id` | No | Auto-generated | Unique identifier |\n"
        "| `request` | No | `null` | Generation metadata (see below) |\n\n"
        "### Request Metadata Fields (all optional)\n\n"
        "| Field | Description |\n"
        "|-------|-------------|\n"
        "| `curriculum` | Curriculum for alignment (e.g., `common_core`, `ap_us_history`). Defaults to `common_core` |\n"
        "| `grade` | Grade level (e.g., \"7\", \"K\", \"12\") |\n"
        "| `subject` | Subject area (e.g., \"mathematics\", \"english\") |\n"
        "| `type` | Content type (e.g., \"mcq\", \"fill-in\", \"article\") |\n"
        "| `difficulty` | Difficulty level (e.g., \"easy\", \"medium\", \"hard\") |\n"
        "| `locale` | Locale/language code (e.g., \"en-US\", \"es-MX\") |\n"
        "| `skills` | Skills info (JSON object or string) |\n"
        "| `instruction` | Generation instruction/prompt |\n\n"
        "The `content` field accepts any format - plain text, JSON object, "
        "or structured data. The evaluator automatically classifies and "
        "processes the content appropriately.\n\n"
        "### Images\n\n"
        "Images are automatically detected from content. Include as:\n"
        "- Direct URLs: `https://example.com/image.png`\n"
        "- Markdown: `![alt](https://example.com/image.png)`\n"
        "- HTML: `<img src=\"https://example.com/image.png\">`\n\n"
        "---\n\n"
        "## AP Evaluation\n\n"
        "Specialized evaluation for **AP Social Studies** (APUSH, APWH, APEH, APGOV, APHG).\n\n"
        "**Curriculums:** `ap_us_history`, `ap_world_history`, `ap_european_history`, "
        "`ap_government`, `ap_human_geography`\n\n"
        "**Question types:** `mcq`, `mcq_set`, `saq`, `leq`, `dbq`\n\n"
        "**Pass criteria:** No hard-fail dimension failures, plus AP threshold logic "
        "(PASS_THRESHOLD=0.85 with borderline handling between 0.80 and 0.90).\n\n"
        "Use structured `content` with `type`, `difficulty`, `request` (curriculum standard), "
        "and `output` (question content) fields.\n\n"
        "---\n\n"
        "## Performance\n\n"
        "- **Parallel Processing**: Items evaluated concurrently\n"
        "- **Concurrency Limit**: Max 10 items processed simultaneously\n"
        "- **Batch Support**: One or more items per request\n"
        "- **Partial Success**: Failed items don't block others"
    ),
    version=API_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# CORS middleware (configure for your deployment)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Configure OpenAPI schema with security
def custom_openapi():
    """
    Customize OpenAPI schema to include Bearer token authentication.
    
    This adds the security scheme to the OpenAPI spec, which makes
    Swagger UI display the "Authorize" button.
    """
    if app.openapi_schema:
        return app.openapi_schema
       
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Add security scheme
    openapi_schema["components"]["securitySchemes"] = {
        "HTTPBearer": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "API Key",
            "description": (
                "Enter your API key: `your-api-key-here`\n\n"
                "Sent as: `Authorization: Bearer <your-api-key>`"
            )
        }
    }
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time header to responses."""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


# Exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Handle ValueError exceptions."""
    logger.warning(f"ValueError: {exc}")
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=ErrorResponse(
            error="ValidationError",
            message=str(exc)
        ).model_dump()
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle unexpected exceptions."""
    logger.error(f"Unexpected error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error="InternalServerError",
            message="An unexpected error occurred",
            detail=str(exc) if settings.LOG_LEVEL == "DEBUG" else None
        ).model_dump()
    )


# API Endpoints
@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["Health"],
    summary="Health check endpoint",
    description="Check if the service is healthy and get version information"
)
async def health_check() -> HealthResponse:
    """
    Health check endpoint.
    
    Returns service health status and version information.
    """
    return HealthResponse(
        status="healthy",
        version=API_VERSION,
        service="InceptBench API"
    )


@app.get(
    "/versions",
    response_model=VersionsResponse,
    tags=["Metadata"],
    summary="List available InceptBench versions",
    description=(
        "Get information about available InceptBench versions. "
        "Use this to discover which versions can be specified via the `version` query parameter "
        "on the /evaluate endpoint."
    )
)
async def list_versions() -> VersionsResponse:
    """
    List available InceptBench versions.
    
    Returns the current version, all supported versions, and the default version.
    Supported versions can be used with the `version` query parameter on /evaluate.
    
    Returns:
        VersionsResponse with current, supported_versions, and default
    """
    # Read supported versions from file
    import pathlib

    # __file__ is src/inceptbench/api/main.py in editable installs —
    # walk up four levels to reach the repo root where supported_versions.txt lives.
    module_dir = pathlib.Path(__file__).parent.parent.parent.parent
    versions_file = module_dir / "supported_versions.txt"
    
    supported_versions = []
    if versions_file.exists():
        content = versions_file.read_text().strip()
        supported_versions = [v.strip() for v in content.split("\n") if v.strip()]
    
    # Current version is the running API version
    # Default is the latest (first in the list, or current if list is empty)
    current = API_VERSION
    default = supported_versions[0] if supported_versions else current
    
    # Ensure current version is in the list
    if current not in supported_versions:
        supported_versions.insert(0, current)
    
    return VersionsResponse(
        current=current,
        supported_versions=supported_versions,
        default=default
    )


@app.get(
    "/curriculums",
    response_model=CurriculumsResponse,
    tags=["Metadata"],
    summary="List available curriculums and versions",
    description=(
        "Get information about available curriculums and their versions. "
        "Returns curriculum details including available versions, latest version, "
        "and descriptions. This data is fetched from the curriculum API."
    )
)
async def list_curriculums() -> CurriculumsResponse:
    """
    List curriculum information including versions.

    Fetches data from the new incept-curriculum service (/versions and
    /list-curricula endpoints) and returns it in the existing response shape.

    Returns:
        CurriculumsResponse with default_curriculum and curricula details

    Raises:
        HTTPException: If curriculum API is unavailable
    """
    base_url = settings.INCEPT_CURRICULUM_API_URL.rstrip("/")
    headers: dict[str, str] = {}
    if settings.INCEPT_CURRICULUM_API_KEY:
        headers["X-API-Key"] = settings.INCEPT_CURRICULUM_API_KEY

    try:
        async with httpx.AsyncClient(timeout=settings.CURRICULUM_SEARCH_TIMEOUT) as client:
            # Fetch versions and curricula list in parallel
            versions_resp, curricula_resp = await asyncio.gather(
                client.get(f"{base_url}/versions", headers=headers),
                client.get(f"{base_url}/list-curricula", headers=headers),
            )
            versions_resp.raise_for_status()
            curricula_resp.raise_for_status()

            versions_data = versions_resp.json()
            curricula_data = curricula_resp.json()

            # Build a description lookup from /list-curricula
            desc_by_abbrev: dict[str, str] = {}
            for entry in curricula_data.get("curricula", []):
                abbrev = entry.get("abbreviation", "")
                desc_by_abbrev[abbrev] = entry.get("description", entry.get("name", ""))

            # Build version list from /versions
            version_objects = [
                CurriculumVersion(
                    version=v["version"],
                    version_date=v.get("release_date", ""),
                )
                for v in versions_data.get("versions", [])
            ]
            latest = versions_data.get("latest", "")

            # Build one CurriculumInfo per abbreviation found in curricula list
            # Map abbreviation back to InceptBench slug for response keys.
            # Use the explicit canonical mapping so many-to-one AP slugs resolve
            # deterministically to "ap" instead of last-write-wins.
            abbrev_to_slug = CURRICULUM_ABBREVIATION_TO_SLUG

            curricula: dict[str, CurriculumInfo] = {}
            for entry in curricula_data.get("curricula", []):
                abbrev = entry.get("abbreviation", "")
                slug = abbrev_to_slug.get(abbrev, abbrev.lower())
                curricula[slug] = CurriculumInfo(
                    versions=version_objects,
                    latest=latest,
                    description=entry.get("description", entry.get("name", "")),
                )

            return CurriculumsResponse(
                default_curriculum=settings.DEFAULT_CURRICULUM,
                curricula=curricula,
            )

    except httpx.HTTPStatusError as e:
        logger.error(f"Curriculum API error: {e.response.status_code} - {e.response.text}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Curriculum service temporarily unavailable"
        )
    except httpx.RequestError as e:
        logger.error(f"Curriculum API connection error: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Unable to connect to curriculum service"
        )
    except Exception as e:
        logger.error(f"Unexpected error fetching curriculums: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch curriculum information"
        )


@app.post(
    "/evaluate",
    response_model=EvaluationResponse,
    tags=["Evaluation"],
    summary="Evaluate educational content",
    description=(
        "Evaluate educational content across **11+ quality dimensions**.\n\n"
        "**Input Format:**\n"
        "```json\n"
        '{"generated_content": [{"content": "Your content here"}]}\n'
        "```\n\n"
        "**Response:**\n"
        "Returns evaluation results keyed by item ID, with scores and "
        "reasoning for each quality dimension.\n\n"
        "**Limits:** No fixed maximum items per request"
    ),
    response_description="Evaluation results with quality metrics"
)
async def evaluate_content(
    request: EvaluationRequest,
    service: EvaluationServiceDep,
    api_key: APIKeyDep
) -> EvaluationResponse:
    """
    Evaluate educational content.
    
    This endpoint accepts educational content and:
    1. Classifies content type (question, quiz, reading passage, etc.)
    2. Routes to the appropriate evaluator
    3. Processes items in parallel with concurrency control
    4. Returns evaluation results with scores and suggestions
    
    Args:
        request: EvaluationRequest with generated_content array
        service: Injected EvaluationService instance
        api_key: API key for authentication
    
    Returns:
        EvaluationResponse with evaluations keyed by item ID
    
    Raises:
        HTTPException: If evaluation fails or validation errors occur
    """
    start_time = time.time()
    request_id = str(uuid4())
    
    items = request.generated_content
    
    version_info = f", curriculum_version: {request.curriculum_version}" if request.curriculum_version else ""
    logger.info(
        f"[{request_id}] Evaluating {len(items)} item(s) "
        f"(max concurrent: {MAX_CONCURRENT_EVALUATIONS}{version_info})"
    )

    try:
        if settings.INCLUDE_COST:
            init_usage_tracking()

        # Apply per-request Gemini service tier override (if provided)
        if request.service_tier:
            set_service_tier_override(request.service_tier)

        # Use BatchProcessor for parallel evaluation
        processor = BatchProcessor(
            service=service,
            max_concurrent=MAX_CONCURRENT_EVALUATIONS
        )

        # Process all items (no progress callback for API)
        batch_result = await processor.process_batch(
            items,
            curriculum_version=request.curriculum_version
        )
        
        # Calculate total time
        evaluation_time = time.time() - start_time
        
        # Log summary
        if batch_result.failed_items:
            logger.warning(
                f"[{request_id}] Partial success. "
                f"Success: {batch_result.success_count}, "
                f"Failed: {batch_result.failure_count}, "
                f"Time: {evaluation_time:.2f}s"
            )
        else:
            logger.info(
                f"[{request_id}] Complete. "
                f"Items: {batch_result.success_count}, "
                f"Time: {evaluation_time:.2f}s"
            )
        
        # Build failed items list for API response
        failed_items_list = None
        if batch_result.failed_items:
            failed_items_list = [
                FailedItem(item_id=fi.item_id, error=fi.error)
                for fi in batch_result.failed_items
            ]

        cost_summary = None
        if settings.INCLUDE_COST:
            usage_summary = get_usage_summary() or []
            cost_summary = [CostSummary(**u) for u in usage_summary]
        
        # Return response
        return EvaluationResponse(
            request_id=request_id,
            evaluations=batch_result.evaluations,
            evaluation_time_seconds=evaluation_time,
            inceptbench_version=API_VERSION,
            curriculum_version=request.curriculum_version,
            failed_items=failed_items_list,
            cost=cost_summary,
        )
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.warning(f"[{request_id}] Validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(
            f"[{request_id}] Error during evaluation: {e}",
            exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Evaluation failed: {str(e)}"
        )


# Root endpoint
@app.get(
    "/",
    include_in_schema=False,
    tags=["Root"]
)
async def root():
    """Root endpoint - provides API information."""
    return {
        "service": "InceptBench API",
        "version": API_VERSION,
        "docs": "/docs",
        "health": "/health",
        "endpoints": {
            "evaluate": "POST /evaluate",
            "versions": "GET /versions",
            "curriculums": "GET /curriculums",
            "health": "GET /health"
        },
        "limits": {
            "max_concurrent_evaluations": MAX_CONCURRENT_EVALUATIONS
        }
    }


# For local development and testing
if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "inceptbench.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
