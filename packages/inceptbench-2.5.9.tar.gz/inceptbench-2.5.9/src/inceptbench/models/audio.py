"""
Audio-related models for content evaluation.

This module provides Pydantic models for audio transcript data,
used primarily for debugging and reviewing what text was extracted
from audio during decomposition.

Key design principle (same as video):
- Transcripts are for DECOMPOSITION only (understanding structure)
- Evaluators receive audio data, not transcripts
- The extracted_text is stored for debugging/review purposes
"""

from typing import Dict, Optional

from pydantic import BaseModel, Field


class AudioTranscriptInfo(BaseModel):
    """
    Information about an audio transcript for debugging/review.

    Stored in evaluation results so reviewers can see
    what transcript text was used during decomposition.
    """

    audio_url: str = Field(
        ...,
        description="The audio URL this transcript was extracted from"
    )

    extracted_text: str = Field(
        ...,
        description="The transcript text used for decomposition decisions"
    )

    available: bool = Field(
        ...,
        description="Whether the transcript was successfully generated"
    )

    language: Optional[str] = Field(
        None,
        description="Language of the transcript if known"
    )

    error_message: Optional[str] = Field(
        None,
        description="Error message if transcription failed"
    )


class AudioTranscriptSummary(BaseModel):
    """
    Summary of all audio transcripts used in an evaluation.

    Attached to evaluation results for debugging/review.
    Shows what text was extracted from each audio file.
    """

    transcripts: Dict[str, AudioTranscriptInfo] = Field(
        default_factory=dict,
        description="Map of audio URL to transcript info"
    )

    @property
    def audio_count(self) -> int:
        """Number of audio files processed."""
        return len(self.transcripts)

    @property
    def available_count(self) -> int:
        """Number of audio files with available transcripts."""
        return sum(1 for t in self.transcripts.values() if t.available)

    def add_transcript(
        self,
        audio_url: str,
        extracted_text: str,
        available: bool,
        language: Optional[str] = None,
        error_message: Optional[str] = None
    ) -> None:
        """Add a transcript to the summary."""
        self.transcripts[audio_url] = AudioTranscriptInfo(
            audio_url=audio_url,
            extracted_text=extracted_text,
            available=available,
            language=language,
            error_message=error_message
        )
