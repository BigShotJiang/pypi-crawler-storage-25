"""
Pydantic and dataclass models for stimulus reference detection.

These models define the structured data returned by the LLM extraction step
and the final programmatic mismatch result used by the question evaluator.
"""

from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


# Legacy LLM-output shape — retained for backwards compatibility with any caller
# still relying on the old extractor.  The new pipeline uses StimulusPromiseExtraction.
class StimulusReferenceExtraction(BaseModel):
    """Structured LLM output for visual-reference extraction (legacy)."""

    model_config = ConfigDict(extra="forbid")

    has_visual_references: bool = Field(
        description=(
            "Whether the student-facing text references an external visual "
            "stimulus (image/diagram/figure/chart/table/etc.)."
        )
    )
    references_found: list[str] = Field(
        default_factory=list,
        description="Specific visual-reference phrases found in the student-facing text.",
    )


PromiseMedium = Literal["visual", "audio", "video", "multimedia", "text"]


class StimulusPromise(BaseModel):
    """One stimulus the student-facing text promises the student will consult."""

    model_config = ConfigDict(extra="ignore")

    kind: str = Field(
        description="Short label for the artifact (chart, illustration, passage, oral_announcement, ...)."
    )
    medium_required: PromiseMedium = Field(
        description="Which channel satisfies the promise: visual | audio | video | multimedia | text."
    )
    exact_phrase: str = Field(
        default="",
        description="Short phrase from the student-facing text that announced this promise.",
    )


class StimulusPromiseExtraction(BaseModel):
    """LLM output: every stimulus the question promises the student will consult."""

    model_config = ConfigDict(extra="ignore")

    promises: list[StimulusPromise] = Field(default_factory=list)


@dataclass
class UnsatisfiedPromise:
    """A promised stimulus that the content does not actually provide."""

    kind: str
    medium_required: PromiseMedium
    exact_phrase: str
    reason: str


@dataclass
class StimulusReferenceResult:
    """Final result for hybrid stimulus-reference mismatch detection."""

    has_visual_references: bool
    references_found: list[str]
    has_actual_stimulus: bool
    is_mismatch: bool
    detection_method: Literal["regex", "llm", "promise", "none"]
    unsatisfied_promises: list[UnsatisfiedPromise] = field(default_factory=list)
    promises: list[StimulusPromise] = field(default_factory=list)
