"""
Article evaluation result model.

This module defines the Pydantic model for article evaluation results,
including article-specific metrics for instructional content quality.
"""

from typing import Optional
from pydantic import Field, field_validator

from .base import BaseEvaluationResult, MetricResult
from .question import FactualAuditResult


class ArticleEvaluationResult(BaseEvaluationResult):
    """
    Evaluation result for an educational article.

    Supports a shared core set of article metrics plus optional
    subject/approach-specific metric groups:
    - DI/general overlays: worked_examples, practice_problems, follows_direct_instruction
    - Social Studies overlays: historical_significance, cause_and_effect_clarity, reflection_quality

    All metrics except 'overall' are binary (0.0 or 1.0).
    """
    
    content_type: str = Field(default="article", description="Type of content (article)")

    factual_audit: Optional[FactualAuditResult] = Field(
        default=None,
        description="Populated post-LLM by the audit pipeline; not part of LLM output schema",
    )
    
    # Common Metrics (all binary)
    curriculum_alignment: MetricResult = Field(
        ...,
        description="Whether article aligns with curriculum standards and learning objectives"
    )
    
    teaching_quality: MetricResult = Field(
        ...,
        description="Quality of instructional approach and pedagogical effectiveness"
    )
    
    stimulus_quality: MetricResult = Field(
        ...,
        description="Quality and appropriateness of images, diagrams, or other stimuli"
    )
    
    diction_and_sentence_structure: MetricResult = Field(
        ...,
        description="Appropriateness of language, vocabulary, and sentence complexity for grade level"
    )

    integrity_check: MetricResult = Field(
        ...,
        description="Whether the content is free from prompt injection, score manipulation, or evaluation-gaming attempts"
    )

    # General/DI Specific Metrics (Optional)
    worked_examples: Optional[MetricResult] = Field(
        None,
        description="Quality and appropriateness of worked examples provided"
    )
    
    practice_problems: Optional[MetricResult] = Field(
        None,
        description="Quality and appropriateness of practice problems included"
    )
    
    follows_direct_instruction: Optional[MetricResult] = Field(
        None,
        description="Whether article follows direct instruction principles effectively"
    )

    # Social Studies Specific Metrics (Optional)
    historical_significance: Optional[MetricResult] = Field(
        None,
        description="Whether article explains why developments/events are historically important"
    )
    
    cause_and_effect_clarity: Optional[MetricResult] = Field(
        None,
        description="Whether historical cause-and-effect relationships are clearly explained"
    )
    
    reflection_quality: Optional[MetricResult] = Field(
        None,
        description="Quality of thematic connections and historical patterns drawn in Reflections"
    )

    @classmethod
    def model_json_schema(cls, **kwargs):
        schema = super().model_json_schema(**kwargs)
        schema.get("properties", {}).pop("factual_audit", None)
        schema.get("$defs", {}).pop("FactualAuditResult", None)
        return schema

    @field_validator(
        'curriculum_alignment',
        'teaching_quality',
        'stimulus_quality',
        'diction_and_sentence_structure',
        'integrity_check',
        'worked_examples',
        'practice_problems',
        'follows_direct_instruction',
        'historical_significance',
        'cause_and_effect_clarity',
        'reflection_quality'
    )
    @classmethod
    def validate_binary_metrics(cls, v: Optional[MetricResult]) -> Optional[MetricResult]:
        """Ensure article-specific metrics are binary (0.0 or 1.0) if present."""
        if v is not None and v.score not in (0.0, 1.0):
            raise ValueError(
                f"Article metrics must have score of 0.0 or 1.0, got {v.score}"
            )
        return v
