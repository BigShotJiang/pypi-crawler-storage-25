"""
Video-related models for content evaluation.

This module provides Pydantic models for video transcript data,
used primarily for debugging and reviewing what text was extracted
from videos during decomposition.

Key design principle:
- Transcripts are for DECOMPOSITION only (understanding structure)
- Evaluators receive video URLs, not transcripts
- The extracted_text is stored for debugging/review purposes
"""

from typing import Dict, Optional

from pydantic import BaseModel, Field


class VideoTranscriptInfo(BaseModel):
    """
    Information about a video transcript for debugging/review.
    
    This is stored in evaluation results so reviewers can see
    what transcript text was used during decomposition.
    """
    
    video_url: str = Field(
        ...,
        description="The video URL this transcript was extracted from"
    )
    
    extracted_text: str = Field(
        ...,
        description="The transcript text used for decomposition decisions"
    )
    
    available: bool = Field(
        ...,
        description="Whether the transcript was successfully fetched"
    )
    
    language: Optional[str] = Field(
        None,
        description="Language of the transcript if known"
    )
    
    error_message: Optional[str] = Field(
        None,
        description="Error message if transcript fetch failed"
    )


class VideoTranscriptSummary(BaseModel):
    """
    Summary of all video transcripts used in an evaluation.
    
    Attached to evaluation results for debugging/review.
    Shows what extracted_text was used for each video.
    """
    
    transcripts: Dict[str, VideoTranscriptInfo] = Field(
        default_factory=dict,
        description="Map of video URL to transcript info"
    )
    
    @property
    def video_count(self) -> int:
        """Number of videos processed."""
        return len(self.transcripts)
    
    @property
    def available_count(self) -> int:
        """Number of videos with available transcripts."""
        return sum(1 for t in self.transcripts.values() if t.available)
    
    def add_transcript(
        self,
        video_url: str,
        extracted_text: str,
        available: bool,
        language: Optional[str] = None,
        error_message: Optional[str] = None
    ) -> None:
        """Add a transcript to the summary."""
        self.transcripts[video_url] = VideoTranscriptInfo(
            video_url=video_url,
            extracted_text=extracted_text,
            available=available,
            language=language,
            error_message=error_message
        )
