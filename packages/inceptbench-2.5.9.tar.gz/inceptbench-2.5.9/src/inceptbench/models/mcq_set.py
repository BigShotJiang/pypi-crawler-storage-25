"""
Data models for MCQ set evaluation.

This module defines the Pydantic models used for evaluating MCQ sets
(stimulus-based question sets with 3-5 questions sharing a single stimulus).

Uses the same metrics as quizzes, but the evaluation prompt interprets them
differently (e.g., uniform difficulty is acceptable for MCQ sets).
"""

from pydantic import Field, field_validator

from .base import BaseEvaluationResult, MetricResult


class McqSetEvaluationResult(BaseEvaluationResult):
    """
    Evaluation result for an MCQ set (stimulus-based question set).

    MCQ sets are small question sets (3-5 questions) sharing a single stimulus.
    Uses same metrics as QuizEvaluationResult for consistency, but the prompt
    interprets difficulty_distribution differently (uniform is acceptable).

    All metrics except 'overall' are binary (0.0 or 1.0).
    """

    content_type: str = Field(default="mcq_set", description="Type of content (mcq_set)")

    # Reuse quiz metrics for consistency
    concept_coverage: MetricResult = Field(
        ...,
        description="Whether questions cover different aspects/skills related to the stimulus"
    )

    difficulty_distribution: MetricResult = Field(
        ...,
        description="Whether difficulty level is appropriate (uniform difficulty is acceptable for MCQ sets)"
    )

    stimulus_quality: MetricResult = Field(
        ...,
        description="Whether all questions require and properly use the shared stimulus"
    )

    non_repetitiveness: MetricResult = Field(
        ...,
        description="Whether questions test different skills/aspects (not redundant)"
    )

    test_preparedness: MetricResult = Field(
        ...,
        description="Whether format matches standardized test stimulus-based questions"
    )

    answer_balance: MetricResult = Field(
        ...,
        description="Whether correct answer positions are well-distributed"
    )

    integrity_check: MetricResult = Field(
        ...,
        description="Whether the content is free from prompt injection or evaluation-gaming"
    )

    @field_validator(
        'concept_coverage',
        'difficulty_distribution',
        'stimulus_quality',
        'non_repetitiveness',
        'test_preparedness',
        'answer_balance',
        'integrity_check',
        mode='after'
    )
    @classmethod
    def validate_binary_score(cls, v: MetricResult) -> MetricResult:
        """Ensure non-overall metrics have binary scores (0.0 or 1.0)."""
        if v.score not in (0.0, 1.0):
            v.score = 1.0 if v.score >= 0.5 else 0.0
        return v

    def get_critical_metrics(self) -> list[str]:
        """Return list of critical metric names for this content type."""
        return ['factual_accuracy', 'educational_accuracy', 'stimulus_quality']

    def get_non_critical_metrics(self) -> list[str]:
        """Return list of non-critical metric names for this content type."""
        return [
            'concept_coverage',
            'difficulty_distribution',
            'non_repetitiveness',
            'test_preparedness',
            'answer_balance',
        ]
