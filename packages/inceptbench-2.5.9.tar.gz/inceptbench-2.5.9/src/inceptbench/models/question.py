"""
Data models for question evaluation.

This module defines the Pydantic models used for evaluating individual questions,
including all metrics specific to question content.
"""

from typing import Optional

from pydantic import BaseModel, Field, field_validator

from .base import BaseEvaluationResult, MetricResult


class FactualAuditResult(BaseModel):
    """Factual audit result stored for dashboard visibility.

    The audit score IS merged into ``factual_accuracy`` via ``min(main, audit)``
    inside ``apply_factual_audit_to_question_result``.  The ``skipped`` flag
    indicates a fail-open run where no merge was performed.
    """

    score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str = Field(default="")
    suggested_improvements: Optional[str] = None
    skipped: bool = False


class QuestionEvaluationResult(BaseEvaluationResult):
    """
    Evaluation result for a single question.
    
    Includes the required metrics (overall, factual_accuracy, educational_accuracy)
    plus question-specific metrics that assess various quality dimensions.
    
    All metrics except 'overall' are binary (0.0 or 1.0).
    """
    
    content_type: str = Field(default="question", description="Type of content (question)")

    factual_audit: Optional[FactualAuditResult] = Field(
        default=None,
        description="Populated post-LLM by the audit pipeline; not part of LLM output schema",
    )
    
    # Question-specific metrics (all binary)
    curriculum_alignment: MetricResult = Field(
        ...,
        description="Whether question aligns with curriculum standards and learning objectives"
    )
    
    clarity_precision: MetricResult = Field(
        ...,
        description="Whether question is semantically clear, unambiguous, and precisely worded"
    )
    
    specification_compliance: MetricResult = Field(
        ...,
        description="Whether question meets format/structure requirements from skill specification"
    )
    
    reveals_misconceptions: MetricResult = Field(
        ...,
        description="Whether question effectively reveals and addresses student misconceptions"
    )
    
    difficulty_alignment: MetricResult = Field(
        ...,
        description="Whether question difficulty matches intended level and cognitive demand"
    )
    
    passage_reference: MetricResult = Field(
        ...,
        description="Whether question properly references passage/context when applicable"
    )
    
    distractor_quality: MetricResult = Field(
        ...,
        description="Quality of incorrect answer choices (distractors) if present"
    )
    
    stimulus_quality: MetricResult = Field(
        ...,
        description="Quality and appropriateness of images, diagrams, or other stimuli"
    )
    
    mastery_learning_alignment: MetricResult = Field(
        ...,
        description="Whether question supports mastery learning principles and deep understanding"
    )

    integrity_check: MetricResult = Field(
        ...,
        description="Whether the content is free from prompt injection, score manipulation, or evaluation-gaming attempts"
    )

    @classmethod
    def model_json_schema(cls, **kwargs):
        schema = super().model_json_schema(**kwargs)
        schema.get("properties", {}).pop("factual_audit", None)
        schema.get("$defs", {}).pop("FactualAuditResult", None)
        return schema

    @field_validator(
        'curriculum_alignment',
        'clarity_precision', 
        'specification_compliance',
        'reveals_misconceptions',
        'difficulty_alignment',
        'passage_reference',
        'distractor_quality',
        'stimulus_quality',
        'mastery_learning_alignment',
        'integrity_check'
    )
    @classmethod
    def validate_binary_metrics(cls, v: MetricResult) -> MetricResult:
        """Ensure question-specific metrics are binary (0.0 or 1.0)."""
        if v.score not in (0.0, 1.0):
            raise ValueError(
                f"Question metrics must have score of 0.0 or 1.0, got {v.score}"
            )
        return v

