"""
Data models for the educational content evaluation system.

This module provides Pydantic models for:
- Content types and evaluation requests
- Evaluation results and metrics
- Content tree structures (hierarchical content)
- Specific result types (question, quiz, reading, article, other)
- Video transcript models
- Audio transcript models
"""

from .base import (
    BaseEvaluationResult,
    ContentType,
    CurriculumCitation,
    EvaluationRequest,
    MetricResult,
    OverallRating,
    with_required_interest_relevance,
)
from .content_tree import ContentNode, ContentTree, DecompositionResult, ExtractedContent
from .video import VideoTranscriptInfo, VideoTranscriptSummary
from .audio import AudioTranscriptInfo, AudioTranscriptSummary
from .article import ArticleEvaluationResult
from .mcq_set import McqSetEvaluationResult
from .other import OtherEvaluationResult
from .question import FactualAuditResult, QuestionEvaluationResult
from .quiz import QuizEvaluationResult
from .reading import ReadingEvaluationResult
from .stimulus_reference import (
    StimulusReferenceExtraction,
    StimulusReferenceResult,
)

__all__ = [
    # Base models
    "ContentType",
    "OverallRating",
    "CurriculumCitation",
    "MetricResult",
    "BaseEvaluationResult",
    "EvaluationRequest",
    "with_required_interest_relevance",
    # Content tree models
    "ContentNode",
    "ContentTree",
    "DecompositionResult",
    "ExtractedContent",
    # Video transcript models
    "VideoTranscriptInfo",
    "VideoTranscriptSummary",
    # Audio transcript models
    "AudioTranscriptInfo",
    "AudioTranscriptSummary",
    # Specific evaluation results
    "FactualAuditResult",
    "QuestionEvaluationResult",
    "QuizEvaluationResult",
    "McqSetEvaluationResult",
    "ReadingEvaluationResult",
    "ArticleEvaluationResult",
    "OtherEvaluationResult",
    # Stimulus reference detection models
    "StimulusReferenceExtraction",
    "StimulusReferenceResult",
]
