"""
Base models for educational content evaluation.

This module defines the core Pydantic models used across all evaluators,
including metric results, evaluation results, and content types.
"""

from abc import ABC
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, computed_field, field_validator, model_serializer

from inceptbench.config.tier_scoring import calculate_weighted_score

_CRITICAL_METRICS = ("factual_accuracy", "educational_accuracy")
_NONCRITICAL_EXCLUSIONS = {
    "factual_accuracy",
    "educational_accuracy",
    "overall",
    "content_type",
    "overall_rating",
    "subcontent_evaluations",
    "factual_audit",
}

class ContentType(str, Enum):
    """Types of educational content that can be evaluated."""
    QUESTION = "question"
    QUIZ = "quiz"
    MCQ_SET = "mcq_set"  # Stimulus-based MCQ set (3-5 questions, uniform difficulty expected)
    FICTION_READING = "fiction_reading"
    NONFICTION_READING = "nonfiction_reading"
    ARTICLE = "article"
    OTHER = "other"


class OverallRating(str, Enum):
    """
    Qualitative rating corresponding to the overall assessment score.
    
    Thresholds:
    - SUPERIOR: score >= 0.99 (exceeds typical high-quality content)
    - ACCEPTABLE: score >= 0.85 and < 0.99 (comparable to typical high-quality content)
    - INFERIOR: score < 0.85 (falls short of expected quality)
    """
    SUPERIOR = "SUPERIOR"
    ACCEPTABLE = "ACCEPTABLE"
    INFERIOR = "INFERIOR"


class CurriculumCitation(BaseModel):
    """A curriculum citation supporting a metric assessment."""

    line_no: int = Field(..., ge=1, description="1-indexed curriculum line number")
    line_text: str = Field(..., description="Exact numbered curriculum line text")


class MetricResult(BaseModel):
    """
    Result for a single evaluation metric.

    Field ordering is intentional: reasoning fields come BEFORE score so that
    LLMs generating structured JSON must complete their analysis before
    committing to a numeric score. This prevents the model from anchoring
    on an early score value and then rationalizing it.

    Attributes:
        internal_reasoning: Detailed step-by-step analysis for consistency (not for human readers).
        score: Float in [0.0, 1.0]. Binary metrics are 0.0 or 1.0.
               Only 'overall' can have intermediate values.
        reasoning: Clean, human-readable explanation for the score given.
        suggested_improvements: Suggestions for improvement (null if score = 1.0).

    Note: internal_reasoning is intentionally placed BEFORE score so that the LLM
    generates its reasoning chain first, then commits the score value that reflects
    the conclusion of that reasoning. This prevents the LLM from committing an early
    score before self-correcting in its reasoning.
    """
    internal_reasoning: Optional[str] = Field(
        None,
        description="Detailed step-by-step analysis (internal use, helps ensure consistency)"
    )
    score: float = Field(..., ge=0.0, le=1.0, description="Score between 0.0 and 1.0")
    reasoning: str = Field(default="No issues found.", description="Clean, human-readable explanation for the score")
    suggested_improvements: Optional[str] = Field(
        None,
        description="Suggestions for improvement (provide if score < 1.0, null if score = 1.0)"
    )
    citations: Optional[List[CurriculumCitation]] = Field(
        None,
        description="Optional curriculum citations supporting this metric"
    )

    @field_validator('reasoning', mode='before')
    @classmethod
    def ensure_non_empty_reasoning(cls, v: str) -> str:
        """Ensure reasoning is never empty - use default if empty string provided."""
        if not v or (isinstance(v, str) and not v.strip()):
            return "No issues found."
        return v

    @model_serializer(mode='wrap')
    def _serialize_metric(self, serializer: Any) -> dict:
        """Serialize metric fields: reasonings first, then score; omit absent citations."""
        data = serializer(self)
        ordered = {}
        for key in (
            "internal_reasoning",
            "reasoning",
            "suggested_improvements",
            "citations",
            "score",
        ):
            if key == "citations" and data.get(key) is None:
                continue
            ordered[key] = data.get(key)
        return ordered

    def to_dict(self) -> dict:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in self.model_dump().items() if v is not None}


class BaseEvaluationResult(BaseModel, ABC):
    """
    Abstract base class for all evaluation results.
    
    All evaluation results must include:
    - content_type: Type of content evaluated
    - overall: Overall assessment (continuous metric)
    - factual_accuracy: Factual correctness (binary)
    - educational_accuracy: Educational intent fulfillment (binary)
    - localization_quality: Cultural/linguistic appropriateness (binary)

    Subclasses add content-type-specific metrics.
    """
    
    model_config = ConfigDict(
        # Serialize using actual runtime type, not annotated type
        # This ensures subcontent_evaluations include all subclass fields
        use_enum_values=True,
    )
    
    content_type: str = Field(..., description="Type of content evaluated")
    overall: MetricResult = Field(..., description="Overall assessment (continuous)")
    factual_accuracy: MetricResult = Field(
        ..., 
        description="Factual correctness (binary)"
    )
    educational_accuracy: MetricResult = Field(
        ..., 
        description="Educational intent fulfillment (binary)"
    )
    localization_quality: MetricResult = Field(
        ...,
        description="Cultural and linguistic appropriateness for target audience (binary)"
    )

    # Informational metrics (no impact on overall score)
    interest_relevance: Optional[MetricResult] = Field(
        None,
        description="Whether content reflects provided student interests (null when no interests provided)"
    )

    # Hierarchical content support
    subcontent_evaluations: Optional[List['BaseEvaluationResult']] = Field(
        None,
        description="Evaluation results for nested content (e.g., questions within a quiz)"
    )

    @field_validator('factual_accuracy', 'educational_accuracy', 'localization_quality')
    @classmethod
    def validate_binary_metric(cls, v: MetricResult) -> MetricResult:
        """Ensure binary metrics have scores of exactly 0.0 or 1.0."""
        if v.score not in (0.0, 1.0):
            raise ValueError(
                f"Binary metrics must have score of 0.0 or 1.0, got {v.score}"
            )
        return v

    @field_validator('interest_relevance')
    @classmethod
    def validate_informational_metric(cls, v: Optional[MetricResult]) -> Optional[MetricResult]:
        """Ensure informational metrics are binary (0.0 or 1.0) when present."""
        if v is not None and v.score not in (0.0, 1.0):
            raise ValueError(
                f"Informational metrics must have score of 0.0 or 1.0, got {v.score}"
            )
        return v
    
    @model_serializer(mode='wrap')
    def _serialize_model(self, serializer: Any) -> dict:
        """
        Custom serializer to control field ordering in output.
        
        Output order:
        1. content_type
        2. overall_rating (qualitative rating)
        3. overall (detailed assessment)
        4. All other metrics (in their defined order)
        5. subcontent_evaluations (at the end, if present)
        """
        # Get default serialization
        data = serializer(self)
        
        # Build reordered output
        ordered = {}
        
        # 1. content_type first
        if 'content_type' in data:
            ordered['content_type'] = data.pop('content_type')
        
        # 2. overall_rating second
        if 'overall_rating' in data:
            ordered['overall_rating'] = data.pop('overall_rating')
        
        # 3. overall third
        if 'overall' in data:
            ordered['overall'] = data.pop('overall')
        
        # 4. Remove subcontent_evaluations temporarily to add at the end
        subcontent = data.pop('subcontent_evaluations', None)
        
        # 5. Add all remaining metrics (except weighted_score which we skip)
        for key, value in data.items():
            if key != 'weighted_score':  # Skip weighted_score - it's confusing
                ordered[key] = value
        
        # 6. Add subcontent_evaluations at the end
        if subcontent is not None:
            # Serialize each subcontent item with all its fields
            subcontent_serialized = [
                item.model_dump(mode='python') if hasattr(item, 'model_dump')
                else item
                for item in self.subcontent_evaluations
            ] if self.subcontent_evaluations else None
            ordered['subcontent_evaluations'] = subcontent_serialized
        else:
            ordered['subcontent_evaluations'] = None
        
        return ordered
    
    def _get_metric_scores(self) -> Dict[str, float]:
        """Extract all metric scores from this result."""
        scores = {}
        for field_name in type(self).model_fields:
            if field_name in ('content_type', 'subcontent_evaluations', 'overall'):
                continue
            value = getattr(self, field_name, None)
            if isinstance(value, MetricResult):
                scores[field_name] = value.score
        return scores
    
    def _failure_counts(self) -> tuple[int, int]:
        """Return (critical_failures, noncritical_failures) based on metric scores."""
        critical_failures = sum(
            1
            for metric_name in _CRITICAL_METRICS
            if isinstance(getattr(self, metric_name, None), MetricResult)
            and getattr(self, metric_name).score == 0.0
        )

        noncritical_failures = 0
        for field_name in type(self).model_fields:
            if field_name in _NONCRITICAL_EXCLUSIONS:
                continue
            metric = getattr(self, field_name, None)
            if isinstance(metric, MetricResult) and metric.score == 0.0:
                noncritical_failures += 1

        return critical_failures, noncritical_failures

    def overall_score_bounds(self) -> tuple[float, float]:
        """Return (floor, ceiling) for the overall score based on metric failure patterns.

        The LLM-generated overall score is clamped to this range so it stays
        within the band that the failure pattern warrants, while still allowing
        the LLM to express meaningful variation within that band.
        """
        integrity_check = getattr(self, "integrity_check", None)
        if isinstance(integrity_check, MetricResult) and integrity_check.score == 0.0:
            return (0.0, 0.0)

        critical, noncritical = self._failure_counts()

        if critical >= 2:
            return (0.0, 0.0)
        if critical == 1:
            if noncritical <= 2:
                return (0.55, 0.84)
            return (0.0, 0.55)
        # critical == 0
        if noncritical == 0:
            return (0.85, 1.0)
        if noncritical <= 2:
            return (0.55, 0.84)
        return (0.0, 0.65)

    def constrained_overall_score(self) -> float:
        """Clamp the LLM-generated overall score to the valid range for this failure pattern."""
        llm_score = self.overall.score
        floor, ceiling = self.overall_score_bounds()
        return max(floor, min(ceiling, llm_score))
    @computed_field
    @property
    def weighted_score(self) -> float:
        """
        Tier-weighted score based on metric importance.

        Critical metrics (factual_accuracy, educational_accuracy) are weighted 2x.
        Important metrics (curriculum_alignment, clarity, etc.) are weighted 1.5x.
        Enhancement metrics (localization, engagement, etc.) are weighted 1x.
        """
        scores = self._get_metric_scores()
        result = calculate_weighted_score(scores)
        return round(result, 4) if result is not None else 0.0

    @computed_field
    @property
    def overall_rating(self) -> OverallRating:
        """Qualitative rating derived deterministically from metric failure counts.

        Uses ``overall.score`` (which is set to the deterministic value by the
        evaluator pipeline) with the standard thresholds:
            >= 0.99  -> SUPERIOR
            >= 0.85  -> ACCEPTABLE
            <  0.85  -> INFERIOR
        """
        score = self.overall.score
        if score >= 0.99:
            return OverallRating.SUPERIOR
        elif score >= 0.85:
            return OverallRating.ACCEPTABLE
        else:
            return OverallRating.INFERIOR

    def to_json(self) -> str:
        """Convert to JSON string."""
        return self.model_dump_json(indent=2)
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return self.model_dump()


class EvaluationRequest(BaseModel):
    """
    Request model for content evaluation.
    
    Attributes:
        content: The educational content to evaluate (any string, may contain image URLs)
        curriculum: Curriculum to use for evaluation (defaults to "common_core")
        generation_prompt: Optional prompt used to generate the content (for AI-generated content)
    """
    content: str = Field(..., min_length=1, description="Content to evaluate")
    curriculum: str = Field(
        "common_core", 
        description="Curriculum for evaluation"
    )
    generation_prompt: Optional[str] = Field(
        None,
        description="Optional prompt used to generate the content (useful for evaluating AI-generated content)"
    )
    
    @field_validator('content')
    @classmethod
    def validate_content_not_empty(cls, v: str) -> str:
        """Ensure content is not just whitespace."""
        if not v.strip():
            raise ValueError("Content cannot be empty or just whitespace")
        return v


_interest_required_cache: Dict[type, type] = {}


def with_required_interest_relevance(model_cls: type[BaseEvaluationResult]) -> type[BaseEvaluationResult]:
    """
    Return a variant of model_cls where interest_relevance is required.

    When student_interests are provided, we need the LLM's structured-output
    schema to show interest_relevance as a required field (not optional) so the
    model cannot skip it.  This creates a thin subclass that overrides only that
    one field — all validators, serializers, and other fields are inherited.

    Results are cached per model class.
    """
    if model_cls not in _interest_required_cache:
        ns = {
            '__annotations__': {
                'interest_relevance': MetricResult,
            },
            'interest_relevance': Field(
                ...,
                description="Whether content reflects provided student interests"
            ),
        }
        variant = type(model_cls.__name__, (model_cls,), ns)
        _interest_required_cache[model_cls] = variant
    return _interest_required_cache[model_cls]

