# language: es
# ==============================================================================
# Ejemplo Completo de Testing de APIs REST
# Todos los steps usan los nombres EXACTOS definidos en api_testing_steps.py
#
# NOTA: No necesitas declarar "uso el modo api" en pruebas puras de API.
#       El reporte detecta automaticamente que es API y muestra request/response.
#
# URL de prueba: https://jsonplaceholder.typicode.com (API publica gratuita)
# ==============================================================================

@no_browser
Caracteristica: Testing Completo de APIs REST

  # ============================================================================
  # ESCENARIO 1: Configuracion de sesion y GET basico
  #
  # configuro la API base en "{url}"
  # configuro el header "{name}" con valor "{value}"
  # realizo GET a "{url}"
  # la respuesta deberia tener codigo "{status}"
  # el campo "{path}" de la respuesta deberia ser "{value}"
  # el campo "{path}" de la respuesta deberia contener "{value}"
  # el campo "{path}" de la respuesta no deberia estar vacio
  # el campo "{path}" deberia existir en la respuesta
  # la respuesta deberia ser un objeto JSON
  # verifico que la respuesta API es JSON valido
  # ============================================================================

  Escenario: GET basico con configuracion de sesion
    Dado que configuro la API base en "https://jsonplaceholder.typicode.com"
    Y configuro el header "Accept" con valor "application/json"
    Y configuro el header "Content-Type" con valor "application/json"

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "id" de la respuesta deberia ser "1"
    Y el campo "name" de la respuesta deberia ser "Leanne Graham"
    Y el campo "email" de la respuesta deberia contener "@"
    Y el campo "name" de la respuesta no deberia estar vacio
    Y el campo "id" deberia existir en la respuesta
    Y la respuesta deberia ser un objeto JSON
    Y verifico que la respuesta API es JSON valido


  # ============================================================================
  # ESCENARIO 2: Autenticacion Bearer Token
  #
  # configuro el token Bearer "{token}"
  # ============================================================================

  Escenario: GET con autenticacion Bearer Token
    Dado que configuro el token Bearer "${ENV.API_TOKEN}"
    Y configuro el header "Accept" con valor "application/json"

    Cuando realizo GET a "${ENV.API_BASE_URL}/protected/resource"

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "data" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 3: Autenticacion Basic Auth
  #
  # configuro autenticacion basica usuario "{user}" contrasena "{pass}"
  # ============================================================================

  Escenario: GET con autenticacion Basic Auth
    Dado que configuro autenticacion basica usuario "${ENV.API_USER}" contrasena "${ENV.API_PASSWORD}"

    Cuando realizo GET a "${ENV.API_BASE_URL}/secure/data"

    Entonces la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 4: Autenticacion API Key en header
  #
  # configuro API key en el header "{header}" con valor "{key}"
  # ============================================================================

  Escenario: GET con API Key en header personalizado
    Dado que configuro API key en el header "X-API-Key" con valor "${ENV.API_KEY}"

    Cuando realizo GET a "${ENV.API_BASE_URL}/data"

    Entonces la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 5: GET con query parameters
  #
  # realizo GET a "{url}" con parametros "{json}"
  # la respuesta deberia ser un array JSON
  # el array "{path}" de la respuesta deberia tener "{n}" elementos
  # el tiempo de respuesta deberia ser menor a "{ms}" milisegundos
  # ============================================================================

  Escenario: GET con query parameters y validacion de array
    Cuando realizo GET con parametros '{"userId": "1"}' a "https://jsonplaceholder.typicode.com/posts"

    Entonces la respuesta deberia tener codigo "200"
    Y la respuesta deberia ser un array JSON
    Y el array "" de la respuesta deberia tener "10" elementos
    Y el tiempo de respuesta deberia ser menor a "3000" milisegundos


  # ============================================================================
  # ESCENARIO 6: POST con body inline
  #
  # realizo POST a "{url}" con body "{body}"
  # guardo el campo "{path}" de la respuesta en la variable "{var}"
  # ============================================================================

  Escenario: POST con body inline y extraccion de ID
    Cuando realizo POST a "https://jsonplaceholder.typicode.com/posts" con body '{"title": "Test Post", "body": "Contenido", "userId": 1}'

    Entonces la respuesta deberia tener codigo "201"
    Y el campo "title" de la respuesta deberia ser "Test Post"
    Y el campo "id" deberia existir en la respuesta

    Cuando guardo el campo "id" de la respuesta en la variable "post_id"
    Entonces verifico que la variable "post_id" contiene "1"


  # ============================================================================
  # ESCENARIO 7: POST con body JSON multilinea (DocString)
  #
  # realizo POST a "{url}" con JSON body
  # (el body se define como DocString debajo del step)
  # ============================================================================

  Escenario: POST con body JSON multilinea como DocString
    Cuando envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {
        "title": "Articulo de prueba",
        "body": "Contenido del articulo",
        "userId": 1
      }
      """

    Entonces la respuesta deberia tener codigo "201"
    Y el campo "title" de la respuesta deberia ser "Articulo de prueba"


  # ============================================================================
  # ESCENARIO 8: POST con body desde archivo externo
  #
  # realizo POST a "{url}" con body del archivo "{file}"
  # cargo el cuerpo de peticion API del archivo "{file}" y envio POST a "{url}" guardando respuesta en variable "{var}"
  # ============================================================================

  Escenario: POST con body cargado desde archivo JSON
    Cuando cargo y envio POST a "https://jsonplaceholder.typicode.com/posts" con body del archivo "payloads/create_post.json"

    Entonces la respuesta deberia tener codigo "201"
    Y el campo "id" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 9: PUT - actualizar recurso completo
  #
  # realizo PUT a "{url}" con body "{body}"
  # realizo PUT a "{url}" con JSON body  (DocString)
  # realizo PUT a "{url}" con body del archivo "{file}"
  # ============================================================================

  Escenario: PUT para actualizar un recurso completo
    Cuando envio JSON body a "https://jsonplaceholder.typicode.com/posts/1" via PUT
      """
      {
        "id": 1,
        "title": "Titulo actualizado",
        "body": "Contenido actualizado",
        "userId": 1
      }
      """

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "title" de la respuesta deberia ser "Titulo actualizado"
    Y el campo "id" de la respuesta deberia ser "1"


  # ============================================================================
  # ESCENARIO 10: PATCH - actualizar parcialmente
  #
  # realizo PATCH a "{url}" con body "{body}"
  # realizo PATCH a "{url}" con JSON body  (DocString)
  # realizo PATCH a "{url}" con body del archivo "{file}"
  # ============================================================================

  Escenario: PATCH para actualizar parcialmente un recurso
    Cuando realizo PATCH a "https://jsonplaceholder.typicode.com/posts/1" con body '{"title": "Solo el titulo cambia"}'

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "title" de la respuesta deberia ser "Solo el titulo cambia"


  # ============================================================================
  # ESCENARIO 11: DELETE
  #
  # realizo DELETE a "{url}"
  # el body de la respuesta deberia estar vacio
  # ============================================================================

  Escenario: DELETE de un recurso
    Cuando realizo DELETE a "https://jsonplaceholder.typicode.com/posts/1"

    Entonces la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 12: Flujo CRUD completo encadenando requests
  # ============================================================================

  Escenario: Flujo CRUD completo
    Dado que configuro el header "Content-Type" con valor "application/json"

    # CREATE
    Cuando envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {"title": "Post CRUD", "body": "Contenido inicial", "userId": 1}
      """
    Entonces la respuesta deberia tener codigo "201"
    Y guardo el campo "id" de la respuesta en la variable "nuevo_id"

    # READ
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"
    Entonces la respuesta deberia tener codigo "200"
    Y el campo "userId" de la respuesta deberia ser "1"
    Y guardo el campo "title" de la respuesta en la variable "titulo_original"

    # UPDATE
    Cuando realizo PATCH a "https://jsonplaceholder.typicode.com/posts/1" con body '{"title": "Titulo modificado"}'
    Entonces la respuesta deberia tener codigo "200"
    Y el campo "title" de la respuesta deberia ser "Titulo modificado"

    # DELETE
    Cuando realizo DELETE a "https://jsonplaceholder.typicode.com/posts/1"
    Entonces la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 13: Guardar y reutilizar valores entre requests
  #
  # guardo el campo "{path}" de la respuesta en la variable "{var}"
  # guardo el body completo de la respuesta en la variable "{var}"
  # guardo el status code de la respuesta en la variable "{var}"
  # guardo el header "{header}" de la respuesta en la variable "{var}"
  # ============================================================================

  Escenario: Extraer y reutilizar datos entre requests
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts"
    Entonces guardo el campo "0.id" de la respuesta en la variable "primer_post_id"
    Y guardo el campo "0.userId" de la respuesta en la variable "user_id"
    Y guardo el status code de la respuesta en la variable "status_lista"
    Y guardo el body completo de la respuesta en la variable "body_completo"

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/${primer_post_id}"
    Entonces la respuesta deberia tener codigo "200"
    Y el campo "id" de la respuesta deberia ser "${primer_post_id}"
    Y el campo "userId" de la respuesta deberia ser "${user_id}"
    Y verifico que la variable "status_lista" es igual a "200"


  # ============================================================================
  # ESCENARIO 14: Validacion de headers de respuesta
  #
  # verifico que el header de respuesta API "{header}" es igual a "{value}"
  # verifico que el header de respuesta API "{header}" contiene "{text}"
  # guardo el header "{header}" de la respuesta en la variable "{var}"
  # ============================================================================

  Escenario: Validar headers de respuesta
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Entonces la respuesta deberia tener codigo "200"
    Y verifico que el header de respuesta API "Content-Type" contiene "application/json"
    Y guardo el header "Content-Type" de la respuesta en la variable "content_type"
    Y verifico que la variable "content_type" contiene "json"


  # ============================================================================
  # ESCENARIO 15: Validacion de tiempo y performance
  #
  # el tiempo de respuesta deberia ser menor a "{ms}" milisegundos
  # verifico que el tiempo de respuesta de la API es menor a "{s}" segundos
  # ============================================================================

  Escenario: Validar performance de la API
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Entonces la respuesta deberia tener codigo "200"
    Y el tiempo de respuesta deberia ser menor a "5000" milisegundos
    Y verifico que el tiempo de respuesta de la API es menor a "5" segundos


  # ============================================================================
  # ESCENARIO 16: POST con form data y multipart
  #
  # realizo POST a "{url}" con form data "{data}"
  # realizo POST a "{url}" con archivo multipart "{file}" en campo "{field}"
  # ============================================================================

  Escenario: POST con form data
    Cuando envio form data '{"username": "testuser", "action": "login"}' a "${ENV.API_BASE_URL}/form-endpoint"

    Entonces la respuesta deberia tener codigo "200"


  Escenario: POST subiendo un archivo
    Cuando subo archivo "test_files/documento.pdf" a "${ENV.API_BASE_URL}/upload" en campo "file"

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "filename" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 17: Validacion de esquema JSON
  #
  # verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema}"
  # verifico que el JSON de respuesta API coincide exactamente con el archivo "{file}"
  # verifico que el JSON de respuesta API coincide con el archivo "{file}" ignorando orden
  # verifico que el JSON de respuesta API coincide con el archivo "{file}" ignorando campos "{campos}"
  # ============================================================================

  Escenario: Validar respuesta contra esquema JSON Schema
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"
    Y verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/user_schema.json"


  Escenario: Comparar respuesta con archivo esperado
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Entonces la respuesta deberia tener codigo "200"
    Y verifico que el JSON de respuesta API coincide con el archivo "expected/post_1.json" ignorando orden
    Y verifico que el JSON de respuesta API coincide con el archivo "expected/post_1.json" ignorando campos "created_at,updated_at"


  # ============================================================================
  # ESCENARIO 18: Validaciones avanzadas de campos JSON
  #
  # verifico que el JSON de respuesta API tiene el campo "{field}" con tipo "{type}"
  # verifico que el campo "{field}" del JSON de respuesta API coincide con el patron "{regex}"
  # verifico que el campo "{field}" del JSON de respuesta API esta en el rango {min} a {max}
  # verifico que el JSON de respuesta API no tiene valores nulos
  # ============================================================================

  Escenario: Validaciones avanzadas de tipos y formatos
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"
    Y verifico que el JSON de respuesta API tiene el campo "id" con tipo "integer"
    Y verifico que el JSON de respuesta API tiene el campo "name" con tipo "string"
    Y verifico que el JSON de respuesta API tiene el campo "address" con tipo "object"
    Y verifico que el campo "email" del JSON de respuesta API coincide con el patron "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    Y verifico que el campo "id" del JSON de respuesta API esta en el rango 1 a 100


  # ============================================================================
  # ESCENARIO 19: Manejo de errores HTTP
  # ============================================================================

  Escenario: Verificar manejo de errores 404
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/99999"

    Entonces la respuesta deberia tener codigo "404"


  Escenario: Verificar rango de status codes exitosos
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Entonces verifico que el estado de respuesta API esta en el rango "200" a "299"


  # ============================================================================
  # ESCENARIO 20: Guardar respuesta en archivo
  #
  # guardo el cuerpo de respuesta API en el archivo "{file}"
  # ============================================================================

  Escenario: Guardar respuesta en archivo para analisis posterior
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users"

    Entonces la respuesta deberia tener codigo "200"
    Y guardo el cuerpo de respuesta API en el archivo "reports/users_response.json"


  # ============================================================================
  # ESCENARIO 21: Limpiar sesion y cambiar configuracion
  #
  # limpio los headers de sesion API
  # establezco el header de API "{header}" a "{value}"
  # establezco el timeout de API a "{timeout}" segundos
  # ============================================================================

  Escenario: Cambiar configuracion de sesion entre requests
    Dado que configuro el token Bearer "token-inicial"
    Y configuro el header "X-Custom" con valor "valor1"

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/1"
    Entonces la respuesta deberia tener codigo "200"

    Cuando limpio los headers de sesion API
    Y establezco el header de API "Authorization" a "Bearer token-nuevo"
    Y establezco el timeout de API a "10" segundos

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/2"
    Entonces la respuesta deberia tener codigo "200"
    Y el campo "id" de la respuesta deberia ser "2"


  # ============================================================================
  # ESCENARIO 22: Flujo de autenticacion con token dinamico
  # ============================================================================

  Escenario: Obtener token y usarlo en siguientes requests
    Dado que configuro el header "Content-Type" con valor "application/json"

    Cuando envio JSON body a "${ENV.AUTH_URL}/token" via POST
      """
      {
        "username": "${ENV.TEST_USER}",
        "password": "${ENV.TEST_PASSWORD}",
        "grant_type": "password"
      }
      """
    Entonces la respuesta deberia tener codigo "200"
    Y guardo el campo "access_token" de la respuesta en la variable "auth_token"

    Cuando configuro el token Bearer "${auth_token}"
    Y realizo GET a "${ENV.API_BASE_URL}/me"
    Entonces la respuesta deberia tener codigo "200"
    Y el campo "username" de la respuesta deberia ser "${ENV.TEST_USER}"


  # ============================================================================
  # ESCENARIO 23: Peticiones en lote desde archivo
  #
  # envio peticiones API en lote desde archivo "{file}" y guardo resultados en variable "{var}"
  # ============================================================================

  Escenario: Ejecutar multiples peticiones desde archivo de configuracion
    Cuando envío peticiones API en lote desde archivo "batch/requests.json" y guardo resultados en variable "batch_results"

    Entonces verifico que la variable "batch_results" contiene "status_code"


  # ============================================================================
  # ESCENARIO 24: Peticiones concurrentes
  #
  # envio peticiones API concurrentes "{n}" veces a "{url}" y verifico que todas tengan exito
  # ============================================================================

  Escenario: Verificar que la API soporta carga concurrente
    Cuando envío peticiones API concurrentes "5" veces a "https://jsonplaceholder.typicode.com/posts/1" y verifico que todas tengan éxito

    Entonces la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 25: Verificaciones de seguridad y CORS
  #
  # verifico que la respuesta API tiene headers de seguridad
  # verifico que los headers de rate limit estan presentes en la respuesta API
  # verifico que el endpoint API "{endpoint}" soporta CORS
  # ============================================================================

  Escenario: Verificar headers de seguridad
    Cuando realizo GET a "${ENV.API_BASE_URL}/secure"

    Entonces la respuesta deberia tener codigo "200"
    Y verifico que la respuesta API tiene headers de seguridad


  Escenario: Verificar soporte CORS del endpoint
    Entonces verifico que el endpoint API "https://jsonplaceholder.typicode.com/posts" soporta CORS


  # ============================================================================
  # ESCENARIO 26: JSONPath - existencia y tipos
  #
  # la respuesta deberia tener el campo "$.campo"
  # la respuesta no deberia tener el campo "$.campo"
  # el campo "$.campo" debe ser de tipo "string/number/integer/boolean/array/object/null"
  # ============================================================================

  Escenario: Verificar existencia y tipos con JSONPath
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"

    # Existencia
    Y la respuesta deberia tener el campo "$.id"
    Y la respuesta deberia tener el campo "$.address.city"
    Y la respuesta deberia tener el campo "$.address.geo.lat"
    Y la respuesta no deberia tener el campo "$.password"

    # Tipos
    Y el campo "$.id" debe ser de tipo "integer"
    Y el campo "$.name" debe ser de tipo "string"
    Y el campo "$.address" debe ser de tipo "object"


  # ============================================================================
  # ESCENARIO 27: JSONPath - valores exactos y parciales
  #
  # la respuesta deberia tener el campo "$.campo" con valor "valor"
  # la respuesta deberia tener el campo "$.campo" que contiene "texto"
  # el campo "$.campo" deberia ser nulo / no deberia ser nulo
  # el campo "$.campo" deberia estar vacio / no deberia estar vacio
  # ============================================================================

  Escenario: Verificar valores con notacion JSONPath
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"
    Y la respuesta deberia tener el campo "$.id" con valor "1"
    Y la respuesta deberia tener el campo "$.username" con valor "Bret"
    Y la respuesta deberia tener el campo "$.email" que contiene "@"
    Y el campo "$.name" no deberia ser nulo
    Y el campo "$.name" no deberia estar vacio


  # ============================================================================
  # ESCENARIO 28: JSONPath - comparaciones numericas
  #
  # el campo "$.campo" deberia ser mayor que "valor"
  # el campo "$.campo" deberia ser menor que "valor"
  # el campo "$.campo" deberia estar entre "min" y "max"
  # ============================================================================

  Escenario: Verificar rangos numericos con JSONPath
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/5"

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "$.id" debe ser de tipo "integer"
    Y el campo "$.id" deberia ser mayor que "0"
    Y el campo "$.id" deberia ser menor que "100"
    Y el campo "$.id" deberia estar entre "1" y "10"


  # ============================================================================
  # ESCENARIO 29: JSONPath - expresiones regulares
  #
  # el campo "$.campo" deberia coincidir con el patron "regex"
  # ============================================================================

  Escenario: Verificar formatos con expresiones regulares
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Entonces la respuesta deberia tener codigo "200"
    Y el campo "$.email" deberia coincidir con el patron "^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$"
    Y el campo "$.website" deberia coincidir con el patron "\\."


  # ============================================================================
  # ESCENARIO 30: JSONPath - arrays
  #
  # el arreglo "$.campo" deberia tener "N" elementos
  # el arreglo "$.campo" deberia tener al menos "N" elementos
  # en el arreglo "$.campo" en la posicion "N" encuentro "$.campo" con valor "valor"
  # en el arreglo "$.campo" en la posicion "N" encuentro el campo "$.campo"
  # el arreglo "$.campo" deberia contener un elemento con "$.campo" igual a "valor"
  # todos los elementos del arreglo "$.campo" deberian tener el campo "$.campo"
  # ============================================================================

  Escenario: Verificar arrays con notacion JSONPath
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users"

    Entonces la respuesta deberia tener codigo "200"
    Y la respuesta deberia ser un array JSON

    # Conteo
    Y el arreglo "$" deberia tener "10" elementos
    Y el arreglo "$" deberia tener al menos "5" elementos

    # Elemento en posicion especifica
    Y en el arreglo "$" en la posicion "0" encuentro "$.id" con valor "1"
    Y en el arreglo "$" en la posicion "0" encuentro el campo "$.name"
    Y en el arreglo "$" en la posicion "9" encuentro "$.id" con valor "10"

    # Buscar elemento con valor especifico
    Y el arreglo "$" deberia contener un elemento con "$.username" igual a "Bret"

    # Todos los elementos tienen un campo
    Y todos los elementos del arreglo "$" deberian tener el campo "$.id"
    Y todos los elementos del arreglo "$" deberian tener el campo "$.email"


  # ============================================================================
  # ESCENARIO 31: JSONPath - extraccion y reutilizacion
  #
  # guardo el campo "$.campo" de la respuesta en la variable "{var}"
  # ============================================================================

  Escenario: Extraer valores con JSONPath y usarlos en siguientes requests
    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts"
    Entonces la respuesta deberia tener codigo "200"
    Y guardo el campo "$.0.id" de la respuesta en la variable "primer_id"
    Y guardo el campo "$.0.userId" de la respuesta en la variable "user_id"

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/posts/${primer_id}"
    Entonces la respuesta deberia tener codigo "200"
    Y la respuesta deberia tener el campo "$.id" con valor "${primer_id}"
    Y la respuesta deberia tener el campo "$.userId" con valor "${user_id}"


  # ============================================================================
  # ESCENARIO 32: Flujo completo con JSONPath - crear y verificar
  # ============================================================================

  Escenario: Crear recurso y verificar estructura completa con JSONPath
    Dado que configuro el header "Content-Type" con valor "application/json"

    Cuando envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {
        "title": "Post de prueba JSONPath",
        "body": "Contenido del post",
        "userId": 1
      }
      """

    Entonces la respuesta deberia tener codigo "201"

    # Verificar con JSONPath
    Y la respuesta deberia tener el campo "$.id"
    Y el campo "$.id" debe ser de tipo "integer"
    Y la respuesta deberia tener el campo "$.title" con valor "Post de prueba JSONPath"
    Y el campo "$.title" no deberia estar vacio
    Y el campo "$.userId" deberia ser mayor que "0"

    # Guardar para uso posterior
    Y guardo el campo "$.id" de la respuesta en la variable "nuevo_post_id"
    Y guardo el campo "$.title" de la respuesta en la variable "titulo_creado"


  # ============================================================================
  # ESCENARIO 33: Combinacion de steps legacy y nuevos en el mismo escenario
  # ============================================================================

  Escenario: Usar steps legacy y nuevos juntos
    Dado que configuro el header "Accept" con valor "application/json"

    Cuando realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    # Steps legacy (siguen funcionando)
    Entonces verifico que el código de estado de la respuesta API es "200"
    Y verifico que la respuesta API contiene "name" con valor "Leanne Graham"
    Y extraigo el valor de la respuesta API "id" y lo guardo en la variable "user_id_legacy"

    # Steps nuevos simplificados
    Y la respuesta deberia tener codigo "200"
    Y el campo "name" de la respuesta deberia ser "Leanne Graham"
    Y guardo el campo "id" de la respuesta en la variable "user_id_nuevo"

    # Steps JSONPath
    Y la respuesta deberia tener el campo "$.id" con valor "1"
    Y el campo "$.name" debe ser de tipo "string"
    Y guardo el campo "$.email" de la respuesta en la variable "email_usuario"
