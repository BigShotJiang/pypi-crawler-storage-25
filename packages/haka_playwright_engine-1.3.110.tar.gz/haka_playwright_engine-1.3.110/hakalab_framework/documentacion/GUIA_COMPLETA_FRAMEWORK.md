# Guía Completa del Framework Hakalab v1.3.77

> Documentación exhaustiva del framework de automatización de pruebas basado en Playwright + Behave.
> Generada automáticamente desde el código fuente.

---

## --- Instalación y Configuración Inicial ---

tema: Instalación del framework
contenido: El framework se instala como paquete Python desde PyPI con el nombre `haka-playwright-engine`. Ejecuta `pip install haka-playwright-engine` para instalar la última versión. Después de instalar, ejecuta `playwright install` para descargar los navegadores necesarios (Chromium, Firefox, WebKit). Para crear un nuevo proyecto usa el CLI: `haka-init mi_proyecto`. Esto genera la estructura base con carpetas `features/`, `json_poms/`, archivos `.env`, `behave.ini` y `environment.py` preconfigurados. El framework se registra automáticamente como plugin de Behave a través de `behave_plugin.py`, por lo que no necesitas modificar `environment.py` manualmente. Las opciones de plantilla son `--template basic` o `--template advanced`, y el idioma se configura con `--language es`, `--language en` o `--language mixed`.

tema: Archivo .env y variables de entorno
contenido: El framework usa un archivo `.env` en la raíz del proyecto para toda la configuración. Se carga automáticamente con `python-dotenv` con `override=True`, lo que significa que las variables del `.env` tienen prioridad sobre las del sistema. Las variables principales son: `BROWSER` (chromium/firefox/webkit/chrome), `HEADLESS` (true/false), `TIMEOUT` (milisegundos, default 30000), `BASE_URL`, `VIEWPORT_WIDTH` y `VIEWPORT_HEIGHT` (default 1920x1080). Para screenshots: `SCREENSHOTS_DIR`, `SCREENSHOT_FULL_PAGE` (true/false), `AUTO_SCREENSHOT_ON_FAILURE`. Para video: `RECORD_VIDEO`, `VIDEO_DIR`, `VIDEO_SIZE`, `VIDEO_MODE` (on/off/retain-on-failure). Para logging: `LOG_LEVEL` (DEBUG/INFO/WARNING/ERROR). Para API testing: `API_BASE_URL`, `API_TIMEOUT`, `API_KEY`, `BEARER_TOKEN`. Para base de datos: `DB_TYPE` (sqlite/mysql/postgresql), `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`. Para Gemini AI: `GEMINI_API_KEY`, `GEMINI_JUDGE_MODEL`, `GEMINI_JUDGE_THRESHOLD`. Para semántica: `SEMANTIC_MODEL`, `SEMANTIC_THRESHOLD`. Para reportes: `HTML_REPORTS_DIR`, `GENERATE_AI_REPORT`, `AI_REPORT_PATH`. Para ocultar warnings: `HIDE_TRANSFORMERS_WARNINGS`, `HIDE_HF_WARNINGS`, `HIDE_BEHAVE_WARNINGS`. Todas las variables tienen valores por defecto sensatos.

tema: Estructura del proyecto
contenido: Un proyecto típico tiene esta estructura:
```
mi_proyecto/
├── .env                    # Variables de entorno
├── behave.ini              # Configuración de Behave
├── features/               # Archivos .feature (Gherkin)
│   ├── login.feature
│   ├── steps/              # Steps personalizados del proyecto
│   │   └── mis_steps.py
│   └── environment.py      # (opcional, el plugin lo maneja)
├── json_poms/              # Page Object Models en JSON
│   ├── LOGIN.json
│   └── DASHBOARD.json
├── reports/                # Reportes generados
│   ├── screenshots/
│   ├── videos/
│   └── html-reports/
└── downloads/              # Archivos descargados
```
Los archivos `.feature` van en `features/`, los POMs JSON en `json_poms/`, y los steps personalizados en `features/steps/`. El framework carga automáticamente todos sus steps internos (512+) sin necesidad de importarlos.

---

## --- Referencia Completa de Variables de Entorno (.env) ---

tema: Navegador - Configuración principal
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `BROWSER` | string | `chromium` | Navegador a usar: `chromium`, `firefox`, `webkit`, `chrome` |
| `HEADLESS` | bool | `false` | Ejecutar sin interfaz gráfica |
| `TIMEOUT` | int (ms) | `30000` | Timeout global para operaciones de Playwright |
| `ASSERTION_TIMEOUT` | int (ms) | `30000` | Timeout específico para assertions/verificaciones |
| `VIEWPORT_WIDTH` | int | `1920` | Ancho del viewport en píxeles |
| `VIEWPORT_HEIGHT` | int | `1080` | Alto del viewport en píxeles |
| `DEVICE_SCALE_FACTOR` | float | `1` | Factor de escala del dispositivo (2 para retina) |
| `SLOW_MO` | int (ms) | `0` | Milisegundos de pausa entre cada acción de Playwright |
| `BASE_URL` | string | `""` | URL base de la aplicación bajo prueba |
| `IGNORE_HTTPS_ERRORS` | bool | `false` | Ignorar errores de certificados SSL |
| `BROWSER_USER_AGENT` | string | `""` | User agent personalizado (alias: `USER_AGENT`) |
| `STEALTH_MODE` | bool | `false` | Activar modo anti-detección (requiere `playwright-stealth`) |

tema: Navegador - Configuración avanzada
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `BROWSER_ARGS` | string | `""` | Argumentos adicionales del navegador separados por coma |
| `BROWSER_CONFIG_PRESET` | string | `""` | Preset predefinido: `performance`, `mobile`, `cicd`, `security_disabled` |
| `BROWSER_CONFIG_FILE` | string | `""` | Ruta a archivo JSON con argumentos del navegador |
| `BROWSER_MEMORY_LIMIT` | int (MB) | `4096` | Límite de memoria para el navegador |
| `BROWSER_PROXY` | string | `""` | URL del proxy (ej: `http://proxy:8080`) |
| `BROWSER_DOWNLOADS_DIR` | string | `downloads` | Directorio para archivos descargados |
| `BROWSER_DOWNLOAD_BEHAVIOR` | string | `auto` | Comportamiento de descargas |

tema: Chrome/Chromium - Configuración específica
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `CHROME_DISABLE_SECURITY` | bool | `false` | Desactivar seguridad web (web-security, certificate errors) |
| `CHROME_ENABLE_LOGGING` | bool | `false` | Activar logging del navegador |
| `CHROME_LOG_LEVEL` | string | `INFO` | Nivel de log del navegador |
| `CHROME_DISABLE_EXTENSIONS` | bool | `true` | Desactivar extensiones |
| `CHROME_DISABLE_PLUGINS` | bool | `true` | Desactivar plugins |
| `CHROME_DISABLE_IMAGES` | bool | `false` | No cargar imágenes (acelera pruebas) |
| `CHROME_DISABLE_JAVASCRIPT` | bool | `false` | Desactivar JavaScript |

tema: Firefox - Configuración específica
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `FIREFOX_PROFILE_PATH` | string | `""` | Ruta a perfil de Firefox personalizado |
| `FIREFOX_DISABLE_ADDONS` | bool | `true` | Desactivar addons (safe mode) |
| `FIREFOX_PRIVATE_MODE` | bool | `false` | Abrir en modo privado |

tema: WebKit - Configuración específica
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `WEBKIT_DISABLE_FEATURES` | string | `""` | Features a desactivar separadas por coma |

tema: Screenshots
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `SCREENSHOTS_DIR` | string | `screenshots` | Directorio donde se guardan los screenshots |
| `SCREENSHOT_FULL_PAGE` | bool | `true` | Capturar página completa (`true`) o solo viewport (`false`) |
| `AUTO_SCREENSHOT_ON_FAILURE` | bool | `true` | Tomar screenshot automáticamente cuando un escenario falla |

tema: Video
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `RECORD_VIDEO` | bool | `false` | Activar grabación de video |
| `VIDEO_DIR` | string | `videos` | Directorio donde se guardan los videos |
| `VIDEO_SIZE` | string | `1280x720` | Resolución del video (ancho x alto) |
| `VIDEO_MODE` | string | `retain-on-failure` | Cuándo guardar: `on` (siempre), `off` (nunca), `retain-on-failure` (solo fallos) |
| `CLEANUP_OLD_VIDEOS` | bool | `true` | Limpiar videos antiguos automáticamente |
| `VIDEO_MAX_AGE_HOURS` | int | `168` | Edad máxima de videos en horas (168 = 7 días) |

tema: Reportes y archivos
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `HTML_REPORTS_DIR` | string | `html-reports` | Directorio para reportes HTML |
| `ALLURE_RESULTS_DIR` | string | `allure-results` | Directorio para resultados de Allure |
| `DOWNLOADS_DIR` | string | `downloads` | Directorio para archivos descargados |
| `JSON_POMS_PATH` | string | `json_poms` | Directorio donde están los archivos JSON de POMs |

tema: Limpieza automática de archivos
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `CLEANUP_OLD_FILES` | bool | `false` | Activar limpieza automática de screenshots y reportes |
| `CLEANUP_MODE` | string | `all` | Modo de limpieza: `all` (elimina todo) o `old` (solo archivos antiguos) |
| `CLEANUP_MAX_AGE_HOURS` | int | `24` | Edad máxima en horas para modo `old` |

tema: Logging y warnings
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `LOG_LEVEL` | string | `INFO` | Nivel de logging: `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `LOG_FILE` | string | `""` | Ruta a archivo de log (vacío = solo consola) |
| `ENVIRONMENT` | string | `dev` | Entorno de ejecución: `dev`, `staging`, `production` |
| `HIDE_TRANSFORMERS_WARNINGS` | bool | `false` | Ocultar warnings de transformers/sentence-transformers |
| `HIDE_HF_WARNINGS` | bool | `false` | Ocultar warnings de Hugging Face Hub |
| `HIDE_BEHAVE_WARNINGS` | bool | `false` | Ocultar warnings de Behave context masking |
| `HAKALAB_SHOW_STEPS` | bool | `false` | Mostrar lista de steps cargados al iniciar |
| `HAKALAB_DEBUG` | bool | `false` | Activar mensajes de debug del framework |

tema: Pruebas y reintentos
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `AUTO_WAIT_FOR_LOAD` | bool | `true` | Esperar automáticamente a que la página cargue |
| `RETRY_FAILED_STEPS` | int | `0` | Número de reintentos para steps fallidos |
| `RETRY_FAILED_SCENARIOS` | bool | `false` | Activar reintentos automáticos de escenarios fallidos |
| `MAX_SCENARIO_RETRIES` | int | `1` | Número máximo de reintentos por escenario |

tema: Paralelización
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `PARALLEL_WORKERS` | int | `4` | Número de workers para ejecución paralela |
| `MAX_BROWSER_INSTANCES` | int | `10` | Máximo de instancias de navegador simultáneas |
| `BROWSER_POOL_SIZE` | int | `5` | Tamaño del pool de navegadores |
| `WORKER_TIMEOUT` | int (s) | `300` | Timeout por worker en segundos |
| `SHARD_INDEX` | int | — | Índice del shard actual (para CI/CD) |
| `TOTAL_SHARDS` | int | — | Total de shards (para CI/CD) |

tema: Datos de prueba
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `TEST_EMAIL` | string | `""` | Email de prueba (accesible via `context.test_data['email']`) |
| `TEST_PASSWORD` | string | `""` | Contraseña de prueba (accesible via `context.test_data['password']`) |
| `TEST_USER_NAME` | string | `""` | Nombre de usuario de prueba |

tema: API Testing
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `API_BASE_URL` | string | `""` | URL base para testing de APIs |
| `API_TIMEOUT` | int (s) | `30` | Timeout para requests HTTP en segundos |
| `API_KEY` | string | `""` | API Key para autenticación |
| `BEARER_TOKEN` | string | `""` | Bearer token para autenticación |

tema: Base de datos
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `DB_TYPE` | string | `sqlite` | Tipo de BD: `sqlite`, `mysql`, `postgresql` |
| `DB_SQLITE_PATH` | string | `test_data/test.db` | Ruta al archivo SQLite |
| `DB_SQLITE_TIMEOUT` | int (s) | `30` | Timeout de conexión SQLite |
| `DB_MYSQL_HOST` | string | `localhost` | Host de MySQL |
| `DB_MYSQL_PORT` | int | `3306` | Puerto de MySQL |
| `DB_MYSQL_DATABASE` | string | `test_db` | Nombre de la base de datos MySQL |
| `DB_MYSQL_USERNAME` | string | `test_user` | Usuario de MySQL |
| `DB_MYSQL_PASSWORD` | string | `test_password` | Contraseña de MySQL |
| `DB_MYSQL_CHARSET` | string | `utf8mb4` | Charset de MySQL |
| `DB_POSTGRES_HOST` | string | `localhost` | Host de PostgreSQL |
| `DB_POSTGRES_PORT` | int | `5432` | Puerto de PostgreSQL |
| `DB_POSTGRES_DATABASE` | string | `test_db` | Nombre de la base de datos PostgreSQL |
| `DB_POSTGRES_USERNAME` | string | `test_user` | Usuario de PostgreSQL |
| `DB_POSTGRES_PASSWORD` | string | `test_password` | Contraseña de PostgreSQL |
| `DB_CONNECTION_TIMEOUT` | int (s) | `30` | Timeout de conexión a BD |
| `DB_AUTO_COMMIT` | bool | `true` | Auto-commit en operaciones de escritura |
| `DB_DEBUG_QUERIES` | bool | `false` | Mostrar queries ejecutadas en el log |
| `DB_BACKUP_DIR` | string | `test_data/backups` | Directorio para backups de BD |

tema: Gemini AI (Juez)
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `GEMINI_API_KEY` | string | — | API Key de Google Gemini (requerida para GenAI) |
| `GEMINI_JUDGE_MODEL` | string | `gemini-2.5-flash` | Modelo de Gemini a usar. Opciones: `gemini-2.5-pro`, `gemini-2.5-flash` (recomendado), `gemini-2.5-flash-lite`, `gemini-3-pro-preview` |
| `GEMINI_JUDGE_THRESHOLD` | float | `0.80` | Umbral por defecto para evaluaciones (0.0-1.0). 0.90+ excelencia, 0.80+ bueno, 0.70+ aceptable |
| `GEMINI_JUDGE_PROMPT_FILE` | string | `""` | Ruta a archivo con prompt personalizado para el juez |
| `GEMINI_CACHE_THRESHOLD` | int | `32000` | Umbral de tokens para activar Context Caching |
| `GEMINI_CACHE_TTL_HOURS` | int | `1` | TTL del caché en horas |

tema: Reportes de IA
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `GENERATE_AI_REPORT` | bool | `true` | Generar reporte especializado de validaciones IA |
| `AI_REPORT_PATH` | string | `reports/ai-reports` | Directorio para reportes de IA |
| `AI_REPORT_ANALYSIS` | bool | `true` | Usar Gemini para análisis automático del reporte |

tema: Validación semántica
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `SEMANTIC_MODEL` | string | `paraphrase-multilingual-MiniLM-L12-v2` | Modelo de Sentence Transformers. Opciones: `paraphrase-multilingual-MiniLM-L12-v2` (~420MB, multilingüe), `paraphrase-multilingual-mpnet-base-v2` (~1GB, más preciso), `all-MiniLM-L6-v2` (~80MB, solo inglés) |
| `SEMANTIC_THRESHOLD` | float | `0.75` | Umbral de similitud semántica (0.0-1.0). 0.85 estricto, 0.75 estándar, 0.70 flexible |

tema: OCR
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `TESSERACT_PATH` | string | `""` | Ruta al ejecutable de Tesseract (necesario en Windows) |

tema: Jira
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `JIRA_ENABLED` | bool | `false` | Activar integración con Jira |
| `JIRA_URL` | string | `""` | URL de la instancia Jira (ej: `https://tu-empresa.atlassian.net`) |
| `JIRA_EMAIL` | string | `""` | Email de la cuenta Jira |
| `JIRA_TOKEN` | string | `""` | API token de Jira |
| `JIRA_PROJECT` | string | `""` | Clave del proyecto (ej: `PROJ`) |
| `JIRA_COMMENT_MESSAGE` | string | `Reporte prueba de QA` | Mensaje personalizado para comentarios en issues |
| `JIRA_UPLOAD_REPORTS` | bool | `true` | Subir reportes automáticamente a issues |

tema: Xray (Test Management)
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `XRAY_ENABLED` | bool | `false` | Activar integración con Xray |
| `XRAY_AUTHORIZATION_TOKEN` | string | `""` | Bearer token de Xray Cloud |
| `XRAY_BASE_URL` | string | `https://xray.cloud.getxray.app` | URL base de la API de Xray |
| `XRAY_TEST_PLAN` | string | `""` | Clave del Test Plan en Jira |

tema: Azure DevOps
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `AZURE_DEVOPS_ENABLED` | bool | `false` | Activar integración con Azure DevOps |
| `AZURE_DEVOPS_ORG` | string | `""` | Nombre de la organización en Azure DevOps |
| `AZURE_DEVOPS_PROJECT` | string | `""` | Nombre del proyecto |
| `AZURE_DEVOPS_PAT` | string | `""` | Personal Access Token (requiere permisos Work Items Read & Write) |
| `AZURE_DEVOPS_STATUS_FIELD` | string | `Custom.TestStatus` | Campo personalizado para estado del test |
| `AZURE_DEVOPS_STATUS_PASSED` | string | `Passed` | Valor del campo para estado "passed" |
| `AZURE_DEVOPS_STATUS_FAILED` | string | `Failed` | Valor del campo para estado "failed" |
| `AZURE_DEVOPS_ATTACH_REPORT` | bool | `true` | Adjuntar reportes automáticamente |
| `AZURE_DEVOPS_REPORT_PATH` | string | `reports/report.html` | Ruta del reporte a adjuntar |
| `AZURE_DEVOPS_API_VERSION` | string | `7.1` | Versión de la API de Azure DevOps |

tema: Email Testing
contenido:
| Variable | Tipo | Default | Descripción |
|---|---|---|---|
| `SMTP_HOST` | string | `""` | Host del servidor SMTP |
| `SMTP_PORT` | int | `587` | Puerto SMTP |
| `SMTP_USER` | string | `""` | Usuario SMTP |
| `SMTP_PASSWORD` | string | `""` | Contraseña SMTP (usar app password para Gmail) |
| `IMAP_HOST` | string | `""` | Host del servidor IMAP |
| `IMAP_PORT` | int | `993` | Puerto IMAP |
| `IMAP_USER` | string | `""` | Usuario IMAP |
| `IMAP_PASSWORD` | string | `""` | Contraseña IMAP |

---

## --- Sistema de Page Object Model (JSON POMs) ---

tema: Formato básico de POMs JSON
contenido: El framework usa un sistema de Page Object Model basado en archivos JSON ubicados en la carpeta configurada por `JSON_POMS_PATH` (default: `json_poms/`). Cada archivo JSON representa una página o componente. Los elementos se referencian en los steps con el formato `$.ARCHIVO.elemento`. Por ejemplo, si tienes `json_poms/LOGIN.json` con `{"username": "#user-input", "password": "#pass-input"}`, en tu feature escribes:
```gherkin
When relleno el campo "usuario" con "admin" con identificador "$.LOGIN.username"
And relleno el campo "contraseña" con "secret" con identificador "$.LOGIN.password"
```
Los selectores pueden ser CSS (`#id`, `.class`, `[attr=val]`) o XPath (`//div[@class='x']`). El sistema cachea los archivos JSON para mejor rendimiento y puedes limpiar el caché con `context.element_locator.reload_cache()`.

tema: Placeholders dinámicos en POMs
contenido: Los POMs soportan placeholders que se reemplazan en tiempo de ejecución. Hay dos tipos: placeholders de texto (con comillas) y de enteros (sin comillas). Los placeholders de texto son: `<valor>`, `<value>`, `<placeholder>`, `{valor}`, `{value}`, `{placeholder}`. Los de enteros son: `<valor_int>`, `<value_int>`, `<int>`, `{valor_int}`, `{value_int}`, `{int}`. Ejemplo en JSON:
```json
{
  "resultado_por_texto": "//*[contains(text(), '<valor>')]",
  "checkbox_por_indice": "(//input[@type='checkbox'])[<valor_int>]"
}
```
En el feature se usa con `=` para pasar el valor dinámico:
```gherkin
When hago click en el elemento "resultado" con identificador "$.SEARCH.resultado_por_texto=Hola Mundo"
And hago click en el elemento "checkbox 3" con identificador "$.SEARCH.checkbox_por_indice=3"
```
Los valores de texto se escapan automáticamente para XPath (comillas simples, dobles y mixtas).

tema: Fallbacks automáticos en POMs
contenido: Los elementos pueden definir selectores de respaldo que se intentan automáticamente si el selector principal no encuentra el elemento. Formato en JSON:
```json
{
  "boton_enviar": {
    "selector": "button[type='submit']",
    "fallbacks": [
      ".btn-primary",
      "//button[contains(text(), 'Enviar')]"
    ]
  }
}
```
El framework intenta el selector principal primero. Si no encuentra el elemento (usando `count() > 0`), prueba cada fallback en orden. Esto es útil para elementos que cambian de selector entre versiones de la aplicación. En la consola verás `✓ Elemento encontrado usando fallback #1: .btn-primary` cuando se usa un fallback.

tema: Localizadores por Role (accesibilidad)
contenido: Los POMs soportan localizadores basados en roles de accesibilidad usando `get_by_role()` de Playwright. Formato en JSON:
```json
{
  "campo_nombre": {
    "role": "textbox",
    "type": "name",
    "value": "Ingresa tu nombre"
  },
  "boton_login": {
    "role": "button",
    "type": "exact",
    "value": "Login"
  }
}
```
El `type` puede ser `name` (busca por nombre accesible, aria-label, label) o `exact` (coincidencia exacta del nombre). Esto genera internamente `page.get_by_role("textbox", name="Ingresa tu nombre")`. Es la forma más robusta y accesible de localizar elementos.

tema: Inferencia automática de localizadores
contenido: Los POMs pueden usar `type` y `value` para que el framework infiera el selector automáticamente:
```json
{
  "titulo": {"type": "text", "value": "Bienvenido"},
  "campo_email": {"type": "placeholder", "value": "Ingrese su email"},
  "contenedor": {"type": "id", "value": "main-container"},
  "boton": {"type": "class", "value": "btn-primary"},
  "input_nombre": {"type": "name", "value": "first_name"},
  "etiqueta": {"type": "label", "value": "Nombre completo"},
  "custom": {"type": "data-testid", "value": "login-form"}
}
```
Los tipos soportados son: `text` (XPath por texto visible con fallback), `label` (XPath por label), `placeholder`, `id`, `class`, `name`, y cualquier atributo `data-*`. El tipo `text` genera automáticamente un fallback: primero `contains(text(), 'valor')` y luego `text()='valor'` exacto.

tema: Índices para elementos múltiples
contenido: Cuando un selector coincide con múltiples elementos, puedes usar índices con la sintaxis `[n]` para seleccionar uno específico (base 0). Ejemplo:
```gherkin
When relleno el campo "nombre 1" con "Juan" con identificador "$.CONTACTO.campo_nombre[0]"
And relleno el campo "nombre 2" con "Pedro" con identificador "$.CONTACTO.campo_nombre[1]"
```
Internamente usa `.nth(n)` de Playwright. También se puede combinar con placeholders dinámicos: `$.SEARCH.resultado[2]=Hola`. El índice se extrae antes de resolver el placeholder.

---

## --- Sistema de Variables ---

tema: Variables del framework
contenido: El framework tiene un sistema de variables con dos alcances: `scenario` (se limpian al terminar cada escenario) y `global` (persisten durante toda la ejecución). Las variables se referencian en los steps con la sintaxis `${nombre_variable}`. Para variables de entorno explícitas se usa `${ENV.NOMBRE}`. Ejemplo en feature:
```gherkin
Given guardo el valor "admin@test.com" en la variable "email"
When relleno el campo "email" con "${email}" con identificador "$.LOGIN.email"
And voy a la url "${ENV.BASE_URL}/dashboard"
```
El `VariableManager` busca primero en variables de escenario, luego en globales, y finalmente en variables de entorno del sistema. Si la variable no existe, el texto `${variable}` se mantiene sin cambios. Las variables se resuelven automáticamente en URLs, textos de campos, y cualquier parámetro de los steps que pase por `resolve_variables()`.

tema: Generación de datos aleatorios y dinámicos
contenido: Los `variable_steps` incluyen steps para generar datos dinámicos sin necesidad de código Python. Esto es útil para crear datos únicos en cada ejecución y evitar colisiones en pruebas paralelas.
```gherkin
# Texto aleatorio de N caracteres (letras + dígitos)
When genero un texto aleatorio de 10 caracteres y lo guardo en la variable "codigo"

# Número aleatorio entre min y max
When genero un número aleatorio entre 1 y 1000 y lo guardo en la variable "id_random"

# Timestamp actual (formato ISO: 2026-03-15T14:30:00)
When genero un timestamp y lo guardo en la variable "ts"

# Fecha actual con formato personalizado (default: %Y-%m-%d)
When genero la fecha actual con formato "%d/%m/%Y" y la guardo en la variable "fecha_hoy"

# Fecha de días hábiles (excluye sábados y domingos)
When genero la fecha de 5 días hábiles a partir de hoy con formato "%Y-%m-%d" y la guardo en la variable "fecha_entrega"
```
La generación de días hábiles usa un algoritmo que salta sábados y domingos automáticamente. El formato de fecha acepta cualquier directiva de `strftime` de Python (`%Y`, `%m`, `%d`, `%H`, `%M`, `%S`, etc.).

tema: Operaciones con variables
contenido: Los steps permiten manipular variables existentes sin escribir código:
```gherkin
# Concatenar dos variables en una nueva
When concateno las variables "nombre" y "apellido" y guardo el resultado en "nombre_completo"

# Incrementar variable numérica
When incremento la variable "contador" en 1

# Copiar variable
When copio la variable "original" a la variable "copia"

# Imprimir valor (útil para debug)
When imprimo el valor de la variable "mi_variable"

# Listar todas las variables activas
When listo todas las variables

# Limpiar todas las variables
When limpio todas las variables
```
La concatenación une los valores con un espacio. El incremento convierte a entero, suma, y guarda como string. `listo todas las variables` imprime en consola todas las variables de escenario y globales con sus valores actuales, útil para debugging.

tema: Verificación de variables
contenido: Puedes verificar el contenido de variables sin interactuar con la página:
```gherkin
# Verificar que contiene un texto (parcial)
Then verifico que la variable "titulo" contiene "Dashboard"

# Verificar valor exacto
Then verifico que la variable "estado" es igual a "activo"
```
Ambos steps resuelven variables dentro del valor esperado, así que puedes hacer `verifico que la variable "resultado" es igual a "${esperado}"`. Si la verificación falla, el mensaje de error muestra el valor actual vs el esperado.

tema: Extracción y almacenamiento de datos
contenido: Los `data_extraction_steps` permiten extraer datos de la página y guardarlos en variables para usarlos después. Van más allá de texto simple:
```gherkin
# Texto visible de un elemento
When obtengo el texto del elemento "titulo" y lo guardo en la variable "titulo_pagina" con identificador "$.PAGE.titulo"

# Valor de un campo de formulario (input_value)
When obtengo el valor del campo "email" y lo guardo en la variable "email_actual" con identificador "$.FORM.email"

# Atributo HTML de un elemento
When obtengo el atributo "href" del elemento "link" y lo guardo en la variable "url_link" con identificador "$.PAGE.link"

# Propiedad CSS computada
When obtengo la propiedad css "color" del elemento "titulo" y la guardo en la variable "color_titulo" con identificador "$.PAGE.titulo"

# URL actual del navegador
When obtengo la url actual y la guardo en la variable "url_actual"

# Título de la página
When obtengo el título de la página y lo guardo en la variable "titulo"

# Contar elementos que coinciden con un selector
When cuento los elementos con identificador "$.TABLE.filas" y guardo el conteo en la variable "total_filas"

# Verificar visibilidad y guardar resultado (true/false)
When verifico si el elemento "banner" es visible y guardo el resultado en la variable "banner_visible" con identificador "$.PAGE.banner"

# Verificar si está habilitado
When verifico si el elemento "boton" está habilitado y guardo el resultado en la variable "boton_activo" con identificador "$.FORM.submit"

# Verificar si checkbox está marcado
When verifico si el checkbox "terminos" está marcado y guardo el resultado en la variable "aceptado" con identificador "$.FORM.checkbox"
```
Las variables de escenario se limpian automáticamente al inicio de cada escenario nuevo. Las variables globales se mantienen entre escenarios del mismo feature, útil para compartir datos como tokens o IDs generados.

---

## --- Creación de Steps Personalizados ---

tema: Estructura de un step personalizado
contenido: Los steps personalizados se crean en archivos Python dentro de `features/steps/`. Cada step usa el decorador `@step()` de Behave con el patrón en español y/o inglés. Estructura básica:
```python
from behave import step

@step('mi paso personalizado con "{parametro}"')
@step('que mi paso personalizado con "{parametro}"')
def step_mi_paso(context, parametro):
    """Descripción de lo que hace el paso"""
    # Resolver variables si el parámetro puede contenerlas
    valor = context.variable_manager.resolve_variables(parametro)
    
    # Acceder a la página de Playwright
    context.page.locator('#mi-elemento').fill(valor)
    
    # Usar el localizador de elementos JSON
    element = context.element_locator.find(context.page, "$.MI_POM.elemento")
    element.click()
    
    # Guardar datos en variables
    context.variable_manager.set_variable("resultado", "valor_obtenido")
```
Es importante agregar siempre la variante con prefijo `que ` para que funcione como Given/When/Then indistintamente. Los parámetros entre comillas dobles `"{param}"` capturan strings, y `{param:d}` captura enteros.

tema: Reglas para evitar ambigüedad en steps
contenido: Behave no puede distinguir entre dos pasos cuando uno es prefijo del otro. Esto causa `AmbiguousStep`. Regla de oro: si dos pasos comparten los mismos parámetros iniciales, deben tener palabras clave diferentes que los distingan. Ejemplo incorrecto: `'verifico que el elemento "{name}"'` y `'verifico que el elemento "{name}" tiene clase "{class}"'`. Ejemplo correcto: `'verifico que el elemento "{name}" existe'` y `'verifico que el elemento "{name}" tiene clase "{class}"'`. La palabra "existe" vs "tiene" hace que sean claramente diferentes. Antes de crear un step, busca en los archivos existentes si ya existe algo similar con `grep`. Checklist: ¿El paso es prefijo de otro? ¿Otro paso podría ser prefijo de este? ¿Hay palabras clave que diferencien claramente? Los parámetros deben estar en orden lógico y cada step debe ser único e inequívoco.

tema: Objetos disponibles en context
contenido: Dentro de cualquier step personalizado, el objeto `context` de Behave tiene estos atributos principales configurados por el framework:
- `context.page` — Página activa de Playwright (para interactuar con el navegador)
- `context.browser` — Instancia del navegador Playwright
- `context.element_locator` — Instancia de `ElementLocator` para buscar elementos desde JSON POMs
- `context.variable_manager` — Instancia de `VariableManager` para gestionar variables
- `context.logger` — Logger configurado del framework
- `context.framework_config` — Configuración completa del framework (`FrameworkConfig`)
- `context.test_data` — Diccionario con datos de prueba del `.env` (email, password, etc.)
- `context.data_snapshot` — `DataSnapshotManager` para capturar datos en pruebas sin UI
- `context.soft_assertions` — `SoftAssertionManager` (si está habilitado)
- `context.current_frame` — Frame actual si se está dentro de un iframe (o `None`)
- `context.api_listening_active` — Booleano para escucha de API activa

Si el escenario tiene el tag `@no_browser`, `context.page` y `context.browser` no estarán disponibles, y `context.browser_disabled` será `True`.

tema: Convenciones internas del framework para crear steps
contenido: Los steps del framework siguen convenciones específicas que debes replicar en tus steps personalizados para mantener consistencia y compatibilidad con iframes, POMs JSON y frameworks SPA.

**1. Función auxiliar `_get_element`:** Todos los archivos de steps incluyen esta función al inicio. Soporta selectores CSS directos e identificadores JSON (`$.ARCHIVO.elemento`), y detecta automáticamente si estamos dentro de un iframe:
```python
def _get_element(context, selector, dynamic_value=None):
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)
```
Usa siempre `_get_element()` en vez de `context.page.locator()` directamente. Así tus steps funcionarán dentro de iframes sin cambios.

**2. Decoradores trilingües (español + inglés + prefijo `que`):** Cada step debe tener al menos la versión en español y la variante con `que` para que funcione como Given/When/Then:
```python
@step('I click on the element "{name}" with identifier "{identifier}"')
@step('hago click en el elemento "{name}" con identificador "{identifier}"')
@step('que hago click en el elemento "{name}" con identificador "{identifier}"')
def step_click(context, name, identifier):
    element = _get_element(context, identifier)
    element.click()
```

**3. Resolver variables siempre:** Todo parámetro que pueda contener `${variable}` debe pasar por `resolve_variables()`:
```python
resolved = context.variable_manager.resolve_variables(parametro)
```

**4. Usar `get_locator()` vs `find()`:** `get_locator(identifier)` retorna el string del selector CSS/XPath. `find(page, identifier)` retorna directamente el Locator de Playwright listo para usar. Prefiere `find()` para interacciones y `get_locator()` cuando necesitas el string raw (ej: para `page.locator()` o `page.select_option()`).

**5. Disparar eventos para frameworks SPA:** Después de interacciones con formularios (fill, select, date), dispara eventos para que Angular/React/Vue detecten los cambios:
```python
element.dispatch_event('input')
element.dispatch_event('change')
element.dispatch_event('blur')
# O con bubbling para Angular Material:
element.evaluate("""el => {
    el.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true, cancelable: true }));
}""")
```

**6. Timeout configurable para assertions:** Usa `ASSERTION_TIMEOUT` del `.env` (default 30000ms):
```python
def _get_assertion_timeout():
    return int(os.getenv('ASSERTION_TIMEOUT', '30000'))
```

**7. Usar `expect` de Playwright para validaciones:** Para verificaciones con auto-retry y mensajes claros:
```python
from playwright.sync_api import expect
import re

# Texto exacto
expect(element).to_have_text("Bienvenido", timeout=timeout)
# Contiene texto (usar re.compile, NO string con .*)
expect(element).to_have_text(re.compile("Bienvenido"), timeout=timeout)
# Título contiene
expect(context.page).to_have_title(re.compile(re.escape("MiApp")), timeout=timeout)
```
Importante: `to_have_title()` y `to_have_text()` tratan strings como coincidencia exacta. Para "contiene", usa siempre `re.compile()`.

**8. Prints informativos:** Usa emojis para feedback visual en consola:
```python
print(f"✓ Opción '{valor}' seleccionada del select '{nombre}'")
print(f"❌ Elemento '{nombre}' no encontrado")
print(f"⚠️ Timeout esperando elemento")
```

**9. Ejemplo completo siguiendo todas las convenciones:**
```python
from behave import step
from playwright.sync_api import expect
import os, re

def _get_element(context, selector, dynamic_value=None):
    page_or_frame = getattr(context, 'current_frame', None) or context.page
    if selector.startswith('$.') and hasattr(context, 'element_locator'):
        return context.element_locator.find(page_or_frame, selector, dynamic_value)
    else:
        return page_or_frame.locator(selector)

def _get_assertion_timeout():
    return int(os.getenv('ASSERTION_TIMEOUT', '30000'))

@step('I verify the field "{field}" contains "{text}" with identifier "{identifier}"')
@step('verifico que el campo "{field}" contiene el texto "{text}" con identificador "{identifier}"')
@step('que verifico que el campo "{field}" contiene el texto "{text}" con identificador "{identifier}"')
def step_verify_field_contains(context, field, text, identifier):
    """Verifica que un campo contiene un texto específico"""
    resolved_text = context.variable_manager.resolve_variables(text)
    element = _get_element(context, identifier)
    timeout = _get_assertion_timeout()
    expect(element).to_have_text(re.compile(re.escape(resolved_text)), timeout=timeout)
    print(f"✓ Campo '{field}' contiene '{resolved_text}'")
```

---

## --- Uso de Playwright según el Framework ---

tema: Interacción con el navegador
contenido: El framework inicializa Playwright automáticamente. La página se reutiliza entre escenarios del mismo feature para mantener la sesión (cookies, localStorage). Solo se crea una nueva página si la anterior está cerrada o no existe. Para interactuar directamente con Playwright en steps personalizados:
```python
# Navegación
context.page.goto("https://ejemplo.com")
context.page.go_back()
context.page.reload()

# Localizar y actuar sobre elementos
context.page.locator("#mi-input").fill("texto")
context.page.locator("button.submit").click()
context.page.locator(".menu-item").hover()

# Esperas
context.page.wait_for_selector(".loading", state="hidden")
context.page.wait_for_load_state("networkidle")
context.page.wait_for_timeout(1000)  # milisegundos

# JavaScript
resultado = context.page.evaluate("document.title")
context.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

# Screenshots
context.page.screenshot(path="mi_screenshot.png", full_page=True)
```
El timeout por defecto se configura con `TIMEOUT` en `.env` (default 30000ms). Se re-aplica automáticamente al inicio de cada escenario incluso si se reutiliza la página.

tema: Navegación robusta con fallback
contenido: El step `voy a la url` implementa un mecanismo de navegación robusto con fallback automático. Primero intenta navegar con `wait_until="networkidle"` (espera que no haya requests por 500ms) + `domcontentloaded`. Si falla (timeout, error de red), automáticamente reintenta con una navegación básica sin `networkidle` y timeout reducido a 15 segundos. Esto evita que pruebas fallen por páginas con long-polling, WebSockets o recursos lentos que nunca alcanzan "networkidle". En la consola verás `⚠️ Navegación con fallback exitosa` cuando se usa el mecanismo de respaldo. Todas las URLs pasan por `resolve_variables()`, así que puedes usar `${ENV.BASE_URL}` o cualquier variable.

tema: Navegadores soportados y configuración
contenido: El framework soporta 4 navegadores configurables con la variable `BROWSER`: `chromium` (default, Chromium de Playwright), `chrome` (Google Chrome instalado en el sistema, con fallback a Chromium), `firefox` y `webkit` (Safari engine). Cada navegador tiene configuraciones específicas. Para Chrome/Chromium: `CHROME_DISABLE_SECURITY`, `CHROME_ENABLE_LOGGING`, `CHROME_DISABLE_EXTENSIONS`, `CHROME_DISABLE_IMAGES`, `CHROME_DISABLE_JAVASCRIPT`. Para Firefox: `FIREFOX_PROFILE_PATH`, `FIREFOX_PRIVATE_MODE`, `FIREFOX_DISABLE_ADDONS`. Para WebKit: `WEBKIT_DISABLE_FEATURES`. Argumentos adicionales se pasan con `BROWSER_ARGS` (separados por coma). Ejemplo: `BROWSER_ARGS=--start-maximized,--disable-notifications`. En modo headless (`HEADLESS=true`) se agregan automáticamente flags de optimización como `--no-sandbox`, `--disable-dev-shm-usage`, `--disable-gpu`.

tema: Presets de configuración del navegador
contenido: El framework incluye presets predefinidos activables con `BROWSER_CONFIG_PRESET` en `.env`:
- `performance` — Optimiza rendimiento: desactiva throttling, background timers, cache agresivo, memory pressure off. Ideal para pruebas de carga.
- `mobile` — Simula dispositivo móvil: user agent móvil, touch events, viewport meta, scale factor 2x.
- `cicd` — Optimizado para CI/CD: no sandbox, sin extensiones, sin plugins, sin sync, sin first run, sin safe browsing updates. Minimiza recursos.
- `security_disabled` — Desactiva seguridad web: web security off, certificate errors ignorados, SSL errors ignorados, insecure content permitido. Solo para testing en entornos controlados.
También puedes cargar configuración desde un archivo JSON con `BROWSER_CONFIG_FILE=mi_config.json` donde el JSON tiene `{"args": ["--flag1", "--flag2"]}`.

tema: Configuración avanzada del navegador en runtime
contenido: Los `browser_advanced_config_steps` permiten modificar la configuración del navegador durante la ejecución, sin reiniciar. Esto es útil para pruebas que necesitan diferentes configuraciones en distintos escenarios:
```gherkin
# Agregar argumentos individuales o en lista
When configuro el argumento del navegador "--disable-notifications"
When configuro los argumentos del navegador "--no-sandbox,--disable-gpu,--disable-dev-shm-usage"

# Chrome flags específicos
When configuro el flag de Chrome "enable-features" con valor "NetworkService"
When activo la feature experimental de Chrome "enable-quic"
When desactivo la feature experimental de Chrome "enable-quic"

# Preferencias del navegador
When configuro la preferencia del navegador "download.default_directory" con valor "/tmp/downloads"

# Comportamiento de descargas
When configuro el comportamiento de descarga como "allow" en la ruta "/tmp/downloads"

# Proxy
When configuro el proxy del navegador a "http://proxy.empresa.com:8080"

# Seguridad (solo para testing)
When desactivo la seguridad del navegador

# Modo rendimiento (desactiva animaciones, imágenes, fuentes)
When activo el modo de rendimiento del navegador

# Límite de memoria
When establezco el límite de memoria del navegador a 2048 MB

# Configuración para mobile testing
When configuro el navegador para testing móvil

# Configuración para CI/CD
When configuro el navegador para entorno CI/CD

# Cargar/guardar configuración desde archivo JSON
When cargo la configuración del navegador desde el archivo "config/browser_ci.json"
When guardo la configuración del navegador en el archivo "config/browser_actual.json"

# Limpiar configuración
When limpio los argumentos del navegador
When limpio las preferencias del navegador

# Ver configuración actual
When muestro la configuración actual del navegador
```
El step `muestro la configuración actual del navegador` imprime en consola todos los argumentos, flags, preferencias, proxy y límites configurados. La configuración se aplica al crear la siguiente instancia del navegador.

tema: Modo Stealth (anti-detección)
contenido: Activando `STEALTH_MODE=true` en `.env`, el framework aplica técnicas anti-detección usando `playwright-stealth`. Esto oculta las propiedades de automatización del navegador (como `navigator.webdriver`), modifica el fingerprint del navegador, y hace que las pruebas parezcan navegación humana real. Requiere instalar: `pip install playwright-stealth`. Es útil para probar sitios que bloquean bots o tienen protección anti-scraping. Se aplica automáticamente al crear cada página nueva. En la consola verás `🥷 Modo stealth activado`.

---

## --- Control del Navegador (Cookies, Storage, JavaScript) ---

tema: Gestión de cookies
contenido: Los `browser_control_steps` permiten manipular cookies del navegador directamente desde features:
```gherkin
# Establecer una cookie
When establezco la cookie "session_id" con valor "abc123"

# Obtener valor de una cookie y guardarlo en variable
When obtengo el valor de la cookie "session_id" y lo guardo en la variable "mi_session"

# Eliminar una cookie específica
When elimino la cookie "session_id"

# Limpiar todas las cookies
When limpio todas las cookies
```
Las cookies se establecen en el contexto del navegador actual. `obtener cookie` busca por nombre en `context.browser.cookies()` y guarda el valor en una variable. Si la cookie no existe, guarda una cadena vacía. Útil para verificar tokens de sesión, preferencias de usuario, o cookies de tracking.

tema: Gestión de localStorage y sessionStorage
contenido: Los steps permiten interactuar con el almacenamiento web del navegador:
```gherkin
# localStorage (persiste entre sesiones)
When establezco en localStorage la clave "theme" con valor "dark"
When obtengo de localStorage la clave "theme" y la guardo en la variable "tema_actual"
When elimino de localStorage la clave "theme"
When limpio todo el localStorage

# sessionStorage (se limpia al cerrar pestaña)
When establezco en sessionStorage la clave "cart_id" con valor "12345"
When obtengo de sessionStorage la clave "cart_id" y la guardo en la variable "carrito"
When limpio todo el sessionStorage
```
Internamente usa `page.evaluate()` con `localStorage.setItem()`, `localStorage.getItem()`, `localStorage.removeItem()`, `localStorage.clear()` y sus equivalentes de `sessionStorage`. Los valores se resuelven con `resolve_variables()`, así que puedes usar `${mi_variable}` como valor.

tema: Ejecución de JavaScript (inline y multilínea)
contenido: El framework permite ejecutar JavaScript arbitrario desde features, tanto en una línea como en bloques multilínea:
```gherkin
# JavaScript inline — una línea, resultado en variable
When ejecuto el JavaScript "document.title" y guardo el resultado en la variable "titulo"
When ejecuto el JavaScript "document.querySelectorAll('tr').length" y guardo el resultado en la variable "filas"

# JavaScript multilínea — usa bloque de texto (triple comillas en .feature)
When ejecuto el siguiente JavaScript y guardo el resultado en la variable "formato_fecha"
  """
  const input = document.getElementById('filtroFechaFin');
  return input.getAttribute('placeholder') || 'dd-mm-aaaa';
  """
```
El JavaScript multilínea usa `context.text` de Behave (el bloque indentado con `"""`). Si el script contiene `return`, se envuelve automáticamente en una IIFE: `(() => { tu_codigo })()`. Los resultados de tipo `dict` o `list` se serializan con `json.dumps()`, otros tipos se convierten a string. Los scripts pasan por `resolve_variables()`, así que puedes usar `${mi_variable}` dentro del JavaScript. Si el resultado es `None`, se guarda cadena vacía.

tema: Bloqueo de recursos y simulación de red
contenido: Los steps permiten controlar qué recursos carga el navegador y simular condiciones de red:
```gherkin
# Bloquear tipos de recursos (acelera pruebas)
When bloqueo los recursos de tipo "image"
When bloqueo los recursos de tipo "stylesheet"
When bloqueo los recursos de tipo "font"
When bloqueo los recursos de tipo "media"

# Desbloquear todos los recursos
When desbloqueo todos los recursos

# Simular condiciones de red
When simulo la condición de red "slow3g"
When simulo la condición de red "fast3g"
When simulo la condición de red "offline"

# Limpiar caché del navegador
When limpio la caché del navegador
```
El bloqueo de recursos usa `page.route()` para interceptar y abortar requests del tipo especificado. Tipos válidos: `image`, `stylesheet`, `font`, `media`, `script`, `xhr`, `fetch`. La simulación de red usa throttling de Playwright. `limpio la caché del navegador` ejecuta `context.browser.clear_cookies()` y limpia localStorage/sessionStorage.

tema: Control de JavaScript y User Agent
contenido: Steps para habilitar/deshabilitar JavaScript y cambiar el user agent en runtime:
```gherkin
# Deshabilitar JavaScript (para probar accesibilidad sin JS)
When deshabilito JavaScript en el navegador

# Re-habilitar JavaScript
When habilito JavaScript en el navegador

# Cambiar user agent
When establezco el user agent del navegador a "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)"

# Obtener user agent actual
When obtengo el user agent del navegador y lo guardo en la variable "ua"
```
Deshabilitar JavaScript es útil para verificar que la página funciona sin JS (progressive enhancement). El cambio de user agent se aplica a todas las requests subsiguientes de la página actual.

tema: Deshabilitar y re-habilitar el navegador mid-test
contenido: Los steps permiten deshabilitar el navegador durante un escenario para ejecutar pasos que no requieren UI (como llamadas API o verificaciones de base de datos), y luego re-habilitarlo:
```gherkin
# Deshabilitar navegador (cierra la página actual)
When deshabilito el navegador para este test

# ... pasos sin navegador (API, DB, etc.) ...

# Re-habilitar navegador (crea nueva página)
When habilito el navegador nuevamente
```
`deshabilito el navegador` cierra la página actual y marca `context.browser_disabled = True`. `habilito el navegador` crea una nueva página con la configuración original (timeout, viewport, stealth). Esto es diferente del tag `@no_browser` que desactiva el navegador para todo el escenario.

---

## --- Screenshots y Videos ---

tema: Sistema de screenshots
contenido: El framework gestiona screenshots automáticamente. Configuración en `.env`: `SCREENSHOTS_DIR` (default: `screenshots`), `SCREENSHOT_FULL_PAGE` (true/false, default true), `AUTO_SCREENSHOT_ON_FAILURE` (true/false, default true). Cuando un escenario falla, se toma automáticamente un screenshot con nombre `FAILED_nombre_escenario_timestamp.png`. También puedes tomar screenshots manualmente desde steps:
```gherkin
When tomo un screenshot con nombre "estado_actual"
```
El plugin de screenshots (`ScreenshotPlugin`) se integra con el reporte HTML, adjuntando screenshots a cada step. La limpieza automática se configura con `CLEANUP_OLD_FILES=true`, `CLEANUP_MODE` (all/old) y `CLEANUP_MAX_AGE_HOURS` (default 24). Los screenshots se toman en formato PNG de alta calidad.

tema: Grabación de video
contenido: Activa la grabación con `RECORD_VIDEO=true` en `.env`. Variables de configuración: `VIDEO_DIR` (default: `videos`), `VIDEO_SIZE` (default: `1280x720`), `VIDEO_MODE` controla cuándo se guardan los videos:
- `on` — Guarda video de todos los escenarios (PASSED y FAILED)
- `off` — No graba video
- `retain-on-failure` (default) — Solo guarda video de escenarios que fallan
Los videos se graban en formato WebM. El nombre incluye feature, escenario, estado y timestamp: `FAILED_Login_Verificar_credenciales_20260314_153045.webm`. La limpieza automática de videos antiguos se configura con `CLEANUP_OLD_VIDEOS=true` y `VIDEO_MAX_AGE_HOURS` (default 168 = 7 días). El video se configura a nivel de contexto de navegador, por lo que se graba toda la sesión del escenario.

---

## --- Soft Assertions ---

tema: Sistema de soft assertions
contenido: Las soft assertions permiten que un escenario continúe ejecutando validaciones incluso después de que una falle, acumulando todos los errores para reportarlos al final. Se activan con el step:
```gherkin
Given activo las soft assertions
When verifico que el elemento "titulo" contiene "Dashboard" con identificador "$.PAGE.titulo"
And verifico que el elemento "subtitulo" contiene "Bienvenido" con identificador "$.PAGE.subtitulo"
And verifico que el elemento "contador" contiene "5" con identificador "$.PAGE.contador"
Then verifico todas las soft assertions
```
Si la primera validación falla, las siguientes se siguen ejecutando. Al final, `verifico todas las soft assertions` lanza un `AssertionError` con todos los errores acumulados. En la consola verás `⚠️ SOFT ASSERTION FAILED: [Step 1] verifico que...` por cada fallo, seguido de `Continuando con las siguientes validaciones...`. El `SoftAssertionManager` se integra con los hooks de Behave: `before_scenario` inicializa el manager, `after_step` captura errores de assertion, y `after_scenario` ejecuta `assert_all()`. En el reporte HTML, los escenarios con soft assertions fallidas se marcan correctamente como fallidos aunque Behave los muestre como passed. Al final de la ejecución verás un resumen: `⚠️ SOFT ASSERTIONS: N escenario(s) fallaron`.

---

## --- Reportes ---

tema: Reporte HTML nativo
contenido: El framework genera reportes HTML propios sin depender de Allure. Se activa automáticamente con el plugin `HtmlReportPlugin`. El reporte incluye: header con logos personalizables (Haka Lab + logo del cliente), resumen con gráficos de dona (Chart.js) para features/escenarios/steps, lista expandible de features con escenarios y steps detallados, screenshots adjuntos a cada step, información de errores con stack trace, y modal para ver screenshots en tamaño completo. Configuración en `.env`: `HTML_REPORTS_DIR` (default: `html-reports`). El reporte es responsive (se adapta a móviles) y tiene diseño moderno con gradientes y animaciones. Los logos se configuran en la sección de configuración del reporte. El reporte JSON se genera junto al HTML para debugging.

tema: Reporte unificado
contenido: El `UnifiedReportGenerator` combina resultados de múltiples ejecuciones (útil para paralelización o sharding en CI/CD) en un solo reporte HTML. Usa `cucumber_report_merger` para fusionar reportes JSON de Cucumber/Behave. El reporte unificado tiene la misma estructura visual que el reporte individual pero con datos consolidados. Se genera con el CLI: `haka-report` o programáticamente. También incluye gráficos de dona y es completamente interactivo.

tema: Reporte de validaciones IA
contenido: Cuando usas steps de Gemini como Juez, validación semántica o RAG, el framework genera un reporte especializado de IA. Se activa con `GENERATE_AI_REPORT=true` (default). Configuración: `AI_REPORT_PATH` (default: `reports/ai-reports`), `AI_REPORT_ANALYSIS=true` para que Gemini genere un análisis automático del reporte con resumen ejecutivo, patrones identificados, problemas recurrentes y recomendaciones. El `AIReportPlugin` recopila datos de cada evaluación durante la ejecución y genera el reporte al final. Incluye visualizaciones especiales para scores de evaluación, dimensiones evaluadas, razonamiento del juez, errores, fortalezas y sugerencias.

tema: Data Snapshots para pruebas sin UI
contenido: Para pruebas sin navegador (API, semántica, NLP), el `DataSnapshotManager` captura información relevante en lugar de screenshots. Genera archivos JSON y HTML visuales en `reports/data_snapshots/`. Tipos de snapshots: `semantic_validation` (textos comparados, similitud, umbral, modelo, resultado), `gemini_evaluation` (respuesta SUT, contexto, score, detalles), `api_request` (method, URL, headers, body, response, tiempo), `nlp_analysis` (texto, tipo de análisis, resultado). Los HTML generados tienen diseño visual con badges de colores según el tipo y sección de datos raw en JSON. Se integran automáticamente con el reporte HTML principal.

---

## --- API Testing ---

tema: Testing de APIs REST
contenido: El framework incluye steps completos para testing de APIs sin necesidad de navegador (usar tag `@no_browser`). Configuración en `.env`: `API_BASE_URL`, `API_TIMEOUT` (default 30s), `API_KEY`, `BEARER_TOKEN`. Ejemplo de feature:
```gherkin
@no_browser
Scenario: Verificar endpoint de usuarios
  Given configuro la API base en "${ENV.API_BASE_URL}"
  And configuro el header "Authorization" con valor "Bearer ${ENV.BEARER_TOKEN}"
  When realizo una petición GET a "/users"
  Then verifico que el código de respuesta es 200
  And verifico que la respuesta contiene el campo "data"
  And verifico que el campo "data" es una lista con más de 0 elementos
```
Los steps soportan: GET, POST, PUT, PATCH, DELETE con headers, body JSON, query params, form data y file upload. Validaciones disponibles: código de respuesta, campos JSON (existencia, valor, tipo), esquema JSON, tiempo de respuesta, headers de respuesta. Se puede escuchar llamadas API del navegador con `activo la escucha de llamadas API` y luego verificar que se realizaron llamadas específicas. Los datos de API se capturan como data snapshots para el reporte.

tema: Validación avanzada de JSON
contenido: Los `api_json_validation_steps` permiten validaciones profundas de respuestas JSON: verificar tipos de datos (`string`, `number`, `boolean`, `array`, `object`), validar esquemas JSON, comparar valores con operadores (`igual`, `mayor que`, `menor que`, `contiene`), navegar estructuras anidadas con dot notation (`data.users[0].name`), verificar longitud de arrays, y extraer valores a variables para uso posterior. También soporta validación de arrays completos: verificar que todos los elementos cumplen una condición, que al menos uno cumple, o que ninguno cumple.

---

## --- Base de Datos ---

tema: Testing de bases de datos
contenido: El `DatabaseManager` soporta SQLite, MySQL y PostgreSQL. Configuración en `.env`: `DB_TYPE` (sqlite/mysql/postgresql). Para SQLite: `DB_SQLITE_PATH`, `DB_SQLITE_TIMEOUT`. Para MySQL: `DB_MYSQL_HOST`, `DB_MYSQL_PORT`, `DB_MYSQL_DATABASE`, `DB_MYSQL_USERNAME`, `DB_MYSQL_PASSWORD`, `DB_MYSQL_CHARSET`. Para PostgreSQL: `DB_POSTGRES_HOST`, `DB_POSTGRES_PORT`, `DB_POSTGRES_DATABASE`, `DB_POSTGRES_USERNAME`, `DB_POSTGRES_PASSWORD`. Variables comunes: `DB_CONNECTION_TIMEOUT` (default 30), `DB_AUTO_COMMIT` (default true), `DB_DEBUG_QUERIES` (default false). Ejemplo:
```gherkin
@no_browser
Scenario: Verificar datos en base de datos
  Given me conecto a la base de datos
  When ejecuto la consulta "SELECT * FROM users WHERE email = 'test@example.com'"
  Then verifico que la consulta retorna al menos 1 resultado
  And verifico que el campo "name" del resultado 1 es "Test User"
```
El manager soporta queries SELECT (retorna lista de diccionarios), updates (INSERT/UPDATE/DELETE con rowcount), transacciones (commit/rollback), backup de SQLite, y creación de bases de datos de prueba con datos de ejemplo. Las dependencias de MySQL (`mysql-connector-python`) y PostgreSQL (`psycopg2-binary`) son opcionales.

---

## --- OCR (Reconocimiento Óptico de Caracteres) ---

tema: Capacidades de OCR
contenido: El `OCRManager` soporta dos engines: Tesseract y EasyOCR. Configuración: `TESSERACT_PATH` (ruta al ejecutable en Windows). Funcionalidades: extraer texto de imágenes/screenshots, buscar texto específico en imágenes, validar calidad de texto (confidence score), preprocesamiento de imágenes (default, denoise, enhance, morphology). Ejemplo:
```gherkin
When tomo un screenshot con nombre "pantalla_actual"
Then verifico por OCR que la imagen contiene el texto "Bienvenido"
And verifico que la calidad del texto en la imagen es al menos 70%
```
EasyOCR soporta múltiples idiomas (español e inglés por defecto) y retorna bounding boxes de cada texto encontrado. Tesseract usa configuración `--psm 6` por defecto y soporta idiomas `eng+spa`. El preprocesamiento incluye conversión a escala de grises, umbralización Otsu, reducción de ruido, mejora de contraste y operaciones morfológicas. Las dependencias (`pytesseract`, `easyocr`, `opencv-python`, `Pillow`) son opcionales y se instalan con `haka-deps --install ocr`.

---

## --- Inteligencia Artificial y Validación Semántica ---

tema: Gemini como Juez (GenAI Evaluation)
contenido: El framework integra Google Gemini como "juez" para evaluar respuestas de sistemas de IA. Configuración en `.env`: `GEMINI_API_KEY`, `GEMINI_JUDGE_MODEL` (recomendado: `gemini-2.5-flash`), `GEMINI_JUDGE_THRESHOLD` (default 0.80, rango 0.0-1.0), `GEMINI_JUDGE_PROMPT_FILE` (prompt personalizado opcional), `GEMINI_CACHE_THRESHOLD` (default 32000 tokens para Context Caching), `GEMINI_CACHE_TTL_HOURS` (default 1). Modelos disponibles: `gemini-2.5-pro` (mejor calidad), `gemini-2.5-flash` (balance recomendado), `gemini-2.5-flash-lite` (más rápido), `gemini-3-pro-preview` (experimental). No usar modelos 1.5 (deprecados). Ejemplo:
```gherkin
@no_browser
Scenario: Evaluar respuesta del chatbot
  Given cargo el contexto de negocio desde "customer_service_rules.txt"
  When envío la pregunta "¿Cuál es la política de devoluciones?"
  And capturo la respuesta del sistema
  Then el Juez Gemini debe validar la respuesta con umbral 0.85
```
El juez evalúa múltiples dimensiones (precisión, completitud, relevancia, tono) y genera un score global. El reporte incluye razonamiento, errores encontrados, fortalezas y sugerencias de mejora.

tema: Validación semántica con Sentence Transformers
contenido: La validación semántica compara el significado de dos textos usando modelos de embeddings. Configuración: `SEMANTIC_MODEL` (default: `paraphrase-multilingual-MiniLM-L12-v2`, multilingüe ~420MB), `SEMANTIC_THRESHOLD` (default 0.75). Otros modelos: `paraphrase-multilingual-mpnet-base-v2` (más preciso, ~1GB), `all-MiniLM-L6-v2` (solo inglés, rápido, ~80MB). Ejemplo:
```gherkin
Then verifico que el texto "El pedido fue enviado" es semánticamente similar a "Su orden ha sido despachada" con umbral 0.80
```
A diferencia de comparación exacta de strings, la validación semántica entiende sinónimos, paráfrasis y variaciones de idioma. Los steps avanzados permiten: comparar listas de textos, validar que un texto pertenece a una categoría semántica, calcular similitud entre documentos, y análisis NLP (sentimiento, entidades, idioma, resumen). Los resultados se capturan como data snapshots con el modelo usado, score de similitud, umbral y resultado.

tema: RAG con Supabase Vector Database
contenido: El framework soporta búsqueda vectorial en Supabase para testing de sistemas RAG (Retrieval-Augmented Generation). Los steps permiten: vectorizar documentos y almacenarlos en Supabase, realizar búsquedas por similitud semántica, validar que los resultados recuperados son relevantes, y combinar con Gemini para evaluar respuestas generadas a partir de contexto recuperado. Requiere configuración de Supabase (URL, API key) en `.env`.

---

## --- Salesforce ---

tema: Automatización de Salesforce
contenido: El framework incluye steps específicos para Salesforce Lightning y Classic. Funcionalidades: esperar carga de Lightning (`espero a que cargue Salesforce Lightning`), navegar a aplicaciones y objetos, crear/editar/eliminar registros, rellenar campos (input, picklist, lookup con búsqueda), guardar registros, verificar valores de campos, hacer click en pestañas, manejar mensajes toast (success/error/warning/info), cambiar entre Lightning y Classic, abrir registros por ID, y búsqueda global. Los steps manejan automáticamente los selectores específicos de Salesforce (SLDS components, Lightning Web Components) con múltiples fallbacks. Ejemplo:
```gherkin
Scenario: Crear nuevo contacto en Salesforce
  Given espero a que cargue Salesforce Lightning
  When navego al objeto de Salesforce "Contact"
  And creo un nuevo registro de Salesforce para el objeto "Contact"
  And relleno el campo de Salesforce "FirstName" con "Juan"
  And relleno el campo de Salesforce "LastName" con "Pérez"
  And selecciono la opción "Customer" del picklist "Type" de Salesforce
  And guardo el registro de Salesforce
  Then espero el mensaje toast de Salesforce "success"
```

---

## --- Scroll (Desplazamiento) ---

tema: Steps de scroll de página y elementos
contenido: Los `scroll_steps` permiten desplazamiento preciso de la página y de elementos individuales con scroll interno (contenedores con overflow):
```gherkin
# Scroll a un elemento específico (scroll_into_view_if_needed)
When hago scroll al elemento "footer" con identificador "$.PAGE.footer"

# Scroll a posiciones fijas
When hago scroll al inicio de la página
When hago scroll al final de la página

# Scroll por píxeles (vertical)
When hago scroll hacia abajo 500 píxeles
When hago scroll hacia arriba 200 píxeles

# Scroll por píxeles (horizontal)
When hago scroll hacia la derecha 300 píxeles
When hago scroll hacia la izquierda 300 píxeles

# Scroll dentro de un elemento contenedor (div con overflow)
When hago scroll del elemento "lista" hacia abajo 200 píxeles con identificador "$.PAGE.contenedor_scroll"
When hago scroll del elemento "lista" hacia arriba 100 píxeles con identificador "$.PAGE.contenedor_scroll"
```
El scroll a elemento usa `scroll_into_view_if_needed()` de Playwright, que solo hace scroll si el elemento no está visible en el viewport. El scroll por píxeles usa `window.scrollBy()` para la página y `element.scrollBy()` para elementos contenedores. El scroll horizontal es útil para tablas anchas o carruseles.

---

## --- Esperas (Wait Steps) ---

tema: Esperas por estado de elementos
contenido: Los `wait_steps` proveen 30+ condiciones de espera que usan el timeout global (`TIMEOUT` del `.env`). A diferencia de `time.sleep()`, estas esperas son inteligentes: terminan tan pronto como la condición se cumple.
```gherkin
# Esperar visibilidad/ocultamiento
When espero a que el elemento "spinner" sea visible con identificador "$.PAGE.spinner"
When espero a que el elemento "spinner" esté oculto con identificador "$.PAGE.spinner"

# Esperar que esté habilitado (no disabled)
When espero a que el elemento "boton" esté habilitado con identificador "$.FORM.submit"

# Esperar que sea clickeable (visible + habilitado)
When espero a que el elemento "boton" sea clickeable con identificador "$.FORM.submit"

# Esperar texto específico en un elemento
When espero a que el elemento "estado" contenga el texto "Completado" con identificador "$.PAGE.estado"

# Esperar que la URL contenga un texto
When espero a que la URL contenga "/dashboard"

# Esperar título de página
When espero a que el título de la página sea "Dashboard"

# Esperar carga de página
When espero a que la red esté inactiva
When espero a que el DOM esté cargado
```

tema: Esperas por atributos y valores
contenido: Steps para esperar condiciones específicas de atributos HTML y valores de campos:
```gherkin
# Esperar que un elemento tenga un atributo
When espero a que el elemento "input" tenga el atributo "data-loaded" con identificador "$.FORM.campo"

# Esperar valor específico de atributo
When espero a que el elemento "input" tenga el atributo "data-status" con valor "ready" con identificador "$.FORM.campo"

# Esperar que un campo tenga valor (no vacío)
When espero a que el campo "email" tenga valor con identificador "$.FORM.email"

# Esperar valor específico en campo
When espero a que el campo "estado" tenga el valor "aprobado" con identificador "$.FORM.estado"

# Esperar clase CSS
When espero a que el elemento "tab" tenga la clase "active" con identificador "$.PAGE.tab"
When espero a que el elemento "tab" no tenga la clase "loading" con identificador "$.PAGE.tab"
```

tema: Esperas por cantidad de elementos
contenido: Steps para esperar que aparezca un número específico de elementos en la página:
```gherkin
# Esperar mínimo N elementos
When espero a que haya al menos 5 elementos "fila" con identificador "$.TABLE.filas"

# Esperar cantidad exacta
When espero a que haya exactamente 3 elementos "opcion" con identificador "$.SELECT.opciones"

# Esperar que un select tenga opciones cargadas
When espero a que el select "pais" tenga opciones con identificador "$.FORM.select_pais"
When espero a que el select "ciudad" tenga al menos 5 opciones con identificador "$.FORM.select_ciudad"

# Esperar que una tabla tenga filas
When espero a que la tabla "resultados" tenga filas con identificador "$.PAGE.tabla"
When espero a que la tabla "resultados" tenga al menos 10 filas con identificador "$.PAGE.tabla"

# Esperar que una lista tenga items
When espero a que la lista "productos" tenga items con identificador "$.PAGE.lista"

# Esperar que un elemento tenga hijos
When espero a que el elemento "contenedor" tenga hijos con identificador "$.PAGE.contenedor"
```

tema: Esperas avanzadas
contenido: Steps para condiciones de espera más complejas:
```gherkin
# Esperar que un elemento no esté vacío (tenga texto)
When espero a que el elemento "resultado" no esté vacío con identificador "$.PAGE.resultado"

# Esperar que un elemento esté estable (no cambie de posición/tamaño por 500ms)
When espero a que el elemento "panel" esté estable con identificador "$.PAGE.panel"

# Esperar que un spinner/loader desaparezca
When espero a que el spinner desaparezca con identificador "$.PAGE.spinner"

# Esperar que un elemento sea removido del DOM
When espero a que el elemento "notificacion" sea removido del DOM con identificador "$.PAGE.notif"

# Espera fija en segundos o milisegundos
When espero 3 segundos
When espero 500 milisegundos
```
La espera de estabilidad (`esté estable`) verifica que el bounding box del elemento no cambie durante 500ms consecutivos, con un máximo de 10 intentos. Es útil para elementos que se animan o reposicionan después de cargar.

---

## --- Timing (Cronómetros y Esperas Avanzadas) ---

tema: Cronómetros para medir tiempos
contenido: Los `timing_steps` permiten medir tiempos de operaciones y verificar que están dentro de límites aceptables:
```gherkin
# Iniciar cronómetro con nombre
When inicio el cronómetro "carga_dashboard"

# ... acciones a medir ...

# Verificar que el tiempo es menor a N segundos
Then verifico que el cronómetro "carga_dashboard" es menor a 5 segundos

# Mostrar duración en consola (sin verificar)
Then muestro la duración del cronómetro "carga_dashboard"
```
Los cronómetros se almacenan en `context._timers` como diccionario `{nombre: timestamp_inicio}`. `verifico que el cronómetro` calcula la diferencia y lanza `AssertionError` si excede el límite. `muestro la duración` imprime `⏱️ Cronómetro 'carga_dashboard': 2.34 segundos`.

tema: Esperas con condiciones avanzadas
contenido: Steps de timing para pausas controladas y esperas con condiciones:
```gherkin
# Pausa fija
When pauso la ejecución por 2 segundos
When pauso la ejecución por 500 milisegundos

# Pausa aleatoria (útil para simular comportamiento humano)
When espero un tiempo aleatorio entre 1 y 3 segundos

# Esperar a que un elemento sea visible con timeout personalizado
When espero máximo 10 segundos a que el elemento sea visible con identificador "$.PAGE.resultado"

# Cambiar timeout global en runtime
When establezco el timeout global a 60000 milisegundos

# Esperar a que un elemento deje de tener clase "loading"
When espero a que el elemento deje de estar en estado de carga con identificador "$.PAGE.contenedor"

# Espera progresiva (incrementa el intervalo entre intentos)
When realizo una espera progresiva con patrón "1,2,4,8"
```
La espera progresiva acepta un patrón de segundos separados por coma. Ejecuta `time.sleep()` con cada valor en secuencia. Útil para esperar servicios que tardan en responder (backoff exponencial). El step `espero a que el elemento deje de estar en estado de carga` verifica que el elemento no tenga clases como `loading`, `spinner`, `is-loading`, `ng-loading` con polling cada 500ms.

tema: Manejo de iFrames
contenido: El framework permite interactuar con elementos dentro de iframes. Los steps cambian el contexto de búsqueda al frame especificado. Hay múltiples formas de acceder a un iframe:
```gherkin
# Por identificador JSON POM
When cambio al iframe "mi_frame" con identificador "$.PAGE.mi_iframe"

# Por atributo name del iframe
When cambio al iframe con nombre "frame_contenido"

# Por URL parcial del src
When cambio al iframe con src que contiene "formulario.html"

# Por índice (base 0)
When cambio al iframe con índice 2

# Volver al contenido principal
Then cambio al contenido principal
```
Cuando estás dentro de un iframe, `context.current_frame` apunta al frame actual. Todos los steps de interacción (click, fill, etc.) detectan automáticamente si hay un frame activo y buscan elementos dentro de él gracias a la función `_get_element()`. También puedes interactuar directamente dentro del iframe sin cambiar contexto:
```gherkin
# Click dentro del iframe
When hago click en el elemento "boton" dentro del iframe con identificador "$.IFRAME.boton"

# Rellenar campo dentro del iframe
When relleno el campo "nombre" con "Juan" dentro del iframe con identificador "$.IFRAME.campo"

# Verificar texto dentro del iframe
Then debería ver el texto "Bienvenido" dentro del iframe

# Verificar que un elemento existe dentro del iframe
Then debería ver el elemento "titulo" dentro del iframe con identificador "$.IFRAME.titulo"

# Esperar a que el iframe cargue
When espero a que cargue el iframe "contenido" con identificador "$.PAGE.iframe"

# Ejecutar JavaScript dentro del iframe
When ejecuto JavaScript "document.title" dentro del iframe

# Contar iframes en la página
When cuento los iframes y guardo el resultado en la variable "total_iframes"

# Verificar que un iframe existe
Then verifico que el iframe "mapa" existe con identificador "$.PAGE.iframe_mapa"

# Verificar el src de un iframe
Then verifico que el iframe "mapa" tiene src "https://maps.google.com" con identificador "$.PAGE.iframe_mapa"
```

tema: Manejo de modales y diálogos
contenido: Los `modal_steps` proveen control completo sobre modales HTML y diálogos nativos del navegador (alert, confirm, prompt):
```gherkin
# Esperar a que aparezca un modal
When espero a que aparezca el modal "confirmacion" con identificador "$.PAGE.modal"

# Esperar a que desaparezca
When espero a que desaparezca el modal "loading" con identificador "$.PAGE.modal_loading"

# Cerrar modal por botón, tecla Escape, o click fuera
When cierro el modal "confirmacion" con identificador "$.PAGE.boton_cerrar"
When cierro el modal presionando Escape
When cierro el modal haciendo click fuera

# Verificar visibilidad
Then verifico que el modal "confirmacion" es visible con identificador "$.PAGE.modal"
Then verifico que el modal "confirmacion" no es visible con identificador "$.PAGE.modal"

# Verificar título del modal
Then verifico que el título del modal "confirmacion" es "¿Está seguro?" con identificador "$.PAGE.modal"

# Interactuar dentro del modal
When hago click en el botón "Aceptar" del modal "confirmacion" con identificador del modal "$.PAGE.modal"
When relleno el campo "motivo" con "Cambio de plan" en el modal "confirmacion" con identificador del modal "$.PAGE.modal" e identificador del campo "$.PAGE.campo_motivo"

# Verificar contenido del modal
Then verifico que el modal "confirmacion" contiene el texto "¿Desea continuar?" con identificador "$.PAGE.modal"

# Tomar screenshot del modal
When tomo screenshot del modal "error" con identificador "$.PAGE.modal_error"

# Verificar que no hay modales visibles
Then verifico que no hay modales visibles en la página
```

tema: Diálogos nativos del navegador (alert, confirm, prompt)
contenido: Los diálogos nativos se manejan con listeners de Playwright. El framework incluye steps avanzados para capturar y verificar mensajes de diálogos:
```gherkin
# Aceptar/cancelar diálogos
When acepto el diálogo de alerta
When acepto el diálogo de confirmación
When cancelo el diálogo de confirmación
When escribo "mi texto" en el diálogo prompt y acepto

# Capturar mensaje del diálogo (para verificar después)
When prevengo que el diálogo se cierre automáticamente
# ... acción que dispara el diálogo ...
Then obtengo el mensaje del diálogo capturado
Then verifico que el mensaje del diálogo capturado contiene "¿Está seguro?"
Then verifico que el mensaje del diálogo capturado es exactamente "Error: campo requerido"
When guardo el mensaje del diálogo capturado en la variable "mensaje_dialogo"

# Deshabilitar manejo automático de diálogos
When deshabilito el manejo automático de diálogos
```
`prevengo que el diálogo se cierre automáticamente` registra un listener que captura el mensaje del diálogo y lo acepta, guardando el mensaje en `context._captured_dialog_message`. Esto permite verificar el contenido del diálogo después de que se cierra. Sin este step, los diálogos se manejan automáticamente (accept por defecto).

tema: Manejo de ventanas y pestañas
contenido: El framework soporta múltiples pestañas y ventanas:
```gherkin
When abro una nueva pestaña
And cambio a la pestaña 1
And cierro la pestaña actual
When maximizo la ventana
And establezco el tamaño de ventana a 1024x768
```
Las pestañas se indexan desde 0. Al inicio de cada escenario, si hay múltiples pestañas abiertas, el framework cambia automáticamente a la primera. La página se reutiliza entre escenarios del mismo feature.

---

## --- Tags Especiales ---

tema: Tags disponibles en el framework
contenido: Los tags de Behave controlan el comportamiento del framework:
- `@no_browser` — Desactiva la inicialización del navegador. Esencial para pruebas de API, base de datos, semántica o cualquier test que no necesite UI. `context.browser_disabled = True`.
- `@mobile` — Configura viewport móvil automáticamente (375x667).
- `@soft_assertions` — Activa soft assertions para el escenario (alternativa al step manual).
- `@retry` — Marca el escenario para reintento automático si falla (requiere `RETRY_FAILED_SCENARIOS=true`).
- `@JIRA-123` — Vincula el escenario a una issue de Jira. El reporte se adjunta automáticamente a la issue.
- `@wip` — Work in progress, Behave lo salta por defecto.
- `@skip` — Salta el escenario.
Los tags de Jira/Xray se procesan automáticamente: si el tag tiene formato `PROYECTO-NUMERO`, se trata como clave de issue.

---

## --- Reintentos de Escenarios ---

tema: Sistema de reintentos automáticos
contenido: El framework incluye un `RetryRunner` que reintenta automáticamente escenarios fallidos. Configuración en `.env`: `RETRY_FAILED_SCENARIOS=true` (default false), `MAX_SCENARIO_RETRIES=2` (default 1). Funcionamiento: después de la primera ejecución completa, el runner identifica escenarios fallidos y los reintenta hasta el máximo configurado. En cada reintento: se resetea el estado del escenario y sus steps, se cierra la página actual y se crea una nueva, se limpian las variables de escenario, y se re-ejecuta el escenario completo. En la consola verás `🔄 Reintentando escenario: nombre - Intento 1 de 2`. Si el escenario pasa en un reintento: `✅ Escenario pasó después de 1 reintento(s)`. Si falla todos los reintentos: `❌ Escenario falló después de 2 reintentos`. El contador de reintentos se almacena en `context.scenario_retry_count` con clave `feature_name::scenario_name`.

---

## --- Integración Jira y Xray ---

tema: Integración con Jira
contenido: El framework se integra con Jira Cloud para adjuntar reportes y crear issues automáticamente. Configuración en `.env`: `JIRA_ENABLED=true`, `JIRA_URL` (URL de tu instancia Jira), `JIRA_EMAIL`, `JIRA_TOKEN` (API token), `JIRA_PROJECT` (clave del proyecto), `JIRA_COMMENT_MESSAGE` (mensaje personalizado para comentarios). Funcionalidades: verificar conexión (`test_connection`), obtener/buscar issues, agregar comentarios, adjuntar archivos (reportes HTML, screenshots), crear issues nuevas (Bug, Task, Story con prioridad y labels), y procesar tags de features para adjuntar reportes automáticamente. La autenticación usa Basic Auth con email + API token codificados en Base64. Ejemplo de uso con tags:
```gherkin
@PROJ-123
Feature: Login de usuario
  Scenario: Login exitoso
    ...
```
Al finalizar el feature, el reporte HTML se adjunta automáticamente a la issue PROJ-123 con un comentario timestamped.

tema: Integración con Xray
contenido: Xray (by Blend) se integra para gestionar Test Executions. Configuración adicional: `XRAY_ENABLED=true`, `XRAY_AUTHORIZATION_TOKEN` (Bearer token de Xray Cloud), `XRAY_BASE_URL` (default: `https://xray.cloud.getxray.app`), `XRAY_TEST_PLAN` (clave del Test Plan). Funcionamiento: los escenarios con tags que corresponden a issues de tipo "Test" en Jira se agrupan en un Test Execution. El framework crea una sola llamada a la API de Xray con todos los tests, incluyendo estado (passed/failed), timestamps, y comentarios. Si hay una Historia de Usuario en los tags del feature, el Test Execution se vincula automáticamente a ella, y cada Test individual también se vincula. Los estados se mapean: passed→passed, failed→failed, skipped/undefined/pending→skipped.

---

## --- Sistema de Plugins ---

tema: Arquitectura de plugins
contenido: El framework usa un sistema de plugins basado en hooks de Behave. Cada plugin extiende `BasePlugin` e implementa los métodos que necesita: `before_all`, `after_all`, `before_feature`, `after_feature`, `before_scenario`, `after_scenario`, `before_step`, `after_step`. Cada plugin tiene un método `_is_enabled()` que determina si se activa (generalmente leyendo una variable de entorno). El `PluginManager` gestiona todos los plugins y ejecuta sus hooks en orden. Plugins incluidos:
- `HtmlReportPlugin` — Genera reporte HTML con screenshots
- `AIReportPlugin` — Genera reporte de validaciones IA
- `SoftAssertionsPlugin` — Gestiona soft assertions
- `ScreenshotPlugin` — Captura screenshots automáticos
- `JiraXrayPlugin` — Integración con Jira y Xray
- `AzureDevOpsPlugin` — Integración con Azure DevOps
Los plugins se registran automáticamente en `behave_plugin.py`. El orden de ejecución es importante: en `before_scenario` primero se inicializa el navegador, luego soft assertions, luego plugins. En `after_scenario` primero soft assertions, luego plugins (HTML), luego otros hooks.

tema: Crear un plugin personalizado
contenido: Para crear un plugin personalizado, extiende `BasePlugin`:
```python
from hakalab_framework.plugins.base_plugin import BasePlugin
import os

class MiPlugin(BasePlugin):
    def _is_enabled(self) -> bool:
        return os.getenv('MI_PLUGIN_ENABLED', 'false').lower() == 'true'
    
    def before_scenario(self, context, scenario) -> None:
        print(f"Iniciando: {scenario.name}")
    
    def after_scenario(self, context, scenario) -> None:
        if scenario.status.name == 'failed':
            # Lógica personalizada para escenarios fallidos
            pass
```
Luego regístralo en `plugin_manager.py` agregándolo a la lista de plugins en `__init__`.

---

## --- Azure DevOps ---

tema: Integración con Azure DevOps
contenido: El `AzureDevOpsPlugin` permite integrar los resultados de pruebas con Azure DevOps. Se configura con variables de entorno específicas de Azure DevOps (organización, proyecto, token PAT). Funcionalidades: publicar resultados de pruebas como Test Runs, adjuntar reportes y screenshots, vincular resultados a Work Items, y actualizar estados de Test Cases. Se activa automáticamente cuando las variables de Azure DevOps están configuradas en `.env`. Consulta el archivo de ejemplo `.env.azure_devops_example` para ver todas las variables disponibles.

---

## --- Accesibilidad ---

tema: Testing de accesibilidad
contenido: Los `accessibility_steps` permiten verificar aspectos de accesibilidad web:
```gherkin
Then verifico que todos los elementos img tienen atributo alt
And verifico que los encabezados siguen un orden jerárquico
And verifico que los formularios tienen labels asociados
And verifico el contraste de colores del elemento "titulo" con identificador "$.PAGE.titulo"
And verifico que la página es navegable con teclado
```
Las verificaciones incluyen: atributos alt en imágenes, jerarquía de encabezados (h1→h2→h3), labels en formularios, contraste de colores (WCAG), navegación por teclado, roles ARIA, y landmarks de la página. Estas verificaciones son programáticas y complementan (pero no reemplazan) las pruebas manuales con tecnologías asistivas.

---

## --- Testing Responsive ---

tema: Pruebas responsive
contenido: Los `responsive_steps` permiten probar la aplicación en diferentes tamaños de pantalla y verificar comportamientos responsive:
```gherkin
# Presets de viewport
When establezco el viewport a tamaño "mobile" (375x667)
When establezco el viewport a tamaño "tablet" (768x1024)
When establezco el viewport a tamaño "desktop" (1920x1080)
When establezco el tamaño de ventana a 1024x768

# Verificar visibilidad en diferentes viewports
Then verifico que el elemento "menu_hamburguesa" es visible en mobile con identificador "$.PAGE.menu"
Then verifico que el elemento "sidebar" está oculto en mobile con identificador "$.PAGE.sidebar"

# Verificar que un elemento se adapta al viewport
Then verifico que el elemento "contenedor" se adapta al viewport con identificador "$.PAGE.contenedor"

# Verificar que la navegación colapsa en mobile
Then verifico que la navegación colapsa en mobile

# Verificar legibilidad del texto en mobile
Then verifico que el texto es legible en mobile

# Verificar que los botones son touch-friendly (mínimo 44x44px)
Then verifico que los botones son touch-friendly

# Verificar que no hay scroll horizontal
Then verifico que no hay scroll horizontal en la página

# Verificar que las imágenes escalan correctamente
Then verifico que las imágenes escalan en mobile

# Verificar que elementos se apilan en mobile (flex-direction: column)
Then verifico que el elemento "grid" se apila en mobile con identificador "$.PAGE.grid"

# Verificar comportamiento en un breakpoint específico
Then verifico el comportamiento en el breakpoint 768 píxeles

# Verificar que el tamaño de fuente es responsive
Then verifico que el tamaño de fuente del elemento "titulo" es responsive con identificador "$.PAGE.titulo"
```
La verificación de adaptación al viewport compara el ancho del elemento con el ancho del viewport en 3 tamaños (mobile 375, tablet 768, desktop 1920). Los botones touch-friendly verifican que todos los `button` y `[role="button"]` tengan al menos 44x44px (estándar WCAG). La verificación de breakpoint cambia el viewport al ancho especificado y verifica que no hay overflow horizontal ni elementos cortados.

---

## --- Paralelización ---

tema: Ejecución paralela y sharding
contenido: El framework soporta ejecución paralela con el `ParallelizationManager`. Configuración: `PARALLEL_WORKERS` (default 4), `MAX_BROWSER_INSTANCES` (default 10), `BROWSER_POOL_SIZE` (default 5), `WORKER_TIMEOUT` (default 300s). Para CI/CD con sharding, usa variables de entorno `SHARD_INDEX` y `TOTAL_SHARDS`. El CLI soporta: `haka-run --parallel --workers 8`. El `--shard-info` muestra información del shard actual (total escenarios, ejecuciones, tags únicos). En modo paralelo, cada worker tiene su propia instancia de navegador. Los reportes de cada worker se fusionan con `cucumber_report_merger` en un reporte unificado. En modo headless se agregan automáticamente flags de optimización para paralelismo.

---

## --- CLI (Línea de Comandos) ---

tema: Comandos disponibles del CLI
contenido: El framework provee varios comandos CLI:
- `haka-init <nombre> [--template basic|advanced] [--language es|en|mixed]` — Crea un nuevo proyecto con estructura completa.
- `haka-run [opciones]` — Ejecuta pruebas. Opciones: `--feature <archivo>`, `--tags <tag>`, `--parallel`, `--workers N`, `--browser <navegador>`, `--headless`, `--docker`, `--list-features`, `--shard-info`.
- `haka-report [opciones]` — Genera reportes. Opciones: `--serve` (servidor local), `--port N`, `--simple` (HTML simple), `--clean`, `--no-browser`.
- `haka-steps [opciones]` — Explora steps disponibles. Opciones: `--search <texto>`, `--category <cat>`, `--language <idioma>`, `--suggest <texto>`, `--generate-docs`.
- `haka-validate` — Valida la configuración del proyecto (directorios, dependencias, archivos).
- `haka-deps [opciones]` — Gestiona dependencias opcionales. Opciones: `--status`, `--check <grupo>`, `--install <grupo|all>`. Grupos: `ocr`, `advanced_data`, `performance`.

---

## --- Validaciones Avanzadas de Elementos ---

tema: Validaciones de CSS y estilos
contenido: Los `validation_steps` permiten verificar propiedades visuales de elementos:
```gherkin
# Verificar clase CSS
Then verifico que el elemento "boton" tiene la clase CSS "btn-primary" con identificador "$.PAGE.boton"
Then verifico que el elemento "boton" no tiene la clase CSS "disabled" con identificador "$.PAGE.boton"

# Verificar propiedad CSS específica
Then verifico que la propiedad CSS "display" del elemento "menu" es "flex" con identificador "$.PAGE.menu"
Then verifico que la propiedad CSS "opacity" del elemento "modal" contiene "1" con identificador "$.PAGE.modal"
Then verifico que la propiedad CSS "display" del elemento "oculto" no existe en el elemento "visible" con identificador "$.PAGE.visible"

# Verificar que una propiedad CSS existe/no existe
Then verifico que el elemento "titulo" tiene la propiedad CSS "font-weight" con identificador "$.PAGE.titulo"
Then verifico que el elemento "texto" no tiene la propiedad CSS "text-decoration" con identificador "$.PAGE.texto"

# Verificar propiedad CSS con patrón regex
Then verifico que la propiedad CSS "background" del elemento "header" coincide con el patrón "rgb\\(.*\\)" con identificador "$.PAGE.header"

# Guardar propiedad CSS en variable
When guardo la propiedad CSS "font-size" del elemento "titulo" en la variable "tamaño_fuente" con identificador "$.PAGE.titulo"

# Colores específicos
Then verifico que el color de fondo del elemento "header" es "rgb(0, 123, 255)" con identificador "$.PAGE.header"
Then verifico que el color de texto del elemento "error" es "rgb(255, 0, 0)" con identificador "$.PAGE.error"

# Tamaño de fuente
Then verifico que el tamaño de fuente del elemento "titulo" es "24px" con identificador "$.PAGE.titulo"
```

tema: Validaciones de dimensiones y posición
contenido: Steps para verificar tamaño y ubicación de elementos en la página:
```gherkin
# Verificar ancho y alto
Then verifico que el ancho del elemento "imagen" es 300 con identificador "$.PAGE.imagen"
Then verifico que el alto del elemento "banner" es 200 con identificador "$.PAGE.banner"

# Verificar posición (x, y)
Then verifico que la posición del elemento "logo" es x=10 y=10 con identificador "$.PAGE.logo"

# Verificar que está en el viewport
Then verifico que el elemento "boton" está en el viewport con identificador "$.PAGE.boton"

# Verificar que tiene el foco
Then verifico que el elemento "campo" tiene el foco con identificador "$.FORM.campo"
```

tema: Validaciones de formato de texto
contenido: Steps para verificar que el texto de un elemento cumple con formatos específicos:
```gherkin
# Verificar formato de email
Then verifico que el texto del elemento "email" tiene formato de email con identificador "$.PAGE.email"

# Verificar formato de teléfono
Then verifico que el texto del elemento "telefono" tiene formato de teléfono con identificador "$.PAGE.telefono"

# Verificar formato de fecha
Then verifico que el texto del elemento "fecha" tiene formato de fecha "DD/MM/YYYY" con identificador "$.PAGE.fecha"

# Verificar que es numérico
Then verifico que el texto del elemento "precio" es numérico con identificador "$.PAGE.precio"

# Verificar longitud exacta
Then verifico que el texto del elemento "codigo" tiene longitud 10 con identificador "$.PAGE.codigo"

# Verificar rango de longitud
Then verifico que el texto del elemento "descripcion" tiene longitud entre 10 y 500 con identificador "$.PAGE.descripcion"

# Verificar patrón regex
Then verifico que el texto del elemento "codigo" coincide con el patrón "[A-Z]{3}-\\d{4}" con identificador "$.PAGE.codigo"

# Verificar valor de atributo
Then verifico que el atributo "data-status" del elemento "pedido" es "completado" con identificador "$.PAGE.pedido"

# Verificar patrón en atributo
Then verifico que el atributo "class" del elemento "item" coincide con el patrón "item-\\d+" con identificador "$.PAGE.item"
```

---

## --- Manipulación Avanzada de Elementos Web ---

tema: Manipulación del DOM
contenido: Los `web_elements_steps` permiten manipular elementos del DOM directamente, útil para preparar el estado de la página antes de verificaciones:
```gherkin
# Establecer atributo HTML
When establezco el atributo "data-test" con valor "true" en el elemento "contenedor" con identificador "$.PAGE.contenedor"

# Eliminar atributo HTML
When elimino el atributo "readonly" del elemento "campo" con identificador "$.FORM.campo"

# Establecer estilo CSS inline
When establezco el estilo CSS "display" con valor "block" en el elemento "oculto" con identificador "$.PAGE.oculto"

# Disparar evento personalizado
When disparo el evento "change" en el elemento "select" con identificador "$.FORM.select"

# Enfocar/desenfocar elemento
When enfoco el elemento "campo" con identificador "$.FORM.campo"
When desenfocar el elemento "campo" con identificador "$.FORM.campo"

# Seleccionar texto dentro de un elemento
When selecciono el texto del elemento "parrafo" con identificador "$.PAGE.parrafo"

# Limpiar selección de texto
When limpio la selección en la página

# Simular mouse enter/leave (hover in/out)
When simulo mouse enter en el elemento "menu" con identificador "$.PAGE.menu"
When simulo mouse leave en el elemento "menu" con identificador "$.PAGE.menu"

# Obtener dimensiones de un elemento
When obtengo las dimensiones del elemento y las guardo en variables ancho="ancho_elem" alto="alto_elem" para elemento "imagen" con identificador "$.PAGE.imagen"

# Obtener posición de un elemento
When obtengo la posición del elemento y la guardo en variables x="pos_x" y="pos_y" para elemento "boton" con identificador "$.PAGE.boton"

# Clonar elemento y añadirlo a otro
When clono el elemento "template" y lo añado a "contenedor" con identificadores "$.PAGE.template" y "$.PAGE.contenedor"

# Eliminar elemento del DOM
When elimino el elemento "banner" con identificador "$.PAGE.banner_promo"
```
Estos steps son útiles para: preparar el estado de la página antes de pruebas, simular interacciones complejas que no tienen step dedicado, manipular elementos que no son accesibles por medios normales, y testing de componentes dinámicos.

tema: Interacciones básicas con formularios
contenido: Los `interaction_steps` proveen las interacciones fundamentales con campos de formulario:
```gherkin
# Rellenar campo de texto
When relleno el campo "nombre" con "Juan Pérez" con identificador "$.FORM.nombre"

# Rellenar campo de fecha (acepta DD-MM-YYYY y YYYY-MM-DD)
When relleno el campo de fecha "nacimiento" con "15-03-1990" con identificador "$.FORM.fecha"

# Limpiar campo
When limpio el campo "busqueda" con identificador "$.FORM.busqueda"

# Escribir texto carácter por carácter (simula tipeo humano)
When escribo "texto lento" en el campo "busqueda" con identificador "$.FORM.busqueda"

# Seleccionar opción de dropdown nativo
When selecciono la opción "Chile" del dropdown "pais" con identificador "$.FORM.pais"

# Marcar/desmarcar checkbox
When marco el checkbox "acepto_terminos" con identificador "$.FORM.checkbox"
When desmarco el checkbox "newsletter" con identificador "$.FORM.newsletter"

# Subir archivo
When subo el archivo "documento.pdf" al campo "adjunto" con identificador "$.FORM.file_input"

# Abrir calendario nativo y rellenar fecha
When abro el calendario y relleno el campo de fecha "inicio" con "2026-03-15" con identificador "$.FORM.fecha_inicio"

# Presionar tecla
When presiono la tecla "Enter"
```
Los campos de fecha disparan automáticamente eventos de Angular/React/Vue (`input`, `change`, `blur`, `keydown`, `keyup`) para compatibilidad con frameworks SPA. El formato DD-MM-YYYY se convierte automáticamente a YYYY-MM-DD para el input nativo.

tema: Manipulación de atributos HTML
contenido: Los steps permiten modificar atributos HTML de elementos, útil para habilitar campos readonly o disabled:
```gherkin
# Remover atributo (ej: quitar readonly para poder escribir)
When elimino el atributo "readonly" del elemento "campo_fecha" con identificador "$.FORM.fecha"
When elimino el atributo "disabled" del elemento "boton" con identificador "$.FORM.submit"

# Establecer atributo
When establezco el atributo "placeholder" con valor "Ingrese su nombre" en el elemento "nombre" con identificador "$.FORM.nombre"

# Verificar existencia de atributo
Then verifico que el elemento "campo" con identificador "$.FORM.email" tiene el atributo "required"
Then verifico que el elemento "campo" con identificador "$.FORM.email" no tiene el atributo "disabled"

# Obtener valor de atributo y guardarlo
When obtengo el atributo "data-id" del elemento "fila" con identificador "$.TABLE.fila" y lo guardo en la variable "id_registro"
```

tema: Operaciones avanzadas de formularios
contenido: Los `form_handling_steps` proveen operaciones a nivel de formulario completo:
```gherkin
# Enviar formulario (submit)
When envío el formulario "registro" con identificador "$.PAGE.form_registro"

# Resetear formulario (limpia todos los campos)
When reseteo el formulario "registro" con identificador "$.PAGE.form_registro"

# Rellenar formulario completo desde variable JSON
Given guardo el valor '{"nombre": "Juan", "email": "juan@test.com", "telefono": "123456"}' en la variable "datos"
When relleno el formulario "registro" con los datos de la variable "datos" con identificador "$.PAGE.form_registro"

# Obtener todos los datos del formulario como JSON
When obtengo los datos del formulario "registro" y los guardo en la variable "datos_form" con identificador "$.PAGE.form_registro"

# Validar formulario (verifica campos required)
Then valido el formulario "registro" con identificador "$.PAGE.form_registro"

# Verificar campos requeridos
Then verifico los campos requeridos del formulario "registro" con identificador "$.PAGE.form_registro"

# Hacer campo readonly/enabled/disabled
When hago el campo "email" readonly en el formulario "registro" con identificador del formulario "$.PAGE.form" e identificador del campo "$.FORM.email"
When habilito el campo "email" en el formulario "registro" con identificador del formulario "$.PAGE.form" e identificador del campo "$.FORM.email"
When deshabilito el campo "email" en el formulario "registro" con identificador del formulario "$.PAGE.form" e identificador del campo "$.FORM.email"

# Auto-rellenar formulario con datos de prueba
When auto-relleno el formulario "registro" con identificador "$.PAGE.form_registro"

# Limpiar todos los campos del formulario
When limpio todos los campos del formulario "registro" con identificador "$.PAGE.form_registro"
```
El auto-relleno detecta el tipo de cada campo (text, email, number, date, tel, select, checkbox, radio, textarea) y genera datos apropiados automáticamente. `relleno el formulario con los datos de la variable` parsea el JSON y busca campos por name, id o label que coincidan con las claves del JSON.

---

## --- Drag & Drop, Tablas y CSV ---

tema: Drag and Drop
contenido: Los `drag_drop_steps` permiten arrastrar y soltar elementos:
```gherkin
When arrastro el elemento "item" con identificador "$.PAGE.draggable" al elemento "zona" con identificador "$.PAGE.dropzone"
```
Usa la API nativa de Playwright para drag and drop, compatible con HTML5 drag events.

tema: Interacción con tablas
contenido: Los `table_steps` permiten interactuar con tablas HTML: obtener número de filas/columnas, leer contenido de celdas específicas, verificar valores en celdas, buscar texto en toda la tabla, ordenar por columna, y extraer datos de filas/columnas completas a variables.

tema: Manejo de archivos CSV
contenido: Los `csv_file_steps` permiten leer, validar y manipular archivos CSV: verificar existencia, contar filas/columnas, leer valores específicos, buscar datos, comparar con valores esperados, y usar datos CSV como input para pruebas data-driven.

---

## --- Email Testing ---

tema: Testing de emails
contenido: Los `email_steps` permiten verificar emails enviados por la aplicación. Configuración en `.env`: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` (para envío), `IMAP_HOST`, `IMAP_PORT`, `IMAP_USER`, `IMAP_PASSWORD` (para lectura). Funcionalidades: enviar emails de prueba, verificar recepción de emails, buscar emails por asunto/remitente/destinatario, verificar contenido del email (texto, HTML), verificar adjuntos, y limpiar bandeja de entrada.

---

## --- PDF Testing ---

tema: Validación de PDFs
contenido: Los `pdf_steps` permiten verificar contenido de archivos PDF descargados:
```gherkin
Then verifico que el archivo PDF "reporte.pdf" contiene el texto "Resumen Ejecutivo"
And verifico que el PDF tiene al menos 5 páginas
And extraigo el texto de la página 1 del PDF y lo guardo en la variable "contenido"
```

---

## --- Teclado y Mouse Avanzado ---

tema: Interacciones avanzadas de teclado y mouse
contenido: Los `keyboard_mouse_steps` proveen control fino sobre teclado y mouse:
```gherkin
When presiono la tecla "Enter"
And presiono la combinación "Control+A"
And hago click en las coordenadas 500, 300
And muevo el mouse a las coordenadas 200, 150
And hago scroll hacia abajo 500 pixeles
```
Soporta teclas especiales (Enter, Escape, Tab, Arrow keys, Page Up/Down), combinaciones (Ctrl+C, Alt+F4, Shift+Click), y acciones de mouse (click, doble click, click derecho, hover, drag).

---

## --- Performance Testing ---

tema: Medición de rendimiento
contenido: Los `performance_steps` permiten medir tiempos de carga y rendimiento de componentes específicos de la página:
```gherkin
# Verificar tiempo de carga de página completa
Then verifico que la página carga en menos de 3 segundos

# Medir y guardar tiempo de carga
When mido el tiempo de carga de la página y lo guardo en la variable "tiempo_carga"

# Verificar tiempo de aparición de un elemento
Then verifico que el elemento "contenido" aparece en menos de 2 segundos con identificador "$.PAGE.contenido"

# Verificar tiempo de respuesta al click
Then verifico que el click en el elemento "boton" responde en menos de 1 segundo con identificador "$.PAGE.boton"

# Verificar tiempo de requests de red
Then verifico que las peticiones de red se completan en menos de 5 segundos

# Verificar tiempo de envío de formulario
Then verifico que el envío del formulario se completa en menos de 3 segundos

# Verificar tiempo de resultados de búsqueda
Then verifico que los resultados de búsqueda aparecen en menos de 2 segundos

# Verificar tiempo de carga de imagen
Then verifico que la imagen "banner" carga en menos de 2 segundos con identificador "$.PAGE.banner"

# Verificar tiempo de animación
Then verifico que la animación se completa en menos de 1 segundo para el elemento "panel" con identificador "$.PAGE.panel"

# Verificar tiempo de apertura de modal
Then verifico que el modal "detalle" se abre en menos de 0.5 segundos con identificador "$.PAGE.modal"

# Verificar tiempo de expansión de dropdown
Then verifico que el dropdown "opciones" se expande en menos de 0.5 segundos con identificador "$.PAGE.dropdown"

# Verificar rendimiento de scroll (FPS)
Then verifico el rendimiento del scroll de la página

# Verificar uso de memoria después de N acciones
Then verifico el uso de memoria después de 100 acciones
```
Los steps de performance usan `performance.timing` del navegador para medir tiempos de carga, y cronómetros internos para medir tiempos de interacción. La verificación de scroll mide los FPS durante un scroll automático. La verificación de memoria compara `performance.memory.usedJSHeapSize` antes y después de las acciones para detectar memory leaks.

tema: Cronómetros manuales (timing_steps)
contenido: Los `timing_steps` proveen cronómetros manuales para medir cualquier operación:
```gherkin
When inicio el cronómetro "flujo_compra"
# ... todos los pasos del flujo ...
Then verifico que el cronómetro "flujo_compra" es menor a 30 segundos
Then muestro la duración del cronómetro "flujo_compra"
```
Los cronómetros son independientes de los steps de performance. Puedes tener múltiples cronómetros activos simultáneamente. Se almacenan en `context._timers` y persisten durante todo el escenario.

---

## --- Variables de Entorno en Runtime ---

tema: Gestión de variables de entorno desde features
contenido: Los `environment_steps` permiten manipular variables de entorno durante la ejecución, sin modificar el archivo `.env`:
```gherkin
# Cargar un archivo .env adicional
When cargo el archivo de entorno "config/staging.env"

# Establecer variable de entorno en runtime
When establezco la variable de entorno "API_BASE_URL" con valor "https://staging.api.com"

# Obtener variable de entorno y guardarla
When obtengo la variable de entorno "BROWSER" y la guardo en la variable "navegador_actual"

# Verificar que existe una variable de entorno
Then verifico que la variable de entorno "GEMINI_API_KEY" existe

# Verificar valor de variable de entorno
Then verifico que la variable de entorno "BROWSER" tiene el valor "chromium"

# Navegar a URL desde variable de entorno
When navego a la URL de la variable de entorno "BASE_URL"

# Rellenar campo con valor de variable de entorno
When relleno el campo "api_key" con la variable de entorno "API_KEY" con identificador "$.CONFIG.api_key"

# Login usando credenciales del .env
When hago login con las credenciales de las variables de entorno usuario "TEST_EMAIL" y contraseña "TEST_PASSWORD"

# Imprimir todas las variables de entorno
When imprimo todas las variables de entorno

# Imprimir variables que coinciden con un patrón
When imprimo las variables de entorno que coinciden con "DB_*"

# Backup y restore de variables (útil para pruebas que modifican config)
When hago backup de la variable de entorno "TIMEOUT" con nombre "timeout_original"
# ... modificar TIMEOUT ...
When restauro la variable de entorno "TIMEOUT" desde el backup "timeout_original"
```
El step de login busca automáticamente campos de usuario y contraseña en la página usando selectores comunes (`input[type="email"]`, `input[type="password"]`, `#username`, `#password`, etc.) con múltiples fallbacks. `imprimo las variables de entorno que coinciden` acepta patrones con `*` como wildcard.

---

## --- Configuración de behave.ini ---

tema: Archivo behave.ini
contenido: El archivo `behave.ini` configura el comportamiento de Behave. Se genera automáticamente con `haka-init`. Configuración típica:
```ini
[behave]
# Directorio de features
paths = features

# Formatters de salida
format = pretty
        json
        
# Archivo de salida JSON (para reportes)
outfiles = reports/behave-report.json

# Colores en consola
color = true

# Mostrar snippets para steps no implementados
show_snippets = true

# No capturar stdout (permite ver prints en consola)
stdout_capture = false
stderr_capture = false
log_capture = false

# Tags por defecto (excluir @wip y @skip)
default_tags = ~@wip ~@skip

# Timeout por step (en segundos, 0 = sin límite)
# step_timeout = 300
```
El formatter `json` genera el archivo JSON que el framework usa para generar reportes HTML. Si usas `haka-run`, el CLI configura automáticamente los formatters necesarios. Para ejecución directa con `behave`, asegúrate de tener `json` en los formatters y un `outfile` configurado. El `stdout_capture = false` es importante para ver los prints con emojis del framework en la consola.

---

## --- Personalización de environment.py ---

tema: Archivo environment.py
contenido: El framework se registra automáticamente como plugin de Behave a través de `behave_plugin.py`, por lo que normalmente no necesitas un `environment.py`. Sin embargo, si necesitas agregar hooks personalizados, puedes crear `features/environment.py` y combinar tus hooks con los del framework:
```python
# features/environment.py
from hakalab_framework.behave_plugin import (
    before_all as fw_before_all,
    after_all as fw_after_all,
    before_feature as fw_before_feature,
    after_feature as fw_after_feature,
    before_scenario as fw_before_scenario,
    after_scenario as fw_after_scenario,
    before_step as fw_before_step,
    after_step as fw_after_step
)

def before_all(context):
    fw_before_all(context)
    # Tu código personalizado aquí
    print("🚀 Iniciando suite de pruebas")

def after_all(context):
    fw_after_all(context)
    # Tu código personalizado aquí
    print("✅ Suite de pruebas finalizada")

def before_scenario(context, scenario):
    fw_before_scenario(context, scenario)
    # Ejemplo: agregar datos personalizados al contexto
    context.mi_dato_custom = "valor"

def after_scenario(context, scenario):
    fw_after_scenario(context, scenario)
    # Ejemplo: limpiar recursos personalizados
    if hasattr(context, 'mi_conexion'):
        context.mi_conexion.close()

def before_feature(context, feature):
    fw_before_feature(context, feature)

def after_feature(context, feature):
    fw_after_feature(context, feature)

def before_step(context, step):
    fw_before_step(context, step)

def after_step(context, step):
    fw_after_step(context, step)
```
Es importante llamar siempre a los hooks del framework (`fw_before_*`, `fw_after_*`) para que el sistema de plugins, screenshots, soft assertions y reportes funcionen correctamente. Si omites algún hook del framework, esa funcionalidad se desactivará. El orden importa: llama al hook del framework primero en `before_*` y después en `after_*` para que tu código se ejecute en el momento correcto.

---

## --- Testing Data-Driven ---

tema: Scenario Outline con Examples
contenido: Behave soporta pruebas data-driven usando `Scenario Outline` con tablas `Examples`. El framework resuelve variables en todos los parámetros, así que puedes combinar datos de la tabla con variables del `.env`:
```gherkin
Feature: Login con múltiples usuarios

  Scenario Outline: Login con credenciales válidas
    Given voy a la url "${ENV.BASE_URL}/login"
    When relleno el campo "email" con "<email>" con identificador "$.LOGIN.email"
    And relleno el campo "password" con "<password>" con identificador "$.LOGIN.password"
    And hago click en el elemento "login" con identificador "$.LOGIN.boton"
    Then verifico que la URL contiene "/dashboard"
    And verifico que el elemento "bienvenida" contiene "<nombre>" con identificador "$.DASHBOARD.bienvenida"

    Examples:
      | email              | password    | nombre  |
      | admin@test.com     | Admin123    | Admin   |
      | user@test.com      | User123     | Usuario |
      | viewer@test.com    | Viewer123   | Viewer  |
```
Cada fila de `Examples` genera un escenario independiente. Los placeholders `<email>`, `<password>`, `<nombre>` se reemplazan por los valores de la tabla. Esto es diferente de las variables `${variable}` del framework: los placeholders de Examples los resuelve Behave antes de ejecutar el step, mientras que `${variable}` los resuelve el framework dentro del step.

tema: Testing con datos CSV
contenido: Los `csv_file_steps` permiten usar archivos CSV como fuente de datos para pruebas:
```gherkin
@no_browser
Scenario: Validar datos del CSV de productos
  Given verifico que el archivo CSV "datos/productos.csv" existe
  When cuento las filas del CSV "datos/productos.csv"
  Then verifico que el CSV tiene al menos 10 filas
  And verifico que el valor en la fila 1 columna "nombre" del CSV es "Producto A"
```
Los CSV se pueden combinar con Scenario Outline para pruebas masivas, o usar directamente para validar exportaciones de datos de la aplicación.

---

## --- Emulación de Dispositivos y Geolocalización ---

tema: Emulación de dispositivos
contenido: Los `advanced_steps` permiten emular dispositivos específicos de la biblioteca de Playwright:
```gherkin
# Emular un dispositivo específico (usa la lista de devices de Playwright)
When emulo el dispositivo "iPhone 13"
When emulo el dispositivo "Pixel 5"
When emulo el dispositivo "iPad Pro 11"
```
La emulación configura automáticamente el viewport y headers HTTP del dispositivo. Los nombres de dispositivos disponibles son los de la lista oficial de Playwright: `iPhone 13`, `iPhone 13 Pro Max`, `Pixel 5`, `Galaxy S21`, `iPad Pro 11`, etc. Si el dispositivo no existe, lanza una excepción con el nombre proporcionado.

tema: Geolocalización
contenido: El framework permite simular la ubicación geográfica del navegador:
```gherkin
# Establecer geolocalización (latitud y longitud como decimales)
When establezco la geolocalización del navegador a latitud 40.416775 y longitud -3.703790
When establezco la geolocalización del navegador a latitud -33.448890 y longitud -70.669265
```
La geolocalización se establece a nivel de contexto del navegador con `context.page.context.set_geolocation()`. Es útil para probar aplicaciones que usan la API de Geolocation del navegador (mapas, tiendas cercanas, etc.). Los valores son `float`, así que acepta decimales con precisión.

tema: Listado completo de categorías
contenido: El framework incluye 42 categorías de steps con 512+ pasos únicos en español. Las categorías se cargan automáticamente desde `hakalab_framework/steps/__init__.py`:

1. Navigation Steps — Navegación, URLs, historial, pestañas, ventanas
2. Interaction Steps — Click, doble click, hover, fill, select, checkbox, upload, atributos HTML
3. Assertion Steps — Verificaciones de texto, visibilidad, estado de elementos
4. Scroll Steps — Desplazamiento de página y elementos
5. Wait Steps — Esperas explícitas e implícitas
6. Data Extraction Steps — Extracción de texto, atributos, datos de la página
7. Variable Steps — Gestión de variables de escenario y globales
8. Window Steps — Manejo de ventanas, tabs, popups
9. Advanced Steps — JavaScript, screenshots manuales, evaluación de expresiones
10. Drag & Drop Steps — Arrastrar y soltar elementos
11. Combobox Steps — Selects y dropdowns avanzados (búsqueda, multi-select)
12. iFrame Steps — Cambio de contexto a iframes
13. Modal Steps — Modales, diálogos, alertas del navegador
14. File Steps — Upload, download, verificación de archivos
15. Table Steps — Interacción con tablas HTML
16. Keyboard/Mouse Steps — Teclas, combinaciones, coordenadas
17. Salesforce Steps — Automatización específica de Salesforce Lightning/Classic
18. Environment Steps — Variables de entorno en runtime
19. CSV File Steps — Lectura y validación de archivos CSV
20. Timing Steps — Cronómetros y esperas avanzadas
21. Advanced Input Steps — Interacción avanzada con campos de entrada
22. Validation Steps — Validaciones avanzadas de elementos y datos
23. Accessibility Steps — Testing de accesibilidad web
24. Combobox Validation Steps — Validaciones específicas de combobox
25. Performance Steps — Medición de rendimiento y tiempos de carga
26. Responsive Steps — Testing responsive y viewports
27. Jira/Xray Steps — Integración con Jira y Xray desde features
28. Web Elements Steps — Manipulación avanzada de elementos DOM
29. Form Handling Steps — Manejo completo de formularios
30. Browser Control Steps — Control del navegador (cookies, localStorage, console)
31. Browser Advanced Config Steps — Configuración avanzada del navegador en runtime
32. API Testing Steps — Testing de APIs REST completo
33. Database Steps — Testing de bases de datos (SQLite, MySQL, PostgreSQL)
34. Email Steps — Testing de emails (SMTP/IMAP)
35. PDF Steps — Validación de contenido de PDFs
36. OCR Steps — Reconocimiento óptico de caracteres
37. GenAI Evaluation Steps — Evaluación con Gemini como Juez
38. API JSON Validation Steps — Validación avanzada de respuestas JSON
39. Semantic Validation Steps — Validación semántica con IA
40. Semantic Advanced Steps — Validación semántica avanzada
41. Semantic NLP Steps — Procesamiento de lenguaje natural
42. GenAI Advanced Steps — Testing avanzado de IA Generativa
43. Supabase Vector Steps — Búsqueda vectorial en Supabase

Para ver el inventario completo de pasos con descripciones, consulta `INVENTARIO_COMPLETO_PASOS.md`. Para pasos de validación específicamente, consulta `INVENTARIO_VALIDACIONES_PASOS.md`.

---

## --- Hooks Automáticos del Framework ---

tema: Ciclo de vida de los hooks
contenido: El framework registra hooks automáticamente a través de `behave_plugin.py`. No necesitas modificar `environment.py`. El ciclo de vida es:

**before_all:** `setup_framework_context()` inicializa FrameworkConfig, Playwright, browser, ElementLocator, VariableManager, DataSnapshotManager, AIReportGenerator, y la integración Jira/Xray. Luego ejecuta `before_all` de todos los plugins habilitados.

**before_feature:** `auto_before_feature()` configura el feature actual. Luego plugins.

**before_scenario:** Detecta tag `@no_browser` → `setup_scenario_context()` reutiliza o crea página, configura timeout, helpers, tag `@mobile` → `before_scenario_soft_assertions()` → plugins.

**before_step / after_step:** Plugins ejecutan sus hooks. `after_step` captura soft assertions si están activas.

**after_scenario:** Soft assertions `assert_all()` → plugins (HTML report captura datos) → `auto_after_scenario()` (video, retry counter, Jira/Xray).

**after_feature:** Plugins → `auto_after_feature()` cierra todas las páginas del feature, Jira/Xray.

**after_all:** Plugins → `auto_after_all()` genera reporte IA (si no usa plugins), muestra resumen de soft assertions.

La página se reutiliza entre escenarios del mismo feature. Se verifica que esté activa intentando acceder a `page.url`. Si está cerrada, se crea una nueva automáticamente.

---

## --- Limpieza y Mantenimiento ---

tema: Limpieza automática de archivos
contenido: El framework puede limpiar automáticamente archivos antiguos. Configuración: `CLEANUP_OLD_FILES=true`, `CLEANUP_MODE` (`all` = elimina todo, `old` = solo archivos antiguos), `CLEANUP_MAX_AGE_HOURS` (default 24). Se limpian: screenshots PNG en `SCREENSHOTS_DIR`, reportes HTML y JSON en `HTML_REPORTS_DIR`. Para videos: `CLEANUP_OLD_VIDEOS=true`, `VIDEO_MAX_AGE_HOURS` (default 168 = 7 días). La limpieza se ejecuta automáticamente al inicio de la ejecución. También puedes limpiar manualmente con `haka-report --clean`.

---

## --- Dependencias Opcionales ---

tema: Gestión de dependencias opcionales
contenido: El framework tiene dependencias opcionales organizadas en grupos, gestionadas con el CLI `haka-deps`:
- `ocr` — pytesseract, easyocr, opencv-python, Pillow (para OCR)
- `advanced_data` — openpyxl, xlrd (para Excel), tabulate (para tablas)
- `performance` — locust, psutil (para pruebas de carga)
Comandos: `haka-deps --status` (ver estado), `haka-deps --check ocr` (verificar grupo), `haka-deps --install ocr` (instalar grupo), `haka-deps --install all` (instalar todo). Las dependencias core (playwright, behave, python-dotenv, click, requests) se instalan automáticamente con el paquete principal. Para Gemini: `google-generativeai`. Para semántica: `sentence-transformers`. Para stealth: `playwright-stealth`. Para MySQL: `mysql-connector-python`. Para PostgreSQL: `psycopg2-binary`.

---

## --- Ejemplo Completo de Feature ---

tema: Feature de ejemplo con múltiples capacidades
contenido:
```gherkin
@PROJ-456
Feature: Flujo completo de compra
  Como usuario registrado
  Quiero completar una compra
  Para recibir mi producto

  Background:
    Given voy a la url "${ENV.BASE_URL}/login"
    And relleno el campo "email" con "${ENV.TEST_EMAIL}" con identificador "$.LOGIN.email"
    And relleno el campo "password" con "${ENV.TEST_PASSWORD}" con identificador "$.LOGIN.password"
    And hago click en el elemento "login" con identificador "$.LOGIN.boton_login"
    And espero a que cargue la página

  Scenario: Agregar producto al carrito
    When voy a la url "${ENV.BASE_URL}/productos"
    And hago click en el elemento "producto 1" con identificador "$.PRODUCTOS.primer_producto"
    And hago click en el elemento "agregar" con identificador "$.PRODUCTOS.boton_agregar"
    Then verifico que el elemento "contador" contiene "1" con identificador "$.HEADER.carrito_contador"
    And extraigo el texto del elemento "precio" con identificador "$.PRODUCTOS.precio" y lo guardo en la variable "precio_producto"

  @no_browser
  Scenario: Verificar API de inventario
    Given configuro la API base en "${ENV.API_BASE_URL}"
    When realizo una petición GET a "/inventory/check?product=1"
    Then verifico que el código de respuesta es 200
    And verifico que el campo "in_stock" es true
```

tema: Feature de ejemplo con soft assertions y variables
contenido:
```gherkin
Feature: Validación completa del dashboard

  Scenario: Verificar todos los widgets del dashboard
    Given voy a la url "${ENV.BASE_URL}/dashboard"
    And activo las soft assertions
    When espero a que el elemento "dashboard" sea visible con identificador "$.DASH.contenedor"
    Then verifico que el elemento "widget_ventas" contiene "Ventas" con identificador "$.DASH.widget_ventas"
    And verifico que el elemento "widget_usuarios" contiene "Usuarios" con identificador "$.DASH.widget_usuarios"
    And verifico que el elemento "widget_pedidos" contiene "Pedidos" con identificador "$.DASH.widget_pedidos"
    And verifico que el elemento "grafico" es visible con identificador "$.DASH.grafico"
    And verifico todas las soft assertions

  Scenario: Extraer datos y verificar consistencia
    Given voy a la url "${ENV.BASE_URL}/reportes"
    When genero un timestamp y lo guardo en la variable "ts_inicio"
    And obtengo el texto del elemento "total_ventas" y lo guardo en la variable "total_ui" con identificador "$.REPORT.total"
    And obtengo el texto del elemento "fecha_reporte" y lo guardo en la variable "fecha" con identificador "$.REPORT.fecha"
    Then verifico que la variable "total_ui" contiene "$"
    And verifico que la variable "fecha" contiene "2026"
    And imprimo el valor de la variable "total_ui"
```

tema: Feature de ejemplo con JavaScript y browser control
contenido:
```gherkin
Feature: Testing avanzado con JavaScript y cookies

  Scenario: Verificar estado de la aplicación via JavaScript
    Given voy a la url "${ENV.BASE_URL}"
    When ejecuto el JavaScript "document.readyState" y guardo el resultado en la variable "estado"
    Then verifico que la variable "estado" es igual a "complete"
    When ejecuto el siguiente JavaScript y guardo el resultado en la variable "version_app"
      """
      const meta = document.querySelector('meta[name="version"]');
      return meta ? meta.getAttribute('content') : 'no-version';
      """
    Then imprimo el valor de la variable "version_app"

  Scenario: Gestionar cookies de sesión
    Given voy a la url "${ENV.BASE_URL}/login"
    When establezco la cookie "preferencia_idioma" con valor "es"
    And relleno el campo "email" con "${ENV.TEST_EMAIL}" con identificador "$.LOGIN.email"
    And relleno el campo "password" con "${ENV.TEST_PASSWORD}" con identificador "$.LOGIN.password"
    And hago click en el elemento "login" con identificador "$.LOGIN.boton_login"
    Then obtengo el valor de la cookie "session_id" y lo guardo en la variable "mi_session"
    And verifico que la variable "mi_session" contiene ""
    # La variable no estará vacía si el login fue exitoso

  Scenario: Testing responsive del menú
    Given voy a la url "${ENV.BASE_URL}"
    When establezco el viewport a tamaño "mobile" (375x667)
    Then verifico que el elemento "menu_hamburguesa" es visible en mobile con identificador "$.NAV.hamburguesa"
    And verifico que el elemento "menu_desktop" está oculto en mobile con identificador "$.NAV.menu_desktop"
    When establezco el viewport a tamaño "desktop" (1920x1080)
    Then verifico que el elemento "menu_desktop" es visible con identificador "$.NAV.menu_desktop"
```

tema: Feature de ejemplo con API + base de datos
contenido:
```gherkin
@no_browser
Feature: Validación end-to-end de API y base de datos

  Scenario: Crear usuario via API y verificar en BD
    Given configuro la API base en "${ENV.API_BASE_URL}"
    And configuro el header "Authorization" con valor "Bearer ${ENV.BEARER_TOKEN}"
    And genero un texto aleatorio de 8 caracteres y lo guardo en la variable "username"
    When realizo una petición POST a "/users" con body:
      """
      {"username": "${username}", "email": "${username}@test.com", "role": "viewer"}
      """
    Then verifico que el código de respuesta es 201
    And verifico que el campo "id" existe en la respuesta

    # Verificar en base de datos
    Given me conecto a la base de datos
    When ejecuto la consulta "SELECT * FROM users WHERE username = '${username}'"
    Then verifico que la consulta retorna al menos 1 resultado
    And verifico que el campo "role" del resultado 1 es "viewer"
```

---

> Documento generado para Hakalab Framework v1.3.77
> Para consultar el inventario completo de pasos disponibles, ver INVENTARIO_COMPLETO_PASOS.md
> Para consultar solo pasos de validación, ver INVENTARIO_VALIDACIONES_PASOS.md



---

# Automatizacion de Aplicaciones de Escritorio

El framework incluye soporte nativo para automatizar aplicaciones de escritorio usando **PyAutoGUI**.
Funciona en Windows, macOS y Linux. Compatible con pruebas puras de escritorio y pruebas mixtas.

## Instalacion

```bash
pip install pyautogui pillow pyperclip pytesseract
```

## Variables de entorno

```env
DESKTOP_ACTION_PAUSE=0.3        # Pausa entre acciones (segundos)
DESKTOP_IMAGE_CONFIDENCE=0.85   # Confianza para busqueda de imagenes (0.0-1.0)
DESKTOP_SEARCH_TIMEOUT=10.0     # Timeout para busqueda de imagenes (segundos)
DESKTOP_TYPING_INTERVAL=0.05    # Intervalo entre caracteres al escribir
DESKTOP_IMAGES_DIR=desktop_images  # Carpeta de imagenes de referencia
DESKTOP_CAPTURE_ALL_STEPS=true  # Captura automatica por step en reporte
```

## Estructura de carpetas recomendada

```
mi_proyecto/
├── features/
│   └── mi_prueba.feature
├── desktop_images/          ← imagenes de referencia organizadas por app
│   ├── audacity/
│   │   ├── boton_play.png
│   │   └── menu_archivo.png
│   ├── calculadora/
│   │   ├── boton_igual.png
│   │   └── display.png
│   └── notepad/
│       └── area_texto.png
├── screenshots/             ← capturas automaticas del reporte
└── .env
```

## Imagenes de referencia

Toma un screenshot del elemento exacto (boton, campo, icono) y guardalo en `desktop_images/`.
En el feature usa el nombre relativo sin extension: `"audacity/boton_play"`.

- Recorta justo el elemento, sin espacio extra alrededor
- Toma la captura en la misma resolucion que usaras en las pruebas
- Si el click no es preciso, usa `hago click con desplazamiento "{x}" "{y}" en la imagen "..."`

## Modos de reporte (solo en pruebas mixtas)

En pruebas puras (solo web, solo desktop, solo API) el framework detecta el modo automaticamente.
Solo necesitas declarar el modo cuando mezclas tipos en el mismo escenario:

```gherkin
Cuando uso el modo desktop   # capturas con PyAutoGUI
Cuando uso el modo web       # capturas con Playwright
Cuando uso el modo api       # muestra request/response, sin screenshot
```

## Ejemplo 1 — Prueba pura de escritorio

```gherkin
@desktop @no_browser
Escenario: Login en Audacity
  Dado que lanzo y espero "3" segundos la aplicacion "C:/Program Files/Audacity/Audacity.exe"
  Y capturo el escritorio con nombre "audacity_abierto"

  Cuando hago click en la imagen "audacity/menu_archivo"
  Y espero con timeout "3" segundos a que aparezca la imagen "audacity/menu_desplegado"
  Y hago click en la imagen "audacity/opcion_abrir"

  Entonces deberia ver la imagen "audacity/dialogo_abrir" en pantalla
  Y capturo el escritorio con nombre "dialogo_abrir_visible"

  Y cierro la aplicacion "Audacity.exe"
```

## Ejemplo 2 — Formulario con texto especial (tildes, enie)

```gherkin
@desktop @no_browser
Escenario: Llenar formulario con caracteres especiales
  Dado que lanzo y espero "2" segundos la aplicacion "notepad.exe"

  # pego el texto usa portapapeles: soporta tildes, enie, etc.
  Cuando pego el texto "Nombre: José García" usando el portapapeles
  Y presiono Enter en escritorio
  Y pego el texto "Ciudad: Concepción" usando el portapapeles
  Y presiono el atajo de escritorio guardar

  Entonces deberia ver el texto "José" en el escritorio usando OCR
  Y cierro la aplicacion "notepad.exe"
```

## Ejemplo 3 — Leer valor de un campo

```gherkin
@desktop @no_browser
Escenario: Verificar valor calculado
  Dado que lanzo y espero "2" segundos la aplicacion "calc.exe"

  Cuando hago click en la imagen "calculadora/boton_1"
  Y hago click en la imagen "calculadora/boton_0"
  Y hago click en la imagen "calculadora/boton_mas"
  Y hago click en la imagen "calculadora/boton_5"
  Y hago click en la imagen "calculadora/boton_igual"

  # Leer resultado via OCR
  Entonces capturo el escritorio y extraigo texto en la variable "resultado"
  Y el texto leido en la variable "resultado" deberia contener "15"

  # O leer via portapapeles (mas preciso para valores exactos)
  Cuando leo el campo imagen "calculadora/display" y guardo el texto en la variable "valor_display"
  Entonces el texto leido en la variable "valor_display" deberia ser exactamente "15"

  Y cierro la aplicacion "CalculatorApp.exe"
```

## Ejemplo 4 — Prueba mixta (web + desktop)

```gherkin
Escenario: Exportar desde web y verificar en Excel
  # --- WEB (capturas Playwright automaticas) ---
  Dado que navego a "${ENV.BASE_URL}/reportes"
  Cuando hago click en el elemento "exportar" con identificador "#btn-export"
  Y espero "3" segundos

  # --- DESKTOP (capturas PyAutoGUI automaticas) ---
  Cuando uso el modo desktop
  Y cambio a la aplicacion de escritorio "C:/Program Files/Microsoft Office/root/Office16/EXCEL.EXE" desde la prueba web
  Y espero con timeout "15" segundos a que aparezca la imagen "excel/excel_listo"

  Entonces deberia ver el texto "Reporte" en el escritorio usando OCR
  Y capturo el escritorio con nombre "excel_con_datos"

  # --- VOLVER A WEB ---
  Cuando uso el modo web
  Y vuelvo al navegador web despues de la interaccion con escritorio
  Entonces verifico que el elemento con css ".export-success" es visible
```

## Ejemplo 5 — Prueba mixta (web + API + desktop)

```gherkin
Escenario: Flujo completo con tres modos
  # WEB
  Dado que navego a "${ENV.BASE_URL}/login"
  Cuando ingreso "${ENV.TEST_USER}" en el campo con id "username"
  Y hago click en el boton con css "button[type='submit']"

  # API (request/response en reporte, sin screenshot)
  Cuando uso el modo api
  Y envío petición GET a "${ENV.API_URL}/users/me" y guardo la respuesta en la variable "user"
  Entonces la respuesta debería tener código 200

  # DESKTOP (capturas PyAutoGUI)
  Cuando uso el modo desktop
  Y lanzo y espero "2" segundos la aplicacion "${ENV.APP_CLIENTE}"
  Y espero con timeout "10" segundos a que aparezca la imagen "app/pantalla_principal"

  # VOLVER A WEB
  Cuando uso el modo web
  Y navego a "${ENV.BASE_URL}/dashboard"
  Entonces verifico que el elemento con css ".dashboard" es visible
```

## Notas importantes

- **FAILSAFE**: mover el mouse a la esquina superior izquierda detiene el script de emergencia
- **Rutas**: usar forward slashes `C:/Program Files/App/app.exe` para evitar problemas con backslashes
- **Texto especial**: usar `pego el texto usando el portapapeles` para tildes, enie, etc.
- **Coordenadas vs imagenes**: las coordenadas son fragiles si la ventana se mueve; las imagenes son mas robustas
- **Capturas automaticas**: el reporte captura pantalla despues de cada step de desktop automaticamente
