from flask import jsonify, make_response
from loguru import logger

from ..app import app
from ..tools.tools_interface import interface


@app.route("/hw_proxy/hello")
@logger.catch
def hello():
    """
    hw_proxy/hello is called when the Point of Sale is launched,
    and when user clicks on the device icon.

    If the call to hello fails, Iot Box is considered offline
    and no other calls will be done."""
    return make_response("ping")


@app.route("/hw_proxy/handshake", methods=["POST"])
@logger.catch
def handshake():
    """hw_proxy/handshake is done just after 'hello' call,
    if the hello call succeeded.

    If the call to handshake fails, an error is raised
    in the Point of sale, and no other calls will be done.
    """
    return jsonify(jsonrpc="2.0", result=True)


@app.route("/hw_proxy/status_json", methods=["POST", "PUT"])
@logger.catch
def status_json():
    """
    hw_proxy/status_json is called every 5 seconds by Odoo,
    if hello / handshake was correctly answered.

    it returns a dictionary with the following structure.
        {
            'DEVICE_TYPE_1': {'status': 'STATUS_1'},
            'DEVICE_TYPE_X': {'status': 'STATUS_X'},
        }

    If the call to status_json fails, an error is raised
    every each 5 seconds, that is quite annoying for the end user.
    """
    # Lazy import, to avoid circular import problem
    from ..tools.tools_plugins import installed_plugins

    status = {}

    for driver_function, driver in interface.drivers.items():
        if driver.is_connected:
            plugin = installed_plugins.get(f"odoo_driver_plugin_{driver.plugin_name}")
            status[driver_function] = {
                "status": "connected",
                "plugin_name": driver.plugin_name,
                "plugin_version": plugin.__version__,
                "plugin_hash": plugin.code_hash,
                "vendor_product_code": driver.get_usb_info("full_id_str"),
                "serial_number": driver.get_usb_info("product_serial_number"),
                "manufacturer": driver.get_usb_info("product_manufacturer"),
                "product_name": driver.get_usb_info("product_name"),
                "device_name": driver.get_usb_info("device_name"),
            }
        else:
            status[driver_function] = {"status": "disconnected"}
        print(status[driver_function])

    return jsonify(jsonrpc="2.0", result=status)
