from . import routes_odoo, routes_website
