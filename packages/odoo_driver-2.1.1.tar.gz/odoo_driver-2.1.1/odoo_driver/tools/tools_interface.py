import base64
import time
from datetime import datetime
from io import BytesIO
from threading import Thread

import usb
from loguru import logger
from PIL import Image

from ..drivers.driver_abstract_with_queue import DriverAbstractWithQueue
from . import tools_usb_device


class Interface(Thread):
    @property
    def usb_core_devices(self) -> list[usb.core.Device]:
        """Ordered list of usb devices that have been detected on the host.

        The list is refreshed every ``_refresh_devices_delay`` seconds;
        by the function ``refresh_usb_core_devices()``,
        or manually by the UI.
        """
        return sorted(
            self._usb_core_devices,
            key=lambda x: tools_usb_device.get_usb_device_infos(x).get("usb_full_path"),
        )

    @property
    def start_date(self) -> datetime:
        return self._start_date

    @property
    def last_refresh_devices_date(self) -> datetime:
        return self._last_refresh_devices_date

    @property
    def refresh_devices_delay(self) -> int:
        return self._refresh_devices_delay

    @property
    def drivers(self) -> dict:
        return self._drivers

    def __init__(self):
        Thread.__init__(self)
        self._usb_core_devices = []
        self._drivers = {}
        self._last_refresh_devices_date = False
        self._start_date = datetime.now()

    def initialize(self, refresh_devices_delay: int, log_folder=False):
        self._refresh_devices_delay = refresh_devices_delay
        self._log_folder = log_folder

        self.refresh_usb_core_devices()

        for _driver_function, driver in self._drivers.items():
            if issubclass(driver.__class__, DriverAbstractWithQueue):
                driver.start()
                logger.info(
                    f"Queue enabled. Driver {_driver_function} can now receive tasks."
                )

        self.start()

    # ###########################
    # Generic Device Section
    # ###########################

    @logger.catch
    def refresh_usb_core_devices(self, manual=False):
        log_message = "Refreshing USB Devices List ..."
        if manual:
            log_message += "(Manual)"
        else:
            log_message += f"(Next refresh in {self._refresh_devices_delay} second(s).)"
        logger.debug(log_message)

        current_usb_core_devices = [x for x in usb.core.find(find_all=True)]

        # Detect new devices
        for usb_core_device in current_usb_core_devices:
            if usb_core_device not in self._usb_core_devices:
                self._hook_usb_core_device_new(usb_core_device)

        # Handle device removal
        for usb_core_device in self._usb_core_devices:
            if usb_core_device not in current_usb_core_devices:
                self._hook_usb_core_device_removed(usb_core_device)
        self._last_refresh_devices_date = datetime.now()

    def _log_prepare_device_message(self, info: dict) -> str:
        log_message = f"ID '{info['full_id_str']}',"
        if info["product_name"]:
            log_message += f" Name '{info['product_name']}',"
        if info["product_manufacturer"]:
            log_message += f" Manufacturer '{info['product_manufacturer']}',"
        if info["product_serial_number"]:
            log_message += f" Serial Number '{info['product_serial_number']}',"
        if info["driver_function"]:
            log_message += f" Function '{info['driver_function']}',"
            log_message += f" Device Name '{info['device_name']}'."
        return log_message

    def _hook_usb_core_device_new(self, device):
        """Handle here things to be done, when a new usb device is detected."""
        info = tools_usb_device.get_usb_device_infos(device)

        log_message = (
            f"Discovering new USB device : {self._log_prepare_device_message(info)}"
        )

        logger.log(info["driver_function"] and "SUCCESS" or "INFO", log_message)

        if info["driver_function"]:
            self.drivers[info["driver_function"]].set_usb_device(device, info)

        self._usb_core_devices.append(device)

    def _hook_usb_core_device_removed(self, device, error=False):
        """Handle here cleanup to be done, when a removal of
        device is detected"""
        info = tools_usb_device.get_usb_device_infos(device)

        log_message = f"Removing USB device : {self._log_prepare_device_message(info)}"

        logger.log(info["driver_function"] and "WARNING" or "INFO", log_message)

        if info["driver_function"]:
            self.drivers[info["driver_function"]].remove_usb_device(info)

        self._usb_core_devices.remove(device)

    # ###########################
    # Thread Section
    # ###########################

    def run(self):
        while True:
            time.sleep(self._refresh_devices_delay)
            self.refresh_usb_core_devices()

    # ###########################
    # Log Section
    # ###########################
    def log_image(self, base64_image, log_level):
        if logger._core.min_level <= logger.level(log_level).no:
            if not self._log_folder:
                logger.warning(
                    "Log Folder is undefined. unable to save image for debug purpose."
                )
                return
            try:
                image = Image.open(BytesIO(base64.b64decode(base64_image)))
                dt = datetime.now().isoformat("_").replace(":", "-").replace(".", "-")
                filepath = self._log_folder / f"odoo-driver__print__{dt}.{image.format}"
                image.save(filepath)
                logger.debug(f"Image saved into {filepath}")
            except Exception as e:
                logger.error(f"Unable to log image. {e}")

    def log_data(self, data, device_type, log_level):
        if logger._core.min_level <= logger.level(log_level).no:
            logger.debug(f"Data received on device '{device_type}': {data}")


interface = Interface()
