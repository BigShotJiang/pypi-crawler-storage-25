import importlib
import pkgutil
from pathlib import Path

from loguru import logger

from ..app import app
from .tools_interface import interface
from .tools_usb_device import usb_devices


def load_installed_plugins():
    logger.info("Searching for plugins ...")
    result = {}
    modules = [
        module
        for module in pkgutil.iter_modules()
        if module.name.startswith("odoo_driver_plugin_")
    ]
    current_rules = [rule for rule in app.url_map.iter_rules()]
    for k, module in enumerate(modules, 1):
        logger.info(f"{k} / {len(modules)}: Importing plugin '{module.name}' ...")
        plugin = importlib.import_module(module.name)
        _load_usb_devices_from_plugin(plugin)
        _load_driver_from_plugin(plugin)
        _load_routes_from_plugin(plugin, current_rules)
        _define_translations_folder_from_plugin(plugin)
        result[module.name] = plugin
        logger.success(
            f"{k} / {len(modules)}: "
            f"Plugin '{module.name}' (Version: {plugin.__version__}) loaded successfully."
        )
    return result


def _load_usb_devices_from_plugin(plugin):
    logger.info(f"Adding {len(plugin.usb_devices.USB_DEVICES)} compatible devices.")
    for _vendor_product_code, _device_info in plugin.usb_devices.USB_DEVICES.items():
        usb_devices[_vendor_product_code] = _device_info
        usb_devices[_vendor_product_code].update(
            {
                "driver_function": plugin.DRIVER_FUNCTION,
                "plugin_name": plugin.PLUGIN_NAME,
                "plugin_version": plugin.__version__,
                "plugin_path": plugin.__path__[0],
            }
        )


def _load_driver_from_plugin(plugin):
    logger.info(f"Initialize driver with function {plugin.DRIVER_FUNCTION}.")
    interface.drivers[plugin.DRIVER_FUNCTION] = plugin.DRIVER_CLASS()
    interface.drivers[plugin.DRIVER_FUNCTION].interface = interface


def _load_routes_from_plugin(plugin, current_rules):
    logger.info(f"Loading new routes for {plugin.DRIVER_FUNCTION}.")
    for driver_routes in plugin.DRIVER_ROUTES_GROUPS:
        app.register_blueprint(driver_routes)
        new_rules = [rule for rule in app.url_map.iter_rules()]
        for new_rule in new_rules:
            if new_rule not in current_rules:
                logger.info(f"New route added '{new_rule.endpoint}'.")
                current_rules.append(new_rule)


def _define_translations_folder_from_plugin(plugin):
    translation_path = (Path(plugin.__path__[0]) / "i18n").absolute()
    if translation_path.exists():
        logger.info(
            f"New translation directory added '{translation_path}' for {plugin.DRIVER_FUNCTION}."
        )
        app.config["BABEL_TRANSLATION_DIRECTORIES"] += f";{translation_path}"


installed_plugins = load_installed_plugins()
