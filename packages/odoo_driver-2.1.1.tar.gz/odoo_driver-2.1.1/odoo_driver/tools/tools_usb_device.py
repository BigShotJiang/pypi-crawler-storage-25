import usb

usb_devices = {}


def get_usb_device_infos(device: usb.core.Device) -> dict:
    vendor_product_code = (device.idVendor, device.idProduct)

    device_info = usb_devices.get(vendor_product_code, {})

    vendor_id_str = "{0:04x}".format(device.idVendor)
    product_id_str = "{0:04x}".format(device.idProduct)
    full_id_str = f"{vendor_id_str}:{product_id_str}"

    return {
        "vendor_id": device.idVendor,
        "vendor_id_str": vendor_id_str,
        "product_id": device.idProduct,
        "product_id_str": product_id_str,
        "full_id": (device.idVendor, device.idProduct),
        "full_id_str": full_id_str,
        "product_name": _get_extra_device_value(device, "product"),
        "product_manufacturer": _get_extra_device_value(device, "manufacturer"),
        "product_serial_number": _get_extra_device_value(device, "serial_number"),
        "plugin_name": device_info.get("plugin_name", ""),
        "driver_function": device_info.get("driver_function", ""),
        "device_name": device_info.get("name", ""),
        "device_image": device_info.get("image", ""),
        "usb_full_path": _compute_usb_full_path(device),
        "has_parent": bool(device.parent),
    }


def _compute_usb_full_path(device: usb.core.Device) -> str:
    current_id = (
        "{0:04x}".format(device.idVendor) + ":" + "{0:04x}".format(device.idProduct)
    )
    if device.parent:
        return f"{_compute_usb_full_path(device.parent)} / {current_id}"
    else:
        return current_id


def _get_extra_device_value(device: usb.core.Device, name: str) -> str:
    try:
        return getattr(device, name, "")
    except ValueError:
        return ""
