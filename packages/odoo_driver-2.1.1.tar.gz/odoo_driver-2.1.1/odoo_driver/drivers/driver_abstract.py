from datetime import datetime

import serial.tools.list_ports
from flask_babel import gettext as _
from loguru import logger
from serial import Serial


class DriverAbstract:
    _has_queue = False
    _driver_function = False
    _plugin_name = False
    _use_serial = False

    def __init__(self):
        self._disconnections = []
        self._usb_device = False
        self._interface = False
        self._usb_device_info = {}
        self._usb_image_name = False
        self._terminal_file = False

    @property
    def driver_function(self):
        return self._driver_function

    @property
    def interface(self):
        return self._interface

    @interface.setter
    def interface(self, value):
        if self._interface:
            raise Exception(
                "Interface is set only once, at start of the odoo-driver application"
            )
        self._interface = value

    @property
    def plugin_name(self):
        if not self._plugin_name:
            raise Exception
        return self._plugin_name

    @property
    def has_queue(self):
        return self._has_queue

    @property
    def terminal_file(self):
        return self._terminal_file

    def get_usb_info(self, info_name):
        if info_name:
            return self._usb_device_info.get(info_name, False)
        else:
            return self._usb_device_info

    @property
    def name(self):
        return _("Unknown")

    @property
    def usb_device_full_id(self):
        return self._usb_device_info.get("full_id", False)

    @property
    def is_connected(self):
        return bool(self._usb_device)

    @property
    def disconnections(self):
        return self._disconnections

    @property
    def disconnections_qty(self):
        return len(self._disconnections)

    @property
    def usb_device_name(self):
        return self._usb_device_info.get("device_name", False)

    # ###########################
    # USB Device Section
    # ###########################
    def set_usb_device(self, usb_device, usb_device_info):
        self._usb_device = usb_device
        self._usb_device_info = usb_device_info
        connected_comports = [x for x in serial.tools.list_ports.comports()]
        for port in connected_comports:
            if (port.vid, port.pid) == (
                usb_device.idVendor,
                usb_device.idProduct,
            ):
                self._terminal_file = port.device
                self._logger("DEBUG", f"Terminal File found: {self._terminal_file}.")
                break
        if not self._terminal_file:
            self._logger("DEBUG", "Terminal File not found.")

    def remove_usb_device(self, usb_device_info):
        self._usb_device = False
        self._usb_device_info = {}
        self._terminal_file = False
        self._disconnections.append(
            {
                "full_id_str": usb_device_info["full_id_str"],
                "date": datetime.now(),
                "error": False,
            }
        )

    def _get_serial(self):
        if not self._terminal_file:
            raise Exception(
                "Unable to open a Serial connexion,"
                " because terminal_file is not defined."
            )
        return Serial(self._terminal_file, 9600, timeout=0.05)

    # ###########################
    # Loggging Section
    # ###########################
    def _logger(self, level, message):
        if self._usb_device:
            extra_info = f" ({self.usb_device_name} - {self._usb_device_info.get('full_id_str', '')})"
        else:
            extra_info = ""
        logger.log(level, f"Device '{self.driver_function}'{extra_info}: {message}")
