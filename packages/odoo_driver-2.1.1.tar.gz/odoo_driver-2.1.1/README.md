# Odoo Drivers

![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/odoo-driver)
![PyPI - Downloads](https://img.shields.io/pypi/dm/odoo-driver)
![GitLab last commit](https://img.shields.io/gitlab/last-commit/60778766)
![GitLab stars](https://img.shields.io/gitlab/stars/60778766?style=social)

This tools is intented to be used with the Odoo Point of sale application. It replaces the Odoo [IoT Box](https://www.odoo.com/app/iot) or the
Community [pywebdriver](https://github.com/pywebdriver/pywebdriver) library.

Once installed locally in the cashier computer, devices will be discovered by the tool,
once plugged, and communication can be done with the Odoo Point of Sale module.


## Table of contents

1. [Run](#run)
2. [Usage](#usage)
3. [Installation](#installation)
4. [Compatible Plugins](#compatible-pugins)
5. [How to Contribute](#how-to-contribute)
6. [Development](#development)
7. [Credits](#credits)

<a name="run"></a>

## Run

```shell
odoo-driver\
  --address 0.0.0.0\
  --port 8069\
  --secure\
  --refresh-devices-delay 1\
  --log-level INFO\
  --log-folder false
```

(The values displayed above are the default values.

* `-a / --address`: address where the web service will be available

* `-p / --port`: port where the web service will be available

* `--secure/--unsecure`: expose webservice with https
  (or http, if `--unsecure` is selected).

* `-r / --refresh-devices-delay`: interval in seconds
  between two checks of devices connected to usb ports.

* `-l / --log-level`: Possible values:
  `DEBUG` / `INFO` / `SUCCESS` /
  `WARNING` / `ERROR` / `CRITICAL`.

Note:
`DEBUG` will log all the data received, including images received by the printer device.
Use `INFO` level or higher in production outside a debugging situation.

* `-f / --log-folder`: Optional directory that will contains logs.
  If defined, it should exist and be writable.

<a name="usage"></a>

## Usage

Go the home page of the tool, via https://localhost:8069.

If you choose https deployment, you should accept the first time
a security exception in your browser.

<img src="https://gitlab.com/grap-rhone-alpes/odoo-driver/-/raw/main/readme/security_exception.png" />

Pages are available to test connections, see errors, etc.

<img src="https://gitlab.com/grap-rhone-alpes/odoo-driver/-/raw/main/readme/home_page.png" />

<a name="installation"></a>

## Installation

### Run it manually

* install the latest released version:

```shell
pipx install odoo-driver
```

* _or_ Install the latest version:

```shell
pipx install git+https://gitlab.com/grap-rhone-alpes/odoo-driver.git
```

Note: use `--python python3.9` (or higher) option, if your default python environment is under python 3.9 version.

### Run it as a service

This will create a service (via systemd) that will execute odoo-driver in the background and launches at startup.

```shell
wget https://gitlab.com/grap-rhone-alpes/odoo-driver/-/raw/main/debian_install.sh
# (OPTIONAL) adapt the installation script before execution
# adding specific argument in the call of odoo-driver in the .service file
sudo sh debian_install.sh
```

Once installed, you can run the following system command.

```shell
# Get status of the service
sudo systemctl status odoo-driver.service

# Follow the logs of the service
sudo journalctl -fu odoo-driver.service
```

<a name="compatible-plugins"></a>

## Compatible Plugins

<table style="width: 100%;">
    <thead>
        <tr>
            <th>Function</th>
            <th>Protocol</th>
            <th>URL</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Printers</td>
            <td>ESC/POS</td>
            <td>
              <a href="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos">odoo-driver-plugin-printer-escpos</a>
            </td>
        </tr>
        <tr>
            <td>Payment Terminals</td>
            <td>Telium</td>
            <td>
              <a href="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-payment-telium">odoo-driver-plugin-payment-telium</a>
            </td>
        </tr>
        <tr>
            <td>LCD Displays</td>
            <td>ESC/POS</td>
            <td>
              <a href="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-display-escpos">odoo-driver-plugin-display-escpos</a>
            </td>
        </tr>
        <tr>
            <td>Scale</td>
            <td>Toledo</td>
            <td>
              <a href="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-scale-toledo">odoo-driver-plugin-scale-toledo</a>
            </td>
        </tr>
    </tbody>
</table>

<a name="how-to-contribute"></a>

## How to Contribute

### Welcome contributions

* If the project is not translated into your language,
  you can propose a translation.
  (Refer to the ``update_translation.sh`` helper script.)

* If you tested a plugin with a driver that is not referenced in the
  ``usb_devices.py`` file, and if all works correctly, please feel free
  to make an Merge Request, to mark this device as compatible.
  (add an image, make a change in ``usb_devices.py`` and in the ``README.md``
  files)

* If you've encountered a problem or bug that you've solved,
  the patch will be very welcome !

* If you face an issue and you have a budget, you can ask for a quotation
  to try to solve the problem.

### Unwelcome contributions

* Please **do not use** AI to propose Merge Requests and / or write issues.
  Such 'contributions' will be closed.
  (If you don't have time to contribute, don't ask time for review.)

* Please **do not propose** a Merge Request before opening first an issue on gitlab,
  if you want to add new feature, new devices, etc.

### Separate contributions

* If you want to develop a plugin that is not developped, feel free to create
  a new project, named ``odoo-driver-plugin-FUNCTION-PROTOCOL``. you can take
  example on the existing projects.

<a name="development"></a>

## Development

See the dedicated section [in this document](https://gitlab.com/grap-rhone-alpes/odoo-driver/-/blob/main/DEVELOP.md).

<a name="credits"></a>

## Credits

### Authors

* GRAP <https://www.grap.coop>

### Contributors

* Sylvain LE GAL <https://www.grap.coop/>

### Extra authorship

Part of the code in this project comes from the following projects, including:

* [Pywebdriver](https://github.com/pywebdriver/pywebdriver) (AGPL-3.0). Main contributors are:

  * Sylvain LE GAL <https://www.grap.coop/>
  * Sylvain CALADOR <https://akretion.com/>
  * Sébastien BEAU <https://akretion.com/>
  * Carmen BIANCA BAKKER <https://coopiteasy.be/>
  * Alexis DE LATTRE <https://akretion.com/>
  * Quentin DUPONT <https://www.grap.coop/>
  * Pierrick BRUN <https://akretion.com/>
  * Hugues DE KEYZER <https://coopiteasy.be/>

The following projects were also useful and were studied to realize this library.

* [Odoo](https://github.com/odoo/odoo) (AGPL-3.0 up to version 8.0, and then LGPL-3.0 from version 9.0 onwards), by Odoo SA, specially "hw_" modules.

### Images

* [Main Application icon](https://www.flaticon.com/fr/icones-gratuites/hub-usb), by AbtoCreative (Flaticon).

* [Unknown device icon](https://www.flaticon.com/fr/icone-gratuite/inconnu_5978016), by Freepik (Flaticon).
