"""Integration test: agent + FileTransport + emit → JSONL verification."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from bpsai_agent_core import (
    AsyncTransport,
    BaseAgent,
    AgentConfig,
    FileTransport,
    Transport,
)
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

class StubAgent(BaseAgent):
    """Minimal concrete agent for integration testing."""

    async def sense(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.SENSE, passed=True, duration_ms=0.0)

    async def plan(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.PLAN, passed=True, duration_ms=0.0)

    async def execute(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.EXECUTE, passed=True, duration_ms=0.0)

    async def learn(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.LEARN, passed=True, duration_ms=0.0)


# ------------------------------------------------------------------
# Public API surface
# ------------------------------------------------------------------

class TestPublicExports:
    """All observation types must be importable from the top-level package."""

    def test_observation_exported(self) -> None:
        from bpsai_agent_core import Observation  # noqa: F811
        assert Observation is not None

    def test_transport_exported(self) -> None:
        from bpsai_agent_core import Transport  # noqa: F811
        assert Transport is not None

    def test_async_transport_exported(self) -> None:
        from bpsai_agent_core import AsyncTransport  # noqa: F811
        assert AsyncTransport is not None

    def test_file_transport_exported(self) -> None:
        from bpsai_agent_core import FileTransport  # noqa: F811
        assert FileTransport is not None

    def test_all_types_in_dunder_all(self) -> None:
        import bpsai_agent_core
        for name in ("Observation", "Transport", "AsyncTransport", "FileTransport"):
            assert name in bpsai_agent_core.__all__, f"{name} missing from __all__"


# ------------------------------------------------------------------
# Version
# ------------------------------------------------------------------

class TestVersion:
    def test_version_is_0_4_0(self) -> None:
        import bpsai_agent_core
        assert bpsai_agent_core.__version__ == "0.4.0"


# ------------------------------------------------------------------
# End-to-end: create agent → set FileTransport → emit → verify JSONL
# ------------------------------------------------------------------

class TestAgentFileTransportIntegration:
    """Full integration: agent emits observations via FileTransport to JSONL."""

    def test_sync_emit_writes_jsonl(self, tmp_path: Path) -> None:
        log_file = tmp_path / "obs.jsonl"
        transport = FileTransport(log_file)

        agent = StubAgent(AgentConfig(agent_id="test-1", name="IntegrationBot"))
        agent.set_transport(transport)

        agent.emit("step.started", {"step": 1})
        agent.emit("step.completed", {"step": 1, "result": "ok"}, severity="info")

        lines = log_file.read_text().strip().splitlines()
        assert len(lines) == 2

        first = json.loads(lines[0])
        assert first["agent_name"] == "IntegrationBot"
        assert first["type"] == "step.started"
        assert first["payload"] == {"step": 1}
        assert "timestamp" in first

        second = json.loads(lines[1])
        assert second["type"] == "step.completed"
        assert second["payload"]["result"] == "ok"

    @pytest.mark.asyncio
    async def test_async_emit_writes_jsonl(self, tmp_path: Path) -> None:
        log_file = tmp_path / "obs_async.jsonl"
        transport = FileTransport(log_file)

        agent = StubAgent(AgentConfig(agent_id="test-2", name="AsyncBot"))
        agent.set_transport(transport)

        await agent.aemit("tick.done", {"tick": 42})

        lines = log_file.read_text().strip().splitlines()
        assert len(lines) == 1

        record = json.loads(lines[0])
        assert record["agent_name"] == "AsyncBot"
        assert record["type"] == "tick.done"
        assert record["payload"]["tick"] == 42

    def test_no_transport_emit_is_noop(self) -> None:
        agent = StubAgent(AgentConfig(agent_id="test-3", name="NoTransport"))
        # Should not raise
        agent.emit("event", {"data": True})

    def test_file_transport_satisfies_protocols(self, tmp_path: Path) -> None:
        transport = FileTransport(tmp_path / "proto.jsonl")
        assert isinstance(transport, Transport)
        assert isinstance(transport, AsyncTransport)
