"""Tests for PlanClusterer -- plan clustering and selection."""

from __future__ import annotations

import pytest

from bpsai_agent_core.multi_plan import GeneratedPlan
from bpsai_agent_core.plan_cluster import PlanClusterer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _plan(title: str, approach: str, tasks: tuple[str, ...], cx: int = 10) -> GeneratedPlan:
    return GeneratedPlan(title=title, approach=approach, tasks=tasks, estimated_cx=cx)


PLAN_A = _plan("Modular", "Use a modular architecture with plugins", ("T1", "T2", "T3"))
PLAN_B = _plan("Modular v2", "Use a modular plugin-based architecture", ("T1", "T2"))
PLAN_C = _plan("Monolith", "Build a single monolithic service", ("T1",))
PLAN_D = _plan("Microservices", "Use microservices with event-driven comms", ("T1", "T2", "T3", "T4"), cx=20)


# ---------------------------------------------------------------------------
# PlanClusterer construction
# ---------------------------------------------------------------------------

class TestPlanClustererInit:
    def test_default_threshold(self):
        clusterer = PlanClusterer()
        assert clusterer.similarity_threshold == 0.3

    def test_custom_threshold(self):
        clusterer = PlanClusterer(similarity_threshold=0.5)
        assert clusterer.similarity_threshold == 0.5


# ---------------------------------------------------------------------------
# Similarity scoring
# ---------------------------------------------------------------------------

class TestSimilarityScoring:
    def test_identical_plans_score_one(self):
        clusterer = PlanClusterer()
        score = clusterer.similarity(PLAN_A, PLAN_A)
        assert score == 1.0

    def test_similar_plans_high_score(self):
        clusterer = PlanClusterer()
        score = clusterer.similarity(PLAN_A, PLAN_B)
        assert score > 0.3  # above default threshold

    def test_dissimilar_plans_low_score(self):
        clusterer = PlanClusterer()
        score = clusterer.similarity(PLAN_A, PLAN_C)
        # Modular vs monolith should be different enough
        # (but both contain common words, so we just check it's lower)
        score_similar = clusterer.similarity(PLAN_A, PLAN_B)
        assert score < score_similar

    def test_score_is_symmetric(self):
        clusterer = PlanClusterer()
        assert clusterer.similarity(PLAN_A, PLAN_C) == clusterer.similarity(PLAN_C, PLAN_A)

    def test_score_bounded_zero_to_one(self):
        clusterer = PlanClusterer()
        score = clusterer.similarity(PLAN_A, PLAN_D)
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------

class TestPlanClustering:
    def test_cluster_groups_similar_plans(self):
        clusterer = PlanClusterer()
        clusters = clusterer.cluster([PLAN_A, PLAN_B, PLAN_C])
        # A and B should cluster together; C separate
        assert len(clusters) == 2

    def test_single_plan_returns_single_cluster(self):
        clusterer = PlanClusterer()
        clusters = clusterer.cluster([PLAN_A])
        assert len(clusters) == 1
        assert clusters[0] == [PLAN_A]

    def test_empty_input_returns_empty(self):
        clusterer = PlanClusterer()
        clusters = clusterer.cluster([])
        assert clusters == []

    def test_all_identical_returns_single_cluster(self):
        """Degenerate case: all plans identical -> single cluster."""
        same = _plan("Same", "Same approach", ("T1",))
        clusterer = PlanClusterer()
        clusters = clusterer.cluster([same, same, same])
        assert len(clusters) == 1

    def test_output_count_lte_input_count(self):
        clusterer = PlanClusterer()
        plans = [PLAN_A, PLAN_B, PLAN_C, PLAN_D]
        clusters = clusterer.cluster(plans)
        assert len(clusters) <= len(plans)


# ---------------------------------------------------------------------------
# Representative selection
# ---------------------------------------------------------------------------

class TestRepresentativeSelection:
    def test_select_returns_one_per_cluster(self):
        clusterer = PlanClusterer()
        reps = clusterer.select([PLAN_A, PLAN_B, PLAN_C])
        # Should get representatives -- one per cluster
        assert len(reps) >= 1
        assert len(reps) <= 3

    def test_select_picks_highest_coverage(self):
        """Representative should be the plan with most tasks (coverage proxy)."""
        clusterer = PlanClusterer()
        # A has 3 tasks, B has 2 -- A should be selected from their cluster
        reps = clusterer.select([PLAN_A, PLAN_B])
        assert PLAN_A in reps

    def test_select_empty_returns_empty(self):
        clusterer = PlanClusterer()
        assert clusterer.select([]) == []

    def test_select_single_plan(self):
        clusterer = PlanClusterer()
        reps = clusterer.select([PLAN_C])
        assert reps == [PLAN_C]

    def test_all_different_returns_all(self):
        """If no plans are similar enough, each gets its own cluster."""
        clusterer = PlanClusterer(similarity_threshold=0.99)
        plans = [PLAN_A, PLAN_C, PLAN_D]
        reps = clusterer.select(plans)
        assert len(reps) == 3
