"""Tests for PlanSynthesizer -- adversarial plan synthesis."""

from __future__ import annotations

import asyncio
import json

import pytest

from bpsai_agent_core.multi_plan import GeneratedPlan
from bpsai_agent_core.plan_synthesis import PlanSynthesizer, SynthesizedPlan


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _plan(title: str, approach: str, tasks: tuple[str, ...], cx: int = 10) -> GeneratedPlan:
    return GeneratedPlan(title=title, approach=approach, tasks=tasks, estimated_cx=cx)


PLAN_A = _plan("Modular", "Use modular plugins", ("T1", "T2", "T3"), cx=15)
PLAN_B = _plan("Monolith", "Build monolithic service", ("T1",), cx=5)
PLAN_C = _plan("Microservices", "Use microservices", ("T1", "T2", "T3", "T4"), cx=20)


def _synthesis_response(
    title: str = "Hybrid",
    approach: str = "Combine modular + micro",
    tasks: list[str] | None = None,
    cx: int = 12,
    provenance: dict[str, str] | None = None,
) -> str:
    """Build a valid LLM synthesis JSON response."""
    return json.dumps({
        "title": title,
        "approach": approach,
        "tasks": tasks or ["T1", "T2", "T3"],
        "estimated_cx": cx,
        "provenance": provenance or {
            "T1": "Modular",
            "T2": "Modular",
            "T3": "Microservices",
        },
    })


class FakeSynthesisLLM:
    """LLMCall that returns a canned synthesis response."""

    def __init__(self, response: str | None = None):
        self._response = response or _synthesis_response()
        self.call_count = 0

    async def __call__(self, system: str, user: str) -> str:
        self.call_count += 1
        return self._response


class FailingLLM:
    """LLMCall that always raises."""

    async def __call__(self, system: str, user: str) -> str:
        raise RuntimeError("LLM unavailable")


class BadJsonLLM:
    """LLMCall that returns invalid JSON."""

    async def __call__(self, system: str, user: str) -> str:
        return "not valid json"


# ---------------------------------------------------------------------------
# SynthesizedPlan dataclass
# ---------------------------------------------------------------------------

class TestSynthesizedPlan:
    def test_fields(self):
        sp = SynthesizedPlan(
            title="X",
            approach="Y",
            tasks=("T1",),
            estimated_cx=10,
            provenance={"T1": "Plan A"},
        )
        assert sp.title == "X"
        assert sp.provenance == {"T1": "Plan A"}

    def test_provenance_tracks_source(self):
        sp = SynthesizedPlan(
            title="Hybrid",
            approach="Mixed",
            tasks=("T1", "T2"),
            estimated_cx=12,
            provenance={"T1": "Modular", "T2": "Microservices"},
        )
        assert sp.provenance["T1"] == "Modular"
        assert sp.provenance["T2"] == "Microservices"


# ---------------------------------------------------------------------------
# PlanSynthesizer construction
# ---------------------------------------------------------------------------

class TestPlanSynthesizerInit:
    def test_requires_llm(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM())
        assert synth is not None

    def test_default_timeout(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM())
        assert synth.timeout_seconds == 30.0

    def test_custom_timeout(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM(), timeout_seconds=60.0)
        assert synth.timeout_seconds == 60.0


# ---------------------------------------------------------------------------
# Synthesis -- happy path
# ---------------------------------------------------------------------------

class TestPlanSynthesizerSynthesize:
    async def test_returns_synthesized_plan(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM())
        result = await synth.synthesize([PLAN_A, PLAN_B, PLAN_C])
        assert isinstance(result, SynthesizedPlan)

    async def test_synthesized_has_provenance(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM())
        result = await synth.synthesize([PLAN_A, PLAN_B])
        assert isinstance(result.provenance, dict)
        assert len(result.provenance) > 0

    async def test_llm_called_once(self):
        llm = FakeSynthesisLLM()
        synth = PlanSynthesizer(llm=llm)
        await synth.synthesize([PLAN_A, PLAN_B])
        assert llm.call_count == 1

    async def test_single_plan_returned_as_is(self):
        """Single input plan is returned directly without LLM call."""
        llm = FakeSynthesisLLM()
        synth = PlanSynthesizer(llm=llm)
        result = await synth.synthesize([PLAN_A])
        assert result.title == PLAN_A.title
        assert result.approach == PLAN_A.approach
        assert llm.call_count == 0


# ---------------------------------------------------------------------------
# Synthesis -- fallback behavior
# ---------------------------------------------------------------------------

class TestPlanSynthesizerFallback:
    async def test_llm_failure_falls_back_to_best_plan(self):
        """If LLM synthesis fails, return the highest-scoring input plan."""
        synth = PlanSynthesizer(llm=FailingLLM())
        result = await synth.synthesize([PLAN_A, PLAN_B, PLAN_C])
        # Fallback picks plan with most tasks (C has 4)
        assert result.title == PLAN_C.title
        assert result.approach == PLAN_C.approach

    async def test_bad_json_falls_back(self):
        synth = PlanSynthesizer(llm=BadJsonLLM())
        result = await synth.synthesize([PLAN_A, PLAN_B])
        # Fallback picks A (3 tasks) over B (1 task)
        assert result.title == PLAN_A.title

    async def test_fallback_provenance_is_self(self):
        """Fallback plan provenance maps all tasks to the source plan title."""
        synth = PlanSynthesizer(llm=FailingLLM())
        result = await synth.synthesize([PLAN_A, PLAN_B])
        for task in result.tasks:
            assert result.provenance[task] == PLAN_A.title

    async def test_empty_input_raises(self):
        synth = PlanSynthesizer(llm=FakeSynthesisLLM())
        with pytest.raises(ValueError, match="at least one plan"):
            await synth.synthesize([])
