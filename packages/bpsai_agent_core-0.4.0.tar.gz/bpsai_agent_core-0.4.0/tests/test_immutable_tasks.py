"""Tests for immutable tasks on frozen dataclasses."""

from __future__ import annotations

import pytest

from bpsai_agent_core.multi_plan import GeneratedPlan
from bpsai_agent_core.plan_synthesis import SynthesizedPlan


class TestGeneratedPlanImmutableTasks:
    def test_tasks_is_tuple(self):
        plan = GeneratedPlan(
            title="X", approach="Y", tasks=("T1", "T2"), estimated_cx=5
        )
        assert isinstance(plan.tasks, tuple)

    def test_frozen_dataclass_rejects_mutation(self):
        plan = GeneratedPlan(
            title="X", approach="Y", tasks=("T1",), estimated_cx=5
        )
        with pytest.raises(AttributeError):
            plan.tasks = ("T3",)  # type: ignore[misc]


class TestSynthesizedPlanImmutableTasks:
    def test_tasks_is_tuple(self):
        sp = SynthesizedPlan(
            title="X",
            approach="Y",
            tasks=("T1", "T2"),
            estimated_cx=5,
            provenance={"T1": "A"},
        )
        assert isinstance(sp.tasks, tuple)
