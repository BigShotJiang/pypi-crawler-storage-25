"""Tests for MultiPlanGenerator — multi-navigator plan generation."""

from __future__ import annotations

import asyncio
from dataclasses import fields

import pytest

from bpsai_agent_core.multi_plan import GeneratedPlan, MultiPlanGenerator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class FakeLLM:
    """LLMCall that returns a canned JSON plan."""

    def __init__(self, response: str | None = None, delay: float = 0.0):
        self._response = response or (
            '{"title": "Approach A", "approach": "Use modules",'
            ' "tasks": ["T1", "T2"], "estimated_cx": 10}'
        )
        self._delay = delay
        self.call_count = 0

    async def __call__(self, system: str, user: str) -> str:
        self.call_count += 1
        if self._delay:
            await asyncio.sleep(self._delay)
        return self._response


class FailingLLM:
    """LLMCall that raises on invocation."""

    async def __call__(self, system: str, user: str) -> str:
        raise RuntimeError("LLM unavailable")


class BadJsonLLM:
    """LLMCall that returns invalid JSON."""

    async def __call__(self, system: str, user: str) -> str:
        return "This is not JSON at all"


# ---------------------------------------------------------------------------
# GeneratedPlan dataclass
# ---------------------------------------------------------------------------

class TestGeneratedPlan:
    def test_fields_exist(self):
        plan = GeneratedPlan(
            title="My Plan",
            approach="Do the thing",
            tasks=("a", "b"),
            estimated_cx=15,
        )
        assert plan.title == "My Plan"
        assert plan.approach == "Do the thing"
        assert plan.tasks == ("a", "b")
        assert plan.estimated_cx == 15

    def test_is_dataclass(self):
        names = {f.name for f in fields(GeneratedPlan)}
        assert names == {"title", "approach", "tasks", "estimated_cx"}


# ---------------------------------------------------------------------------
# MultiPlanGenerator — construction
# ---------------------------------------------------------------------------

class TestMultiPlanGeneratorInit:
    def test_default_navigator_count(self):
        gen = MultiPlanGenerator(llm=FakeLLM())
        assert gen.navigator_count == 3

    def test_custom_navigator_count(self):
        gen = MultiPlanGenerator(llm=FakeLLM(), navigator_count=5)
        assert gen.navigator_count == 5

    def test_default_timeout(self):
        gen = MultiPlanGenerator(llm=FakeLLM())
        assert gen.timeout_seconds == 30.0

    def test_custom_timeout(self):
        gen = MultiPlanGenerator(llm=FakeLLM(), timeout_seconds=60.0)
        assert gen.timeout_seconds == 60.0

    def test_protocol_based_llm(self):
        """Any object with async __call__(system, user) -> str works."""
        gen = MultiPlanGenerator(llm=FakeLLM())
        assert gen._llm is not None


# ---------------------------------------------------------------------------
# MultiPlanGenerator.generate — happy path
# ---------------------------------------------------------------------------

class TestMultiPlanGeneratorGenerate:
    async def test_returns_n_plans(self):
        gen = MultiPlanGenerator(llm=FakeLLM(), navigator_count=3)
        plans = await gen.generate(
            task_prompt="Build a widget",
            context="We use Python",
        )
        assert len(plans) == 3
        assert all(isinstance(p, GeneratedPlan) for p in plans)

    async def test_each_navigator_receives_prompt(self):
        llm = FakeLLM()
        gen = MultiPlanGenerator(llm=llm, navigator_count=4)
        await gen.generate(task_prompt="Do X", context="Ctx")
        assert llm.call_count == 4

    async def test_plan_fields_parsed(self):
        gen = MultiPlanGenerator(llm=FakeLLM(), navigator_count=1)
        plans = await gen.generate(task_prompt="Build it", context="")
        plan = plans[0]
        assert plan.title == "Approach A"
        assert plan.approach == "Use modules"
        assert plan.tasks == ("T1", "T2")
        assert plan.estimated_cx == 10

    async def test_different_llm_responses(self):
        """Each navigator can produce a different plan."""

        class VariedLLM:
            def __init__(self):
                self._counter = 0

            async def __call__(self, system: str, user: str) -> str:
                self._counter += 1
                return (
                    f'{{"title": "Plan {self._counter}",'
                    f' "approach": "Approach {self._counter}",'
                    f' "tasks": ["T{self._counter}"],'
                    f' "estimated_cx": {self._counter * 10}}}'
                )

        gen = MultiPlanGenerator(llm=VariedLLM(), navigator_count=3)
        plans = await gen.generate(task_prompt="Build", context="")
        titles = {p.title for p in plans}
        assert len(titles) == 3  # all distinct


# ---------------------------------------------------------------------------
# MultiPlanGenerator.generate — timeout handling
# ---------------------------------------------------------------------------

class TestMultiPlanGeneratorTimeout:
    async def test_slow_navigators_killed(self):
        """Navigators exceeding timeout are dropped; fast ones kept."""
        fast_llm = FakeLLM(delay=0.0)
        slow_llm = FakeLLM(delay=5.0)

        call_count = 0

        class MixedLLM:
            async def __call__(self, system: str, user: str) -> str:
                nonlocal call_count
                call_count += 1
                if call_count == 2:
                    return await slow_llm(system, user)
                return await fast_llm(system, user)

        gen = MultiPlanGenerator(llm=MixedLLM(), navigator_count=3, timeout_seconds=0.5)
        plans = await gen.generate(task_prompt="X", context="")
        # At least the fast ones should return
        assert len(plans) >= 2
        assert len(plans) < 3  # slow one killed

    async def test_all_timeout_returns_empty(self):
        gen = MultiPlanGenerator(
            llm=FakeLLM(delay=5.0),
            navigator_count=2,
            timeout_seconds=0.1,
        )
        plans = await gen.generate(task_prompt="X", context="")
        assert plans == []


# ---------------------------------------------------------------------------
# MultiPlanGenerator.generate — error handling
# ---------------------------------------------------------------------------

class TestMultiPlanGeneratorErrors:
    async def test_llm_failure_excluded(self):
        """If one navigator's LLM raises, that plan is dropped."""
        call_count = 0

        class SometimesFailLLM:
            async def __call__(self, system: str, user: str) -> str:
                nonlocal call_count
                call_count += 1
                if call_count == 2:
                    raise RuntimeError("boom")
                return (
                    '{"title": "OK", "approach": "Fine",'
                    ' "tasks": ["T1"], "estimated_cx": 5}'
                )

        gen = MultiPlanGenerator(llm=SometimesFailLLM(), navigator_count=3)
        plans = await gen.generate(task_prompt="X", context="")
        assert len(plans) == 2  # 1 failed, 2 succeeded

    async def test_bad_json_excluded(self):
        gen = MultiPlanGenerator(llm=BadJsonLLM(), navigator_count=2)
        plans = await gen.generate(task_prompt="X", context="")
        assert plans == []

    async def test_all_fail_returns_empty(self):
        gen = MultiPlanGenerator(llm=FailingLLM(), navigator_count=3)
        plans = await gen.generate(task_prompt="X", context="")
        assert plans == []
