"""Tests for license discovery — file reading, missing file, env var override."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from bpsai_agent_core.license_discovery import (
    LicenseDiscoveryError,
    discover_license_id,
)


@pytest.fixture
def license_dir(tmp_path: Path) -> Path:
    """Create a .paircoder dir with a valid license.json."""
    pc_dir = tmp_path / ".paircoder"
    pc_dir.mkdir()
    license_data = {"payload": {"license_id": "lic-test-42"}}
    (pc_dir / "license.json").write_text(json.dumps(license_data), encoding="utf-8")
    return tmp_path


class TestLicenseFileFound:
    """License file found and read correctly."""

    def test_reads_license_id(self, license_dir: Path) -> None:
        result = discover_license_id(home_dir=license_dir)
        assert result == "lic-test-42"


class TestLicenseFileMissing:
    """Missing license file raises LicenseDiscoveryError."""

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(LicenseDiscoveryError, match="No license found"):
            discover_license_id(home_dir=tmp_path)


class TestEnvVarOverride:
    """BPSAI_LICENSE_FILE env var overrides default path."""

    def test_env_var_path_used(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        custom_path = tmp_path / "custom_license.json"
        license_data = {"payload": {"license_id": "lic-env-99"}}
        custom_path.write_text(json.dumps(license_data), encoding="utf-8")

        monkeypatch.setenv("BPSAI_LICENSE_FILE", str(custom_path))
        result = discover_license_id()
        assert result == "lic-env-99"

    def test_env_var_missing_file_raises(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("BPSAI_LICENSE_FILE", str(tmp_path / "nope.json"))
        with pytest.raises(LicenseDiscoveryError, match="No license found"):
            discover_license_id()
