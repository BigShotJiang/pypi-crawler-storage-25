"""Tests for SenseEvent type in agent-core."""

from __future__ import annotations

from bpsai_agent_core.sense_event import SenseEvent, emit_sense_event


class TestSenseEvent:
    """SenseEvent dataclass tests."""

    def test_to_dict_roundtrip(self) -> None:
        event = SenseEvent(
            hook="TestHook", tick=1, timestamp="2026-04-05T00:00:00Z",
            metrics={"count": 42},
        )
        d = event.to_dict()
        restored = SenseEvent.from_dict(d)
        assert restored.hook == "TestHook"
        assert restored.tick == 1
        assert restored.metrics == {"count": 42}

    def test_emit_sense_event_appends(self) -> None:
        class FakeCtx:
            state_snapshot: dict = {}

        ctx = FakeCtx()
        ctx.state_snapshot = {}
        event = SenseEvent(hook="X", tick=1, timestamp="t", metrics={})
        emit_sense_event(ctx, event)
        assert len(ctx.state_snapshot["sense_telemetry"]) == 1

    def test_emit_sense_event_accumulates(self) -> None:
        class FakeCtx:
            state_snapshot: dict = {}

        ctx = FakeCtx()
        ctx.state_snapshot = {}
        for i in range(3):
            emit_sense_event(ctx, SenseEvent(hook="X", tick=i, timestamp="t", metrics={}))
        assert len(ctx.state_snapshot["sense_telemetry"]) == 3
