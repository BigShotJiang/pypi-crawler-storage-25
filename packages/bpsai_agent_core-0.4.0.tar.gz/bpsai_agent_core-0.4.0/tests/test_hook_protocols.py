"""Tests for hook dependency protocols in agent-core."""

from __future__ import annotations

from typing import Any

from bpsai_agent_core.hook_protocols import (
    BriefingSourceProtocol,
    DecisionJournalProtocol,
    HypothesisBacklogProtocol,
    SignalStoreProtocol,
)


class TestHypothesisBacklogProtocol:
    """Protocol for hypothesis backlog access."""

    def test_conforming_class_satisfies_protocol(self) -> None:
        class FakeBacklog:
            def list_by_status(self, status: Any) -> list:
                return []

            def get(self, hyp_id: str) -> Any:
                return None

            def update_confidence(
                self, hyp_id: str, confidence: float, evidence: dict[str, Any],
            ) -> None:
                pass

        assert isinstance(FakeBacklog(), HypothesisBacklogProtocol)

    def test_non_conforming_class_fails(self) -> None:
        class Missing:
            pass

        assert not isinstance(Missing(), HypothesisBacklogProtocol)


class TestSignalStoreProtocol:
    """Protocol for signal store access."""

    def test_conforming_class_satisfies_protocol(self) -> None:
        class FakeStore:
            def list_active(self) -> list:
                return []

            def close(self, signal_id: str, reason: str) -> None:
                pass

        assert isinstance(FakeStore(), SignalStoreProtocol)

    def test_non_conforming_class_fails(self) -> None:
        class Missing:
            pass

        assert not isinstance(Missing(), SignalStoreProtocol)


class TestDecisionJournalProtocol:
    """Protocol for decision journal access."""

    def test_conforming_class_satisfies_protocol(self) -> None:
        class FakeJournal:
            def record(self, decision: Any) -> None:
                pass

        assert isinstance(FakeJournal(), DecisionJournalProtocol)


class TestBriefingSourceProtocol:
    """Protocol for briefing source access."""

    def test_conforming_class_satisfies_protocol(self) -> None:
        class FakeSource:
            def get_latest_briefing(self) -> dict[str, Any] | None:
                return None

        assert isinstance(FakeSource(), BriefingSourceProtocol)
