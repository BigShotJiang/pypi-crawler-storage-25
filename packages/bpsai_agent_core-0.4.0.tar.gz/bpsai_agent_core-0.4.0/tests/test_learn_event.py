"""Tests for LearnEvent type in agent-core."""

from __future__ import annotations

from bpsai_agent_core.learn_event import LearnEvent, emit_learn_event


class TestLearnEvent:
    """LearnEvent dataclass tests."""

    def test_to_dict_roundtrip(self) -> None:
        event = LearnEvent(
            hook="TestHook", tick=1, timestamp="2026-04-05T00:00:00Z",
            metrics={"updated": 3},
        )
        d = event.to_dict()
        restored = LearnEvent.from_dict(d)
        assert restored.hook == "TestHook"
        assert restored.tick == 1
        assert restored.metrics == {"updated": 3}

    def test_emit_learn_event_appends(self) -> None:
        class FakeCtx:
            state_snapshot: dict = {}

        ctx = FakeCtx()
        ctx.state_snapshot = {}
        event = LearnEvent(hook="X", tick=1, timestamp="t", metrics={})
        emit_learn_event(ctx, event)
        assert len(ctx.state_snapshot["learn_telemetry"]) == 1

    def test_emit_learn_event_accumulates(self) -> None:
        class FakeCtx:
            state_snapshot: dict = {}

        ctx = FakeCtx()
        ctx.state_snapshot = {}
        for i in range(3):
            emit_learn_event(ctx, LearnEvent(hook="X", tick=i, timestamp="t", metrics={}))
        assert len(ctx.state_snapshot["learn_telemetry"]) == 3
