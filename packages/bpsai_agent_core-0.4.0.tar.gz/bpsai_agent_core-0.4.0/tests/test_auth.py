"""Tests for TokenManager — JWT caching, expiry, and failure handling."""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from bpsai_agent_core.auth import TokenManager


@pytest.fixture
def token_manager() -> TokenManager:
    return TokenManager(
        paircoder_api_url="https://api.example.com",
        license_id="lic-123",
        operator="test-op",
    )


class TestTokenCaching:
    """Second call returns cached token without HTTP."""

    async def test_cached_token_returned_without_http(
        self, token_manager: TokenManager
    ) -> None:
        future_ts = time.time() + 3600
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"token": "jwt-abc", "expires_at": future_ts}
        mock_resp.raise_for_status = MagicMock()

        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(return_value=mock_resp)

        first = await token_manager.get_token()
        second = await token_manager.get_token()

        assert first == "jwt-abc"
        assert second == "jwt-abc"
        # HTTP called only once — second call uses cache
        assert token_manager._http.post.call_count == 1


class TestTokenExpiry:
    """Expired token triggers a fresh fetch."""

    async def test_expired_token_triggers_refresh(
        self, token_manager: TokenManager
    ) -> None:
        # Seed with an already-expired token
        token_manager._token = "old-jwt"
        token_manager._expires_at = time.time() - 10  # already expired

        future_ts = time.time() + 3600
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"token": "new-jwt", "expires_at": future_ts}
        mock_resp.raise_for_status = MagicMock()

        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(return_value=mock_resp)

        result = await token_manager.get_token()
        assert result == "new-jwt"
        assert token_manager._http.post.call_count == 1

    async def test_token_near_expiry_triggers_refresh(
        self, token_manager: TokenManager
    ) -> None:
        """Token within 60s of expiry should be refreshed."""
        token_manager._token = "old-jwt"
        token_manager._expires_at = time.time() + 30  # within 60s buffer

        future_ts = time.time() + 3600
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"token": "refreshed-jwt", "expires_at": future_ts}
        mock_resp.raise_for_status = MagicMock()

        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(return_value=mock_resp)

        result = await token_manager.get_token()
        assert result == "refreshed-jwt"


class TestFailureHandling:
    """HTTP errors return None, never crash."""

    async def test_http_error_returns_none(self, token_manager: TokenManager) -> None:
        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(
            side_effect=httpx.ConnectError("connection refused")
        )

        result = await token_manager.get_token()
        assert result is None

    async def test_bad_json_returns_none(self, token_manager: TokenManager) -> None:
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"unexpected": "shape"}

        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(return_value=mock_resp)

        result = await token_manager.get_token()
        assert result is None

    async def test_failure_clears_cached_token(
        self, token_manager: TokenManager
    ) -> None:
        """After failure, cached token and expiry are cleared."""
        token_manager._token = "stale"
        token_manager._expires_at = time.time() - 100

        token_manager._http = AsyncMock()
        token_manager._http.post = AsyncMock(
            side_effect=httpx.ConnectError("down")
        )

        await token_manager.get_token()
        assert token_manager._token is None
        assert token_manager._expires_at == 0.0
