"""Plan clustering and representative selection.

Groups generated plans by approach similarity using text-based scoring
(no embedding model required). Selects the highest-coverage representative
from each cluster.
"""

from __future__ import annotations

from bpsai_agent_core.multi_plan import GeneratedPlan


class PlanClusterer:
    """Cluster plans by approach similarity and select representatives.

    Uses Jaccard similarity on word tokens from title + approach text.
    Plans above the similarity threshold are grouped together.
    """

    def __init__(self, *, similarity_threshold: float = 0.3) -> None:
        self.similarity_threshold = similarity_threshold

    def similarity(self, a: GeneratedPlan, b: GeneratedPlan) -> float:
        """Compute text-based similarity between two plans (0.0 to 1.0).

        Uses Jaccard index over lowercased word tokens from title + approach.
        """
        tokens_a = _tokenize(a)
        tokens_b = _tokenize(b)
        if not tokens_a and not tokens_b:
            return 1.0
        if not tokens_a or not tokens_b:
            return 0.0
        intersection = tokens_a & tokens_b
        union = tokens_a | tokens_b
        return len(intersection) / len(union)

    def cluster(self, plans: list[GeneratedPlan]) -> list[list[GeneratedPlan]]:
        """Group plans into clusters by approach similarity.

        Uses single-linkage: a plan joins the first cluster where it
        exceeds the similarity threshold with any existing member.
        """
        if not plans:
            return []

        clusters: list[list[GeneratedPlan]] = [[plans[0]]]
        for plan in plans[1:]:
            placed = False
            for group in clusters:
                if any(
                    self.similarity(plan, member) >= self.similarity_threshold
                    for member in group
                ):
                    group.append(plan)
                    placed = True
                    break
            if not placed:
                clusters.append([plan])
        return clusters

    def select(self, plans: list[GeneratedPlan]) -> list[GeneratedPlan]:
        """Cluster plans and return the highest-coverage representative per cluster.

        Coverage is proxied by task count (more tasks = higher coverage).
        """
        clusters = self.cluster(plans)
        return [_best_representative(group) for group in clusters]


def _tokenize(plan: GeneratedPlan) -> set[str]:
    """Extract lowercased word tokens from a plan's title and approach."""
    text = f"{plan.title} {plan.approach}"
    return set(text.lower().split())


def _best_representative(group: list[GeneratedPlan]) -> GeneratedPlan:
    """Pick the plan with the most tasks (coverage proxy)."""
    return max(group, key=lambda p: len(p.tasks))
