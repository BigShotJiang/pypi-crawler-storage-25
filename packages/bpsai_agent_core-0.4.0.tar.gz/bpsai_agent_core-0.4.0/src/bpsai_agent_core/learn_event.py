"""LearnEvent -- structured observability event emitted by LEARN hooks.

Each LEARN hook emits a LearnEvent into ``context.state_snapshot["learn_telemetry"]``
so that learning reasoning is observable and auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LearnEvent:
    """Structured telemetry event from a LEARN phase hook execution."""

    hook: str
    tick: int
    timestamp: str
    metrics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "hook": self.hook,
            "tick": self.tick,
            "timestamp": self.timestamp,
            "metrics": dict(self.metrics),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LearnEvent:
        """Construct from a dict."""
        return cls(
            hook=str(data["hook"]),
            tick=int(data["tick"]),
            timestamp=str(data["timestamp"]),
            metrics=dict(data.get("metrics", {})),
        )


def emit_learn_event(context: Any, event: LearnEvent) -> None:
    """Append a LearnEvent to the context's learn_telemetry list."""
    telemetry = context.state_snapshot.setdefault("learn_telemetry", [])
    telemetry.append(event.to_dict())
