"""Multi-navigator plan generation.

Spawns N concurrent navigator sessions to produce diverse plan approaches
for a given task. Each navigator independently calls an LLM to generate
a structured plan. Stragglers are killed after a configurable timeout.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Any

from bpsai_agent_core.llm import LLMCall

_SYSTEM_PROMPT = (
    "You are a navigator producing an implementation plan. "
    "Respond with ONLY a JSON object containing these fields:\n"
    '  "title": short plan title,\n'
    '  "approach": description of the architectural approach,\n'
    '  "tasks": list of task description strings,\n'
    '  "estimated_cx": integer complexity estimate\n'
    "Do not include any text outside the JSON object."
)


@dataclass(frozen=True, slots=True)
class GeneratedPlan:
    """A single plan produced by one navigator session."""

    title: str
    approach: str
    tasks: tuple[str, ...]
    estimated_cx: int


class MultiPlanGenerator:
    """Spawn N navigators to produce diverse plan approaches.

    Each navigator independently receives the same task prompt and context,
    calls the injected LLM, and returns a structured plan. Plans from
    navigators that time out or fail are silently dropped.
    """

    def __init__(
        self,
        *,
        llm: LLMCall,
        navigator_count: int = 3,
        timeout_seconds: float = 30.0,
    ) -> None:
        self._llm = llm
        self.navigator_count = navigator_count
        self.timeout_seconds = timeout_seconds

    async def generate(
        self,
        task_prompt: str,
        context: str,
    ) -> list[GeneratedPlan]:
        """Run N navigators concurrently and collect their plans."""
        tasks = [
            self._run_navigator(task_prompt, context)
            for _ in range(self.navigator_count)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        plans: list[GeneratedPlan] = []
        for result in results:
            if isinstance(result, GeneratedPlan):
                plans.append(result)
        return plans

    async def _run_navigator(
        self,
        task_prompt: str,
        context: str,
    ) -> GeneratedPlan:
        """Single navigator session with timeout."""
        user_msg = f"Task: {task_prompt}"
        if context:
            user_msg += f"\n\nContext: {context}"

        raw = await asyncio.wait_for(
            self._llm(_SYSTEM_PROMPT, user_msg),
            timeout=self.timeout_seconds,
        )
        return _parse_plan(raw)


def _parse_plan(raw: str) -> GeneratedPlan:
    """Parse LLM JSON response into a GeneratedPlan."""
    data: dict[str, Any] = json.loads(raw)
    return GeneratedPlan(
        title=data["title"],
        approach=data["approach"],
        tasks=tuple(data["tasks"]),
        estimated_cx=int(data["estimated_cx"]),
    )
