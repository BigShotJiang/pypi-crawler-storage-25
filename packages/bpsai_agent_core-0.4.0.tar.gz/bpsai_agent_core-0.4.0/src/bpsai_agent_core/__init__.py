"""BPS AI Agent Core -- base package for the agent ecosystem."""

__version__ = "0.4.0"

from bpsai_agent_core.agent import AgentConfig, BaseAgent
from bpsai_agent_core.auth import TokenManager
from bpsai_agent_core.card import AgentCapabilities, AgentCard, AgentProvider, AgentSkill
from bpsai_agent_core.enforcement import (
    AsyncEnforcementRule,
    EnforcementResult,
    EnforcementRule,
)
from bpsai_agent_core.file_transport import FileTransport
from bpsai_agent_core.license_discovery import LicenseDiscoveryError, discover_license_id
from bpsai_agent_core.hook_protocols import (
    BriefingSourceProtocol,
    DecisionJournalProtocol,
    HypothesisBacklogProtocol,
    SignalStoreProtocol,
)
from bpsai_agent_core.hooks import PhaseHook, PhaseRegistry
from bpsai_agent_core.learn_event import LearnEvent, emit_learn_event
from bpsai_agent_core.llm import LLMCall
from bpsai_agent_core.loop import LoopRunner
from bpsai_agent_core.multi_plan import GeneratedPlan, MultiPlanGenerator
from bpsai_agent_core.observation import Observation
from bpsai_agent_core.plan_cluster import PlanClusterer
from bpsai_agent_core.plan_synthesis import PlanSynthesizer, SynthesizedPlan
from bpsai_agent_core.quality import QualityObservation, QualityProfile
from bpsai_agent_core.sense_event import SenseEvent, emit_sense_event
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult
from bpsai_agent_core.transport import AsyncTransport, Transport

__all__ = [
    "AgentCapabilities",
    "AgentCard",
    "AgentConfig",
    "AgentProvider",
    "AgentSkill",
    "AsyncEnforcementRule",
    "AsyncTransport",
    "BaseAgent",
    "LicenseDiscoveryError",
    "BriefingSourceProtocol",
    "DecisionJournalProtocol",
    "EnforcementResult",
    "EnforcementRule",
    "FileTransport",
    "GeneratedPlan",
    "HypothesisBacklogProtocol",
    "LearnEvent",
    "LLMCall",
    "LoopRunner",
    "MultiPlanGenerator",
    "Observation",
    "Phase",
    "PhaseHook",
    "PhaseRegistry",
    "PhaseResult",
    "PlanClusterer",
    "PlanSynthesizer",
    "QualityObservation",
    "QualityProfile",
    "SenseEvent",
    "SignalStoreProtocol",
    "SynthesizedPlan",
    "TickContext",
    "TickResult",
    "TokenManager",
    "Transport",
    "discover_license_id",
    "emit_learn_event",
    "emit_sense_event",
]
