"""Protocol interfaces for hook dependencies.

Hooks in any repo can depend on these protocols instead of concrete
framework implementations. Each protocol captures the minimal surface
area a hook actually calls.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class HypothesisBacklogProtocol(Protocol):
    """Minimal interface for hypothesis backlog access.

    Used by: HypothesisScanner (SENSE), HypothesisUpdater (LEARN).
    """

    def list_by_status(self, status: Any) -> list: ...
    def get(self, hyp_id: str) -> Any: ...
    def update_confidence(
        self, hyp_id: str, confidence: float, evidence: dict[str, Any],
    ) -> None: ...


@runtime_checkable
class SignalStoreProtocol(Protocol):
    """Minimal interface for signal store access.

    Used by: SignalStoreReader (SENSE), SignalCloser (LEARN).
    """

    def list_active(self) -> list: ...
    def close(self, signal_id: str, reason: str) -> None: ...


@runtime_checkable
class DecisionJournalProtocol(Protocol):
    """Minimal interface for decision journal recording.

    Used by: OutcomeRecorder (LEARN).
    """

    def record(self, decision: Any) -> None: ...


@runtime_checkable
class BriefingSourceProtocol(Protocol):
    """Minimal interface for reading briefings.

    Used by: BriefingReader (SENSE).
    """

    def get_latest_briefing(self) -> dict[str, Any] | None: ...
