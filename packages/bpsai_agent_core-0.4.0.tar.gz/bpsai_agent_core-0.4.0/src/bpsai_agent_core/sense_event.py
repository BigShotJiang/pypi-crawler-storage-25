"""SenseEvent -- structured observability event emitted by SENSE hooks.

Each SENSE hook emits a SenseEvent into ``context.state_snapshot["sense_telemetry"]``
so that sensing reasoning is observable and auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SenseEvent:
    """Structured telemetry event from a SENSE phase hook execution."""

    hook: str
    tick: int
    timestamp: str
    metrics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "hook": self.hook,
            "tick": self.tick,
            "timestamp": self.timestamp,
            "metrics": dict(self.metrics),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SenseEvent:
        """Construct from a dict."""
        return cls(
            hook=str(data["hook"]),
            tick=int(data["tick"]),
            timestamp=str(data["timestamp"]),
            metrics=dict(data.get("metrics", {})),
        )


def emit_sense_event(context: Any, event: SenseEvent) -> None:
    """Append a SenseEvent to the context's sense_telemetry list."""
    telemetry = context.state_snapshot.setdefault("sense_telemetry", [])
    telemetry.append(event.to_dict())
