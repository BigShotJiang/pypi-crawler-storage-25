"""Attention variants (GQA, MHA, CrossAttention) with KV cache support."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from torchblocks.registry import register
from torchblocks.position import apply_rotary_emb


@register("attention", "gqa")
class GroupedQueryAttention(nn.Module):
    """Grouped Query Attention (Ainslie et al., 2023).

    When ``num_kv_heads < num_heads``, K/V projections are smaller,
    reducing KV cache size proportionally.
    """

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        assert d_model % num_heads == 0
        assert num_heads % num_kv_heads == 0

        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = d_model // num_heads
        self.num_groups = num_heads // num_kv_heads

        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout_p = dropout

    def _expand_kv(self, kv: torch.Tensor) -> torch.Tensor:
        if self.num_groups == 1:
            return kv
        batch, num_kv, seq_len, head_dim = kv.shape
        return (
            kv.unsqueeze(2)
            .expand(batch, num_kv, self.num_groups, seq_len, head_dim)
            .reshape(batch, self.num_heads, seq_len, head_dim)
        )

    def forward(
        self,
        x: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
        kv_cache: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        batch_size, seq_len, _ = x.shape

        query = self.q_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        key = self.k_proj(x).view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        value = self.v_proj(x).view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        query = apply_rotary_emb(query, rope_cos, rope_sin)
        key = apply_rotary_emb(key, rope_cos, rope_sin)

        if kv_cache is not None:
            key = torch.cat([kv_cache[0], key], dim=2)
            value = torch.cat([kv_cache[1], value], dim=2)
        new_cache = (key, value)

        key = self._expand_kv(key)
        value = self._expand_kv(value)

        output = F.scaled_dot_product_attention(
            query, key, value,
            attn_mask=attn_mask,
            dropout_p=self.dropout_p if self.training else 0.0,
        )
        output = output.transpose(1, 2).reshape(batch_size, seq_len, -1)
        return self.out_proj(output), new_cache


@register("attention", "mha")
class MultiHeadAttention(nn.Module):
    """Standard MHA — GQA with ``num_kv_heads == num_heads``."""

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.gqa = GroupedQueryAttention(d_model, num_heads, num_heads, dropout)

    def forward(
        self,
        x: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
        kv_cache: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        return self.gqa(x, rope_cos, rope_sin, attn_mask, kv_cache)


@register("attention", "cross")
class CrossAttention(nn.Module):
    """Cross-attention over encoder memory. No RoPE applied."""

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        assert d_model % num_heads == 0
        assert num_heads % num_kv_heads == 0

        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = d_model // num_heads
        self.num_groups = num_heads // num_kv_heads

        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(d_model, num_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout_p = dropout

    def _expand_kv(self, kv: torch.Tensor) -> torch.Tensor:
        if self.num_groups == 1:
            return kv
        batch, num_kv, seq_len, head_dim = kv.shape
        return (
            kv.unsqueeze(2)
            .expand(batch, num_kv, self.num_groups, seq_len, head_dim)
            .reshape(batch, self.num_heads, seq_len, head_dim)
        )

    def forward(
        self,
        x: torch.Tensor,
        memory: torch.Tensor,
        attn_mask: torch.Tensor | None = None,
        kv_cache: tuple[torch.Tensor, torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        batch_size, tgt_len, _ = x.shape
        _, src_len, _ = memory.shape

        query = self.q_proj(x).view(batch_size, tgt_len, self.num_heads, self.head_dim).transpose(1, 2)

        if kv_cache is not None:
            key, value = kv_cache
        else:
            key = self.k_proj(memory).view(batch_size, src_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
            value = self.v_proj(memory).view(batch_size, src_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        new_cache = (key, value)

        key = self._expand_kv(key)
        value = self._expand_kv(value)

        output = F.scaled_dot_product_attention(
            query, key, value,
            attn_mask=attn_mask,
            dropout_p=self.dropout_p if self.training else 0.0,
        )
        output = output.transpose(1, 2).reshape(batch_size, tgt_len, -1)
        return self.out_proj(output), new_cache
