"""Module registry: ``@register(category, name)`` / ``get(category, name)``."""

from __future__ import annotations

from typing import Type

import torch.nn as nn


_REGISTRIES: dict[str, dict[str, Type[nn.Module]]] = {}


def register(category: str, name: str):
    """Class decorator that registers *cls* under *category*/*name*."""
    def decorator(cls: Type[nn.Module]) -> Type[nn.Module]:
        if category not in _REGISTRIES:
            _REGISTRIES[category] = {}
        if name in _REGISTRIES[category]:
            raise ValueError(f"'{name}' already registered in '{category}'")
        _REGISTRIES[category][name] = cls
        return cls
    return decorator


def get(category: str, name: str) -> Type[nn.Module]:
    if category not in _REGISTRIES:
        raise KeyError(f"Category '{category}' not found. Available: {list(_REGISTRIES)}")
    registry = _REGISTRIES[category]
    if name not in registry:
        raise KeyError(f"Module '{name}' not found in '{category}'. Available: {list(registry)}")
    return registry[name]


def list_modules(category: str | None = None) -> dict[str, list[str]]:
    if category is not None:
        return {category: list(_REGISTRIES.get(category, {}))}
    return {cat: list(modules) for cat, modules in _REGISTRIES.items()}
