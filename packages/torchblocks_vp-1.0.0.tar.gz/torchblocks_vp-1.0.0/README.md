# torchblocks

Reusable Transformer building blocks with a plugin registry system.

## Installation

```bash
pip install torchblocks
```

Requires Python >= 3.14 and PyTorch >= 2.0.

## Features

- **Registry system** — `@register(category, name)` decorator + `get(category, name)` lookup
- **Attention** — Grouped Query Attention (GQA), Multi-Head Attention (MHA), Cross-Attention with KV cache
- **Feed-forward** — SwiGLU, GeLU variants
- **Normalization** — RMSNorm, LayerNorm
- **Positional encoding** — Rotary Position Embeddings (RoPE)
- **Convolution** — Conformer-style depthwise separable conv1d
- **Adapters** — Language-conditioned, bottleneck, and no-op adapters

## Quick Start

```python
import torchblocks

# List all registered modules
print(torchblocks.list_modules())

# Get a specific module class
GQA = torchblocks.get("attention", "gqa")
attention = GQA(d_model=512, num_heads=8, num_kv_heads=2)

# Register your own module
@torchblocks.register("feedforward", "my_custom_ff")
class MyFeedForward(torch.nn.Module):
    ...
```

## License

See LICENSE file in the repository root.
