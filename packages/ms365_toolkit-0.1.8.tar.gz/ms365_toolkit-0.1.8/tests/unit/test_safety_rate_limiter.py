from __future__ import annotations

import sqlite3
from dataclasses import replace
from datetime import UTC, datetime

from ms365_toolkit.config.loader import SafetyRateLimits
from ms365_toolkit.safety.gate import SafetyResult
from ms365_toolkit.safety.rate_limiter import RateLimiter


def test_rate_limiter_enforces_hourly_limit(tmp_path) -> None:
    limiter = RateLimiter(
        profile="default",
        rate_limits=_limits(send_email_per_hour=2),
        path=tmp_path / "rate_limit.db",
    )
    now = datetime(2026, 4, 1, 12, tzinfo=UTC)

    assert limiter.check("send_email", now=now) == SafetyResult(True, "rate_limit_ok")
    assert limiter.check("send_email", now=now) == SafetyResult(True, "rate_limit_ok")
    assert limiter.check("send_email", now=now) == SafetyResult(False, "rate_limit_exceeded")


def test_rate_limiter_deduplicates_same_operation_id(tmp_path) -> None:
    limiter = RateLimiter(
        profile="default",
        rate_limits=_limits(send_email_per_hour=1),
        path=tmp_path / "rate_limit.db",
    )
    now = datetime(2026, 4, 1, 12, tzinfo=UTC)

    assert limiter.check("send_email", now=now, operation_id="op-1") == SafetyResult(
        True,
        "rate_limit_ok",
    )
    assert limiter.check("send_email", now=now, operation_id="op-1") == SafetyResult(
        True,
        "rate_limit_ok",
    )
    assert limiter.check("send_email", now=now, operation_id="op-2") == SafetyResult(
        False,
        "rate_limit_exceeded",
    )


def test_rate_limiter_fails_closed_when_db_is_unavailable(tmp_path) -> None:
    limiter = RateLimiter(
        profile="default",
        rate_limits=_limits(),
        path=tmp_path / "rate_limit.db",
        connect=lambda path: (_ for _ in ()).throw(sqlite3.OperationalError("database is locked")),
    )

    assert limiter.check("send_email") == SafetyResult(False, "rate_limit_unavailable")


def _limits(**overrides: int) -> SafetyRateLimits:
    base = SafetyRateLimits(
        send_email_per_hour=5,
        send_email_per_day=20,
        draft_email_per_hour=10,
        draft_email_per_day=30,
        reply_email_per_hour=5,
        reply_email_per_day=20,
        forward_email_per_hour=5,
        forward_email_per_day=20,
        move_email_per_hour=20,
        flag_email_per_hour=50,
        create_event_per_hour=5,
        create_event_per_day=20,
        update_event_per_hour=10,
        respond_event_per_hour=10,
    )
    return replace(base, **overrides)

