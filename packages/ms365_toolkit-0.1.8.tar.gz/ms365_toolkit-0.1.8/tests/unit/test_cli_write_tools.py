from __future__ import annotations

from argparse import Namespace
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ms365_toolkit.cli.write_tools import (
    create_email_draft_command,
    create_reply_draft_command,
    send_email_draft_command,
)
from ms365_toolkit.client.exceptions import SafetyDeniedError
from ms365_toolkit.models.email import EmailDraft

if TYPE_CHECKING:
    import pytest


def test_create_email_draft_command_prints_draft(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake_client = _FakeWriteEmailClient()
    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: fake_client,
    )

    exit_code = create_email_draft_command(
        Namespace(
            profile="default",
            to=["to@example.com"],
            cc=["cc@example.com"],
            bcc=None,
            reply_to=None,
            subject="Hello",
            body="<p>Hello</p>",
            body_file=None,
            importance="high",
        ),
        _config(),
    )

    assert exit_code == 0
    assert fake_client.calls == [
        (
            "create",
            {
                "to": ("to@example.com",),
                "cc": ("cc@example.com",),
                "bcc": (),
                "subject": "Hello",
                "body": "<p>Hello</p>",
                "reply_to": (),
                "importance": "high",
            },
        )
    ]
    output = capsys.readouterr().out
    assert "Draft ID: draft-1" in output
    assert "Content Hash: hash-1" in output


def test_create_reply_draft_command_reads_body_file(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path,
) -> None:
    body_file = tmp_path / "reply.html"
    body_file.write_text("<p>Reply</p>", encoding="utf-8")
    fake_client = _FakeWriteEmailClient()
    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: fake_client,
    )

    exit_code = create_reply_draft_command(
        Namespace(
            profile="default",
            message_id="msg-1",
            body=None,
            body_file=str(body_file),
            importance=None,
        ),
        _config(),
    )

    assert exit_code == 0
    assert fake_client.calls == [
        (
            "reply",
            {
                "message_id": "msg-1",
                "body": "<p>Reply</p>",
                "importance": None,
            },
        )
    ]
    output = capsys.readouterr().out
    assert "Draft ID: draft-1" in output


def test_send_email_draft_command_prints_confirmation(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake_client = _FakeWriteEmailClient()
    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: fake_client,
    )

    exit_code = send_email_draft_command(
        Namespace(profile="default", draft_id="draft-1", content_hash="hash-1"),
        _config(),
    )

    assert exit_code == 0
    assert fake_client.calls == [
        (
            "send",
            {
                "draft_id": "draft-1",
                "content_hash": "hash-1",
            },
        )
    ]
    output = capsys.readouterr().out
    assert "Sent draft draft-1" in output


def test_send_email_draft_command_strips_values(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake_client = _FakeWriteEmailClient()
    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: fake_client,
    )

    exit_code = send_email_draft_command(
        Namespace(profile="default", draft_id=" draft-1 ", content_hash=" hash-1 "),
        _config(),
    )

    assert exit_code == 0
    assert fake_client.calls == [
        (
            "send",
            {
                "draft_id": "draft-1",
                "content_hash": "hash-1",
            },
        )
    ]
    output = capsys.readouterr().out
    assert "Sent draft draft-1" in output


def test_create_email_draft_command_prints_safety_error_to_stderr(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    class DenyingClient(_FakeWriteEmailClient):
        def create_email_draft(self, **kwargs):
            raise SafetyDeniedError(
                "allowlist_denied",
                "draft_email",
                "recipient outside domain allowlist",
            )

    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: DenyingClient(),
    )

    exit_code = create_email_draft_command(
        Namespace(
            profile="default",
            to=["outside@example.net"],
            cc=None,
            bcc=None,
            reply_to=None,
            subject="Hello",
            body="<p>Hello</p>",
            body_file=None,
            importance="normal",
        ),
        _config(),
    )

    assert exit_code == 1
    assert "Safety denied for draft_email" in capsys.readouterr().err


def test_create_email_draft_command_rejects_blank_email_values(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake_client = _FakeWriteEmailClient()
    monkeypatch.setattr(
        "ms365_toolkit.cli.write_tools.build_write_email_client",
        lambda config, profile: fake_client,
    )

    exit_code = create_email_draft_command(
        Namespace(
            profile="default",
            to=["to@example.com", "   "],
            cc=None,
            bcc=None,
            reply_to=None,
            subject="Hello",
            body="<p>Hello</p>",
            body_file=None,
            importance="normal",
        ),
        _config(),
    )

    assert exit_code == 1
    assert fake_client.calls == []
    assert "email lists must not contain empty values" in capsys.readouterr().err


class _FakeWriteEmailClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, object]]] = []

    def create_email_draft(self, **kwargs) -> EmailDraft:
        self.calls.append(("create", kwargs))
        return _draft()

    def create_reply_draft(
        self,
        message_id: str,
        *,
        body: str,
        importance: str | None = None,
    ) -> EmailDraft:
        self.calls.append(
            (
                "reply",
                {
                    "message_id": message_id,
                    "body": body,
                    "importance": importance,
                },
            )
        )
        return _draft()

    def send_email_draft(self, draft_id: str, *, content_hash: str) -> None:
        self.calls.append(
            (
                "send",
                {
                    "draft_id": draft_id,
                    "content_hash": content_hash,
                },
            )
        )


def _draft() -> EmailDraft:
    return EmailDraft(
        draft_id="draft-1",
        content_hash="hash-1",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        subject="Hello",
        body="<p>Hello</p>",
        attachments=(),
        reply_to=(),
        importance="normal",
        created_at=datetime(2026, 4, 12, 10, 0, tzinfo=UTC),
    )


def _config():
    class StubAuth:
        tenant_id = "tenant"
        client_id = "client"

    class StubUser:
        endpoint = "me"
        user_principal_name = "owner@example.com"
        timezone = "UTC"

    class StubSafety:
        domain_allowlist = ("example.com",)

    class StubVip:
        emails = ()
        domains = ()

    class StubIntelligence:
        critical_keywords = ()
        noise_keywords = ()
        action_keywords = ()

    class StubConfig:
        auth = StubAuth()
        user = StubUser()
        safety = StubSafety()
        vip = StubVip()
        intelligence = StubIntelligence()

    return StubConfig()
