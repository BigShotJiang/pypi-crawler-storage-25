from __future__ import annotations

from ms365_toolkit.safety.dialog import can_show_dialog, show_confirmation_dialog
from ms365_toolkit.safety.gate import DialogPreview, SafetyResult


def test_can_show_dialog_returns_false_outside_macos() -> None:
    assert can_show_dialog(platform="linux") is False


def test_show_confirmation_dialog_denies_when_preflight_fails() -> None:
    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="  hello \n world "),
        platform="linux",
    )

    assert result == SafetyResult(False, "dialog_preflight_failed")


def test_show_confirmation_dialog_allows_when_runner_succeeds() -> None:
    commands: list[list[str]] = []

    def runner(command: list[str]) -> int:
        commands.append(command)
        return 0

    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="  hello \n world "),
        platform="darwin",
        session_check=lambda: True,
        smoke_test=lambda: True,
        runner=runner,
    )

    assert result == SafetyResult(True, "dialog_approved")
    assert any("hello world" in part for part in commands[0])


def test_show_confirmation_dialog_denies_when_user_cancels() -> None:
    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="Body"),
        platform="darwin",
        session_check=lambda: True,
        smoke_test=lambda: True,
        runner=lambda command: 1,
    )

    assert result == SafetyResult(False, "dialog_cancelled")

