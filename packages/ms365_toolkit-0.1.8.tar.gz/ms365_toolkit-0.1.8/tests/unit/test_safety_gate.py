from __future__ import annotations

from datetime import UTC, datetime

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.safety.audit import AuditLogger
from ms365_toolkit.safety.canonical import compute_hash
from ms365_toolkit.safety.folder_allowlist import FolderAllowlistChecker
from ms365_toolkit.safety.gate import (
    ConfiguredSafetyGate,
    DialogPreview,
    SafetyResult,
    WriteOperation,
)
from ms365_toolkit.safety.rate_limiter import RateLimiter


def test_safety_gate_allows_operation_and_audits_it(tmp_path) -> None:
    config = _config(tmp_path, domain_allowlist='["example.com"]')
    gate = _gate(tmp_path, config, dialog=lambda preview: SafetyResult(True, "dialog_approved"))
    canonical_payload = '{"subject":"hello"}'

    operation = WriteOperation(
        tool_name="send_email",
        payload_hash=compute_hash(canonical_payload),
        canonical_payload=canonical_payload,
        recipients=("user@example.com",),
        dialog_preview=DialogPreview(title="Confirm", body="hello"),
        message_id="msg-1",
    )

    assert gate.full_check(operation) == SafetyResult(True, "safety_check_passed")
    assert '"action": "allow"' in (tmp_path / "audit.jsonl").read_text(encoding="utf-8")


def test_safety_gate_denies_on_domain_check(tmp_path) -> None:
    config = _config(tmp_path, domain_allowlist='["example.com"]')
    gate = _gate(tmp_path, config, dialog=lambda preview: SafetyResult(True, "dialog_approved"))

    result = gate.full_check(
        WriteOperation(
            tool_name="send_email",
            payload_hash=compute_hash('{"subject":"hello"}'),
            canonical_payload='{"subject":"hello"}',
            recipients=("user@outside.com",),
        )
    )

    assert result == SafetyResult(False, "allowlist_denied")


def test_safety_gate_denies_on_dialog_cancel(tmp_path) -> None:
    config = _config(tmp_path, domain_allowlist='["example.com"]')
    gate = _gate(tmp_path, config, dialog=lambda preview: SafetyResult(False, "dialog_cancelled"))

    result = gate.full_check(
        WriteOperation(
            tool_name="send_email",
            payload_hash=compute_hash('{"subject":"hello"}'),
            canonical_payload='{"subject":"hello"}',
            recipients=("user@example.com",),
            dialog_preview=DialogPreview(title="Confirm", body="hello"),
        )
    )

    assert result == SafetyResult(False, "dialog_cancelled")


def test_safety_gate_reloads_config_when_file_changes(tmp_path) -> None:
    config = _config(tmp_path, domain_allowlist='["example.com"]')
    gate = _gate(tmp_path, config, dialog=lambda preview: SafetyResult(True, "dialog_approved"))

    write_config_text(
        config.config_path,
        _config_text(domain_allowlist='["changed.com"]'),
    )

    result = gate.full_check(
        WriteOperation(
            tool_name="send_email",
            payload_hash="015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862",
            canonical_payload='{"subject":"hello"}',
            recipients=("user@example.com",),
        )
    )

    assert result == SafetyResult(False, "allowlist_denied")


def _gate(tmp_path, config, *, dialog):
    return ConfiguredSafetyGate(
        config=config,
        rate_limiter=RateLimiter(
            profile="default",
            rate_limits=config.safety.rate_limits,
            path=tmp_path / "rate_limit.db",
            clock=lambda: datetime(2026, 4, 1, 12, tzinfo=UTC),
        ),
        audit_logger=AuditLogger(path=tmp_path / "audit.jsonl"),
        dialog=dialog,
        folder_checker=FolderAllowlistChecker(
            profile="default",
            allowed_folders=config.safety.folder_allowlist,
            folder_provider=lambda: [{"id": "folder-1", "display_name": "Archive"}],
            cache_path=tmp_path / "folders.json",
        ),
    )


def _config(tmp_path, *, domain_allowlist: str):
    config_path = tmp_path / "default" / "config.toml"
    write_config_text(config_path, _config_text(domain_allowlist=domain_allowlist))
    return load_config(base_dir=tmp_path)


def _config_text(*, domain_allowlist: str) -> str:
    return f"""
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = {domain_allowlist}
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
