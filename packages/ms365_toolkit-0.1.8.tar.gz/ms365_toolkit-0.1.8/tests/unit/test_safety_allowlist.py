from __future__ import annotations

from ms365_toolkit.safety.allowlist import check_recipients
from ms365_toolkit.safety.gate import SafetyResult


def test_check_recipients_allows_exact_and_subdomain_matches() -> None:
    result = check_recipients(
        ("user@example.com", "person@sub.example.com"),
        ("example.com", ".example.com"),
    )

    assert result == SafetyResult(True, "allowlist_ok")


def test_check_recipients_denies_address_outside_allowlist() -> None:
    result = check_recipients(
        ("user@example.com", "person@outside.com"),
        ("example.com",),
    )

    assert result == SafetyResult(False, "allowlist_denied")


def test_check_recipients_normalizes_idna_domains() -> None:
    result = check_recipients(
        ("user@bücher.example",),
        (".xn--bcher-kva.example",),
    )

    assert result == SafetyResult(True, "allowlist_ok")

