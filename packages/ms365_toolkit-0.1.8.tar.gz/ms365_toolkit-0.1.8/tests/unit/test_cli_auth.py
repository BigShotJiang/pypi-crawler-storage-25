from __future__ import annotations

from argparse import Namespace
from typing import TYPE_CHECKING

from ms365_toolkit.cli import _build_parser, main
from ms365_toolkit.cli.auth import AuthStatus, login_command, revoke_write_command, status_command

if TYPE_CHECKING:
    import pytest


def test_login_command_invokes_device_code_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, object]] = []

    monkeypatch.setattr("ms365_toolkit.cli.auth.CredentialStore", lambda profile: object())
    monkeypatch.setattr(
        "ms365_toolkit.cli.auth.authenticate_device_code",
        lambda **kwargs: calls.append(kwargs),
    )

    exit_code = login_command(
        Namespace(profile="default", write=False, insecure_env_write=False),
        config=_config(),
    )

    assert exit_code == 0
    assert calls and calls[0]["write"] is False


def test_login_command_can_request_channel_message_scope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, object]] = []

    monkeypatch.setattr("ms365_toolkit.cli.auth.CredentialStore", lambda profile: object())
    monkeypatch.setattr(
        "ms365_toolkit.cli.auth.authenticate_device_code",
        lambda **kwargs: calls.append(kwargs),
    )

    exit_code = login_command(
        Namespace(
            profile="default",
            write=False,
            teams_channel_messages=True,
            insecure_env_write=False,
        ),
        config=_config(),
    )

    assert exit_code == 0
    assert calls[0]["extra_scopes"] == frozenset({"ChannelMessage.Read.All"})


def test_login_command_can_request_file_and_meeting_scopes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, object]] = []

    monkeypatch.setattr("ms365_toolkit.cli.auth.CredentialStore", lambda profile: object())
    monkeypatch.setattr(
        "ms365_toolkit.cli.auth.authenticate_device_code",
        lambda **kwargs: calls.append(kwargs),
    )

    exit_code = login_command(
        Namespace(
            profile="default",
            write=False,
            teams_channel_messages=False,
            teams_files=True,
            meeting_transcripts=True,
            meeting_notes=True,
            insecure_env_write=False,
        ),
        config=_config(),
    )

    assert exit_code == 0
    assert calls[0]["extra_scopes"] == frozenset(
        {
            "Files.Read",
            "OnlineMeetings.Read",
            "OnlineMeetingTranscript.Read.All",
            "OnlineMeetingAiInsight.Read.All",
        }
    )


def test_status_command_prints_logged_in(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.auth.get_auth_status",
        lambda profile, config, write=False: AuthStatus(
            logged_in=True,
            scopes=("Calendars.Read", "Mail.Read"),
            expires_at="2026-03-12T10:00:00+00:00",
        ),
    )

    exit_code = status_command(Namespace(profile="default", write=False), _config())

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "logged in" in output
    assert "Mail.Read" in output


def test_status_command_can_print_write_token_status(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.auth.get_auth_status",
        lambda profile, config, write=False: AuthStatus(
            logged_in=True,
            scopes=("Mail.ReadWrite", "Mail.Send"),
            expires_at="2026-03-12T10:00:00+00:00",
        ),
    )

    exit_code = status_command(Namespace(profile="default", write=True), _config())

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "write scopes" in output
    assert "Mail.Send" in output


def test_revoke_write_command_deletes_write_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    deleted: list[str] = []

    class FakeStore:
        def delete_cache(self, *, kind: str) -> None:
            deleted.append(kind)

    monkeypatch.setattr("ms365_toolkit.cli.auth.CredentialStore", lambda profile: FakeStore())

    exit_code = revoke_write_command(Namespace(profile="default"))

    assert exit_code == 0
    assert deleted == ["write"]


def test_main_dispatches_inbox(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("ms365_toolkit.cli.load_config", lambda profile: _config())
    monkeypatch.setattr("ms365_toolkit.cli.inbox_command", lambda args, config: 0)

    exit_code = main(["inbox", "--top", "5"])

    assert exit_code == 0


def test_label_thread_parser_accepts_strategic_update() -> None:
    parser = _build_parser()

    args = parser.parse_args(
        [
            "label-thread",
            "conv-1",
            "--thread-class",
            "strategic_update",
            "--action-needed",
            "yes",
            "--urgency",
            "medium",
            "--acted-by-you",
            "unknown",
            "--confidence",
            "0.8",
        ]
    )

    assert args.thread_class == "strategic_update"


def test_download_email_attachments_parser_accepts_output_dir() -> None:
    parser = _build_parser()

    args = parser.parse_args(
        ["download-email-attachments", "msg-1", "--output-dir", "/tmp/downloads"]
    )

    assert args.message_id == "msg-1"
    assert args.output_dir == "/tmp/downloads"


def test_download_email_attachments_parser_accepts_filters() -> None:
    parser = _build_parser()

    args = parser.parse_args(
        [
            "download-email-attachments",
            "msg-1",
            "--include-inline",
            "--attachment-id",
            "att-1",
            "--attachment-id",
            "att-2",
            "--extensions",
            "pdf",
            "docx",
        ]
    )

    assert args.include_inline is True
    assert args.attachment_id == ["att-1", "att-2"]
    assert args.extensions == ["pdf", "docx"]


def test_read_email_attachment_parser_accepts_max_chars() -> None:
    parser = _build_parser()

    args = parser.parse_args(["read-email-attachment", "msg-1", "att-1", "--max-chars", "1234"])

    assert args.message_id == "msg-1"
    assert args.attachment_id == "att-1"
    assert args.max_chars == 1234


def test_auth_login_parser_accepts_teams_channel_messages() -> None:
    parser = _build_parser()

    args = parser.parse_args(["auth", "login", "--teams-channel-messages"])

    assert args.teams_channel_messages is True


def test_auth_login_parser_accepts_file_and_meeting_flags() -> None:
    parser = _build_parser()

    args = parser.parse_args(
        ["auth", "login", "--teams-files", "--meeting-transcripts", "--meeting-notes"]
    )

    assert args.teams_files is True
    assert args.meeting_transcripts is True
    assert args.meeting_notes is True


def test_auth_status_parser_accepts_write_flag() -> None:
    parser = _build_parser()

    args = parser.parse_args(["auth", "status", "--write"])

    assert args.write is True


def test_create_email_draft_parser_accepts_email_fields() -> None:
    parser = _build_parser()

    args = parser.parse_args(
        [
            "create-email-draft",
            "--to",
            "to@example.com",
            "--cc",
            "cc@example.com",
            "--bcc",
            "bcc@example.com",
            "--reply-to",
            "reply@example.com",
            "--subject",
            "Hello",
            "--body",
            "<p>Hello</p>",
            "--importance",
            "high",
        ]
    )

    assert args.to == ["to@example.com"]
    assert args.cc == ["cc@example.com"]
    assert args.bcc == ["bcc@example.com"]
    assert args.reply_to == ["reply@example.com"]
    assert args.body == "<p>Hello</p>"
    assert args.importance == "high"


def test_send_email_draft_parser_accepts_hash() -> None:
    parser = _build_parser()

    args = parser.parse_args(["send-email-draft", "draft-1", "hash-1"])

    assert args.draft_id == "draft-1"
    assert args.content_hash == "hash-1"


def _config():
    class StubAuth:
        tenant_id = "tenant"
        client_id = "client"

    class StubUser:
        endpoint = "me"
        user_principal_name = "owner@example.com"
        timezone = "UTC"

    class StubSafety:
        domain_allowlist = ("example.com",)

    class StubVip:
        emails = ()
        domains = ()

    class StubIntelligence:
        critical_keywords = ()
        noise_keywords = ()
        action_keywords = ()

    class StubConfig:
        profile = "default"
        auth = StubAuth()
        user = StubUser()
        safety = StubSafety()
        vip = StubVip()
        intelligence = StubIntelligence()
        config_hash = "hash"
        config_mtime = 0.0
        config_path = None

    return StubConfig()
