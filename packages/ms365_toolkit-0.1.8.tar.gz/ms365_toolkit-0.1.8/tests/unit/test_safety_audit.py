from __future__ import annotations

import hashlib
import json
import stat

from ms365_toolkit.safety.audit import AuditLogger
from ms365_toolkit.safety.gate import AuditEvent


def test_audit_logger_writes_jsonl_with_private_domain_hashes(tmp_path) -> None:
    path = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=path, max_bytes=1024, backup_count=2)

    logger.log(
        AuditEvent(
            tool_name="send_email",
            action="deny",
            denial_reason="allowlist_denied",
            config_version="config-hash",
            canonical_payload_hash="payload-hash",
            recipients=("user@example.com", "person@sub.example.com"),
        )
    )

    payload = json.loads(path.read_text(encoding="utf-8").splitlines()[0])

    assert payload["tool_name"] == "send_email"
    assert payload["recipient_count"] == 2
    assert payload["domain_hashes"] == sorted(
        [
            hashlib.sha256(b"example.com").hexdigest(),
            hashlib.sha256(b"sub.example.com").hexdigest(),
        ]
    )
    assert "example.com" not in path.read_text(encoding="utf-8")
    assert stat.S_IMODE(path.stat().st_mode) == 0o600


def test_audit_logger_rotates_when_file_exceeds_limit(tmp_path) -> None:
    path = tmp_path / "audit.jsonl"
    logger = AuditLogger(path=path, max_bytes=120, backup_count=2)

    for index in range(3):
        logger.log(
            AuditEvent(
                tool_name="send_email",
                action="allow",
                config_version=f"config-{index}",
                canonical_payload_hash=f"payload-{index}",
            )
        )

    assert path.exists()
    assert (tmp_path / "audit.jsonl.1").exists()
