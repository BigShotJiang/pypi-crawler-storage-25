from __future__ import annotations

from ms365_toolkit.safety.folder_allowlist import FolderAllowlistChecker
from ms365_toolkit.safety.gate import SafetyResult


def test_folder_allowlist_allows_configured_folder_id(tmp_path) -> None:
    checker = FolderAllowlistChecker(
        profile="default",
        allowed_folders=("Archive",),
        folder_provider=lambda: [{"id": "folder-1", "display_name": "Archive"}],
        cache_path=tmp_path / "folder-cache.json",
    )

    assert checker.check_folder("folder-1") == SafetyResult(True, "folder_allowed")


def test_folder_allowlist_denies_system_folder_even_if_named_in_allowlist(tmp_path) -> None:
    checker = FolderAllowlistChecker(
        profile="default",
        allowed_folders=("Deleted Items",),
        folder_provider=lambda: [{"id": "folder-1", "display_name": "Deleted Items"}],
        cache_path=tmp_path / "folder-cache.json",
    )

    assert checker.check_folder("folder-1") == SafetyResult(False, "system_folder_blocked")


def test_folder_allowlist_refreshes_when_folder_missing_from_cache(tmp_path) -> None:
    calls = {"count": 0}

    def provider():
        calls["count"] += 1
        if calls["count"] == 1:
            return [{"id": "folder-1", "display_name": "Archive"}]
        return [{"id": "folder-2", "display_name": "Archive"}]

    checker = FolderAllowlistChecker(
        profile="default",
        allowed_folders=("Archive",),
        folder_provider=provider,
        cache_path=tmp_path / "folder-cache.json",
    )

    checker.check_folder("folder-1")

    assert checker.check_folder("folder-2") == SafetyResult(True, "folder_allowed")
    assert calls["count"] == 2

