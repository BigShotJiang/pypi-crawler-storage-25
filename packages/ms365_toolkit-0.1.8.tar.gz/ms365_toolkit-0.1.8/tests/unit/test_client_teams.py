from __future__ import annotations

import base64
import io
import json
from datetime import UTC, datetime
from io import BytesIO
from typing import TYPE_CHECKING, Any
from urllib.error import HTTPError

import pytest
from docx import Document

from ms365_toolkit.client.exceptions import GraphAPIError
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.client.teams import TeamsClient
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_list_chats_maps_payload(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token=_jwt_token(user_id="self-1", upn="owner@example.com"),
            transport=lambda req, timeout: _response({"value": [_chat_item("chat-1")]}),
        )
    )

    chats = client.list_chats()

    assert chats[0].id == "chat-1"
    assert chats[0].chat_type == "oneOnOne"
    assert chats[0].display_label == "Madeline"
    assert chats[0].last_updated_at == datetime(2026, 4, 3, 16, 0, tzinfo=UTC)
    assert chats[0].other_participants[0].display_name == "Madeline"


def test_list_chats_caps_top_to_graph_limit(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.list_chats(top=100)

    assert "$top=50" in captured["url"]
    assert "$expand=members" in captured["url"]


def test_list_chats_builds_participant_label_when_topic_is_missing(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token=_jwt_token(user_id="self-1", upn="owner@example.com"),
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _chat_item(
                            "chat-1",
                            topic=None,
                            members=(
                                _member_item("Adhiappan, Shiv", "owner@example.com", "self-1"),
                                _member_item("Kamal, Sara", "sara@example.com", "user-2"),
                            ),
                        )
                    ]
                }
            ),
        )
    )

    chat = client.list_chats()[0]

    assert chat.display_label == "Kamal, Sara"
    assert tuple(
        (participant.display_name, participant.email, participant.user_id)
        for participant in chat.other_participants
    ) == (("Kamal, Sara", "sara@example.com", "user-2"),)


def test_list_chats_keeps_all_members_when_viewer_identity_is_unknown(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="not-a-jwt",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _chat_item(
                            "chat-1",
                            topic=None,
                            members=(
                                _member_item("Adhiappan, Shiv", "owner@example.com", "self-1"),
                                _member_item("Kamal, Sara", "sara@example.com", "user-2"),
                            ),
                        )
                    ]
                }
            ),
        )
    )

    chat = client.list_chats()[0]

    assert tuple(
        (participant.display_name, participant.email, participant.user_id)
        for participant in chat.other_participants
    ) == (
        ("Adhiappan, Shiv", "owner@example.com", "self-1"),
        ("Kamal, Sara", "sara@example.com", "user-2"),
    )


def test_search_chats_prioritizes_direct_match_over_group_and_topic(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token=_jwt_token(user_id="self-1", upn="owner@example.com"),
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _chat_item(
                            "chat-direct",
                            topic=None,
                            members=(
                                _member_item("Adhiappan, Shiv", "owner@example.com", "self-1"),
                                _member_item(
                                    "Burkhardt, Alyssa",
                                    "alyssa@example.com",
                                    "user-2",
                                ),
                            ),
                        ),
                        _chat_item(
                            "chat-group",
                            topic="Architecture sync",
                            chat_type="group",
                            members=(
                                _member_item("Adhiappan, Shiv", "owner@example.com", "self-1"),
                                _member_item(
                                    "Burkhardt, Alyssa",
                                    "alyssa@example.com",
                                    "user-2",
                                ),
                                _member_item("Teammate", "teammate@example.com", "user-3"),
                            ),
                        ),
                        _chat_item(
                            "chat-meeting",
                            topic="Alyssa readout",
                            chat_type="meeting",
                            members=(),
                        ),
                    ]
                }
            ),
        )
    )

    chats = client.search_chats("Alyssa Burkhardt", top=3)

    assert [chat.id for chat in chats] == ["chat-direct", "chat-group"]


def test_list_chat_messages_sanitizes_html(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response({"value": [_chat_message_item("msg-1")]}),
        )
    )

    messages = client.list_chat_messages("chat-1")

    assert messages[0].id == "msg-1"
    assert messages[0].body_content == "Hello world"
    assert messages[0].sender.display_name == "Sender"


def test_get_chat_message_maps_downloadable_attachments(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    **_chat_message_item("msg-1"),
                    "attachments": [
                        _teams_attachment_item(
                            attachment_id="att-1",
                            name="brief.docx",
                            content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
                        )
                    ],
                }
            ),
        )
    )

    message = client.get_chat_message("chat-1", "msg-1")

    assert message.attachments[0].id == "att-1"
    assert message.attachments[0].content_url == "https://contoso.sharepoint.com/:w:/r/brief.docx"


def test_list_message_attachments_returns_downloadable_teams_files(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    **_chat_message_item("msg-1"),
                    "attachments": [
                        _teams_attachment_item(
                            attachment_id="att-1",
                            name="brief.docx",
                            content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
                        ),
                        _teams_attachment_item(
                            attachment_id="att-2",
                            name="card",
                            content_type="application/vnd.microsoft.card.codesnippet",
                            content_url="",
                        ),
                    ],
                }
            ),
        )
    )

    attachments = client.list_message_attachments(chat_id="chat-1", message_id="msg-1")

    assert [(attachment.id, attachment.name) for attachment in attachments] == [
        ("att-1", "brief.docx")
    ]


def test_download_message_attachment_resolves_share_link_and_downloads_bytes(
    tmp_path: Path,
) -> None:
    calls: list[str] = []
    responses = iter(
        [
            {
                **_chat_message_item("msg-1"),
                "attachments": [
                    _teams_attachment_item(
                        attachment_id="att-1",
                        name="brief.docx",
                        content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
                    )
                ],
            },
            {
                "name": "brief.docx",
                "file": {
                    "mimeType": (
                        "application/vnd.openxmlformats-officedocument."
                        "wordprocessingml.document"
                    )
                },
            },
            b"hello",
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = TeamsClient(graph, files_graph=graph)

    attachment = client.download_message_attachment(
        chat_id="chat-1",
        message_id="msg-1",
        attachment_id="att-1",
    )

    assert attachment.name == "brief.docx"
    assert attachment.content == b"hello"
    assert calls[1].startswith("https://graph.microsoft.com/v1.0/shares/u!")
    assert calls[2].endswith("/driveItem/content")


def test_read_message_attachment_text_extracts_docx_content(tmp_path: Path) -> None:
    responses = iter(
        [
            {
                **_chat_message_item("msg-1"),
                "attachments": [
                    _teams_attachment_item(
                        attachment_id="att-1",
                        name="brief.docx",
                        content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
                    )
                ],
            },
            {
                **_chat_message_item("msg-1"),
                "attachments": [
                    _teams_attachment_item(
                        attachment_id="att-1",
                        name="brief.docx",
                        content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
                    )
                ],
            },
            {
                "name": "brief.docx",
                "file": {
                    "mimeType": (
                        "application/vnd.openxmlformats-officedocument."
                        "wordprocessingml.document"
                    )
                },
            },
            _docx_bytes(),
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = TeamsClient(graph, files_graph=graph)

    extracted = client.read_message_attachment_text(
        chat_id="chat-1",
        message_id="msg-1",
        attachment_id="att-1",
    )

    assert extracted.format == "docx"
    assert "Quarterly review" in extracted.text_content


def test_list_chat_messages_caps_top_to_graph_limit(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.list_chat_messages("chat-1", top=100)

    assert "$top=50" in captured["url"]


def test_search_chat_messages_matches_body_and_sender(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _chat_message_item(
                            "msg-1",
                            content="Please share the cost center today",
                            sender_name="Kamal, Sara",
                            sender_email="sara@example.com",
                        ),
                        _chat_message_item(
                            "msg-2",
                            content="Status only",
                            sender_name="Other Person",
                            sender_email="other@example.com",
                        ),
                    ]
                }
            ),
        )
    )

    messages = client.search_chat_messages("chat-1", "cost center", top=5)

    assert [message.id for message in messages] == ["msg-1"]


def test_search_teams_messages_posts_search_query_and_maps_chat_hit(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["method"] = req.get_method()
        captured["body"] = json.loads(req.data.decode("utf-8"))
        return _response(
            {
                "value": [
                    {
                        "hitsContainers": [
                            {
                                "hits": [
                                    {
                                        "summary": "...cost center...",
                                        "resource": _search_hit_resource(
                                            "msg-1",
                                            chat_id="chat-1",
                                        ),
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.search_teams_messages("cost center", top=10)

    assert captured["url"] == "https://graph.microsoft.com/v1.0/search/query"
    assert captured["method"] == "POST"
    assert captured["body"] == {
        "requests": [
            {
                "entityTypes": ["chatMessage"],
                "query": {"queryString": "cost center"},
                "from": 0,
                "size": 10,
                "enableTopResults": True,
            }
        ]
    }
    assert messages[0].id == "msg-1"
    assert messages[0].summary == "...cost center..."
    assert messages[0].chat_id == "chat-1"
    assert messages[0].location_kind == "chat"
    assert messages[0].sender_name == "Sender"
    assert messages[0].sender_email == "sender@example.com"


def test_search_teams_messages_maps_channel_hit_and_caps_top(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["body"] = json.loads(req.data.decode("utf-8"))
        return _response(
            {
                "value": [
                    {
                        "hitsContainers": [
                            {
                                "hits": [
                                    {
                                        "summary": "...authorization rate...",
                                        "resource": _search_hit_resource(
                                            "msg-2",
                                            team_id="team-1",
                                            channel_id="channel-1",
                                        ),
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.search_teams_messages("authorization rate", top=100)

    assert captured["body"]["requests"][0]["size"] == 25
    assert messages[0].team_id == "team-1"
    assert messages[0].channel_id == "channel-1"
    assert messages[0].location_kind == "channel"
    assert messages[0].web_url == "https://teams.microsoft.com/l/message/1"


def test_search_teams_messages_rewords_admin_permission_error(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            403,
            "Forbidden",
            {},
            io.BytesIO(
                json.dumps(
                    {
                        "error": {
                            "code": "Forbidden",
                            "message": (
                                "Missing role permissions on the request. "
                                "API requires one of 'ChannelMessage.Read.All'."
                            ),
                        }
                    }
                ).encode("utf-8")
            ),
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    with pytest.raises(GraphAPIError, match=r"auth login --teams-channel-messages"):
        client.search_teams_messages("cost center")


def test_search_teams_messages_preserves_other_403_errors(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            403,
            "Forbidden",
            {},
            io.BytesIO(
                json.dumps(
                    {
                        "error": {
                            "code": "Forbidden",
                            "message": "User is not allowed to search this content.",
                        }
                    }
                ).encode("utf-8")
            ),
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    with pytest.raises(GraphAPIError, match="not allowed to search this content"):
        client.search_teams_messages("cost center")


def test_list_channel_messages_counts_replies(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {"value": [_channel_message_item("msg-1", reply_count=2)]}
            ),
        )
    )

    messages = client.list_channel_messages("team-1", "channel-1")

    assert messages[0].reply_count == 2
    assert messages[0].team_id == "team-1"
    assert messages[0].channel_id == "channel-1"


def test_list_channel_messages_caps_top_to_graph_limit(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.list_channel_messages("team-1", "channel-1", top=100)

    assert "$top=50" in captured["url"]


def test_search_channel_messages_prioritizes_summary_match(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _channel_message_item(
                            "msg-1",
                            reply_count=0,
                            summary="Authorization rate dropped in HBG",
                        ),
                        _channel_message_item(
                            "msg-2",
                            reply_count=0,
                            summary="Unrelated alert",
                        ),
                    ]
                }
            ),
        )
    )

    messages = client.search_channel_messages("team-1", "channel-1", "authorization rate")

    assert [message.id for message in messages] == ["msg-1"]


def test_list_channel_messages_handles_null_sender(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {"value": [_channel_message_item("msg-1", reply_count=0, include_sender=False)]}
            ),
        )
    )

    messages = client.list_channel_messages("team-1", "channel-1")

    assert messages[0].sender.display_name == ""
    assert messages[0].sender.kind == "unknown"


def test_list_channel_replies_returns_chronological_page_and_truncation(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "@odata.nextLink": "https://graph.microsoft.com/v1.0/next",
                    "value": [
                        _channel_reply_item("reply-2", created_at="2026-04-03T16:12:00Z"),
                        _channel_reply_item("reply-1", created_at="2026-04-03T16:11:00Z"),
                    ],
                }
            ),
        )
    )

    reply_page = client.list_channel_replies("team-1", "channel-1", "msg-1")

    assert tuple(reply.id for reply in reply_page.replies) == ("reply-1", "reply-2")
    assert all(reply.reply_count == 0 for reply in reply_page.replies)
    assert all(reply.reply_to_id == "msg-1" for reply in reply_page.replies)
    assert reply_page.has_more_replies is True


def test_list_channel_replies_caps_top_to_graph_limit(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.list_channel_replies("team-1", "channel-1", "msg-1", top=100)

    assert "$top=50" in captured["url"]
    assert captured["url"].endswith("/messages/msg-1/replies?$top=50")


def test_read_channel_thread_combines_root_and_reply_page(tmp_path: Path) -> None:
    captured_urls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        captured_urls.append(req.full_url)
        if req.full_url.endswith("/messages/msg-1"):
            return _response(_channel_message_item("msg-1", reply_count=0))
        return _response(
            {
                "value": [
                    _channel_reply_item("reply-2", created_at="2026-04-03T16:12:00Z"),
                    _channel_reply_item("reply-1", created_at="2026-04-03T16:11:00Z"),
                ]
            }
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    thread = client.read_channel_thread("team-1", "channel-1", "msg-1", replies_top=10)

    assert thread.root_message.id == "msg-1"
    assert tuple(reply.id for reply in thread.replies) == ("reply-1", "reply-2")
    assert thread.has_more_replies is False
    assert len(captured_urls) == 2
    assert captured_urls[0].endswith("/messages/msg-1")
    assert captured_urls[1].endswith("/messages/msg-1/replies?$top=10")


def test_list_chat_messages_normalizes_missing_fields(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        {
                            "id": "msg-1",
                            "body": {"contentType": None, "content": None},
                            "createdDateTime": None,
                            "lastModifiedDateTime": None,
                            "lastEditedDateTime": None,
                            "deletedDateTime": None,
                            "subject": None,
                            "summary": None,
                            "importance": None,
                            "messageType": None,
                            "replyToId": None,
                            "webUrl": None,
                            "from": None,
                        }
                    ]
                }
            ),
        )
    )

    message = client.list_chat_messages("chat-1")[0]

    assert message.created_at is None
    assert message.last_modified_at is None
    assert message.last_edited_at is None
    assert message.deleted_at is None
    assert message.subject == ""
    assert message.summary == ""
    assert message.importance == ""
    assert message.message_type == ""
    assert message.reply_to_id == ""
    assert message.web_url == ""
    assert message.sender.display_name == ""


def test_list_channel_messages_rewords_admin_permission_error(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            403,
            "Forbidden",
            {},
            io.BytesIO(
                json.dumps(
                    {
                        "error": {
                            "code": "Forbidden",
                            "message": (
                                "Missing role permissions on the request. "
                                "API requires one of 'ChannelMessage.Read.All'."
                            ),
                        }
                    }
                ).encode("utf-8")
            ),
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    with pytest.raises(GraphAPIError, match=r"admin-approved ChannelMessage\.Read\.All"):
        client.list_channel_messages("team-1", "channel-1")


def test_list_channel_messages_preserves_other_403_errors(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            403,
            "Forbidden",
            {},
            io.BytesIO(
                json.dumps(
                    {
                        "error": {
                            "code": "Forbidden",
                            "message": "User is not a member of this channel.",
                        }
                    }
                ).encode("utf-8")
            ),
        )

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    with pytest.raises(GraphAPIError, match="not a member of this channel"):
        client.list_channel_messages("team-1", "channel-1")


def test_teams_client_requires_me_endpoint(tmp_path: Path) -> None:
    client = TeamsClient(
        GraphClient(
            config=_config(
                tmp_path,
                extra_replacements=(
                    ('endpoint = "me"', 'endpoint = "users"'),
                    ('user_principal_name = ""', 'user_principal_name = "leader@example.com"'),
                ),
            ),
            token="token",
            transport=lambda req, timeout: _response({"value": []}),
        )
    )

    with pytest.raises(ValueError, match=r"user\.endpoint='me'"):
        client.list_teams()


def test_channel_paths_escape_dynamic_ids(tmp_path: Path) -> None:
    captured: dict[str, str] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = TeamsClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.list_channel_messages("team 1", "channel/1")

    assert "teams/team%201/channels/channel%2F1/messages" in captured["url"]


class _FakeResponse:
    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = json.dumps(payload).encode("utf-8")

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _response(payload: dict[str, Any]) -> _FakeResponse:
    return _FakeResponse(payload)


class _FakeBytesResponse:
    def __init__(self, payload: bytes) -> None:
        self._payload = payload

    def __enter__(self) -> _FakeBytesResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _bytes_response(payload: bytes) -> _FakeBytesResponse:
    return _FakeBytesResponse(payload)


def _chat_item(
    chat_id: str,
    *,
    topic: str | None = "Madeline",
    chat_type: str = "oneOnOne",
    members: tuple[dict[str, str], ...] | None = None,
) -> dict[str, Any]:
    return {
        "id": chat_id,
        "topic": topic,
        "chatType": chat_type,
        "createdDateTime": "2026-04-03T15:00:00Z",
        "lastUpdatedDateTime": "2026-04-03T16:00:00Z",
        "lastMessageReadDateTime": "2026-04-03T16:05:00Z",
        "webUrl": "https://teams.microsoft.com/chat",
        "isHidden": False,
        "isHiddenForAllMembers": False,
        "members": list(
            members
            or (
                _member_item("Adhiappan, Shiv", "owner@example.com", "self-1"),
                _member_item("Madeline", "madeline@example.com", "user-2"),
            )
        ),
    }


def _member_item(display_name: str, email: str, user_id: str) -> dict[str, str]:
    return {
        "displayName": display_name,
        "email": email,
        "userId": user_id,
    }


def _chat_message_item(
    message_id: str,
    *,
    content: str = "<div>Hello <b>world</b></div>",
    content_type: str = "html",
    summary: str = "Hello world",
    sender_name: str = "Sender",
    sender_email: str = "sender@example.com",
) -> dict[str, Any]:
    return {
        "id": message_id,
        "body": {"contentType": content_type, "content": content},
        "createdDateTime": "2026-04-03T16:10:00Z",
        "lastModifiedDateTime": "2026-04-03T16:10:00Z",
        "lastEditedDateTime": "2026-04-03T16:12:00Z",
        "summary": summary,
        "importance": "normal",
        "messageType": "message",
        "webUrl": "https://teams.microsoft.com/l/message/1",
        "from": {"user": {"displayName": sender_name, "email": sender_email, "id": "user-1"}},
    }


def _teams_attachment_item(
    *,
    attachment_id: str,
    name: str,
    content_url: str,
    content_type: str = "reference",
) -> dict[str, str]:
    return {
        "id": attachment_id,
        "name": name,
        "contentType": content_type,
        "contentUrl": content_url,
        "thumbnailUrl": "https://example.com/thumb.png",
        "teamsAppId": "",
    }


def _search_hit_resource(
    message_id: str,
    *,
    chat_id: str = "",
    team_id: str = "",
    channel_id: str = "",
) -> dict[str, Any]:
    resource = {
        "id": message_id,
        "createdDateTime": "2026-04-03T16:10:00Z",
        "lastModifiedDateTime": "2026-04-03T16:12:00Z",
        "subject": "",
        "importance": "normal",
        "webLink": "https://teams.microsoft.com/l/message/1",
        "from": {
            "emailAddress": {
                "name": "Sender",
                "address": "sender@example.com",
            }
        },
        "chatId": chat_id,
    }
    if team_id or channel_id:
        resource["channelIdentity"] = {
            "teamId": team_id,
            "channelId": channel_id,
        }
    else:
        resource["channelIdentity"] = {}
    return resource


def _channel_message_item(
    message_id: str,
    *,
    reply_count: int,
    include_sender: bool = True,
    created_at: str = "2026-04-03T16:10:00Z",
    reply_to_id: str | None = None,
    summary: str = "Hello world",
) -> dict[str, Any]:
    item = {
        **_chat_message_item(message_id, summary=summary),
        "createdDateTime": created_at,
        "replyToId": reply_to_id,
        "replies": [{"id": f"reply-{index}"} for index in range(reply_count)],
    }
    if not include_sender:
        item["from"] = None
    return item


def _channel_reply_item(message_id: str, *, created_at: str) -> dict[str, Any]:
    return _channel_message_item(
        message_id,
        reply_count=0,
        created_at=created_at,
        reply_to_id="msg-1",
    )


def _docx_bytes() -> bytes:
    document = Document()
    document.add_paragraph("Quarterly review")
    output = BytesIO()
    document.save(output)
    return output.getvalue()


def _jwt_token(*, user_id: str, upn: str) -> str:
    header = base64.urlsafe_b64encode(
        json.dumps({"alg": "none", "typ": "JWT"}).encode("utf-8")
    ).rstrip(b"=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"oid": user_id, "upn": upn, "exp": 9999999999}).encode("utf-8")
    ).rstrip(b"=")
    return f"{header.decode()}.{payload.decode()}."


def _config(tmp_path: Path, extra_replacements: tuple[tuple[str, str], ...] = ()) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    for old, new in extra_replacements:
        content = content.replace(old, new)
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
