#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE=""
MODEL=""
EFFORT="high"
DRY_RUN=0

usage() {
  cat <<EOF
Usage: $(basename "$0") [options] <review|review-commit|consult> [args]

Modes:
  review [focus text]          Critical review of the current working tree
  review-commit <commit>       Critical review of a specific commit or range
  consult <question>           Repository-grounded consultation

Options:
  --model NAME                 Claude model alias or full model name
  --effort LEVEL               low, medium, high, or max (default: high)
  --dry-run                    Print the resolved claude command without running it
  -h, --help                   Show this help text
EOF
}

run() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '+'
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi
  "$@"
}

if ! command -v claude >/dev/null 2>&1; then
  echo "claude CLI not found on PATH" >&2
  exit 1
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --model)
      MODEL="$2"
      shift 2
      ;;
    --effort)
      EFFORT="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    review|review-commit|consult)
      MODE="$1"
      shift
      break
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [[ -z "$MODE" ]]; then
  usage >&2
  exit 1
fi

if [[ "$EFFORT" != "low" && "$EFFORT" != "medium" && "$EFFORT" != "high" && "$EFFORT" != "max" ]]; then
  echo "--effort must be one of: low, medium, high, max" >&2
  exit 1
fi

case "$MODE" in
  review)
    FOCUS="${*:-current working tree}"
    PROMPT=$(cat <<EOF
Do a critical code review of the repository at $ROOT_DIR.

Scope: $FOCUS

Focus on bugs, behavioral regressions, risky assumptions, API mismatches, missing tests, and release or operational risks.

Review rules:
- findings first, ordered by severity
- include exact file/line references when possible
- keep summaries brief
- if there are no findings, say so explicitly and mention residual risks or gaps
EOF
)
    ;;
  review-commit)
    if [[ $# -lt 1 ]]; then
      echo "review-commit requires a commit or range" >&2
      exit 1
    fi
    COMMIT="$1"
    shift
    EXTRA="${*:-}"
    PROMPT=$(cat <<EOF
Do a critical code review of commit or range $COMMIT in the repository at $ROOT_DIR.

Additional focus: $EXTRA

Focus on bugs, behavioral regressions, risky assumptions, API mismatches, missing tests, and release or operational risks introduced by this change.

Review rules:
- findings first, ordered by severity
- include exact file/line references when possible
- keep summaries brief
- if there are no findings, say so explicitly and mention residual risks or gaps
EOF
)
    ;;
  consult)
    if [[ $# -lt 1 ]]; then
      echo "consult requires a question" >&2
      exit 1
    fi
    QUESTION="$*"
    PROMPT=$(cat <<EOF
Act as a senior engineer consulting on the repository at $ROOT_DIR.

Question: $QUESTION

Ground the answer in the current codebase. Be concise, concrete, and explicit about tradeoffs, risks, and assumptions. Cite file references when relevant.
EOF
)
    ;;
esac

CLAUDE_ARGS=(
  -p
  --permission-mode
  dontAsk
  --allowedTools
  "Read Grep Glob Bash(git status:*) Bash(git diff:*) Bash(git show:*) Bash(git log:*) Bash(git branch:*)"
  --effort
  "$EFFORT"
)

if [[ -n "$MODEL" ]]; then
  CLAUDE_ARGS+=(--model "$MODEL")
fi

cd "$ROOT_DIR"
run claude "${CLAUDE_ARGS[@]}" "$PROMPT"
