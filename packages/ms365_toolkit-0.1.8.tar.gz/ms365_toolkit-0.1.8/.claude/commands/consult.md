---
description: Consult Claude on a design or implementation question using the current repo
argument-hint: "<question>"
disable-model-invocation: true
allowed-tools: Read Grep Glob Bash(git status:*) Bash(git diff:*) Bash(git log:*) Bash(git branch:*)
---

## Question

$ARGUMENTS

## Repository Context

- Current branch: !`git branch --show-current`
- Git status: !`git status --short`
- Recent commits: !`git log --oneline -10`

## Task

Answer the question using the current repository state.

Rules:
- ground the answer in the codebase
- cite file references when relevant
- emphasize tradeoffs, risks, and assumptions
- be concise and concrete
