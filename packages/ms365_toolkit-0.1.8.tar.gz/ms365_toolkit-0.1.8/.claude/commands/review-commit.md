---
description: Critical review of a specific commit or commit range
argument-hint: "<commit or range>"
disable-model-invocation: true
allowed-tools: Read Grep Glob Bash(git show:*) Bash(git diff:*) Bash(git log:*)
---

## Commit Context

- Requested commit or range: $ARGUMENTS
- Commit summary: !`git show --stat --summary --no-ext-diff $ARGUMENTS`

## Task

Do a critical code review of commit or range `$ARGUMENTS`.

Focus on:
- bugs and regressions introduced by the change
- risky assumptions, fragile logic, and interface mismatches
- missing tests or weak test coverage
- release or rollout risks

Review rules:
- findings first, ordered by severity
- include exact file references and line numbers when possible
- keep summaries brief
- if there are no findings, say so explicitly and note residual risks or gaps
