---
description: Critical review of the current working tree or a specified scope
argument-hint: "[optional focus or files]"
disable-model-invocation: true
allowed-tools: Read Grep Glob Bash(git status:*) Bash(git diff:*) Bash(git log:*) Bash(git branch:*) Bash(git show:*)
---

## Review Context

- Current branch: !`git branch --show-current`
- Git status: !`git status --short`
- Working tree diff summary: !`git diff --stat`
- Recent commits: !`git log --oneline -10`

## Optional Focus

$ARGUMENTS

## Task

Do a critical code review of the current repository state.

Focus on:
- bugs and behavioral regressions
- risky assumptions and API mismatches
- missing validation or missing tests
- operational or release risks

Review rules:
- findings first, ordered by severity
- include exact file references and line numbers when possible
- keep summaries brief
- if there are no findings, say so explicitly and note residual risks or gaps
