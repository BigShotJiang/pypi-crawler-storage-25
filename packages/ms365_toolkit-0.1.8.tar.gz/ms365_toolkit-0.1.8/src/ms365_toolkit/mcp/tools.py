from __future__ import annotations

from datetime import UTC, datetime
from functools import wraps
from typing import TYPE_CHECKING, Any, ParamSpec, TypeVar

from ms365_toolkit.client.exceptions import (
    AuthenticationError,
    GraphAPIError,
    RateLimitedError,
    SafetyDeniedError,
)
from ms365_toolkit.mcp.planner import find_open_windows
from ms365_toolkit.mcp.serializers import (
    serialize_channel,
    serialize_chat,
    serialize_email,
    serialize_email_attachment,
    serialize_email_draft,
    serialize_event,
    serialize_extracted_attachment,
    serialize_extracted_meeting_transcript,
    serialize_extracted_teams_file,
    serialize_meeting_ai_insight,
    serialize_meeting_transcript,
    serialize_team,
    serialize_teams_attachment,
    serialize_teams_message,
    serialize_teams_message_search_hit,
    serialize_teams_reply_page,
    serialize_teams_thread,
    serialize_windows,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from fastmcp import FastMCP

    from ms365_toolkit.mcp.runtime import ReadRuntime

P = ParamSpec("P")
R = TypeVar("R")


def register_tools(mcp: FastMCP, runtime: ReadRuntime) -> None:
    @mcp.tool(description="List inbox messages from the current mailbox.")
    @_tool_errors
    def list_inbox(
        mailbox_filter: str = "all",
        top: int = 10,
        skip: int = 0,
    ) -> dict[str, Any]:
        normalized_filter = _normalize_mailbox_filter(mailbox_filter)
        messages = runtime.email_client().list_inbox(
            mailbox_filter=normalized_filter,
            top=_positive_int(top, "top"),
            skip=_non_negative_int(skip, "skip"),
        )
        return {"messages": [serialize_email(item) for item in messages]}

    @mcp.tool(description="Search mailbox messages by query.")
    @_tool_errors
    def search_emails(
        query: str,
        mailbox_filter: str = "all",
        top: int = 10,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        normalized_filter = _normalize_mailbox_filter(mailbox_filter)
        messages = runtime.email_client().search_emails(
            query=query,
            mailbox_filter=normalized_filter,
        )
        return {
            "messages": [serialize_email(item) for item in messages[: _positive_int(top, "top")]]
        }

    @mcp.tool(description="Read a single email message by id.")
    @_tool_errors
    def read_email(message_id: str) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_email(runtime.email_client().read_email(message_id))

    @mcp.tool(description="List downloadable email attachments by message id.")
    @_tool_errors
    def list_email_attachments(
        message_id: str,
        include_inline: bool = False,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        attachments = runtime.email_client().list_attachments(
            message_id,
            include_inline=include_inline,
        )
        return {"attachments": [serialize_email_attachment(item) for item in attachments]}

    @mcp.tool(description="Read supported email attachment text by attachment id.")
    @_tool_errors
    def read_email_attachment(
        message_id: str,
        attachment_id: str,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        if not attachment_id.strip():
            raise ValueError("attachment_id must be a non-empty string")
        return serialize_extracted_attachment(
            runtime.email_client().read_attachment_text(
                message_id,
                attachment_id,
                max_chars=_positive_int(max_chars, "max_chars"),
            )
        )

    @mcp.tool(description="Create a guarded email draft in the signed-in mailbox.")
    @_tool_errors
    def create_email_draft(
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        reply_to: list[str] | None = None,
        importance: str = "normal",
    ) -> dict[str, Any]:
        draft = runtime.email_client(write=True).create_email_draft(
            to=_non_empty_emails(to, "to"),
            cc=_optional_emails(cc),
            bcc=_optional_emails(bcc),
            subject=subject,
            body=body,
            reply_to=_optional_emails(reply_to),
            importance=_normalize_importance(importance),
        )
        return serialize_email_draft(draft)

    @mcp.tool(description="Create a guarded reply draft for an existing email message.")
    @_tool_errors
    def create_reply_draft(
        message_id: str,
        body: str,
        importance: str | None = None,
    ) -> dict[str, Any]:
        normalized_message_id = message_id.strip()
        if not normalized_message_id:
            raise ValueError("message_id must be a non-empty string")
        draft = runtime.email_client(write=True).create_reply_draft(
            message_id=normalized_message_id,
            body=body,
            importance=_normalize_importance(importance) if importance is not None else None,
        )
        return serialize_email_draft(draft)

    @mcp.tool(description="Send a previously created draft after hash verification.")
    @_tool_errors
    def send_email_draft(draft_id: str, content_hash: str) -> dict[str, Any]:
        normalized_draft_id = draft_id.strip()
        if not normalized_draft_id:
            raise ValueError("draft_id must be a non-empty string")
        normalized_hash = content_hash.strip()
        if not normalized_hash:
            raise ValueError("content_hash must be a non-empty string")
        runtime.email_client(write=True).send_email_draft(
            draft_id=normalized_draft_id,
            content_hash=normalized_hash,
        )
        return {"status": "sent", "draft_id": normalized_draft_id}

    @mcp.tool(description="List downloadable Teams files from a chat or channel message.")
    @_tool_errors
    def list_teams_message_files(
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        attachments = runtime.teams_client(
            include_channel_messages=team_id is not None and team_id.strip() != "",
        ).list_message_attachments(
            message_id=message_id,
            **_teams_message_locator(
                chat_id=chat_id,
                team_id=team_id,
                channel_id=channel_id,
            ),
        )
        return {"attachments": [serialize_teams_attachment(item) for item in attachments]}

    @mcp.tool(description="Read supported Teams file text from a chat or channel message.")
    @_tool_errors
    def read_teams_message_file(
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        if not attachment_id.strip():
            raise ValueError("attachment_id must be a non-empty string")
        extracted = runtime.teams_client(
            include_channel_messages=team_id is not None and team_id.strip() != "",
            include_files=True,
        ).read_message_attachment_text(
            message_id=message_id,
            attachment_id=attachment_id,
            max_chars=_positive_int(max_chars, "max_chars"),
            **_teams_message_locator(
                chat_id=chat_id,
                team_id=team_id,
                channel_id=channel_id,
            ),
        )
        return serialize_extracted_teams_file(extracted)

    @mcp.tool(description="List available mail folders.")
    @_tool_errors
    def list_folders() -> dict[str, Any]:
        return {"folders": runtime.email_client().list_folders()}

    @mcp.tool(description="List calendar events in a time window.")
    @_tool_errors
    def list_events(
        start: str,
        end: str,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> dict[str, Any]:
        start_dt, end_dt = _parse_window(start, end)
        events = runtime.calendar_client().list_events(
            start=start_dt,
            end=end_dt,
            calendar_id=_optional_str(calendar_id),
            calendar_filter=_optional_str(calendar_filter),
        )
        return {"events": [serialize_event(item) for item in events]}

    @mcp.tool(description="Get a single calendar event by id.")
    @_tool_errors
    def get_event(event_id: str) -> dict[str, Any]:
        if not event_id.strip():
            raise ValueError("event_id must be a non-empty string")
        return serialize_event(runtime.calendar_client().get_event(event_id))

    @mcp.tool(description="List meeting transcripts for an event, join URL, or online meeting id.")
    @_tool_errors
    def list_meeting_transcripts(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 10,
    ) -> dict[str, Any]:
        transcripts = runtime.calendar_client(
            include_meeting_transcripts=True
        ).list_meeting_transcripts(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            top=_positive_int(top, "top"),
        )
        return {"transcripts": [serialize_meeting_transcript(item) for item in transcripts]}

    @mcp.tool(
        description="Read meeting transcript text for an event, join URL, or online meeting id."
    )
    @_tool_errors
    def read_meeting_transcript(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        transcript_id: str | None = None,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        extracted = runtime.calendar_client(
            include_meeting_transcripts=True
        ).read_meeting_transcript(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            transcript_id=_optional_str(transcript_id),
            max_chars=_positive_int(max_chars, "max_chars"),
        )
        return serialize_extracted_meeting_transcript(extracted)

    @mcp.tool(
        description=(
            "Read Copilot-generated meeting notes for an event, join URL, or online "
            "meeting id."
        )
    )
    @_tool_errors
    def read_meeting_notes(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        ai_insight_id: str | None = None,
    ) -> dict[str, Any]:
        insight = runtime.calendar_client(
            include_meeting_notes=True
        ).read_meeting_ai_insight(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            ai_insight_id=_optional_str(ai_insight_id),
        )
        return serialize_meeting_ai_insight(insight)

    @mcp.tool(description="Search calendar events by subject.")
    @_tool_errors
    def search_events(
        query: str,
        start: str | None = None,
        end: str | None = None,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        start_dt = _parse_datetime(start, "start") if start is not None else None
        end_dt = _parse_datetime(end, "end") if end is not None else None
        if start_dt is not None and end_dt is not None and end_dt <= start_dt:
            raise ValueError("end must be later than start")
        events = runtime.calendar_client().search_events(query=query, start=start_dt, end=end_dt)
        return {"events": [serialize_event(item) for item in events]}

    @mcp.tool(description="List available calendars.")
    @_tool_errors
    def list_calendars() -> dict[str, Any]:
        return {"calendars": runtime.calendar_client().list_calendars()}

    @mcp.tool(description="Find open windows across attendees using Microsoft 365 free/busy.")
    @_tool_errors
    def find_free_slots(
        attendees: list[str],
        start: str,
        end: str,
        duration_minutes: int,
        ignore_subject_terms: list[str] | None = None,
    ) -> dict[str, Any]:
        normalized_attendees = [item.strip() for item in attendees if item.strip()]
        if not normalized_attendees:
            raise ValueError("attendees must contain at least one email address")
        start_dt, end_dt = _parse_window(start, end)
        response = runtime.graph_client().post(
            "calendar/getSchedule",
            body={
                "schedules": normalized_attendees,
                "startTime": {
                    "dateTime": start_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "endTime": {
                    "dateTime": end_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "availabilityViewInterval": _positive_int(duration_minutes, "duration_minutes"),
            },
        )
        windows = find_open_windows(
            response,
            start=start_dt,
            end=end_dt,
            duration_minutes=duration_minutes,
            ignore_subject_terms=ignore_subject_terms or [],
        )
        return {"windows": serialize_windows(windows)}

    @mcp.tool(description="List Teams chats for the current user.")
    @_tool_errors
    def list_chats(top: int = 25) -> dict[str, Any]:
        chats = runtime.teams_client(include_channel_messages=False).list_chats(
            top=_positive_int(top, "top")
        )
        return {"chats": [serialize_chat(item) for item in chats]}

    @mcp.tool(description="Search Teams chats by participant name, email, or topic.")
    @_tool_errors
    def search_chats(query: str, top: int = 10) -> dict[str, Any]:
        chats = runtime.teams_client(include_channel_messages=False).search_chats(
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"chats": [serialize_chat(item) for item in chats]}

    @mcp.tool(description="List messages from a Teams chat.")
    @_tool_errors
    def list_chat_messages(chat_id: str, top: int = 25) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=False).list_chat_messages(
            chat_id=chat_id,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search messages in a Teams chat.")
    @_tool_errors
    def search_chat_messages(chat_id: str, query: str, top: int = 10) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=False).search_chat_messages(
            chat_id=chat_id,
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search Teams messages across chats and channels.")
    @_tool_errors
    def search_teams_messages(query: str, top: int = 10) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).search_teams_messages(
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message_search_hit(item) for item in messages]}

    @mcp.tool(description="Read a single Teams chat message by id.")
    @_tool_errors
    def read_chat_message(chat_id: str, message_id: str) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=False).get_chat_message(
                chat_id,
                message_id,
            )
        )

    @mcp.tool(description="List Teams joined teams for the current user.")
    @_tool_errors
    def list_teams() -> dict[str, Any]:
        return {
            "teams": [
                serialize_team(item)
                for item in runtime.teams_client(include_channel_messages=False).list_teams()
            ]
        }

    @mcp.tool(description="List channels in a Teams team.")
    @_tool_errors
    def list_channels(team_id: str) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        channels = runtime.teams_client(include_channel_messages=False).list_channels(team_id)
        return {"channels": [serialize_channel(item) for item in channels]}

    @mcp.tool(description="List top-level messages in a Teams channel.")
    @_tool_errors
    def list_channel_messages(team_id: str, channel_id: str, top: int = 25) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).list_channel_messages(
            team_id=team_id,
            channel_id=channel_id,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search top-level messages in a Teams channel.")
    @_tool_errors
    def search_channel_messages(
        team_id: str,
        channel_id: str,
        query: str,
        top: int = 10,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).search_channel_messages(
            team_id=team_id,
            channel_id=channel_id,
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="List replies to a Teams channel message.")
    @_tool_errors
    def list_channel_replies(
        team_id: str,
        channel_id: str,
        message_id: str,
        top: int = 25,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        reply_page = runtime.teams_client(include_channel_messages=True).list_channel_replies(
            team_id=team_id,
            channel_id=channel_id,
            message_id=message_id,
            top=_positive_int(top, "top"),
        )
        return serialize_teams_reply_page(reply_page)

    @mcp.tool(description="Read a single Teams channel message by id.")
    @_tool_errors
    def read_channel_message(team_id: str, channel_id: str, message_id: str) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=True).get_channel_message(
                team_id,
                channel_id,
                message_id,
            )
        )

    @mcp.tool(description="Read a Teams channel thread, including replies.")
    @_tool_errors
    def read_channel_thread(
        team_id: str,
        channel_id: str,
        message_id: str,
        top: int = 25,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        thread = runtime.teams_client(include_channel_messages=True).read_channel_thread(
            team_id,
            channel_id,
            message_id,
            replies_top=_positive_int(top, "top"),
        )
        return serialize_teams_thread(thread)


def _tool_errors(func: Callable[P, R]) -> Callable[P, R]:
    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        try:
            return func(*args, **kwargs)
        except ValueError:
            raise
        except AuthenticationError as exc:
            raise RuntimeError(f"Authentication failed: {exc}") from exc
        except RateLimitedError as exc:
            raise RuntimeError(str(exc)) from exc
        except SafetyDeniedError as exc:
            raise RuntimeError(str(exc)) from exc
        except GraphAPIError as exc:
            raise RuntimeError(
                f"Microsoft Graph error {exc.status_code} ({exc.error_code}): {exc.message}"
            ) from exc
        except Exception as exc:
            raise RuntimeError("Internal MCP server error") from exc

    return wrapper


def _normalize_mailbox_filter(value: str) -> str | None:
    normalized = value.strip().lower()
    if normalized not in {"all", "focused"}:
        raise ValueError("filter must be 'all' or 'focused'")
    return None if normalized == "all" else normalized


def _parse_window(start: str, end: str) -> tuple[datetime, datetime]:
    start_dt = _parse_datetime(start, "start")
    end_dt = _parse_datetime(end, "end")
    if end_dt <= start_dt:
        raise ValueError("end must be later than start")
    return start_dt, end_dt


def _parse_datetime(value: str, field_name: str) -> datetime:
    raw = value.strip()
    if not raw:
        raise ValueError(f"{field_name} must be a non-empty ISO 8601 datetime")
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field_name} must be a valid ISO 8601 datetime") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone offset")
    return parsed.astimezone(UTC)


def _positive_int(value: int, field_name: str) -> int:
    if value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _non_negative_int(value: int, field_name: str) -> int:
    if value < 0:
        raise ValueError(f"{field_name} must be zero or greater")
    return value


def _optional_str(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _normalize_importance(value: str) -> str:
    normalized = value.strip().lower()
    if normalized not in {"low", "normal", "high"}:
        raise ValueError("importance must be one of: low, normal, high")
    return normalized


def _non_empty_emails(values: list[str], field_name: str) -> tuple[str, ...]:
    emails = _optional_emails(values)
    if not emails:
        raise ValueError(f"{field_name} must contain at least one email address")
    return emails


def _optional_emails(values: list[str] | None) -> tuple[str, ...]:
    if not values:
        return ()
    normalized = tuple(value.strip() for value in values if value.strip())
    if len(normalized) != len(values):
        raise ValueError("email lists must not contain empty values")
    return normalized


def _teams_message_locator(
    *,
    chat_id: str | None,
    team_id: str | None,
    channel_id: str | None,
) -> dict[str, str]:
    normalized_chat_id = _optional_str(chat_id)
    normalized_team_id = _optional_str(team_id)
    normalized_channel_id = _optional_str(channel_id)
    if normalized_chat_id is not None:
        if normalized_team_id is not None or normalized_channel_id is not None:
            raise ValueError("provide chat_id or both team_id and channel_id, not both")
        return {"chat_id": normalized_chat_id}
    if normalized_team_id is None or normalized_channel_id is None:
        raise ValueError("provide chat_id or both team_id and channel_id")
    return {
        "team_id": normalized_team_id,
        "channel_id": normalized_channel_id,
    }
