from __future__ import annotations

from fastmcp import FastMCP

from ms365_toolkit import __version__
from ms365_toolkit.mcp.runtime import ReadRuntime
from ms365_toolkit.mcp.tools import register_tools


def create_server(profile: str = "default", runtime: ReadRuntime | None = None) -> FastMCP:
    active_runtime = runtime or ReadRuntime.load(profile=profile)
    mcp = FastMCP(
        name="ms365-toolkit",
        instructions=(
            "Microsoft 365 mailbox, calendar, and Teams tools with guarded email draft and send "
            "support. "
            "All datetimes must be timezone-aware ISO 8601 strings."
        ),
        version=__version__,
    )
    register_tools(mcp, active_runtime)
    return mcp
