from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING

from ms365_toolkit.cli.read_common import build_write_email_client
from ms365_toolkit.client.exceptions import (
    AuthenticationError,
    GraphAPIError,
    RateLimitedError,
    SafetyDeniedError,
)

if TYPE_CHECKING:
    from argparse import Namespace

    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.models.email import EmailDraft


def create_email_draft_command(args: Namespace, config: ToolkitConfig) -> int:
    try:
        draft = build_write_email_client(config, args.profile).create_email_draft(
            to=_addresses(args.to),
            cc=_addresses(args.cc),
            bcc=_addresses(args.bcc),
            subject=args.subject,
            body=_body_value(args),
            reply_to=_addresses(args.reply_to),
            importance=_importance_value(args),
        )
    except (
        AuthenticationError,
        GraphAPIError,
        RateLimitedError,
        SafetyDeniedError,
        OSError,
        ValueError,
    ) as exc:
        return _print_write_error(exc)
    _print_email_draft(draft)
    return 0


def create_reply_draft_command(args: Namespace, config: ToolkitConfig) -> int:
    try:
        draft = build_write_email_client(config, args.profile).create_reply_draft(
            args.message_id,
            body=_body_value(args),
            importance=_optional_importance_value(args),
        )
    except (
        AuthenticationError,
        GraphAPIError,
        RateLimitedError,
        SafetyDeniedError,
        OSError,
        ValueError,
    ) as exc:
        return _print_write_error(exc)
    _print_email_draft(draft)
    return 0


def send_email_draft_command(args: Namespace, config: ToolkitConfig) -> int:
    try:
        draft_id = args.draft_id.strip()
        build_write_email_client(config, args.profile).send_email_draft(
            draft_id,
            content_hash=args.content_hash.strip(),
        )
    except (
        AuthenticationError,
        GraphAPIError,
        RateLimitedError,
        SafetyDeniedError,
        OSError,
        ValueError,
    ) as exc:
        return _print_write_error(exc)
    print(f"Sent draft {draft_id}")
    return 0


def _addresses(value: list[str] | None) -> tuple[str, ...]:
    if not value:
        return ()
    normalized = tuple(item.strip() for item in value)
    if any(not item for item in normalized):
        raise ValueError("email lists must not contain empty values")
    return normalized


def _body_value(args: Namespace) -> str:
    body = getattr(args, "body", None)
    if body is not None:
        if not isinstance(body, str):
            raise ValueError("--body must be a string")
        return body
    body_file = getattr(args, "body_file", None)
    if not isinstance(body_file, str) or not body_file.strip():
        raise ValueError("provide --body or --body-file")
    return Path(body_file).read_text(encoding="utf-8")


def _importance_value(args: Namespace) -> str:
    value = getattr(args, "importance", "normal")
    return str(value).strip().lower()


def _optional_importance_value(args: Namespace) -> str | None:
    value = getattr(args, "importance", None)
    if value is None:
        return None
    return str(value).strip().lower()


def _print_email_draft(draft: EmailDraft) -> None:
    print(f"Draft ID: {draft.draft_id}")
    print(f"Content Hash: {draft.content_hash}")
    print(f"Created: {draft.created_at.isoformat()}")
    print(f"Importance: {draft.importance}")
    print(f"To: {', '.join(draft.to) or '(none)'}")
    if draft.cc:
        print(f"Cc: {', '.join(draft.cc)}")
    if draft.bcc:
        print(f"Bcc: {', '.join(draft.bcc)}")
    if draft.reply_to:
        print(f"Reply-To: {', '.join(draft.reply_to)}")
    print(f"Subject: {draft.subject or '(no subject)'}")
    if draft.attachments:
        print("Attachments:")
        for attachment in draft.attachments:
            print(f" - {attachment.name or '(unnamed attachment)'}")
    print("Body:")
    print(draft.body or "(empty body)")


def _print_write_error(exc: Exception) -> int:
    if isinstance(exc, AuthenticationError):
        print(f"Authentication failed: {exc}", file=sys.stderr)
        return 1
    if isinstance(exc, RateLimitedError):
        print(str(exc), file=sys.stderr)
        return 1
    if isinstance(exc, GraphAPIError):
        print(
            f"Microsoft Graph error {exc.status_code} ({exc.error_code}): {exc.message}",
            file=sys.stderr,
        )
        return 1
    print(str(exc), file=sys.stderr)
    return 1
