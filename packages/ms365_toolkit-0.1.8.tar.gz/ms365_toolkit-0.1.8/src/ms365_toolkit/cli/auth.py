from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import msal  # type: ignore[import-untyped]

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.device_code import DeviceCodePrompt, authenticate_device_code
from ms365_toolkit.auth.tokens import TokenBundle, TokenManager
from ms365_toolkit.client.exceptions import AuthenticationError
from ms365_toolkit.config.loader import ToolkitConfig
from ms365_toolkit.models.enums import (
    CHANNEL_MESSAGE_READ_SCOPES,
    MEETING_AI_INSIGHT_READ_SCOPES,
    MEETING_TRANSCRIPT_READ_SCOPES,
    TEAMS_FILE_READ_SCOPES,
)

if TYPE_CHECKING:
    from argparse import Namespace

    from ms365_toolkit.config.loader import ToolkitConfig


AUTHORITY_TEMPLATE = "https://login.microsoftonline.com/{tenant_id}"


@dataclass(frozen=True)
class AuthStatus:
    logged_in: bool
    scopes: tuple[str, ...]
    expires_at: str | None


def login_command(args: Namespace, config: ToolkitConfig) -> int:
    store = CredentialStore(profile=args.profile)
    authenticate_device_code(
        config=config,
        credential_store=store,
        write=bool(args.write),
        extra_scopes=_login_extra_scopes(args),
        presenter=_print_device_code_prompt,
        app_factory=lambda cache: build_public_client_application(config, cache),
        allow_env_write=bool(args.insecure_env_write),
    )
    print(f"Stored {'write' if args.write else 'read'} token cache for profile {args.profile}.")
    return 0


def status_command(args: Namespace, config: ToolkitConfig) -> int:
    write = bool(getattr(args, "write", False))
    status = get_auth_status(profile=args.profile, config=config, write=write)
    if not status.logged_in:
        if write:
            print(f"Profile {args.profile}: write token not available")
            return 1
        print(f"Profile {args.profile}: not logged in")
        return 1
    scopes = ", ".join(status.scopes)
    if write:
        print(f"Profile {args.profile}: logged in for write scopes")
    else:
        print(f"Profile {args.profile}: logged in")
    print(f"Scopes: {scopes}")
    if status.expires_at is not None:
        print(f"Expires: {status.expires_at}")
    return 0


def revoke_write_command(args: Namespace) -> int:
    store = CredentialStore(profile=args.profile)
    store.delete_cache(kind="write")
    print(f"Removed write token cache for profile {args.profile}.")
    return 0


def get_auth_status(profile: str, config: ToolkitConfig, *, write: bool = False) -> AuthStatus:
    store = CredentialStore(profile=profile)
    try:
        bundle = _load_bundle(config=config, store=store, write=write)
    except AuthenticationError:
        return AuthStatus(logged_in=False, scopes=(), expires_at=None)
    return AuthStatus(
        logged_in=True,
        scopes=tuple(sorted(bundle.scopes)),
        expires_at=bundle.expires_at.isoformat(),
    )


def _load_bundle(config: ToolkitConfig, store: CredentialStore, *, write: bool) -> TokenBundle:
    manager = TokenManager(
        config=config,
        credential_store=store,
        app_factory=lambda cache: build_public_client_application(config, cache),
    )
    return manager.get_access_token(write=write)


def build_public_client_application(
    config: ToolkitConfig,
    cache: msal.SerializableTokenCache,
) -> msal.PublicClientApplication:
    return msal.PublicClientApplication(
        client_id=config.auth.client_id,
        authority=AUTHORITY_TEMPLATE.format(tenant_id=config.auth.tenant_id),
        token_cache=cache,
    )


def _print_device_code_prompt(prompt: DeviceCodePrompt) -> None:
    print(prompt.message)
    print(f"Verification URL: {prompt.verification_uri}")
    print(f"User code: {prompt.user_code}")


def _login_extra_scopes(args: Namespace) -> frozenset[str] | None:
    scopes = frozenset[str]()
    if bool(getattr(args, "teams_channel_messages", False)):
        scopes |= CHANNEL_MESSAGE_READ_SCOPES
    if bool(getattr(args, "teams_files", False)):
        scopes |= TEAMS_FILE_READ_SCOPES
    if bool(getattr(args, "meeting_transcripts", False)):
        scopes |= MEETING_TRANSCRIPT_READ_SCOPES
    if bool(getattr(args, "meeting_notes", False)):
        scopes |= MEETING_AI_INSIGHT_READ_SCOPES
    return scopes or None
