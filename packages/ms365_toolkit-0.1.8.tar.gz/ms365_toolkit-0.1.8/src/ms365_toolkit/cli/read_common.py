from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.tokens import TokenManager
from ms365_toolkit.cli.auth import build_public_client_application
from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.client.mail_index import MailboxIndex
from ms365_toolkit.config.loader import get_profile_dir
from ms365_toolkit.safety.audit import AuditLogger
from ms365_toolkit.safety.dialog import show_confirmation_dialog
from ms365_toolkit.safety.gate import ConfiguredSafetyGate, DialogPreview, SafetyResult
from ms365_toolkit.safety.rate_limiter import RateLimiter

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig


def build_read_clients(config: ToolkitConfig, profile: str) -> tuple[EmailClient, CalendarClient]:
    graph = build_read_graph_client(config, profile)
    return EmailClient(graph), CalendarClient(graph)


def build_read_graph_client(
    config: ToolkitConfig,
    profile: str,
    *,
    extra_scopes: frozenset[str] | None = None,
) -> GraphClient:
    store = CredentialStore(profile=profile)
    manager = TokenManager(
        config=config,
        credential_store=store,
        app_factory=lambda cache: build_public_client_application(config, cache),
    )
    bundle = manager.get_access_token(write=False, extra_scopes=extra_scopes)
    return GraphClient(config=config, token=bundle.access_token)


def build_write_graph_client(
    config: ToolkitConfig,
    profile: str,
) -> GraphClient:
    store = CredentialStore(profile=profile)
    manager = TokenManager(
        config=config,
        credential_store=store,
        app_factory=lambda cache: build_public_client_application(config, cache),
    )
    bundle = manager.get_access_token(write=True)
    return GraphClient(config=config, token=bundle.access_token)


def build_write_email_client(config: ToolkitConfig, profile: str) -> EmailClient:
    return EmailClient(
        build_write_graph_client(config, profile),
        safety_gate=build_safety_gate(config, profile),
    )


def build_mailbox_index(profile: str) -> MailboxIndex:
    return MailboxIndex(get_profile_dir(profile) / "mail_index.db")


def build_safety_gate(config: ToolkitConfig, profile: str) -> ConfiguredSafetyGate:
    profile_dir = get_profile_dir(profile)
    safety_dir = profile_dir / "safety"
    return ConfiguredSafetyGate(
        config=config,
        rate_limiter=RateLimiter(
            profile=profile,
            rate_limits=config.safety.rate_limits,
            path=safety_dir / "rate_limits.sqlite3",
        ),
        audit_logger=AuditLogger(path=safety_dir / "audit.jsonl"),
        dialog=_confirmation_dialog,
    )


def _confirmation_dialog(preview: DialogPreview) -> SafetyResult:
    result = show_confirmation_dialog(preview)
    if result.reason == "dialog_preflight_failed":
        return SafetyResult(True, "dialog_skipped")
    return result
