from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any, Protocol, TypeVar
from urllib.parse import quote

import jwt

from ms365_toolkit.client.exceptions import AuthenticationError, GraphAPIError
from ms365_toolkit.client.sanitize import strip_html
from ms365_toolkit.models.calendar import (
    Attendee,
    CalendarEvent,
    ExtractedMeetingTranscript,
    FreeBusySlot,
    MeetingActionItem,
    MeetingAiInsight,
    MeetingMentionEvent,
    MeetingNotePoint,
    MeetingTranscript,
)

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient


class SupportsMeetingWindow(Protocol):
    created_at: datetime
    end_at: datetime


T = TypeVar("T", bound=SupportsMeetingWindow)


class CalendarClient:
    def __init__(
        self,
        graph: GraphClient,
        *,
        online_meeting_graph: GraphClient | None = None,
        transcript_graph: GraphClient | None = None,
        ai_insights_graph: GraphClient | None = None,
    ) -> None:
        self.graph = graph
        self.online_meeting_graph = online_meeting_graph or graph
        self.transcript_graph = transcript_graph or self.online_meeting_graph
        self.ai_insights_graph = ai_insights_graph

    def list_events(
        self,
        *,
        start: datetime,
        end: datetime,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> list[CalendarEvent]:
        path = f"calendars/{calendar_id}/calendarView" if calendar_id else "calendarView"
        query: dict[str, Any] = {
            "startDateTime": _to_graph_datetime(start),
            "endDateTime": _to_graph_datetime(end),
            "$orderby": "start/dateTime",
        }
        if calendar_filter:
            query["$filter"] = calendar_filter
        response = self.graph.get(path, query=query)
        return [self._event_from_item(item) for item in response.get("value", [])]

    def get_event(self, event_id: str) -> CalendarEvent:
        response = self.graph.get(f"events/{event_id}")
        return self._event_from_item(response)

    def find_free_slots(
        self,
        *,
        attendees: list[str],
        start: datetime,
        end: datetime,
        duration: int,
    ) -> list[FreeBusySlot]:
        response = self.graph.post(
            "calendar/getSchedule",
            body={
                "schedules": attendees,
                "startTime": {"dateTime": _to_graph_datetime(start), "timeZone": "UTC"},
                "endTime": {"dateTime": _to_graph_datetime(end), "timeZone": "UTC"},
                "availabilityViewInterval": duration,
            },
        )
        slots: list[FreeBusySlot] = []
        for schedule in response.get("value", []):
            for item in schedule.get("scheduleItems", []):
                slots.append(
                    FreeBusySlot(
                        start=_parse_graph_datetime(item.get("start", {}).get("dateTime")),
                        end=_parse_graph_datetime(item.get("end", {}).get("dateTime")),
                        status=item.get("status", "unknown"),
                    )
                )
        return slots

    def list_calendars(self) -> list[dict[str, str]]:
        response = self.graph.get("calendars", query={"$top": 100})
        return [
            {"id": item.get("id", ""), "name": item.get("name", "")}
            for item in response.get("value", [])
        ]

    def search_events(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CalendarEvent]:
        filters = [f"contains(subject,'{_escape_odata_string(query)}')"]
        if start is not None:
            filters.append(f"start/dateTime ge '{_to_graph_datetime(start)}'")
        if end is not None:
            filters.append(f"end/dateTime le '{_to_graph_datetime(end)}'")
        response = self.graph.get("events", query={"$filter": " and ".join(filters)})
        return [self._event_from_item(item) for item in response.get("value", [])]

    def list_meeting_transcripts(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 25,
    ) -> list[MeetingTranscript]:
        self._ensure_supported_online_meeting_endpoint()
        event = self._event_for_online_meeting_artifact(event_id)
        meeting_id = self._resolve_online_meeting_id(
            join_web_url=event.join_url if event is not None else join_web_url,
            online_meeting_id=online_meeting_id,
        )
        transcripts = self._meeting_transcripts(
            meeting_id,
            top=_bounded_top(top, maximum=50),
        )
        if event is None:
            return transcripts
        return self._transcripts_for_event_window(transcripts, event=event)

    def read_meeting_transcript(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        transcript_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedMeetingTranscript:
        if max_chars <= 0:
            raise ValueError("max_chars must be a positive integer")
        self._ensure_supported_online_meeting_endpoint()
        event = self._event_for_online_meeting_artifact(event_id)
        meeting_id = self._resolve_online_meeting_id(
            join_web_url=event.join_url if event is not None else join_web_url,
            online_meeting_id=online_meeting_id,
        )
        transcripts = self._meeting_transcripts(meeting_id, top=None)
        if event is not None and transcript_id is None:
            transcripts = self._transcripts_for_event_window(transcripts, event=event)
        transcript = self._select_transcript(transcripts, transcript_id=transcript_id)
        try:
            content = self.transcript_graph.get_bytes(
                "onlineMeetings/"
                f"{_path_segment('online_meeting_id', meeting_id)}/transcripts/"
                f"{_path_segment('transcript_id', transcript.id)}/content"
            ).decode("utf-8", errors="replace")
        except GraphAPIError as exc:
            raise _meeting_transcript_permission_error(exc) from exc
        text_content = _extract_transcript_text(content)
        warnings: list[str] = []
        if not text_content:
            warnings.append("No extractable transcript text found.")
        text_content, is_truncated = _truncate_text(text_content, max_chars)
        if is_truncated:
            warnings.append(f"Content truncated to {max_chars} characters.")
        return ExtractedMeetingTranscript(
            transcript=transcript,
            format="vtt" if content.lstrip().startswith("WEBVTT") else "text",
            text_content=text_content,
            is_truncated=is_truncated,
            warnings=tuple(warnings),
        )

    def list_meeting_ai_insights(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 10,
    ) -> list[MeetingAiInsight]:
        self._ensure_supported_online_meeting_endpoint()
        graph = self._require_ai_insights_graph()
        user_id = _current_user_id(graph.token)
        if not user_id:
            raise AuthenticationError("meeting notes require a signed-in user token")
        event = self._event_for_online_meeting_artifact(event_id)
        meeting_id = self._resolve_online_meeting_id(
            join_web_url=event.join_url if event is not None else join_web_url,
            online_meeting_id=online_meeting_id,
        )
        insights = self._meeting_ai_insights(
            graph,
            user_id=user_id,
            meeting_id=meeting_id,
            top=_bounded_top(top, maximum=25),
        )
        if event is None:
            return insights
        return self._ai_insights_for_event_window(insights, event=event)

    def read_meeting_ai_insight(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        ai_insight_id: str | None = None,
    ) -> MeetingAiInsight:
        self._ensure_supported_online_meeting_endpoint()
        graph = self._require_ai_insights_graph()
        user_id = _current_user_id(graph.token)
        if not user_id:
            raise AuthenticationError("meeting notes require a signed-in user token")
        event = self._event_for_online_meeting_artifact(event_id)
        meeting_id = self._resolve_online_meeting_id(
            join_web_url=event.join_url if event is not None else join_web_url,
            online_meeting_id=online_meeting_id,
        )
        insights = self._meeting_ai_insights(
            graph,
            user_id=user_id,
            meeting_id=meeting_id,
            top=None,
        )
        if event is not None and ai_insight_id is None:
            insights = self._ai_insights_for_event_window(insights, event=event)
        insight = self._select_ai_insight(insights, ai_insight_id=ai_insight_id)
        try:
            response = graph.get(
                "https://graph.microsoft.com/v1.0/copilot/users/"
                f"{_path_segment('user_id', user_id)}/onlineMeetings/"
                f"{_path_segment('online_meeting_id', meeting_id)}/aiInsights/"
                f"{_path_segment('ai_insight_id', insight.id)}"
            )
        except GraphAPIError as exc:
            raise _meeting_notes_permission_error(exc) from exc
        if not isinstance(response, dict):
            raise GraphAPIError(0, "InvalidMeetingInsight", "meeting insight lookup failed")
        return self._ai_insight_from_item(response)

    def _event_from_item(self, item: dict[str, Any]) -> CalendarEvent:
        attendees = tuple(self._attendee_from_item(value) for value in item.get("attendees", []))
        body = item.get("body", {}).get("content", "")
        start_time = item.get("start", {})
        end_time = item.get("end", {})
        location = item.get("location", {}).get("displayName", "")
        response_status = item.get("responseStatus", {}).get("response", "none")
        organizer = (
            item.get("organizer", {})
            .get("emailAddress", {})
            .get("address", "")
        )
        return CalendarEvent(
            id=item.get("id", ""),
            subject=item.get("subject", ""),
            start=_parse_graph_datetime(start_time.get("dateTime")),
            end=_parse_graph_datetime(end_time.get("dateTime")),
            timezone=start_time.get("timeZone", "UTC"),
            location=location,
            body_content=strip_html(body),
            attendees=attendees,
            is_online_meeting=bool(item.get("isOnlineMeeting", False)),
            is_cancelled=bool(item.get("isCancelled", False)),
            importance=item.get("importance", "normal"),
            categories=tuple(item.get("categories", [])),
            recurrence=str(item.get("recurrence")) if item.get("recurrence") is not None else None,
            organizer=organizer,
            response_status=response_status,
            calendar_id=item.get("calendar", {}).get("id", ""),
            join_url=_event_join_url(item),
            ical_uid=_string_value(item.get("iCalUId")),
        )

    def _attendee_from_item(self, item: dict[str, Any]) -> Attendee:
        email = item.get("emailAddress", {})
        status = item.get("status", {})
        return Attendee(
            email=email.get("address", ""),
            name=email.get("name", ""),
            response=status.get("response", "none"),
            type=item.get("type", "required"),
        )

    def _resolve_online_meeting_id(
        self,
        *,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
    ) -> str:
        if online_meeting_id is not None and online_meeting_id.strip():
            return online_meeting_id.strip()
        normalized_join_url = (join_web_url or "").strip()
        if not normalized_join_url:
            raise ValueError("provide join_web_url or online_meeting_id")
        response = self.online_meeting_graph.get(
            "onlineMeetings",
            query={
                "$filter": f"JoinWebUrl eq '{_escape_odata_string(normalized_join_url)}'",
            },
        )
        for item in response.get("value", []):
            if not isinstance(item, dict):
                continue
            meeting_id = _string_value(item.get("id"))
            if meeting_id:
                return meeting_id
        raise ValueError("online meeting was not found for the provided join URL")

    def _event_for_online_meeting_artifact(self, event_id: str | None) -> CalendarEvent | None:
        if event_id is None or not event_id.strip():
            return None
        event = self.graph.get(
            f"events/{_path_segment('event_id', event_id)}",
            query={"$select": "id,start,end,isOnlineMeeting,onlineMeeting,onlineMeetingUrl"},
        )
        if not isinstance(event, dict):
            raise GraphAPIError(0, "InvalidEvent", "event lookup failed")
        parsed = self._event_from_item(event)
        if parsed.join_url:
            return parsed
        raise ValueError("event does not have an online meeting join URL")

    def _meeting_transcripts(
        self,
        meeting_id: str,
        *,
        top: int | None,
    ) -> list[MeetingTranscript]:
        try:
            items = _paged_graph_values(
                self.transcript_graph,
                f"onlineMeetings/{_path_segment('online_meeting_id', meeting_id)}/transcripts",
                query={"$top": top} if top is not None else None,
                maximum=top,
            )
        except GraphAPIError as exc:
            raise _meeting_transcript_permission_error(exc) from exc
        return [self._transcript_from_item(item) for item in items]

    def _meeting_ai_insights(
        self,
        graph: GraphClient,
        *,
        user_id: str,
        meeting_id: str,
        top: int | None,
    ) -> list[MeetingAiInsight]:
        try:
            items = _paged_graph_values(
                graph,
                (
                    "https://graph.microsoft.com/v1.0/copilot/users/"
                    f"{_path_segment('user_id', user_id)}/onlineMeetings/"
                    f"{_path_segment('online_meeting_id', meeting_id)}/aiInsights"
                ),
                query={"$top": top} if top is not None else None,
                maximum=top,
            )
        except GraphAPIError as exc:
            raise _meeting_notes_permission_error(exc) from exc
        return [self._ai_insight_from_item(item) for item in items]

    def _transcript_from_item(self, item: dict[str, Any]) -> MeetingTranscript:
        organizer = item.get("meetingOrganizer")
        if not isinstance(organizer, dict):
            organizer = {}
        organizer_user = organizer.get("user")
        if not isinstance(organizer_user, dict):
            organizer_user = {}
        return MeetingTranscript(
            id=_string_value(item.get("id")),
            meeting_id=_string_value(item.get("meetingId")),
            call_id=_string_value(item.get("callId")),
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            end_at=_parse_graph_datetime(item.get("endDateTime")),
            content_correlation_id=_string_value(item.get("contentCorrelationId")),
            transcript_content_url=_string_value(item.get("transcriptContentUrl")),
            organizer_user_id=_string_value(organizer_user.get("id")),
            organizer_display_name=_string_value(organizer_user.get("displayName")),
            organizer_tenant_id=_string_value(organizer_user.get("tenantId")),
        )

    def _ai_insight_from_item(self, item: dict[str, Any]) -> MeetingAiInsight:
        viewpoint = item.get("viewpoint")
        if not isinstance(viewpoint, dict):
            viewpoint = {}
        return MeetingAiInsight(
            id=_string_value(item.get("id")),
            call_id=_string_value(item.get("callId")),
            content_correlation_id=_string_value(item.get("contentCorrelationId")),
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            end_at=_parse_graph_datetime(item.get("endDateTime")),
            meeting_notes=tuple(
                self._meeting_note_point_from_item(note) for note in item.get("meetingNotes", [])
            ),
            action_items=tuple(
                self._meeting_action_item_from_item(action)
                for action in item.get("actionItems", [])
            ),
            mention_events=tuple(
                self._meeting_mention_event_from_item(event)
                for event in viewpoint.get("mentionEvents", [])
            ),
        )

    def _meeting_note_point_from_item(self, item: dict[str, Any]) -> MeetingNotePoint:
        return MeetingNotePoint(
            title=_string_value(item.get("title")),
            text=_string_value(item.get("text")),
            subpoints=tuple(
                self._meeting_note_point_from_item(subpoint)
                for subpoint in item.get("subpoints", [])
            ),
        )

    def _meeting_action_item_from_item(self, item: dict[str, Any]) -> MeetingActionItem:
        return MeetingActionItem(
            title=_string_value(item.get("title")),
            text=_string_value(item.get("text")),
            owner_display_name=_string_value(item.get("ownerDisplayName")),
        )

    def _meeting_mention_event_from_item(self, item: dict[str, Any]) -> MeetingMentionEvent:
        speaker = item.get("speaker")
        if not isinstance(speaker, dict):
            speaker = {}
        speaker_user = speaker.get("user")
        if not isinstance(speaker_user, dict):
            speaker_user = {}
        return MeetingMentionEvent(
            event_at=_parse_graph_datetime(item.get("eventDateTime")),
            speaker_name=_string_value(speaker_user.get("displayName")),
            speaker_user_id=_string_value(speaker_user.get("id")),
            transcript_utterance=_string_value(item.get("transcriptUtterance")),
        )

    def _select_transcript(
        self,
        transcripts: list[MeetingTranscript],
        *,
        transcript_id: str | None,
    ) -> MeetingTranscript:
        if transcript_id is not None and transcript_id.strip():
            for transcript in transcripts:
                if transcript.id == transcript_id.strip():
                    return transcript
            raise ValueError("transcript_id was not found for the specified meeting")
        if not transcripts:
            raise ValueError("no transcripts were found for the specified meeting")
        return max(transcripts, key=lambda item: item.created_at.timestamp())

    def _select_ai_insight(
        self,
        insights: list[MeetingAiInsight],
        *,
        ai_insight_id: str | None,
    ) -> MeetingAiInsight:
        if ai_insight_id is not None and ai_insight_id.strip():
            for insight in insights:
                if insight.id == ai_insight_id.strip():
                    return insight
            raise ValueError("ai_insight_id was not found for the specified meeting")
        if not insights:
            raise ValueError("no meeting notes were found for the specified meeting")
        return max(insights, key=lambda item: item.created_at.timestamp())

    def _ensure_supported_online_meeting_endpoint(self) -> None:
        if self.graph.config.user.endpoint != "me":
            raise ValueError("Meeting transcripts and notes only support user.endpoint='me'")

    def _transcripts_for_event_window(
        self,
        transcripts: list[MeetingTranscript],
        *,
        event: CalendarEvent,
    ) -> list[MeetingTranscript]:
        return _artifacts_for_event_window(transcripts, event=event)

    def _ai_insights_for_event_window(
        self,
        insights: list[MeetingAiInsight],
        *,
        event: CalendarEvent,
    ) -> list[MeetingAiInsight]:
        return _artifacts_for_event_window(insights, event=event)

    def _require_ai_insights_graph(self) -> GraphClient:
        if self.ai_insights_graph is None:
            raise AuthenticationError("meeting notes are not configured for this client")
        return self.ai_insights_graph


def _to_graph_datetime(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _parse_graph_datetime(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        return datetime.fromtimestamp(0, tz=UTC)
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _extract_transcript_text(content: str) -> str:
    blocks = re.split(r"\r?\n\r?\n", content.replace("\ufeff", "").strip())
    chunks: list[str] = []
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        if lines[0].upper() in {"WEBVTT", "STYLE", "REGION"} or lines[0].startswith("NOTE"):
            continue
        timestamp_index = next((index for index, line in enumerate(lines) if "-->" in line), -1)
        if timestamp_index < 0:
            continue
        text_lines = [_normalize_transcript_line(line) for line in lines[timestamp_index + 1 :]]
        text = "\n".join(line for line in text_lines if line).strip()
        if text:
            chunks.append(text)
    return "\n\n".join(chunks)


def _normalize_transcript_line(line: str) -> str:
    normalized = line.strip()
    if not normalized:
        return ""
    match = re.match(r"<v(?:\s+([^>]+))?>(.*)", normalized)
    if match is not None:
        speaker = (match.group(1) or "").strip()
        text = strip_html(match.group(2)).strip()
        if speaker and text:
            return f"{speaker}: {text}"
        return text or speaker
    return strip_html(normalized).strip()


def _truncate_text(text: str, max_chars: int) -> tuple[str, bool]:
    if len(text) <= max_chars:
        return text, False
    return text[:max_chars].rstrip(), True


def _escape_odata_string(value: str) -> str:
    return value.replace("'", "''")


def _string_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    return ""


def _event_join_url(item: dict[str, Any]) -> str:
    online_meeting = item.get("onlineMeeting")
    if isinstance(online_meeting, dict):
        join_url = _string_value(online_meeting.get("joinUrl"))
        if join_url:
            return join_url
    return _string_value(item.get("onlineMeetingUrl"))


def _current_user_id(token: str) -> str:
    try:
        payload = jwt.decode(token, options={"verify_signature": False, "verify_aud": False})
    except jwt.PyJWTError:
        payload = {}
    return _string_value(payload.get("oid") or payload.get("sub"))


def _paged_graph_values(
    graph: GraphClient,
    path: str,
    *,
    query: dict[str, Any] | None = None,
    maximum: int | None = None,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    next_path = path
    next_query = query
    while next_path:
        response = graph.get(next_path, query=next_query)
        values = [item for item in response.get("value", []) if isinstance(item, dict)]
        if maximum is None:
            items.extend(values)
        else:
            remaining = maximum - len(items)
            if remaining <= 0:
                break
            items.extend(values[:remaining])
            if len(items) >= maximum:
                break
        next_path = _string_value(response.get("@odata.nextLink"))
        next_query = None
    return items


def _artifacts_for_event_window(items: list[T], *, event: CalendarEvent) -> list[T]:
    grace_before = timedelta(hours=1)
    grace_after = timedelta(hours=2)
    by_end = [item for item in items if event.start <= item.end_at <= (event.end + grace_after)]
    if by_end:
        return by_end
    by_created = [
        item
        for item in items
        if (event.start - grace_before) <= item.created_at <= (event.end + grace_after)
    ]
    return by_created or items


def _path_segment(name: str, value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{name} must be a non-empty string")
    return quote(normalized, safe="")


def _bounded_top(value: int, *, maximum: int) -> int:
    if value <= 0:
        raise ValueError("top must be a positive integer")
    return min(value, maximum)


def _meeting_transcript_permission_error(error: GraphAPIError) -> GraphAPIError:
    return _permission_error(
        error,
        markers=("onlinemeetingtranscript.read.all",),
        message=(
            "Meeting transcript reads require OnlineMeetingTranscript.Read.All consent; "
            "run auth login --meeting-transcripts"
        ),
    )


def _meeting_notes_permission_error(error: GraphAPIError) -> GraphAPIError:
    return _permission_error(
        error,
        markers=("onlinemeetingaiinsight.read.all",),
        message=(
            "Meeting notes require OnlineMeetingAiInsight.Read.All consent and a "
            "Copilot-licensed user; run auth login --meeting-notes"
        ),
    )


def _permission_error(
    error: GraphAPIError,
    *,
    markers: tuple[str, ...],
    message: str,
) -> GraphAPIError:
    if error.status_code != 403:
        return error
    normalized_message = error.message.lower()
    if not any(
        marker in normalized_message
        for marker in (*markers, "missing role permissions", "insufficient privileges")
    ):
        return error
    return GraphAPIError(error.status_code, error.error_code, message)
