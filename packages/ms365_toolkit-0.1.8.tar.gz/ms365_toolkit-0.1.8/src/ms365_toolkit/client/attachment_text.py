from __future__ import annotations

from io import BytesIO
from pathlib import Path

from docx import Document
from openpyxl import load_workbook
from pptx import Presentation
from pypdf import PdfReader

from ms365_toolkit.models.email import EmailAttachment, ExtractedAttachment

_CONTENT_TYPE_FORMATS = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
}


def extract_attachment_text(
    attachment: EmailAttachment,
    content: bytes,
    *,
    max_chars: int = 50_000,
) -> ExtractedAttachment:
    if max_chars <= 0:
        raise ValueError("max_chars must be a positive integer")
    format_name = _detect_format(attachment)
    extractor = {
        "pdf": _extract_pdf_text,
        "docx": _extract_docx_text,
        "xlsx": _extract_xlsx_text,
        "pptx": _extract_pptx_text,
    }[format_name]
    try:
        text_content = extractor(content)
    except Exception as exc:
        raise ValueError(f"attachment could not be parsed as {format_name}") from exc
    warnings: list[str] = []
    if not text_content:
        warnings.append("No extractable text found.")
    text_content, is_truncated = _truncate_text(text_content, max_chars)
    if is_truncated:
        warnings.append(f"Content truncated to {max_chars} characters.")
    return ExtractedAttachment(
        attachment=attachment,
        format=format_name,
        text_content=text_content,
        is_truncated=is_truncated,
        warnings=tuple(warnings),
    )


def _detect_format(attachment: EmailAttachment) -> str:
    suffix = Path(attachment.name).suffix.lower().lstrip(".")
    if suffix in {"pdf", "docx", "xlsx", "pptx"}:
        return suffix
    content_type = attachment.content_type.lower()
    if content_type in _CONTENT_TYPE_FORMATS:
        return _CONTENT_TYPE_FORMATS[content_type]
    label = attachment.name or attachment.content_type or attachment.id
    raise ValueError(
        f"attachment format is not supported: {label}"
    )


def _extract_pdf_text(content: bytes) -> str:
    reader = PdfReader(BytesIO(content))
    chunks: list[str] = []
    for index, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if text:
            chunks.append(f"[Page {index}]\n{text}")
    return "\n\n".join(chunks)


def _extract_docx_text(content: bytes) -> str:
    document = Document(BytesIO(content))
    chunks: list[str] = []
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if text:
            chunks.append(text)
    for table_index, table in enumerate(document.tables, start=1):
        rows: list[str] = []
        for row in table.rows:
            values = [cell.text.strip() for cell in row.cells]
            if any(values):
                rows.append("\t".join(values))
        if rows:
            chunks.append(f"[Table {table_index}]")
            chunks.extend(rows)
    return "\n".join(chunks)


def _extract_xlsx_text(content: bytes) -> str:
    workbook = load_workbook(BytesIO(content), data_only=True)
    chunks: list[str] = []
    for worksheet in workbook.worksheets:
        rows: list[str] = []
        for row in worksheet.iter_rows(values_only=True):
            values = ["" if value is None else str(value).strip() for value in row]
            if any(values):
                rows.append("\t".join(values))
        if rows:
            chunks.append(f"[Sheet {worksheet.title}]")
            chunks.extend(rows)
    return "\n".join(chunks)


def _extract_pptx_text(content: bytes) -> str:
    presentation = Presentation(BytesIO(content))
    chunks: list[str] = []
    for index, slide in enumerate(presentation.slides, start=1):
        slide_chunks: list[str] = []
        for shape in slide.shapes:
            text = getattr(shape, "text", "").strip()
            if text:
                slide_chunks.append(text)
        if slide_chunks:
            chunks.append(f"[Slide {index}]")
            chunks.extend(slide_chunks)
    return "\n".join(chunks)


def _truncate_text(text: str, max_chars: int) -> tuple[str, bool]:
    if len(text) <= max_chars:
        return text, False
    return text[:max_chars].rstrip(), True
