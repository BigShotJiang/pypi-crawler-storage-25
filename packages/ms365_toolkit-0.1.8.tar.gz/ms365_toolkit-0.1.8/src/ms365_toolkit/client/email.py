from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ms365_toolkit.client.attachment_text import extract_attachment_text
from ms365_toolkit.client.exceptions import GraphAPIError, SafetyDeniedError
from ms365_toolkit.client.sanitize import sanitize_email_body
from ms365_toolkit.models.email import (
    AttachmentInfo,
    EmailAttachment,
    EmailDraft,
    EmailMessage,
    ExtractedAttachment,
)
from ms365_toolkit.safety import DialogPreview, WriteOperation, canonicalize_email, compute_hash

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient
    from ms365_toolkit.safety import SafetyGate


class EmailClient:
    def __init__(self, graph: GraphClient, *, safety_gate: SafetyGate | None = None) -> None:
        self.graph = graph
        self.safety_gate = safety_gate

    def list_inbox(
        self,
        *,
        mailbox_filter: str | None = None,
        top: int = 10,
        skip: int = 0,
    ) -> list[EmailMessage]:
        query = {
            "$top": top,
            "$skip": skip,
            "$orderby": "receivedDateTime desc",
        }
        if mailbox_filter == "focused":
            query["$filter"] = "inferenceClassification eq 'focused'"
        try:
            response = self.graph.get("mailFolders/inbox/messages", query=query)
        except GraphAPIError as exc:
            if mailbox_filter == "focused" and _should_fallback_to_plain_inbox(exc):
                response = self.graph.get(
                    "mailFolders/inbox/messages",
                    query={"$top": top, "$skip": skip, "$orderby": "receivedDateTime desc"},
                )
                return self._messages_from_response(response)
            raise
        items = self._messages_from_response(response)
        if mailbox_filter == "focused" and not items:
            response = self.graph.get(
                "mailFolders/inbox/messages",
                query={"$top": top, "$skip": skip, "$orderby": "receivedDateTime desc"},
            )
            return self._messages_from_response(response)
        return items

    def read_email(self, message_id: str) -> EmailMessage:
        response = self.graph.get(f"messages/{message_id}")
        return self._message_from_item(response)

    def search_emails(self, query: str, mailbox_filter: str | None = None) -> list[EmailMessage]:
        normalized_query = _normalize_search_query(query)
        search_value = f"\"{normalized_query}\""
        try:
            response = self.graph.get(
                "messages",
                query={"$search": search_value, "$top": 25},
                headers={"ConsistencyLevel": "eventual"},
            )
            messages = self._messages_from_response(response)
        except GraphAPIError as exc:
            if _should_retry_with_plain_search(exc):
                response = self.graph.get(
                    "messages",
                    query={"$search": normalized_query, "$top": 25},
                    headers={"ConsistencyLevel": "eventual"},
                )
                messages = self._messages_from_response(response)
            elif _should_fallback_to_subject_search(exc):
                response = self.graph.get(
                    "messages",
                    query={
                        "$filter": f"contains(subject,'{_escape_odata_string(normalized_query)}')",
                        "$top": 25,
                    },
                )
                messages = self._messages_from_response(response)
            else:
                raise
        if mailbox_filter == "focused":
            return [message for message in messages if "[ext]" not in message.subject.lower()]
        return messages

    def delta_sync(self, *, delta_link: str | None = None, top: int = 100) -> DeltaSyncResult:
        path = delta_link or "mailFolders/inbox/messages/delta"
        response = self.graph.get(
            path,
            query=None if delta_link else {"$top": top},
            headers={"ConsistencyLevel": "eventual"},
        )
        messages: list[EmailMessage] = []
        removed_ids: list[str] = []
        for item in response.get("value", []):
            if "@removed" in item:
                removed_ids.append(str(item.get("id", "")))
                continue
            messages.append(self._message_from_item(item))
        return DeltaSyncResult(
            messages=messages,
            removed_ids=removed_ids,
            next_link=_get_link(response, "@odata.nextLink"),
            delta_link=_get_link(response, "@odata.deltaLink"),
        )

    def list_folders(self) -> list[dict[str, str]]:
        response = self.graph.get("mailFolders", query={"$top": 100})
        return [
            {"id": item.get("id", ""), "display_name": item.get("displayName", "")}
            for item in response.get("value", [])
        ]

    def list_attachments(
        self,
        message_id: str,
        *,
        include_inline: bool = False,
    ) -> list[EmailAttachment]:
        response = self.graph.get(f"messages/{message_id}/attachments", query={"$top": 100})
        attachments: list[EmailAttachment] = []
        for item in response.get("value", []):
            if not isinstance(item, dict):
                continue
            attachment = self._email_attachment_from_item(item)
            if attachment.odata_type != _FILE_ATTACHMENT_TYPE:
                continue
            if not include_inline and attachment.is_inline:
                continue
            attachments.append(attachment)
        return attachments

    def download_attachments(
        self,
        message_id: str,
        *,
        include_inline: bool = False,
    ) -> list[DownloadedAttachment]:
        return [
            self.download_attachment(message_id, attachment.id)
            for attachment in self.list_attachments(message_id, include_inline=include_inline)
        ]

    def download_attachment(self, message_id: str, attachment_id: str) -> DownloadedAttachment:
        item = self._attachment_item(message_id, attachment_id)
        return self._download_attachment_from_item(message_id, item)

    def read_attachment_text(
        self,
        message_id: str,
        attachment_id: str,
        *,
        max_chars: int = 50_000,
    ) -> ExtractedAttachment:
        item = self._attachment_item(message_id, attachment_id)
        attachment = self._require_file_attachment(item)
        downloaded = self._download_attachment_from_item(message_id, item)
        return extract_attachment_text(attachment, downloaded.content, max_chars=max_chars)

    def create_email_draft(
        self,
        *,
        to: tuple[str, ...],
        cc: tuple[str, ...] = (),
        bcc: tuple[str, ...] = (),
        subject: str,
        body: str,
        reply_to: tuple[str, ...] = (),
        importance: str = "normal",
    ) -> EmailDraft:
        normalized_to = _normalize_addresses(to)
        if not normalized_to:
            raise ValueError("to must contain at least one email address")
        normalized_cc = _normalize_addresses(cc)
        normalized_bcc = _normalize_addresses(bcc)
        normalized_reply_to = _normalize_addresses(reply_to)
        normalized_importance = _normalize_importance(importance)
        self._require_write_support("draft_email")
        operation_draft = self._operation_draft(
            to=normalized_to,
            cc=normalized_cc,
            bcc=normalized_bcc,
            subject=subject,
            body=body,
            reply_to=normalized_reply_to,
            importance=normalized_importance,
        )
        self._run_safety_check(
            WriteOperation(
                tool_name="draft_email",
                payload_hash=compute_hash(canonicalize_email(operation_draft)),
                canonical_payload=canonicalize_email(operation_draft),
                recipients=normalized_to + normalized_cc + normalized_bcc,
            )
        )
        item = self.graph.post(
            "messages",
            body=_draft_payload(
                to=normalized_to,
                cc=normalized_cc,
                bcc=normalized_bcc,
                subject=subject,
                body=body,
                reply_to=normalized_reply_to,
                importance=normalized_importance,
            ),
        )
        return self._draft_from_item(item)

    def create_reply_draft(
        self,
        message_id: str,
        *,
        body: str,
        importance: str | None = None,
    ) -> EmailDraft:
        normalized_message_id = message_id.strip()
        if not normalized_message_id:
            raise ValueError("message_id must be a non-empty string")
        self._require_write_support("reply_email")
        source_item = self.graph.get(f"messages/{normalized_message_id}")
        recipients = _reply_recipients(source_item)
        if not recipients:
            raise GraphAPIError(
                0,
                "InvalidMessage",
                "source message does not contain reply recipients",
            )
        normalized_importance = _normalize_importance(
            importance if importance is not None else _string_value(source_item.get("importance"))
        )
        operation_draft = self._operation_draft(
            to=recipients,
            cc=(),
            bcc=(),
            subject=_reply_subject(_string_value(source_item.get("subject"))),
            body=body,
            reply_to=(),
            importance=normalized_importance,
        )
        self._run_safety_check(
            WriteOperation(
                tool_name="reply_email",
                payload_hash=compute_hash(canonicalize_email(operation_draft)),
                canonical_payload=canonicalize_email(operation_draft),
                recipients=recipients,
                message_id=normalized_message_id,
            )
        )
        created = self.graph.post(f"messages/{normalized_message_id}/createReply")
        draft_id = _string_value(created.get("id"))
        if not draft_id:
            raise GraphAPIError(0, "InvalidDraft", "reply draft did not return an id")
        patch_body: dict[str, Any] = {
            "body": {"contentType": "html", "content": body},
        }
        if importance is not None:
            patch_body["importance"] = normalized_importance
        self.graph.patch(f"messages/{draft_id}", body=patch_body)
        return self._draft_from_item(self.graph.get(f"messages/{draft_id}"))

    def send_email_draft(
        self,
        draft_id: str,
        *,
        content_hash: str,
    ) -> None:
        normalized_draft_id = draft_id.strip()
        if not normalized_draft_id:
            raise ValueError("draft_id must be a non-empty string")
        normalized_hash = content_hash.strip()
        if not normalized_hash:
            raise ValueError("content_hash must be a non-empty string")
        self._require_write_support("send_email")
        current_draft = self._draft_from_item(self.graph.get(f"messages/{normalized_draft_id}"))
        canonical = canonicalize_email(current_draft)
        self._run_safety_check(
            WriteOperation(
                tool_name="send_email",
                payload_hash=normalized_hash,
                canonical_payload=canonical,
                recipients=current_draft.to + current_draft.cc + current_draft.bcc,
                dialog_preview=DialogPreview(
                    title="Confirm Email Send",
                    body=_send_dialog_body(current_draft),
                ),
                draft_id=current_draft.draft_id,
                operation_id=current_draft.draft_id,
            )
        )
        self.graph.post(f"messages/{normalized_draft_id}/send")

    def _messages_from_response(self, response: dict[str, Any]) -> list[EmailMessage]:
        return [self._message_from_item(item) for item in response.get("value", [])]

    def _message_from_item(self, item: dict[str, Any]) -> EmailMessage:
        attachments = tuple(
            self._attachment_from_item(attachment) for attachment in item.get("attachments", [])
        )
        sender = item.get("from", {}).get("emailAddress", {}).get("address", "")
        return EmailMessage(
            id=item.get("id", ""),
            subject=item.get("subject", ""),
            sender=sender,
            to=_recipients(item.get("toRecipients")),
            cc=_recipients(item.get("ccRecipients")),
            bcc=_recipients(item.get("bccRecipients")),
            body_preview=item.get("bodyPreview", ""),
            body_content=sanitize_email_body(item.get("body", {}).get("content", "")),
            received_at=_parse_graph_datetime(item.get("receivedDateTime")),
            is_read=bool(item.get("isRead", False)),
            is_flagged=item.get("flag", {}).get("flagStatus") == "flagged",
            importance=item.get("importance", "normal"),
            has_attachments=bool(item.get("hasAttachments", False)),
            attachments=attachments,
            conversation_id=item.get("conversationId", ""),
            folder_id=item.get("parentFolderId", ""),
        )

    def _attachment_from_item(self, item: dict[str, Any]) -> AttachmentInfo:
        content_bytes = item.get("contentBytes", "")
        sha = ""
        if content_bytes:
            decoded = base64.b64decode(str(content_bytes))
            sha = hashlib.sha256(decoded).hexdigest()
        return AttachmentInfo(
            name=item.get("name", ""),
            content_type=item.get("contentType", ""),
            size=int(item.get("size", 0)),
            sha256=sha,
            is_reference=item.get("@odata.type") == "#microsoft.graph.referenceAttachment",
        )

    def _attachment_item(self, message_id: str, attachment_id: str) -> dict[str, Any]:
        item = self.graph.get(f"messages/{message_id}/attachments/{attachment_id}")
        if not isinstance(item, dict):
            raise GraphAPIError(
                0,
                "InvalidAttachment",
                "attachment lookup did not return an object",
            )
        return item

    def _email_attachment_from_item(self, item: dict[str, Any]) -> EmailAttachment:
        attachment_id = str(item.get("id", "")).strip()
        if not attachment_id:
            raise GraphAPIError(0, "InvalidAttachment", "attachment is missing id")
        odata_type = str(item.get("@odata.type", ""))
        return EmailAttachment(
            id=attachment_id,
            name=str(item.get("name", "")),
            content_type=str(item.get("contentType", "")),
            size=int(item.get("size", 0)),
            is_inline=bool(item.get("isInline", False)),
            is_reference=odata_type == _REFERENCE_ATTACHMENT_TYPE,
            odata_type=odata_type,
        )

    def _require_file_attachment(self, item: dict[str, Any]) -> EmailAttachment:
        attachment = self._email_attachment_from_item(item)
        if attachment.odata_type != _FILE_ATTACHMENT_TYPE:
            raise ValueError("only file attachments are supported")
        return attachment

    def _download_attachment_from_item(
        self,
        message_id: str,
        item: dict[str, Any],
    ) -> DownloadedAttachment:
        attachment = self._require_file_attachment(item)
        content = _attachment_content_bytes(item)
        if content is None:
            content = self.graph.get_bytes(
                f"messages/{message_id}/attachments/{attachment.id}/$value"
            )
        return DownloadedAttachment(
            attachment_id=attachment.id,
            name=attachment.name,
            content_type=attachment.content_type,
            size=attachment.size,
            content=content,
            is_inline=attachment.is_inline,
        )

    def _draft_from_item(self, item: dict[str, Any]) -> EmailDraft:
        draft = EmailDraft(
            draft_id=_string_value(item.get("id")),
            content_hash="",
            to=_normalize_addresses(_recipients(item.get("toRecipients"))),
            cc=_normalize_addresses(_recipients(item.get("ccRecipients"))),
            bcc=_normalize_addresses(_recipients(item.get("bccRecipients"))),
            subject=_string_value(item.get("subject")),
            body=_body_content(item),
            attachments=tuple(
                self._attachment_from_item(attachment)
                for attachment in item.get("attachments", [])
                if isinstance(attachment, dict)
            ),
            reply_to=_normalize_addresses(_recipients(item.get("replyTo"))),
            importance=_normalize_importance(_string_value(item.get("importance"))),
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
        )
        return EmailDraft(
            draft_id=draft.draft_id,
            content_hash=compute_hash(canonicalize_email(draft)),
            to=draft.to,
            cc=draft.cc,
            bcc=draft.bcc,
            subject=draft.subject,
            body=draft.body,
            attachments=draft.attachments,
            reply_to=draft.reply_to,
            importance=draft.importance,
            created_at=draft.created_at,
        )

    def _operation_draft(
        self,
        *,
        to: tuple[str, ...],
        cc: tuple[str, ...],
        bcc: tuple[str, ...],
        subject: str,
        body: str,
        reply_to: tuple[str, ...],
        importance: str,
    ) -> EmailDraft:
        return EmailDraft(
            draft_id="",
            content_hash="",
            to=to,
            cc=cc,
            bcc=bcc,
            subject=subject,
            body=body,
            attachments=(),
            reply_to=reply_to,
            importance=importance,
            created_at=datetime.fromtimestamp(0, tz=UTC),
        )

    def _require_write_support(self, tool_name: str) -> None:
        if self.safety_gate is None:
            raise SafetyDeniedError(
                "safety_gate_unavailable",
                tool_name,
                "configured safety gate required for write operations",
            )
        if self.graph.config.user.endpoint != "me":
            raise SafetyDeniedError(
                "unsupported_endpoint",
                tool_name,
                "write operations require user.endpoint='me'",
            )

    def _run_safety_check(self, operation: WriteOperation) -> None:
        assert self.safety_gate is not None
        result = self.safety_gate.full_check(operation)
        if result.allowed:
            return
        raise SafetyDeniedError(
            result.reason,
            operation.tool_name,
            _safety_denial_details(result.reason),
        )


def _recipients(items: Any) -> tuple[str, ...]:
    if not isinstance(items, list):
        return ()
    return tuple(
        item.get("emailAddress", {}).get("address", "")
        for item in items
        if isinstance(item, dict)
    )


def _normalize_addresses(addresses: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(address.strip() for address in addresses if address.strip())


def _normalize_importance(value: str | None) -> str:
    normalized = (value or "normal").strip().lower()
    if normalized not in {"low", "normal", "high"}:
        raise ValueError("importance must be one of: low, normal, high")
    return normalized


def _draft_payload(
    *,
    to: tuple[str, ...],
    cc: tuple[str, ...],
    bcc: tuple[str, ...],
    subject: str,
    body: str,
    reply_to: tuple[str, ...],
    importance: str,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "subject": subject,
        "importance": importance,
        "body": {
            "contentType": "html",
            "content": body,
        },
        "toRecipients": _recipient_payload(to),
    }
    if cc:
        payload["ccRecipients"] = _recipient_payload(cc)
    if bcc:
        payload["bccRecipients"] = _recipient_payload(bcc)
    if reply_to:
        payload["replyTo"] = _recipient_payload(reply_to)
    return payload


def _recipient_payload(recipients: tuple[str, ...]) -> list[dict[str, dict[str, str]]]:
    return [{"emailAddress": {"address": recipient}} for recipient in recipients]


def _reply_recipients(item: dict[str, Any]) -> tuple[str, ...]:
    reply_to = _normalize_addresses(_recipients(item.get("replyTo")))
    if reply_to:
        return reply_to
    sender = _string_value(item.get("from", {}).get("emailAddress", {}).get("address", ""))
    if not sender:
        return ()
    return (sender,)


def _reply_subject(subject: str) -> str:
    normalized = subject.strip()
    if normalized.lower().startswith("re:"):
        return normalized
    if not normalized:
        return "RE:"
    return f"RE: {normalized}"


def _body_content(item: dict[str, Any]) -> str:
    body = item.get("body", {})
    if not isinstance(body, dict):
        return ""
    return _string_value(body.get("content"))


def _string_value(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _send_dialog_body(draft: EmailDraft) -> str:
    parts = [
        f"To: {', '.join(draft.to) or '(none)'}",
    ]
    if draft.cc:
        parts.append(f"Cc: {', '.join(draft.cc)}")
    if draft.bcc:
        parts.append(f"Bcc: {', '.join(draft.bcc)}")
    parts.append(f"Subject: {draft.subject or '(no subject)'}")
    parts.append("")
    parts.append(draft.body or "(empty body)")
    return "\n".join(parts)


def _safety_denial_details(reason: str) -> str | None:
    mapping = {
        "allowlist_denied": "recipient outside domain allowlist",
        "rate_limit_exceeded": "rate limit exceeded",
        "rate_limit_unavailable": "rate limiter unavailable",
        "dialog_cancelled": "send cancelled at confirmation dialog",
        "hash_mismatch": "draft contents changed since the content hash was issued",
    }
    return mapping.get(reason)


def _parse_graph_datetime(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        return datetime.fromtimestamp(0, tz=UTC)
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _should_fallback_to_plain_inbox(error: GraphAPIError) -> bool:
    normalized_message = error.message.lower()
    return error.status_code == 400 and "too complex" in normalized_message


def _should_fallback_to_subject_search(error: GraphAPIError) -> bool:
    normalized_message = error.message.lower()
    return error.status_code == 400 and "does not support filtering" in normalized_message


def _should_retry_with_plain_search(error: GraphAPIError) -> bool:
    normalized_message = error.message.lower()
    return (
        error.status_code == 400
        and "an identifier was expected at position 0" in normalized_message
    )


def _get_link(response: dict[str, Any], key: str) -> str | None:
    value = response.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _escape_odata_string(value: str) -> str:
    return value.replace("'", "''")


def _normalize_search_query(value: str) -> str:
    normalized = value.strip().replace('\\"', '"').replace("\\'", "'")
    while len(normalized) >= 2 and normalized[0] == normalized[-1] and normalized[0] in {"'", '"'}:
        normalized = normalized[1:-1].strip()
    return normalized


@dataclass(frozen=True)
class DeltaSyncResult:
    messages: list[EmailMessage]
    removed_ids: list[str]
    next_link: str | None
    delta_link: str | None


@dataclass(frozen=True)
class DownloadedAttachment:
    attachment_id: str
    name: str
    content_type: str
    size: int
    content: bytes
    is_inline: bool


_FILE_ATTACHMENT_TYPE = "#microsoft.graph.fileAttachment"
_REFERENCE_ATTACHMENT_TYPE = "#microsoft.graph.referenceAttachment"


def _attachment_content_bytes(item: dict[str, Any]) -> bytes | None:
    content_bytes = item.get("contentBytes")
    if not isinstance(content_bytes, str) or not content_bytes:
        return None
    return base64.b64decode(content_bytes)
