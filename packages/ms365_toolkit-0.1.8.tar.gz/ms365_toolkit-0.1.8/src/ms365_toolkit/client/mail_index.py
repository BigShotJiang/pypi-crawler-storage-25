from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from ms365_toolkit.client.email import EmailClient
    from ms365_toolkit.models.email import EmailMessage


@dataclass(frozen=True)
class IndexedMessage:
    message_id: str
    conversation_id: str
    subject: str
    sender: str
    body_preview: str
    received_at: str


@dataclass(frozen=True)
class IndexedThread:
    conversation_id: str
    latest_message_id: str
    latest_subject: str
    latest_sender: str
    latest_body_preview: str
    latest_received_at: str
    message_count: int


class MailboxIndex:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._initialize()

    def sync(self, email_client: EmailClient, *, batch_size: int = 100, max_pages: int = 10) -> int:
        delta_link = self.get_delta_link()
        total = 0
        pages = 0
        while pages < max_pages:
            result = email_client.delta_sync(delta_link=delta_link, top=batch_size)
            self.upsert_messages(result.messages)
            self.remove_messages(result.removed_ids)
            total += len(result.messages) + len(result.removed_ids)
            pages += 1
            if result.next_link is not None:
                delta_link = result.next_link
                continue
            if result.delta_link is not None:
                self.set_delta_link(result.delta_link)
            break
        return total

    def upsert_messages(self, messages: list[EmailMessage]) -> None:
        with sqlite3.connect(self.path) as conn:
            conn.executemany(
                """
                INSERT INTO messages (
                    message_id,
                    conversation_id,
                    subject,
                    sender,
                    body_preview,
                    received_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(message_id) DO UPDATE SET
                    conversation_id = excluded.conversation_id,
                    subject = excluded.subject,
                    sender = excluded.sender,
                    body_preview = excluded.body_preview,
                    received_at = excluded.received_at
                """,
                [
                    (
                        message.id,
                        message.conversation_id,
                        message.subject,
                        message.sender,
                        message.body_preview,
                        message.received_at.isoformat(),
                    )
                    for message in messages
                ],
            )

    def remove_messages(self, message_ids: list[str]) -> None:
        if not message_ids:
            return
        with sqlite3.connect(self.path) as conn:
            conn.executemany(
                "DELETE FROM messages WHERE message_id = ?",
                [(message_id,) for message_id in message_ids],
            )

    def search(self, query: str, *, limit: int = 10) -> list[IndexedMessage]:
        pattern = f"%{query.lower()}%"
        with sqlite3.connect(self.path) as conn:
            rows = conn.execute(
                """
                SELECT message_id, conversation_id, subject, sender, body_preview, received_at
                FROM messages
                WHERE lower(subject) LIKE ? OR lower(sender) LIKE ? OR lower(body_preview) LIKE ?
                ORDER BY received_at DESC
                LIMIT ?
                """,
                (pattern, pattern, pattern, limit),
            ).fetchall()
        return [IndexedMessage(*row) for row in rows]

    def recent(self, *, limit: int = 20) -> list[IndexedMessage]:
        with sqlite3.connect(self.path) as conn:
            rows = conn.execute(
                """
                SELECT message_id, conversation_id, subject, sender, body_preview, received_at
                FROM messages
                ORDER BY received_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [IndexedMessage(*row) for row in rows]

    def recent_threads(self, *, limit: int = 20) -> list[IndexedThread]:
        with sqlite3.connect(self.path) as conn:
            rows = conn.execute(
                """
                SELECT
                    m.conversation_id,
                    m.message_id,
                    m.subject,
                    m.sender,
                    m.body_preview,
                    m.received_at,
                    counts.message_count
                FROM messages AS m
                JOIN (
                    SELECT
                        conversation_id,
                        MAX(received_at) AS max_received_at,
                        COUNT(*) AS message_count
                    FROM messages
                    GROUP BY conversation_id
                ) AS counts
                    ON counts.conversation_id = m.conversation_id
                   AND counts.max_received_at = m.received_at
                ORDER BY m.received_at DESC, m.message_id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [IndexedThread(*row) for row in rows]

    def get_delta_link(self) -> str | None:
        with sqlite3.connect(self.path) as conn:
            row = conn.execute("SELECT value FROM metadata WHERE key = 'delta_link'").fetchone()
        if row is None:
            return None
        return str(row[0])

    def set_delta_link(self, delta_link: str) -> None:
        with sqlite3.connect(self.path) as conn:
            conn.execute(
                """
                INSERT INTO metadata (key, value) VALUES ('delta_link', ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (delta_link,),
            )

    def _initialize(self) -> None:
        with sqlite3.connect(self.path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    message_id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    body_preview TEXT NOT NULL,
                    received_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
