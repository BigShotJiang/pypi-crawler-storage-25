from __future__ import annotations

import hashlib
import os
import tomllib
import warnings
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

PROFILE_ROOT = Path.home() / ".ms365-toolkit" / "profiles"
CONFIG_FILENAME = "config.toml"
REJECTED_PUBLIC_SUFFIXES = frozenset({".co.uk", ".com.au", ".com.br"})
REJECTED_TOP_LEVEL_ALLOWLISTS = frozenset({".com", ".org", ".net"})


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class AuthConfig:
    tenant_id: str
    client_id: str


@dataclass(frozen=True)
class UserConfig:
    endpoint: str
    user_principal_name: str
    timezone: str


@dataclass(frozen=True)
class SafetyRateLimits:
    send_email_per_hour: int
    send_email_per_day: int
    draft_email_per_hour: int
    draft_email_per_day: int
    reply_email_per_hour: int
    reply_email_per_day: int
    forward_email_per_hour: int
    forward_email_per_day: int
    move_email_per_hour: int
    flag_email_per_hour: int
    create_event_per_hour: int
    create_event_per_day: int
    update_event_per_hour: int
    respond_event_per_hour: int


@dataclass(frozen=True)
class SafetyConfig:
    domain_allowlist: tuple[str, ...]
    folder_allowlist: tuple[str, ...]
    rate_limits: SafetyRateLimits


@dataclass(frozen=True)
class VipConfig:
    emails: tuple[str, ...]
    domains: tuple[str, ...]


@dataclass(frozen=True)
class IntelligenceConfig:
    critical_keywords: tuple[str, ...]
    noise_keywords: tuple[str, ...]
    action_keywords: tuple[str, ...]


@dataclass(frozen=True)
class ToolkitConfig:
    profile: str
    auth: AuthConfig
    user: UserConfig
    safety: SafetyConfig
    vip: VipConfig
    intelligence: IntelligenceConfig
    config_hash: str
    config_mtime: float
    config_path: Path


def get_profile_dir(profile: str, base_dir: Path | None = None) -> Path:
    return (base_dir or PROFILE_ROOT) / profile


def get_config_path(profile: str = "default", base_dir: Path | None = None) -> Path:
    return get_profile_dir(profile=profile, base_dir=base_dir) / CONFIG_FILENAME


def load_config(profile: str = "default", base_dir: Path | None = None) -> ToolkitConfig:
    config_path = get_config_path(profile=profile, base_dir=base_dir)
    raw_bytes = config_path.read_bytes()
    parsed = tomllib.loads(raw_bytes.decode("utf-8"))
    stat_result = config_path.stat()
    config = ToolkitConfig(
        profile=profile,
        auth=_parse_auth_config(parsed),
        user=_parse_user_config(parsed),
        safety=_parse_safety_config(parsed),
        vip=_parse_vip_config(parsed),
        intelligence=_parse_intelligence_config(parsed),
        config_hash=hashlib.sha256(raw_bytes).hexdigest(),
        config_mtime=stat_result.st_mtime,
        config_path=config_path,
    )
    validate_config(config)
    return config


def validate_config(config: ToolkitConfig) -> None:
    if not config.safety.domain_allowlist:
        warnings.warn("domain_allowlist is empty; write operations will be blocked", stacklevel=2)

    for domain in config.safety.domain_allowlist:
        normalized = domain.strip().lower()
        if normalized in REJECTED_TOP_LEVEL_ALLOWLISTS:
            raise ConfigError(f"domain_allowlist entry {domain!r} is too broad")
        if normalized in REJECTED_PUBLIC_SUFFIXES:
            raise ConfigError(f"domain_allowlist entry {domain!r} is a public suffix")

    for name, value in _iter_rate_limits(config.safety.rate_limits):
        if value <= 0:
            raise ConfigError(f"{name} must be a positive integer")

    if config.user.endpoint not in {"me", "users"}:
        raise ConfigError("user.endpoint must be 'me' or 'users'")

    if config.user.endpoint == "users" and not config.user.user_principal_name.strip():
        raise ConfigError("user.user_principal_name is required when user.endpoint='users'")


def write_config_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp_path: Path | None = None
    with NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        delete=False,
        prefix=f".{path.name}.",
        suffix=".tmp",
    ) as temp_file:
        temp_file.write(content)
        temp_file.flush()
        os.fsync(temp_file.fileno())
        temp_path = Path(temp_file.name)
    assert temp_path is not None
    temp_path.replace(path)


def _parse_auth_config(parsed: dict[str, Any]) -> AuthConfig:
    section = _get_section(parsed, "auth")
    return AuthConfig(
        tenant_id=_get_str(section, "tenant_id"),
        client_id=_get_str(section, "client_id"),
    )


def _parse_user_config(parsed: dict[str, Any]) -> UserConfig:
    section = _get_section(parsed, "user")
    return UserConfig(
        endpoint=_get_str(section, "endpoint"),
        user_principal_name=_get_str(section, "user_principal_name"),
        timezone=_get_str(section, "timezone"),
    )


def _parse_safety_config(parsed: dict[str, Any]) -> SafetyConfig:
    section = _get_section(parsed, "safety")
    return SafetyConfig(
        domain_allowlist=_get_str_tuple(section, "domain_allowlist"),
        folder_allowlist=_get_str_tuple(section, "folder_allowlist"),
        rate_limits=SafetyRateLimits(
            send_email_per_hour=_get_int(section, "send_email_per_hour"),
            send_email_per_day=_get_int(section, "send_email_per_day"),
            draft_email_per_hour=_get_int(section, "draft_email_per_hour"),
            draft_email_per_day=_get_int(section, "draft_email_per_day"),
            reply_email_per_hour=_get_int(section, "reply_email_per_hour"),
            reply_email_per_day=_get_int(section, "reply_email_per_day"),
            forward_email_per_hour=_get_int(section, "forward_email_per_hour"),
            forward_email_per_day=_get_int(section, "forward_email_per_day"),
            move_email_per_hour=_get_int(section, "move_email_per_hour"),
            flag_email_per_hour=_get_int(section, "flag_email_per_hour"),
            create_event_per_hour=_get_int(section, "create_event_per_hour"),
            create_event_per_day=_get_int(section, "create_event_per_day"),
            update_event_per_hour=_get_int(section, "update_event_per_hour"),
            respond_event_per_hour=_get_int(section, "respond_event_per_hour"),
        ),
    )


def _parse_vip_config(parsed: dict[str, Any]) -> VipConfig:
    section = _get_section(parsed, "vip")
    return VipConfig(
        emails=_get_str_tuple(section, "emails"),
        domains=_get_str_tuple(section, "domains"),
    )


def _parse_intelligence_config(parsed: dict[str, Any]) -> IntelligenceConfig:
    section = _get_section(parsed, "intelligence")
    return IntelligenceConfig(
        critical_keywords=_get_str_tuple(section, "critical_keywords"),
        noise_keywords=_get_str_tuple(section, "noise_keywords"),
        action_keywords=_get_str_tuple(section, "action_keywords"),
    )


def _get_section(parsed: dict[str, Any], name: str) -> dict[str, Any]:
    value = parsed.get(name)
    if not isinstance(value, dict):
        raise ConfigError(f"missing [{name}] section")
    return value


def _get_str(section: dict[str, Any], key: str) -> str:
    value = section.get(key)
    if not isinstance(value, str):
        raise ConfigError(f"{key} must be a string")
    return value


def _get_int(section: dict[str, Any], key: str) -> int:
    value = section.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ConfigError(f"{key} must be an integer")
    return value


def _get_str_tuple(section: dict[str, Any], key: str) -> tuple[str, ...]:
    value = section.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigError(f"{key} must be a list of strings")
    return tuple(value)


def _iter_rate_limits(rate_limits: SafetyRateLimits) -> tuple[tuple[str, int], ...]:
    return (
        ("send_email_per_hour", rate_limits.send_email_per_hour),
        ("send_email_per_day", rate_limits.send_email_per_day),
        ("draft_email_per_hour", rate_limits.draft_email_per_hour),
        ("draft_email_per_day", rate_limits.draft_email_per_day),
        ("reply_email_per_hour", rate_limits.reply_email_per_hour),
        ("reply_email_per_day", rate_limits.reply_email_per_day),
        ("forward_email_per_hour", rate_limits.forward_email_per_hour),
        ("forward_email_per_day", rate_limits.forward_email_per_day),
        ("move_email_per_hour", rate_limits.move_email_per_hour),
        ("flag_email_per_hour", rate_limits.flag_email_per_hour),
        ("create_event_per_hour", rate_limits.create_event_per_hour),
        ("create_event_per_day", rate_limits.create_event_per_day),
        ("update_event_per_hour", rate_limits.update_event_per_hour),
        ("respond_event_per_hour", rate_limits.respond_event_per_hour),
    )
