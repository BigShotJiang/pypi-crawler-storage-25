from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime


@dataclass(frozen=True)
class Attendee:
    email: str
    name: str
    response: str
    type: str


@dataclass(frozen=True)
class CalendarEvent:
    id: str
    subject: str
    start: datetime
    end: datetime
    timezone: str
    location: str
    body_content: str
    attendees: tuple[Attendee, ...]
    is_online_meeting: bool
    is_cancelled: bool
    importance: str
    categories: tuple[str, ...]
    recurrence: str | None
    organizer: str
    response_status: str
    calendar_id: str
    join_url: str = ""
    ical_uid: str = ""


@dataclass(frozen=True)
class FreeBusySlot:
    start: datetime
    end: datetime
    status: str


@dataclass(frozen=True)
class MeetingTranscript:
    id: str
    meeting_id: str
    call_id: str
    created_at: datetime
    end_at: datetime
    content_correlation_id: str
    transcript_content_url: str
    organizer_user_id: str
    organizer_display_name: str
    organizer_tenant_id: str


@dataclass(frozen=True)
class ExtractedMeetingTranscript:
    transcript: MeetingTranscript
    format: str
    text_content: str
    is_truncated: bool
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class MeetingNotePoint:
    title: str
    text: str
    subpoints: tuple[MeetingNotePoint, ...] = ()


@dataclass(frozen=True)
class MeetingActionItem:
    title: str
    text: str
    owner_display_name: str


@dataclass(frozen=True)
class MeetingMentionEvent:
    event_at: datetime
    speaker_name: str
    speaker_user_id: str
    transcript_utterance: str


@dataclass(frozen=True)
class MeetingAiInsight:
    id: str
    call_id: str
    content_correlation_id: str
    created_at: datetime
    end_at: datetime
    meeting_notes: tuple[MeetingNotePoint, ...] = ()
    action_items: tuple[MeetingActionItem, ...] = ()
    mention_events: tuple[MeetingMentionEvent, ...] = ()
