from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ms365_toolkit.safety.gate import SafetyResult


def check_recipients(recipients: Sequence[str], allowlist: Sequence[str]) -> SafetyResult:
    from ms365_toolkit.safety.gate import SafetyResult

    if not recipients:
        return SafetyResult(True, "allowlist_ok")
    normalized_patterns = [_normalize_pattern(pattern) for pattern in allowlist if pattern.strip()]
    if not normalized_patterns:
        return SafetyResult(False, "allowlist_denied")
    for recipient in recipients:
        domain = _email_domain(recipient)
        if domain is None:
            return SafetyResult(False, "allowlist_denied")
        if not any(_domain_matches_pattern(domain, pattern) for pattern in normalized_patterns):
            return SafetyResult(False, "allowlist_denied")
    return SafetyResult(True, "allowlist_ok")


def _email_domain(email: str) -> str | None:
    normalized = email.strip()
    if "@" not in normalized:
        return None
    return _normalize_domain(normalized.rsplit("@", 1)[1])


def _normalize_pattern(pattern: str) -> str:
    normalized = pattern.strip().lower()
    if normalized.startswith("."):
        return f".{_normalize_domain(normalized[1:])}"
    return _normalize_domain(normalized)


def _normalize_domain(value: str) -> str:
    normalized = value.strip().lower().strip(".")
    return normalized.encode("idna").decode("ascii")


def _domain_matches_pattern(domain: str, pattern: str) -> bool:
    if pattern.startswith("."):
        suffix = pattern[1:]
        return domain == suffix or domain.endswith(f".{suffix}")
    return domain == pattern
