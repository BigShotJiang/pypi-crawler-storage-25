from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from ms365_toolkit.config.loader import load_config
from ms365_toolkit.safety.allowlist import check_recipients
from ms365_toolkit.safety.canonical import compute_hash

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.safety.audit import AuditLogger
    from ms365_toolkit.safety.folder_allowlist import FolderAllowlistChecker
    from ms365_toolkit.safety.rate_limiter import RateLimiter


@dataclass(frozen=True)
class DialogPreview:
    title: str
    body: str


@dataclass(frozen=True)
class AuditEvent:
    tool_name: str
    action: str
    reason: str = ""
    message_id: str | None = None
    ical_uid: str | None = None
    draft_id: str | None = None
    canonical_payload_hash: str | None = None
    config_version: str | None = None
    dialog_outcome: str | None = None
    denial_reason: str | None = None
    recipients: tuple[str, ...] = ()


@dataclass(frozen=True)
class WriteOperation:
    tool_name: str
    payload_hash: str
    canonical_payload: str | None = None
    recipients: tuple[str, ...] = ()
    folder_id: str | None = None
    dialog_preview: DialogPreview | None = None
    message_id: str | None = None
    ical_uid: str | None = None
    draft_id: str | None = None
    operation_id: str | None = None


@dataclass(frozen=True)
class SafetyResult:
    allowed: bool
    reason: str


class SafetyGate(Protocol):
    def check_domain(self, recipients: tuple[str, ...]) -> SafetyResult: ...

    def check_folder(self, folder_id: str) -> SafetyResult: ...

    def check_rate_limit(self, tool: str) -> SafetyResult: ...

    def show_dialog(self, preview: DialogPreview) -> SafetyResult: ...

    def verify_hash(self, expected: str, actual: str) -> SafetyResult: ...

    def audit(self, event: AuditEvent) -> None: ...

    def full_check(self, operation: WriteOperation) -> SafetyResult: ...


class NoOpSafetyGate:
    """Safety gate that approves all operations without enforcement.

    FOR TESTING ONLY. This implementation bypasses domain allowlists, rate
    limits, folder restrictions, and hash verification. Do not instantiate in
    production code paths.
    """

    def __init__(self) -> None:
        self.audit_log: list[AuditEvent] = []

    def check_domain(self, recipients: tuple[str, ...]) -> SafetyResult:
        return SafetyResult(True, f"allowed:{len(recipients)}")

    def check_folder(self, folder_id: str) -> SafetyResult:
        return SafetyResult(True, folder_id)

    def check_rate_limit(self, tool: str) -> SafetyResult:
        return SafetyResult(True, tool)

    def show_dialog(self, preview: DialogPreview) -> SafetyResult:
        return SafetyResult(True, preview.title)

    def verify_hash(self, expected: str, actual: str) -> SafetyResult:
        return SafetyResult(
            expected == actual,
            "hash_match" if expected == actual else "hash_mismatch",
        )

    def audit(self, event: AuditEvent) -> None:
        self.audit_log.append(event)

    def full_check(self, operation: WriteOperation) -> SafetyResult:
        return SafetyResult(True, operation.tool_name)


class ConfiguredSafetyGate:
    def __init__(
        self,
        *,
        config: ToolkitConfig,
        rate_limiter: RateLimiter,
        audit_logger: AuditLogger,
        dialog: Callable[[DialogPreview], SafetyResult],
        folder_checker: FolderAllowlistChecker | None = None,
    ) -> None:
        self.config = config
        self.rate_limiter = rate_limiter
        self.audit_logger = audit_logger
        self.dialog = dialog
        self.folder_checker = folder_checker

    def check_domain(self, recipients: tuple[str, ...]) -> SafetyResult:
        return check_recipients(recipients, self.config.safety.domain_allowlist)

    def check_folder(self, folder_id: str) -> SafetyResult:
        if self.folder_checker is None:
            return SafetyResult(False, "folder_checker_unavailable")
        return self.folder_checker.check_folder(folder_id)

    def check_rate_limit(self, tool: str, *, operation_id: str | None = None) -> SafetyResult:
        return self.rate_limiter.check(tool, operation_id=operation_id)

    def show_dialog(self, preview: DialogPreview) -> SafetyResult:
        return self.dialog(preview)

    def verify_hash(self, expected: str, actual: str) -> SafetyResult:
        return SafetyResult(
            expected == actual,
            "hash_match" if expected == actual else "hash_mismatch",
        )

    def audit(self, event: AuditEvent) -> None:
        self.audit_logger.log(event)

    def full_check(self, operation: WriteOperation) -> SafetyResult:
        self._reload_config_if_needed()
        config_version = self.config.config_hash
        if operation.recipients:
            domain_result = self.check_domain(operation.recipients)
            if not domain_result.allowed:
                return self._audit_result(operation, domain_result, config_version=config_version)
        if operation.folder_id is not None:
            folder_result = self.check_folder(operation.folder_id)
            if not folder_result.allowed:
                return self._audit_result(operation, folder_result, config_version=config_version)
        rate_result = self.check_rate_limit(
            operation.tool_name,
            operation_id=operation.operation_id,
        )
        if not rate_result.allowed:
            return self._audit_result(operation, rate_result, config_version=config_version)
        dialog_outcome: str | None = None
        if operation.dialog_preview is not None:
            dialog_result = self.show_dialog(operation.dialog_preview)
            dialog_outcome = dialog_result.reason
            if not dialog_result.allowed:
                return self._audit_result(
                    operation,
                    dialog_result,
                    config_version=config_version,
                    dialog_outcome=dialog_outcome,
                )
        actual_hash = operation.payload_hash
        if operation.canonical_payload is not None:
            actual_hash = compute_hash(operation.canonical_payload)
        hash_result = self.verify_hash(operation.payload_hash, actual_hash)
        if not hash_result.allowed:
            return self._audit_result(
                operation,
                hash_result,
                config_version=config_version,
                dialog_outcome=dialog_outcome,
            )
        result = SafetyResult(True, "safety_check_passed")
        return self._audit_result(
            operation,
            result,
            config_version=config_version,
            dialog_outcome=dialog_outcome,
        )

    def _audit_result(
        self,
        operation: WriteOperation,
        result: SafetyResult,
        *,
        config_version: str,
        dialog_outcome: str | None = None,
    ) -> SafetyResult:
        self.audit(
            AuditEvent(
                tool_name=operation.tool_name,
                action="allow" if result.allowed else "deny",
                reason=result.reason,
                message_id=operation.message_id,
                ical_uid=operation.ical_uid,
                draft_id=operation.draft_id,
                canonical_payload_hash=operation.payload_hash,
                config_version=config_version,
                dialog_outcome=dialog_outcome,
                denial_reason=None if result.allowed else result.reason,
                recipients=operation.recipients,
            )
        )
        return result

    def _reload_config_if_needed(self) -> None:
        current_mtime = self.config.config_path.stat().st_mtime
        if current_mtime <= self.config.config_mtime:
            return
        reloaded = load_config(
            profile=self.config.profile,
            base_dir=_profile_root(self.config.config_path),
        )
        self.config = reloaded
        self.rate_limiter.update_limits(reloaded.safety.rate_limits)
        if self.folder_checker is not None:
            self.folder_checker.update_allowed_folders(reloaded.safety.folder_allowlist)


def _profile_root(config_path: Path) -> Path:
    return config_path.parent.parent
