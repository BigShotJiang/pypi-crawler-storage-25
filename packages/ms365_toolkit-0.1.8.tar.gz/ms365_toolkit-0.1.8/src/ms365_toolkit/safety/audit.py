from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import UTC, datetime
from hashlib import sha256
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from pathlib import Path

    from ms365_toolkit.safety.gate import AuditEvent


@dataclass
class AuditLogger:
    path: Path
    max_bytes: int = 10 * 1024 * 1024
    backup_count: int = 5

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.renderer = structlog.processors.JSONRenderer()

    def log(self, event: AuditEvent) -> None:
        payload = self._payload(event)
        rendered = self.renderer(None, "", payload)
        encoded = rendered if isinstance(rendered, bytes) else rendered.encode("utf-8")
        self._rotate_if_needed(len(encoded) + 1)
        fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        try:
            os.write(fd, encoded + b"\n")
        finally:
            os.close(fd)
        os.chmod(self.path, 0o600)

    def _payload(self, event: AuditEvent) -> dict[str, Any]:
        recipient_domains = sorted(
            {
                domain
                for recipient in event.recipients
                if (domain := _recipient_domain(recipient)) is not None
            }
        )
        payload = {
            "timestamp": datetime.now(UTC).isoformat(),
            "tool_name": event.tool_name,
            "action": event.action,
            "message_id": event.message_id,
            "ical_uid": event.ical_uid,
            "draft_id": event.draft_id,
            "canonical_payload_hash": event.canonical_payload_hash,
            "config_version": event.config_version,
            "dialog_outcome": event.dialog_outcome,
            "denial_reason": event.denial_reason or event.reason or None,
            "recipient_count": len(event.recipients),
            "domain_hashes": sorted(_hash_domain(domain) for domain in recipient_domains),
        }
        return {key: value for key, value in payload.items() if value not in (None, [], "")}

    def _rotate_if_needed(self, incoming_bytes: int) -> None:
        if not self.path.exists():
            return
        if self.path.stat().st_size + incoming_bytes <= self.max_bytes:
            return
        oldest = self.path.with_name(f"{self.path.name}.{self.backup_count}")
        if oldest.exists():
            oldest.unlink()
        for index in range(self.backup_count - 1, 0, -1):
            source = self.path.with_name(f"{self.path.name}.{index}")
            target = self.path.with_name(f"{self.path.name}.{index + 1}")
            if source.exists():
                source.replace(target)
        self.path.replace(self.path.with_name(f"{self.path.name}.1"))


def _recipient_domain(recipient: str) -> str | None:
    normalized = recipient.strip().lower()
    if "@" not in normalized:
        return None
    return normalized.rsplit("@", 1)[1]


def _hash_domain(domain: str) -> str:
    return sha256(domain.encode("utf-8")).hexdigest()
