from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ms365_toolkit.safety.gate import SafetyResult

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from ms365_toolkit.config.loader import SafetyRateLimits


@dataclass
class RateLimiter:
    profile: str
    rate_limits: SafetyRateLimits
    path: Path
    clock: Callable[[], datetime] | None = None
    connect: Callable[[Path], sqlite3.Connection] | None = None

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def update_limits(self, rate_limits: SafetyRateLimits) -> None:
        self.rate_limits = rate_limits

    def check(
        self,
        tool: str,
        *,
        now: datetime | None = None,
        operation_id: str | None = None,
    ) -> SafetyResult:
        limits = _limits_for_tool(self.rate_limits, tool)
        if limits is None:
            return SafetyResult(False, "rate_limit_unknown_tool")
        hour_limit, day_limit = limits
        effective_now = now or (self.clock() if self.clock is not None else datetime.now(UTC))
        try:
            with self._connection() as conn:
                if operation_id and _has_operation(conn, self.profile, tool, operation_id):
                    return SafetyResult(True, "rate_limit_ok")
                hour_bucket = effective_now.astimezone(UTC).strftime("%Y%m%d%H")
                day_bucket = effective_now.astimezone(UTC).strftime("%Y%m%d")
                if (
                    _read_count(conn, "hourly_counts", self.profile, tool, hour_bucket)
                    >= hour_limit
                ):
                    return SafetyResult(False, "rate_limit_exceeded")
                if day_limit is not None and _read_count(
                    conn,
                    "daily_counts",
                    self.profile,
                    tool,
                    day_bucket,
                ) >= day_limit:
                    return SafetyResult(False, "rate_limit_exceeded")
                if operation_id:
                    conn.execute(
                        """
                        INSERT INTO operations (profile, tool, operation_id)
                        VALUES (?, ?, ?)
                        """,
                        (self.profile, tool, operation_id),
                    )
                _increment_count(conn, "hourly_counts", self.profile, tool, hour_bucket)
                if day_limit is not None:
                    _increment_count(conn, "daily_counts", self.profile, tool, day_bucket)
            return SafetyResult(True, "rate_limit_ok")
        except sqlite3.Error:
            return SafetyResult(False, "rate_limit_unavailable")

    def _initialize(self) -> None:
        try:
            with self._connection() as conn:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA busy_timeout=5000")
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS hourly_counts (
                        profile TEXT NOT NULL,
                        tool TEXT NOT NULL,
                        bucket TEXT NOT NULL,
                        count INTEGER NOT NULL,
                        PRIMARY KEY (profile, tool, bucket)
                    )
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS daily_counts (
                        profile TEXT NOT NULL,
                        tool TEXT NOT NULL,
                        bucket TEXT NOT NULL,
                        count INTEGER NOT NULL,
                        PRIMARY KEY (profile, tool, bucket)
                    )
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS operations (
                        profile TEXT NOT NULL,
                        tool TEXT NOT NULL,
                        operation_id TEXT NOT NULL,
                        PRIMARY KEY (profile, tool, operation_id)
                    )
                    """
                )
        except sqlite3.Error:
            return

    def _connection(self) -> sqlite3.Connection:
        if self.connect is not None:
            return self.connect(self.path)
        return sqlite3.connect(self.path)


def _has_operation(conn: sqlite3.Connection, profile: str, tool: str, operation_id: str) -> bool:
    row = conn.execute(
        """
        SELECT 1
        FROM operations
        WHERE profile = ? AND tool = ? AND operation_id = ?
        """,
        (profile, tool, operation_id),
    ).fetchone()
    return row is not None


def _read_count(conn: sqlite3.Connection, table: str, profile: str, tool: str, bucket: str) -> int:
    row = conn.execute(
        f"SELECT count FROM {table} WHERE profile = ? AND tool = ? AND bucket = ?",
        (profile, tool, bucket),
    ).fetchone()
    return 0 if row is None else int(row[0])


def _increment_count(
    conn: sqlite3.Connection,
    table: str,
    profile: str,
    tool: str,
    bucket: str,
) -> None:
    conn.execute(
        f"""
        INSERT INTO {table} (profile, tool, bucket, count)
        VALUES (?, ?, ?, 1)
        ON CONFLICT(profile, tool, bucket)
        DO UPDATE SET count = count + 1
        """,
        (profile, tool, bucket),
    )


def _limits_for_tool(
    rate_limits: SafetyRateLimits,
    tool: str,
) -> tuple[int, int | None] | None:
    mapping = {
        "send_email": (rate_limits.send_email_per_hour, rate_limits.send_email_per_day),
        "draft_email": (rate_limits.draft_email_per_hour, rate_limits.draft_email_per_day),
        "reply_email": (rate_limits.reply_email_per_hour, rate_limits.reply_email_per_day),
        "forward_email": (rate_limits.forward_email_per_hour, rate_limits.forward_email_per_day),
        "move_email": (rate_limits.move_email_per_hour, None),
        "flag_email": (rate_limits.flag_email_per_hour, None),
        "create_event": (rate_limits.create_event_per_hour, rate_limits.create_event_per_day),
        "update_event": (rate_limits.update_event_per_hour, None),
        "respond_event": (rate_limits.respond_event_per_hour, None),
    }
    return mapping.get(tool)
