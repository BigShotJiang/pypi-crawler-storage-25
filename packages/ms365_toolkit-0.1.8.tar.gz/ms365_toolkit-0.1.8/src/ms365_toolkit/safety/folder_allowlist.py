from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ms365_toolkit.safety.gate import SafetyResult

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

SYSTEM_FOLDER_BLOCKLIST = frozenset(
    {
        "deleted items",
        "junk email",
        "outbox",
        "sent items",
        "drafts",
    }
)


@dataclass
class FolderAllowlistChecker:
    profile: str
    allowed_folders: tuple[str, ...]
    folder_provider: Callable[[], list[dict[str, str]]]
    cache_path: Path

    def check_folder(self, folder_id: str) -> SafetyResult:
        mapping = self._load_mapping()
        folder_name = mapping.get(folder_id)
        if folder_name is None:
            mapping = self._refresh_mapping()
            folder_name = mapping.get(folder_id)
        if folder_name is None:
            return SafetyResult(False, "folder_not_found")
        normalized_name = _normalize_name(folder_name)
        if normalized_name in SYSTEM_FOLDER_BLOCKLIST:
            return SafetyResult(False, "system_folder_blocked")
        if normalized_name not in {_normalize_name(name) for name in self.allowed_folders}:
            return SafetyResult(False, "folder_not_allowed")
        return SafetyResult(True, "folder_allowed")

    def update_allowed_folders(self, allowed_folders: tuple[str, ...]) -> None:
        self.allowed_folders = allowed_folders

    def _load_mapping(self) -> dict[str, str]:
        if self.cache_path.exists():
            payload = json.loads(self.cache_path.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                return {str(key): str(value) for key, value in payload.items()}
        return self._refresh_mapping()

    def _refresh_mapping(self) -> dict[str, str]:
        mapping = {
            str(item.get("id", "")): str(item.get("display_name") or item.get("name") or "")
            for item in self.folder_provider()
            if item.get("id")
        }
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps(mapping, sort_keys=True), encoding="utf-8")
        return mapping


def _normalize_name(value: str) -> str:
    return " ".join(value.strip().lower().split())
