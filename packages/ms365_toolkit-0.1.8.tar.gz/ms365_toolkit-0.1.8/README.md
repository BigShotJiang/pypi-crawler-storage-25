# ms365-toolkit

`ms365-toolkit` is a generic Microsoft 365 email, calendar, and Teams toolkit with:
- device-code auth
- Graph read clients and guarded email write flows
- local mailbox indexing
- triage and briefing workflows
- a local labeling workflow for improving per-user email intelligence

## Self-Service Setup

### 1. Prerequisites

- Python 3.11+
- `uv`
- A Microsoft 365 account with access to the mailbox you want to use
- A Microsoft Entra app registration configured as a public client for device-code auth

This project uses device-code flow. Users do not need to put a client secret in local config.

### 2. Create a Microsoft Entra App Registration

Create an app registration in your tenant and capture these two values:

- `tenant_id`
- `client_id`

Configure the app as a public client so device-code auth is allowed.

For normal read-only use, the delegated Microsoft Graph permissions should include:

- `Mail.Read`
- `Calendars.Read`
- `Chat.Read`
- `Team.ReadBasic.All`
- `Channel.ReadBasic.All`
- `MailboxSettings.Read`

If you want to read Teams channel messages, also grant:

- `ChannelMessage.Read.All`

If you plan to add or use write operations later, also grant:

- `Mail.ReadWrite`
- `Mail.Send`
- `Calendars.ReadWrite`
- `MailboxSettings.ReadWrite`

If your organization requires admin consent for these scopes, an administrator must grant it before login will work.

Teams notes:

- Teams reads currently require `endpoint = "me"`.
- Channel message reads typically require admin-approved consent for `ChannelMessage.Read.All`.
- Users who need channel-message reads should run `auth login --teams-channel-messages`.

### 3. Create Local Config

Create a local profile config from the example:

```bash
mkdir -p ~/.ms365-toolkit/profiles/default
cp config.example.toml ~/.ms365-toolkit/profiles/default/config.toml
```

Edit `~/.ms365-toolkit/profiles/default/config.toml` and set at least:

```toml
[auth]
tenant_id = "<your-entra-tenant-id>"
client_id = "<your-app-registration-client-id>"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"
```

Notes:

- Use `endpoint = "me"` for your own mailbox.
- Use `endpoint = "users"` only for delegated/shared mailbox access, and then set `user_principal_name` to the target mailbox UPN.
- `domain_allowlist = []` is acceptable for read-only use, but write operations will be blocked until you set it.

### 4. Authenticate

Run device-code login:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth login
```

If you need guarded email draft/send support:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth login --write
```

If you need Teams channel-message reads:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth login --teams-channel-messages
```

The CLI will print a verification URL and user code. Complete that sign-in flow in a browser.

### 5. Verify It Works

Check auth status:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth status
```

Check write-token status:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth status --write
```

Run tests:

```bash
uv run --with '.[dev]' pytest tests/unit/ -q
```

Try a basic mailbox read:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit inbox --top 5
```

Try a basic Teams read:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit list-chats --top 5
uvx --from ms365-toolkit==0.1.8 ms365-toolkit search-chats "Sara Kamal" --top 3
uvx --from ms365-toolkit==0.1.8 ms365-toolkit list-teams
uvx --from ms365-toolkit==0.1.8 ms365-toolkit search-teams-messages "cost center" --top 5
uvx --from ms365-toolkit==0.1.8 ms365-toolkit search-channel-messages <team_id> <channel_id> "authorization rate" --top 5
uvx --from ms365-toolkit==0.1.8 ms365-toolkit read-channel-thread <team_id> <channel_id> <message_id> --top 10
```

Global Teams search returns ranked search hits and snippets, not hydrated full message bodies.

Try attachment download:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit download-email-attachments <message_id> --output-dir ./downloads
uvx --from ms365-toolkit==0.1.8 ms365-toolkit list-email-attachments <message_id>
uvx --from ms365-toolkit==0.1.8 ms365-toolkit read-email-attachment <message_id> <attachment_id> --max-chars 50000
```

Try the guarded email write flow:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit create-email-draft --to user@example.com --subject "Hello" --body "<p>Hello</p>"
uvx --from ms365-toolkit==0.1.8 ms365-toolkit create-reply-draft <message_id> --body "<p>Reply</p>"
uvx --from ms365-toolkit==0.1.8 ms365-toolkit send-email-draft <draft_id> <content_hash>
```

### 5b. Installable MCP Setup

The public install shape is a local stdio MCP launched from the published wrapper package.
These commands work after the corresponding package version has been published to PyPI.

Register it with Codex:

```bash
codex mcp add ms365 --env MS365_TOOLKIT_PROFILE=default -- uvx --from ms365-toolkit-mcp==0.1.8 ms365-toolkit-mcp
```

Register it with Claude:

```bash
claude mcp add -s user ms365 -e MS365_TOOLKIT_PROFILE=default -- uvx --from ms365-toolkit-mcp==0.1.8 ms365-toolkit-mcp
```

Upgrade to a newer release by changing the version in the registration command and re-running it.

Supported v1 tools include guarded email writes:
- `list_inbox`
- `search_emails`
- `read_email`
- `list_email_attachments`
- `read_email_attachment`
- `create_email_draft`
- `create_reply_draft`
- `send_email_draft`
- `list_folders`
- `list_events`
- `get_event`
- `search_events`
- `list_calendars`
- `find_free_slots`
- `list_chats`
- `search_chats`
- `list_chat_messages`
- `search_chat_messages`
- `search_teams_messages`
- `read_chat_message`
- `list_teams`
- `list_channels`
- `list_channel_messages`
- `search_channel_messages`
- `list_channel_replies`
- `read_channel_message`
- `read_channel_thread`

All MCP datetime inputs must be timezone-aware ISO 8601 strings.
Email write operations require a write token, `user.endpoint = "me"`, and a configured domain allowlist.

### 5c. Repo-Local MCP Fallback

Install the MCP extra:

```bash
uv sync --extra mcp
```

Run the local stdio MCP server:

```bash
uv run --extra mcp ms365-toolkit-mcp
```

Or run it directly from the module entrypoint:

```bash
uv run --extra mcp python -m ms365_toolkit.mcp
```

### 5d. Repo-Local One-Command Setup

Use the installer script to wire everything up for both tools:

```bash
./scripts/setup_mcp.sh
```

This is the developer fallback, not the primary public install path.

What it does:
- installs the MCP extra with `uv`
- checks that your selected MS365 profile is already authenticated
- registers the `ms365` server with Codex
- registers the `ms365` server with Claude using `user` scope so it is available across sessions

Useful variants:

```bash
./scripts/setup_mcp.sh --target codex
./scripts/setup_mcp.sh --target claude
./scripts/setup_mcp.sh --profile default
./scripts/setup_mcp.sh --dry-run
```

Equivalent Make targets:

```bash
make mcp-setup
make mcp-setup-codex
make mcp-setup-claude
```

### 5e. Claude Review Workflow

This repo includes project-local Claude review commands and a shell workflow.

In an interactive `claude` session, use:

```text
/review-critical
/review-critical teams changes
/review-commit f9c3079
/consult Should we expose participant names in 1:1 chats?
```

For terminal or Codex-driven runs, use:

```bash
./scripts/claude_workflow.sh review
./scripts/claude_workflow.sh review-commit f9c3079
./scripts/claude_workflow.sh consult "Should Teams support user.endpoint=users?"
```

Equivalent Make targets:

```bash
make claude-review
make claude-review-commit COMMIT=f9c3079
make claude-consult PROMPT="Should Teams support user.endpoint=users?"
```

### 6. Where Secrets and Local State Live

Do not put secrets or mailbox data into the repo.

Local config:

- `~/.ms365-toolkit/profiles/<profile>/config.toml`

Token caches:

- stored in the OS keychain via `keyring`
- read cache key: `ms365-read-token-<profile>`
- write cache key: `ms365-write-token-<profile>`

Mailbox-derived local state:

- `~/.ms365-toolkit/profiles/<profile>/mail_index.db`
- `~/.ms365-toolkit/profiles/<profile>/thread_labels.jsonl`

## Shareable Code vs Private Local State

The repository is intended to be generic and shareable.

Generic, shareable parts:
- source code under `src/`
- tests under `tests/`
- build and dependency config
- generic CLI commands and labeling UI

Private, per-user local state:
- `~/.ms365-toolkit/profiles/<profile>/config.toml`
- token caches
- local mailbox index databases
- exported label datasets such as `thread_labels.jsonl`
- any mailbox-derived training or evaluation data

Do not commit or share profile directories, token caches, mailbox indexes, or label datasets unless you explicitly want to share mailbox-derived data.

## Local Workflow

1. Configure a local profile under `~/.ms365-toolkit/profiles/<profile>/config.toml`
2. Authenticate with:

```bash
uvx --from ms365-toolkit==0.1.8 ms365-toolkit auth login
```

3. Build a local mailbox index:

```bash
uv run --with '.[dev]' ms365-toolkit sync-mail-index
```

4. Export thread candidates for labeling:

```bash
uv run --with '.[dev]' ms365-toolkit export-label-candidates --top 30 --sync-index
```

5. Review and label locally:

```bash
uv run --with '.[dev]' ms365-toolkit label-ui
```

The learned behavior from triage is driven by each user’s local labeled dataset, not by checked-in project state.
