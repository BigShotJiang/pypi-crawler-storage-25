class ArrayTypeError(Exception):
    ...
    


def reverse_arr(array):
    return array[::-1]

def sum_arr(array):
    res = 0
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else: res += i
    return res

def multiplication_arr(array):
    res = 1
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else:
            res *= i
    return res

def min(array):
    res = array[0]
    for i in array:
        if i < res:
            res = i
        elif not isinstance(i, int, float):
            raise ArrayTypeError
        return res
        
def max(array):
    res = array[0]
    for i in array:
        if i > res:
            res = i
        elif not isinstance(i, int, float):
            raise ArrayTypeError
        return res
def arifmetic_mean(array):
    s = sum_arr(array)
    return s / len(array)