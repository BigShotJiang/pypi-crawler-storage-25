def leafs(array):
    def is_leaf(array):
        return isinstance(array, int)

    res = []
 
    for i in array:
        if is_leaf(i):
            res.append(i)
        else:
            leaf = leafs(i)
            res += leaf
 
    return res

def num_of_leafs(array):
    if isinstance(array, int):  
        return 1
    
    res = 0
    for i in array:
        res += num_of_leafs(i)  
    return res

def len_arr(array) -> int:
    res = 0
    for i in array:
        if isinstance(i, (int, str, float, bool)):
            res += 1
        else:
            res  += len_arr(i)
    return res

def equation_system(full_matrix):
    def get_determinant(matrix):
        size = len(matrix)
        if size == 2:
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
        
        if size == 3:
            m = matrix
            return (m[0][0] * m[1][1] * m[2][2] +
                    m[0][1] * m[1][2] * m[2][0] +
                    m[0][2] * m[1][0] * m[2][1] -
                    m[0][2] * m[1][1] * m[2][0] -
                    m[0][0] * m[1][2] * m[2][1] -
                    m[0][1] * m[1][0] * m[2][2])
    n = len(full_matrix)
    
    
    main_matrix = [row[:n] for row in full_matrix]
    
    constants = [row[n] for row in full_matrix]
    
    main_det = get_determinant(main_matrix)
    if main_det == 0:
        return "has no solution"

    results = []
    for i in range(n):
        
        temp_matrix = [row[:] for row in main_matrix]
        
        for j in range(n):
            temp_matrix[j][i] = constants[j]
        
        results.append(get_determinant(temp_matrix) / main_det)
    
    return results
