from __future__ import annotations

from typing import Any

from comate_agent_sdk.tool_schemas._base import ToolOutput


class BashOutput(ToolOutput):
    stdout: str
    stderr: str
    exit_code: int
    timed_out: bool
    interrupted: bool
    killed: bool
    duration_ms: int
    truncated: bool
    truncated_reason: str | None = None
    artifact: dict[str, Any] | None = None
