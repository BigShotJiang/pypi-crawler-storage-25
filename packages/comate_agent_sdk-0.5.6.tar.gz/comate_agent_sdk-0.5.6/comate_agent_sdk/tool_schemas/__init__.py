"""Tool Input/Output schemas for facade consumers.

Output schemas are defined in this module.
Input schemas are re-exported from their original tool implementation files.
"""
from comate_agent_sdk.tool_schemas._base import ToolOutput
from comate_agent_sdk.tool_schemas._registry import TOOL_SCHEMA_REGISTRY
from comate_agent_sdk.tool_schemas._projection import project_input, project_output

# ── Output schemas ──
from comate_agent_sdk.tool_schemas.bash import BashOutput
from comate_agent_sdk.tool_schemas.read import ReadOutput
from comate_agent_sdk.tool_schemas.write import WriteOutput
from comate_agent_sdk.tool_schemas.edit import EditOutput
from comate_agent_sdk.tool_schemas.search import GlobOutput, GrepOutput, LSOutput
from comate_agent_sdk.tool_schemas.web import WebFetchOutput
from comate_agent_sdk.tool_schemas.task import TaskCreateOutput, TaskListOutput, TaskGetOutput, TaskUpdateOutput
from comate_agent_sdk.tool_schemas.team import TeamCreateOutput, TeamDeleteOutput, SendMessageOutput
from comate_agent_sdk.tool_schemas.misc import AskUserQuestionOutput, ExitPlanModeOutput, YieldTurnOutput
from comate_agent_sdk.tool_schemas.custom import CustomToolOutput

# ── Input schemas (re-exported from tool implementation files) ──
from comate_agent_sdk.system_tools.tools import (
    BashInput, ReadInput, WriteInput, EditInput,
    GlobInput, GrepInput, LSInput, WebFetchInput,
    AskUserQuestionInput, ExitPlanModeInput, YieldTurnInput,
)
from comate_agent_sdk.system_tools.task.tools import (
    TaskCreateInput, TaskListInput, TaskGetInput, TaskUpdateInput,
)
from comate_agent_sdk.system_tools.team.tools import TeamCreateInput, SendMessageInput

# ── Union type ──
ToolOutputSchema = (
    BashOutput | ReadOutput | WriteOutput | EditOutput
    | GlobOutput | GrepOutput | LSOutput | WebFetchOutput
    | TaskCreateOutput | TaskListOutput | TaskGetOutput | TaskUpdateOutput
    | TeamCreateOutput | TeamDeleteOutput | SendMessageOutput
    | AskUserQuestionOutput | ExitPlanModeOutput | YieldTurnOutput
    | CustomToolOutput
)

__all__ = [
    "ToolOutput", "TOOL_SCHEMA_REGISTRY", "ToolOutputSchema",
    "BashOutput", "ReadOutput", "WriteOutput", "EditOutput",
    "GlobOutput", "GrepOutput", "LSOutput", "WebFetchOutput",
    "TaskCreateOutput", "TaskListOutput", "TaskGetOutput", "TaskUpdateOutput",
    "TeamCreateOutput", "TeamDeleteOutput", "SendMessageOutput",
    "AskUserQuestionOutput", "ExitPlanModeOutput", "YieldTurnOutput",
    "CustomToolOutput",
    "BashInput", "ReadInput", "WriteInput", "EditInput",
    "GlobInput", "GrepInput", "LSInput", "WebFetchInput",
    "TaskCreateInput", "TaskListInput", "TaskGetInput", "TaskUpdateInput",
    "TeamCreateInput", "SendMessageInput",
    "AskUserQuestionInput", "ExitPlanModeInput", "YieldTurnInput",
]
