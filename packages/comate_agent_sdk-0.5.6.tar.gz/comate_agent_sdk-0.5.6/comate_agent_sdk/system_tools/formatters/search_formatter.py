"""Formatters for Glob, Grep, and LS tool results."""
from __future__ import annotations

from typing import Any

from comate_agent_sdk.context.truncation import TruncationRecord
from comate_agent_sdk.system_tools.formatters.types import FormattedToolResult, ToolExecutionMeta

from .common import _artifact_hint, _as_int, _default_truncation, _duration_from_result, _format_hints_footer

_GREP_FORMATTER_CONTEXT_GUARD_FILES = 50
_GREP_FORMATTER_CONTEXT_GUARD_MATCHES = 20
_GREP_FORMATTER_CONTEXT_GUARD_TOTAL = 500


def _pluralize(value: int, singular: str, plural: str | None = None) -> str:
    if value == 1:
        return singular
    return plural or f"{singular}s"


def _format_pagination_inline(meta: dict[str, Any]) -> str:
    head_limit = _as_int(meta.get("head_limit"), 0)
    offset = _as_int(meta.get("offset"), 0)
    parts: list[str] = []
    if head_limit > 0:
        parts.append(f"limit: {head_limit}")
    if offset > 0:
        parts.append(f"offset: {offset}")
    return ", ".join(parts)


def _pagination_hint_args(meta: dict[str, Any], shown_count: int) -> dict[str, Any] | None:
    head_limit = _as_int(meta.get("head_limit"), 0)
    offset = _as_int(meta.get("offset"), 0)
    hint_args: dict[str, Any] = {}
    if head_limit > 0:
        hint_args["head_limit"] = head_limit
        hint_args["offset"] = offset + shown_count
    elif offset > 0:
        hint_args["offset"] = offset + shown_count
    return hint_args or None


def _format_pagination_block(meta: dict[str, Any]) -> str:
    inline = _format_pagination_inline(meta)
    if not inline:
        return ""
    return f"[Showing results with pagination = {inline}]"


def _format_file_size(size_bytes: int) -> str:
    """智能单位转换：B/KB/MB/GB"""
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / 1024 / 1024:.1f}MB"
    else:
        return f"{size_bytes / 1024 / 1024 / 1024:.1f}GB"


def format_glob_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    env_meta = result.get("meta", {})

    pattern_value = env_meta.get("pattern") if isinstance(env_meta, dict) else ""
    pattern = str(pattern_value) if pattern_value not in (None, "") else "**/*"
    search_path = str(data.get("search_path") or "")
    if not search_path and isinstance(env_meta, dict):
        search_path = str(env_meta.get("search_path") or "")
    matches = data.get("matches", [])
    if not isinstance(matches, list):
        matches = []
    truncated = bool(data.get("truncated"))
    lines = list(matches[:100]) or ["No files found"]

    hints: list[dict[str, Any]] = []
    if truncated and matches:
        lines.append("(Results are truncated. Consider using a more specific path or pattern.)")
    if truncated:
        hints.append(
            {
                "action": "Glob",
                "priority": "high",
                "args": {
                    "pattern": pattern,
                    "path": search_path,
                },
            }
        )
    artifact_hint = _artifact_hint(data)
    if artifact_hint is not None:
        hints.append(artifact_hint)

    footer = _format_hints_footer(hints) if truncated else ""
    if footer:
        lines.extend(["", footer])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=_default_truncation(data),
        retrieval_hints=(hints or None) if truncated else None,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_grep_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    env_meta = result.get("meta", {})

    mode = str(env_meta.get("output_mode") if isinstance(env_meta, dict) else "") or "files_with_matches"
    pattern_value = env_meta.get("pattern") if isinstance(env_meta, dict) else ""
    pattern = str(pattern_value) if pattern_value not in (None, "") else "<pattern>"
    search_path = str(env_meta.get("search_path") if isinstance(env_meta, dict) else "") or str(
        data.get("search_path", ".")
    )

    lines: list[str] = []
    hints: list[dict[str, Any]] = []

    truncated = bool(data.get("truncated"))
    lower_bound = bool(data.get("total_matches_is_lower_bound"))
    formatter_clipped = False
    formatter_shown_range: dict[str, int] | None = None
    formatter_total_available: int | None = None
    shown_count = 0
    if mode == "files_with_matches":
        files = data.get("files", [])
        if not isinstance(files, list):
            files = []
        shown_count = len(files)
        count = _as_int(data.get("count"), len(files))
        count_label = f"at least {count}" if lower_bound else str(count)
        pagination_inline = _format_pagination_inline(env_meta if isinstance(env_meta, dict) else {})
        if files:
            header = f"Found {count_label} {_pluralize(count, 'file')}"
            if pagination_inline:
                header += f" {pagination_inline}"
            lines.append(header)
            lines.extend(files[:100])
        else:
            lines.append("No files found")
    elif mode == "count":
        counts = data.get("counts", [])
        if not isinstance(counts, list):
            counts = []
        shown_count = len(counts)
        total_matches = _as_int(data.get("total_matches"), 0)
        total_matches_label = f"at least {total_matches}" if lower_bound else str(total_matches)
        files_with_counts = 0
        pagination_inline = _format_pagination_inline(env_meta if isinstance(env_meta, dict) else {})
        for row in counts[:100]:
            if isinstance(row, dict):
                files_with_counts += 1
                lines.append(f"{row.get('file')}:{row.get('count')}")
        if not lines:
            lines.append("No matches found")
        summary = (
            f"Found {total_matches_label} total {_pluralize(total_matches, 'occurrence')} across "
            f"{files_with_counts} {_pluralize(files_with_counts, 'file')}."
        )
        if pagination_inline:
            summary += f" with pagination = {pagination_inline}"
        lines.extend(["", summary])
    else:
        matches_by_file = data.get("matches_by_file", {})
        if not isinstance(matches_by_file, dict):
            matches_by_file = {}

        total_matches = _as_int(data.get("total_matches"), 0)
        total_files = len(matches_by_file)
        matches_per_file_counts: list[int] = []
        for _file_data in matches_by_file.values():
            if isinstance(_file_data, dict):
                matches_in_file = _file_data.get("matches", [])
                if isinstance(matches_in_file, list):
                    matches_per_file_counts.append(len(matches_in_file))
        max_matches_in_any_file = max(matches_per_file_counts) if matches_per_file_counts else 0

        match_count = 0
        files_shown = 0
        first_file = None
        first_line_number = None
        for file, file_data in list(matches_by_file.items())[:_GREP_FORMATTER_CONTEXT_GUARD_FILES]:
            if not isinstance(file_data, dict):
                continue
            matches_in_file = file_data.get("matches", [])
            if not isinstance(matches_in_file, list):
                continue

            files_shown += 1
            for m in matches_in_file[:_GREP_FORMATTER_CONTEXT_GUARD_MATCHES]:
                if not isinstance(m, dict):
                    continue
                ln = m.get("line_number")
                text = str(m.get("line", ""))
                if isinstance(ln, int):
                    before_context = m.get("before_context") or []
                    if isinstance(before_context, list):
                        for idx, context_line in enumerate(before_context):
                            context_ln = ln - len(before_context) + idx
                            lines.append(f"{file}-{context_ln}:{context_line}")
                    lines.append(f"{file}:{ln}:{text}")
                    after_context = m.get("after_context") or []
                    if isinstance(after_context, list):
                        for idx, context_line in enumerate(after_context, start=1):
                            lines.append(f"{file}-{ln + idx}:{context_line}")
                else:
                    lines.append(f"{file}:{text}")

                if first_file is None and isinstance(ln, int):
                    first_file = file
                    first_line_number = _as_int(ln, 1)

                match_count += 1
                shown_count = match_count
                if match_count >= _GREP_FORMATTER_CONTEXT_GUARD_TOTAL:
                    break
            if match_count >= _GREP_FORMATTER_CONTEXT_GUARD_TOTAL:
                break

        if not matches_by_file:
            lines.append("No matches found")

        head_limit_in_meta = _as_int(env_meta.get("head_limit"), 0) if isinstance(env_meta, dict) else 0
        reached_display_cap = (
            total_files > _GREP_FORMATTER_CONTEXT_GUARD_FILES
            or max_matches_in_any_file > _GREP_FORMATTER_CONTEXT_GUARD_MATCHES
            or match_count >= _GREP_FORMATTER_CONTEXT_GUARD_TOTAL
        )
        formatter_clipped = reached_display_cap and head_limit_in_meta == 0
        if formatter_clipped:
            lines.extend(
                [
                    "",
                    f"Note: Formatter capped at {_GREP_FORMATTER_CONTEXT_GUARD_FILES} files × "
                    f"{_GREP_FORMATTER_CONTEXT_GUARD_MATCHES} matches per file "
                    f"({_GREP_FORMATTER_CONTEXT_GUARD_TOTAL} total). "
                    f"Showing {files_shown}/{total_files} files, {match_count} matches. "
                    "Use pagination or a more precise search scope to inspect the remaining results.",
                ]
            )
            formatter_shown_range = {
                "files": files_shown,
                "matches_per_file": _GREP_FORMATTER_CONTEXT_GUARD_MATCHES,
                "total_shown": match_count,
            }
            formatter_total_available = total_matches or sum(matches_per_file_counts)

        if first_file is not None and first_line_number is not None:
            hints.append(
                {
                    "action": "Read",
                    "priority": "high",
                    "args": {
                        "file_path": first_file,
                        "offset_line": max(first_line_number - 20, 0),
                        "limit_lines": 120,
                    },
                }
            )

    meta_dict = env_meta if isinstance(env_meta, dict) else {}
    hint_args = _pagination_hint_args(meta_dict, shown_count)
    if mode == "content":
        pagination_note = _format_pagination_block(meta_dict)
        if pagination_note:
            lines.extend(["", pagination_note])

    if truncated:
        hints.append(
            {
                "action": "Grep",
                "priority": "medium",
                "args": {
                    "pattern": pattern,
                    "path": search_path,
                    "output_mode": mode,
                    **(hint_args or {}),
                },
            }
        )
    artifact_hint = _artifact_hint(data)
    if artifact_hint is not None:
        hints.append(artifact_hint)

    footer = _format_hints_footer(hints) if truncated else ""
    if footer:
        lines.extend(["", footer])

    truncation_record = _default_truncation(data)
    if formatter_clipped:
        reasons = []
        if truncation_record is not None and truncation_record.formatter_reason:
            reasons.append(truncation_record.formatter_reason)
        reasons.append("formatter_clip")
        truncation_record = TruncationRecord(
            formatter_truncated=True,
            formatter_reason=",".join(reasons),
            formatter_shown_range=formatter_shown_range,
            formatter_total_estimate=formatter_total_available or 0,
        )

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=truncation_record,
        retrieval_hints=(hints or None) if truncated else None,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_ls_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    env_meta = result.get("meta", {})

    entries = data.get("entries", [])
    if not isinstance(entries, list):
        entries = []

    count = _as_int(data.get("count"), len(entries))
    truncated = bool(data.get("truncated"))
    path = str(data.get("path") or "")
    if not path and isinstance(env_meta, dict):
        path = str(env_meta.get("path") or "")
    sort_by = str(env_meta.get("sort_by") if isinstance(env_meta, dict) else "") or "name"

    lines = [
        f"# LS: {path or '.'}",
        "",
        f"Entries shown: {len(entries)} of {count} (sorted by {sort_by})"
        + (" (TRUNCATED)" if truncated else ""),
        "",
    ]
    if entries:
        for row in entries[:100]:
            if not isinstance(row, dict):
                continue
            item_type = str(row.get("type") or "other").upper()
            name = str(row.get("name") or "")
            size = _as_int(row.get("size"), 0)
            size_display = _format_file_size(size)
            lines.append(f"- [{item_type}] {name} (size={size_display})")
    else:
        lines.append("- (empty)")

    hints: list[dict[str, Any]] = []
    if truncated:
        hints.append(
            {
                "action": "LS",
                "priority": "high",
                "args": {
                    "path": path,
                    "head_limit": 300,
                    "sort_by": sort_by,
                },
            }
        )
        if count > 300:
            lines.append("")
            lines.append("Note: Results exceed schema max head_limit (300). Refine the path or request a smaller page.")
    artifact_hint = _artifact_hint(data)
    if artifact_hint is not None:
        hints.append(artifact_hint)

    footer = _format_hints_footer(hints) if truncated else ""
    if footer:
        lines.extend(["", footer])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=_default_truncation(data),
        retrieval_hints=hints or None,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)
