"""Formatter for Bash tool results."""
from __future__ import annotations

from typing import Any

from comate_agent_sdk.system_tools.formatters.types import FormattedToolResult, ToolExecutionMeta

from .common import _artifact_hint, _as_float, _as_int, _default_truncation, _duration_from_result, _format_hints_footer


def format_bash_result(tool_name: str, tool_call_id: str, result: dict[str, Any]) -> FormattedToolResult:
    data = result.get("data", {})
    env_meta = result.get("meta", {})

    args = env_meta.get("args") if isinstance(env_meta, dict) else None
    if isinstance(args, list):
        cmd = " ".join(str(part) for part in args)
    else:
        cmd = "<command>"

    exit_code = _as_int(data.get("exit_code"), 0)
    duration_ms = _as_float(data.get("duration_ms"))
    timed_out = bool(data.get("timed_out"))
    interrupted = bool(data.get("interrupted"))
    truncated = bool(data.get("truncated"))

    stdout = str(data.get("stdout", ""))
    stderr = str(data.get("stderr", ""))
    artifact = data.get("artifact") if isinstance(data.get("artifact"), dict) else None
    artifact_path = str(artifact.get("relpath", "")).strip() if artifact else ""

    lines = [
        f"# Bash: {cmd}",
        "",
        f"Exit code: {exit_code}",
        f"Timed out: {timed_out}",
        f"Interrupted: {interrupted}",
    ]
    if duration_ms is not None:
        lines.append(f"Duration: {duration_ms:.1f}ms")

    if truncated and artifact_path:
        lines.extend(
            [
                "",
                f"Full output saved to: {artifact_path}",
                "",
                "Preview:",
                stdout or "(empty)",
            ]
        )
    else:
        lines.extend(["", "Output:", stdout or "(empty)"])

    if stderr:
        lines.extend(["", "Control:", stderr])

    hints: list[dict[str, Any]] = []
    artifact_hint = _artifact_hint(data)
    if artifact_hint is not None:
        hints.append(artifact_hint)

    if truncated:
        hints.append(
            {
                "action": "Read",
                "priority": "medium",
                "args": {
                    "file_path": artifact_path or "<full-output-file>",
                    "format": "raw",
                    "offset_line": 1,
                    "limit_lines": 500,
                },
            }
        )

    footer = _format_hints_footer(hints) if truncated or timed_out else ""
    if footer:
        lines.extend(["", footer])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        truncation=_default_truncation(data),
        retrieval_hints=hints or None,
        duration_ms=duration_ms if duration_ms is not None else _duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)
