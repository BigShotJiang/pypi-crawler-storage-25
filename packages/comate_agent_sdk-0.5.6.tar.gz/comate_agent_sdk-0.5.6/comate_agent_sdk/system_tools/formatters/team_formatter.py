"""Formatters for Team tools: SendMessage, TeamCreate, TeamDelete."""
from __future__ import annotations

from typing import Any

from comate_agent_sdk.system_tools.formatters.types import FormattedToolResult, ToolExecutionMeta

from .common import _duration_from_result, _format_hints_footer

_CONTENT_PREVIEW_CHARS = 80


def _content_preview(content: str) -> str:
    if not content:
        return ""
    text = content.replace("\n", " ").strip()
    if len(text) <= _CONTENT_PREVIEW_CHARS:
        return text
    return text[:_CONTENT_PREVIEW_CHARS] + "..."


def format_send_message_result(
    tool_name: str, tool_call_id: str, result: dict[str, Any]
) -> FormattedToolResult:
    data = result.get("data", {}) or {}
    env_meta = result.get("meta", {}) or {}

    to = str(data.get("to") or "")
    msg_type = str(data.get("type") or "message")
    delivered_to = data.get("delivered_to") or []
    if not isinstance(delivered_to, list):
        delivered_to = []

    from_agent = str(env_meta.get("from") or "<unknown>")
    team_name = str(env_meta.get("team") or "<unknown>")
    content = str(env_meta.get("content") or "")

    lines = [
        f"# SendMessage: {from_agent} → {to} (team={team_name})",
        "",
        f"Type: {msg_type}",
        f"Delivered to: {list(delivered_to)}",
    ]
    preview = _content_preview(content)
    if preview:
        lines.append(f"Content preview: {preview}")

    hints: list[dict[str, Any]] = []
    should_hint_yieldturn = (to == "*") or (msg_type == "shutdown_request")
    if should_hint_yieldturn:
        hints.append(
            {
                "action": "YieldTurn",
                "priority": "high",
                "args": {},
            }
        )
        footer = _format_hints_footer(hints)
        if footer:
            lines.extend(["", footer])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        retrieval_hints=hints or None,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_team_create_result(
    tool_name: str, tool_call_id: str, result: dict[str, Any]
) -> FormattedToolResult:
    data = result.get("data", {}) or {}
    env_meta = result.get("meta", {}) or {}

    team_name = str(data.get("team_name") or "")
    config_path = str(data.get("config_path") or "")
    description = str(data.get("description") or "") or "(none)"
    leader = str(env_meta.get("leader") or "<unknown>")

    lines = [
        f"# TeamCreate: {team_name}",
        "",
        f"Leader: {leader}",
        f"Config: {config_path}",
        f"Description: {description}",
    ]

    hints: list[dict[str, Any]] = [
        {
            "action": "Agent",
            "priority": "medium",
            "args": {
                "team_name": team_name,
                "name": "<teammate-name>",
            },
        }
    ]
    footer = _format_hints_footer(hints)
    if footer:
        lines.extend(["", footer])

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        retrieval_hints=hints,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)


def format_team_delete_result(
    tool_name: str, tool_call_id: str, result: dict[str, Any]
) -> FormattedToolResult:
    data = result.get("data", {}) or {}

    team_name = str(data.get("team_name") or "")
    cleaned = data.get("cleaned") or []
    if not isinstance(cleaned, list):
        cleaned = []

    lines = [f"# TeamDelete: {team_name}", "", "Cleaned:"]
    if cleaned:
        lines.extend([f"- {item}" for item in cleaned])
    else:
        lines.append("- (nothing cleaned — team dir did not exist)")

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text="\n".join(lines).strip(), meta=meta)
