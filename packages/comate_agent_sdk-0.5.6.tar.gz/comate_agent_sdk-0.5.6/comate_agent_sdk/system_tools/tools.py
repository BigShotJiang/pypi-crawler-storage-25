from __future__ import annotations

import asyncio
from datetime import datetime
import difflib
import hashlib
import json
import logging
import os
import re
import shlex
import signal
import shutil
import stat as stat_module
import subprocess
import tempfile
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from fnmatch import fnmatch
from wcmatch.glob import globmatch, GLOBSTAR, DOTMATCH, BRACE

_GLOB_FLAGS = GLOBSTAR | DOTMATCH | BRACE
from pathlib import Path, PurePath
from typing import Annotated, Any, Callable, Literal

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_core import PydanticUseDefault

from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.system_tools import _internal_utils as iu
from comate_agent_sdk.system_tools.artifact_store import ArtifactStore
from comate_agent_sdk.system_tools.description import (
    ASK_USER_QUESTION_USAGE_RULES,
    BASH_USAGE_RULES,
    EDIT_USAGE_RULES,
    EXIT_PLAN_MODE_USAGE_RULES,
    GLOB_USAGE_RULES,
    GREP_USAGE_RULES,
    LS_USAGE_RULES,
    READ_USAGE_RULES,
    WEBFETCH_USAGE_RULES,
    WRITE_USAGE_RULES,
    YIELD_TURN_USAGE_RULES,
)
from comate_agent_sdk.system_tools.policy_engine import (
    BASH_COMMAND_POLICY,
    READ_REGISTRY_POLICY,
)
from comate_agent_sdk.system_tools.path_guard import (
    PathGuardError,
    normalize_user_path,
    resolve_for_read,
    resolve_for_search,
    resolve_for_write,
    suggest_path_under_roots,
    to_safe_relpath,
)
from comate_agent_sdk.system_tools.task import TASK_TOOLS
from comate_agent_sdk.system_tools.team.config import resolve_teams_base_dir
from comate_agent_sdk.system_tools.team.tools import (
    SendMessage,
    TeamCreate,
    TeamDelete,
)
from comate_agent_sdk.system_tools.task.tools import (
    TaskCreate,
    TaskCreateInput,
    TaskGet,
    TaskGetInput,
    TaskList,
    TaskListInput,
    TaskUpdate,
    TaskUpdateInput,
)
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools.decorator import Tool, tool
from comate_agent_sdk.tools.depends import Depends
from comate_agent_sdk.tools.system_context import SystemToolContext, get_system_tool_context

logger = logging.getLogger(__name__)

_READ_MIN_LIMIT = 1
_READ_DEFAULT_LIMIT = 500
_LINE_TRUNCATE_CHARS = 2000
_READ_BINARY_SCAN_BYTES = 8192
_READ_BINARY_EXTENSIONS = frozenset(
    {
        ".7z",
        ".a",
        ".avi",
        ".bin",
        ".bmp",
        ".bz2",
        ".class",
        ".db",
        ".dll",
        ".dylib",
        ".eot",
        ".exe",
        ".flac",
        ".gif",
        ".gz",
        ".ico",
        ".jar",
        ".jpeg",
        ".jpg",
        ".mp3",
        ".mp4",
        ".o",
        ".ogg",
        ".otf",
        ".pdf",
        ".png",
        ".pyc",
        ".pyo",
        ".so",
        ".sqlite",
        ".tar",
        ".ttf",
        ".wav",
        ".wasm",
        ".webm",
        ".webp",
        ".woff",
        ".woff2",
        ".xz",
        ".zip",
    }
)

_BASH_DEFAULT_TIMEOUT_MS = 120_000
_BASH_MAX_TIMEOUT_MS = 600_000
_BASH_OUTPUT_DEFAULT_MAX_CHARS = 30_000
_READ_HARD_LINE_LIMIT = 50 * 1024
_MAX_EDIT_FILE_SIZE = 1024 * 1024 * 1024

_WEBFETCH_TIMEOUT_SECONDS = 20
_WEBFETCH_LLM_TIMEOUT_SECONDS = 30
_WEBFETCH_CACHE_TTL_SECONDS = 15 * 60
_WEBFETCH_MARKDOWN_TRUNCATE_CHARS = 50_000

_TEXT_SPILL_CHARS = 10_000
_BYTES_SPILL_LIMIT = 16 * 1024
_READ_TEXT_SPILL_CHARS = 30_000
_READ_BYTES_SPILL_LIMIT = 64 * 1024
_LIST_SPILL_LIMIT = 100
_GLOB_DEFAULT_HEAD_LIMIT = 100
_ARTIFACT_TTL_SECONDS = 3600
_GREP_CONTENT_PER_FILE_MAX_COUNT = 1000
_GREP_CONTENT_PARSE_MAX_CHARS = 200_000
_GREP_CONTENT_MATCH_EVENT_LIMIT = 5000
_SEARCH_RG_TIMEOUT_SECONDS = 20.0
_SUBPROCESS_INTERRUPT_GRACE_SECONDS = 0.8
_MEMORY_INDEX_GUARD_MODE_ENV = "COMATE_MEMORY_INDEX_GUARD_MODE"
_MEMORY_INDEX_FREEFORM_STREAK_ENV = "COMATE_MEMORY_INDEX_FREEFORM_STREAK"
_MEMORY_INDEX_GUARD_DEFAULT_MODE = "warn"
_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT = 3
_MEMORY_INDEX_ENTRY_RE = re.compile(
    r"^\s*(?:[-*+]|\d+\.)\s+@[^\s@]+\.md\s*-\s*.+\s*$"
)
_MEMORY_INDEX_LEGACY_ENTRY_RE = re.compile(
    r"^\s*(?:[-*+]|\d+\.)\s+`[^`]+\.md`\s*(?:\|\s*.+)?\s*$"
)
_MEMORY_INDEX_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S.*$")

_SEARCH_EXCLUDED_DIRS = (".bzr", ".git", ".hg", ".jj", ".sl", ".svn")

_RIPGREP_MISSING_MESSAGE = (
    "ripgrep (rg) binary not found. It should be installed automatically via the "
    "'ripgrep' wheel; if missing, install via: brew install ripgrep / "
    "apt install ripgrep / pip install ripgrep."
)

_WEBFETCH_CACHE: dict[str, dict[str, Any]] = {}
# Backward-compatible alias for existing tests/introspection.
_READ_REGISTRY_MEMORY = READ_REGISTRY_POLICY.memory
_READ_REUSE_MESSAGE = (
    "File unchanged since last read. The content from the earlier Read result in this conversation is still current."
)

# P2-8: Cleanup counter for loop-local dicts (every 100 calls)
_CLEANUP_CALL_COUNTER = 0
_CLEANUP_FREQUENCY = 100


def _maybe_cleanup_loop_dicts() -> None:
    """Low-frequency cleanup of loop-local dicts to prevent memory leaks."""
    global _CLEANUP_CALL_COUNTER
    _CLEANUP_CALL_COUNTER += 1
    if _CLEANUP_CALL_COUNTER % _CLEANUP_FREQUENCY == 0:
        iu.cleanup_loop_local_dicts()
        READ_REGISTRY_POLICY.cleanup_stale_loops()


def _project_root(ctx: SystemToolContext) -> Path:
    return ctx.project_root.resolve()


def _workspace_root(ctx: SystemToolContext) -> Path:
    if ctx.workspace_root is not None:
        return ctx.workspace_root.resolve()
    return (_project_root(ctx) / ".agent_workspace").resolve()


def _session_root_from_ctx(ctx: SystemToolContext) -> Path | None:
    if ctx.session_root is None:
        return None
    return ctx.session_root.resolve()


def _allowed_roots(ctx: SystemToolContext) -> list[Path]:
    roots = [_project_root(ctx)]
    roots.append(_workspace_root(ctx))
    roots.extend(list(ctx.extra_write_roots or ()))
    return roots


def _extra_read_roots(ctx: SystemToolContext) -> tuple[Path, ...]:
    return ctx.extra_read_roots or ()


def _artifact_store(ctx: SystemToolContext) -> ArtifactStore:
    return ArtifactStore(_workspace_root(ctx))


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _is_team_inbox_json_path(path: Path) -> bool:
    teams_root = resolve_teams_base_dir().resolve()
    resolved_path = path.resolve()
    if not _is_under(resolved_path, teams_root):
        return False
    if resolved_path.suffix != ".json":
        return False
    return resolved_path.parent.name == "inboxes"


async def _mark_read(ctx: SystemToolContext, path: Path) -> None:
    """Mark file as read (without version tracking, for backward compatibility)."""
    await READ_REGISTRY_POLICY.mark_read(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )


async def _mark_read_with_version(ctx: SystemToolContext, path: Path, sha256: str) -> None:
    """Mark file as read with version tracking (for Edit conflict detection)."""
    await READ_REGISTRY_POLICY.mark_read_with_version(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        sha256=sha256,
    )


async def _mark_read_range_with_version(
    ctx: SystemToolContext,
    path: Path,
    sha256: str,
    *,
    offset_line: int,
    limit_lines: int,
    format_name: str,
    max_line_chars: int,
) -> None:
    await READ_REGISTRY_POLICY.mark_read_range(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        sha256=sha256,
        offset_line=offset_line,
        limit_lines=limit_lines,
        format_name=format_name,
        max_line_chars=max_line_chars,
    )


async def _require_read(ctx: SystemToolContext, path: Path) -> bool:
    return await READ_REGISTRY_POLICY.has_read(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )


async def _check_version_conflict(ctx: SystemToolContext, path: Path, current_sha256: str) -> bool:
    """Check if file has been modified externally since last Read.

    Returns:
        True if conflict detected (version mismatch), False otherwise
    """
    has_read, stored_sha256 = await READ_REGISTRY_POLICY.has_read_with_version(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )
    if not has_read:
        return False  # Not read yet, no conflict
    if stored_sha256 is None:
        return False  # Read without version tracking (old behavior), no conflict check
    return stored_sha256 != current_sha256  # Conflict if versions differ


async def _has_read_range_with_version(
    ctx: SystemToolContext,
    path: Path,
    sha256: str,
    *,
    offset_line: int,
    limit_lines: int,
    format_name: str,
    max_line_chars: int,
) -> bool:
    return await READ_REGISTRY_POLICY.has_read_range(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        sha256=sha256,
        offset_line=offset_line,
        limit_lines=limit_lines,
        format_name=format_name,
        max_line_chars=max_line_chars,
    )


async def _read_text(path: Path, *, encoding: str = "utf-8") -> str:
    return await iu.io_call(path.read_text, encoding=encoding, errors="replace")


def _read_bytes_prefix_sync(path: Path, limit: int) -> bytes:
    with path.open("rb") as handle:
        return handle.read(limit)


async def _read_bytes_prefix(path: Path, *, limit: int) -> bytes:
    return await iu.io_call(_read_bytes_prefix_sync, path, limit)


async def _exists(path: Path) -> bool:
    return await iu.io_call(path.exists)


async def _is_dir(path: Path) -> bool:
    return await iu.io_call(path.is_dir)


async def _is_file(path: Path) -> bool:
    return await iu.io_call(path.is_file)


async def _stat(path: Path):
    return await iu.io_call(path.stat)


def _looks_binary_sample(sample: bytes) -> bool:
    if not sample:
        return False
    if b"\x00" in sample:
        return True

    suspicious = 0
    for byte in sample:
        if byte < 32 and byte not in (9, 10, 12, 13):
            suspicious += 1
        elif byte == 127:
            suspicious += 1
    return suspicious * 10 >= len(sample) * 3


async def _detect_binary_read_target(path: Path) -> str | None:
    if any(suffix.lower() in _READ_BINARY_EXTENSIONS for suffix in path.suffixes):
        return "extension_blacklist"

    sample = await _read_bytes_prefix(path, limit=_READ_BINARY_SCAN_BYTES)
    if _looks_binary_sample(sample):
        return "content_scan"
    return None


def _memory_relpath_from_user_path(user_path: str) -> Path | None:
    raw = str(user_path or "").strip()
    if not raw:
        return None

    expanded = Path(raw).expanduser()
    if expanded.is_absolute():
        return None

    parts = [p for p in PurePath(raw).parts if p not in (".", "")]
    if not parts:
        return None

    relpath: Path | None = None
    if len(parts) == 1 and parts[0].lower() == "memory.md":
        relpath = Path("MEMORY.md")
    elif parts[0].lower() == "memory" and len(parts) > 1:
        relpath = Path(*parts[1:])

    if relpath is None:
        return None
    if any(part in {"", ".."} for part in relpath.parts):
        return None
    return relpath


def _memory_root_from_ctx(ctx: SystemToolContext) -> Path | None:
    for root in tuple(ctx.extra_write_roots or ()):
        resolved = root.expanduser().resolve()
        if resolved.name.lower() == "memory":
            return resolved
    return None


def _memory_index_guard_mode() -> Literal["off", "warn", "enforce"]:
    raw = str(os.getenv(_MEMORY_INDEX_GUARD_MODE_ENV, _MEMORY_INDEX_GUARD_DEFAULT_MODE)).strip().lower()
    if raw in {"off", "warn", "enforce"}:
        return raw
    logger.warning(
        f"Invalid {_MEMORY_INDEX_GUARD_MODE_ENV}={raw!r}, fallback to {_MEMORY_INDEX_GUARD_DEFAULT_MODE!r}"
    )
    return _MEMORY_INDEX_GUARD_DEFAULT_MODE


def _memory_index_freeform_streak_limit() -> int:
    raw = str(os.getenv(_MEMORY_INDEX_FREEFORM_STREAK_ENV, str(_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT))).strip()
    try:
        value = int(raw)
    except Exception:
        logger.warning(
            f"Invalid {_MEMORY_INDEX_FREEFORM_STREAK_ENV}={raw!r}, fallback to {_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT}"
        )
        return _MEMORY_INDEX_FREEFORM_STREAK_DEFAULT
    return max(1, value)


def _is_memory_index_target(path: Path, ctx: SystemToolContext) -> bool:
    if path.name.lower() != "memory.md":
        return False
    memory_root = _memory_root_from_ctx(ctx)
    if memory_root is None:
        return False
    return path.resolve() == (memory_root / "MEMORY.md").resolve()


def _memory_index_violation_reason(content: str) -> str | None:
    freeform_limit = _memory_index_freeform_streak_limit()
    freeform_streak = 0
    for line in content.splitlines():
        text = line.strip()
        if not text:
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_HEADING_RE.match(text):
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_ENTRY_RE.match(text):
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_LEGACY_ENTRY_RE.match(text):
            return (
                "Legacy MEMORY.md index format is not allowed. "
                "Use the new format: - @filename.md - short description."
            )

        freeform_streak += 1
        if freeform_streak >= freeform_limit:
            return (
                "MEMORY.md must be an index-only router file. "
                "Write detailed memory to `memory/<topic>.md`, then keep one-line index entries in MEMORY.md "
                "for example: - @debugging.md - summary."
            )
    return None


def _enforce_memory_index_policy(
    *,
    path: Path,
    content: str,
    ctx: SystemToolContext,
) -> tuple[dict[str, Any] | None, str | None]:
    if not _is_memory_index_target(path, ctx):
        return None, None

    reason = _memory_index_violation_reason(content)
    if reason is None:
        return None, None

    mode = _memory_index_guard_mode()
    if mode == "off":
        return None, None
    if mode == "warn":
        logger.warning(f"MEMORY.md index guard warning: {reason}")
        return None, reason
    return err("INVALID_ARGUMENT", reason), None


async def _resolve_write_path(
    *,
    user_path: str,
    ctx: SystemToolContext,
) -> Path:
    """Resolve write target.

    Three-stage explicit routing:
    1. Memory route: dedicated matcher for memory/MEMORY.md paths.
    2. Absolute path route: check against all known writable roots.
    3. Relative path route: unconditionally resolve under project_root.
    """
    workspace_root = _workspace_root(ctx)
    project_root = _project_root(ctx)
    extra_roots = tuple(ctx.extra_write_roots or ())

    # Stage 1: Memory route (dedicated matcher, unchanged)
    memory_relpath = _memory_relpath_from_user_path(user_path)
    if memory_relpath is not None:
        memory_root = _memory_root_from_ctx(ctx)
        if memory_root is not None:
            return resolve_for_write(
                user_path=memory_relpath.as_posix(),
                workspace_root=memory_root,
            )

    candidate = normalize_user_path(user_path)

    # Stage 2: Absolute path — check against known writable roots in priority order
    if candidate.is_absolute():
        for root in (project_root, workspace_root, *extra_roots):
            try:
                return resolve_for_write(user_path=user_path, workspace_root=root)
            except PathGuardError:
                continue
        raise PathGuardError(
            "PATH_ESCAPE",
            f"path is outside all allowed write roots",
        )

    # Stage 3: Relative path — unconditionally resolve under project_root
    return resolve_for_write(user_path=user_path, workspace_root=project_root)


def _atomic_write_bytes_sync(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    original_mode: int | None = None
    try:
        original_mode = stat_module.S_IMODE(os.stat(path).st_mode)
    except FileNotFoundError:
        pass
    fd, tmp_name = tempfile.mkstemp(prefix=".tmp_", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        if original_mode is not None:
            os.chmod(tmp_name, original_mode)
        os.replace(tmp_name, path)
        try:
            dir_fd = os.open(str(path.parent), os.O_DIRECTORY)
        except Exception:
            dir_fd = None
        if dir_fd is not None:
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
    finally:
        if os.path.exists(tmp_name):
            try:
                os.remove(tmp_name)
            except FileNotFoundError:
                pass


async def _atomic_write_text(path: Path, content: str, *, encoding: str = "utf-8") -> None:
    payload = content.encode(encoding)
    await iu.io_call(_atomic_write_bytes_sync, path, payload)


def _path_error_result(exc: PathGuardError) -> dict[str, Any]:
    return err(exc.code, exc.message)


def _invalid_argument(message: str, *, field: str | None = None) -> dict[str, Any]:
    field_errors: list[dict[str, Any]] = []
    if field:
        field_errors.append({"field": field, "message": message})
    return err("INVALID_ARGUMENT", message, field_errors=field_errors)


def _validate_bash_command(
    params: BashInput,
    *,
    cwd: Path,
    ctx: SystemToolContext,
) -> dict[str, Any] | None:
    violation = BASH_COMMAND_POLICY.validate(
        args=params.args,
        cwd=cwd,
        allowed_roots=_allowed_roots(ctx),
    )
    if violation is None:
        return None
    return err(violation.code, violation.message)


class BashInput(BaseModel):
    args: list[str] = Field(min_length=1, description="Command and arguments as a list, e.g. ['git', 'status']. For shell features (pipes, &&, redirects): ['sh', '-c', 'cmd1 | cmd2']")
    timeout_ms: int = Field(default=_BASH_DEFAULT_TIMEOUT_MS, ge=1, le=_BASH_MAX_TIMEOUT_MS, description="Timeout in milliseconds (default: 120000ms). Increase for long-running commands.")
    cwd: str | None = Field(default=None, description="Working directory for command. Defaults to project root when omitted.")
    env: dict[str, str] | None = Field(default=None, description="Optional environment variable overrides")
    max_output_chars: int = Field(default=_BASH_OUTPUT_DEFAULT_MAX_CHARS, ge=200, le=200_000, description="Maximum output characters returned (default: 30000). Reduce if output is too large.")

    model_config = {"extra": "forbid"}

    @model_validator(mode="before")
    @classmethod
    def _coerce_stringified_fields(cls, data: Any) -> Any:
        """Defense-in-depth: 修复非原生 OpenAI 模型将参数值字符串化的问题。"""
        if not isinstance(data, dict):
            return data

        # args: '["git","diff"]' → ["git", "diff"]
        args = data.get("args")
        if isinstance(args, str):
            try:
                parsed = json.loads(args)
                if isinstance(parsed, list):
                    data["args"] = parsed
            except (json.JSONDecodeError, TypeError):
                pass

        # env: '{}' / '{"K":"V"}' / 'null' → dict | None
        env = data.get("env")
        if isinstance(env, str):
            normalized = env.strip().lower()
            if normalized in ("null", "none", ""):
                data["env"] = None
            else:
                try:
                    parsed = json.loads(env)
                    if isinstance(parsed, dict):
                        data["env"] = parsed
                    elif parsed is None:
                        data["env"] = None
                except (json.JSONDecodeError, TypeError):
                    pass

        # timeout_ms: "120000" → 120000
        timeout_ms = data.get("timeout_ms")
        if isinstance(timeout_ms, str):
            try:
                data["timeout_ms"] = int(timeout_ms)
            except (ValueError, TypeError):
                pass

        # max_output_chars: "30000" → 30000
        max_output_chars = data.get("max_output_chars")
        if isinstance(max_output_chars, str):
            try:
                data["max_output_chars"] = int(max_output_chars)
            except (ValueError, TypeError):
                pass

        return data

    @field_validator("cwd", mode="before")
    @classmethod
    def _normalize_cwd(cls, value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"", "null", "none"}:
                return None
        return value


class ReadInput(BaseModel):
    file_path: str = Field(description="Path to text file")
    offset_line: int = Field(
        default=1,
        ge=0,
        description="1-based line number to start reading from. Passing 0 is tolerated and treated as 1.",
    )
    limit_lines: int = Field(
        default=_READ_DEFAULT_LIMIT,
        ge=_READ_MIN_LIMIT,
        description="Number of lines to read (default: 500). Large slices are limited by the output budget, not by a fixed schema maximum. If file has more, response includes has_more=true and next_offset_line for pagination.",
    )
    format: Literal["line_numbers", "raw"] = Field(default="line_numbers", description="line_numbers (default): prefixes each line with its number, recommended for code editing; raw: plain text without line numbers.")
    max_line_chars: int = Field(default=_LINE_TRUNCATE_CHARS, ge=100, le=20_000, description="Lines longer than this are truncated in output (default: 2000).")

    model_config = {"extra": "forbid"}


class WriteInput(BaseModel):
    file_path: str = Field(description="Target file path")
    content: str = Field(description="Content to write")
    mode: Literal["overwrite", "append"] = Field(default="overwrite", description="overwrite (default): replaces the entire file content; append: adds content to the end of the file.")
    encoding: str = Field(default="utf-8", description="File encoding (default: utf-8).")

    model_config = {"extra": "forbid"}


class EditInput(BaseModel):
    file_path: str = Field(description="Target file path")
    old_string: str = Field(description="Text to replace. Must match exactly (including whitespace and indentation). Use empty string only to create a new file or fill an existing empty file.")
    new_string: str = Field(description="Replacement text")
    replace_all: bool = Field(default=False, description="If True, replace all occurrences. Use when old_string appears multiple times and all should be replaced.")

    model_config = {"extra": "forbid"}


def _normalize_write_input_for_path(path: Path, content: str) -> str:
    if path.suffix.lower() in {".md", ".mdx"}:
        return content
    return iu.strip_trailing_whitespace(content)


class GlobInput(BaseModel):
    pattern: str = Field(description="Glob pattern to match file paths, e.g. '**/*.py' (recursive), '*.json' (current dir), 'src/**/*.ts'.")
    path: str | None = Field(default=None, description="Directory to search in. Defaults to project root when omitted.")

    model_config = {"extra": "forbid"}


class GrepInput(BaseModel):
    pattern: str = Field(description="Ripgrep regex pattern to search for, e.g. 'def\\s+\\w+', 'TODO|FIXME', 'class\\s+Foo'.")
    path: str | None = Field(default=None, description="Directory or file to search in. Defaults to project root when omitted.")
    glob: str | None = Field(default=None, description="Filter files by glob pattern, e.g. '*.py', '**/*.ts'. Applied on top of path.")
    type: str | None = Field(default=None, description="Filter by file type shorthand, e.g. 'py', 'js', 'rust'. Faster than glob for common types.")
    output_mode: Literal["content", "files_with_matches", "count"] = Field(default="files_with_matches", description="files_with_matches (default): return only file paths; content: return matching lines with context; count: return match count per file.")

    B: int | None = Field(default=None, alias="-B", ge=0, description="Lines of context before each match.")
    A: int | None = Field(default=None, alias="-A", ge=0, description="Lines of context after each match.")
    C: int | None = Field(default=None, alias="-C", ge=0, description="Lines of context before and after each match (shorthand for equal -B and -A).")
    context: int | None = Field(default=None, ge=0, description="Lines of context before and after each match. Takes precedence over -C/-A/-B when set.")
    i: bool | None = Field(default=None, alias="-i", description="Case-insensitive search.")
    n: bool | None = Field(default=True, alias="-n", description="Show line numbers in output (default: True).")

    head_limit: int = Field(
        default=250,
        ge=0,
        description=(
            "Limit output to first N lines/entries, equivalent to \"| head -N\". "
            "Works across all output modes: content (limits output lines), "
            "files_with_matches (limits file paths), count (limits count entries). "
            "Defaults to 250 when unspecified. "
            "Pass 0 for unlimited (use sparingly — large result sets waste context)."
        ),
    )
    offset: int = Field(default=0, ge=0, description="Skip the first N results before applying head_limit.")
    multiline: bool = Field(default=False, description="Enable multiline mode where patterns can span multiple lines.")

    model_config = {"populate_by_name": True, "extra": "forbid"}

    @staticmethod
    def _coerce_int(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            raise ValueError("boolean is not a valid integer")
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                raise PydanticUseDefault()
            return int(stripped)
        return value

    @staticmethod
    def _coerce_bool(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            stripped = value.strip().lower()
            if not stripped:
                raise PydanticUseDefault()
            if stripped in {"1", "true", "yes", "on"}:
                return True
            if stripped in {"0", "false", "no", "off"}:
                return False
            raise ValueError(f"cannot coerce {value!r} to bool")
        return value

    _coerce_int_fields = field_validator(
        "head_limit",
        "offset",
        "A",
        "B",
        "C",
        "context",
        mode="before",
    )(_coerce_int)
    _coerce_bool_fields = field_validator(
        "i",
        "n",
        "multiline",
        mode="before",
    )(_coerce_bool)


class LSInput(BaseModel):
    path: str = Field(description="Absolute or relative directory path to list. Use '.' for project root.")
    ignore: list[str] | None = Field(default=None, description="List of glob patterns to exclude, e.g. ['*.pyc', '__pycache__'].")
    head_limit: int = Field(default=_LIST_SPILL_LIMIT, ge=1, le=300, description="Maximum number of entries to return (default: 100).")
    include_hidden: bool = Field(default=False, description="If True, include hidden files and directories (names starting with '.').")
    sort_by: Literal["name", "mtime", "size"] = Field(default="name", description="Sort order: name (default, alphabetical), mtime (most recently modified first), size (largest first).")

    model_config = {"extra": "forbid"}


class WebFetchInput(BaseModel):
    url: str = Field(
        description="The URL to fetch content from",
        json_schema_extra={"format": "uri"},
    )
    prompt: str = Field(description="The prompt to run on the fetched content")

    model_config = {"extra": "forbid"}


class ExitPlanModeInput(BaseModel):
    plan_markdown: str | None = Field(
        default=None,
        description="Deprecated: plan markdown must be written to active plan file before calling ExitPlanMode.",
    )
    summary: str = Field(min_length=1, description="Short summary shown in approval UI.")
    title: str | None = Field(default=None, description="Deprecated: title is no longer used for plan filename.")
    execution_prompt: str | None = Field(
        default=None,
        description="Optional prompt to auto-run in Act Mode after approval.",
    )

    model_config = {"extra": "forbid"}


class YieldTurnInput(BaseModel):
    status: str = Field(
        min_length=1,
        description="Short machine-readable yield status, e.g. waiting_for_teammate.",
    )

    model_config = {"extra": "forbid"}


class QuestionOption(BaseModel):
    label: str = Field(max_length=50, description="Display text for this option (1-5 words)")
    description: str = Field(description="Explanation of this option")

    model_config = {"extra": "forbid"}


class Question(BaseModel):
    question: str = Field(description="The complete question to ask the user")
    header: str = Field(max_length=12, description="Short label displayed as a chip/tag (max 12 chars)")
    options: list[QuestionOption] = Field(min_length=2, max_length=4, description="Available options (2-4)")
    multiSelect: bool = Field(default=False, description="If True, user can select multiple options. Default False (single select only).")

    model_config = {"extra": "forbid"}


class AskUserQuestionInput(BaseModel):
    questions: list[Question] = Field(min_length=1, max_length=4, description="Questions to ask")

    model_config = {"extra": "forbid"}

    @model_validator(mode="before")
    @classmethod
    def _coerce_stringified_questions(cls, data: Any) -> Any:
        """Defense-in-depth: 修复 LLM 将 questions 数组字符串化的问题。"""
        if not isinstance(data, dict):
            return data
        questions = data.get("questions")
        if isinstance(questions, str):
            try:
                parsed = json.loads(questions)
                if isinstance(parsed, list):
                    data["questions"] = parsed
            except (json.JSONDecodeError, TypeError):
                pass
        return data


def _compute_context_window(params: GrepInput) -> tuple[int, int]:
    if params.context is not None:
        context = max(0, int(params.context))
        return context, context
    before = params.B or 0
    after = params.A or 0
    if params.C is not None:
        before = int(params.C)
        after = int(params.C)
    return max(0, int(before)), max(0, int(after))


def _split_glob_patterns(glob_value: str | None) -> list[str]:
    if not glob_value:
        return []
    patterns: list[str] = []
    for chunk in glob_value.split():
        patterns.extend(part for part in chunk.split(",") if part)
    return patterns


def _extract_glob_base_directory(pattern: str) -> tuple[str, str]:
    match = re.search(r"[*?[{]", pattern)
    if match is None:
        return str(Path(pattern).parent), Path(pattern).name

    static_prefix = pattern[: match.start()]
    last_sep_index = max(static_prefix.rfind("/"), static_prefix.rfind(os.sep))
    if last_sep_index == -1:
        return "", pattern

    base_dir = static_prefix[:last_sep_index]
    relative_pattern = pattern[last_sep_index + 1 :]
    if not base_dir and last_sep_index == 0:
        base_dir = os.sep
    return base_dir, relative_pattern


def _env_truthy(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _search_rg_timeout_seconds() -> float:
    raw = os.getenv("CLAUDE_CODE_GLOB_TIMEOUT_SECONDS")
    if raw is None or not raw.strip():
        return _SEARCH_RG_TIMEOUT_SECONDS
    try:
        parsed = float(raw)
    except ValueError:
        return _SEARCH_RG_TIMEOUT_SECONDS
    return parsed if parsed > 0 else _SEARCH_RG_TIMEOUT_SECONDS


def _path_looks_like_glob(path: str | None) -> bool:
    return bool(path) and any(ch in path for ch in "*?[]{}")


_IS_WINDOWS = os.name == "nt"


def _is_unc_like(user_path: str | None) -> bool:
    if not _IS_WINDOWS:
        return False
    if not user_path:
        return False
    return user_path.strip().startswith(("\\\\", "//"))


def _build_search_path_not_found_message(
    *,
    user_path: str | None,
    resolved_path: Path,
    ctx: SystemToolContext,
    tool_name: str,
) -> str:
    displayed_path = user_path or str(resolved_path)
    suggestion = suggest_path_under_roots(
        user_path=user_path or str(resolved_path),
        project_root=_project_root(ctx),
        workspace_root=_workspace_root(ctx),
        extra_read_roots=_extra_read_roots(ctx),
    )
    message = f"Search path not found: {displayed_path}."
    if suggestion:
        message += f" Did you mean {suggestion}?"
    if _path_looks_like_glob(user_path):
        if tool_name == "Grep":
            message += " path must be an existing file or directory; put wildcards in glob instead."
        elif tool_name == "Glob":
            message += " path must be an existing directory; keep wildcards in pattern instead."
        else:
            message += " path must be an existing directory; remove wildcard characters from path."
    return message


def _resolve_glob_search_target(
    *,
    params: GlobInput,
    ctx: SystemToolContext,
) -> tuple[Path, str]:
    if _is_unc_like(params.pattern):
        base_dir, relative_pattern = _extract_glob_base_directory(params.pattern)
        return Path(base_dir or os.sep), relative_pattern

    if Path(params.pattern).is_absolute():
        base_dir, relative_pattern = _extract_glob_base_directory(params.pattern)
        search_dir = resolve_for_search(
            user_path=base_dir or os.sep,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
        return search_dir, relative_pattern

    if _is_unc_like(params.path):
        return Path(str(params.path).strip()), params.pattern

    search_dir = resolve_for_search(
        user_path=params.path,
        project_root=_project_root(ctx),
        workspace_root=_workspace_root(ctx),
        extra_read_roots=_extra_read_roots(ctx),
    )
    return search_dir, params.pattern


def _glob_match_path(path: Path, *, search_root: Path, pattern: str) -> bool:
    rel = path.relative_to(search_root).as_posix()
    return globmatch(rel, pattern, flags=_GLOB_FLAGS) or globmatch(path.name, pattern, flags=_GLOB_FLAGS)


def _glob_sort_key(path: Path, *, roots: list[Path]) -> tuple[float, str]:
    try:
        mtime = path.stat().st_mtime_ns
    except OSError:
        mtime = 0
    return (mtime, to_safe_relpath(path.resolve(), roots=roots))


def _build_glob_rg_args(pattern: str) -> list[str]:
    no_ignore = _env_truthy("CLAUDE_CODE_GLOB_NO_IGNORE", default=True)
    hidden = _env_truthy("CLAUDE_CODE_GLOB_HIDDEN", default=True)
    args = [
        "rg",
        "--files",
        "--sort=modified",
        "--glob",
        pattern,
    ]
    if hidden:
        args.append("--hidden")
    if no_ignore:
        args.append("--no-ignore")
    for excluded_dir in _SEARCH_EXCLUDED_DIRS:
        args.extend(["--glob", f"!{excluded_dir}"])
    return args


def _apply_search_pagination[T](items: list[T], *, head_limit: int, offset: int) -> tuple[list[T], bool]:
    if head_limit == 0:
        return items[offset:], False
    return items[offset : offset + head_limit], len(items) > offset + head_limit


def _build_rg_base_args(params: GrepInput) -> list[str]:
    args: list[str] = ["rg", "--color=never", "--max-columns", "500", "--hidden"]
    if params.i:
        args.append("-i")
    for excluded_dir in _SEARCH_EXCLUDED_DIRS:
        args.extend(["--glob", f"!{excluded_dir}"])
    for glob_pattern in _split_glob_patterns(params.glob):
        args.extend(["--glob", glob_pattern])
    if params.type:
        args.extend(["--type", params.type])
    if params.multiline:
        args.extend(["-U", "--multiline-dotall"])
    return args


async def _run_subprocess(args: list[str], *, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return await iu.io_call(
        subprocess.run,
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=str(cwd) if cwd is not None else None,
    )


def _append_bounded_text(
    chunks: list[str],
    text: str,
    *,
    current_chars: int,
    max_chars: int,
) -> tuple[int, bool]:
    if max_chars <= 0:
        return current_chars, True
    if current_chars >= max_chars:
        return current_chars, True

    remain = max_chars - current_chars
    if len(text) <= remain:
        chunks.append(text)
        return current_chars + len(text), False

    chunks.append(text[:remain])
    return max_chars, True


@dataclass
class _StreamingSubprocessResult:
    returncode: int
    stdout_capture: str
    stderr_capture: str
    stdout_capture_truncated: bool
    stderr_capture_truncated: bool
    stopped_early: bool
    timed_out: bool


async def _run_subprocess_streaming_lines(
    args: list[str],
    *,
    cwd: Path | None = None,
    on_stdout_line: Callable[[str], bool] | None = None,
    stdout_capture_max_chars: int = _GREP_CONTENT_PARSE_MAX_CHARS,
    stderr_capture_max_chars: int = _TEXT_SPILL_CHARS,
    run_controller: Any | None = None,
    timeout_seconds: float | None = None,
) -> _StreamingSubprocessResult:
    create_kwargs: dict[str, Any] = {
        "stdout": asyncio.subprocess.PIPE,
        "stderr": asyncio.subprocess.PIPE,
        "cwd": str(cwd) if cwd is not None else None,
    }
    if os.name != "nt":
        create_kwargs["start_new_session"] = True

    proc = await asyncio.create_subprocess_exec(*args, **create_kwargs)

    assert proc.stdout is not None
    assert proc.stderr is not None

    stdout_chunks: list[str] = []
    stderr_chunks: list[str] = []
    stdout_chars = 0
    stderr_chars = 0
    stdout_capture_truncated = False
    stderr_capture_truncated = False
    stopped_early = False
    interrupted = False
    unregister_interrupt_callback: Callable[[], None] | None = None

    def _send_interrupt_signal(*, force: bool, mark_interrupted: bool) -> None:
        nonlocal interrupted
        if proc.returncode is not None:
            return

        if mark_interrupted:
            interrupted = True

        try:
            if os.name == "nt":
                if force:
                    proc.kill()
                else:
                    proc.terminate()
                return

            sig = signal.SIGKILL if force else signal.SIGTERM
            if proc.pid is not None:
                os.killpg(proc.pid, sig)
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning(f"failed to signal subprocess: {exc}", exc_info=True)

    async def _terminate_process_with_grace(*, mark_interrupted: bool) -> None:
        _send_interrupt_signal(force=False, mark_interrupted=mark_interrupted)
        if proc.returncode is not None:
            return
        try:
            await asyncio.wait_for(
                proc.wait(),
                timeout=_SUBPROCESS_INTERRUPT_GRACE_SECONDS,
            )
            return
        except asyncio.TimeoutError:
            pass

        _send_interrupt_signal(force=True, mark_interrupted=mark_interrupted)
        if proc.returncode is not None:
            return
        try:
            await asyncio.wait_for(
                proc.wait(),
                timeout=_SUBPROCESS_INTERRUPT_GRACE_SECONDS,
            )
        except asyncio.TimeoutError:
            logger.warning("subprocess did not exit after SIGKILL fallback")

    if run_controller is not None:
        def _on_interrupt(reason: str, interrupt_count: int) -> None:
            force = (
                interrupt_count >= 2
                or str(reason).strip().lower().endswith("force")
            )
            _send_interrupt_signal(force=force, mark_interrupted=True)

        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            _on_interrupt
        )
        if run_controller.is_interrupted:
            _on_interrupt(
                str(run_controller.reason or "user"),
                max(1, int(run_controller.interrupt_count)),
            )

    async def _consume_stdout() -> None:
        nonlocal stdout_chars, stdout_capture_truncated, stopped_early

        while True:
            raw = await proc.stdout.readline()
            if not raw:
                break
            text = raw.decode("utf-8", errors="replace")

            stdout_chars, clipped = _append_bounded_text(
                stdout_chunks,
                text,
                current_chars=stdout_chars,
                max_chars=stdout_capture_max_chars,
            )
            stdout_capture_truncated = stdout_capture_truncated or clipped

            if stopped_early:
                continue
            if on_stdout_line is None:
                continue

            row = text.rstrip("\n")
            should_continue = bool(on_stdout_line(row))
            if not should_continue:
                stopped_early = True
                _send_interrupt_signal(force=False, mark_interrupted=False)

    async def _consume_stderr() -> None:
        nonlocal stderr_chars, stderr_capture_truncated
        while True:
            raw = await proc.stderr.read(4096)
            if not raw:
                break
            text = raw.decode("utf-8", errors="replace")
            stderr_chars, clipped = _append_bounded_text(
                stderr_chunks,
                text,
                current_chars=stderr_chars,
                max_chars=stderr_capture_max_chars,
            )
            stderr_capture_truncated = stderr_capture_truncated or clipped

    stdout_task = asyncio.create_task(_consume_stdout())
    stderr_task = asyncio.create_task(_consume_stderr())
    wait_task = asyncio.create_task(proc.wait())
    timed_out = False

    try:
        gather_task = asyncio.gather(stdout_task, stderr_task, wait_task)
        if timeout_seconds is not None:
            await asyncio.wait_for(gather_task, timeout=timeout_seconds)
        else:
            await gather_task
        returncode = wait_task.result()
    except asyncio.TimeoutError:
        timed_out = True
        logger.warning(f"subprocess timed out after {timeout_seconds}s: {' '.join(args[:6])}")
        await _terminate_process_with_grace(mark_interrupted=False)
        await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)
        returncode = proc.returncode if proc.returncode is not None else 124
    except asyncio.CancelledError:
        await _terminate_process_with_grace(mark_interrupted=True)
        stdout_task.cancel()
        stderr_task.cancel()
        wait_task.cancel()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()

    if interrupted:
        raise asyncio.CancelledError

    return _StreamingSubprocessResult(
        returncode=int(returncode),
        stdout_capture="".join(stdout_chunks),
        stderr_capture="".join(stderr_chunks),
        stdout_capture_truncated=stdout_capture_truncated,
        stderr_capture_truncated=stderr_capture_truncated,
        stopped_early=stopped_early,
        timed_out=timed_out,
    )


_EAGAIN_OS_ERROR_CODES: tuple[str, ...] = ("os error 11", "os error 35")


def _is_eagain_error(stderr: str) -> bool:
    if "Resource temporarily unavailable" in stderr:
        return True
    return any(code in stderr for code in _EAGAIN_OS_ERROR_CODES)


async def _run_rg_streaming_lines(
    args: list[str],
    *,
    cwd: Path | None = None,
    on_stdout_line: Callable[[str], bool] | None = None,
    reset_state_on_retry: Callable[[], None] | None = None,
    stdout_capture_max_chars: int = _GREP_CONTENT_PARSE_MAX_CHARS,
    stderr_capture_max_chars: int = _TEXT_SPILL_CHARS,
    run_controller: Any | None = None,
) -> tuple[_StreamingSubprocessResult, bool]:
    timeout_seconds = _search_rg_timeout_seconds()
    stream = await _run_subprocess_streaming_lines(
        args,
        cwd=cwd,
        on_stdout_line=on_stdout_line,
        stdout_capture_max_chars=stdout_capture_max_chars,
        stderr_capture_max_chars=stderr_capture_max_chars,
        run_controller=run_controller,
        timeout_seconds=timeout_seconds,
    )
    retried_single_thread = False
    if (
        not stream.timed_out
        and stream.returncode not in {0, 1}
        and _is_eagain_error(stream.stderr_capture)
    ):
        retried_single_thread = True
        retry_args = list(args)
        retry_args[1:1] = ["-j", "1"]
        logger.warning(f"ripgrep hit EAGAIN; retrying single-threaded: {' '.join(args[:6])}")
        if reset_state_on_retry is not None:
            reset_state_on_retry()
        stream = await _run_subprocess_streaming_lines(
            retry_args,
            cwd=cwd,
            on_stdout_line=on_stdout_line,
            stdout_capture_max_chars=stdout_capture_max_chars,
            stderr_capture_max_chars=stderr_capture_max_chars,
            run_controller=run_controller,
            timeout_seconds=timeout_seconds,
        )
    return stream, retried_single_thread


def _sort_ls(entries: list[dict[str, Any]], sort_by: str) -> list[dict[str, Any]]:
    if sort_by == "mtime":
        return sorted(entries, key=lambda x: (x["mtime"], x["name"]), reverse=True)
    if sort_by == "size":
        return sorted(entries, key=lambda x: (x["size"], x["name"]), reverse=True)
    return sorted(entries, key=lambda x: x["name"])


@tool(
    "Run command. args as list: ['git', 'status'] NOT string. exit_code 0=success. Set cwd if needed. For pipes: ['sh', '-c', 'cmd1 | cmd2']",
    name="Bash",
    usage_rules=BASH_USAGE_RULES,
)
async def Bash(
    params: BashInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    start = time.monotonic()

    try:
        if params.cwd is not None:
            cwd = resolve_for_read(
                user_path=params.cwd,
                project_root=_project_root(ctx),
                workspace_root=_workspace_root(ctx),
                extra_read_roots=_extra_read_roots(ctx),
            )
            if not await _exists(cwd):
                return err("NOT_FOUND", f"cwd not found: {params.cwd}")
            if not await _is_dir(cwd):
                return err("INVALID_ARGUMENT", f"cwd is not a directory: {params.cwd}")
        else:
            cwd = _project_root(ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    validation_err = _validate_bash_command(params, cwd=cwd, ctx=ctx)
    if validation_err is not None:
        return validation_err

    env = os.environ.copy()
    # config 级环境变量（AgentOptions.env）— ctx 已通过 Depends 注入
    if ctx.config_env:
        env.update(ctx.config_env)
    # 调用级环境变量（LLM 每次调用传入）
    if params.env:
        env.update(params.env)

    timed_out = False
    interrupted = False
    stdout = ""
    stderr = ""
    exit_code = -1
    artifact: dict[str, Any] | None = None

    proc: subprocess.Popen[str] | None = None
    unregister_interrupt_callback: Callable[[], None] | None = None
    artifact_store = _artifact_store(ctx)
    output_dir = artifact_store.base_dir / "bash"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_fd, output_tmp_name = tempfile.mkstemp(
        prefix=".tmp_bash_",
        suffix=".txt",
        dir=str(output_dir),
    )
    os.close(output_fd)
    output_path = Path(output_tmp_name)
    output_file: Any | None = None

    def _send_interrupt_signal(*, force: bool, mark_interrupted: bool) -> None:
        nonlocal interrupted
        if proc is None or proc.returncode is not None:
            return

        if mark_interrupted:
            interrupted = True

        try:
            if os.name == "nt":
                if force:
                    proc.kill()
                else:
                    proc.terminate()
                return

            sig = signal.SIGKILL if force else signal.SIGTERM
            if proc.pid is not None:
                os.killpg(proc.pid, sig)
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning(f"failed to signal bash process: {exc}", exc_info=True)

    async def _terminate_process_with_grace(*, mark_interrupted: bool) -> None:
        _send_interrupt_signal(force=False, mark_interrupted=mark_interrupted)
        if proc is None or proc.returncode is not None:
            return
        try:
            await iu.io_call(proc.wait, timeout=0.8)
            return
        except subprocess.TimeoutExpired:
            pass

        _send_interrupt_signal(force=True, mark_interrupted=mark_interrupted)
        if proc is None or proc.returncode is not None:
            return
        try:
            await iu.io_call(proc.wait, timeout=0.8)
        except subprocess.TimeoutExpired:
            logger.warning("bash process did not exit after SIGKILL fallback")

    async with iu.bash_semaphore():
        try:
            create_kwargs: dict[str, Any] = {
                "cwd": str(cwd),
                "env": env,
            }
            if os.name != "nt":
                create_kwargs["start_new_session"] = True

            output_file = output_path.open("wb")
            create_kwargs["stdout"] = output_file
            create_kwargs["stderr"] = subprocess.STDOUT

            proc = subprocess.Popen(params.args, **create_kwargs)

            run_controller = getattr(ctx, "run_controller", None)
            if run_controller is not None:
                def _on_interrupt(reason: str, interrupt_count: int) -> None:
                    force = (
                        interrupt_count >= 2
                        or str(reason).strip().lower().endswith("force")
                    )
                    _send_interrupt_signal(
                        force=force,
                        mark_interrupted=True,
                    )

                unregister_interrupt_callback = run_controller.register_interrupt_callback(
                    _on_interrupt
                )
                if run_controller.is_interrupted:
                    _on_interrupt(
                        str(run_controller.reason or "user"),
                        max(1, int(run_controller.interrupt_count)),
                    )

            try:
                await iu.io_call(
                    proc.communicate,
                    timeout=params.timeout_ms / 1000.0,
                )
            except subprocess.TimeoutExpired:
                timed_out = True
                await _terminate_process_with_grace(mark_interrupted=False)
                if proc.returncode is None:
                    try:
                        await iu.io_call(
                            proc.communicate,
                            timeout=1.0,
                        )
                    except subprocess.TimeoutExpired:
                        pass
            except asyncio.CancelledError:
                await _terminate_process_with_grace(mark_interrupted=True)
                raise
            finally:
                if output_file is not None:
                    output_file.close()
                    output_file = None
                if unregister_interrupt_callback is not None:
                    unregister_interrupt_callback()
                    unregister_interrupt_callback = None

            if proc.returncode is not None:
                exit_code = int(proc.returncode)
        finally:
            if output_file is not None:
                output_file.close()
                output_file = None
            if unregister_interrupt_callback is not None:
                unregister_interrupt_callback()
                unregister_interrupt_callback = None

    duration_ms = int((time.monotonic() - start) * 1000)

    has_more_chars = False
    try:
        with output_path.open("r", encoding="utf-8", errors="replace") as f:
            preview = f.read(params.max_output_chars + 1)
        if len(preview) > params.max_output_chars:
            has_more_chars = True
            preview = preview[:params.max_output_chars]
        stdout = preview
    except FileNotFoundError:
        stdout = ""

    should_spill = has_more_chars
    truncated_reason = "output_too_large" if should_spill else None

    temp_file_consumed = False
    if should_spill:
        try:
            artifact = await artifact_store.put_file(
                namespace="bash",
                source_path=output_path,
                mime="text/plain",
                ttl_seconds=_ARTIFACT_TTL_SECONDS,
            )
            temp_file_consumed = True
        except Exception:
            relpath = os.path.relpath(str(output_path), str(_workspace_root(ctx)))
            artifact = {
                "id": f"temp:{output_path.name}",
                "relpath": relpath,
                "bytes": output_path.stat().st_size if output_path.exists() else 0,
                "sha256": "",
                "mime": "text/plain",
                "created_at": int(time.time()),
                "ttl_seconds": int(_ARTIFACT_TTL_SECONDS),
            }

    if output_path.exists() and (not should_spill or temp_file_consumed):
        try:
            output_path.unlink()
        except FileNotFoundError:
            pass

    data = {
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "interrupted": interrupted,
        "killed": timed_out or interrupted,
        "duration_ms": duration_ms,
        "truncated": bool(should_spill),
        "truncated_reason": truncated_reason,
    }
    if artifact is not None:
        data["artifact"] = artifact

    if timed_out:
        exec_meta = {
            "args": params.args,
            "cwd": str(cwd),
            "timeout_ms": params.timeout_ms,
            "max_output_chars": params.max_output_chars,
            "duration_ms": duration_ms,
        }
        return err(
            "TIMEOUT",
            f"Command timed out after {params.timeout_ms}ms",
            data=data,
            retryable=True,
            meta=exec_meta,
        )

    if interrupted:
        exec_meta = {
            "args": params.args,
            "cwd": str(cwd),
            "timeout_ms": params.timeout_ms,
            "max_output_chars": params.max_output_chars,
            "duration_ms": duration_ms,
        }
        return err(
            "INTERRUPTED",
            "Command interrupted by user",
            data=data,
            retryable=True,
            meta=exec_meta,
        )

    return ok(
        data=data,
        meta={
            "args": params.args,
            "cwd": str(cwd),
            "timeout_ms": params.timeout_ms,
            "max_output_chars": params.max_output_chars,
            "duration_ms": duration_ms,
        },
    )


@tool("Read file with line numbers. For large files: use offset_line/limit_lines to read in chunks.", name="Read", usage_rules=READ_USAGE_RULES)
async def Read(
    params: ReadInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    try:
        path = resolve_for_read(
            user_path=params.file_path,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if _is_team_inbox_json_path(path):
        return err(
            "POLICY_DENIED",
            (
                "Inbox messages are delivered automatically. "
                'If you are waiting for teammates or new inbox work, call YieldTurn(status="waiting_for_teammate") instead of reading inbox files.'
            ),
        )

    if not await _exists(path):
        similar = iu.find_similar_file(path)
        suggestion = f" Did you mean {similar}?" if similar else ""
        return err("NOT_FOUND", f"File not found: {params.file_path}.{suggestion}")
    if await _is_dir(path):
        return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
    if not await _is_file(path):
        return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
    binary_reason = await _detect_binary_read_target(path)
    if binary_reason is not None:
        return err(
            "BINARY_FILE",
            f"Read only supports text files. Refusing binary file: {params.file_path}",
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "detected_by": binary_reason,
            },
        )

    text = await _read_text(path)
    file_sha256 = iu.sha256_text(text)
    file_bytes = int((await _stat(path)).st_size)
    lines = text.splitlines()
    total_lines = len(lines)

    effective_offset_line = params.offset_line if params.offset_line > 0 else 1
    start = effective_offset_line - 1
    end = min(total_lines, start + params.limit_lines)
    sliced = lines[start:end]

    if await _has_read_range_with_version(
        ctx,
        path,
        file_sha256,
        offset_line=effective_offset_line,
        limit_lines=params.limit_lines,
        format_name=params.format,
        max_line_chars=params.max_line_chars,
    ):
        await _mark_read_with_version(ctx, path, file_sha256)
        return ok(
            data={
                "content": "",
                "total_lines": total_lines,
                "lines_returned": 0,
                "has_more": False,
                "truncated": False,
                "reused_previous_result": True,
                "reuse_message": _READ_REUSE_MESSAGE,
                "summary": {
                    "file_size_kb": round(file_bytes / 1024, 2),
                    "total_lines": total_lines,
                    "avg_line_length": int(file_bytes / max(total_lines, 1)),
                },
                "meta": {
                    "encoding": "utf-8",
                    "file_bytes": file_bytes,
                },
            },
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "offset_line": effective_offset_line,
                "limit_lines": params.limit_lines,
                "format": params.format,
                "max_line_chars": params.max_line_chars,
                "encoding": "utf-8",
                "file_bytes": file_bytes,
            },
        )

    for i, line in enumerate(sliced, start=effective_offset_line):
        line_size_bytes = len(line.encode("utf-8"))
        if line_size_bytes > _READ_HARD_LINE_LIMIT:
            kb_size = line_size_bytes / 1024
            limit_kb = _READ_HARD_LINE_LIMIT / 1024
            quoted_path = shlex.quote(str(path))
            return err(
                "OUTPUT_TOO_LARGE",
                f"Line {i} is {kb_size:.1f}KB, exceeds single-line limit ({limit_kb:.1f}KB).",
                meta={
                    "file_path": params.file_path,
                    "resolved_file_path": str(path),
                    "problem_line": i,
                    "line_size_bytes": line_size_bytes,
                    "hard_limit_bytes": _READ_HARD_LINE_LIMIT,
                    "single_line_extractable": True,
                    "extract_command": f"sed -n '{i}p' {quoted_path} | head -c {_READ_HARD_LINE_LIMIT}",
                    "total_lines": total_lines,
                    "file_bytes": file_bytes,
                },
            )

    line_truncated = False
    formatted_lines: list[str] = []
    if params.format == "line_numbers":
        for i, line in enumerate(sliced, start=effective_offset_line):
            clipped = iu.truncate_line(line, params.max_line_chars)
            if clipped != line:
                line_truncated = True
            formatted_lines.append(f"{i}\t{clipped}")
    else:
        for line in sliced:
            clipped = iu.truncate_line(line, params.max_line_chars)
            if clipped != line:
                line_truncated = True
            formatted_lines.append(clipped)
    content = "\n".join(formatted_lines)

    has_more = end < total_lines
    output_too_large = (
        len(content) > _READ_TEXT_SPILL_CHARS or len(content.encode("utf-8")) > _READ_BYTES_SPILL_LIMIT
    )

    # P1-5: Semantic summary
    avg_line_length = int(file_bytes / max(total_lines, 1))

    # P2-7: truncated_reason
    truncated_reason = None
    if line_truncated:
        truncated_reason = "line_length_exceeded"
    elif output_too_large:
        truncated_reason = "output_too_large"

    if output_too_large:
        cumulative_chars = 0
        cumulative_bytes = 0
        safe_count = 0
        for idx, formatted_line in enumerate(formatted_lines):
            sep = 1 if idx > 0 else 0
            line_chars = len(formatted_line) + sep
            line_bytes = len(formatted_line.encode("utf-8")) + sep
            if (
                cumulative_chars + line_chars > _READ_TEXT_SPILL_CHARS
                or cumulative_bytes + line_bytes > _READ_BYTES_SPILL_LIMIT
            ):
                break
            cumulative_chars += line_chars
            cumulative_bytes += line_bytes
            safe_count = idx + 1

        suggested_limit_lines: int | None = None
        suggested_max_line_chars: int | None = None
        extract_command: str | None = None
        # Lines already clipped by max_line_chars cannot be recovered by shrinking
        # limit_lines; provide a precise Bash extraction path and keep Grep as a
        # secondary locator-only suggestion.
        recommend_alternative: str | None = "bash_precise_extract" if line_truncated else None
        field_errors = [
            {
                "field": "offset_line",
                "message": f"Keep offset_line={effective_offset_line} and reduce the response size to continue reading this range.",
            }
        ]
        if safe_count > 0:
            suggested_limit_lines = max(_READ_MIN_LIMIT, safe_count)
            # Preserve the caller's max_line_chars in meta so the retry hint keeps
            # the same clipping budget the safe_count scan was measured against.
            suggested_max_line_chars = params.max_line_chars
            if recommend_alternative == "bash_precise_extract":
                start_line_no = effective_offset_line
                end_line_no = effective_offset_line + suggested_limit_lines - 1
                extract_command = (
                    f"sed -n '{start_line_no},{end_line_no}p' {shlex.quote(str(path))}"
                )
            field_errors.append(
                {
                    "field": "limit_lines",
                    "message": f"Current slice is too large; retry with limit_lines={suggested_limit_lines} or smaller.",
                }
            )
            if recommend_alternative == "bash_precise_extract":
                error_message = (
                    "Read slice exceeded the tool budget and lines in this range are already clipped "
                    f"by max_line_chars={params.max_line_chars}. Shrinking limit_lines to "
                    f"{suggested_limit_lines} will fit, but the clipped content is unrecoverable this way. "
                    "Prefer Bash `sed -n 'start,endp' file` to extract the exact lines, "
                    "and use Grep only to locate keywords or narrow the range first."
                )
            else:
                error_message = (
                    "Read slice exceeded the tool budget. "
                    f"Retry Read with the same offset_line={effective_offset_line} "
                    f"and a smaller limit_lines (for example {suggested_limit_lines}) instead of repeating the same request."
                )
        else:
            suggested_max_line_chars = max(100, params.max_line_chars // 2)
            if recommend_alternative == "bash_precise_extract":
                first_line_no = effective_offset_line
                extract_command = (
                    f"sed -n '{first_line_no}p' {shlex.quote(str(path))}"
                )
            field_errors.append(
                {
                    "field": "max_line_chars",
                    "message": (
                        "Even a single formatted line exceeds the Read budget; "
                        f"retry with max_line_chars={suggested_max_line_chars} and limit_lines=1."
                    ),
                }
            )
            if recommend_alternative == "bash_precise_extract":
                error_message = (
                    "Read slice exceeded the tool budget and every line is already clipped by "
                    f"max_line_chars={params.max_line_chars}. Shrinking further will not recover "
                    "the original line content; prefer Bash `sed -n 'Np' file` to fetch the exact line, "
                    "and use Grep only to locate keywords or narrow the range first."
                )
            else:
                error_message = (
                    "Read slice exceeded the tool budget. "
                    f"Keep offset_line={effective_offset_line}, retry with limit_lines=1, "
                    f"and reduce max_line_chars to {suggested_max_line_chars}."
                )
        return err(
            "OUTPUT_TOO_LARGE",
            error_message,
            field_errors=field_errors,
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "offset_line": effective_offset_line,
                "limit_lines": params.limit_lines,
                "suggested_offset_line": effective_offset_line,
                "suggested_limit_lines": suggested_limit_lines,
                "suggested_max_line_chars": suggested_max_line_chars,
                "recommend_alternative": recommend_alternative,
                "extract_command": extract_command,
                "format": params.format,
                "max_line_chars": params.max_line_chars,
                "encoding": "utf-8",
                "file_bytes": file_bytes,
                "truncated_reason": truncated_reason,
                "total_lines": total_lines,
            },
        )

    data: dict[str, Any] = {
        "content": content,
        "total_lines": total_lines,
        "lines_returned": len(sliced),
        "has_more": has_more,
        "truncated": bool(line_truncated or output_too_large),
        "truncated_reason": truncated_reason,
        "summary": {
            "file_size_kb": round(file_bytes / 1024, 2),
            "total_lines": total_lines,
            "avg_line_length": avg_line_length,
        },
        "meta": {
            "encoding": "utf-8",
            "file_bytes": file_bytes,
        },
    }

    if has_more:
        data["next_offset_line"] = end + 1

    await _mark_read_with_version(ctx, path, file_sha256)  # P1-6: Track version for Edit conflict detection
    await _mark_read_range_with_version(
        ctx,
        path,
        file_sha256,
        offset_line=effective_offset_line,
        limit_lines=params.limit_lines,
        format_name=params.format,
        max_line_chars=params.max_line_chars,
    )

    return ok(
        data=data,
        meta={
            "file_path": params.file_path,
            "resolved_file_path": str(path),
            "offset_line": effective_offset_line,
            "limit_lines": params.limit_lines,
            "format": params.format,
            "max_line_chars": params.max_line_chars,
            "encoding": "utf-8",
            "file_bytes": file_bytes,
        },
    )


@tool("Create file or overwrite/append. Existing files: MUST Read first. mode='append' to add, 'overwrite' to replace all.", name="Write", usage_rules=WRITE_USAGE_RULES)
async def Write(
    params: WriteInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        path = await _resolve_write_path(user_path=params.file_path, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    root_refs = _allowed_roots(ctx)
    normalized_content = _normalize_write_input_for_path(path, params.content)
    before_content: str | None = None
    memory_index_warning: str | None = None
    async with iu.file_lock(path):
        existed = await _exists(path)
        if existed and await _is_dir(path):
            return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
        if existed and not await _is_file(path):
            return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
        if existed and params.mode != "append" and not await _require_read(ctx, path):
            return err("PRECONDITION_FAILED", f"File already exists. Use Read(file_path='{params.file_path}') first, then retry Write.", meta={"file_path": params.file_path})

        if existed:
            before_content = await _read_text(path, encoding=params.encoding)

        if params.mode == "append" and before_content is not None:
            final_content = before_content + normalized_content
        elif params.mode == "append" and before_content is None:
            final_content = normalized_content
        else:
            final_content = normalized_content

        policy_error, memory_index_warning = _enforce_memory_index_policy(
            path=path,
            content=final_content,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        await _atomic_write_text(path, final_content, encoding=params.encoding)

    final_bytes = len(final_content.encode(params.encoding, errors="replace"))
    op_bytes = len(normalized_content.encode(params.encoding, errors="replace"))
    op_lines = len(normalized_content.rstrip("\n").split("\n")) if normalized_content else 0
    relpath = to_safe_relpath(path, roots=root_refs)
    sha256_before = iu.sha256_text(before_content) if before_content is not None else None
    sha256_after = iu.sha256_text(final_content)
    operation = "create" if not existed else ("append" if params.mode == "append" else "overwrite")
    return ok(
        data={
            "bytes_written": op_bytes,
            "lines_written": op_lines,
            "file_bytes": final_bytes,
            "created": not existed,
            "sha256": sha256_after,
            "relpath": relpath,
        },
        meta={
            "file_path": params.file_path,
            "resolved_file_path": str(path),
            "operation": operation,
            "sha256_before": sha256_before,
            "sha256_after": sha256_after,
            "encoding": params.encoding,
            "mode": params.mode,
            "memory_index_guard_warning": memory_index_warning,
        },
    )



def _line_range_from_span(content: str, start: int, end: int) -> tuple[int, int]:
    """Find 1-based start and end line numbers of a span in content."""
    if start < 0 or end < start:
        return (0, 0)
    start_line = content[:start].count("\n") + 1
    end_line = start_line + content[start:end].count("\n")
    return (start_line, end_line)


@tool("Performs exact string replacement in a file.", name="Edit", usage_rules=EDIT_USAGE_RULES)
async def Edit(
    params: EditInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        path = await _resolve_write_path(user_path=params.file_path, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    actual_new_string = _normalize_write_input_for_path(path, params.new_string)
    if params.old_string == actual_new_string:
        return _invalid_argument("new_string must differ from old_string", field="new_string")

    try:
        file_size = int((await _stat(path)).st_size)
        if file_size > _MAX_EDIT_FILE_SIZE:
            return err(
                "FILE_TOO_LARGE",
                (
                    f"File is too large to edit ({iu.format_file_size(file_size)}). "
                    f"Maximum editable file size is {iu.format_file_size(_MAX_EDIT_FILE_SIZE)}."
                ),
            )
    except FileNotFoundError:
        pass

    root_refs = _allowed_roots(ctx)
    memory_index_warning: str | None = None
    async with iu.file_lock(path):
        exists = await _exists(path)
        created = False
        if not exists:
            if params.old_string != "":
                similar = iu.find_similar_file(path)
                suggestion = f" Did you mean {similar}?" if similar else ""
                message = (
                    f"File not found: {params.file_path}.{suggestion} "
                    "To create a new file with Edit, set old_string to ''."
                ) if suggestion else (
                    f"File not found: {params.file_path}. "
                    "To create a new file with Edit, set old_string to ''."
                )
                return err(
                    "NOT_FOUND",
                    message,
                )
            before = ""
            current_sha256 = None
            after = actual_new_string
            replacements = 1
            created = True
            line_count = iu.count_text_lines(after)
            start_line = 1 if line_count > 0 else 0
            end_line = line_count if line_count > 0 else 0
        else:
            if await _is_dir(path):
                return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
            if not await _is_file(path):
                return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
            if not await _require_read(ctx, path):
                return err("PRECONDITION_FAILED", f"Must Read file before modifying it: {params.file_path}")

            before = await _read_text(path)

            current_sha256 = iu.sha256_text(before)
            if await _check_version_conflict(ctx, path, current_sha256):
                return err(
                    "CONFLICT",
                    f"File has been modified externally since last Read. Re-read the file before editing: {params.file_path}",
                    meta={"conflict_type": "external_modification", "file_path": params.file_path},
                )

            if params.old_string == "":
                if before != "":
                    return err(
                        "CONFLICT",
                        (
                            "old_string='' is only allowed when creating a new file or filling an existing empty file: "
                            f"{params.file_path}"
                        ),
                    )
                after = actual_new_string
                replacements = 1
                line_count = iu.count_text_lines(after)
                start_line = 1 if line_count > 0 else 0
                end_line = line_count if line_count > 0 else 0
            else:
                matches = iu.find_edit_matches(before, params.old_string)
                count = len(matches)
                if count == 0:
                    preview = iu.truncate_line(params.old_string, 120)
                    return err(
                        "CONFLICT",
                        f"old_string not found in file: {params.file_path}. Search text: {preview}",
                    )

                if not params.replace_all and count > 1:
                    return err(
                        "CONFLICT",
                        f"old_string appears {count} times; provide a more specific old_string or set replace_all=true",
                    )

                start_line, end_line = _line_range_from_span(before, matches[0][0], matches[0][1])
                after = iu.apply_edit_matches(
                    before,
                    old_string=params.old_string,
                    new_string=actual_new_string,
                    matches=matches,
                    replace_all=params.replace_all,
                )
                replacements = count if params.replace_all else 1

        policy_error, memory_index_warning = _enforce_memory_index_policy(
            path=path,
            content=after,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        await _atomic_write_text(path, after)

    before_sha = current_sha256
    after_sha = iu.sha256_text(after)

    await _mark_read_with_version(ctx, path, after_sha)
    relpath = to_safe_relpath(path, roots=root_refs)
    diff_lines = iu.generate_unified_diff(
        before, after, fromfile=params.file_path, tofile=params.file_path
    )
    return ok(
        data={
            "replacements": replacements,
            "created": created,
            "before_sha256": before_sha,
            "after_sha256": after_sha,
            "relpath": relpath,
            "diff": diff_lines,
            "start_line": start_line,
            "end_line": end_line,
        },
        meta={
            "file_path": params.file_path,
            "operation": "replace",
            "created": created,
            "replace_all": params.replace_all,
            "replacements": replacements,
            "sha256_before": before_sha,
            "sha256_after": after_sha,
            "memory_index_guard_warning": memory_index_warning,
        },
    )


@tool(
    r"""- Fast file pattern matching tool that works with any codebase size
- Supports glob patterns like "**/*.js" or "src/**/*.ts"
- Returns matching file paths sorted by modification time
- Use this tool when you need to find files by name patterns
- When you are doing an open ended search that may require multiple rounds of globbing and grepping, use the Agent tool instead""",
    name="Glob",
    usage_rules=GLOB_USAGE_RULES,
)
async def Glob(
    params: GlobInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        search_dir, search_pattern = _resolve_glob_search_target(params=params, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not _is_unc_like(str(search_dir)) and not await _exists(search_dir):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=search_dir,
                ctx=ctx,
                tool_name="Glob",
            ),
        )

    run_controller = getattr(ctx, "run_controller", None)
    stop_event = threading.Event()
    unregister_interrupt_callback: Callable[[], None] | None = None
    if run_controller is not None:
        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            lambda _reason, _count: stop_event.set()
        )
        if run_controller.is_interrupted:
            stop_event.set()

    root_refs = _allowed_roots(ctx)
    rg_path = shutil.which("rg")
    timeout_seconds = _search_rg_timeout_seconds()

    try:
        if search_dir.is_file():
            candidates = [search_dir] if _glob_match_path(search_dir, search_root=search_dir.parent, pattern=search_pattern) else []
            candidates = sorted(candidates, key=lambda item: _glob_sort_key(item, roots=root_refs))
            matches = [to_safe_relpath(p.resolve(), roots=root_refs) for p in candidates]
        elif rg_path:
            cmd = _build_glob_rg_args(search_pattern) + ["."]
            rel_files: list[str] = []
            total = 0
            lower_bound = False

            def _on_file_line(raw_line: str) -> bool:
                nonlocal total, lower_bound
                line = raw_line.strip()
                if not line:
                    return True
                total += 1
                if total <= _GLOB_DEFAULT_HEAD_LIMIT:
                    normalized = line[2:] if line.startswith("./") else line
                    rel_files.append(
                        to_safe_relpath((search_dir / normalized).resolve(), roots=root_refs)
                    )
                if total >= _GLOB_DEFAULT_HEAD_LIMIT + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_stream_state() -> None:
                nonlocal total, lower_bound
                rel_files.clear()
                total = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                cwd=search_dir,
                on_stdout_line=_on_file_line,
                reset_state_on_retry=_reset_stream_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and total == 0:
                return err(
                    "TIMEOUT",
                    f"Glob timed out after {timeout_seconds:.0f}s",
                    meta={
                        "engine": "rg",
                        "pattern": params.pattern,
                        "path": params.path,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
                        "count_is_lower_bound": False,
                        "timed_out": True,
                        "retried_single_thread": retried_single_thread,
                        "timeout_seconds": timeout_seconds,
                    },
                )
            if stream.returncode == 1 and total == 0:
                return ok(
                    data={
                        "matches": [],
                        "count": 0,
                        "count_is_lower_bound": False,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "truncated": False,
                        "truncated_reason": None,
                        "summary": {"total_files": 0, "file_extensions": {}},
                    },
                    meta={
                        "engine": "rg",
                        "pattern": params.pattern,
                        "path": params.path,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
                        "count_is_lower_bound": False,
                        "timed_out": False,
                        "retried_single_thread": retried_single_thread,
                        "timeout_seconds": timeout_seconds,
                    },
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Glob timed out with partial results after {timeout_seconds:.0f}s")
            count_is_lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            total_count = total
            matches = rel_files
            glob_meta = {
                "engine": "rg",
                "timed_out": stream.timed_out,
                "retried_single_thread": retried_single_thread,
                "timeout_seconds": timeout_seconds,
            }
        else:
            return err("RIPGREP_MISSING", _RIPGREP_MISSING_MESSAGE)
    except asyncio.CancelledError:
        stop_event.set()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()

    if stop_event.is_set():
        raise asyncio.CancelledError

    if search_dir.is_file():
        total_count = len(matches)
        count_is_lower_bound = False
        glob_meta = {
            "engine": "python",
            "timed_out": False,
            "retried_single_thread": False,
            "timeout_seconds": None,
        }

    preview = matches[: _GLOB_DEFAULT_HEAD_LIMIT]
    truncated = count_is_lower_bound or total_count > len(preview)

    # P1-5: Semantic summary
    file_extensions: dict[str, int] = {}
    for m in preview:
        ext = Path(m).suffix or "(no extension)"
        file_extensions[ext] = file_extensions.get(ext, 0) + 1

    data: dict[str, Any] = {
        "matches": preview,
        "count": total_count,
        "count_is_lower_bound": count_is_lower_bound,
        "search_path": to_safe_relpath(search_dir, roots=root_refs),
        "truncated": truncated,
        "truncated_reason": "timeout" if glob_meta["timed_out"] else ("head_limit_reached" if truncated else None),
        "summary": {
            "total_files": total_count,
            "file_extensions": dict(sorted(file_extensions.items(), key=lambda x: x[1], reverse=True)[:10]),
        },
    }

    return ok(
        data=data,
        meta={
            "pattern": params.pattern,
            "path": params.path,
            "search_path": data["search_path"],
            "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
            "count_is_lower_bound": count_is_lower_bound,
            **glob_meta,
        },
    )


@tool(
    r"""A powerful search tool built on ripgrep

  Usage:
  - ALWAYS use Grep for search tasks. NEVER invoke `grep` or `rg` as a Bash command. The Grep tool has been optimized for correct permissions and access.
  - Supports full regex syntax (e.g., "log.*Error", "function\s+\w+")
  - Filter files with glob parameter (e.g., "*.js", "**/*.tsx") or type parameter (e.g., "js", "py", "rust")
  - Output modes: "content" shows matching lines, "files_with_matches" shows only file paths (default), "count" shows match counts
  - Use Agent tool for open-ended searches requiring multiple rounds
  - Pattern syntax: Uses ripgrep (not grep) - literal braces need escaping (use `interface\{\}` to find `interface{}` in Go code)
  - Multiline matching: By default patterns match within single lines only. For cross-line patterns like `struct \{[\s\S]*?field`, use `multiline: true`""",
    name="Grep",
    usage_rules=GREP_USAGE_RULES,
)
async def Grep(
    params: GrepInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    try:
        if _is_unc_like(params.path):
            search_path = Path(str(params.path).strip())
        else:
            search_path = resolve_for_search(
                user_path=params.path,
                project_root=_project_root(ctx),
                extra_read_roots=_extra_read_roots(ctx),
                workspace_root=_workspace_root(ctx),
            )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not _is_unc_like(str(search_path)) and not await _exists(search_path):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=search_path,
                ctx=ctx,
                tool_name="Grep",
            ),
        )

    run_controller = getattr(ctx, "run_controller", None)
    stop_event = threading.Event()
    unregister_interrupt_callback: Callable[[], None] | None = None
    if run_controller is not None:
        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            lambda _reason, _count: stop_event.set()
        )
        if run_controller.is_interrupted:
            stop_event.set()

    rg_path = shutil.which("rg")
    if not rg_path:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()
        return err("RIPGREP_MISSING", _RIPGREP_MISSING_MESSAGE)

    root_refs = _allowed_roots(ctx)
    search_path_rel = to_safe_relpath(search_path.resolve(), roots=root_refs)
    timeout_seconds = _search_rg_timeout_seconds()

    def _grep_meta(**extra: Any) -> dict[str, Any]:
        meta = {
            "engine": "rg",
            "pattern": params.pattern,
            "path": params.path,
            "search_path": search_path_rel,
            "glob": params.glob,
            "type": params.type,
            "output_mode": params.output_mode,
            "head_limit": params.head_limit,
            "offset": params.offset,
            "context": params.context,
            "multiline": params.multiline,
            "timed_out": False,
            "retried_single_thread": False,
            "timeout_seconds": timeout_seconds,
        }
        meta.update(extra)
        return meta

    try:
        if params.output_mode == "files_with_matches":
            cmd = _build_rg_base_args(params) + [
                "--sortr=modified",
                "-l",
                "--max-count",
                "1",
                *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
                str(search_path),
            ]
            rel_files: list[str] = []
            total = 0
            lower_bound = False

            def _on_file_line(raw_line: str) -> bool:
                nonlocal total, lower_bound
                line = raw_line.strip()
                if not line:
                    return True
                total += 1
                if total > params.offset and (params.head_limit == 0 or len(rel_files) < params.head_limit):
                    rel_files.append(
                        to_safe_relpath(Path(line).resolve(), roots=root_refs)
                    )
                if params.head_limit > 0 and total >= params.offset + params.head_limit + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_stream_state() -> None:
                nonlocal total, lower_bound
                rel_files.clear()
                total = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                on_stdout_line=_on_file_line,
                reset_state_on_retry=_reset_stream_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and total == 0:
                return err(
                    "TIMEOUT",
                    f"Grep timed out after {timeout_seconds:.0f}s",
                    meta=_grep_meta(
                        timed_out=True,
                        retried_single_thread=retried_single_thread,
                    ),
                )
            if stream.returncode == 1 and total == 0:
                return ok(
                    data={
                        "files": [],
                        "count": 0,
                        "truncated": False,
                        "total_matches_is_lower_bound": False,
                    },
                    meta=_grep_meta(retried_single_thread=retried_single_thread),
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Grep files_with_matches timed out with partial results after {timeout_seconds:.0f}s")
            lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            preview = rel_files
            return ok(
                data={
                    "files": preview,
                    "count": total,
                    "truncated": lower_bound or total > len(preview),
                    "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if lower_bound else None),
                    "total_matches_is_lower_bound": lower_bound,
                },
                meta=_grep_meta(
                    timed_out=stream.timed_out,
                    retried_single_thread=retried_single_thread,
                ),
            )

        if params.output_mode == "count":
            cmd = _build_rg_base_args(params) + [
                "-c",
                *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
                str(search_path),
            ]
            counts: list[dict[str, Any]] = []
            total_matches = 0
            file_count = 0
            lower_bound = False

            def _on_count_line(raw_line: str) -> bool:
                nonlocal total_matches, file_count, lower_bound
                row = raw_line.strip()
                if not row:
                    return True
                try:
                    file_part, count_part = row.rsplit(":", 1)
                    count_value = int(count_part)
                except Exception:
                    return True
                file_count += 1
                total_matches += count_value
                if file_count > params.offset and (params.head_limit == 0 or len(counts) < params.head_limit):
                    counts.append(
                        {
                            "file": to_safe_relpath(Path(file_part).resolve(), roots=root_refs),
                            "count": count_value,
                        }
                    )
                if params.head_limit > 0 and file_count >= params.offset + params.head_limit + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_count_state() -> None:
                nonlocal total_matches, file_count, lower_bound
                counts.clear()
                total_matches = 0
                file_count = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                on_stdout_line=_on_count_line,
                reset_state_on_retry=_reset_count_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and file_count == 0:
                return err(
                    "TIMEOUT",
                    f"Grep timed out after {timeout_seconds:.0f}s",
                    meta=_grep_meta(
                        timed_out=True,
                        retried_single_thread=retried_single_thread,
                    ),
                )
            if stream.returncode == 1 and file_count == 0:
                return ok(
                    data={
                        "counts": [],
                        "total_matches": 0,
                        "truncated": False,
                        "total_matches_is_lower_bound": False,
                    },
                    meta=_grep_meta(retried_single_thread=retried_single_thread),
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Grep count timed out with partial results after {timeout_seconds:.0f}s")
            lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            preview = counts
            return ok(
                data={
                    "counts": preview,
                    "total_matches": total_matches,
                    "truncated": lower_bound or file_count > len(preview),
                    "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if lower_bound else None),
                    "total_matches_is_lower_bound": lower_bound,
                },
                meta=_grep_meta(
                    timed_out=stream.timed_out,
                    retried_single_thread=retried_single_thread,
                ),
            )

        before, after = _compute_context_window(params)
        per_file_limit = _GREP_CONTENT_PER_FILE_MAX_COUNT
        if params.head_limit > 0:
            per_file_limit = min(
                _GREP_CONTENT_PER_FILE_MAX_COUNT,
                max(1, params.offset + params.head_limit + 1),
            )
        per_file_max_count = min(
            _GREP_CONTENT_PER_FILE_MAX_COUNT,
            per_file_limit,
        )
        content_match_limit = _GREP_CONTENT_MATCH_EVENT_LIMIT
        if params.head_limit > 0:
            content_match_limit = min(
                _GREP_CONTENT_MATCH_EVENT_LIMIT,
                params.offset + params.head_limit + 1,
            )
        cmd = _build_rg_base_args(params) + [
            "--json",
            "--max-count",
            str(per_file_max_count),
            *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
            str(search_path),
        ]
        matches: list[dict[str, Any]] = []
        line_refs: list[tuple[str, int]] = []
        total_matches = 0
        lower_bound = False

        def _on_rg_json_line(raw_line: str) -> bool:
            nonlocal total_matches, lower_bound
            row = raw_line.strip()
            if not row:
                return True

            try:
                evt = json.loads(row)
            except json.JSONDecodeError:
                return True
            if evt.get("type") != "match":
                return True

            data = evt.get("data", {})
            path_text = ((data.get("path") or {}).get("text") or "").strip()
            line_no = data.get("line_number")
            line_text = ((data.get("lines") or {}).get("text") or "").rstrip("\n")

            total_matches += 1
            if total_matches >= content_match_limit:
                lower_bound = True
                return False
            if total_matches <= params.offset:
                return True
            if params.head_limit > 0 and len(matches) >= params.head_limit:
                return True

            abs_path = str(Path(path_text).resolve()) if path_text else ""
            rel_file = to_safe_relpath(Path(abs_path), roots=root_refs) if abs_path else ""
            ln = int(line_no) if line_no is not None else 0

            matches.append(
                {
                    "file": rel_file,
                    "line_number": ln if params.n and line_no is not None else None,
                    "line": iu.truncate_line(line_text, _LINE_TRUNCATE_CHARS),
                    "before_context": None,
                    "after_context": None,
                }
            )
            line_refs.append((abs_path, ln))
            return True

        def _reset_content_state() -> None:
            nonlocal total_matches, lower_bound
            matches.clear()
            line_refs.clear()
            total_matches = 0
            lower_bound = False

        stream, retried_single_thread = await _run_rg_streaming_lines(
            cmd,
            on_stdout_line=_on_rg_json_line,
            reset_state_on_retry=_reset_content_state,
            stdout_capture_max_chars=_GREP_CONTENT_PARSE_MAX_CHARS,
            stderr_capture_max_chars=_TEXT_SPILL_CHARS,
            run_controller=run_controller,
        )

        if stream.returncode == 2:
            return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
        if stream.timed_out and total_matches == 0:
            return err(
                "TIMEOUT",
                f"Grep timed out after {timeout_seconds:.0f}s",
                meta=_grep_meta(
                    timed_out=True,
                    retried_single_thread=retried_single_thread,
                ),
            )
        if stream.returncode == 1 and total_matches == 0:
            return ok(
                data={"matches": [], "total_matches": 0, "truncated": False},
                meta=_grep_meta(retried_single_thread=retried_single_thread),
            )
        if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
            return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

        if stream.timed_out:
            logger.warning(f"Grep content timed out with partial results after {timeout_seconds:.0f}s")
        if stream.stopped_early or stream.timed_out:
            lower_bound = True

        if (before > 0 or after > 0) and matches:
            by_file: dict[str, list[tuple[int, int]]] = defaultdict(list)
            for idx, (abs_path, line_no) in enumerate(line_refs):
                if not abs_path or line_no <= 0:
                    continue
                by_file[abs_path].append((idx, line_no))

            for abs_path, refs in by_file.items():
                try:
                    file_lines = await _read_text(Path(abs_path))
                except Exception:
                    continue
                lines = file_lines.splitlines()
                total_lines = len(lines)
                for idx, line_no in refs:
                    ln0 = line_no - 1
                    b0 = max(0, ln0 - before)
                    a1 = min(total_lines, ln0 + 1 + after)
                    matches[idx]["before_context"] = [iu.truncate_line(s, _LINE_TRUNCATE_CHARS) for s in lines[b0:ln0]]
                    matches[idx]["after_context"] = [iu.truncate_line(s, _LINE_TRUNCATE_CHARS) for s in lines[ln0 + 1 : a1]]

        matches_by_file: dict[str, dict[str, Any]] = {}
        for match in matches:
            file = match["file"]
            if file not in matches_by_file:
                matches_by_file[file] = {
                    "file": file,
                    "match_count": 0,
                    "matches": [],
                }
            match_entry = {k: v for k, v in match.items() if k != "file"}
            matches_by_file[file]["matches"].append(match_entry)
            matches_by_file[file]["match_count"] += 1

        truncated = total_matches > len(matches) or lower_bound
        avg_matches_per_file = total_matches / max(len(matches_by_file), 1)
        top_files = sorted(
            [(file, data["match_count"]) for file, data in matches_by_file.items()],
            key=lambda x: x[1],
            reverse=True,
        )[:5]

        data = {
            "matches_by_file": matches_by_file,
            "total_matches": total_matches,
            "file_count": len(matches_by_file),
            "truncated": truncated,
            "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if truncated else None),
            "total_matches_is_lower_bound": lower_bound,
            "summary": {
                "files_with_matches": len(matches_by_file),
                "avg_matches_per_file": round(avg_matches_per_file, 1),
                "top_files": top_files,
            },
        }

        raw_capture = stream.stdout_capture
        if truncated or stream.stdout_capture_truncated or len(raw_capture.encode("utf-8")) > _BYTES_SPILL_LIMIT:
            artifact = await iu.spill_text(
                artifact_store=_artifact_store(ctx),
                namespace="grep_content",
                text=raw_capture,
                mime="text/plain",
                ttl_seconds=_ARTIFACT_TTL_SECONDS,
            )
            data["artifact"] = artifact
            if stream.stdout_capture_truncated:
                data["raw_output_truncated"] = True

        return ok(
            data=data,
            meta=_grep_meta(
                timed_out=stream.timed_out,
                retried_single_thread=retried_single_thread,
            ),
        )
    except asyncio.CancelledError:
        stop_event.set()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()


@tool("List directory contents (like 'ls'). Use Glob for finding files by pattern.", name="LS", usage_rules=LS_USAGE_RULES)
async def LS(
    params: LSInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        p = resolve_for_search(
            user_path=params.path,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not await _exists(p):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=p,
                ctx=ctx,
                tool_name="LS",
            ).replace("Search path", "Path"),
        )
    if not await _is_dir(p):
        return err("INVALID_ARGUMENT", f"Path is not a directory: {params.path}")

    ignore = params.ignore or []

    def _collect_entries(path: Path) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for child in path.iterdir():
            name = child.name
            if not params.include_hidden and name.startswith("."):
                continue
            if any(fnmatch(name, pat) for pat in ignore):
                continue

            item_type = "dir" if child.is_dir() else "file" if child.is_file() else "other"
            try:
                st = child.stat()
                size = int(st.st_size) if child.is_file() else 0
                mtime = int(st.st_mtime)
            except Exception:
                size = 0
                mtime = 0

            rows.append({
                "name": name,
                "type": item_type,
                "size": size,
                "mtime": mtime,
            })
        return rows

    entries = await iu.io_call(_collect_entries, p)
    entries = _sort_ls(entries, params.sort_by)

    total = len(entries)
    preview = entries[: params.head_limit]

    # P1-5: Semantic summary
    dir_count = sum(1 for e in entries if e["type"] == "dir")
    file_count = sum(1 for e in entries if e["type"] == "file")
    total_size = sum(e["size"] for e in entries)

    data: dict[str, Any] = {
        "entries": preview,
        "count": total,
        "truncated": total > len(preview),
        "truncated_reason": "head_limit_reached" if total > len(preview) else None,
        "path": to_safe_relpath(p, roots=_allowed_roots(ctx)),
        "summary": {
            "dir_count": dir_count,
            "file_count": file_count,
            "total_size": iu.format_file_size(total_size),
        },
    }

    if total > len(preview):
        artifact = await iu.spill_json(
            artifact_store=_artifact_store(ctx),
            namespace="ls",
            data={"entries": entries, "count": total},
            ttl_seconds=_ARTIFACT_TTL_SECONDS,
        )
        data["artifact"] = artifact

    return ok(
        data=data,
        meta={
            "path": params.path,
            "resolved_path": data["path"],
            "ignore": ignore,
            "head_limit": params.head_limit,
            "include_hidden": params.include_hidden,
            "sort_by": params.sort_by,
        },
    )


@tool("Fetch webpage → markdown → LLM summary. Returns summary + full markdown artifact. Cached 15min. Prefer MCP-provided web fetch(or scrape) tools (named like \"mcp__*\") if available.", name="WebFetch", usage_rules=WEBFETCH_USAGE_RULES)
async def WebFetch(
    params: WebFetchInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    url = params.url.strip()
    prompt = params.prompt

    if not url:
        return _invalid_argument("url cannot be empty", field="url")
    if url.startswith("http://"):
        url = f"https://{url[7:]}"

    now = time.time()
    iu.cleanup_ttl_cache(_WEBFETCH_CACHE, now=now, ttl=_WEBFETCH_CACHE_TTL_SECONDS)

    cached = _WEBFETCH_CACHE.get(url)
    if cached and (now - float(cached.get("ts", 0.0)) <= _WEBFETCH_CACHE_TTL_SECONDS):
        markdown = str(cached.get("markdown", ""))
        final_url = str(cached.get("final_url", url))
        status = int(cached.get("status", 200))
        markdown_tokens = cached.get("markdown_tokens")
        content_signal = cached.get("content_signal")
        cached_hit = True
    else:
        cached_hit = False
        markdown_tokens = None
        content_signal = None
        try:
            from curl_cffi import requests as crequests
        except Exception as exc:
            return err("TOOL_NOT_AVAILABLE", f"WebFetch missing dependency curl_cffi: {exc}")

        # 1. 优先请求 Markdown (Cloudflare Markdown for Agents)
        try:
            response = await iu.io_call(
                crequests.get,
                url,
                timeout=_WEBFETCH_TIMEOUT_SECONDS,
                impersonate="chrome",
                headers={"Accept": "text/markdown, text/html"},
            )
        except Exception as exc:
            return err("INTERNAL", f"WebFetch request failed: {exc}", retryable=True)

        # 尝试获取 headers，支持 dict 或 SimpleNamespace
        def _get_header(resp, key):
            headers = getattr(resp, "headers", None)
            if headers is None:
                return None
            if isinstance(headers, dict):
                return headers.get(key)
            # SimpleNamespace 等对象
            return getattr(headers, key, None)

        status = int(getattr(response, "status_code", 0) or 0)
        final_url = str(getattr(response, "url", "") or url)
        markdown_tokens = _get_header(response, "x-markdown-tokens")
        content_signal = _get_header(response, "content-signal")

        if status != 200:
            # Markdown 请求失败，尝试普通 HTML 请求
            try:
                response = await iu.io_call(
                    crequests.get,
                    url,
                    timeout=_WEBFETCH_TIMEOUT_SECONDS,
                    impersonate="chrome",
                )
            except Exception as exc:
                return err("INTERNAL", f"WebFetch request failed: {exc}", retryable=True)

            status = int(getattr(response, "status_code", 0) or 0)
            final_url = str(getattr(response, "url", "") or url)
            html_text = str(getattr(response, "text", "") or "")
            markdown_tokens = None
            content_signal = None

            if status != 200:
                preview = iu.truncate_text(html_text, 2000)
                code = "NOT_FOUND" if status == 404 else "INTERNAL"
                return err(
                    code,
                    f"HTTP {status} fetching {final_url}",
                    meta={"status": status, "preview": preview},
                )

            try:
                from markdownify import markdownify as to_markdown
            except Exception as exc:
                return err("TOOL_NOT_AVAILABLE", f"WebFetch missing dependency markdownify: {exc}")

            markdown = await iu.io_call(to_markdown, html_text)
        else:
            # Markdown 请求成功
            markdown = str(getattr(response, "text", "") or "")

        # P2-9: Cache fingerprint
        content_sha256 = iu.sha256_text(markdown)
        _WEBFETCH_CACHE[url] = {
            "ts": now,
            "markdown": markdown,
            "final_url": final_url,
            "status": status,
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
            "content_sha256": content_sha256,
            "fetch_time": int(now),
        }

    artifact = await iu.spill_text(
        artifact_store=_artifact_store(ctx),
        namespace="webfetch",
        text=markdown,
        mime="text/markdown",
        ttl_seconds=_ARTIFACT_TTL_SECONDS,
    )

    if ctx.llm_levels is None or "LOW" not in ctx.llm_levels:
        return err("TOOL_NOT_AVAILABLE", "WebFetch requires llm_levels['LOW']")

    markdown_for_llm = markdown
    truncated_for_llm = False
    if len(markdown_for_llm) > _WEBFETCH_MARKDOWN_TRUNCATE_CHARS:
        markdown_for_llm = markdown_for_llm[:_WEBFETCH_MARKDOWN_TRUNCATE_CHARS]
        truncated_for_llm = True

    llm = ctx.llm_levels["LOW"]
    try:
        completion = await asyncio.wait_for(
            llm.ainvoke(
                messages=[
                    UserMessage(
                        content=(
                            f"{prompt}\n\n<url>{final_url}</url>\n\n"
                            f"<content>\n{markdown_for_llm}\n</content>"
                        )
                    )
                ],
                tools=None,
                tool_choice=None,
            ),
            timeout=_WEBFETCH_LLM_TIMEOUT_SECONDS,
        )
    except asyncio.TimeoutError:
        return err(
            "TIMEOUT",
            f"WebFetch LLM timeout after {_WEBFETCH_LLM_TIMEOUT_SECONDS}s",
            retryable=True,
        )
    except Exception as exc:
        logger.error(f"WebFetch LLM call failed: {exc}", exc_info=True)
        return err("INTERNAL", f"WebFetch LLM call failed: {exc}", retryable=True)

    if completion.usage and ctx.token_cost is not None:
        source = "webfetch"
        if ctx.subagent_source_prefix:
            source = f"{ctx.subagent_source_prefix}:webfetch"
        elif ctx.subagent_name:
            source = f"subagent:{ctx.subagent_name}:webfetch"
        ctx.token_cost.add_usage(
            str(llm.model),
            completion.usage,
            level="LOW",
            source=source,
        )

    # P2-9: Expose cache fingerprint to agent
    cache_sha256 = cached.get("content_sha256", "") if cached_hit else content_sha256
    cache_fetch_time = cached.get("fetch_time") if cached_hit else int(now)

    return ok(
        data={
            "final_url": final_url,
            "status": status,
            "cached": cached_hit,
            "cache_fingerprint": cache_sha256[:16] if cache_sha256 else "",
            "fetch_time": cache_fetch_time,
            "artifact": artifact,
            "truncated_for_llm": truncated_for_llm,
            "summary_text": completion.text,
            "model_used": str(llm.model),
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
        },
        meta={
            "url": url,
            "prompt_length": len(prompt),
            "final_url": final_url,
            "status": status,
            "cached": cached_hit,
            "truncated_for_llm": truncated_for_llm,
            "model_used": str(llm.model),
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
        },
    )


@tool(
    "Yield control back to the runtime and end the current turn deterministically.",
    name="YieldTurn",
    usage_rules=YIELD_TURN_USAGE_RULES,
)
async def YieldTurn(
    params: YieldTurnInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    del ctx
    try:
        normalized_status = str(params.status or "").strip()
        logger.info(f"YieldTurn requested with status={normalized_status!r}")
        return ok(
            data={
                "status": "yielded",
                "yield_status": normalized_status,
            },
            message=f"Yielded turn with status={normalized_status}",
            meta={
                "status": "yielded",
                "yield_status": normalized_status,
            },
        )
    except Exception as exc:
        logger.error(f"YieldTurn failed: {exc}", exc_info=True)
        return err("INTERNAL", f"YieldTurn failed: {exc}")


@tool(
    "Use this tool ONLY during active task execution when you need structured input (requirements, choices, clarification). Never use for: greetings, casual chat, or when no task has been assigned. If uncertain, respond conversationally instead. Hard rule: AskUserQuestion must be called alone (no other tool calls in the same response). Tool result means waiting for user input; user answers come in the next user message.",
    name="AskUserQuestion",
    usage_rules=ASK_USER_QUESTION_USAGE_RULES,
    input_examples=[
        {"questions": [{"question": "Which database do you prefer?", "header": "Database", "options": [{"label": "PostgreSQL (Recommended)", "description": "Mature relational DB"}, {"label": "SQLite", "description": "Lightweight embedded DB"}], "multiSelect": False}]},
        {"questions": [{"question": "Which features should I include?", "header": "Features", "options": [{"label": "Auth", "description": "User authentication"}, {"label": "Logging", "description": "Request logging"}, {"label": "Rate limiting", "description": "API rate limits"}], "multiSelect": True}]},
        {"questions": [{"question": "Which framework?", "header": "Framework", "options": [{"label": "FastAPI", "description": "Async Python framework"}, {"label": "Flask", "description": "Lightweight framework"}], "multiSelect": False}, {"question": "Need tests?", "header": "Testing", "options": [{"label": "Yes", "description": "Include unit tests"}, {"label": "No", "description": "Skip tests"}], "multiSelect": False}]},
    ],
)
async def AskUserQuestion(
    params: AskUserQuestionInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        questions_data = [q.model_dump(mode="json") for q in params.questions]
        logger.info(f"AskUserQuestion prepared {len(questions_data)} question(s)")
        return ok(
            data={
                "status": "waiting_for_input",
                "questions": questions_data,
            },
            message=f"Prepared {len(questions_data)} question(s) for user",
            meta={
                "status": "waiting_for_input",
                "question_count": len(questions_data),
            },
        )
    except Exception as exc:
        logger.error(f"AskUserQuestion failed: {exc}", exc_info=True)
        return err("INTERNAL", f"AskUserQuestion failed: {exc}")


@tool(
    "Finalize plan artifact and request approval to leave Plan Mode.",
    name="ExitPlanMode",
    usage_rules=EXIT_PLAN_MODE_USAGE_RULES,
)
async def ExitPlanMode(
    params: ExitPlanModeInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        if str(params.plan_markdown or "").strip():
            return err(
                "INVALID_ARGUMENT",
                "plan_markdown is deprecated. Write your plan to the active plan file, then call ExitPlanMode.",
            )

        if ctx is None or ctx.active_plan_path is None:
            return err(
                "INVALID_ARGUMENT",
                "No active plan file is bound to this session. Enter Plan Mode and edit the provided plan file first.",
            )

        path = ctx.active_plan_path.expanduser().resolve()
        if not await _exists(path):
            return err(
                "NOT_FOUND",
                f"Active plan file not found: {path}. Use Write to create it before calling ExitPlanMode.",
            )

        plan_markdown = (await _read_text(path, encoding="utf-8")).strip()
        if not plan_markdown:
            return err(
                "INVALID_ARGUMENT",
                f"Active plan file is empty: {path}. Add plan content before calling ExitPlanMode.",
            )

        execution_prompt = str(params.execution_prompt or "").strip()
        if not execution_prompt:
            execution_prompt = "implement it all. do everything in the plan, don't cherry-pick, do not stop until all tasks and phases are completed, don't pause for confirmation mid-flow."

        logger.info(f"ExitPlanMode finalized active plan artifact: {path}")
        return ok(
            data={
                "status": "waiting_for_plan_approval",
                "plan_path": str(path),
                "summary": params.summary,
                "execution_prompt": execution_prompt,
            },
            message=f"Plan is ready for approval: {path}",
            meta={
                "status": "waiting_for_plan_approval",
                "plan_path": str(path),
            },
        )
    except Exception as exc:
        logger.error(f"ExitPlanMode failed: {exc}", exc_info=True)
        return err("INTERNAL", f"ExitPlanMode failed: {exc}")


SYSTEM_TOOLS: list[Tool] = [
    Bash,
    Read,
    Write,
    Edit,
    Glob,
    Grep,
    LS,
    *TASK_TOOLS,
    TeamCreate,
    TeamDelete,
    SendMessage,
    WebFetch,
    YieldTurn,
    ExitPlanMode,
    AskUserQuestion,
]
