import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from comate_agent_sdk.system_tools.path_guard import PathGuardError, resolve_for_read, resolve_for_write


class TestPathGuard(unittest.TestCase):
    def test_resolve_for_write_expands_home_path(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            plans_root = (Path(td) / ".agent" / "plans").resolve()
            plans_root.mkdir(parents=True, exist_ok=True)

            with mock.patch.dict(os.environ, {"HOME": td}, clear=False):
                resolved = resolve_for_write(
                    user_path="~/.agent/plans/demo.md",
                    workspace_root=plans_root,
                )

            self.assertEqual(resolved, (plans_root / "demo.md").resolve())

    def test_resolve_for_read_expands_home_path_with_extra_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = (Path(td) / "project").resolve()
            workspace_root = (project_root / ".agent_workspace").resolve()
            plans_root = (Path(td) / ".agent" / "plans").resolve()
            project_root.mkdir(parents=True, exist_ok=True)
            workspace_root.mkdir(parents=True, exist_ok=True)
            plans_root.mkdir(parents=True, exist_ok=True)

            with mock.patch.dict(os.environ, {"HOME": td}, clear=False):
                resolved = resolve_for_read(
                    user_path="~/.agent/plans/demo.md",
                    project_root=project_root,
                    workspace_root=workspace_root,
                    extra_read_roots=(plans_root,),
                )

            self.assertEqual(resolved, (plans_root / "demo.md").resolve())

    def test_resolve_for_read_blocks_dev_urandom_even_under_extra_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = (Path(td) / "project").resolve()
            workspace_root = (project_root / ".agent_workspace").resolve()
            project_root.mkdir(parents=True, exist_ok=True)
            workspace_root.mkdir(parents=True, exist_ok=True)

            with self.assertRaises(PathGuardError) as ctx:
                resolve_for_read(
                    user_path="/dev/urandom",
                    project_root=project_root,
                    workspace_root=workspace_root,
                    extra_read_roots=(Path("/dev").resolve(),),
                )

        self.assertEqual(ctx.exception.code, "DEVICE_PATH_BLOCKED")

    def test_resolve_for_read_blocks_proc_fd_even_under_extra_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            project_root = (Path(td) / "project").resolve()
            workspace_root = (project_root / ".agent_workspace").resolve()
            project_root.mkdir(parents=True, exist_ok=True)
            workspace_root.mkdir(parents=True, exist_ok=True)

            with self.assertRaises(PathGuardError) as ctx:
                resolve_for_read(
                    user_path=f"/proc/{os.getpid()}/fd/0",
                    project_root=project_root,
                    workspace_root=workspace_root,
                    extra_read_roots=(Path("/proc").resolve(),),
                )

        self.assertEqual(ctx.exception.code, "DEVICE_PATH_BLOCKED")


if __name__ == "__main__":
    unittest.main()
