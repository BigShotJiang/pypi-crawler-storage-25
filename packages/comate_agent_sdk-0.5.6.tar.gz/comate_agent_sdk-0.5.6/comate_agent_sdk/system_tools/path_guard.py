from __future__ import annotations

from difflib import get_close_matches
from pathlib import Path
from typing import Iterable

from comate_agent_sdk.system_tools.tool_result import ToolErrorCode

_SENSITIVE_PATHS: tuple[Path, ...] = (
    Path("/proc"),
    Path("/sys"),
    Path("/dev"),
    Path("/etc"),
)
_BLOCKED_DEVICE_PATHS: tuple[Path, ...] = (
    Path("/dev/urandom"),
    Path("/dev/random"),
    Path("/dev/zero"),
    Path("/dev/full"),
    Path("/dev/stdin"),
    Path("/dev/stdout"),
    Path("/dev/stderr"),
    Path("/dev/tty"),
    Path("/dev/console"),
)
_BLOCKED_FD_NUMBERS = {"0", "1", "2"}


class PathGuardError(Exception):
    def __init__(self, code: ToolErrorCode, message: str) -> None:
        super().__init__(message)
        self.code: ToolErrorCode = code
        self.message = message


def normalize_user_path(user_path: str) -> Path:
    """Normalize user-provided path before access checks."""
    try:
        return Path(user_path).expanduser()
    except RuntimeError as exc:
        raise PathGuardError(
            "INVALID_ARGUMENT",
            f"failed to expand user path: {user_path}",
        ) from exc


def _resolve_like_user_input(*, user_path: str, base_root: Path) -> Path:
    candidate = normalize_user_path(user_path)
    if candidate.is_absolute():
        return candidate.resolve(strict=False)
    return (base_root.resolve() / candidate).resolve(strict=False)


def _closest_existing_parent(path: Path, root: Path) -> Path | None:
    root_resolved = root.resolve()
    cursor = path
    while True:
        if cursor.exists() and cursor.is_dir():
            try:
                cursor.relative_to(root_resolved)
                return cursor
            except ValueError:
                return None
        if cursor == root_resolved or cursor.parent == cursor:
            return root_resolved if root_resolved.exists() else None
        cursor = cursor.parent


def suggest_path_under_roots(
    *,
    user_path: str | None,
    project_root: Path,
    workspace_root: Path | None,
    extra_read_roots: tuple[Path, ...] = (),
) -> str | None:
    if user_path is None or not user_path.strip():
        return None

    search_roots: list[Path] = []
    if workspace_root is not None:
        search_roots.append(workspace_root.resolve())
    search_roots.append(project_root.resolve())
    search_roots.extend(root.resolve() for root in extra_read_roots)

    for root in search_roots:
        candidate = _resolve_like_user_input(user_path=user_path, base_root=root)
        try:
            candidate.relative_to(root)
        except ValueError:
            continue

        parent = _closest_existing_parent(candidate.parent, root)
        if parent is None:
            continue

        try:
            names = sorted(child.name for child in parent.iterdir())
        except OSError:
            continue

        matches = get_close_matches(candidate.name, names, n=1, cutoff=0.6)
        if not matches:
            continue

        suggestion = parent / matches[0]
        try:
            return suggestion.relative_to(root).as_posix()
        except ValueError:
            continue
    return None


def _ensure_not_sensitive(path: Path) -> None:
    for prefix in _SENSITIVE_PATHS:
        try:
            path.relative_to(prefix)
            raise PathGuardError(
                "PERMISSION_DENIED",
                f"path {path} is under restricted system directory {prefix}",
            )
        except ValueError:
            continue


def _ensure_under_roots(path: Path, roots: Iterable[Path]) -> None:
    resolved_roots = [r.resolve() for r in roots]
    for root in resolved_roots:
        try:
            path.relative_to(root)
            return
        except ValueError:
            continue
    roots_text = ", ".join(str(r) for r in resolved_roots)
    raise PathGuardError(
        "PATH_ESCAPE",
        f"path {path} is outside allowed roots: {roots_text}",
    )


def _is_blocked_device_path(path: Path) -> bool:
    if not path.is_absolute():
        return False

    for blocked in _BLOCKED_DEVICE_PATHS:
        if path == blocked:
            return True

    parts = path.parts
    if len(parts) == 4 and parts[1] == "dev" and parts[2] == "fd" and parts[3] in _BLOCKED_FD_NUMBERS:
        return True
    if len(parts) == 5 and parts[1] == "proc" and parts[3] == "fd" and parts[4] in _BLOCKED_FD_NUMBERS:
        return True
    return False


def _ensure_not_blocked_device_path(*, original_path: Path, resolved_path: Path) -> None:
    if _is_blocked_device_path(original_path) or _is_blocked_device_path(resolved_path):
        raise PathGuardError(
            "DEVICE_PATH_BLOCKED",
            f"path {original_path} resolves to a blocked device or stdio endpoint",
        )


def _ensure_no_symlink_traversal(path: Path, root: Path) -> None:
    root_resolved = root.resolve()
    try:
        rel_parts = path.relative_to(root_resolved).parts
    except ValueError as exc:
        raise PathGuardError("PATH_ESCAPE", f"path {path} is outside root {root_resolved}") from exc

    cursor = root_resolved
    for part in rel_parts:
        cursor = cursor / part
        if cursor.exists() and cursor.is_symlink():
            raise PathGuardError(
                "PATH_ESCAPE",
                f"path segment {cursor} is a symbolic link and is not allowed",
            )


def resolve_for_read(
    *,
    user_path: str,
    project_root: Path,
    workspace_root: Path | None,
    extra_read_roots: tuple[Path, ...] = (),
) -> Path:
    if not user_path or not user_path.strip():
        raise PathGuardError("INVALID_ARGUMENT", "file_path cannot be empty")

    project_root_resolved = project_root.resolve()
    candidate = normalize_user_path(user_path)
    if candidate.is_absolute():
        resolved = candidate.resolve()
    else:
        project_candidate = (project_root_resolved / candidate).resolve()
        workspace_candidate: Path | None = None
        if workspace_root is not None:
            workspace_candidate = (workspace_root.resolve() / candidate).resolve()

        if workspace_candidate is not None and workspace_candidate.exists():
            # Prefer workspace for relative paths so Read/Edit target the same tree.
            resolved = workspace_candidate
        elif project_candidate.exists():
            resolved = project_candidate
        elif workspace_candidate is not None:
            # Not found in either place: keep project fallback behavior for error message stability.
            resolved = project_candidate
        else:
            resolved = project_candidate

    allowed_roots: list[Path] = [project_root_resolved]
    if workspace_root is not None:
        allowed_roots.append(workspace_root.resolve())
    allowed_roots.extend(extra_read_roots)

    _ensure_not_blocked_device_path(original_path=candidate, resolved_path=resolved)
    _ensure_not_sensitive(resolved)
    _ensure_under_roots(resolved, allowed_roots)
    return resolved


def resolve_for_search(
    *,
    user_path: str | None,
    project_root: Path,
    workspace_root: Path | None,
    extra_read_roots: tuple[Path, ...] = (),
) -> Path:
    if user_path is None:
        return project_root.resolve()
    return resolve_for_read(
        user_path=user_path,
        project_root=project_root,
        workspace_root=workspace_root,
        extra_read_roots=extra_read_roots,
    )


def resolve_for_write(*, user_path: str, workspace_root: Path) -> Path:
    if not user_path or not user_path.strip():
        raise PathGuardError("INVALID_ARGUMENT", "file_path cannot be empty")

    root = workspace_root.resolve()
    candidate = normalize_user_path(user_path)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()

    _ensure_not_sensitive(resolved)
    _ensure_under_roots(resolved, [root])
    _ensure_no_symlink_traversal(resolved, root)
    return resolved


def to_safe_relpath(path: Path, *, roots: Iterable[Path]) -> str:
    resolved = path.resolve()
    for root in roots:
        try:
            rel = resolved.relative_to(root.resolve())
            return rel.as_posix()
        except Exception:
            continue
    return str(resolved.name)
