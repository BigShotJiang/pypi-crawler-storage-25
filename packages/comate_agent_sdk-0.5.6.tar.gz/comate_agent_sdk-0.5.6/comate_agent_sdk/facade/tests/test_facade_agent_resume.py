"""Facade `Agent(options=AgentOptions(session_id=...))` 的 resume 路径回归测试。

护栏：任何人把 Agent 的构造路径改回"无视 context.jsonl、直接 ChatSession(session_id=...)"
都应该被这些测试拦下来。
"""
from __future__ import annotations

import tempfile
import unittest
import uuid
from pathlib import Path

from comate_agent_sdk.agent import Agent as InternalAgent
from comate_agent_sdk.agent import AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.session_store import default_session_root
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.facade.core.agent import Agent as FacadeAgent


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("Tests must not invoke the LLM")


def _persist_fake_session(cwd: Path, session_id: str, *, team_name: str | None = None) -> None:
    """用 SDK 内部 Agent+ChatSession 在 cwd 下预落盘一个 session（context.jsonl + session.json）。"""
    template = InternalAgent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            setting_sources=None,
            cwd=cwd,
        ),
    )
    session = ChatSession(template, session_id=session_id, cwd=cwd)
    if team_name:
        session._agent._team_name = team_name
        session._bind_task_namespace(team_name, persist=True)
    session._ensure_header_persisted()


class TestFacadeAgentResumePath(unittest.IsolatedAsyncioTestCase):
    async def test_existing_context_jsonl_triggers_resume(self) -> None:
        """context.jsonl 已存在时必须走 resume：_lock_header_from_snapshot=True。"""
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            session_id = f"sess-{uuid.uuid4().hex[:8]}"
            _persist_fake_session(cwd, session_id)

            jsonl = default_session_root(session_id, cwd=cwd) / "context.jsonl"
            self.assertTrue(jsonl.exists(), "前置条件：context.jsonl 应已写入")

            agent = FacadeAgent(
                options=AgentOptions(
                    model=_FakeChatModel(),  # type: ignore[arg-type]
                    cwd=cwd,
                    session_id=session_id,
                    setting_sources=[],
                )
            )
            await agent._ensure_initialized()
            try:
                cs = agent._chat_session
                assert cs is not None
                self.assertEqual(cs.session_id, session_id)
                self.assertTrue(
                    cs._agent._lock_header_from_snapshot,
                    "context.jsonl 存在时 facade Agent 必须走 ChatSession.resume 路径",
                )
            finally:
                await agent.shutdown()

    async def test_missing_context_jsonl_creates_new_session_with_preferred_id(self) -> None:
        """session_id 给定但 context.jsonl 不存在 → 创建新 session 并预占 ID。"""
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            session_id = f"new-{uuid.uuid4().hex[:8]}"

            agent = FacadeAgent(
                options=AgentOptions(
                    model=_FakeChatModel(),  # type: ignore[arg-type]
                    cwd=cwd,
                    session_id=session_id,
                    setting_sources=[],
                )
            )
            await agent._ensure_initialized()
            try:
                cs = agent._chat_session
                assert cs is not None
                self.assertEqual(cs.session_id, session_id)
                self.assertFalse(
                    cs._agent._lock_header_from_snapshot,
                    "新 session 不应被标记为从 snapshot 锁定",
                )
            finally:
                await agent.shutdown()

    async def test_no_session_id_generates_random_uuid(self) -> None:
        """未传 session_id 时回退到随机 UUID（与历史行为一致）。"""
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            agent = FacadeAgent(
                options=AgentOptions(
                    model=_FakeChatModel(),  # type: ignore[arg-type]
                    cwd=cwd,
                    setting_sources=[],
                )
            )
            await agent._ensure_initialized()
            try:
                cs = agent._chat_session
                assert cs is not None
                # UUID4 的标准形态是 36 字符带横杠
                self.assertEqual(len(cs.session_id), 36)
                self.assertEqual(cs.session_id.count("-"), 4)
                self.assertFalse(cs._agent._lock_header_from_snapshot)
            finally:
                await agent.shutdown()

    async def test_team_mode_resume_restores_team_name(self) -> None:
        """Team Mode + 已持久化 session → 走 resume，team_name 从 session.json 恢复。"""
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            session_id = f"team-{uuid.uuid4().hex[:8]}"
            team_name = "review-team"
            _persist_fake_session(cwd, session_id, team_name=team_name)

            agent = FacadeAgent(
                options=AgentOptions(
                    model=_FakeChatModel(),  # type: ignore[arg-type]
                    cwd=cwd,
                    session_id=session_id,
                    setting_sources=[],
                ),
                team_name=team_name,
                name="leader",
            )
            await agent._ensure_initialized()
            try:
                cs = agent._chat_session
                assert cs is not None
                self.assertEqual(cs.session_id, session_id)
                self.assertTrue(
                    cs._agent._lock_header_from_snapshot,
                    "Team Mode 下已持久化 session 仍必须走 resume",
                )
                self.assertEqual(cs._agent._team_name, team_name)
            finally:
                await agent.shutdown()

    async def test_team_mode_new_session_sets_team_name(self) -> None:
        """Team Mode + 未持久化 session → 新建 runtime 且带 team_name。"""
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            session_id = f"team-new-{uuid.uuid4().hex[:8]}"
            team_name = "review-team"

            agent = FacadeAgent(
                options=AgentOptions(
                    model=_FakeChatModel(),  # type: ignore[arg-type]
                    cwd=cwd,
                    session_id=session_id,
                    setting_sources=[],
                ),
                team_name=team_name,
                name="leader",
            )
            await agent._ensure_initialized()
            try:
                cs = agent._chat_session
                assert cs is not None
                self.assertEqual(cs.session_id, session_id)
                self.assertEqual(cs._agent._team_name, team_name)
                self.assertFalse(cs._agent._lock_header_from_snapshot)
            finally:
                await agent.shutdown()


if __name__ == "__main__":
    unittest.main()
