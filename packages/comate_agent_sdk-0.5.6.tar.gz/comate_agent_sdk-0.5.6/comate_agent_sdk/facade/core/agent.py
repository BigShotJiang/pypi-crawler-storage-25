# comate_agent_sdk/facade/core/agent.py
from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from comate_agent_sdk.agent.chat_session import ChatSession
    from comate_agent_sdk.agent.core.template import AgentTemplate
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger(__name__)


class Agent:
    """
    智能体实例。

    最小化 API：通过 options 配置。
    可选参数：tools, options, session_id（Advanced）, team_name/name（Team Mode）。
    """

    def __init__(
        self,
        *,
        tools: list[Any] | None = None,
        options: Any | None = None,
        session_id: str | None = None,
        team_name: str | None = None,
        name: str | None = None,
    ) -> None:
        """
        初始化 Agent。

        Args:
            tools: 工具列表（Optional，Extended 阶段）
            options: 配置对象（Optional，通过 options.system_prompt 设置系统 prompt）
            session_id: 会话 ID（Optional，Advanced 阶段，支持但不在文档第一章）
            team_name: 所属 team 名（Optional，Team Mode）
            name: 在 team 中的身份（Optional，Team Mode）
        """
        self.tools = tools or []
        self.options = options
        self.session_id = session_id
        self.team_name = team_name
        self.name = name

        # 延迟初始化（会话在 run_agent 时创建）
        self._chat_session: ChatSession | None = None
        self._agent_template: AgentTemplate | None = None
        self._pending_hooks: list[tuple[str, Any, str | None, float | None]] = []

    def register_hook(
        self,
        event: str,
        callback: Any,
        *,
        matcher: str | None = None,
        timeout: float | None = None,
    ) -> None:
        """注册 Python hook（必须在 run_message 之前调用）。

        Args:
            event: 事件名 ("PreToolUse", "PostToolUse", ...)
            callback: 异步回调 (hook_input_dict, tool_use_id) -> output_dict | None
            matcher: 正则匹配工具名，None = 匹配所有
            timeout: 超时秒数，None = 使用 SDK 默认值
        """
        if self._chat_session is not None:
            raise RuntimeError("Cannot register hooks after run_message() has been called")
        from comate_agent_sdk.facade.config.hooks import HOOK_EVENTS
        if event not in HOOK_EVENTS:
            raise ValueError(f"Unknown hook event: {event!r}. Valid events: {sorted(HOOK_EVENTS)}")
        self._pending_hooks.append((event, callback, matcher, timeout))

    async def _ensure_initialized(self) -> None:
        """确保 agent 已初始化"""
        if self._chat_session is not None:
            return

        from dataclasses import replace

        from comate_agent_sdk.agent.service import AgentTemplate
        from comate_agent_sdk.facade._internals.adapters import _map_options
        from comate_agent_sdk.facade.client import _open_chat_session
        from comate_agent_sdk.facade.config.options import AgentOptions
        from comate_agent_sdk.facade._internals.query import _resolve_options

        # 处理 plugins（原来直接跳到 _map_options）
        # tools=None 是有意的：self.tools 是 Tool 对象列表（非 plugin 配置），
        # 由下方 config.tools 合并逻辑处理，不通过 _resolve_options
        opts = self.options if isinstance(self.options, AgentOptions) else None
        opts, loaded_plugins = _resolve_options(options=opts, tools=None)

        # 映射选项（注意：opts 是局部变量，不修改 self.options）
        config = _map_options(opts)

        # 合并 plugin 资源
        if loaded_plugins:
            from comate_agent_sdk.facade._internals.adapters import _merge_plugin_resources
            config = _merge_plugin_resources(config, loaded_plugins)

        # 合并 Agent(tools=[...]) 传入的自定义工具
        if self.tools:
            existing = list(config.tools) if config.tools else []
            existing.extend(self.tools)
            config = replace(config, tools=tuple(existing))

        # 创建 AgentTemplate
        self._agent_template = AgentTemplate(config=config)

        # session_id 优先级：Agent(session_id=...) > options.session_id
        resolved_session_id = self.session_id
        if resolved_session_id is None and self.options and hasattr(self.options, "session_id"):
            resolved_session_id = self.options.session_id

        # 统一走 _open_chat_session：context.jsonl 存在则 resume，否则新建。
        # Team Mode 由 team_name 分支接管 runtime 构造。
        resolved_options = opts if opts is not None else AgentOptions()
        self._chat_session = _open_chat_session(
            template=self._agent_template,
            options=resolved_options,
            session_id=resolved_session_id,
            team_name=self.team_name,
        )

        # ── Hook 注入 ──
        runtime = self._chat_session._agent
        # ① AgentOptions.hooks → hook_engine._config.extend()
        if self.options and hasattr(self.options, "hooks") and self.options.hooks:
            from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks
            facade_hook_config = _map_facade_hooks(self.options.hooks)
            runtime._hook_engine._config.extend(facade_hook_config)

        # ② _pending_hooks → 直接构建 HookMatcherGroup 追加到 hook_engine
        #    不用 runtime.register_python_hook()，因为它不支持 timeout 参数
        if self._pending_hooks:
            from comate_agent_sdk.facade._internals.adapters import _wrap_facade_hook_callback
            from comate_agent_sdk.agent.hooks.models import HookHandlerSpec, HookMatcherGroup
            for event, callback, matcher, timeout in self._pending_hooks:
                wrapped = _wrap_facade_hook_callback(callback)
                spec = HookHandlerSpec(
                    type="python",
                    callback=wrapped,
                    timeout=int(timeout) if timeout is not None else 10,
                    name=getattr(callback, "__name__", "facade_hook"),
                    source="facade",
                )
                group = HookMatcherGroup(
                    matcher=matcher or "*",
                    hooks=[spec],
                    source="facade",
                )
                runtime._hook_engine._config.events.setdefault(event, []).append(group)
            self._pending_hooks.clear()

        sp_desc = "None"
        if self.options and hasattr(self.options, "system_prompt") and self.options.system_prompt:
            sp = self.options.system_prompt
            sp_desc = f"len={len(sp)}" if isinstance(sp, str) else f"SystemPromptConfig(mode={sp.mode})"

        logger.debug(
            f"Agent initialized: session_id={self._chat_session.session_id}, "
            f"system_prompt={sp_desc}, "
            f"team_mode={'enabled' if self.team_name else 'disabled'}"
        )

    async def run_message(self, prompt: str | AsyncIterable[dict[str, Any]]) -> Any:
        """异步生成器：运行消息，产生事件流。

        Args:
            prompt: 单条字符串消息，或 AsyncIterable[dict] 逐条消费。
                    dict 格式：{"type": "user", "message": {"role": "user", "content": "..."}}
                    逐条模式下，completed 继续拉取下一条，interrupted/max_iterations 终止。
        """
        from comate_agent_sdk.facade._internals.adapters import _filter_events_new
        from comate_agent_sdk.facade.core.events import StopEvent, YieldEvent

        await self._ensure_initialized()
        assert self._chat_session is not None

        if isinstance(prompt, str):
            # --- 单条字符串消息 ---
            logger.debug(f"Running message: {prompt[:100] if len(prompt) > 100 else prompt}")
            async for event in _filter_events_new(self._chat_session.query_stream(prompt)):
                yield event

                runtime_team = getattr(self._chat_session._agent, "_team_name", "") if self._chat_session else ""
                if isinstance(event, YieldEvent) and runtime_team:
                    # 不变量：YieldEvent 是 _filter_events_new 映射的最后一个事件
                    # （InternalStopEvent(yielded) → YieldEvent 后 query_stream 结束）
                    logger.debug("YieldEvent detected, entering team continuation loop")
                    async for continuation_event in self._team_continuation_loop():
                        yield continuation_event
                    return
        else:
            # --- AsyncIterable：逐条消费 ---
            runtime_team = getattr(self._chat_session._agent, "_team_name", "") if self._chat_session else ""
            if runtime_team or self.team_name:
                from comate_agent_sdk.facade.errors import AgentExecutionError
                raise AgentExecutionError(
                    "Team Mode does not support AsyncIterable prompts. Use a string prompt."
                )

            logger.debug("Running with AsyncIterable prompt source")
            async for item in prompt:
                message = item["message"]["content"]
                logger.debug(f"Consuming item: {str(message)[:100]}")
                async for event in _filter_events_new(self._chat_session.query_stream(message)):
                    yield event

                    # 异常终止：停止消费迭代器
                    if isinstance(event, StopEvent) and event.reason != "completed":
                        logger.debug(f"StopEvent(reason={event.reason}), aborting iterable consumption")
                        return

    async def _team_continuation_loop(self) -> Any:
        """Team Mode 续轮：轮询等待 inbox → query_stream(None) → 继续 yield 事件。

        后台 poll loop (run_inbox_poll_loop) 负责 inbox → scheduler enqueue。
        本方法负责 scheduler → query_stream(None) → drain → yield 事件。

        关键：必须在外层持有 external_turn_callback，否则 query_stream 的
        finally 会拆除 callback + inbox poll task，导致续轮死锁。
        """
        from comate_agent_sdk.facade._internals.adapters import _filter_events_new
        from comate_agent_sdk.facade.core.events import StopEvent, YieldEvent
        from comate_agent_sdk.system_tools.team.polling import DEFAULT_TEAM_POLL_INTERVAL_SECONDS

        poll_interval = DEFAULT_TEAM_POLL_INTERVAL_SECONDS
        assert self._chat_session is not None
        session = self._chat_session

        # 外层持有 callback，保证 inbox poll 在整个续轮阶段保持运行。
        # 内层 query_stream(None) 的 set/restore 会嵌套在此之上，
        # restore 时 external_turn_callback 恢复到外层值（非 None），inbox poll 不会被停掉。
        previous = session._set_external_turn_callback()
        try:
            while True:
                while not session.has_pending_external_turns():
                    # 实时 drain subagent 转发过来的 TeamMessageEvent，
                    # 不等待 leader 收到 external turn 才一次性吐出。
                    async for event in session._drain_session_events():
                        yield event
                    await asyncio.sleep(poll_interval)

                # 消费 pending turns（无用户消息）
                async for event in _filter_events_new(session.query_stream(None)):
                    yield event

                    if isinstance(event, StopEvent):
                        return  # 真正停止
                    if isinstance(event, YieldEvent):
                        break  # 再次 yield，继续外层 while 等待

                # 内层 query_stream restore 会清除 team_message_event_callback，
                # 重新设置以保证 TeamMessageEvent 继续流转
                if session._agent._team.team_message_event_callback is None:
                    session._agent._team.team_message_event_callback = session._enqueue_team_message_event
        finally:
            session._restore_external_turn_callback(previous)

    async def shutdown(self) -> None:
        """关闭 agent，清理资源"""
        if self._chat_session is not None:
            await self._chat_session.shutdown()

    def interrupt(self, reason: str = "user") -> bool:
        """Interrupt the currently running turn.

        Thread-safe: can be called from any thread (signal handlers, UI callbacks, etc.).
        Multiple calls increment interrupt_count for progressive forced interruption.

        Args:
            reason: Interrupt reason, defaults to "user".

        Returns:
            True if an active session was interrupted, False if session not initialized.
        """
        if self._chat_session is None:
            return False
        self._chat_session.run_controller.interrupt(reason)
        return True

    @property
    def is_running(self) -> bool:
        """Whether there is an active running turn."""
        if self._chat_session is None:
            return False
        return self._chat_session.is_turn_active


__all__ = ["Agent"]
