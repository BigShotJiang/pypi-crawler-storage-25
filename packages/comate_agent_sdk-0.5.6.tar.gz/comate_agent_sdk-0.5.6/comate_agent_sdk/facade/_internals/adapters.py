from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from comate_agent_sdk.agent.compaction import CompactionConfig
from comate_agent_sdk.agent.chat_session import ChatSessionError
from comate_agent_sdk.agent.events import (
    AgentEvent,
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    HiddenUserMessageEvent,
    LLMSwitchedEvent,
    MessageCompleteEvent,
    MessageStartEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
    SessionInitEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent as InternalStopEvent,
    SubagentProgressEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TaskUpdatedEvent,
    TeamMessageEvent,
    TextEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
    UserQuestionEvent,
    CompactionMetaEvent,
    CompactionResultEvent,
)
from comate_agent_sdk.agent.options import AgentConfig
from comate_agent_sdk.agent.session_store import SessionStoreError
from comate_agent_sdk.facade.errors import (
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
)
from comate_agent_sdk.facade.core.events import Event, StopEvent, ToolUseEvent, YieldEvent
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.mcp.store import McpConfigError
from comate_agent_sdk.utils.paths import PathInputError

_IGNORED_EVENT_TYPES = (
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    MessageStartEvent,
    MessageCompleteEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    UsageDeltaEvent,
    SubagentProgressEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    HiddenUserMessageEvent,
    TaskUpdatedEvent,
    CompactionResultEvent,
    CompactionMetaEvent,
    LLMSwitchedEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
)


def _map_output_format(raw: Any) -> dict[str, Any] | None:
    """Convert output_format from facade types (dict / Pydantic class / Pydantic instance) to standard dict."""
    if raw is None:
        return None
    from pydantic import BaseModel
    from comate_agent_sdk.llm.schema import build_response_format_from_model
    if isinstance(raw, BaseModel):
        # User passed a Pydantic instance
        return build_response_format_from_model(type(raw))
    if isinstance(raw, type) and issubclass(raw, BaseModel):
        # User passed a Pydantic model class
        return build_response_format_from_model(raw)
    if isinstance(raw, dict):
        return raw
    raise TypeError(f"output_format must be dict, Pydantic model class, or Pydantic instance, got {type(raw)}")


def _map_options(options: AgentOptions | None) -> AgentConfig:
    if options is None:
        return AgentConfig(setting_sources=None)

    tools_opt = getattr(options, "tools", None)
    model_opt = getattr(options, "model", None)
    agents_opt = getattr(options, "agents", None)
    setting_sources_opt = getattr(options, "setting_sources", None)
    env_opt = getattr(options, "env", None)
    memory_background_enabled_opt = getattr(options, "memory_background_enabled", None)
    compaction_threshold_ratio_opt = getattr(options, "compaction_threshold_ratio", None)
    add_dirs_opt = getattr(options, "add_dirs", None)
    disallowed_tools_opt = getattr(options, "disallowed_tools", None)
    output_format_opt = getattr(options, "output_format", None)
    system_prompt_opt = getattr(options, "system_prompt", None)
    max_iterations_opt = getattr(options, "max_iterations", 200)
    mcp_servers_opt = getattr(options, "mcp_servers", None)
    session_id_opt = getattr(options, "session_id", None)
    cwd_opt = getattr(options, "cwd", None)
    system_role_opt = getattr(options, "system_role", None)

    # --- tools 映射 ---
    # AgentOptions.tools=None → 空 tuple（无内置工具，仅用户自定义工具）
    # AgentOptions.tools="comate" → None（SDK 加载全部内置工具）
    # AgentOptions.tools=["Bash","Read"] → tuple("Bash","Read")（按名挑选）
    tools: tuple[Any, ...] | None
    if tools_opt is None:
        tools = ()
    elif tools_opt == "comate":
        tools = None
    elif isinstance(tools_opt, list):
        tools = tuple(tools_opt)
    else:
        tools = ()

    # --- model → llm_levels 映射（映射到 MID 档）---
    # 字符串保持原样传递，延迟到 resolve_llm_levels 时再实例化（届时 settings 已加载，api_key 可用）
    llm_levels: dict[str, Any] | None = None
    if model_opt is not None:
        if isinstance(model_opt, str):
            llm_levels = {"MID": model_opt}
        else:
            llm_levels = {"MID": model_opt}

    # --- agents → AgentDefinition 映射 ---
    agents: tuple[Any, ...] | None = None
    if agents_opt:
        from comate_agent_sdk.subagent.models import AgentDefinition
        agent_defs = []
        for name, cfg in agents_opt.items():
            agent_defs.append(AgentDefinition(
                name=name,
                description=cfg.description,
                prompt=cfg.prompt,
                tools=cfg.tools,
                model=cfg.model,
                max_iterations=cfg.max_iterations,
                skills=cfg.skills,
                shared_auto_memory=cfg.shared_auto_memory,
            ))
        agents = tuple(agent_defs)

    # --- setting_sources 映射 ---
    setting_sources = (
        tuple(setting_sources_opt)
        if setting_sources_opt is not None
        else None
    )

    if add_dirs_opt:
        for p in add_dirs_opt:
            resolved = Path(p).expanduser().resolve()
            if not resolved.exists():
                logger.warning(f"add_dirs: path does not exist (yet): {resolved}")

    return AgentConfig(
        system_prompt=system_prompt_opt,
        max_iterations=max_iterations_opt,
        tools=tools,
        mcp_servers=dict(mcp_servers_opt) if mcp_servers_opt is not None else None,
        session_id=session_id_opt,
        cwd=cwd_opt if cwd_opt is not None else Path.cwd(),
        llm_levels=llm_levels,
        agents=agents,
        setting_sources=setting_sources,
        env=dict(env_opt) if env_opt else None,
        memory_background_enabled=memory_background_enabled_opt,
        compaction=(
            CompactionConfig(threshold_ratio=compaction_threshold_ratio_opt)
            if compaction_threshold_ratio_opt is not None
            else None
        ),
        add_dirs=tuple(Path(p).expanduser().resolve() for p in add_dirs_opt) if add_dirs_opt else None,
        disallowed_tools=tuple(disallowed_tools_opt) if disallowed_tools_opt else None,
        output_format=_map_output_format(output_format_opt),
        role=system_role_opt,
    )


def _map_construction_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    if isinstance(exc, (PathInputError, SessionStoreError, McpConfigError, TypeError, ValueError)):
        return AgentConfigError(str(exc))
    return AgentExecutionError(str(exc))


def _map_runtime_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return AgentTimeoutError(str(exc))
    if isinstance(exc, (ModelProviderError, ModelRateLimitError, ConnectionError)):
        return AgentConnectionError(str(exc))
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    return AgentExecutionError(str(exc))


def _map_stop_event(event: InternalStopEvent) -> StopEvent | YieldEvent:
    """Map internal StopEvent to external StopEvent or YieldEvent.

    Team Mode notes:
    - reason="yielded": Agent in team mode waiting for teammate -> YieldEvent
    - reason="waiting_for_plan_approval": Special case -> should not reach here
    """
    reason = event.reason

    # Team Mode: yielded -> YieldEvent（Team Mode 等待队友）
    if reason == "yielded":
        return YieldEvent(
            reason="waiting_for_teammate",
            metadata={"internal_reason": "yielded"}
        )

    # Normal stop reasons -> StopEvent
    if reason in {"completed", "max_iterations"}:
        mapped_reason = "completed" if reason == "completed" else "max_iterations"
        return StopEvent(reason=mapped_reason)

    if reason == "interrupted":
        return StopEvent(reason="interrupted")

    # These should not reach facade API
    if reason in {"shutdown_request", "waiting_for_input", "waiting_for_plan_approval"}:
        raise AgentExecutionError(
            f"Unsupported internal stop reason for facade API: {reason}"
        )

    raise AgentExecutionError(f"Unknown internal stop reason for facade API: {reason}")


def _map_stop_event_legacy(event: InternalStopEvent) -> DoneEvent:
    """Legacy mapping: InternalStopEvent -> DoneEvent (for AgentClient/query backward compatibility)"""
    from comate_agent_sdk.facade.events import DoneEvent

    reason = event.reason
    if reason in {"completed", "max_iterations"}:
        return DoneEvent(reason="completed")
    if reason in {"interrupted", "shutdown_request"}:
        return DoneEvent(reason="interrupted")
    if reason == "waiting_for_input":
        return DoneEvent(reason="waiting_for_input")
    if reason in {"yielded", "waiting_for_plan_approval"}:
        raise AgentExecutionError(
            f"Unsupported internal stop reason for facade API: {reason}"
        )
    raise AgentExecutionError(f"Unknown internal stop reason for facade API: {reason}")


async def _filter_events(events: AsyncIterator[AgentEvent]) -> AsyncIterator[Event]:
    """Legacy filter: maps to old DoneEvent (for AgentClient/query backward compatibility).

    Used by:
    - AgentClient.chat() / AgentClient.query()
    - query() function
    """
    from comate_agent_sdk.facade.events import DoneEvent

    async for event in events:
        if isinstance(event, SessionInitEvent):
            continue
        if isinstance(event, (TextEvent, ThinkingEvent, ToolResultEvent, StepStartEvent, StepCompleteEvent, UserQuestionEvent, TeamMessageEvent)):
            yield event
            continue
        if isinstance(event, ToolCallEvent):
            yield ToolUseEvent(
                tool=event.tool,
                args=dict(event.args),
                tool_call_id=event.tool_call_id,
                display_name=event.display_name,
            )
            continue
        if isinstance(event, InternalStopEvent):
            yield _map_stop_event_legacy(event)
            continue
        if isinstance(event, _IGNORED_EVENT_TYPES):
            continue
        raise AgentExecutionError(
            f"Unsupported internal event leaked into facade API: {type(event).__name__}"
        )


async def _filter_events_new(events: AsyncIterator[AgentEvent]) -> AsyncIterator[Event]:
    """New filter: maps to StopEvent and YieldEvent (for new Agent/run_agent API).

    Used by:
    - Agent.run_message()
    - run_agent() / run_agent_async()
    """
    async for event in events:
        if isinstance(event, SessionInitEvent):
            yield event
            continue
        if isinstance(event, (TextEvent, ThinkingEvent, ToolResultEvent, StepStartEvent, StepCompleteEvent, UserQuestionEvent, TeamMessageEvent)):
            yield event
            continue
        if isinstance(event, ToolCallEvent):
            yield ToolUseEvent(
                tool=event.tool,
                args=dict(event.args),
                tool_call_id=event.tool_call_id,
                display_name=event.display_name,
            )
            continue
        if isinstance(event, InternalStopEvent):
            yield _map_stop_event(event)
            continue
        if isinstance(event, _IGNORED_EVENT_TYPES):
            continue
        raise AgentExecutionError(
            f"Unsupported internal event leaked into facade API: {type(event).__name__}"
        )


# ── Facade Hook 适配 ──────────────────────────────────


def _wrap_facade_hook_callback(callback: Any) -> Any:
    """将 Facade HookCallback(dict, str|None) 包装为 SDK 内部 PythonHookCallback(HookInput)。"""
    from comate_agent_sdk.agent.hooks.models import HookInput

    async def wrapper(hook_input: HookInput) -> dict[str, Any] | None:
        input_dict = hook_input.to_dict()
        tool_use_id = hook_input.tool_call_id
        result = await callback(input_dict, tool_use_id)
        return result or None

    wrapper.__name__ = getattr(callback, "__name__", "facade_hook")
    wrapper.__qualname__ = getattr(callback, "__qualname__", "facade_hook")
    return wrapper


def _map_facade_hooks(hooks: dict[str, list[Any]]) -> Any:
    """将 Facade hooks 配置转换为 SDK 内部 HookConfig。"""
    from comate_agent_sdk.agent.hooks.models import (
        HookConfig,
        HookHandlerSpec,
        HookMatcherGroup,
    )

    events: dict[str, list[HookMatcherGroup]] = {}
    for event_name, matchers in hooks.items():
        groups: list[HookMatcherGroup] = []
        for m in matchers:
            specs = [
                HookHandlerSpec(
                    type="python",
                    callback=_wrap_facade_hook_callback(cb),
                    timeout=int(m.timeout) if m.timeout is not None else 10,
                    name=getattr(cb, "__name__", "facade_hook"),
                    source="facade",
                )
                for cb in m.hooks
            ]
            groups.append(
                HookMatcherGroup(
                    matcher=m.matcher or "*",
                    hooks=specs,
                    source="facade",
                )
            )
        events[event_name] = groups
    return HookConfig(events=events)


def _merge_plugin_resources(
    config: "AgentConfig",
    loaded_plugins: list,
) -> "AgentConfig":
    """将已加载 plugin 的资源无损合并到 AgentConfig。

    优先级：用户显式定义 > plugin 提供（同名用户覆盖 plugin）。
    """
    from dataclasses import replace

    # 1. agents
    plugin_agents = [a for p in loaded_plugins for a in p.agents]
    if plugin_agents:
        existing = {a.name: a for a in (config.agents or ())}
        merged = {a.name: a for a in plugin_agents}
        merged.update(existing)
        config = replace(config, agents=tuple(merged.values()))

    # 2. skills
    plugin_skills = [s for p in loaded_plugins for s in p.skills]
    if plugin_skills:
        existing = {s.name: s for s in (config.skills or ())}
        merged = {s.name: s for s in plugin_skills}
        merged.update(existing)
        config = replace(config, skills=tuple(merged.values()))

    # 3. mcp_servers
    plugin_mcp: dict = {}
    for p in loaded_plugins:
        plugin_mcp.update(p.mcp_servers)
    if plugin_mcp:
        existing_mcp = dict(config.mcp_servers) if config.mcp_servers else {}
        merged_mcp = {**plugin_mcp, **existing_mcp}
        config = replace(config, mcp_servers=merged_mcp)

    return config
