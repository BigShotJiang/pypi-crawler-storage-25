"""spacecraft — reserved. Install modelreins-worker instead.

See https://modelreins.com/docs/sdk/python
"""
raise ImportError(
    "spacecraft is a reserved name guard. "
    "Install the real package: pip install modelreins-worker"
)
