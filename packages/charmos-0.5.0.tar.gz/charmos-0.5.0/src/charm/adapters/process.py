import json
import os
import subprocess
import threading
from typing import Any, Dict, List, Optional

from ..core.logger import logger
from .base import BaseAdapter


class CharmProcessAdapter(BaseAdapter):
    """
    Adapter for running external processes (e.g., Node.js, Go).
    It writes the input to 'input.json' and executes the entry_point command.
    """

    def __init__(self, command: str):
        self.command = command
        super().__init__(None)

    def invoke(
        self, inputs: Dict[str, Any], callbacks: Optional[List[Any]] = None
    ) -> Dict[str, Any]:
        logger.info(f"Executing Process Agent via command: {self.command}")

        # Prepare Input Payload
        input_path = os.path.join(os.getcwd(), "input.json")
        native_input = inputs.copy()

        try:
            with open(input_path, "w", encoding="utf-8") as f:
                json.dump(native_input, f, ensure_ascii=False)
        except Exception as e:
            return {"status": "error", "message": f"Failed to write input.json: {e}"}

        # Execute Command
        try:
            process = subprocess.Popen(
                self.command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env={**os.environ, "CHARM_INPUT_FILE": input_path},
            )

            stdout_lines: List[str] = []
            stderr_lines: List[str] = []

            # Stream output in real-time
            def read_stream(stream, collection, is_err=False):
                for line in stream:
                    collection.append(line)
                    print(line, end="")

            t_out = threading.Thread(target=read_stream, args=(process.stdout, stdout_lines))
            t_err = threading.Thread(target=read_stream, args=(process.stderr, stderr_lines))

            t_out.start()
            t_err.start()

            process.wait()
            t_out.join()
            t_err.join()

            if process.returncode != 0:
                return {
                    "status": "error",
                    "message": f"Process exited with code {process.returncode}",
                    "stderr": "".join(stderr_lines),
                }

            # Retrieve Output
            return {
                "status": "success",
                "output": "".join(stdout_lines),
                "message": "Process execution finished.",
            }

        except Exception as e:
            logger.error(f"Process Execution Error: {e}")
            return {"status": "error", "message": str(e)}
