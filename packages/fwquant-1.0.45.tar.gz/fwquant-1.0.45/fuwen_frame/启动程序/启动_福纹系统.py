import os

# 导入语言设置模块
import sys

from fuwen_backtest_single import SingleBacktesterApp
from fuwen_ctastrategy import CtaStrategyApp
from fuwen_frame.公共库.语言 import _
from fuwen_adaptor.event import EventEngine
from fuwen_adaptor.trader.ui import create_qapp
from fuwen_datamanager import DataManagerApp
from fuwen_okx import OkxGateway
from fuwen_riskmanager import RiskManagerApp

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from PySide6 import QtCore

# ===== 导入需要的应用与网关 =====

from fuwen_frame.gateway.fw_adaptor.trader.engine import fw_MainEngine

from fuwen_frame.gateway.fw_ctp.ctp_gateway import fw_CtpGateway
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.公共库.登录自动连接 import 登录自动连接网关, 登录自动连接SIMNOW网关

# fw继承 后的引用
from fuwen_frame.gateway.fw_riskmanager import fw_RiskManagerApp
from fuwen_frame.gateway.fw_okx import fw_OkxGateway
from fuwen_frame.gateway.fw_adaptor.trader.ui.mainwindow import fw_MainWindow

IS_AUTO_LOGIN = False
AUTO_SIMNOW_USDT = "247672"


# ===== 主函数：程序启动入口 =====
def main():
    """"""
    # ===== 初始环境 =====
    qapp = create_qapp()  # 创建基于PyQt5/6的GUI应用
    event_engine = EventEngine()  # 创建事件引擎，负责事件派发和处理
    main_engine = fw_MainEngine(event_engine)  # 创建主引擎，传入事件引擎

    logger.设置主引擎(main_engine)

    # ===== 添加交易所网关 =====
    main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="CTP")  # 添加 CTP 交易所网关
    main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="SIMNOW-247672")  # 添加 CTP 交易所网关
    # main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="SIMNOW-245004")  # 添加 CTP 交易所网关
    main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="SIMNOW_7x24-247672")  # 添加 CTP 交易所网关
    # main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="SIMNOW_7x24-245004")  # 添加 CTP 交易所网关
    # main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="yinhe-demo")  # 添加 CTP 交易所网关
    # main_engine.add_gateway(gateway_class=fw_CtpGateway, gateway_name="yinhe-demo-163")  # 添加 CTP 交易所网关
    main_engine.add_gateway(gateway_class=fw_OkxGateway, gateway_name="OKX")  # 添加 OKX 交易所网关（）
    main_engine.add_gateway(gateway_class=OkxGateway, gateway_name="OKX-old")  # 添加 OKX 交易所网关（）

    # main_engine.add_gateway(BinanceLinearGateway)  # 添加 binance 交易所网关 （USDT本位永续合约）
    # main_engine.add_gateway(BinanceInverseGateway)  # 添加 binance 交易所网关 （币本位合约）

    main_engine.add_app(CtaStrategyApp)  # 添加 CTA 策略模块
    main_engine.add_app(SingleBacktesterApp)  # 添加 CTA 回测模块
    main_engine.add_app(DataManagerApp)  # 添加 数据管理模块
    # main_engine.add_app(DataRecorderApp)  # 添加 数据记录应用

    # main_engine.add_app(fw_RiskManagerApp)  # 添加 风控管理应用     原：RiskManagerApp
    main_engine.add_app(RiskManagerApp)  # 添加 风控管理应用     原：RiskManagerApp

    # main_engine.add_app(ScriptTraderApp)  # 添加 脚本交易应用
    # main_engine.add_app(WebTraderApp)       #web交易模块

    # ===== 初始化主界面 =====
    main_window = fw_MainWindow(main_engine, event_engine)  # 创建主界面窗口
    main_window.showMaximized()  # 窗口最大化显示

    # ===== 关键：延迟自动连接OKX（确保界面加载完成） =
    if IS_AUTO_LOGIN == True:
        QtCore.QTimer.singleShot(1000, lambda: 登录自动连接网关(主引擎=main_engine, 网关名称="OKX"))
        # 登录自动连接网关(主引擎=main_engine, 网关名称="OKX")
        if AUTO_SIMNOW_USDT != "":
            登录自动连接SIMNOW网关(主引擎=main_engine, 环境1=F"SIMNOW-{AUTO_SIMNOW_USDT}",
                                   环境2_7X24=F"SIMNOW_7x24-{AUTO_SIMNOW_USDT}")
        # 登录自动连接SIMNOW网关(主引擎=main_engine, 环境1="SIMNOW-245004", 环境2_7X24="SIMNOW_7x24-245004")

    # ===== 启动程序 =====
    qapp.exec()  # 启动Qt事件循环，进入GUI主程序


# ===== 程序启动 =====
if __name__ == "__main__":
    print("工作目录:", os.getcwd())
    print("PYTHONPATH:", os.environ.get("PYTHONPATH"))
    print("日志级别:", logger.level_name)  # 打印当前日志级别
    logger.set_level("INFO")  # 设置日志级别为INFO
    logger.info(_("fuwen_adaptor 交易终端启动中..."), gateway_name="")
    main()  # 调用主函数，启动整个交易终端
    logger.info(_("fuwen_adaptor 交易终端退出"), gateway_name="")
