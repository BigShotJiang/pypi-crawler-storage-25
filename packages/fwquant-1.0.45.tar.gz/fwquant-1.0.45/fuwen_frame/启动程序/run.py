from fuwen_adaptor.event import EventEngine

from fuwen_adaptor.trader.engine import MainEngine
from fuwen_adaptor.trader.ui import MainWindow, create_qapp

# from fw_ctp import CtpGateway
# from fuwen_ctptest import CtptestGateway
# from fuwen_mini import MiniGateway
# from fuwen_femas import FemasGateway
# from fuwen_sopt import SoptGateway
# from fuwen_uft import UftGateway
# from fuwen_esunny import EsunnyGateway
# from fuwen_xtp import XtpGateway
# from fuwen_tora import ToraStockGateway, ToraOptionGateway
# from fuwen_ib import IbGateway
# from fuwen_tap import TapGateway
# from fuwen_da import DaGateway
# from fuwen_rohon import RohonGateway
# from fuwen_tts import TtsGateway

# from fuwen_paperaccount import PaperAccountApp
from fuwen_ctastrategy import CtaStrategyApp
from fuwen_backtest_single import SingleBacktesterApp
# from fuwen_spreadtrading import SpreadTradingApp
# from fuwen_algotrading import AlgoTradingApp
# from fuwen_optionmaster import OptionMasterApp
# from fuwen_backtest_multi import MultiBacktestApp
# from fuwen_scripttrader import ScriptTraderApp
# from fuwen_chartwizard import ChartWizardApp
# from fuwen_rpcservice import RpcServiceApp
# from fuwen_excelrtd import ExcelRtdApp
from fuwen_datamanager import DataManagerApp


# from fuwen_datarecorder import DataRecorderApp
# from fw_riskmanager import RiskManagerApp
# from fuwen_webtrader import WebTraderApp
# from fuwen_portfoliomanager import PortfolioManagerApp


def main():
    """"""
    qapp = create_qapp()

    event_engine = EventEngine()

    main_engine = MainEngine(event_engine)

    # main_engine.add_gateway(CtpGateway)
    # main_engine.add_gateway(CtptestGateway)
    # main_engine.add_gateway(MiniGateway)
    # main_engine.add_gateway(FemasGateway)
    # main_engine.add_gateway(SoptGateway)
    # main_engine.add_gateway(UftGateway)
    # main_engine.add_gateway(EsunnyGateway)
    # main_engine.add_gateway(XtpGateway)
    # main_engine.add_gateway(ToraStockGateway)
    # main_engine.add_gateway(ToraOptionGateway)
    # main_engine.add_gateway(IbGateway)
    # main_engine.add_gateway(TapGateway)
    # main_engine.add_gateway(DaGateway)
    # main_engine.add_gateway(RohonGateway)
    # main_engine.add_gateway(TtsGateway)

    # main_engine.add_app(PaperAccountApp)
    main_engine.add_app(CtaStrategyApp)
    main_engine.add_app(SingleBacktesterApp)
    # main_engine.add_app(SpreadTradingApp)
    # main_engine.add_app(AlgoTradingApp)
    # main_engine.add_app(OptionMasterApp)
    # main_engine.add_app(MultiBacktestApp)
    # main_engine.add_app(ScriptTraderApp)
    # main_engine.add_app(ChartWizardApp)
    # main_engine.add_app(RpcServiceApp)
    # main_engine.add_app(ExcelRtdApp)

    main_engine.add_app(DataManagerApp)

    # main_engine.add_app(DataRecorderApp)

    # main_engine.add_app(RiskManagerApp)

    # main_engine.add_app(WebTraderApp)
    # main_engine.add_app(PortfolioManagerApp)

    main_window = MainWindow(main_engine, event_engine)
    main_window.showMaximized()

    qapp.exec()


if __name__ == "__main__":
    main()
