# 语言模块 - 支持中文和英文切换
import gettext
import os
import json
from pathlib import Path

from fuwen_config.常量 import 福纹配置文件路径, 福纹配置目录


# 优先从配置文件读取语言设置
def get_language_setting():
    """
    从配置文件读取语言设置
    
    :return: 语言代码，如 "zh" 或 "en"
    """
    # 配置文件路径
    config_paths = [
        Path(福纹配置文件路径),
        Path(福纹配置目录)
    ]

    for config_path in config_paths:
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    language = config.get("language", "zh")
                    # 统一语言代码格式
                    if language == "zh":
                        return "zh_CN"
                    return language
            except Exception as e:
                print(f"读取配置文件失败: {e}")

    # 默认返回中文
    return "zh_CN"


# 获取语言设置
LANGUAGES = get_language_setting()

# 设置环境变量
os.environ["LANG"] = LANGUAGES
os.environ["LANGUAGE"] = LANGUAGES
os.environ["LC_ALL"] = LANGUAGES
os.environ["LC_MESSAGES"] = LANGUAGES

# 导入 fuwen_adaptor 原生翻译
try:
    from fuwen_adaptor.trader.ui.qt import _ as fuwen_trans
except:
    fuwen_trans = lambda s: s


def load_custom_translation():
    """加载自定义翻译：优先用你的，没有就用 fuwen_adaptor"""

    localedir = os.path.join(os.path.dirname(__file__), "locale")

    # 加载翻译
    try:
        # 尝试加载指定语言的翻译
        custom_trans = gettext.translation(
            domain="messages",
            localedir=localedir,
            languages=[LANGUAGES],
            fallback=True
        )
    except Exception as e:
        print(f"加载翻译失败: {e}")
        custom_trans = None

    # 最终翻译函数
    def _(message):
        # 1. 优先用自定义翻译
        if custom_trans:
            try:
                trans_text = custom_trans.gettext(message)
                if trans_text != message:
                    return trans_text
            except Exception:
                pass

        # 2. 没有 → 用 fuwen_adaptor 原生翻译
        try:
            return fuwen_trans(message)
        except Exception:
            return message

    return _


# 全局翻译函数
_ = load_custom_translation()

# ====================== 测试 ======================
if __name__ == "__main__":
    # 配置文件位置：
    print("=" * 50)
    print(f"当前语言设置: [{LANGUAGES}]")
    print(_("Connect"))  # 测试翻译
    print(_("确认退出？"))  # 测试中文
    print(_("My Strategy"))  # 测试英文
    print(_("Auto Trading"))  # 测试英文
    print("=" * 50)
