import traceback
from datetime import datetime

from PySide6 import QtWidgets
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_adaptor.event import EventEngine
from fuwen_adaptor.trader.constant import Direction, Offset, OrderType
from fuwen_adaptor.trader.engine import MainEngine
from fuwen_adaptor.trader.gateway import BaseGateway
from fuwen_adaptor.trader.object import OrderRequest, SubscribeRequest


class fw_MainEngine(MainEngine):
    def __init__(self, event_engine: EventEngine):
        super().__init__(event_engine)

    # 一键全平功能
    def close_all_positions(self):
        """
        fuwen_adaptor 全平台通用 一键全平
        自动平掉所有当前持仓
        """
        logger.info("【一键全平】开始执行平掉所有持仓...")
        positions = self.get_all_positions()

        if not positions:
            logger.info("【一键全平】无任何持仓需要平仓")
            return

        icount = 0
        for pos in positions:
            if pos.volume == 0:
                continue
            icount = icount + 1
            direction = Direction.SHORT if pos.direction == Direction.LONG else Direction.LONG
            req: OrderRequest = OrderRequest(
                symbol=pos.symbol,
                exchange=pos.exchange,
                direction=direction,
                offset=Offset.CLOSE,
                type=OrderType.MARKET,
                price=0,
                volume=pos.volume,
                reference="ManualTrading",
            )

            gateway_name = pos.gateway_name

            self.send_order(req=req, gateway_name=gateway_name)
            logger.info(f"【一键全平】第{icount}个持仓已平仓：{pos.fw_symbol}")
            # logger.info(f"【一键全平】已平仓：{pos.fw_symbol} 方向:{pos.direction} 数量:{pos.volume}")

        logger.info("【一键全平】所有平仓指令已全部发出！")

    def 断开网关(self, gateway_name: str = None):
        """断开当前选中的网关连接"""
        result_msg = {}
        if not gateway_name:
            result_msg = {"success": False, "code": 1, "msg": "未指定网关名称"}
            return result_msg

        result_msg = self._close_gateway(self, gateway_name)
        return result_msg

    def send_order(self, req: OrderRequest, gateway_name: str) -> str:
        gateway: BaseGateway | None = self.get_gateway(gateway_name)
        if gateway:
            # self.write_log(_("委托下单 -> {}：{}").format(gateway_name, req))        # 翻译 用中文日志  国际化翻译函数（i18n）
            logger.info(msg=f"【委托下单】 -> {gateway_name}：{req}", gateway_name=gateway_name)

            result = gateway.send_order(req)
            return result
        else:
            return ""

    def subscribe(self, req: SubscribeRequest, gateway_name: str) -> None:
        gateway: BaseGateway | None = self.get_gateway(gateway_name)
        try:
            gateway.subscribe(req)
            logger.info(msg=f"【订阅行情】：{req}", gateway_name=gateway_name)
        except Exception as e:
            logger.error(msg=f"【订阅行情】失败：{e},traceback={traceback.format_exc()}", gateway_name=gateway_name)

    # ==================== 断开接口（安全登出版 - 只退出账号，不崩fuwen） ====================
    # ==================== 断开接口（安全登出版 - 只退出账号，不崩fuwen） ====================
    def _close_gateway(self, main_engine: MainEngine, gateway_name: str) -> dict:
        """
        安全登出网关账号（不关闭网关，不崩溃）
        清理持仓/委托/成交数据 + 触发界面刷新
        """
        # 1. 获取网关
        gateway = main_engine.get_gateway(gateway_name)
        if gateway is None:
            return {"success": True, "code": 2, "msg": f"网关 {gateway_name} 不存在"}

        # 2. 检查是否已登录
        oms_engine = main_engine.engines.get('oms')
        if not oms_engine or oms_engine.accounts == {}:
            return {"success": True, "code": 3, "msg": f"网关 {gateway_name} 未登录账号！"}

        try:
            # ==================== 核心：只登出账号，不调用 gateway.close() ====================
            # 安全登出，适配所有fuwen标准网关
            if hasattr(gateway, 'logout'):
                gateway.logout()
            elif hasattr(gateway, 'logout_account'):
                gateway.logout_account()
            elif hasattr(gateway, 'user_logout'):
                gateway.user_logout()

            # 3. 清理该网关的交易数据（持仓、委托、成交、账号）
            self._clear_gateway_data(main_engine, gateway_name)

            # 4. 修复：正确触发fuwen界面刷新（绝对不报错）
            from fuwen_adaptor.event import Event
            main_engine.event_engine.put(Event("EVENT_REFRESH"))

            return {
                "success": True,
                "code": 0,
                "msg": f"网关 {gateway_name} 账号已安全登出，数据已清理"
            }

        except Exception as e:
            return {
                "success": False,
                "code": 5,
                "msg": f"登出失败: {str(e)}"
            }

    def _clear_gateway_data(self, main_engine: MainEngine, gateway_name: str):
        """
        清理指定网关的交易缓存数据（持仓、委托、成交、账号）
        """
        oms_engine = main_engine.engines['oms']

        # 清理持仓
        oms_engine.positions = {
            key: pos for key, pos in oms_engine.positions.items()
            if pos.gateway_name != gateway_name
        }

        # 清理委托
        oms_engine.orders = {
            key: order for key, order in oms_engine.orders.items()
            if order.gateway_name != gateway_name
        }

        # 清理成交
        oms_engine.trades = {
            key: trade for key, trade in oms_engine.trades.items()
            if trade.gateway_name != gateway_name
        }

        # 清理账号
        oms_engine.accounts = {
            key: account for key, account in oms_engine.accounts.items()
            if account.gateway_name != gateway_name
        }
