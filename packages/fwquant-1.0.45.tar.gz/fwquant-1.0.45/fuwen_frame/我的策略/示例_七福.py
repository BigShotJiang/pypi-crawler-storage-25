import os
import platform
import sqlite3
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd
from fuwen_ctastrategy import CtaTemplate, StopOrder

from fuwen_signal.fw_signal.信号工厂.七福 import 七福信号引擎
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.策略函数.策略常量 import SETTING_PATH
from fuwen_frame.我的策略.策略函数.回测交易记录器 import 回测交易记录器类

from fuwen_adaptor.trader.object import TickData, BarData, OrderData, TradeData
from fuwen_adaptor.trader.utility import BarGenerator, ArrayManager, get_folder_path

# 保持原有的全局变量和函数定义
交易对 = 'HK.MHI2602'
止损比例 = 0.2
RET_OK = 0
IS_DEBUG = False

写数据库 = False


class 示例_七福类(CtaTemplate):
    """完整的CTA策略类"""

    author = "七福_策略"
    缓存k线_最大保存数量 = 150

    # 策略参数
    均线快周期 = 5  # MA5
    均线中周期 = 20  # MA20
    均线慢周期 = 60  # MA60

    止盈回撤比例 = 0.5  # 50%止盈比例
    止损比例 = 0.3

    下单数量 = 1
    最大持仓量 = 2
    开仓成功N分钟后才允许平仓 = 5  # N周期 后才允许平仓

    # other
    n个周期内查找低点 = 30
    当前k线时间 = None
    当前K线索引 = 0
    总K线数量 = 0
    回测引擎: None

    # 策略变量
    订单_id = ''
    仓位 = {'持仓数量': 0, '开仓时间': '', '方向': '', '开仓价格': 0.0, '委托时间': None}
    显示列表 = ['author', '均线快周期', '均线中周期', '均线慢周期', '止盈回撤比例', '下单数量', '最大持仓量']
    parameters = 显示列表

    _开仓次数 = 0
    _平仓次数 = 0

    def __init__(self, cta_engine: Any, strategy_name: str, fw_symbol: str, setting: dict):
        """初始化策略"""
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)

        self.缓存k线_最大保存数量 = 150
        self.当前k线_1分钟 = None
        self._初始化七福对象()
        self.回测任务ID = None

        # 添加交易记录器
        self.策略名称 = strategy_name
        self.交易记录器 = 回测交易记录器类(策略名称=strategy_name)
        self.交易记录_开仓 = []
        self.交易记录_平仓 = []

        # 策略
        self.策略开启时间 = None
        self.策略停止时间 = None

        # K线合成器（用于合成1分钟K线）
        self.bg1 = BarGenerator(self.on_bar, window=1, on_window_bar=self.处理1分钟合成K线)

        # 1分钟K线数据
        self.bar_data = []  # 存储BarData对象
        self.bar_k_lines_df = pd.DataFrame()  # 缓存DataFrame格式数据       K线缓存

        self.当前k线 = None
        self.当前k线时间_1分钟 = None
        self.进度百分比 = 0

        # 初始化数组管理器（可选）
        self.am = ArrayManager(size=120)

        # ========== 新增：缓存回测引擎引用 ==========
        self._缓存回测引擎引用()

    def _缓存回测引擎引用(self):
        """修正：正确获取回测引擎对象引用"""
        # 重置回测引擎引用
        self.回测引擎 = None

        # fuwen回测引擎的正确层级路径（从CTA引擎向上查找）
        engine = self.cta_engine

        # 层级1: 直接在cta_engine中
        if hasattr(engine, 'backtesting_engine') and engine.backtesting_engine:
            self.回测引擎 = engine.backtesting_engine
        # 层级2: 在main_engine中
        elif hasattr(engine, 'main_engine') and hasattr(engine.main_engine, 'backtesting_engine'):
            self.回测引擎 = engine.main_engine.backtesting_engine
        # 层级3: 在engine子属性中
        elif hasattr(engine, 'engine') and hasattr(engine.engine, 'backtesting_engine'):
            self.回测引擎 = engine.engine.backtesting_engine

        # 调试输出：确认是否获取到引擎
        if self.回测引擎:
            logger.debug(f"成功获取回测引擎: {type(self.回测引擎)}")
        else:
            logger.debug("未能获取回测引擎对象")

    def _获取七福参数配置(self, 更新参数=None) -> Dict[str, Any]:

        if 更新参数 is None:
            更新参数 = {}
        res_配置 = {
            '订单_id': self.订单_id,
            '仓位': self.仓位,
            '最大持仓量': self.最大持仓量,
            '持仓数量': self.pos,  # 20260313  暂时直接使用 fuwen_adaptor 引擎的持仓数量

            '均线快周期': self.均线快周期,
            '均线中周期': self.均线中周期,
            '均线慢周期': self.均线慢周期,
            '止盈回撤比例': self.止盈回撤比例,
            '止损比例': self.止损比例,
            '开仓成功N分钟后才允许平仓': self.开仓成功N分钟后才允许平仓,
            'n个周期内查找低点': self.n个周期内查找低点,

            '当前k线': None,
            '历史k线': None,

            '当前k线时间': self.当前k线时间,
            '当前k线索引': self.当前K线索引,
            '总K线数量_回测': self.总K线数量
        }
        if 更新参数 and isinstance(更新参数, dict):
            res_配置.update(更新参数)
        return res_配置

    def _初始化七福对象(self):
        参数 = self._获取七福参数配置()
        self.七福对象 = 七福信号引擎(参数=参数)

        # 判断是否回测环境
        # if self.cta_engine.gateway_name == '回测':
        if self.cta_engine.get_engine_type().value in ['回测']:
            数量 = len(self.cta_engine.history_data)
            if 数量 > 0:
                历史k线_全量_回测 = self.获得当前回测引擎所有历史数据_df(self.cta_engine.history_data)
                参数['历史k线_全量_回测'] = 历史k线_全量_回测
                self.七福对象.更新历史k线_全量_回测(全量历史k线=历史k线_全量_回测)

    def on_init(self) -> None:
        """策略初始化"""
        self._初始化七福对象()

        self._平仓次数 = 0
        self._开仓次数 = 0
        self.交易记录_开仓 = []
        self.交易记录_平仓 = []

        self._初始化七福对象()
        if self.cta_engine.get_engine_type().value in ['回测']:
            self.总K线数量 = len(self.cta_engine.history_data)
        else:
            self.总K线数量 = -1
        logger.debug("策略初始化")

    def on_start(self) -> None:
        """策略启动"""

        self._初始化七福对象()

        self.策略开启时间 = datetime.now()
        logger.info(f"{'=' * 20}策略启动{'=' * 20}")

        # 创建回测任务
        if self.cta_engine.get_engine_type().value in ['回测']:
            result_创建回测任务 = self.创建回测任务()
            logger.debug(f"创建回测任务结果: {result_创建回测任务}")

        self.put_event()  # 触发策略事件，更新显示

    def on_stop(self) -> None:
        """策略停止（增强版，添加统计导出）"""
        self.策略停止时间 = datetime.now()
        logger.info(f"{'=' * 20}策略停止{'=' * 20}")

        # ========== 新增：延迟获取统计数据 ==========
        # time.sleep(2)  # 延迟2秒，确保回测引擎完成最终计算            20260316 暂时先注释

        # 更新回测任务
        if self.cta_engine.get_engine_type().value in ['回测']:
            result_更新回测任务 = self.更新回测任务()
            logger.debug(f"更新回测任务结果: {result_更新回测任务}")

        # 导出交易记录
        result_导出交易记录 = self._导出交易记录()
        logger.debug(f"导出交易记录结果: {result_导出交易记录}")

        logger.info(f"{'=' * 20}策略已完全停止{'=' * 20}")
        logger.info(f"策略共用时：{self.策略停止时间 - self.策略开启时间}秒")
        self.put_event()  # 触发策略事件，更新显示

    def on_tick(self, tick: TickData) -> None:
        """Tick数据更新"""
        self.bg1.update_tick(tick)

    def on_bar(self, bar: BarData) -> None:
        self.当前k线时间 = datetime.strftime(bar.datetime, '%Y-%m-%d %H:%M')
        if self.当前k线时间 in ['2026-02-03 10:28']:
            print(f"当前k线时间：{self.当前k线时间}")

        self.当前k线 = bar
        self.当前K线索引 += 1
        if self.总K线数量 == 0:
            self.总K线数量 = len(self.cta_engine.history_data)

        if self.总K线数量 != 0:
            当前进度百分比 = round((self.当前K线索引 / self.总K线数量) * 100, 0)
            if self.进度百分比 != 当前进度百分比:
                self.进度百分比 = 当前进度百分比
                # print(f"进度百分比：{self.进度百分比:.2f}%")

        """1分钟Bar数据更新"""
        # 更新K线合成器
        self.bg1.update_bar(bar)

        # 保存到bar_data列表
        self.bar_data.append(bar)

        # 保持bar_data的长度（最多保留最近500根K线）
        if len(self.bar_data) > self.缓存k线_最大保存数量:
            self.bar_data = self.bar_data[-self.缓存k线_最大保存数量:]

        # 更新缓存DataFrame
        self.更新缓存DataFrame()

        # 更新数组管理器
        self.am.update_bar(bar)

        logger.debug(f"1分钟Bar数据更新: {bar.fw_symbol} {bar.datetime} {bar.close_price} {bar.volume}")

    def on_order(self, order: OrderData) -> None:
        """委托更新"""
        if order.is_active():
            return
        self.仓位['委托时间'] = order.datetime
        logger.debug(f"委托更新: {order.vt_orderid} {order.direction.value} {order.offset.value} "
                     f"{order.status.name} @{order.price} {order.volume}")
        self.put_event()

    def on_trade(self, trade: TradeData) -> None:
        super().on_trade(trade)

        """成交更新"""
        # 同步更新自定义仓位状态
        if trade.offset.value in ["CLOSE", "CLOSETODAY", "CLOSEYESTERDAY"]:
            self.订单_id = ""
            self.仓位['持仓数量'] = 0  # 强制清空自定义持仓
            self.仓位['平仓时间'] = trade.datetime
            self.仓位['平仓成交价格'] = trade.price
        else:
            # 开仓成交时更新
            self.仓位['持仓数量'] = int(self.pos)
            self.仓位['开仓时间'] = trade.datetime
            self.仓位['开仓成交价格'] = trade.price

        logger.debug(f"成交更新: {trade.vt_orderid} {trade.direction.value} {trade.offset.value} "
                     f"@{trade.price} {trade.volume}")
        self.put_event()

    def on_stop_order(self, stop_order: StopOrder) -> None:
        """停止单更新"""
        pass
        logger.debug(f"停止单更新:  {stop_order.direction.value} {stop_order.offset.value} "
                     f"{stop_order.status.name} @{stop_order.price} {stop_order.volume}")

    def 处理1分钟合成K线(self, bar: BarData) -> None:
        if self.当前k线时间 in ['2026-02-03 10:28']:
            print(f"当前k线时间：{self.当前k线时间}")

        return
        """1分钟合成K线"""
        self.当前k线_1分钟 = bar  # 获取当前时间
        self.当前k线时间_1分钟 = bar.datetime.strftime("%Y-%m-%d %H:%M:%S")

        # 更新持仓价格和状态
        if self.仓位['持仓数量'] != int(self.pos):
            self.仓位['持仓数量'] = int(self.pos)

        res_回测_更新k线的N种方法 = self.回测_更新k线的N种方法(方法="增量")
        if res_回测_更新k线的N种方法:
            # 检查是否应该开仓   暂不支持多仓   20260209
            if abs(int(self.pos)) == 0:
                self._开仓_判断(self.七福对象)  # 执行 _开仓_判断
            # 如果有持仓，执行平仓检查
            if abs(int(self.pos)) > 0 and self.订单_id != '':
                self._平仓_判断(self.七福对象)  # 执行 _平仓_判断
        # 更新事件
        self.put_event()

    def 回测_更新k线的N种方法(self, 方法="增量"):
        # 准备数据---准备数据---准备数据---准备数据---准备数据---准备数据---准备数据---准备数据---准备数据
        ret, f历史k线 = self.获取历史K线(数量=120, 周期="K_1M")  # 120
        if ret != 0 and ret != '0':
            logger.debug(f"获取历史K线失败: {ret}")
            return False
        新k线 = f历史k线[-1:]

        # 这里是影响性能最严重的地方之一，，，，核心影响效率的地方，请优化，，20260316.。
        # ============ sta ================
        if 方法 in ["方法1", '历史数据']:
            # 方法一，历史数据      每次传历史数据，效率最低
            七福参数 = self._获取七福参数配置(更新参数={'当前k线': 新k线, '历史k线': f历史k线, })
            self.七福对象.设置参数(参数=七福参数)
            # ============ end ================
        elif 方法 in ["方法2", '增量']:
            # 方法二，增量        更新历史k线和当前k线
            self.七福对象.追加历史k线(新k线=新k线)
            self.七福对象.更新当前k线(当前k线=新k线)
        elif 方法 in ["方法3", '回测']:
            # 方法三，回测        专为回测的接口
            self.七福对象.设置当前k线_回测(当前k线=新k线)
        return True

    def _开仓_判断(self, 七福对象):
        参数 = 七福对象.获取参数()
        参数['持仓数量'] = self.pos
        参数['仓位']['持仓数量'] = self.pos
        result = 七福对象.开仓检测(参数=参数)
        开仓id = int(result.get("id", "0"))
        if 开仓id in [1001, 1003] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"
            下单价格 = result['价格'] if result['价格'] else 七福对象._参数['当前k线'].close.iloc[0]
            备注 = result['判断详情']
            self.仓位['方向'] = '多头'
            order_ret, order_data = self.开仓(方向="buy", 价格=下单价格, 数量=self.下单数量, 原因=原因,
                                              备注=备注)  # 执行开仓
            logger.debug(f"【开仓】多头，下单价格={下单价格:.2f}, 下单数量={self.下单数量}, 原因={原因}, "
                         f"order_ret={order_ret}, order_data={order_data}")
        if 开仓id in [1002, 1004] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"
            下单价格 = result['价格'] if result['价格'] else 七福对象._参数['当前k线'].close.iloc[0]
            备注 = result['判断详情']
            self.仓位['方向'] = '空头'
            order_ret, order_data = self.开仓(方向="sell", 价格=下单价格, 数量=self.下单数量, 原因=原因,
                                              备注=备注)  # 执行开仓
            logger.debug(f"【开仓】空头，下单价格={下单价格:.2f}, 下单数量={self.下单数量}, 原因={原因}, "
                         f"order_ret={order_ret}, order_data={order_data}")

    def _平仓_判断(self, 七福对象):
        result = {"success": False, "msg": ""}
        result_平仓规则 = 七福对象.平仓判断(参数=七福对象.获取参数())
        平仓规则 = result_平仓规则.get("平仓规则", None)
        if not 平仓规则 is None:
            推荐平仓方向 = 平仓规则.get('推荐平仓方向', '')
            推荐平仓价格 = 平仓规则.get('推荐平仓价格', 0.0)
            推荐平仓数量 = 平仓规则.get('推荐平仓数量', 0.0)
            平仓ID = result_平仓规则.get('id', '')
            备注 = result_平仓规则

            原因 = f"<{平仓ID}>{平仓规则['原因']}"
            code, 平仓详细 = self.平仓(价格=推荐平仓价格, 方向=推荐平仓方向, 数量=推荐平仓数量, 原因=原因,
                                       备注=备注)

            result = 平仓规则
            result['code'] = code
            result['msg'] = 平仓详细
            result['id'] = 平仓ID

            if code == RET_OK:
                result['success'] = True
            else:
                result['success'] = False

        return result

    def 更新缓存DataFrame(self):
        """更新K线数据缓存为DataFrame格式"""
        if not self.bar_data:
            return
        return  #20260407 tjw

        # 转换为DataFrame
        records = []
        for bar in self.bar_data:
            records.append({
                'open': bar.open_price,
                'high': bar.high_price,
                'low': bar.low_price,
                'close': bar.close_price,
                'volume': bar.volume,
                'time_key': bar.datetime
            })
        df = pd.DataFrame(records)
        self.bar_k_lines_df = df

    def 获得当前回测引擎所有历史数据_df(self, history_data) -> pd.DataFrame:
        """
        将fuwen的history_data转换为DataFrame

        参数:
            history_data: fuwen的K线历史数据列表，每个元素是BarData对象

        返回:
            pd.DataFrame: 包含指定字段的DataFrame，time_key设为索引，且格式化为标准时间
        """
        # 空数据校验
        if not history_data:
            print("警告：输入的历史数据为空！")
            return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'volume', 'time_key'])

        # 提取指定字段并构建数据列表
        data_list = []
        for bar in history_data:
            bar_dict = {
                'open': bar.open_price,
                'high': bar.high_price,
                'low': bar.low_price,
                'close': bar.close_price,
                'volume': bar.volume,
                'time_key': bar.datetime
            }
            data_list.append(bar_dict)

        # 转换为DataFrame
        df = pd.DataFrame(data_list)

        # 数据格式化优化（可选但推荐）
        # 1. 将time_key转换为datetime类型并设为索引
        df['time_key'] = pd.to_datetime(df['time_key'])
        df = df.set_index('time_key')

        # 2. 确保数值类型正确
        numeric_cols = ['open', 'high', 'low', 'close', 'volume']
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce')

        # 3. 按时间排序（确保数据有序）
        df = df.sort_index()

        return df

    def 获取历史K线(self, 数量: int = 120, 周期: str = "K_1M") -> tuple:
        """
        fuwen回测/实盘通用获取K线函数
        从bar_df_cache获取指定数量和周期的K线
        优化点：减少深拷贝、避免重复排序、优化重采样逻辑
        """
        # 预定义常量（类内可考虑提升为类常量）
        支持的周期 = {"K_1M": "1min", "K_3M": "3min", "K_5M": "5min"}

        # 1. 快速校验周期（字典查找比列表in操作更快）
        if 周期 not in 支持的周期:
            return -1, f"不支持的周期：{周期}，仅支持{list(支持的周期.keys())}"

        # 2. 快速检查数据是否为空（避免后续操作）
        if self.bar_k_lines_df.empty:
            return -2, "未加载任何K线数据"

        try:
            # 3. 只做一次浅拷贝（深拷贝在无修改时完全没必要）
            df = self.bar_k_lines_df.copy()

            # 4. 只排序一次且仅在需要时排序（假设原始数据大部分时间已排序）
            if not df.index.is_monotonic_increasing:
                df = df.sort_values('time_key')

            # 5. 计算实际需要返回的数据量（避免后续重复判断）
            实际数量 = min(数量, len(df))

            if 实际数量 < 数量:
                logger.debug(f"请求{数量}根K线，但缓存只有{实际数量}根")

            # 6. 优化不同周期的处理逻辑
            if 周期 == "K_1M":
                # 直接取最后N条，避免索引操作
                结果df = df.iloc[-实际数量:]
            else:
                # 重采样优化：只取需要的原始数据，减少计算量
                # 计算需要的原始1分钟K线数量（确保能生成足够的目标周期K线）
                原始数据量 = 实际数量 * int(支持的周期[周期][0]) + 5  # 加5个缓冲区
                原始数据量 = min(原始数据量, len(df))

                # 只取需要的原始数据进行重采样
                df_重采样 = df.iloc[-原始数据量:].set_index('time_key')

                # 重采样聚合（使用预定义的聚合规则）
                聚合规则 = {
                    'open': 'first',
                    'high': 'max',
                    'low': 'min',
                    'close': 'last',
                    'volume': 'sum'
                }
                结果df = df_重采样.resample(支持的周期[周期]).agg(聚合规则).dropna()

                # 只取最后N条结果
                结果df = 结果df.iloc[-实际数量:].reset_index()

            # 7. 统一处理列顺序和last_price（优化赋值方式）
            目标列 = ['open', 'high', 'low', 'close', 'volume', 'time_key']
            # 确保列存在（兼容不同数据源）
            结果df = 结果df.reindex(columns=目标列, fill_value=0)

            # 高效添加last_price列（避免.loc链式赋值）
            if not 结果df.empty:
                结果df['last_price'] = 结果df['close']

            return 0, 结果df

        except Exception as e:
            # 增加异常捕获，提升鲁棒性
            logger.debug(f"获取K线数据出错：{str(e)}")
            return -3, f"获取K线数据异常：{str(e)}"

    def 开仓(self, 价格=0, 方向: str = "buy", 数量: int = 1, 原因: str | Dict[str, Any] = "", 备注=None) -> tuple:
        """开仓函数（增强版，添加记录功能）"""
        self._开仓次数 = self._开仓次数 + 1
        print(f"{self._开仓次数},开仓函数：[{self.当前k线时间}],价格={价格}, 方向={方向}, 数量={数量}, 原因={原因}")
        ret11111111111111111111111, 开仓返回信息 = 0, ""

        try:
            # 获取引擎环境
            引擎环境 = self.获取引擎环境()

            if abs(self.pos) <= abs(self.最大持仓量):
                开仓成功订单号 = ""
                if 方向 in ("buy", "long"):
                    开仓成功订单号 = self.buy(价格, 数量)  # ==============开多==============
                elif 方向 in ("sell", "short"):
                    开仓成功订单号 = self.short(价格, 数量)  # ==============开空==============

                if 开仓成功订单号 != "":
                    ret11111111111111111111111 = 0
                    self.订单_id = 开仓成功订单号
                    self.仓位['开仓订单id'] = 开仓成功订单号
                    self.仓位['持仓数量'] = int(self.pos)
                    self.仓位['开仓数量'] = 数量
                    self.仓位['开仓价格'] = 价格
                    self.仓位['开仓方向'] = 方向
                    self.仓位['委托开仓时间'] = self.当前k线.datetime

                    开仓返回信息 = {'状态': 'success', '订单号': 开仓成功订单号, '方向': 方向, '价格': 价格,
                                    '数量': 数量, '原因': 原因}

                    # 记录开仓操作到数据库（仅回测环境）
                    if 引擎环境 == "回测":
                        try:
                            if isinstance(原因, (dict, list)):
                                # 原因_str = 原因.__str__()
                                # 原因_str = f"编号 ：{原因.get('id', '')},动作：开仓，方向:{方向},价格：{价格}，原因：{原因.get('判断详情', {}).get('最终说明', '')}"
                                原因_str = f"原因：{原因.get('id', '')},{原因.get('判断详情', {}).get('最终说明', '')}"
                            else:
                                原因_str = str(原因)

                            self._记录开仓(
                                订单号=开仓成功订单号,
                                交易品种=self.fw_symbol,
                                委托方向=方向,
                                操作价格=价格,
                                操作数量=数量,
                                操作时间=self.当前k线.datetime,
                                操作原因=原因_str,
                                持仓方向=方向,
                                开仓价格=价格,
                                当前持仓数量=数量,
                                备注信息=f"<判断详情>：{备注}"
                            )
                        except Exception as e:
                            logger.error(f"记录开仓操作失败: {str(e)}，treaback:{traceback.format_exc()}")

                else:
                    ret11111111111111111111111 = -1
                    开仓返回信息 = {'状态': 'failed', '订单号': 开仓成功订单号, '方向': 方向, '价格': 价格,
                                    '数量': 数量, '原因': 原因}
            else:
                ret11111111111111111111111 = -1
                开仓返回信息 = f"开仓失败: 超出最大持仓限制, 当前持仓: {self.pos}, 最大持仓: {self.最大持仓量}"

        except Exception as e:
            self.开仓平仓日志(f"开仓异常: {str(e)}，trackback: {traceback.format_exc()}")
            return -2, f"开仓异常: {str(e)}"
        finally:
            self.开仓平仓日志(f"开仓信息：data:{开仓返回信息}")
            return ret11111111111111111111111, 开仓返回信息

    def 平仓(self, 方向: str = "buy", 价格=0, 数量: int = 0, 原因: str | Dict[str, Any] = "", 备注=None):
        """平仓函数（增强版，添加记录功能）"""
        self._平仓次数 = self._平仓次数 + 1
        print(f"{self._平仓次数},平仓函数：[{self.当前k线时间}],价格={价格}, 方向={方向}, 数量={数量}, 原因={原因}")
        ret, 平仓返回信息 = 0, ""

        # 判断引擎环境
        引擎环境 = self.获取引擎环境()
        # if 引擎环境 == "回测":
        #     价格 = 0

        if 数量 == 0:
            数量 = abs(int(self.pos))

        平仓成功订单号 = ""

        # 获取开仓记录，用于关联交易
        开仓记录 = None
        if self.订单_id:
            开仓记录 = self.交易记录器.获取开仓记录(self.订单_id)

        if self.pos > 0:
            if 方向 in ("buy", "long"):
                平仓成功订单号 = self.sell(价格, 数量)  # ====核心代码 平多 =====================
            else:
                ret, 平仓返回信息 = -1, f"-1,平多失败: 持仓方向不匹配, 当前持仓: {self.pos}, 请求方向: {方向},原因:{原因}"
        elif self.pos < 0:
            if 方向 in ("sell", "short"):
                平仓成功订单号 = self.cover(价格, 数量)  # ====核心代码 平空 =====================
            else:
                ret, 平仓返回信息 = -2, f"-2,平空失败: 持仓方向不匹配, 当前持仓: {self.pos}, 请求方向: {方向}"
        else:
            ret, 平仓返回信息 = -3, f"-3,平仓失败: 无持仓, 当前持仓: {self.pos}, 请求方向: {方向}"

        if 平仓成功订单号 != "":
            ret = 0
            平仓返回信息 = {'order_id': 平仓成功订单号, '方向': 方向, '价格': 价格, '数量': 数量, '原因': 原因}

            # 更新持仓状态
            self.订单_id = ""
            self.仓位['平仓订单id'] = 平仓成功订单号
            self.仓位['平仓数量'] = 数量
            self.仓位['平仓价格'] = 价格
            self.仓位['平仓方向'] = 方向
            self.仓位['持仓数量'] = 0
            self.仓位['平仓下单时间'] = self.当前k线.datetime

            # 记录平仓操作到数据库（仅回测环境）
            if 引擎环境 == "回测":
                try:
                    if 原因 is dict:
                        原因_str = f"原因：{原因.get('id', '')},{原因.get('原因', '')}"
                    else:
                        原因_str = f"原因：{原因}"
                    平仓记录ID = self._记录平仓(
                        订单号=平仓成功订单号,
                        委托方向=方向,
                        交易品种=self.fw_symbol,
                        操作价格=价格,
                        操作数量=数量,
                        操作时间=self.当前k线.datetime,
                        操作原因=原因_str,
                        持仓方向=self.仓位.get('开仓方向', ''),
                        开仓价格=self.仓位.get('开仓价格', 0),
                        当前持仓数量=0,
                        备注信息=f"<判断详情>：{备注} "
                    )

                    # 如果有关联的开仓记录，记录完整的交易结果 开仓订单id
                    if 开仓记录 and 开仓记录.get('记录ID'):
                        self.交易记录器.记录交易结果(
                            开仓记录ID=开仓记录['记录ID'],
                            平仓记录ID=平仓记录ID,
                            开仓时间=开仓记录.get('操作时间'),
                            平仓时间=self.当前k线.datetime,
                            开仓价格=开仓记录.get('操作价格', 0),
                            平仓价格=价格,
                            开仓方向=开仓记录.get('持仓方向', ''),
                            操作数量=数量,
                            交易备注=str(原因)
                        )

                except Exception as e:
                    logger.error(f"记录平仓操作失败: {str(e)},traceback:{traceback.format_exc()}")

        self.开仓平仓日志(f"平仓信息：data:{平仓返回信息}")
        return ret, 平仓返回信息

    def 开仓平仓日志(self, msg: str) -> None:
        """写开仓平仓日志"""
        self.当前k线时间 = datetime.strftime(self.bar_k_lines_df['time_key'].iloc[-1], "%Y-%m-%d %H:%M:%S")
        msg = f"<开仓平仓日志>,[{self.当前k线时间}] ,msg={msg}"

        logger.info(msg)
        pass

    def 获取引擎环境(self):
        """判断当前是回测还是实盘"""
        # 回测
        # result = self.cta_engine.gateway_name

        result = self.cta_engine.get_engine_type().value
        return result

    def _导出交易记录(self):
        """
        导出交易记录（优化版：移除日志输出，返回结果信息）
        Returns:
            dict: 包含导出结果的字典，结构如下：
                {
                    "success": bool,       # 是否成功
                    "msg": str,        # 结果描述
                    "file_path": str|None, # 导出文件路径（成功且有记录时）
                 }
        """
        result = {"success": False, "msg": "", "file_path": None, }

        try:
            if self.获取引擎环境() == "回测":
                统计信息 = self.交易记录器.获取交易统计()
                if 统计信息["总交易数"] > 0:
                    文件路径 = self.交易记录器.导出交易记录()
                    result["success"] = True
                    result["msg"] = "交易记录导出成功"
                    result["file_path"] = 文件路径
                else:
                    result["success"] = True
                    result["msg"] = "没有交易记录需要导出"
            else:
                result["success"] = True
                result["msg"] = "非回测环境，无需导出交易记录"
        except Exception as e:
            result["success"] = False
            result["msg"] = f"导出交易记录失败,{str(e)}，trackback: {traceback.format_exc()}"

        return result

    def 创建回测任务(self):

        result = self.交易记录器.创建回测任务(
            cta_engine=self.cta_engine,
            strategy=self,
            回测名称=self.回测任务ID or self.策略名称,
            交易品种=self.cta_engine.symbol,
            初始资金=self.cta_engine.capital,
            手续费率=self.cta_engine.rate,
            滑点=self.cta_engine.risk_free,
            合约乘数=self.cta_engine.size,
            回测备注=f"七福策略回测-fuwen自带回测系统！"
        )
        self.回测任务ID = result.get('回测任务ID', None)

        return result

    def 更新回测任务(self):

        回测引擎 = self.回测引擎 or self.cta_engine
        result = self.交易记录器.更新回测任务(
            cta_engine=回测引擎,
            回测任务ID=self.回测任务ID,
            回测状态="已完成",
            回测备注=f"回测完成，总耗时：{self.策略停止时间 - self.策略开启时间}"
        )

        return result

    def _记录开仓(self, 订单号, 交易品种, 委托方向, 操作价格, 操作数量, 操作时间, 操作原因, 持仓方向, 开仓价格,
                  当前持仓数量, 备注信息):
        开仓记录ID = self.交易记录器.记录开仓操作(订单号=订单号, 交易品种=交易品种, 委托方向=委托方向,
                                                  操作价格=操作价格,
                                                  操作数量=操作数量, 操作时间=操作时间, 操作原因=操作原因,
                                                  持仓方向=持仓方向,
                                                  开仓价格=开仓价格, 当前持仓数量=当前持仓数量, 备注信息=备注信息)
        self.交易记录_开仓.append({
            "订单号": 订单号,
            "交易品种": 交易品种,
            "委托方向": 委托方向,
            "操作价格": 操作价格,
            "操作数量": 操作数量,
            "操作时间": 操作时间,
            "操作原因": 操作原因,
            "持仓方向": 持仓方向,
            "开仓价格": 开仓价格,
            "当前持仓数量": 当前持仓数量,
            "备注信息": 备注信息
        })
        return 开仓记录ID

    def _记录平仓(self, 订单号, 委托方向, 交易品种, 操作价格, 操作数量, 操作时间, 操作原因, 持仓方向, 开仓价格,
                  当前持仓数量, 备注信息):
        平仓记录ID = self.交易记录器.记录平仓操作(
            订单号=订单号,
            委托方向=委托方向,
            交易品种=交易品种,
            操作价格=操作价格,
            操作数量=操作数量,
            操作时间=操作时间,
            操作原因=操作原因,
            持仓方向=持仓方向,
            开仓价格=开仓价格,
            当前持仓数量=当前持仓数量,
            备注信息=备注信息
        )
        self.交易记录_平仓.append({
            "订单号": 订单号,
            "委托方向": 委托方向,
            "交易品种": 交易品种,
            "操作价格": 操作价格,
            "操作数量": 操作数量,
            "操作时间": 操作时间,
            "操作原因": 操作原因,
            "持仓方向": 持仓方向,
            "开仓价格": 开仓价格,
            "当前持仓数量": 当前持仓数量,
            "备注信息": 备注信息})

        return 平仓记录ID
