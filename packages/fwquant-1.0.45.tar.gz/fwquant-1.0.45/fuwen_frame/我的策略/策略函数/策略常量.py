import os
import fuwen_config as 福纹配置

SETTING_PATH = 福纹配置.福纹配置文件路径

if __name__ == '__main__':
    print(f"SETTING_PATH: [{SETTING_PATH}]")
