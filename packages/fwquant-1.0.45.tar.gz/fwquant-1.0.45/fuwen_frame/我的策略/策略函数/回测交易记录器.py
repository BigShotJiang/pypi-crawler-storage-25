import os
import platform
import sqlite3
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd

from fuwen_config import 常量, 福纹配置目录, 福纹配置目录名称
from fuwen_config.常量 import 缓存目录
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.策略函数.策略常量 import SETTING_PATH
from fuwen_adaptor.trader.utility import get_folder_path


class 回测交易记录器类:
    """SQLite回测交易记录器"""

    def __init__(self, 策略名称: str, 数据库路径: str = None):
        """
        初始化交易记录器

        Args:
            策略名称: 策略名称，用于创建表名
            数据库路径: SQLite数据库路径，默认在当前目录
        """
        self.当前回测任务ID = None
        self.策略名称 = f"{策略名称}-{str(uuid.uuid4())}"

        # ========== 核心：跨平台自动适配数据库路径 ==========
        if 数据库路径:
            # 1. 优先使用手动指定的路径
            self.数据库路径 = 数据库路径
        else:
            try:
                # 2. 尝试从VNTrader配置目录自动获取（推荐方式）
                # 获取SETTING_PATH所在的目录（而非文件路径）
                vt_root_dir = os.path.dirname(get_folder_path(SETTING_PATH))
                self.数据库路径 = os.path.join(vt_root_dir, "database.db")
            except Exception:

                self.数据库路径 = os.path.join(福纹配置目录, "database.db")


        # 创建数据库目录（如果不存在）
        Path(self.数据库路径).parent.mkdir(parents=True, exist_ok=True)

        # 初始化数据库
        self._初始化数据库()

    def _获取连接(self):
        """获取数据库连接"""
        return sqlite3.connect(self.数据库路径)

    def _初始化数据库(self):
        """初始化数据库表结构（直接执行外部SQL文件，带表存在性判断）"""
        import os
        import sqlite3

        # 1. 定义外部SQL文件路径（当前py文件下一级目录：七福/初始化脚本_fuwen.sql）
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sql_file_path = os.path.join(current_dir, "脚本", "初始化脚本_fuwen.sql")

        # 2. 检查SQL文件是否存在
        if not os.path.exists(sql_file_path):
            raise FileNotFoundError(f"SQL初始化脚本文件不存在：{sql_file_path}")

        # 3. 连接数据库，先检查核心表是否已存在（避免重复初始化）
        with self._获取连接() as conn:
            cursor = conn.cursor()

            # 检查关键表是否存在（回测交易记录表、回测交易结果表）
            cursor.execute("""
                           SELECT name
                           FROM sqlite_master
                           WHERE type = 'table'
                             AND (name = '回测交易记录表' OR name = '回测交易结果表' OR name = '回测任务表')
                           """)
            existing_tables = cursor.fetchall()

            # 如果两个核心表都已存在，跳过初始化（核心优化：提升效率）
            table_names = [t[0] for t in existing_tables]
            if "回测交易记录表" in table_names and "回测交易结果表" in table_names and "回测任务表" in table_names:
                return

            # 4. 直接读取并执行整个SQL文件（核心优化：使用executescript一次性执行）
            try:
                # 读取SQL文件完整内容
                with open(sql_file_path, 'r', encoding='utf-8') as f:
                    sql_script = f.read()

                # 一次性执行整个SQL脚本（SQLite官方推荐方式，效率最高）
                conn.executescript(sql_script)
                conn.commit()
                print(f"成功初始化数据库表结构（共执行{len(sql_script.split(';'))}条语句）")

            except sqlite3.Error as e:
                conn.rollback()
                raise Exception(f"执行SQL初始化脚本失败：{str(e)}")
            except Exception as e:
                raise Exception(f"读取/执行SQL文件异常：{str(e)}")

    def 记录开仓操作(
            self,
            订单号: str,
            交易品种: str,
            委托方向: str,
            操作价格: float,
            操作数量: int,
            操作时间: datetime,
            操作原因: Any | Dict[str, Any] = None,
            持仓方向: str = "",
            开仓价格: float = 0.0,
            当前持仓数量: int = 0,
            备注信息: str = ""
    ) -> int:
        """        记录开仓操作        Returns:            记录ID        """
        操作原因文本 = str(操作原因) if 操作原因 else ""

        订单号 = 订单号.__str__()
        with self._获取连接() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                           INSERT INTO 回测交易记录表 (策略名称, 订单类型, 委托方向, 订单号, 交易品种,
                                                       操作价格, 操作数量, 操作时间, 操作原因, 持仓方向,
                                                       开仓价格, 当前持仓数量, 备注信息)
                           VALUES (?, ?, ?, ?, ?,
                                   ?, ?, ?, ?, ?,
                                   ?, ?, ?)
                           ''', (
                               self.策略名称, "开仓", 委托方向, 订单号, 交易品种,
                               操作价格, 操作数量, 操作时间, 操作原因文本,
                               持仓方向, 开仓价格, 当前持仓数量, 备注信息
                           ))
            记录ID = cursor.lastrowid
            conn.commit()

        return 记录ID

    def 记录平仓操作(
            self,
            订单号: str,
            交易品种: str,
            委托方向: str,
            操作价格: float,
            操作数量: int,
            操作时间: datetime,
            操作原因: Dict[str, Any] | str = None,
            持仓方向: str = "",
            开仓价格: float = 0.0,
            当前持仓数量: int = 0,
            备注信息: str = ""
    ) -> int:
        """
        记录平仓操作

        Returns:
            记录ID
        """
        操作原因文本 = str(操作原因) if 操作原因 else ""
        订单号 = 订单号.__str__()

        with self._获取连接() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                           INSERT INTO 回测交易记录表 (策略名称, 订单类型, 委托方向, 订单号, 交易品种,
                                                       操作价格, 操作数量, 操作时间, 操作原因,
                                                       持仓方向, 开仓价格, 当前持仓数量, 备注信息)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                           ''', (
                               self.策略名称, "平仓", 委托方向, 订单号, 交易品种,
                               操作价格, 操作数量, 操作时间, 操作原因文本,
                               持仓方向, 开仓价格, 当前持仓数量, 备注信息
                           ))
            记录ID = cursor.lastrowid
            conn.commit()

        return 记录ID

    def _获取持仓周期(self, 开仓时间, 平仓时间):
        # 转换为字符串并解析为datetime对象
        开仓_str = str(开仓时间)  # 使用str()而不是__str__()
        平仓_str = str(平仓时间)
        开仓_dt = datetime.fromisoformat(开仓_str)
        平仓_dt = datetime.fromisoformat(平仓_str)

        时间差 = 平仓_dt - 开仓_dt  # 计算时间差（总秒数）
        持仓周期秒数 = 时间差.total_seconds()  # 使用total_seconds()而不是seconds
        持仓周期分钟 = max(持仓周期秒数 / 60, 0)  # 转换为分钟，确保非负数
        return int(持仓周期分钟)  # 返回整数分钟

    def 记录交易结果(
            self,
            开仓记录ID: int | str | Any,
            平仓记录ID: int | str | Any,
            开仓时间: datetime,
            平仓时间: datetime,
            开仓价格: float,
            平仓价格: float,
            开仓方向: str,
            操作数量: int,
            交易备注: str = ""
    ) -> int:
        """记录完整的交易结果        Returns:结果ID        """
        # 计算持仓周期（分钟）
        持仓周期 = self._获取持仓周期(开仓时间=开仓时间, 平仓时间=平仓时间)

        # 计算盈亏
        if 开仓方向.lower() in ["多头", "buy"]:
            盈亏值 = (平仓价格 - 开仓价格) * 操作数量
        else:  # 空头
            盈亏值 = (开仓价格 - 平仓价格) * 操作数量

        盈亏百分比 = (盈亏值 / (开仓价格 * 操作数量)) * 100

        # 判断交易结果
        交易结果 = "胜利" if 盈亏值 > 0 else "失败"

        # 计算累计统计
        统计信息 = self._获取累计统计()
        累计盈亏 = 统计信息.get("累计盈亏", 0) + 盈亏值
        胜率 = self._计算胜率()
        最大回撤 = self._计算最大回撤()

        with self._获取连接() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                           INSERT INTO 回测交易结果表 (策略名称, 开仓记录ID, 平仓记录ID, 交易结果,
                                                       开仓时间, 平仓时间, 开仓价格, 平仓价格,
                                                       开仓方向, 操作数量, 持仓周期_分钟,
                                                       盈亏值, 盈亏百分比, 累计盈亏, 胜率, 最大回撤, 交易备注)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                           ''', (
                               self.策略名称, 开仓记录ID, 平仓记录ID, 交易结果,
                               开仓时间, 平仓时间, 开仓价格, 平仓价格,
                               开仓方向, 操作数量, 持仓周期,
                               盈亏值, 盈亏百分比, 累计盈亏, 胜率, 最大回撤, 交易备注
                           ))
            结果ID = cursor.lastrowid
            conn.commit()

        return 结果ID

    def _获取累计统计(self) -> Dict[str, float]:
        """获取累计统计信息"""
        with self._获取连接() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                           SELECT COUNT(*)                                           as 总交易数,
                                  SUM(CASE WHEN 交易结果 = '胜利' THEN 1 ELSE 0 END) as 胜利次数,
                                  SUM(盈亏值)                                        as 累计盈亏
                           FROM 回测交易结果表
                           WHERE 策略名称 = ?
                           ''', (self.策略名称,))

            result = cursor.fetchone()
            if result and result[0] > 0:
                return {
                    "总交易数": result[0],
                    "胜利次数": result[1],
                    "累计盈亏": result[2] or 0
                }
            else:
                return {"总交易数": 0, "胜利次数": 0, "累计盈亏": 0}

    def _计算胜率(self) -> float:
        """计算当前胜率（不包括当前交易）"""
        统计信息 = self._获取累计统计()
        if 统计信息["总交易数"] > 0:
            return (统计信息["胜利次数"] / 统计信息["总交易数"]) * 100
        return 0.0

    def _计算最大回撤(self) -> float:
        """计算最大回撤"""
        with self._获取连接() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                           SELECT 累计盈亏
                           FROM 回测交易结果表
                           WHERE 策略名称 = ?
                           ORDER BY 创建时间
                           ''', (self.策略名称,))

            results = cursor.fetchall()
            if not results:
                return 0.0

            累计盈亏列表 = [row[0] for row in results]
            峰值 = 累计盈亏列表[0]
            最大回撤 = 0.0

            for 盈亏 in 累计盈亏列表:
                if 盈亏 > 峰值:
                    峰值 = 盈亏
                回撤 = 峰值 - 盈亏
                if 回撤 > 最大回撤:
                    最大回撤 = 回撤

            return 最大回撤

    def 获取开仓记录(self, 订单号: str = None) -> Optional[Dict]:
        """获取开仓记录"""
        if len(订单号) != 1:
            logger.error(f"获取开仓记录时，订单号参数必须是一个列表，包含一个元素。当前参数: {订单号}")
            return None
        订单号 = 订单号.__str__()  # 默认取第一个订单号

        with self._获取连接() as conn:
            cursor = conn.cursor()

            if 订单号:
                cursor.execute('''
                               SELECT *
                               FROM 回测交易记录表
                               WHERE 策略名称 = ?
                                 AND 订单类型 = '开仓'
                                 AND 订单号 like ?
                               ''', (self.策略名称, f"%{订单号}%"))

            columns = [description[0] for description in cursor.description]
            row = cursor.fetchone()

            if row:
                return dict(zip(columns, row))
            return None

    def 获取交易统计(self) -> Dict[str, Any]:
        """获取完整的交易统计信息"""
        with self._获取连接() as conn:
            cursor = conn.cursor()

            # 基础统计
            cursor.execute('''
                           SELECT COUNT(*)                                           as 总交易数,
                                  SUM(CASE WHEN 交易结果 = '胜利' THEN 1 ELSE 0 END) as 胜利次数,
                                  SUM(CASE WHEN 交易结果 = '失败' THEN 1 ELSE 0 END) as 失败次数,
                                  AVG(持仓周期_分钟)                                 as 平均持仓分钟数,
                                  SUM(盈亏值)                                        as 总盈亏,
                                  AVG(盈亏值)                                        as 平均盈亏,
                                  MIN(盈亏值)                                        as 最大亏损,
                                  MAX(盈亏值)                                        as 最大盈利,
                                  AVG(盈亏百分比)                                    as 平均盈亏百分比
                           FROM 回测交易结果表
                           WHERE 策略名称 = ?
                           ''', (self.策略名称,))

            基础统计 = cursor.fetchone()

            # 按方向统计
            cursor.execute('''
                           SELECT 开仓方向,
                                  COUNT(*)                                           as 交易次数,
                                  SUM(CASE WHEN 交易结果 = '胜利' THEN 1 ELSE 0 END) as 胜利次数,
                                  AVG(盈亏百分比)                                    as 平均盈亏百分比
                           FROM 回测交易结果表
                           WHERE 策略名称 = ?
                           GROUP BY 开仓方向
                           ''', (self.策略名称,))

            方向统计 = cursor.fetchall()

            # 计算胜率
            总交易数 = 基础统计[0] if 基础统计[0] else 0
            胜利次数 = 基础统计[1] if 基础统计[1] else 0
            胜率 = (胜利次数 / 总交易数 * 100) if 总交易数 > 0 else 0

            return {
                "总交易数": 总交易数,
                "胜利次数": 胜利次数,
                "失败次数": 基础统计[2] if 基础统计[2] else 0,
                "胜率": round(胜率, 2),
                "平均持仓分钟数": round(基础统计[3], 1) if 基础统计[3] else 0,
                "总盈亏": round(基础统计[4], 2) if 基础统计[4] else 0,
                "平均盈亏": round(基础统计[5], 2) if 基础统计[5] else 0,
                "最大亏损": round(基础统计[6], 2) if 基础统计[6] else 0,
                "最大盈利": round(基础统计[7], 2) if 基础统计[7] else 0,
                "平均盈亏百分比": round(基础统计[8], 2) if 基础统计[8] else 0,
                "方向统计": {
                    row[0]: {
                        "交易次数": row[1],
                        "胜利次数": row[2],
                        "平均盈亏百分比": round(row[3], 2) if row[3] else 0
                    } for row in 方向统计
                }
            }

    def 导出交易记录(self, 文件路径: str = None, 格式: str = 'csv'):
        """导出交易记录到文件，支持csv和xlsx格式"""
        import os
        from datetime import datetime

        if not 文件路径:
            # 生成文件名
            时间戳 = datetime.now().strftime('%Y%m%d_%H%M%S')
            文件名 = f"{self.策略名称}_交易记录_{时间戳}"
            # 拼接最终路径（跨平台）
            文件路径 = os.path.join(缓存目录, f"{文件名}.{格式}")

        with self._获取连接() as conn:
            # 交易记录表
            df_记录 = pd.read_sql_query(
                f"SELECT * FROM 回测交易记录表 WHERE 策略名称 = '{self.策略名称}' ORDER BY 操作时间",
                conn
            )

            # 交易结果表
            df_结果 = pd.read_sql_query(
                f"SELECT * FROM 回测交易结果表 WHERE 策略名称 = '{self.策略名称}' ORDER BY 开仓时间",
                conn
            )

            # 统计汇总
            统计信息 = self.获取交易统计()
            df_统计 = pd.DataFrame([统计信息])

        if 格式.lower() == 'csv':
            # 保存为CSV文件（多个文件）
            df_记录.to_csv(文件路径.replace('.csv', '_交易记录.csv'), index=False, encoding='utf-8-sig')
            df_结果.to_csv(文件路径.replace('.csv', '_交易结果.csv'), index=False, encoding='utf-8-sig')
            df_统计.to_csv(文件路径.replace('.csv', '_统计汇总.csv'), index=False, encoding='utf-8-sig')

            # 返回第一个文件路径
            return 文件路径.replace('.csv', '_交易记录.csv')
        else:
            # 保持原有XLSX格式
            with pd.ExcelWriter(文件路径, engine='openpyxl') as writer:
                df_记录.to_excel(writer, sheet_name='交易记录', index=False)
                df_结果.to_excel(writer, sheet_name='交易结果', index=False)
                df_统计.to_excel(writer, sheet_name='统计汇总', index=False)

            return 文件路径

    def 获取策略参数(self, 策略对象) -> Dict[str, Any]:
        """
        精准提取fuwen策略对象中指定的参数（白名单方式）

        参数:
            策略对象: fuwen策略实例对象（继承自CtaTemplate）

        返回:
            dict: 仅包含指定参数的字典，结构如下：
            {
                "parameters": {
                    "author": "作者名",
                    "下单数量": 值,
                    "最大持仓量": 值,
                    "快线周期": 值,
                    "慢线周期": 值
                },
                "信号参数": 对应的值
            }
        """
        # 初始化返回结果
        返回结果 = {
            "parameters": {},
            "信号参数": None  # 先初始化，后续赋值
        }

        # 1. 定义需要提取的parameters子参数列表（你指定的白名单）
        目标参数列表 = [
            "author",
            "下单数量",
            "最大持仓量",
            "快线周期",
            "慢线周期"
        ]

        # 2. 提取parameters下的指定参数
        for 参数名 in 目标参数列表:
            # 检查策略对象是否有该属性，有则提取，无则设为None（避免报错）
            if hasattr(策略对象, 参数名):
                返回结果["parameters"][参数名] = getattr(策略对象, 参数名)
            else:
                返回结果["parameters"][参数名] = None  # 无该参数时标记为None

        # 3. 提取"信号参数"属性
        if hasattr(策略对象, "信号参数"):
            返回结果["信号参数"] = getattr(策略对象, "信号参数")

        return 返回结果

    # ========== 核心函数1：创建回测任务 ==========
    def 创建回测任务(
            self,
            cta_engine: Any,
            strategy: Any,
            回测名称: str,
            交易品种: str,
            回测开始时间: datetime = None,
            回测结束时间: datetime = None,
            任务开始时间: datetime = None,
            初始资金: float = 100000.0,
            手续费率: float = 0.0003,
            滑点: float = 0.0,
            合约乘数: int = 1,
            回测备注: str = ""
    ) -> dict[Any, Any]:
        """
        创建回测任务记录（在on_start中调用）
        Args:
            cta_engine: fuwen的CTA引擎对象（回测引擎）
            strategy: 策略实例对象
            回测名称: 自定义回测任务名称
            交易品种: 回测品种（如HK.MHI2602）
            回测开始时间: 回测时间范围开始
            回测结束时间: 回测时间范围结束
            任务开始时间: 任务开始时间
            初始资金: 回测初始资金
            手续费率: 手续费率
            滑点: 滑点值
            合约乘数: 合约乘数
            回测备注: 自定义备注


        """
        result = {}
        try:
            # 从回测引擎提取基础信息
            if 任务开始时间 is None:
                任务开始时间 = datetime.now()
            策略名称 = strategy.strategy_name
            策略参数 = self.获取策略参数(策略对象=strategy)  # strategy.七福对象.获取参数()
            策略参数_str = 策略参数.__str__()

            # 自动补全回测时间范围（如果未传入）
            if not 回测开始时间 and hasattr(cta_engine, 'history_data') and cta_engine.history_data:
                回测开始时间 = cta_engine.history_data[0].datetime
            if not 回测结束时间 and hasattr(cta_engine, 'history_data') and cta_engine.history_data:
                回测结束时间 = cta_engine.history_data[-1].datetime
            if 回测名称 == '':
                回测名称 = f"{策略名称}_{交易品种}_{回测开始时间.strftime('%Y%m%d_%H%M%S')}"

            # 插入回测任务记录到数据库
            with self._获取连接() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                               INSERT INTO 回测任务表 (回测名称, 策略名称, 交易品种, 回测开始时间, 回测结束时间,
                                                       任务开始时间, 初始资金, 手续费率, 滑点, 合约乘数,
                                                       回测备注, 回测状态, 策略参数)
                               VALUES (?, ?, ?, ?, ?,
                                       ?, ?, ?, ?, ?,
                                       ?, ?, ?)
                               ''', (
                                   回测名称, 策略名称, 交易品种, 回测开始时间, 回测结束时间,
                                   任务开始时间, 初始资金, 手续费率, 滑点, 合约乘数,
                                   回测备注, '运行中', 策略参数_str
                               ))
                回测任务ID = cursor.lastrowid
                conn.commit()

            # 缓存任务ID到实例，方便后续更新
            self.当前回测任务ID = 回测任务ID
            result['success'] = True
            result['回测任务ID'] = 回测任务ID
            result['msg'] = f"✅ 创建回测任务成功！任务ID：{回测任务ID}（策略：{策略名称}，品种：{交易品种}）"

        except Exception as e:
            result['success'] = False
            result['msg'] = f"❌ 创建回测任务失败: {str(e)}\n{traceback.format_exc()}"
            print(f"创建回测任务失败: {str(e)}\n{traceback.format_exc()}")

        return result

    # ========== 核心函数2：更新回测任务 ==========
    import datetime
    from typing import Any, Dict

    # 假设这是类中的方法，保留原有方法名和参数，仅优化字段映射逻辑
    def 更新回测任务(
            self,
            cta_engine: Any,
            回测任务ID: int = None,
            回测状态: str = "已完成",
            回测备注: str = "",
            任务结束时间: datetime = None,
    ) -> Dict[Any, Any]:
        """
        更新回测任务结果（在on_stop中调用）
        Args:
            cta_engine: fuwen的CTA引擎对象（回测引擎）
            回测任务ID: 回测任务ID（不传则使用缓存的当前任务ID）
            回测状态: 运行中/已完成/失败
            回测备注: 补充备注（会追加到原有备注后，而非覆盖）
            任务结束时间: 任务结束时间（不传则自动记录当前时间）

        Returns:
            是否更新成功
        """
        result = {}
        try:
            # 使用缓存的任务ID（如果未传入）
            回测任务ID = 回测任务ID or getattr(self, '当前回测任务ID', None)
            if not 回测任务ID:
                raise Exception("回测任务ID为空，无法更新")

            # 从回测引擎提取结果数据
            if 任务结束时间 is None:
                任务结束时间 = datetime.now()

            # 获得统计数据
            result_回测数据 = self._获得回测数据(回测引擎=cta_engine)
            if not result_回测数据.get("success", False):
                result['success'] = False
                result['msg'] = f"❌ 更新回测任务失败: 获取统计数据出错！errmsg=[{result_回测数据.get('msg', '')}]"
                return result
            统计数据 = result_回测数据.get("统计数据", {})

            if not isinstance(统计数据, dict):
                raise ValueError("统计数据格式错误，必须是字典类型")

            # ===================== 核心优化：修正字段映射 + 增强兼容性 =====================
            # 1. 结束资金（优先使用final_equity，这是fuwen界面显示的核心字段）
            结束资金 = 统计数据.get('end_balance', 0.0)

            # 2. 总盈亏（优先使用total_pnl，兼容新版本的total_net_pnl）
            总盈亏 = 统计数据.get('total_net_pnl', 0.0)

            # 3. 初始资金（优先使用start_equity，兼容capital）
            初始资金 = 统计数据.get('capital', 9999999.0)

            # 4. 总盈亏率（增加防除零保护，保留2位小数）
            if 初始资金 != 0:
                总盈亏率 = round((结束资金 - 初始资金) / 初始资金 * 100, 2)
            else:
                总盈亏率 = 0.0
            总盈亏率_str = f"{总盈亏率}%"

            # 5. 年化收益率（无需乘100，原数据已是百分比数值；增加保留2位小数）
            年化收益率 = round(统计数据.get('annual_return', 0.0), 2)

            # 6. 总手续费（兼容字段）
            总手续费 = 统计数据.get('total_commission', 0.0)

            # 7. 胜率（兼容处理，无数据时默认0，保留2位小数）
            胜率 = round(统计数据.get('win_rate', 0.0) * 100, 2)

            # 8. 最大回撤（保留2位小数）
            最大回撤 = round(统计数据.get('max_drawdown', 0.0), 2)

            # 9. 最大回撤率（修正字段名：max_drawdown_ratio → max_ddpercent；保留2位小数）
            最大回撤率 = round(统计数据.get('max_ddpercent', 0.0) or 统计数据.get('max_drawdown_ratio', 0.0), 2)

            # 10. 夏普比率（保留4位小数，更符合金融统计习惯）
            夏普比率 = round(统计数据.get('sharpe_ratio', 0.0), 4)

            # 11. 盈亏比（无数据时默认0，保留2位小数）
            盈亏比 = round(统计数据.get('profit_loss_ratio', 0.0), 2)

            # 12. 总交易次数（修正字段名：total_trades → total_trade_count；转为整数）
            总交易次数 = int(统计数据.get('total_trade_count', 0) or 统计数据.get('total_trades', 0))
            # ==========================================================================

            with self._获取连接() as conn:
                cursor = conn.cursor()

                # ========== 核心修改：先查询原有备注，实现累加 ==========
                # 1. 查询当前任务的原有备注
                cursor.execute('SELECT 回测备注 FROM 回测任务表 WHERE 回测任务ID = ?', (回测任务ID,))
                原有备注 = cursor.fetchone()
                原有备注内容 = 原有备注[0] if (原有备注 and 原有备注[0]) else ""

                # 2. 拼接新备注（如果新备注非空，追加到原有备注后，用换行/分隔符区分）
                if 回测备注:
                    # 兼容原有备注为空的情况，避免多余分隔符
                    最终回测备注 = f"{原有备注内容}\n{回测备注}" if 原有备注内容 else 回测备注
                else:
                    # 新备注为空时，直接使用原有备注（保持不变）
                    最终回测备注 = 原有备注内容
                # ========== 核心修改结束 ==========

                # 执行更新（将原参数中的“回测备注”替换为拼接后的“最终回测备注”）
                cursor.execute('''
                               UPDATE 回测任务表
                               SET 任务结束时间 = ?,
                                   结束资金     = ?,
                                   总盈亏       = ?,
                                   总盈亏率     = ?,
                                   年化收益率   = ?,
                                   总手续费     = ?,
                                   胜率         = ?,
                                   最大回撤     = ?,
                                   最大回撤率   = ?,
                                   夏普比率     = ?,
                                   盈亏比       = ?,
                                   总交易次数   = ?,
                                   回测状态     = ?,
                                   回测备注     = ?,
                                   更新时间     = CURRENT_TIMESTAMP
                               WHERE 回测任务ID = ?
                               ''', (
                                   任务结束时间, 结束资金, 总盈亏, 总盈亏率_str, 年化收益率,
                                   总手续费, 胜率, 最大回撤, 最大回撤率, 夏普比率,
                                   盈亏比, 总交易次数, 回测状态, 最终回测备注, 回测任务ID
                               ))
                conn.commit()

            result['success'] = True
            result['更新数量'] = cursor.rowcount
            result['msg'] = f"✅ 更新回测任务成功！更新数量：{cursor.rowcount}（任务ID：{回测任务ID}）"
        except Exception as e:
            result['success'] = False
            result['msg'] = f"❌ 更新回测任务失败: {str(e)}\n{traceback.format_exc()}"
        return result

    def _获得回测数据(self, 回测引擎):
        """
        修复版：正确获取回测引擎的最终统计数据
        """
        res_统计数据 = None
        res_计算回测结果 = None
        msg = ""

        result = {
            "success": False,
            "msg": '',
            "统计数据": {},
            "计算回测结果": {},
        }

        # 先计算回测结果（生成 trades/results）
        if hasattr(回测引擎, 'calculate_result'):
            res_计算回测结果 = 回测引擎.calculate_result()

        # ========== 核心修复1：优先获取真正的回测引擎实例 ==========
        backtesting_engine = None
        # 层级1: cta_engine直接包含backtesting_engine（fuwen标准结构）
        if hasattr(回测引擎, 'backtesting_engine') and 回测引擎.backtesting_engine:
            backtesting_engine = 回测引擎.backtesting_engine
        # 层级2: 从main_engine获取
        elif hasattr(回测引擎, 'main_engine') and hasattr(回测引擎.main_engine, 'backtesting_engine'):
            backtesting_engine = 回测引擎.main_engine.backtesting_engine
        # 层级3: 兼容旧版本
        elif hasattr(回测引擎, 'engine') and hasattr(回测引擎.engine, 'backtesting_engine'):
            backtesting_engine = 回测引擎.engine.backtesting_engine

        # ========== 核心修复2：使用回测引擎计算最终结果 ==========
        if backtesting_engine:
            try:
                # 第一步：强制计算回测结果（生成完整的交易记录和收益曲线）
                if hasattr(backtesting_engine, 'calculate_result'):
                    res_计算回测结果 = backtesting_engine.calculate_result()
                # 第二步：强制计算统计指标（生成最终的统计数据）
                if hasattr(backtesting_engine, 'calculate_statistics'):
                    res_统计数据 = backtesting_engine.calculate_statistics()
                # 第三步：直接从回测引擎获取最终统计数据（最高优先级）
                if hasattr(backtesting_engine, 'statistics') and backtesting_engine.statistics:
                    res_统计数据 = backtesting_engine.statistics
            except Exception as e:
                # 打印详细错误，便于排查
                msg = f"【关键错误】计算回测统计失败: {str(e)}\n{traceback.format_exc()}"
        else:
            # 降级方案：兼容原有逻辑（仅用于报错提示）

            if hasattr(回测引擎, 'calculate_statistics'):
                res_统计数据 = 回测引擎.calculate_statistics()
            elif hasattr(回测引擎, 'statistics'):
                res_统计数据 = 回测引擎.statistics

        # ========== 核心修复3：校验统计数据有效性 ==========
        if not res_统计数据 or not isinstance(res_统计数据, dict):
            result['success'] = False
            msg = f"统计数据获取失败，数据类型异常: {type(res_统计数据)}"
            res_统计数据 = {}
        else:
            result['success'] = True

        result['统计数据'] = res_统计数据
        result['计算回测结果'] = res_计算回测结果
        result['msg'] = msg

        return result
