import warnings

from fuwen_ctastrategy import CtaTemplate

from fuwen_adaptor.trader.object import BarData

# 屏蔽pandas的FutureWarning
warnings.filterwarnings('ignore', category=FutureWarning, module='pyqtgraph')


class 示例_指定时间交易策略_bak(CtaTemplate):
    """指定时间交易策略"""

    作者 = "示例_指定时间交易策略"
    默认交易数量 = 10
    parameters = ["作者", '默认交易数量']  # 显示 参数

    def on_init(self) -> None:
        pass

    def __init__(self, cta_engine, strategy_name, fw_symbol, setting):
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)


    def on_bar(self, bar: BarData):
        # 统一管理的交易指令列表（全部使用中文标识）
        预计交易订单列表 = [
            {"时间": "2026-02-02 14:50", "操作": "开多"},
            {"时间": "2026-02-02 17:51", "操作": "平多"},

            {"时间": "2026-02-03 09:57", "操作": "开空"},
            {"时间": "2026-02-03 10:51", "操作": "平空"},

            {"时间": "2026-02-03 10:52", "操作": "开多"},
            {"时间": "2026-02-03 12:00", "操作": "平多"},

            {"时间": "2026-02-03 23:50", "操作": "开空"},
            {"时间": "2026-02-04 02:47", "操作": "平空"},



            {"时间": "2026-02-20 22:14", "操作": "开多"},
            {"时间": "2026-02-23 10:47", "操作": "平多"},

            {"时间": "2026-02-23 22:41", "操作": "开空"},
            {"时间": "2026-02-24 13:23", "操作": "平空"},

            {"时间": "2026-02-24 13:41", "操作": "开多"},
            {"时间": "2026-02-26 09:27", "操作": "平多"},

            {"时间": "2026-02-26 09:31", "操作": "开空"},
            {"时间": "2026-02-26 16:04", "操作": "平空"},

            {"时间": "2026-03-09 10:34", "操作": "开多"},
            {"时间": "2026-03-09 10:57", "操作": "平多"},



        ]

        当前时间 = bar.datetime.strftime("%Y-%m-%d %H:%M")  # 获取当前K线的时间字符串
        print(f"当前时间={当前时间}")
        # 操作映射（中文操作名 -> 实际调用的方法）
        操作映射 = {"开多": self.buy, "平多": self.sell, "开空": self.short, "平空": self.cover}
        # 遍历交易指令，匹配时间并执行对应操作
        for 指令 in 预计交易订单列表:
            if 当前时间 == 指令["时间"]:
                价格 = bar.close_price
                数量 = 指令.get("手数", self.默认交易数量)

                # 根据中文操作名执行对应交易
                操作映射[指令["操作"]](price=价格, volume=数量)
