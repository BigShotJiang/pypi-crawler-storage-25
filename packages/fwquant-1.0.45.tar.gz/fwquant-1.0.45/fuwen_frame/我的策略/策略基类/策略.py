import abc
import os
import platform
import sqlite3
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
from collections import deque

import pandas as pd
from fuwen_ctastrategy import CtaTemplate, StopOrder

from fuwen_config.常量 import 缓存目录
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.策略函数.策略常量 import SETTING_PATH
from fuwen_frame.我的策略.策略函数.回测交易记录器 import 回测交易记录器类

from fuwen_adaptor.trader.object import TickData, BarData, OrderData, TradeData
from fuwen_adaptor.trader.utility import BarGenerator, ArrayManager

# 公共依赖
from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举, 福纹信号_响应类

# ======================================
# 极简配置：只保留必须项
# ======================================
是否_调试模式 = False
写数据库 = False  # 保留写数据库日志


# ======================================
# 策略基类（极致精简 + 高性能）
# ======================================
class 策略_基类(CtaTemplate, abc.ABC):
    """精简版：仅保留 周期信号检测 + 交易开平仓 + 数据库日志"""
    author = "模板_策略_信号整合版_性能优化"

    # 固定参数
    下单数量 = 1
    最大持仓量 = 2

    # 固定变量
    当前k线时间 = None
    回测引擎: Optional[Any] = None
    订单_id = ''
    仓位 = {'持仓数量': 0}
    显示列表 = ['author', '下单数量', '最大持仓量']
    parameters = 显示列表

    # 信号固定变量
    _信号参数: Dict[str, Any] = {}

    # ======================
    # 核心初始化（无冗余）
    # ======================
    @abc.abstractmethod
    def __init__(self, cta_engine: Any = None, strategy_name: str = "", fw_symbol: str = "", setting: dict = {}):
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)

        # 仅保留核心组件
        self.bg1 = BarGenerator(self.on_bar)
        self.am = ArrayManager(size=120)
        self.bar_data = deque(maxlen=120)

        # 交易记录器（必须保留）
        self.策略名称 = strategy_name
        self.交易记录器 = 回测交易记录器类(策略名称=strategy_name)
        self.交易记录_开仓 = []
        self.交易记录_平仓 = []

        # 信号引擎
        self.信号引擎实例 = None
        self.回测任务ID = None
        self.当前k线 = None

        # 初始化信号
        self.初始化信号引擎()

    # ======================
    # 强制保留：信号初始化
    # ======================
    @abc.abstractmethod
    def 初始化信号引擎(self, 参数=None):
        pass

    # ======================
    # 核心：信号响应（无冗余）
    # ======================
    def 信号_响应(self) -> Dict[str, Any]:
        if not self.信号引擎实例:
            return {"信号结果": 信号结果_枚举.无信号.value}

        # 只传当前K线，极致高效
        self._福纹信号 = self.信号引擎实例.响应福纹信号(参数=self.当前k线)
        return self._福纹信号

    # ======================
    # 生命周期（极简）
    # ======================
    def on_init(self) -> None:
        """初始化：清空记录"""
        self.交易记录_开仓.clear()
        self.交易记录_平仓.clear()

    def on_start(self) -> None:
        """启动：初始化信号"""
        self.初始化信号引擎()

    def on_stop(self) -> None:
        """停止：导出交易记录"""
        self._导出交易记录()

    # ======================
    # 数据推送（极简）
    # ======================
    def on_tick(self, tick: TickData) -> None:
        self.bg1.update_tick(tick)

    def on_bar(self, bar: BarData) -> None:
        """【核心】每个周期执行一次：信号 + 交易"""
        self.当前k线 = bar
        self.当前k线时间 = bar.datetime.strftime('%Y-%m-%d %H:%M')

        # 缓存K线
        self.bar_data.append(bar)
        self.am.update_bar(bar)

        # 【核心】每个周期触发信号检测
        self.处理1分钟K线(bar)

    # ======================
    # 无冗余回调
    # ======================
    def on_order(self, order: OrderData) -> None:
        pass

    def on_trade(self, trade: TradeData) -> None:
        super().on_trade(trade)
        self.仓位['持仓数量'] = int(self.pos)

    def on_stop_order(self, stop_order: StopOrder) -> None:
        pass

    # ======================
    # 核心：信号 + 开平仓（唯一业务逻辑）
    # ======================
    def 处理1分钟K线(self, bar: BarData) -> None:
        # 1. 获取信号
        try:
            信号结果 = self.信号_响应()
        except:
            return

        # 2. 解析信号
        信号值 = 信号结果['信号结果']
        if 信号值 == 信号结果_枚举.看多.value:
            开仓方向 = "buy"
            平仓方向 = "cover"
        elif 信号值 == 信号结果_枚举.看空.value:
            开仓方向 = "short"
            平仓方向 = "sell"
        else:
            return

        # 3. 基础参数
        当前持仓 = int(self.pos)
        价格 = bar.close_price
        数量 = self.下单数量

        # 4. 平反向仓位
        if (当前持仓 < 0 and 开仓方向 == "buy") or (当前持仓 > 0 and 开仓方向 == "short"):
            self.平仓(方向=平仓方向, 价格=价格, 数量=abs(当前持仓), 原因="信号反向平仓")

        # 5. 开仓（不超限）
        if abs(当前持仓) < self.最大持仓量:
            self.开仓(方向=开仓方向, 价格=价格, 数量=数量, 原因=信号值)

    # ======================
    # 开仓（保留数据库日志）
    # ======================
    def 开仓(self, 方向: str, 价格=0.0, 数量: int = 1, 原因: str = "") -> tuple:
        try:
            订单号 = self.buy(价格, 数量) if 方向 == "buy" else self.short(价格, 数量)
        except:
            return -1, "开仓失败"

        if not 订单号:
            return -1, "下单失败"

        self.交易记录_开仓.append(
            {
                "订单号": 订单号,
                "委托方向": 方向,
                "操作价格": 价格,
                "操作数量": 数量,
                "操作时间": self.当前k线.datetime,
                "操作原因": 原因,
                "持仓方向": 方向,
                "开仓价格": 价格,
                "当前持仓数量": self.pos
            }
        )

        # 记录数据库
        if 写数据库:
            try:
                self.交易记录器.记录开仓操作(
                    订单号=订单号,
                    交易品种=self.fw_symbol,
                    委托方向=方向,
                    操作价格=价格,
                    操作数量=数量,
                    操作时间=self.当前k线.datetime,
                    操作原因=原因,
                    持仓方向=方向,
                    开仓价格=价格,
                    当前持仓数量=self.pos
                )
            except:
                pass

        self.订单_id = 订单号
        return 0, "开仓成功"

    # ======================
    # 平仓（保留数据库日志）
    # ======================
    def 平仓(self, 方向: str, 价格=0.0, 数量: int = 0, 原因: str = "") -> tuple:
        当前持仓 = int(self.pos)
        if 当前持仓 == 0:
            return -1, "无持仓"

        数量 = abs(当前持仓)
        try:
            订单号 = self.sell(价格, 数量) if 方向 == "sell" else self.cover(价格, 数量)
        except:
            return -1, "平仓失败"

        if not 订单号:
            return -1, "下单失败"

        self.交易记录_平仓.append(
            {
                "订单号": 订单号,
                "委托方向": 方向,
                "操作价格": 价格,
                "操作数量": 数量,
                "操作时间": self.当前k线.datetime,
                "操作原因": 原因,
                "持仓方向": 方向,
                "开仓价格": 价格,
                "当前持仓数量": self.pos
            }
        )
        # 记录数据库
        if 写数据库:
            try:
                self.交易记录器.记录平仓操作(
                    订单号=订单号,
                    委托方向=方向,
                    交易品种=self.fw_symbol,
                    操作价格=价格,
                    操作数量=数量,
                    操作时间=self.当前k线.datetime,
                    操作原因=原因,
                    持仓方向="long" if 当前持仓 > 0 else "short",
                    开仓价格=价格,
                    当前持仓数量=self.pos
                )
            except:
                pass

        return 0, "平仓成功"

    # ======================
    # 交易记录导出
    # ======================
    def _导出交易记录(self):
        if self.获取引擎环境() == "BACKTESTING":
            # self.交易记录器.导出交易记录()
            交易记录 = self.交易记录_开仓 + self.交易记录_平仓
            交易记录_df = pd.DataFrame(交易记录)
            #按时间排序
            交易记录_df=交易记录_df.sort_values(by="操作时间")
            交易记录_df.to_csv(f"{缓存目录}/{self.fw_symbol}_交易记录.csv", index=False)

    def 获取引擎环境(self) -> str:
        return self.cta_engine.gateway_name


# ======================================
# 信号基类（极致精简）
# ======================================
class 信号_基类(abc.ABC):
    def __init__(self, 请求参数=None):
        self.历史k线列表 = []
        self.历史k线 = pd.DataFrame()
        self.信号 = 信号结果_枚举.无信号
        self.信号参数 = 请求参数 or {}

    def 响应福纹信号(self, 参数=None):
        """只接收当前K线，极速处理"""
        # 只保留最新120根K线
        if not isinstance(参数, dict):
            数据 = {
                "时间": 参数.datetime,
                "开盘价": 参数.open_price,
                "最高价": 参数.high_price,
                "最低价": 参数.low_price,
                "收盘价": 参数.close_price,
                "成交量": 参数.volume,
            }
            self.历史k线列表.append(数据)
            self.历史k线列表 = self.历史k线列表[-120:]

        self.历史k线 = pd.DataFrame(self.历史k线列表)

        # 执行信号算法
        self.信号 = self.信号算法()

        # 返回固定格式
        if self.信号 == 信号结果_枚举.看多:
            return {"信号结果": "看多"}
        elif self.信号 == 信号结果_枚举.看空:
            return {"信号结果": "看空"}
        return {"信号结果": "无信号"}

    @abc.abstractmethod
    def 信号算法(self) -> 信号结果_枚举:
        """必须实现信号逻辑"""
        pass
