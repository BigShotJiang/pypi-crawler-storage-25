import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional
import pandas as pd
from fuwen_ctastrategy import CtaTemplate, StopOrder

from fuwen_signal.fw_signal.信号工厂.七福 import 七福信号引擎
from fuwen_frame.我的策略.策略函数.策略常量 import SETTING_PATH

from fuwen_frame.我的策略.策略函数.回测交易记录器 import 回测交易记录器类

from fuwen_adaptor.trader.logger import logger
from fuwen_adaptor.trader.object import TickData, BarData, OrderData, TradeData
from fuwen_adaptor.trader.utility import BarGenerator, ArrayManager, get_folder_path

# 全局常量定义
交易对 = 'HK.MHI2602'
止损比例 = 0.2
RET_OK = 0
IS_DEBUG = False


class 示例_七福_批量保存(CtaTemplate):
    """优化版七福CTA策略类 - 性能提升 + 错误修复"""

    author = "七福_策略"

    # 策略参数
    均线快周期 = 5  # MA5
    均线中周期 = 20  # MA20
    均线慢周期 = 60  # MA60
    止盈回撤比例 = 0.5  # 50%止盈比例
    止损比例 = 0.3
    下单数量 = 1
    最大持仓量 = 2
    开仓成功N分钟后才允许平仓 = 5  # N周期后才允许平仓

    # 内部参数
    n个周期内查找低点 = 30
    当前k线时间 = None
    当前K线索引 = 0
    总K线数量 = 0
    回测引擎: Optional[Any] = None

    # 策略变量
    订单_id = ''
    仓位 = {
        '持仓数量': 0, '开仓时间': '', '方向': '', '开仓价格': 0.0,
        '委托时间': None, '平仓时间': None, '平仓成交价格': 0.0
    }
    显示列表 = [
        'author', '均线快周期', '均线中周期', '均线慢周期',
        '止盈回撤比例', '下单数量', '最大持仓量'
    ]
    parameters = 显示列表

    # 交易统计
    _开仓次数 = 0
    _平仓次数 = 0

    # 性能优化：批量缓存
    _批量开仓记录缓存: List[Dict] = []  # 批量保存开仓记录
    _批量平仓记录缓存: List[Dict] = []  # 批量保存平仓记录
    _批量交易结果缓存: List[Dict] = []  # 批量保存交易结果

    # K线缓存优化
    _k线缓存长度 = 120  # 保留最近120根K线
    _历史k线缓存: pd.DataFrame = pd.DataFrame()  # 优化的K线缓存

    def __init__(self, cta_engine: Any, strategy_name: str, fw_symbol: str, setting: dict):
        """初始化策略"""
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)

        self.当前k线_1分钟 = None
        self._初始化七福对象()
        self.回测任务ID = None

        # 交易记录器
        self.策略名称 = strategy_name
        self.交易记录器 = 回测交易记录器类(策略名称=strategy_name)

        # 策略时间
        self.策略开启时间 = None
        self.策略停止时间 = None

        # K线合成器
        self.bg1 = BarGenerator(self.on_bar, window=1, on_window_bar=self.处理1分钟合成K线)
        self.bg3 = BarGenerator(self.on_bar, window=3, on_window_bar=self.处理3分钟合成K线)

        # K线数据（优化存储）
        self.bar_data = []  # 原始BarData对象
        self.bar_k_lines_df = pd.DataFrame()  # DataFrame格式缓存

        # 其他初始化
        self.当前k线 = None
        self.当前k线时间_1分钟 = None
        self.进度百分比 = 0
        self.am = ArrayManager(size=120)

        # 缓存回测引擎
        self._缓存回测引擎引用()

    def _缓存回测引擎引用(self):
        """获取回测引擎对象引用"""
        self.回测引擎 = None
        engine = self.cta_engine

        # 多层级查找回测引擎
        lookup_paths = [
            ('backtesting_engine',),
            ('main_engine', 'backtesting_engine'),
            ('engine', 'backtesting_engine')
        ]

        for path in lookup_paths:
            try:
                obj = engine
                for attr in path:
                    obj = getattr(obj, attr)
                if obj:
                    self.回测引擎 = obj
                    break
            except AttributeError:
                continue

        if self.回测引擎:
            self.write_debug(f"成功获取回测引擎: {type(self.回测引擎)}")
        else:
            self.write_debug("未能获取回测引擎对象")

    def _获取七福参数配置(self, 更新参数: Optional[Dict] = None) -> Dict[str, Any]:
        """获取七福信号引擎参数配置"""
        res_配置 = {
            '订单_id': self.订单_id,
            '仓位': self.仓位,
            '最大持仓量': self.最大持仓量,
            '持仓数量': self.pos,
            '均线快周期': self.均线快周期,
            '均线中周期': self.均线中周期,
            '均线慢周期': self.均线慢周期,
            '止盈回撤比例': self.止盈回撤比例,
            '止损比例': self.止损比例,
            '开仓成功N分钟后才允许平仓': self.开仓成功N分钟后才允许平仓,
            'n个周期内查找低点': self.n个周期内查找低点,
            '当前k线': None,
            '历史k线': self._历史k线缓存,  # 使用优化的K线缓存
            '当前k线时间': self.当前k线时间,
            '当前K线索引': self.当前K线索引,
            '总K线数量_回测': self.总K线数量
        }

        if 更新参数 and isinstance(更新参数, dict):
            res_配置.update(更新参数)

        return res_配置

    def _初始化七福对象(self):
        """初始化七福信号引擎"""
        参数 = self._获取七福参数配置()
        self.七福对象 = 七福信号引擎(参数=参数)

        # 回测环境初始化
        if self.cta_engine.gateway_name == 'BACKTESTING':
            数量 = len(getattr(self.cta_engine, 'history_data', []))
            if 数量 > 0:
                历史k线_全量_回测 = self.获得当前回测引擎所有历史数据_df(self.cta_engine.history_data)
                # 只保留最近N根K线，提升性能
                self._历史k线缓存 = 历史k线_全量_回测.tail(self._k线缓存长度)
                参数['历史k线_全量_回测'] = self._历史k线缓存
                self.七福对象.更新历史k线_全量_回测(全量历史k线=self._历史k线缓存)

    def on_init(self) -> None:
        """策略初始化"""
        self._初始化七福对象()

        # 重置统计和缓存
        self._平仓次数 = 0
        self._开仓次数 = 0
        self._批量开仓记录缓存 = []
        self._批量平仓记录缓存 = []
        self._批量交易结果缓存 = []

        self.总K线数量 = len(getattr(self.cta_engine, 'history_data', []))
        self.write_debug("策略初始化完成")

    def on_start(self) -> None:
        """策略启动"""
        self._初始化七福对象()
        self.策略开启时间 = datetime.now()
        self.write_info(f"{'=' * 20}策略启动{'=' * 20}")

        # 创建回测任务
        result_创建回测任务 = self.创建回测任务()
        self.write_debug(f"创建回测任务结果: {result_创建回测任务}")

        self.put_event()

    def on_stop(self) -> None:
        """策略停止 - 批量写入所有缓存数据"""
        self.策略停止时间 = datetime.now()
        self.write_info(f"{'=' * 20}策略停止{'=' * 20}")

        # ========== 批量写入所有缓存的交易记录 ==========
        if self.获取引擎环境() == "BACKTESTING":
            self._批量写入所有交易记录()

        # 更新回测任务
        result_更新回测任务 = self.更新回测任务()
        self.write_debug(f"更新回测任务结果: {result_更新回测任务}")

        # 导出交易记录
        result_导出交易记录 = self._导出交易记录()
        self.write_debug(f"导出交易记录结果: {result_导出交易记录}")

        self.write_info(f"{'=' * 20}策略已完全停止{'=' * 20}")
        self.write_info(f"策略共用时：{self.策略停止时间 - self.策略开启时间}")
        self.put_event()

    def _批量写入所有交易记录(self):
        """批量写入所有缓存的交易记录（性能优化核心）"""
        try:
            # 批量写入开仓记录
            if self._批量开仓记录缓存:
                开仓记录ID映射 = {}
                for 记录 in self._批量开仓记录缓存:
                    记录ID = self.交易记录器.记录开仓操作(**记录)
                    开仓记录ID映射[记录['订单号']] = 记录ID

                # 批量写入平仓记录
                平仓记录ID映射 = {}
                for 记录 in self._批量平仓记录缓存:
                    记录ID = self.交易记录器.记录平仓操作(**记录)
                    平仓记录ID映射[记录['订单号']] = 记录ID

                # 批量写入交易结果
                for 交易结果 in self._批量交易结果缓存:
                    开仓订单号 = 交易结果.get('开仓订单号')
                    平仓订单号 = 交易结果.get('平仓订单号')

                    if 开仓订单号 in 开仓记录ID映射 and 平仓订单号 in 平仓记录ID映射:
                        self.交易记录器.记录交易结果(
                            开仓记录ID=开仓记录ID映射[开仓订单号],
                            平仓记录ID=平仓记录ID映射[平仓订单号],
                            开仓时间=交易结果['开仓时间'],
                            平仓时间=交易结果['平仓时间'],
                            开仓价格=交易结果['开仓价格'],
                            平仓价格=交易结果['平仓价格'],
                            开仓方向=交易结果['开仓方向'],
                            操作数量=交易结果['操作数量'],
                            交易备注=交易结果['交易备注']
                        )

                self.write_info(
                    f"批量写入完成：开仓记录{len(self._批量开仓记录缓存)}条，平仓记录{len(self._批量平仓记录缓存)}条")

            # 清空缓存
            self._批量开仓记录缓存.clear()
            self._批量平仓记录缓存.clear()
            self._批量交易结果缓存.clear()

        except Exception as e:
            self.write_error(f"批量写入交易记录失败: {str(e)}\n{traceback.format_exc()}")

    def on_tick(self, tick: TickData) -> None:
        """Tick数据更新"""
        self.bg1.update_tick(tick)
        self.bg3.update_tick(tick)

        if IS_DEBUG:
            self.write_debug(
                f"Tick数据更新: {tick.fw_symbol} {tick.datetime}  "
                f"卖一价{tick.ask_price_1}，买一价 {tick.bid_price_1}，"
                f"成交量 {tick.volume}"
            )

    def on_bar(self, bar: BarData) -> None:
        """Bar数据更新（核心性能优化）"""
        # 更新进度信息
        self.当前k线时间 = datetime.strftime(bar.datetime, '%Y-%m-%d %H:%M')
        self.当前k线 = bar
        self.当前K线索引 += 1

        # 进度计算优化
        if self.总K线数量 == 0:
            self.总K线数量 = len(getattr(self.cta_engine, 'history_data', []))

        if self.总K线数量 > 0:
            当前进度百分比 = round((self.当前K线索引 / self.总K线数量) * 100, 0)
            if self.进度百分比 != 当前进度百分比:
                self.进度百分比 = 当前进度百分比

        # 更新K线合成器
        self.bg1.update_bar(bar)
        self.bg3.update_bar(bar)

        # K线缓存优化：固定长度缓存
        self.bar_data.append(bar)
        if len(self.bar_data) > self._k线缓存长度:
            self.bar_data.pop(0)  # 移除最旧的K线，比切片更高效

        # 增量更新DataFrame缓存（性能优化）
        self._增量更新缓存DataFrame(bar)

        # 更新数组管理器
        self.am.update_bar(bar)

        if IS_DEBUG:
            self.write_debug(f"1分钟Bar数据更新: {bar.fw_symbol} {bar.datetime} {bar.close_price} {bar.volume}")

    def _增量更新缓存DataFrame(self, bar: BarData):
        """增量更新K线DataFrame（避免全量重建）"""
        # 单条K线转换
        bar_dict = {
            'open': bar.open_price,
            'high': bar.high_price,
            'low': bar.low_price,
            'close': bar.close_price,
            'volume': bar.volume,
            'time_key': bar.datetime
        }

        # 创建单行DataFrame
        new_row = pd.DataFrame([bar_dict])
        new_row['time_key'] = pd.to_datetime(new_row['time_key'])

        # 增量添加
        if self.bar_k_lines_df.empty:
            self.bar_k_lines_df = new_row
        else:
            self.bar_k_lines_df = pd.concat([self.bar_k_lines_df, new_row], ignore_index=True)

        # 保持缓存长度
        if len(self.bar_k_lines_df) > self._k线缓存长度:
            self.bar_k_lines_df = self.bar_k_lines_df.tail(self._k线缓存长度).reset_index(drop=True)

        # 更新优化的历史K线缓存
        self._历史k线缓存 = self.bar_k_lines_df.copy()
        if not self._历史k线缓存.empty:
            self._历史k线缓存 = self._历史k线缓存.set_index('time_key')

    def on_order(self, order: OrderData) -> None:
        """委托更新"""
        if order.is_active():
            return
        self.仓位['委托时间'] = order.datetime
        self.write_debug(
            f"委托更新: {order.vt_orderid} {order.direction.value} {order.offset.value} "
            f"{order.status.name} @{order.price} {order.volume}"
        )
        self.put_event()

    def on_trade(self, trade: TradeData) -> None:
        """成交更新"""
        super().on_trade(trade)

        # 同步更新仓位状态
        if trade.offset.value in ["CLOSE", "CLOSETODAY", "CLOSEYESTERDAY"]:
            self.订单_id = ""
            self.仓位['持仓数量'] = 0
            self.仓位['平仓时间'] = trade.datetime
            self.仓位['平仓成交价格'] = trade.price
        else:
            self.仓位['持仓数量'] = int(self.pos)
            self.仓位['开仓时间'] = trade.datetime
            self.仓位['开仓成交价格'] = trade.price

        self.write_debug(
            f"成交更新: {trade.vt_orderid} {trade.direction.value} {trade.offset.value} "
            f"@{trade.price} {trade.volume}"
        )
        self.put_event()

    def on_stop_order(self, stop_order: StopOrder) -> None:
        """停止单更新"""
        self.write_debug(
            f"停止单更新:  {stop_order.direction.value} {stop_order.offset.value} "
            f"{stop_order.status.name} @{stop_order.price} {stop_order.volume}"
        )

    # 日志函数优化
    def write_info(self, msg: str) -> None:
        logger.info(f"[{self.策略名称}] {msg}")

    def write_debug(self, msg: str) -> None:
        logger.debug(f"[{self.策略名称}] {msg}")

    def write_warning(self, msg: str) -> None:
        logger.warning(f"[{self.策略名称}] {msg}")

    def write_error(self, msg: str) -> None:
        logger.error(f"[{self.策略名称}] {msg}")

    def 处理3分钟合成K线(self, bar: BarData):
        """处理3分钟合成K线"""
        if IS_DEBUG:
            print(f"3分钟K线更新: {bar.datetime} {bar.close_price} {bar.volume}")

    def 处理1分钟合成K线(self, bar: BarData) -> None:
        """处理1分钟合成K线（核心交易逻辑）"""
        self.当前k线_1分钟 = bar
        self.当前k线时间_1分钟 = bar.datetime.strftime("%Y-%m-%d %H:%M:%S")

        # 更新持仓状态
        if self.仓位['持仓数量'] != int(self.pos):
            self.仓位['持仓数量'] = int(self.pos)

        # 更新K线数据并执行交易判断
        if self.回测_更新k线的N种方法(方法="增量"):
            # 开仓判断
            if abs(int(self.pos)) == 0:
                self._开仓_判断(self.七福对象)
            # 平仓判断
            if abs(int(self.pos)) > 0 and self.订单_id != '':
                self._平仓_判断(self.七福对象)
            self._根据信号开平仓(self.七福对象)

        self.put_event()

    def _根据信号开平仓(self, 七福对象):
        res = 七福对象.七福信号
        if res.信号结果.value in ["看多", "看空"]:
            self._开仓_判断(七福对象)
        return res

    def 回测_更新k线的N种方法(self, 方法="增量") -> bool:
        """K线更新优化：增量更新代替全量传输"""
        try:
            # 获取最新K线（仅获取增量）
            ret, f历史k线 = self.获取历史K线(数量=self._k线缓存长度, 周期="K_1M")
            if ret != 0:
                self.write_debug(f"获取历史K线失败: {ret}")
                return False

            新k线 = f历史k线.tail(1)  # 仅取最新1根K线

            # 增量更新策略（性能最优）
            if 方法 == "增量":
                # 仅传递增量数据，避免全量拷贝
                self.七福对象.追加历史k线(新k线=新k线)
                self.七福对象.更新当前k线(当前k线=新k线)
                # 更新缓存引用
                self._历史k线缓存 = f历史k线
            elif 方法 == "历史数据":
                # 全量更新（仅用于初始化）
                七福参数 = self._获取七福参数配置(
                    更新参数={'当前k线': 新k线, '历史k线': f历史k线}
                )
                self.七福对象.设置参数(参数=七福参数)
            elif 方法 == "回测":
                self.七福对象.设置当前k线_回测(当前k线=新k线)

            return True

        except Exception as e:
            self.write_error(f"K线更新失败: {str(e)}")
            return False

    def _开仓_判断(self, 七福对象):
        """开仓判断逻辑 - 修复None值格式化问题"""
        参数 = 七福对象.获取参数()
        参数.update({
            '持仓数量': self.pos,
            '仓位': {'持仓数量': self.pos}
        })

        result = 七福对象.开仓检测(参数=参数)
        开仓id = int(result.get("id", "0"))

        # 多头开仓
        if 开仓id in [1001, 1003] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"

            # 修复：增加None值判断和默认值
            try:
                # 获取下单价格，增加多重容错
                if result.get('价格') and not pd.isna(result['价格']):
                    下单价格 = result['价格']
                elif not 七福对象._参数['当前k线'].empty:
                    下单价格 = 七福对象._参数['当前k线']['close'].iloc[0] if 'close' in 七福对象._参数[
                        '当前k线'].columns else 0.0
                else:
                    下单价格 = self.当前k线.close_price if hasattr(self, '当前k线') else 0.0
            except:
                下单价格 = 0.0

            备注 = result['判断详情']
            self.仓位['方向'] = '多头'

            order_ret, order_data = self.开仓(
                方向="buy", 价格=下单价格, 数量=self.下单数量,
                原因=原因, 备注=备注
            )

            # 修复：使用安全的格式化方式
            logger.debug(f"【开仓】多头，价格={下单价格 if 下单价格 else 0:.2f}, 数量={self.下单数量}, 原因={原因}")

        # 空头开仓
        elif 开仓id in [1002, 1004] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"

            # 修复：增加None值判断和默认值
            try:
                # 获取下单价格，增加多重容错
                if result.get('价格') and not pd.isna(result['价格']):
                    下单价格 = result['价格']
                elif not 七福对象._参数['当前k线'].empty:
                    下单价格 = 七福对象._参数['当前k线']['close'].iloc[0] if 'close' in 七福对象._参数[
                        '当前k线'].columns else 0.0
                else:
                    下单价格 = self.当前k线.close_price if hasattr(self, '当前k线') else 0.0
            except:
                下单价格 = 0.0

            备注 = result['判断详情']
            self.仓位['方向'] = '空头'

            order_ret, order_data = self.开仓(
                方向="sell", 价格=下单价格, 数量=self.下单数量,
                原因=原因, 备注=备注
            )

            # 修复：使用安全的格式化方式
            logger.debug(f"【开仓】空头，价格={下单价格 if 下单价格 else 0:.2f}, 数量={self.下单数量}, 原因={原因}")

    def _平仓_判断(self, 七福对象) -> Dict:
        """平仓判断逻辑"""
        result = {"success": False, "msg": ""}

        try:
            result_平仓规则 = 七福对象.平仓判断(参数=七福对象.获取参数())
            平仓规则 = result_平仓规则.get("平仓规则")

            if 平仓规则:
                推荐平仓方向 = 平仓规则.get('推荐平仓方向', '')
                # 修复：None值处理
                推荐平仓价格 = 平仓规则.get('推荐平仓价格', 0.0) or 0.0
                推荐平仓数量 = 平仓规则.get('推荐平仓数量', abs(int(self.pos))) or abs(int(self.pos))
                平仓ID = result_平仓规则.get('id', '')
                备注 = result_平仓规则

                原因 = f"<{平仓ID}>{平仓规则['原因']}"
                code, 平仓详细 = self.平仓(
                    价格=推荐平仓价格, 方向=推荐平仓方向,
                    数量=推荐平仓数量, 原因=原因, 备注=备注
                )

                result = {
                    'success': (code == RET_OK),
                    'msg': 平仓详细,
                    'code': code,
                    'id': 平仓ID,
                    **平仓规则
                }

        except Exception as e:
            result['msg'] = f"平仓判断异常: {str(e)}"
            self.write_error(f"平仓判断失败: {str(e)}")

        return result

    def 开仓(self, 价格=0, 方向: str = "buy", 数量: int = 1,
             原因: str | Dict = "", 备注=None) -> tuple:
        """开仓函数 - 批量缓存记录 + None值修复"""
        self._开仓次数 += 1
        ret = -1
        开仓返回信息 = ""

        # 修复：价格参数None值处理
        价格 = 价格 or 0.0

        try:
            if abs(self.pos) <= abs(self.最大持仓量):
                开仓成功订单号 = ""
                if 方向 in ("buy", "long"):
                    开仓成功订单号 = self.buy(价格, 数量)
                elif 方向 in ("sell", "short"):
                    开仓成功订单号 = self.short(价格, 数量)

                if 开仓成功订单号:
                    ret = 0
                    self.订单_id = 开仓成功订单号

                    # 更新仓位信息
                    self.仓位.update({
                        '开仓订单id': 开仓成功订单号,
                        '持仓数量': int(self.pos),
                        '开仓数量': 数量,
                        '开仓价格': 价格,
                        '开仓方向': 方向,
                        '委托开仓时间': self.当前k线.datetime if hasattr(self, '当前k线') else datetime.now()
                    })

                    开仓返回信息 = {
                        '状态': 'success', '订单号': 开仓成功订单号,
                        '方向': 方向, '价格': 价格, '数量': 数量, '原因': 原因
                    }

                    # 回测环境：缓存记录（批量写入）
                    if self.获取引擎环境() == "BACKTESTING":
                        try:
                            原因_str = self._格式化原因(原因)

                            # 添加到批量缓存
                            self._批量开仓记录缓存.append({
                                "订单号": 开仓成功订单号,
                                "交易品种": self.fw_symbol,
                                "委托方向": 方向,
                                "操作价格": 价格,
                                "操作数量": 数量,
                                "操作时间": self.当前k线.datetime if hasattr(self, '当前k线') else datetime.now(),
                                "操作原因": 原因_str,
                                "持仓方向": 方向,
                                "开仓价格": 价格,
                                "当前持仓数量": 数量,
                                "备注信息": f"<判断详情>：{备注}"
                            })

                        except Exception as e:
                            self.write_error(f"缓存开仓记录失败: {str(e)}")
                else:
                    开仓返回信息 = {
                        '状态': 'failed', '订单号': '',
                        '方向': 方向, '价格': 价格, '数量': 数量, '原因': 原因
                    }
            else:
                开仓返回信息 = f"开仓失败: 超出最大持仓限制, 当前持仓: {self.pos}, 最大持仓: {self.最大持仓量}"

        except Exception as e:
            self.write_error(f"开仓异常: {str(e)}\n{traceback.format_exc()}")
            ret = -2
            开仓返回信息 = f"开仓异常: {str(e)}"

        finally:
            self.开仓平仓日志(f"开仓：{开仓返回信息}")
            return ret, 开仓返回信息

    def 平仓(self, 方向: str = "buy", 价格=0, 数量: int = 0,
             原因: str | Dict = "", 备注=None) -> tuple:
        """平仓函数 - 批量缓存记录 + None值修复"""
        self._平仓次数 += 1
        ret = -1
        平仓返回信息 = ""

        # 修复：参数None值处理
        价格 = 价格 or 0.0
        数量 = abs(int(self.pos)) if 数量 == 0 else 数量

        try:
            平仓成功订单号 = ""

            # 平多
            if self.pos > 0:
                if 方向 in ("buy", "long"):
                    平仓成功订单号 = self.sell(价格, 数量)
                else:
                    ret, 平仓返回信息 = -1, f"平多失败: 持仓方向不匹配"
            # 平空
            elif self.pos < 0:
                if 方向 in ("sell", "short"):
                    平仓成功订单号 = self.cover(价格, 数量)
                else:
                    ret, 平仓返回信息 = -2, f"平空失败: 持仓方向不匹配"
            else:
                ret, 平仓返回信息 = -3, f"平仓失败: 无持仓"

            if 平仓成功订单号:
                ret = 0
                # 更新仓位状态
                self.订单_id = ""
                self.仓位.update({
                    '平仓订单id': 平仓成功订单号,
                    '平仓数量': 数量,
                    '平仓价格': 价格,
                    '平仓方向': 方向,
                    '持仓数量': 0,
                    '平仓下单时间': self.当前k线.datetime if hasattr(self, '当前k线') else datetime.now()
                })

                平仓返回信息 = {
                    'order_id': 平仓成功订单号, '方向': 方向,
                    '价格': 价格, '数量': 数量, '原因': 原因
                }

                # 回测环境：缓存记录
                if self.获取引擎环境() == "BACKTESTING":
                    try:
                        原因_str = self._格式化原因(原因)

                        # 缓存平仓记录
                        平仓记录 = {
                            "订单号": 平仓成功订单号,
                            "委托方向": 方向,
                            "交易品种": self.fw_symbol,
                            "操作价格": 价格,
                            "操作数量": 数量,
                            "操作时间": self.当前k线.datetime if hasattr(self, '当前k线') else datetime.now(),
                            "操作原因": 原因_str,
                            "持仓方向": self.仓位.get('开仓方向', ''),
                            "开仓价格": self.仓位.get('开仓价格', 0),
                            "当前持仓数量": 0,
                            "备注信息": f"<判断详情>：{备注}"
                        }
                        self._批量平仓记录缓存.append(平仓记录)

                        # 缓存交易结果（关联开仓平仓）
                        if self.订单_id in [r['订单号'] for r in self._批量开仓记录缓存]:
                            开仓记录 = next(
                                r for r in self._批量开仓记录缓存
                                if r['订单号'] == self.仓位.get('开仓订单id')
                            )

                            self._批量交易结果缓存.append({
                                '开仓订单号': self.仓位.get('开仓订单id'),
                                '平仓订单号': 平仓成功订单号,
                                '开仓时间': 开仓记录['操作时间'],
                                '平仓时间': self.当前k线.datetime if hasattr(self, '当前k线') else datetime.now(),
                                '开仓价格': 开仓记录['操作价格'],
                                '平仓价格': 价格,
                                '开仓方向': 开仓记录['持仓方向'],
                                '操作数量': 数量,
                                '交易备注': str(原因)
                            })

                    except Exception as e:
                        self.write_error(f"缓存平仓记录失败: {str(e)}\n{traceback.format_exc()}")

        except Exception as e:
            self.write_error(f"平仓异常: {str(e)}\n{traceback.format_exc()}")
            ret = -4
            平仓返回信息 = f"平仓异常: {str(e)}"

        finally:
            self.开仓平仓日志(f"平仓：{平仓返回信息}")
            return ret, 平仓返回信息

    def _格式化原因(self, 原因) -> str:
        """格式化原因字符串 - 增加None值处理"""
        if 原因 is None:
            return "无原因"
        elif isinstance(原因, dict):
            return f"原因：{原因.get('id', '')},{原因.get('判断详情', {}).get('最终说明', '') or 原因.get('原因', '')}"
        return str(原因)

    def 开仓平仓日志(self, msg: str) -> None:
        """开平仓日志 - 增加空值判断"""
        try:
            if not self.bar_k_lines_df.empty:
                self.当前k线时间 = datetime.strftime(
                    self.bar_k_lines_df['time_key'].iloc[-1],
                    "%Y-%m-%d %H:%M:%S"
                )
                msg = f"<开仓平仓日志>[{self.当前k线时间}] {msg}"
                self.write_info(msg)
        except:
            # 日志记录失败时不影响主流程
            self.write_info(f"<开仓平仓日志>[未知时间] {msg}")

    def 获取引擎环境(self) -> str:
        """判断引擎环境"""
        return getattr(self.cta_engine, 'gateway_name', '')

    def 获得当前回测引擎所有历史数据_df(self, history_data) -> pd.DataFrame:
        """转换历史数据为DataFrame"""
        if not history_data:
            self.write_warning("历史数据为空！")
            return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'volume', 'time_key'])

        # 批量转换（优化性能）
        data_list = [{
            'open': bar.open_price,
            'high': bar.high_price,
            'low': bar.low_price,
            'close': bar.close_price,
            'volume': bar.volume,
            'time_key': bar.datetime
        } for bar in history_data]

        df = pd.DataFrame(data_list)
        df['time_key'] = pd.to_datetime(df['time_key'])
        df = df.set_index('time_key').sort_index()

        # 类型转换优化
        numeric_cols = ['open', 'high', 'low', 'close', 'volume']
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors='coerce')

        return df

    def 获取历史K线(self, 数量: int = 120, 周期: str = "K_1M") -> tuple:
        """优化版获取历史K线 - 增加异常处理"""
        支持的周期 = {"K_1M": "1min", "K_3M": "3min", "K_5M": "5min"}

        if 周期 not in 支持的周期:
            return -1, f"不支持的周期：{周期}"

        if self.bar_k_lines_df.empty:
            return -2, "未加载任何K线数据"

        try:
            df = self.bar_k_lines_df.copy()

            # 只在必要时排序
            if not df['time_key'].is_monotonic_increasing:
                df = df.sort_values('time_key')

            实际数量 = min(数量, len(df))

            # 1分钟K线直接返回
            if 周期 == "K_1M":
                结果df = df.iloc[-实际数量:]
            else:
                # 重采样优化
                原始数据量 = 实际数量 * int(支持的周期[周期][0]) + 5
                原始数据量 = min(原始数据量, len(df))

                df_重采样 = df.iloc[-原始数据量:].set_index('time_key')
                聚合规则 = {
                    'open': 'first', 'high': 'max', 'low': 'min',
                    'close': 'last', 'volume': 'sum'
                }

                结果df = df_重采样.resample(支持的周期[周期]).agg(聚合规则).dropna()
                结果df = 结果df.iloc[-实际数量:].reset_index()

            # 列处理
            目标列 = ['open', 'high', 'low', 'close', 'volume', 'time_key']
            结果df = 结果df.reindex(columns=目标列, fill_value=0)

            if not 结果df.empty:
                结果df['last_price'] = 结果df['close']

            return 0, 结果df

        except Exception as e:
            self.write_error(f"获取K线异常: {str(e)}")
            return -3, f"获取K线异常：{str(e)}"

    def _导出交易记录(self) -> Dict:
        """导出交易记录"""
        result = {"success": False, "msg": "", "file_path": None}

        try:
            if self.获取引擎环境() == "BACKTESTING":
                统计信息 = self.交易记录器.获取交易统计()
                if 统计信息 and 统计信息.get("总交易数", 0) > 0:
                    文件路径 = self.交易记录器.导出交易记录()
                    result = {
                        "success": True,
                        "msg": "交易记录导出成功",
                        "file_path": 文件路径
                    }
                else:
                    result = {"success": True, "msg": "没有交易记录需要导出"}
            else:
                result = {"success": True, "msg": "非回测环境，无需导出"}

        except Exception as e:
            result = {
                "success": False,
                "msg": f"导出失败: {str(e)}",
                "traceback": traceback.format_exc()
            }

        return result

    def 创建回测任务(self) -> Dict:
        """创建回测任务 - 增加属性容错"""
        try:
            result = self.交易记录器.创建回测任务(
                cta_engine=self.cta_engine,
                strategy=self,
                回测名称=self.回测任务ID or self.策略名称,
                交易品种=getattr(self.cta_engine, 'symbol', ''),
                初始资金=getattr(self.cta_engine, 'capital', 0),
                手续费率=getattr(self.cta_engine, 'rate', 0),
                滑点=getattr(self.cta_engine, 'risk_free', 0),
                合约乘数=getattr(self.cta_engine, 'size', 1),
                回测备注="七福策略回测-fuwen自带回测系统！"
            )
            self.回测任务ID = result.get('回测任务ID')
            return result
        except Exception as e:
            self.write_error(f"创建回测任务失败: {str(e)}")
            return {"success": False, "msg": str(e)}

    def 更新回测任务(self) -> Dict:
        """更新回测任务 - 增加容错"""
        try:
            回测引擎 = self.回测引擎 or self.cta_engine
            return self.交易记录器.更新回测任务(
                cta_engine=回测引擎,
                回测任务ID=self.回测任务ID,
                回测状态="已完成",
                回测备注=f"回测完成，总耗时：{self.策略停止时间 - self.策略开启时间 if self.策略停止时间 and self.策略开启时间 else '未知'}"
            )
        except Exception as e:
            self.write_error(f"更新回测任务失败: {str(e)}")
            return {"success": False, "msg": str(e)}
