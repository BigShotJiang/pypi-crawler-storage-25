from fuwen_config.setting import *

if __name__ == '__main__':
    print(f"SETTING_FILENAME: {SETTING_FILENAME}")
    pass
