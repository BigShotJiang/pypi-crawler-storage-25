import base64
import hashlib
import hmac
import json
import time
from copy import copy
from datetime import datetime
from urllib.parse import urlencode
from types import TracebackType
from collections.abc import Callable
from time import sleep
from typing import cast

from fuwen_adaptor.event import EventEngine, Event, EVENT_TIMER
from fuwen_adaptor.trader.constant import (
    Direction,
    Exchange,
    Interval,
    Offset,
    OrderType,
    Product,
    Status
)
from fuwen_adaptor.trader.gateway import BaseGateway
from fuwen_adaptor.trader.utility import round_to, ZoneInfo
from fuwen_adaptor.trader.object import (
    AccountData,
    BarData,
    CancelRequest,
    ContractData,
    HistoryRequest,
    OrderData,
    OrderRequest,
    PositionData,
    SubscribeRequest,
    TickData,
    TradeData
)
from fuwen.core.公共函数 import fw_float
from fuwen_rest import Request, Response, RestClient
from fuwen_websocket import WebsocketClient

# UTC时区
UTC_TZ: ZoneInfo = ZoneInfo("UTC")

# 真实服务器地址
REAL_REST_HOST: str = "https://www.okx.com"
REAL_PUBLIC_HOST: str = "wss://ws.okx.com:8443/ws/v5/public"
REAL_PRIVATE_HOST: str = "wss://ws.okx.com:8443/ws/v5/private"
REAL_BUSINESS_HOST: str = "wss://ws.okx.com:8443/ws/v5/business"

# 模拟服务器地址
DEMO_REST_HOST: str = "https://www.okx.com"
DEMO_PUBLIC_HOST: str = "wss://wspap.okx.com:8443/ws/v5/public"
DEMO_PRIVATE_HOST: str = "wss://wspap.okx.com:8443/ws/v5/private"
DEMO_BUSINESS_HOST: str = "wss://wspap.okx.com:8443/ws/v5/business"

# 订单状态映射
STATUS_OKX2VT: dict[str, Status] = {
    "live": Status.NOTTRADED,
    "partially_filled": Status.PARTTRADED,
    "filled": Status.ALLTRADED,
    "canceled": Status.CANCELLED,
    "mmp_canceled": Status.CANCELLED
}

# 订单类型映射
ORDERTYPE_OKX2VT: dict[str, OrderType] = {
    "market": OrderType.MARKET,
    "limit": OrderType.LIMIT,
    "fok": OrderType.FOK,
    "ioc": OrderType.FAK
}
ORDERTYPE_VT2OKX: dict[OrderType, str] = {v: k for k, v in ORDERTYPE_OKX2VT.items()}

# 方向映射
DIRECTION_OKX2VT: dict[str, Direction] = {
    "buy": Direction.LONG,
    "sell": Direction.SHORT
}
DIRECTION_VT2OKX: dict[Direction, str] = {v: k for k, v in DIRECTION_OKX2VT.items()}

# K线周期映射
INTERVAL_VT2OKX: dict[Interval, str] = {
    Interval.MINUTE: "1m",
    Interval.HOUR: "1H",
    Interval.DAILY: "1D",
}

# 产品类型映射
PRODUCT_OKX2VT: dict[str, Product] = {
    "SWAP": Product.SWAP,
    "SPOT": Product.SPOT,
    "FUTURES": Product.FUTURES
}
PRODUCT_VT2OKX: dict[Product, str] = {v: k for k, v in PRODUCT_OKX2VT.items()}


class OkxGateway(BaseGateway):
    """
    OKX交易网关（VeighNa框架）
    仅支持净持仓模式
    """

    default_name = "OKX"

    default_setting: dict = {
        "API Key": "",
        "Secret Key": "",
        "Passphrase": "",
        "Server": ["REAL", "DEMO"],
        "Proxy Host": "",
        "Proxy Port": 0,
        "Spread Trading": ["False", "True"],
        "Margin Currency": ""
    }

    exchanges: list[Exchange] = [Exchange.GLOBAL]

    def __init__(self, event_engine: EventEngine, gateway_name: str) -> None:
        """
        网关初始化方法
        event_engine: VeighNa全局事件引擎对象
        gateway_name: 网关唯一标识名称
        """
        super().__init__(event_engine, gateway_name)

        self.key: str = ""
        self.secret: str = ""
        self.passphrase: str = ""
        self.server: str = ""
        self.proxy_host: str = ""
        self.proxy_port: int = 0
        self.spread_trading: bool = False
        self.margin_currency: str = ""

        self.orders: dict[str, OrderData] = {}
        self.local_orderids: set[str] = set()

        self.symbol_contract_map: dict[str, ContractData] = {}
        self.name_contract_map: dict[str, ContractData] = {}

        self.rest_api: RestApi = RestApi(self)
        self.public_api: PublicApi = PublicApi(self)
        self.private_api: PrivateApi = PrivateApi(self)
        self.business_api: BusinessApi = BusinessApi(self)

        self.ping_count: int = 0
        self.ping_interval: int = 20

        self.subscribed_symbols: set[str] = set()

    def connect(self, setting: dict) -> None:
        """
        连接服务器
        使用提供的配置参数建立与OKX服务器的连接
        参数:
            setting: 包含连接参数的字典，包括API凭证、服务器选择和代理配置
        """
        self.key = setting["API Key"]
        self.secret = setting["Secret Key"]
        self.passphrase = setting["Passphrase"]
        self.server = setting["Server"]
        self.proxy_host = setting["Proxy Host"]
        self.proxy_port = setting["Proxy Port"]
        self.spread_trading = setting["Spread Trading"] == "True"
        self.margin_currency = setting["Margin Currency"]

        self.rest_api.connect(
            self.key,
            self.secret,
            self.passphrase,
            self.server,
            self.proxy_host,
            self.proxy_port,
            self.spread_trading
        )

    def connect_ws_api(self) -> None:
        """
        连接OKX WebSocket API
        """
        self.public_api.connect(
            self.server,
            self.proxy_host,
            self.proxy_port,
        )
        self.private_api.connect(
            self.key,
            self.secret,
            self.passphrase,
            self.server,
            self.proxy_host,
            self.proxy_port,
            self.margin_currency,
        )

        if self.spread_trading:
            self.business_api.connect(
                self.key,
                self.secret,
                self.passphrase,
                self.server,
                self.proxy_host,
                self.proxy_port,
            )

        self.event_engine.register(EVENT_TIMER, self.process_timer_event)

    def subscribe(self, req: SubscribeRequest) -> None:
        """
        订阅行情数据
        参数:
            req: 包含合约信息的订阅请求对象
        """
        # 检查合约是否存在
        contract: ContractData | None = self.symbol_contract_map.get(req.symbol, None)
        if not contract:
            self.write_log(f"订阅失败，合约不存在: {req.symbol}")
            return

        # 过滤重复订阅
        if req.fw_symbol in self.subscribed_symbols:
            return
        self.subscribed_symbols.add(req.fw_symbol)

        # 发送请求到相应的API
        if contract.product == Product.SPREAD:
            self.business_api.subscribe(req)
        else:
            self.public_api.subscribe(req)

    def send_order(self, req: OrderRequest) -> str:
        """
        发送新订单到OKX
        此函数将订单委托给私有WebSocket API处理，API负责验证、生成订单并提交到交易所
        参数:
            req: 包含订单详情的订单请求对象
        返回:
            str: 成功时返回VeighNa订单ID，失败时返回空字符串
        """
        contract: ContractData | None = self.symbol_contract_map.get(req.symbol, None)
        if not contract:
            self.write_log(f"下单失败，合约不存在: {req.symbol}")
            return ""

        if contract.product == Product.SPREAD:
            return self.business_api.send_order(req)
        else:
            return self.private_api.send_order(req)

    def cancel_order(self, req: CancelRequest) -> None:
        """
        取消OKX上的订单
        此函数将订单取消请求委托给私有WebSocket API处理，API负责确定使用的ID类型并提交请求
        参数:
            req: 包含订单详情的取消请求对象
        """
        contract: ContractData | None = self.symbol_contract_map.get(req.symbol, None)
        if not contract:
            self.write_log(f"撤单失败，合约不存在: {req.symbol}")
            return

        if contract.product == Product.SPREAD:
            self.business_api.cancel_order(req)
        else:
            self.private_api.cancel_order(req)

    def query_account(self) -> None:
        """
        查询账户余额
        此方法未实现，因为OKX通过WebSocket API提供账户余额更新
        """
        pass

    def query_position(self) -> None:
        """
        查询持仓
        此方法未实现，因为OKX通过WebSocket API提供持仓更新
        """
        pass

    def query_history(self, req: HistoryRequest) -> list[BarData]:
        """
        查询历史K线数据
        参数:
            req: 包含查询参数的历史请求对象
        返回:
            list[BarData]: 历史K线数据列表
        """
        contract: ContractData | None = self.symbol_contract_map.get(req.symbol, None)
        if not contract:
            self.write_log(f"查询历史失败，合约不存在: {req.symbol}")
            return []

        if contract.product == Product.SPREAD:
            return self.rest_api.query_spread_history(req)
        else:
            return self.rest_api.query_history(req)

    def close(self) -> None:
        """
        关闭服务器连接
        此方法停止所有API连接并释放资源
        """
        self.rest_api.stop()
        self.public_api.stop()
        self.private_api.stop()
        self.business_api.stop()

    def on_order(self, order: OrderData) -> None:
        """
        缓存订单数据并推送订单事件
        参数:
            order: 订单数据对象
        """
        self.orders[order.orderid] = order
        super().on_order(order)

    def get_order(self, orderid: str) -> OrderData | None:
        """
        根据订单ID获取已保存的订单
        参数:
            orderid: 要获取的订单ID
        返回:
            OrderData: 找到的订单数据对象，未找到返回None
        """
        return self.orders.get(orderid, None)

    def on_contract(self, contract: ContractData) -> None:
        """
        缓存合约数据并推送合约事件
        参数:
            contract: 合约数据对象
        """
        self.symbol_contract_map[contract.symbol] = contract
        self.name_contract_map[contract.name] = contract

        super().on_contract(contract)

    def get_contract_by_symbol(self, symbol: str) -> ContractData | None:
        """
        根据VeighNa合约代码获取合约
        参数:
            symbol: 合约代码
        返回:
            ContractData: 找到的合约数据对象，未找到返回None
        """
        return self.symbol_contract_map.get(symbol, None)

    def get_contract_by_name(self, name: str) -> ContractData | None:
        """
        根据交易所合约名称获取合约
        参数:
            name: 合约名称
        返回:
            ContractData: 找到的合约数据对象，未找到返回None
        """
        return self.name_contract_map.get(name, None)

    def parse_order_data(self, data: dict, gateway_name: str) -> OrderData:
        """
        解析字典为订单数据
        此函数将OKX订单数据转换为VeighNa OrderData对象，从交易所响应中提取并映射所有相关字段
        参数:
            data: 来自OKX的订单数据
            gateway_name: 用于标识的网关名称
        返回:
            OrderData: VeighNa订单对象
        """
        contract: ContractData = cast(ContractData, self.get_contract_by_name(data["instId"]))

        order_id: str = data["clOrdId"]
        if order_id:
            self.local_orderids.add(order_id)
        else:
            order_id = data["ordId"]

        order: OrderData = OrderData(
            symbol=contract.symbol,
            exchange=Exchange.GLOBAL,
            type=ORDERTYPE_OKX2VT[data["ordType"]],
            orderid=order_id,
            direction=DIRECTION_OKX2VT[data["side"]],
            offset=Offset.NONE,
            traded=fw_float(data["accFillSz"]),
            price=fw_float(data["px"]),
            volume=fw_float(data["sz"]),
            datetime=parse_timestamp(data["cTime"]),
            status=STATUS_OKX2VT[data["state"]],
            gateway_name=gateway_name,
        )
        return order

    def parse_spread_order_data(self, data: dict, gateway_name: str) -> OrderData:
        """
        解析字典为价差订单数据
        此函数将OKX价差订单数据转换为VeighNa OrderData对象，从交易所响应中提取并映射所有相关字段
        参数:
            data: 来自OKX的订单数据
            gateway_name: 用于标识的网关名称
        返回:
            OrderData: VeighNa订单对象
        """
        contract: ContractData = cast(ContractData, self.get_contract_by_name(data["sprdId"]))

        order_id: str = data["clOrdId"]
        if order_id:
            self.local_orderids.add(order_id)
        else:
            order_id = data["ordId"]

        order: OrderData = OrderData(
            symbol=contract.symbol,
            exchange=Exchange.GLOBAL,
            type=ORDERTYPE_OKX2VT[data["ordType"]],
            orderid=order_id,
            direction=DIRECTION_OKX2VT[data["side"]],
            offset=Offset.NONE,
            traded=fw_float(data["accFillSz"]),
            price=fw_float(data["px"]),
            volume=fw_float(data["sz"]),
            datetime=parse_timestamp(data["cTime"]),
            status=STATUS_OKX2VT[data["state"]],
            gateway_name=gateway_name,
        )
        return order

    def process_timer_event(self, event: Event) -> None:
        """
        处理定时器事件，用于发送心跳消息
        """
        self.ping_count += 1
        if self.ping_count < self.ping_interval:
            return
        self.ping_count = 0

        self.private_api.send_ping()
        self.public_api.send_ping()
        self.business_api.send_ping()


class RestApi(RestClient):
    """OKX网关的REST API"""

    def __init__(self, gateway: OkxGateway) -> None:
        """
        API初始化方法
        参数:
            gateway: 父网关对象，用于推送回调数据
        """
        super().__init__()

        self.gateway: OkxGateway = gateway
        self.gateway_name: str = gateway.gateway_name

        self.key: str = ""
        self.secret: bytes = b""
        self.passphrase: str = ""
        self.simulated: bool = False

        self.product_ready: set = set()

    def sign(self, request: Request) -> Request:
        """
        请求签名的标准回调
        此方法为需要API密钥认证的请求添加必要的认证参数和签名
        参数:
            request: 待签名的请求对象
        返回:
            Request: 添加了认证参数的修改后请求
        """
        # 为模拟服务器添加模拟交易头（适用于所有请求）
        if self.simulated:
            if not request.headers:
                request.headers = {"x-simulated-trading": "1"}
            else:
                request.headers["x-simulated-trading"] = "1"

        # 公共API不需要签名
        if "public" in request.path:
            return request

        # 生成签名
        timestamp: str = generate_timestamp()

        if request.data:
            request.data = json.dumps(request.data)
        else:
            request.data = ""

        if request.params:
            path: str = request.path + "?" + urlencode(request.params)
        else:
            path = request.path

        msg: str = timestamp + request.method + path + request.data
        signature: bytes = generate_signature(msg, self.secret)

        # 添加请求头
        request.headers = {
            "OK-ACCESS-KEY": self.key,
            "OK-ACCESS-SIGN": signature.decode(),
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": self.passphrase,
            "Content-Type": "application/json"
        }

        if self.simulated:
            request.headers["x-simulated-trading"] = "1"

        return request

    def connect(
            self,
            key: str,
            secret: str,
            passphrase: str,
            server: str,
            proxy_host: str,
            proxy_port: int,
            spread_trading: bool
    ) -> None:
        """
        连接服务器
        使用提供的凭证和配置建立与OKX REST API服务器的连接
        参数:
            key: 用于认证的API Key
            secret: 用于请求签名的API Secret
            passphrase: 用于认证的API Passphrase
            server: 服务器类型（"REAL" 或 "DEMO"）
            proxy_host: 代理服务器主机名或IP
            proxy_port: 代理服务器端口
            spread_trading: 是否启用价差交易
        """
        self.key = key
        self.secret = secret.encode()
        self.passphrase = passphrase

        if server == "DEMO":
            self.simulated = True

        self.connect_time = int(datetime.now().strftime("%y%m%d%H%M%S"))

        server_hosts: dict[str, str] = {
            "REAL": REAL_REST_HOST,
            "DEMO": DEMO_REST_HOST,
        }

        host: str = server_hosts[server]
        self.init(host, proxy_host, proxy_port)

        self.start()
        self.gateway.write_log("REST API已启动")

        self.query_time()
        self.query_contract()

        if spread_trading:
            self.query_spread()

    def query_time(self) -> None:
        """
        查询服务器时间
        发送请求获取交易所服务器时间，用于同步本地时间与服务器时间
        """
        self.add_request(
            "GET",
            "/api/v5/public/time",
            callback=self.on_query_time
        )

    def query_order(self) -> None:
        """
        查询开放订单
        发送请求获取所有未完全成交或取消的活跃订单
        """
        self.add_request(
            "GET",
            "/api/v5/trade/orders-pending",
            callback=self.on_query_order,
        )

    def query_contract(self) -> None:
        """
        查询可交易合约
        发送请求获取交易所信息，包括所有可交易产品及其规格
        """
        for inst_type in PRODUCT_OKX2VT.keys():
            self.add_request(
                "GET",
                "/api/v5/public/instruments",
                callback=self.on_query_contract,
                params={"instType": inst_type}
            )

    def query_spread(self) -> None:
        """
        查询可交易价差合约
        发送请求获取所有可交易价差合约
        """
        self.add_request(
            "GET",
            "/api/v5/sprd/spreads",
            callback=self.on_query_spread
        )

    def query_spread_order(self) -> None:
        """
        查询开放价差订单
        发送请求获取所有未完全成交或取消的活跃价差订单
        """
        if not self.key:
            return

        self.add_request(
            "GET",
            "/api/v5/sprd/orders-pending",
            callback=self.on_query_spread_order,
        )

    def on_query_time(self, packet: dict, request: Request) -> None:
        """
        服务器时间查询回调
        处理服务器时间响应，计算本地时间与服务器时间的差异并记录日志
        参数:
            packet: 服务器响应数据
            request: 原始请求对象
        """
        timestamp: int = int(packet["data"][0]["ts"])
        server_time: datetime = datetime.fromtimestamp(timestamp / 1000, UTC_TZ)
        local_time: datetime = datetime.now()

        msg: str = f"服务器时间: {server_time}, 本地时间: {local_time}"
        self.gateway.write_log(msg)

    def on_query_order(self, packet: dict, request: Request) -> None:
        """
        开放订单查询回调
        处理开放订单响应，为每个活跃订单创建OrderData对象
        参数:
            packet: 服务器响应数据
            request: 原始请求对象
        """
        for order_info in packet["data"]:
            order: OrderData = self.gateway.parse_order_data(
                order_info,
                self.gateway_name
            )
            self.gateway.on_order(order)

        self.gateway.write_log("订单数据已接收")

    def on_query_contract(self, packet: dict, request: Request) -> None:
        """
        可交易合约查询回调
        处理交易所信息响应，为每个交易产品创建ContractData对象
        参数:
            packet: 服务器响应数据
            request: 原始请求对象
        """
        data: list = packet["data"]

        if not data:
            return

        for d in data:
            name: str = d["instId"]
            product: Product = PRODUCT_OKX2VT[d["instType"]]
            net_position: bool = True

            if product == Product.SPOT:
                size: float = 1
            elif d["ctVal"]:
                size = float(d["ctVal"])
            else:
                size = 1

            match product:
                case Product.SPOT:
                    symbol: str = name.replace("-", "") + "_SPOT_OKX"
                case Product.SWAP:
                    base, quote, _ = name.split("-")
                    symbol = base + quote + "_SWAP_OKX"
                case Product.FUTURES:
                    symbol_parts: list[str] = name.split("-")
                    if len(symbol_parts) < 3:
                        continue

                    base, quote, expiry = symbol_parts
                    symbol = base + quote + "_" + expiry + "_OKX"

            if d["tickSz"]:
                pricetick: float = float(d["tickSz"])
            else:
                pricetick = 0

            if d["minSz"]:
                min_volume: float = float(d["minSz"])
            else:
                min_volume = 0

            contract: ContractData = ContractData(
                symbol=symbol,
                exchange=Exchange.GLOBAL,
                name=name,
                product=product,
                size=size,
                pricetick=pricetick,
                min_volume=min_volume,
                history_data=True,
                net_position=net_position,
                gateway_name=self.gateway_name,
            )
            contract.extra = d

            self.gateway.on_contract(contract)

        inst_type: str = request.params["instType"]
        self.gateway.write_log(f"{inst_type}合约数据已接收")

        # 所有合约数据接收完成后连接WebSocket API
        self.product_ready.add(PRODUCT_OKX2VT[inst_type])

        if len(self.product_ready) == len(PRODUCT_OKX2VT):
            self.query_order()

            self.gateway.connect_ws_api()

    def on_query_spread(self, packet: dict, request: Request) -> None:
        """
        可交易价差合约查询回调
        处理交易所信息响应，为每个价差合约创建ContractData对象
        参数:
            packet: 服务器响应数据
            request: 原始请求对象
        """
        data: list = packet["data"]

        for d in data:
            leg_symbols: list[str] = []
            for leg in d["legs"]:
                leg_name: str = leg["instId"]
                leg_contract: ContractData = cast(ContractData, self.gateway.get_contract_by_name(leg_name))
                leg_symbols.append(leg_contract.symbol)

            contract: ContractData = ContractData(
                symbol="-".join(leg_symbols),
                exchange=Exchange.GLOBAL,
                name=d["sprdId"],
                product=Product.SPREAD,
                size=float(d["lotSz"]),
                pricetick=float(d["tickSz"]),
                min_volume=float(d["minSz"]),
                history_data=True,
                net_position=True,
                gateway_name=self.gateway_name,
            )

            self.gateway.on_contract(contract)

        self.gateway.write_log("价差合约数据已接收")

        self.query_spread_order()

    def on_query_spread_order(self, packet: dict, request: Request) -> None:
        """
        开放价差订单查询回调
        处理开放订单响应，为每个活跃价差订单创建OrderData对象
        参数:
            packet: 服务器响应数据
            request: 原始请求对象
        """
        for order_info in packet["data"]:
            order: OrderData = self.gateway.parse_spread_order_data(
                order_info,
                self.gateway_name
            )
            self.gateway.on_order(order)

        self.gateway.write_log("价差订单数据已接收")

    def on_error(
            self,
            exc: type,
            value: Exception,
            tb: TracebackType,
            request: Request
    ) -> None:
        """
        通用错误回调
        REST API请求发生异常时调用此函数，记录异常详情用于故障排除
        参数:
            exc: 异常类型
            value: 异常实例
            tb: 回溯对象
            request: 原始请求对象
        """
        detail: str = self.exception_detail(exc, value, tb, request)
        # 转义花括号以防止loguru将其解释为格式占位符
        detail = detail.replace("{", "{{").replace("}", "}}")

        msg: str = f"REST API捕获异常: {detail}"
        self.gateway.write_log(msg)

    def _query_history(
            self,
            req: HistoryRequest,
            path: str,
            id_key: str,
            bar_parser: Callable[[list, HistoryRequest], BarData]
    ) -> list[BarData]:
        """
        查询K线历史数据的通用辅助方法
        """
        # 验证合约是否存在
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"查询K线历史失败，合约不存在: {req.symbol}")
            return []

        # 验证周期不为空
        if not req.interval:
            self.gateway.write_log(f"查询K线历史失败，周期为空: {req.symbol}")
            return []

        # 初始化存储K线的缓冲区
        buf: dict[datetime, BarData] = {}
        limit: str = "100"

        if not req.end:
            req.end = datetime.now(UTC_TZ)

        after: str = str(int(req.end.timestamp() * 1000))

        # 循环查询直到没有更多数据或请求失败
        while True:
            # 添加小延迟避免触发限流
            sleep(0.1)

            # 创建查询参数
            params: dict = {
                id_key: contract.name,
                "bar": INTERVAL_VT2OKX[req.interval],
                "limit": limit,
                "after": after
            }

            # 从服务器获取响应
            resp: Response = self.request(
                "GET",
                path,
                params=params
            )

            # 请求失败时退出循环
            if resp.status_code // 100 != 2:
                log_msg: str = f"查询K线历史失败，状态码: {resp.status_code}, 消息: {resp.text}"
                self.gateway.write_log(log_msg)
                break
            else:
                data: dict = resp.json()
                bar_data: list | None = data.get("data", None)

                if not bar_data:
                    msg: str = data.get("msg", "未返回数据")
                    log_msg = f"未收到K线历史数据, {msg}"
                    self.gateway.write_log(log_msg)
                    break

                for row in bar_data:
                    bar: BarData = bar_parser(row, req)
                    buf[bar.datetime] = bar

                begin: str = bar_data[-1][0]
                begin_dt: datetime = parse_timestamp(begin)
                end: str = bar_data[0][0]
                end_dt: datetime = parse_timestamp(end)

                log_msg = f"查询K线历史完成, {req.symbol} - {req.interval.value}, {begin_dt} - {end_dt}"
                self.gateway.write_log(log_msg)

                # 所有K线查询完成时退出
                if begin_dt <= req.start:
                    break

                # 更新开始时间
                after = begin

        index: list[datetime] = list(buf.keys())
        index.sort()

        history: list[BarData] = [buf[i] for i in index]
        return history

    def query_history(self, req: HistoryRequest) -> list[BarData]:
        """
        查询K线历史数据
        发送请求获取特定交易产品和时间段的历史K线数据，迭代查询直到达到开始时间
        参数:
            req: 包含查询参数的历史请求对象
        返回:
            list[BarData]: 历史K线数据列表
        """

        def parse_bar(row: list, req: HistoryRequest) -> BarData:
            ts, op, hp, lp, cp, volume, turnover, _, _ = row
            dt: datetime = parse_timestamp(ts)
            return BarData(
                symbol=req.symbol,
                exchange=req.exchange,
                datetime=dt,
                interval=req.interval,
                volume=float(volume),
                turnover=float(turnover),
                open_price=float(op),
                high_price=float(hp),
                low_price=float(lp),
                close_price=float(cp),
                gateway_name=self.gateway_name
            )

        return self._query_history(
            req=req,
            path="/api/v5/market/history-candles",
            id_key="instId",
            bar_parser=parse_bar
        )

    def query_spread_history(self, req: HistoryRequest) -> list[BarData]:
        """
        查询价差合约K线历史数据
        发送请求获取特定价差合约和时间段的历史K线数据，迭代查询直到达到开始时间
        参数:
            req: 包含查询参数的历史请求对象
        返回:
            list[BarData]: 历史K线数据列表
        """

        def parse_spread_bar(row: list, req: HistoryRequest) -> BarData:
            ts, op, hp, lp, cp, volume, _ = row
            dt: datetime = parse_timestamp(ts)
            return BarData(
                symbol=req.symbol,
                exchange=req.exchange,
                datetime=dt,
                interval=req.interval,
                volume=float(volume),
                open_price=float(op),
                high_price=float(hp),
                low_price=float(lp),
                close_price=float(cp),
                gateway_name=self.gateway_name
            )

        return self._query_history(
            req=req,
            path="/api/v5/market/sprd-history-candles",
            id_key="sprdId",
            bar_parser=parse_spread_bar
        )


class WebsocketApi(WebsocketClient):
    """OKX网关的WebSocket API基类"""

    def __init__(self, gateway: OkxGateway, name: str) -> None:
        """
        API初始化方法
        """
        super().__init__()

        self.name: str = name
        self.gateway: OkxGateway = gateway
        self.gateway_name: str = gateway.gateway_name

        self.connected: bool = False
        self.callbacks: dict[str, Callable] = {}
        self.server_hosts: dict[str, str] = {}

    def connect_(
            self,
            server: str,
            proxy_host: str,
            proxy_port: int,
    ) -> None:
        """
        连接服务器
        """
        host: str = self.server_hosts[server]
        self.init(host, proxy_host, proxy_port, 20)
        self.start()

    def on_connected(self) -> None:
        """
        服务器连接成功回调
        """
        self.connected = True
        self.gateway.write_log(f"{self.name}已连接")

    def on_disconnected(self, status_code: int, msg: str) -> None:
        """
        服务器断开连接回调
        """
        self.connected = False
        self.gateway.write_log(f"{self.name}已断开连接, 代码: {status_code}, 消息: {msg}")

    def on_message(self, message: str) -> None:
        """
        当WebSocket应用收到新消息时的回调
        """
        if message == "pong":
            return
        self.on_packet(json.loads(message))

    def on_packet(self, packet: dict) -> None:
        """
        数据更新回调
        """
        if "event" in packet:
            cb_name: str = packet["event"]
        elif "op" in packet:
            cb_name = packet["op"]
        elif "arg" in packet and "channel" in packet["arg"]:
            cb_name = packet["arg"]["channel"]
        else:
            return

        callback: Callable | None = self.callbacks.get(cb_name, None)
        if callback:
            callback(packet)

    def on_error(self, value: Exception) -> None:
        """
        通用错误回调
        """
        self.gateway.write_log(f"{self.name}捕获异常: {value}")

    def send_ping(self) -> None:
        """向服务器发送心跳ping"""
        if self.connected:
            try:
                self.wsapp.send("ping")
            except Exception:
                pass


class PublicApi(WebsocketApi):
    """OKX网关的公共WebSocket API"""

    def __init__(self, gateway: OkxGateway) -> None:
        """
        API初始化方法
        参数:
            gateway: 父网关对象，用于推送回调数据
        """
        super().__init__(gateway, "公共API")

        self.subscribed: dict[str, SubscribeRequest] = {}
        self.ticks: dict[str, TickData] = {}

        self.callbacks: dict[str, Callable] = {
            "tickers": self.on_ticker,
            "books5": self.on_depth,
            "funding-rate": self.on_funding_rate,
            "error": self.on_api_error
        }

        self.server_hosts: dict[str, str] = {
            "REAL": REAL_PUBLIC_HOST,
            "DEMO": DEMO_PUBLIC_HOST,
        }

    def connect(self, server: str, proxy_host: str, proxy_port: int) -> None:
        """
        连接服务器
        """
        self.connect_(server, proxy_host, proxy_port)

    def subscribe(self, req: SubscribeRequest) -> None:
        """
        订阅行情数据
        发送指定交易产品的行情和深度数据订阅请求
        参数:
            req: 包含合约信息的订阅请求对象
        """
        # 根据VeighNa合约代码获取合约
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"订阅数据失败，合约不存在: {req.symbol}")
            return

        # 添加订阅记录
        self.subscribed[req.fw_symbol] = req

        # 创建Tick对象
        tick: TickData = TickData(
            symbol=req.symbol,
            exchange=req.exchange,
            name=contract.name,
            datetime=datetime.now(UTC_TZ),
            gateway_name=self.gateway_name,
        )
        tick.extra = {}
        self.ticks[contract.name] = tick

        # 发送订阅请求
        args: list = []
        for channel in ["tickers", "books5"]:
            args.append({
                "channel": channel,
                "instId": contract.name
            })

        if contract.product == Product.SWAP:
            args.append({
                "channel": "funding-rate",
                "instId": contract.name
            })

        packet: dict = {
            "op": "subscribe",
            "args": args
        }
        self.send_packet(packet)

    def on_connected(self) -> None:
        """
        服务器连接成功回调
        当与服务器的WebSocket连接成功建立时调用此函数，记录连接状态并重新订阅之前订阅的行情频道
        """
        super().on_connected()

        for req in list(self.subscribed.values()):
            self.subscribe(req)

    def on_api_error(self, packet: dict) -> None:
        """
        API错误回调
        """
        code: str = packet["code"]
        msg: str = packet["msg"]
        self.gateway.write_log(f"{self.name}请求失败, 状态码: {code}, 消息: {msg}")

    def on_ticker(self, packet: dict) -> None:
        """
        行情更新回调
        处理行情数据更新并更新对应的TickData对象
        参数:
            packet: 来自WebSocket的行情数据
        """
        for d in packet["data"]:
            tick: TickData = self.ticks[d["instId"]]

            tick.last_price = float(d["last"])
            tick.open_price = float(d["open24h"])
            tick.high_price = float(d["high24h"])
            tick.low_price = float(d["low24h"])
            tick.volume = float(d["vol24h"])
            tick.turnover = float(d["volCcy24h"])

            self.gateway.on_tick(copy(tick))

    def on_depth(self, packet: dict) -> None:
        """
        盘口深度更新回调
        处理订单簿深度数据更新并更新对应的TickData对象
        参数:
            packet: 来自WebSocket的深度数据
        """
        for d in packet["data"]:
            tick: TickData = self.ticks[d["instId"]]
            bids: list = d["bids"]
            asks: list = d["asks"]

            for n in range(min(5, len(bids))):
                price, volume, _, _ = bids[n]
                tick.__setattr__("bid_price_%s" % (n + 1), float(price))
                tick.__setattr__("bid_volume_%s" % (n + 1), float(volume))

            for n in range(min(5, len(asks))):
                price, volume, _, _ = asks[n]
                tick.__setattr__("ask_price_%s" % (n + 1), float(price))
                tick.__setattr__("ask_volume_%s" % (n + 1), float(volume))

            tick.datetime = parse_timestamp(d["ts"])
            self.gateway.on_tick(copy(tick))

    def on_funding_rate(self, packet: dict) -> None:
        """
        资金费率更新回调
        参数:
            packet: 来自WebSocket的资金费率数据
        """
        for d in packet["data"]:
            tick: TickData | None = self.ticks.get(d["instId"])
            if not tick:
                continue

            if tick.extra is None:
                tick.extra = {}

            tick.extra["funding_rate"] = float(d["fundingRate"])
            tick.extra["funding_time"] = int(d["fundingTime"])

            self.gateway.on_tick(copy(tick))


class PrivateApi(WebsocketApi):
    """OKX网关的私有WebSocket API"""

    def __init__(self, gateway: OkxGateway) -> None:
        """
        API初始化方法
        参数:
            gateway: 父网关对象，用于推送回调数据
        """
        super().__init__(gateway, "私有API")

        self.local_orderids: set[str] = gateway.local_orderids

        self.key: str = ""
        self.secret: bytes = b""
        self.passphrase: str = ""
        self.margin_currency: str = ""

        self.reqid: int = 0
        self.order_count: int = 0
        self.connect_time: int = 0

        self.logged_in: bool = False

        self.callbacks: dict[str, Callable] = {
            "login": self.on_login,
            "orders": self.on_order,
            "account": self.on_account,
            "positions": self.on_position,
            "order": self.on_send_order,
            "cancel-order": self.on_cancel_order,
            "error": self.on_api_error
        }

        self.server_hosts: dict[str, str] = {
            "REAL": REAL_PRIVATE_HOST,
            "DEMO": DEMO_PRIVATE_HOST,
        }

        self.reqid_order_map: dict[str, OrderData] = {}

    def connect(
            self,
            key: str,
            secret: str,
            passphrase: str,
            server: str,
            proxy_host: str,
            proxy_port: int,
            margin_currency: str,
    ) -> None:
        """
        连接服务器
        建立与OKX私有数据流的WebSocket连接
        参数:
            key: 用于认证的API Key
            secret: 用于请求签名的API Secret
            passphrase: 用于认证的API Passphrase
            server: 服务器类型（"REAL" 或 "DEMO"）
            proxy_host: 代理服务器主机名或IP
            proxy_port: 代理服务器端口
            margin_currency: 保证金币种
        """
        self.key = key
        self.secret = secret.encode()
        self.passphrase = passphrase
        self.margin_currency = margin_currency

        self.connect_time = int(datetime.now().strftime("%y%m%d%H%M%S"))

        self.connect_(server, proxy_host, proxy_port)

    def on_connected(self) -> None:
        """
        服务器连接成功回调
        WebSocket连接成功建立时调用此函数，记录连接状态并启动登录流程
        """
        super().on_connected()
        self.login()

    def on_api_error(self, packet: dict) -> None:
        """
        API错误回调
        处理来自WebSocket API的错误响应，记录错误详情用于故障排除
        参数:
            packet: 来自WebSocket的错误数据
        """
        # 从响应中提取错误码和消息
        code: str = packet["code"]
        msg: str = packet["msg"]

        # 记录错误详情用于调试
        self.gateway.write_log(f"{self.name}请求失败, 状态码: {code}, 消息: {msg}")

    def on_login(self, packet: dict) -> None:
        """
        用户登录回调
        处理登录响应，如果登录成功则订阅私有数据频道
        参数:
            packet: 来自WebSocket的登录响应数据
        """
        if packet["code"] == '0':
            self.gateway.write_log(f"{self.name}登录成功")
            self.subscribe_topic()
        else:
            self.gateway.write_log(f"{self.name}登录失败")

    def on_order(self, packet: dict) -> None:
        """
        订单更新回调
        处理订单更新和成交执行，创建OrderData和TradeData对象并推送到网关
        参数:
            packet: 来自WebSocket的订单更新数据
        """
        # 从数据包中提取订单数据
        data: list = packet["data"]
        for d in data:
            # 根据数据创建订单对象
            order: OrderData = self.gateway.parse_order_data(d, self.gateway_name)
            self.gateway.on_order(order)

            # 检查订单是否成交 - 如果没有成交数量则跳过创建成交记录
            if d["fillSz"] == "0":
                return

            # 处理已成交或部分成交订单的成交数据
            # 对成交数量进行四舍五入以满足最小数量精度要求
            trade_volume: float = float(d["fillSz"])
            contract: ContractData | None = self.gateway.get_contract_by_symbol(order.symbol)
            if contract:
                trade_volume = round_to(trade_volume, contract.min_volume)

            # 创建成交对象并推送到网关
            trade: TradeData = TradeData(
                symbol=order.symbol,
                exchange=order.exchange,
                orderid=order.orderid,
                tradeid=d["tradeId"],
                direction=order.direction,
                offset=order.offset,
                price=float(d["fillPx"]),
                volume=trade_volume,
                datetime=parse_timestamp(d["uTime"]),
                gateway_name=self.gateway_name,
            )
            self.gateway.on_trade(trade)

    def on_account(self, packet: dict) -> None:
        """
        账户余额更新回调
        处理账户余额更新，为每个资产创建AccountData对象
        参数:
            packet: WebSocket收到的账户更新数据
        """
        if len(packet["data"]) == 0:
            return

        buf: dict = packet["data"][0]
        for detail in buf["details"]:
            account: AccountData = AccountData(
                accountid=detail["ccy"],
                balance=float(detail["eq"]),
                gateway_name=self.gateway_name,
            )
            account.available = float(detail["availEq"])
            account.frozen = float(detail["frozenBal"])
            self.gateway.on_account(account)

    def on_position(self, packet: dict) -> None:
        """
        持仓更新回调
        处理持仓更新并为每个持仓创建PositionData对象
        参数:
            packet: 来自WebSocket的持仓更新数据
        """
        data: list = packet["data"]
        for d in data:
            name: str = d["instId"]
            contract: ContractData = cast(ContractData, self.gateway.get_contract_by_name(name))

            pos: float = float(d["pos"])
            price: float = get_float_value(d, "avgPx")
            pnl: float = get_float_value(d, "upl")

            position: PositionData = PositionData(
                symbol=contract.symbol,
                exchange=Exchange.GLOBAL,
                direction=Direction.NET,
                volume=pos,
                price=price,
                pnl=pnl,
                gateway_name=self.gateway_name,
            )
            self.gateway.on_position(position)

    def on_send_order(self, packet: dict) -> None:
        """
        下单回调
        处理下单请求的响应，处理错误和拒绝情况
        参数:
            packet: 来自WebSocket的订单响应数据
        """
        data: list = packet["data"]

        # 参数错误
        if packet["code"] != "0":
            if not data:
                order: OrderData | None = self.reqid_order_map.get(packet["id"], None)
                if order:
                    order.status = Status.REJECTED
                    self.gateway.on_order(order)

                return

        # 处理失败
        for d in data:
            code: str = d["sCode"]
            if code == "0":
                return

            orderid: str = d["clOrdId"]
            order = self.gateway.get_order(orderid)
            if not order:
                return
            order.status = Status.REJECTED
            self.gateway.on_order(copy(order))

            msg: str = d["sMsg"]
            self.gateway.write_log(f"下单失败, 状态码: {code}, 消息: {msg}")

    def on_cancel_order(self, packet: dict) -> None:
        """
        撤单回调
        处理撤单请求的响应，处理错误并记录相应消息
        参数:
            packet: 来自WebSocket的撤单响应数据
        """
        # 参数错误
        if packet["code"] != "0":
            msg: str = packet["msg"]
            if msg:
                code: str = packet["code"]
                self.gateway.write_log(f"撤单失败, 状态码: {code}, 消息: {msg}")
                return

        # 处理失败
        data: list = packet["data"]
        for d in data:
            code = d["sCode"]
            if code == "0":
                return

            msg = d["sMsg"]
            self.gateway.write_log(f"撤单失败, 状态码: {code}, 消息: {msg}")

    def login(self) -> None:
        """
        用户登录
        准备并发送登录请求，使用API凭证进行WebSocket API认证
        """
        if not self.key:
            return

        timestamp: str = str(time.time())
        msg: str = timestamp + "GET" + "/users/self/verify"
        signature: bytes = generate_signature(msg, self.secret)

        packet: dict = {
            "op": "login",
            "args":
                [
                    {
                        "apiKey": self.key,
                        "passphrase": self.passphrase,
                        "timestamp": timestamp,
                        "sign": signature.decode("utf-8")
                    }
                ]
        }
        self.send_packet(packet)

    def subscribe_topic(self) -> None:
        """
        订阅私有数据频道
        登录成功后发送订单、账户和持仓更新的订阅请求
        """
        packet: dict = {
            "op": "subscribe",
            "args": [
                {
                    "channel": "orders",
                    "instType": "ANY"
                },
                {
                    "channel": "account"
                },
                {
                    "channel": "positions",
                    "instType": "ANY"
                },
            ]
        }
        self.send_packet(packet)

    def send_order(self, req: OrderRequest) -> str:
        """
        向OKX发送新订单
        创建并发送新订单请求到交易所，处理不同的订单类型和交易模式
        参数:
            req: 包含订单详情的订单请求对象
        返回:
            str: 成功时返回VeighNa订单ID，失败时返回空字符串
        """
        # 验证订单类型是否被OKX支持
        if req.type not in ORDERTYPE_VT2OKX:
            self.gateway.write_log(f"下单失败, 不支持的订单类型: {req.type.value}")
            return ""

        # 验证合约代码是否存在
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"下单失败, 未找到合约: {req.symbol}")
            return ""

        # 生成唯一的本地订单ID
        self.order_count += 1
        count_str = str(self.order_count).rjust(6, "0")
        orderid = f"{self.connect_time}{count_str}"

        # 为OKX API准备订单参数
        arg: dict = {
            "instIdCode": contract.extra["instIdCode"],  # type: ignore
            "clOrdId": orderid,
            "side": DIRECTION_VT2OKX[req.direction],
            "ordType": ORDERTYPE_VT2OKX[req.type],
            "px": str(req.price),
            "sz": str(req.volume),
            "tdMode": "cross"  # 仅支持全仓保证金模式
        }

        # 为组合保证金添加额外字段
        if self.margin_currency:
            arg["ccy"] = self.margin_currency

        # 为现货添加额外字段
        if "SPOT" in req.symbol:
            quote_ccy_list: list[str] = contract.extra["tradeQuoteCcyList"]  # type: ignore
            arg["tradeQuoteCcy"] = quote_ccy_list[0]

        # 使用唯一请求ID创建WebSocket请求
        self.reqid += 1
        packet: dict = {
            "id": str(self.reqid),
            "op": "order",
            "args": [arg]
        }
        self.send_packet(packet)

        # 创建订单数据对象并推送到网关
        order: OrderData = req.create_order_data(orderid, self.gateway_name)
        self.gateway.on_order(order)

        # 返回VeighNa订单ID（网关名称.订单ID）
        return str(order.vt_orderid)

    def cancel_order(self, req: CancelRequest) -> None:
        """
        取消OKX上的现有订单
        发送请求取消交易所上的现有订单，确定使用客户端订单ID还是交易所订单ID
        参数:
            req: 包含订单详情的取消请求对象
        """
        # 验证合约代码是否存在
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"撤单失败, 未找到合约: {req.symbol}")
            return

        # 初始化撤单参数
        arg: dict = {"instIdCode": contract.extra["instIdCode"]}  # type: ignore

        # 确定用于取消的订单ID类型
        # OKX支持使用客户端订单ID和交易所订单ID进行取消
        if req.orderid in self.local_orderids:
            # 如果是此网关实例创建的订单，使用客户端订单ID
            arg["clOrdId"] = req.orderid
        else:
            # 如果来自其他来源，使用交易所订单ID
            arg["ordId"] = req.orderid

        # 使用唯一请求ID创建WebSocket请求
        self.reqid += 1
        packet: dict = {
            "id": str(self.reqid),
            "op": "cancel-order",
            "args": [arg]
        }

        # 发送取消请求
        self.send_packet(packet)


class BusinessApi(WebsocketApi):
    """OKX网关的业务WebSocket API"""

    def __init__(self, gateway: OkxGateway) -> None:
        """
        API初始化方法
        参数:
            gateway: 父网关对象，用于推送回调数据
        """
        super().__init__(gateway, "业务API")

        self.local_orderids: set[str] = gateway.local_orderids
        self.subscribed: dict[str, SubscribeRequest] = {}
        self.ticks: dict[str, TickData] = {}

        self.key: str = ""
        self.secret: bytes = b""
        self.passphrase: str = ""

        self.reqid: int = 0
        self.order_count: int = 0
        self.connect_time: int = 0

        self.callbacks: dict[str, Callable] = {
            "login": self.on_login,
            "sprd-orders": self.on_order,
            "sprd-trades": self.on_trade,
            "sprd-tickers": self.on_ticker,
            "sprd-books5": self.on_depth,
            "order": self.on_send_order,
            "cancel-order": self.on_cancel_order,
            "error": self.on_api_error
        }

        self.server_hosts: dict[str, str] = {
            "REAL": REAL_BUSINESS_HOST,
            "DEMO": DEMO_BUSINESS_HOST,
        }

        self.reqid_order_map: dict[str, OrderData] = {}

    def connect(
            self,
            key: str,
            secret: str,
            passphrase: str,
            server: str,
            proxy_host: str,
            proxy_port: int,
    ) -> None:
        """
        启动服务器连接
        建立到OKX私有数据流的WebSocket连接
        参数:
            key: 用于认证的API Key
            secret: 用于请求签名的API Secret
            passphrase: 用于认证的API Passphrase
            server: 服务器类型（"REAL" 或 "DEMO"）
            proxy_host: 代理服务器主机名或IP
            proxy_port: 代理服务器端口
        """
        self.key = key
        self.secret = secret.encode()
        self.passphrase = passphrase

        self.connect_time = int(datetime.now().strftime("%y%m%d%H%M%S"))

        self.connect_(server, proxy_host, proxy_port)

    def subscribe(self, req: SubscribeRequest) -> None:
        """
        订阅行情数据
        为指定交易产品发送行情和深度数据订阅请求
        参数:
            req: 包含合约代码信息的订阅请求对象
        """
        # 根据VeighNa合约代码获取合约
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"订阅数据失败, 未找到合约: {req.symbol}")
            return

        # 添加订阅记录
        self.subscribed[req.fw_symbol] = req

        # 创建Tick对象
        tick: TickData = TickData(
            symbol=req.symbol,
            exchange=req.exchange,
            name=contract.name,
            datetime=datetime.now(UTC_TZ),
            gateway_name=self.gateway_name,
        )
        self.ticks[contract.name] = tick

        # 发送订阅请求
        args: list = []
        for channel in ["sprd-tickers", "sprd-books5"]:
            args.append({
                "channel": channel,
                "sprdId": contract.name
            })

        packet: dict = {
            "op": "subscribe",
            "args": args
        }

        self.send_packet(packet)

    def on_connected(self) -> None:
        """
        服务器连接成功回调
        当与服务器的WebSocket连接成功建立时调用此函数，记录连接状态并启动登录流程
        """
        super().on_connected()

        for req in list(self.subscribed.values()):
            self.subscribe(req)

        self.login()

    def on_api_error(self, packet: dict) -> None:
        """
        API错误回调
        处理来自WebSocket API的错误响应，记录错误详情用于故障排除
        参数:
            packet: 来自WebSocket的错误数据
        """
        # 从响应中提取错误码和消息
        code: str = packet["code"]
        msg: str = packet["msg"]

        # 记录错误详情用于调试
        self.gateway.write_log(f"{self.name}请求失败, 状态码: {code}, 消息: {msg}")

    def on_login(self, packet: dict) -> None:
        """
        用户登录回调
        处理登录响应，如果登录成功则订阅私有数据频道
        参数:
            packet: 来自WebSocket的登录响应数据
        """
        if packet["code"] == '0':
            self.gateway.write_log(f"{self.name}登录成功")
            self.subscribe_topic()
        else:
            self.gateway.write_log(f"{self.name}登录失败")

    def on_order(self, packet: dict) -> None:
        """
        订单更新回调
        处理订单更新和成交执行，创建OrderData对象并推送到网关
        参数:
            packet: 来自WebSocket的订单更新数据
        """
        # 从数据包中提取订单数据
        data: list = packet["data"]
        for d in data:
            # 根据数据创建订单对象
            order: OrderData = self.gateway.parse_spread_order_data(d, self.gateway_name)
            self.gateway.on_order(order)

    def on_trade(self, packet: dict) -> None:
        """
        成交更新回调
        处理成交更新并创建TradeData对象
        参数:
            packet: 来自WebSocket的订单更新数据
        """
        # 从数据包中提取成交数据
        for d in packet["data"]:
            # 获取订单ID
            if d["clOrdId"]:
                order_id: str = d["clOrdId"]
            else:
                order_id = d["ordId"]

            dt: datetime = parse_timestamp(d["ts"])

            for leg in d["legs"]:
                name: str = leg["instId"]
                contract: ContractData | None = self.gateway.get_contract_by_name(name)
                if not contract:
                    self.gateway.write_log(f"解析成交数据失败, 未找到合约: {name}")
                    continue

                trade: TradeData = TradeData(
                    symbol=contract.symbol,
                    exchange=Exchange.GLOBAL,
                    orderid=order_id,
                    tradeid=leg["tradeId"],
                    direction=DIRECTION_OKX2VT[leg["side"]],
                    price=float(leg["px"]),
                    volume=float(leg["sz"]),
                    datetime=dt,
                    gateway_name=self.gateway_name,
                )
                self.gateway.on_trade(trade)

    def on_send_order(self, packet: dict) -> None:
        """
        下单回调
        处理下单请求的响应，处理错误和拒绝情况
        参数:
            packet: 来自WebSocket的订单响应数据
        """
        data: list = packet["data"]

        # 参数错误
        if packet["code"] != "0":
            if not data:
                order: OrderData | None = self.reqid_order_map.get(packet["id"], None)
                if order:
                    order.status = Status.REJECTED
                    self.gateway.on_order(order)

                return

        # 处理失败
        for d in data:
            code: str = d["sCode"]
            if code == "0":
                return

            orderid: str = d["clOrdId"]
            order = self.gateway.get_order(orderid)
            if not order:
                return

            order.status = Status.REJECTED
            self.gateway.on_order(copy(order))

            msg: str = d["sMsg"]
            self.gateway.write_log(f"下单失败, 状态码: {code}, 消息: {msg}")

    def on_cancel_order(self, packet: dict) -> None:
        """
        撤单回调
        处理撤单请求的响应，处理错误并记录相应消息
        参数:
            packet: 来自WebSocket的撤单响应数据
        """
        # 参数错误
        if packet["code"] != "0":
            msg: str = packet["msg"]
            if msg:
                code: str = packet["code"]
                self.gateway.write_log(f"撤单失败, 状态码: {code}, 消息: {msg}")
                return

        # 处理失败
        data: list = packet["data"]
        for d in data:
            code = d["sCode"]
            if code == "0":
                return

            msg = d["sMsg"]
            self.gateway.write_log(f"撤单失败, 状态码: {code}, 消息: {msg}")

    def on_ticker(self, packet: dict) -> None:
        """
        行情更新回调
        处理行情数据更新并更新对应的TickData对象
        参数:
            packet: 来自WebSocket的行情数据
        """
        for d in packet["data"]:
            if not d["last"]:
                return

            tick: TickData = self.ticks[d["sprdId"]]

            tick.last_price = float(d["last"])
            tick.last_volume = float(d["lastSz"])
            tick.open_price = float(d["open24h"])
            tick.high_price = float(d["high24h"])
            tick.low_price = float(d["low24h"])
            tick.volume = float(d["vol24h"])
            tick.datetime = parse_timestamp(d["ts"])

            self.gateway.on_tick(copy(tick))

    def on_depth(self, packet: dict) -> None:
        """
        盘口深度更新回调
        处理订单簿深度数据更新并更新对应的TickData对象
        参数:
            packet: 来自WebSocket的深度数据
        """
        name: str = packet["arg"]["sprdId"]
        tick: TickData = self.ticks[name]

        for d in packet["data"]:
            bids: list = d["bids"]
            asks: list = d["asks"]

            for n in range(min(5, len(bids))):
                price, volume, _ = bids[n]
                tick.__setattr__("bid_price_%s" % (n + 1), float(price))
                tick.__setattr__("bid_volume_%s" % (n + 1), float(volume))

            for n in range(min(5, len(asks))):
                price, volume, _ = asks[n]
                tick.__setattr__("ask_price_%s" % (n + 1), float(price))
                tick.__setattr__("ask_volume_%s" % (n + 1), float(volume))

            tick.datetime = parse_timestamp(d["ts"])
            self.gateway.on_tick(copy(tick))

    def login(self) -> None:
        """
        用户登录
        准备并发送登录请求，使用API凭证进行WebSocket API认证
        """
        if not self.key:
            return

        timestamp: str = str(time.time())
        msg: str = timestamp + "GET" + "/users/self/verify"
        signature: bytes = generate_signature(msg, self.secret)

        packet: dict = {
            "op": "login",
            "args":
                [
                    {
                        "apiKey": self.key,
                        "passphrase": self.passphrase,
                        "timestamp": timestamp,
                        "sign": signature.decode("utf-8")
                    }
                ]
        }
        self.send_packet(packet)

    def subscribe_topic(self) -> None:
        """
        订阅私有数据频道
        登录成功后发送订单和成交更新的订阅请求
        """
        packet: dict = {
            "op": "subscribe",
            "args": [
                {
                    "channel": "sprd-orders"
                },
                {
                    "channel": "sprd-trades"
                }
            ]
        }
        self.send_packet(packet)

    def send_order(self, req: OrderRequest) -> str:
        """
        向OKX发送新订单
        创建并发送新订单请求到交易所，处理不同的订单类型和交易模式
        参数:
            req: 包含订单详情的订单请求对象
        返回:
            str: 成功时返回VeighNa订单ID，失败时返回空字符串
        """
        # 验证订单类型是否被OKX支持
        if req.type not in ORDERTYPE_VT2OKX:
            self.gateway.write_log(f"下单失败, 不支持的订单类型: {req.type.value}")
            return ""

        # 验证合约代码是否存在
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"下单失败, 未找到合约: {req.symbol}")
            return ""

        # 生成唯一的本地订单ID
        self.order_count += 1
        count_str = str(self.order_count).rjust(6, "0")
        orderid = f"{self.connect_time}{count_str}"

        # 为OKX API准备订单参数
        arg: dict = {
            "sprdId": contract.name,
            "clOrdId": orderid,
            "side": DIRECTION_VT2OKX[req.direction],
            "ordType": ORDERTYPE_VT2OKX[req.type],
            "px": str(req.price),
            "sz": str(req.volume)
        }

        # 使用唯一请求ID创建WebSocket请求
        self.reqid += 1
        packet: dict = {
            "id": str(self.reqid),
            "op": "sprd-order",
            "args": [arg]
        }
        self.send_packet(packet)

        # 创建订单数据对象并推送到网关
        order: OrderData = req.create_order_data(orderid, self.gateway_name)
        self.gateway.on_order(order)

        # 返回VeighNa订单ID（网关名称.订单ID）
        return str(order.vt_orderid)

    def cancel_order(self, req: CancelRequest) -> None:
        """
        取消OKX上的现有订单
        发送请求取消交易所上的现有订单，确定使用客户端订单ID还是交易所订单ID
        参数:
            req: 包含订单详情的取消请求对象
        """
        # 验证合约代码是否存在
        contract: ContractData | None = self.gateway.get_contract_by_symbol(req.symbol)
        if not contract:
            self.gateway.write_log(f"撤单失败, 未找到合约: {req.symbol}")
            return

        # 初始化撤单参数
        arg: dict = {}

        # 确定用于取消的订单ID类型
        # OKX支持使用客户端订单ID和交易所订单ID进行取消
        if req.orderid in self.local_orderids:
            # 如果是此网关实例创建的订单，使用客户端订单ID
            arg["clOrdId"] = req.orderid
        else:
            # 如果来自其他来源，使用交易所订单ID
            arg["ordId"] = req.orderid

        # 使用唯一请求ID创建WebSocket请求
        self.reqid += 1
        packet: dict = {
            "id": str(self.reqid),
            "op": "sprd-cancel-order",
            "args": [arg]
        }

        # 发送取消请求
        self.send_packet(packet)


def generate_signature(msg: str, secret_key: bytes) -> bytes:
    """
    根据消息生成签名
    创建OKX认证API请求所需的HMAC-SHA256签名
    参数:
        msg: 待签名的消息
        secret_key: 字节格式的API密钥
    返回:
        bytes: Base64编码的签名
    """
    return base64.b64encode(hmac.new(secret_key, msg.encode(), hashlib.sha256).digest())


def generate_timestamp() -> str:
    """
    生成当前时间戳
    创建OKX API请求所需的带毫秒的ISO格式时间戳
    返回:
        str: 带Z后缀的ISO 8601格式时间戳
    """
    now: datetime = datetime.utcnow()
    timestamp: str = now.isoformat("T", "milliseconds")
    return timestamp + "Z"


def parse_timestamp(timestamp: str) -> datetime:
    """
    将时间戳解析为datetime对象
    将OKX时间戳转换为带UTC时区的datetime对象
    参数:
        timestamp: 毫秒级的OKX时间戳
    返回:
        datetime: 带UTC时区的datetime对象
    """
    return datetime.fromtimestamp(int(timestamp) / 1000, tz=UTC_TZ)


def get_float_value(data: dict, key: str) -> float:
    """
    从浮点值中获取十进制数字
    安全地从字典中提取浮点值，处理空值或缺失值
    参数:
        data: 包含值的字典
        key: 要从字典中提取的键
    返回:
        float: 提取的值，如果未找到则返回0.0
    """
    data_str: str = data.get(key, "")
    if not data_str:
        return 0.0
    return float(data_str)