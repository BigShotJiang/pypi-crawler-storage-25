try:
    from .常量定义 import *
except ImportError:
    from fuwen_config.常量.常量定义 import *

if __name__ == '__main__':
    print(f"当前工作区目录: [{当前工作区目录}]")
