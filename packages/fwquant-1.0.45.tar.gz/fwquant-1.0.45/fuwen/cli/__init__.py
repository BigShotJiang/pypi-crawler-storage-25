#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
FuWen Quant CLI Module - 命令行交互模块

提供交互式菜单和命令行参数解析功能
"""

import argparse
import sys
import os
import subprocess


def open_with_default_app(file_path):
    """使用系统默认程序打开文件或目录"""
    if not os.path.exists(file_path):
        print(f"❌ 文件/目录不存在: {file_path}")
        return False

    try:
        if sys.platform == 'darwin':
            subprocess.run(['open', file_path], check=True)
        elif sys.platform == 'win32':
            subprocess.run(['start', file_path], check=True, shell=True)
        else:
            subprocess.run(['xdg-open', file_path], check=True)
        print(f"✅ 已使用系统默认程序打开: {file_path}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 打开失败: {e}")
        return False
    except FileNotFoundError:
        print(f"❌ 无法找到默认程序，请手动打开: {file_path}")
        return False


def print_menu():
    """打印交互式菜单"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                    福纹量化交易平台                          ║
╚══════════════════════════════════════════════════════════════╝
┌──────────────────────────────────────────────────────────────┐
│                      启动菜单                                │
├──────────────────────────────────────────────────────────────┤
│  1. 🌐 启动Web服务（默认配置）                               │
│     - 启动后可通过浏览器访问: http://localhost:8000          │
│  2. 🖥️  启动GUI窗口（图形界面）                              │
│     - 启动带有QT界面的量化交易系统                           │
│  3. ⚙️  启动Web服务（自定义配置）                            │
│     - 可自定义端口、绑定地址等参数                           │
│  4. ❓ 显示帮助信息                                          │
│  0. 🚪 退出                                                 │
└──────────────────────────────────────────────────────────────┘
请输入选择 (0-4): """, end='')


def start_gui():
    """启动GUI界面"""
    print("\n🚀 启动福纹量化GUI...")
    try:
        from fuwen.gui import start
        start()
    except ImportError as e:
        print(f"❌ 导入GUI模块失败: {e}")
        print("请确保已安装 PySide6: pip install PySide6")
    except Exception as e:
        print(f"❌ GUI启动失败: {e}")
        import traceback
        traceback.print_exc()


def start_web(host="0.0.0.0", port=8000, reload=False):
    """启动Web服务"""
    print(f"\n🌐 启动福纹量化Web服务...")
    print(f"配置: host={host}, port={port}, reload={reload}")
    try:
        from fuwen.web import run
        run(host=host, port=port, reload=reload)
    except ImportError as e:
        print(f"❌ 导入Web模块失败: {e}")
        print("请确保已安装必要依赖: pip install uvicorn")
    except Exception as e:
        print(f"❌ Web服务启动失败: {e}")
        import traceback
        traceback.print_exc()


def show_help():
    """显示帮助信息"""
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    readme_path = os.path.join(project_root, "README.md")
    docs_path = os.path.join(project_root, "docs")

    while True:
        help_text = f"""
╔══════════════════════════════════════════════════════════════╗
║                    福纹量化交易平台 - 帮助手册               ║
╚══════════════════════════════════════════════════════════════╝

【命令行使用方式】
  python main.py web          # 启动Web服务（默认配置）
  python main.py gui          # 启动GUI窗口（图形界面）
  python main.py web --port 8080 --reload
  python main.py              # 显示交互式菜单
  
【Web服务参数】
  --host       绑定地址 (默认: 0.0.0.0)
  --port       服务端口 (默认: 8000)
  --reload     启用自动重载（开发模式）
  
【界面说明】
  Web服务: 通过浏览器访问的网页界面，适合远程访问
  GUI窗口: QT图形界面，功能完整，适合本地使用
  
【项目文档】
  README: {readme_path}
  文档目录: {docs_path}
  
【操作选项】
  1. 📖 使用默认程序打开 README.md
  2. 📁 打开文档目录 (docs/)
  3. 🔙 返回主菜单
  
请输入选择 (1-3): """
        print(help_text)

        try:
            choice = input().strip()

            if choice == '1':
                open_with_default_app(readme_path)
                print("\n按 Enter 键继续...")
                input()
            elif choice == '2':
                open_with_default_app(docs_path)
                print("\n按 Enter 键继续...")
                input()
            elif choice == '3':
                break
            else:
                print("\n❌ 无效选择，请输入 1-3")
                print("按 Enter 键继续...")
                input()

        except KeyboardInterrupt:
            break


def interactive_mode():
    """交互式菜单模式"""
    while True:
        print_menu()
        try:
            choice = input().strip()

            if choice == '1':
                start_web()
                break
            elif choice == '2':
                start_gui()
                break
            elif choice == '3':
                host = input("请输入绑定地址 (默认: 0.0.0.0): ").strip() or "0.0.0.0"
                port_input = input("请输入服务端口 (默认: 8000): ").strip()
                port = int(port_input) if port_input else 8000
                reload_input = input("启用自动重载? (y/n, 默认: n): ").strip().lower()
                reload = reload_input == 'y'
                start_web(host=host, port=port, reload=reload)
                break
            elif choice == '4':
                show_help()
            elif choice == '0':
                print("\n👋 再见！")
                sys.exit(0)
            else:
                print("\n❌ 无效选择，请输入 1-5")

        except KeyboardInterrupt:
            print("\n\n👋 再见！")
            sys.exit(0)
        except ValueError:
            print("\n❌ 输入无效，请输入数字")


def run():
    """主入口函数"""
    parser = argparse.ArgumentParser(
        description="福纹量化交易平台启动器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python main.py gui               # 启动GUI界面(图形界面,也可以是 windows 模式)
  python main.py web               # 启动Web服务（默认配置）
  python main.py web --port 8080    # 指定端口
  python main.py                   # 显示交互式菜单
        """
    )

    parser.add_argument('mode', nargs='?', default=None, choices=['web', 'www', 'gui', 'windows', 'menu'],
                        type=str.lower,
                        help="启动模式: web(启动服务[默认])、 gui(启动窗口) 或 menu(交互式菜单)")

    parser.add_argument('--host', default='0.0.0.0', help='绑定地址')
    parser.add_argument('--port', type=int, default=8000, help='服务端口')
    parser.add_argument('--reload', action='store_true', help='启用自动重载')

    args = parser.parse_args()
    lower_mode = args.mode.lower()

    if args.mode is None or lower_mode in ['web', 'www']:  # 默认 启动Web服务
        start_web(host=args.host, port=args.port, reload=args.reload)
    elif lower_mode in ['windows', 'gui']:
        start_gui()
    elif lower_mode == 'menu':
        interactive_mode()
    else:
        show_help()


__all__ = ['run', 'start_gui', 'start_web', 'show_help', 'interactive_mode']
