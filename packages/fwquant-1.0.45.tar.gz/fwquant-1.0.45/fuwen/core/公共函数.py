"""
公共工具函数

该模块包含基础的工具函数，不依赖任何业务模块，避免循环导入。
"""
import json

from pathlib import Path

from fuwen_adaptor.trader.utility import TEMP_DIR
from fuwen_config.常量.常量定义 import 福纹配置目录名称


def _get_trader_dir(temp_name: str) -> tuple[Path, Path]:
    """
    Get path where trader is running in.
    """
    cwd: Path = Path.cwd()
    temp_path: Path = cwd.joinpath(temp_name)

    # If 福纹配置目录名称 folder exists in current working directory,
    # then use it as trader running path.
    if temp_path.exists():
        return cwd, temp_path

    # Otherwise use home path of system.
    home_path: Path = Path.home()
    temp_path = home_path.joinpath(temp_name)

    # Create 福纹配置目录名称 folder under home path if not exist.
    if not temp_path.exists():
        temp_path.mkdir()

    return home_path, temp_path


TRADER_DIR, TEMP_DIR = _get_trader_dir(福纹配置目录名称)


def get_file_path(filename: str) -> Path:
    """
    Get path for temp file with filename.
    """
    return TEMP_DIR.joinpath(filename)


def save_json(filename: str, data: dict) -> None:
    """
    Save data into json file in temp path.
    """
    filepath: Path = get_file_path(filename)
    with open(filepath, mode="w+", encoding="UTF-8") as f:
        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )


def load_json(filename: str) -> dict:
    """
    Load data from json file in temp path.
    """
    filepath: Path = get_file_path(filename)

    if filepath.exists():
        with open(filepath, encoding="UTF-8") as f:
            data: dict = json.load(f)
        return data
    else:
        save_json(filename, {})
        return {}


def fw_float(x) -> float:
    """
    将输入转换为float类型
    
    :param x: 输入值，可以是字符串、数字或其他可转换类型
    :return: 转换后的float值
    """
    if x is None:
        return 0.0
    try:
        return float(x)
    except (ValueError, TypeError):
        return 0.0
