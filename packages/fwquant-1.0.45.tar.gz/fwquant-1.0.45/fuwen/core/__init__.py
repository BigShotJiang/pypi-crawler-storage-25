"""
FuWen Core - 核心工具模块

提供基础工具函数，独立于业务模块，避免循环导入问题。
"""

from .公共函数 import fw_float

__all__ = ["fw_float"]