"""
FuWen Quant - 福纹量化统一入口

提供统一的API接口，包括：
- GUI界面启动 (fuwen.gui)
- Web服务启动 (fuwen.web)
- 命令行工具 (fuwen.cli)
- 核心工具函数 (fuwen.core)

使用示例：
    # 启动GUI
    import fuwen
    fuwen.gui.start()
    
    # 启动Web服务
    fuwen.web.run()
    
    # 使用命令行
    fuwen.cli.main()
    
    # 使用工具函数
    fuwen.core.fw_float("123.45")
"""

from . import core
from . import gui
from . import web
from . import cli

# 便捷函数
def start():
    """启动GUI界面（便捷入口）"""
    gui.start()

def run(host: str = "0.0.0.0", port: int = 8000, reload: bool = False):
    """启动Web服务（便捷入口）"""
    web.run(host=host, port=port, reload=reload)

# 导出子模块
__all__ = [
    "core",     # 核心工具模块
    "gui",      # GUI启动模块
    "web",      # Web服务模块
    "cli",      # 命令行模块
    "start",    # GUI启动便捷函数
    "run",      # Web启动便捷函数
]

__version__ = "1.0.0"