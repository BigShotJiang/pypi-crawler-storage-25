#!/usr/bin/env python
import logging
logging.getLogger('asyncio').setLevel(logging.CRITICAL)
from crewai import Agent, Task, Crew
from dotenv import load_dotenv

load_dotenv(override=True)


def main():
    agent = Agent(role="分析师", goal="分析市场趋势", backstory="专业分析师", llm="openai/qwen-turbo")
    task = Task(description="分析ETH市场趋势，包括价格走势、支撑压力、市场情绪", agent=agent, expected_output="市场分析报告")
    result = Crew(agents=[agent], tasks=[task]).kickoff()
    print(result)


if __name__ == '__main__':
    main()