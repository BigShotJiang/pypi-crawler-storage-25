#!/usr/bin/env python
import os
import requests
from crewai import Agent, Task, Crew
from dotenv import load_dotenv

load_dotenv()

def get_okx_kline(inst_id="ETH-USDT-SWAP", bar="5m", limit=100):
    """从OKX获取K线数据"""
    url = f"https://www.okx.com/api/v5/market/candles?instId={inst_id}&bar={bar}&limit={limit}"
    response = requests.get(url, timeout=10)
    data = response.json()
    if data['code'] == '0' and data['data']:
        candles = data['data']
        return candles
    return None

def get_okx_ticker(inst_id="ETH-USDT-SWAP"):
    """从OKX获取实时行情"""
    url = f"https://www.okx.com/api/v5/market/ticker?instId={inst_id}"
    response = requests.get(url, timeout=10)
    data = response.json()
    if data['code'] == '0':
        return data['data'][0]
    return None

def analyze_kline_data(candles, timeframe):
    """分析K线数据"""
    if not candles:
        return "暂无数据"

    closes = [float(c[4]) for c in candles]
    highs = [float(c[2]) for c in candles]
    lows = [float(c[3]) for c in candles]
    volumes = [float(c[5]) for c in candles]

    recent_high = max(highs[:20])
    recent_low = min(lows[:20])
    avg_volume = sum(volumes[:20]) / 20
    price_change = closes[0] - closes[-1]
    change_pct = (price_change / closes[-1]) * 100

    return f"""【{timeframe} K线分析】
- 当前价格: {closes[0]:,.2f} USDT
- 近期最高: {recent_high:,.2f} USDT
- 近期最低: {recent_low:,.2f} USDT
- 价格变化: {price_change:+.2f} USDT ({change_pct:+.2f}%)
- 近20根平均成交量: {avg_volume:,.2f}
- K线数量: {len(candles)}根"""

def main():
    print("📊 正在获取OKX真实K线数据...")

    # 获取多时间框架K线数据
    kline_5min = get_okx_kline("ETH-USDT-SWAP", "5m", 100)
    kline_1h = get_okx_kline("ETH-USDT-SWAP", "1H", 100)
    kline_1d = get_okx_kline("ETH-USDT-SWAP", "1D", 100)
    ticker = get_okx_ticker("ETH-USDT-SWAP")

    if not kline_5min or not kline_1h or not kline_1d or not ticker:
        print("❌ 获取数据失败")
        return

    # 计算涨跌数据
    last = float(ticker['last'])
    open24h = float(ticker['open24h'])
    change = last - open24h
    change_pct = (change / open24h) * 100

    # 准备分析数据
    analysis_data = f"""【ETH-USDT-SWAP 实时数据】
最新价格: {last:,.2f} USDT
24h涨跌: {change:+.2f} USDT
24h涨幅: {change_pct:+.2f}%
24h最高: {float(ticker['high24h']):,.2f} USDT
24h最低: {float(ticker['low24h']):,.2f} USDT
24h成交量: {float(ticker['vol24h']):,.2f} ETH

{analyze_kline_data(kline_5min, '5分钟')}

{analyze_kline_data(kline_1h, '1小时')}

{analyze_kline_data(kline_1d, '1天')}"""

    print(analysis_data)

    # 阳智能体 - 看多分析师
    yang_agent = Agent(
        role="☀️ 阳分析师（多头视角）",
        goal="从乐观角度分析市场，寻找上涨信号和理由",
        backstory="你是一位资深的多头分析师，擅长发现市场中的上涨潜力和买入机会。即使在市场疲软时，也能看到潜在的上涨因素。你的分析充满正能量，善于发现市场的积极面。",
        llm="dashscope/qwen-turbo",
        verbose=True
    )

    # 阴智能体 - 看空分析师
    yin_agent = Agent(
        role="🌙 阴分析师（空头视角）",
        goal="从悲观角度分析市场，寻找下跌信号和风险",
        backstory="你是一位谨慎的空头分析师，擅长识别市场中的风险和下跌信号。即使在市场上涨时，也能看到潜在的风险因素。你的分析注重风险控制，善于发现市场的负面因素。",
        llm="dashscope/qwen-turbo",
        verbose=True
    )

    # 综合智能体 - 仲裁者
    judge_agent = Agent(
        role="⚖️ 综合仲裁者",
        goal="综合阳阴两位分析师的观点，给出客观中立的最终分析报告",
        backstory="你是一位经验丰富的市场仲裁者，善于平衡多方观点。你不偏不倚，根据数据和逻辑做出独立判断，最终结论必须明确且有说服力。",
        llm="dashscope/qwen-turbo",
        verbose=True
    )

    # 创建任务
    yang_task = Task(
        description=f"""请从多头视角分析以下ETH行情数据：
{analysis_data}

分析要点：
1. 找出所有看涨信号（如支撑位、成交量放大、上涨趋势等）
2. 列举支持上涨的理由和因素
3. 预测未来可能的上涨目标
4. 给出看多的投资建议""",
        agent=yang_agent,
        expected_output="一份详细的看多分析报告"
    )

    yin_task = Task(
        description=f"""请从空头视角分析以下ETH行情数据：
{analysis_data}

分析要点：
1. 找出所有看空信号（如压力位、成交量萎缩、下跌趋势等）
2. 列举支持下跌的理由和风险因素
3. 预测未来可能的下跌目标
4. 给出看空的投资建议""",
        agent=yin_agent,
        expected_output="一份详细的看空分析报告"
    )

    # 执行分析
    print("\n" + "="*80)
    print("☀️ 阳分析师（看多）开始分析...")
    print("="*80)
    crew1 = Crew(agents=[yang_agent], tasks=[yang_task])
    yang_result = crew1.kickoff()

    print("\n" + "="*80)
    print("🌙 阴分析师（看空）开始分析...")
    print("="*80)
    crew2 = Crew(agents=[yin_agent], tasks=[yin_task])
    yin_result = crew2.kickoff()

    print("\n" + "="*80)
    print("⚖️ 综合仲裁者开始综合分析...")
    print("="*80)

    judge_task = Task(
        description=f"""请综合以下两份报告，给出最终的中立分析报告：

【☀️ 阳分析师报告】
{yang_result}

【🌙 阴分析师报告】
{yin_result}

分析要求：
1. 对比两份报告的观点和依据
2. 评估各自的合理性和局限性
3. 给出明确的最终结论（看多/看空/观望）

操作建议（按时间框架输出）：
- 5分钟：开仓方向（多/空/无），开仓价格，止损价格，止盈价格
- 1小时：开仓方向（多/空/无），开仓价格，止损价格，止盈价格
- 1天：开仓方向（多/空/无），开仓价格，止损价格，止盈价格

必须开仓：开仓方向（多/空/无），开仓价格，止损价格，止盈价格

注："无"表示观望，不建议开仓；"必须开仓"为强制开仓情况下的建议""",
        agent=judge_agent,
        expected_output="一份综合、客观、有明确结论的最终分析报告，包含各时间框架的具体操作建议"
    )

    crew3 = Crew(agents=[judge_agent], tasks=[judge_task])
    judge_result = crew3.kickoff()

    # 输出最终报告
    print("\n" + "="*80)
    print("📋 最终综合分析报告")
    print("="*80)
    print(judge_result)

if __name__ == '__main__':
    main()