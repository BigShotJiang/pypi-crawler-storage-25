import os
import asyncio
import requests
import time
import threading
import logging
from datetime import datetime
from dotenv import load_dotenv
from crewai import Agent, Task, Crew

load_dotenv()

# ========== 日志配置 ==========
LOG_DIR = "/Users/yanhuang/PythonProject1/logs"
os.makedirs(LOG_DIR, exist_ok=True)

detailed_logger = logging.getLogger('detailed')
detailed_logger.setLevel(logging.DEBUG)
detailed_handler = logging.FileHandler(os.path.join(LOG_DIR, '详细日志.log'), encoding='utf-8')
detailed_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
detailed_logger.addHandler(detailed_handler)

trade_logger = logging.getLogger('trade')
trade_logger.setLevel(logging.INFO)
trade_handler = logging.FileHandler(os.path.join(LOG_DIR, '交易记录日志.log'), encoding='utf-8')
trade_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
trade_logger.addHandler(trade_handler)

result_logger = logging.getLogger('result')
result_logger.setLevel(logging.INFO)
result_handler = logging.FileHandler(os.path.join(LOG_DIR, '交易结果日志.log'), encoding='utf-8')
result_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
result_logger.addHandler(result_handler)

# ========== API Key 检查 ==========
load_dotenv()
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY")
if not DASHSCOPE_API_KEY:
    print("⚠️ 警告：未设置 DASHSCOPE_API_KEY 环境变量")
    print("请在项目根目录创建 .env 文件，内容如下：")
    print("DASHSCOPE_API_KEY=your_api_key_here")
    print("您可以从 https://dashscope.aliyun.com/ 获取API Key")
    detailed_logger.warning("未设置 DASHSCOPE_API_KEY 环境变量")


# ========== 网络请求重试装饰器 ==========
def retry_on_failure(max_retries=3, delay=2):
    def decorator(func):
        def wrapper(*args, **kwargs):
            last_error = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    wait_time = delay * (2 ** attempt)
                    print(f"⚠️ 请求失败 ({attempt + 1}/{max_retries})，{wait_time}秒后重试...")
                    detailed_logger.warning(f"请求失败 ({attempt + 1}/{max_retries}): {e}")
                    time.sleep(wait_time)
            print(f"❌ 请求失败，已重试{max_retries}次: {last_error}")
            detailed_logger.error(f"请求失败，已重试{max_retries}次: {last_error}")
            return None

        return wrapper

    return decorator


# ========== 验证功能相关数据结构 ==========
class TradeRecommendation:
    def __init__(self, inst_id, direction, entry_price, stop_loss, take_profit, timestamp):
        self.inst_id = inst_id
        self.direction = direction
        self.entry_price = entry_price
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.timestamp = timestamp
        self.status = "active"
        self.result = None
        self.close_reason = None
        self.close_price = None
        self.close_time = None

    def __repr__(self):
        return f"{self.direction.upper()} {self.inst_id} @ {self.entry_price:.2f} (TP:{self.take_profit:.2f}, SL:{self.stop_loss:.2f})"


class RecommendationValidator:
    def __init__(self):
        self.active_recommendation = None
        self.history = []

    def add_recommendation(self, inst_id, direction, entry_price, stop_loss, take_profit):
        if self.active_recommendation:
            self.force_close("时间到")

        rec = TradeRecommendation(inst_id, direction, entry_price, stop_loss, take_profit, datetime.now())
        self.active_recommendation = rec

        log_msg = f"开仓: {direction.upper()} {inst_id} | 开仓时间: {rec.timestamp.strftime('%Y-%m-%d %H:%M:%S')} | 入场: {entry_price:.2f} | 止损: {stop_loss:.2f} | 止盈: {take_profit:.2f}"
        print(f"\n📝 {log_msg}")
        detailed_logger.info(log_msg)
        trade_logger.info(log_msg)

        return rec

    def check_and_update(self):
        if not self.active_recommendation:
            return None

        current_time = datetime.now()
        try:
            price = self._get_current_price(self.active_recommendation.inst_id)
            if price is None:
                return None

            rec = self.active_recommendation
            if rec.direction == "long":
                if price >= rec.take_profit:
                    return self._close_recommendation(rec, "win", "tp", price, current_time)
                elif price <= rec.stop_loss:
                    return self._close_recommendation(rec, "loss", "sl", price, current_time)
            else:
                if price <= rec.take_profit:
                    return self._close_recommendation(rec, "win", "tp", price, current_time)
                elif price >= rec.stop_loss:
                    return self._close_recommendation(rec, "loss", "sl", price, current_time)
        except Exception as e:
            error_msg = f"检查建议时出错: {e}"
            print(f"⚠️ {error_msg}")
            detailed_logger.error(error_msg)

        return None

    def force_close(self, reason="时间到"):
        if not self.active_recommendation:
            return None

        current_time = datetime.now()
        price = self._get_current_price(self.active_recommendation.inst_id)

        if price is None:
            price = self.active_recommendation.entry_price

        rec = self.active_recommendation

        if rec.direction == "long":
            if price >= rec.entry_price:
                result = "win"
            else:
                result = "loss"
        else:
            if price <= rec.entry_price:
                result = "win"
            else:
                result = "loss"

        return self._close_recommendation(rec, result, "time", price, current_time)

    @retry_on_failure(max_retries=3, delay=2)
    def _get_current_price(self, inst_id):
        url = f"https://www.okx.com/api/v5/market/ticker?instId={inst_id}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['code'] == '0':
            return float(data['data'][0]['last'])
        return None

    def _close_recommendation(self, rec, result, reason, price, close_time):
        rec.status = "closed"
        rec.result = result
        rec.close_reason = reason
        rec.close_price = price
        rec.close_time = close_time

        if rec.direction == "long":
            profit = price - rec.entry_price
        else:
            profit = rec.entry_price - price
        profit_pct = (profit / rec.entry_price) * 100

        self.history.append(rec)
        self.active_recommendation = None

        result_emoji = "🎉" if result == "win" else "💔"
        if reason == "time":
            reason_text = "时间到"
        elif reason == "tp":
            reason_text = "止盈"
        else:
            reason_text = "止损"

        message = (f"{result_emoji} 平仓: {rec.direction.upper()} {rec.inst_id} | {result} | {reason_text} "
                   f"| 开仓:{rec.timestamp.strftime('%Y-%m-%d %H:%M:%S')} 平仓:{close_time.strftime('%Y-%m-%d %H:%M:%S')} "
                   f"| 入场:{rec.entry_price:.2f} 平仓:{price:.2f} "
                   f"| 盈亏:{profit:+.2f} ({profit_pct:+.2f}%)")

        print(f"\n{message}")
        detailed_logger.info(message)
        result_logger.info(
            f"{rec.direction.upper()} {rec.inst_id} | {result} | {reason_text} | 入场:{rec.entry_price:.2f} 平仓:{price:.2f} | 盈亏:{profit:+.2f} ({profit_pct:+.2f}%)")

        return message

    def get_stats(self):
        total = len(self.history)
        wins = sum(1 for r in self.history if r.result == "win")
        losses = sum(1 for r in self.history if r.result == "loss")
        win_rate = (wins / total * 100) if total > 0 else 0

        total_profit = 0
        for r in self.history:
            if r.direction == "long":
                total_profit += (r.close_price - r.entry_price)
            else:
                total_profit += (r.entry_price - r.close_price)

        return {
            "total": total,
            "wins": wins,
            "losses": losses,
            "win_rate": round(win_rate, 2),
            "active": 1 if self.active_recommendation else 0,
            "total_profit": round(total_profit, 2)
        }

    def get_last_result(self):
        if self.history:
            last = self.history[-1]
            result_emoji = "✅" if last.result == "win" else "❌"

            if last.close_reason == "tp":
                reason_text = "止盈"
            elif last.close_reason == "sl":
                reason_text = "止损"
            else:
                reason_text = "时间到"

            if last.direction == "long":
                profit = last.close_price - last.entry_price
            else:
                profit = last.entry_price - last.close_price
            profit_pct = (profit / last.entry_price) * 100

            return (f"{result_emoji} 上次结果: {last.direction.upper()} {last.inst_id} | {last.result} | {reason_text} "
                    f"| 开仓:{last.timestamp.strftime('%H:%M:%S')} 平仓:{last.close_time.strftime('%H:%M:%S')} "
                    f"| 入场:{last.entry_price:.2f} 平仓:{last.close_price:.2f} "
                    f"| 盈亏:{profit:+.2f} ({profit_pct:+.2f}%)")
        return "暂无交易记录"

    def get_history_summary(self):
        if not self.history:
            return "暂无历史记录"

        summary = ["📊 交易历史记录（最近10条）:"]
        for i, rec in enumerate(reversed(self.history[-10:]), 1):
            result_emoji = "✅" if rec.result == "win" else "❌"

            if rec.close_reason == "tp":
                reason_text = "止盈"
            elif rec.close_reason == "sl":
                reason_text = "止损"
            else:
                reason_text = "时间到"

            if rec.direction == "long":
                profit = rec.close_price - rec.entry_price
            else:
                profit = rec.entry_price - rec.close_price
            profit_pct = (profit / rec.entry_price) * 100

            summary.append(
                f"{i}. {result_emoji} {rec.direction.upper()} {rec.inst_id} | "
                f"{rec.timestamp.strftime('%H:%M')}-{rec.close_time.strftime('%H:%M')} | "
                f"入场:{rec.entry_price:.2f} 平仓:{rec.close_price:.2f} | "
                f"{reason_text} | 盈亏:{profit:+.2f} ({profit_pct:+.2f}%)"
            )
        return "\n".join(summary)


validator = RecommendationValidator()


# ========== 行情获取功能 ==========
@retry_on_failure(max_retries=3, delay=2)
def get_real_time_market(inst_id="BTC-USDT-SWAP"):
    url = f"https://www.okx.com/api/v5/market/ticker?instId={inst_id}"
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    data = response.json()

    if data['code'] == '0':
        ticker = data['data'][0]
        last = float(ticker['last'])
        open_24h = float(ticker['open24h'])
        high_24h = float(ticker['high24h'])
        low_24h = float(ticker['low24h'])
        change = last - open_24h
        change_pct = (change / open_24h) * 100

        detailed_logger.debug(f"获取行情 {inst_id}: 价格={last:.2f}, 24h涨跌={change_pct:+.2f}%")

        return {
            'success': True,
            'data': f"""
【OKX {inst_id} 行情】
最新价格：{last:,.2f} USDT
24h涨跌：{change_pct:+.2f}% ({change:+.2f} USDT)
24h最高：{high_24h:,.2f} USDT
24h最低：{low_24h:,.2f} USDT
""",
            'price': last,
            'change_pct': change_pct,
            'high_24h': high_24h,
            'low_24h': low_24h
        }
    else:
        error_msg = f"API返回错误: {data.get('msg', '未知错误')}"
        detailed_logger.error(error_msg)
        return {'success': False, 'error': error_msg}


@retry_on_failure(max_retries=3, delay=2)
def get_kline_data(inst_id="BTC-USDT-SWAP", bar="5m", limit=100):
    url = f"https://www.okx.com/api/v5/market/candles?instId={inst_id}&bar={bar}&limit={limit}"
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    data = response.json()

    if data['code'] == '0' and data['data']:
        candles = data['data']
        recent_high = max(float(c[2]) for c in candles[:20])
        recent_low = min(float(c[3]) for c in candles[:20])

        # 计算简单技术指标
        closes = [float(c[4]) for c in candles]
        volume_sum = sum(float(c[5]) for c in candles[:10])

        detailed_logger.debug(f"获取K线 {inst_id}: 支撑={recent_low:.2f}, 压力={recent_high:.2f}")

        return {
            'success': True,
            'data': f"""
【OKX {inst_id} {bar} K线数据】
支撑位参考：{recent_low:,.2f} USDT
压力位参考：{recent_high:,.2f} USDT
""",
            'support': recent_low,
            'resistance': recent_high,
            'candles': candles,
            'price_change': closes[0] - closes[-1] if len(closes) > 1 else 0,
            'volume': volume_sum
        }
    error_msg = "K线数据为空"
    detailed_logger.error(error_msg)
    return {'success': False, 'error': error_msg}


# ========== Agent定义 ==========
def create_agents():
    try:
        market_agent = Agent(
            role="OKX行情数据员",
            goal="解读加密货币行情数据，提供准确的实时价格和技术指标",
            backstory="专业金融行情分析，擅长数据解读和趋势判断",
            verbose=False,
            llm="dashscope/qwen-turbo"
        )

        analyst_agent = Agent(
            role="量化技术分析师",
            goal="基于K线数据进行技术面趋势分析、支撑压力判断、多空信号识别",
            backstory="精通均线、MACD、RSI、布林带等技术指标，能够客观判断多空趋势，敢于在信号明确时给出交易建议",
            verbose=False,
            llm="openai/qwen-turbo"
        )

        risk_agent = Agent(
            role="量化风控专员",
            goal="提供仓位管理建议、止损止盈点位建议、爆仓风险提示",
            backstory="保守风控，优先保本金，严格执行风险控制",
            verbose=False,
            llm="dashscope/qwen-turbo"
        )

        return market_agent, analyst_agent, risk_agent
    except Exception as e:
        error_msg = f"创建Agent失败: {e}"
        print(f"❌ {error_msg}")
        detailed_logger.error(error_msg)
        return None, None, None


# ========== 解析函数 ==========
def parse_user_input(user_input):
    user_input_lower = user_input.lower()

    if "eth" in user_input_lower:
        return "ETH-USDT-SWAP" if "swap" in user_input_lower or "永续" in user_input_lower else "ETH-USDT"
    elif "btc" in user_input_lower:
        return "BTC-USDT-SWAP" if "swap" in user_input_lower or "永续" in user_input_lower else "BTC-USDT"
    elif "sol" in user_input_lower:
        return "SOL-USDT-SWAP" if "swap" in user_input_lower or "永续" in user_input_lower else "SOL-USDT"
    elif "lab" in user_input_lower:
        return "LAB-USDT-SWAP" if "swap" in user_input_lower or "永续" in user_input_lower else "LAB-USDT"
    else:
        return "BTC-USDT-SWAP"


def parse_trade_signal(response_text, inst_id):
    lines = response_text.split('\n')
    direction = None
    entry_price = None
    stop_loss = None
    take_profit = None

    detailed_logger.debug(f"解析交易信号: {response_text[:300]}...")

    for line in lines:
        line_stripped = line.strip()
        if "推荐操作" in line_stripped:
            if "做多" in line_stripped and "做空" not in line_stripped and "观望" not in line_stripped:
                direction = "long"
            elif "做空" in line_stripped and "做多" not in line_stripped and "观望" not in line_stripped:
                direction = "short"
            elif "观望" in line_stripped:
                direction = "wait"

        if "入场点" in line_stripped or "入场价" in line_stripped:
            try:
                entry_price = float(''.join([c for c in line_stripped if c.isdigit() or c == '.']))
            except:
                pass
        if "止损点" in line_stripped or "止损价" in line_stripped:
            try:
                stop_loss = float(''.join([c for c in line_stripped if c.isdigit() or c == '.']))
            except:
                pass
        if "止盈点" in line_stripped or "止盈价" in line_stripped:
            try:
                take_profit = float(''.join([c for c in line_stripped if c.isdigit() or c == '.']))
            except:
                pass

    if direction == "wait":
        detailed_logger.info(f"AI建议观望，不开仓")
        return False, None, None, None, None

    if direction and entry_price and stop_loss and take_profit:
        validator.add_recommendation(inst_id, direction, entry_price, stop_loss, take_profit)
        detailed_logger.info(
            f"解析成功: {direction.upper()} {inst_id} 入场:{entry_price:.2f} 止损:{stop_loss:.2f} 止盈:{take_profit:.2f}")
        return True, direction, entry_price, stop_loss, take_profit

    detailed_logger.warning(
        f"解析失败，未找到完整信号: direction={direction}, entry={entry_price}, sl={stop_loss}, tp={take_profit}")
    return False, None, None, None, None


# ========== 分析函数 ==========
def analyze_market(inst_id="BTC-USDT-SWAP"):
    print(f"\n🔍 正在分析 {inst_id} 五分钟行情...")
    detailed_logger.info(f"开始分析 {inst_id} 五分钟行情")

    ticker_result = get_real_time_market(inst_id)
    if ticker_result is None:
        return {"success": False, "error": "获取行情失败（重试后仍失败）"}
    if not ticker_result['success']:
        return {"success": False, "error": ticker_result['error']}

    kline_result = get_kline_data(inst_id, bar="5m", limit=100)
    if kline_result is None:
        return {"success": False, "error": "获取K线失败（重试后仍失败）"}
    if not kline_result['success']:
        return {"success": False, "error": kline_result['error']}

    market_agent, analyst_agent, risk_agent = create_agents()
    if not market_agent:
        return {"success": False, "error": "无法创建AI Agent"}

    current_price = ticker_result['price']
    change_pct = ticker_result['change_pct']
    support = kline_result['support']
    resistance = kline_result['resistance']

    # 计算额外指标
    price_to_support = (current_price - support) / current_price * 100
    price_to_resistance = (resistance - current_price) / current_price * 100

    task = Task(
        description=f"""
基础行情参考：
{ticker_result['data']}

K线数据：
{kline_result['data']}

技术分析指标：
- 当前价格: {current_price:.2f} USDT
- 支撑位: {support:.2f} USDT (距离当前: {price_to_support:.2f}%)
- 压力位: {resistance:.2f} USDT (距离当前: {price_to_resistance:.2f}%)
- 24h涨跌幅: {change_pct:+.2f}%

请基于以上数据，给出五分钟级别交易建议。

## 分析要求：
1. 作为专业交易员，要有明确的交易观点，不要过于保守
2. 当价格接近支撑位且有上涨迹象时，考虑做多
3. 当价格接近压力位且有下跌迹象时，考虑做空
4. 只有在行情非常不明朗时才建议观望
5. 概率评分总和必须为100%，单个概率不要低于10%

## 输出格式：
## 三、📊 重点推荐（概率评分）
- 做多概率：XX%
- 做空概率：XX%  
- 观望概率：XX%
- 【推荐操作】：明确推荐"做多"、"做空"或"观望"
- 【推荐理由】：详细说明判断依据

## 四、操作建议
- 入场点：XXX USDT
- 止损点：XXX USDT
- 止盈点：XXX USDT
- 仓位建议：XX%
""",
        expected_output="专业量化分析报告，包含概率评分和操作建议，要有明确的交易观点",
        agent=analyst_agent
    )

    crew = Crew(agents=[market_agent, analyst_agent, risk_agent], tasks=[task], verbose=False)

    try:
        result = crew.kickoff()
        result_str = str(result)
        print(f"📊 AI分析完成")
        detailed_logger.info(f"AI分析完成，结果长度: {len(result_str)}")

        parsed, direction, entry, sl, tp = parse_trade_signal(result_str, inst_id)

        return {
            "success": True,
            "analysis": result_str,
            "parsed": parsed,
            "direction": direction,
            "entry_price": entry,
            "stop_loss": sl,
            "take_profit": tp,
            "current_price": current_price,
            "timestamp": datetime.now()
        }
    except RuntimeError as e:
        if "cannot enter context" in str(e):
            try:
                new_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(new_loop)
                result = new_loop.run_until_complete(asyncio.ensure_future(crew.kickoff()))
                result_str = str(result)
                print(f"📊 AI分析完成（备用模式）")
                parsed, direction, entry, sl, tp = parse_trade_signal(result_str, inst_id)
                new_loop.close()
                return {
                    "success": True,
                    "analysis": result_str,
                    "parsed": parsed,
                    "direction": direction,
                    "entry_price": entry,
                    "stop_loss": sl,
                    "take_profit": tp,
                    "current_price": current_price,
                    "timestamp": datetime.now()
                }
            except Exception as inner_e:
                error_msg = f"异步模式也失败: {inner_e}"
                detailed_logger.error(error_msg)
                return {"success": False, "error": error_msg}
        error_msg = f"AI分析失败: {e}"
        detailed_logger.error(error_msg)
        return {"success": False, "error": error_msg}
    except Exception as e:
        error_msg = f"分析过程出错: {e}"
        detailed_logger.error(error_msg)
        return {"success": False, "error": error_msg}


# ========== 定时任务线程 ==========
class AutoAnalyzer:
    def __init__(self):
        self.running = False
        self.thread = None
        self.target_inst_id = "BTC-USDT-SWAP"

    def start(self, inst_id="BTC-USDT-SWAP"):
        if self.running:
            print("⚠️ 自动分析已在运行中")
            detailed_logger.warning("自动分析已在运行中")
            return
        self.target_inst_id = inst_id
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        print(f"✅ 自动分析已启动（每5分钟分析 {inst_id}）")
        detailed_logger.info(f"自动分析已启动，交易对: {inst_id}")

    def _run_loop(self):
        while self.running:
            print("\n" + "=" * 60)
            current_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print(f"🕐 {current_time_str}")
            print("=" * 60)

            detailed_logger.info(f"========== 新周期开始 {current_time_str} ==========")

            if validator.active_recommendation:
                print("\n⏰ 5分钟周期结束，强制平仓...")
                detailed_logger.info("5分钟周期结束，强制平仓")
                validator.force_close("时间到")
            else:
                print("\n📋 无持仓")
                detailed_logger.info("无持仓")

            last_result = validator.get_last_result()
            print(f"\n📊 {last_result}")

            result = analyze_market(self.target_inst_id)

            if result['success']:
                print(f"\n📈 本次建议: {'开仓' if result['parsed'] else '观望'}")
                if result['parsed']:
                    print(f"   方向: {result['direction'].upper()}")
                    print(f"   入场: {result['entry_price']:.2f} USDT")
                    print(f"   止损: {result['stop_loss']:.2f} USDT")
                    print(f"   止盈: {result['take_profit']:.2f} USDT")
            else:
                print(f"❌ 分析失败: {result['error']}")

            if self.running:
                self._wait_with_checks()

    def _wait_with_checks(self):
        for _ in range(10):
            if not self.running:
                break
            validator.check_and_update()
            time.sleep(30)

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        print("🛑 自动分析已停止")
        detailed_logger.info("自动分析已停止")


auto_analyzer = AutoAnalyzer()


# ========== 聊天查询 ==========
def chat_query(user_input):
    if user_input.lower() in ["stats", "统计", "战绩", "历史"]:
        stats = validator.get_stats()
        summary = validator.get_history_summary()

        position_info = ""
        if validator.active_recommendation:
            rec = validator.active_recommendation
            position_info = f"""
📌 当前持仓:
- 方向: {rec.direction.upper()}
- 交易对: {rec.inst_id}
- 入场价: {rec.entry_price:.2f} USDT
- 止损: {rec.stop_loss:.2f} USDT
- 止盈: {rec.take_profit:.2f} USDT
- 开仓时间: {rec.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
"""

        return f"""
📊 交易统计:
- 总交易数: {stats['total']}
- 盈利: {stats['wins']}
- 亏损: {stats['losses']}
- 胜率: {stats['win_rate']}%
- 总盈亏: {stats['total_profit']:+.2f} USDT
- 当前持仓: {'有' if stats['active'] else '无'}

{position_info}{summary}
"""

    inst_id = parse_user_input(user_input)
    result = analyze_market(inst_id)

    if result['success']:
        return result['analysis']
    else:
        return f"❌ 分析失败: {result['error']}"


# ========== 主程序 ==========
def main():
    print("=" * 60)
    print("✅ OKX量化多智能体聊天助手 v1.0")
    print("🔍 自动验证功能已集成")
    print("📝 日志记录已启用")
    print("支持: BTC、ETH、SOL、LAB")
    print("命令:")
    print("  stats/统计 - 查看验证历史")
    print("  auto on - 启动自动分析")
    print("  auto off - 停止自动分析")
    print("  auto btc/eth/sol/lab - 切换分析币种")
    print("  exit/退出 - 退出程序")
    print("=" * 60)

    if not DASHSCOPE_API_KEY:
        print("\n⚠️ 警告：未设置 DASHSCOPE_API_KEY 环境变量")
        print("请创建 .env 文件并添加: DASHSCOPE_API_KEY=your_api_key")
        print("API Key 获取地址: https://dashscope.aliyun.com/\n")

    detailed_logger.info("程序启动")

    while True:
        user_text = input("\n你：").strip()
        if not user_text:
            continue

        if user_text.lower() in ["exit", "quit", "退出"]:
            auto_analyzer.stop()
            detailed_logger.info("程序退出")
            print("👋 退出聊天")
            break

        if user_text.lower().startswith("auto"):
            parts = user_text.lower().split()
            if len(parts) >= 2:
                if parts[1] == "on":
                    if not DASHSCOPE_API_KEY:
                        print("❌ 请先设置 DASHSCOPE_API_KEY 环境变量")
                        continue
                    auto_analyzer.start()
                elif parts[1] == "off":
                    auto_analyzer.stop()
                elif parts[1] in ["btc", "eth", "sol", "lab"]:
                    if not DASHSCOPE_API_KEY:
                        print("❌ 请先设置 DASHSCOPE_API_KEY 环境变量")
                        continue
                    inst_id = f"{parts[1].upper()}-USDT-SWAP"
                    auto_analyzer.stop()
                    auto_analyzer.start(inst_id)
                else:
                    print("❌ 未知命令，可用: auto on/off/btc/eth/sol/lab")
            else:
                print("❌ 命令格式: auto on/off/btc/eth/sol/lab")
            continue

        if not DASHSCOPE_API_KEY:
            print("❌ 请先设置 DASHSCOPE_API_KEY 环境变量")
            continue

        print("\n🤖 AI分析中，请稍候...")
        res = chat_query(user_text)
        print(f"\nAI：{res}")


if __name__ == "__main__":
    main()
