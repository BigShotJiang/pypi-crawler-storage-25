from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from enum import Enum
import json
import os

from fuwen_config.常量 import 福纹配置目录

router = APIRouter()

CONFIG_DIR = 福纹配置目录
os.makedirs(CONFIG_DIR, exist_ok=True)

class ExchangeType(str, Enum):
    OKX = "okx"
    IB = "ib"
    BINANCE = "binance"
    FUTU = "futu"

class GatewayConfig(BaseModel):
    id: Optional[str] = None
    name: str = Field(..., description="网关名称")
    exchange: ExchangeType = Field(..., description="交易所类型")
    api_key: str = Field(..., description="API Key")
    api_secret: str = Field(..., description="API Secret")
    passphrase: Optional[str] = Field(None, description="API Passphrase（OKX专用）")
    host: Optional[str] = Field(None, description="服务器地址")
    port: Optional[int] = Field(None, description="端口")
    is_active: bool = Field(True, description="是否启用")
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

gateway_store = {}

def load_gateways():
    """从 JSON 文件加载网关配置"""
    for filename in os.listdir(CONFIG_DIR):
        if filename.startswith('connect_') and filename.endswith('.json'):
            filepath = os.path.join(CONFIG_DIR, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    gateway_id = filename.removeprefix('connect_').removesuffix('.json')
                    if gateway_id:
                        gateway_store[gateway_id] = data
            except Exception as e:
                print(f"加载配置文件失败 {filename}: {e}")

load_gateways()

@router.get("/", summary="获取网关列表")
async def list_gateways(exchange: Optional[ExchangeType] = None) -> Dict[str, Any]:
    if exchange:
        filtered = {k: v for k, v in gateway_store.items() if v['exchange'] == exchange.value}
        return {"success": True, "data": list(filtered.values())}
    return {"success": True, "data": list(gateway_store.values())}

@router.get("/{gateway_id}", summary="获取网关详情")
async def get_gateway(gateway_id: str) -> Dict[str, Any]:
    if gateway_id not in gateway_store:
        raise HTTPException(status_code=404, detail="网关不存在")
    return {"success": True, "data": gateway_store[gateway_id]}

@router.post("/", summary="创建网关配置")
async def create_gateway(config: GatewayConfig) -> Dict[str, Any]:
    import time
    gateway_id = f"GW_{config.exchange.value}_{int(time.time() * 1000)}"
    config_dict = config.dict()
    config_dict['id'] = gateway_id
    config_dict['created_at'] = time.strftime("%Y-%m-%d %H:%M:%S")
    config_dict['updated_at'] = config_dict['created_at']
    gateway_store[gateway_id] = config_dict
    
    # 保存到 JSON 文件
    filename = f"connect_{config.name}.json"
    filepath = os.path.join(CONFIG_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(config_dict, f, ensure_ascii=False, indent=2)
    
    return {"success": True, "data": config_dict}

@router.put("/{gateway_id}", summary="更新网关配置")
async def update_gateway(gateway_id: str, config: GatewayConfig) -> Dict[str, Any]:
    if gateway_id not in gateway_store:
        raise HTTPException(status_code=404, detail="网关不存在")
    import time
    config_dict = config.dict()
    config_dict['id'] = gateway_id
    config_dict['created_at'] = gateway_store[gateway_id]['created_at']
    config_dict['updated_at'] = time.strftime("%Y-%m-%d %H:%M:%S")
    gateway_store[gateway_id] = config_dict
    
    # 更新 JSON 文件
    filename = f"connect_{config.name}.json"
    filepath = os.path.join(CONFIG_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(config_dict, f, ensure_ascii=False, indent=2)
    
    return {"success": True, "data": config_dict}

@router.delete("/{gateway_id}", summary="删除网关配置")
async def delete_gateway(gateway_id: str) -> Dict[str, Any]:
    if gateway_id not in gateway_store:
        raise HTTPException(status_code=404, detail="网关不存在")
    deleted = gateway_store.pop(gateway_id)
    
    # 删除 JSON 文件
    filename = f"connect_{deleted.get('name', gateway_id)}.json"
    filepath = os.path.join(CONFIG_DIR, filename)
    if os.path.exists(filepath):
        os.remove(filepath)
    
    return {"success": True, "data": deleted}

class TestRequest(BaseModel):
    serverType: Optional[str] = "demo"

@router.post("/{gateway_id}/test", summary="测试网关连接")
async def test_gateway(gateway_id: str, req: Optional[TestRequest] = None) -> Dict[str, Any]:
    if gateway_id not in gateway_store:
        raise HTTPException(status_code=404, detail="网关不存在")
    
    gateway = gateway_store[gateway_id]
    server_type = req.serverType if req else "demo"
    
    try:
        import ccxt
        exchange_class = getattr(ccxt, 'okx')
        exchange = exchange_class({
            'apiKey': gateway['api_key'],
            'secret': gateway['api_secret'],
            'password': gateway.get('passphrase', ''),
            'enableRateLimit': True,
            'options': {
                'defaultType': 'swap',
            }
        })
        
        if server_type == 'demo':
            exchange.set_sandbox_mode(True)
        
        balance = exchange.fetch_balance()
        usdt_balance = balance.get('USDT', {}).get('free', 0)
        
        return {
            "success": True,
            "data": {
                "gateway_id": gateway_id,
                "exchange": gateway['exchange'],
                "status": "connected",
                "message": f"{gateway['exchange']} 网关连接测试成功（{server_type}环境）",
                "balance": float(usdt_balance)
            }
        }
    except ImportError:
        return {
            "success": True,
            "data": {
                "gateway_id": gateway_id,
                "exchange": gateway['exchange'],
                "status": "connected",
                "message": f"{gateway['exchange']} 网关配置有效（ccxt未安装，跳过真实连接测试）"
            }
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@router.get("/exchanges", summary="获取支持的交易所列表")
async def list_exchanges() -> Dict[str, Any]:
    exchanges = [
        {"code": "okx", "name": "OKX", "description": "欧易交易所", "support_margin": True, "support_futures": True},
        {"code": "ib", "name": "Interactive Brokers", "description": "盈透证券", "support_margin": True, "support_futures": True},
        {"code": "binance", "name": "Binance", "description": "币安交易所", "support_margin": True, "support_futures": True},
        {"code": "futu", "name": "富途牛牛", "description": "富途证券", "support_margin": True, "support_futures": False}
    ]
    return {"success": True, "data": exchanges}