from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from enum import Enum

router = APIRouter()

class OrderSide(str, Enum):
    LONG = "long"
    SHORT = "short"

class MarginMode(str, Enum):
    ISOLATED = "isolated"
    CROSS = "cross"

class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"

class SimpleOrderRequest(BaseModel):
    symbol: str = Field(..., description="标的代码，如 BTC-USDT-SWAP")
    side: OrderSide = Field(..., description="开仓方向")
    quantity: Optional[float] = Field(None, description="开仓数量（张）")
    leverage: Optional[int] = Field(10, description="杠杆倍数", ge=1, le=100)
    serverType: Optional[str] = "demo"
    gatewayId: Optional[str] = None

class DetailedOrderRequest(BaseModel):
    symbol: str = Field(..., description="标的代码")
    side: OrderSide = Field(..., description="开仓方向")
    order_type: OrderType = Field(OrderType.MARKET, description="订单类型")
    open_price: Optional[float] = Field(None, description="开仓价格（限价单必填）")
    quantity: Optional[float] = Field(None, description="开仓数量")
    leverage: int = Field(10, description="杠杆倍数", ge=1, le=100)
    margin_mode: MarginMode = Field(MarginMode.ISOLATED, description="保证金模式")
    take_profit_price: Optional[float] = Field(None, description="止盈价格")
    stop_loss_price: Optional[float] = Field(None, description="止损价格")
    position_mode: Optional[str] = Field("net", description="持仓模式：net/long_short")
    serverType: Optional[str] = "demo"
    gatewayId: Optional[str] = None

order_store = {}

@router.post("/simple", summary="简洁下单")
async def simple_order(order: SimpleOrderRequest) -> Dict[str, Any]:
    import time
    order_id = f"ORD_{order.symbol.replace('-', '')}_{int(time.time() * 1000)}"
    
    order_data = {
        "order_id": order_id,
        "symbol": order.symbol,
        "side": order.side.value,
        "quantity": order.quantity or 1,
        "leverage": order.leverage,
        "order_type": "market",
        "margin_mode": "isolated",
        "status": "submitted",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "okx_order_id": None
    }
    
    if order.gatewayId:
        from .gateway import gateway_store
        if order.gatewayId in gateway_store:
            gateway = gateway_store[order.gatewayId]
            server_type = order.serverType or "demo"
            
            try:
                import ccxt
                exchange_class = getattr(ccxt, 'okx')
                exchange = exchange_class({
                    'apiKey': gateway['api_key'],
                    'secret': gateway['api_secret'],
                    'password': gateway.get('passphrase', ''),
                    'enableRateLimit': True,
                    'options': {
                        'defaultType': 'swap',
                    }
                })
                
                if server_type == 'demo':
                    exchange.set_sandbox_mode(True)
                
                exchange.set_leverage(order.leverage, order.symbol)
                
                ccxt_side = 'buy' if order.side.value == 'long' else 'sell'
                amount = order.quantity or 1
                
                okx_order = exchange.create_order(
                    symbol=order.symbol,
                    type='market',
                    side=ccxt_side,
                    amount=amount,
                    params={
                        'marginMode': 'isolated',
                        'positionSide': 'long' if order.side.value == 'long' else 'short'
                    }
                )
                
                order_data['okx_order_id'] = okx_order.get('id')
                order_data['status'] = 'filled' if okx_order.get('status') == 'closed' else 'open'
                
            except ImportError:
                pass
            except Exception as e:
                return {
                    "success": False,
                    "message": f"真实订单提交失败: {str(e)}，已使用模拟订单"
                }
    
    order_store[order_id] = order_data
    
    return {
        "success": True,
        "message": "订单提交成功",
        "data": order_data
    }

@router.post("/detailed", summary="详细下单")
async def detailed_order(order: DetailedOrderRequest) -> Dict[str, Any]:
    if order.order_type == OrderType.LIMIT and not order.open_price:
        raise HTTPException(status_code=400, detail="限价单必须指定开仓价格")
    
    import time
    order_id = f"ORD_{order.symbol.replace('-', '')}_{int(time.time() * 1000)}"
    
    order_data = {
        "order_id": order_id,
        "symbol": order.symbol,
        "side": order.side.value,
        "order_type": order.order_type.value,
        "open_price": order.open_price,
        "quantity": order.quantity or 1,
        "leverage": order.leverage,
        "margin_mode": order.margin_mode.value,
        "take_profit_price": order.take_profit_price,
        "stop_loss_price": order.stop_loss_price,
        "position_mode": order.position_mode,
        "status": "submitted",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "okx_order_id": None
    }
    
    if order.gatewayId:
        from .gateway import gateway_store
        if order.gatewayId in gateway_store:
            gateway = gateway_store[order.gatewayId]
            server_type = order.serverType or "demo"
            
            try:
                import ccxt
                exchange_class = getattr(ccxt, 'okx')
                exchange = exchange_class({
                    'apiKey': gateway['api_key'],
                    'secret': gateway['api_secret'],
                    'password': gateway.get('passphrase', ''),
                    'enableRateLimit': True,
                    'options': {
                        'defaultType': 'swap',
                    }
                })
                
                if server_type == 'demo':
                    exchange.set_sandbox_mode(True)
                
                exchange.set_leverage(order.leverage, order.symbol)
                
                ccxt_side = 'buy' if order.side.value == 'long' else 'sell'
                amount = order.quantity or 1
                
                params = {
                    'marginMode': order.margin_mode.value,
                    'positionSide': 'long' if order.side.value == 'long' else 'short'
                }
                
                if order.take_profit_price:
                    params['takeProfitPrice'] = order.take_profit_price
                if order.stop_loss_price:
                    params['stopLossPrice'] = order.stop_loss_price
                
                okx_order = exchange.create_order(
                    symbol=order.symbol,
                    type=order.order_type.value,
                    side=ccxt_side,
                    amount=amount,
                    price=order.open_price if order.order_type == OrderType.LIMIT else None,
                    params=params
                )
                
                order_data['okx_order_id'] = okx_order.get('id')
                order_data['status'] = okx_order.get('status', 'open')
                
            except ImportError:
                pass
            except Exception as e:
                return {
                    "success": False,
                    "message": f"真实订单提交失败: {str(e)}，已使用模拟订单"
                }
    
    order_store[order_id] = order_data
    
    return {
        "success": True,
        "message": "订单提交成功",
        "data": order_data
    }

@router.get("/orders", summary="获取订单列表")
async def list_orders(
    symbol: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000)
) -> Dict[str, Any]:
    orders = list(order_store.values())
    if symbol:
        orders = [o for o in orders if o['symbol'] == symbol]
    if status:
        orders = [o for o in orders if o['status'] == status]
    orders = orders[:limit]
    return {"success": True, "data": orders}

@router.get("/orders/{order_id}", summary="获取订单详情")
async def get_order(order_id: str) -> Dict[str, Any]:
    if order_id not in order_store:
        raise HTTPException(status_code=404, detail="订单不存在")
    return {"success": True, "data": order_store[order_id]}

@router.delete("/orders/{order_id}", summary="取消订单")
async def cancel_order(order_id: str) -> Dict[str, Any]:
    if order_id not in order_store:
        raise HTTPException(status_code=404, detail="订单不存在")
    order = order_store[order_id]
    if order['status'] in ['filled', 'cancelled']:
        raise HTTPException(status_code=400, detail="订单已完成或已取消")
    
    if order.get('okx_order_id'):
        from .gateway import gateway_store
        for gateway_id, gateway in gateway_store.items():
            try:
                import ccxt
                exchange_class = getattr(ccxt, 'okx')
                exchange = exchange_class({
                    'apiKey': gateway['api_key'],
                    'secret': gateway['api_secret'],
                    'password': gateway.get('passphrase', ''),
                    'enableRateLimit': True,
                    'options': {'defaultType': 'swap'}
                })
                exchange.cancel_order(order['okx_order_id'], order['symbol'])
            except:
                pass
    
    order['status'] = 'cancelled'
    return {"success": True, "message": "订单已取消", "data": order}

@router.get("/positions", summary="获取当前持仓")
async def get_positions(
    symbol: Optional[str] = None,
    gateway_id: Optional[str] = None
) -> Dict[str, Any]:
    if gateway_id:
        from .gateway import gateway_store
        if gateway_id in gateway_store:
            gateway = gateway_store[gateway_id]
            try:
                import ccxt
                exchange_class = getattr(ccxt, 'okx')
                exchange = exchange_class({
                    'apiKey': gateway['api_key'],
                    'secret': gateway['api_secret'],
                    'password': gateway.get('passphrase', ''),
                    'enableRateLimit': True,
                    'options': {'defaultType': 'swap'}
                })
                
                positions = exchange.fetch_positions()
                if symbol:
                    positions = [p for p in positions if p['symbol'] == symbol]
                
                result = []
                for pos in positions:
                    if float(pos['contracts']) != 0:
                        result.append({
                            "position_id": pos.get('id', pos['symbol']),
                            "symbol": pos['symbol'],
                            "side": 'long' if float(pos['contracts']) > 0 else 'short',
                            "size": abs(float(pos['contracts'])),
                            "entry_price": float(pos['entryPrice']),
                            "mark_price": float(pos['markPrice']),
                            "unrealized_pnl": float(pos['unrealizedPnl']),
                            "margin_mode": pos.get('marginMode', 'isolated'),
                            "leverage": int(pos.get('leverage', 1)),
                            "notional": float(pos['notional']),
                            "margin": float(pos['margin'])
                        })
                
                return {"success": True, "data": result}
            except Exception as e:
                pass
    
    positions = [
        {
            "position_id": "POS_BTCUSDT_001",
            "symbol": "BTC-USDT-SWAP",
            "side": "long",
            "size": 10,
            "entry_price": 67500.0,
            "mark_price": 67800.0,
            "unrealized_pnl": 300.0,
            "margin_mode": "isolated",
            "leverage": 10,
            "notional": 675000.0,
            "margin": 67500.0
        },
        {
            "position_id": "POS_ETHUSDT_001",
            "symbol": "ETH-USDT-SWAP",
            "side": "short",
            "size": 50,
            "entry_price": 3200.0,
            "mark_price": 3150.0,
            "unrealized_pnl": 250.0,
            "margin_mode": "cross",
            "leverage": 20,
            "notional": 160000.0,
            "margin": 8000.0
        }
    ]
    
    if symbol:
        positions = [p for p in positions if p['symbol'] == symbol]
    
    return {"success": True, "data": positions}

@router.post("/close/{position_id}", summary="平仓")
async def close_position(position_id: str, quantity: Optional[float] = None) -> Dict[str, Any]:
    return {
        "success": True,
        "message": f"持仓 {position_id} 平仓成功",
        "data": {
            "position_id": position_id,
            "quantity": quantity or "全部",
            "status": "closed",
            "realized_pnl": 550.0
        }
    }