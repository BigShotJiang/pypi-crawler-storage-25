import socket
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip != '127.0.0.1' and not ip.startswith('169.254.'):
            if ip.startswith('192.168.') or ip.startswith('10.') or ip.startswith('172.'):
                return ip
    except Exception as e:
        pass

    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        if ip != '127.0.0.1' and not ip.startswith('169.254.'):
            if ip.startswith('192.168.') or ip.startswith('10.') or ip.startswith('172.'):
                return ip
    except Exception as e:
        pass

    return '127.0.0.1'


def initialize_engine():
    try:
        from fuwen_web.engine_manager import engine_manager
        print("正在初始化引擎...")
        result = engine_manager.initialize()
        if result["success"]:
            print(f"✅ 引擎初始化成功: {result['msg']}")
            return True
        else:
            print(f"❌ 引擎初始化失败: {result['msg']}")
            return False
    except ImportError:
        print("⚠️  未找到引擎管理器，跳过引擎初始化")
        return True
    except Exception as e:
        print(f"⚠️  引擎初始化异常: {e}")
        return True


def find_available_port(start_port=8888):
    port = start_port
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(('127.0.0.1', port))
            s.close()
            return port
        except socket.error:
            port += 1


def start():
    if not initialize_engine():
        sys.exit(1)

    local_ip = get_local_ip()
    port = find_available_port(start_port=8888)  # 从 8888开始 ，查找 可用端口

    print("=" * 60)
    print(f"  版本: v1.0.0")
    print(f"  框架: FastAPI")
    print(f"  本地IP: 127.0.0.1")
    print(f"  局域网IP: {local_ip}")
    print(f"  端口: {port}")

    print(f"  可用API端点:")
    print(f"    • 策略管理: /api/strategy/")
    print(f"    • 账户管理: /api/account/")
    print(f"    • 市场数据: /api/market/")
    print(f"    • 系统管理: /api/system/")
    print("-" * 60)
    print(f"  🏠 本地访问: http://127.0.0.1:{port}/")
    print(f"  🌐 首页访问: http://{local_ip}:{port}/")
    print("-" * 60)
    print("=" * 60)

    from fuwen_cli.cli import start_web_server
    start_web_server(host="0.0.0.0", port=port, reload=False, verbose=False)


if __name__ == '__main__':
    start()