from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_inputs_response_200_item import ListInputsResponse200Item
from ...models.list_inputs_runnable_type import ListInputsRunnableType
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    runnable_id: str | Unset = UNSET,
    runnable_type: ListInputsRunnableType | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["runnable_id"] = runnable_id

    json_runnable_type: str | Unset = UNSET
    if not isinstance(runnable_type, Unset):
        json_runnable_type = runnable_type.value

    params["runnable_type"] = json_runnable_type

    params["page"] = page

    params["per_page"] = per_page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/inputs/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListInputsResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListInputsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListInputsResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    runnable_id: str | Unset = UNSET,
    runnable_type: ListInputsRunnableType | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[list[ListInputsResponse200Item]]:
    """List saved Inputs for a Runnable

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (ListInputsRunnableType | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListInputsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
        page=page,
        per_page=per_page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    runnable_id: str | Unset = UNSET,
    runnable_type: ListInputsRunnableType | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> list[ListInputsResponse200Item] | None:
    """List saved Inputs for a Runnable

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (ListInputsRunnableType | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListInputsResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
        page=page,
        per_page=per_page,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    runnable_id: str | Unset = UNSET,
    runnable_type: ListInputsRunnableType | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[list[ListInputsResponse200Item]]:
    """List saved Inputs for a Runnable

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (ListInputsRunnableType | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListInputsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
        page=page,
        per_page=per_page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    runnable_id: str | Unset = UNSET,
    runnable_type: ListInputsRunnableType | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> list[ListInputsResponse200Item] | None:
    """List saved Inputs for a Runnable

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (ListInputsRunnableType | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListInputsResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            runnable_id=runnable_id,
            runnable_type=runnable_type,
            page=page,
            per_page=per_page,
        )
    ).parsed
