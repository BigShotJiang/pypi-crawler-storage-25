from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_input_body import CreateInputBody
from ...models.create_input_runnable_type import CreateInputRunnableType
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    body: CreateInputBody,
    runnable_id: str | Unset = UNSET,
    runnable_type: CreateInputRunnableType | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["runnable_id"] = runnable_id

    json_runnable_type: str | Unset = UNSET
    if not isinstance(runnable_type, Unset):
        json_runnable_type = runnable_type.value

    params["runnable_type"] = json_runnable_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/inputs/create".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UUID | None:
    if response.status_code == 201:
        response_201 = UUID(response.text)

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateInputBody,
    runnable_id: str | Unset = UNSET,
    runnable_type: CreateInputRunnableType | Unset = UNSET,
) -> Response[UUID]:
    """Create an Input for future use in a script or flow

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (CreateInputRunnableType | Unset):
        body (CreateInputBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateInputBody,
    runnable_id: str | Unset = UNSET,
    runnable_type: CreateInputRunnableType | Unset = UNSET,
) -> UUID | None:
    """Create an Input for future use in a script or flow

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (CreateInputRunnableType | Unset):
        body (CreateInputBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateInputBody,
    runnable_id: str | Unset = UNSET,
    runnable_type: CreateInputRunnableType | Unset = UNSET,
) -> Response[UUID]:
    """Create an Input for future use in a script or flow

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (CreateInputRunnableType | Unset):
        body (CreateInputBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
        runnable_id=runnable_id,
        runnable_type=runnable_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateInputBody,
    runnable_id: str | Unset = UNSET,
    runnable_type: CreateInputRunnableType | Unset = UNSET,
) -> UUID | None:
    """Create an Input for future use in a script or flow

    Args:
        workspace (str):
        runnable_id (str | Unset):
        runnable_type (CreateInputRunnableType | Unset):
        body (CreateInputBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
            runnable_id=runnable_id,
            runnable_type=runnable_type,
        )
    ).parsed
