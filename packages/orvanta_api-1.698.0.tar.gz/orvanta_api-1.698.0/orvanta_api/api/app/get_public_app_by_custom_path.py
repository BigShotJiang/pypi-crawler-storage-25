from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_public_app_by_custom_path_response_200 import GetPublicAppByCustomPathResponse200
from ...types import Response


def _get_kwargs(
    custom_path: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps_u/public_app_by_custom_path/{custom_path}".format(
            custom_path=quote(str(custom_path), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetPublicAppByCustomPathResponse200 | None:
    if response.status_code == 200:
        response_200 = GetPublicAppByCustomPathResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetPublicAppByCustomPathResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    custom_path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetPublicAppByCustomPathResponse200]:
    """get public app by custom path

    Args:
        custom_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetPublicAppByCustomPathResponse200]
    """

    kwargs = _get_kwargs(
        custom_path=custom_path,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    custom_path: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetPublicAppByCustomPathResponse200 | None:
    """get public app by custom path

    Args:
        custom_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetPublicAppByCustomPathResponse200
    """

    return sync_detailed(
        custom_path=custom_path,
        client=client,
    ).parsed


async def asyncio_detailed(
    custom_path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetPublicAppByCustomPathResponse200]:
    """get public app by custom path

    Args:
        custom_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetPublicAppByCustomPathResponse200]
    """

    kwargs = _get_kwargs(
        custom_path=custom_path,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    custom_path: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetPublicAppByCustomPathResponse200 | None:
    """get public app by custom path

    Args:
        custom_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetPublicAppByCustomPathResponse200
    """

    return (
        await asyncio_detailed(
            custom_path=custom_path,
            client=client,
        )
    ).parsed
