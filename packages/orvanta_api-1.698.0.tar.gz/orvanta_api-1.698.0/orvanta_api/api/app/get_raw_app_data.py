from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs(
    workspace: str,
    secret_with_extension: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/apps/get_data/v/{secret_with_extension}".format(
            workspace=quote(str(workspace), safe=""),
            secret_with_extension=quote(str(secret_with_extension), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    secret_with_extension: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """get raw app data by

    Args:
        workspace (str):
        secret_with_extension (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        secret_with_extension=secret_with_extension,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    secret_with_extension: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """get raw app data by

    Args:
        workspace (str):
        secret_with_extension (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        secret_with_extension=secret_with_extension,
        client=client,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    secret_with_extension: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """get raw app data by

    Args:
        workspace (str):
        secret_with_extension (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        secret_with_extension=secret_with_extension,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    secret_with_extension: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """get raw app data by

    Args:
        workspace (str):
        secret_with_extension (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            secret_with_extension=secret_with_extension,
            client=client,
        )
    ).parsed
