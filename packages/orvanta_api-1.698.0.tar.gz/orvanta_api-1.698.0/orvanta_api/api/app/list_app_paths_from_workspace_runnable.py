from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_app_paths_from_workspace_runnable_runnable_kind import ListAppPathsFromWorkspaceRunnableRunnableKind
from ...types import Response


def _get_kwargs(
    workspace: str,
    runnable_kind: ListAppPathsFromWorkspaceRunnableRunnableKind,
    path: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/apps/list_paths_from_workspace_runnable/{runnable_kind}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            runnable_kind=quote(str(runnable_kind), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    runnable_kind: ListAppPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[list[str]]:
    """list app paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListAppPathsFromWorkspaceRunnableRunnableKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    runnable_kind: ListAppPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> list[str] | None:
    """list app paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListAppPathsFromWorkspaceRunnableRunnableKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return sync_detailed(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        client=client,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    runnable_kind: ListAppPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[list[str]]:
    """list app paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListAppPathsFromWorkspaceRunnableRunnableKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    runnable_kind: ListAppPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> list[str] | None:
    """list app paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListAppPathsFromWorkspaceRunnableRunnableKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            runnable_kind=runnable_kind,
            path=path,
            client=client,
        )
    ).parsed
