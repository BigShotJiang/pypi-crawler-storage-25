from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.upload_s3_file_from_app_response_200 import UploadS3FileFromAppResponse200
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    body: File,
    file_key: str | Unset = UNSET,
    file_extension: str | Unset = UNSET,
    s3_resource_path: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    content_type: str | Unset = UNSET,
    content_disposition: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["file_key"] = file_key

    params["file_extension"] = file_extension

    params["s3_resource_path"] = s3_resource_path

    params["resource_type"] = resource_type

    params["storage"] = storage

    params["content_type"] = content_type

    params["content_disposition"] = content_disposition

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/apps_u/upload_s3_file/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    _kwargs["content"] = body.payload

    headers["Content-Type"] = "application/octet-stream"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UploadS3FileFromAppResponse200 | None:
    if response.status_code == 200:
        response_200 = UploadS3FileFromAppResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UploadS3FileFromAppResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: File,
    file_key: str | Unset = UNSET,
    file_extension: str | Unset = UNSET,
    s3_resource_path: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    content_type: str | Unset = UNSET,
    content_disposition: str | Unset = UNSET,
) -> Response[UploadS3FileFromAppResponse200]:
    """upload s3 file from app

    Args:
        workspace (str):
        path (str):
        file_key (str | Unset):
        file_extension (str | Unset):
        s3_resource_path (str | Unset):
        resource_type (str | Unset):
        storage (str | Unset):
        content_type (str | Unset):
        content_disposition (str | Unset):
        body (File):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadS3FileFromAppResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
        file_key=file_key,
        file_extension=file_extension,
        s3_resource_path=s3_resource_path,
        resource_type=resource_type,
        storage=storage,
        content_type=content_type,
        content_disposition=content_disposition,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: File,
    file_key: str | Unset = UNSET,
    file_extension: str | Unset = UNSET,
    s3_resource_path: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    content_type: str | Unset = UNSET,
    content_disposition: str | Unset = UNSET,
) -> UploadS3FileFromAppResponse200 | None:
    """upload s3 file from app

    Args:
        workspace (str):
        path (str):
        file_key (str | Unset):
        file_extension (str | Unset):
        s3_resource_path (str | Unset):
        resource_type (str | Unset):
        storage (str | Unset):
        content_type (str | Unset):
        content_disposition (str | Unset):
        body (File):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadS3FileFromAppResponse200
    """

    return sync_detailed(
        workspace=workspace,
        path=path,
        client=client,
        body=body,
        file_key=file_key,
        file_extension=file_extension,
        s3_resource_path=s3_resource_path,
        resource_type=resource_type,
        storage=storage,
        content_type=content_type,
        content_disposition=content_disposition,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: File,
    file_key: str | Unset = UNSET,
    file_extension: str | Unset = UNSET,
    s3_resource_path: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    content_type: str | Unset = UNSET,
    content_disposition: str | Unset = UNSET,
) -> Response[UploadS3FileFromAppResponse200]:
    """upload s3 file from app

    Args:
        workspace (str):
        path (str):
        file_key (str | Unset):
        file_extension (str | Unset):
        s3_resource_path (str | Unset):
        resource_type (str | Unset):
        storage (str | Unset):
        content_type (str | Unset):
        content_disposition (str | Unset):
        body (File):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadS3FileFromAppResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
        file_key=file_key,
        file_extension=file_extension,
        s3_resource_path=s3_resource_path,
        resource_type=resource_type,
        storage=storage,
        content_type=content_type,
        content_disposition=content_disposition,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: File,
    file_key: str | Unset = UNSET,
    file_extension: str | Unset = UNSET,
    s3_resource_path: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    content_type: str | Unset = UNSET,
    content_disposition: str | Unset = UNSET,
) -> UploadS3FileFromAppResponse200 | None:
    """upload s3 file from app

    Args:
        workspace (str):
        path (str):
        file_key (str | Unset):
        file_extension (str | Unset):
        s3_resource_path (str | Unset):
        resource_type (str | Unset):
        storage (str | Unset):
        content_type (str | Unset):
        content_disposition (str | Unset):
        body (File):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadS3FileFromAppResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            path=path,
            client=client,
            body=body,
            file_key=file_key,
            file_extension=file_extension,
            s3_resource_path=s3_resource_path,
            resource_type=resource_type,
            storage=storage,
            content_type=content_type,
            content_disposition=content_disposition,
        )
    ).parsed
