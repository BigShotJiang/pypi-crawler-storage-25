from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.move_captures_and_configs_body import MoveCapturesAndConfigsBody
from ...models.move_captures_and_configs_runnable_kind import MoveCapturesAndConfigsRunnableKind
from ...types import Response


def _get_kwargs(
    workspace: str,
    runnable_kind: MoveCapturesAndConfigsRunnableKind,
    path: str,
    *,
    body: MoveCapturesAndConfigsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/capture/move/{runnable_kind}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            runnable_kind=quote(str(runnable_kind), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    runnable_kind: MoveCapturesAndConfigsRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveCapturesAndConfigsBody,
) -> Response[str]:
    """move captures and configs for a script or flow

    Args:
        workspace (str):
        runnable_kind (MoveCapturesAndConfigsRunnableKind):
        path (str):
        body (MoveCapturesAndConfigsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    runnable_kind: MoveCapturesAndConfigsRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveCapturesAndConfigsBody,
) -> str | None:
    """move captures and configs for a script or flow

    Args:
        workspace (str):
        runnable_kind (MoveCapturesAndConfigsRunnableKind):
        path (str):
        body (MoveCapturesAndConfigsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    runnable_kind: MoveCapturesAndConfigsRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveCapturesAndConfigsBody,
) -> Response[str]:
    """move captures and configs for a script or flow

    Args:
        workspace (str):
        runnable_kind (MoveCapturesAndConfigsRunnableKind):
        path (str):
        body (MoveCapturesAndConfigsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    runnable_kind: MoveCapturesAndConfigsRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: MoveCapturesAndConfigsBody,
) -> str | None:
    """move captures and configs for a script or flow

    Args:
        workspace (str):
        runnable_kind (MoveCapturesAndConfigsRunnableKind):
        path (str):
        body (MoveCapturesAndConfigsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            runnable_kind=runnable_kind,
            path=path,
            client=client,
            body=body,
        )
    ).parsed
