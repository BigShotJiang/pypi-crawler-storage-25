from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_captures_response_200_item import ListCapturesResponse200Item
from ...models.list_captures_runnable_kind import ListCapturesRunnableKind
from ...models.list_captures_trigger_kind import ListCapturesTriggerKind
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    runnable_kind: ListCapturesRunnableKind,
    path: str,
    *,
    trigger_kind: ListCapturesTriggerKind | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_trigger_kind: str | Unset = UNSET
    if not isinstance(trigger_kind, Unset):
        json_trigger_kind = trigger_kind.value

    params["trigger_kind"] = json_trigger_kind

    params["page"] = page

    params["per_page"] = per_page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/capture/list/{runnable_kind}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            runnable_kind=quote(str(runnable_kind), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListCapturesResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListCapturesResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListCapturesResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    runnable_kind: ListCapturesRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    trigger_kind: ListCapturesTriggerKind | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[list[ListCapturesResponse200Item]]:
    """list captures for a script or flow

    Args:
        workspace (str):
        runnable_kind (ListCapturesRunnableKind):
        path (str):
        trigger_kind (ListCapturesTriggerKind | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListCapturesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        trigger_kind=trigger_kind,
        page=page,
        per_page=per_page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    runnable_kind: ListCapturesRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    trigger_kind: ListCapturesTriggerKind | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> list[ListCapturesResponse200Item] | None:
    """list captures for a script or flow

    Args:
        workspace (str):
        runnable_kind (ListCapturesRunnableKind):
        path (str):
        trigger_kind (ListCapturesTriggerKind | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListCapturesResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        client=client,
        trigger_kind=trigger_kind,
        page=page,
        per_page=per_page,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    runnable_kind: ListCapturesRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    trigger_kind: ListCapturesTriggerKind | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[list[ListCapturesResponse200Item]]:
    """list captures for a script or flow

    Args:
        workspace (str):
        runnable_kind (ListCapturesRunnableKind):
        path (str):
        trigger_kind (ListCapturesTriggerKind | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListCapturesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        trigger_kind=trigger_kind,
        page=page,
        per_page=per_page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    runnable_kind: ListCapturesRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    trigger_kind: ListCapturesTriggerKind | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> list[ListCapturesResponse200Item] | None:
    """list captures for a script or flow

    Args:
        workspace (str):
        runnable_kind (ListCapturesRunnableKind):
        path (str):
        trigger_kind (ListCapturesTriggerKind | Unset):
        page (int | Unset):
        per_page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListCapturesResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            runnable_kind=runnable_kind,
            path=path,
            client=client,
            trigger_kind=trigger_kind,
            page=page,
            per_page=per_page,
        )
    ).parsed
