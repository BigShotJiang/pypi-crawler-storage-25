from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connect_callback_body import ConnectCallbackBody
from ...models.connect_callback_response_200 import ConnectCallbackResponse200
from ...types import Response


def _get_kwargs(
    client_name: str,
    *,
    body: ConnectCallbackBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/oauth/connect_callback/{client_name}".format(
            client_name=quote(str(client_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConnectCallbackResponse200 | None:
    if response.status_code == 200:
        response_200 = ConnectCallbackResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConnectCallbackResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectCallbackBody,
) -> Response[ConnectCallbackResponse200]:
    """connect callback

    Args:
        client_name (str):
        body (ConnectCallbackBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectCallbackResponse200]
    """

    kwargs = _get_kwargs(
        client_name=client_name,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    client_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectCallbackBody,
) -> ConnectCallbackResponse200 | None:
    """connect callback

    Args:
        client_name (str):
        body (ConnectCallbackBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectCallbackResponse200
    """

    return sync_detailed(
        client_name=client_name,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    client_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectCallbackBody,
) -> Response[ConnectCallbackResponse200]:
    """connect callback

    Args:
        client_name (str):
        body (ConnectCallbackBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectCallbackResponse200]
    """

    kwargs = _get_kwargs(
        client_name=client_name,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    client_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectCallbackBody,
) -> ConnectCallbackResponse200 | None:
    """connect callback

    Args:
        client_name (str):
        body (ConnectCallbackBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectCallbackResponse200
    """

    return (
        await asyncio_detailed(
            client_name=client_name,
            client=client,
            body=body,
        )
    ).parsed
