from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connect_client_credentials_body import ConnectClientCredentialsBody
from ...models.connect_client_credentials_response_200 import ConnectClientCredentialsResponse200
from ...types import Response


def _get_kwargs(
    client_path: str,
    *,
    body: ConnectClientCredentialsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/oauth/connect_client_credentials/{client_path}".format(
            client_path=quote(str(client_path), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConnectClientCredentialsResponse200 | None:
    if response.status_code == 200:
        response_200 = ConnectClientCredentialsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConnectClientCredentialsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectClientCredentialsBody,
) -> Response[ConnectClientCredentialsResponse200]:
    """connect OAuth using client credentials

    Args:
        client_path (str):
        body (ConnectClientCredentialsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectClientCredentialsResponse200]
    """

    kwargs = _get_kwargs(
        client_path=client_path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    client_path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectClientCredentialsBody,
) -> ConnectClientCredentialsResponse200 | None:
    """connect OAuth using client credentials

    Args:
        client_path (str):
        body (ConnectClientCredentialsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectClientCredentialsResponse200
    """

    return sync_detailed(
        client_path=client_path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    client_path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectClientCredentialsBody,
) -> Response[ConnectClientCredentialsResponse200]:
    """connect OAuth using client credentials

    Args:
        client_path (str):
        body (ConnectClientCredentialsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectClientCredentialsResponse200]
    """

    kwargs = _get_kwargs(
        client_path=client_path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    client_path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConnectClientCredentialsBody,
) -> ConnectClientCredentialsResponse200 | None:
    """connect OAuth using client credentials

    Args:
        client_path (str):
        body (ConnectClientCredentialsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectClientCredentialsResponse200
    """

    return (
        await asyncio_detailed(
            client_path=client_path,
            client=client,
            body=body,
        )
    ).parsed
