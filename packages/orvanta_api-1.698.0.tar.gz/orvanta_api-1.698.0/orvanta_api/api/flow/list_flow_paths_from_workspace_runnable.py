from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_flow_paths_from_workspace_runnable_runnable_kind import (
    ListFlowPathsFromWorkspaceRunnableRunnableKind,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    runnable_kind: ListFlowPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    match_path_start: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["match_path_start"] = match_path_start

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/flows/list_paths_from_workspace_runnable/{runnable_kind}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            runnable_kind=quote(str(runnable_kind), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    runnable_kind: ListFlowPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    match_path_start: bool | Unset = UNSET,
) -> Response[list[str]]:
    """list flow paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListFlowPathsFromWorkspaceRunnableRunnableKind):
        path (str):
        match_path_start (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        match_path_start=match_path_start,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    runnable_kind: ListFlowPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    match_path_start: bool | Unset = UNSET,
) -> list[str] | None:
    """list flow paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListFlowPathsFromWorkspaceRunnableRunnableKind):
        path (str):
        match_path_start (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return sync_detailed(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        client=client,
        match_path_start=match_path_start,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    runnable_kind: ListFlowPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    match_path_start: bool | Unset = UNSET,
) -> Response[list[str]]:
    """list flow paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListFlowPathsFromWorkspaceRunnableRunnableKind):
        path (str):
        match_path_start (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        runnable_kind=runnable_kind,
        path=path,
        match_path_start=match_path_start,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    runnable_kind: ListFlowPathsFromWorkspaceRunnableRunnableKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    match_path_start: bool | Unset = UNSET,
) -> list[str] | None:
    """list flow paths from workspace runnable

    Args:
        workspace (str):
        runnable_kind (ListFlowPathsFromWorkspaceRunnableRunnableKind):
        path (str):
        match_path_start (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            runnable_kind=runnable_kind,
            path=path,
            client=client,
            match_path_start=match_path_start,
        )
    ).parsed
