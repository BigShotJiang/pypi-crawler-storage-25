from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_job_metrics_body import GetJobMetricsBody
from ...models.get_job_metrics_response_200 import GetJobMetricsResponse200
from ...types import Response


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    body: GetJobMetricsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/job_metrics/get/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetJobMetricsResponse200 | None:
    if response.status_code == 200:
        response_200 = GetJobMetricsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetJobMetricsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: GetJobMetricsBody,
) -> Response[GetJobMetricsResponse200]:
    """get job metrics

    Args:
        workspace (str):
        id (UUID):
        body (GetJobMetricsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobMetricsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: GetJobMetricsBody,
) -> GetJobMetricsResponse200 | None:
    """get job metrics

    Args:
        workspace (str):
        id (UUID):
        body (GetJobMetricsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobMetricsResponse200
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: GetJobMetricsBody,
) -> Response[GetJobMetricsResponse200]:
    """get job metrics

    Args:
        workspace (str):
        id (UUID):
        body (GetJobMetricsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobMetricsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: GetJobMetricsBody,
) -> GetJobMetricsResponse200 | None:
    """get job metrics

    Args:
        workspace (str):
        id (UUID):
        body (GetJobMetricsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobMetricsResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            client=client,
            body=body,
        )
    ).parsed
