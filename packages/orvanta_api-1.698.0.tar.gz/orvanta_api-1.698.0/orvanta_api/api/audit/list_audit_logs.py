import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_audit_logs_action_kind import ListAuditLogsActionKind
from ...models.list_audit_logs_response_200_item import ListAuditLogsResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    username: str | Unset = UNSET,
    operation: str | Unset = UNSET,
    operations: str | Unset = UNSET,
    exclude_operations: str | Unset = UNSET,
    resource: str | Unset = UNSET,
    action_kind: ListAuditLogsActionKind | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    json_before: str | Unset = UNSET
    if not isinstance(before, Unset):
        json_before = before.isoformat()
    params["before"] = json_before

    json_after: str | Unset = UNSET
    if not isinstance(after, Unset):
        json_after = after.isoformat()
    params["after"] = json_after

    params["username"] = username

    params["operation"] = operation

    params["operations"] = operations

    params["exclude_operations"] = exclude_operations

    params["resource"] = resource

    json_action_kind: str | Unset = UNSET
    if not isinstance(action_kind, Unset):
        json_action_kind = action_kind.value

    params["action_kind"] = json_action_kind

    params["all_workspaces"] = all_workspaces

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/audit/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListAuditLogsResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListAuditLogsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListAuditLogsResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    username: str | Unset = UNSET,
    operation: str | Unset = UNSET,
    operations: str | Unset = UNSET,
    exclude_operations: str | Unset = UNSET,
    resource: str | Unset = UNSET,
    action_kind: ListAuditLogsActionKind | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> Response[list[ListAuditLogsResponse200Item]]:
    """list audit logs (requires admin privilege)

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        username (str | Unset):
        operation (str | Unset):
        operations (str | Unset):
        exclude_operations (str | Unset):
        resource (str | Unset):
        action_kind (ListAuditLogsActionKind | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListAuditLogsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        before=before,
        after=after,
        username=username,
        operation=operation,
        operations=operations,
        exclude_operations=exclude_operations,
        resource=resource,
        action_kind=action_kind,
        all_workspaces=all_workspaces,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    username: str | Unset = UNSET,
    operation: str | Unset = UNSET,
    operations: str | Unset = UNSET,
    exclude_operations: str | Unset = UNSET,
    resource: str | Unset = UNSET,
    action_kind: ListAuditLogsActionKind | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> list[ListAuditLogsResponse200Item] | None:
    """list audit logs (requires admin privilege)

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        username (str | Unset):
        operation (str | Unset):
        operations (str | Unset):
        exclude_operations (str | Unset):
        resource (str | Unset):
        action_kind (ListAuditLogsActionKind | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListAuditLogsResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        page=page,
        per_page=per_page,
        before=before,
        after=after,
        username=username,
        operation=operation,
        operations=operations,
        exclude_operations=exclude_operations,
        resource=resource,
        action_kind=action_kind,
        all_workspaces=all_workspaces,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    username: str | Unset = UNSET,
    operation: str | Unset = UNSET,
    operations: str | Unset = UNSET,
    exclude_operations: str | Unset = UNSET,
    resource: str | Unset = UNSET,
    action_kind: ListAuditLogsActionKind | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> Response[list[ListAuditLogsResponse200Item]]:
    """list audit logs (requires admin privilege)

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        username (str | Unset):
        operation (str | Unset):
        operations (str | Unset):
        exclude_operations (str | Unset):
        resource (str | Unset):
        action_kind (ListAuditLogsActionKind | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListAuditLogsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        before=before,
        after=after,
        username=username,
        operation=operation,
        operations=operations,
        exclude_operations=exclude_operations,
        resource=resource,
        action_kind=action_kind,
        all_workspaces=all_workspaces,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    username: str | Unset = UNSET,
    operation: str | Unset = UNSET,
    operations: str | Unset = UNSET,
    exclude_operations: str | Unset = UNSET,
    resource: str | Unset = UNSET,
    action_kind: ListAuditLogsActionKind | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> list[ListAuditLogsResponse200Item] | None:
    """list audit logs (requires admin privilege)

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        username (str | Unset):
        operation (str | Unset):
        operations (str | Unset):
        exclude_operations (str | Unset):
        resource (str | Unset):
        action_kind (ListAuditLogsActionKind | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListAuditLogsResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            page=page,
            per_page=per_page,
            before=before,
            after=after,
            username=username,
            operation=operation,
            operations=operations,
            exclude_operations=exclude_operations,
            resource=resource,
            action_kind=action_kind,
            all_workspaces=all_workspaces,
        )
    ).parsed
