from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.set_mqtt_trigger_mode_body import SetMqttTriggerModeBody
from ...types import Response


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    body: SetMqttTriggerModeBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/mqtt_triggers/setmode/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetMqttTriggerModeBody,
) -> Response[str]:
    """set enabled mqtt trigger

    Args:
        workspace (str):
        path (str):
        body (SetMqttTriggerModeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetMqttTriggerModeBody,
) -> str | None:
    """set enabled mqtt trigger

    Args:
        workspace (str):
        path (str):
        body (SetMqttTriggerModeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        path=path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetMqttTriggerModeBody,
) -> Response[str]:
    """set enabled mqtt trigger

    Args:
        workspace (str):
        path (str):
        body (SetMqttTriggerModeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetMqttTriggerModeBody,
) -> str | None:
    """set enabled mqtt trigger

    Args:
        workspace (str):
        path (str):
        body (SetMqttTriggerModeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            path=path,
            client=client,
            body=body,
        )
    ).parsed
