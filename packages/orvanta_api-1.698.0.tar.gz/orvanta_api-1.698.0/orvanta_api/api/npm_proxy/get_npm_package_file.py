from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs(
    workspace: str,
    package: str,
    version: str,
    filepath: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/npm_proxy/file/{package}/{version}/{filepath}".format(
            workspace=quote(str(workspace), safe=""),
            package=quote(str(package), safe=""),
            version=quote(str(version), safe=""),
            filepath=quote(str(filepath), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    package: str,
    version: str,
    filepath: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """get specific file from npm package in private registry

    Args:
        workspace (str):
        package (str):
        version (str):
        filepath (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        package=package,
        version=version,
        filepath=filepath,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    package: str,
    version: str,
    filepath: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """get specific file from npm package in private registry

    Args:
        workspace (str):
        package (str):
        version (str):
        filepath (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        package=package,
        version=version,
        filepath=filepath,
        client=client,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    package: str,
    version: str,
    filepath: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """get specific file from npm package in private registry

    Args:
        workspace (str):
        package (str):
        version (str):
        filepath (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        package=package,
        version=version,
        filepath=filepath,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    package: str,
    version: str,
    filepath: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """get specific file from npm package in private registry

    Args:
        workspace (str):
        package (str):
        version (str):
        filepath (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            package=package,
            version=version,
            filepath=filepath,
            client=client,
        )
    ).parsed
