from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    audience: str,
    *,
    expires_in: float | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["expires_in"] = expires_in

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/oidc/token/{audience}".format(
            workspace=quote(str(workspace), safe=""),
            audience=quote(str(audience), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    audience: str,
    *,
    client: AuthenticatedClient | Client,
    expires_in: float | Unset = UNSET,
) -> Response[str]:
    """get OIDC token (ee only)

    Args:
        workspace (str):
        audience (str):
        expires_in (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        audience=audience,
        expires_in=expires_in,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    audience: str,
    *,
    client: AuthenticatedClient | Client,
    expires_in: float | Unset = UNSET,
) -> str | None:
    """get OIDC token (ee only)

    Args:
        workspace (str):
        audience (str):
        expires_in (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        audience=audience,
        client=client,
        expires_in=expires_in,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    audience: str,
    *,
    client: AuthenticatedClient | Client,
    expires_in: float | Unset = UNSET,
) -> Response[str]:
    """get OIDC token (ee only)

    Args:
        workspace (str):
        audience (str):
        expires_in (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        audience=audience,
        expires_in=expires_in,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    audience: str,
    *,
    client: AuthenticatedClient | Client,
    expires_in: float | Unset = UNSET,
) -> str | None:
    """get OIDC token (ee only)

    Args:
        workspace (str):
        audience (str):
        expires_in (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            audience=audience,
            client=client,
            expires_in=expires_in,
        )
    ).parsed
