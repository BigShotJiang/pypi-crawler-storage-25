from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_conversation_messages_response_200_item import ListConversationMessagesResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    conversation_id: UUID,
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    after_seq: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params["after_seq"] = after_seq

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/flow_conversations/{conversation_id}/messages".format(
            workspace=quote(str(workspace), safe=""),
            conversation_id=quote(str(conversation_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListConversationMessagesResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListConversationMessagesResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListConversationMessagesResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    after_seq: int | Unset = UNSET,
) -> Response[list[ListConversationMessagesResponse200Item]]:
    """list conversation messages

    Args:
        workspace (str):
        conversation_id (UUID):
        page (int | Unset):
        per_page (int | Unset):
        after_seq (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListConversationMessagesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        conversation_id=conversation_id,
        page=page,
        per_page=per_page,
        after_seq=after_seq,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    after_seq: int | Unset = UNSET,
) -> list[ListConversationMessagesResponse200Item] | None:
    """list conversation messages

    Args:
        workspace (str):
        conversation_id (UUID):
        page (int | Unset):
        per_page (int | Unset):
        after_seq (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListConversationMessagesResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        conversation_id=conversation_id,
        client=client,
        page=page,
        per_page=per_page,
        after_seq=after_seq,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    after_seq: int | Unset = UNSET,
) -> Response[list[ListConversationMessagesResponse200Item]]:
    """list conversation messages

    Args:
        workspace (str):
        conversation_id (UUID):
        page (int | Unset):
        per_page (int | Unset):
        after_seq (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListConversationMessagesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        conversation_id=conversation_id,
        page=page,
        per_page=per_page,
        after_seq=after_seq,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    after_seq: int | Unset = UNSET,
) -> list[ListConversationMessagesResponse200Item] | None:
    """list conversation messages

    Args:
        workspace (str):
        conversation_id (UUID):
        page (int | Unset):
        per_page (int | Unset):
        after_seq (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListConversationMessagesResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            conversation_id=conversation_id,
            client=client,
            page=page,
            per_page=per_page,
            after_seq=after_seq,
        )
    ).parsed
