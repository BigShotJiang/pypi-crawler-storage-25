from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.query_resource_types_response_200_item import QueryResourceTypesResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    text: str,
    limit: float | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["text"] = text

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/embeddings/query_resource_types".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[QueryResourceTypesResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = QueryResourceTypesResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[QueryResourceTypesResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    text: str,
    limit: float | Unset = UNSET,
) -> Response[list[QueryResourceTypesResponse200Item]]:
    """query resource types by similarity

    Args:
        workspace (str):
        text (str):
        limit (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[QueryResourceTypesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        text=text,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    text: str,
    limit: float | Unset = UNSET,
) -> list[QueryResourceTypesResponse200Item] | None:
    """query resource types by similarity

    Args:
        workspace (str):
        text (str):
        limit (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[QueryResourceTypesResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        text=text,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    text: str,
    limit: float | Unset = UNSET,
) -> Response[list[QueryResourceTypesResponse200Item]]:
    """query resource types by similarity

    Args:
        workspace (str):
        text (str):
        limit (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[QueryResourceTypesResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        text=text,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    text: str,
    limit: float | Unset = UNSET,
) -> list[QueryResourceTypesResponse200Item] | None:
    """query resource types by similarity

    Args:
        workspace (str):
        text (str):
        limit (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[QueryResourceTypesResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            text=text,
            limit=limit,
        )
    ).parsed
