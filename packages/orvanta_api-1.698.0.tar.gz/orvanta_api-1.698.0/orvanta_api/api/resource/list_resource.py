from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_resource_response_200_item import ListResourceResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    resource_type_exclude: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path: str | Unset = UNSET,
    description: str | Unset = UNSET,
    value: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
    label: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params["resource_type"] = resource_type

    params["resource_type_exclude"] = resource_type_exclude

    params["path_start"] = path_start

    params["path"] = path

    params["description"] = description

    params["value"] = value

    params["broad_filter"] = broad_filter

    params["label"] = label

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/resources/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListResourceResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListResourceResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListResourceResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    resource_type_exclude: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path: str | Unset = UNSET,
    description: str | Unset = UNSET,
    value: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListResourceResponse200Item]]:
    """list resources

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        resource_type (str | Unset):
        resource_type_exclude (str | Unset):
        path_start (str | Unset):
        path (str | Unset):
        description (str | Unset):
        value (str | Unset):
        broad_filter (str | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListResourceResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        resource_type=resource_type,
        resource_type_exclude=resource_type_exclude,
        path_start=path_start,
        path=path,
        description=description,
        value=value,
        broad_filter=broad_filter,
        label=label,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    resource_type_exclude: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path: str | Unset = UNSET,
    description: str | Unset = UNSET,
    value: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListResourceResponse200Item] | None:
    """list resources

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        resource_type (str | Unset):
        resource_type_exclude (str | Unset):
        path_start (str | Unset):
        path (str | Unset):
        description (str | Unset):
        value (str | Unset):
        broad_filter (str | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListResourceResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        page=page,
        per_page=per_page,
        resource_type=resource_type,
        resource_type_exclude=resource_type_exclude,
        path_start=path_start,
        path=path,
        description=description,
        value=value,
        broad_filter=broad_filter,
        label=label,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    resource_type_exclude: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path: str | Unset = UNSET,
    description: str | Unset = UNSET,
    value: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListResourceResponse200Item]]:
    """list resources

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        resource_type (str | Unset):
        resource_type_exclude (str | Unset):
        path_start (str | Unset):
        path (str | Unset):
        description (str | Unset):
        value (str | Unset):
        broad_filter (str | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListResourceResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        resource_type=resource_type,
        resource_type_exclude=resource_type_exclude,
        path_start=path_start,
        path=path,
        description=description,
        value=value,
        broad_filter=broad_filter,
        label=label,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    resource_type: str | Unset = UNSET,
    resource_type_exclude: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path: str | Unset = UNSET,
    description: str | Unset = UNSET,
    value: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListResourceResponse200Item] | None:
    """list resources

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        resource_type (str | Unset):
        resource_type_exclude (str | Unset):
        path_start (str | Unset):
        path (str | Unset):
        description (str | Unset):
        value (str | Unset):
        broad_filter (str | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListResourceResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            page=page,
            per_page=per_page,
            resource_type=resource_type,
            resource_type_exclude=resource_type_exclude,
            path_start=path_start,
            path=path,
            description=description,
            value=value,
            broad_filter=broad_filter,
            label=label,
        )
    ).parsed
