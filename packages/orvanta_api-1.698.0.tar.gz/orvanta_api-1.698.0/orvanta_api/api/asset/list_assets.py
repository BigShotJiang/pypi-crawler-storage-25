import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_assets_response_200 import ListAssetsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    per_page: int | Unset = 50,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: int | Unset = UNSET,
    asset_path: str | Unset = UNSET,
    usage_path: str | Unset = UNSET,
    asset_kinds: str | Unset = UNSET,
    path: str | Unset = UNSET,
    columns: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["per_page"] = per_page

    json_cursor_created_at: str | Unset = UNSET
    if not isinstance(cursor_created_at, Unset):
        json_cursor_created_at = cursor_created_at.isoformat()
    params["cursor_created_at"] = json_cursor_created_at

    params["cursor_id"] = cursor_id

    params["asset_path"] = asset_path

    params["usage_path"] = usage_path

    params["asset_kinds"] = asset_kinds

    params["path"] = path

    params["columns"] = columns

    params["broad_filter"] = broad_filter

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/assets/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListAssetsResponse200 | None:
    if response.status_code == 200:
        response_200 = ListAssetsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListAssetsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    per_page: int | Unset = 50,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: int | Unset = UNSET,
    asset_path: str | Unset = UNSET,
    usage_path: str | Unset = UNSET,
    asset_kinds: str | Unset = UNSET,
    path: str | Unset = UNSET,
    columns: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> Response[ListAssetsResponse200]:
    """List all assets in the workspace with cursor pagination

    Args:
        workspace (str):
        per_page (int | Unset):  Default: 50.
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (int | Unset):
        asset_path (str | Unset):
        usage_path (str | Unset):
        asset_kinds (str | Unset):
        path (str | Unset):
        columns (str | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAssetsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        per_page=per_page,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        asset_path=asset_path,
        usage_path=usage_path,
        asset_kinds=asset_kinds,
        path=path,
        columns=columns,
        broad_filter=broad_filter,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    per_page: int | Unset = 50,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: int | Unset = UNSET,
    asset_path: str | Unset = UNSET,
    usage_path: str | Unset = UNSET,
    asset_kinds: str | Unset = UNSET,
    path: str | Unset = UNSET,
    columns: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> ListAssetsResponse200 | None:
    """List all assets in the workspace with cursor pagination

    Args:
        workspace (str):
        per_page (int | Unset):  Default: 50.
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (int | Unset):
        asset_path (str | Unset):
        usage_path (str | Unset):
        asset_kinds (str | Unset):
        path (str | Unset):
        columns (str | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAssetsResponse200
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        per_page=per_page,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        asset_path=asset_path,
        usage_path=usage_path,
        asset_kinds=asset_kinds,
        path=path,
        columns=columns,
        broad_filter=broad_filter,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    per_page: int | Unset = 50,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: int | Unset = UNSET,
    asset_path: str | Unset = UNSET,
    usage_path: str | Unset = UNSET,
    asset_kinds: str | Unset = UNSET,
    path: str | Unset = UNSET,
    columns: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> Response[ListAssetsResponse200]:
    """List all assets in the workspace with cursor pagination

    Args:
        workspace (str):
        per_page (int | Unset):  Default: 50.
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (int | Unset):
        asset_path (str | Unset):
        usage_path (str | Unset):
        asset_kinds (str | Unset):
        path (str | Unset):
        columns (str | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAssetsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        per_page=per_page,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        asset_path=asset_path,
        usage_path=usage_path,
        asset_kinds=asset_kinds,
        path=path,
        columns=columns,
        broad_filter=broad_filter,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    per_page: int | Unset = 50,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: int | Unset = UNSET,
    asset_path: str | Unset = UNSET,
    usage_path: str | Unset = UNSET,
    asset_kinds: str | Unset = UNSET,
    path: str | Unset = UNSET,
    columns: str | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> ListAssetsResponse200 | None:
    """List all assets in the workspace with cursor pagination

    Args:
        workspace (str):
        per_page (int | Unset):  Default: 50.
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (int | Unset):
        asset_path (str | Unset):
        usage_path (str | Unset):
        asset_kinds (str | Unset):
        path (str | Unset):
        columns (str | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAssetsResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            per_page=per_page,
            cursor_created_at=cursor_created_at,
            cursor_id=cursor_id,
            asset_path=asset_path,
            usage_path=usage_path,
            asset_kinds=asset_kinds,
            path=path,
            columns=columns,
            broad_filter=broad_filter,
        )
    ).parsed
