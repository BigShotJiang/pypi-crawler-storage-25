from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_assets_by_usage_body import ListAssetsByUsageBody
from ...models.list_assets_by_usage_response_200_item_item import ListAssetsByUsageResponse200ItemItem
from ...types import Response


def _get_kwargs(
    workspace: str,
    *,
    body: ListAssetsByUsageBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/assets/list_by_usages".format(
            workspace=quote(str(workspace), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[list[ListAssetsByUsageResponse200ItemItem]] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = []
            _response_200_item = response_200_item_data
            for response_200_item_item_data in _response_200_item:
                response_200_item_item = ListAssetsByUsageResponse200ItemItem.from_dict(response_200_item_item_data)

                response_200_item.append(response_200_item_item)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[list[ListAssetsByUsageResponse200ItemItem]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAssetsByUsageBody,
) -> Response[list[list[ListAssetsByUsageResponse200ItemItem]]]:
    """List all assets used by given usages paths

    Args:
        workspace (str):
        body (ListAssetsByUsageBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[list[ListAssetsByUsageResponse200ItemItem]]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAssetsByUsageBody,
) -> list[list[ListAssetsByUsageResponse200ItemItem]] | None:
    """List all assets used by given usages paths

    Args:
        workspace (str):
        body (ListAssetsByUsageBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[list[ListAssetsByUsageResponse200ItemItem]]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAssetsByUsageBody,
) -> Response[list[list[ListAssetsByUsageResponse200ItemItem]]]:
    """List all assets used by given usages paths

    Args:
        workspace (str):
        body (ListAssetsByUsageBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[list[ListAssetsByUsageResponse200ItemItem]]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAssetsByUsageBody,
) -> list[list[ListAssetsByUsageResponse200ItemItem]] | None:
    """List all assets used by given usages paths

    Args:
        workspace (str):
        body (ListAssetsByUsageBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[list[ListAssetsByUsageResponse200ItemItem]]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
        )
    ).parsed
