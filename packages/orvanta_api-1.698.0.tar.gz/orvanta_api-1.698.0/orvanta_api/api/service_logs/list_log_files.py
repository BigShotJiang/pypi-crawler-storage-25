import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_log_files_response_200_item import ListLogFilesResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    with_error: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_before: str | Unset = UNSET
    if not isinstance(before, Unset):
        json_before = before.isoformat()
    params["before"] = json_before

    json_after: str | Unset = UNSET
    if not isinstance(after, Unset):
        json_after = after.isoformat()
    params["after"] = json_after

    params["with_error"] = with_error

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/service_logs/list_files",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListLogFilesResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListLogFilesResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListLogFilesResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    with_error: bool | Unset = UNSET,
) -> Response[list[ListLogFilesResponse200Item]]:
    """list log files ordered by timestamp

    Args:
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        with_error (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListLogFilesResponse200Item]]
    """

    kwargs = _get_kwargs(
        before=before,
        after=after,
        with_error=with_error,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    with_error: bool | Unset = UNSET,
) -> list[ListLogFilesResponse200Item] | None:
    """list log files ordered by timestamp

    Args:
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        with_error (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListLogFilesResponse200Item]
    """

    return sync_detailed(
        client=client,
        before=before,
        after=after,
        with_error=with_error,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    with_error: bool | Unset = UNSET,
) -> Response[list[ListLogFilesResponse200Item]]:
    """list log files ordered by timestamp

    Args:
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        with_error (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListLogFilesResponse200Item]]
    """

    kwargs = _get_kwargs(
        before=before,
        after=after,
        with_error=with_error,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    before: datetime.datetime | Unset = UNSET,
    after: datetime.datetime | Unset = UNSET,
    with_error: bool | Unset = UNSET,
) -> list[ListLogFilesResponse200Item] | None:
    """list log files ordered by timestamp

    Args:
        before (datetime.datetime | Unset):
        after (datetime.datetime | Unset):
        with_error (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListLogFilesResponse200Item]
    """

    return (
        await asyncio_detailed(
            client=client,
            before=before,
            after=after,
            with_error=with_error,
        )
    ).parsed
