from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_all_t_google_topic_subscriptions_body import ListAllTGoogleTopicSubscriptionsBody
from ...types import Response


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    body: ListAllTGoogleTopicSubscriptionsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/gcp_triggers/subscriptions/list/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAllTGoogleTopicSubscriptionsBody,
) -> Response[list[str]]:
    """list all subscription of a give topic from google cloud service

    Args:
        workspace (str):
        path (str):
        body (ListAllTGoogleTopicSubscriptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAllTGoogleTopicSubscriptionsBody,
) -> list[str] | None:
    """list all subscription of a give topic from google cloud service

    Args:
        workspace (str):
        path (str):
        body (ListAllTGoogleTopicSubscriptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return sync_detailed(
        workspace=workspace,
        path=path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAllTGoogleTopicSubscriptionsBody,
) -> Response[list[str]]:
    """list all subscription of a give topic from google cloud service

    Args:
        workspace (str):
        path (str):
        body (ListAllTGoogleTopicSubscriptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: ListAllTGoogleTopicSubscriptionsBody,
) -> list[str] | None:
    """list all subscription of a give topic from google cloud service

    Args:
        workspace (str):
        path (str):
        body (ListAllTGoogleTopicSubscriptionsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            path=path,
            client=client,
            body=body,
        )
    ).parsed
