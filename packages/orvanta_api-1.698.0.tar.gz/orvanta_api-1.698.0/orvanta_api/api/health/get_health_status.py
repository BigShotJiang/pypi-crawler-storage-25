from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_health_status_response_200 import GetHealthStatusResponse200
from ...models.get_health_status_response_503 import GetHealthStatusResponse503
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    force: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["force"] = force

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/health/status",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetHealthStatusResponse200 | GetHealthStatusResponse503 | None:
    if response.status_code == 200:
        response_200 = GetHealthStatusResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 503:
        response_503 = GetHealthStatusResponse503.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetHealthStatusResponse200 | GetHealthStatusResponse503]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    force: bool | Unset = False,
) -> Response[GetHealthStatusResponse200 | GetHealthStatusResponse503]:
    """health status

     Health status endpoint. Returns cached health status (database connectivity, worker count).
    Cache TTL is fixed at 5 seconds. Use force=true query parameter to bypass cache.
    Note: This endpoint is intentionally different from Kubernetes probes to avoid confusion.
    For k8s liveness/readiness probes, use /version endpoint.

    Args:
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetHealthStatusResponse200 | GetHealthStatusResponse503]
    """

    kwargs = _get_kwargs(
        force=force,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    force: bool | Unset = False,
) -> GetHealthStatusResponse200 | GetHealthStatusResponse503 | None:
    """health status

     Health status endpoint. Returns cached health status (database connectivity, worker count).
    Cache TTL is fixed at 5 seconds. Use force=true query parameter to bypass cache.
    Note: This endpoint is intentionally different from Kubernetes probes to avoid confusion.
    For k8s liveness/readiness probes, use /version endpoint.

    Args:
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetHealthStatusResponse200 | GetHealthStatusResponse503
    """

    return sync_detailed(
        client=client,
        force=force,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    force: bool | Unset = False,
) -> Response[GetHealthStatusResponse200 | GetHealthStatusResponse503]:
    """health status

     Health status endpoint. Returns cached health status (database connectivity, worker count).
    Cache TTL is fixed at 5 seconds. Use force=true query parameter to bypass cache.
    Note: This endpoint is intentionally different from Kubernetes probes to avoid confusion.
    For k8s liveness/readiness probes, use /version endpoint.

    Args:
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetHealthStatusResponse200 | GetHealthStatusResponse503]
    """

    kwargs = _get_kwargs(
        force=force,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    force: bool | Unset = False,
) -> GetHealthStatusResponse200 | GetHealthStatusResponse503 | None:
    """health status

     Health status endpoint. Returns cached health status (database connectivity, worker count).
    Cache TTL is fixed at 5 seconds. Use force=true query parameter to bypass cache.
    Note: This endpoint is intentionally different from Kubernetes probes to avoid confusion.
    For k8s liveness/readiness probes, use /version endpoint.

    Args:
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetHealthStatusResponse200 | GetHealthStatusResponse503
    """

    return (
        await asyncio_detailed(
            client=client,
            force=force,
        )
    ).parsed
