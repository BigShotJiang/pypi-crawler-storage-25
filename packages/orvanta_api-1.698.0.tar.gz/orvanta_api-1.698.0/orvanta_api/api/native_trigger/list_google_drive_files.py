from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_google_drive_files_response_200 import ListGoogleDriveFilesResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    q: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    page_token: str | Unset = UNSET,
    shared_with_me: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["q"] = q

    params["parent_id"] = parent_id

    params["page_token"] = page_token

    params["shared_with_me"] = shared_with_me

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/native_triggers/google/drive/files".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListGoogleDriveFilesResponse200 | None:
    if response.status_code == 200:
        response_200 = ListGoogleDriveFilesResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListGoogleDriveFilesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    q: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    page_token: str | Unset = UNSET,
    shared_with_me: bool | Unset = False,
) -> Response[ListGoogleDriveFilesResponse200]:
    """list or search Google Drive files

    Args:
        workspace (str):
        q (str | Unset):
        parent_id (str | Unset):
        page_token (str | Unset):
        shared_with_me (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListGoogleDriveFilesResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        q=q,
        parent_id=parent_id,
        page_token=page_token,
        shared_with_me=shared_with_me,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    q: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    page_token: str | Unset = UNSET,
    shared_with_me: bool | Unset = False,
) -> ListGoogleDriveFilesResponse200 | None:
    """list or search Google Drive files

    Args:
        workspace (str):
        q (str | Unset):
        parent_id (str | Unset):
        page_token (str | Unset):
        shared_with_me (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListGoogleDriveFilesResponse200
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        q=q,
        parent_id=parent_id,
        page_token=page_token,
        shared_with_me=shared_with_me,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    q: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    page_token: str | Unset = UNSET,
    shared_with_me: bool | Unset = False,
) -> Response[ListGoogleDriveFilesResponse200]:
    """list or search Google Drive files

    Args:
        workspace (str):
        q (str | Unset):
        parent_id (str | Unset):
        page_token (str | Unset):
        shared_with_me (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListGoogleDriveFilesResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        q=q,
        parent_id=parent_id,
        page_token=page_token,
        shared_with_me=shared_with_me,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    q: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    page_token: str | Unset = UNSET,
    shared_with_me: bool | Unset = False,
) -> ListGoogleDriveFilesResponse200 | None:
    """list or search Google Drive files

    Args:
        workspace (str):
        q (str | Unset):
        parent_id (str | Unset):
        page_token (str | Unset):
        shared_with_me (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListGoogleDriveFilesResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            q=q,
            parent_id=parent_id,
            page_token=page_token,
            shared_with_me=shared_with_me,
        )
    ).parsed
