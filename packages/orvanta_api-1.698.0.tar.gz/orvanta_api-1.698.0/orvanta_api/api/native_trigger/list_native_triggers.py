from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_native_triggers_response_200_item import ListNativeTriggersResponse200Item
from ...models.list_native_triggers_service_name import ListNativeTriggersServiceName
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    service_name: ListNativeTriggersServiceName,
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    path: str | Unset = UNSET,
    is_flow: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params["path"] = path

    params["is_flow"] = is_flow

    params["label"] = label

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/native_triggers/{service_name}/list".format(
            workspace=quote(str(workspace), safe=""),
            service_name=quote(str(service_name), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListNativeTriggersResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListNativeTriggersResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListNativeTriggersResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    service_name: ListNativeTriggersServiceName,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    path: str | Unset = UNSET,
    is_flow: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListNativeTriggersResponse200Item]]:
    """list native triggers

     Lists all native triggers for the specified service in the workspace.

    Args:
        workspace (str):
        service_name (ListNativeTriggersServiceName):
        page (int | Unset):
        per_page (int | Unset):
        path (str | Unset):
        is_flow (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListNativeTriggersResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        service_name=service_name,
        page=page,
        per_page=per_page,
        path=path,
        is_flow=is_flow,
        label=label,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    service_name: ListNativeTriggersServiceName,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    path: str | Unset = UNSET,
    is_flow: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListNativeTriggersResponse200Item] | None:
    """list native triggers

     Lists all native triggers for the specified service in the workspace.

    Args:
        workspace (str):
        service_name (ListNativeTriggersServiceName):
        page (int | Unset):
        per_page (int | Unset):
        path (str | Unset):
        is_flow (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListNativeTriggersResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        service_name=service_name,
        client=client,
        page=page,
        per_page=per_page,
        path=path,
        is_flow=is_flow,
        label=label,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    service_name: ListNativeTriggersServiceName,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    path: str | Unset = UNSET,
    is_flow: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListNativeTriggersResponse200Item]]:
    """list native triggers

     Lists all native triggers for the specified service in the workspace.

    Args:
        workspace (str):
        service_name (ListNativeTriggersServiceName):
        page (int | Unset):
        per_page (int | Unset):
        path (str | Unset):
        is_flow (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListNativeTriggersResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        service_name=service_name,
        page=page,
        per_page=per_page,
        path=path,
        is_flow=is_flow,
        label=label,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    service_name: ListNativeTriggersServiceName,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    path: str | Unset = UNSET,
    is_flow: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListNativeTriggersResponse200Item] | None:
    """list native triggers

     Lists all native triggers for the specified service in the workspace.

    Args:
        workspace (str):
        service_name (ListNativeTriggersServiceName):
        page (int | Unset):
        per_page (int | Unset):
        path (str | Unset):
        is_flow (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListNativeTriggersResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            service_name=service_name,
            client=client,
            page=page,
            per_page=per_page,
            path=path,
            is_flow=is_flow,
            label=label,
        )
    ).parsed
