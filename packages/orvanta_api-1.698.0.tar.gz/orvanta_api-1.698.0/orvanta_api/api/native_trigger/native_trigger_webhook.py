from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.native_trigger_webhook_json_body import NativeTriggerWebhookJsonBody
from ...models.native_trigger_webhook_service_name import NativeTriggerWebhookServiceName
from ...types import UNSET, Response, Unset


def _get_kwargs(
    service_name: NativeTriggerWebhookServiceName,
    workspace_id: str,
    internal_id: int,
    *,
    body: NativeTriggerWebhookJsonBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/native_triggers/{service_name}/w/{workspace_id}/webhook/{internal_id}".format(
            service_name=quote(str(service_name), safe=""),
            workspace_id=quote(str(workspace_id), safe=""),
            internal_id=quote(str(internal_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    service_name: NativeTriggerWebhookServiceName,
    workspace_id: str,
    internal_id: int,
    *,
    client: AuthenticatedClient | Client,
    body: NativeTriggerWebhookJsonBody | Unset = UNSET,
) -> Response[str]:
    """receive webhook from external native trigger service

    Args:
        service_name (NativeTriggerWebhookServiceName):
        workspace_id (str):
        internal_id (int):
        body (NativeTriggerWebhookJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        service_name=service_name,
        workspace_id=workspace_id,
        internal_id=internal_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    service_name: NativeTriggerWebhookServiceName,
    workspace_id: str,
    internal_id: int,
    *,
    client: AuthenticatedClient | Client,
    body: NativeTriggerWebhookJsonBody | Unset = UNSET,
) -> str | None:
    """receive webhook from external native trigger service

    Args:
        service_name (NativeTriggerWebhookServiceName):
        workspace_id (str):
        internal_id (int):
        body (NativeTriggerWebhookJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        service_name=service_name,
        workspace_id=workspace_id,
        internal_id=internal_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    service_name: NativeTriggerWebhookServiceName,
    workspace_id: str,
    internal_id: int,
    *,
    client: AuthenticatedClient | Client,
    body: NativeTriggerWebhookJsonBody | Unset = UNSET,
) -> Response[str]:
    """receive webhook from external native trigger service

    Args:
        service_name (NativeTriggerWebhookServiceName):
        workspace_id (str):
        internal_id (int):
        body (NativeTriggerWebhookJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        service_name=service_name,
        workspace_id=workspace_id,
        internal_id=internal_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    service_name: NativeTriggerWebhookServiceName,
    workspace_id: str,
    internal_id: int,
    *,
    client: AuthenticatedClient | Client,
    body: NativeTriggerWebhookJsonBody | Unset = UNSET,
) -> str | None:
    """receive webhook from external native trigger service

    Args:
        service_name (NativeTriggerWebhookServiceName):
        workspace_id (str):
        internal_id (int):
        body (NativeTriggerWebhookJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            service_name=service_name,
            workspace_id=workspace_id,
            internal_id=internal_id,
            client=client,
            body=body,
        )
    ).parsed
