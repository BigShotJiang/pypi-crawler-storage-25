from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    offset: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    sort_col: str | Unset = UNSET,
    sort_desc: bool | Unset = UNSET,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    csv_separator: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["offset"] = offset

    params["limit"] = limit

    params["sort_col"] = sort_col

    params["sort_desc"] = sort_desc

    params["search_col"] = search_col

    params["search_term"] = search_term

    params["storage"] = storage

    params["csv_separator"] = csv_separator

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/job_helpers/load_csv_preview/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    offset: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    sort_col: str | Unset = UNSET,
    sort_desc: bool | Unset = UNSET,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    csv_separator: str | Unset = UNSET,
) -> Response[Any]:
    """Load a preview of a csv file

    Args:
        workspace (str):
        path (str):
        offset (float | Unset):
        limit (float | Unset):
        sort_col (str | Unset):
        sort_desc (bool | Unset):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):
        csv_separator (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        offset=offset,
        limit=limit,
        sort_col=sort_col,
        sort_desc=sort_desc,
        search_col=search_col,
        search_term=search_term,
        storage=storage,
        csv_separator=csv_separator,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    offset: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    sort_col: str | Unset = UNSET,
    sort_desc: bool | Unset = UNSET,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
    csv_separator: str | Unset = UNSET,
) -> Response[Any]:
    """Load a preview of a csv file

    Args:
        workspace (str):
        path (str):
        offset (float | Unset):
        limit (float | Unset):
        sort_col (str | Unset):
        sort_desc (bool | Unset):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):
        csv_separator (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        offset=offset,
        limit=limit,
        sort_col=sort_col,
        sort_desc=sort_desc,
        search_col=search_col,
        search_term=search_term,
        storage=storage,
        csv_separator=csv_separator,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
