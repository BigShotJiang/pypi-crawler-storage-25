from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.duckdb_connection_settings_body import DuckdbConnectionSettingsBody
from ...models.duckdb_connection_settings_response_200 import DuckdbConnectionSettingsResponse200
from ...types import Response


def _get_kwargs(
    workspace: str,
    *,
    body: DuckdbConnectionSettingsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/job_helpers/duckdb_connection_settings".format(
            workspace=quote(str(workspace), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DuckdbConnectionSettingsResponse200 | None:
    if response.status_code == 200:
        response_200 = DuckdbConnectionSettingsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DuckdbConnectionSettingsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: DuckdbConnectionSettingsBody,
) -> Response[DuckdbConnectionSettingsResponse200]:
    """Converts an S3 resource to the set of instructions necessary to connect DuckDB to an S3 bucket

    Args:
        workspace (str):
        body (DuckdbConnectionSettingsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DuckdbConnectionSettingsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: DuckdbConnectionSettingsBody,
) -> DuckdbConnectionSettingsResponse200 | None:
    """Converts an S3 resource to the set of instructions necessary to connect DuckDB to an S3 bucket

    Args:
        workspace (str):
        body (DuckdbConnectionSettingsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DuckdbConnectionSettingsResponse200
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: DuckdbConnectionSettingsBody,
) -> Response[DuckdbConnectionSettingsResponse200]:
    """Converts an S3 resource to the set of instructions necessary to connect DuckDB to an S3 bucket

    Args:
        workspace (str):
        body (DuckdbConnectionSettingsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DuckdbConnectionSettingsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: DuckdbConnectionSettingsBody,
) -> DuckdbConnectionSettingsResponse200 | None:
    """Converts an S3 resource to the set of instructions necessary to connect DuckDB to an S3 bucket

    Args:
        workspace (str):
        body (DuckdbConnectionSettingsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DuckdbConnectionSettingsResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
        )
    ).parsed
