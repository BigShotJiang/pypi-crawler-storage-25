from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.load_table_row_count_response_200 import LoadTableRowCountResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["search_col"] = search_col

    params["search_term"] = search_term

    params["storage"] = storage

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/job_helpers/load_table_count/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> LoadTableRowCountResponse200 | None:
    if response.status_code == 200:
        response_200 = LoadTableRowCountResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[LoadTableRowCountResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
) -> Response[LoadTableRowCountResponse200]:
    """Load the table row count

    Args:
        workspace (str):
        path (str):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LoadTableRowCountResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        search_col=search_col,
        search_term=search_term,
        storage=storage,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
) -> LoadTableRowCountResponse200 | None:
    """Load the table row count

    Args:
        workspace (str):
        path (str):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LoadTableRowCountResponse200
    """

    return sync_detailed(
        workspace=workspace,
        path=path,
        client=client,
        search_col=search_col,
        search_term=search_term,
        storage=storage,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
) -> Response[LoadTableRowCountResponse200]:
    """Load the table row count

    Args:
        workspace (str):
        path (str):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LoadTableRowCountResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        search_col=search_col,
        search_term=search_term,
        storage=storage,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    search_col: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    storage: str | Unset = UNSET,
) -> LoadTableRowCountResponse200 | None:
    """Load the table row count

    Args:
        workspace (str):
        path (str):
        search_col (str | Unset):
        search_term (str | Unset):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LoadTableRowCountResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            path=path,
            client=client,
            search_col=search_col,
            search_term=search_term,
            storage=storage,
        )
    ).parsed
