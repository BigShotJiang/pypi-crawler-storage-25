from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    src_file_key: str,
    dest_file_key: str,
    storage: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["src_file_key"] = src_file_key

    params["dest_file_key"] = dest_file_key

    params["storage"] = storage

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/job_helpers/move_s3_file".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    src_file_key: str,
    dest_file_key: str,
    storage: str | Unset = UNSET,
) -> Response[Any]:
    """Move a S3 file from one path to the other within the same bucket

    Args:
        workspace (str):
        src_file_key (str):
        dest_file_key (str):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        src_file_key=src_file_key,
        dest_file_key=dest_file_key,
        storage=storage,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    src_file_key: str,
    dest_file_key: str,
    storage: str | Unset = UNSET,
) -> Response[Any]:
    """Move a S3 file from one path to the other within the same bucket

    Args:
        workspace (str):
        src_file_key (str):
        dest_file_key (str):
        storage (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        src_file_key=src_file_key,
        dest_file_key=dest_file_key,
        storage=storage,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
