from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.s3_resource_info_body import S3ResourceInfoBody
from ...models.s3_resource_info_response_200 import S3ResourceInfoResponse200
from ...types import Response


def _get_kwargs(
    workspace: str,
    *,
    body: S3ResourceInfoBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/job_helpers/v2/s3_resource_info".format(
            workspace=quote(str(workspace), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> S3ResourceInfoResponse200 | None:
    if response.status_code == 200:
        response_200 = S3ResourceInfoResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[S3ResourceInfoResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: S3ResourceInfoBody,
) -> Response[S3ResourceInfoResponse200]:
    """Returns the s3 resource associated to the provided path, or the workspace default S3 resource

    Args:
        workspace (str):
        body (S3ResourceInfoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[S3ResourceInfoResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: S3ResourceInfoBody,
) -> S3ResourceInfoResponse200 | None:
    """Returns the s3 resource associated to the provided path, or the workspace default S3 resource

    Args:
        workspace (str):
        body (S3ResourceInfoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        S3ResourceInfoResponse200
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: S3ResourceInfoBody,
) -> Response[S3ResourceInfoResponse200]:
    """Returns the s3 resource associated to the provided path, or the workspace default S3 resource

    Args:
        workspace (str):
        body (S3ResourceInfoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[S3ResourceInfoResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: S3ResourceInfoBody,
) -> S3ResourceInfoResponse200 | None:
    """Returns the s3 resource associated to the provided path, or the workspace default S3 resource

    Args:
        workspace (str):
        body (S3ResourceInfoBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        S3ResourceInfoResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
        )
    ).parsed
