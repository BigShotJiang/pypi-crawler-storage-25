from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_resume_urls_response_200 import GetResumeUrlsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    resume_id: int,
    *,
    approver: str | Unset = UNSET,
    flow_level: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["approver"] = approver

    params["flow_level"] = flow_level

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/resume_urls/{id}/{resume_id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
            resume_id=quote(str(resume_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetResumeUrlsResponse200 | None:
    if response.status_code == 200:
        response_200 = GetResumeUrlsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetResumeUrlsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    resume_id: int,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    flow_level: bool | Unset = UNSET,
) -> Response[GetResumeUrlsResponse200]:
    """get resume urls given a job_id, resume_id and a nonce to resume a flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        approver (str | Unset):
        flow_level (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetResumeUrlsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        approver=approver,
        flow_level=flow_level,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    resume_id: int,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    flow_level: bool | Unset = UNSET,
) -> GetResumeUrlsResponse200 | None:
    """get resume urls given a job_id, resume_id and a nonce to resume a flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        approver (str | Unset):
        flow_level (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetResumeUrlsResponse200
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        client=client,
        approver=approver,
        flow_level=flow_level,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    resume_id: int,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    flow_level: bool | Unset = UNSET,
) -> Response[GetResumeUrlsResponse200]:
    """get resume urls given a job_id, resume_id and a nonce to resume a flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        approver (str | Unset):
        flow_level (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetResumeUrlsResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        approver=approver,
        flow_level=flow_level,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    resume_id: int,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    flow_level: bool | Unset = UNSET,
) -> GetResumeUrlsResponse200 | None:
    """get resume urls given a job_id, resume_id and a nonce to resume a flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        approver (str | Unset):
        flow_level (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetResumeUrlsResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            resume_id=resume_id,
            client=client,
            approver=approver,
            flow_level=flow_level,
        )
    ).parsed
