import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_queue_response_200_item import ListQueueResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    worker: str | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    trigger_path: str | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["order_desc"] = order_desc

    params["created_by"] = created_by

    json_parent_job: str | Unset = UNSET
    if not isinstance(parent_job, Unset):
        json_parent_job = str(parent_job)
    params["parent_job"] = json_parent_job

    params["worker"] = worker

    params["script_path_exact"] = script_path_exact

    params["script_path_start"] = script_path_start

    params["schedule_path"] = schedule_path

    params["trigger_path"] = trigger_path

    params["trigger_kind"] = trigger_kind

    params["script_hash"] = script_hash

    json_started_before: str | Unset = UNSET
    if not isinstance(started_before, Unset):
        json_started_before = started_before.isoformat()
    params["started_before"] = json_started_before

    json_started_after: str | Unset = UNSET
    if not isinstance(started_after, Unset):
        json_started_after = started_after.isoformat()
    params["started_after"] = json_started_after

    params["success"] = success

    params["scheduled_for_before_now"] = scheduled_for_before_now

    params["job_kinds"] = job_kinds

    params["suspended"] = suspended

    params["running"] = running

    params["args"] = args

    params["result"] = result

    params["allow_wildcards"] = allow_wildcards

    params["tag"] = tag

    params["page"] = page

    params["per_page"] = per_page

    params["all_workspaces"] = all_workspaces

    params["is_not_schedule"] = is_not_schedule

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/queue/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListQueueResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListQueueResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListQueueResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    worker: str | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    trigger_path: str | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> Response[list[ListQueueResponse200Item]]:
    """list all queued jobs

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        worker (str | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        trigger_path (str | Unset):
        trigger_kind (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListQueueResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        worker=worker,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        trigger_path=trigger_path,
        trigger_kind=trigger_kind,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    worker: str | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    trigger_path: str | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> list[ListQueueResponse200Item] | None:
    """list all queued jobs

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        worker (str | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        trigger_path (str | Unset):
        trigger_kind (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListQueueResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        worker=worker,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        trigger_path=trigger_path,
        trigger_kind=trigger_kind,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    worker: str | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    trigger_path: str | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> Response[list[ListQueueResponse200Item]]:
    """list all queued jobs

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        worker (str | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        trigger_path (str | Unset):
        trigger_kind (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListQueueResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        worker=worker,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        trigger_path=trigger_path,
        trigger_kind=trigger_kind,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    worker: str | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    trigger_path: str | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> list[ListQueueResponse200Item] | None:
    """list all queued jobs

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        worker (str | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        trigger_path (str | Unset):
        trigger_kind (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListQueueResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            order_desc=order_desc,
            created_by=created_by,
            parent_job=parent_job,
            worker=worker,
            script_path_exact=script_path_exact,
            script_path_start=script_path_start,
            schedule_path=schedule_path,
            trigger_path=trigger_path,
            trigger_kind=trigger_kind,
            script_hash=script_hash,
            started_before=started_before,
            started_after=started_after,
            success=success,
            scheduled_for_before_now=scheduled_for_before_now,
            job_kinds=job_kinds,
            suspended=suspended,
            running=running,
            args=args,
            result=result,
            allow_wildcards=allow_wildcards,
            tag=tag,
            page=page,
            per_page=per_page,
            all_workspaces=all_workspaces,
            is_not_schedule=is_not_schedule,
        )
    ).parsed
