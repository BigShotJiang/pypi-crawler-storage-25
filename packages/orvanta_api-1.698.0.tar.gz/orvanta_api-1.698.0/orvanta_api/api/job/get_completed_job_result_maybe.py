from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_completed_job_result_maybe_response_200 import GetCompletedJobResultMaybeResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    get_started: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["get_started"] = get_started

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs_u/completed/get_result_maybe/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetCompletedJobResultMaybeResponse200 | None:
    if response.status_code == 200:
        response_200 = GetCompletedJobResultMaybeResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetCompletedJobResultMaybeResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    get_started: bool | Unset = UNSET,
) -> Response[GetCompletedJobResultMaybeResponse200]:
    """get completed job result if job is completed

    Args:
        workspace (str):
        id (UUID):
        get_started (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCompletedJobResultMaybeResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        get_started=get_started,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    get_started: bool | Unset = UNSET,
) -> GetCompletedJobResultMaybeResponse200 | None:
    """get completed job result if job is completed

    Args:
        workspace (str):
        id (UUID):
        get_started (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCompletedJobResultMaybeResponse200
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        client=client,
        get_started=get_started,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    get_started: bool | Unset = UNSET,
) -> Response[GetCompletedJobResultMaybeResponse200]:
    """get completed job result if job is completed

    Args:
        workspace (str):
        id (UUID):
        get_started (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCompletedJobResultMaybeResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        get_started=get_started,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    get_started: bool | Unset = UNSET,
) -> GetCompletedJobResultMaybeResponse200 | None:
    """get completed job result if job is completed

    Args:
        workspace (str):
        id (UUID):
        get_started (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCompletedJobResultMaybeResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            client=client,
            get_started=get_started,
        )
    ).parsed
