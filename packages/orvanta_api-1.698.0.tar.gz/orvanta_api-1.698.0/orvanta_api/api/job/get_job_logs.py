from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    remove_ansi_warnings: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["remove_ansi_warnings"] = remove_ansi_warnings

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs_u/get_logs/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    remove_ansi_warnings: bool | Unset = UNSET,
) -> Response[str]:
    """get job logs

    Args:
        workspace (str):
        id (UUID):
        remove_ansi_warnings (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        remove_ansi_warnings=remove_ansi_warnings,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    remove_ansi_warnings: bool | Unset = UNSET,
) -> str | None:
    """get job logs

    Args:
        workspace (str):
        id (UUID):
        remove_ansi_warnings (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        client=client,
        remove_ansi_warnings=remove_ansi_warnings,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    remove_ansi_warnings: bool | Unset = UNSET,
) -> Response[str]:
    """get job logs

    Args:
        workspace (str):
        id (UUID):
        remove_ansi_warnings (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        remove_ansi_warnings=remove_ansi_warnings,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    remove_ansi_warnings: bool | Unset = UNSET,
) -> str | None:
    """get job logs

    Args:
        workspace (str):
        id (UUID):
        remove_ansi_warnings (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            client=client,
            remove_ansi_warnings=remove_ansi_warnings,
        )
    ).parsed
