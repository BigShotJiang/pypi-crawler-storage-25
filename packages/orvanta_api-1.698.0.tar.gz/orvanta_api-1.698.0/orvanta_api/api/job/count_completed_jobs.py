from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    completed_after_s_ago: int | Unset = UNSET,
    success: bool | Unset = UNSET,
    tags: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["completed_after_s_ago"] = completed_after_s_ago

    params["success"] = success

    params["tags"] = tags

    params["all_workspaces"] = all_workspaces

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/completed/count_jobs".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> int | None:
    if response.status_code == 200:
        response_200 = cast(int, response.json())
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[int]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    completed_after_s_ago: int | Unset = UNSET,
    success: bool | Unset = UNSET,
    tags: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> Response[int]:
    """count number of completed jobs with filter

    Args:
        workspace (str):
        completed_after_s_ago (int | Unset):
        success (bool | Unset):
        tags (str | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[int]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        completed_after_s_ago=completed_after_s_ago,
        success=success,
        tags=tags,
        all_workspaces=all_workspaces,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    completed_after_s_ago: int | Unset = UNSET,
    success: bool | Unset = UNSET,
    tags: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> int | None:
    """count number of completed jobs with filter

    Args:
        workspace (str):
        completed_after_s_ago (int | Unset):
        success (bool | Unset):
        tags (str | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        int
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        completed_after_s_ago=completed_after_s_ago,
        success=success,
        tags=tags,
        all_workspaces=all_workspaces,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    completed_after_s_ago: int | Unset = UNSET,
    success: bool | Unset = UNSET,
    tags: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> Response[int]:
    """count number of completed jobs with filter

    Args:
        workspace (str):
        completed_after_s_ago (int | Unset):
        success (bool | Unset):
        tags (str | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[int]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        completed_after_s_ago=completed_after_s_ago,
        success=success,
        tags=tags,
        all_workspaces=all_workspaces,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    completed_after_s_ago: int | Unset = UNSET,
    success: bool | Unset = UNSET,
    tags: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
) -> int | None:
    """count number of completed jobs with filter

    Args:
        workspace (str):
        completed_after_s_ago (int | Unset):
        success (bool | Unset):
        tags (str | Unset):
        all_workspaces (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        int
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            completed_after_s_ago=completed_after_s_ago,
            success=success,
            tags=tags,
            all_workspaces=all_workspaces,
        )
    ).parsed
