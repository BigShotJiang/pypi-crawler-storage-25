from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.run_raw_script_dependencies_body import RunRawScriptDependenciesBody
from ...models.run_raw_script_dependencies_response_201 import RunRawScriptDependenciesResponse201
from ...types import Response


def _get_kwargs(
    workspace: str,
    *,
    body: RunRawScriptDependenciesBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/run/dependencies".format(
            workspace=quote(str(workspace), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RunRawScriptDependenciesResponse201 | None:
    if response.status_code == 201:
        response_201 = RunRawScriptDependenciesResponse201.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RunRawScriptDependenciesResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunRawScriptDependenciesBody,
) -> Response[RunRawScriptDependenciesResponse201]:
    """run a one-off dependencies job

    Args:
        workspace (str):
        body (RunRawScriptDependenciesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RunRawScriptDependenciesResponse201]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunRawScriptDependenciesBody,
) -> RunRawScriptDependenciesResponse201 | None:
    """run a one-off dependencies job

    Args:
        workspace (str):
        body (RunRawScriptDependenciesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RunRawScriptDependenciesResponse201
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunRawScriptDependenciesBody,
) -> Response[RunRawScriptDependenciesResponse201]:
    """run a one-off dependencies job

    Args:
        workspace (str):
        body (RunRawScriptDependenciesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RunRawScriptDependenciesResponse201]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunRawScriptDependenciesBody,
) -> RunRawScriptDependenciesResponse201 | None:
    """run a one-off dependencies job

    Args:
        workspace (str):
        body (RunRawScriptDependenciesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RunRawScriptDependenciesResponse201
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
        )
    ).parsed
