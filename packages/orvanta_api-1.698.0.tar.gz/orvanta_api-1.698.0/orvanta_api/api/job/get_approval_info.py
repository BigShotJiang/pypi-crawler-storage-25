from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_approval_info_response_200 import GetApprovalInfoResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    job_id: UUID,
    *,
    token: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["token"] = token

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs_u/flow/approval_info/{job_id}".format(
            workspace=quote(str(workspace), safe=""),
            job_id=quote(str(job_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetApprovalInfoResponse200 | None:
    if response.status_code == 200:
        response_200 = GetApprovalInfoResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetApprovalInfoResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    token: str | Unset = UNSET,
) -> Response[GetApprovalInfoResponse200]:
    """get approval info for a suspended flow/WAC job

     Get approval info for a suspended flow/WAC job. Returns form schema, approval rules, and whether the
    current user can approve. Either a valid token query parameter or an authenticated session is
    required.

    Args:
        workspace (str):
        job_id (UUID):
        token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApprovalInfoResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        token=token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    token: str | Unset = UNSET,
) -> GetApprovalInfoResponse200 | None:
    """get approval info for a suspended flow/WAC job

     Get approval info for a suspended flow/WAC job. Returns form schema, approval rules, and whether the
    current user can approve. Either a valid token query parameter or an authenticated session is
    required.

    Args:
        workspace (str):
        job_id (UUID):
        token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApprovalInfoResponse200
    """

    return sync_detailed(
        workspace=workspace,
        job_id=job_id,
        client=client,
        token=token,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    token: str | Unset = UNSET,
) -> Response[GetApprovalInfoResponse200]:
    """get approval info for a suspended flow/WAC job

     Get approval info for a suspended flow/WAC job. Returns form schema, approval rules, and whether the
    current user can approve. Either a valid token query parameter or an authenticated session is
    required.

    Args:
        workspace (str):
        job_id (UUID):
        token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApprovalInfoResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        token=token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    token: str | Unset = UNSET,
) -> GetApprovalInfoResponse200 | None:
    """get approval info for a suspended flow/WAC job

     Get approval info for a suspended flow/WAC job. Returns form schema, approval rules, and whether the
    current user can approve. Either a valid token query parameter or an authenticated session is
    required.

    Args:
        workspace (str):
        job_id (UUID):
        token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApprovalInfoResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            job_id=job_id,
            client=client,
            token=token,
        )
    ).parsed
