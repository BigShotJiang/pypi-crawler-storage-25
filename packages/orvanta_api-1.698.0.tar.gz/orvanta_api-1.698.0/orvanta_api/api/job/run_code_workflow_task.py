from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.run_code_workflow_task_body import RunCodeWorkflowTaskBody
from ...types import Response


def _get_kwargs(
    workspace: str,
    job_id: str,
    entrypoint: str,
    *,
    body: RunCodeWorkflowTaskBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/workflow_as_code/{job_id}/{entrypoint}".format(
            workspace=quote(str(workspace), safe=""),
            job_id=quote(str(job_id), safe=""),
            entrypoint=quote(str(entrypoint), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UUID | None:
    if response.status_code == 201:
        response_201 = UUID(response.text)

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    job_id: str,
    entrypoint: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunCodeWorkflowTaskBody,
) -> Response[UUID]:
    """run code-workflow task

    Args:
        workspace (str):
        job_id (str):
        entrypoint (str):
        body (RunCodeWorkflowTaskBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        entrypoint=entrypoint,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    job_id: str,
    entrypoint: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunCodeWorkflowTaskBody,
) -> UUID | None:
    """run code-workflow task

    Args:
        workspace (str):
        job_id (str):
        entrypoint (str):
        body (RunCodeWorkflowTaskBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return sync_detailed(
        workspace=workspace,
        job_id=job_id,
        entrypoint=entrypoint,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    job_id: str,
    entrypoint: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunCodeWorkflowTaskBody,
) -> Response[UUID]:
    """run code-workflow task

    Args:
        workspace (str):
        job_id (str):
        entrypoint (str):
        body (RunCodeWorkflowTaskBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        entrypoint=entrypoint,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    job_id: str,
    entrypoint: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunCodeWorkflowTaskBody,
) -> UUID | None:
    """run code-workflow task

    Args:
        workspace (str):
        job_id (str):
        entrypoint (str):
        body (RunCodeWorkflowTaskBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            job_id=job_id,
            entrypoint=entrypoint,
            client=client,
            body=body,
        )
    ).parsed
