import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.run_flow_by_version_body import RunFlowByVersionBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    version: int,
    *,
    body: RunFlowByVersionBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_scheduled_for: str | Unset = UNSET
    if not isinstance(scheduled_for, Unset):
        json_scheduled_for = scheduled_for.isoformat()
    params["scheduled_for"] = json_scheduled_for

    params["scheduled_in_secs"] = scheduled_in_secs

    params["skip_preprocessor"] = skip_preprocessor

    json_parent_job: str | Unset = UNSET
    if not isinstance(parent_job, Unset):
        json_parent_job = str(parent_job)
    params["parent_job"] = json_parent_job

    params["tag"] = tag

    json_job_id: str | Unset = UNSET
    if not isinstance(job_id, Unset):
        json_job_id = str(job_id)
    params["job_id"] = json_job_id

    params["include_header"] = include_header

    params["invisible_to_owner"] = invisible_to_owner

    json_memory_id: str | Unset = UNSET
    if not isinstance(memory_id, Unset):
        json_memory_id = str(memory_id)
    params["memory_id"] = json_memory_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/run/fv/{version}".format(
            workspace=quote(str(workspace), safe=""),
            version=quote(str(version), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UUID | None:
    if response.status_code == 201:
        response_201 = UUID(response.text)

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    body: RunFlowByVersionBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> Response[UUID]:
    """run flow by version

    Args:
        workspace (str):
        version (int):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        skip_preprocessor (bool | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        memory_id (UUID | Unset):
        body (RunFlowByVersionBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        version=version,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        skip_preprocessor=skip_preprocessor,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        memory_id=memory_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    body: RunFlowByVersionBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> UUID | None:
    """run flow by version

    Args:
        workspace (str):
        version (int):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        skip_preprocessor (bool | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        memory_id (UUID | Unset):
        body (RunFlowByVersionBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return sync_detailed(
        workspace=workspace,
        version=version,
        client=client,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        skip_preprocessor=skip_preprocessor,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        memory_id=memory_id,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    body: RunFlowByVersionBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> Response[UUID]:
    """run flow by version

    Args:
        workspace (str):
        version (int):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        skip_preprocessor (bool | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        memory_id (UUID | Unset):
        body (RunFlowByVersionBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        version=version,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        skip_preprocessor=skip_preprocessor,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        memory_id=memory_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    body: RunFlowByVersionBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> UUID | None:
    """run flow by version

    Args:
        workspace (str):
        version (int):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        skip_preprocessor (bool | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        memory_id (UUID | Unset):
        body (RunFlowByVersionBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            version=version,
            client=client,
            body=body,
            scheduled_for=scheduled_for,
            scheduled_in_secs=scheduled_in_secs,
            skip_preprocessor=skip_preprocessor,
            parent_job=parent_job,
            tag=tag,
            job_id=job_id,
            include_header=include_header,
            invisible_to_owner=invisible_to_owner,
            memory_id=memory_id,
        )
    ).parsed
