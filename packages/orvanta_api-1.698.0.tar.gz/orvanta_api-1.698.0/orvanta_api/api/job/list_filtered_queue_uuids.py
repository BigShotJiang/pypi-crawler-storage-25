import datetime
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    concurrency_key: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["order_desc"] = order_desc

    params["created_by"] = created_by

    json_parent_job: str | Unset = UNSET
    if not isinstance(parent_job, Unset):
        json_parent_job = str(parent_job)
    params["parent_job"] = json_parent_job

    params["script_path_exact"] = script_path_exact

    params["script_path_start"] = script_path_start

    params["schedule_path"] = schedule_path

    params["script_hash"] = script_hash

    json_started_before: str | Unset = UNSET
    if not isinstance(started_before, Unset):
        json_started_before = started_before.isoformat()
    params["started_before"] = json_started_before

    json_started_after: str | Unset = UNSET
    if not isinstance(started_after, Unset):
        json_started_after = started_after.isoformat()
    params["started_after"] = json_started_after

    params["success"] = success

    params["scheduled_for_before_now"] = scheduled_for_before_now

    params["job_kinds"] = job_kinds

    params["suspended"] = suspended

    params["running"] = running

    params["args"] = args

    params["result"] = result

    params["allow_wildcards"] = allow_wildcards

    params["tag"] = tag

    params["page"] = page

    params["per_page"] = per_page

    params["concurrency_key"] = concurrency_key

    params["all_workspaces"] = all_workspaces

    params["is_not_schedule"] = is_not_schedule

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/queue/list_filtered_uuids".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    concurrency_key: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> Response[list[str]]:
    """get the ids of all queued jobs matching the given filters

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        concurrency_key (str | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        concurrency_key=concurrency_key,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    concurrency_key: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> list[str] | None:
    """get the ids of all queued jobs matching the given filters

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        concurrency_key (str | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        concurrency_key=concurrency_key,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    concurrency_key: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> Response[list[str]]:
    """get the ids of all queued jobs matching the given filters

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        concurrency_key (str | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[str]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        order_desc=order_desc,
        created_by=created_by,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        success=success,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        running=running,
        args=args,
        result=result,
        allow_wildcards=allow_wildcards,
        tag=tag,
        page=page,
        per_page=per_page,
        concurrency_key=concurrency_key,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    success: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    running: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    tag: str | Unset = UNSET,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    concurrency_key: str | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
) -> list[str] | None:
    """get the ids of all queued jobs matching the given filters

    Args:
        workspace (str):
        order_desc (bool | Unset):
        created_by (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        success (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        running (bool | Unset):
        args (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        tag (str | Unset):
        page (int | Unset):
        per_page (int | Unset):
        concurrency_key (str | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[str]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            order_desc=order_desc,
            created_by=created_by,
            parent_job=parent_job,
            script_path_exact=script_path_exact,
            script_path_start=script_path_start,
            schedule_path=schedule_path,
            script_hash=script_hash,
            started_before=started_before,
            started_after=started_after,
            success=success,
            scheduled_for_before_now=scheduled_for_before_now,
            job_kinds=job_kinds,
            suspended=suspended,
            running=running,
            args=args,
            result=result,
            allow_wildcards=allow_wildcards,
            tag=tag,
            page=page,
            per_page=per_page,
            concurrency_key=concurrency_key,
            all_workspaces=all_workspaces,
            is_not_schedule=is_not_schedule,
        )
    ).parsed
