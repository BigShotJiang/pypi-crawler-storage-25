import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.restart_flow_at_step_body import RestartFlowAtStepBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    body: RestartFlowAtStepBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_scheduled_for: str | Unset = UNSET
    if not isinstance(scheduled_for, Unset):
        json_scheduled_for = scheduled_for.isoformat()
    params["scheduled_for"] = json_scheduled_for

    params["scheduled_in_secs"] = scheduled_in_secs

    json_parent_job: str | Unset = UNSET
    if not isinstance(parent_job, Unset):
        json_parent_job = str(parent_job)
    params["parent_job"] = json_parent_job

    params["tag"] = tag

    json_job_id: str | Unset = UNSET
    if not isinstance(job_id, Unset):
        json_job_id = str(job_id)
    params["job_id"] = json_job_id

    params["include_header"] = include_header

    params["invisible_to_owner"] = invisible_to_owner

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/restart/f/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UUID | None:
    if response.status_code == 201:
        response_201 = UUID(response.text)

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RestartFlowAtStepBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
) -> Response[UUID]:
    """restart a completed flow at a given step

    Args:
        workspace (str):
        id (UUID):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        body (RestartFlowAtStepBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RestartFlowAtStepBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
) -> UUID | None:
    """restart a completed flow at a given step

    Args:
        workspace (str):
        id (UUID):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        body (RestartFlowAtStepBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        client=client,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RestartFlowAtStepBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
) -> Response[UUID]:
    """restart a completed flow at a given step

    Args:
        workspace (str):
        id (UUID):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        body (RestartFlowAtStepBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        body=body,
        scheduled_for=scheduled_for,
        scheduled_in_secs=scheduled_in_secs,
        parent_job=parent_job,
        tag=tag,
        job_id=job_id,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: RestartFlowAtStepBody,
    scheduled_for: datetime.datetime | Unset = UNSET,
    scheduled_in_secs: int | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    tag: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
) -> UUID | None:
    """restart a completed flow at a given step

    Args:
        workspace (str):
        id (UUID):
        scheduled_for (datetime.datetime | Unset):
        scheduled_in_secs (int | Unset):
        parent_job (UUID | Unset):
        tag (str | Unset):
        job_id (UUID | Unset):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        body (RestartFlowAtStepBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            client=client,
            body=body,
            scheduled_for=scheduled_for,
            scheduled_in_secs=scheduled_in_secs,
            parent_job=parent_job,
            tag=tag,
            job_id=job_id,
            include_header=include_header,
            invisible_to_owner=invisible_to_owner,
        )
    ).parsed
