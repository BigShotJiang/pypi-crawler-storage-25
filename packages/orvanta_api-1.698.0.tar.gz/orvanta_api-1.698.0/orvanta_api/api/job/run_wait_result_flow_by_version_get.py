from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    version: int,
    *,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    payload: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["include_header"] = include_header

    params["queue_limit"] = queue_limit

    params["payload"] = payload

    json_job_id: str | Unset = UNSET
    if not isinstance(job_id, Unset):
        json_job_id = str(job_id)
    params["job_id"] = json_job_id

    params["skip_preprocessor"] = skip_preprocessor

    json_memory_id: str | Unset = UNSET
    if not isinstance(memory_id, Unset):
        json_memory_id = str(memory_id)
    params["memory_id"] = json_memory_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/run_wait_result/fv/{version}".format(
            workspace=quote(str(workspace), safe=""),
            version=quote(str(version), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    payload: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> Response[Any]:
    """run flow by version with GET and wait until completion

    Args:
        workspace (str):
        version (int):
        include_header (str | Unset):
        queue_limit (str | Unset):
        payload (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        version=version,
        include_header=include_header,
        queue_limit=queue_limit,
        payload=payload,
        job_id=job_id,
        skip_preprocessor=skip_preprocessor,
        memory_id=memory_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    workspace: str,
    version: int,
    *,
    client: AuthenticatedClient | Client,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    payload: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
) -> Response[Any]:
    """run flow by version with GET and wait until completion

    Args:
        workspace (str):
        version (int):
        include_header (str | Unset):
        queue_limit (str | Unset):
        payload (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        version=version,
        include_header=include_header,
        queue_limit=queue_limit,
        payload=payload,
        job_id=job_id,
        skip_preprocessor=skip_preprocessor,
        memory_id=memory_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
