from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_job_response_200_type_0 import GetJobResponse200Type0
from ...models.get_job_response_200_type_1 import GetJobResponse200Type1
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    no_logs: bool | Unset = UNSET,
    no_code: bool | Unset = UNSET,
    approval_token: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["no_logs"] = no_logs

    params["no_code"] = no_code

    params["approval_token"] = approval_token

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs_u/get/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetJobResponse200Type0 | GetJobResponse200Type1 | None:
    if response.status_code == 200:

        def _parse_response_200(data: object) -> GetJobResponse200Type0 | GetJobResponse200Type1:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = GetJobResponse200Type0.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_1 = GetJobResponse200Type1.from_dict(data)

            return response_200_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetJobResponse200Type0 | GetJobResponse200Type1]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    no_logs: bool | Unset = UNSET,
    no_code: bool | Unset = UNSET,
    approval_token: str | Unset = UNSET,
) -> Response[GetJobResponse200Type0 | GetJobResponse200Type1]:
    """get job

    Args:
        workspace (str):
        id (UUID):
        no_logs (bool | Unset):
        no_code (bool | Unset):
        approval_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobResponse200Type0 | GetJobResponse200Type1]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        no_logs=no_logs,
        no_code=no_code,
        approval_token=approval_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    no_logs: bool | Unset = UNSET,
    no_code: bool | Unset = UNSET,
    approval_token: str | Unset = UNSET,
) -> GetJobResponse200Type0 | GetJobResponse200Type1 | None:
    """get job

    Args:
        workspace (str):
        id (UUID):
        no_logs (bool | Unset):
        no_code (bool | Unset):
        approval_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobResponse200Type0 | GetJobResponse200Type1
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        client=client,
        no_logs=no_logs,
        no_code=no_code,
        approval_token=approval_token,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    no_logs: bool | Unset = UNSET,
    no_code: bool | Unset = UNSET,
    approval_token: str | Unset = UNSET,
) -> Response[GetJobResponse200Type0 | GetJobResponse200Type1]:
    """get job

    Args:
        workspace (str):
        id (UUID):
        no_logs (bool | Unset):
        no_code (bool | Unset):
        approval_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobResponse200Type0 | GetJobResponse200Type1]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        no_logs=no_logs,
        no_code=no_code,
        approval_token=approval_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    no_logs: bool | Unset = UNSET,
    no_code: bool | Unset = UNSET,
    approval_token: str | Unset = UNSET,
) -> GetJobResponse200Type0 | GetJobResponse200Type1 | None:
    """get job

    Args:
        workspace (str):
        id (UUID):
        no_logs (bool | Unset):
        no_code (bool | Unset):
        approval_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobResponse200Type0 | GetJobResponse200Type1
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            client=client,
            no_logs=no_logs,
            no_code=no_code,
            approval_token=approval_token,
        )
    ).parsed
