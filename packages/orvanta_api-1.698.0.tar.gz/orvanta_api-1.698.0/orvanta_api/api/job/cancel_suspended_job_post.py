from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cancel_suspended_job_post_body import CancelSuspendedJobPostBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    resume_id: int,
    signature: str,
    *,
    body: CancelSuspendedJobPostBody,
    approver: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["approver"] = approver

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs_u/cancel/{id}/{resume_id}/{signature}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
            resume_id=quote(str(resume_id), safe=""),
            signature=quote(str(signature), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 201:
        response_201 = response.text
        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    resume_id: int,
    signature: str,
    *,
    client: AuthenticatedClient | Client,
    body: CancelSuspendedJobPostBody,
    approver: str | Unset = UNSET,
) -> Response[str]:
    """cancel a job for a suspended flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        signature (str):
        approver (str | Unset):
        body (CancelSuspendedJobPostBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        signature=signature,
        body=body,
        approver=approver,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    id: UUID,
    resume_id: int,
    signature: str,
    *,
    client: AuthenticatedClient | Client,
    body: CancelSuspendedJobPostBody,
    approver: str | Unset = UNSET,
) -> str | None:
    """cancel a job for a suspended flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        signature (str):
        approver (str | Unset):
        body (CancelSuspendedJobPostBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        signature=signature,
        client=client,
        body=body,
        approver=approver,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    resume_id: int,
    signature: str,
    *,
    client: AuthenticatedClient | Client,
    body: CancelSuspendedJobPostBody,
    approver: str | Unset = UNSET,
) -> Response[str]:
    """cancel a job for a suspended flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        signature (str):
        approver (str | Unset):
        body (CancelSuspendedJobPostBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        resume_id=resume_id,
        signature=signature,
        body=body,
        approver=approver,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    id: UUID,
    resume_id: int,
    signature: str,
    *,
    client: AuthenticatedClient | Client,
    body: CancelSuspendedJobPostBody,
    approver: str | Unset = UNSET,
) -> str | None:
    """cancel a job for a suspended flow

    Args:
        workspace (str):
        id (UUID):
        resume_id (int):
        signature (str):
        approver (str | Unset):
        body (CancelSuspendedJobPostBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            id=id,
            resume_id=resume_id,
            signature=signature,
            client=client,
            body=body,
            approver=approver,
        )
    ).parsed
