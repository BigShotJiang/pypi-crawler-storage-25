from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.resume_suspended_body import ResumeSuspendedBody
from ...types import Response


def _get_kwargs(
    workspace: str,
    job_id: UUID,
    *,
    body: ResumeSuspendedBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs_u/flow/resume_suspended/{job_id}".format(
            workspace=quote(str(workspace), safe=""),
            job_id=quote(str(job_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 201:
        response_201 = response.text
        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ResumeSuspendedBody,
) -> Response[str]:
    """resume or cancel a suspended flow/WAC job

     Resume or cancel a suspended flow/WAC job. Uses approval rules to determine authorization. Either a
    valid approval_token or an authenticated session is required.

    Args:
        workspace (str):
        job_id (UUID):
        body (ResumeSuspendedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ResumeSuspendedBody,
) -> str | None:
    """resume or cancel a suspended flow/WAC job

     Resume or cancel a suspended flow/WAC job. Uses approval rules to determine authorization. Either a
    valid approval_token or an authenticated session is required.

    Args:
        workspace (str):
        job_id (UUID):
        body (ResumeSuspendedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        job_id=job_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ResumeSuspendedBody,
) -> Response[str]:
    """resume or cancel a suspended flow/WAC job

     Resume or cancel a suspended flow/WAC job. Uses approval rules to determine authorization. Either a
    valid approval_token or an authenticated session is required.

    Args:
        workspace (str):
        job_id (UUID):
        body (ResumeSuspendedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        job_id=job_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    job_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ResumeSuspendedBody,
) -> str | None:
    """resume or cancel a suspended flow/WAC job

     Resume or cancel a suspended flow/WAC job. Uses approval rules to determine authorization. Either a
    valid approval_token or an authenticated session is required.

    Args:
        workspace (str):
        job_id (UUID):
        body (ResumeSuspendedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            job_id=job_id,
            client=client,
            body=body,
        )
    ).parsed
