from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.run_script_preview_body import RunScriptPreviewBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    body: RunScriptPreviewBody,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["include_header"] = include_header

    params["invisible_to_owner"] = invisible_to_owner

    json_job_id: str | Unset = UNSET
    if not isinstance(job_id, Unset):
        json_job_id = str(job_id)
    params["job_id"] = json_job_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/run/preview".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UUID | None:
    if response.status_code == 201:
        response_201 = UUID(response.text)

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunScriptPreviewBody,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
) -> Response[UUID]:
    """run script preview

    Args:
        workspace (str):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        job_id (UUID | Unset):
        body (RunScriptPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        job_id=job_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunScriptPreviewBody,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
) -> UUID | None:
    """run script preview

    Args:
        workspace (str):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        job_id (UUID | Unset):
        body (RunScriptPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        body=body,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        job_id=job_id,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunScriptPreviewBody,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
) -> Response[UUID]:
    """run script preview

    Args:
        workspace (str):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        job_id (UUID | Unset):
        body (RunScriptPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UUID]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        body=body,
        include_header=include_header,
        invisible_to_owner=invisible_to_owner,
        job_id=job_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunScriptPreviewBody,
    include_header: str | Unset = UNSET,
    invisible_to_owner: bool | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
) -> UUID | None:
    """run script preview

    Args:
        workspace (str):
        include_header (str | Unset):
        invisible_to_owner (bool | Unset):
        job_id (UUID | Unset):
        body (RunScriptPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UUID
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            body=body,
            include_header=include_header,
            invisible_to_owner=invisible_to_owner,
            job_id=job_id,
        )
    ).parsed
