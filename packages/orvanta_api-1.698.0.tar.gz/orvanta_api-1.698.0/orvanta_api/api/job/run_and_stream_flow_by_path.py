from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.run_and_stream_flow_by_path_body import RunAndStreamFlowByPathBody
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    path: str,
    *,
    body: RunAndStreamFlowByPathBody,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
    poll_delay_ms: int | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["include_header"] = include_header

    params["queue_limit"] = queue_limit

    json_job_id: str | Unset = UNSET
    if not isinstance(job_id, Unset):
        json_job_id = str(job_id)
    params["job_id"] = json_job_id

    params["skip_preprocessor"] = skip_preprocessor

    json_memory_id: str | Unset = UNSET
    if not isinstance(memory_id, Unset):
        json_memory_id = str(memory_id)
    params["memory_id"] = json_memory_id

    params["poll_delay_ms"] = poll_delay_ms

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/jobs/run_and_stream/f/{path}".format(
            workspace=quote(str(workspace), safe=""),
            path=quote(str(path), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunAndStreamFlowByPathBody,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
    poll_delay_ms: int | Unset = UNSET,
) -> Response[str]:
    """run flow by path and stream updates via SSE

    Args:
        workspace (str):
        path (str):
        include_header (str | Unset):
        queue_limit (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):
        poll_delay_ms (int | Unset):
        body (RunAndStreamFlowByPathBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
        include_header=include_header,
        queue_limit=queue_limit,
        job_id=job_id,
        skip_preprocessor=skip_preprocessor,
        memory_id=memory_id,
        poll_delay_ms=poll_delay_ms,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunAndStreamFlowByPathBody,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
    poll_delay_ms: int | Unset = UNSET,
) -> str | None:
    """run flow by path and stream updates via SSE

    Args:
        workspace (str):
        path (str):
        include_header (str | Unset):
        queue_limit (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):
        poll_delay_ms (int | Unset):
        body (RunAndStreamFlowByPathBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        path=path,
        client=client,
        body=body,
        include_header=include_header,
        queue_limit=queue_limit,
        job_id=job_id,
        skip_preprocessor=skip_preprocessor,
        memory_id=memory_id,
        poll_delay_ms=poll_delay_ms,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunAndStreamFlowByPathBody,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
    poll_delay_ms: int | Unset = UNSET,
) -> Response[str]:
    """run flow by path and stream updates via SSE

    Args:
        workspace (str):
        path (str):
        include_header (str | Unset):
        queue_limit (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):
        poll_delay_ms (int | Unset):
        body (RunAndStreamFlowByPathBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        path=path,
        body=body,
        include_header=include_header,
        queue_limit=queue_limit,
        job_id=job_id,
        skip_preprocessor=skip_preprocessor,
        memory_id=memory_id,
        poll_delay_ms=poll_delay_ms,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: RunAndStreamFlowByPathBody,
    include_header: str | Unset = UNSET,
    queue_limit: str | Unset = UNSET,
    job_id: UUID | Unset = UNSET,
    skip_preprocessor: bool | Unset = UNSET,
    memory_id: UUID | Unset = UNSET,
    poll_delay_ms: int | Unset = UNSET,
) -> str | None:
    """run flow by path and stream updates via SSE

    Args:
        workspace (str):
        path (str):
        include_header (str | Unset):
        queue_limit (str | Unset):
        job_id (UUID | Unset):
        skip_preprocessor (bool | Unset):
        memory_id (UUID | Unset):
        poll_delay_ms (int | Unset):
        body (RunAndStreamFlowByPathBody): The arguments to pass to the script or flow

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            path=path,
            client=client,
            body=body,
            include_header=include_header,
            queue_limit=queue_limit,
            job_id=job_id,
            skip_preprocessor=skip_preprocessor,
            memory_id=memory_id,
            poll_delay_ms=poll_delay_ms,
        )
    ).parsed
