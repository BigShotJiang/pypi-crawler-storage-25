from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    id: UUID,
    *,
    approver: str | Unset = UNSET,
    message: str | Unset = UNSET,
    team_name: str,
    channel_name: str,
    flow_step_id: str,
    default_args_json: str | Unset = UNSET,
    dynamic_enums_json: str | Unset = UNSET,
    resume_button_text: str | Unset = UNSET,
    cancel_button_text: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["approver"] = approver

    params["message"] = message

    params["team_name"] = team_name

    params["channel_name"] = channel_name

    params["flow_step_id"] = flow_step_id

    params["default_args_json"] = default_args_json

    params["dynamic_enums_json"] = dynamic_enums_json

    params["resume_button_text"] = resume_button_text

    params["cancel_button_text"] = cancel_button_text

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/teams_approval/{id}".format(
            workspace=quote(str(workspace), safe=""),
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    message: str | Unset = UNSET,
    team_name: str,
    channel_name: str,
    flow_step_id: str,
    default_args_json: str | Unset = UNSET,
    dynamic_enums_json: str | Unset = UNSET,
    resume_button_text: str | Unset = UNSET,
    cancel_button_text: str | Unset = UNSET,
) -> Response[Any]:
    """generate interactive teams approval for suspended job

    Args:
        workspace (str):
        id (UUID):
        approver (str | Unset):
        message (str | Unset):
        team_name (str):
        channel_name (str):
        flow_step_id (str):
        default_args_json (str | Unset):
        dynamic_enums_json (str | Unset):
        resume_button_text (str | Unset):
        cancel_button_text (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        approver=approver,
        message=message,
        team_name=team_name,
        channel_name=channel_name,
        flow_step_id=flow_step_id,
        default_args_json=default_args_json,
        dynamic_enums_json=dynamic_enums_json,
        resume_button_text=resume_button_text,
        cancel_button_text=cancel_button_text,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    workspace: str,
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    approver: str | Unset = UNSET,
    message: str | Unset = UNSET,
    team_name: str,
    channel_name: str,
    flow_step_id: str,
    default_args_json: str | Unset = UNSET,
    dynamic_enums_json: str | Unset = UNSET,
    resume_button_text: str | Unset = UNSET,
    cancel_button_text: str | Unset = UNSET,
) -> Response[Any]:
    """generate interactive teams approval for suspended job

    Args:
        workspace (str):
        id (UUID):
        approver (str | Unset):
        message (str | Unset):
        team_name (str):
        channel_name (str):
        flow_step_id (str):
        default_args_json (str | Unset):
        dynamic_enums_json (str | Unset):
        resume_button_text (str | Unset):
        cancel_button_text (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        id=id,
        approver=approver,
        message=message,
        team_name=team_name,
        channel_name=channel_name,
        flow_step_id=flow_step_id,
        default_args_json=default_args_json,
        dynamic_enums_json=dynamic_enums_json,
        resume_button_text=resume_button_text,
        cancel_button_text=cancel_button_text,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
