import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_jobs_response_200_item_type_0 import ListJobsResponse200ItemType0
from ...models.list_jobs_response_200_item_type_1 import ListJobsResponse200ItemType1
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    created_by: str | Unset = UNSET,
    label: str | Unset = UNSET,
    worker: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    created_before: datetime.datetime | Unset = UNSET,
    created_after: datetime.datetime | Unset = UNSET,
    completed_before: datetime.datetime | Unset = UNSET,
    completed_after: datetime.datetime | Unset = UNSET,
    created_before_queue: datetime.datetime | Unset = UNSET,
    created_after_queue: datetime.datetime | Unset = UNSET,
    running: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    tag: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    per_page: int | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    is_skipped: bool | Unset = UNSET,
    is_flow_step: bool | Unset = UNSET,
    has_null_parent: bool | Unset = UNSET,
    success: bool | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["created_by"] = created_by

    params["label"] = label

    params["worker"] = worker

    json_parent_job: str | Unset = UNSET
    if not isinstance(parent_job, Unset):
        json_parent_job = str(parent_job)
    params["parent_job"] = json_parent_job

    params["script_path_exact"] = script_path_exact

    params["script_path_start"] = script_path_start

    params["schedule_path"] = schedule_path

    params["script_hash"] = script_hash

    json_started_before: str | Unset = UNSET
    if not isinstance(started_before, Unset):
        json_started_before = started_before.isoformat()
    params["started_before"] = json_started_before

    json_started_after: str | Unset = UNSET
    if not isinstance(started_after, Unset):
        json_started_after = started_after.isoformat()
    params["started_after"] = json_started_after

    json_created_before: str | Unset = UNSET
    if not isinstance(created_before, Unset):
        json_created_before = created_before.isoformat()
    params["created_before"] = json_created_before

    json_created_after: str | Unset = UNSET
    if not isinstance(created_after, Unset):
        json_created_after = created_after.isoformat()
    params["created_after"] = json_created_after

    json_completed_before: str | Unset = UNSET
    if not isinstance(completed_before, Unset):
        json_completed_before = completed_before.isoformat()
    params["completed_before"] = json_completed_before

    json_completed_after: str | Unset = UNSET
    if not isinstance(completed_after, Unset):
        json_completed_after = completed_after.isoformat()
    params["completed_after"] = json_completed_after

    json_created_before_queue: str | Unset = UNSET
    if not isinstance(created_before_queue, Unset):
        json_created_before_queue = created_before_queue.isoformat()
    params["created_before_queue"] = json_created_before_queue

    json_created_after_queue: str | Unset = UNSET
    if not isinstance(created_after_queue, Unset):
        json_created_after_queue = created_after_queue.isoformat()
    params["created_after_queue"] = json_created_after_queue

    params["running"] = running

    params["scheduled_for_before_now"] = scheduled_for_before_now

    params["job_kinds"] = job_kinds

    params["suspended"] = suspended

    params["args"] = args

    params["tag"] = tag

    params["result"] = result

    params["allow_wildcards"] = allow_wildcards

    params["per_page"] = per_page

    params["trigger_kind"] = trigger_kind

    params["is_skipped"] = is_skipped

    params["is_flow_step"] = is_flow_step

    params["has_null_parent"] = has_null_parent

    params["success"] = success

    params["all_workspaces"] = all_workspaces

    params["is_not_schedule"] = is_not_schedule

    params["broad_filter"] = broad_filter

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/jobs/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:

            def _parse_response_200_item(data: object) -> ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    response_200_item_type_0 = ListJobsResponse200ItemType0.from_dict(data)

                    return response_200_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_item_type_1 = ListJobsResponse200ItemType1.from_dict(data)

                return response_200_item_type_1

            response_200_item = _parse_response_200_item(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    created_by: str | Unset = UNSET,
    label: str | Unset = UNSET,
    worker: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    created_before: datetime.datetime | Unset = UNSET,
    created_after: datetime.datetime | Unset = UNSET,
    completed_before: datetime.datetime | Unset = UNSET,
    completed_after: datetime.datetime | Unset = UNSET,
    created_before_queue: datetime.datetime | Unset = UNSET,
    created_after_queue: datetime.datetime | Unset = UNSET,
    running: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    tag: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    per_page: int | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    is_skipped: bool | Unset = UNSET,
    is_flow_step: bool | Unset = UNSET,
    has_null_parent: bool | Unset = UNSET,
    success: bool | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> Response[list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]]:
    """list all jobs

    Args:
        workspace (str):
        created_by (str | Unset):
        label (str | Unset):
        worker (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        created_before (datetime.datetime | Unset):
        created_after (datetime.datetime | Unset):
        completed_before (datetime.datetime | Unset):
        completed_after (datetime.datetime | Unset):
        created_before_queue (datetime.datetime | Unset):
        created_after_queue (datetime.datetime | Unset):
        running (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        args (str | Unset):
        tag (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        per_page (int | Unset):
        trigger_kind (str | Unset):
        is_skipped (bool | Unset):
        is_flow_step (bool | Unset):
        has_null_parent (bool | Unset):
        success (bool | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        created_by=created_by,
        label=label,
        worker=worker,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        created_before=created_before,
        created_after=created_after,
        completed_before=completed_before,
        completed_after=completed_after,
        created_before_queue=created_before_queue,
        created_after_queue=created_after_queue,
        running=running,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        args=args,
        tag=tag,
        result=result,
        allow_wildcards=allow_wildcards,
        per_page=per_page,
        trigger_kind=trigger_kind,
        is_skipped=is_skipped,
        is_flow_step=is_flow_step,
        has_null_parent=has_null_parent,
        success=success,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
        broad_filter=broad_filter,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    created_by: str | Unset = UNSET,
    label: str | Unset = UNSET,
    worker: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    created_before: datetime.datetime | Unset = UNSET,
    created_after: datetime.datetime | Unset = UNSET,
    completed_before: datetime.datetime | Unset = UNSET,
    completed_after: datetime.datetime | Unset = UNSET,
    created_before_queue: datetime.datetime | Unset = UNSET,
    created_after_queue: datetime.datetime | Unset = UNSET,
    running: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    tag: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    per_page: int | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    is_skipped: bool | Unset = UNSET,
    is_flow_step: bool | Unset = UNSET,
    has_null_parent: bool | Unset = UNSET,
    success: bool | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1] | None:
    """list all jobs

    Args:
        workspace (str):
        created_by (str | Unset):
        label (str | Unset):
        worker (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        created_before (datetime.datetime | Unset):
        created_after (datetime.datetime | Unset):
        completed_before (datetime.datetime | Unset):
        completed_after (datetime.datetime | Unset):
        created_before_queue (datetime.datetime | Unset):
        created_after_queue (datetime.datetime | Unset):
        running (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        args (str | Unset):
        tag (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        per_page (int | Unset):
        trigger_kind (str | Unset):
        is_skipped (bool | Unset):
        is_flow_step (bool | Unset):
        has_null_parent (bool | Unset):
        success (bool | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        created_by=created_by,
        label=label,
        worker=worker,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        created_before=created_before,
        created_after=created_after,
        completed_before=completed_before,
        completed_after=completed_after,
        created_before_queue=created_before_queue,
        created_after_queue=created_after_queue,
        running=running,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        args=args,
        tag=tag,
        result=result,
        allow_wildcards=allow_wildcards,
        per_page=per_page,
        trigger_kind=trigger_kind,
        is_skipped=is_skipped,
        is_flow_step=is_flow_step,
        has_null_parent=has_null_parent,
        success=success,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
        broad_filter=broad_filter,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    created_by: str | Unset = UNSET,
    label: str | Unset = UNSET,
    worker: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    created_before: datetime.datetime | Unset = UNSET,
    created_after: datetime.datetime | Unset = UNSET,
    completed_before: datetime.datetime | Unset = UNSET,
    completed_after: datetime.datetime | Unset = UNSET,
    created_before_queue: datetime.datetime | Unset = UNSET,
    created_after_queue: datetime.datetime | Unset = UNSET,
    running: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    tag: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    per_page: int | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    is_skipped: bool | Unset = UNSET,
    is_flow_step: bool | Unset = UNSET,
    has_null_parent: bool | Unset = UNSET,
    success: bool | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> Response[list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]]:
    """list all jobs

    Args:
        workspace (str):
        created_by (str | Unset):
        label (str | Unset):
        worker (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        created_before (datetime.datetime | Unset):
        created_after (datetime.datetime | Unset):
        completed_before (datetime.datetime | Unset):
        completed_after (datetime.datetime | Unset):
        created_before_queue (datetime.datetime | Unset):
        created_after_queue (datetime.datetime | Unset):
        running (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        args (str | Unset):
        tag (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        per_page (int | Unset):
        trigger_kind (str | Unset):
        is_skipped (bool | Unset):
        is_flow_step (bool | Unset):
        has_null_parent (bool | Unset):
        success (bool | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        created_by=created_by,
        label=label,
        worker=worker,
        parent_job=parent_job,
        script_path_exact=script_path_exact,
        script_path_start=script_path_start,
        schedule_path=schedule_path,
        script_hash=script_hash,
        started_before=started_before,
        started_after=started_after,
        created_before=created_before,
        created_after=created_after,
        completed_before=completed_before,
        completed_after=completed_after,
        created_before_queue=created_before_queue,
        created_after_queue=created_after_queue,
        running=running,
        scheduled_for_before_now=scheduled_for_before_now,
        job_kinds=job_kinds,
        suspended=suspended,
        args=args,
        tag=tag,
        result=result,
        allow_wildcards=allow_wildcards,
        per_page=per_page,
        trigger_kind=trigger_kind,
        is_skipped=is_skipped,
        is_flow_step=is_flow_step,
        has_null_parent=has_null_parent,
        success=success,
        all_workspaces=all_workspaces,
        is_not_schedule=is_not_schedule,
        broad_filter=broad_filter,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    created_by: str | Unset = UNSET,
    label: str | Unset = UNSET,
    worker: str | Unset = UNSET,
    parent_job: UUID | Unset = UNSET,
    script_path_exact: str | Unset = UNSET,
    script_path_start: str | Unset = UNSET,
    schedule_path: str | Unset = UNSET,
    script_hash: str | Unset = UNSET,
    started_before: datetime.datetime | Unset = UNSET,
    started_after: datetime.datetime | Unset = UNSET,
    created_before: datetime.datetime | Unset = UNSET,
    created_after: datetime.datetime | Unset = UNSET,
    completed_before: datetime.datetime | Unset = UNSET,
    completed_after: datetime.datetime | Unset = UNSET,
    created_before_queue: datetime.datetime | Unset = UNSET,
    created_after_queue: datetime.datetime | Unset = UNSET,
    running: bool | Unset = UNSET,
    scheduled_for_before_now: bool | Unset = UNSET,
    job_kinds: str | Unset = UNSET,
    suspended: bool | Unset = UNSET,
    args: str | Unset = UNSET,
    tag: str | Unset = UNSET,
    result: str | Unset = UNSET,
    allow_wildcards: bool | Unset = UNSET,
    per_page: int | Unset = UNSET,
    trigger_kind: str | Unset = UNSET,
    is_skipped: bool | Unset = UNSET,
    is_flow_step: bool | Unset = UNSET,
    has_null_parent: bool | Unset = UNSET,
    success: bool | Unset = UNSET,
    all_workspaces: bool | Unset = UNSET,
    is_not_schedule: bool | Unset = UNSET,
    broad_filter: str | Unset = UNSET,
) -> list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1] | None:
    """list all jobs

    Args:
        workspace (str):
        created_by (str | Unset):
        label (str | Unset):
        worker (str | Unset):
        parent_job (UUID | Unset):
        script_path_exact (str | Unset):
        script_path_start (str | Unset):
        schedule_path (str | Unset):
        script_hash (str | Unset):
        started_before (datetime.datetime | Unset):
        started_after (datetime.datetime | Unset):
        created_before (datetime.datetime | Unset):
        created_after (datetime.datetime | Unset):
        completed_before (datetime.datetime | Unset):
        completed_after (datetime.datetime | Unset):
        created_before_queue (datetime.datetime | Unset):
        created_after_queue (datetime.datetime | Unset):
        running (bool | Unset):
        scheduled_for_before_now (bool | Unset):
        job_kinds (str | Unset):
        suspended (bool | Unset):
        args (str | Unset):
        tag (str | Unset):
        result (str | Unset):
        allow_wildcards (bool | Unset):
        per_page (int | Unset):
        trigger_kind (str | Unset):
        is_skipped (bool | Unset):
        is_flow_step (bool | Unset):
        has_null_parent (bool | Unset):
        success (bool | Unset):
        all_workspaces (bool | Unset):
        is_not_schedule (bool | Unset):
        broad_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListJobsResponse200ItemType0 | ListJobsResponse200ItemType1]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            created_by=created_by,
            label=label,
            worker=worker,
            parent_job=parent_job,
            script_path_exact=script_path_exact,
            script_path_start=script_path_start,
            schedule_path=schedule_path,
            script_hash=script_hash,
            started_before=started_before,
            started_after=started_after,
            created_before=created_before,
            created_after=created_after,
            completed_before=completed_before,
            completed_after=completed_after,
            created_before_queue=created_before_queue,
            created_after_queue=created_after_queue,
            running=running,
            scheduled_for_before_now=scheduled_for_before_now,
            job_kinds=job_kinds,
            suspended=suspended,
            args=args,
            tag=tag,
            result=result,
            allow_wildcards=allow_wildcards,
            per_page=per_page,
            trigger_kind=trigger_kind,
            is_skipped=is_skipped,
            is_flow_step=is_flow_step,
            has_null_parent=has_null_parent,
            success=success,
            all_workspaces=all_workspaces,
            is_not_schedule=is_not_schedule,
            broad_filter=broad_filter,
        )
    ).parsed
