from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs(
    workspace: str,
    token: str,
    path: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/scripts_u/tokened_raw/{workspace}/{token}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            token=quote(str(token), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    token: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """raw script by path with a token (mostly used by lsp to be used with import maps to resolve scripts)

    Args:
        workspace (str):
        token (str):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        token=token,
        path=path,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    token: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """raw script by path with a token (mostly used by lsp to be used with import maps to resolve scripts)

    Args:
        workspace (str):
        token (str):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        token=token,
        path=path,
        client=client,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    token: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[str]:
    """raw script by path with a token (mostly used by lsp to be used with import maps to resolve scripts)

    Args:
        workspace (str):
        token (str):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        token=token,
        path=path,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    token: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> str | None:
    """raw script by path with a token (mostly used by lsp to be used with import maps to resolve scripts)

    Args:
        workspace (str):
        token (str):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            token=token,
            path=path,
            client=client,
        )
    ).parsed
