from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_scripts_response_200_item import ListScriptsResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path_exact: str | Unset = UNSET,
    first_parent_hash: str | Unset = UNSET,
    last_parent_hash: str | Unset = UNSET,
    parent_hash: str | Unset = UNSET,
    show_archived: bool | Unset = UNSET,
    include_without_main: bool | Unset = UNSET,
    include_draft_only: bool | Unset = UNSET,
    is_template: bool | Unset = UNSET,
    kinds: str | Unset = UNSET,
    starred_only: bool | Unset = UNSET,
    with_deployment_msg: bool | Unset = UNSET,
    languages: str | Unset = UNSET,
    without_description: bool | Unset = UNSET,
    dedicated_worker: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params["order_desc"] = order_desc

    params["created_by"] = created_by

    params["path_start"] = path_start

    params["path_exact"] = path_exact

    params["first_parent_hash"] = first_parent_hash

    params["last_parent_hash"] = last_parent_hash

    params["parent_hash"] = parent_hash

    params["show_archived"] = show_archived

    params["include_without_main"] = include_without_main

    params["include_draft_only"] = include_draft_only

    params["is_template"] = is_template

    params["kinds"] = kinds

    params["starred_only"] = starred_only

    params["with_deployment_msg"] = with_deployment_msg

    params["languages"] = languages

    params["without_description"] = without_description

    params["dedicated_worker"] = dedicated_worker

    params["label"] = label

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/scripts/list".format(
            workspace=quote(str(workspace), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[ListScriptsResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListScriptsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListScriptsResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path_exact: str | Unset = UNSET,
    first_parent_hash: str | Unset = UNSET,
    last_parent_hash: str | Unset = UNSET,
    parent_hash: str | Unset = UNSET,
    show_archived: bool | Unset = UNSET,
    include_without_main: bool | Unset = UNSET,
    include_draft_only: bool | Unset = UNSET,
    is_template: bool | Unset = UNSET,
    kinds: str | Unset = UNSET,
    starred_only: bool | Unset = UNSET,
    with_deployment_msg: bool | Unset = UNSET,
    languages: str | Unset = UNSET,
    without_description: bool | Unset = UNSET,
    dedicated_worker: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListScriptsResponse200Item]]:
    """list all scripts

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        order_desc (bool | Unset):
        created_by (str | Unset):
        path_start (str | Unset):
        path_exact (str | Unset):
        first_parent_hash (str | Unset):
        last_parent_hash (str | Unset):
        parent_hash (str | Unset):
        show_archived (bool | Unset):
        include_without_main (bool | Unset):
        include_draft_only (bool | Unset):
        is_template (bool | Unset):
        kinds (str | Unset):
        starred_only (bool | Unset):
        with_deployment_msg (bool | Unset):
        languages (str | Unset):
        without_description (bool | Unset):
        dedicated_worker (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListScriptsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        order_desc=order_desc,
        created_by=created_by,
        path_start=path_start,
        path_exact=path_exact,
        first_parent_hash=first_parent_hash,
        last_parent_hash=last_parent_hash,
        parent_hash=parent_hash,
        show_archived=show_archived,
        include_without_main=include_without_main,
        include_draft_only=include_draft_only,
        is_template=is_template,
        kinds=kinds,
        starred_only=starred_only,
        with_deployment_msg=with_deployment_msg,
        languages=languages,
        without_description=without_description,
        dedicated_worker=dedicated_worker,
        label=label,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path_exact: str | Unset = UNSET,
    first_parent_hash: str | Unset = UNSET,
    last_parent_hash: str | Unset = UNSET,
    parent_hash: str | Unset = UNSET,
    show_archived: bool | Unset = UNSET,
    include_without_main: bool | Unset = UNSET,
    include_draft_only: bool | Unset = UNSET,
    is_template: bool | Unset = UNSET,
    kinds: str | Unset = UNSET,
    starred_only: bool | Unset = UNSET,
    with_deployment_msg: bool | Unset = UNSET,
    languages: str | Unset = UNSET,
    without_description: bool | Unset = UNSET,
    dedicated_worker: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListScriptsResponse200Item] | None:
    """list all scripts

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        order_desc (bool | Unset):
        created_by (str | Unset):
        path_start (str | Unset):
        path_exact (str | Unset):
        first_parent_hash (str | Unset):
        last_parent_hash (str | Unset):
        parent_hash (str | Unset):
        show_archived (bool | Unset):
        include_without_main (bool | Unset):
        include_draft_only (bool | Unset):
        is_template (bool | Unset):
        kinds (str | Unset):
        starred_only (bool | Unset):
        with_deployment_msg (bool | Unset):
        languages (str | Unset):
        without_description (bool | Unset):
        dedicated_worker (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListScriptsResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        client=client,
        page=page,
        per_page=per_page,
        order_desc=order_desc,
        created_by=created_by,
        path_start=path_start,
        path_exact=path_exact,
        first_parent_hash=first_parent_hash,
        last_parent_hash=last_parent_hash,
        parent_hash=parent_hash,
        show_archived=show_archived,
        include_without_main=include_without_main,
        include_draft_only=include_draft_only,
        is_template=is_template,
        kinds=kinds,
        starred_only=starred_only,
        with_deployment_msg=with_deployment_msg,
        languages=languages,
        without_description=without_description,
        dedicated_worker=dedicated_worker,
        label=label,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path_exact: str | Unset = UNSET,
    first_parent_hash: str | Unset = UNSET,
    last_parent_hash: str | Unset = UNSET,
    parent_hash: str | Unset = UNSET,
    show_archived: bool | Unset = UNSET,
    include_without_main: bool | Unset = UNSET,
    include_draft_only: bool | Unset = UNSET,
    is_template: bool | Unset = UNSET,
    kinds: str | Unset = UNSET,
    starred_only: bool | Unset = UNSET,
    with_deployment_msg: bool | Unset = UNSET,
    languages: str | Unset = UNSET,
    without_description: bool | Unset = UNSET,
    dedicated_worker: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> Response[list[ListScriptsResponse200Item]]:
    """list all scripts

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        order_desc (bool | Unset):
        created_by (str | Unset):
        path_start (str | Unset):
        path_exact (str | Unset):
        first_parent_hash (str | Unset):
        last_parent_hash (str | Unset):
        parent_hash (str | Unset):
        show_archived (bool | Unset):
        include_without_main (bool | Unset):
        include_draft_only (bool | Unset):
        is_template (bool | Unset):
        kinds (str | Unset):
        starred_only (bool | Unset):
        with_deployment_msg (bool | Unset):
        languages (str | Unset):
        without_description (bool | Unset):
        dedicated_worker (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListScriptsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        page=page,
        per_page=per_page,
        order_desc=order_desc,
        created_by=created_by,
        path_start=path_start,
        path_exact=path_exact,
        first_parent_hash=first_parent_hash,
        last_parent_hash=last_parent_hash,
        parent_hash=parent_hash,
        show_archived=show_archived,
        include_without_main=include_without_main,
        include_draft_only=include_draft_only,
        is_template=is_template,
        kinds=kinds,
        starred_only=starred_only,
        with_deployment_msg=with_deployment_msg,
        languages=languages,
        without_description=without_description,
        dedicated_worker=dedicated_worker,
        label=label,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    *,
    client: AuthenticatedClient | Client,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
    order_desc: bool | Unset = UNSET,
    created_by: str | Unset = UNSET,
    path_start: str | Unset = UNSET,
    path_exact: str | Unset = UNSET,
    first_parent_hash: str | Unset = UNSET,
    last_parent_hash: str | Unset = UNSET,
    parent_hash: str | Unset = UNSET,
    show_archived: bool | Unset = UNSET,
    include_without_main: bool | Unset = UNSET,
    include_draft_only: bool | Unset = UNSET,
    is_template: bool | Unset = UNSET,
    kinds: str | Unset = UNSET,
    starred_only: bool | Unset = UNSET,
    with_deployment_msg: bool | Unset = UNSET,
    languages: str | Unset = UNSET,
    without_description: bool | Unset = UNSET,
    dedicated_worker: bool | Unset = UNSET,
    label: str | Unset = UNSET,
) -> list[ListScriptsResponse200Item] | None:
    """list all scripts

    Args:
        workspace (str):
        page (int | Unset):
        per_page (int | Unset):
        order_desc (bool | Unset):
        created_by (str | Unset):
        path_start (str | Unset):
        path_exact (str | Unset):
        first_parent_hash (str | Unset):
        last_parent_hash (str | Unset):
        parent_hash (str | Unset):
        show_archived (bool | Unset):
        include_without_main (bool | Unset):
        include_draft_only (bool | Unset):
        is_template (bool | Unset):
        kinds (str | Unset):
        starred_only (bool | Unset):
        with_deployment_msg (bool | Unset):
        languages (str | Unset):
        without_description (bool | Unset):
        dedicated_worker (bool | Unset):
        label (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListScriptsResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            client=client,
            page=page,
            per_page=per_page,
            order_desc=order_desc,
            created_by=created_by,
            path_start=path_start,
            path_exact=path_exact,
            first_parent_hash=first_parent_hash,
            last_parent_hash=last_parent_hash,
            parent_hash=parent_hash,
            show_archived=show_archived,
            include_without_main=include_without_main,
            include_draft_only=include_draft_only,
            is_template=is_template,
            kinds=kinds,
            starred_only=starred_only,
            with_deployment_msg=with_deployment_msg,
            languages=languages,
            without_description=without_description,
            dedicated_worker=dedicated_worker,
            label=label,
        )
    ).parsed
