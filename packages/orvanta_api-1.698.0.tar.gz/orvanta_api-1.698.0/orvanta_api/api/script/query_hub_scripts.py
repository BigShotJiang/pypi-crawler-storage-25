from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.query_hub_scripts_response_200_item import QueryHubScriptsResponse200Item
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    text: str,
    kind: str | Unset = UNSET,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["text"] = text

    params["kind"] = kind

    params["limit"] = limit

    params["app"] = app

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/embeddings/query_hub_scripts",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[QueryHubScriptsResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = QueryHubScriptsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[QueryHubScriptsResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    text: str,
    kind: str | Unset = UNSET,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
) -> Response[list[QueryHubScriptsResponse200Item]]:
    """query hub scripts by similarity

    Args:
        text (str):
        kind (str | Unset):
        limit (float | Unset):
        app (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[QueryHubScriptsResponse200Item]]
    """

    kwargs = _get_kwargs(
        text=text,
        kind=kind,
        limit=limit,
        app=app,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    text: str,
    kind: str | Unset = UNSET,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
) -> list[QueryHubScriptsResponse200Item] | None:
    """query hub scripts by similarity

    Args:
        text (str):
        kind (str | Unset):
        limit (float | Unset):
        app (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[QueryHubScriptsResponse200Item]
    """

    return sync_detailed(
        client=client,
        text=text,
        kind=kind,
        limit=limit,
        app=app,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    text: str,
    kind: str | Unset = UNSET,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
) -> Response[list[QueryHubScriptsResponse200Item]]:
    """query hub scripts by similarity

    Args:
        text (str):
        kind (str | Unset):
        limit (float | Unset):
        app (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[QueryHubScriptsResponse200Item]]
    """

    kwargs = _get_kwargs(
        text=text,
        kind=kind,
        limit=limit,
        app=app,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    text: str,
    kind: str | Unset = UNSET,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
) -> list[QueryHubScriptsResponse200Item] | None:
    """query hub scripts by similarity

    Args:
        text (str):
        kind (str | Unset):
        limit (float | Unset):
        app (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[QueryHubScriptsResponse200Item]
    """

    return (
        await asyncio_detailed(
            client=client,
            text=text,
            kind=kind,
            limit=limit,
            app=app,
        )
    ).parsed
