from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_ci_test_results_kind import GetCiTestResultsKind
from ...models.get_ci_test_results_response_200_item import GetCiTestResultsResponse200Item
from ...types import Response


def _get_kwargs(
    workspace: str,
    kind: GetCiTestResultsKind,
    path: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/scripts/ci_test_results/{kind}/{path}".format(
            workspace=quote(str(workspace), safe=""),
            kind=quote(str(kind), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[GetCiTestResultsResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = GetCiTestResultsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[GetCiTestResultsResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    kind: GetCiTestResultsKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[list[GetCiTestResultsResponse200Item]]:
    """get CI test results for a script, flow, or resource

    Args:
        workspace (str):
        kind (GetCiTestResultsKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[GetCiTestResultsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        kind=kind,
        path=path,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    kind: GetCiTestResultsKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> list[GetCiTestResultsResponse200Item] | None:
    """get CI test results for a script, flow, or resource

    Args:
        workspace (str):
        kind (GetCiTestResultsKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[GetCiTestResultsResponse200Item]
    """

    return sync_detailed(
        workspace=workspace,
        kind=kind,
        path=path,
        client=client,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    kind: GetCiTestResultsKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[list[GetCiTestResultsResponse200Item]]:
    """get CI test results for a script, flow, or resource

    Args:
        workspace (str):
        kind (GetCiTestResultsKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[GetCiTestResultsResponse200Item]]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        kind=kind,
        path=path,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    kind: GetCiTestResultsKind,
    path: str,
    *,
    client: AuthenticatedClient | Client,
) -> list[GetCiTestResultsResponse200Item] | None:
    """get CI test results for a script, flow, or resource

    Args:
        workspace (str):
        kind (GetCiTestResultsKind):
        path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[GetCiTestResultsResponse200Item]
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            kind=kind,
            path=path,
            client=client,
        )
    ).parsed
