from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_top_hub_scripts_response_200 import GetTopHubScriptsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
    kind: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["app"] = app

    params["kind"] = kind

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/scripts/hub/top",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetTopHubScriptsResponse200 | None:
    if response.status_code == 200:
        response_200 = GetTopHubScriptsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetTopHubScriptsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
    kind: str | Unset = UNSET,
) -> Response[GetTopHubScriptsResponse200]:
    """get top hub scripts

    Args:
        limit (float | Unset):
        app (str | Unset):
        kind (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTopHubScriptsResponse200]
    """

    kwargs = _get_kwargs(
        limit=limit,
        app=app,
        kind=kind,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
    kind: str | Unset = UNSET,
) -> GetTopHubScriptsResponse200 | None:
    """get top hub scripts

    Args:
        limit (float | Unset):
        app (str | Unset):
        kind (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetTopHubScriptsResponse200
    """

    return sync_detailed(
        client=client,
        limit=limit,
        app=app,
        kind=kind,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
    kind: str | Unset = UNSET,
) -> Response[GetTopHubScriptsResponse200]:
    """get top hub scripts

    Args:
        limit (float | Unset):
        app (str | Unset):
        kind (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTopHubScriptsResponse200]
    """

    kwargs = _get_kwargs(
        limit=limit,
        app=app,
        kind=kind,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: float | Unset = UNSET,
    app: str | Unset = UNSET,
    kind: str | Unset = UNSET,
) -> GetTopHubScriptsResponse200 | None:
    """get top hub scripts

    Args:
        limit (float | Unset):
        app (str | Unset):
        kind (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetTopHubScriptsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            app=app,
            kind=kind,
        )
    ).parsed
