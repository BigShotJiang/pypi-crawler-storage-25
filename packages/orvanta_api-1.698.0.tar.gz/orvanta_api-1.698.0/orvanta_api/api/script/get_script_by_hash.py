from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_script_by_hash_response_200 import GetScriptByHashResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workspace: str,
    hash_: str,
    *,
    with_starred_info: bool | Unset = UNSET,
    authed: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["with_starred_info"] = with_starred_info

    params["authed"] = authed

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/w/{workspace}/scripts/get/h/{hash_}".format(
            workspace=quote(str(workspace), safe=""),
            hash_=quote(str(hash_), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetScriptByHashResponse200 | None:
    if response.status_code == 200:
        response_200 = GetScriptByHashResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetScriptByHashResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    hash_: str,
    *,
    client: AuthenticatedClient | Client,
    with_starred_info: bool | Unset = UNSET,
    authed: bool | Unset = UNSET,
) -> Response[GetScriptByHashResponse200]:
    """get script by hash

    Args:
        workspace (str):
        hash_ (str):
        with_starred_info (bool | Unset):
        authed (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetScriptByHashResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        hash_=hash_,
        with_starred_info=with_starred_info,
        authed=authed,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    hash_: str,
    *,
    client: AuthenticatedClient | Client,
    with_starred_info: bool | Unset = UNSET,
    authed: bool | Unset = UNSET,
) -> GetScriptByHashResponse200 | None:
    """get script by hash

    Args:
        workspace (str):
        hash_ (str):
        with_starred_info (bool | Unset):
        authed (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetScriptByHashResponse200
    """

    return sync_detailed(
        workspace=workspace,
        hash_=hash_,
        client=client,
        with_starred_info=with_starred_info,
        authed=authed,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    hash_: str,
    *,
    client: AuthenticatedClient | Client,
    with_starred_info: bool | Unset = UNSET,
    authed: bool | Unset = UNSET,
) -> Response[GetScriptByHashResponse200]:
    """get script by hash

    Args:
        workspace (str):
        hash_ (str):
        with_starred_info (bool | Unset):
        authed (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetScriptByHashResponse200]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        hash_=hash_,
        with_starred_info=with_starred_info,
        authed=authed,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    hash_: str,
    *,
    client: AuthenticatedClient | Client,
    with_starred_info: bool | Unset = UNSET,
    authed: bool | Unset = UNSET,
) -> GetScriptByHashResponse200 | None:
    """get script by hash

    Args:
        workspace (str):
        hash_ (str):
        with_starred_info (bool | Unset):
        authed (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetScriptByHashResponse200
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            hash_=hash_,
            client=client,
            with_starred_info=with_starred_info,
            authed=authed,
        )
    ).parsed
