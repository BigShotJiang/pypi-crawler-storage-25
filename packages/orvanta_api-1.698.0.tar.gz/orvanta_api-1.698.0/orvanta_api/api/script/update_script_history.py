from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.update_script_history_body import UpdateScriptHistoryBody
from ...types import Response


def _get_kwargs(
    workspace: str,
    hash_: str,
    path: str,
    *,
    body: UpdateScriptHistoryBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/w/{workspace}/scripts/history_update/h/{hash_}/p/{path}".format(
            workspace=quote(str(workspace), safe=""),
            hash_=quote(str(hash_), safe=""),
            path=quote(str(path), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    hash_: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateScriptHistoryBody,
) -> Response[str]:
    """update history of a script

    Args:
        workspace (str):
        hash_ (str):
        path (str):
        body (UpdateScriptHistoryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        hash_=hash_,
        path=path,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workspace: str,
    hash_: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateScriptHistoryBody,
) -> str | None:
    """update history of a script

    Args:
        workspace (str):
        hash_ (str):
        path (str):
        body (UpdateScriptHistoryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        workspace=workspace,
        hash_=hash_,
        path=path,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workspace: str,
    hash_: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateScriptHistoryBody,
) -> Response[str]:
    """update history of a script

    Args:
        workspace (str):
        hash_ (str):
        path (str):
        body (UpdateScriptHistoryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        hash_=hash_,
        path=path,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workspace: str,
    hash_: str,
    path: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateScriptHistoryBody,
) -> str | None:
    """update history of a script

    Args:
        workspace (str):
        hash_ (str):
        path (str):
        body (UpdateScriptHistoryBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            workspace=workspace,
            hash_=hash_,
            path=path,
            client=client,
            body=body,
        )
    ).parsed
