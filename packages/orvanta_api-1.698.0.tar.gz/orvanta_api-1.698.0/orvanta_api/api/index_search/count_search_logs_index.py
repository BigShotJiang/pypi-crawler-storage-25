import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.count_search_logs_index_response_200 import CountSearchLogsIndexResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    search_query: str,
    min_ts: datetime.datetime | Unset = UNSET,
    max_ts: datetime.datetime | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["search_query"] = search_query

    json_min_ts: str | Unset = UNSET
    if not isinstance(min_ts, Unset):
        json_min_ts = min_ts.isoformat()
    params["min_ts"] = json_min_ts

    json_max_ts: str | Unset = UNSET
    if not isinstance(max_ts, Unset):
        json_max_ts = max_ts.isoformat()
    params["max_ts"] = json_max_ts

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/srch/index/search/count_service_logs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CountSearchLogsIndexResponse200 | None:
    if response.status_code == 200:
        response_200 = CountSearchLogsIndexResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CountSearchLogsIndexResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    search_query: str,
    min_ts: datetime.datetime | Unset = UNSET,
    max_ts: datetime.datetime | Unset = UNSET,
) -> Response[CountSearchLogsIndexResponse200]:
    """Search and count the log line hits on every provided host

    Args:
        search_query (str):
        min_ts (datetime.datetime | Unset):
        max_ts (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CountSearchLogsIndexResponse200]
    """

    kwargs = _get_kwargs(
        search_query=search_query,
        min_ts=min_ts,
        max_ts=max_ts,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    search_query: str,
    min_ts: datetime.datetime | Unset = UNSET,
    max_ts: datetime.datetime | Unset = UNSET,
) -> CountSearchLogsIndexResponse200 | None:
    """Search and count the log line hits on every provided host

    Args:
        search_query (str):
        min_ts (datetime.datetime | Unset):
        max_ts (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CountSearchLogsIndexResponse200
    """

    return sync_detailed(
        client=client,
        search_query=search_query,
        min_ts=min_ts,
        max_ts=max_ts,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    search_query: str,
    min_ts: datetime.datetime | Unset = UNSET,
    max_ts: datetime.datetime | Unset = UNSET,
) -> Response[CountSearchLogsIndexResponse200]:
    """Search and count the log line hits on every provided host

    Args:
        search_query (str):
        min_ts (datetime.datetime | Unset):
        max_ts (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CountSearchLogsIndexResponse200]
    """

    kwargs = _get_kwargs(
        search_query=search_query,
        min_ts=min_ts,
        max_ts=max_ts,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    search_query: str,
    min_ts: datetime.datetime | Unset = UNSET,
    max_ts: datetime.datetime | Unset = UNSET,
) -> CountSearchLogsIndexResponse200 | None:
    """Search and count the log line hits on every provided host

    Args:
        search_query (str):
        min_ts (datetime.datetime | Unset):
        max_ts (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CountSearchLogsIndexResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            search_query=search_query,
            min_ts=min_ts,
            max_ts=max_ts,
        )
    ).parsed
