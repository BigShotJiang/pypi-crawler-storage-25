import time

from watchdog.observers import Observer

from gams_frog.ssr.init.ApplicationContext import ApplicationContext
from gams_frog.ssr.watch.ApplicationViewFileEventController import ApplicationViewFileEventController


class ApplicationViewFileWatcher:
    """
    Watches the application files src-folder for changes and triggers the generation of new output files,
    based on defined event handler.
    """

    @staticmethod
    def start(app_context: ApplicationContext):
        """
        Watches the filesystem for changes and triggers the generation of new output files
        :param app_context : ApplicationContext : The application context to be passed down to the event controller
        """
        view_template_folder = app_context.get_config().project_src_dir
        # passing application context to the event controller (based on filewatching)
        event_handler = ApplicationViewFileEventController(app_context)
        # render views at startup
        event_handler.render_views()

        # setting up the observer
        observer = Observer()
        observer.schedule(event_handler, path=view_template_folder, recursive=True)
        observer.start()

        try:
            while True:
                time.sleep(5)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()
