"""Carve.Photos — Python SDK for background removal API."""

from carvesdk.client import CarveClient

__all__ = ["CarveClient"]
__version__ = "0.1.0"
