"""Carve.Photos API client."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, BinaryIO

import requests


class CarveError(Exception):
    """Base exception for Carve API errors."""

    def __init__(self, message: str, status_code: int | None = None, detail: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail


class CarveClient:
    """Client for Carve.Photos background removal API.

    Usage::

        from carvesdk import CarveClient

        client = CarveClient("YOUR_API_KEY")

        # Remove background from image
        result = client.remove_background("photo.jpg")
        result.save("result.png")

        # Remove background from video
        result = client.remove_background_video("video.mp4")
        result.save("result.mp4")

    Full documentation: https://carve.photos/help/api-docs
    """

    BASE_URL = "https://api.carve.photos/api/v1"

    def __init__(self, api_key: str, *, base_url: str | None = None):
        self.api_key = api_key
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self._session = requests.Session()
        self._session.headers["X-API-Key"] = api_key

    # ── Images ──────────────────────────────────────────────

    def remove_background(
        self,
        image: str | Path | BinaryIO,
        *,
        format: str = "png",
        size: str = "auto",
        bg_color: str | None = None,
        bg_image: str | Path | BinaryIO | None = None,
        crop: bool = False,
        crop_margin: str | None = None,
        crop_threshold: float | None = None,
        roi: str | None = None,
        scale: str | None = None,
        position: str | None = None,
        poll_interval: float = 2.0,
        timeout: float = 120.0,
    ) -> ImageResult:
        """Remove background from an image.

        Args:
            image: Path to image file or file-like object.
            format: Output format — ``png``, ``webp``, ``jpg``, ``zip``.
            size: Output size — ``preview``, ``medium``, ``hd``, ``full``, ``auto``,
                  or custom like ``"800px 600px"``.
            bg_color: Background color in hex, e.g. ``"#FFFFFF"``.
            bg_image: Background image file path or file-like object.
            crop: Crop to object bounds.
            crop_margin: Margin around crop, e.g. ``"10%"`` or ``"20px"``.
            crop_threshold: Crop sensitivity (0.01–1.0).
            roi: Region of interest, e.g. ``"10% 10% 90% 90%"``.
            scale: Object scale, e.g. ``"75%"`` or ``"original"``.
            position: Object position, e.g. ``"center"`` or ``"50% 50%"``.
            poll_interval: Seconds between status checks.
            timeout: Maximum wait time in seconds.

        Returns:
            ImageResult with the processed image data.

        Raises:
            CarveError: If the API returns an error.
        """
        data: dict[str, Any] = {"format": format, "size": size}
        if bg_color:
            data["bg_color"] = bg_color
        if crop:
            data["crop"] = "true"
        if crop_margin:
            data["crop_margin"] = crop_margin
        if crop_threshold is not None:
            data["crop_threshold"] = str(crop_threshold)
        if roi:
            data["roi"] = roi
        if scale:
            data["scale"] = scale
        if position:
            data["position"] = position

        files: dict[str, Any] = {"image": self._open_file(image)}
        if bg_image:
            files["bg_image"] = self._open_file(bg_image)

        resp = self._session.post(
            f"{self.base_url}/images/remove_bg",
            data=data,
            files=files,
        )
        self._check_response(resp, 202)
        image_id = resp.json()["image_id"]

        return self._poll_image(image_id, poll_interval, timeout)

    def get_image_status(self, image_id: str) -> dict[str, Any]:
        """Get current status of an image processing task."""
        resp = self._session.get(f"{self.base_url}/images/images/{image_id}")
        return {"status_code": resp.status_code, **resp.json()}

    # ── Video ───────────────────────────────────────────────

    def remove_background_video(
        self,
        video: str | Path | BinaryIO,
        *,
        format: str = "mp4",
        processing_type: str = "human",
        background_color: str = "#00B140",
        start_time_sec: float = 0.0,
        end_time_sec: float = 0.0,
        poll_interval: float = 5.0,
        timeout: float = 600.0,
    ) -> VideoResult:
        """Remove background from a video.

        Args:
            video: Path to video file or file-like object.
            format: Output format — ``mp4`` or ``pro_bundle``.
            processing_type: ``human`` for people/animals, ``object`` for products.
            background_color: Background color in hex, e.g. ``"#00B140"``.
            start_time_sec: Trim start in seconds.
            end_time_sec: Trim end in seconds (0 = until end).
            poll_interval: Seconds between status checks.
            timeout: Maximum wait time in seconds.

        Returns:
            VideoResult with the processed video data.

        Raises:
            CarveError: If the API returns an error.
        """
        # 1. Create task
        resp = self._session.post(
            f"{self.base_url}/videos/remove_bg",
            json={
                "format": format,
                "processing_type": processing_type,
                "background_color": background_color,
                "start_time_sec": start_time_sec,
                "end_time_sec": end_time_sec,
            },
        )
        self._check_response(resp, 202)
        data = resp.json()
        video_id = data["video_id"]
        upload_url = data["upload_data"]["url"]
        upload_fields = data["upload_data"]["fields"]

        # 2. Upload file
        file_obj = self._open_file(video)
        upload_resp = requests.post(
            upload_url,
            data=upload_fields,
            files={"file": file_obj},
        )
        if upload_resp.status_code not in (200, 204):
            raise CarveError(
                f"Upload failed: {upload_resp.status_code}",
                status_code=upload_resp.status_code,
            )

        # 3. Confirm
        confirm_resp = self._session.put(f"{self.base_url}/videos/{video_id}/source")
        if confirm_resp.status_code != 204:
            raise CarveError(
                f"Confirm failed: {confirm_resp.status_code}",
                status_code=confirm_resp.status_code,
            )

        # 4. Poll
        return self._poll_video(video_id, poll_interval, timeout)

    def get_video_status(self, video_id: str) -> dict[str, Any]:
        """Get current status of a video processing task."""
        resp = self._session.get(f"{self.base_url}/videos/{video_id}")
        return resp.json()

    # ── Account ─────────────────────────────────────────────

    def get_balance(self) -> dict[str, Any]:
        """Get current account balance.

        Returns:
            Dict with ``total``, ``details.api_calls``, ``details.points``.
        """
        resp = self._session.get(f"{self.base_url}/account/balance")
        self._check_response(resp, 200)
        return resp.json()

    # ── Internal ────────────────────────────────────────────

    def _poll_image(
        self, image_id: str, interval: float, timeout: float
    ) -> "ImageResult":
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            resp = self._session.get(f"{self.base_url}/images/images/{image_id}")
            if resp.status_code == 200:
                url = resp.json()["image_url"]
                content = requests.get(url).content
                return ImageResult(image_id=image_id, url=url, data=content)
            if resp.status_code not in (201, 202):
                raise CarveError(
                    f"Processing failed: {resp.status_code}",
                    status_code=resp.status_code,
                    detail=resp.json(),
                )
            time.sleep(interval)
        raise CarveError("Timeout waiting for image processing", status_code=None)

    def _poll_video(
        self, video_id: str, interval: float, timeout: float
    ) -> "VideoResult":
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            resp = self._session.get(f"{self.base_url}/videos/{video_id}")
            body = resp.json()
            status = body.get("status")
            if status == "completed":
                result_url = body["result_url"]
                preview_url = body.get("preview_url")
                content = requests.get(result_url).content
                return VideoResult(
                    video_id=video_id,
                    url=result_url,
                    preview_url=preview_url,
                    data=content,
                )
            if status == "failed":
                error = body.get("error", {})
                raise CarveError(
                    f"Video processing failed: {error.get('reason', 'unknown')}",
                    detail=body,
                )
            time.sleep(interval)
        raise CarveError("Timeout waiting for video processing", status_code=None)

    @staticmethod
    def _open_file(f: str | Path | BinaryIO) -> Any:
        if isinstance(f, (str, Path)):
            path = Path(f)
            return (path.name, open(path, "rb"), "application/octet-stream")
        return f

    @staticmethod
    def _check_response(resp: requests.Response, expected: int) -> None:
        if resp.status_code != expected:
            try:
                detail = resp.json()
            except Exception:
                detail = resp.text
            raise CarveError(
                f"API error {resp.status_code}: {detail}",
                status_code=resp.status_code,
                detail=detail,
            )


class ImageResult:
    """Result of image background removal."""

    def __init__(self, *, image_id: str, url: str, data: bytes):
        self.image_id = image_id
        self.url = url
        self.data = data

    def save(self, path: str | Path) -> Path:
        """Save result to file."""
        p = Path(path)
        p.write_bytes(self.data)
        return p

    def __len__(self) -> int:
        return len(self.data)


class VideoResult:
    """Result of video background removal."""

    def __init__(
        self,
        *,
        video_id: str,
        url: str,
        preview_url: str | None,
        data: bytes,
    ):
        self.video_id = video_id
        self.url = url
        self.preview_url = preview_url
        self.data = data

    def save(self, path: str | Path) -> Path:
        """Save result to file."""
        p = Path(path)
        p.write_bytes(self.data)
        return p

    def __len__(self) -> int:
        return len(self.data)
