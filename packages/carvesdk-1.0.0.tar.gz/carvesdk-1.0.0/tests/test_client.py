"""Comprehensive tests for carvesdk.client module."""

from __future__ import annotations

import io
import time
from pathlib import Path
from unittest.mock import MagicMock, Mock, call, mock_open, patch

import pytest
import requests

from carvesdk.client import CarveClient, CarveError, ImageResult, VideoResult


# ── CarveError ──────────────────────────────────────────────


class TestCarveError:
    def test_basic(self):
        err = CarveError("boom")
        assert str(err) == "boom"
        assert err.status_code is None
        assert err.detail is None

    def test_with_status_and_detail(self):
        err = CarveError("fail", status_code=400, detail={"err": "bad"})
        assert err.status_code == 400
        assert err.detail == {"err": "bad"}

    def test_is_exception(self):
        assert issubclass(CarveError, Exception)


# ── CarveClient.__init__ ───────────────────────────────────


class TestCarveClientInit:
    def test_defaults(self):
        c = CarveClient("key123")
        assert c.api_key == "key123"
        assert c.base_url == "https://api.carve.photos/api/v1"
        assert c._session.headers["X-API-Key"] == "key123"

    def test_custom_base_url(self):
        c = CarveClient("k", base_url="https://custom.api/v2")
        assert c.base_url == "https://custom.api/v2"

    def test_trailing_slash_stripped(self):
        c = CarveClient("k", base_url="https://custom.api/v2/")
        assert c.base_url == "https://custom.api/v2"

    def test_session_is_requests_session(self):
        c = CarveClient("k")
        assert isinstance(c._session, requests.Session)


# ── CarveClient._check_response ───────────────────────────


class TestCheckResponse:
    def test_matching_status(self):
        resp = Mock(status_code=200)
        CarveClient._check_response(resp, 200)  # should not raise

    def test_mismatch_with_json(self):
        resp = Mock(status_code=400)
        resp.json.return_value = {"error": "bad request"}
        with pytest.raises(CarveError) as exc_info:
            CarveClient._check_response(resp, 200)
        assert exc_info.value.status_code == 400
        assert exc_info.value.detail == {"error": "bad request"}
        assert "400" in str(exc_info.value)

    def test_mismatch_with_non_json(self):
        resp = Mock(status_code=500)
        resp.json.side_effect = ValueError("no json")
        resp.text = "Internal Server Error"
        with pytest.raises(CarveError) as exc_info:
            CarveClient._check_response(resp, 200)
        assert exc_info.value.detail == "Internal Server Error"
        assert exc_info.value.status_code == 500


# ── CarveClient._open_file ─────────────────────────────────


class TestOpenFile:
    def test_string_path(self, tmp_path):
        f = tmp_path / "test.jpg"
        f.write_bytes(b"\xff\xd8")
        result = CarveClient._open_file(str(f))
        assert result[0] == "test.jpg"
        assert result[2] == "application/octet-stream"
        data = result[1].read()
        assert data == b"\xff\xd8"
        result[1].close()

    def test_path_object(self, tmp_path):
        f = tmp_path / "img.png"
        f.write_bytes(b"\x89PNG")
        result = CarveClient._open_file(f)
        assert result[0] == "img.png"
        data = result[1].read()
        assert data == b"\x89PNG"
        result[1].close()

    def test_file_like_object(self):
        buf = io.BytesIO(b"data")
        result = CarveClient._open_file(buf)
        assert result is buf


# ── CarveClient.get_balance ────────────────────────────────


class TestGetBalance:
    def test_success(self):
        client = CarveClient("key")
        mock_resp = Mock(status_code=200)
        mock_resp.json.return_value = {"total": 100, "details": {"api_calls": 50, "points": 50}}
        client._session.get = Mock(return_value=mock_resp)

        result = client.get_balance()
        assert result == {"total": 100, "details": {"api_calls": 50, "points": 50}}
        client._session.get.assert_called_once_with("https://api.carve.photos/api/v1/account/balance")

    def test_error(self):
        client = CarveClient("key")
        mock_resp = Mock(status_code=401)
        mock_resp.json.return_value = {"error": "unauthorized"}
        client._session.get = Mock(return_value=mock_resp)

        with pytest.raises(CarveError) as exc_info:
            client.get_balance()
        assert exc_info.value.status_code == 401


# ── CarveClient.get_image_status ───────────────────────────


class TestGetImageStatus:
    def test_returns_status_with_code(self):
        client = CarveClient("key")
        mock_resp = Mock(status_code=200)
        mock_resp.json.return_value = {"status": "completed", "image_url": "https://example.com/img.png"}
        client._session.get = Mock(return_value=mock_resp)

        result = client.get_image_status("img-123")
        assert result["status_code"] == 200
        assert result["status"] == "completed"
        client._session.get.assert_called_once_with(
            "https://api.carve.photos/api/v1/images/images/img-123"
        )

    def test_pending(self):
        client = CarveClient("key")
        mock_resp = Mock(status_code=202)
        mock_resp.json.return_value = {"status": "processing"}
        client._session.get = Mock(return_value=mock_resp)

        result = client.get_image_status("img-456")
        assert result["status_code"] == 202
        assert result["status"] == "processing"


# ── CarveClient.get_video_status ───────────────────────────


class TestGetVideoStatus:
    def test_returns_json(self):
        client = CarveClient("key")
        mock_resp = Mock()
        mock_resp.json.return_value = {"status": "processing", "progress": 0.5}
        client._session.get = Mock(return_value=mock_resp)

        result = client.get_video_status("vid-789")
        assert result == {"status": "processing", "progress": 0.5}
        client._session.get.assert_called_once_with(
            "https://api.carve.photos/api/v1/videos/vid-789"
        )


# ── CarveClient._poll_image ───────────────────────────────


class TestPollImage:
    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_immediate_success(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        status_resp = Mock(status_code=200)
        status_resp.json.return_value = {"image_url": "https://cdn.example.com/result.png"}
        client._session.get = Mock(return_value=status_resp)

        download_resp = Mock()
        download_resp.content = b"PNG_DATA"
        mock_get.return_value = download_resp

        result = client._poll_image("img-1", interval=2.0, timeout=120.0)
        assert isinstance(result, ImageResult)
        assert result.image_id == "img-1"
        assert result.url == "https://cdn.example.com/result.png"
        assert result.data == b"PNG_DATA"
        mock_sleep.assert_not_called()

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_polls_then_succeeds(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0, 2.0, 3.0]
        client = CarveClient("key")

        pending_resp = Mock(status_code=202)
        pending_resp.json.return_value = {"status": "processing"}

        ready_resp = Mock(status_code=200)
        ready_resp.json.return_value = {"image_url": "https://cdn.example.com/done.png"}

        client._session.get = Mock(side_effect=[pending_resp, ready_resp])

        download_resp = Mock()
        download_resp.content = b"RESULT"
        mock_get.return_value = download_resp

        result = client._poll_image("img-2", interval=1.0, timeout=120.0)
        assert result.data == b"RESULT"
        mock_sleep.assert_called_once_with(1.0)

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_polls_with_201_status(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0, 2.0]
        client = CarveClient("key")

        pending_resp = Mock(status_code=201)
        ready_resp = Mock(status_code=200)
        ready_resp.json.return_value = {"image_url": "https://cdn.example.com/x.png"}
        client._session.get = Mock(side_effect=[pending_resp, ready_resp])

        mock_get.return_value = Mock(content=b"DATA")
        result = client._poll_image("img-3", interval=1.0, timeout=120.0)
        assert result.data == b"DATA"

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_error_status(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        err_resp = Mock(status_code=500)
        err_resp.json.return_value = {"error": "internal"}
        client._session.get = Mock(return_value=err_resp)

        with pytest.raises(CarveError) as exc_info:
            client._poll_image("img-4", interval=1.0, timeout=120.0)
        assert exc_info.value.status_code == 500
        assert exc_info.value.detail == {"error": "internal"}

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_timeout(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0, 200.0]
        client = CarveClient("key")

        pending_resp = Mock(status_code=202)
        pending_resp.json.return_value = {"status": "processing"}
        client._session.get = Mock(return_value=pending_resp)

        with pytest.raises(CarveError, match="Timeout"):
            client._poll_image("img-5", interval=1.0, timeout=10.0)


# ── CarveClient._poll_video ───────────────────────────────


class TestPollVideo:
    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_immediate_completed(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        status_resp = Mock()
        status_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/video.mp4",
            "preview_url": "https://cdn.example.com/preview.jpg",
        }
        client._session.get = Mock(return_value=status_resp)

        mock_get.return_value = Mock(content=b"VIDEO_DATA")

        result = client._poll_video("vid-1", interval=5.0, timeout=600.0)
        assert isinstance(result, VideoResult)
        assert result.video_id == "vid-1"
        assert result.url == "https://cdn.example.com/video.mp4"
        assert result.preview_url == "https://cdn.example.com/preview.jpg"
        assert result.data == b"VIDEO_DATA"
        mock_sleep.assert_not_called()

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_completed_without_preview(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        status_resp = Mock()
        status_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/v.mp4",
        }
        client._session.get = Mock(return_value=status_resp)
        mock_get.return_value = Mock(content=b"V")

        result = client._poll_video("vid-np", interval=1.0, timeout=60.0)
        assert result.preview_url is None

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_polls_then_completed(self, mock_mono, mock_sleep, mock_get):
        mock_mono.side_effect = [0.0, 1.0, 2.0, 3.0]
        client = CarveClient("key")

        processing_resp = Mock()
        processing_resp.json.return_value = {"status": "processing"}

        done_resp = Mock()
        done_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/done.mp4",
            "preview_url": None,
        }
        client._session.get = Mock(side_effect=[processing_resp, done_resp])
        mock_get.return_value = Mock(content=b"DONE")

        result = client._poll_video("vid-2", interval=5.0, timeout=600.0)
        assert result.data == b"DONE"
        mock_sleep.assert_called_once_with(5.0)

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_failed_with_reason(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        fail_resp = Mock()
        fail_resp.json.return_value = {
            "status": "failed",
            "error": {"reason": "unsupported_format"},
        }
        client._session.get = Mock(return_value=fail_resp)

        with pytest.raises(CarveError, match="unsupported_format"):
            client._poll_video("vid-3", interval=1.0, timeout=60.0)

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_failed_without_reason(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        fail_resp = Mock()
        fail_resp.json.return_value = {"status": "failed", "error": {}}
        client._session.get = Mock(return_value=fail_resp)

        with pytest.raises(CarveError, match="unknown"):
            client._poll_video("vid-4", interval=1.0, timeout=60.0)

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_failed_no_error_key(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        fail_resp = Mock()
        fail_resp.json.return_value = {"status": "failed"}
        client._session.get = Mock(return_value=fail_resp)

        with pytest.raises(CarveError, match="unknown"):
            client._poll_video("vid-5", interval=1.0, timeout=60.0)

    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_timeout(self, mock_mono, mock_sleep):
        mock_mono.side_effect = [0.0, 1.0, 700.0]
        client = CarveClient("key")

        processing_resp = Mock()
        processing_resp.json.return_value = {"status": "processing"}
        client._session.get = Mock(return_value=processing_resp)

        with pytest.raises(CarveError, match="Timeout"):
            client._poll_video("vid-6", interval=5.0, timeout=10.0)


# ── CarveClient.remove_background ─────────────────────────


class TestRemoveBackground:
    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_minimal_params(self, mock_mono, mock_sleep, mock_dl):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        post_resp = Mock(status_code=202)
        post_resp.json.return_value = {"image_id": "abc"}

        poll_resp = Mock(status_code=200)
        poll_resp.json.return_value = {"image_url": "https://cdn.example.com/r.png"}

        client._session.post = Mock(return_value=post_resp)
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"IMG")

        buf = io.BytesIO(b"image_data")
        result = client.remove_background(buf)

        assert isinstance(result, ImageResult)
        assert result.data == b"IMG"

        # Verify POST was called with correct URL
        post_call = client._session.post.call_args
        assert post_call[0][0] == "https://api.carve.photos/api/v1/images/remove_bg"
        data = post_call[1]["data"]
        assert data["format"] == "png"
        assert data["size"] == "auto"
        assert "bg_color" not in data
        assert "crop" not in data

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_all_params(self, mock_mono, mock_sleep, mock_dl):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        post_resp = Mock(status_code=202)
        post_resp.json.return_value = {"image_id": "xyz"}

        poll_resp = Mock(status_code=200)
        poll_resp.json.return_value = {"image_url": "https://cdn.example.com/full.png"}

        client._session.post = Mock(return_value=post_resp)
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"FULL")

        buf = io.BytesIO(b"data")
        result = client.remove_background(
            buf,
            format="webp",
            size="hd",
            bg_color="#FF0000",
            crop=True,
            crop_margin="10%",
            crop_threshold=0.5,
            roi="10% 10% 90% 90%",
            scale="75%",
            position="center",
        )

        post_call = client._session.post.call_args
        data = post_call[1]["data"]
        assert data["format"] == "webp"
        assert data["size"] == "hd"
        assert data["bg_color"] == "#FF0000"
        assert data["crop"] == "true"
        assert data["crop_margin"] == "10%"
        assert data["crop_threshold"] == "0.5"
        assert data["roi"] == "10% 10% 90% 90%"
        assert data["scale"] == "75%"
        assert data["position"] == "center"

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_crop_threshold_zero(self, mock_mono, mock_sleep, mock_dl):
        """crop_threshold=0 should be included (not skipped by falsy check)."""
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        post_resp = Mock(status_code=202)
        post_resp.json.return_value = {"image_id": "ct0"}

        poll_resp = Mock(status_code=200)
        poll_resp.json.return_value = {"image_url": "https://cdn.example.com/ct0.png"}

        client._session.post = Mock(return_value=post_resp)
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"X")

        buf = io.BytesIO(b"data")
        client.remove_background(buf, crop_threshold=0.0)

        data = client._session.post.call_args[1]["data"]
        assert data["crop_threshold"] == "0.0"

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_with_bg_image(self, mock_mono, mock_sleep, mock_dl):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        post_resp = Mock(status_code=202)
        post_resp.json.return_value = {"image_id": "bg1"}

        poll_resp = Mock(status_code=200)
        poll_resp.json.return_value = {"image_url": "https://cdn.example.com/bg.png"}

        client._session.post = Mock(return_value=post_resp)
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"BG")

        image_buf = io.BytesIO(b"img")
        bg_buf = io.BytesIO(b"bg")
        result = client.remove_background(image_buf, bg_image=bg_buf)

        files = client._session.post.call_args[1]["files"]
        assert "image" in files
        assert "bg_image" in files

    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_with_file_path(self, mock_mono, mock_sleep, mock_dl, tmp_path):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        img_file = tmp_path / "photo.jpg"
        img_file.write_bytes(b"\xff\xd8\xff")

        post_resp = Mock(status_code=202)
        post_resp.json.return_value = {"image_id": "fp1"}

        poll_resp = Mock(status_code=200)
        poll_resp.json.return_value = {"image_url": "https://cdn.example.com/fp.png"}

        client._session.post = Mock(return_value=post_resp)
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"FP")

        result = client.remove_background(str(img_file))
        assert result.data == b"FP"

        files = client._session.post.call_args[1]["files"]
        assert files["image"][0] == "photo.jpg"

    def test_api_error(self):
        client = CarveClient("key")

        post_resp = Mock(status_code=400)
        post_resp.json.return_value = {"error": "bad image"}
        client._session.post = Mock(return_value=post_resp)

        buf = io.BytesIO(b"bad")
        with pytest.raises(CarveError) as exc_info:
            client.remove_background(buf)
        assert exc_info.value.status_code == 400


# ── CarveClient.remove_background_video ────────────────────


class TestRemoveBackgroundVideo:
    @patch("carvesdk.client.requests.get")
    @patch("carvesdk.client.requests.post")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_full_flow(self, mock_mono, mock_sleep, mock_upload_post, mock_dl):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        # 1. Create task
        create_resp = Mock(status_code=202)
        create_resp.json.return_value = {
            "video_id": "vid-1",
            "upload_data": {
                "url": "https://s3.example.com/upload",
                "fields": {"key": "val", "policy": "abc"},
            },
        }
        client._session.post = Mock(return_value=create_resp)

        # 2. Upload
        mock_upload_post.return_value = Mock(status_code=204)

        # 3. Confirm
        confirm_resp = Mock(status_code=204)
        client._session.put = Mock(return_value=confirm_resp)

        # 4. Poll
        poll_resp = Mock()
        poll_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/result.mp4",
            "preview_url": "https://cdn.example.com/preview.jpg",
        }
        client._session.get = Mock(return_value=poll_resp)
        mock_dl.return_value = Mock(content=b"VIDEO")

        buf = io.BytesIO(b"video_data")
        result = client.remove_background_video(buf)

        assert isinstance(result, VideoResult)
        assert result.video_id == "vid-1"
        assert result.data == b"VIDEO"

        # Verify create was called with defaults
        create_call = client._session.post.call_args
        body = create_call[1]["json"]
        assert body["format"] == "mp4"
        assert body["processing_type"] == "human"
        assert body["background_color"] == "#00B140"
        assert body["start_time_sec"] == 0.0
        assert body["end_time_sec"] == 0.0

        # Verify upload
        mock_upload_post.assert_called_once()
        upload_call = mock_upload_post.call_args
        assert upload_call[0][0] == "https://s3.example.com/upload"

        # Verify confirm
        client._session.put.assert_called_once_with(
            "https://api.carve.photos/api/v1/videos/vid-1/source"
        )

    @patch("carvesdk.client.requests.post")
    @patch("carvesdk.client.time.sleep")
    @patch("carvesdk.client.time.monotonic")
    def test_custom_params(self, mock_mono, mock_sleep, mock_upload_post):
        mock_mono.side_effect = [0.0, 1.0]
        client = CarveClient("key")

        create_resp = Mock(status_code=202)
        create_resp.json.return_value = {
            "video_id": "vid-c",
            "upload_data": {"url": "https://s3.example.com/u", "fields": {}},
        }
        client._session.post = Mock(return_value=create_resp)
        mock_upload_post.return_value = Mock(status_code=200)
        client._session.put = Mock(return_value=Mock(status_code=204))

        poll_resp = Mock()
        poll_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/c.mp4",
            "preview_url": None,
        }
        client._session.get = Mock(return_value=poll_resp)

        with patch("carvesdk.client.requests.get", return_value=Mock(content=b"V")):
            buf = io.BytesIO(b"vid")
            result = client.remove_background_video(
                buf,
                format="pro_bundle",
                processing_type="object",
                background_color="#000000",
                start_time_sec=1.5,
                end_time_sec=10.0,
            )

        body = client._session.post.call_args[1]["json"]
        assert body["format"] == "pro_bundle"
        assert body["processing_type"] == "object"
        assert body["background_color"] == "#000000"
        assert body["start_time_sec"] == 1.5
        assert body["end_time_sec"] == 10.0

    def test_create_api_error(self):
        client = CarveClient("key")
        create_resp = Mock(status_code=400)
        create_resp.json.return_value = {"error": "bad"}
        client._session.post = Mock(return_value=create_resp)

        with pytest.raises(CarveError) as exc_info:
            client.remove_background_video(io.BytesIO(b"v"))
        assert exc_info.value.status_code == 400

    @patch("carvesdk.client.requests.post")
    def test_upload_failure(self, mock_upload_post):
        client = CarveClient("key")

        create_resp = Mock(status_code=202)
        create_resp.json.return_value = {
            "video_id": "vid-uf",
            "upload_data": {"url": "https://s3.example.com/u", "fields": {"k": "v"}},
        }
        client._session.post = Mock(return_value=create_resp)
        mock_upload_post.return_value = Mock(status_code=403)

        with pytest.raises(CarveError, match="Upload failed"):
            client.remove_background_video(io.BytesIO(b"v"))

    @patch("carvesdk.client.requests.post")
    def test_confirm_failure(self, mock_upload_post):
        client = CarveClient("key")

        create_resp = Mock(status_code=202)
        create_resp.json.return_value = {
            "video_id": "vid-cf",
            "upload_data": {"url": "https://s3.example.com/u", "fields": {}},
        }
        client._session.post = Mock(return_value=create_resp)
        mock_upload_post.return_value = Mock(status_code=200)
        client._session.put = Mock(return_value=Mock(status_code=500))

        with pytest.raises(CarveError, match="Confirm failed"):
            client.remove_background_video(io.BytesIO(b"v"))

    @patch("carvesdk.client.requests.post")
    def test_with_file_path(self, mock_upload_post, tmp_path):
        client = CarveClient("key")

        vid_file = tmp_path / "clip.mp4"
        vid_file.write_bytes(b"\x00\x00\x00\x1c")

        create_resp = Mock(status_code=202)
        create_resp.json.return_value = {
            "video_id": "vid-fp",
            "upload_data": {"url": "https://s3.example.com/u", "fields": {}},
        }
        client._session.post = Mock(return_value=create_resp)
        mock_upload_post.return_value = Mock(status_code=200)
        client._session.put = Mock(return_value=Mock(status_code=204))

        poll_resp = Mock()
        poll_resp.json.return_value = {
            "status": "completed",
            "result_url": "https://cdn.example.com/fp.mp4",
            "preview_url": None,
        }
        client._session.get = Mock(return_value=poll_resp)

        with patch("carvesdk.client.requests.get", return_value=Mock(content=b"VID")):
            result = client.remove_background_video(str(vid_file))
        assert result.data == b"VID"


# ── ImageResult ────────────────────────────────────────────


class TestImageResult:
    def test_attributes(self):
        r = ImageResult(image_id="i1", url="https://example.com/i.png", data=b"hello")
        assert r.image_id == "i1"
        assert r.url == "https://example.com/i.png"
        assert r.data == b"hello"

    def test_len(self):
        r = ImageResult(image_id="i2", url="u", data=b"12345")
        assert len(r) == 5

    def test_len_empty(self):
        r = ImageResult(image_id="i3", url="u", data=b"")
        assert len(r) == 0

    def test_save(self, tmp_path):
        r = ImageResult(image_id="i4", url="u", data=b"PNG_CONTENT")
        out = tmp_path / "output.png"
        returned = r.save(out)
        assert returned == out
        assert out.read_bytes() == b"PNG_CONTENT"

    def test_save_string_path(self, tmp_path):
        r = ImageResult(image_id="i5", url="u", data=b"DATA")
        out = str(tmp_path / "out.webp")
        returned = r.save(out)
        assert returned == Path(out)
        assert Path(out).read_bytes() == b"DATA"


# ── VideoResult ────────────────────────────────────────────


class TestVideoResult:
    def test_attributes(self):
        r = VideoResult(
            video_id="v1",
            url="https://example.com/v.mp4",
            preview_url="https://example.com/p.jpg",
            data=b"video",
        )
        assert r.video_id == "v1"
        assert r.url == "https://example.com/v.mp4"
        assert r.preview_url == "https://example.com/p.jpg"
        assert r.data == b"video"

    def test_preview_url_none(self):
        r = VideoResult(video_id="v2", url="u", preview_url=None, data=b"x")
        assert r.preview_url is None

    def test_len(self):
        r = VideoResult(video_id="v3", url="u", preview_url=None, data=b"abcdef")
        assert len(r) == 6

    def test_len_empty(self):
        r = VideoResult(video_id="v4", url="u", preview_url=None, data=b"")
        assert len(r) == 0

    def test_save(self, tmp_path):
        r = VideoResult(video_id="v5", url="u", preview_url=None, data=b"MP4_DATA")
        out = tmp_path / "video.mp4"
        returned = r.save(out)
        assert returned == out
        assert out.read_bytes() == b"MP4_DATA"

    def test_save_string_path(self, tmp_path):
        r = VideoResult(video_id="v6", url="u", preview_url=None, data=b"D")
        out = str(tmp_path / "out.mp4")
        returned = r.save(out)
        assert returned == Path(out)
        assert Path(out).read_bytes() == b"D"


# ── __init__.py imports ────────────────────────────────────


class TestModuleImports:
    def test_carve_client_importable(self):
        from carvesdk import CarveClient as CC
        assert CC is CarveClient

    def test_version(self):
        import carvesdk
        assert carvesdk.__version__ == "0.1.0"

    def test_all(self):
        import carvesdk
        assert "CarveClient" in carvesdk.__all__
