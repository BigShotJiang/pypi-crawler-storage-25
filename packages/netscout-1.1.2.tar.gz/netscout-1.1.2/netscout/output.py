"""
Rich terminal UI — live dashboard during scan and final summary table.

Colour scheme:
  Green   = alive host
  Yellow  = open port
  Cyan    = hostname / CIDR label
  Magenta = OS guess
  Red     = errors
  Dim     = dead hosts (only in --verbose)
  Bold white = IPs
"""

from __future__ import annotations

import time
from typing import Sequence

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text
from rich import box

from .scanner import HostResult

# ---------------------------------------------------------------------------
# Console singleton
# ---------------------------------------------------------------------------

console = Console(highlight=False)
console_err = Console(highlight=False, stderr=True)

# ---------------------------------------------------------------------------
# ASCII banner
# ---------------------------------------------------------------------------

BANNER = r"""
[bold green]
  ███╗   ██╗███████╗████████╗███████╗ ██████╗ ██████╗ ██╗   ██╗████████╗
  ████╗  ██║██╔════╝╚══██╔══╝██╔════╝██╔════╝██╔═══██╗██║   ██║╚══██╔══╝
  ██╔██╗ ██║█████╗     ██║   ███████╗██║     ██║   ██║██║   ██║   ██║
  ██║╚██╗██║██╔══╝     ██║   ╚════██║██║     ██║   ██║██║   ██║   ██║
  ██║ ╚████║███████╗   ██║   ███████║╚██████╗╚██████╔╝╚██████╔╝   ██║
  ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝
[/bold green]
[dim]  ──────────────────────────────────────────────────────────────────────[/dim]
[bold cyan]  ⚡ Production Recon CLI[/bold cyan]  [dim]│[/dim]  [yellow]Speed First[/yellow]  [dim]│[/dim]  [magenta]v{version}[/magenta]
[dim]  ──────────────────────────────────────────────────────────────────────[/dim]
"""


def print_banner() -> None:
    """Print the ASCII art banner."""
    from . import __version__
    console.print(BANNER.format(version=__version__))


# ---------------------------------------------------------------------------
# Pre-scan summary
# ---------------------------------------------------------------------------


def print_scan_summary(
    range_count: int, total_hosts: int, ranges_display: list[str]
) -> None:
    """Print target summary before scanning begins."""
    lines = [
        f"[bold]Scanning [cyan]{total_hosts:,}[/cyan] hosts across "
        f"[cyan]{range_count}[/cyan] range{'s' if range_count != 1 else ''}[/bold]",
    ]
    for r in ranges_display[:10]:
        lines.append(f"  [dim]▸[/dim] [cyan]{r}[/cyan]")
    if len(ranges_display) > 10:
        lines.append(f"  [dim]  ... and {len(ranges_display) - 10} more[/dim]")

    panel = Panel(
        "\n".join(lines),
        title="[bold cyan]netscout[/bold cyan]",
        border_style="cyan",
        padding=(0, 2),
    )
    console.print(panel)
    console.print()


# ---------------------------------------------------------------------------
# Live scan progress
# ---------------------------------------------------------------------------


class ScanProgress:
    """
    Manages a Rich Live display during the scanning phase.

    Usage:
        sp = ScanProgress(total_hosts, range_label)
        sp.start()
        ...
        sp.advance(host_result)
        ...
        sp.stop()
    """

    def __init__(self, total: int, range_label: str = ""):
        self.total = total
        self.range_label = range_label
        self.scanned = 0
        self.alive = 0
        self.dead = 0
        self._start_time = 0.0
        self._live_hosts: list[HostResult] = []

        self._progress = Progress(
            SpinnerColumn("dots", style="cyan"),
            TextColumn("[bold]{task.description}"),
            BarColumn(bar_width=30, style="cyan", complete_style="bold green"),
            TaskProgressColumn(),
            MofNCompleteColumn(),
            TextColumn("⚡"),
            TextColumn("[yellow]{task.fields[rate]}[/yellow] hosts/sec"),
            TimeElapsedColumn(),
            console=console,
            expand=False,
        )
        self._task_id = self._progress.add_task(
            "Scanning", total=total, rate="0"
        )
        self._live: Live | None = None

    def _build_layout(self) -> Table:
        """Build the full dashboard layout."""
        grid = Table.grid(padding=(0, 1))
        grid.add_row(self._progress)

        # Stats line
        elapsed = max(time.time() - self._start_time, 0.01)
        rate = self.scanned / elapsed
        remaining = self.total - self.scanned

        stats = Text.assemble(
            ("  Live: ", ""),
            (f"{self.alive}", "bold green"),
            ("   Dead: ", ""),
            (f"{self.dead}", "dim"),
            ("   Remaining: ", ""),
            (f"{remaining}", "yellow"),
        )
        grid.add_row(stats)

        # Recent live hosts (last 8)
        if self._live_hosts:
            grid.add_row(Text(""))
            for hr in self._live_hosts[-8:]:
                ports_str = " ".join(str(p) for p in hr.open_ports[:6]) if hr.open_ports else ""
                hostname_str = hr.hostname or "—"
                os_str = hr.os_guess or ""

                line = Text.assemble(
                    ("  ✓  ", "green"),
                    (f"{hr.ip:<16}", "bold white"),
                    (f"{hostname_str:<24}", "cyan"),
                    (f"{ports_str:<16}", "yellow"),
                    (f"{os_str}", "magenta"),
                )
                grid.add_row(line)

        panel = Panel(
            grid,
            title=f"[bold cyan]netscout[/bold cyan] ── {self.range_label}",
            border_style="cyan",
            padding=(0, 1),
        )
        return Table.grid().add_row(panel) if False else panel

    def start(self) -> None:
        """Begin the live display."""
        self._start_time = time.time()
        self._live = Live(
            self._build_layout(),
            console=console,
            refresh_per_second=20,
            transient=True,
        )
        self._live.start()

    def advance(self, hr: HostResult | None = None, count: int = 1) -> None:
        """Update progress after a host is scanned."""
        self.scanned += count
        if hr:
            if hr.alive:
                self.alive += 1
                self._live_hosts.append(hr)
            else:
                self.dead += 1

        elapsed = max(time.time() - self._start_time, 0.01)
        rate = f"{self.scanned / elapsed:.0f}"
        self._progress.update(self._task_id, advance=count, rate=rate)

        if self._live:
            self._live.update(self._build_layout())

    def stop(self) -> None:
        """Stop the live display."""
        if self._live:
            self._live.stop()


# ---------------------------------------------------------------------------
# Final summary table
# ---------------------------------------------------------------------------


def print_results_table(
    hosts: dict[str, HostResult],
    verbose: bool = False,
) -> None:
    """Print the final rich summary table."""
    table = Table(
        title="[bold]Scan Results[/bold]",
        box=box.DOUBLE_EDGE,
        show_lines=False,
        header_style="bold cyan",
        border_style="cyan",
        padding=(0, 1),
    )
    table.add_column("IP", style="bold white", min_width=15)
    table.add_column("Hostname", style="cyan", min_width=20)
    table.add_column("OS Guess", style="magenta", min_width=12)
    table.add_column("Open Ports", style="yellow", min_width=16)
    table.add_column("Banners", style="dim", min_width=20)

    sorted_hosts = sorted(hosts.values(), key=lambda h: tuple(int(o) for o in h.ip.split(".")))

    for hr in sorted_hosts:
        if not hr.alive and not verbose:
            continue

        if not hr.alive:
            table.add_row(
                Text(hr.ip, style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
            )
            continue

        ports_str = " ".join(str(p) for p in hr.open_ports) if hr.open_ports else "—"
        hostname = hr.hostname or "—"
        os_guess = hr.os_guess or "—"

        # Build banner string from port details
        banners: list[str] = []
        for port in hr.open_ports:
            pi = hr.port_details.get(port)
            if pi and pi.banner:
                banners.append(f"{port}:{pi.banner[:30]}")
            elif pi and pi.service:
                banners.append(f"{port}:{pi.service}")
        banner_str = " | ".join(banners[:3]) if banners else "—"

        table.add_row(hr.ip, hostname, os_guess, ports_str, banner_str)

    console.print()
    console.print(table)


# ---------------------------------------------------------------------------
# CIDR range summary
# ---------------------------------------------------------------------------


def print_range_summary(
    ranges: list[str],
    hosts: dict[str, HostResult],
    total_hosts: int,
    elapsed: float,
) -> None:
    """Print per-range alive stats and follow-up suggestions."""
    alive_count = sum(1 for hr in hosts.values() if hr.alive)
    alive_ips = [hr.ip for hr in hosts.values() if hr.alive]
    all_ports: set[int] = set()
    for hr in hosts.values():
        if hr.alive:
            all_ports.update(hr.open_ports)

    console.print()
    console.print("[bold]  CIDR RANGES DETECTED:[/bold]")
    for r in ranges:
        pct = (alive_count / max(total_hosts, 1)) * 100
        bar_filled = int(pct / 5)
        bar = "█" * bar_filled + "░" * (20 - bar_filled)
        console.print(
            f"  [dim]▸[/dim] [cyan]{r}[/cyan]    →  "
            f"[green]{alive_count}[/green] alive / {total_hosts} total   "
            f"[dim][{bar}][/dim]  {pct:.1f}%"
        )

    # Follow-up suggestion
    if alive_ips and all_ports:
        ports_str = ",".join(str(p) for p in sorted(all_ports))
        ips_str = " ".join(alive_ips[:10])
        console.print()
        console.print("[bold]  FOLLOW-UP:[/bold]")
        console.print(
            f"  [dim]▸[/dim] nmap -sCV -T4 -p{ports_str} {ips_str}"
        )

    console.print()
    rate = total_hosts / max(elapsed, 0.01)
    console.print(
        f"  [bold]Scan complete:[/bold] {total_hosts:,} hosts in "
        f"[cyan]{elapsed:.1f}s[/cyan]  ({rate:.0f} hosts/sec)"
    )
    console.print()


# ---------------------------------------------------------------------------
# Quiet mode output
# ---------------------------------------------------------------------------


def print_quiet(hosts: dict[str, HostResult]) -> None:
    """Print only IP:PORT pairs, one per line. For piping to other tools."""
    for hr in sorted(hosts.values(), key=lambda h: tuple(int(o) for o in h.ip.split("."))):
        if not hr.alive:
            continue
        if hr.open_ports:
            for port in hr.open_ports:
                print(f"{hr.ip}:{port}")
        else:
            print(hr.ip)


# ---------------------------------------------------------------------------
# Error / warning helpers
# ---------------------------------------------------------------------------


def warn(msg: str) -> None:
    """Print a warning to stderr."""
    console_err.print(f"[yellow][!][/yellow] {msg}")


def error(msg: str) -> None:
    """Print an error to stderr."""
    console_err.print(f"[red][✗][/red] {msg}")


def info(msg: str) -> None:
    """Print an info message."""
    console.print(f"[cyan][*][/cyan] {msg}")


def success(msg: str) -> None:
    """Print a success message."""
    console.print(f"[green][✓][/green] {msg}")
