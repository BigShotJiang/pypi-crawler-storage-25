import sys
from netscout.main import main

if __name__ == "__main__":
    sys.exit(main())
