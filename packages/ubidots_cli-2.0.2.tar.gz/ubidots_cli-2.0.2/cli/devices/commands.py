from typing import Annotated
from typing import no_type_check

import typer

from cli.commons.decorators import add_filter_option
from cli.commons.decorators import add_pagination_options
from cli.commons.decorators import add_sort_by_option
from cli.commons.decorators import simple_lookup_key
from cli.commons.enums import DefaultInstanceFieldEnum
from cli.commons.enums import EntityNameEnum
from cli.commons.enums import OutputFormatFieldsEnum
from cli.commons.formatters import resolve_formatter
from cli.commons.utils import get_instance_key
from cli.commons.validators import is_valid_json_string
from cli.config.helpers import get_configuration
from cli.devices import handlers

FIELDS_DEVICE_HELP_TEXT = (
    "Comma-separated fields to process * e.g. field1,field2,field3. "
    "* Available fields: (id, label, name, createdAt, description, isActive, lastActivity, "
    "organization, location, tags, url, variables, "
    "variablesCount, properties). "
    "For more details, visit the documentation at:\n"
    "https://docs.ubidots.com/reference/device-object"
)
app = typer.Typer(help="Device management and operations.")


@app.command(short_help="Deletes a specific device using its id or label.")
@simple_lookup_key(entity_name=EntityNameEnum.DEVICE)
def delete(
    id: str | None = None,
    label: str | None = None,
    profile: Annotated[
        str,
        typer.Option(
            help="Name of the profile to use for remote server communication."
        ),
    ] = "",
    output_format: Annotated[
        OutputFormatFieldsEnum | None,
        typer.Option("--format"),
    ] = None,
):
    active_config = get_configuration(profile=profile)
    device_key = get_instance_key(id=id, label=label)
    formatter = resolve_formatter(
        flag=output_format, active_config=active_config, command="devices delete"
    )
    handlers.delete_device(
        device_key=device_key, active_config=active_config, formatter=formatter
    )


@app.command(short_help="Retrieves a specific device using its id or label.")
@simple_lookup_key(entity_name=EntityNameEnum.DEVICE)
@no_type_check
def get(
    id: str | None = None,
    label: str | None = None,
    profile: Annotated[
        str,
        typer.Option(
            help="Name of the profile to use for remote server communication."
        ),
    ] = "",
    fields: Annotated[
        str,
        typer.Option(help=FIELDS_DEVICE_HELP_TEXT),
    ] = DefaultInstanceFieldEnum.get_default_fields(),
    output_format: Annotated[
        OutputFormatFieldsEnum | None,
        typer.Option("--format"),
    ] = None,
):
    active_config = get_configuration(profile=profile)
    device_key = get_instance_key(id=id, label=label)
    formatter = resolve_formatter(
        flag=output_format, active_config=active_config, command="devices get"
    )
    handlers.retrieve_device(
        device_key=device_key,
        fields=fields,
        formatter=formatter,
        active_config=active_config,
    )


@app.command(short_help="Lists all available devices.")
@add_pagination_options()
@add_sort_by_option()
@add_filter_option()
@no_type_check
def list(
    fields: Annotated[
        str,
        typer.Option(help=FIELDS_DEVICE_HELP_TEXT),
    ] = DefaultInstanceFieldEnum.get_default_fields(),
    filter: str | None = None,
    sort_by: str | None = None,
    page_size: int | None = None,
    page: int | None = None,
    output_format: Annotated[
        OutputFormatFieldsEnum | None,
        typer.Option("--format"),
    ] = None,
    profile: Annotated[
        str,
        typer.Option(
            help="Name of the profile to use for remote server communication."
        ),
    ] = "",
):
    active_config = get_configuration(profile=profile)
    formatter = resolve_formatter(
        flag=output_format, active_config=active_config, command="devices list"
    )
    handlers.list_devices(
        fields=fields,
        filter=filter,
        sort_by=sort_by,
        page_size=page_size,
        page=page,
        formatter=formatter,
        active_config=active_config,
    )


@app.command(short_help="Adds a new device.")
def add(
    label: Annotated[
        str, typer.Argument(help="The label for the device.", show_default=False)
    ],
    name: Annotated[str, typer.Option(help="The name of the device.")] = "",
    description: Annotated[
        str, typer.Option(help="A brief description of the device.")
    ] = "",
    organization: Annotated[
        str,
        typer.Option(
            help="The organization associated with the device. Its id or ['~label' | \\~label]."
        ),
    ] = "",
    tags: Annotated[
        str,
        typer.Option(help="Comma-separated tags for the device. e.g. tag1,tag2,tag3"),
    ] = "",
    properties: Annotated[
        str,
        typer.Option(
            help="Device properties in JSON format.", callback=is_valid_json_string
        ),
    ] = "{}",
    profile: Annotated[
        str,
        typer.Option(
            help="Name of the profile to use for remote server communication."
        ),
    ] = "",
    output_format: Annotated[
        OutputFormatFieldsEnum | None,
        typer.Option("--format"),
    ] = None,
):
    active_config = get_configuration(profile=profile)
    formatter = resolve_formatter(
        flag=output_format, active_config=active_config, command="devices add"
    )
    handlers.add_device(
        active_config=active_config,
        formatter=formatter,
        label=label,
        name=name,
        description=description,
        organization=organization,
        tags=tags,
        properties=properties,
    )


@app.command(short_help="Update a device.")
@simple_lookup_key(entity_name=EntityNameEnum.DEVICE)
def update(
    id: str | None = None,
    label: str | None = None,
    new_label: Annotated[str, typer.Option(help="The label for the device.")] = "",
    new_name: Annotated[str, typer.Option(help="The name of the device.")] = "",
    description: Annotated[
        str, typer.Option(help="A brief description of the device.")
    ] = "",
    organization: Annotated[
        str,
        typer.Option(
            help="The organization associated with the device. Its id or ['~label' | \\~label]."
        ),
    ] = "",
    tags: Annotated[
        str,
        typer.Option(help="Comma-separated tags for the device. e.g. tag1,tag2,tag3"),
    ] = "",
    properties: Annotated[
        str,
        typer.Option(
            help="Device properties in JSON format.", callback=is_valid_json_string
        ),
    ] = "{}",
    profile: Annotated[
        str,
        typer.Option(
            help="Name of the profile to use for remote server communication."
        ),
    ] = "",
    output_format: Annotated[
        OutputFormatFieldsEnum | None,
        typer.Option("--format"),
    ] = None,
):
    active_config = get_configuration(profile=profile)
    device_key = get_instance_key(id=id, label=label)
    formatter = resolve_formatter(
        flag=output_format, active_config=active_config, command="devices update"
    )
    handlers.update_device(
        active_config=active_config,
        device_key=device_key,
        formatter=formatter,
        label=new_label,
        name=new_name,
        description=description,
        organization=organization,
        tags=tags,
        properties=properties,
    )
