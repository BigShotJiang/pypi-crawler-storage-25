import unittest
from unittest.mock import ANY
from unittest.mock import patch

from typer.testing import CliRunner

from cli.pages.commands import app
from cli.pages.models import PageTypeEnum


class TestDevAddCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.create_local_page")
    def test_dev_add_command_default_values(self, mock_create_page):
        result = self.runner.invoke(app, ["dev", "add"])

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="my_page",
            verbose=False,
            profile="",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    @patch("cli.pages.commands.executor.create_local_page")
    def test_init_command_with_name(self, mock_create_page):
        result = self.runner.invoke(app, ["dev", "add", "--name", "test_page"])

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="test_page",
            verbose=False,
            profile="",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    @patch("cli.pages.commands.executor.create_local_page")
    def test_init_command_with_profile(self, mock_create_page):
        result = self.runner.invoke(app, ["dev", "add", "--profile", "prod"])

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="my_page",
            verbose=False,
            profile="prod",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    @patch("cli.pages.commands.executor.create_local_page")
    def test_init_command_with_type(self, mock_create_page):
        result = self.runner.invoke(app, ["dev", "add", "--type", "dashboard"])

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="my_page",
            verbose=False,
            profile="",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    @patch("cli.pages.commands.executor.create_local_page")
    def test_init_command_verbose(self, mock_create_page):
        result = self.runner.invoke(app, ["dev", "add", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="my_page",
            verbose=True,
            profile="",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    @patch("cli.pages.commands.executor.create_local_page")
    def test_init_command_all_options(self, mock_create_page):
        result = self.runner.invoke(
            app,
            [
                "dev",
                "add",
                "--name",
                "custom_page",
                "--profile",
                "staging",
                "--type",
                "dashboard",
                "--verbose",
            ],
        )

        self.assertEqual(result.exit_code, 0)
        mock_create_page.assert_called_once_with(
            name="custom_page",
            verbose=True,
            profile="staging",
            type=PageTypeEnum.DASHBOARD,
            formatter=ANY,
        )

    def test_init_command_with_remote_id(self):
        result = self.runner.invoke(app, ["dev", "add", "--remote-id", "page123"])

        self.assertEqual(result.exit_code, 2)


class TestStartCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.start_local_dev_server")
    def test_start_command_default(self, mock_start_page):
        result = self.runner.invoke(app, ["dev", "start"])

        self.assertEqual(result.exit_code, 0)
        mock_start_page.assert_called_once_with(verbose=False, formatter=ANY)

    @patch("cli.pages.commands.executor.start_local_dev_server")
    def test_start_command_verbose(self, mock_start_page):
        result = self.runner.invoke(app, ["dev", "start", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_start_page.assert_called_once_with(verbose=True, formatter=ANY)


class TestStopCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.stop_local_dev_server")
    def test_stop_command_default(self, mock_stop_page):
        result = self.runner.invoke(app, ["dev", "stop"])

        self.assertEqual(result.exit_code, 0)
        mock_stop_page.assert_called_once_with(verbose=False, formatter=ANY)

    @patch("cli.pages.commands.executor.stop_local_dev_server")
    def test_stop_command_verbose(self, mock_stop_page):
        result = self.runner.invoke(app, ["dev", "stop", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_stop_page.assert_called_once_with(verbose=True, formatter=ANY)


class TestRestartCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.restart_local_dev_server")
    def test_restart_command_default(self, mock_restart_page):
        result = self.runner.invoke(app, ["dev", "restart"])

        self.assertEqual(result.exit_code, 0)
        mock_restart_page.assert_called_once_with(verbose=False, formatter=ANY)

    @patch("cli.pages.commands.executor.restart_local_dev_server")
    def test_restart_command_verbose(self, mock_restart_page):
        result = self.runner.invoke(app, ["dev", "restart", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_restart_page.assert_called_once_with(verbose=True, formatter=ANY)


class TestStatusCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.show_local_dev_server_status")
    def test_status_command_default(self, mock_status_page):
        result = self.runner.invoke(app, ["dev", "status"])

        self.assertEqual(result.exit_code, 0)
        mock_status_page.assert_called_once_with(verbose=False, formatter=ANY)

    @patch("cli.pages.commands.executor.show_local_dev_server_status")
    def test_status_command_verbose(self, mock_status_page):
        result = self.runner.invoke(app, ["dev", "status", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_status_page.assert_called_once_with(verbose=True, formatter=ANY)


class TestListCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.list_local_pages")
    def test_list_command_default(self, mock_list_pages):
        result = self.runner.invoke(app, ["dev", "list"])

        self.assertEqual(result.exit_code, 0)
        mock_list_pages.assert_called_once_with(verbose=False, formatter=ANY)

    @patch("cli.pages.commands.executor.list_local_pages")
    def test_list_command_verbose(self, mock_list_pages):
        result = self.runner.invoke(app, ["dev", "list", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_list_pages.assert_called_once_with(verbose=True, formatter=ANY)


class TestCommandsIntegration(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    def test_app_help(self):
        result = self.runner.invoke(app, ["--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Tool for managing and developing Ubidots Pages", result.stdout)

    def test_init_command_help(self):
        result = self.runner.invoke(app, ["dev", "add", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Create a new local Ubidots page", result.stdout)

    def test_start_command_help(self):
        result = self.runner.invoke(app, ["dev", "start", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Start the local development server", result.stdout)

    def test_stop_command_help(self):
        result = self.runner.invoke(app, ["dev", "stop", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Stop the local development server", result.stdout)

    def test_restart_command_help(self):
        result = self.runner.invoke(app, ["dev", "restart", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Restart the local development server", result.stdout)

    def test_status_command_help(self):
        result = self.runner.invoke(app, ["dev", "status", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Show the status of the local development server", result.stdout)

    def test_list_command_help(self):
        result = self.runner.invoke(app, ["dev", "list", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("List all pages and their status", result.stdout)


class TestLogsCommand(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    @patch("cli.pages.commands.executor.logs_local_dev_server")
    def test_logs_command_default_values(self, mock_logs):
        result = self.runner.invoke(app, ["dev", "logs"])

        self.assertEqual(result.exit_code, 0)
        mock_logs.assert_called_once_with(
            tail="all", follow=False, verbose=False, formatter=ANY
        )

    @patch("cli.pages.commands.executor.logs_local_dev_server")
    def test_logs_command_with_tail(self, mock_logs):
        result = self.runner.invoke(app, ["dev", "logs", "--tail", "50"])

        self.assertEqual(result.exit_code, 0)
        mock_logs.assert_called_once_with(
            tail="50", follow=False, verbose=False, formatter=ANY
        )

    @patch("cli.pages.commands.executor.logs_local_dev_server")
    def test_logs_command_with_follow(self, mock_logs):
        result = self.runner.invoke(app, ["dev", "logs", "--follow"])

        self.assertEqual(result.exit_code, 0)
        mock_logs.assert_called_once_with(
            tail="all", follow=True, verbose=False, formatter=ANY
        )

    @patch("cli.pages.commands.executor.logs_local_dev_server")
    def test_logs_command_with_verbose(self, mock_logs):
        result = self.runner.invoke(app, ["dev", "logs", "--verbose"])

        self.assertEqual(result.exit_code, 0)
        mock_logs.assert_called_once_with(
            tail="all", follow=False, verbose=True, formatter=ANY
        )

    @patch("cli.pages.commands.executor.logs_local_dev_server")
    def test_logs_command_all_options(self, mock_logs):
        result = self.runner.invoke(
            app, ["dev", "logs", "--tail", "100", "--follow", "--verbose"]
        )

        self.assertEqual(result.exit_code, 0)
        mock_logs.assert_called_once_with(
            tail="100", follow=True, verbose=True, formatter=ANY
        )


class TestLogsCommandHelp(unittest.TestCase):

    def setUp(self):
        self.runner = CliRunner()

    def test_logs_command_help(self):
        result = self.runner.invoke(app, ["dev", "logs", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Display logs", result.stdout)
