"""VS-215 — SDK emits a heartbeat line every N seconds of log silence.

Without this, the SDK's log stream looks dead-frozen during the 10-min
cold-install window (`_WORKER_PIP_DEPS` runs server-side before the
worker writes anything to S3). With it, the user gets a periodic
"still booting" hint instead of nothing.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from veri_sdk import _decorators


@pytest.mark.asyncio
async def test_log_heartbeat_fires_during_silence(monkeypatch):
    """No log lines arrive at all → heartbeat fires after the interval."""
    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 0.01)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.02)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.02)

    async def silent_iter(_job_id, _client):
        # No lines — simulate the pre-worker dead-silence window.
        # Sleep a bit so the heartbeat task has time to fire.
        import asyncio
        await asyncio.sleep(0.05)
        return
        yield  # pragma: no cover

    monkeypatch.setattr(_decorators, "_iter_log_lines", silent_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "running"  # non-terminal so the reconnect loop runs
    lines: list[str] = []

    async def collect(msg: str) -> None:
        lines.append(msg)

    # The reconnect loop only exits on terminal status. Flip after the
    # heartbeat has had time to fire.
    async def flip_terminal() -> None:
        import asyncio
        await asyncio.sleep(0.08)
        job.status = "completed"

    import asyncio
    flip_task = asyncio.create_task(flip_terminal())
    try:
        await _decorators._log_stream_loop(job, MagicMock(), safe_log=collect)
    finally:
        flip_task.cancel()

    heartbeats = [ln for ln in lines if "heartbeat" in ln.lower()]
    assert heartbeats, f"Expected at least one heartbeat; saw: {lines!r}"


@pytest.mark.asyncio
async def test_log_heartbeat_suppressed_when_lines_flow(monkeypatch):
    """If real lines arrive on each tick, no heartbeat should fire."""
    monkeypatch.setattr(_decorators, "_LOG_HEARTBEAT_INTERVAL", 0.05)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_INITIAL", 0.0)
    monkeypatch.setattr(_decorators, "_LOG_RECONNECT_MAX", 0.0)

    async def chatty_iter(_job_id, _client):
        import asyncio
        for i in range(5):
            yield f"line {i}"
            await asyncio.sleep(0.01)  # well under the heartbeat interval
        yield "[Job completed]"  # terminal sentinel — exit cleanly

    monkeypatch.setattr(_decorators, "_iter_log_lines", chatty_iter)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "running"
    lines: list[str] = []

    async def collect(msg: str) -> None:
        lines.append(msg)

    await _decorators._log_stream_loop(job, MagicMock(), safe_log=collect)

    heartbeats = [ln for ln in lines if "heartbeat" in ln.lower()]
    assert not heartbeats, f"Heartbeat should be suppressed when lines flow; saw: {heartbeats!r}"
    # Sanity: we did process real lines
    worker_lines = [ln for ln in lines if "[worker]" in ln]
    assert len(worker_lines) == 5
