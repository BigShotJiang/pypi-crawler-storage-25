# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal

import httpx

from ...types import web_scrape_params, web_search_params
from .browser import (
    BrowserResource,
    AsyncBrowserResource,
    BrowserResourceWithRawResponse,
    AsyncBrowserResourceWithRawResponse,
    BrowserResourceWithStreamingResponse,
    AsyncBrowserResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.web_scrape_response import WebScrapeResponse
from ...types.web_search_response import WebSearchResponse

__all__ = ["WebResource", "AsyncWebResource"]


class WebResource(SyncAPIResource):
    """Search and scrape webpages with finance-oriented defaults."""

    @cached_property
    def browser(self) -> BrowserResource:
        """Search and scrape webpages with finance-oriented defaults."""
        return BrowserResource(self._client)

    @cached_property
    def with_raw_response(self) -> WebResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return WebResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WebResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return WebResourceWithStreamingResponse(self)

    def scrape(
        self,
        *,
        url: str,
        block_ads: bool | Omit = omit,
        formats: Iterable[web_scrape_params.Format] | Omit = omit,
        headers: Optional[Dict[str, str]] | Omit = omit,
        max_age: int | Omit = omit,
        only_main_content: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebScrapeResponse:
        """
        Scrape a webpage

        Args:
          url: HTTP(S) URL of the webpage to scrape.

          block_ads: Whether to block ads and cookie consent banners while scraping.

          formats: Requested scrape output formats. Defaults to `['markdown']`. Mix `markdown`,
              `html`, `rawHtml`, and screenshot configurations to retrieve multiple
              representations in one scrape.

          headers: Optional HTTP headers to send when scraping the page, such as `User-Agent`,
              `Authorization`, or cookies.

          max_age: Maximum cache age in milliseconds. If the cached scrape result is older than
              this, the page will be re-scraped. Defaults to 24 hours.

          only_main_content: Only return the main content of the page excluding headers, navs, footers, etc.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/web/scrape",
            body=maybe_transform(
                {
                    "url": url,
                    "block_ads": block_ads,
                    "formats": formats,
                    "headers": headers,
                    "max_age": max_age,
                    "only_main_content": only_main_content,
                },
                web_scrape_params.WebScrapeParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebScrapeResponse,
        )

    def search(
        self,
        *,
        query: str,
        search_type: Literal["all", "news"],
        date_range: Optional[web_search_params.DateRange] | Omit = omit,
        exclude_domains: SequenceNotStr[str] | Omit = omit,
        include_domains: SequenceNotStr[str] | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebSearchResponse:
        """Wraps Firecrawl search with finance-focused defaults.

        The raw `query` is passed
        through, `include_domains` and `exclude_domains` are appended as `site:` and
        `-site:` operators, multiple included domains are grouped with `OR`, and
        `date_range` is sent separately as Firecrawl's `tbs` parameter for `web` results
        only. When `search_type="all"`, this endpoint requests both `web` and `news`
        results and flattens them into one combined list.

        Args:
          query: Base search query text. You can include inline search operators here, such as
              exact phrases (`"..."`), excluded terms (`-term`), file extension filters
              (`filetype:pdf`), URL matching (`inurl:` and `allinurl:`), title matching
              (`intitle:` and `allintitle:`), and related-site lookup (`related:`). Prefer
              `include_domains` and `exclude_domains` over manually adding `site:` operators.
              Use `date_range` for time filtering instead of embedding time operators in the
              query.

          search_type: Search source to query. Use `all` to request both `web` and `news` results in
              one call, or `news` for news-only results. There is currently no `web`-only
              option. This field is required and has no server-side default.

          date_range: An inclusive date range for filtering web search results.

          exclude_domains: Additional domains to exclude from results. Each domain is converted into a
              `-site:` operator and merged with the default denylist.

          include_domains: Optional domains to require in results. A single domain is converted into a
              `site:` operator; multiple domains are grouped into an `OR` expression so
              matches from any included domain are allowed.

          limit: Maximum number of results requested per upstream source. With
              `search_type="all"`, up to this many `web` results and this many `news` results
              may be returned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/web/search",
            body=maybe_transform(
                {
                    "query": query,
                    "search_type": search_type,
                    "date_range": date_range,
                    "exclude_domains": exclude_domains,
                    "include_domains": include_domains,
                    "limit": limit,
                },
                web_search_params.WebSearchParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebSearchResponse,
        )


class AsyncWebResource(AsyncAPIResource):
    """Search and scrape webpages with finance-oriented defaults."""

    @cached_property
    def browser(self) -> AsyncBrowserResource:
        """Search and scrape webpages with finance-oriented defaults."""
        return AsyncBrowserResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncWebResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWebResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWebResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncWebResourceWithStreamingResponse(self)

    async def scrape(
        self,
        *,
        url: str,
        block_ads: bool | Omit = omit,
        formats: Iterable[web_scrape_params.Format] | Omit = omit,
        headers: Optional[Dict[str, str]] | Omit = omit,
        max_age: int | Omit = omit,
        only_main_content: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebScrapeResponse:
        """
        Scrape a webpage

        Args:
          url: HTTP(S) URL of the webpage to scrape.

          block_ads: Whether to block ads and cookie consent banners while scraping.

          formats: Requested scrape output formats. Defaults to `['markdown']`. Mix `markdown`,
              `html`, `rawHtml`, and screenshot configurations to retrieve multiple
              representations in one scrape.

          headers: Optional HTTP headers to send when scraping the page, such as `User-Agent`,
              `Authorization`, or cookies.

          max_age: Maximum cache age in milliseconds. If the cached scrape result is older than
              this, the page will be re-scraped. Defaults to 24 hours.

          only_main_content: Only return the main content of the page excluding headers, navs, footers, etc.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/web/scrape",
            body=await async_maybe_transform(
                {
                    "url": url,
                    "block_ads": block_ads,
                    "formats": formats,
                    "headers": headers,
                    "max_age": max_age,
                    "only_main_content": only_main_content,
                },
                web_scrape_params.WebScrapeParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebScrapeResponse,
        )

    async def search(
        self,
        *,
        query: str,
        search_type: Literal["all", "news"],
        date_range: Optional[web_search_params.DateRange] | Omit = omit,
        exclude_domains: SequenceNotStr[str] | Omit = omit,
        include_domains: SequenceNotStr[str] | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebSearchResponse:
        """Wraps Firecrawl search with finance-focused defaults.

        The raw `query` is passed
        through, `include_domains` and `exclude_domains` are appended as `site:` and
        `-site:` operators, multiple included domains are grouped with `OR`, and
        `date_range` is sent separately as Firecrawl's `tbs` parameter for `web` results
        only. When `search_type="all"`, this endpoint requests both `web` and `news`
        results and flattens them into one combined list.

        Args:
          query: Base search query text. You can include inline search operators here, such as
              exact phrases (`"..."`), excluded terms (`-term`), file extension filters
              (`filetype:pdf`), URL matching (`inurl:` and `allinurl:`), title matching
              (`intitle:` and `allintitle:`), and related-site lookup (`related:`). Prefer
              `include_domains` and `exclude_domains` over manually adding `site:` operators.
              Use `date_range` for time filtering instead of embedding time operators in the
              query.

          search_type: Search source to query. Use `all` to request both `web` and `news` results in
              one call, or `news` for news-only results. There is currently no `web`-only
              option. This field is required and has no server-side default.

          date_range: An inclusive date range for filtering web search results.

          exclude_domains: Additional domains to exclude from results. Each domain is converted into a
              `-site:` operator and merged with the default denylist.

          include_domains: Optional domains to require in results. A single domain is converted into a
              `site:` operator; multiple domains are grouped into an `OR` expression so
              matches from any included domain are allowed.

          limit: Maximum number of results requested per upstream source. With
              `search_type="all"`, up to this many `web` results and this many `news` results
              may be returned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/web/search",
            body=await async_maybe_transform(
                {
                    "query": query,
                    "search_type": search_type,
                    "date_range": date_range,
                    "exclude_domains": exclude_domains,
                    "include_domains": include_domains,
                    "limit": limit,
                },
                web_search_params.WebSearchParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebSearchResponse,
        )


class WebResourceWithRawResponse:
    def __init__(self, web: WebResource) -> None:
        self._web = web

        self.scrape = to_raw_response_wrapper(
            web.scrape,
        )
        self.search = to_raw_response_wrapper(
            web.search,
        )

    @cached_property
    def browser(self) -> BrowserResourceWithRawResponse:
        """Search and scrape webpages with finance-oriented defaults."""
        return BrowserResourceWithRawResponse(self._web.browser)


class AsyncWebResourceWithRawResponse:
    def __init__(self, web: AsyncWebResource) -> None:
        self._web = web

        self.scrape = async_to_raw_response_wrapper(
            web.scrape,
        )
        self.search = async_to_raw_response_wrapper(
            web.search,
        )

    @cached_property
    def browser(self) -> AsyncBrowserResourceWithRawResponse:
        """Search and scrape webpages with finance-oriented defaults."""
        return AsyncBrowserResourceWithRawResponse(self._web.browser)


class WebResourceWithStreamingResponse:
    def __init__(self, web: WebResource) -> None:
        self._web = web

        self.scrape = to_streamed_response_wrapper(
            web.scrape,
        )
        self.search = to_streamed_response_wrapper(
            web.search,
        )

    @cached_property
    def browser(self) -> BrowserResourceWithStreamingResponse:
        """Search and scrape webpages with finance-oriented defaults."""
        return BrowserResourceWithStreamingResponse(self._web.browser)


class AsyncWebResourceWithStreamingResponse:
    def __init__(self, web: AsyncWebResource) -> None:
        self._web = web

        self.scrape = async_to_streamed_response_wrapper(
            web.scrape,
        )
        self.search = async_to_streamed_response_wrapper(
            web.search,
        )

    @cached_property
    def browser(self) -> AsyncBrowserResourceWithStreamingResponse:
        """Search and scrape webpages with finance-oriented defaults."""
        return AsyncBrowserResourceWithStreamingResponse(self._web.browser)
