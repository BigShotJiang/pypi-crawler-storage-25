# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .document import (
    DocumentResource,
    AsyncDocumentResource,
    DocumentResourceWithRawResponse,
    AsyncDocumentResourceWithRawResponse,
    DocumentResourceWithStreamingResponse,
    AsyncDocumentResourceWithStreamingResponse,
)
from ...._types import Body, Query, Headers, NotGiven, not_given
from ...._utils import path_template
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.edgar.edgar_filing_full import EdgarFilingFull

__all__ = ["FilingResource", "AsyncFilingResource"]


class FilingResource(SyncAPIResource):
    """Direct access to SEC EDGAR filings and documents by accession number."""

    @cached_property
    def document(self) -> DocumentResource:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return DocumentResource(self._client)

    @cached_property
    def with_raw_response(self) -> FilingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return FilingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FilingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return FilingResourceWithStreamingResponse(self)

    def retrieve(
        self,
        accession_number: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EdgarFilingFull:
        """
        Retrieve an SEC filing by its accession number, including the full list of
        documents in the filing and all related entities with their relationship types
        (e.g. filer, subject company, reporting owner).

        Args:
          accession_number: The SEC accession number of the filing (e.g. '0000320193-23-000077').

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not accession_number:
            raise ValueError(f"Expected a non-empty value for `accession_number` but received {accession_number!r}")
        return self._get(
            path_template("/edgar/filing/{accession_number}", accession_number=accession_number),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EdgarFilingFull,
        )


class AsyncFilingResource(AsyncAPIResource):
    """Direct access to SEC EDGAR filings and documents by accession number."""

    @cached_property
    def document(self) -> AsyncDocumentResource:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return AsyncDocumentResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncFilingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncFilingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFilingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncFilingResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        accession_number: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EdgarFilingFull:
        """
        Retrieve an SEC filing by its accession number, including the full list of
        documents in the filing and all related entities with their relationship types
        (e.g. filer, subject company, reporting owner).

        Args:
          accession_number: The SEC accession number of the filing (e.g. '0000320193-23-000077').

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not accession_number:
            raise ValueError(f"Expected a non-empty value for `accession_number` but received {accession_number!r}")
        return await self._get(
            path_template("/edgar/filing/{accession_number}", accession_number=accession_number),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EdgarFilingFull,
        )


class FilingResourceWithRawResponse:
    def __init__(self, filing: FilingResource) -> None:
        self._filing = filing

        self.retrieve = to_raw_response_wrapper(
            filing.retrieve,
        )

    @cached_property
    def document(self) -> DocumentResourceWithRawResponse:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return DocumentResourceWithRawResponse(self._filing.document)


class AsyncFilingResourceWithRawResponse:
    def __init__(self, filing: AsyncFilingResource) -> None:
        self._filing = filing

        self.retrieve = async_to_raw_response_wrapper(
            filing.retrieve,
        )

    @cached_property
    def document(self) -> AsyncDocumentResourceWithRawResponse:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return AsyncDocumentResourceWithRawResponse(self._filing.document)


class FilingResourceWithStreamingResponse:
    def __init__(self, filing: FilingResource) -> None:
        self._filing = filing

        self.retrieve = to_streamed_response_wrapper(
            filing.retrieve,
        )

    @cached_property
    def document(self) -> DocumentResourceWithStreamingResponse:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return DocumentResourceWithStreamingResponse(self._filing.document)


class AsyncFilingResourceWithStreamingResponse:
    def __init__(self, filing: AsyncFilingResource) -> None:
        self._filing = filing

        self.retrieve = async_to_streamed_response_wrapper(
            filing.retrieve,
        )

    @cached_property
    def document(self) -> AsyncDocumentResourceWithStreamingResponse:
        """Direct access to SEC EDGAR filings and documents by accession number."""
        return AsyncDocumentResourceWithStreamingResponse(self._filing.document)
