# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ..types import email_send_params
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.email_send_response import EmailSendResponse

__all__ = ["EmailResource", "AsyncEmailResource"]


class EmailResource(SyncAPIResource):
    """Send emails via AWS SES."""

    @cached_property
    def with_raw_response(self) -> EmailResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return EmailResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EmailResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return EmailResourceWithStreamingResponse(self)

    def send(
        self,
        *,
        body: str,
        subject: str,
        to: SequenceNotStr[str],
        attachments: Iterable[email_send_params.Attachment] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        from_name: Optional[str] | Omit = omit,
        html_body: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailSendResponse:
        """
        Send an email via AWS SES.

        This is a fire-and-forget endpoint — the email is sent but not persisted to any
        database or thread.

        Args:
          body: Plain-text email body.

          subject: Email subject line.

          to: List of recipient email addresses.

          attachments: Attachments to include with the email.

          bcc: List of BCC email addresses.

          cc: List of CC email addresses.

          from_name: Display name for the sender. Defaults to "Village".

          html_body: HTML email body.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/email/send",
            body=maybe_transform(
                {
                    "body": body,
                    "subject": subject,
                    "to": to,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                    "from_name": from_name,
                    "html_body": html_body,
                },
                email_send_params.EmailSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailSendResponse,
        )


class AsyncEmailResource(AsyncAPIResource):
    """Send emails via AWS SES."""

    @cached_property
    def with_raw_response(self) -> AsyncEmailResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEmailResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEmailResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncEmailResourceWithStreamingResponse(self)

    async def send(
        self,
        *,
        body: str,
        subject: str,
        to: SequenceNotStr[str],
        attachments: Iterable[email_send_params.Attachment] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        from_name: Optional[str] | Omit = omit,
        html_body: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailSendResponse:
        """
        Send an email via AWS SES.

        This is a fire-and-forget endpoint — the email is sent but not persisted to any
        database or thread.

        Args:
          body: Plain-text email body.

          subject: Email subject line.

          to: List of recipient email addresses.

          attachments: Attachments to include with the email.

          bcc: List of BCC email addresses.

          cc: List of CC email addresses.

          from_name: Display name for the sender. Defaults to "Village".

          html_body: HTML email body.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/email/send",
            body=await async_maybe_transform(
                {
                    "body": body,
                    "subject": subject,
                    "to": to,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                    "from_name": from_name,
                    "html_body": html_body,
                },
                email_send_params.EmailSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailSendResponse,
        )


class EmailResourceWithRawResponse:
    def __init__(self, email: EmailResource) -> None:
        self._email = email

        self.send = to_raw_response_wrapper(
            email.send,
        )


class AsyncEmailResourceWithRawResponse:
    def __init__(self, email: AsyncEmailResource) -> None:
        self._email = email

        self.send = async_to_raw_response_wrapper(
            email.send,
        )


class EmailResourceWithStreamingResponse:
    def __init__(self, email: EmailResource) -> None:
        self._email = email

        self.send = to_streamed_response_wrapper(
            email.send,
        )


class AsyncEmailResourceWithStreamingResponse:
    def __init__(self, email: AsyncEmailResource) -> None:
        self._email = email

        self.send = async_to_streamed_response_wrapper(
            email.send,
        )
