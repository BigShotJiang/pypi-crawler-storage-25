# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EmailSendResponse"]


class EmailSendResponse(BaseModel):
    """Response returned after successfully sending an email."""

    ses_message_id: str
    """The AWS SES message ID for tracking."""
