# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["BrowserCreateParams"]


class BrowserCreateParams(TypedDict, total=False):
    activity_ttl: int
    """Seconds of inactivity before session is destroyed (10-3600)."""

    ttl: int
    """Total session lifetime in seconds (30-3600).

    Defaults to server-side value when omitted.
    """
