# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["BrowserDeleteResponse"]


class BrowserDeleteResponse(BaseModel):
    """Successful browser session deletion response."""

    success: bool
    """Whether the session was successfully destroyed."""

    credits_billed: Optional[float] = None
    """Number of credits billed for the session."""

    session_duration_ms: Optional[int] = None
    """Total session duration in milliseconds."""
