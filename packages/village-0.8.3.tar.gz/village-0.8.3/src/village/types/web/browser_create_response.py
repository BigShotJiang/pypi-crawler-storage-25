# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["BrowserCreateResponse"]


class BrowserCreateResponse(BaseModel):
    """Successful browser session creation response."""

    id: str
    """Unique session identifier."""

    cdp_url: str
    """WebSocket URL for Chrome DevTools Protocol access."""

    expires_at: Optional[str] = None
    """ISO-8601 timestamp when the session expires."""
