# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["EdgarListFilingsParams"]


class EdgarListFilingsParams(TypedDict, total=False):
    earliest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include filings with a filing date on or after this date (inclusive).

    This filters on the SEC filing date, not the period of report.
    """

    form_categories: Optional[SequenceNotStr[str]]
    """Form category keys to filter by (e.g.

    `INSIDER_TRADING`, `NEWS`). Repeat the parameter to specify multiple values.
    Each category expands into its member form types and is unioned with any
    explicit `form_types`. Use the `GET /edgar/form-categories` endpoint to discover
    available categories.
    """

    form_types: Optional[SequenceNotStr[str]]
    """SEC form type codes to filter by (e.g.

    `10-K`, `8-K`, `4`). Repeat the parameter to specify multiple values.
    """

    latest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include filings with a filing date on or before this date (inclusive).

    This filters on the SEC filing date, not the period of report.
    """

    page: int
    """Page number (1-based)."""

    page_size: int
    """Number of filings per page."""
