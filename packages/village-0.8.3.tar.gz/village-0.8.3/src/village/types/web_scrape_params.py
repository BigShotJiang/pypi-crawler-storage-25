# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

__all__ = ["WebScrapeParams", "Format", "FormatWebScrapeScreenshotFormat", "FormatWebScrapeScreenshotFormatViewport"]


class WebScrapeParams(TypedDict, total=False):
    url: Required[str]
    """HTTP(S) URL of the webpage to scrape."""

    block_ads: bool
    """Whether to block ads and cookie consent banners while scraping."""

    formats: Iterable[Format]
    """Requested scrape output formats.

    Defaults to `['markdown']`. Mix `markdown`, `html`, `rawHtml`, and screenshot
    configurations to retrieve multiple representations in one scrape.
    """

    headers: Optional[Dict[str, str]]
    """
    Optional HTTP headers to send when scraping the page, such as `User-Agent`,
    `Authorization`, or cookies.
    """

    max_age: int
    """Maximum cache age in milliseconds.

    If the cached scrape result is older than this, the page will be re-scraped.
    Defaults to 24 hours.
    """

    only_main_content: bool
    """Only return the main content of the page excluding headers, navs, footers, etc."""


class FormatWebScrapeScreenshotFormatViewport(TypedDict, total=False):
    """Viewport dimensions in pixels for the screenshot render."""

    height: Required[int]
    """Viewport height in pixels for the screenshot render."""

    width: Required[int]
    """Viewport width in pixels for the screenshot render."""


class FormatWebScrapeScreenshotFormat(TypedDict, total=False):
    type: Required[Literal["screenshot"]]
    """Discriminator for screenshot scrape output."""

    full_page: bool
    """Whether to capture the full page instead of only the viewport."""

    viewport: FormatWebScrapeScreenshotFormatViewport
    """Viewport dimensions in pixels for the screenshot render."""


Format: TypeAlias = Union[Literal["markdown", "html", "rawHtml"], FormatWebScrapeScreenshotFormat]
