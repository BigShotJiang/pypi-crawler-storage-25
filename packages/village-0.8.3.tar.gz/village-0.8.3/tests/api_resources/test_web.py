# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types import WebScrapeResponse, WebSearchResponse
from village._utils import parse_date

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWeb:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_scrape(self, client: Village) -> None:
        web = client.web.scrape(
            url="https://example.com",
        )
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_scrape_with_all_params(self, client: Village) -> None:
        web = client.web.scrape(
            url="https://example.com",
            block_ads=True,
            formats=["markdown"],
            headers={"foo": "string"},
            max_age=0,
            only_main_content=True,
        )
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_scrape(self, client: Village) -> None:
        response = client.web.with_raw_response.scrape(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        web = response.parse()
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_scrape(self, client: Village) -> None:
        with client.web.with_streaming_response.scrape(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            web = response.parse()
            assert_matches_type(WebScrapeResponse, web, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_search(self, client: Village) -> None:
        web = client.web.search(
            query="x",
            search_type="all",
        )
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_search_with_all_params(self, client: Village) -> None:
        web = client.web.search(
            query="x",
            search_type="all",
            date_range={
                "end_date": parse_date("2019-12-27"),
                "start_date": parse_date("2019-12-27"),
            },
            exclude_domains=["string"],
            include_domains=["string"],
            limit=1,
        )
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_search(self, client: Village) -> None:
        response = client.web.with_raw_response.search(
            query="x",
            search_type="all",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        web = response.parse()
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_search(self, client: Village) -> None:
        with client.web.with_streaming_response.search(
            query="x",
            search_type="all",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            web = response.parse()
            assert_matches_type(WebSearchResponse, web, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncWeb:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_scrape(self, async_client: AsyncVillage) -> None:
        web = await async_client.web.scrape(
            url="https://example.com",
        )
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_scrape_with_all_params(self, async_client: AsyncVillage) -> None:
        web = await async_client.web.scrape(
            url="https://example.com",
            block_ads=True,
            formats=["markdown"],
            headers={"foo": "string"},
            max_age=0,
            only_main_content=True,
        )
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_scrape(self, async_client: AsyncVillage) -> None:
        response = await async_client.web.with_raw_response.scrape(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        web = await response.parse()
        assert_matches_type(WebScrapeResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_scrape(self, async_client: AsyncVillage) -> None:
        async with async_client.web.with_streaming_response.scrape(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            web = await response.parse()
            assert_matches_type(WebScrapeResponse, web, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_search(self, async_client: AsyncVillage) -> None:
        web = await async_client.web.search(
            query="x",
            search_type="all",
        )
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_search_with_all_params(self, async_client: AsyncVillage) -> None:
        web = await async_client.web.search(
            query="x",
            search_type="all",
            date_range={
                "end_date": parse_date("2019-12-27"),
                "start_date": parse_date("2019-12-27"),
            },
            exclude_domains=["string"],
            include_domains=["string"],
            limit=1,
        )
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_search(self, async_client: AsyncVillage) -> None:
        response = await async_client.web.with_raw_response.search(
            query="x",
            search_type="all",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        web = await response.parse()
        assert_matches_type(WebSearchResponse, web, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_search(self, async_client: AsyncVillage) -> None:
        async with async_client.web.with_streaming_response.search(
            query="x",
            search_type="all",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            web = await response.parse()
            assert_matches_type(WebSearchResponse, web, path=["response"])

        assert cast(Any, response.is_closed) is True
