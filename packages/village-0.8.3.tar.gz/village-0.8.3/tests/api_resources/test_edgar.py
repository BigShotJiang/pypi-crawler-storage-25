# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types import EdgarListFormCategoriesResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEdgar:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_form_categories(self, client: Village) -> None:
        edgar = client.edgar.list_form_categories()
        assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_form_categories(self, client: Village) -> None:
        response = client.edgar.with_raw_response.list_form_categories()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        edgar = response.parse()
        assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_form_categories(self, client: Village) -> None:
        with client.edgar.with_streaming_response.list_form_categories() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            edgar = response.parse()
            assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncEdgar:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_form_categories(self, async_client: AsyncVillage) -> None:
        edgar = await async_client.edgar.list_form_categories()
        assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_form_categories(self, async_client: AsyncVillage) -> None:
        response = await async_client.edgar.with_raw_response.list_form_categories()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        edgar = await response.parse()
        assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_form_categories(self, async_client: AsyncVillage) -> None:
        async with async_client.edgar.with_streaming_response.list_form_categories() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            edgar = await response.parse()
            assert_matches_type(EdgarListFormCategoriesResponse, edgar, path=["response"])

        assert cast(Any, response.is_closed) is True
