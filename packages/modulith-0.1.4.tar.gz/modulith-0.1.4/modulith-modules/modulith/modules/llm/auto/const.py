KNOWN_MODELS = {
    "gpt-5.4": "openai",
    "gpt-5.4-pro": "openai",
    "gpt-5.4-mini": "openai",
    "gpt-5.4-nano": "openai",
}