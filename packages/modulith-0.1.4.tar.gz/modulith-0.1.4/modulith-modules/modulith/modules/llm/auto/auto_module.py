from typing import Literal
from .const import KNOWN_MODELS
from modulith.modules.llm.base_classes import BaseChatModule


def get_chat_module(
    model_name: str, 
    variation: Literal["chat", "completions", "response"] = "chat", 
    **kwargs
) -> BaseChatModule:
    if provider is None and model_name in KNOWN_MODELS:
        provider = KNOWN_MODELS[model_name]
    else:
        raise NameError("Get unknown model name. Please provide name of the provider.")

    if provider == "openai":
        try:
            from modulith.modules.llm.openai import OpenAIChatModule, OpenAICompletionModule, OpenAIResponseModule
        except ImportError:
            raise ImportError("Please 'pip install modulith-modules-llms-openai' before using the OpenAI chat module.")
        if variation == "chat":
            return OpenAIChatModule(model_name, **kwargs)
        elif variation == "completions":
            return OpenAICompletionModule(model_name, **kwargs)
        else:
            return OpenAIResponseModule(model_name, **kwargs)
    
    elif provider == "openrouter":
        try:
            from modulith.modules.llm.openrouter import OpenRouterChatModule, OpenRouterCompletionModule, OpenRouterResponseModule
        except ImportError:            
            raise ImportError("Please 'pip install modulith-modules-llms-openrouter' before using the OpenRouter chat module.")
        if variation == "chat":
            return OpenRouterChatModule(model_name, **kwargs)
        elif variation == "completions":
            return OpenRouterCompletionModule(model_name, **kwargs)
        else:
            return OpenRouterResponseModule(model_name, **kwargs)
    
    elif provider == "selfhosted" or provider == "openai-compatible":
        try:
            from modulith.modules.llm.openai_compatible import OpenAICompatibleChatModule, OpenAICompatibleCompletionModule, OpenAICompatibleResponseModule
        except ImportError:
            raise ImportError("Please 'pip install modulith-modules-llms-openai-compatible' before using the OpenAI-Compatible chat module.")
        if variation == "chat":
            return OpenAICompatibleChatModule(model_name, **kwargs)
        elif variation == "completions":
            return OpenAICompatibleCompletionModule(model_name, **kwargs)
        else:
            return OpenAICompatibleResponseModule(model_name, **kwargs)
    
    else:
        raise ValueError(f"Unsupported chat provider: {provider}")

class AutoChatModule:
    def __init__(self, name: str, **kwargs) -> BaseChatModule:
        return get_chat_module(name, variation="chat", **kwargs)
    
class AutoCompletionsModule:
    def __init__(self, name: str, **kwargs) -> BaseChatModule:
        return get_chat_module(name, variation="completions", **kwargs)
    
class AutoResponseModule:
    def __init__(self, name: str, **kwargs) -> BaseChatModule:
        return get_chat_module(name, variation="response", **kwargs)