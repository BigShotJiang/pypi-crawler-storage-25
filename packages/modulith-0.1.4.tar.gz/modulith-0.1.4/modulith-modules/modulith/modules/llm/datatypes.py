from typing import Tuple


TokenLogprob = Tuple[str | int, float]