from typing import List
from pydantic import BaseModel
from modulith.core import ModulithModule
from modulith.modules.llm.datatypes import TokenLogprob


class ChatModuleOutputSchema(BaseModel):
    answer: str  # Generated answer as a string
    logprobs: List[List[TokenLogprob]] | None = None  # List of tokens and their log probabilities

class BaseChatModule(ModulithModule):
    output_type = ChatModuleOutputSchema

class BaseCompletionModule(BaseChatModule):
    pass

class BaseResponseModule(BaseChatModule):
    pass