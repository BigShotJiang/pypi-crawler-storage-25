from typing import List
from pydantic import BaseModel
from modulith.core import ModulithModule
from modulith.core.datatypes import Embedding
from modulith.core.api_gateway import APIGateway
from modulith._modules.indexes.index_module import IndexModule
from modulith._modules.indexes.vector_indexes.dataclasses import DocumentEmbedding, QueryEmbedding


class DocumentSearchInputSchema(BaseModel):
    query: str | None = None
    documents: List[str] | None = None
    top_k: int = 5

class DocumentSearchOutputSchema(BaseModel):
    search_results: List[str] | None = None

class DocumentSearchModule(ModulithModule):
    input_schema = DocumentSearchInputSchema
    output_schema = DocumentSearchOutputSchema

    def __init__(
        self, 
        name: str, 
        index_module: APIGateway | IndexModule,
        **kwargs
    ):
        super().__init__(name)
        self.index_module = index_module

    def _pipeline(self, input_data: dict) -> dict:
        query = input_data.get("query")
        documents = input_data.get("documents")
        top_k = input_data.get("top_k", 5)

        index_input = {}
        if documents:
            embeddings: List[Embedding] = self.embedding_model(contents=documents)
            index_input = {
                "documents": [
                    DocumentEmbedding(content=document, embedding=embedding) 
                    for document, embedding in zip(documents, embeddings)
                ]
            }

        if query:
            embeddings: List[Embedding] = self.embedding_model(contents=query)
            index_input["query"] = QueryEmbedding(content=query, embedding=embeddings[0])
            index_input["top_k"] = top_k

        output = self.index(input_data=index_input).result
        return {"search_results": output["search_results"]}