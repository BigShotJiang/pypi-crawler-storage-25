from typing import List, Any
from pydantic import BaseModel
from abc import abstractmethod
from modulith.core import ModulithModule


class RetrievedDocument(BaseModel):
    content: str
    score: float

    @property
    def id(self) -> str:
        # Generate a unique ID for the document based on its content using sha256 hashing
        import hashlib
        hash_object = hashlib.sha256(self.content.encode())
        hash = hash_object.hexdigest()
        return hash

class BaseIndexModule(ModulithModule):
    output_type = List[RetrievedDocument] | None

    @classmethod
    def from_documents(cls, name: str, documents: List[Any], collection_name: str = "default_collection", **kwargs):
        instance = cls(name, **kwargs)
        instance.add(documents=documents, collection_name=collection_name, **kwargs)
        return instance

    @abstractmethod
    def add(self, documents: List[Any], collection_name: str = "default_collection", **kwargs):
        pass

    @abstractmethod
    def remove(self, documents: List[Any] | None = None, collection_name: str = "default_collection", **kwargs):
        pass

    @abstractmethod
    def search(self, query: Any, top_k: int = 5, collection_name: str = "default_collection", **kwargs) -> List[dict]:
        pass
    
    def _implementation(
        self, 
        *, 
        query: Any | None = None, 
        add_documents: List[Any] | None = None,
        remove_documents: List[Any] | None = None,
        collection_name: str = "default_collection",
        top_k: int = 5,
        **kwargs
    ) -> dict:
        if add_documents:
            self.add(documents=add_documents, collection_name=collection_name, **kwargs)
        
        if remove_documents:
            self.remove(documents=remove_documents, collection_name=collection_name, **kwargs)
        
        results = None
        if query:
            results = self.search(query=query, top_k=top_k, collection_name=collection_name, **kwargs)
        return {"results": results}