from pydantic import BaseModel
from typing import Optional, List
from modulith.core import ModulithModule
from modulith.core.baseclasses import BaseClient
from modulith.core.api_gateway import APIGateway


class GenerativeAgentModuleInputSchema(BaseModel):
    messages: List[dict]
    tools: Optional[List[dict]] = None
    output_schema: Optional[type[BaseModel]] = None
    max_retries: int = 5

class GenerativeAgentModuleOutputSchema(BaseModel):
    answer: str | dict

class GenerativeAgentModule(ModulithModule):
    input_schema = GenerativeAgentModuleInputSchema
    output_schema = GenerativeAgentModuleOutputSchema

    def __init__(
        self, 
        name: str, 
        llm_model: str | APIGateway | BaseClient,
        system_prompt: str = None,
    ):
        super().__init__(name)
        self.llm_model = llm_model
        self.system_prompt = system_prompt

    def _implementation(
        self, 
        *
        messages: List[dict],
        max_retries: int = 5,
        output_schema: type[BaseModel] | None = None,
        **kwargs,
    ) -> dict:
        # Handle system prompt if provided
        if self.system_prompt:
            assert messages[0]["role"] != "system", "System prompt cannot be provided if the first message already has the role 'system'."
            messages.insert(0, {"role": "system", "content": self.system_prompt})

        # Handle output schema if provided
        if output_schema:
            # Create output schema instructions based on the provided output schema
            output_schema_instructions = (
                "You must produce the final output that strictly follows the JSON schema provided below.\n\n"

                "JSON Schema:\n"
                "{json_schema}"
            ).format(json_schema=output_schema.model_json_schema())
            # Append output schema instructions to input content
            messages[-1]["content"] += f"\n\n{output_schema_instructions}"
            
            # If output schema is provided, we will attempt to validate the output and retry if it doesn't match the schema
            success = False
            for _ in range(max_retries):
                answer = self.llm_model(messages=messages, **kwargs).choices[0].message.content
                try:
                    answer = output_schema.model_validate_json(answer).model_dump()
                    success = True
                    break
                except Exception as e:
                    pass
            if not success:
                raise ValueError("Failed to generate a valid response after multiple attempts.")
        else:
            answer = self.llm_model(messages=messages, **kwargs).choices[0].message.content
        return {"answer": answer}