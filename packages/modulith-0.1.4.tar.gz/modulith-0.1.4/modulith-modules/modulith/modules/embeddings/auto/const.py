KNOWN_MODELS = {
    "text-embedding-3-small": "openai",
    "text-embedding-3-large": "openai",
}