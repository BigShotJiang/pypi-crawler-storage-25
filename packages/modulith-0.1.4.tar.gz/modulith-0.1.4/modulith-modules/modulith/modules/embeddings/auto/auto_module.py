from .const import KNOWN_MODELS
from modulith.modules.embeddings.base_classes import BaseEmbeddingModule


def get_embedding_module(model_name: str, provider: str | None = None, **kwargs) -> BaseEmbeddingModule:
    if provider is None and model_name in KNOWN_MODELS:
        provider = KNOWN_MODELS[model_name]
    else:
        raise NameError("Get unknown model name. Please provide name of the provider.")

    if provider == "openai":
        try:
            from modulith.modules.embeddings.openai import OpenAIEmbeddingModule
        except ImportError:
            raise ImportError("Please 'pip install modulith-modules-embeddings-openai' before using the OpenAI embedding module.")
        return OpenAIEmbeddingModule(model_name, **kwargs)
    
    elif provider == "openrouter":
        try:
            from modulith.modules.embeddings.openrouter import OpenRouterEmbeddingModule
        except ImportError:            
            raise ImportError("Please 'pip install modulith-modules-embeddings-openrouter' before using the OpenRouter embedding module.")
        return OpenRouterEmbeddingModule(model_name, **kwargs)
    
    elif provider == "selfhosted" or provider == "openai-compatible":
        try:
            from modulith.modules.embeddings.openai_compatible import OpenAICompatibleEmbeddingModule
        except ImportError:
            raise ImportError("Please 'pip install modulith-modules-embeddings-openai-compatible' before using the OpenAI-Compatible embedding module.")
        return OpenAICompatibleEmbeddingModule(model_name, **kwargs)
    
    else:
        raise ValueError(f"Unsupported embedding provider: {provider}")

class AutoEmbeddingModule:
    def __init__(self, model_name: str = "text-embedding-3-small", provider: str | None = None, **kwargs) -> BaseEmbeddingModule:
        return get_embedding_module(model_name, provider=provider, **kwargs)