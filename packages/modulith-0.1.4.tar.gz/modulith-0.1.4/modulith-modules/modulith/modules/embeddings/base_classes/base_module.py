from typing import List
from modulith.core import ModulithModule
from modulith.modules.embeddings.datatypes import Embedding


class BaseEmbeddingModule(ModulithModule):
    output_type = List[Embedding]