from typing import List
from modulith.core import ModulithModule
from modulith.modules.index.base_classes.base_module import RetrievedDocument


class ReciprocalRankFusionModule(ModulithModule):
    def _implementation(self, lst_contents: List[List[RetrievedDocument]], k: int = 60, **kwargs):
        """
        Implements Reciprocal Rank Fusion (RRF) to combine multiple rankings into a single ranking.

        Args:
            lst_contents (List[List[RetrievedDocument]]): A list of rankings, where each ranking is a list of RetrievedDocument objects.
            k (int): The parameter for RRF that controls the influence of lower-ranked documents.

        Returns:
            List[RetrievedDocument]: A single fused ranking of document contents.
        """
        # Create a dictionary to store the RRF scores for each document
        rrf_scores = {}
        doc_id_to_content = {}

        # Iterate over each ranking and calculate the RRF score for each document
        for contents in lst_contents:
            for i, content in enumerate(contents):
                rrf_score = 1 / (k + i)  # Calculate the RRF score based on the rank position
                if content.id in rrf_scores:
                    rrf_scores[content.id] += rrf_score  # Accumulate the RRF score if the document appears in multiple rankings
                else:
                    rrf_scores[content.id] = rrf_score  # Initialize the RRF score for new documents
                    doc_id_to_content[content.id] = content.content  # Store the content of the document

        # Sort the documents by their RRF scores in descending order
        fused_indices = sorted(rrf_scores.keys(), key=lambda doc_id: rrf_scores[doc_id], reverse=True)
        fused_contents = [RetrievedDocument(id=doc_id, content=doc_id_to_content[doc_id]).model_dump() for doc_id in fused_indices]

        return fused_contents