from xai_sdk import Client
from modulith.core import ModulithModule


class xAIVideoGenerationModule(ModulithModule):
    output_type = str

    def __init__(self, *args, model: str = "grok-imagine-video", **kwargs):
        super().__init__(*args, **kwargs)
        self.client = Client()
        self.model = model

    def _implementation(
        self, 
        prompt: str, 
        image_url: str | None = None,
        video_url: str | None = None,
        duration: int | None = 10,
        aspect_ratio: str | None = "16:9",
        resolution: str | None = "720p",
        **kwargs
    ) -> str:
        response = self.client.video.generate(
            model=self.model,
            prompt=prompt,
            image_url=image_url,
            video_url=video_url,
            duration=duration,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs
        )
        return response.url