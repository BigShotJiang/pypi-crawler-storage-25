import requests
from modulith.modules.video_generation.xai import xAIVideoGenerationModule


def test_video_generation():
    module = xAIVideoGenerationModule(model="grok-imagine-video")
    video_url = module(
        prompt="A timelapse of a sunset",
        duration=5,
        aspect_ratio="16:9",
        resolution="720p",
    )
    # Save to disk by reading the whole video content into memory (not recommended for large videos)
    with open("generated_video_whole.mp4", "wb") as f:
        f.write(requests.get(video_url).content)
    # Save to disk by streaming the video content (recommended for large videos)
    with requests.get(video_url, stream=True) as r:
        r.raise_for_status()
        with open("generated_video_streamed.mp4", "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)


if __name__ == "__main__":
    test_video_generation()