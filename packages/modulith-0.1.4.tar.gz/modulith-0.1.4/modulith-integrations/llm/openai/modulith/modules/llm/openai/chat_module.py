from typing import List
from openai import OpenAI
from modulith.modules.llm.base_classes import BaseChatModule


class OpenAIChatModule(BaseChatModule):
    def __init__(self, model_name: str, **kwargs):
        super().__init__()
        self.model_name = model_name
        self.client = OpenAI(**kwargs)

    def _implementation(self, *, messages: List[dict], logprobs: int | None = None, **kwargs) -> dict:
        output = self.client.chat.completions.create(
            model=self.model_name,
            messages=messages,
            logprobs=logprobs and logprobs > 0,
            top_logprobs=logprobs,
            **kwargs
        )
        return {
            "answer": output.choices[0].message.content, 
            "logprobs": [[(top_logprob.token, top_logprob.logprob) for top_logprob in content.top_logprobs] for content in output.choices[0].logprobs.content] if logprobs and logprobs > 0 else None,
        }