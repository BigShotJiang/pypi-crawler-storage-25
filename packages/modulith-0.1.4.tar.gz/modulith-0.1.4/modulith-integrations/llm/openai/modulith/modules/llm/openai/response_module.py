from typing import List
from openai import OpenAI
from modulith.modules.llm.base_classes import BaseResponseModule


class OpenAIResponseModule(BaseResponseModule):
    def __init__(self, model_name: str, **kwargs):
        super().__init__()
        self.model_name = model_name
        self.client = OpenAI(**kwargs)

    def _implementation(self, *, input: str | List[dict], instructions: str | None = None, **kwargs) -> dict:
        output = self.client.responses.create(
            model=self.model_name,
            input=input,
            instructions=instructions,
            **kwargs
        )
        return {
            "answer": output.output_text, 
        }