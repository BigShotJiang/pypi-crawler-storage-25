from openai import OpenAI
from modulith.modules.llm.base_classes import BaseCompletionModule


class OpenAICompletionModule(BaseCompletionModule):
    def __init__(self, model_name: str, **kwargs):
        super().__init__()
        self.model_name = model_name
        self.client = OpenAI(**kwargs)

    def _implementation(self, *, prompt: str, logprobs: int | None = None, **kwargs) -> dict:
        output = self.client.completions.create(
            model=self.model_name,
            prompt=prompt,
            logprobs=logprobs,
            **kwargs
        )
        return {
            "answer": output.choices[0].text, 
            "logprobs": [[(token, logprob) for token, logprob in top_logprob.items()] for top_logprob in output.choices[0].logprobs.top_logprobs] if logprobs and logprobs > 0 else None,
        }