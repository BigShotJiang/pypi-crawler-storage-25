from modulith.modules.llm.openai import OpenAIResponseModule


class OpenAICompatibleResponseModule(OpenAIResponseModule):
    def __init__(self, model_name: str, base_url: str, **kwargs):
        super().__init__(model_name=model_name, base_url=base_url, **kwargs)