from modulith.modules.llm.xai import XAIChatModule


def test_llm():
    module = XAIChatModule(model_name="grok-4-1-fast-reasoning")
    response = module(
        messages=[
            {"role": "user", "content": "Hello, how are you?"}
        ],
        logprobs=5
    )
    print(response)


if __name__ == "__main__":
    test_llm()