from typing import List
from xai_sdk import Client
from xai_sdk.chat import user, system, assistant
from modulith.modules.llm.base_classes import BaseChatModule


class XAIChatModule(BaseChatModule):
    def __init__(self, model_name: str = "grok-4-1-fast-reasoning", **kwargs):
        super().__init__()
        self.model_name = model_name
        self.client = Client(**kwargs)

    def _implementation(self, *, messages: List[dict], logprobs: int | None = None, **kwargs) -> dict:
        inputs = []
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            if role == "user":
                inputs.append(user(content))
            elif role == "system":
                inputs.append(system(content))
            elif role == "assistant":
                inputs.append(assistant(content))
            else:
                raise ValueError(f"Unsupported role: {role}")
        
        output = self.client.chat.create(
            model=self.model_name, 
            messages=inputs,
            logprobs=logprobs and logprobs > 0,
            top_logprobs=logprobs,
            **kwargs
        ).sample()
        
        return {
            "answer": output.content,
            "logprobs": [[(token_logprob.token, token_logprob.logprob) for token_logprob in content.top_logprobs] for content in output.logprobs.content] if logprobs and logprobs > 0 else None,
        }