from typing import List
from xai_sdk import Client
from modulith.core import ModulithModule


class xAIImageGenerationModule(ModulithModule):
    output_type = str

    def __init__(self, *args, model: str = "grok-imagine-image", **kwargs):
        super().__init__(*args, **kwargs)
        self.client = Client()
        self.model = model

    def _implementation(
        self, 
        prompt: str, 
        image_url: str | None = None,
        image_urls: List[str] | None = None,
        aspect_ratio: str | None = "16:9",
        resolution: str | None = "1k",
        **kwargs
    ) -> str:
        response = self.client.image.sample(
            model=self.model,
            prompt=prompt,
            image_url=image_url,
            image_urls=image_urls,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs
        )
        return response.url