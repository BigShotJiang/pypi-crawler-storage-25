import requests
from modulith.modules.image_generation.xai import xAIImageGenerationModule


def test_image_generation():
    module = xAIImageGenerationModule(model="grok-imagine-image")
    image_url = module(
        prompt="A beautiful landscape with mountains and a river",
        aspect_ratio="16:9",
        resolution="1k",
    )
    # Save to disk by reading the whole image content into memory (not recommended for large images)
    with open("generated_image_whole.png", "wb") as f:
        f.write(requests.get(image_url).content)
    # Save to disk by streaming the image content (recommended for large images)
    with requests.get(image_url, stream=True) as r:
        r.raise_for_status()
        with open("generated_image_streamed.png", "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)


if __name__ == "__main__":
    test_image_generation()