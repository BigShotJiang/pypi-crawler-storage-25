import os
import requests
from xai_sdk import Client
from typing import Literal
from modulith.core import ModulithModule


class xAITTSModule(ModulithModule):
    output_type = bytes

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.client = Client()

    def _implementation(
        self, 
        text: str, 
        voice_id: Literal["eve", "ara", "rex", "sal", "leo"] = "eve",
        language: Literal["auto", "en", "ar-EG", "ar-SA", "ar-AE", "bn", "zh", "fr", "de", "hi", "id", "it", "ja", "ko", "pt-BR", "pt-PT", "ru", "es-MX", "es-ES", "tr", "vi"] = "auto",
        output_format: dict | None = None,
        **kwargs
    ) -> bytes:
        input_data = {
            "text": text,
            "voice_id": voice_id,
            "language": language,
            **kwargs
        }
        if output_format:
            input_data["output_format"] = output_format

        response = requests.post(
            "https://api.x.ai/v1/tts",
            headers={
                "Authorization": f"Bearer {os.environ['XAI_API_KEY']}",
                "Content-Type": "application/json",
            },
            json=input_data,
        )
        return response.content