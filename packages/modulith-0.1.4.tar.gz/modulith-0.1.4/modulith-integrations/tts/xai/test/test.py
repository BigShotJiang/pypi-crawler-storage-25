from modulith.modules.tts.xai import xAITTSModule


def test_text_to_speech():
    module = xAITTSModule()
    audio_content = module(
        text="Hello, world!",
        voice_id="eve",
        language="en",
    )
    with open("generated_audio_whole.mp3", "wb") as f:
        f.write(audio_content)


if __name__ == "__main__":
    test_text_to_speech()