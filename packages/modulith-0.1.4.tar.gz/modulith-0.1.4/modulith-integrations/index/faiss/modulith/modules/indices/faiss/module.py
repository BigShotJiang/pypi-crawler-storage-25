import faiss
import pickle
import numpy as np
from typing import List
from pydantic import BaseModel
from modulith.core import APIGateway
from modulith.modules.embedding.auto import AutoEmbeddingModule
from modulith.modules.index.base_classes import BaseIndexModule
from modulith.modules.embedding.base_classes import BaseEmbeddingModule


class EmbeddedContent(BaseModel):
    content: str
    embedding: List[float]

class FaissVectorStoreModule(BaseIndexModule):
    def __init__(
        self, 
        name: str, 
        index_method: type[faiss.Index] = faiss.IndexFlatIP, 
        persistent_path: str | None = None,
        **kwargs
    ):
        super().__init__(name=name, **kwargs)
        self.persistent_path = persistent_path
        self.index_method = index_method
        self.collections = {}
    
    @classmethod
    def from_persistent_path(cls, name: str, persistent_path: str, **kwargs):
        instance = cls(name, persistent_path=persistent_path, **kwargs)
        instance.load_index()
        return instance

    def dump_index(self):
        if self.persistent_path and len(self.collections) > 0:
            for collection_name, collection in self.collections.items():
                # Save the FAISS index
                faiss.write_index(collection["index"], f"{self.persistent_path}/{collection_name}.faiss_index")
                # Save contents as well using pickle
                with open(f"{self.persistent_path}/{collection_name}.contents.pkl", "wb") as f:
                    pickle.dump(collection["contents"], f)

    def load_index(self):
        if self.persistent_path:
            import os
            for filename in os.listdir(self.persistent_path):
                if filename.endswith(".faiss_index"):
                    collection_name = filename.replace(".faiss_index", "")
                    # Load the FAISS index
                    self.collections[collection_name] = {"index": faiss.read_index(os.path.join(self.persistent_path, filename)), "contents": []}
                    # Load contents as well using pickle
                    with open(f"{self.persistent_path}/{collection_name}.contents.pkl", "rb") as f:
                        self.collections[collection_name]["contents"] = pickle.load(f)

    def _create_index(self, contents: List[EmbeddedContent]) -> faiss.Index:
        dim = len(contents[0].embedding)

        if self.index_method == faiss.IndexFlatIP:
            index = faiss.IndexFlatIP(dim)

        elif self.index_method == faiss.IndexFlatL2:
            index = faiss.IndexFlatL2(dim)

        elif self.index_method == faiss.IndexIVFFlat:
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFFlat(quantizer, dim, nlist=100)
            index.train(np.array([cont.embedding for cont in contents], dtype=np.float32))

        elif self.index_method == faiss.IndexHNSWFlat:
            index = faiss.IndexHNSWFlat(dim, M=32)

        elif self.index_method == faiss.IndexPQ:
            index = faiss.IndexPQ(dim, M=16, nbits_per_index=8)
            index.train(np.array([cont.embedding for cont in contents], dtype=np.float32))

        elif self.index_method == faiss.IndexLSH:
            index = faiss.IndexLSH(dim, nbits=128)

        elif self.index_method == faiss.IndexScalarQuantizer:
            index = faiss.IndexScalarQuantizer(dim, faiss.ScalarQuantizer.QT_4bit)
            index.train(np.array([cont.embedding for cont in contents], dtype=np.float32))

        elif self.index_method == faiss.IndexIVFPQ:
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFPQ(quantizer, dim, nlist=100, M=16, nbits_per_index=8)
            index.train(np.array([cont.embedding for cont in contents], dtype=np.float32))

        elif self.index_method == faiss.IndexIVFPQR:
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFPQR(quantizer, dim, nlist=100, M=16, nbits_per_index=8)
            index.train(np.array([cont.embedding for cont in contents], dtype=np.float32))

        else:
            raise ValueError(f"Unsupported index method: {self.index_method}")
        
        return index

    def add(self, contents: List[EmbeddedContent], collection_name: str = "default_collection", **kwargs):
        if collection_name not in self.collections:
            self.collections[collection_name] = {"index": None, "contents": []}
            self.collections[collection_name]["index"] = self._create_index(contents)
        self.collections[collection_name]["contents"].extend(contents)
        self.collections[collection_name]["index"].add(np.array([cont.embedding for cont in contents], dtype=np.float32))

    def remove(self, contents: List[EmbeddedContent] | None = None, collection_name: str = "default_collection", **kwargs):
        """Note: Faiss does not support removing specific vectors from the index, so this method will rebuild the index without the specified contents."""
        if collection_name not in self.collections:
            raise ValueError(f"Collection '{collection_name}' does not exist.")
        collection = self.collections.pop(collection_name)
        if contents is not None:
            remaining_contents = []
            for cont in collection["contents"]:
                to_remove = False
                for target_cont in contents:
                    if cont.content == target_cont.content:
                        to_remove = True
                        break
                if not to_remove:
                    remaining_contents.append(cont)
            if remaining_contents:
                self.collections[collection_name] = {"index": self._create_index(remaining_contents), "contents": remaining_contents}

    def search(self, query: EmbeddedContent, top_k: int = 5, collection_name: str = "default_collection", **kwargs) -> List[dict]:
        if collection_name not in self.collections:
            raise ValueError(f"Collection '{collection_name}' does not exist.")
        index: faiss.Index = self.collections[collection_name]["index"]
        distances, indices = index.search(np.array([query.embedding], dtype=np.float32), top_k)
        return [
            {
                "content": self.collections[collection_name]["contents"][idx], 
                "score": float(dist)
            } for idx, dist in zip(indices[0], distances[0]) 
        ]
    
class FaissIndexModule(FaissVectorStoreModule):
    def __init__(
        self, 
        name: str, 
        index_method: type[faiss.Index] = faiss.IndexFlatIP, 
        embedding_module: str | APIGateway | BaseEmbeddingModule = "text-embedding-3-small",
        persistent_path: str | None = None,
        **kwargs
    ):
        super().__init__(name=name, index_method=index_method, persistent_path=persistent_path, **kwargs)
        self.embedding_module = AutoEmbeddingModule(embedding_module) if isinstance(embedding_module, str) else embedding_module

    def add(self, contents: List[str], collection_name: str = "default_collection", **kwargs):
        embeddings = self.embedding_module(contents=contents)["embeddings"]
        embedded_contents = [EmbeddedContent(content=content, embedding=embedding) for content, embedding in zip(contents, embeddings)]
        super().add(contents=embedded_contents, collection_name=collection_name, **kwargs)

    def remove(self, contents: List[str] | None = None, collection_name: str = "default_collection", **kwargs):
        embeddings = self.embedding_module(contents=contents)["embeddings"]
        embedded_contents = [EmbeddedContent(content=content, embedding=embedding) for content, embedding in zip(contents, embeddings)]
        super().remove(contents=embedded_contents, collection_name=collection_name, **kwargs)

    def search(self, query: str, top_k: int = 5, collection_name: str = "default_collection", **kwargs) -> List[dict]:
        query_embedding = self.embedding_module(contents=[query])["embeddings"][0]
        embedded_query = EmbeddedContent(content=query, embedding=query_embedding)
        return super().search(query=embedded_query, top_k=top_k, collection_name=collection_name, **kwargs)