import chromadb
from typing import List
from modulith.core import APIGateway
from modulith.modules.embedding.auto import AutoEmbeddingModule
from modulith.modules.index.base_classes import BaseIndexModule
from modulith.modules.embedding.base_classes import BaseEmbeddingModule


class ChromaDBIndexModule(BaseIndexModule):
    def __init__(
        self, 
        name: str, 
        persistent_path: str | None = None,
        embedding_module: str | APIGateway | BaseEmbeddingModule = "text-embedding-3-small",
        **kwargs
    ):
        super().__init__(name=name, **kwargs)
        self.embedding_module = AutoEmbeddingModule(embedding_module) if isinstance(embedding_module, str) else embedding_module
        self.persistent_path = persistent_path
        if persistent_path:
            self.collections = chromadb.PersistentClient(path=persistent_path)
        else:
            self.collections = chromadb.Client()

    def add(self, contents: List[str], collection_name: str = "default_collection", **kwargs):
        collection = self.collections.get_or_create_collection(name=collection_name)

        embeddings = self.embedding_module(contents=contents)["embeddings"]
        collection.add(
            ids=[str(i) for i in range(len(contents))],
            documents=contents,
            embeddings=embeddings
        )

    def remove(self, contents: List[str] | None = None, collection_name: str = "default_collection", **kwargs):
        self.collections.delete_collection(name=collection_name)
        if contents is not None:
            self.add(contents=contents, collection_name=collection_name, **kwargs)

    def search(self, query: str, top_k: int = 5, collection_name: str = "default_collection", **kwargs) -> List[dict]:
        collection = self.collections.get_collection(name=collection_name)
        query_embedding = self.embedding_module(contents=[query])["embeddings"][0]
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k
        )
        return [
            {
                "content": doc, 
                "score": float(score)
            } for doc, score in zip(results["documents"][0], results["distances"][0])
        ]