from typing import List
from bm25s import BM25, tokenize
from modulith.modules.index.base_classes import BaseIndexModule


class BM25IndexModule(BaseIndexModule):
    def __init__(
        self, 
        name: str, 
        persistent_path: str | None = None,
        **kwargs
    ):
        super().__init__(name=name, **kwargs)
        self.persistent_path = persistent_path
        self.collections = {}

    def _create_index(self, contents: List[str]) -> BM25:
        tokenized_contents = [tokenize(content) for content in contents]
        index = BM25()
        index.index(tokenized_contents)
        return index

    def add(self, contents: List[str], collection_name: str = "default_collection", **kwargs):
        if collection_name not in self.collections:
            self.collections[collection_name] = {"index": None, "contents": []}
        self.collections[collection_name]["contents"].extend(contents)
        # Create or update the BM25 index for the collection
        self.collections[collection_name]["index"] = self._create_index(self.collections[collection_name]["contents"])

    def remove(self, contents: List[str] | None = None, collection_name: str = "default_collection", **kwargs):
        if collection_name not in self.collections:
            raise ValueError(f"Collection '{collection_name}' does not exist.")
        collection = self.collections.pop(collection_name)
        if contents is not None:
            remaining_contents = []
            for cont in collection["contents"]:
                to_remove = False
                for target_cont in contents:
                    if cont == target_cont:
                        to_remove = True
                        break
                if not to_remove:
                    remaining_contents.append(cont)
            if remaining_contents:
                self.collections[collection_name] = {
                    "index": self._create_index(remaining_contents), 
                    "contents": remaining_contents
                }

    def search(self, query: str, top_k: int = 5, collection_name: str = "default_collection", **kwargs) -> List[dict]:
        query_tokens = tokenize(query)
        results, scores = self.collections[collection_name]["index"].retrieve(query_tokens, top_k=top_k)
        return [
            {
                "content": self.collections[collection_name]["contents"][idx], 
                "score": float(score)
            } for idx, score in zip(results[0], scores[0])
        ]