from typing import List
from openai import OpenAI
from modulith.modules.embeddings.base_classes import BaseEmbeddingModule


class OpenAIEmbeddingModule(BaseEmbeddingModule):
    def __init__(self, model_name: str = "text-embedding-3-small", **kwargs):
        super().__init__()
        self.model_name = model_name
        self.client = OpenAI(**kwargs)

    def _implementation(self, *, contents: str | List[str], **kwargs) -> dict:
        output = self.client.embeddings.create(
            model=self.model_name,
            input=contents,
            **kwargs
        )
        return {
            "embeddings": [data.embedding for data in output.data]
        }