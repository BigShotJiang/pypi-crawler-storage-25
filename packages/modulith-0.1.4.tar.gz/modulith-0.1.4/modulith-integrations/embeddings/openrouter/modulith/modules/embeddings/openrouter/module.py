import os
from modulith.modules.embeddings.openai import OpenAIEmbeddingModule


class OpenRouterEmbeddingModule(OpenAIEmbeddingModule):
    def __init__(self, model_name: str, **kwargs):
        super().__init__(
            model_name=model_name, 
            base_url="https://openrouter.ai/api/v1",
            api_key=os.environ.get("OPENROUTER_API_KEY"),
            **kwargs
        )