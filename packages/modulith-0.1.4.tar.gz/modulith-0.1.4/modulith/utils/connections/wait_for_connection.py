import time
import requests


def wait_for_connection(url: str, timeout: int = 1, max_wait: int = 15) -> bool:
    """
    Waits for a connection to the specified URL.

    Args:
        url (str): The URL to check.
        timeout (int): The timeout for each request in seconds.
        max_wait (int): The maximum time to wait in seconds.

    Returns:
        bool: True if the connection is successful, False otherwise.

    """
    for _ in range(max_wait * 2):  # ~max_wait seconds max
        try:
            r = requests.get(url, timeout=timeout)
            if r.status_code == 200:
                return True
        except requests.exceptions.RequestException:
            time.sleep(0.5)
    return False