import secrets
from fastapi import HTTPException


class SecretTokenManager:
    def __init__(self, token_length: int = 32):
        self.token_length = token_length
        self.owner_token = None
        self.public_token = None

    def generate_token(self) -> str:
        return "pk-" + secrets.token_urlsafe(self.token_length)

    def verify_token(
        self, 
        token: str | None, 
        public: bool = False, 
        protected: bool = True
    ) -> str:
        if token == self.owner_token:
            return "owner"

        if public:
            if not protected:
                return "public"
            elif token == self.public_token:
                return "public"

        raise HTTPException(status_code=401, detail="Invalid token")