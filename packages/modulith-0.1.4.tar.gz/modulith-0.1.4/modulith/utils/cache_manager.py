import time
import threading


class CacheManager:
    def __init__(self, max_size: int = 100000):
        self._cache = {}
        self._timestamps = {}
        self._lock = threading.Lock()
        self._max_size = max_size

    def get(self, key: str):
        with self._lock:
            return self._cache.get(key)

    def set(self, key: str, value):
        with self._lock:
            self._cache[key] = value
            self._timestamps[key] = time.time()
            # Time-based eviction policy: clear cache when max size is exceeded
            if len(self._cache) > self._max_size:
                oldest_key = min(self._timestamps, key=self._timestamps.get)
                del self._cache[oldest_key]
                del self._timestamps[oldest_key]