class NgrokTunnel:
    def __init__(self):
        self.tunnel = None
    
    @property
    def public_url(self):
        return self.tunnel.public_url
    
    def start(self, port: int):
        try:
            from pyngrok import ngrok
        except ImportError:
            raise ImportError("pyngrok is required for ngrok tunneling. Install it with 'pip install pyngrok'")
        self.tunnel = ngrok.connect(port)

    def stop(self):
        if self.tunnel:
            from pyngrok import ngrok
            ngrok.disconnect(self.tunnel.public_url)