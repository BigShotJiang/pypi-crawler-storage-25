import shutil
import secrets
import subprocess


class InstaTunnel:
    def __init__(self):
        self._process = None
        self._public_url = None
    
    @property
    def public_url(self):
        return self._public_url
    
    def start(self, port: int):
        if shutil.which("it") is None:
            raise RuntimeError("❌ 'instatunnel' is not installed. Install it with: 'npm install -g instatunnel'")
    
        self._process = subprocess.Popen(
            ["it", str(port), "--subdomain", f"modulith{secrets.token_hex(4)}"], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        # Extract the public URL from the output
        for line in self._process.stdout:
            if "Your app is now live at" in line:
                self._public_url = line.split("Your app is now live at")[1].strip()
                break

    def stop(self):
        if not self._process:
            return

        self._process.terminate()

        try:
            self._process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self._process.kill()

        subprocess.run(
            ["it", "--kill", self._public_url.split("//")[1].split(".")[0]], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
        )
        print("🔌 InstaTunnel has been shut down")

        self._process = None
        self._thread = None
        self._public_url = None