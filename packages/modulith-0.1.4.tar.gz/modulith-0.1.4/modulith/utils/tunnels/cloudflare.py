class CloudflareTunnel:
    def __init__(self):
        self.tunnel = None
    
    @property
    def public_url(self):
        return self.tunnel.tunnel_url
    
    def start(self, port: int):
        import logging
        logging.disable(logging.INFO)

        try:
            from flaredantic import FlareTunnel
        except ImportError:
            raise ImportError("flaredantic is required for cloudflare tunneling. Install it with 'pip install flaredantic'")
        self.tunnel = FlareTunnel({"port": port})
        self.tunnel.start()

        logging.disable(logging.NOTSET)

    def stop(self):
        if self.tunnel and self.tunnel.tunnel_process:
            self.tunnel.tunnel_process.terminate()
