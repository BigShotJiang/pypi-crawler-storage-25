from typing import Literal
from .ngrok import NgrokTunnel
from .instatunnel import InstaTunnel
from .cloudflare import CloudflareTunnel


AVAILABLE_TUNNELS = {
    "instatunnel": InstaTunnel,
    "cloudflare": CloudflareTunnel,
    "ngrok": NgrokTunnel,
}

def start_tunnel(
    local_port: int = 8000, 
    provider: Literal["instatunnel", "cloudflare", "ngrok", "any"] = "any", 
):
    from modulith.utils.connections import wait_for_connection

    if provider not in AVAILABLE_TUNNELS and provider != "any":
        raise ValueError(f"Unsupported tunnel provider '{provider}'. Available options are: {list(AVAILABLE_TUNNELS.keys())} or 'any'.")

    if provider == "any":
        for t in AVAILABLE_TUNNELS.keys():
            tunnel_instance = AVAILABLE_TUNNELS[t]()
            tunnel_instance.start(local_port)
            if wait_for_connection(tunnel_instance.public_url):
                return tunnel_instance
    else:
        tunnel_instance = AVAILABLE_TUNNELS[provider]()
        tunnel_instance.start(local_port)
        if wait_for_connection(tunnel_instance.public_url):
            return tunnel_instance
    return None