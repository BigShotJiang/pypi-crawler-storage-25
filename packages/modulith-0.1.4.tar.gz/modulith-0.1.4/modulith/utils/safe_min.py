def safe_min(value1: int | None, value2: int | None, default: int | None = None) -> int | None:
    """Returns the minimum of two values, treating None as a missing value. If both values are None, returns the default."""
    if value1 is None and value2 is None:
        return default
    if value1 is None:
        return value2
    if value2 is None:
        return value1
    return min(value1, value2)