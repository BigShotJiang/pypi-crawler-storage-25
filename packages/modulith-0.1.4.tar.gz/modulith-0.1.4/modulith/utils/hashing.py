def hash_string(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode()).hexdigest()