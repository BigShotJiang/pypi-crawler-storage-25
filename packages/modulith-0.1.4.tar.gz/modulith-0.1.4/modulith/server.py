import os
import uuid
import json
import time
import heapq
import atexit
import logging
import asyncio
import keyring
import uvicorn
import threading
import contextlib
from typing import Any
from modulith import Modulith
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field
from modulith.dataclasses import Capability
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import TimedRotatingFileHandler
from modulith.utils.rate_limiters import TokenBucketLimiter
from fastapi import Request, FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials


@dataclass(order=True)
class PrioritizedJob:
    priority: int
    seq: int
    job: Any = field(compare=False)

@dataclass
class Job:
    job_id: str
    capability_name: str
    payload: dict
    access_mode: str
    created_at: str
    future: asyncio.Future

class RequestCounter:
    lock = threading.Lock()
    counts = defaultdict(int)

    @contextmanager
    def track(self, capability_name: str):
        with self.lock:
            self.counts[capability_name] += 1
        try:
            yield
        finally:
            with self.lock:
                self.counts[capability_name] -= 1
                if self.counts[capability_name] < 0:
                    raise RuntimeError(f"Negative count for {capability_name}")
                
    def total(self) -> int:
        with self.lock:
            return sum(self.counts.values())
        
    def current(self, capability_name: str) -> int:
        with self.lock:
            return self.counts[capability_name]


def create_fastapi_server(
    module: Modulith,
    host: str = "localhost",
    port: int = 8000,
    auth_token: str | None = None,
    public: bool = False,
    burst_limit: int | None = None,
    rate_limit: int | None = None,
    max_queue_size: int = 10000,
    num_workers: int | None = None,
    timeout: float | None = None,
    logging_path: str = "./logs/server.log",
) -> FastAPI:
    # Config logging
    os.makedirs(os.path.dirname(logging_path), exist_ok=True)
    handler = TimedRotatingFileHandler(logging_path, when="midnight", backupCount=0)
    handler.suffix = "%Y-%m-%d"
    handler.namer = lambda name: name
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',         
        handlers=[handler, logging.StreamHandler()]
    )

    num_workers = num_workers or (4 * os.cpu_count())
    auth_token = auth_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")

    app = FastAPI(title=module.name)
    limiter = TokenBucketLimiter(
        capacity=burst_limit,
        refill_rate=rate_limit,
    )
    security = HTTPBearer(auto_error=False)
    request_counter = RequestCounter()

    thread_executor = ThreadPoolExecutor()
    semaphores: dict[str, asyncio.Semaphore] = {}

    def get_semaphore(capability_name: str, max_concurrency: int | None) -> asyncio.Semaphore:
        if max_concurrency is None:
            return contextlib.nullcontext()   # no limit, skip semaphore
        
        if capability_name not in semaphores:
            semaphores[capability_name] = asyncio.Semaphore(max_concurrency)
        
        return semaphores[capability_name]
    
    # ----------------------------
    # Queue state
    # ----------------------------
    sequence = 0
    queue_lock = asyncio.Lock()
    queue_not_empty = asyncio.Condition(lock=queue_lock)
    priority_heap: list[PrioritizedJob] = []
    workers: list[asyncio.Task] = []

    def queue_size() -> int:
        return len(priority_heap)
    
    async def enqueue_job(job: Job) -> None:
        nonlocal sequence
        async with queue_lock:
            if len(priority_heap) >= max_queue_size:
                logging.warning(f"Queue is full: {len(priority_heap)} requests queued, rejecting new job {job.job_id} for capability '{job.capability_name}'")
                raise HTTPException(
                    status_code=503,
                    detail={
                        "error": "Server queue is full",
                        "queue_size": len(priority_heap),
                        "max_queue_size": max_queue_size,
                    },
                )
            # Owner gets higher priority
            priority = 0 if job.access_mode == "owner" else 1
            heapq.heappush(
                priority_heap,
                PrioritizedJob(priority=priority, seq=sequence, job=job),
            )
            sequence += 1
            queue_not_empty.notify()

    async def dequeue_job() -> Job:
        async with queue_not_empty:
            while not priority_heap:
                await queue_not_empty.wait()
            item = heapq.heappop(priority_heap)
            return item.job
        
    # ----------------------------
    # Report status
    # ----------------------------
    routine_shutdown_event = threading.Event()
    
    def routine_loop():
        while not routine_shutdown_event.is_set():
            routine_shutdown_event.wait(timeout=60) # Report every 60 seconds
            logging.info(f"Running {request_counter.total()} requests, Queuing {queue_size()} requests")

    routine_worker = threading.Thread(target=routine_loop, daemon=True)
    routine_worker.start()
    # ----------------------------
    # Access control
    # ----------------------------
    def get_access_mode(credentials: HTTPAuthorizationCredentials | None = Depends(security)) -> str:
        if credentials:
            token = credentials.credentials
            if token == auth_token:
                return "owner"
            else:
                return "public"
        else:
            return "unauthorized"
        
    def open_access(access_mode: str = Depends(get_access_mode)) -> str:
        return access_mode
        
    def authorized_access(access_mode: str = Depends(get_access_mode)) -> str:
        if not public:
            if access_mode == "unauthorized":
                logging.warning("Unauthorized access attempt")
                raise HTTPException(status_code=401, detail="Unauthorized: Valid token required")
            elif access_mode == "public":
                logging.warning("Forbidden access attempt with invalid token")
                raise HTTPException(status_code=403, detail="Forbidden: This capability is not available with the provided token")
        return access_mode
        
    # ----------------------------
    # Request limiting
    # ----------------------------
    async def maybe_run_rate_limit(request: Request, access_mode: str):
        if access_mode == "owner":
            return

        if burst_limit is None and rate_limit is None:
            return

        # TODO: implement smarter client identification that can handle proxies and shared IPs, instead of using the raw client IP which may lead to unfair rate limiting for users behind NAT or corporate proxies. This could involve using a combination of headers (e.g. X-Forwarded-For), cookies, or even requiring clients to include a unique identifier in their requests to ensure more accurate and fair rate limiting.
        client_id = request.client.host if request.client else "unknown"
        allowed = limiter.consume(key=client_id)
        if not allowed:
            retry_after = limiter.estimate_wait_time(key=client_id)
            logging.warning(f"Rate limit exceeded for client {client_id}")
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "Rate limit exceeded",
                    "retry_after": retry_after,
                },
            )
    # ----------------------------
    # Capability execution
    # ----------------------------
    async def run_capability(capability_name: str, payload: dict):
        loop = asyncio.get_running_loop()
        capability: Capability = module.capabilities[capability_name]
        # If caching is allowed for this capability, check if the result is already in cache
        if capability.allow_cache:
            cache_key = f"{capability_name}:{json.dumps(payload, sort_keys=True)}"
            if cache_key in module.cache:
                return module.cache[cache_key]
        # If not in cache, execute the capability and store the result in cache if allowed
        sem = get_semaphore(capability_name, capability.max_concurrency)
        async with sem:
            return await loop.run_in_executor(
                    thread_executor, 
                    module.__call__,
                    capability_name,
                    payload,
                )
    
    async def worker_loop(worker_id: int):
        while True:
            job = await dequeue_job()

            with request_counter.track(job.capability_name):
                try:
                    coro = run_capability(job.capability_name, job.payload)

                    if timeout is not None:
                        result = await asyncio.wait_for(coro, timeout=timeout)
                    else:
                        result = await coro

                    if not job.future.done():
                        job.future.set_result(result)

                except HTTPException as e:
                    if not job.future.done():
                        job.future.set_exception(e)

                except asyncio.TimeoutError:
                    if not job.future.done():
                        job.future.set_exception(
                            HTTPException(
                                status_code=504,
                                detail={
                                    "error": "Job execution timed out",
                                    "capability": job.capability_name,
                                    "timeout": timeout,
                                },
                            )
                        )

                except Exception as e:
                    if not job.future.done():
                        job.future.set_exception(
                            HTTPException(status_code=500, detail=str(e))
                        )

    async def submit_and_wait(
        request: Request,
        capability_name: str,
        payload: dict,
        access_mode: str,
    ):
        loop = asyncio.get_running_loop()
        future = loop.create_future()

        job = Job(
            job_id=str(uuid.uuid4()),
            capability_name=capability_name,
            payload=payload,
            access_mode=access_mode,
            created_at=time.monotonic(),
            future=future,
        )

        await enqueue_job(job)

        try:
            result = await future
            logging.info(f"Completed job {job.job_id} ('{capability_name}' capability) in {time.monotonic() - job.created_at:.2f} seconds")
            return {"output": result}
        except HTTPException as e:
            logging.exception(f"Error executing job {job.job_id} ('{capability_name}' capability): {e.detail}")
            raise

    # ----------------------------
    # Lifecycle
    # ----------------------------
    @app.on_event("startup")
    async def startup_event():
        for i in range(num_workers):
            workers.append(asyncio.create_task(worker_loop(i)))

    @app.on_event("shutdown")
    async def shutdown_event():
        for task in workers:
            task.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        thread_executor.shutdown(wait=True)

    # ----------------------------
    # Endpoints
    # ----------------------------
    @app.get("/")
    async def root(request: Request, access_mode: str = Depends(open_access)):
        await maybe_run_rate_limit(request, access_mode)
        return {
            "status": "online",
            "name": module.name,
            "capabilities": {
                name: {
                    "signature": cap.signature,
                    "docstring": cap.docstring,
                    "allow_cache": cap.allow_cache,
                    "max_concurrency": cap.max_concurrency,
                }
                for name, cap in module.capabilities.items()
            },
        }

    def make_get_endpoint(capability_name: str):
        async def endpoint(request: Request, access_mode: str = Depends(authorized_access)):
            # NOTE: In future update, different capabilities may have different limits, queue, and access policies.
            await maybe_run_rate_limit(request, access_mode)
            client_id = request.client.host if request.client else "unknown"
            return {
                "capability": capability_name,
                "access_mode": access_mode,
                "remaining_quota": limiter.get_quota(client_id) if access_mode != "owner" else "unlimited",
                "queuing_requests": queue_size(),
                "running_requests": request_counter.total(),
            }
        endpoint.__name__ = f"{capability_name}_get_endpoint"
        return endpoint
    
    def make_post_endpoint(capability_name: str):
        async def endpoint(request: Request, payload: dict, access_mode: str = Depends(authorized_access)):
            await maybe_run_rate_limit(request, access_mode)
            output = await submit_and_wait(
                request=request,
                capability_name=capability_name,
                payload=payload,
                access_mode=access_mode,
            )
            return output
        endpoint.__name__ = f"{capability_name}_post_endpoint"
        return endpoint

    for capability_name in module.capabilities:
        app.add_api_route(f"/{capability_name}", make_get_endpoint(capability_name), methods=["GET"])
        app.add_api_route(f"/{capability_name}", make_post_endpoint(capability_name), methods=["POST"])

    # Run server in background
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level="warning",
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # ----------------------------
    # Shutdown handling
    # ----------------------------
    def shutdown():
        if server.should_exit:
            return
        server.should_exit = True
        thread_executor.shutdown(wait=True)
        routine_shutdown_event.set()
        routine_worker.join()
        thread.join()
        logging.info("Server shut down successfully")
    
    atexit.register(shutdown)

    return thread