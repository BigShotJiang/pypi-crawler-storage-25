import time
import atexit
import inspect
import requests
import threading
from typing import Callable, Any
from modulith.mns.module import resolve_module


class Capability:
    def __init__(
        self, 
        name: str,
        signature: str,
        docstring: str,
        allow_cache: bool = True,
        max_concurrency: int | None = None,
    ):
        self.name = name
        self.signature = signature
        self.docstring = docstring
        self.allow_cache = allow_cache
        self.max_concurrency = max_concurrency 

    def execute(self, kwargs: dict) -> Any:
        raise NotImplementedError("Subclasses must implement the execute method.")

class LocalCapability(Capability):
    def __init__(
        self, 
        name: str,
        func: Callable[[dict], Any],
        allow_cache: bool = True,
        max_concurrency: int | None = None,
    ):
        super().__init__(
            name=name,
            signature=str(inspect.signature(func)),
            docstring=inspect.getdoc(func),
            allow_cache=allow_cache,
            max_concurrency=max_concurrency,
        )
        self.func = func

    def execute(self, kwargs: dict | None = None) -> Any:
        kwargs = kwargs or {}
        return self.func(**kwargs)

class RemoteCapability(Capability):
    def __init__(
        self, 
        name: str,
        repository: str | None,
        signature: str,
        docstring: str,
        urls: list[str],
        allow_cache: bool,
        access_token: str,
    ):
        super().__init__(
            name=name,
            signature=signature,
            docstring=docstring,
            allow_cache=allow_cache,
            max_concurrency=1,
        )

        self.repository = repository
        self.access_token = access_token
        self.urls = urls

        self.running_index = 0 # Index for round-robin load balancing
        self.last_check_time = time.monotonic() # Timestamp of the last URLs and quota check

        self.shutdown_event = threading.Event()
        self.wake_event = threading.Event()

        
        self.routine_worker = threading.Thread(target=self._routine_loop, daemon=True)
        if self.repository:
            self.routine_worker.start()
            self.wake_event.set()  # Trigger the routine loop to perform the initial URLs and quota check immediately
        
        atexit.register(self._shutdown)

    def _shutdown(self):
        # Signal all threads to shut down
        self.shutdown_event.set()
        # Wait for the routine worker to finish
        if self.routine_worker.is_alive():
            self.routine_worker.join()

    def _routine_loop(self):
        while not self.shutdown_event.is_set():
            self.wake_event.wait(timeout=60)  # Wait for either timeout or wake signal
            # Update list of accessible URLs
            remote_urls = resolve_module(self.repository, self.access_token)
            accessible_urls = []
            for url in remote_urls:
                response = requests.get(f"{url}/{self.name}", headers={"Authorization": f"Bearer {self.access_token}"} if self.access_token else {})
                if response.status_code == 200:
                    accessible_urls.append(url)
            with threading.Lock():
                self.urls = accessible_urls
                # Ensure that running_index is within the bounds of the updated URLs list
                if self.running_index >= len(self.urls):
                    self.running_index = 0
            self.wake_event.clear()  # Clear the wake event after processing
                        
    def execute(self, kwargs: dict | None = None, timeout: float | None = 10) -> Any:
        kwargs = kwargs or {}
        # If URLs are being updated, wait until the update is done
        while self.wake_event.is_set():
            time.sleep(0.1)
        if len(self.urls) == 0:
            raise Exception(f"No accessible module URLs. Please check the '{self.repository}' repository and your access token.")
        
        for attempt in range(2):
            # Get url for remote call with simple round-robin load balancing
            with threading.Lock():
                url = self.urls[self.running_index]
                self.running_index = (self.running_index + 1) % len(self.urls)
            try:
                result = self.remote_call(
                    url=url,
                    endpoint=self.name,
                    access_token=self.access_token,
                    kwargs=kwargs,
                    timeout=timeout,
                )
                break   # Break after successful execution
            except Exception as e:
                if attempt == 0:
                    self.wake_event.set()  # Wake up the routine loop to refresh URLs and quotas on the first failure
                    while self.wake_event.is_set():
                        time.sleep(0.1)  # Wait for the routine loop to update the URLs before retrying
                    if len(self.urls) == 0:
                        raise Exception(f"No accessible module URLs. Please check the '{self.repository}' repository and your access token.")
                    continue  # Retry on the first attempt
                raise e
        return result

    @staticmethod
    def remote_call(
        url: str, 
        endpoint: str, 
        access_token: str, 
        kwargs: dict, 
        timeout: float | None = 10,
    ) -> Any:
        """
        Perform a remote call to the specified URL and endpoint with the given access token and arguments.
        Retry the call if it fails due to rate limiting (HTTP 429) or server queue full (HTTP 503), until it succeeds or the optional timeout is reached.
        """
        start_time = time.monotonic()
        while True:
            # Timeout check
            if timeout:
                elapsed_time = time.monotonic() - start_time
                if elapsed_time > timeout:
                    raise TimeoutError(f"Remote call to {url}/{endpoint} timed out after {timeout} seconds.")

            # Make the remote call
            headers = {"Authorization": f"Bearer {access_token}"} if access_token else {}
            response = requests.post(f"{url}/{endpoint}", json=kwargs, headers=headers, timeout=timeout)

            if response.status_code == 200:
                return response.json()["output"]
            elif response.status_code == 429:
                # Rate limit exceeded, wait and keep retry until timeout or success
                retry_after = response.json().get("retry_after", 1)
                time.sleep(retry_after)
                continue
            elif response.status_code == 503:
                # Server queue full, wait and keep retry until timeout or success
                time.sleep(1)
                continue
            else:
                raise Exception(f"Remote call failed with status code {response.status_code}: {response.text}")