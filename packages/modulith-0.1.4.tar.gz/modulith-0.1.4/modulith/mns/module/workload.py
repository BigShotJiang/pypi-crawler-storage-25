import requests
from .resolve import resolve_module
from modulith.global_variables import MNS_URL


def workload_module(repository: str, token: str = None, validate_url: bool = True) -> list[str]:
    urls = resolve_module(repository, token, validate_url)
    
    results = {}
    for url in urls:
        response = requests.get(f"{url}/workload")
        if response.status_code == 200:
            results[url] = response.json()
        else:
            results[url] = {"error": f"Failed to retrieve workload: {response.text}"}
    return results
