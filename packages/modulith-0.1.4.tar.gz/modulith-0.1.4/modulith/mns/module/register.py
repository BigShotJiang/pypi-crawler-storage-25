import requests
from modulith.global_variables import MNS_URL


def register_module(modulename: str, public_url: str, public: bool, token: str = None) -> str:
    response = requests.post(
        f"{MNS_URL}/register_module",
        json={
            "modulename": modulename,
            "url": public_url,
            "public": public,
            "token": token,
        },
    )
    if response.status_code == 200:
        return response.json()["repo"]
    raise ValueError(f"Failed to register module: {response.text}")