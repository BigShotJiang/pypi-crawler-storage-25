from .resolve import resolve_module
from .workload import workload_module