import requests
from modulith.global_variables import MNS_URL


def resolve_module(repository: str, token: str = None, validate_url: bool = True) -> list[str]:
    response = requests.get(f"{MNS_URL}/resolve_module", json={
        "repository": repository,
        "token": token,
        "validate_url": validate_url,
    })
    if response.status_code == 200:
        return response.json().get("urls", [])
    raise ValueError(f"Failed to resolve module: {response.text}")