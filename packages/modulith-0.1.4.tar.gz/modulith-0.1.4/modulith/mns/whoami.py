import requests
from modulith.global_variables import MNS_URL


def whoami(api_key: str) -> str:
    response = requests.get(f"{MNS_URL}/whoami", json={"token": api_key})
    if response.status_code == 200:
        username = response.json()["username"]
        return username
    raise ValueError(f"Failed to retrieve user information: {response.text.replace('Internal Server Error: ', '')}")