import requests
from modulith.global_variables import MNS_URL


def guest_signup() -> str:
    from .login import login
    response = requests.post(f"{MNS_URL}/guest_sign_up", json={})
    if response.status_code == 200:
        token = response.json().get("token")
        # Automatically log in the user after successful sign-up
        login(token)
        return token
    raise ValueError("Failed to sign up as guest")