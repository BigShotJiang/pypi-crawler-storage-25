import keyring


def login(api_key: str) -> str:
    from .whoami import whoami
    try:
        username = whoami(api_key)
        keyring.set_password("modulith", "api_key", api_key)
        return username
    except ValueError as e:
        raise ValueError(f"Login failed: {e}")