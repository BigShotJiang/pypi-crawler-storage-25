import requests
from modulith.global_variables import MNS_URL


def sign_up(
    email: str,
    username: str,
    password: str,
) -> str:
    from .login import login
    payload = {
        "email": email,
        "password": password,
        "username": username,
    }
    response = requests.post(f"{MNS_URL}/sign_up", json=payload)
    if response.status_code == 200:
        token = response.json().get("token")
        # Automatically log in the user after successful sign-up
        login(token)
        return token
    raise ValueError(f"Failed to sign up: {response.text}")