import os
import typer
import keyring
import subprocess
from modulith import Modulith
from typing import Annotated, Optional
from modulith.mns.whoami import whoami
from modulith.cli.run import load_module


dockerfile = """
FROM python:3.12-slim

COPY . .

RUN pip install --no-cache-dir modulith
RUN if [ -f "requirements.txt" ]; then \
    pip install --no-cache-dir -r requirements.txt; \
fi
ARG MODULE_SOURCE
ENV MODULE_SOURCE=${MODULE_SOURCE}
ENTRYPOINT ["modulith", "run", "--module-source", "${MODULE_SOURCE}"]
"""


build_app = typer.Typer()

@build_app.command("build")
def build_command(
    module_source: Annotated[
        str,
        typer.Option("--module-source", help="Python module source, e.g. 'calculator.module' or 'calculator:module'"),
    ] = None,
    push_to_hub: Annotated[
        bool,
        typer.Option("--push-to-hub", help="Whether to push the built image to Docker Hub."),
    ] = False,
    docker_username: Annotated[
        str,
        typer.Option("--docker-username", help="Your Docker Hub username."),
    ] = None,
    docker_token: Annotated[
        str,
        typer.Option("--docker-token", help="Your Docker Hub token."),
    ] = None,
    auth_token: Annotated[
        Optional[str],
        typer.Option("--auth-token", help="Your authentication token. If not provided, a token will be generated and displayed in the console."),
    ] = None,
):
    if not module_source:
        module_source = typer.prompt("Module source")
    if not docker_username:
        docker_username = typer.prompt("Docker Hub Username")

    auth_token = auth_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")

    # Create Dockerfile
    with open("Dockerfile", "w") as f:
        f.write(dockerfile)

    # Build Docker image
    module: Modulith = load_module(module_source)
    modulith_username = whoami(api_key=auth_token)
    image_name = f"{docker_username}/{modulith_username}"
    tag = module.name
    subprocess.run(f"docker build --build-arg MODULE_SOURCE={module_source} -t {image_name}:{tag} .", shell=True, check=True)

    # Push Docker image to registry
    if push_to_hub:
        if not docker_token:
            docker_token = typer.prompt("Docker Hub Token", hide_input=True)
        subprocess.run(f"docker login -u {docker_username} --password-stdin", input=docker_token, text=True, shell=True, check=True)
        subprocess.run(f"docker push {image_name}:{tag}", shell=True, check=True)