import typer
import keyring


logout_app = typer.Typer()

@logout_app.command("logout")
def logout_command():
    keyring.delete_password("modulith", "api_key")
    typer.echo("✅ Logout successful. Authentication token removed.")