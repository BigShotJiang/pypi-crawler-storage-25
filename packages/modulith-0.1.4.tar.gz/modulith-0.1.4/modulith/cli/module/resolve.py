import typer
from modulith.mns.module.resolve import resolve_module


resolve_module_app = typer.Typer()

@resolve_module_app.command("resolve")
def resolve_command():
    repository = typer.prompt("Repository")
    token = typer.prompt("Authentication Token", hide_input=True)
    validate_url = typer.confirm("Validate URL?", default=True)
    try:
        urls = resolve_module(repository, token, validate_url)
        typer.echo(f"Module URLs: {urls}")
    except ValueError as e:
        typer.echo(f"Failed to resolve module: {str(e)}")
