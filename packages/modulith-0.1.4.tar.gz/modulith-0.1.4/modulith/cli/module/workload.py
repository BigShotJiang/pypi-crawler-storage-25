import typer
from modulith.mns.module.workload import workload_module


workload_module_app = typer.Typer()

@workload_module_app.command("workload")
def workload_command(
    repo: str = typer.Argument(..., help="Repository"),
    token: str = typer.Option(None, help="Authentication Token", prompt=True, hide_input=True),
    validate_url: bool = typer.Option(True, help="Validate URL?"),
):
    repo = typer.prompt("Repository") if not repo else repo
    token = typer.prompt("Authentication Token", hide_input=True) if not token else token
    validate_url = typer.confirm("Validate URL?", default=True) if validate_url is None else validate_url
    try:
        results = workload_module(repo, token, validate_url)
        typer.echo(f"Module Workload: {results}")
    except ValueError as e:
        typer.echo(f"Failed to retrieve workload: {str(e)}")
