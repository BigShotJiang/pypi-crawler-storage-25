import typer
from modulith.mns.login import login


login_app = typer.Typer()

@login_app.command("login")
def login_command():
    auth_token = typer.prompt("Authentication Token")

    try:
        username = login(auth_token)
        typer.echo("✅ Login successful")
        typer.echo(f"Username: {username}")
    except ValueError as e:
        typer.echo(e)