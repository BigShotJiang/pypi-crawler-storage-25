import os
import sys
import typer
import keyring
import requests
import threading
import importlib
import subprocess
from typing import Literal
from modulith import Modulith
from typing import Annotated, Optional
from modulith.mns.whoami import whoami
from modulith.utils.tunnels import start_tunnel
from modulith.server import create_fastapi_server
from modulith.mns.guest_signup import guest_signup
from modulith.mns.module.register import register_module
from modulith.utils.connections import wait_for_connection


def load_module(module_ref: str):
    variable_name = None
    if ":" in module_ref:
        module_ref, variable_name = module_ref.split(":")
    
    # Add the current working directory to sys.path if it's not already there
    if os.getcwd() not in sys.path:
        sys.path.insert(0, os.getcwd())
    
    mod = importlib.import_module(module_ref)
    if variable_name is None:
        for name in ("module", "app", "service", "tool"):
            if hasattr(mod, name):
                variable_name = name
                break

    if variable_name is None:
        raise ValueError(f"Module reference '{module_ref}' does not specify a variable name and no default variable ('module', 'app', 'service', or 'tool') was found. Please specify the variable name explicitly, e.g. '{module_ref}:variable_name'.")

    module = getattr(mod, variable_name)
    if isinstance(module, Modulith):
        return module
    
    raise ValueError(f"Module '{module_ref}' is not an instance of Modulith.")


run_app = typer.Typer()
@run_app.command("run")
def run_command(
    module_source: Annotated[
        Optional[str],
        typer.Option("--module-source", help="Python module source, e.g. 'calculator.module' or 'calculator:module'"),
    ] = None,
    module_name: Annotated[
        Optional[str],
        typer.Option("--module-name", help="Name of the module, e.g. 'calculator'"),
    ] = None,
    port: Annotated[
        int,
        typer.Option("--port", help="Port to bind the server to."),
    ] = 8000,
    host: Annotated[
        str,
        typer.Option("--host", help="Host to bind the server to. Use 'localhost' for tunnel providers to work properly."),
    ] = "localhost",
    tunnel: Annotated[
        Optional[Literal["instatunnel", "cloudflare", "ngrok", "any"]],
        typer.Option("--tunnel", help="Tunnel provider to use for public exposure. Options: 'instatunnel', 'cloudflare', 'ngrok', 'any'. If not specified, the server will not be exposed publicly."),
    ] = "any",
    public: Annotated[
        bool,
        typer.Option("--public", help="Expose the module publicly."),
    ] = False,
    burst_limit: Annotated[
        Optional[int],
        typer.Option("--burst-limit", help="Maximum number of concurrent requests allowed for public access."),
    ] = None,
    rate_limit: Annotated[
        Optional[int],
        typer.Option("--rate-limit", help="Maximum number of requests per minute allowed for public access."),
    ] = None,
    max_queue_size: Annotated[
        int,
        typer.Option("--max-queue-size", help="Maximum number of requests to queue when the server is under heavy load. Requests beyond this limit will be rejected with a 503 error."),
    ] = 10000,
    num_workers: Annotated[
        Optional[int],
        typer.Option("--num-workers", help="Number of worker processes to handle requests. If not specified, it will default to the number of CPU cores."),
    ] = None,
    timeout: Annotated[
        Optional[float],
        typer.Option("--timeout", help="Maximum time in seconds to allow a request to be processed before timing out. If not specified, there will be no timeout."),
    ] = None,
    logging_path: Annotated[
        str,
        typer.Option("--logging-path", help="Path to the log file for the server. Logs will be rotated daily."),
    ] = "logs/server.log",
    auth_token: Annotated[
        Optional[str],
        typer.Option("--auth-token", help="Your authentication token. If not provided, a token will be generated and displayed in the console."),
    ] = None,
    no_tunnel: Annotated[
        bool,
        typer.Option("--no-tunnel", help="Do not establish a tunnel even if the --tunnel option is specified. This is useful for testing the server without exposing it publicly."),
    ] = False,
    skip_registration: Annotated[
        bool,
        typer.Option("--skip-registration", help="Skip registering the module to the Modulith Network Service."),
    ] = False,
    silent: Annotated[
        bool,
        typer.Option("--silent", help="Suppress console output except for errors."),
    ] = False,
):
    if not silent: typer.echo("🚀 Authenticating...")
    auth_token = auth_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")
    if auth_token is None:
        auth_token = guest_signup()
        typer.echo()
        typer.echo(f"🔑 Your authentication token: {auth_token}")
    
    def print_startup_message(module_name):
        if not silent:
            params = f"port: {port}, host: '{host}', tunnel: '{tunnel}', public: {public}, burst_limit: {burst_limit}, rate_limit: {rate_limit}, max_queue_size: {max_queue_size}, num_workers: {num_workers}, timeout: {timeout}, no_tunnel: {no_tunnel}, skip_registration: {skip_registration}"
            typer.echo(f"🚀 Starting module '{module_name}' with the following configuration:")
            typer.echo("{" + params + "}")

    if module_name:
        print_startup_message(module_name)

        # Pull the Docker image and run the container
        host = "localhost"
        docker_username = "teakatz"  # TODO: get from argument
        modulith_username = whoami(api_key=auth_token)
        image_name = f"{docker_username}/{modulith_username}:{module_name}"
        container_name = f"{modulith_username}_{module_name}"
        # Pull image
        try:
            subprocess.run(
                ["docker", "pull", image_name], 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                check=True
            )
        except subprocess.CalledProcessError as e:
            pass
        cmd = ["--host", "0.0.0.0", "--port", "8000", "--no-tunnel", "--skip-registration", "--silent"]
        if public:
            cmd.append("--public")
        if burst_limit is not None:
            cmd.extend(["--burst-limit", str(burst_limit)])
        if rate_limit is not None:
            cmd.extend(["--rate-limit", str(rate_limit)])
        if max_queue_size is not None:
            cmd.extend(["--max-queue-size", str(max_queue_size)])
        if num_workers is not None:
            cmd.extend(["--num-workers", str(num_workers)])
        if timeout is not None:
            cmd.extend(["--timeout", str(timeout)])
        if logging_path is not None:
            cmd.extend(["--logging-path", logging_path])
        if auth_token is not None:
            cmd.extend(["--auth-token", auth_token])
        
        def server_run():
            process = subprocess.Popen(
                ["docker", "run", "--name", container_name, "--rm", "-p", f"{port}:8000", image_name] + cmd,
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                text=True
            )
            for line in process.stdout:
                print(line, end="")
            process.wait()
        try:
            thread = threading.Thread(target=server_run, daemon=True)
            thread.start()
        except subprocess.CalledProcessError as e:
            print(e.stderr.decode())
            sys.exit(1)
    
    elif module_source:
        module: Modulith = load_module(module_source)
        print_startup_message(module.name)

        thread = create_fastapi_server(
            module=module,
            host=host,
            port=port,
            auth_token=auth_token,
            public=public,
            burst_limit=burst_limit,
            rate_limit=rate_limit,
            max_queue_size=max_queue_size,
            num_workers=num_workers,
            timeout=timeout,
            logging_path=logging_path,
        )
    else:
        raise ValueError("Either --module-source or --module-name must be provided.")
    
    local_url = f"http://{host}:{port}"
    # Wait for server to be up
    if not wait_for_connection(local_url):
        raise RuntimeError(f"❌ Failed to start server at port {port}")
    
    response = requests.get(f"{local_url}/")
    module_info = response.json()
    module_name = module_info["name"]
    module_capabilities = module_info["capabilities"]
    
    public_url = None
    repository = None
    tunnel_instance = None
    if not no_tunnel:
        if not silent: typer.echo("🚀 Establishing tunnel...")
        tunnel_instance = start_tunnel(local_port=port, provider=tunnel)
        public_url = tunnel_instance.public_url
        
    if not skip_registration and public_url:
        if not silent: typer.echo("🚀 Registering module...")
        repository = register_module(modulename=module_name, public_url=public_url, public=public, token=auth_token)

    if not silent:
        typer.echo()
        typer.echo(f"🌐 Module '{module_name}' is live:")
        if repository:
            typer.echo(f"- Repository: {repository}")
        if public_url:
            typer.echo(f"- Public URL: {public_url}")
        typer.echo(f"- Local URL: {local_url}")
        typer.echo()

        typer.echo("⚙️ Capabilities:")
        for name, capability in module_capabilities.items():
            typer.echo(f"- {name}{capability['signature']}")
        typer.echo()

        if public and (burst_limit or rate_limit):
            typer.echo("⚡ Public access limits:")
            if rate_limit:
                typer.echo(f"- Rate limit: {rate_limit} requests per minute")
            if burst_limit:
                typer.echo(f"- Burst limit: {burst_limit} concurrent requests")
            typer.echo()

        typer.echo("🛑 Press Ctrl+C to stop")

    try:
        while thread.is_alive():
            thread.join(timeout=1)
    except KeyboardInterrupt:
        typer.echo("🛑 Shutting down...")
        if tunnel_instance:
            tunnel_instance.stop()
        typer.echo(f"🔌 Module '{module_name}' has been shut down")
        # TODO: deregister model from MNS
        # print("✅ Shutdown complete")