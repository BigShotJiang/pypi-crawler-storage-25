import typer
import keyring
from modulith.mns.whoami import whoami


whoami_app = typer.Typer()

@whoami_app.command("whoami")
def whoami_command():
    api_key = keyring.get_password("modulith", "api_key")
    if not api_key:
        typer.echo("No authentication token found. Please login first.")
        raise typer.Exit(code=1)

    try:
        username = whoami(api_key)
        typer.echo(f"Authenticated as: {username}")
    except ValueError as e:
        typer.echo(e)