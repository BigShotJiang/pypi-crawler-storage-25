import typer
from modulith.mns.signup import sign_up


singup_app = typer.Typer()

@singup_app.command("signup")
def signup_command():
    email = typer.prompt("Email")
    username = typer.prompt("Username")
    password = typer.prompt("Password", hide_input=True)

    try:
        token = sign_up(email, username, password)
        typer.echo("✅ Signup successful")
        typer.echo(f"Email: {email}")
        typer.echo(f"Username: {username}")
        typer.echo(f"Authentication key: {token}")
    except ValueError as e:
        typer.echo(f"Failed to signup: {str(e)}")