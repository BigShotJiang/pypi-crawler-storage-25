"""
Version information for benchlab-pycore
"""

__version__ = "0.2.1"
