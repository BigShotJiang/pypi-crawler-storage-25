# Copyright (c) 2026 Ori Cohen https://github.com/ori88c/
# Licensed under the Apache License 2.0.

from unittest.mock import patch

import pytest

from frequency_anomaly_reporter import (
    ExcessiveFrequencyReporter,
    ExcessiveFrequencyReporterConfig,
    ExcessiveFrequencyReportingMode,
)

_EVERY = ExcessiveFrequencyReportingMode.REPORT_EVERY
_ONCE_STOP = ExcessiveFrequencyReportingMode.REPORT_ONCE_THEN_STOP
_MONOTONIC_NS = "frequency_anomaly_reporter._excessive_reporter.time.monotonic_ns"


def make_reporter(
    callback,
    mode: ExcessiveFrequencyReportingMode = _EVERY,
    max_events: int = 3,
    window_ms: int = 60_000,
) -> ExcessiveFrequencyReporter:
    config = ExcessiveFrequencyReporterConfig(
        window_duration_ms=window_ms,
        max_events_in_window=max_events,
        on_excessive_frequency=callback,
        reporting_mode=mode,
    )
    return ExcessiveFrequencyReporter(config)


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "override, exc_type",
    [
        ({"window_duration_ms": 0}, ValueError),
        ({"window_duration_ms": -1}, ValueError),
        ({"max_events_in_window": 0}, ValueError),
        ({"max_events_in_window": -5}, ValueError),
        ({"on_excessive_frequency": "not_callable"}, TypeError),
        ({"reporting_mode": "bad_value"}, TypeError),
    ],
)
def test_config_validation_rejects_invalid_inputs(override, exc_type):
    base = {
        "window_duration_ms": 1_000,
        "max_events_in_window": 3,
        "on_excessive_frequency": lambda n: None,
        "reporting_mode": _EVERY,
    }
    base.update(override)
    with pytest.raises(exc_type):
        ExcessiveFrequencyReporterConfig(**base)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


def test_initial_state_is_inactive():
    reporter = make_reporter(lambda n: None)
    assert not reporter.is_active


def test_start_stop_lifecycle():
    reporter = make_reporter(lambda n: None)
    assert not reporter.is_active

    reporter.start()
    assert reporter.is_active
    reporter.start()  # idempotent — already active
    assert reporter.is_active

    reporter.stop()
    assert not reporter.is_active
    reporter.stop()  # idempotent — already stopped
    assert not reporter.is_active

    reporter.start()  # re-arm
    assert reporter.is_active


# ---------------------------------------------------------------------------
# Inactive no-op
# ---------------------------------------------------------------------------


async def test_record_event_when_inactive_is_noop():
    breach_counts: list[int] = []
    reporter = make_reporter(breach_counts.append, max_events=1)

    # Before first start: silent no-op
    await reporter.record_event()
    await reporter.record_event()
    assert breach_counts == []

    # After stop: silent no-op
    reporter.start()
    reporter.stop()
    await reporter.record_event()
    assert breach_counts == []


# ---------------------------------------------------------------------------
# Threshold semantics — no breach at exactly max_events
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("mode", [_EVERY, _ONCE_STOP])
async def test_no_breach_when_at_or_below_threshold(
    mode: ExcessiveFrequencyReportingMode,
):
    breach_counts: list[int] = []
    max_events = 3
    reporter = make_reporter(breach_counts.append, mode=mode, max_events=max_events)
    reporter.start()

    for _ in range(max_events):
        await reporter.record_event()
    # Threshold is strictly >, so exactly max_events must not trigger
    assert breach_counts == []
    assert reporter.is_active


# ---------------------------------------------------------------------------
# REPORT_EVERY — fires on every breach
# ---------------------------------------------------------------------------


async def test_report_every_fires_on_each_breach():
    breach_counts: list[int] = []
    max_events = 3
    reporter = make_reporter(breach_counts.append, mode=_EVERY, max_events=max_events)
    reporter.start()

    for _ in range(max_events):
        await reporter.record_event()
    assert breach_counts == []
    assert reporter.is_active

    await reporter.record_event()  # first breach: window has max+1 events
    assert breach_counts == [max_events + 1]
    assert reporter.is_active  # must stay active in REPORT_EVERY mode
    await reporter.record_event()  # second breach: window has max+2 events
    assert breach_counts == [max_events + 1, max_events + 2]
    assert reporter.is_active


# ---------------------------------------------------------------------------
# REPORT_ONCE_THEN_STOP — auto-stop, re-arm, cleared window
# ---------------------------------------------------------------------------


async def test_report_once_then_stop_auto_stops_and_rearms():
    breach_counts: list[int] = []
    max_events = 3
    reporter = make_reporter(breach_counts.append, mode=_ONCE_STOP, max_events=max_events)
    reporter.start()

    for _ in range(max_events):
        await reporter.record_event()
    assert breach_counts == []

    await reporter.record_event()  # first breach
    assert breach_counts == [max_events + 1]
    assert not reporter.is_active  # auto-stopped after callback

    # Further calls are silent no-ops while stopped
    await reporter.record_event()
    await reporter.record_event()
    assert len(breach_counts) == 1

    # Re-arm: clear first (start() no longer clears the window) then activate
    reporter.clear()
    reporter.start()
    assert reporter.is_active

    for _ in range(max_events):
        await reporter.record_event()
    assert len(breach_counts) == 1  # no breach yet — window is fresh

    await reporter.record_event()  # second breach after re-arm
    assert len(breach_counts) == 2
    assert not reporter.is_active  # auto-stopped again


# ---------------------------------------------------------------------------
# Sliding window — old events expire
# ---------------------------------------------------------------------------


async def test_sliding_window_expires_old_events():
    breach_counts: list[int] = []
    max_events = 2
    window_ms = 100
    ns_per_ms = 1_000_000

    # Timestamps (ms): 0, 50, 110, 160, 200
    #
    # Call 1 @ 0ms:   cutoff=-100ms, no prune, deque=[0],           count=1, no breach
    # Call 2 @ 50ms:  cutoff=-50ms,  no prune, deque=[0,50],        count=2, no breach
    # Call 3 @ 110ms: cutoff=10ms,   prune 0ms, deque=[50,110],     count=2, no breach
    # Call 4 @ 160ms: cutoff=60ms,   prune 50ms, deque=[110,160],   count=2, no breach
    # Call 5 @ 200ms: cutoff=100ms,  no prune, deque=[110,160,200], count=3>2 → breach
    timestamps = [t * ns_per_ms for t in (0, 50, 110, 160, 200)]

    reporter = make_reporter(
        breach_counts.append, mode=_EVERY, max_events=max_events, window_ms=window_ms
    )
    reporter.start()

    with patch(_MONOTONIC_NS, side_effect=timestamps):
        await reporter.record_event()  # t=0ms
        await reporter.record_event()  # t=50ms
        assert breach_counts == []

        await reporter.record_event()  # t=110ms — 0ms pruned, count=2, no breach
        await reporter.record_event()  # t=160ms — 50ms pruned, count=2, no breach
        assert breach_counts == []

        await reporter.record_event()  # t=200ms — count=3, breach
        assert breach_counts == [3]


# ---------------------------------------------------------------------------
# Async callback dispatch
# ---------------------------------------------------------------------------


async def test_async_callback_is_awaited():
    breach_counts: list[int] = []

    async def async_cb(n: int) -> None:
        breach_counts.append(n)

    reporter = make_reporter(async_cb, mode=_EVERY, max_events=1)
    reporter.start()

    await reporter.record_event()  # count=1, equals max — no breach
    assert breach_counts == []

    await reporter.record_event()  # count=2 > 1 — breach
    assert breach_counts == [2]


# ---------------------------------------------------------------------------
# clear() resets the window; stop() does not
# ---------------------------------------------------------------------------


async def test_clear_resets_window():
    breach_counts: list[int] = []
    max_events = 3
    reporter = make_reporter(breach_counts.append, mode=_EVERY, max_events=max_events)
    reporter.start()

    for _ in range(max_events):
        await reporter.record_event()
    assert breach_counts == []

    # stop() alone does NOT clear the window — history carries over
    reporter.stop()
    reporter.start()
    await reporter.record_event()  # max+1 events in window → immediate breach
    assert len(breach_counts) == 1
    assert reporter.is_active  # REPORT_EVERY keeps it active
    # clear() wipes the window regardless of active state
    reporter.clear()
    assert reporter.current_window_event_count == 0

    for _ in range(max_events):
        await reporter.record_event()
    assert len(breach_counts) == 1  # fresh window — no new breach


# ---------------------------------------------------------------------------
# current_window_event_count — live metrics with stale eviction
# ---------------------------------------------------------------------------


async def test_current_window_event_count():
    ns_per_ms = 1_000_000
    reporter = make_reporter(lambda n: None, mode=_EVERY, max_events=5, window_ms=100)
    assert reporter.current_window_event_count == 0  # empty deque

    reporter.start()
    # side_effect order: record@0ms, record@50ms, query@50ms, query@110ms
    ts = [t * ns_per_ms for t in (0, 50, 50, 110)]
    with patch(_MONOTONIC_NS, side_effect=ts):
        await reporter.record_event()  # record t=0ms
        await reporter.record_event()  # record t=50ms
        assert reporter.current_window_event_count == 2  # query @ t=50ms: both fresh
        assert reporter.current_window_event_count == 1  # query @ t=110ms: 0ms evicted

    reporter.clear()
    assert reporter.current_window_event_count == 0  # empty deque after clear
