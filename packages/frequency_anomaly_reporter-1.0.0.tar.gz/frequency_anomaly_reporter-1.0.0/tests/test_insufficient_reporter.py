# Copyright (c) 2026 Ori Cohen https://github.com/ori88c/
# Licensed under the Apache License 2.0.

"""Tests for InsufficientFrequencyReporter.

Behavior tests use :class:`VirtualClock` with :func:`make_reporter_with_clock` so
simulated time and the checker ``sleep`` stay in sync. Each injected
``sleep(seconds)`` advances internal nanoseconds by that interval, then yields the
real event loop. Use :meth:`VirtualClock.advance_ms` or :meth:`VirtualClock.set_ms`
(test-facing milliseconds) when timestamps must not follow checker sleeps alone.
``monotonic_ns()`` still returns nanoseconds for the reporter DI hook. Tests call
:func:`_trigger_event_loop_cycles` to ``await asyncio.sleep(0)`` repeatedly so
the checker task can run between assertions.
"""

import asyncio
import math
from collections.abc import Awaitable, Callable
from typing import Any

import pytest

from frequency_anomaly_reporter import (
    InsufficientFrequencyReporter,
    InsufficientFrequencyReporterConfig,
    InsufficientFrequencyReportingMode,
)

_EVERY = InsufficientFrequencyReportingMode.REPORT_EVERY
_ONCE_STOP = InsufficientFrequencyReportingMode.REPORT_ONCE_THEN_STOP

# Captured once so injected test sleep can await the real primitive without
# going through a patched module global.
_REAL_ASYNCIO_SLEEP = asyncio.sleep

_NS_PER_MS = 1_000_000
_CHECK_INTERVAL_MS = 10
_WINDOW_MS_DEFAULT = 100

# How many ``asyncio.sleep(0)`` yields to schedule the checker (tuned per scenario).
_YIELDS_LIGHT = 8
_YIELDS_LIFECYCLE = 6
# For tests with no ``record_event``: after ``start()``, the reporter waits
# ``_WINDOW_MS_DEFAULT`` ms (grace) before it checks the window. Each checker
# sleep adds ``_CHECK_INTERVAL_MS`` ms. Add slack so ``sleep(0)`` yields and
# ``VirtualClock``'s inner ``await asyncio.sleep(0)`` per checker tick still
# schedule the first shortfall reliably.
_YIELDS_FIRST_SHORTFALL_SCHEDULING_SLACK = 4
_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW = math.ceil(
    _WINDOW_MS_DEFAULT / _CHECK_INTERVAL_MS
) + _YIELDS_FIRST_SHORTFALL_SCHEDULING_SLACK
_YIELDS_EXPIRING_EVENTS = 20
_YIELDS_WITHIN_1S_GRACE = 50  # 50 × _CHECK_INTERVAL_MS ≈ 500 ms < 1 s grace


class VirtualClock:
    """Simulated monotonic clock paired with ``sleep`` for DI tests.

    Test code moves time in **milliseconds** via :meth:`set_ms` / :meth:`advance_ms`.
    :meth:`monotonic_ns` returns the reporter-facing clock in **nanoseconds**.
    Each ``await sleep(sec)`` advances internal nanoseconds by ``round(sec * 1e9)``
    (the reporter passes seconds), then yields the loop.
    """

    __slots__ = ("_now_ns",)

    def __init__(self, start_ms: float | int = 0) -> None:
        self._now_ns = int(start_ms * _NS_PER_MS)

    def monotonic_ns(self) -> int:
        return self._now_ns

    def set_ms(self, t_ms: float | int) -> None:
        self._now_ns = int(t_ms * _NS_PER_MS)

    def advance_ms(self, delta_ms: float | int) -> None:
        self._now_ns += int(delta_ms * _NS_PER_MS)

    async def sleep(self, seconds: float) -> None:
        self._now_ns += int(round(seconds * 1e9))
        await _REAL_ASYNCIO_SLEEP(0)


async def _trigger_event_loop_cycles(*, n: int = 12) -> None:
    """Await ``asyncio.sleep(0)`` ``n`` times so other tasks (e.g. the checker) run."""
    for _ in range(n):
        await _REAL_ASYNCIO_SLEEP(0)


def make_reporter(
    callback: Callable[[int], Any],
    mode: InsufficientFrequencyReportingMode = _EVERY,
    min_events: int = 3,
    window_ms: int = _WINDOW_MS_DEFAULT,
    check_interval_ms: int = _CHECK_INTERVAL_MS,
    *,
    monotonic_ns: Callable[[], int] | None = None,
    sleep: Callable[[float], Awaitable[None]] | None = None,
) -> InsufficientFrequencyReporter:
    kw: dict[str, Any] = {
        "window_duration_ms": window_ms,
        "min_events_in_window": min_events,
        "check_interval_ms": check_interval_ms,
        "on_insufficient_frequency": callback,
        "reporting_mode": mode,
    }
    if monotonic_ns is not None:
        kw["_monotonic_ns"] = monotonic_ns
    if sleep is not None:
        kw["_sleep"] = sleep
    config = InsufficientFrequencyReporterConfig(**kw)
    return InsufficientFrequencyReporter(config)


def make_reporter_with_clock(
    callback: Callable[[int], Any],
    clock: VirtualClock,
    **kwargs: Any,
) -> InsufficientFrequencyReporter:
    monotonic_ns = kwargs.pop("monotonic_ns", clock.monotonic_ns)
    sleep = kwargs.pop("sleep", clock.sleep)
    return make_reporter(
        callback,
        monotonic_ns=monotonic_ns,
        sleep=sleep,
        **kwargs,
    )


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "override, exc_type",
    [
        ({"window_duration_ms": 0}, ValueError),
        ({"window_duration_ms": -1}, ValueError),
        ({"min_events_in_window": 0}, ValueError),
        ({"min_events_in_window": -5}, ValueError),
        ({"check_interval_ms": 0}, ValueError),
        ({"check_interval_ms": -1}, ValueError),
        ({"on_insufficient_frequency": "not_callable"}, TypeError),
        ({"reporting_mode": "bad_value"}, TypeError),
        ({"_monotonic_ns": "not_callable"}, TypeError),
        ({"_sleep": "not_callable"}, TypeError),
    ],
)
def test_config_validation_rejects_invalid_inputs(override, exc_type):
    base = {
        "window_duration_ms": 1_000,
        "min_events_in_window": 3,
        "check_interval_ms": _CHECK_INTERVAL_MS,
        "on_insufficient_frequency": lambda n: None,
        "reporting_mode": _EVERY,
    }
    base.update(override)
    with pytest.raises(exc_type):
        InsufficientFrequencyReporterConfig(**base)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


def test_initial_state_is_inactive():
    clock = VirtualClock()
    reporter = make_reporter_with_clock(lambda n: None, clock)
    assert not reporter.is_active


def test_start_requires_running_event_loop():
    clock = VirtualClock()
    reporter = make_reporter_with_clock(lambda n: None, clock)
    with pytest.raises(RuntimeError, match="no running event loop"):
        reporter.start()


async def test_start_stop_lifecycle():
    clock = VirtualClock()
    reporter = make_reporter_with_clock(lambda n: None, clock, min_events=3)

    assert not reporter.is_active
    reporter.start()
    assert reporter.is_active
    reporter.record_event()
    reporter.record_event()
    reporter.record_event()
    await _trigger_event_loop_cycles(n=_YIELDS_LIFECYCLE)
    reporter.stop()
    assert not reporter.is_active

    reporter.start()
    assert reporter.is_active

    reporter.stop()
    assert not reporter.is_active
    reporter.stop()
    assert not reporter.is_active


# ---------------------------------------------------------------------------
# Inactive no-op
# ---------------------------------------------------------------------------


async def test_record_event_when_inactive_is_noop():
    shortfall_counts: list[int] = []

    def cb(n: int) -> None:
        shortfall_counts.append(n)

    reporter = make_reporter(cb, min_events=50)

    reporter.record_event()
    reporter.record_event()
    assert shortfall_counts == []

    clock = VirtualClock()
    r = make_reporter_with_clock(cb, clock, min_events=50)
    r.start()
    await _trigger_event_loop_cycles(n=_YIELDS_LIGHT)
    r.stop()

    reporter.record_event()
    assert shortfall_counts == []


# ---------------------------------------------------------------------------
# Threshold semantics — no callback at exactly min_events
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("mode", [_EVERY, _ONCE_STOP])
async def test_no_callback_when_count_at_or_above_min(
    mode: InsufficientFrequencyReportingMode,
):
    shortfall_counts: list[int] = []
    min_events = 3
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=mode,
        min_events=min_events,
    )

    reporter.start()
    # During grace, record three strictly increasing timestamps so later
    # ``_trigger_event_loop_cycles`` calls do not shrink the window below min_events.
    clock.advance_ms(90)
    for _ in range(min_events):
        reporter.record_event()
        clock.advance_ms(1e-6)
    await _trigger_event_loop_cycles(n=_YIELDS_LIGHT)
    reporter.stop()

    assert shortfall_counts == []
    assert not reporter.is_active


# ---------------------------------------------------------------------------
# REPORT_EVERY — shortfall invokes callback
# ---------------------------------------------------------------------------


async def test_report_every_invokes_callback_on_shortfall():
    shortfall_counts: list[int] = []
    min_events = 2
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=min_events,
    )

    reporter.start()
    # Yields so the checker task runs; each loop awaits ``clock.sleep`` for
    # ``_CHECK_INTERVAL_MS``, advancing ``VirtualClock`` by one tick. After enough ticks,
    # grace ends and
    # the checker sees zero events, so the shortfall callback runs with count 0.
    await _trigger_event_loop_cycles(n=_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW)

    assert shortfall_counts[:1] == [0]
    reporter.stop()


async def test_report_every_no_callback_when_window_has_enough_events():
    shortfall_counts: list[int] = []
    min_events = 2
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=min_events,
    )

    reporter.start()
    clock.advance_ms(90)
    reporter.record_event()
    clock.advance_ms(1)
    reporter.record_event()
    # Each yield typically lets the checker run once, advancing ``now`` by about
    # ``_CHECK_INTERVAL_MS``. Rough upper bound on extra advance is
    # ``_YIELDS_LIGHT * _CHECK_INTERVAL_MS``, which is below ``_WINDOW_MS_DEFAULT``;
    # the two events sit just after 90 ms, so the window should still hold both
    # and no shortfall callback fires.
    await _trigger_event_loop_cycles(n=_YIELDS_LIGHT)

    assert shortfall_counts == []
    reporter.stop()


async def test_report_every_shortfall_after_staged_event_times():
    shortfall_counts: list[int] = []
    min_events = 2
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=min_events,
    )

    reporter.start()
    clock.advance_ms(50)
    reporter.record_event()
    reporter.record_event()
    await _trigger_event_loop_cycles(n=_YIELDS_EXPIRING_EVENTS)

    assert shortfall_counts[:1] == [0]
    reporter.stop()


# ---------------------------------------------------------------------------
# REPORT_ONCE_THEN_STOP — auto-stop, re-arm, clear window
# ---------------------------------------------------------------------------


async def test_report_once_then_stop_auto_stops_and_rearms():
    shortfall_counts: list[int] = []
    min_events = 3
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_ONCE_STOP,
        min_events=min_events,
    )

    reporter.start()
    await _trigger_event_loop_cycles(n=_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW)
    assert shortfall_counts == [0]
    assert not reporter.is_active

    shortfall_counts.clear()
    reporter.clear()
    reporter.start()
    assert reporter.is_active
    await _trigger_event_loop_cycles(n=_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW)
    assert shortfall_counts == [0]

    reporter.stop()


# ---------------------------------------------------------------------------
# Sliding window — old events expire (checker sees pruned count)
# ---------------------------------------------------------------------------


async def test_sliding_window_expires_old_events():
    shortfall_counts: list[int] = []
    min_events = 4
    check_interval_ms = _CHECK_INTERVAL_MS
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=min_events,
    )

    reporter.start()
    for step_ms in (0, 50, 110, 160, 200):
        clock.set_ms(step_ms)
        reporter.record_event()
    # The checker always ``await``s ``sleep`` before it reads ``now``. If ``now`` stayed
    # at 200 ms, the first read would be 210 ms. Rewind so one ``sleep(check_interval)``
    # lands the first read at ``rewind_ms + check_interval_ms`` ms.
    rewind_ms = 190
    clock.set_ms(rewind_ms)
    first_checker_now_ms = rewind_ms + check_interval_ms
    # One ``asyncio.sleep(0)`` resumes the checker through ``VirtualClock.sleep``'s
    # injected ``await asyncio.sleep(0)`` (clock reaches 200 ms) but not always
    # through the evaluation that follows; a second yield completes the first check.
    await _trigger_event_loop_cycles(n=2)
    assert clock.monotonic_ns() == (first_checker_now_ms + check_interval_ms) * _NS_PER_MS
    assert shortfall_counts == [3]

    # Logical t = 200 ms: first read instant; three events still in the window.
    clock.set_ms(first_checker_now_ms)
    assert reporter.current_window_event_count == 3
    assert shortfall_counts == [3]

    # t = 250 ms: cutoff 150 ms; only timestamps at 160 ms and 200 ms remain.
    clock.set_ms(250)
    assert reporter.current_window_event_count == 2
    await _trigger_event_loop_cycles(n=2)
    assert shortfall_counts == [3, 2, 1]

    reporter.stop()


# ---------------------------------------------------------------------------
# Async callback dispatch
# ---------------------------------------------------------------------------


async def test_async_callback_is_awaited():
    shortfall_counts: list[int] = []

    async def async_cb(n: int) -> None:
        shortfall_counts.append(n)

    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        async_cb,
        clock,
        mode=_EVERY,
        min_events=2,
    )

    reporter.start()
    await _trigger_event_loop_cycles(n=_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW)

    assert shortfall_counts[:1] == [0]
    reporter.stop()


# ---------------------------------------------------------------------------
# clear() resets the window; stop() does not
# ---------------------------------------------------------------------------


async def test_clear_resets_window():
    """Clear drops recorded events; ``stop()`` not clearing the deque is not covered here."""
    shortfall_counts: list[int] = []
    min_events = 4
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=min_events,
    )

    reporter.start()
    for _ in range(4):
        reporter.record_event()
    await _trigger_event_loop_cycles(n=1)
    assert shortfall_counts == []

    reporter.clear()
    # Empty window after ``clear()``: cover the grace span in checker steps, plus
    # slack for ``VirtualClock``'s extra ``await asyncio.sleep(0)`` per checker tick.
    await _trigger_event_loop_cycles(
        n=math.ceil(_WINDOW_MS_DEFAULT / _CHECK_INTERVAL_MS)
        + _YIELDS_FIRST_SHORTFALL_SCHEDULING_SLACK
    )
    assert shortfall_counts[:1] == [0]

    reporter.stop()


# ---------------------------------------------------------------------------
# Grace period — no callback until a full window after start()
# ---------------------------------------------------------------------------


async def test_grace_period_skips_callback():
    shortfall_counts: list[int] = []
    window_ms = 1_000
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=2,
        window_ms=window_ms,
    )

    reporter.start()
    # Each checker sleep advances ``_CHECK_INTERVAL_MS``; stay under 1 s grace.
    await _trigger_event_loop_cycles(n=_YIELDS_WITHIN_1S_GRACE)
    assert shortfall_counts == []

    reporter.stop()


async def test_after_grace_insufficient_triggers_callback():
    shortfall_counts: list[int] = []
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        shortfall_counts.append,
        clock,
        mode=_EVERY,
        min_events=2,
    )

    reporter.start()
    await _trigger_event_loop_cycles(n=_YIELDS_UNTIL_FIRST_SHORTFALL_EMPTY_WINDOW)

    assert shortfall_counts[:1] == [0]
    reporter.stop()


# ---------------------------------------------------------------------------
# current_window_event_count — stale eviction
# ---------------------------------------------------------------------------


async def test_current_window_event_count():
    clock = VirtualClock()
    reporter = make_reporter_with_clock(
        lambda n: None,
        clock,
        mode=_EVERY,
        min_events=5,
    )
    reporter.start()
    reporter.record_event()
    clock.advance_ms(50)
    reporter.record_event()
    clock.set_ms(50)
    assert reporter.current_window_event_count == 2
    clock.set_ms(110)
    assert reporter.current_window_event_count == 1
    reporter.stop()
