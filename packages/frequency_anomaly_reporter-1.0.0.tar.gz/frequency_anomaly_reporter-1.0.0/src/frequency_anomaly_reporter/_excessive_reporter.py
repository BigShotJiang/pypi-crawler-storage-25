# Copyright (c) 2026 Ori Cohen https://github.com/ori88c/
# Licensed under the Apache License 2.0.

from __future__ import annotations

import inspect
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any


class ExcessiveFrequencyReportingMode(Enum):
    """Controls how the reporter behaves after the frequency threshold is
    first exceeded.

    ``REPORT_EVERY``
        Invoke the callback on **every** ``record_event()`` call that finds
        the sliding window over the configured threshold. Suitable for
        metrics and counters where each breach should be counted.

    ``REPORT_ONCE_THEN_STOP``
        Invoke the callback **once** on the first breach, then automatically
        stop the reporter. Further ``record_event()`` calls become silent
        no-ops until ``start()`` is called to re-arm. Suitable for fatal
        escalation where human or orchestrator intervention is expected.
    """

    REPORT_EVERY = "report_every"
    REPORT_ONCE_THEN_STOP = "report_once_then_stop"


@dataclass
class ExcessiveFrequencyReporterConfig:
    """Configuration for :class:`ExcessiveFrequencyReporter`.

    All fields are required — no defaults are provided. Callers must make
    an explicit choice for every parameter, including ``reporting_mode``,
    to avoid silent misconfiguration.

    Validation is performed in ``__post_init__`` and raises
    :class:`ValueError` or :class:`TypeError` on invalid inputs, so errors
    surface at config-creation time rather than at reporter-construction time.

    Fields:
        window_duration_ms: Length of the sliding window in milliseconds.
            Must be positive.
        max_events_in_window: Maximum number of events allowed within the
            window before the callback is invoked. The callback fires when
            the count *exceeds* this value. Must be positive.
        on_excessive_frequency: Callback invoked on threshold breach.
            Receives the current number of events in the window as its only
            argument. May be sync or async.
        reporting_mode: Controls callback invocation behaviour after the
            first breach. See :class:`ExcessiveFrequencyReportingMode`.
    """

    window_duration_ms: int
    max_events_in_window: int
    on_excessive_frequency: Callable[[int], Any]
    reporting_mode: ExcessiveFrequencyReportingMode

    def __post_init__(self) -> None:
        if self.window_duration_ms <= 0:
            raise ValueError(
                f"window_duration_ms must be positive, got {self.window_duration_ms}"
            )
        if self.max_events_in_window <= 0:
            raise ValueError(
                "max_events_in_window must be positive, "
                f"got {self.max_events_in_window}"
            )
        if not callable(self.on_excessive_frequency):
            raise TypeError("on_excessive_frequency must be callable")
        if not isinstance(self.reporting_mode, ExcessiveFrequencyReportingMode):
            raise TypeError(
                "reporting_mode must be an ExcessiveFrequencyReportingMode member, "
                f"got {type(self.reporting_mode).__name__}"
            )


class ExcessiveFrequencyReporter:
    """Sliding-window monitor that invokes a callback when event frequency
    exceeds a configured threshold.

    Internally maintains a :class:`~collections.deque` of monotonically
    increasing nanosecond timestamps (via :func:`time.monotonic_ns`).
    On each :meth:`record_event` call, timestamps outside the sliding window
    are pruned and the remaining count is compared against the threshold.

    Both synchronous and asynchronous callbacks are supported. The callback
    type is detected once at construction time via
    :func:`inspect.iscoroutinefunction`, so dispatch in :meth:`record_event`
    is a simple branch with no per-call introspection overhead.

    Usage::

        class PrivilegeEscalationMonitor:
            def __init__(self, siem_client: SiemClient) -> None:
                self._siem_client = siem_client
                config = ExcessiveFrequencyReporterConfig(
                    # window_duration_ms=...,
                    # max_events_in_window=...,
                    on_excessive_frequency=self._on_escalation_flood,
                    # reporting_mode=...,
                )
                self._reporter = ExcessiveFrequencyReporter(config)

            def start(self) -> None:
                self._reporter.start()

            def stop(self) -> None:
                self._reporter.stop()

            async def _on_escalation_flood(self, event_count: int) -> None:
                await self._siem_client.alert(
                    severity="CRITICAL",
                    detail=f"{event_count} unauthorised sudo attempts in window",
                )

            async def process_audit_entry(self, entry: AuditEntry) -> None:
                if entry.event_type == AuditEventType.SUDO_FAILURE:
                    await self._reporter.record_event()
    """

    __slots__ = (
        "_ascending_timestamps",
        "_is_active",
        "_is_async_callback",
        "_max_events_in_window",
        "_on_excessive_frequency",
        "_reporting_mode",
        "_window_duration_ns",
    )

    def __init__(self, config: ExcessiveFrequencyReporterConfig) -> None:
        self._window_duration_ns: int = config.window_duration_ms * 1_000_000
        self._max_events_in_window: int = config.max_events_in_window
        self._on_excessive_frequency: Callable[[int], Any] = (
            config.on_excessive_frequency
        )
        self._reporting_mode: ExcessiveFrequencyReportingMode = config.reporting_mode
        self._is_async_callback: bool = inspect.iscoroutinefunction(
            config.on_excessive_frequency
        )
        self._ascending_timestamps: deque[int] = deque()
        self._is_active: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def is_active(self) -> bool:
        """Whether the reporter is currently active.

        When inactive, :meth:`record_event` silently returns without
        recording anything or invoking the callback.
        """
        return self._is_active

    def start(self) -> None:
        """Activate the reporter for the first time, or re-arm it after it
        has been stopped.

        Sets the reporter to active without touching the window contents.
        To start with a clean slate, call :meth:`clear` before or after
        ``start()``. Idempotent — calling ``start()`` on an already-active
        reporter is a no-op.
        """
        if self._is_active:
            return
        self._is_active = True

    def stop(self) -> None:
        """Deactivate the reporter.

        Sets the reporter to inactive without touching the window contents.
        To discard accumulated history, call :meth:`clear` explicitly.
        Idempotent — calling ``stop()`` on an already-stopped reporter is
        a no-op.
        """
        if not self._is_active:
            return
        self._is_active = False

    def clear(self) -> None:
        """Remove all recorded timestamps from the sliding window.

        Clearing is independent of the active/inactive state and can be
        called at any time. Unlike :meth:`start` and :meth:`stop`, which
        manage the monitoring lifecycle, ``clear()`` is an explicit data
        reset — useful when the context that produced past events is no
        longer relevant (e.g. after a successful recovery).
        """
        self._ascending_timestamps.clear()

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    @property
    def current_window_event_count(self) -> int:
        """Number of events currently within the sliding window.

        Stale timestamps outside the window are evicted before counting,
        so the returned value always reflects the true trailing window.
        Useful for exposing live metrics without waiting for the next
        :meth:`record_event` call.
        """
        self._evict_stale_events(time.monotonic_ns())
        return len(self._ascending_timestamps)

    # ------------------------------------------------------------------
    # Event recording
    # ------------------------------------------------------------------

    async def record_event(self) -> None:
        """Record an event occurrence.

        If the number of events within the sliding window exceeds
        ``max_events_in_window``, the ``on_excessive_frequency`` callback
        is invoked with the current event count in the window.

        When the reporter is inactive (not yet started, or stopped), this
        method silently returns.
        """
        if not self._is_active:
            return

        now = time.monotonic_ns()
        self._evict_stale_events(now)
        self._ascending_timestamps.append(now)

        if len(self._ascending_timestamps) > self._max_events_in_window:
            if (
                self._reporting_mode
                is ExcessiveFrequencyReportingMode.REPORT_ONCE_THEN_STOP
            ):
                self._is_active = False

            event_count = len(self._ascending_timestamps)
            if self._is_async_callback:
                await self._on_excessive_frequency(event_count)
            else:
                self._on_excessive_frequency(event_count)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _evict_stale_events(self, now: int) -> None:
        cutoff = now - self._window_duration_ns
        while self._ascending_timestamps and self._ascending_timestamps[0] <= cutoff:
            self._ascending_timestamps.popleft()
