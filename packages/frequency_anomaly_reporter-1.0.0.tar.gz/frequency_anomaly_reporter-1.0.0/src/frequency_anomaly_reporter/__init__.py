"""frequency-anomaly-reporter — sliding-window event-frequency monitors."""

from __future__ import annotations

from importlib.metadata import version

from frequency_anomaly_reporter._excessive_reporter import (
    ExcessiveFrequencyReporter,
    ExcessiveFrequencyReporterConfig,
    ExcessiveFrequencyReportingMode,
)
from frequency_anomaly_reporter._insufficient_reporter import (
    InsufficientFrequencyReporter,
    InsufficientFrequencyReporterConfig,
    InsufficientFrequencyReportingMode,
)

__version__ = version("frequency-anomaly-reporter")

__all__ = [
    "ExcessiveFrequencyReporter",
    "ExcessiveFrequencyReporterConfig",
    "ExcessiveFrequencyReportingMode",
    "InsufficientFrequencyReporter",
    "InsufficientFrequencyReporterConfig",
    "InsufficientFrequencyReportingMode",
    "__version__",
]
