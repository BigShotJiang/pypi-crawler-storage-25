# Copyright (c) 2026 Ori Cohen https://github.com/ori88c/
# Licensed under the Apache License 2.0.

from __future__ import annotations

import asyncio
import inspect
import time
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class InsufficientFrequencyReportingMode(Enum):
    """Controls how the reporter behaves after a low-frequency condition is
    detected by the periodic checker.

    ``REPORT_EVERY``
        Invoke the callback on **every** check cycle that finds the sliding
        window below the configured minimum. Suitable for continuous alerting
        where each missed-heartbeat window should be counted.

    ``REPORT_ONCE_THEN_STOP``
        Invoke the callback **once** on the first detected shortfall, then
        automatically stop the reporter. Further check cycles become no-ops
        until ``start()`` is called to re-arm. Suitable for scenarios where
        human or orchestrator intervention is expected before monitoring
        resumes.
    """

    REPORT_EVERY = "report_every"
    REPORT_ONCE_THEN_STOP = "report_once_then_stop"


@dataclass
class InsufficientFrequencyReporterConfig:
    """Configuration for :class:`InsufficientFrequencyReporter`.

    The first five fields are required — callers must make an explicit choice
    for each, including ``reporting_mode``, to avoid silent misconfiguration.

    Optional internal hooks (``_monotonic_ns``, ``_sleep``) default to
    :func:`time.monotonic_ns` and :func:`asyncio.sleep` respectively. They exist
    for dependency injection in tests and are **not** part of the supported
    public contract for application code. They are omitted from ``repr()``.

    Validation is performed in ``__post_init__`` and raises
    :class:`ValueError` or :class:`TypeError` on invalid inputs, so errors
    surface at config-creation time rather than at reporter-construction time.

    Fields:
        window_duration_ms: Length of the sliding window in milliseconds.
            Must be positive.
        min_events_in_window: Minimum number of events expected within the
            window. The callback fires when the count is *below* this value.
            Must be positive.
        check_interval_ms: How often the periodic checker evaluates the
            window, in milliseconds. Must be positive.
        on_insufficient_frequency: Callback invoked when the window event
            count falls below ``min_events_in_window``. Receives the current
            count as its only argument. May be sync or async.

            **The callback must not raise.** It is invoked from a background
            ``asyncio.Task``, so an unhandled exception would silently
            terminate the checker loop. Wrap the body in a try/except if
            there is any risk of failure.
        reporting_mode: Controls callback invocation behaviour after the
            first detected shortfall. See
            :class:`InsufficientFrequencyReportingMode`.
    """

    window_duration_ms: int
    min_events_in_window: int
    check_interval_ms: int
    on_insufficient_frequency: Callable[[int], Any]
    reporting_mode: InsufficientFrequencyReportingMode
    _monotonic_ns: Callable[[], int] = field(
        default=time.monotonic_ns,
        repr=False,
    )
    _sleep: Callable[[float], Awaitable[None]] = field(
        default=asyncio.sleep,
        repr=False,
    )

    def __post_init__(self) -> None:
        if self.window_duration_ms <= 0:
            raise ValueError(
                f"window_duration_ms must be positive, got {self.window_duration_ms}"
            )
        if self.min_events_in_window <= 0:
            raise ValueError(
                "min_events_in_window must be positive, "
                f"got {self.min_events_in_window}"
            )
        if self.check_interval_ms <= 0:
            raise ValueError(
                f"check_interval_ms must be positive, got {self.check_interval_ms}"
            )
        if not callable(self.on_insufficient_frequency):
            raise TypeError("on_insufficient_frequency must be callable")
        if not isinstance(self.reporting_mode, InsufficientFrequencyReportingMode):
            raise TypeError(
                "reporting_mode must be an InsufficientFrequencyReportingMode member, "
                f"got {type(self.reporting_mode).__name__}"
            )
        if not callable(self._monotonic_ns):
            raise TypeError("_monotonic_ns must be callable")
        if not callable(self._sleep):
            raise TypeError("_sleep must be callable")


class InsufficientFrequencyReporter:
    """Sliding-window monitor that invokes a callback when event frequency
    falls below a configured minimum threshold.

    Internally maintains a :class:`~collections.deque` of monotonically
    increasing nanosecond timestamps from the configured clock (by default
    :func:`time.monotonic_ns`).
    Unlike :class:`ExcessiveFrequencyReporter`, the threshold check is **not**
    driven by incoming events. Instead, :meth:`start` spawns a background
    ``asyncio.Task`` that wakes at a configurable ``check_interval_ms`` and
    compares ``min_events_in_window`` against how many recorded events fall
    inside the sliding window that ends at the current check instant.

    A **grace period** equal to ``window_duration_ms`` is observed after every
    :meth:`start` call. The checker silently skips reporting while less than a
    full window has elapsed, because the window cannot yet be considered
    meaningfully "too quiet".

    Both synchronous and asynchronous callbacks are supported. The callback
    type is detected once at construction time via
    :func:`inspect.iscoroutinefunction`, so dispatch in the checker adds no
    per-cycle introspection overhead.

    **Callback contract**: the callback **must not raise**. It runs inside a
    background task; an unhandled exception would silently terminate the
    checker loop. Wrap the callback body in a ``try/except`` if there is any
    risk of failure.

    Usage::

        class HeartbeatMonitor:
            def __init__(self, alerting_client: AlertingClient) -> None:
                self._alerting_client = alerting_client
                config = InsufficientFrequencyReporterConfig(
                    # window_duration_ms=...,
                    # min_events_in_window=...,
                    # check_interval_ms=...,
                    on_insufficient_frequency=self._on_heartbeat_silence,
                    # reporting_mode=...,
                )
                self._reporter = InsufficientFrequencyReporter(config)

            def start(self) -> None:
                self._reporter.start()

            def stop(self) -> None:
                self._reporter.stop()

            async def _on_heartbeat_silence(self, event_count: int) -> None:
                await self._alerting_client.alert(
                    severity="WARNING",
                    detail=f"Only {event_count} heartbeats in window",
                )

            def on_heartbeat_received(self) -> None:
                # record_event() is sync — no await needed
                self._reporter.record_event()
    """

    __slots__ = (
        "_ascending_timestamps",
        "_check_interval_s",
        "_check_task",
        "_is_active",
        "_is_async_callback",
        "_last_start_ns",
        "_min_events_in_window",
        "_monotonic_ns",
        "_on_insufficient_frequency",
        "_reporting_mode",
        "_sleep",
        "_window_duration_ns",
    )

    def __init__(self, config: InsufficientFrequencyReporterConfig) -> None:
        self._window_duration_ns: int = config.window_duration_ms * 1_000_000
        self._min_events_in_window: int = config.min_events_in_window
        self._check_interval_s: float = config.check_interval_ms / 1000
        self._on_insufficient_frequency: Callable[[int], Any] = (
            config.on_insufficient_frequency
        )
        self._reporting_mode: InsufficientFrequencyReportingMode = config.reporting_mode
        self._is_async_callback: bool = inspect.iscoroutinefunction(
            config.on_insufficient_frequency
        )
        self._ascending_timestamps: deque[int] = deque()
        self._check_task: asyncio.Task[None] | None = None
        self._last_start_ns: int = 0
        self._is_active: bool = False
        self._monotonic_ns: Callable[[], int] = config._monotonic_ns
        self._sleep: Callable[[float], Awaitable[None]] = config._sleep

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def is_active(self) -> bool:
        """Whether the reporter is currently active.

        When inactive, :meth:`record_event` is a silent no-op and the
        periodic checker does not run.
        """
        return self._is_active

    def start(self) -> None:
        """Activate the reporter and launch the periodic background checker.

        Records the current monotonic time as the start of the grace period,
        then spawns an ``asyncio.Task`` that evaluates the sliding window at
        every ``check_interval_ms``. Must be called from within a running
        asyncio event loop.

        Window contents are not touched — to start with a clean slate call
        :meth:`clear` before or after ``start()``. Idempotent — calling
        ``start()`` on an already-active reporter is a no-op.
        """
        if self._is_active:
            return
        self._last_start_ns = self._monotonic_ns()
        self._is_active = True
        self._check_task = asyncio.get_running_loop().create_task(
            self._periodic_check()
        )

    def stop(self) -> None:
        """Deactivate the reporter and cancel the periodic background checker.

        Window contents are not touched — to discard accumulated history call
        :meth:`clear` explicitly. Idempotent — calling ``stop()`` on an
        already-stopped reporter is a no-op.
        """
        if not self._is_active:
            return
        self._is_active = False
        if self._check_task is not None:
            self._check_task.cancel()
            self._check_task = None

    def clear(self) -> None:
        """Remove all recorded timestamps from the sliding window.

        Clearing is independent of the active/inactive state and can be
        called at any time. Unlike :meth:`start` and :meth:`stop`, which
        manage the monitoring lifecycle, ``clear()`` is an explicit data
        reset — useful when the context that produced past events is no
        longer relevant (e.g. after a service restart or recovery event).
        """
        self._ascending_timestamps.clear()

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    @property
    def current_window_event_count(self) -> int:
        """Number of events currently within the sliding window.

        Stale timestamps outside the window are evicted before counting,
        so the returned value always reflects the true trailing window.
        Useful for exposing live metrics without waiting for the next
        checker cycle.
        """
        self._evict_stale_events(self._monotonic_ns())
        return len(self._ascending_timestamps)

    # ------------------------------------------------------------------
    # Event recording
    # ------------------------------------------------------------------

    def record_event(self) -> None:
        """Record an event occurrence.

        Appends a monotonic nanosecond timestamp to the internal deque.
        This is a **synchronous** method — no callback is invoked here;
        the periodic checker is solely responsible for evaluating the window
        and firing the callback.

        When the reporter is inactive (not yet started, or stopped), this
        method silently returns.
        """
        if not self._is_active:
            return
        self._ascending_timestamps.append(self._monotonic_ns())

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _periodic_check(self) -> None:
        try:
            while self._is_active:
                await self._sleep(self._check_interval_s)

                if not self._is_active:
                    return

                now = self._monotonic_ns()

                # Grace period: skip until a full window has elapsed since start()
                if now - self._last_start_ns < self._window_duration_ns:
                    continue

                self._evict_stale_events(now)
                event_count = len(self._ascending_timestamps)

                if event_count >= self._min_events_in_window:
                    continue

                if (
                    self._reporting_mode
                    is InsufficientFrequencyReportingMode.REPORT_ONCE_THEN_STOP
                ):
                    self._is_active = False

                if self._is_async_callback:
                    await self._on_insufficient_frequency(event_count)
                else:
                    self._on_insufficient_frequency(event_count)

                if not self._is_active:
                    return
        except asyncio.CancelledError:
            pass

    def _evict_stale_events(self, now: int) -> None:
        cutoff = now - self._window_duration_ns
        while self._ascending_timestamps and self._ascending_timestamps[0] <= cutoff:
            self._ascending_timestamps.popleft()
