from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Callable
from uuid import UUID

import httpx
import pytest
from uuid_utils import uuid7

from ellf_pam_sdk import AccessTokenCredential, Client
from ellf_pam_sdk import errors as sdk_errors
from ellf_pam_sdk.client.base import ItemIterator
from ellf_pam_sdk.client.project_plan import (
    ProjectPlanRevisionSummary,
    ProjectPlanSummary,
)
from ellf_pam_sdk.ty import Page

BASE_URL = "https://app.explosion.rocks"
Handler = Callable[[httpx.Request], httpx.Response]


def _make_client(handler: Handler) -> Client:
    cred = AccessTokenCredential(access_token="")
    client = Client(BASE_URL, cred)
    transport = httpx.MockTransport(handler)
    mock_sync = httpx.Client(base_url=BASE_URL, transport=transport)
    client.project_plan._sync_client = mock_sync
    return client


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _detail_payload(
    *,
    plan_id: UUID,
    project_id: UUID,
    name: str,
    content: str,
    version: int,
    user_id: UUID,
) -> dict:
    return {
        "id": str(plan_id),
        "project_id": str(project_id),
        "name": name,
        "content": content,
        "version": version,
        "updated_by_id": str(user_id),
        "created": _now().isoformat(),
        "updated": _now().isoformat(),
    }


def _revision_summary_payload(
    *, plan_id: UUID, version: int, user_id: UUID, rev_id: UUID | None = None
) -> dict:
    return {
        "id": str(rev_id or UUID(str(uuid7()))),
        "plan_id": str(plan_id),
        "version": version,
        "created_by_id": str(user_id),
        "created": _now().isoformat(),
        "updated": _now().isoformat(),
    }


def test_upsert_with_expected_version_forwards_value_and_returns_detail():
    plan_id = UUID(str(uuid7()))
    project_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    seen: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/project-plan/upsert"
        body = json.loads(request.content.decode())
        seen.append(body)
        return httpx.Response(
            200,
            json=_detail_payload(
                plan_id=plan_id,
                project_id=project_id,
                name=body["name"],
                content=body["content"],
                version=body["expected_version"] + 1,
                user_id=user_id,
            ),
        )

    client = _make_client(handler)
    detail = client.project_plan.upsert(project_id, content="next", expected_version=3)

    assert seen == [
        {
            "project_id": str(project_id),
            "name": "project_plan",
            "content": "next",
            "expected_version": 3,
        }
    ]
    assert detail.version == 4
    assert detail.content == "next"
    assert detail.updated_by_id == user_id


def test_upsert_without_expected_version_sends_null():
    """First-write callers don't have a version; the field is sent as null."""
    plan_id = UUID(str(uuid7()))
    project_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    seen: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode())
        seen.append(body)
        return httpx.Response(
            200,
            json=_detail_payload(
                plan_id=plan_id,
                project_id=project_id,
                name=body["name"],
                content=body["content"],
                version=1,
                user_id=user_id,
            ),
        )

    client = _make_client(handler)
    client.project_plan.upsert(project_id, content="hello")

    assert seen[0]["expected_version"] is None


def test_upsert_stale_expected_version_raises_version_conflict():
    plan_id = UUID(str(uuid7()))
    project_id = UUID(str(uuid7()))

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            409,
            json={
                "error": "version_conflict",
                "detail": "version conflict; current is 5",
                "type": "ProjectPlanVersionConflict",
                "current_version": 5,
                "current_content": "current head body",
                "current_id": str(plan_id),
            },
        )

    client = _make_client(handler)
    with pytest.raises(sdk_errors.ProjectPlanVersionConflict) as excinfo:
        client.project_plan.upsert(project_id, content="stomp", expected_version=2)

    err = excinfo.value
    assert err.current_version == 5
    assert err.current_content == "current head body"
    assert err.current_id == plan_id


def test_list_revisions_returns_page_with_cursor():
    plan_id = UUID(str(uuid7()))
    project_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    rev_id = UUID(str(uuid7()))

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/project-plan-revisions/list"
        body = json.loads(request.content.decode())
        assert body == {"project_id": str(project_id), "name": "project_plan"}
        assert request.url.params.get("size") == "50"
        return httpx.Response(
            200,
            json={
                "items": [
                    _revision_summary_payload(
                        plan_id=plan_id, version=2, user_id=user_id, rev_id=rev_id
                    ),
                    _revision_summary_payload(
                        plan_id=plan_id, version=1, user_id=user_id
                    ),
                ],
                "next_cursor": str(rev_id),
                "has_more": True,
            },
        )

    client = _make_client(handler)
    page = client.project_plan.list_revisions(project_id)

    assert isinstance(page, Page)
    assert [r.version for r in page.items] == [2, 1]
    assert page.next_cursor == str(rev_id)
    assert page.has_more is True


def test_item_iterator_traverses_all_revision_pages():
    plan_id = UUID(str(uuid7()))
    project_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    page1_last_id = UUID(str(uuid7()))

    pages_payload = [
        {
            "items": [
                _revision_summary_payload(plan_id=plan_id, version=3, user_id=user_id),
                _revision_summary_payload(
                    plan_id=plan_id,
                    version=2,
                    user_id=user_id,
                    rev_id=page1_last_id,
                ),
            ],
            "next_cursor": str(page1_last_id),
            "has_more": True,
        },
        {
            "items": [
                _revision_summary_payload(plan_id=plan_id, version=1, user_id=user_id),
            ],
            "next_cursor": None,
            "has_more": False,
        },
    ]
    seen_after: list[str | None] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params.get("size") == "2"
        seen_after.append(request.url.params.get("after"))
        return httpx.Response(200, json=pages_payload.pop(0))

    client = _make_client(handler)

    iterator: ItemIterator[ProjectPlanRevisionSummary] = ItemIterator(
        lambda cursor: client.project_plan.list_revisions(
            project_id,
            after=UUID(cursor) if cursor else None,
            size=2,
        )
    )
    versions = [r.version for r in iterator]

    assert versions == [3, 2, 1]
    assert seen_after == [None, str(page1_last_id)]


def test_read_revision_returns_historical_content():
    plan_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    rev_id = UUID(str(uuid7()))

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/project-plan-revision/read"
        body = json.loads(request.content.decode())
        assert body == {"plan_id": str(plan_id), "version": 1}
        return httpx.Response(
            200,
            json={
                "id": str(rev_id),
                "plan_id": str(plan_id),
                "version": 1,
                "content": "v1 body",
                "created_by_id": str(user_id),
                "created": _now().isoformat(),
                "updated": _now().isoformat(),
            },
        )

    client = _make_client(handler)
    rev = client.project_plan.read_revision(plan_id=plan_id, version=1)

    assert rev.version == 1
    assert rev.content == "v1 body"
    assert rev.created_by_id == user_id


def test_summary_includes_version_and_updated_by_id():
    project_id = UUID(str(uuid7()))
    user_id = UUID(str(uuid7()))
    summary = ProjectPlanSummary(
        id=UUID(str(uuid7())),
        project_id=project_id,
        name="project_plan",
        version=7,
        updated_by_id=user_id,
        created=_now(),
        updated=_now(),
    )
    assert summary.version == 7
    assert summary.updated_by_id == user_id
