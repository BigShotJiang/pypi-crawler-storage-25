from datetime import datetime, timezone
from uuid import UUID

import pytest
from uuid_utils import uuid7

from ellf_pam_sdk import AccessTokenCredential, Client
from ellf_pam_sdk.ty import Page


@pytest.fixture
def client() -> Client:
    cred = AccessTokenCredential(access_token="")
    client = Client("https://app.explosion.rocks", cred)
    return client


def test_client_init(client: Client):
    assert client.base_url == "https://app.explosion.rocks"


def test_all_iterates_across_pages(client: Client, monkeypatch: pytest.MonkeyPatch):
    project_a = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="a",
        description="",
    )
    project_b = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="b",
        description="",
    )
    pages = [
        Page[type(project_a)](
            items=[project_a],
            next_cursor=str(project_a.id),
            has_more=True,
        ),
        Page[type(project_b)](
            items=[project_b],
            next_cursor=None,
            has_more=False,
        ),
    ]
    seen_requests: list[tuple[str | None, int | None]] = []

    def fake_read_all_page(
        *_args,
        after: str | None = None,
        size: int | None = None,
        **_kwargs,
    ):
        seen_requests.append((after, size))
        return pages.pop(0)

    monkeypatch.setattr(client.project, "_read_all_page", fake_read_all_page)

    items = list(client.project.all(page_size=1))

    assert [item.name for item in items] == ["a", "b"]
    assert seen_requests == [(None, 1), (str(project_a.id), 1)]


def test_all_pages_exposes_page_objects(
    client: Client, monkeypatch: pytest.MonkeyPatch
):
    project = client.project.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        org_id=UUID(str(uuid7())),
        name="only-page",
        description="",
    )
    page = Page[type(project)](items=[project], next_cursor=None, has_more=False)

    monkeypatch.setattr(
        client.project, "_read_all_page", lambda *_args, **_kwargs: page
    )

    pages = list(client.project.all().pages())

    assert len(pages) == 1
    assert pages[0].items[0].name == "only-page"


def test_all_latest_iterates_across_pages(
    client: Client, monkeypatch: pytest.MonkeyPatch
):
    package_a = client.package.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        name="a",
        version="1.0.0",
        container="cpu",
        recipe_count=0,
    )
    package_b = client.package.Summary(
        id=UUID(str(uuid7())),
        created=datetime.now(timezone.utc),
        updated=datetime.now(timezone.utc),
        name="b",
        version="1.0.0",
        container="cpu",
        recipe_count=0,
    )
    pages = [
        Page[type(package_a)](
            items=[package_a],
            next_cursor=str(package_a.id),
            has_more=True,
        ),
        Page[type(package_b)](
            items=[package_b],
            next_cursor=None,
            has_more=False,
        ),
    ]
    seen_requests: list[tuple[str | None, int | None]] = []

    def fake_read_all_latest_page(
        *_args,
        after: str | None = None,
        size: int | None = None,
        **_kwargs,
    ):
        seen_requests.append((after, size))
        return pages.pop(0)

    monkeypatch.setattr(
        client.package, "_read_all_latest_page", fake_read_all_latest_page
    )

    items = list(
        client.package.all_latest(body=client.package.ListingLatest(), page_size=1)
    )

    assert [item.name for item in items] == ["a", "b"]
    assert seen_requests == [(None, 1), (str(package_a.id), 1)]


def test_all_rejects_conflicting_page_sizes(client: Client):
    with pytest.raises(ValueError, match="page_size or size"):
        client.project.all(page_size=1, size=2)


def test_stream_cluster_settings_sets_read_timeout(
    client: Client, monkeypatch: pytest.MonkeyPatch
):
    """The SSE stream must have a finite read timeout.

    PAM emits a `: keepalive` line every 30s; without a read timeout the
    async-for blocks forever on a TCP connection that has died silently
    (no FIN/RST). The 21h CPL outage on skalitzer (2026-04-28) was caused
    by ``timeout=None`` here.
    """
    import asyncio

    import httpx

    captured: dict[str, object] = {}

    class _FakeStreamCM:
        async def __aenter__(self):
            raise RuntimeError("stop-after-stream-call")

        async def __aexit__(self, exc_type, exc, tb):
            return False

    def fake_stream(method, url, **kwargs):
        captured["method"] = method
        captured["url"] = url
        captured["timeout"] = kwargs.get("timeout")
        return _FakeStreamCM()

    monkeypatch.setattr(client.for_cluster._async_client, "stream", fake_stream)

    async def _consume():
        async for _ in client.for_cluster.stream_cluster_settings():
            return

    with pytest.raises(RuntimeError, match="stop-after-stream-call"):
        asyncio.run(_consume())

    assert captured["method"] == "GET"
    assert captured["url"] == "/api/v1/stream/cluster-settings"
    timeout = captured["timeout"]
    assert isinstance(timeout, httpx.Timeout)
    # Read timeout must be > PAM's 30s keepalive interval and finite.
    assert timeout.read is not None
    assert timeout.read > 30.0
