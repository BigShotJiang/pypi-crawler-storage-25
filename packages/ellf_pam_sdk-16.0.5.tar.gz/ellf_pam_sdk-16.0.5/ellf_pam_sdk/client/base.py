import json
from typing import (
    IO,
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    Generic,
    Iterator,
    TypeVar,
    cast,
)

import httpx
from pydantic import BaseModel

from .. import errors
from ..ty import Page


def _resolve_error_cls(
    errors_module: Any,
    error_type: str | None,
    fallback_name: str,
    default: type[errors.EllfError],
) -> type[errors.EllfError]:
    """Resolve an SDK error class from the server's concrete error type name.

    Prefers the exact ``type`` returned by the server (e.g. ``PackageForbiddenDelete``),
    falling back to ``fallback_name`` (e.g. ``PackageForbidden``), then ``default``.
    """
    if error_type:
        cls = getattr(errors_module, error_type, None)
        if cls is not None:
            return cls
    return getattr(errors_module, fallback_name, default)


class RawIteratorIO(IO[bytes]):
    """
    Creates a IO[bytes] from a bytes iterator.

    Adapted from https://stackoverflow.com/a/12604375/7426717
    """

    _it: Iterator[bytes]
    _memory: bytes

    def __init__(self, it: Iterator[bytes]) -> None:
        self._it = it
        self._memory = b""

        super().__init__()

    def _read1(self, n: int | None = None) -> bytes:
        while not self._memory:
            try:
                next_memory = next(self._it)
            except StopIteration:
                break
            else:
                self._memory = next_memory

        chunk = self._memory[:n]
        self._memory = self._memory[len(chunk) :]

        return chunk

    def read(self, n: int | None = None) -> bytes:
        chunks: list[bytes] = []
        if n is None or n < 0:
            while True:
                m = self._read1()
                if not m:
                    break
                chunks.append(m)
        else:
            while n > 0:
                m = self._read1(n)
                if not m:
                    break
                n -= len(m)
                chunks.append(m)
        return b"".join(chunks)


CHUNK_SIZE = 1024


class BaseClient:
    name: str
    url: str

    def __init__(
        self, sync_client: httpx.Client, async_client: httpx.AsyncClient, path: str
    ) -> None:
        self._sync_client = sync_client
        self._async_client = async_client
        if path.startswith("/"):
            path = path[1:]
        self.name = path.split("/")[-1]
        self.path = f"/{path}"

    def request(
        self,
        method: str,
        *,
        endpoint: str | None = None,
        params: BaseModel | dict[str, Any] | None = None,
        data: BaseModel | dict[str, Any] | None = None,
        headers: dict[str, str] = {},
        after: str | None = None,
        size: int | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        stream: bool = False,
        return_model: type[BaseModel] | None = None,
    ) -> BaseModel | Page[BaseModel] | RawIteratorIO | None:
        req = self._get_validated_request(
            method=method,
            endpoint=endpoint or "",
            params=params,
            data=data,
            params_model=params_model,
            body_model=body_model,
            headers=headers,
            after=after,
            size=size,
        )
        response = self._sync_client.send(req, stream=stream)
        self._raise_and_handle_errors(response)
        content = None
        if (
            response.headers.get("content-type") == "application/json"
            and response.status_code != 204
        ):
            content = response.json()
        if return_model is not None:
            return self._convert_response_to_model(content, return_model)
        return RawIteratorIO(response.iter_bytes(chunk_size=CHUNK_SIZE))

    async def request_async(
        self,
        method: str,
        *,
        endpoint: str | None = None,
        params: BaseModel | dict[str, Any] | None = None,
        data: BaseModel | dict[str, Any] | None = None,
        headers: dict[str, str] = {},
        after: str | None = None,
        size: int | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        stream: bool = False,
        return_model: type[BaseModel] | None = None,
    ) -> BaseModel | Page[BaseModel] | None:
        req = self._get_validated_request(
            method=method,
            endpoint=endpoint or "",
            params=params,
            data=data,
            params_model=params_model,
            body_model=body_model,
            headers=headers,
            after=after,
            size=size,
        )
        response = await self._async_client.send(req, stream=stream)
        self._raise_and_handle_errors(response)
        content = None
        if response.content:
            content = response.json()
        if return_model is not None:
            return self._convert_response_to_model(content, return_model)

    def _get_validated_request(
        self,
        *,
        method: str,
        endpoint: str,
        params: BaseModel | dict[str, Any] | None = None,
        data: BaseModel | dict[str, Any] | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        headers: dict[str, str] | None = None,
        after: str | None = None,
        size: int | None = None,
    ) -> httpx.Request:
        url = self.path
        if endpoint:
            if endpoint.startswith("/"):
                url = endpoint
            else:
                url = f"{self.path}/{endpoint}"
        local_params: dict[str, Any] = {}
        if after is not None:
            local_params["after"] = after
        if size is not None:
            local_params["size"] = size
        if params is not None:
            if isinstance(params, dict):
                params.update(local_params)
                if params_model is not None:
                    # if params_model is passed, use Pydantic to validate params
                    params = params_model(**params)
                    params = params.model_dump()
            elif isinstance(params, BaseModel):
                params = params.model_dump(exclude_none=True, exclude_defaults=True)
                params.update(local_params)
        elif local_params:
            params = local_params
        content = None
        if data is not None:
            if isinstance(data, dict):
                if body_model is not None:
                    body = body_model(**data)
                    content = body.model_dump_json()
                else:
                    content = json.dumps(data)
            elif isinstance(data, BaseModel):
                content = data.model_dump_json()
        req = self._sync_client.build_request(
            method, url, headers=headers, params=params, content=content
        )
        return req

    def _raise_and_handle_errors(self, response: httpx.Response) -> None:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            error_type = None
            sdk_error = None
            try:
                error_data = e.response.json()
            except json.JSONDecodeError:
                error_data = {}
            if isinstance(error_data, dict):
                detail = error_data.get("detail")
                error_type = error_data.get("type")
            else:
                detail = error_data
            if error_type:
                sdk_error = getattr(errors, error_type, None)
            if sdk_error:
                extras: dict[str, Any] = {}
                if isinstance(error_data, dict):
                    for k in ("current_version", "current_content", "current_id"):
                        if k in error_data:
                            extras[k] = error_data[k]
                raise sdk_error(detail=str(detail), **extras)
            elif status == 401:
                raise errors.AuthError(detail=str(detail))
            else:
                raise e

    def _convert_response_to_model(
        self, data: Any, return_model: type[BaseModel]
    ) -> BaseModel | Page[BaseModel] | None:
        """Convert the JSON response to the correct Pydantic model"""
        if data is None:
            return data
        return return_model.model_validate(data)


_TItem = TypeVar("_TItem", bound=BaseModel)


def _resolve_page_size(
    *, page_size: int | None = None, size: int | None = None
) -> int | None:
    if page_size is not None and size is not None:
        raise ValueError("Pass either page_size or size, not both")
    return page_size if page_size is not None else size


class ItemIterator(Generic[_TItem]):
    def __init__(
        self,
        fetch_page: Callable[[str | None], Page[_TItem]],
        *,
        after: str | None = None,
    ) -> None:
        self._fetch_page = fetch_page
        self._after = after

    def __iter__(self) -> Iterator[_TItem]:
        for page in self.pages():
            yield from page.items

    def pages(self) -> Iterator[Page[_TItem]]:
        cursor = self._after
        while True:
            page = self._fetch_page(cursor)
            yield page
            if not page.has_more or page.next_cursor is None:
                break
            cursor = page.next_cursor

    def first_page(self) -> Page[_TItem]:
        return self._fetch_page(self._after)


class AsyncItemIterator(Generic[_TItem]):
    def __init__(
        self,
        fetch_page: Callable[[str | None], Awaitable[Page[_TItem]]],
        *,
        after: str | None = None,
    ) -> None:
        self._fetch_page = fetch_page
        self._after = after

    def __aiter__(self) -> AsyncIterator[_TItem]:
        return self._iterate_items()

    async def _iterate_items(self) -> AsyncIterator[_TItem]:
        async for page in self.pages():
            for item in page.items:
                yield item

    async def pages(self) -> AsyncIterator[Page[_TItem]]:
        cursor = self._after
        while True:
            page = await self._fetch_page(cursor)
            yield page
            if not page.has_more or page.next_cursor is None:
                break
            cursor = page.next_cursor

    async def first_page(self) -> Page[_TItem]:
        return await self._fetch_page(self._after)


_Creating = TypeVar("_Creating", bound=BaseModel)
_Reading = TypeVar("_Reading", bound=BaseModel)
_Updating = TypeVar("_Updating", bound=BaseModel)
_Deleting = TypeVar("_Deleting", bound=BaseModel)
_Summary = TypeVar("_Summary", bound=BaseModel)
_Detail = TypeVar("_Detail", bound=BaseModel)


class ModelClient(
    BaseClient,
    Generic[_Creating, _Reading, _Updating, _Deleting, _Summary, _Detail],
):
    Creating: type[_Creating]
    Reading: type[_Reading]
    Updating: type[_Updating]
    Deleting: type[_Deleting]
    Summary: type[_Summary]
    Detail: type[_Detail]

    def __init__(
        self, sync_client: httpx.Client, async_client: httpx.AsyncClient, path: str
    ) -> None:
        super().__init__(sync_client, async_client, path)
        self.plural_path = self.path if self.path.endswith("s") else f"{self.path}s"

    def create(self, data: _Creating | None = None, **kwargs: Any) -> _Detail:
        data = data if data else self.Creating(**kwargs)
        res = self.request(
            "POST",
            endpoint="create",
            data=data,
            return_model=self.Detail,
        )
        return cast(_Detail, res)

    async def create_async(
        self, data: _Creating | None = None, **kwargs: Any
    ) -> _Detail:
        data = data if data else self.Creating(**kwargs)
        res = await self.request_async(
            "POST",
            endpoint="create",
            data=data,
            return_model=self.Detail,
        )
        return cast(_Detail, res)

    def read(self, query: _Reading | None = None, **kwargs: Any) -> _Detail:
        data = query if query else self.Reading(**kwargs)
        res = self.request(
            "POST",
            endpoint="read",
            data=data,
            return_model=self.Detail,
        )
        return cast(_Detail, res)

    async def read_async(self, query: _Reading | None = None, **kwargs: Any) -> _Detail:
        data = query if query else self.Reading(**kwargs)
        res = await self.request_async(
            "POST",
            endpoint="read",
            data=data,
            return_model=self.Detail,
        )
        return cast(_Detail, res)

    def exists(self, query: _Reading | None = None, **kwargs: Any) -> _Detail | None:
        data = query if query else self.Reading(**kwargs)
        try:
            res = self.request(
                "POST",
                endpoint="read",
                data=data,
                return_model=self.Detail,
            )
        except errors.NotFound:
            res = None
        return cast(_Detail | None, res)

    async def exists_async(
        self, query: _Reading | None = None, **kwargs: Any
    ) -> _Detail | None:
        data = query if query else self.Reading(**kwargs)
        try:
            res = await self.request_async(
                "POST",
                endpoint="read",
                data=data,
                return_model=self.Detail,
            )
        except errors.NotFound:
            res = None
        return cast(_Detail | None, res)

    def update(self, data: _Updating | None = None, **kwargs: Any) -> _Detail:
        data = data if data else self.Updating(**kwargs)
        has_detail, return_model = self._has_detail()
        res = self.request(
            "POST",
            endpoint="update",
            data=data,
            return_model=return_model,  # type: ignore
        )
        return res  # type: ignore

    async def update_async(
        self, data: _Updating | None = None, **kwargs: Any
    ) -> _Summary:
        data = data if data else self.Updating(**kwargs)
        has_detail, return_model = self._has_detail()
        res = await self.request_async(
            "POST",
            endpoint="update",
            data=data,
            return_model=return_model,  # type: ignore
        )
        return res  # type: ignore

    def delete(self, **kwargs: Any) -> None:
        self.request("POST", endpoint="delete", data=kwargs, body_model=self.Deleting)

    async def delete_async(self, **kwargs: Any) -> None:
        await self.request_async(
            "POST", endpoint="delete", data=kwargs, body_model=self.Deleting
        )

    def _read_all_page(
        self,
        data: _Reading,
        *,
        after: str | None = None,
        size: int | None = None,
    ) -> Page[_Summary]:
        res = self.request(
            "POST",
            endpoint=f"{self.plural_path}/read-all",
            data=data,
            after=after,
            size=size,
            return_model=Page[self.Summary],  # type: ignore
        )
        return cast(Page[_Summary], res)

    async def _read_all_page_async(
        self,
        data: _Reading,
        *,
        after: str | None = None,
        size: int | None = None,
    ) -> Page[_Summary]:
        res = await self.request_async(
            "POST",
            endpoint=f"{self.plural_path}/read-all",
            data=data,
            after=after,
            size=size,
            return_model=Page[self.Summary],  # type: ignore
        )
        return cast(Page[_Summary], res)

    def all(
        self,
        query: _Reading | None = None,
        *,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
        **kwargs: Any,
    ) -> ItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        data = query if query else self.Reading(**kwargs)
        return ItemIterator(
            lambda cursor: self._read_all_page(
                data,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def all_async(
        self,
        query: _Reading | None = None,
        *,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
        **kwargs: Any,
    ) -> AsyncItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        data = query if query else self.Reading(**kwargs)
        return AsyncItemIterator(
            lambda cursor: self._read_all_page_async(
                data,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def all_readable(
        self,
        query: _Reading | None = None,
        *,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
        **kwargs: Any,
    ) -> ItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        data = query if query else self.Reading(**kwargs)
        return ItemIterator(
            lambda cursor: self._read_all_page(
                data,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def all_readable_async(
        self,
        query: _Reading | None = None,
        *,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
        **kwargs: Any,
    ) -> AsyncItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        data = query if query else self.Reading(**kwargs)
        return AsyncItemIterator(
            lambda cursor: self._read_all_page_async(
                data,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def _raise_and_handle_errors(self, response: httpx.Response) -> None:
        """Translate errors by status. This allows SDK consumers to get the original
        error from Ellf, not just the status.
        Does nothing if the response was successful
        """
        prefix = self.__class__.__name__
        try:
            super()._raise_and_handle_errors(response)
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            try:
                error_data = e.response.json()
            except json.JSONDecodeError:
                error_data = {}
            detail = error_data.get("detail", "")
            detail_str = str(detail) if detail else ""
            error_code = error_data.get("error")
            error_type = error_data.get("type")
            # Try legacy format: detail as dict with "type" key
            if not error_code and isinstance(detail, dict):
                error_code = detail.get("type")
            # Map structured error codes to SDK exceptions
            if error_code == "not_found":
                cls = _resolve_error_cls(
                    errors, error_type, f"{prefix}NotFound", errors.NotFound
                )
                raise cls(detail=detail_str)
            elif error_code == "forbidden":
                cls = _resolve_error_cls(
                    errors, error_type, f"{prefix}Forbidden", errors.Forbidden
                )
                raise cls(detail=detail_str)
            elif error_code == "already_exists":
                cls = _resolve_error_cls(
                    errors, error_type, f"{prefix}Exists", errors.Exists
                )
                raise cls(detail=detail_str)
            elif error_code == "invalid_input":
                cls = _resolve_error_cls(
                    errors, error_type, f"{prefix}Invalid", errors.Invalid
                )
                raise cls(detail=detail_str)
            elif error_code == "auth_error" or status == 401:
                raise errors.AuthError(detail=detail_str)
            # Fallback to status-code-based mapping
            elif status == 400:
                raise getattr(errors, f"{prefix}Invalid", errors.Invalid)(
                    detail=detail_str
                )
            elif status == 403:
                raise getattr(errors, f"{prefix}Forbidden", errors.Forbidden)(
                    detail=detail_str
                )
            elif status == 404:
                raise getattr(errors, f"{prefix}NotFound", errors.NotFound)(
                    detail=detail_str
                )
            elif status == 422:
                raise getattr(errors, f"{prefix}Invalid", errors.Invalid)(
                    detail=detail_str
                )
            else:
                raise e

    def _has_detail(self) -> tuple[bool, type[_Summary] | type[_Detail]]:
        if hasattr(self, "Detail"):
            return True, cast(type[_Detail], self.Detail)
        else:
            return False, cast(type[_Detail], self.Summary)


_ReadingLatest = TypeVar("_ReadingLatest", bound=BaseModel)
_ListingLatest = TypeVar("_ListingLatest", bound=BaseModel)


class VersionedModelClient(
    Generic[
        _Creating,
        _Reading,
        _Updating,
        _Deleting,
        _Summary,
        _Detail,
        _ReadingLatest,
        _ListingLatest,
    ],
    ModelClient[
        _Creating,
        _Reading,
        _Updating,
        _Deleting,
        _Summary,
        _Detail,
    ],
):
    Creating: type[_Creating]
    Reading: type[_Reading]
    Updating: type[_Updating]
    Deleting: type[_Deleting]
    Summary: type[_Summary]
    Detail: type[_Detail]
    ReadingLatest: type[_ReadingLatest]
    ListingLatest: type[_ListingLatest]

    def _read_all_latest_page(
        self,
        *,
        body: _ListingLatest,
        after: str | None = None,
        size: int | None = None,
    ) -> Page[_Summary]:
        res = self.request(
            "POST",
            endpoint="all-latest",
            data=body,
            after=after,
            size=size,
            return_model=Page[self.Summary],  # type: ignore
        )
        return cast(Page[_Summary], res)

    async def _read_all_latest_page_async(
        self,
        *,
        body: _ListingLatest,
        after: str | None = None,
        size: int | None = None,
    ) -> Page[_Summary]:
        res = await self.request_async(
            "POST",
            endpoint="all-latest",
            data=body,
            after=after,
            size=size,
            return_model=Page[self.Summary],  # type: ignore
        )
        return cast(Page[_Summary], res)  # type: ignore

    def all_latest(
        self,
        *,
        body: _ListingLatest,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
    ) -> ItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        return ItemIterator(
            lambda cursor: self._read_all_latest_page(
                body=body,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def all_latest_async(
        self,
        *,
        body: _ListingLatest,
        after: str | None = None,
        page_size: int | None = None,
        size: int | None = None,
    ) -> AsyncItemIterator[_Summary]:
        resolved_page_size = _resolve_page_size(page_size=page_size, size=size)
        return AsyncItemIterator(
            lambda cursor: self._read_all_latest_page_async(
                body=body,
                after=cursor,
                size=resolved_page_size,
            ),
            after=after,
        )

    def latest(self, *, body: _ReadingLatest) -> _Summary:
        res = self.request(
            "POST",
            endpoint="latest",
            data=body,
            return_model=self.Detail,
        )
        return cast(_Summary, res)

    async def latest_async(self, *, body: _ReadingLatest) -> _Summary:
        res = await self.request_async(
            "POST",
            endpoint="latest",
            data=body,
            return_model=self.Detail,
        )
        return cast(_Summary, res)
