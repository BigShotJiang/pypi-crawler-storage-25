from ..models import (
    ClusterPathCreating,
    ClusterPathDeleting,
    ClusterPathDetail,
    ClusterPathReading,
    ClusterPathSummary,
    ClusterPathUpdating,
)
from .base import ModelClient


class ClusterPath(
    ModelClient[
        ClusterPathCreating,
        ClusterPathReading,
        ClusterPathUpdating,
        ClusterPathDeleting,
        ClusterPathSummary,
        ClusterPathDetail,
    ]
):
    Creating = ClusterPathCreating
    Reading = ClusterPathReading
    Updating = ClusterPathUpdating
    Deleting = ClusterPathDeleting
    Summary = ClusterPathSummary
    Detail = ClusterPathDetail
