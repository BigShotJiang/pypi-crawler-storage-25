from __future__ import annotations

from datetime import datetime
from typing import cast
from uuid import UUID

from pydantic import BaseModel, Field

from ..ty import Page
from .base import BaseClient


class ProjectPlanSummary(BaseModel):
    id: UUID
    project_id: UUID
    name: str
    version: int
    updated_by_id: UUID
    created: datetime
    updated: datetime


class ProjectPlanDetail(BaseModel):
    id: UUID
    project_id: UUID
    name: str
    content: str
    version: int
    updated_by_id: UUID
    created: datetime
    updated: datetime


class ProjectPlanRevisionSummary(BaseModel):
    id: UUID
    plan_id: UUID
    version: int
    created_by_id: UUID
    created: datetime
    updated: datetime


class ProjectPlanRevisionDetail(BaseModel):
    id: UUID
    plan_id: UUID
    version: int
    content: str
    created_by_id: UUID
    created: datetime
    updated: datetime


class _ProjectPlanListResponse(BaseModel):
    items: list[ProjectPlanSummary] = Field(default_factory=list)


class ProjectPlan(BaseClient):
    def list(self, project_id: UUID) -> list[ProjectPlanSummary]:
        # The list endpoint lives at /api/v1/project-plans/list (plural)
        result = self.request(
            "POST",
            endpoint="/api/v1/project-plans/list",
            data={"project_id": str(project_id)},
            return_model=_ProjectPlanListResponse,
        )
        return cast(_ProjectPlanListResponse, result).items

    def read(
        self,
        *,
        id: UUID | None = None,
        project_id: UUID | None = None,
        name: str | None = None,
    ) -> ProjectPlanDetail | None:
        body: dict = {}
        if id is not None:
            body["id"] = str(id)
        if project_id is not None:
            body["project_id"] = str(project_id)
        if name is not None:
            body["name"] = name
        from .. import errors

        try:
            result = self.request(
                "POST",
                endpoint="read",
                data=body,
                return_model=ProjectPlanDetail,
            )
            return cast(ProjectPlanDetail, result)
        except errors.NotFound:
            return None

    def upsert(
        self,
        project_id: UUID,
        name: str = "project_plan",
        *,
        content: str,
        expected_version: int | None = None,
    ) -> ProjectPlanDetail:
        result = self.request(
            "POST",
            endpoint="upsert",
            data={
                "project_id": str(project_id),
                "name": name,
                "content": content,
                "expected_version": expected_version,
            },
            return_model=ProjectPlanDetail,
        )
        return cast(ProjectPlanDetail, result)

    def delete(
        self,
        *,
        id: UUID | None = None,
        project_id: UUID | None = None,
        name: str | None = None,
    ) -> None:
        body: dict = {}
        if id is not None:
            body["id"] = str(id)
        if project_id is not None:
            body["project_id"] = str(project_id)
        if name is not None:
            body["name"] = name
        self.request("POST", endpoint="delete", data=body)

    def list_revisions(
        self,
        project_id: UUID,
        name: str = "project_plan",
        *,
        after: UUID | None = None,
        size: int = 50,
    ) -> Page[ProjectPlanRevisionSummary]:
        result = self.request(
            "POST",
            endpoint="/api/v1/project-plan-revisions/list",
            data={"project_id": str(project_id), "name": name},
            after=str(after) if after is not None else None,
            size=size,
            return_model=Page[ProjectPlanRevisionSummary],
        )
        return cast(Page[ProjectPlanRevisionSummary], result)

    def read_revision(
        self,
        *,
        plan_id: UUID,
        version: int,
    ) -> ProjectPlanRevisionDetail:
        result = self.request(
            "POST",
            endpoint="/api/v1/project-plan-revision/read",
            data={"plan_id": str(plan_id), "version": version},
            return_model=ProjectPlanRevisionDetail,
        )
        return cast(ProjectPlanRevisionDetail, result)
