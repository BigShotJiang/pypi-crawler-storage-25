from typing import IO, Any, cast
from uuid import UUID

from pydantic import BaseModel

from ..models import (
    ClusterCreating,
    ClusterCredentials,
    ClusterDeleting,
    ClusterDetail,
    ClusterReading,
    ClusterSummary,
    ClusterUpdating,
)
from .base import ModelClient


class Cluster(
    ModelClient[
        ClusterCreating,
        ClusterReading,
        ClusterUpdating,
        ClusterDeleting,
        ClusterSummary,
        ClusterDetail,
    ]
):
    Creating = ClusterCreating
    Reading = ClusterReading
    Updating = ClusterUpdating
    Deleting = ClusterDeleting
    Summary = ClusterSummary
    Detail = ClusterDetail

    class Token(BaseModel):
        token: str

    def create(
        self, data: ClusterCreating | None = None, **kwargs: Any
    ) -> ClusterDetail:
        data = data if data else ClusterCreating(**kwargs)
        res = self.request(
            "POST",
            endpoint="create",
            data=data,
            return_model=ClusterDetail,
        )
        assert isinstance(res, ClusterDetail)
        return res

    async def create_async(
        self, data: ClusterCreating | None = None, **kwargs: Any
    ) -> ClusterDetail:
        data = data if data else ClusterCreating(**kwargs)
        res = await self.request_async(
            "POST",
            endpoint="create",
            data=data,
            return_model=ClusterDetail,
        )
        assert isinstance(res, ClusterDetail)
        return res

    def credentials(self, cluster_id: UUID) -> ClusterCredentials:
        res = self.request(
            "POST",
            endpoint="credentials/read",
            data=ClusterReading(id=cluster_id),
            return_model=ClusterCredentials,
        )
        assert isinstance(res, ClusterCredentials)
        return res

    def download_gcloud_files(self) -> IO[bytes]:
        res = self.request("POST", endpoint="files/gcloud/read", stream=True)
        return cast(IO[bytes], res)
