"""Async mirror of declaw.volumes — same contract, awaitable."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, AsyncIterable, BinaryIO, Iterable, List, Optional, Union  # noqa: UP035

from declaw.api.async_client import AsyncApiClient, get_shared_async_client
from declaw.connection_config import ConnectionConfig
from declaw.volumes.main import Volume, _pack_path_to_tar_gz


async def _shared_client(
    api_key: Optional[str],
    domain: Optional[str],
    request_timeout: Optional[float],
) -> AsyncApiClient:
    """Return a process-wide AsyncApiClient keyed by the caller's config
    and current event loop. Shared — do not aclose it."""
    config = ConnectionConfig(
        api_key=api_key or ConnectionConfig().api_key,
        domain=domain or ConnectionConfig.default_domain(),
        request_timeout=request_timeout,
    )
    return await get_shared_async_client(config)


class AsyncVolumes:
    """Async client for the /volumes CRUD API."""

    @staticmethod
    async def create(
        name: str,
        data: Union[
            bytes, BinaryIO, Iterable[bytes], AsyncIterable[bytes], str, "os.PathLike[str]"
        ],
        *,
        content_type: str = "application/gzip",
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> Volume:
        if isinstance(data, (str, os.PathLike)):
            path = Path(data)
            if not path.exists():
                raise FileNotFoundError(f"volume source path does not exist: {path}")
            body: Any = _pack_path_to_tar_gz(path)
        else:
            body = data

        client = await _shared_client(api_key, domain, request_timeout)
        resp = await client.post(
            "/volumes",
            params={"name": name},
            content=body,
            headers={"Content-Type": content_type},
            timeout=request_timeout,
        )
        return Volume.from_dict(resp.json())

    @staticmethod
    async def get(
        volume_id: str,
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> Volume:
        client = await _shared_client(api_key, domain, request_timeout)
        resp = await client.get(f"/volumes/{volume_id}", timeout=request_timeout)
        return Volume.from_dict(resp.json())

    @staticmethod
    async def list(
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> List[Volume]:
        client = await _shared_client(api_key, domain, request_timeout)
        resp = await client.get("/volumes", timeout=request_timeout)
        payload = resp.json() or {}
        return [Volume.from_dict(v) for v in payload.get("volumes", [])]

    @staticmethod
    async def delete(
        volume_id: str,
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> None:
        client = await _shared_client(api_key, domain, request_timeout)
        await client.delete(f"/volumes/{volume_id}", timeout=request_timeout)
