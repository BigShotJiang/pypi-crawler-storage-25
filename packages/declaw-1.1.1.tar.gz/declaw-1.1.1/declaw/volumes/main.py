"""Volumes: upload a tarball once and attach it to one or many sandboxes.

A volume is a tenant-owned blob stored in the same object store the server
uses for sandbox snapshots. On `Sandbox.create(volumes=[...])` the orchestrator
streams the blob out, un-tars it, and writes the regular-file entries into
the sandbox filesystem under the attachment's mount_path.

Phase 1 contract:
- The blob body must be a gzip-compressed tar archive (tar.gz).
- Only regular files are materialized inside the sandbox; symlinks, hardlinks
  and device nodes are dropped on the server.
- Upload body is capped at 500 MiB (same as /files/raw).
"""

from __future__ import annotations

import io
import os
import tarfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO, Dict, Iterable, List, Optional, Union

from declaw.api.client import ApiClient, get_shared_client
from declaw.connection_config import ConnectionConfig


@dataclass
class VolumeAttachment:
    """A (volume_id, mount_path) pair passed to Sandbox.create(volumes=...)."""

    volume_id: str
    mount_path: str

    def to_dict(self) -> Dict[str, Any]:
        return {"volume_id": self.volume_id, "mount_path": self.mount_path}


@dataclass
class Volume:
    """Server-side metadata for a single volume."""

    volume_id: str
    owner_id: str
    name: str
    blob_key: str
    size_bytes: int
    content_type: str
    created_at: str
    metadata: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Volume":
        return cls(
            volume_id=data["volume_id"],
            owner_id=data.get("owner_id", ""),
            name=data.get("name", ""),
            blob_key=data.get("blob_key", ""),
            size_bytes=int(data.get("size_bytes", 0)),
            content_type=data.get("content_type", ""),
            created_at=data.get("created_at", ""),
            metadata=data.get("metadata") or {},
        )

    def attach(self, mount_path: str) -> VolumeAttachment:
        """Shortcut: `vol.attach('/data')` -> VolumeAttachment(vol.volume_id, '/data')."""
        return VolumeAttachment(volume_id=self.volume_id, mount_path=mount_path)


def _pack_path_to_tar_gz(path: Path) -> bytes:
    """Tar+gzip a single file or directory into memory.

    Used when the caller passes a filesystem path to Volumes.create. For
    larger trees the caller should pre-build the tarball themselves and
    pass the bytes or a file handle directly — the in-memory encode is
    only a convenience for small datasets.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(path, arcname=path.name if path.is_file() else ".")
    return buf.getvalue()


class Volumes:
    """Sync client for the /volumes CRUD API."""

    @staticmethod
    def _client(
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> ApiClient:
        """Return a process-wide ApiClient keyed by config. Shared — do
        not ``close()`` it; the cache in ``declaw.api.client`` manages
        lifetime."""
        config = ConnectionConfig(
            api_key=api_key or ConnectionConfig().api_key,
            domain=domain or ConnectionConfig.default_domain(),
            request_timeout=request_timeout,
        )
        return get_shared_client(config)

    @staticmethod
    def create(
        name: str,
        data: Union[bytes, BinaryIO, Iterable[bytes], str, "os.PathLike[str]"],
        *,
        content_type: str = "application/gzip",
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> Volume:
        """Upload a tarball and return the registered Volume.

        `data` may be:
            - bytes: uploaded as-is;
            - a file-like object open in binary mode: streamed as-is;
            - an iterable of bytes chunks: streamed as-is;
            - a path-like pointing to a file or directory: packed into a
              tar.gz in memory and uploaded.
        """
        if isinstance(data, (str, os.PathLike)):
            path = Path(data)
            if not path.exists():
                raise FileNotFoundError(f"volume source path does not exist: {path}")
            body: Union[bytes, BinaryIO, Iterable[bytes]] = _pack_path_to_tar_gz(path)
        else:
            body = data

        client = Volumes._client(api_key=api_key, domain=domain, request_timeout=request_timeout)
        resp = client.post(
            "/volumes",
            params={"name": name},
            content=body,
            headers={"Content-Type": content_type},
            timeout=request_timeout,
        )
        return Volume.from_dict(resp.json())

    @staticmethod
    def get(
        volume_id: str,
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> Volume:
        client = Volumes._client(api_key=api_key, domain=domain, request_timeout=request_timeout)
        resp = client.get(f"/volumes/{volume_id}", timeout=request_timeout)
        return Volume.from_dict(resp.json())

    @staticmethod
    def list(
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> List[Volume]:
        client = Volumes._client(api_key=api_key, domain=domain, request_timeout=request_timeout)
        resp = client.get("/volumes", timeout=request_timeout)
        payload = resp.json() or {}
        return [Volume.from_dict(v) for v in payload.get("volumes", [])]

    @staticmethod
    def delete(
        volume_id: str,
        *,
        api_key: Optional[str] = None,
        domain: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> None:
        client = Volumes._client(api_key=api_key, domain=domain, request_timeout=request_timeout)
        client.delete(f"/volumes/{volume_id}", timeout=request_timeout)
