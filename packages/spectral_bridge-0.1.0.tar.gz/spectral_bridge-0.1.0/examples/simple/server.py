# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "fastapi>=0.115",
#     "uvicorn>=0.34",
#     "websockets",
# ]
# ///

"""Minimal server relay for local demos: one WebSocket client, forward POST /v1/chat/completions"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid

import uvicorn
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

logger = logging.getLogger("spectral_bridge.server")

API_KEY = os.environ.get("API_KEY")
if API_KEY is None:
    raise SystemExit("set API_KEY to a non-empty relay credential")

# The single active WebSocket connection from the spectral-bridge client.
connection: WebSocket | None = None

# In-flight requests: request_id -> Future awaiting the client's response frame.
pending: dict[str, asyncio.Future[dict]] = {}

app = FastAPI(title="spectral-bridge relay server")


@app.websocket("/connect")
async def connect(ws: WebSocket):
    global connection

    auth = ws.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        await ws.close(code=4001, reason="missing or malformed authorization")
        return

    if auth.removeprefix("Bearer ").strip() != API_KEY:
        await ws.close(code=4001, reason="invalid api key")
        return

    await ws.accept()

    # Replace any stale connection.
    if connection is not None:
        try:
            await connection.close(code=1000, reason="replaced by newer connection")
        except Exception:
            pass

    connection = ws
    logger.info("client connected")
    await ws.send_json({"type": "connected"})

    try:
        while True:
            data = await ws.receive_json()
            if data.get("type") == "response":
                request_id = data.get("request_id")
                future = pending.get(request_id)
                if future and not future.done():
                    future.set_result(data.get("payload", {}))
    except WebSocketDisconnect:
        logger.info("client disconnected")
    finally:
        if connection is ws:
            connection = None


@app.post("/v1/chat/completions")
async def forward(request: Request):
    """Forward a chat completion request to the relay client and return its response."""
    if connection is None:
        return JSONResponse(
            status_code=503, content={"error": {"message": "no active connection"}}
        )

    body = await request.json()
    request_id = str(uuid.uuid4())
    future: asyncio.Future[dict] = asyncio.get_running_loop().create_future()
    pending[request_id] = future

    try:
        await connection.send_json(
            {
                "type": "request",
                "request_id": request_id,
                "payload": {
                    "method": "POST",
                    "path": "/v1/chat/completions",
                    "headers": {"content-type": "application/json"},
                    "body": body,
                },
            }
        )
    except Exception:
        pending.pop(request_id, None)
        return JSONResponse(
            status_code=503,
            content={"error": {"message": "failed to send request to client"}},
        )

    try:
        result = await asyncio.wait_for(future, timeout=30.0)
    except asyncio.TimeoutError:
        return JSONResponse(
            status_code=504, content={"error": {"message": "client response timed out"}}
        )
    finally:
        pending.pop(request_id, None)

    return JSONResponse(
        status_code=result.get("status", 200), content=result.get("body", {})
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 9000)))
