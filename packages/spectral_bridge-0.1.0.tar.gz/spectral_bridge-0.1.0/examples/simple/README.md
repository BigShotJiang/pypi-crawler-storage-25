# Local end-to-end example

This example runs every hop on your laptop: 
1. HTTP hits the **relay**
2. the relay pushes work over WebSocket to **spectral-bridge**
3. the bridge calls the **pass-through** adapter
4. the adapter forwards to a tiny **echo bot** that pretends to be an OpenAI-compatible model.

You need [uv](https://docs.astral.sh/uv/) and `spectral-bridge` CLI.

Use four terminals. Start the echo bot and relay before the bridge, then run `curl` last.

## 1. Echo bot (stand-in for your internal API)

From the **repository root**:

```bash
PORT=8000 uv run examples/simple/echo_bot.py
```

Leave this running. It serves `POST /v1/chat/completions` on port 8000.

## 2. Relay server

From the **repository root** (second terminal):

```bash
export API_KEY=secret
PORT=9000 uv run examples/simple/server.py
```

> **Security Consideration:** The server here is a minimal implementation of Section §3.2 in `PROTOCOL.md`. It is mostly designed for simplicity and, in particular, it deliberately omits HTTP-side auth on  `POST /v1/chat/completions`. This is not a recommended production pattern. For proper production scenarios, lean towards designs like §3.3 and §3.4, and always combine them with appropriate authentication on the HTTP forwarding surface.

## 3. spectral-bridge

Set `SPECTRAL_BRIDGE_API_KEY` to the same value as `API_KEY` on the relay:

```bash
export SPECTRAL_BRIDGE_API_KEY=secret
spectral-bridge start \
  --relay-url ws://localhost:9000/connect \
  --insecure-relay \
  --adapter pass-through \
  --target http://localhost:8000
```

`--insecure-relay` is only for this local `ws://` URL. Production setups use `wss://` without that flag.

When the connection succeeds, the bridge logs `connected to relay`.

The pass-through adapter listens on **8840** by default.

## 4. Exercise the path

The completion request goes to the **relay** (9000), not to the echo bot directly:

```bash
curl -sS -X POST "http://localhost:9000/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "echo",
    "messages": [{"role": "user", "content": "hello from spectral-bridge"}]
  }'
```

You should get a JSON body whose assistant `content` echoes the last user message.
