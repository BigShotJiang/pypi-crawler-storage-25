# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "fastapi[standard]>=0.135.0",
# ]
# ///

"""Tiny OpenAI-shaped target, that behaves as an echo bot: it returns the last user message as the assistant reply"""

from __future__ import annotations

import os

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI()


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/v1/chat/completions")
async def chat(request: Request):
    body = await request.json()
    messages = body.get("messages", [])
    last = messages[-1]["content"] if messages else ""
    return JSONResponse(
        content={
            "choices": [{"message": {"role": "assistant", "content": last}}],
        }
    )


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
