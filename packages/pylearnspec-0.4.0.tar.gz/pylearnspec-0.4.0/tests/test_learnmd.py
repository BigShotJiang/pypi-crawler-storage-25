"""Tests for the LearnMD parser and validator."""

from pathlib import Path

from pylearnspec.learnmd.parser import parse_learn
from pylearnspec.learnmd.validator import validate_learn

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> str:
    return (FIXTURES / name).read_text()


class TestParseLearn:
    def test_parses_title(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert lesson.title == "Python Variables"

    def test_parses_frontmatter(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert lesson.frontmatter["lang"] == "en"
        assert lesson.frontmatter["estimated_time"] == "15min"
        assert "python" in lesson.frontmatter["tags"]

    def test_level(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert lesson.level == "2"  # has fenced blocks

    def test_sections(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert len(lesson.sections) == 3
        assert lesson.sections[0].title == "What is a variable?"
        assert lesson.sections[0].depth == 2

    def test_blocks(self):
        lesson = parse_learn(_load("sample.learn.md"))
        block_types = [b.block_type for b in lesson.blocks]
        assert "quiz" in block_types
        assert "summary" in block_types

    def test_quiz_block_content(self):
        lesson = parse_learn(_load("sample.learn.md"))
        quiz_blocks = [b for b in lesson.blocks if b.block_type == "quiz"]
        assert len(quiz_blocks) == 1
        assert "?" in quiz_blocks[0].content

    def test_summary_block(self):
        lesson = parse_learn(_load("sample.learn.md"))
        summary_blocks = [b for b in lesson.blocks if b.block_type == "summary"]
        assert len(summary_blocks) == 1
        assert "Variables" in summary_blocks[0].content

    def test_callouts(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert "tip" in lesson.callouts
        assert "warning" in lesson.callouts

    def test_directives(self):
        lesson = parse_learn(_load("sample.learn.md"))
        assert len(lesson.directives) == 1
        assert lesson.directives[0].type == "import"
        assert lesson.directives[0].path == "./check-variables.quiz.md"

    def test_to_dict(self):
        lesson = parse_learn(_load("sample.learn.md"))
        d = lesson.to_dict()
        assert d["title"] == "Python Variables"
        assert d["type"] == "lesson"
        assert len(d["sections"]) == 3

    def test_no_frontmatter(self):
        content = "# Simple Lesson\n\nSome content.\n\n## Section 1\n\nMore content.\n"
        lesson = parse_learn(content)
        assert lesson.level == "0"
        assert lesson.title == "Simple Lesson"
        assert len(lesson.sections) == 1


class TestValidateLearn:
    def test_valid_lesson(self):
        diagnostics = validate_learn(_load("sample.learn.md"))
        errors = [d for d in diagnostics if d.level == "error"]
        assert len(errors) == 0

    def test_missing_lang(self):
        content = "# Test\n\nSome content.\n"
        diagnostics = validate_learn(content)
        assert any("lang" in d.message.lower() for d in diagnostics)

    def test_strict_mode(self):
        content = "Some content without title or lang.\n"
        diagnostics = validate_learn(content, strict=True)
        errors = [d for d in diagnostics if d.level == "error"]
        assert len(errors) >= 2  # missing title + lang

    def test_quiz_block_without_question(self):
        content = "---\nlang: en\n---\n\n# Test\n\n```quiz\nNo question here\n```\n"
        diagnostics = validate_learn(content)
        assert any("quiz" in d.message.lower() for d in diagnostics)
