"""Tests for the QuizMD parser and validator."""

from pathlib import Path

from pylearnspec.quizmd.parser import parse_quiz
from pylearnspec.quizmd.validator import validate_quiz

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> str:
    return (FIXTURES / name).read_text()


class TestParseQuiz:
    def test_parses_title(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        assert quiz.title == "Sample Quiz"

    def test_parses_frontmatter(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        assert quiz.frontmatter["lang"] == "en"
        assert quiz.frontmatter["domain"] == "academic"
        assert quiz.frontmatter["passing_score"] == 0.7
        assert quiz.frontmatter["scoring"]["correct"] == 2

    def test_level(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        assert quiz.level == "1+2"

    def test_question_count(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        assert len(quiz.questions) == 6

    def test_mcq_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q1 = quiz.questions[0]
        assert q1.number == 1
        assert q1.title == "Capital of France?"
        assert q1.q_type == "mcq"
        assert q1.meta["id"] == "q1-capital"
        assert q1.meta["points"] == 3
        assert q1.meta["difficulty"] == "easy"
        assert len(q1.choices) == 3
        assert q1.choices[0].text == "London"
        assert q1.choices[0].correct is False
        assert q1.choices[1].text == "Paris"
        assert q1.choices[1].correct is True
        assert "Well done" in q1.feedback

    def test_tf_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q2 = quiz.questions[1]
        assert q2.q_type == "tf"
        assert len(q2.choices) == 2

    def test_open_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q3 = quiz.questions[2]
        assert q3.q_type == "open"
        assert q3.open_answer == "star"

    def test_multi_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q4 = quiz.questions[3]
        assert q4.q_type == "multi"
        correct = [c for c in q4.choices if c.correct]
        assert len(correct) == 3

    def test_match_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q5 = quiz.questions[4]
        assert q5.q_type == "match"
        assert len(q5.match_pairs) == 3
        assert q5.match_pairs[0].left == "Newton"
        assert q5.match_pairs[0].right == "Force"

    def test_order_question(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q6 = quiz.questions[5]
        assert q6.q_type == "order"
        assert q6.order_items == ["Mercury", "Venus", "Earth", "Mars"]

    def test_to_dict(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        d = quiz.to_dict()
        assert d["title"] == "Sample Quiz"
        assert len(d["questions"]) == 6
        assert d["questions"][0]["q_type"] == "mcq"

    def test_per_choice_feedback(self):
        quiz = parse_quiz(_load("sample.quiz.md"))
        q1 = quiz.questions[0]
        assert q1.choices[0].feedback == "London is UK's capital."
        assert q1.choices[1].feedback == "Correct!"

    def test_no_frontmatter(self):
        content = "# Simple\n\n## Q1 · Test\n\n- [x] Yes\n- [ ] No\n"
        quiz = parse_quiz(content)
        assert quiz.level == "0"
        assert quiz.title == "Simple"
        assert len(quiz.questions) == 1

    def test_imports(self):
        content = "---\ntitle: Combo\nlang: en\n---\n\n!import ./part1.quiz.md\n!import ./part2.quiz.md\n"
        quiz = parse_quiz(content)
        assert quiz.imports == ["./part1.quiz.md", "./part2.quiz.md"]

    def test_tf_french_vrai_faux(self):
        content = (
            "---\ntitle: T\nlang: fr\n---\n# T\n\n"
            "## Q1 · La Terre est ronde\n\n"
            "- [x] Vrai\n"
            "- [ ] Faux\n"
        )
        quiz = parse_quiz(content)
        assert quiz.questions[0].q_type == "tf"

    def test_tf_yes_no_pair(self):
        content = (
            "---\ntitle: T\nlang: en\n---\n# T\n\n"
            "## Q1 · Is water wet\n\n"
            "- [x] Yes\n"
            "- [ ] No\n"
        )
        quiz = parse_quiz(content)
        assert quiz.questions[0].q_type == "tf"

    def test_tf_oui_non_pair(self):
        content = (
            "---\ntitle: T\nlang: fr\n---\n# T\n\n"
            "## Q1 · Le ciel est bleu\n\n"
            "- [x] Oui\n"
            "- [ ] Non\n"
        )
        quiz = parse_quiz(content)
        assert quiz.questions[0].q_type == "tf"

    def test_tf_pair_case_insensitive(self):
        content = (
            "---\ntitle: T\nlang: fr\n---\n# T\n\n"
            "## Q1 · case\n\n"
            "- [x] VRAI\n"
            "- [ ] faux\n"
        )
        quiz = parse_quiz(content)
        assert quiz.questions[0].q_type == "tf"


class TestValidateQuiz:
    def test_valid_quiz(self):
        diagnostics = validate_quiz(_load("sample.quiz.md"))
        errors = [d for d in diagnostics if d.level == "error"]
        assert len(errors) == 0

    def test_missing_title_warning(self):
        content = "## Q1 · Test\n\n- [x] Yes\n- [ ] No\n"
        diagnostics = validate_quiz(content)
        msgs = [d.message for d in diagnostics]
        assert any("title" in m.lower() for m in msgs)

    def test_missing_lang_warning(self):
        content = "# Test\n\n## Q1 · Test\n\n- [x] Yes\n- [ ] No\n"
        diagnostics = validate_quiz(content)
        msgs = [d.message for d in diagnostics]
        assert any("lang" in m.lower() for m in msgs)

    def test_strict_mode(self):
        content = "## Q1 · Test\n\n- [x] Yes\n- [ ] No\n"
        diagnostics = validate_quiz(content, strict=True)
        errors = [d for d in diagnostics if d.level == "error"]
        assert len(errors) >= 2  # missing title + missing lang

    def test_no_correct_answer(self):
        content = "---\ntitle: Test\nlang: en\n---\n\n# Test\n\n## Q1 · Bad\n\n- [ ] A\n- [ ] B\n"
        diagnostics = validate_quiz(content)
        assert any("correct" in d.message.lower() for d in diagnostics)
