"""GlossaryMD parser — converts .glossary.md content to structured data."""

from __future__ import annotations

import re
import unicodedata

import yaml

from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.glossarymd.models import Glossary, Term

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_H2_RE = re.compile(r"^##\s+(.+)$", re.MULTILINE)
_TERM_BLOCK_RE = re.compile(r"^```term\b([^\n]*)\n(.*?)^```\s*$", re.MULTILINE | re.DOTALL)


def _slugify(text: str) -> str:
    norm = unicodedata.normalize("NFKD", text)
    norm = "".join(c for c in norm if not unicodedata.combining(c))
    norm = norm.lower()
    norm = re.sub(r"[^a-z0-9]+", "-", norm)
    return norm.strip("-")


def _parse_term_attrs(attrs_line: str) -> dict:
    """Parse `id:slug aliases:["a","b"] related:["x"] tags:[t1,t2]` on the term block open line."""
    # We use a permissive approach: convert to YAML-like by isolating key:value
    # patterns and feeding each to yaml.safe_load.
    out: dict = {}
    # Handle list values first
    for m in re.finditer(r'(\w+):(\[[^\]]*\])', attrs_line):
        try:
            out[m.group(1)] = yaml.safe_load(m.group(2))
        except yaml.YAMLError:
            pass
        attrs_line = attrs_line.replace(m.group(0), "", 1)
    # Then scalar values
    for m in re.finditer(r'(\w+):(?:"([^"]*)"|(\S+))', attrs_line):
        key = m.group(1)
        value = m.group(2) if m.group(2) is not None else m.group(3)
        out[key] = value
    return out


def _split_definition(body: str, h2_positions: list[tuple[int, str]]) -> list[tuple[str, str, int, int]]:
    """Return [(heading_text, slice_text, start, end), ...] for each ## section."""
    out: list[tuple[str, str, int, int]] = []
    for i, (pos, heading) in enumerate(h2_positions):
        next_pos = h2_positions[i + 1][0] if i + 1 < len(h2_positions) else len(body)
        # Find end of heading line
        nl = body.find("\n", pos)
        if nl == -1:
            nl = pos
        section_text = body[nl + 1 : next_pos]
        out.append((heading, section_text, nl + 1, next_pos))
    return out


def parse_glossary(content: str) -> Glossary:
    """Parse a .glossary.md string and return a Glossary object."""
    frontmatter, body = extract_frontmatter(content)

    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    # Locate ## headings (term names)
    h2s: list[tuple[int, str]] = [(m.start(), m.group(1).strip()) for m in _H2_RE.finditer(body)]
    sections = _split_definition(body, h2s)

    terms: list[Term] = []
    for heading, section_text, _, _ in sections:
        # Optional ```term ...``` immediately at the start
        attrs: dict = {}
        tm = _TERM_BLOCK_RE.match(section_text.lstrip("\n"))
        definition_text = section_text
        if tm:
            attrs_line = (tm.group(1) or "").strip()
            attrs = _parse_term_attrs(attrs_line)
            # Strip the term block from the definition
            definition_text = section_text[tm.end() :]

        slug = attrs.get("id") or _slugify(heading)
        aliases = attrs.get("aliases") or []
        related = attrs.get("related") or []
        tags = attrs.get("tags") or []

        terms.append(Term(
            name=heading,
            slug=slug,
            definition=definition_text.strip(),
            aliases=list(aliases) if isinstance(aliases, list) else [str(aliases)],
            related=list(related) if isinstance(related, list) else [str(related)],
            tags=list(tags) if isinstance(tags, list) else [str(tags)],
        ))

    has_fm = bool(frontmatter)
    has_term_blocks = any(t.aliases or t.related or t.tags for t in terms)
    if has_term_blocks:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return Glossary(title=title, level=level, frontmatter=frontmatter, terms=terms)
