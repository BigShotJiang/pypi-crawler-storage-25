"""GlossaryMD — glossary format for the LearnSpec suite."""

from pylearnspec.glossarymd.parser import parse_glossary
from pylearnspec.glossarymd.validator import validate_glossary

__all__ = ["parse_glossary", "validate_glossary"]
