"""Shared validation primitives used across all LearnSpec formats."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Severity = Literal["error", "warning"]


@dataclass
class Diagnostic:
    level: Severity
    message: str

    def to_dict(self) -> dict:
        return {"level": self.level, "message": self.message}


def severity_for(strict: bool) -> Severity:
    """Return the severity used for fields demoted to warning in lenient mode."""
    return "error" if strict else "warning"
