"""Data models for BadgeMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Badge:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    image_path: str = ""              # from the ![](...) line in the body
    body_text: str = ""               # narrative criteria
    criteria: list[dict[str, Any]] = field(default_factory=list)
    has_criteria_block: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "image_path": self.image_path,
            "body_text": self.body_text,
            "criteria": self.criteria,
            "has_criteria_block": self.has_criteria_block,
        }
