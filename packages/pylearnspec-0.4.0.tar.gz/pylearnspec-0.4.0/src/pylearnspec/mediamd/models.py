"""Data models for MediaMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class MediaEntry:
    id: str
    raw: dict[str, Any] = field(default_factory=dict)
    has_image_line: bool = False  # whether a preceding ![alt](thumb "media:slug") was found

    def to_dict(self) -> dict[str, Any]:
        d = dict(self.raw)
        d["id"] = self.id
        d["has_image_line"] = self.has_image_line
        return d


@dataclass
class MediaCatalogue:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    entries: list[MediaEntry] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "entries": [e.to_dict() for e in self.entries],
        }
