"""MediaMD validator."""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.mediamd.parser import parse_media


def validate_media(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        cat = parse_media(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not cat.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    seen: dict[str, int] = {}
    for i, e in enumerate(cat.entries, start=1):
        if not e.id:
            diags.append(Diagnostic(level="error", message=f"Entry #{i}: missing 'id' on media block"))
            continue
        seen[e.id] = seen.get(e.id, 0) + 1

        raw = e.raw
        if not raw.get("image_url"):
            diags.append(Diagnostic(level="error", message=f"Entry '{e.id}': missing required 'image_url'"))
        if not raw.get("title"):
            diags.append(Diagnostic(level=sev, message=f"Entry '{e.id}': missing 'title'"))
        if not raw.get("alt"):
            diags.append(Diagnostic(level=sev, message=f"Entry '{e.id}': missing 'alt'"))
        if not raw.get("license"):
            diags.append(Diagnostic(level="error", message=f"Entry '{e.id}': missing 'license'"))

        spdx = raw.get("spdx")
        license_url = raw.get("license_url")
        if not spdx and not license_url:
            diags.append(Diagnostic(
                level=sev,
                message=f"Entry '{e.id}': both 'spdx' and 'license_url' are absent — one is recommended",
            ))
        if spdx == "custom" and not license_url:
            diags.append(Diagnostic(
                level="error",
                message=f"Entry '{e.id}': 'spdx: custom' requires 'license_url'",
            ))

        if raw.get("thumb_url") and not e.has_image_line:
            diags.append(Diagnostic(
                level=sev,
                message=f"Entry '{e.id}': 'thumb_url' present but no preceding Markdown image line",
            ))

    for mid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate media id '{mid}'"))

    return diags
