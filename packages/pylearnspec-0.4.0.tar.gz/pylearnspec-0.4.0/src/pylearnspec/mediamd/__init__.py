"""MediaMD — media catalogue format for the LearnSpec suite."""

from pylearnspec.mediamd.parser import parse_media
from pylearnspec.mediamd.validator import validate_media

__all__ = ["parse_media", "validate_media"]
