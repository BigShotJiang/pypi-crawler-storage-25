"""MediaMD parser — extracts ``media`` fenced blocks and preceding image lines."""

from __future__ import annotations

import re

import yaml

from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.mediamd.models import MediaCatalogue, MediaEntry

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)

# Image line preceding a media block: ![alt](url "media:slug")
_IMAGE_LINE_RE = re.compile(
    r'!\[[^\]]*\]\([^)]*"media:([a-z0-9][a-z0-9-]*)"\)',
)

# ```media id:slug\n...```
_MEDIA_BLOCK_RE = re.compile(
    r"^```media(?:\s+id:([a-z0-9][a-z0-9-]*))?\s*\n(.*?)^```\s*$",
    re.MULTILINE | re.DOTALL,
)


def parse_media(content: str) -> MediaCatalogue:
    frontmatter, body = extract_frontmatter(content)
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    # Find media blocks and their preceding image-line slugs.
    image_slugs_before: dict[int, str] = {}
    for m in _IMAGE_LINE_RE.finditer(body):
        image_slugs_before[m.start()] = m.group(1)

    entries: list[MediaEntry] = []
    for m in _MEDIA_BLOCK_RE.finditer(body):
        # Parse the YAML body
        raw: dict = {}
        try:
            loaded = yaml.safe_load(m.group(2)) or {}
            if isinstance(loaded, dict):
                raw = loaded
        except yaml.YAMLError:
            pass

        block_id = m.group(1) or raw.get("id") or ""

        # Has there been a matching image line shortly before this block?
        has_image_line = False
        # Look back up to 500 chars for an image line with the same slug
        window_start = max(0, m.start() - 500)
        window = body[window_start : m.start()]
        if (im := _IMAGE_LINE_RE.findall(window)) and block_id in im:
            has_image_line = True

        entries.append(MediaEntry(id=block_id, raw=raw, has_image_line=has_image_line))

    has_fm = bool(frontmatter)
    has_enriched = any(
        e.raw.get("width") or e.raw.get("height") or e.raw.get("mime") or e.raw.get("context_url")
        for e in entries
    )
    if has_enriched:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return MediaCatalogue(title=title, level=level, frontmatter=frontmatter, entries=entries)
