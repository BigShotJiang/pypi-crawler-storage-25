"""Data models for LearnMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pylearnspec.common.directives import Checkpoint, MediaRef, RefDirective


@dataclass
class Section:
    title: str
    depth: int  # 2 for ##, 3 for ###

    def to_dict(self) -> dict[str, Any]:
        return {"title": self.title, "depth": self.depth}


@dataclass
class Block:
    block_type: str  # summary, example, note, tip, warning, important, caution, objectives, quiz, concept
    content: str
    title: str = ""
    lang: str = ""  # code language for example blocks
    scored: bool = False  # for quiz blocks

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"block_type": self.block_type, "content": self.content}
        if self.title:
            d["title"] = self.title
        if self.lang:
            d["lang"] = self.lang
        if self.block_type == "quiz":
            d["scored"] = self.scored
        return d


@dataclass
class Directive:
    """Legacy import-only directive — kept for backwards compatibility.

    The richer ``ImportDirective`` (from :mod:`pylearnspec.common.directives`)
    is preferred for new code; see ``Lesson.imports``.
    """
    type: str  # "import"
    path: str

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "path": self.path}


@dataclass
class Lesson:
    # In LearnMD v0.4 the top-level container is called a "document" (was "path"
    # in v0.3 — renamed to avoid confusion with TrackMD). The ``type`` field
    # accepts: document, lesson, concept, cheatsheet.
    title: str = ""
    type: str = "lesson"
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    sections: list[Section] = field(default_factory=list)
    blocks: list[Block] = field(default_factory=list)
    directives: list[Directive] = field(default_factory=list)  # legacy — kept
    callouts: list[str] = field(default_factory=list)
    # LearnMD v0.4 additions
    refs: list[RefDirective] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)
    media_refs: list[MediaRef] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "type": self.type,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "sections": [s.to_dict() for s in self.sections],
            "blocks": [b.to_dict() for b in self.blocks],
            "directives": [d.to_dict() for d in self.directives],
            "callouts": sorted(set(self.callouts)),
            "refs": [r.to_dict() for r in self.refs],
            "checkpoints": [c.to_dict() for c in self.checkpoints],
            "media_refs": [m.to_dict() for m in self.media_refs],
        }
