"""LearnMD validator — checks .learn.md content for errors and warnings."""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.learnmd.parser import parse_learn


def validate_learn(content: str, *, strict: bool = False) -> list[Diagnostic]:
    """Validate a .learn.md string and return a list of diagnostics.

    In lenient mode (default), missing lang/title are warnings.
    In strict mode, they are errors.
    """
    diagnostics: list[Diagnostic] = []

    try:
        lesson = parse_learn(content)
    except Exception as e:
        diagnostics.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diagnostics

    sev = severity_for(strict)

    if not lesson.frontmatter.get("lang"):
        diagnostics.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    if not lesson.title:
        diagnostics.append(Diagnostic(
            level=sev,
            message="Missing title (no H1 heading and no frontmatter title)",
        ))

    # Check for unclosed fenced blocks (simple heuristic)
    fence_opens = content.count("```")
    if fence_opens % 2 != 0:
        diagnostics.append(Diagnostic(level="error", message="Unclosed fenced block detected"))

    # Check quiz blocks have a question line
    for block in lesson.blocks:
        if block.block_type == "quiz":
            if "?" not in block.content:
                diagnostics.append(Diagnostic(
                    level="error",
                    message="Inline quiz block without a '?' question line",
                ))

    # LearnMD v0.4: !checkpoint validation
    seen_cp: dict[str, int] = {}
    for cp in lesson.checkpoints:
        if not cp.id:
            diagnostics.append(Diagnostic(
                level="error",
                message="!checkpoint missing required 'id' attribute",
            ))
            continue
        seen_cp[cp.id] = seen_cp.get(cp.id, 0) + 1
    for cid, count in seen_cp.items():
        if count > 1:
            diagnostics.append(Diagnostic(
                level="error",
                message=f"Duplicate !checkpoint id '{cid}'",
            ))

    # LearnMD v0.4: media:slug rules
    has_media_ref = any(r.kind == "media" for r in lesson.refs)
    for mref in lesson.media_refs:
        if not has_media_ref:
            diagnostics.append(Diagnostic(
                level=sev,
                message=f"media:{mref.slug} used without a matching !ref MediaMD",
            ))
        if not mref.fallback_url:
            diagnostics.append(Diagnostic(
                level=sev,
                message=f"media:{mref.slug} without a fallback URL",
            ))

    return diagnostics
