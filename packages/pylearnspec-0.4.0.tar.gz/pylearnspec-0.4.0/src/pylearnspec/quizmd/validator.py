"""QuizMD validator — checks .quiz.md content for errors and warnings."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from pylearnspec.quizmd.parser import parse_quiz


@dataclass
class Diagnostic:
    level: Literal["error", "warning"]
    message: str
    question: int | None = None

    def to_dict(self) -> dict:
        d = {"level": self.level, "message": self.message}
        if self.question is not None:
            d["question"] = self.question
        return d


def validate_quiz(content: str, *, strict: bool = False) -> list[Diagnostic]:
    """Validate a .quiz.md string and return a list of diagnostics.

    In lenient mode (default), missing title/lang are warnings.
    In strict mode, they are errors.
    """
    diagnostics: list[Diagnostic] = []

    # Try parsing — catch YAML errors
    try:
        quiz = parse_quiz(content)
    except Exception as e:
        diagnostics.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diagnostics

    # Check frontmatter
    severity: Literal["error", "warning"] = "error" if strict else "warning"

    # In QuizMD v0.3, title is optional (inferred from H1). We still warn if
    # neither is present, because every quiz needs *some* title.
    if not quiz.title:
        diagnostics.append(Diagnostic(level=severity, message="Missing title (no H1 heading and no frontmatter title)"))

    if not quiz.frontmatter.get("lang"):
        diagnostics.append(Diagnostic(level=severity, message="Missing 'lang' in frontmatter"))

    # QuizMD v0.3: media:slug rules
    has_media_ref = any(r.kind == "media" for r in quiz.refs)
    for mref in quiz.media_refs:
        if not has_media_ref:
            diagnostics.append(Diagnostic(
                level=severity,
                message=f"media:{mref.slug} used without a matching !ref MediaMD",
            ))
        if not mref.fallback_url:
            diagnostics.append(Diagnostic(
                level=severity,
                message=f"media:{mref.slug} without a fallback URL",
            ))

    # Check questions
    for q in quiz.questions:
        if q.q_type in ("mcq", "tf"):
            correct_count = sum(1 for c in q.choices if c.correct)
            if correct_count == 0:
                diagnostics.append(Diagnostic(
                    level="error" if strict else "warning",
                    message=f"Q{q.number}: No correct answer marked",
                    question=q.number,
                ))

        if q.q_type == "open" and not q.open_answer and not q.match_pairs and not q.order_items:
            diagnostics.append(Diagnostic(
                level="warning",
                message=f"Q{q.number}: Open question without expected answer",
                question=q.number,
            ))

    return diagnostics
