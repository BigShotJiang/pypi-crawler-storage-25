"""FlashMD validator."""

from __future__ import annotations

import re

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.flashmd.parser import _FLASH_BLOCK_RE, parse_flash


def validate_flash(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        deck = parse_flash(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not deck.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))

    # Per-card validation: walk the raw blocks to count separators.
    seen: dict[str, int] = {}
    for i, m in enumerate(_FLASH_BLOCK_RE.finditer(content), start=1):
        block_body = m.group(2)
        seps = [ln for ln in block_body.splitlines() if ln.strip() == "---"]
        card = deck.cards[i - 1] if i - 1 < len(deck.cards) else None
        cid = card.id if card else ""
        prefix = f"Card '{cid}'" if cid else f"Card #{i}"
        if not cid:
            diags.append(Diagnostic(level="error", message=f"{prefix}: missing 'id'"))
        else:
            seen[cid] = seen.get(cid, 0) + 1
        if len(seps) == 0:
            diags.append(Diagnostic(level="error", message=f"{prefix}: missing '---' front/back separator"))
        elif len(seps) > 1:
            diags.append(Diagnostic(level="error", message=f"{prefix}: '---' separator appears more than once"))
        if card and not card.front.strip():
            diags.append(Diagnostic(level="error", message=f"{prefix}: empty front"))
        if card and not card.back.strip() and len(seps) == 1:
            diags.append(Diagnostic(level="error", message=f"{prefix}: empty back"))

    for cid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate card id '{cid}'"))

    # media:slug uses without a !ref
    if re.search(r"media:[a-z0-9-]+", content) and not deck.refs:
        diags.append(Diagnostic(
            level=sev,
            message="media:slug references found but no !ref MediaMD declaration",
        ))

    return diags
