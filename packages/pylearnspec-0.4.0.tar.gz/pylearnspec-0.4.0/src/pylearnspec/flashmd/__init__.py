"""FlashMD — flashcards format for the LearnSpec suite."""

from pylearnspec.flashmd.parser import parse_flash
from pylearnspec.flashmd.validator import validate_flash

__all__ = ["parse_flash", "validate_flash"]
