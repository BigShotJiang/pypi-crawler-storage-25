"""FlashMD parser — extracts ``flash`` fenced blocks."""

from __future__ import annotations

import re

from pylearnspec.common.directives import extract_refs
from pylearnspec.common.frontmatter import extract_frontmatter
from pylearnspec.flashmd.models import Card, FlashDeck

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)

# ```flash id:slug tags:[...] hint:"..."\nfront\n---\nback\n```
_FLASH_BLOCK_RE = re.compile(
    r"^```flash\b([^\n]*)\n(.*?)^```\s*$",
    re.MULTILINE | re.DOTALL,
)

_ID_RE = re.compile(r"\bid:([a-z0-9][a-z0-9-]*)")
_TAGS_RE = re.compile(r"\btags:\[([^\]]*)\]")
_HINT_RE = re.compile(r'\bhint:"([^"]*)"')

# Card body separator
_SEP = "---"


def _parse_card_attrs(line: str) -> tuple[str, list[str], str]:
    cid = (m.group(1) if (m := _ID_RE.search(line)) else "")
    tags: list[str] = []
    if (m := _TAGS_RE.search(line)):
        tags = [t.strip().strip('"').strip("'") for t in m.group(1).split(",") if t.strip()]
    hint = m.group(1) if (m := _HINT_RE.search(line)) else ""
    return cid, tags, hint


def parse_flash(content: str) -> FlashDeck:
    frontmatter, body = extract_frontmatter(content)
    title = frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    refs = [r.path for r in extract_refs(body)]

    cards: list[Card] = []
    for m in _FLASH_BLOCK_RE.finditer(body):
        attrs_line = m.group(1) or ""
        block_body = m.group(2)
        cid, tags, hint = _parse_card_attrs(attrs_line)

        # Split body on a line containing only ---
        lines = block_body.splitlines()
        sep_indices = [i for i, ln in enumerate(lines) if ln.strip() == _SEP]
        if len(sep_indices) == 1:
            front = "\n".join(lines[: sep_indices[0]]).strip()
            back = "\n".join(lines[sep_indices[0] + 1 :]).strip()
        else:
            # 0 separators → all front; >1 separators → join with first as boundary (validator will flag)
            front = "\n".join(lines).strip() if not sep_indices else "\n".join(lines[: sep_indices[0]]).strip()
            back = "" if not sep_indices else "\n".join(lines[sep_indices[0] + 1 :]).strip()

        cards.append(Card(id=cid, front=front, back=back, tags=tags, hint=hint))

    has_fm = bool(frontmatter)
    has_per_card = any(c.tags or c.hint for c in cards) or any("media:" in c.front + c.back for c in cards)
    if has_per_card:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return FlashDeck(title=title, level=level, frontmatter=frontmatter, cards=cards, refs=refs)
