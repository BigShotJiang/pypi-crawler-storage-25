"""CertMD parser."""

from __future__ import annotations

import re

import yaml

from pylearnspec.certmd.models import Cert
from pylearnspec.common.frontmatter import extract_frontmatter

_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_IMAGE_LINE_RE = re.compile(r"^!\[[^\]]*\]\(([^)]+)\)", re.MULTILINE)
_REQUIREMENTS_BLOCK_RE = re.compile(
    r"^```requirements\s*\n(.*?)^```\s*$",
    re.MULTILINE | re.DOTALL,
)


def parse_cert(content: str) -> Cert:
    frontmatter, body = extract_frontmatter(content)

    title = frontmatter.get("name", "") or frontmatter.get("title", "")
    if not title:
        m = _H1_RE.search(body)
        if m:
            title = m.group(1).strip()

    image_path = ""
    if (m := _IMAGE_LINE_RE.search(body)):
        image_path = m.group(1).strip()

    requirements: list[dict] = []
    has_block = False
    if (m := _REQUIREMENTS_BLOCK_RE.search(body)):
        has_block = True
        try:
            loaded = yaml.safe_load(m.group(1))
            if isinstance(loaded, dict):
                requirements = [loaded]
            elif isinstance(loaded, list):
                requirements = [r for r in loaded if isinstance(r, dict)]
        except yaml.YAMLError:
            pass

    body_text = _REQUIREMENTS_BLOCK_RE.sub("", body)
    body_text = _IMAGE_LINE_RE.sub("", body_text, count=1).strip()

    has_fm = bool(frontmatter)
    if has_block:
        level = "2"
    elif has_fm:
        level = "1"
    else:
        level = "0"

    return Cert(
        title=title,
        level=level,
        frontmatter=frontmatter,
        image_path=image_path,
        body_text=body_text,
        requirements=requirements,
        has_requirements_block=has_block,
    )
