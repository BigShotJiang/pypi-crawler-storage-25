"""Data models for TrackMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pylearnspec.common.directives import Checkpoint, ImportDirective, RefDirective


@dataclass
class Section:
    title: str
    steps: list[ImportDirective] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "steps": [s.to_dict() for s in self.steps],
            "checkpoints": [c.to_dict() for c in self.checkpoints],
        }


@dataclass
class Track:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    sections: list[Section] = field(default_factory=list)
    refs: list[RefDirective] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "sections": [s.to_dict() for s in self.sections],
            "refs": [r.to_dict() for r in self.refs],
        }
