"""TrackMD validator."""

from __future__ import annotations

from pylearnspec.common.validation import Diagnostic, severity_for
from pylearnspec.trackmd.parser import parse_track


def validate_track(content: str, *, strict: bool = False) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    try:
        track = parse_track(content)
    except Exception as e:
        diags.append(Diagnostic(level="error", message=f"Parse error: {e}"))
        return diags

    sev = severity_for(strict)

    if not track.frontmatter.get("lang"):
        diags.append(Diagnostic(level=sev, message="Missing 'lang' in frontmatter"))
    if not track.title:
        diags.append(Diagnostic(level=sev, message="Missing title (no H1 and no frontmatter title)"))

    total_steps = sum(len(s.steps) for s in track.sections)
    if total_steps == 0:
        diags.append(Diagnostic(level=sev, message="No !import steps found in the track"))

    # passing_score attr only valid on .quiz.md imports
    for s in track.sections:
        for step in s.steps:
            if "passing_score" in step.attrs and step.kind != "quiz":
                diags.append(Diagnostic(
                    level=sev,
                    message=f"'passing_score' attribute on non-quiz import: {step.path}",
                ))

    # completion.passing_score in [0,1]
    completion = track.frontmatter.get("completion") or {}
    if isinstance(completion, dict):
        ps = completion.get("passing_score")
        if ps is not None:
            try:
                v = float(ps)
                if v < 0 or v > 1:
                    diags.append(Diagnostic(
                        level="error",
                        message=f"completion.passing_score must be between 0.0 and 1.0 (got {ps})",
                    ))
            except (TypeError, ValueError):
                diags.append(Diagnostic(
                    level="error",
                    message=f"completion.passing_score must be a number (got {ps!r})",
                ))

    # Duplicate checkpoint ids
    seen: dict[str, int] = {}
    for s in track.sections:
        for cp in s.checkpoints:
            seen[cp.id] = seen.get(cp.id, 0) + 1
    for cid, count in seen.items():
        if count > 1:
            diags.append(Diagnostic(level="error", message=f"Duplicate checkpoint id '{cid}'"))

    return diags
