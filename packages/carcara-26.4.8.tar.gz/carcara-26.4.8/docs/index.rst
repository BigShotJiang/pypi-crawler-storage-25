.. Carcará documentation master file, created by
   sphinx-quickstart on Sat Jul 12 04:26:21 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Carcará documentation
=====================

Towards Explainable, Scalable, and Accurate Machine-Learned Interatomic Potentials


.. toctree::
   :maxdepth: 2
   :caption: Contents:

