from pathlib import Path
import pathlib

import pytest
import spike2py as s2p
import spike2py_reflex as s2pr


@pytest.mark.plot
def test_plot_single_inspection_study7_burst_off():
    pathlib.WindowsPath = pathlib.PosixPath

    study_path = Path(__file__).resolve().parent / "data" / "study_7"

    if not study_path.exists():
        pytest.skip(f"Study path does not exist: {study_path}")

    info = s2pr.info.Info(study_path, True)
    info.clear_subject()
    info.init_subject("S02")
    info.trial = "bsl_o"

    section_name = "burst_off"
    info.clear_section()
    info.init_section(section_name)

    data = s2p.trial.load(info.section_pkl)
    info.triggers = s2pr.utils.Triggers(info, data)

    section = s2pr.reflexes.extract(info, data)
    section = s2pr.outcomes.calculate(section)
    s2pr.outcomes.summary(section)

    s2pr.plot.reflexes(section)

    reflex_dir = study_path / "S02" / "figures" / "reflexes"

    standard_file = reflex_dir / "bsl_o_burst_off_reflexes.pdf"
    assert standard_file.exists()
    assert standard_file.stat().st_size > 0

    inspection_files = list(reflex_dir.glob("bsl_o_burst_off_*reflexes_inspection.pdf"))
    assert len(inspection_files) >= 1
    assert all(f.stat().st_size > 0 for f in inspection_files)