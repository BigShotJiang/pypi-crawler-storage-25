import copy

import pytest
import spike2py_reflex as s2pr


THRESHOLD = s2pr.plot.get_inspection_threshold(s2pr.utils.SINGLE)


@pytest.mark.plot
def test_plot_single_inspection_created_for_high_reflex_count(info_data_mmax):
    info, data = info_data_mmax

    section = s2pr.reflexes.extract(info, data)
    section = s2pr.outcomes.calculate(section)

    base_reflex = section.reflexes["Fdi"].reflexes[0]
    stim_intensity = base_reflex.stim_intensity

    current_count = len(
        [r for r in section.reflexes["Fdi"].reflexes if r.stim_intensity == stim_intensity]
    )
    duplicates_needed = (THRESHOLD + 1) - current_count

    for _ in range(max(0, duplicates_needed)):
        section.reflexes["Fdi"].reflexes.append(copy.deepcopy(base_reflex))

    out_dir = (
        section.info.study_path
        / section.info.subject
        / "figures"
        / "reflexes"
    )

    expected_file = out_dir / (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{stim_intensity}mA_"
        f"reflexes_inspection.pdf"
    )

    if expected_file.exists():
        expected_file.unlink()

    s2pr.plot.plot_single_inspection(section)

    assert expected_file.exists()
    assert expected_file.stat().st_size > 0


@pytest.mark.plot
def test_plot_single_inspection_not_created_when_reflex_count_below_threshold(info_data_mmax):
    info, data = info_data_mmax

    section = s2pr.reflexes.extract(info, data)
    section = s2pr.outcomes.calculate(section)

    # Force the number of reflexes below the inspection threshold
    max_allowed = max(1, THRESHOLD)
    section.reflexes["Fdi"].reflexes = section.reflexes["Fdi"].reflexes[:max_allowed]

    stim_intensity = section.reflexes["Fdi"].reflexes[0].stim_intensity

    out_dir = (
        section.info.study_path
        / section.info.subject
        / "figures"
        / "reflexes"
    )

    expected_file = out_dir / (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{stim_intensity}mA_"
        f"reflexes_inspection.pdf"
    )

    if expected_file.exists():
        expected_file.unlink()

    s2pr.plot.plot_single_inspection(section)

    assert not expected_file.exists()


@pytest.mark.plot
def test_plot_single_inspection_created_only_for_dense_intensity(info_data_mmax):
    info, data = info_data_mmax

    section = s2pr.reflexes.extract(info, data)
    section = s2pr.outcomes.calculate(section)

    original_intensity = section.reflexes["Fdi"].reflexes[0].stim_intensity
    new_intensity = 32

    # Move one reflex to a new sparse intensity
    section.reflexes["Fdi"].reflexes[-1].stim_intensity = new_intensity

    # Keep avg_waveform consistent with the added intensity
    section.reflexes["Fdi"].avg_waveform[new_intensity] = copy.deepcopy(
        section.reflexes["Fdi"].avg_waveform[original_intensity]
    )

    base_reflex = None
    for reflex in section.reflexes["Fdi"].reflexes:
        if reflex.stim_intensity == original_intensity:
            base_reflex = reflex
            break

    current_count_original = len(
        [r for r in section.reflexes["Fdi"].reflexes if r.stim_intensity == original_intensity]
    )
    duplicates_needed = (THRESHOLD + 1) - current_count_original

    for _ in range(max(0, duplicates_needed)):
        section.reflexes["Fdi"].reflexes.append(copy.deepcopy(base_reflex))

    out_dir = (
        section.info.study_path
        / section.info.subject
        / "figures"
        / "reflexes"
    )

    expected_dense_file = out_dir / (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{original_intensity}mA_"
        f"reflexes_inspection.pdf"
    )

    expected_sparse_file = out_dir / (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{new_intensity}mA_"
        f"reflexes_inspection.pdf"
    )

    if expected_dense_file.exists():
        expected_dense_file.unlink()
    if expected_sparse_file.exists():
        expected_sparse_file.unlink()

    s2pr.plot.plot_single_inspection(section)

    assert expected_dense_file.exists()
    assert expected_dense_file.stat().st_size > 0
    assert not expected_sparse_file.exists()