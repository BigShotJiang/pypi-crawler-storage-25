from typing import List

import matplotlib.pyplot as plt

import spike2py_reflex as s2pr


ROW_HEIGHT = 2.0
COLUMN_WIDTH = 4.0


def plot_double_inspection(section) -> None:
    """Generate additional double-style inspection figures when many doubles are present."""
    muscles, n_muscles, intensities, _ = s2pr.plot.get_muscles_and_intensities(section)

    for intensity in intensities:
        reflexes_by_muscle = {
            muscle: _get_reflexes_for_intensity(section, muscle, intensity)
            for muscle in muscles
        }

        n_reflexes = max(len(reflexes) for reflexes in reflexes_by_muscle.values())
        if not s2pr.plot.should_create_inspection_plot(n_reflexes, s2pr.utils.DOUBLE):
            continue

        n_rows = 1 + n_reflexes
        n_cols = n_muscles * 2

        fig = plt.figure(figsize=(COLUMN_WIDTH * n_muscles * 2, ROW_HEIGHT * n_rows))

        _plot_summary_row(fig, section, muscles, n_rows, n_cols, intensity)

        for reflex_idx in range(n_reflexes):
            _plot_individual_double_row(
                fig=fig,
                section=section,
                muscles=muscles,
                n_rows=n_rows,
                n_cols=n_cols,
                row_idx=reflex_idx + 1,
                reflex_idx=reflex_idx,
                intensity=intensity,
                reflexes_by_muscle=reflexes_by_muscle,
            )

        plt.tight_layout()
        save_inspection_figure(section, intensity)
        plt.close(fig)


def _plot_summary_row(fig, section, muscles, n_rows: int, n_cols: int, intensity) -> None:
    for muscle_idx, muscle in enumerate(muscles):
        wide_subplot = muscle_idx * 2 + 1
        zoom_subplot = wide_subplot + 1

        ax_wide = fig.add_subplot(n_rows, n_cols, wide_subplot)
        plt.sca(ax_wide)
        s2pr.plot.overlay_reflexes(section, muscle, intensity, legend=False)

        ax_zoom = fig.add_subplot(n_rows, n_cols, zoom_subplot)
        plt.sca(ax_zoom)
        _overlay_single_double(section, muscle, intensity=intensity)
        s2pr.plot.add_reflex_windows(section.info, muscle)
        s2pr.plot.set_x_lim(section.info.windows.ms_plotting.double_single_pulse)


def _plot_individual_double_row(
    fig,
    section,
    muscles: List[str],
    n_rows: int,
    n_cols: int,
    row_idx: int,
    reflex_idx: int,
    intensity,
    reflexes_by_muscle: dict,
) -> None:
    for muscle_idx, muscle in enumerate(muscles):
        row_start = row_idx * n_cols
        wide_subplot = row_start + 1 + (muscle_idx * 2)
        zoom_subplot = wide_subplot + 1

        muscle_reflexes = reflexes_by_muscle[muscle]

        ax_wide = fig.add_subplot(n_rows, n_cols, wide_subplot)
        plt.sca(ax_wide)

        if reflex_idx < len(muscle_reflexes):
            reflex = muscle_reflexes[reflex_idx]
            _plot_full_double(section, muscle, reflex)
            _add_double_legend(reflex)
            _set_individual_title(section, muscle, intensity, reflex_idx)
        else:
            ax_wide.set_axis_off()

        ax_zoom = fig.add_subplot(n_rows, n_cols, zoom_subplot)
        plt.sca(ax_zoom)

        if reflex_idx < len(muscle_reflexes):
            reflex = muscle_reflexes[reflex_idx]
            _plot_double_components(section, muscle, reflex)
            s2pr.plot.add_reflex_windows(section.info, muscle)
            s2pr.plot.set_x_lim(section.info.windows.ms_plotting.double_single_pulse)
            _add_component_legend(reflex)
        else:
            ax_zoom.set_axis_off()


def _get_reflexes_for_intensity(section, muscle: str, intensity) -> list:
    reflexes = []
    for reflex in section.reflexes[muscle].reflexes:
        if _matches_intensity(reflex, intensity):
            reflexes.append(reflex)
    return reflexes


def _matches_intensity(reflex, intensity) -> bool:
    if intensity == "no_intensity":
        return reflex.stim_intensity is None
    return reflex.stim_intensity == intensity


def _plot_full_double(section, muscle: str, reflex) -> None:
    plt.plot(
        section.reflexes[muscle].x_axis_extract,
        reflex.waveform,
        alpha=0.9,
    )
    plt.xlabel("time (s)")
    plt.grid()


def _plot_double_components(section, muscle: str, reflex) -> None:
    try:
        plt.plot(
            section.reflexes[muscle].x_axis_singles,
            reflex.reflex1.waveform,
            alpha=0.9,
            color="red",
            label="reflex1",
        )
    except AttributeError:
        pass

    try:
        plt.plot(
            section.reflexes[muscle].x_axis_singles,
            reflex.reflex2.waveform,
            alpha=0.9,
            color="blue",
            label="reflex2",
        )
    except AttributeError:
        pass

    plt.xlabel("time (s)")
    plt.grid()


def _overlay_single_double(section, muscle: str, intensity=None) -> None:
    for reflex in section.reflexes[muscle].reflexes:
        if intensity is not None and reflex.stim_intensity != intensity:
            continue

        try:
            plt.plot(
                section.reflexes[muscle].x_axis_singles,
                reflex.reflex1.waveform,
                alpha=0.3,
                color="red",
            )
        except AttributeError:
            pass

        try:
            plt.plot(
                section.reflexes[muscle].x_axis_singles,
                reflex.reflex2.waveform,
                alpha=0.3,
                color="blue",
            )
        except AttributeError:
            pass

    try:
        avg_reflex1 = section.reflexes[muscle].avg_reflex1[intensity]
        plt.plot(
            section.reflexes[muscle].x_axis_singles,
            avg_reflex1.waveform,
            alpha=1,
            color="red",
            label="reflex1",
        )
    except Exception:
        pass

    try:
        avg_reflex2 = section.reflexes[muscle].avg_reflex2[intensity]
        plt.plot(
            section.reflexes[muscle].x_axis_singles,
            avg_reflex2.waveform,
            alpha=1,
            color="blue",
            label="reflex2",
        )
    except Exception:
        pass


def _add_double_legend(reflex) -> None:
    label = f"{reflex.extract_times[0]:6.1f}-{reflex.extract_times[1]:6.1f}"
    plt.legend([label], fontsize="x-small")


def _add_component_legend(reflex) -> None:
    labels = []
    handles = []

    if reflex.reflex1 is not None:
        labels.append(
            f"r1 {reflex.reflex1.extract_times[0]:.1f}-{reflex.reflex1.extract_times[1]:.1f}"
        )
        handles.append(plt.Line2D([], [], color="red"))

    if reflex.reflex2 is not None:
        labels.append(
            f"r2 {reflex.reflex2.extract_times[0]:.1f}-{reflex.reflex2.extract_times[1]:.1f}"
        )
        handles.append(plt.Line2D([], [], color="blue"))

    if handles:
        plt.legend(handles, labels, fontsize="x-small")


def _set_individual_title(section, muscle: str, intensity, reflex_idx: int) -> None:
    if intensity == "no_intensity" or intensity is None:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"double{reflex_idx + 1}"
        )
    else:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"{intensity}mA-"
            f"double{reflex_idx + 1}"
        )
    plt.title(title, fontsize=9)


def save_inspection_figure(section, intensity) -> None:
    path = section.info.study_path / section.info.subject / "figures" / "reflexes"
    path.mkdir(parents=True, exist_ok=True)

    intensity_label = (
        "no_intensity"
        if intensity == "no_intensity" or intensity is None
        else f"{intensity}mA"
    )
    figure_name = (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{intensity_label}_"
        f"double_reflexes_inspection.pdf"
    )
    plt.savefig(path / figure_name)