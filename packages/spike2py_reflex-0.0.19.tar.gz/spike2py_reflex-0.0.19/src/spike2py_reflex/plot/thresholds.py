import spike2py_reflex as s2pr


def get_inspection_threshold(plot_type: str) -> int:
    """Return the reflex-count threshold for a given plot type.

    Parameters
    ----------
    plot_type : str
        One of s2pr.utils.SINGLE, DOUBLE, or TRAIN.
    """
    if plot_type == s2pr.utils.SINGLE:
        return s2pr.utils.SINGLE_REFLEX_LEGEND_THRESHOLD

    elif plot_type == s2pr.utils.DOUBLE:
        return s2pr.utils.DOUBLE_REFLEX_LEGEND_THRESHOLD

    elif plot_type == s2pr.utils.TRAIN:
        return s2pr.utils.TRAIN_REFLEX_LEGEND_THRESHOLD

    else:
        raise ValueError(f"Unknown plot type: {plot_type}")

def should_create_inspection_plot(n_reflexes: int, plot_type: str) -> bool:
    """Return True if an inspection plot should be generated."""
    return n_reflexes > get_inspection_threshold(plot_type)
