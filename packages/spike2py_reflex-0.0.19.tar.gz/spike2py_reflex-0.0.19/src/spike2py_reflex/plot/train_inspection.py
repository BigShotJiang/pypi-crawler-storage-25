from typing import List

import matplotlib.pyplot as plt

import spike2py_reflex as s2pr


ROW_HEIGHT = 2.0
COLUMN_WIDTH = 4.0
MAX_ROWS = 30 # i.e. Max number of train pulses to consider for inspection plot

def plot_train_inspection(section) -> None:
    muscles, n_muscles, intensities, _ = s2pr.plot.get_muscles_and_intensities(section)

    for intensity in intensities:
        reflexes_by_muscle = {
            muscle: _get_reflexes_for_intensity(section, muscle, intensity)
            for muscle in muscles
        }

        true_n_reflexes = max(len(reflexes) for reflexes in reflexes_by_muscle.values())

        if not s2pr.plot.should_create_inspection_plot(true_n_reflexes, s2pr.utils.TRAIN):
            continue

        # Cap ONLY for plotting
        n_reflexes = min(true_n_reflexes, MAX_ROWS)
        if true_n_reflexes > MAX_ROWS:
            print(f"Capping reflex plots: showing {MAX_ROWS}/{true_n_reflexes}")
            
        n_rows = 1 + n_reflexes
        n_cols = n_muscles
        fig = plt.figure(figsize=(COLUMN_WIDTH * n_muscles, ROW_HEIGHT * n_rows))

        _plot_summary_row(fig, section, muscles, n_rows, n_cols, intensity)

        for reflex_idx in range(n_reflexes):
            _plot_individual_row(
                fig=fig,
                section=section,
                muscles=muscles,
                n_rows=n_rows,
                n_cols=n_cols,
                row_idx=reflex_idx + 1,
                reflex_idx=reflex_idx,
                intensity=intensity,
                reflexes_by_muscle=reflexes_by_muscle,
            )

        plt.tight_layout()
        save_inspection_figure(section, intensity)
        plt.close(fig)


def _plot_summary_row(fig, section, muscles, n_rows: int, n_cols: int, intensity) -> None:
    """Row 1: same overall style as the current train summary row."""
    for muscle_idx, muscle in enumerate(muscles):
        subplot = muscle_idx + 1

        ax = fig.add_subplot(n_rows, n_cols, subplot)
        plt.sca(ax)
        s2pr.plot.overlay_reflexes(section, muscle, intensity, legend=False)
        s2pr.plot.add_reflex_windows(section.info, muscle)
        s2pr.plot.set_x_lim(section.info.windows.ms_plotting.train_single_pulse)


def _plot_individual_row(
    fig,
    section,
    muscles: List[str],
    n_rows: int,
    n_cols: int,
    row_idx: int,
    reflex_idx: int,
    intensity,
    reflexes_by_muscle: dict,
) -> None:
    """Plot one train reflex row across all muscles."""
    for muscle_idx, muscle in enumerate(muscles):
        subplot = row_idx * n_cols + muscle_idx + 1
        ax = fig.add_subplot(n_rows, n_cols, subplot)
        plt.sca(ax)

        muscle_reflexes = reflexes_by_muscle[muscle]
        if reflex_idx < len(muscle_reflexes):
            reflex = muscle_reflexes[reflex_idx]
            _plot_single_reflex(section, muscle, reflex)
            s2pr.plot.add_reflex_windows(section.info, muscle)
            s2pr.plot.set_x_lim(section.info.windows.ms_plotting.train_single_pulse)
            _add_single_reflex_legend(reflex)
            _set_individual_title(section, muscle, intensity, reflex_idx)
        else:
            ax.set_axis_off()


def _get_reflexes_for_intensity(section, muscle: str, intensity) -> list:
    reflexes = []
    for reflex in section.reflexes[muscle].reflexes:
        if _matches_intensity(reflex, intensity):
            reflexes.append(reflex)
    return reflexes


def _matches_intensity(reflex, intensity) -> bool:
    if intensity == "no_intensity":
        return reflex.stim_intensity is None
    return reflex.stim_intensity == intensity


def _plot_single_reflex(section, muscle: str, reflex) -> None:
    plt.plot(
        section.reflexes[muscle].x_axis_extract,
        reflex.waveform,
        alpha=0.9,
    )
    plt.xlabel("time (s)")
    plt.grid()


def _add_single_reflex_legend(reflex) -> None:
    label = f"{reflex.extract_times[0]:6.1f}-{reflex.extract_times[1]:6.1f}"
    plt.legend([label], fontsize="x-small")


def _set_individual_title(section, muscle: str, intensity, reflex_idx: int) -> None:
    if intensity == "no_intensity" or intensity is None:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"reflex{reflex_idx + 1}"
        )
    else:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"{intensity}mA-"
            f"reflex{reflex_idx + 1}"
        )
    plt.title(title, fontsize=9)


def save_inspection_figure(section, intensity) -> None:
    path = section.info.study_path / section.info.subject / "figures" / "reflexes"
    path.mkdir(parents=True, exist_ok=True)

    intensity_label = (
        "no_intensity"
        if intensity == "no_intensity" or intensity is None
        else f"{intensity}mA"
    )
    figure_name = (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{intensity_label}_"
        f"train_reflexes_inspection.pdf"
    )
    plt.savefig(path / figure_name)