from pathlib import Path
from typing import List

import matplotlib.pyplot as plt

import spike2py_reflex as s2pr



# Slightly smaller per-row scaling than the summary figure, because these can get tall.
ROW_HEIGHT = 2.0
COLUMN_WIDTH = 4.0


def plot_single_inspection(section) -> None:
    """Generate additional single-style inspection figures when many reflexes are present.

    For each stimulation intensity with more than LEGEND_REFLEX_LIMIT reflexes,
    generate an additional figure:
      - row 1: standard overview row (wide + zoomed for each muscle)
      - rows 2..N: one reflex per row (wide + zoomed for each muscle)

    This keeps the current summary figure unchanged and adds a companion figure
    only for dense conditions.
    """
    muscles, n_muscles, intensities, _ = s2pr.plot.get_muscles_and_intensities(section)

    print("Entered plot_single_inspection")
    print("muscles:", muscles)
    print("intensities:", intensities)

    muscles, n_muscles, intensities, _ = s2pr.plot.get_muscles_and_intensities(section)

    for intensity in intensities:
        reflexes_by_muscle = {
            muscle: _get_reflexes_for_intensity(section, muscle, intensity)
            for muscle in muscles
        }

        counts = {muscle: len(reflexes_by_muscle[muscle]) for muscle in muscles}
        n_reflexes = max(counts.values())

        print(
            f"intensity={intensity}, counts={counts}, max={n_reflexes}, threshold={s2pr.utils.SINGLE_REFLEX_LEGEND_THRESHOLD}")

        if not s2pr.plot.should_create_inspection_plot(n_reflexes, s2pr.utils.SINGLE):
            continue

        n_rows = 1 + n_reflexes
        n_cols = n_muscles * 2

        fig = plt.figure(figsize=(COLUMN_WIDTH * n_muscles * 2, ROW_HEIGHT * n_rows))

        _plot_summary_row(fig, section, muscles, n_rows, n_cols, intensity)

        for reflex_idx in range(n_reflexes):
            _plot_individual_reflex_row(
                fig=fig,
                section=section,
                muscles=muscles,
                n_rows=n_rows,
                n_cols=n_cols,
                row_idx=reflex_idx + 1,
                reflex_idx=reflex_idx,
                intensity=intensity,
                reflexes_by_muscle=reflexes_by_muscle,
            )

        plt.tight_layout()
        save_inspection_figure(section, intensity)
        plt.close(fig)


def _plot_summary_row(fig, section, muscles, n_rows: int, n_cols: int, intensity) -> None:
    """Row 1: same overall style as the current single summary row."""
    for muscle_idx, muscle in enumerate(muscles):
        wide_subplot = muscle_idx * 2 + 1
        zoom_subplot = wide_subplot + 1

        ax_wide = fig.add_subplot(n_rows, n_cols, wide_subplot)
        plt.sca(ax_wide)
        s2pr.plot.overlay_reflexes(section, muscle, intensity, legend=False)

        ax_zoom = fig.add_subplot(n_rows, n_cols, zoom_subplot)
        plt.sca(ax_zoom)
        s2pr.plot.overlay_reflexes(section, muscle, intensity, legend=False)
        s2pr.plot.set_x_lim(section.info.windows.ms_plotting.single)
        s2pr.plot.add_reflex_windows(section.info, muscle)


def _plot_individual_reflex_row(
    fig,
    section,
    muscles: List[str],
    n_rows: int,
    n_cols: int,
    row_idx: int,
    reflex_idx: int,
    intensity,
    reflexes_by_muscle: dict,
) -> None:
    """Plot one reflex row across all muscles."""
    for muscle_idx, muscle in enumerate(muscles):
        row_start = row_idx * n_cols
        wide_subplot = row_start + 1 + (muscle_idx * 2)
        zoom_subplot = wide_subplot + 1

        ax_wide = fig.add_subplot(n_rows, n_cols, wide_subplot)
        plt.sca(ax_wide)

        muscle_reflexes = reflexes_by_muscle[muscle]
        if reflex_idx < len(muscle_reflexes):
            reflex = muscle_reflexes[reflex_idx]
            _plot_single_reflex(section, muscle, reflex, zoomed=False)
            _add_single_reflex_legend(reflex)
            _set_individual_title(section, muscle, intensity, reflex_idx)
        else:
            ax_wide.set_axis_off()

        ax_zoom = fig.add_subplot(n_rows, n_cols, zoom_subplot)
        plt.sca(ax_zoom)

        if reflex_idx < len(muscle_reflexes):
            reflex = muscle_reflexes[reflex_idx]
            _plot_single_reflex(section, muscle, reflex, zoomed=True)
            s2pr.plot.set_x_lim(section.info.windows.ms_plotting.single)
            s2pr.plot.add_reflex_windows(section.info, muscle)
            _add_single_reflex_legend(reflex)
        else:
            ax_zoom.set_axis_off()


def _plot_single_reflex(section, muscle: str, reflex, zoomed: bool) -> None:
    """Plot a single reflex trace using the existing single-style x-axis."""
    plt.plot(
        section.reflexes[muscle].x_axis_extract,
        reflex.waveform,
        alpha=0.9,
    )
    plt.xlabel("time (s)")
    plt.grid()


def _add_single_reflex_legend(reflex) -> None:
    label = f"{reflex.extract_times[0]:6.1f}-{reflex.extract_times[1]:6.1f}"
    plt.legend([label], fontsize="x-small")


def _set_individual_title(section, muscle: str, intensity, reflex_idx: int) -> None:
    if intensity == "no_intensity" or intensity is None:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"reflex{reflex_idx + 1}"
        )
    else:
        title = (
            f"{section.info.subject}-"
            f"{section.info.trial}-"
            f"{section.info.section}-"
            f"{muscle}-"
            f"{intensity}mA-"
            f"reflex{reflex_idx + 1}"
        )
    plt.title(title, fontsize=9)


def _get_reflexes_for_intensity(section, muscle: str, intensity) -> list:
    """Return reflexes for a specific intensity, preserving original order."""
    reflexes = []
    for reflex in section.reflexes[muscle].reflexes:
        if _matches_intensity(reflex, intensity):
            reflexes.append(reflex)
    return reflexes


def _matches_intensity(reflex, intensity) -> bool:
    """Handle both numeric intensities and no-intensity sections."""
    if intensity == "no_intensity":
        return reflex.stim_intensity is None
    return reflex.stim_intensity == intensity


def save_inspection_figure(section, intensity) -> None:
    path = section.info.study_path / section.info.subject / "figures" / "reflexes"
    if not path.exists():
        path.mkdir(parents=True)

    intensity_label = (
        "no_intensity"
        if intensity == "no_intensity" or intensity is None
        else f"{intensity}mA"
    )
    figure_name = (
        f"{section.info.trial}_"
        f"{section.info.section}_"
        f"{intensity_label}_"
        f"reflexes_inspection.pdf"
    )
    print("Saving inspection figure to:", path / figure_name)
    plt.savefig(path / figure_name)