# Changelog

本项目所有重大变更记录在此文件中。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [0.3.3.5] - 2026-05-10

> 🔴 **隐私泄漏修复（P0）** + spinner 显示 buffer 竞争 fix + auto-install 提示移到命令完成后。

### Fixed

- **🔴 v0.3.3.0 ~ v0.3.3.4 CHANGELOG / docs 含项目内部私人称谓**（P0 隐私泄漏）
  - 影响范围：CHANGELOG.md / docs/roadmap.md / docs/design-kan-doctor.md / docs/reviews/v0.3.3.md
  - 已发到 PyPI 的 v0.3.3.0 ~ v0.3.3.4 含此泄漏 · **强烈建议升级到 v0.3.3.5**
  - 全部替换为中性词「用户」
  - 教训：开源项目所有公开输出（commit message / PR body / CHANGELOG / docs）必须用专业中性词，不用项目内部昵称
- **spinner 跟 auto-install 提示 buffer 竞争** · v0.3.3.4 在 add 命令前调用 `_auto_install_completion` · 其 stderr 输出 Console.print 跟后面 add 命令的 Live Display spinner 共享 stderr · buffer 状态竞争导致 spinner 动画在某些终端可能不可见
  - 修复：`_auto_install_completion` 移到 `atexit` · 命令结束后才执行 · 不再跟 spinner 抢 stderr
  - 用户视角：先看到完整命令输出（含 spinner 动画 + 完成提示 + 失败列表 + 汇总）· 命令完成后才看到一行 `💡 已为你自动启用 zsh 命令补全` 提示
  - TTY 真测验证：xxd 数到 29 次 spinner unicode 帧切换 + 「添加完成」在「💡 已为你自动启用」之前 ✅

### Changed

- `cli_main` 用 `atexit.register(_auto_install_completion)` 替代直接调用
- 命令输出顺序变化：spinner / 命令结果 → 末尾 auto-install 提示（之前是 auto-install 提示 → spinner / 命令结果）

## [0.3.3.4] - 2026-05-10

> 🔴 **修复 v0.3.3.1-3 spinner 不显示的真 bug** + 自动启用 shell 补全（不再要用户手动跑 kan completion install）。

### Fixed

- **🔴 spinner 在终端完全不显示** · v0.3.3.1-3 用户实战暴露：`kan add 169 只`时输入命令后 ~10s 静默无反馈，用户以为程序挂死
  - 根因 1: `cli.py:add` 创建 `Console()` 默认写 stdout
  - 根因 2: `cli.py:add` 外层 `sys.stderr = io.StringIO()` 抑制 akshare tqdm
  - 根因 3: `watchlist.py:_fetch_names_baostock` 内部**也重定向 sys.stdout** 抑制 baostock login banner
  - 根因 4: spinner 写 stdout · baostock 重定向 stdout · **两者打架 spinner ANSI 跑到 StringIO 不可见**
  - 修复: `Console(stderr=True)` 让 spinner 写 stderr · 防被 baostock 内部 stdout 重定向干扰
  - 修复: akshare tqdm 抑制下沉到 `watchlist.py:_fetch_names_akshare` 内部 self-suppress · 不在 cli.py 外层全局重定向
  - **TTY 真测验证**: 用 `script -q` 录终端 ANSI stream · `xxd` 看到 ⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏ braille unicode 多次出现 + `\r` + `[2K` 清行 ✅
- **audit 漏判教训** · 之前 v0.3.3.1/.2 测试都是 `uv run kan add ... | tail` (pipe → 非 TTY → Rich 自动 disable spinner)。**`pipe 测 spinner` 永远是空跑**，必须用 `script` 或 `pty` 真测。

### Added

- **`kan` 任意命令首次启动自动启用 shell 补全** (`_auto_install_completion`)
  - 用户视角: `uv tool install manmankan` 后第一次跑 `kan add 600519` → 自动检测 shell + 装补全脚本 + 显示一行小字提示「💡 已为你自动启用 zsh 命令补全」
  - 不再需要用户手动 `kan completion install`
  - 标记文件 `~/.local/share/kan/.completion_installed` 防重复装
  - **跳过条件**（防 surprising behavior）：
    - 环境变量 `KAN_NO_COMPLETION_AUTOINSTALL=1`（power user 关闭）
    - 标记文件已存在
    - 非 TTY 环境（pipe / CI / docker · 不自动改 shell rc）
    - 检测不到 shell

### Why · 用户批评驱动

- 「卡 10s 啥也没输出怪怪的」→ spinner 不显示真 bug 浮现
- 「为啥还要用户单独去输入命令多复杂哇」→ auto-install completion 实现

## [0.3.3.3] - 2026-05-10

> 新增 `kan completion install` 子命令 · 一键启用 shell 命令前缀补全（kan s<Tab> → kan scan）· 适配 mac/linux/windows 全平台。

### Added

- **`kan completion install [shell]` 子命令** · 一键安装 shell 命令前缀补全
  - 默认: 自动检测 shell（shellingham → $SHELL → windows PSModulePath 三层 fallback）
  - 显式: `kan completion install zsh` / `bash` / `fish` / `powershell` / `pwsh`
  - 用 typer.completion.install 内置 API · 不重造轮子
  - 安装后效果:
    - `kan s<Tab>` → `kan scan`
    - `kan <Tab>` → 列出所有命令（add / scan / list / info / trend / ...）
    - `kan trend --<Tab>` → 列出 `--down` / `--up` / `--latest` / `--candle` 等
- 新增 `_detect_shell_fallback()` helper · 三层 fallback 检测 shell（适配 typer 0.25 + uv tool 环境下 shellingham 失败的 corner case）
- 新增 9 条 completion 测试 (`tests/test_completion_cli.py`) · 154 → **164 passed**
- `kan help` 中文速记加 shell 补全段

### Why

用户 v0.3.3.2 后提需求：「kan s + Tab → kan scan，多匹配按上下键选」。typer 原生支持这个但 typer 0.25 默认 `--install-completion` 在 uv tool 环境下 shellingham 检测失败（process tree 中间是 python wrapper）。manmankan 自己加 `kan completion install` 子命令绕过这个 bug + 加三层 fallback 检测让 mac/linux/windows 都可用。

### Internal

- `kan/cli.py:_VALID_SHELLS = ("zsh", "bash", "fish", "powershell", "pwsh")`
- `kan/cli.py:_detect_shell_fallback()`：1) shellingham · 2) `$SHELL` 路径 · 3) windows PSModulePath
- `kan/cli.py:completion_cmd()`：单 install 路径 · 调 `typer.completion.install(shell=shell, prog_name="kan")`

## [0.3.3.2] - 2026-05-10

> v0.3.3.1 实战体验反馈 patch · 砍掉 add 主循环 Progress（错误地方加了进度条）· 失败累积末尾整齐展示。

### Fixed

- **🔴 v0.3.3.1 进度条加错位置** · v0.3.3.1 给 `kan add ≥20 只` 加了 rich.Progress 进度条，但 add 主循环本身 < 1s（179 只仅 0.X 秒），进度条根本没动就到 100%。中间 ❌ 失败提示打断进度条显示更乱。用户 v0.3.3.1 实战截图：「⠋ 添加中 · 179 只 ━━━ 0% (0/179) 0:00:00 → ❌×10 → 添加中 · 最近: 游族网络 ━━━ 100% (179/179) 0:00:00」混乱不堪
- **失败列表打断输出** · 失败的 ❌ 提示原本散落在进度条中间 · 现在累积到末尾统一展示
- **加载阶段缺完成信号** · v0.3.3.1 spinner 转完悄悄结束 · 现在显示「✅ A 股代码表加载完成 · 用时 X.Xs」明确反馈

### Changed

- `kan add ≥20 只`：从 rich.Progress 进度条改为 `console.status` 单行 spinner（"正在添加 N 只股票..."）
- 失败列表累积到末尾打印 · 不打断 spinner / 加载提示
- 末尾汇总加耗时显示（≥ 0.5s 才显示）："添加完成 · 成功 N · 失败 M · 用时 X.Xs"

### Internal

- 新增 `_NoopContext` 类：`with` 接口对齐 `console.status` · 让小量场景跳过 spinner 一致代码路径
- 删除 cli.py L156-209 的 use_progress 分支（rich.Progress + advance 逻辑）
- 新增失败 buffer `failures: list[str]` 替代分散 typer.echo

### Why · 我又 audit 漏判

v0.3.3.1 isolated env 测了 25 只（无失败）· 没测**179 只 + 10 失败穿插**真实用户场景。**rich.Progress 在 < 1s 完成 + stderr 失败打断**两个组合 v0.3.3.1 没考虑到。再次违反 [audit-must-user-test](.) LOCKED「真实规模 + 错误路径」必跑条款。

## [0.3.3.1] - 2026-05-10

> v0.3.3 实战体验反馈 patch · 解决 `kan add` 大批量场景无进度反馈 + 数据源慢的体验灾难。

### Fixed

- **🔴 `kan add` 大批量场景丢失进度反馈** · v0.3.3 抑制了 akshare 内部 tqdm "n/16" 误导进度条但**没补正向进度反馈** · 用户首次添加 169 只时看到「正在加载 A 股代码表...」后 ~16s 静默 · 容易以为程序卡死
  - 加 rich.console.status spinner：缓存不存在/过期时显示 `⏳ 正在加载 A 股代码表 (首次约 5-15s · 后续 7 天内秒级)...`
  - 大批量（≥20 只）add 用 rich.Progress 进度条 · 显示 `添加中 · 最近: XXX X% (N/M) 0:00:XX` · 跟 `kan scan` 体验一致
  - 小量（< 20）保留原逐行 ✅ 输出（快不需要进度条）

### Changed

- **数据源切换 · A 股代码表加载速度提升 ~3 倍** · 从 akshare 切换到 baostock 主路径（实测用户当前网络）
  - akshare `stock_info_a_code_name`：实测 **15.99s** · 5513 只 A 股个股
  - baostock `query_stock_basic`：实测 **5.27s** · 8723 行（过滤 type=1 status=1 → 纯 A 股个股）
  - 已在 v0.3.3 依赖中（不增加包体积）
  - akshare 保留为 fallback：baostock 失败时自动兜底
  - baostock 服务也维护时给明确错误提示「无法获取 A 股代码表 · 请检查网络」

### Internal

- 新增 `kan/watchlist.py:_fetch_names_baostock`：baostock 主路径 + 字段过滤 + code 格式归一
- 新增 `kan/watchlist.py:_fetch_names_akshare`：akshare fallback 包装
- 新增 `kan/watchlist.py:is_stock_names_cache_fresh`：判断缓存是否新鲜（让 cli.py 决定是否显示 spinner）
- `kan/cli.py:add` 重构：use_progress 阈值 ≥20 只 · spinner 仅缓存不 fresh 时启用

### Why

v0.3.3 user-test 漏判：仅测了 4 只跨板块 add（happy path）· 没触发首次冷启动 + 大批量场景 · 用户 169 只真 watchlist 一跑暴露 ~16s 静默体验。这是 [audit-must-user-test](.) LOCKED 准则的「大数据量场景」执行不到位，违反 v0.3.4 期望文档 E1 已暴露问题但延期处理。本 hotfix 立即修，不等 v0.3.4。

## [0.3.3] - 2026-05-10

> 多源 K 线 fallback 体系 · 解决东财 push2his.eastmoney.com 对部分 IP 段持续封禁的实战痛点（akshare GitHub Issue #6092 / #6148 / #7011 / #6214）。

### Added

- **新数据源 baostock** (`_fetch_baostock`)：独立服务器、免熔断、字符串协议归一化精度对齐
- **新数据源 新浪** (`_fetch_sina` 走 `akshare.stock_zh_a_daily`)：免登录 / float64 直返 / akshare 官方推荐 fallback
- **新数据源 腾讯** (`_fetch_tencent` 走 `akshare.stock_zh_a_hist_tx`)：仅价格列可信
- **三源归一化一致性测试** `tests/test_normalize_alignment.py`：mock fixture 锁 fixture 同一交易日同一只股票 (600519 · 2026-05-08) 跨源数值对齐验证 · 共 10 条测试

### Changed

- **fallback 顺序重设计**：`baostock → 新浪 → 东财 → 腾讯`（旧顺序：`东财 → baostock → 腾讯`）
  - 用户场景下冷启动响应时间从 ~5.5s（先撞东财超时）降到 ~0.5s（直接命中 baostock）
  - 适应 akshare 上游 issue：东财 push2his 对部分 IP 段持续 ban，retry 4 次 5s 间隔实测无效
- **统一归一化出口** `_normalize_kline()`：所有数据源出口必经此函数 · schema 标准化 `[date, open, high, low, close, volume, amount]`
- **`kan add` 体验优化**：抑制 akshare 内部 tqdm（stderr 重定向）+ 批量 IO 优化（N 次 JSON 读写 → 1 读 1 写）+ 进度汇总
- **大 watchlist scan 体验** (复刻自 v0.3.1)：并发 5 + rich.Progress 进度条 + 友好网络错误提示

### Fixed

- **🔴 P0 G1 · 腾讯 amount 字段语义错误**：经实测（贵州茅台 5-08 三源对照），akshare `stock_zh_a_hist_tx` 返回的 "amount" 字段语义跨板块不一致：
  - 主板/创业板：实际是「成交手数」(= shares / 100)
  - 科创板（688/689）：实际是「成交股数」(1:1)
  - 修复策略：`_fetch_tencent` 内保守 `drop("amount")`，让 normalize 把 amount/volume 都填 NaN，下游 v0.4 成交量功能看到 NaN 跳过该股，比错值（误差 100 倍/13 万倍）安全
  - 防御：v0.4 成交量异动功能不再被错值污染缓存
- **腾讯源 docstring 更正**：原写"无 volume 只有 amount" → 改为"价格可信 量额不可信 · drop amount"

### Internal

- 新增 `_fetch_sina` 函数（位于源 2 与源 3 之间）
- `force_eastmoney_path` pytest fixture：旧测试通过 monkeypatch baostock/sina 返回 None 让流程走到东财 mock，保证 0 测试回归
- 测试覆盖：123 → **155**（+32 · multi-source 22 + alignment 10）
- 完整 ruff clean / 全部 mypy/ruff 门禁通过

### Architecture

- 5-10 session 架构师评审落档 `docs/roadmap.md`：渲染层抽象 / cli.py 暂不拆 / 拒绝过度工程
- 已知技术债（v0.3.4+ 修）：
  - TD-1 parquet 加 `_source` 列追溯数据来源
  - TD-2 熔断器 `circuit.json` 持久化（防进程重启丢状态）
  - TD-3 `kan doctor` 诊断命令（三源探测 + 系统代理检测 + cache 状态）

### Migration Guide

无破坏性变更。旧 parquet 缓存自动兼容（schema 已 forward-compatible · 缺列填 NaN）。

## [0.3.2] - 2026-05-09

> 加 `kan uninstall` 命令 · 解决用户卸载时不知道「清哪些数据 + 用哪个命令卸软件包」的痛点。

### Added

- **`kan uninstall` 命令** · 一次完成"清数据 + 看包卸载命令"
  - 默认: 列出 `~/.local/share/kan/` + `~/.kan/` 及大小 → 确认后删除
  - 自动检测安装方式 (uv tool / pipx / pip / venv) → 打印对应卸载指令
  - `--yes` / `-y` 跳过确认（脚本 / CI 用）
  - `--keep-data` 只输出包卸载命令 · 不删数据
- 新增 helper: `_detect_install_method` (基于 `sys.executable` 路径模式) + `_human_size` (字节转 KB/MB)
- 新增 9 个测试 `tests/test_uninstall_cli.py` (helper 单测 + uninstall 集成测)

### Changed

- README 命令速记加「卸载」段 · 含 `kan uninstall` 三种用法 + chicken-and-egg 说明

### Why

v0.3.1 用户卸载体验复盘：用户卸载时面临三个不知道:
1. 软件包通过哪个工具装的 (uv tool / pipx / pip · 命令各不同)
2. 数据存在哪 (XDG `~/.local/share/kan/` 还是 legacy `~/.kan/`)
3. 重装后旧数据是否会自动迁移

`kan uninstall` 一次解决 · 用户不再需要 `rm -rf ~/.kan` 加 `pip uninstall` 加 `which kan` 这种零碎动作。

## [0.3.1] - 2026-05-09

> v0.3.0 实战体验反馈 patch · 解决大 watchlist (≥ 30 只) 卡死体验灾难。

### Fixed

- **`kan scan` 大 watchlist 卡死体验** · v0.3.0 串行拉取 172 只可能阻塞 ≥ 9 分钟无反馈 · 用户以为程序挂了
  - 根因：`_auto_fetch_stale` 串行 + 每只 1-3s 网络等待 + 没有进度条
  - 修复：`fetch_batch` 改用 `ThreadPoolExecutor` 并发（默认 5 个）· 总时间降到 ~30-90s
  - 加 `rich.Progress` 进度条 · 实时显示进度 % + 已用时间 + 当前股票
- **网络异常 traceback 暴露内部 URL** · `kan scan` 失败时显示完整 `HTTPSConnectionPool(host='push2his.eastmoney.com', port=443)` + 查询参数
  - 修复：新增 `_network_error_msg` helper · 识别网络异常关键词后简化为「网络异常 · 请检查连接或稍后重试」
  - 识别 "无效股票代码或无数据" 错误为「无数据（可能停牌 / 退市）」
- **大量失败时输出淹没用户** · 修复：限制只显示前 5 只失败 + "及 N 只 · `kan fetch` 重试"

### Changed

- `fetch_batch(symbols)` 签名扩展（向后兼容默认值）：
  - 新增 `max_workers: int = 5` 控制并发数
  - 新增 `on_progress` 进度回调（`(symbol, ok, err_msg) -> None`）
- 大 watchlist (≥ 30 只) 时 scan 启动会先显示预计时间："需更新 N 只 · 并发 5 · 预计 X-Y 分钟"
- 删除 `kan/fetcher.py` 不再使用的 `import time`（之前用于 sleep 0.3s · 并发后无需）

### Internal

- `_auto_fetch_stale`: 从 typer.echo 串行打印改为 rich.Progress + ThreadPoolExecutor

## [0.3.0] - 2026-05-08

> v0.2 全功能体验 review 驱动 · 聚焦 80 列终端适配（P0 痛点）+ 自选股名称搜索 + 竞品学习。

### Added

- **`kan add` 支持名称搜索** · `kan add 茅台` 自动查找代码并添加
  - 精确匹配 1 只 → 直接添加
  - 多只匹配 → 展示候选前 10 只 + 提示用代码添加
- **`kan remove` 支持名称 + 批量** · `kan remove 茅台 五粮液` 一次删多只
- **`kan list` 显示总数** · 标题 "自选股列表 · 共 N 只"
- **终端宽度自适应** · scan 表根据终端宽度自动选择周期子集
  - 130+ 列：全部 10 周期 · 100 列：6 周期 · 90 列：5 周期 · 80 列：4 周期
  - 共振列在任何宽度下始终可见（v0.2 80 列下被完全截断）
  - 窄屏时底部提示 "显示 N/10 周期 · 加宽终端可见全部"
- **trend --latest 宽度自适应** · 日期列数量根据终端宽度自动调整
  - 80 列约 3 天 · 120 列约 7 天 · 列头和数值不再截断为 "…"
- **版本体验 review 机制** · `docs/reviews/` 存档 + 流程模板（每版本迭代前 AI 自动执行）
- 新增 15 项测试 · 93 → 108 项全绿（终端宽度 11 + 名称搜索 4）

### Changed

- **info 表移除空"状态"列** · 位置列 `[x%]` 颜色已传达触及信息 · 表格更紧凑
- **trend 范围校验中文化** · `--down 1` 从 typer 英文 "Invalid value" 改为中文 "❌ 值必须在 2-30 之间"
- **数据目录迁移到 XDG 规范** · `~/.kan/` → `~/.local/share/kan/`（`$XDG_DATA_HOME/kan/`）
  - 首次运行自动从旧路径迁移 · 旧目录留 `_MIGRATED.txt` 标记
  - 新增 `kan/paths.py` 集中管理所有路径
- **渲染逻辑拆分到 `kan/render.py`** · cli.py 803 → 752 行
  - 周期选择 / 百分比格式化 / 日期列数计算独立为 render 模块

### Fixed

- v0.2 P0-1: scan 表 80 列截断 · 共振列不可见 → 自适应周期选择
- v0.2 P0-2: trend --latest 列头截断 "现…" "连…" "累…" → 日期列数量自适应
- v0.2 P3-1: 数据目录 `~/.kan/` 不符合 XDG 规范 → 迁移到 `~/.local/share/kan/`
- v0.2 P3-2: cli.py 720 行未拆模块 → 渲染逻辑拆分到 render.py
- v0.2 P3-3: scan 标题日期被截断 → 表格宽度自适应后标题自然完整

### Migration Guide (v0.2 → v0.3)

**数据目录自动迁移**：v0.3 起数据目录从 `~/.kan/` 迁移到 `~/.local/share/kan/`（XDG Base Directory 规范）。首次运行 `kan` 时自动迁移，旧目录留 `_MIGRATED.txt` 标记，确认数据无误后可手动删除旧 `~/.kan/`。

**v0.2 移除项已稳定**：`--streak` / `kan scan -p N` 在 v0.2 已移除，v0.3 不再相关。详见 [v0.2 Migration Guide](#migration-guide-v01--v02)（如有）。

## [0.2.0] - 2026-05-08

> v0.1 早期使用反馈驱动迭代 · 聚焦 `kan trend` + `kan scan` 体验 + 排序逻辑重设计。

### Changed (BREAKING)

- **`kan --help` 走中文速记** · 与 `kan` / `kan help` 等价（v0.1 走 typer 默认英文混杂）
  - 反 UNIX 习惯 · 但早期用户基数小 + 慢慢看是 CN-only CLI · 一致性 > 习惯
  - 子命令 `--help` 不影响（如 `kan scan --help` 仍走 typer 默认）
  - v0.1 用户脚本/别名/muscle memory 中 `kan --help | grep ...` 输出会变
- **`kan scan -p / --period N` 选项已移除**（maintainer 拍板 · 站在用户角度判断 -p N 多余 · 与 `kan low/high N` 重叠）
  - 想看单周期触及极值 → `kan low N` / `kan high N`
  - 想看自选股全周期位置 → `kan scan`
- **`kan scan` 排序重设计 · 共振优先 + PERIODS 字典序 tie-break**
  - low：`-low_resonance` → 3 日 pct 升序 → 5 日 → ... → 180 日
  - high：`-high_resonance` → 3 日 pct 降序 → 5 日 → ... → 180 日
  - v0.1 行为：共振优先 → 任意周期 max/min（tie-break 不区分周期）
- **`kan trend` 排序加二级 tie-break · 同天数按累计幅度 abs 降序**
  - 5 天连跌 -15% 排在 5 天连跌 -3% 之前（同天数下幅度大的在前）
  - v0.1 行为：仅按天数 abs 排序 · 同天数顺序随机
- **`kan scan` 表格列宽修复（v0.1 真截断 bug）**
  - 周期列 `min_width` 5 → 6（容纳 [100%] 6 chars · 之前显示 [100…）
  - 现价/N日最低/N日最高/位置列加 `min_width=8`（容纳 4 位数股价 1371.05 + [100.0%] 8 chars）
  - 涉及 scan / low / high / info 共 4 命令
- `--streak` 选项移除（语义合并到 `--down N` / `--up N`）

### Added

- `kan trend --up N` 短写（与 `--down N` 对称）
- `kan help` 文案明确标注「以上参数可任意组合」+ 给出组合示例
- sys.argv 预处理逻辑（`kan.cli._normalize_streak_args`）· 让 `--down`/`--up` 不带值时注入默认 3 · 兼容 v0.1 调用方式
- 测试覆盖大幅提升：v0.1 baseline 46 → v0.2 87+ 项（trend CLI 19 + scan 列宽 8 + 排序逻辑 11）
  - `tests/test_trend_cli.py` · trend CLI 集成测试
  - `tests/test_scan_cli.py` · scan/low/high/info 列宽回归测试
  - `tests/test_sort_logic.py` · scan/trend 排序逻辑测试

### Migration Guide

| v0.1 写法 | v0.2 写法 |
|---|---|
| `kan trend` | `kan trend`（不变） |
| `kan trend --down` | `kan trend --down`（不变） |
| `kan trend --up` | `kan trend --up`（不变） |
| `kan trend --down --streak 5` | `kan trend --down 5` |
| `kan trend --up --streak 7` | `kan trend --up 7` |
| `kan scan -p 60` | `kan low 60` 或 `kan high 60`（视场景） |
| `kan scan --period 60` | 同上 |
| `kan --help` | 输出从 typer 默认变中文速记（与 `kan` / `kan help` 等价） |

### Internal

- entry_point 从 `kan.cli:app` 改为 `kan.cli:cli_main`（包了一层 sys.argv 预处理）
- `kan.scanner._period_pct_key` 新增 · 字典序排序辅助
- `kan.cli._normalize_help_args` 新增 · root-level `--help` 重定向到 `help` 子命令
- pytest: 46 → **93** 项（+47 · trend CLI 19 + scan 列宽 8 + 排序逻辑 11 + help 一致性 9）
- 代码质量门禁：__version__ 同步 · F811 重命名 · F821 import · B904 chaining (3) · B905 strict zip · JSON utf-8 (6)

[0.2.0]: https://github.com/piklen/manmankan/releases/tag/v0.2.0

## [0.1.0] - 2026-05-05

首次开源发布。

### Added

**位置扫描**
- `kan scan` 全景扫描自选股 10 周期位置（3/5/7/10/15/30/60/90/120/180 日）
- `kan scan --high` 高点模式
- `kan scan -S` / `--signal` 仅显示有共振信号的股票
- `kan scan --diff` 增量模式（与上次扫描对比）
- `kan scan -p N` 单周期模式
- `kan scan --exclude-st` 排除 ST/*ST 股票
- 多周期共振信号自动高亮（×N 标记）

**筛选模式**
- `kan low N [N2 N3...]` 筛选 N 日低点（支持多周期）
- `kan high N [N2 N3...]` 筛选 N 日高点
- 触及阈值：≤5% 低点 / ≥95% 高点

**连续涨跌看板**
- `kan trend` 连续涨跌天数 + 累计涨跌幅
- `kan trend --latest N` 展示近 N 天走势详情
- `kan trend --down` / `--up` 筛选连续涨/跌
- `kan trend --streak N` 自定义最少连续天数
- `kan trend --candle` 阳线阴线口径
- 涨跌停自动标记
- 平盘穿透不断连续（行业惯例）

**单只详情**
- `kan info <代码>` 单只股票全周期位置 + 涨跌 + 共振统计

**自选股管理**
- `kan add` / `kan remove` / `kan list` / `kan import` / `kan clear`
- 支持 6 位代码 / 带交易所前缀（sh600519 / sz000858）
- A 股代码-名称本地缓存（7 天有效期）

**数据层**
- AKShare 直调获取前复权日 K 线
- 本地 Parquet 缓存（`~/.kan/data/`）
- 数据过期自动更新（无感）
- `kan fetch [--force]` 手动刷新

**合规**
- 每次输出强制风险提示
- 关键词黑名单
- ST/*ST 涨跌停按 2026-07-06 政策日期切换（5% → 10%）
- 板块差异化涨跌停限制（主板/科创创业/北交所/ST）

[0.1.0]: https://github.com/piklen/manmankan/releases/tag/v0.1.0
