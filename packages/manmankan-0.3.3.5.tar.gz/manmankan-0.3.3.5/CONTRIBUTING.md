# 贡献指南

感谢你对慢慢看的兴趣！

## 开发环境

要求 Python 3.11+，推荐使用 [uv](https://docs.astral.sh/uv/)：

```bash
git clone https://github.com/piklen/manmankan.git
cd manmankan
uv sync
```

## 运行测试

```bash
uv run pytest
uv run pytest --cov=kan          # 带覆盖率
```

## 代码风格

- 使用 [ruff](https://docs.astral.sh/ruff/) 做 lint 和格式化：`uv run ruff check kan/`
- 类型注解：所有公开函数应有类型注解
- 命名：小写 + 下划线
- Pydantic v2 用于数据模型

## 合规红线（重要）

本项目严格定位为**行情数据展示工具**，PR 不应引入任何形式的：

- 买卖建议 / 评分评级 / 策略推荐
- 涨跌预测 / 目标价
- "建议关注 / 低估 / 见底 / 抄底"等暗示性词汇

详见 [`docs/compliance.md`](docs/compliance.md)。

## 提交流程

1. Fork 本仓库
2. 创建功能分支：`git checkout -b feat/your-feature`
3. 提交改动：`git commit -m "feat: ..."`
4. 推送到 fork：`git push origin feat/your-feature`
5. 在 GitHub 上发起 Pull Request

## Commit Message 规范

```
feat: 新功能
fix: 修复 bug
docs: 文档变更
refactor: 重构（不改变功能）
test: 测试相关
chore: 构建/依赖等杂项
```

## 报告问题

通过 [GitHub Issues](https://github.com/piklen/manmankan/issues) 报告 bug 或提出功能建议。

请提供：
- 复现步骤
- 期望行为 vs 实际行为
- Python 版本、操作系统
- 相关日志或截图
