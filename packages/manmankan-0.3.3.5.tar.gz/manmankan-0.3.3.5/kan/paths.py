"""路径管理 · XDG Base Directory 规范

v0.2 及以前：~/.kan/（污染 home 目录）
v0.3 起：$XDG_DATA_HOME/kan/（默认 ~/.local/share/kan/）
首次运行自动从旧路径迁移。
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

_LEGACY_DIR = Path.home() / ".kan"


def _get_base_dir() -> Path:
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "kan"
    return Path.home() / ".local" / "share" / "kan"


BASE_DIR = _get_base_dir()
DATA_DIR = BASE_DIR / "data"
WATCHLIST_PATH = BASE_DIR / "watchlist.json"
STOCK_NAMES_CACHE = BASE_DIR / "stock_names.json"
SNAPSHOT_PATH = BASE_DIR / "last_scan.json"
SNAPSHOTS_DIR = BASE_DIR / "snapshots"


def ensure_dirs() -> None:
    """确保数据目录存在。"""
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)


def migrate_legacy() -> None:
    """从 ~/.kan/ 自动迁移到 XDG 路径 · 仅首次运行时触发。"""
    if not _LEGACY_DIR.exists():
        return
    if WATCHLIST_PATH.exists():
        return

    ensure_dirs()
    for item in _LEGACY_DIR.iterdir():
        dest = BASE_DIR / item.name
        if item.is_dir():
            shutil.copytree(item, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(item, dest)

    readme = _LEGACY_DIR / "_MIGRATED.txt"
    readme.write_text(
        f"数据已迁移到 {BASE_DIR}\n"
        "此目录可安全删除。\n"
    )

    import typer
    # P1-9: migration message 走 stderr · 不污染 stdout
    # (kan --version 等 nullary 命令保持干净 · 脚本可 2>/dev/null 过滤)
    typer.echo(f"📦 数据已从 ~/.kan/ 迁移到 {BASE_DIR}", err=True)
    typer.echo("   旧目录可安全删除（rm -rf ~/.kan/）", err=True)
