"""Fetch arXiv paper HTML."""

from __future__ import annotations

import re
import time

import requests

# arXiv ID patterns
# New format: 2301.12345, 2301.12345v2
# Old format: hep-ph/0301012, cs.AI/0301012v1
_NEW_ID = re.compile(r"^(\d{4}\.\d{4,6})(v\d+)?$")
_OLD_ID = re.compile(r"^([a-z-]+(?:\.[A-Z]{2})?/\d{7})(v\d+)?$")
_URL_PATTERN = re.compile(
    r"https?://(?:www\.)?arxiv\.org/(?:abs|html|pdf)/(.+?)(?:\.pdf)?$"
)

ARXIV_HTML_BASE = "https://arxiv.org/html/"
ARXIV_ABS_BASE = "https://arxiv.org/abs/"

# Rate limiting
_last_request_time = 0.0
_MIN_INTERVAL = 1.0  # seconds between requests


class InvalidArxivID(Exception):
    """Raised when the input cannot be parsed as an arXiv ID."""
    pass


class PaperNotFound(Exception):
    """Raised when the paper does not exist on arXiv."""
    pass


class HTMLNotAvailable(Exception):
    """Raised when the arXiv HTML version is not available."""
    pass


def parse_arxiv_id(raw: str) -> str:
    """Parse various arXiv input formats into a canonical ID.

    Accepts:
        - 2301.12345
        - 2301.12345v2
        - hep-ph/0301012
        - https://arxiv.org/abs/2301.12345
        - https://arxiv.org/html/2301.12345v1
        - https://arxiv.org/pdf/2301.12345.pdf
    """
    raw = raw.strip()

    # Try URL first
    url_match = _URL_PATTERN.match(raw)
    if url_match:
        raw = url_match.group(1)

    # Try new format
    new_match = _NEW_ID.match(raw)
    if new_match:
        return raw  # keep version suffix if present

    # Try old format
    old_match = _OLD_ID.match(raw)
    if old_match:
        return raw

    raise InvalidArxivID(
        f"Invalid arXiv ID: '{raw}'. "
        "Expected formats: 2301.12345, 2301.12345v2, hep-ph/0301012, "
        "or https://arxiv.org/abs/2301.12345"
    )


def _rate_limit():
    """Enforce minimum interval between requests."""
    global _last_request_time
    now = time.monotonic()
    elapsed = now - _last_request_time
    if elapsed < _MIN_INTERVAL:
        time.sleep(_MIN_INTERVAL - elapsed)
    _last_request_time = time.monotonic()


class ArxivFetcher:
    """Fetches arXiv paper HTML."""

    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "paper-digest/0.1 (https://github.com/jingxuan/paper-digest)"
        })

    def parse_arxiv_id(self, raw: str) -> str:
        return parse_arxiv_id(raw)

    def fetch_html(self, arxiv_id: str) -> str:
        """Download the arXiv HTML page for a paper.

        Raises:
            PaperNotFound: if 404
            HTMLNotAvailable: if HTML version doesn't exist
            requests.Timeout: on network timeout
        """
        url = f"{ARXIV_HTML_BASE}{arxiv_id}"
        _rate_limit()

        try:
            resp = self.session.get(url, timeout=self.timeout)
        except requests.Timeout:
            raise requests.Timeout(
                f"Timeout fetching {url}. Use --retry or try again later."
            )

        if resp.status_code == 404:
            # Check if the paper exists at all
            _rate_limit()
            abs_resp = self.session.get(
                f"{ARXIV_ABS_BASE}{arxiv_id}", timeout=self.timeout
            )
            if abs_resp.status_code == 404:
                raise PaperNotFound(f"Paper {arxiv_id} not found on arXiv.")
            raise HTMLNotAvailable(
                f"HTML version not available for {arxiv_id}. "
                "This paper may predate arXiv HTML support (Dec 2023). "
                "LaTeX fallback coming in v1.1: pip install paper-digest[latex]"
            )

        if resp.status_code == 429:
            raise requests.ConnectionError(
                f"Rate limited by arXiv. Wait a moment and try again."
            )

        resp.raise_for_status()

        # Detect encoding
        resp.encoding = resp.apparent_encoding or "utf-8"
        return resp.text

    def fetch_metadata(self, arxiv_id: str) -> dict:
        """Fetch basic metadata from arXiv abs page."""
        url = f"{ARXIV_ABS_BASE}{arxiv_id}"
        _rate_limit()

        try:
            resp = self.session.get(url, timeout=self.timeout)
            resp.raise_for_status()
        except Exception:
            return {"title": "", "authors": [], "date": ""}

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "html.parser")

        title = ""
        title_el = soup.select_one("h1.title")
        if title_el:
            # Remove "Title:" prefix
            for span in title_el.select("span.descriptor"):
                span.decompose()
            title = title_el.get_text(strip=True)

        authors = []
        author_el = soup.select_one("div.authors")
        if author_el:
            for a in author_el.select("a"):
                authors.append(a.get_text(strip=True))
            if not authors:
                for span in author_el.select("span.descriptor"):
                    span.decompose()
                authors = [
                    a.strip()
                    for a in author_el.get_text().split(",")
                    if a.strip()
                ]

        date = ""
        date_el = soup.select_one("div.dateline")
        if date_el:
            date = date_el.get_text(strip=True)

        return {"title": title, "authors": authors, "date": date}
