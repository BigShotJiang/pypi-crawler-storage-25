"""Convert arXiv LaTeX source to Markdown.

Downloads the e-print tar.gz, finds the main .tex file,
and parses LaTeX directly — no pandoc dependency.

Key principle: math formulas are kept as-is (already LaTeX).
"""

from __future__ import annotations

import io
import os
import re
import tarfile
import gzip
from typing import Optional

import requests

from paper_digest.core.models import Paper, Section, classify_section
from paper_digest.core.fetcher import _rate_limit

EPRINT_URL = "https://arxiv.org/e-print/"


class LaTeXConversionError(Exception):
    pass


class LaTeXConverter:
    """Convert arXiv LaTeX source to a Paper object."""

    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "paper-digest/0.1 (https://github.com/jingxuan/paper-digest)"
        })

    def convert(self, arxiv_id: str) -> Paper:
        """Download LaTeX source and convert to Paper."""
        raw = self._download_source(arxiv_id)
        tex_content = self._extract_main_tex(raw)
        tex_content = self._expand_macros(tex_content)
        paper = self._parse_latex(tex_content, arxiv_id)
        return paper

    def _download_source(self, arxiv_id: str) -> bytes:
        """Download e-print source from arXiv."""
        url = f"{EPRINT_URL}{arxiv_id}"
        _rate_limit()

        resp = self.session.get(url, timeout=self.timeout)
        if resp.status_code == 404:
            raise LaTeXConversionError(f"No source available for {arxiv_id}")
        resp.raise_for_status()
        return resp.content

    def _extract_main_tex(self, raw: bytes) -> str:
        """Extract the main .tex file from the source archive.

        arXiv e-print can be:
        - A single .tex file (possibly gzipped)
        - A tar.gz with multiple files
        """
        # Try as tar.gz first
        try:
            with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tar:
                return self._find_main_in_tar(tar)
        except (tarfile.TarError, Exception):
            pass

        # Try as plain gzip (single file)
        try:
            content = gzip.decompress(raw)
            text = content.decode("utf-8", errors="replace")
            if "\\begin{document}" in text:
                return text
        except (gzip.BadGzipFile, Exception):
            pass

        # Try as plain text
        try:
            text = raw.decode("utf-8", errors="replace")
            if "\\begin{document}" in text:
                return text
        except Exception:
            pass

        raise LaTeXConversionError("Could not extract .tex file from source")

    def _find_main_in_tar(self, tar: tarfile.TarFile) -> str:
        """Find the main .tex file in a tar archive."""
        tex_files = {}
        for member in tar.getmembers():
            if member.name.endswith(".tex") and member.isfile():
                f = tar.extractfile(member)
                if f:
                    content = f.read().decode("utf-8", errors="replace")
                    tex_files[member.name] = content

        if not tex_files:
            raise LaTeXConversionError("No .tex files found in source archive")

        # Find the one with \begin{document}
        for name, content in tex_files.items():
            if "\\begin{document}" in content:
                # Resolve \input{} and \include{} references
                content = self._resolve_inputs(content, tex_files)
                return content

        # Fallback: return the largest .tex file
        largest = max(tex_files.items(), key=lambda x: len(x[1]))
        return largest[1]

    def _resolve_inputs(self, content: str, tex_files: dict) -> str:
        """Resolve \\input{} and \\include{} commands."""
        def replacer(match):
            filename = match.group(1)
            # Try with and without .tex extension
            candidates = [filename, f"{filename}.tex"]
            for candidate in candidates:
                # Try exact match and basename match
                for name, text in tex_files.items():
                    if name == candidate or os.path.basename(name) == candidate or name.endswith(f"/{candidate}"):
                        return text
            return match.group(0)  # keep original if not found

        content = re.sub(r"\\input\{([^}]+)\}", replacer, content)
        content = re.sub(r"\\include\{([^}]+)\}", replacer, content)
        return content

    def _expand_macros(self, tex: str) -> str:
        """Expand simple \\newcommand and \\def macros.

        Only handles simple cases:
        - \\newcommand{\\name}{replacement}
        - \\newcommand{\\name}[n]{replacement with #1, #2}
        - \\def\\name{replacement}
        """
        # Collect macro definitions
        macros = {}

        # \newcommand{\name}{replacement}
        for match in re.finditer(
            r"\\(?:newcommand|renewcommand)\{(\\[a-zA-Z]+)\}(?:\[(\d+)\])?\{",
            tex,
        ):
            cmd_name = match.group(1)
            n_args = int(match.group(2)) if match.group(2) else 0
            # Find the matching closing brace
            body = self._extract_braced(tex, match.end() - 1)
            if body is not None:
                macros[cmd_name] = (n_args, body)

        # \def\name{replacement} (no args only)
        for match in re.finditer(r"\\def(\\[a-zA-Z]+)\{", tex):
            cmd_name = match.group(1)
            body = self._extract_braced(tex, match.end() - 1)
            if body is not None and cmd_name not in macros:
                macros[cmd_name] = (0, body)

        # Apply expansions (simple cases only, max 3 passes for nested macros)
        for _ in range(3):
            changed = False
            for cmd_name, (n_args, body) in macros.items():
                if n_args == 0:
                    escaped = re.escape(cmd_name)
                    # Match \cmd followed by non-letter (word boundary)
                    pattern = escaped + r"(?![a-zA-Z])"
                    # Use lambda to avoid regex interpreting backslashes in body
                    new_tex = re.sub(pattern, lambda m: body, tex)
                    if new_tex != tex:
                        tex = new_tex
                        changed = True
                elif n_args <= 3:
                    # Match \cmd{arg1}{arg2}...
                    escaped = re.escape(cmd_name)
                    arg_pattern = r"\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}" * n_args
                    pattern = escaped + arg_pattern
                    def make_replacer(b, n):
                        def repl(m):
                            result = b
                            for i in range(n):
                                result = result.replace(f"#{i+1}", m.group(i + 1))
                            return result
                        return repl
                    new_tex = re.sub(pattern, make_replacer(body, n_args), tex)
                    if new_tex != tex:
                        tex = new_tex
                        changed = True
            if not changed:
                break

        return tex

    def _extract_braced(self, text: str, start: int) -> Optional[str]:
        """Extract content between matching braces starting at position start."""
        if start >= len(text) or text[start] != "{":
            return None
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    return text[start + 1 : i]
        return None

    def _parse_latex(self, tex: str, arxiv_id: str) -> Paper:
        """Parse LaTeX content into a Paper object."""
        paper = Paper(arxiv_id=arxiv_id)

        # Extract title
        title_match = re.search(r"\\title\{(.+?)\}", tex, re.DOTALL)
        if title_match:
            paper.title = self._clean_latex_text(title_match.group(1))

        # Extract authors
        author_match = re.search(r"\\author\{(.+?)\}", tex, re.DOTALL)
        if author_match:
            raw_authors = author_match.group(1)
            # Split by \and or \\
            authors = re.split(r"\\and|\\\\", raw_authors)
            paper.authors = [
                self._clean_latex_text(a).strip()
                for a in authors
                if self._clean_latex_text(a).strip()
            ]

        # Extract document body
        doc_match = re.search(
            r"\\begin\{document\}(.*?)\\end\{document\}", tex, re.DOTALL
        )
        if not doc_match:
            paper.warnings.append("no_document_environment")
            body = tex
        else:
            body = doc_match.group(1)

        # Extract abstract
        abs_match = re.search(
            r"\\begin\{abstract\}(.*?)\\end\{abstract\}", body, re.DOTALL
        )
        if abs_match:
            paper.sections.append(Section(
                tag="ABSTRACT",
                original_title="Abstract",
                content=self._latex_to_markdown(abs_match.group(1)).strip(),
            ))

        # Extract sections
        # Split by \section, \section*, keeping the command
        section_splits = re.split(
            r"(\\(?:section|subsection|subsubsection)\*?\{)", body
        )

        i = 1  # skip preamble before first section
        while i < len(section_splits) - 1:
            cmd = section_splits[i]
            rest = section_splits[i + 1]

            # Extract section title (find matching brace)
            brace_depth = 1
            title_end = 0
            for j, ch in enumerate(rest):
                if ch == "{":
                    brace_depth += 1
                elif ch == "}":
                    brace_depth -= 1
                    if brace_depth == 0:
                        title_end = j
                        break

            title = rest[:title_end]
            content = rest[title_end + 1:]

            # Determine heading level
            if "subsubsection" in cmd:
                level = 4
            elif "subsection" in cmd:
                level = 3
            else:
                level = 2

            title_clean = self._clean_latex_text(title)
            tag, display_title = classify_section(title_clean)

            md_content = self._latex_to_markdown(content).strip()

            if level == 2 and md_content:
                paper.sections.append(Section(
                    tag=tag,
                    original_title=display_title,
                    content=md_content,
                ))
            elif level > 2 and paper.sections:
                # Append subsections to the last section
                prefix = "#" * level
                paper.sections[-1].content += (
                    f"\n\n{prefix} {display_title}\n\n{md_content}"
                )

            i += 2

        # Extract bibliography
        bib_content = self._extract_bibliography(body)
        if bib_content:
            paper.sections.append(Section(
                tag="REFERENCES",
                original_title="References",
                content=bib_content,
            ))

        return paper

    def _latex_to_markdown(self, tex: str) -> str:
        """Convert LaTeX body text to Markdown, preserving math."""
        text = tex

        # Remove comments
        text = re.sub(r"(?<!\\)%.*$", "", text, flags=re.MULTILINE)

        # Preserve math environments as-is
        # Inline math $...$ — already fine in Markdown
        # Display math: convert \begin{equation} etc. to $$...$$
        for env in ["equation", "equation*", "align", "align*", "gather",
                     "gather*", "multline", "multline*", "eqnarray", "eqnarray*"]:
            text = re.sub(
                rf"\\begin\{{{env}\}}(.*?)\\end\{{{env}\}}",
                r"$$\1$$",
                text,
                flags=re.DOTALL,
            )

        # \[ ... \] → $$ ... $$
        text = re.sub(r"\\\[(.*?)\\\]", r"$$\1$$", text, flags=re.DOTALL)

        # Bold/italic
        text = re.sub(r"\\textbf\{([^}]+)\}", r"**\1**", text)
        text = re.sub(r"\\textit\{([^}]+)\}", r"*\1*", text)
        text = re.sub(r"\\emph\{([^}]+)\}", r"*\1*", text)
        text = re.sub(r"\\texttt\{([^}]+)\}", r"`\1`", text)

        # Lists
        text = re.sub(r"\\begin\{itemize\}", "", text)
        text = re.sub(r"\\end\{itemize\}", "", text)
        text = re.sub(r"\\begin\{enumerate\}", "", text)
        text = re.sub(r"\\end\{enumerate\}", "", text)
        text = re.sub(r"\\item\s*", "\n- ", text)

        # Tables → markdown pipe table
        text = self._convert_tables(text)

        # Figures: keep caption, drop includegraphics
        text = re.sub(r"\\includegraphics(?:\[[^\]]*\])?\{[^}]*\}", "", text)
        text = re.sub(
            r"\\caption\{([^}]+)\}",
            r"\n**[Figure]** \1\n",
            text,
        )
        text = re.sub(r"\\begin\{figure\*?\}(?:\[[^\]]*\])?", "", text)
        text = re.sub(r"\\end\{figure\*?\}", "", text)

        # Cross-references: keep as readable markers
        text = re.sub(r"\\ref\{([^}]+)\}", r"[ref:\1]", text)
        text = re.sub(r"\\eqref\{([^}]+)\}", r"[eq:\1]", text)
        text = re.sub(r"\\cite(?:\[[^\]]*\])?\{([^}]+)\}", r"[\1]", text)

        # Labels: remove
        text = re.sub(r"\\label\{[^}]+\}", "", text)

        # Footnotes
        text = re.sub(r"\\footnote\{([^}]+)\}", r" (\1)", text)

        # URLs
        text = re.sub(r"\\(?:url|href)\{([^}]+)\}", r"\1", text)

        # Remove remaining LaTeX commands that don't contribute content
        text = re.sub(r"\\(?:centering|noindent|vspace|hspace|smallskip|medskip|bigskip|newline|clearpage|pagebreak)\b(?:\{[^}]*\})?", "", text)
        text = re.sub(r"\\(?:begin|end)\{(?:center|minipage|figure\*?|table\*?|wrapfigure)\}(?:\{[^}]*\})*(?:\[[^\]]*\])*", "", text)

        # Clean up: remove \\ line breaks outside math
        # (but preserve them inside $$...$$)
        parts = re.split(r"(\$\$.*?\$\$)", text, flags=re.DOTALL)
        for i, part in enumerate(parts):
            if not part.startswith("$$"):
                parts[i] = part.replace("\\\\", "\n")
        text = "".join(parts)

        # Remove leftover braces from commands we stripped
        text = re.sub(r"(?<!\\)[{}]", "", text)

        # Clean whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r"[ \t]+", " ", text)
        lines = [line.strip() for line in text.split("\n")]
        text = "\n".join(lines)

        return text.strip()

    def _convert_tables(self, tex: str) -> str:
        """Convert LaTeX tabular environments to Markdown pipe tables."""
        def replace_table(match):
            inner = match.group(1)
            # Remove \hline, \toprule, \midrule, \bottomrule
            inner = re.sub(r"\\(?:hline|toprule|midrule|bottomrule|cline\{[^}]+\})", "", inner)
            # Split rows by \\
            rows = [r.strip() for r in re.split(r"\\\\", inner) if r.strip()]
            if not rows:
                return ""

            md_rows = []
            for row in rows:
                cells = [c.strip() for c in row.split("&")]
                # Clean cells
                cells = [self._clean_latex_text(c) for c in cells]
                md_rows.append("| " + " | ".join(cells) + " |")

            if len(md_rows) >= 1:
                # Add separator after first row (header)
                ncols = md_rows[0].count("|") - 1
                sep = "| " + " | ".join(["---"] * ncols) + " |"
                md_rows.insert(1, sep)

            return "\n".join(md_rows)

        tex = re.sub(
            r"\\begin\{tabular\}\{[^}]*\}(.*?)\\end\{tabular\}",
            replace_table,
            tex,
            flags=re.DOTALL,
        )
        return tex

    def _extract_bibliography(self, body: str) -> str:
        """Extract bibliography entries."""
        # Try \begin{thebibliography}
        bib_match = re.search(
            r"\\begin\{thebibliography\}.*?\n(.*?)\\end\{thebibliography\}",
            body,
            re.DOTALL,
        )
        if bib_match:
            entries = re.findall(r"\\bibitem(?:\[[^\]]*\])?\{[^}]*\}(.*?)(?=\\bibitem|$)",
                                 bib_match.group(1), re.DOTALL)
            refs = []
            for entry in entries:
                clean = self._clean_latex_text(entry).strip()
                if clean:
                    refs.append(f"- {clean}")
            return "\n".join(refs)

        return ""

    def _clean_latex_text(self, text: str) -> str:
        """Remove LaTeX commands from plain text (not math)."""
        text = re.sub(r"\\textbf\{([^}]+)\}", r"\1", text)
        text = re.sub(r"\\textit\{([^}]+)\}", r"\1", text)
        text = re.sub(r"\\emph\{([^}]+)\}", r"\1", text)
        text = re.sub(r"\\text\{([^}]+)\}", r"\1", text)
        text = re.sub(r"\\[a-zA-Z]+\{([^}]+)\}", r"\1", text)
        text = re.sub(r"[{}]", "", text)
        text = re.sub(r"~", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()
