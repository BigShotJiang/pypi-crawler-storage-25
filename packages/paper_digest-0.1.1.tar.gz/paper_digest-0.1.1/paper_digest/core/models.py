"""Data models for paper-digest."""

from __future__ import annotations

import json
from dataclasses import dataclass, field


# Standard section tags and their matching patterns (case-insensitive).
# Order matters for matching priority.
SECTION_MAP: dict[str, list[str]] = {
    "ABSTRACT": ["abstract"],
    "INTRODUCTION": ["introduction", "background", "motivation"],
    "RELATED_WORK": ["related work", "prior work", "literature review"],
    "METHOD": [
        "method", "methodology", "our approach", "proposed method",
        "model", "architecture", "framework", "model architecture",
        "approach", "proposed framework", "proposed architecture",
        "technical approach",
    ],
    "EXPERIMENTS": [
        "experiments", "experimental setup", "evaluation",
        "experimental results", "setup", "experimental settings",
        "implementation details", "implementation",
    ],
    "RESULTS": [
        "results", "main results", "analysis", "discussion",
        "findings", "discussion and analysis",
    ],
    "CONCLUSION": [
        "conclusion", "conclusions", "summary", "concluding remarks",
        "future work", "conclusion and future work",
        "conclusions and future work",
    ],
    "REFERENCES": ["references", "bibliography"],
    "APPENDIX": ["appendix", "supplementary", "supplementary material"],
}


def classify_section(title: str) -> tuple[str, str]:
    """Classify a section title into a standard tag.

    Returns (tag, cleaned_title). If no match, tag is "OTHER".
    """
    # Strip numbering: "3. Method" → "Method", "3.1 Our Approach" → "Our Approach"
    cleaned = title.strip()
    # Remove leading numbers and dots/spaces
    import re
    cleaned_for_match = re.sub(r"^[\d.]+\s*", "", cleaned).strip()
    # Remove trailing punctuation
    cleaned_for_match = cleaned_for_match.rstrip(".:;")

    lower = cleaned_for_match.lower()

    for tag, patterns in SECTION_MAP.items():
        for pattern in patterns:
            if lower == pattern or lower.startswith(pattern + ":") or lower.startswith(pattern + " "):
                return tag, cleaned
            # Exact match after stripping
            if lower == pattern:
                return tag, cleaned

    return "OTHER", cleaned


@dataclass
class Section:
    """A section of a paper."""
    tag: str  # e.g., "METHOD", "ABSTRACT", "OTHER"
    original_title: str  # e.g., "3.1 Our Proposed Approach"
    content: str  # Markdown content

    @property
    def heading(self) -> str:
        """Format as: ## [METHOD] 3.1 Our Proposed Approach"""
        if self.tag == "OTHER":
            return f"## [OTHER] {self.original_title}"
        return f"## [{self.tag}] {self.original_title}"


@dataclass
class Paper:
    """A parsed and optimized paper."""
    arxiv_id: str
    title: str = ""
    authors: list[str] = field(default_factory=list)
    date: str = ""
    sections: list[Section] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def section(self, tag: str) -> str | None:
        """Get content of a section by tag (case-insensitive)."""
        tag_upper = tag.upper()
        for s in self.sections:
            if s.tag == tag_upper:
                return s.content
        return None

    @property
    def section_tags(self) -> list[str]:
        return [s.tag for s in self.sections]

    @property
    def metadata(self) -> dict:
        return {
            "arxiv_id": self.arxiv_id,
            "title": self.title,
            "authors": self.authors,
            "date": self.date,
            "sections": self.section_tags,
        }

    @property
    def markdown(self) -> str:
        """Full AI-optimized Markdown output with YAML frontmatter."""
        lines = ["---"]
        lines.append(f'arxiv_id: "{self.arxiv_id}"')
        lines.append(f'title: "{self.title}"')
        lines.append(f"authors: {json.dumps(self.authors)}")
        lines.append(f'date: "{self.date}"')
        lines.append(f"sections: {json.dumps(self.section_tags)}")
        if self.warnings:
            lines.append(f"warnings: {json.dumps(self.warnings)}")
        lines.append("---")
        lines.append("")

        for section in self.sections:
            lines.append(section.heading)
            lines.append("")
            lines.append(section.content)
            lines.append("")

        return "\n".join(lines)

    def to_json(self) -> dict:
        """Structured JSON output."""
        return {
            **self.metadata,
            "warnings": self.warnings,
            "sections": [
                {"tag": s.tag, "title": s.original_title, "content": s.content}
                for s in self.sections
            ],
        }
