"""Convert arXiv HTML to Markdown.

Inspired by arxiv2md but optimized for AI consumption:
- Preserves LaTeX math as-is ($...$ and $$...$$)
- Preserves tables as Markdown pipe tables
- Extracts section structure with original titles
- Keeps figure captions, drops image data
"""

from __future__ import annotations

import re

from bs4 import BeautifulSoup, NavigableString, Tag

from paper_digest.core.models import Paper, Section, classify_section


class ConversionError(Exception):
    """Raised when HTML conversion fails."""
    pass


class HTMLConverter:
    """Converts arXiv HTML to a structured Paper object."""

    def convert(self, html: str, arxiv_id: str) -> Paper:
        """Convert arXiv HTML to a Paper with sections.

        Returns a Paper with raw section content (before optimization).
        """
        try:
            soup = BeautifulSoup(html, "html.parser")
        except Exception as e:
            raise ConversionError(f"Failed to parse HTML: {e}")

        paper = Paper(arxiv_id=arxiv_id)

        # Extract title
        title_el = soup.select_one("h1.ltx_title")
        if title_el:
            paper.title = self._clean_text(title_el.get_text())

        # Extract authors
        author_els = soup.select("span.ltx_personname")
        if author_els:
            authors = []
            for a in author_els:
                name = self._clean_text(a.get_text())
                # Clean up: take only the name part before affiliations/emails
                # Many arXiv HTMLs have "Name Affiliation email" in one span
                if name and len(name) < 100:  # reasonable name length
                    authors.append(name)
            paper.authors = authors if authors else [self._clean_text(el.get_text()) for el in author_els[:1]]
        else:
            # Try alternative author markup
            author_div = soup.select_one("div.ltx_authors")
            if author_div:
                paper.authors = [self._clean_text(author_div.get_text())]

        # Extract date
        date_el = soup.select_one("span.ltx_date") or soup.select_one("div.ltx_dates")
        if date_el:
            paper.date = self._clean_text(date_el.get_text())

        # Extract abstract
        abstract_el = soup.select_one("div.ltx_abstract")
        if abstract_el:
            abstract_text = self._element_to_markdown(abstract_el)
            # Remove "Abstract" heading if present
            abstract_text = re.sub(r"^#+\s*Abstract\s*\n*", "", abstract_text, flags=re.IGNORECASE)
            paper.sections.append(Section(
                tag="ABSTRACT",
                original_title="Abstract",
                content=abstract_text.strip(),
            ))

        # Extract sections
        # arXiv HTML uses <section class="ltx_section"> with <h2> headings
        for section_el in soup.select("section.ltx_section, section.ltx_appendix"):
            heading_el = section_el.find(re.compile(r"^h[2-6]$"))
            if not heading_el:
                continue

            title = self._clean_text(heading_el.get_text())
            if not title:
                continue

            tag, cleaned_title = classify_section(title)

            # Convert section content to markdown (skip the heading itself)
            content_parts = []
            for child in section_el.children:
                if child == heading_el:
                    continue
                if isinstance(child, Tag):
                    # Handle subsections
                    if child.name == "section":
                        sub_md = self._section_to_markdown(child)
                        if sub_md:
                            content_parts.append(sub_md)
                    else:
                        md = self._element_to_markdown(child)
                        if md:
                            content_parts.append(md)

            content = "\n\n".join(content_parts)
            if content.strip():
                paper.sections.append(Section(
                    tag=tag,
                    original_title=cleaned_title,
                    content=content.strip(),
                ))

        # Extract bibliography/references
        bib_el = soup.select_one("section.ltx_bibliography")
        if bib_el:
            refs = self._extract_references(bib_el)
            if refs:
                paper.sections.append(Section(
                    tag="REFERENCES",
                    original_title="References",
                    content=refs,
                ))

        if not paper.sections:
            # Fallback: treat the entire body as one section
            body = soup.select_one("div.ltx_page_content") or soup.body
            if body:
                content = self._element_to_markdown(body)
                if content.strip():
                    paper.sections.append(Section(
                        tag="OTHER",
                        original_title="Full Text",
                        content=content.strip(),
                    ))
                    paper.warnings.append("no_sections_detected")

        return paper

    def _section_to_markdown(self, section_el: Tag) -> str:
        """Convert a subsection to markdown with heading."""
        heading_el = section_el.find(re.compile(r"^h[2-6]$"))
        parts = []

        if heading_el:
            level = int(heading_el.name[1])
            title = self._clean_text(heading_el.get_text())
            parts.append(f"{'#' * level} {title}")

        for child in section_el.children:
            if child == heading_el:
                continue
            if isinstance(child, Tag):
                if child.name == "section":
                    sub_md = self._section_to_markdown(child)
                    if sub_md:
                        parts.append(sub_md)
                else:
                    md = self._element_to_markdown(child)
                    if md:
                        parts.append(md)

        return "\n\n".join(parts)

    def _element_to_markdown(self, el: Tag) -> str:
        """Convert an HTML element to Markdown."""
        if isinstance(el, NavigableString):
            return str(el).strip()

        tag = el.name if isinstance(el, Tag) else ""

        # Math: preserve LaTeX as-is
        if "ltx_Math" in el.get("class", []) or "ltx_equation" in el.get("class", []):
            return self._extract_math(el)

        # Tables
        if tag == "table" or "ltx_tabular" in el.get("class", []):
            return self._table_to_markdown(el)

        # Figures: keep caption, drop image
        if "ltx_figure" in el.get("class", []) or "ltx_float" in el.get("class", []):
            return self._figure_to_markdown(el)

        # Lists
        if tag == "ul":
            items = []
            for li in el.find_all("li", recursive=False):
                items.append(f"- {self._element_to_markdown(li)}")
            return "\n".join(items)
        if tag == "ol":
            items = []
            for i, li in enumerate(el.find_all("li", recursive=False), 1):
                items.append(f"{i}. {self._element_to_markdown(li)}")
            return "\n".join(items)

        # Paragraphs
        if tag == "p" or "ltx_para" in el.get("class", []):
            return self._inline_to_markdown(el)

        # Block quotes / theorems
        if "ltx_theorem" in " ".join(el.get("class", [])):
            title_el = el.select_one("span.ltx_title")
            title = self._clean_text(title_el.get_text()) if title_el else "Theorem"
            content = self._inline_to_markdown(el)
            return f"**{title}:** {content}"

        # Algorithm / code blocks
        if "ltx_listing" in el.get("class", []):
            code = el.get_text()
            return f"```\n{code}\n```"

        # Generic: recurse
        parts = []
        for child in el.children:
            if isinstance(child, NavigableString):
                text = str(child).strip()
                if text:
                    parts.append(text)
            elif isinstance(child, Tag):
                md = self._element_to_markdown(child)
                if md:
                    parts.append(md)
        return " ".join(parts)

    def _inline_to_markdown(self, el: Tag) -> str:
        """Convert inline content preserving math and formatting."""
        parts = []
        for child in el.children:
            if isinstance(child, NavigableString):
                parts.append(str(child))
            elif isinstance(child, Tag):
                classes = child.get("class", [])
                if "ltx_Math" in classes or "ltx_equation" in classes:
                    parts.append(self._extract_math(child))
                elif child.name in ("b", "strong") or "ltx_font_bold" in classes:
                    parts.append(f"**{child.get_text()}**")
                elif child.name in ("i", "em") or "ltx_font_italic" in classes:
                    parts.append(f"*{child.get_text()}*")
                elif child.name == "code" or "ltx_font_typewriter" in classes:
                    parts.append(f"`{child.get_text()}`")
                elif child.name == "a":
                    href = child.get("href", "")
                    text = child.get_text()
                    if href and not href.startswith("#"):
                        parts.append(f"[{text}]({href})")
                    else:
                        parts.append(text)
                elif child.name == "cite" or "ltx_cite" in classes:
                    parts.append(child.get_text())
                elif child.name == "sup":
                    parts.append(f"^{child.get_text()}")
                elif child.name == "sub":
                    parts.append(f"_{child.get_text()}")
                else:
                    parts.append(self._inline_to_markdown(child))

        text = "".join(parts)
        # Clean up whitespace
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _extract_math(self, el: Tag) -> str:
        """Extract math content, preserving LaTeX notation."""
        # Try to find the alttext attribute (LaTeX source)
        math_el = el.find("math")
        if math_el:
            alt = math_el.get("alttext", "")
            if alt:
                # Determine inline vs display
                display = math_el.get("display", "") == "block"
                if display or "ltx_equation" in el.get("class", []):
                    return f"$${alt}$$"
                return f"${alt}$"

        # Fallback: look for annotation with LaTeX
        annotation = el.find("annotation", encoding="application/x-tex")
        if annotation:
            latex = annotation.get_text().strip()
            if "ltx_equation" in el.get("class", []):
                return f"$${latex}$$"
            return f"${latex}$"

        # Last resort: just get text
        text = el.get_text().strip()
        if text:
            return f"${text}$"
        return ""

    def _table_to_markdown(self, el: Tag) -> str:
        """Convert HTML table to Markdown pipe table."""
        rows = []
        for tr in el.find_all("tr"):
            cells = []
            for td in tr.find_all(["td", "th"]):
                cell_text = self._inline_to_markdown(td)
                cell_text = cell_text.replace("|", "\\|")  # escape pipes
                cells.append(cell_text)
            if cells:
                rows.append(cells)

        if not rows:
            return ""

        # Normalize column count
        max_cols = max(len(r) for r in rows)
        for r in rows:
            while len(r) < max_cols:
                r.append("")

        lines = []
        # Header row
        lines.append("| " + " | ".join(rows[0]) + " |")
        lines.append("| " + " | ".join(["---"] * max_cols) + " |")
        # Data rows
        for row in rows[1:]:
            lines.append("| " + " | ".join(row) + " |")

        return "\n".join(lines)

    def _figure_to_markdown(self, el: Tag) -> str:
        """Extract figure caption, drop image data."""
        caption_el = el.select_one("figcaption, .ltx_caption")
        if caption_el:
            caption = self._inline_to_markdown(caption_el)
            return f"**[Figure]** {caption}"
        return ""

    def _extract_references(self, bib_el: Tag) -> str:
        """Extract references as a list."""
        refs = []
        for item in bib_el.select("li.ltx_bibitem"):
            ref_text = self._inline_to_markdown(item)
            ref_text = re.sub(r"^\s*\d+\s*", "", ref_text)  # remove leading number
            if ref_text.strip():
                refs.append(f"- {ref_text.strip()}")
        return "\n".join(refs)

    def _clean_text(self, text: str) -> str:
        """Clean up whitespace in text."""
        text = re.sub(r"\s+", " ", text)
        return text.strip()
