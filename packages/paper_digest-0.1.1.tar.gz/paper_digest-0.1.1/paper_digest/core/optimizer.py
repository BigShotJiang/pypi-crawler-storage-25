"""Optimize paper content for AI consumption."""

from __future__ import annotations

import re

from paper_digest.core.models import Paper, Section


# Content to remove (noise, not facts)
_ACKNOWLEDGEMENT_PATTERNS = [
    r"acknowledgements?",
    r"acknowledgments?",
    r"funding",
    r"author contributions?",
]

# arXiv watermark pattern
_ARXIV_WATERMARK = re.compile(
    r"arXiv:\s*\d{4}\.\d{4,5}(?:v\d+)?\s*\[[\w.-]+\]\s*\d+\s*\w+\s*\d{4}",
    re.IGNORECASE,
)


class PaperOptimizer:
    """Optimize paper content for AI consumption.

    Default behavior (raw=False):
    - Remove acknowledgements (noise)
    - Remove arXiv watermarks (noise)
    - Exclude appendix by default
    - Compress consecutive blank lines
    - Keep everything else intact (references, formulas, tables)
    """

    def optimize(
        self,
        paper: Paper,
        *,
        sections: list[str] | None = None,
        raw: bool = False,
    ) -> Paper:
        """Optimize a paper's content.

        Args:
            paper: The parsed paper.
            sections: If set, only include sections with these tags.
            raw: If True, skip all content trimming.
        """
        if not raw:
            paper = self._trim_content(paper)

        if sections:
            paper = self._filter_sections(paper, sections)

        # Clean up all section content
        for section in paper.sections:
            section.content = self._clean_content(section.content)

        return paper

    def _trim_content(self, paper: Paper) -> Paper:
        """Remove noise content."""
        filtered = []
        for section in paper.sections:
            # Skip acknowledgements
            if self._is_acknowledgement(section):
                continue
            # Skip appendix by default
            if section.tag == "APPENDIX":
                continue
            # Remove arXiv watermarks from content
            section.content = _ARXIV_WATERMARK.sub("", section.content)
            filtered.append(section)

        paper.sections = filtered
        return paper

    def _filter_sections(self, paper: Paper, tags: list[str]) -> Paper:
        """Keep only sections matching the requested tags."""
        tags_upper = {t.upper() for t in tags}
        matched = [s for s in paper.sections if s.tag in tags_upper]

        if not matched:
            requested = ", ".join(tags)
            available = ", ".join(s.tag for s in paper.sections)
            paper.warnings.append(
                f"No sections matched requested tags [{requested}]. "
                f"Available: [{available}]"
            )
            return paper

        paper.sections = matched
        return paper

    def _is_acknowledgement(self, section: Section) -> bool:
        """Check if a section is an acknowledgement."""
        title_lower = section.original_title.lower()
        for pattern in _ACKNOWLEDGEMENT_PATTERNS:
            if re.search(pattern, title_lower):
                return True
        return False

    def _clean_content(self, content: str) -> str:
        """Clean up content whitespace."""
        # Compress 3+ consecutive newlines to 2
        content = re.sub(r"\n{3,}", "\n\n", content)
        # Remove trailing whitespace on each line
        lines = [line.rstrip() for line in content.split("\n")]
        return "\n".join(lines).strip()
