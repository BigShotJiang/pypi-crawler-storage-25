"""Command-line interface for paper-digest."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from tqdm import tqdm

from paper_digest import PaperDigest
from paper_digest.core.fetcher import (
    HTMLNotAvailable,
    InvalidArxivID,
    PaperNotFound,
)


@click.command()
@click.argument("arxiv_id", required=False)
@click.option("--batch", type=click.Path(exists=True), help="File with one arXiv ID per line.")
@click.option("--sections", type=str, default=None, help="Comma-separated section tags to include (e.g., abstract,method,results).")
@click.option("--raw", is_flag=True, help="Skip content trimming, output full text.")
@click.option("--format", "fmt", type=click.Choice(["markdown", "json"]), default="markdown", help="Output format.")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file or directory (for batch).")
@click.option("--include-appendix", is_flag=True, help="Include appendix sections.")
@click.option("--prefer-html", is_flag=True, help="Try HTML path first (faster but math may have artifacts).")
@click.option("--retry", type=int, default=0, help="Number of retries on network failure.")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed progress.")
def main(arxiv_id, batch, sections, raw, fmt, output, include_appendix, prefer_html, retry, verbose):
    """Convert arXiv papers to AI-optimized Markdown.

    Examples:

        paper-digest 2301.12345

        paper-digest 2301.12345 --sections abstract,method

        paper-digest --batch ids.txt --output ./papers/
    """
    if not arxiv_id and not batch:
        click.echo("Error: provide an arXiv ID or --batch file.", err=True)
        raise SystemExit(1)

    section_list = [s.strip() for s in sections.split(",")] if sections else None
    pd = PaperDigest(prefer_html=prefer_html)

    if batch:
        _batch_mode(pd, batch, section_list, raw, fmt, output, include_appendix, retry, verbose)
    else:
        _single_mode(pd, arxiv_id, section_list, raw, fmt, output, include_appendix, retry, verbose)


def _single_mode(pd, arxiv_id, sections, raw, fmt, output, include_appendix, retry, verbose):
    """Process a single paper."""
    attempts = 1 + retry
    last_error = None

    for attempt in range(attempts):
        try:
            paper = pd.fetch(arxiv_id, sections=sections, raw=raw or include_appendix)
            break
        except (InvalidArxivID, PaperNotFound, HTMLNotAvailable) as e:
            # These won't be fixed by retrying
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)
        except Exception as e:
            last_error = e
            if verbose and attempt < attempts - 1:
                click.echo(f"Attempt {attempt + 1} failed: {e}. Retrying...", err=True)
    else:
        click.echo(f"Error after {attempts} attempts: {last_error}", err=True)
        raise SystemExit(1)

    _output_paper(paper, fmt, output)


def _batch_mode(pd, batch_file, sections, raw, fmt, output_dir, include_appendix, retry, verbose):
    """Process multiple papers from a file."""
    ids = Path(batch_file).read_text().strip().splitlines()
    ids = [line.strip() for line in ids if line.strip() and not line.startswith("#")]

    if not ids:
        click.echo("Error: batch file is empty.", err=True)
        raise SystemExit(1)

    if output_dir:
        Path(output_dir).mkdir(parents=True, exist_ok=True)

    succeeded = 0
    failed = []

    for arxiv_input in tqdm(ids, desc="Processing papers", disable=not sys.stderr.isatty()):
        try:
            paper = pd.fetch(arxiv_input, sections=sections, raw=raw or include_appendix)
            if output_dir:
                ext = ".json" if fmt == "json" else ".md"
                safe_id = paper.arxiv_id.replace("/", "_")
                out_path = Path(output_dir) / f"{safe_id}{ext}"
                _output_paper(paper, fmt, str(out_path))
            else:
                _output_paper(paper, fmt, None)
                click.echo("---", err=False)  # separator
            succeeded += 1
        except Exception as e:
            failed.append((arxiv_input, str(e)))
            if verbose:
                click.echo(f"  Failed: {arxiv_input}: {e}", err=True)

    # Summary
    click.echo(f"\n{succeeded}/{len(ids)} succeeded.", err=True)
    if failed:
        click.echo(f"{len(failed)} failed:", err=True)
        for fid, reason in failed:
            click.echo(f"  - {fid}: {reason}", err=True)
        raise SystemExit(1)


def _output_paper(paper, fmt, output_path):
    """Write paper to stdout or file."""
    if fmt == "json":
        content = json.dumps(paper.to_json(), ensure_ascii=False, indent=2)
    else:
        content = paper.markdown

    if output_path:
        Path(output_path).write_text(content, encoding="utf-8")
    else:
        click.echo(content)
