"""paper-digest: AI-optimized arXiv paper reader."""

from __future__ import annotations

from typing import Optional, Union, List

from paper_digest.core.models import Paper, Section
from paper_digest.core.fetcher import ArxivFetcher, HTMLNotAvailable
from paper_digest.core.converter import HTMLConverter
from paper_digest.core.latex_converter import LaTeXConverter
from paper_digest.core.optimizer import PaperOptimizer

__version__ = "0.1.0"


class PaperDigest:
    """Main entry point for converting arXiv papers to AI-optimized Markdown.

    Default: LaTeX first (perfect math), HTML fallback (faster but math may have artifacts).
    Switch with prefer_html=True or CLI --prefer-html.
    """

    def __init__(self, prefer_html: bool = False):
        self.prefer_html = prefer_html
        self.fetcher = ArxivFetcher()
        self.html_converter = HTMLConverter()
        self.latex_converter = LaTeXConverter()
        self.optimizer = PaperOptimizer()

    def fetch(self, arxiv_input: str, *, sections: Optional[list] = None, raw: bool = False) -> Paper:
        """Fetch and convert an arXiv paper to AI-optimized Markdown.

        Args:
            arxiv_input: arXiv ID (2301.12345, hep-ph/0301012, 2301.12345v2) or full URL.
            sections: Only include these sections (e.g., ["abstract", "method"]).
            raw: If True, skip content trimming (keep acknowledgements, etc.).
        """
        arxiv_id = self.fetcher.parse_arxiv_id(arxiv_input)

        paper = self._convert_with_fallback(arxiv_id)
        paper = self.optimizer.optimize(paper, sections=sections, raw=raw)
        return paper

    def _convert_with_fallback(self, arxiv_id: str) -> Paper:
        """Convert with automatic fallback between paths."""
        if self.prefer_html:
            return self._try_html_then_latex(arxiv_id)
        else:
            return self._try_latex_then_html(arxiv_id)

    def _try_latex_then_html(self, arxiv_id: str) -> Paper:
        """Default: LaTeX first (perfect math), HTML fallback."""
        try:
            paper = self.latex_converter.convert(arxiv_id)
            paper.warnings.append("source:latex")
            return paper
        except Exception:
            pass

        try:
            html = self.fetcher.fetch_html(arxiv_id)
            paper = self.html_converter.convert(html, arxiv_id)
            paper.warnings.append("source:html")
            return paper
        except Exception as e:
            raise RuntimeError(
                f"Could not convert paper {arxiv_id}. "
                f"Both LaTeX and HTML paths failed: {e}"
            ) from e

    def _try_html_then_latex(self, arxiv_id: str) -> Paper:
        """Alternative: HTML first (faster), LaTeX fallback."""
        try:
            html = self.fetcher.fetch_html(arxiv_id)
            paper = self.html_converter.convert(html, arxiv_id)
            paper.warnings.append("source:html")
            return paper
        except HTMLNotAvailable:
            pass

        try:
            paper = self.latex_converter.convert(arxiv_id)
            paper.warnings.append("source:latex")
            return paper
        except Exception as e:
            raise RuntimeError(
                f"Could not convert paper {arxiv_id}. "
                f"HTML not available, LaTeX conversion failed: {e}"
            ) from e

    def fetch_batch(self, arxiv_inputs: list, **kwargs) -> list:
        """Fetch multiple papers. Returns Paper on success, Exception on failure."""
        results = []
        for inp in arxiv_inputs:
            try:
                results.append(self.fetch(inp, **kwargs))
            except Exception as e:
                results.append(e)
        return results
