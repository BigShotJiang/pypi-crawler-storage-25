"""Tests for paper_digest.core.converter."""

from paper_digest.core.converter import HTMLConverter


def _make_arxiv_html(body_content: str, title: str = "Test Paper") -> str:
    """Create a minimal arXiv-like HTML document."""
    return f"""
    <html>
    <body>
    <h1 class="ltx_title">{title}</h1>
    <div class="ltx_authors">
        <span class="ltx_personname">Alice</span>
        <span class="ltx_personname">Bob</span>
    </div>
    <div class="ltx_abstract">
        <h2>Abstract</h2>
        <p>This is the abstract.</p>
    </div>
    {body_content}
    </body>
    </html>
    """


class TestHTMLConverter:
    def setup_method(self):
        self.converter = HTMLConverter()

    def test_basic_conversion(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>1 Introduction</h2>
            <p>This is the introduction.</p>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        assert paper.arxiv_id == "2301.12345"
        assert paper.title == "Test Paper"
        assert len(paper.authors) == 2
        assert any(s.tag == "ABSTRACT" for s in paper.sections)
        assert any(s.tag == "INTRODUCTION" for s in paper.sections)

    def test_extracts_abstract(self):
        html = _make_arxiv_html("")
        paper = self.converter.convert(html, "2301.12345")
        abstract = paper.section("abstract")
        assert abstract is not None
        assert "abstract" in abstract.lower()

    def test_section_classification(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>3 Method</h2>
            <p>Our method works like this.</p>
        </section>
        <section class="ltx_section">
            <h2>4 Experiments</h2>
            <p>We ran experiments.</p>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        tags = [s.tag for s in paper.sections]
        assert "METHOD" in tags
        assert "EXPERIMENTS" in tags

    def test_preserves_original_title(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>3.1 Our Proposed Approach</h2>
            <p>Content here.</p>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        # Find the section (may be OTHER or METHOD depending on matching)
        non_abstract = [s for s in paper.sections if s.tag != "ABSTRACT"]
        assert len(non_abstract) >= 1
        assert "3.1 Our Proposed Approach" in non_abstract[0].original_title

    def test_math_preservation(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>2 Method</h2>
            <p>The loss is <span class="ltx_Math"><math alttext="\\mathcal{L} = \\sum_i \\ell_i"><mi>L</mi></math></span>.</p>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        method = paper.section("method")
        assert method is not None
        assert "$" in method  # math is wrapped in $

    def test_table_conversion(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>4 Results</h2>
            <table class="ltx_tabular">
                <tr><th>Method</th><th>Acc</th></tr>
                <tr><td>Ours</td><td>95.2</td></tr>
                <tr><td>BERT</td><td>91.3</td></tr>
            </table>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        results = paper.section("results")
        assert results is not None
        assert "95.2" in results
        assert "|" in results  # pipe table format

    def test_figure_caption_preserved(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>3 Method</h2>
            <figure class="ltx_figure">
                <img src="fig1.png" />
                <figcaption>Figure 1: Our architecture overview.</figcaption>
            </figure>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        method = paper.section("method")
        assert method is not None
        assert "architecture overview" in method.lower()

    def test_empty_html(self):
        paper = self.converter.convert("<html><body></body></html>", "2301.12345")
        assert paper.arxiv_id == "2301.12345"
        # Should either have no sections or a warning
        assert len(paper.sections) == 0 or "no_sections_detected" in paper.warnings

    def test_references_extracted(self):
        html = _make_arxiv_html("""
        <section class="ltx_bibliography">
            <h2>References</h2>
            <ul>
                <li class="ltx_bibitem">Vaswani et al. Attention Is All You Need. 2017.</li>
                <li class="ltx_bibitem">Devlin et al. BERT. 2019.</li>
            </ul>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        refs = paper.section("references")
        assert refs is not None
        assert "Vaswani" in refs
        assert "BERT" in refs

    def test_subsections_preserved(self):
        html = _make_arxiv_html("""
        <section class="ltx_section">
            <h2>3 Method</h2>
            <p>Overview of our method.</p>
            <section class="ltx_subsection">
                <h3>3.1 Model Architecture</h3>
                <p>The model uses transformers.</p>
            </section>
            <section class="ltx_subsection">
                <h3>3.2 Training</h3>
                <p>We train for 100 epochs.</p>
            </section>
        </section>
        """)
        paper = self.converter.convert(html, "2301.12345")
        method = paper.section("method")
        assert method is not None
        assert "transformers" in method
        assert "100 epochs" in method
