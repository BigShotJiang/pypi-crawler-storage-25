"""Tests for paper_digest.core.fetcher."""

import pytest

from paper_digest.core.fetcher import InvalidArxivID, parse_arxiv_id


class TestParseArxivId:
    def test_new_format(self):
        assert parse_arxiv_id("2301.12345") == "2301.12345"

    def test_new_format_5_digits(self):
        assert parse_arxiv_id("2301.123456") == "2301.123456"

    def test_new_format_with_version(self):
        assert parse_arxiv_id("2301.12345v2") == "2301.12345v2"

    def test_old_format(self):
        assert parse_arxiv_id("hep-ph/0301012") == "hep-ph/0301012"

    def test_old_format_with_version(self):
        assert parse_arxiv_id("cs.AI/0301012v1") == "cs.AI/0301012v1"

    def test_abs_url(self):
        assert parse_arxiv_id("https://arxiv.org/abs/2301.12345") == "2301.12345"

    def test_html_url(self):
        assert parse_arxiv_id("https://arxiv.org/html/2301.12345v1") == "2301.12345v1"

    def test_pdf_url(self):
        assert parse_arxiv_id("https://arxiv.org/pdf/2301.12345.pdf") == "2301.12345"

    def test_with_whitespace(self):
        assert parse_arxiv_id("  2301.12345  ") == "2301.12345"

    def test_invalid_garbage(self):
        with pytest.raises(InvalidArxivID):
            parse_arxiv_id("not-an-id")

    def test_invalid_empty(self):
        with pytest.raises(InvalidArxivID):
            parse_arxiv_id("")

    def test_invalid_partial(self):
        with pytest.raises(InvalidArxivID):
            parse_arxiv_id("2301")

    def test_www_url(self):
        assert parse_arxiv_id("https://www.arxiv.org/abs/2301.12345") == "2301.12345"
