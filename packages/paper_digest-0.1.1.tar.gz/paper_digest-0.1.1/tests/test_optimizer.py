"""Tests for paper_digest.core.optimizer."""

from paper_digest.core.models import Paper, Section
from paper_digest.core.optimizer import PaperOptimizer


def _make_paper(**kwargs) -> Paper:
    defaults = {
        "arxiv_id": "2301.12345",
        "title": "Test Paper",
        "sections": [
            Section(tag="ABSTRACT", original_title="Abstract", content="This is abstract."),
            Section(tag="METHOD", original_title="Method", content="This is method."),
            Section(tag="RESULTS", original_title="Results", content="This is results."),
        ],
    }
    defaults.update(kwargs)
    return Paper(**defaults)


class TestPaperOptimizer:
    def setup_method(self):
        self.optimizer = PaperOptimizer()

    def test_removes_acknowledgements(self):
        paper = _make_paper(sections=[
            Section(tag="ABSTRACT", original_title="Abstract", content="abc"),
            Section(tag="OTHER", original_title="Acknowledgements", content="Thanks to NSF"),
            Section(tag="CONCLUSION", original_title="Conclusion", content="xyz"),
        ])
        result = self.optimizer.optimize(paper)
        tags = [s.tag for s in result.sections]
        assert "OTHER" not in tags  # acknowledgements removed
        assert "ABSTRACT" in tags
        assert "CONCLUSION" in tags

    def test_removes_appendix_by_default(self):
        paper = _make_paper(sections=[
            Section(tag="ABSTRACT", original_title="Abstract", content="abc"),
            Section(tag="APPENDIX", original_title="Appendix A", content="details"),
        ])
        result = self.optimizer.optimize(paper)
        assert not any(s.tag == "APPENDIX" for s in result.sections)

    def test_raw_mode_keeps_everything(self):
        paper = _make_paper(sections=[
            Section(tag="ABSTRACT", original_title="Abstract", content="abc"),
            Section(tag="OTHER", original_title="Acknowledgements", content="Thanks"),
            Section(tag="APPENDIX", original_title="Appendix", content="details"),
        ])
        result = self.optimizer.optimize(paper, raw=True)
        assert len(result.sections) == 3

    def test_section_filter(self):
        paper = _make_paper()
        result = self.optimizer.optimize(paper, sections=["abstract", "method"])
        assert len(result.sections) == 2
        assert result.sections[0].tag == "ABSTRACT"
        assert result.sections[1].tag == "METHOD"

    def test_section_filter_no_match_warns(self):
        paper = _make_paper()
        result = self.optimizer.optimize(paper, sections=["nonexistent"])
        assert len(result.warnings) > 0
        assert "No sections matched" in result.warnings[0]
        # Original sections preserved when no match
        assert len(result.sections) == 3

    def test_removes_arxiv_watermark(self):
        paper = _make_paper(sections=[
            Section(
                tag="ABSTRACT",
                original_title="Abstract",
                content="arXiv: 2301.12345v1 [cs.CL] 1 Jan 2023\n\nThis is the real abstract.",
            ),
        ])
        result = self.optimizer.optimize(paper)
        assert "arXiv:" not in result.sections[0].content
        assert "real abstract" in result.sections[0].content

    def test_compresses_blank_lines(self):
        paper = _make_paper(sections=[
            Section(
                tag="METHOD",
                original_title="Method",
                content="Line 1\n\n\n\n\nLine 2",
            ),
        ])
        result = self.optimizer.optimize(paper)
        assert "\n\n\n" not in result.sections[0].content
        assert "Line 1\n\nLine 2" == result.sections[0].content

    def test_no_sections_paper(self):
        paper = Paper(arxiv_id="2301.12345", sections=[])
        result = self.optimizer.optimize(paper)
        assert len(result.sections) == 0
