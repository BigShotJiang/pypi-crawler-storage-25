"""Tests for paper_digest.core.models."""

from paper_digest.core.models import Paper, Section, classify_section


class TestClassifySection:
    def test_exact_match(self):
        assert classify_section("Method")[0] == "METHOD"
        assert classify_section("Abstract")[0] == "ABSTRACT"
        assert classify_section("References")[0] == "REFERENCES"

    def test_case_insensitive(self):
        assert classify_section("INTRODUCTION")[0] == "INTRODUCTION"
        assert classify_section("related work")[0] == "RELATED_WORK"

    def test_with_numbering(self):
        tag, title = classify_section("3. Method")
        assert tag == "METHOD"
        assert title == "3. Method"

    def test_with_subsection_numbering(self):
        tag, title = classify_section("3.1 Our Proposed Approach")
        # "Our Proposed Approach" doesn't match any pattern
        # but "Our Approach" does match METHOD
        assert tag == "OTHER" or tag == "METHOD"

    def test_methodology(self):
        assert classify_section("Methodology")[0] == "METHOD"

    def test_experimental_setup(self):
        assert classify_section("Experimental Setup")[0] == "EXPERIMENTS"

    def test_discussion(self):
        assert classify_section("Discussion")[0] == "RESULTS"

    def test_conclusion_and_future_work(self):
        assert classify_section("Conclusion and Future Work")[0] == "CONCLUSION"

    def test_unknown_section(self):
        tag, title = classify_section("Theoretical Framework of Quantum Entanglement")
        assert tag == "OTHER"
        assert title == "Theoretical Framework of Quantum Entanglement"

    def test_preserves_original_title(self):
        _, title = classify_section("3.1 Our Approach")
        assert title == "3.1 Our Approach"


class TestSection:
    def test_heading_with_tag(self):
        s = Section(tag="METHOD", original_title="3.1 Our Approach", content="text")
        assert s.heading == "## [METHOD] 3.1 Our Approach"

    def test_heading_other(self):
        s = Section(tag="OTHER", original_title="Quantum Stuff", content="text")
        assert s.heading == "## [OTHER] Quantum Stuff"


class TestPaper:
    def test_section_lookup(self):
        p = Paper(
            arxiv_id="2301.12345",
            sections=[
                Section(tag="ABSTRACT", original_title="Abstract", content="abc"),
                Section(tag="METHOD", original_title="Method", content="def"),
            ],
        )
        assert p.section("method") == "def"
        assert p.section("abstract") == "abc"
        assert p.section("nonexistent") is None

    def test_markdown_output(self):
        p = Paper(
            arxiv_id="2301.12345",
            title="Test Paper",
            authors=["Alice", "Bob"],
            sections=[
                Section(tag="ABSTRACT", original_title="Abstract", content="hello world"),
            ],
        )
        md = p.markdown
        assert "arxiv_id:" in md
        assert "Test Paper" in md
        assert "## [ABSTRACT] Abstract" in md
        assert "hello world" in md

    def test_json_output(self):
        p = Paper(
            arxiv_id="2301.12345",
            title="Test",
            sections=[
                Section(tag="METHOD", original_title="Method", content="content"),
            ],
        )
        j = p.to_json()
        assert j["arxiv_id"] == "2301.12345"
        assert len(j["sections"]) == 1
        assert j["sections"][0]["tag"] == "METHOD"

    def test_metadata(self):
        p = Paper(
            arxiv_id="2301.12345",
            title="Test",
            authors=["Alice"],
            sections=[Section(tag="ABSTRACT", original_title="Abstract", content="x")],
        )
        m = p.metadata
        assert m["arxiv_id"] == "2301.12345"
        assert m["sections"] == ["ABSTRACT"]
