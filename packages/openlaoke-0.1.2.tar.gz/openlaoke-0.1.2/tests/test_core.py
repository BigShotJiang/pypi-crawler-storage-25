"""Tests for core systems."""

import asyncio
import os
import tempfile
from unittest.mock import AsyncMock, patch

import pytest

from openlaoke.core.state import AppState, create_app_state
from openlaoke.core.tool import Tool, ToolContext, ToolRegistry
from openlaoke.types.core_types import (
    MessageRole,
    PermissionMode,
    PermissionResult,
    TaskState,
    TaskStatus,
    TaskType,
    TokenUsage,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
    is_terminal_task_status,
)
from openlaoke.types.permissions import PermissionConfig, PermissionRule
from openlaoke.commands.base import (
    ClearCommand,
    CostCommand,
    ExitCommand,
    HelpCommand,
    ModelCommand,
    PermissionCommand,
)
from openlaoke.commands.registry import get_command, parse_command, register_all


class TestCoreTypes:
    def test_is_terminal_task_status(self):
        assert is_terminal_task_status(TaskStatus.COMPLETED)
        assert is_terminal_task_status(TaskStatus.FAILED)
        assert is_terminal_task_status(TaskStatus.KILLED)
        assert not is_terminal_task_status(TaskStatus.PENDING)
        assert not is_terminal_task_status(TaskStatus.RUNNING)

    def test_token_usage(self):
        usage = TokenUsage(
            input_tokens=1000,
            output_tokens=500,
            cache_read_tokens=200,
            cache_creation_tokens=100,
        )
        assert usage.total_tokens == 1500

        other = TokenUsage(input_tokens=100, output_tokens=50)
        usage.accumulate(other)
        assert usage.input_tokens == 1100
        assert usage.output_tokens == 550

    def test_tool_use_block(self):
        block = ToolUseBlock(id="test_1", name="Bash", input={"command": "ls"})
        d = block.to_dict()
        assert d["type"] == "tool_use"
        assert d["id"] == "test_1"
        assert d["name"] == "Bash"

    def test_tool_result_block(self):
        result = ToolResultBlock(tool_use_id="test_1", content="output", is_error=False)
        d = result.to_dict()
        assert d["tool_use_id"] == "test_1"
        assert not d["is_error"]

    def test_user_message(self):
        msg = UserMessage(role=MessageRole.USER, content="hello")
        d = msg.to_dict()
        assert d["role"] == "user"
        assert d["content"] == "hello"
        assert d["type"] == "user"


class TestPermissionConfig:
    def test_bypass_mode(self):
        config = PermissionConfig(mode=PermissionMode.BYPASS)
        assert config.check_tool("Bash") == PermissionResult.ALLOW

    def test_auto_mode(self):
        config = PermissionConfig(mode=PermissionMode.AUTO)
        assert config.check_tool("Bash") == PermissionResult.ALLOW

    def test_default_mode_read_allowed(self):
        config = PermissionConfig.defaults()
        assert config.check_tool("Read") == PermissionResult.ALLOW

    def test_default_mode_bash_ask(self):
        config = PermissionConfig.defaults()
        assert config.check_tool("Bash") == PermissionResult.ASK

    def test_approve_tool(self):
        config = PermissionConfig.defaults()
        config.approve_tool("Bash", remember=True)
        assert config.check_tool("Bash") == PermissionResult.ALLOW

    def test_custom_rules(self):
        config = PermissionConfig(
            always_allow_rules=[
                PermissionRule("Custom*", PermissionResult.ALLOW),
            ],
        )
        assert config.check_tool("CustomTool") == PermissionResult.ALLOW
        assert config.check_tool("OtherTool") == PermissionResult.ASK


class TestToolRegistry:
    def test_register_and_get(self):
        registry = ToolRegistry()

        class TestTool(Tool):
            name = "TestTool"
            description = "A test tool"
            input_schema = {"type": "object", "properties": {}}

            async def call(self, ctx: ToolContext, **kwargs):
                return ToolResultBlock(tool_use_id=ctx.tool_use_id, content="ok")

        registry.register(TestTool())
        tool = registry.get("TestTool")
        assert tool is not None
        assert tool.name == "TestTool"

    def test_get_unknown(self):
        registry = ToolRegistry()
        assert registry.get("Unknown") is None

    def test_deferred_loading(self):
        registry = ToolRegistry()
        loaded = []

        def loader():
            loaded.append(True)

            class DeferredTool(Tool):
                name = "Deferred"
                description = "Deferred tool"
                input_schema = {}

                async def call(self, ctx, **kwargs):
                    return ToolResultBlock(tool_use_id=ctx.tool_use_id, content="deferred")

            return DeferredTool()

        registry.register_deferred("Deferred", loader)
        assert registry.get("Deferred") is not None
        assert len(loaded) == 1
        assert len(registry._deferred_loaders) == 0

    def test_get_all_for_prompt(self):
        registry = ToolRegistry()

        class T1(Tool):
            name = "T1"
            description = "Tool 1"
            input_schema = {"type": "object", "properties": {"x": {"type": "string"}}}

            async def call(self, ctx, **kwargs):
                return ToolResultBlock(tool_use_id=ctx.tool_use_id, content="ok")

        registry.register(T1())
        tools = registry.get_all_for_prompt()
        assert len(tools) == 1
        assert tools[0]["name"] == "T1"
        assert "properties" in tools[0]["input_schema"]


class TestAppState:
    def test_create_default(self):
        state = create_app_state()
        assert state.session_id.startswith("session_")
        assert state.cwd == os.getcwd()
        assert len(state.messages) == 0

    def test_add_message(self):
        state = create_app_state()
        msg = UserMessage(role=MessageRole.USER, content="hello")
        state.add_message(msg)
        assert len(state.messages) == 1
        assert state.messages[0].content == "hello"

    def test_task_management(self):
        state = create_app_state()
        task = TaskState(id="t1", type=TaskType.LOCAL_BASH, description="test")
        state.add_task(task)
        assert state.get_task("t1") is not None
        assert len(state.get_all_tasks()) == 1

        task.status = TaskStatus.RUNNING
        state.update_task(task)
        assert state.get_task("t1").status == TaskStatus.RUNNING

    def test_token_accumulation(self):
        state = create_app_state()
        state.accumulate_tokens(TokenUsage(input_tokens=100, output_tokens=50))
        state.accumulate_tokens(TokenUsage(input_tokens=200, output_tokens=100))
        assert state.token_usage.input_tokens == 300
        assert state.token_usage.output_tokens == 150

    def test_persist(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name

        try:
            state = create_app_state(persist_path=path)
            state.add_message(UserMessage(role=MessageRole.USER, content="test"))
            state._persist()

            assert os.path.exists(path)
            assert os.path.getsize(path) > 0
        finally:
            os.unlink(path)


class TestCommands:
    @pytest.fixture(autouse=True)
    def setup_commands(self):
        register_all()

    def test_parse_command(self):
        result = parse_command("/help")
        assert result == ("help", "")

        result = parse_command("/model claude-sonnet-4")
        assert result == ("model", "claude-sonnet-4")

        assert parse_command("hello") is None
        assert parse_command("") is None

    def test_help_command(self):
        cmd = HelpCommand()
        state = create_app_state()
        from openlaoke.commands.base import CommandContext
        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state))
        )
        assert result.success
        assert "help" in result.message.lower()

    def test_exit_command(self):
        cmd = ExitCommand()
        state = create_app_state()
        from openlaoke.commands.base import CommandContext
        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state))
        )
        assert result.should_exit

    def test_model_command(self):
        cmd = ModelCommand()
        state = create_app_state()
        from openlaoke.commands.base import CommandContext

        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state, args=""))
        )
        assert "claude-sonnet-4" in result.message

        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state, args="claude-opus-4"))
        )
        assert state.session_config.model == "claude-opus-4"

    def test_permission_command(self):
        cmd = PermissionCommand()
        state = create_app_state()
        from openlaoke.commands.base import CommandContext

        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state, args="auto"))
        )
        assert state.permission_config.mode == PermissionMode.AUTO

    def test_cost_command(self):
        cmd = CostCommand()
        state = create_app_state()
        state.accumulate_tokens(TokenUsage(input_tokens=1000, output_tokens=500))
        from openlaoke.commands.base import CommandContext
        result = asyncio.get_event_loop().run_until_complete(
            cmd.execute(CommandContext(app_state=state))
        )
        assert "1,000" in result.message or "1000" in result.message


class TestToolValidation:
    def test_required_field_validation(self):
        class ValidatingTool(Tool):
            name = "Validating"
            description = "Test"
            input_schema = {
                "type": "object",
                "required": ["file_path"],
                "properties": {"file_path": {"type": "string"}},
            }

            async def call(self, ctx, **kwargs):
                return ToolResultBlock(tool_use_id=ctx.tool_use_id, content="ok")

        tool = ValidatingTool()
        result = tool.validate_input({})
        assert not result.result
        assert "file_path" in result.message

        result = tool.validate_input({"file_path": "test.txt"})
        assert result.result
