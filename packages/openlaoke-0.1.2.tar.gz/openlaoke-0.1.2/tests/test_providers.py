"""Tests for MiniMax and Aliyun Coding Plan providers."""

from __future__ import annotations

import asyncio
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from openlaoke.core.multi_provider_api import MultiProviderClient
from openlaoke.core.repl import REPL
from openlaoke.core.state import create_app_state
from openlaoke.types.core_types import MessageRole, UserMessage
from openlaoke.types.providers import MultiProviderConfig, ProviderConfig, ProviderType


class TestMiniMaxProvider:
    """Test MiniMax provider integration."""

    def test_minimax_config(self):
        """Test MiniMax provider configuration."""
        config = MultiProviderConfig.defaults()
        assert "minimax" in config.providers
        
        minimax = config.providers["minimax"]
        assert minimax.provider_type == ProviderType.MINIMAX
        assert minimax.base_url == "https://api.minimaxi.com/v1"
        assert minimax.default_model == "MiniMax-M2.7-highspeed"
        assert "MiniMax-M2.7-highspeed" in minimax.models

    @pytest.mark.asyncio
    async def test_minimax_api_call(self):
        """Test MiniMax API call with mocked response."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_minimax_key"
        config.active_provider = "minimax"
        
        client = MultiProviderClient(config)
        
        mock_response = {
            "choices": [
                {
                    "message": {
                        "content": "Here's a Python script to calculate your machine's computing power.",
                        "tool_calls": [],
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 100,
                "completion_tokens": 50,
            },
            "model": "MiniMax-M2.7-highspeed",
        }
        
        with patch.object(client._get_client(), "post", new_callable=AsyncMock) as mock_post:
            mock_response_obj = MagicMock()
            mock_response_obj.json.return_value = mock_response
            mock_response_obj.raise_for_status = MagicMock()
            mock_post.return_value = mock_response_obj
            
            response, usage, cost = await client.send_message(
                system_prompt="You are a helpful assistant.",
                messages=[{"role": "user", "content": "Write code to calculate machine compute power"}],
                tools=None,
            )
            
            assert response.content == "Here's a Python script to calculate your machine's computing power."
            assert usage.input_tokens == 100
            assert usage.output_tokens == 50
        
        await client.close()

    @pytest.mark.asyncio
    async def test_minimax_tool_format(self):
        """Test that tools are formatted correctly for MiniMax API."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        config.active_provider = "minimax"
        
        client = MultiProviderClient(config)
        
        tools = [
            {
                "name": "Bash",
                "description": "Execute a bash command",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                    },
                    "required": ["command"],
                },
            }
        ]
        
        openai_tools = client._convert_tools_to_openai_format(tools)
        
        assert len(openai_tools) == 1
        assert openai_tools[0]["type"] == "function"
        assert openai_tools[0]["function"]["name"] == "Bash"
        assert "parameters" in openai_tools[0]["function"]
        
        await client.close()

    @pytest.mark.asyncio
    async def test_minimax_tool_call_response(self):
        """Test handling tool calls from MiniMax."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        config.active_provider = "minimax"
        
        client = MultiProviderClient(config)
        
        mock_response = {
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "call_123",
                                "type": "function",
                                "function": {
                                    "name": "Bash",
                                    "arguments": json.dumps({"command": "python3 -c 'print(1+1)'"}),
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 100, "completion_tokens": 20},
            "model": "MiniMax-M2.7-highspeed",
        }
        
        with patch.object(client._get_client(), "post", new_callable=AsyncMock) as mock_post:
            mock_response_obj = MagicMock()
            mock_response_obj.json.return_value = mock_response
            mock_response_obj.raise_for_status = MagicMock()
            mock_post.return_value = mock_response_obj
            
            response, usage, cost = await client.send_message(
                system_prompt="You are a helpful assistant.",
                messages=[{"role": "user", "content": "Calculate 1+1"}],
                tools=client._convert_tools_to_openai_format([
                    {"name": "Bash", "description": "Run bash", "input_schema": {}}
                ]),
            )
            
            assert len(response.tool_uses) == 1
            assert response.tool_uses[0].name == "Bash"
            assert response.tool_uses[0].input == {"command": "python3 -c 'print(1+1)'"}
        
        await client.close()


class TestAliyunCodingPlanProvider:
    """Test Aliyun Coding Plan provider integration."""

    def test_aliyun_config(self):
        """Test Aliyun provider configuration."""
        config = MultiProviderConfig.defaults()
        assert "aliyun_coding_plan" in config.providers
        
        aliyun = config.providers["aliyun_coding_plan"]
        assert aliyun.provider_type == ProviderType.ALIYUN_CODING_PLAN
        assert aliyun.base_url == "https://coding.dashscope.aliyuncs.com/v1"
        assert aliyun.default_model == "qwen3.5-plus"
        assert "glm-5" in aliyun.models

    @pytest.mark.asyncio
    async def test_aliyun_api_call(self):
        """Test Aliyun API call with mocked response."""
        config = MultiProviderConfig.defaults()
        aliyun = config.providers["aliyun_coding_plan"]
        aliyun.api_key = "sk-sp-test123"
        config.active_provider = "aliyun_coding_plan"
        
        client = MultiProviderClient(config)
        
        mock_response = {
            "choices": [
                {
                    "message": {
                        "content": "这是计算机器算力的代码...",
                        "tool_calls": [],
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 80, "completion_tokens": 40},
            "model": "qwen3.5-plus",
        }
        
        with patch.object(client._get_client(), "post", new_callable=AsyncMock) as mock_post:
            mock_response_obj = MagicMock()
            mock_response_obj.json.return_value = mock_response
            mock_response_obj.raise_for_status = MagicMock()
            mock_post.return_value = mock_response_obj
            
            response, usage, cost = await client.send_message(
                system_prompt="You are a helpful coding assistant.",
                messages=[{"role": "user", "content": "写一个代码计算本机算力"}],
                tools=None,
            )
            
            assert "计算机器算力" in response.content
            assert usage.input_tokens == 80
        
        await client.close()

    @pytest.mark.asyncio
    async def test_aliyun_headers(self):
        """Test that Aliyun uses correct headers."""
        config = MultiProviderConfig.defaults()
        aliyun = config.providers["aliyun_coding_plan"]
        aliyun.api_key = "sk-sp-test123"
        
        client = MultiProviderClient(config)
        headers = client._build_headers(aliyun)
        
        assert "Authorization" in headers
        assert headers["Authorization"] == "Bearer sk-sp-test123"
        assert "Content-Type" in headers
        
        await client.close()


class TestREPLIntegration:
    """Test REPL integration with providers."""

    @pytest.mark.asyncio
    async def test_repl_message_flow(self):
        """Test that REPL properly sends user messages."""
        app_state = create_app_state(
            cwd="/tmp",
            model="MiniMax-M2.7-highspeed",
            persist_path="/tmp/test_session.json",
        )
        
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        config.active_provider = "minimax"
        
        app_state.multi_provider_config = config
        
        user_msg = UserMessage(role=MessageRole.USER, content="写一个代码计算本机算力")
        app_state.add_message(user_msg)
        
        assert len(app_state.messages) == 1
        assert app_state.messages[0].role == MessageRole.USER
        assert app_state.messages[0].content == "写一个代码计算本机算力"

    @pytest.mark.asyncio
    async def test_message_conversion_for_openai(self):
        """Test message conversion for OpenAI-compatible providers."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        config.active_provider = "minimax"
        
        client = MultiProviderClient(config)
        
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!", "tool_calls": [
                {"id": "call_1", "type": "function", "function": {"name": "Bash", "arguments": '{"command": "ls"}'}}
            ]},
            {"role": "tool", "tool_call_id": "call_1", "content": "file1.txt file2.txt"},
        ]
        
        converted = client._convert_to_openai_format(messages)
        
        assert len(converted) == 3
        assert converted[0]["role"] == "user"
        assert converted[1]["role"] == "assistant"
        assert "tool_calls" in converted[1]
        assert converted[2]["role"] == "tool"
        
        await client.close()


class TestConfigWizard:
    """Test configuration wizard."""

    def test_provider_defaults(self):
        """Test that all providers have proper defaults."""
        config = MultiProviderConfig.defaults()
        
        providers = ["anthropic", "openai", "minimax", "aliyun_coding_plan", "ollama", "lm_studio", "openai_compatible"]
        for provider_name in providers:
            assert provider_name in config.providers
            provider = config.providers[provider_name]
            assert provider.provider_type is not None
            if provider_name != "openai_compatible":
                assert provider.base_url or provider.is_local
                assert provider.default_model or provider.is_local

    @pytest.mark.asyncio
    async def test_minimax_env_var(self):
        """Test MiniMax API key from environment."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        
        with patch.dict(os.environ, {"MINIMAX_API_KEY": "env_test_key"}):
            client = MultiProviderClient(config)
            api_key = client._get_api_key(minimax)
            assert api_key == "env_test_key"
            await client.close()

    @pytest.mark.asyncio
    async def test_aliyun_env_var(self):
        """Test Aliyun API key from environment."""
        config = MultiProviderConfig.defaults()
        aliyun = config.providers["aliyun_coding_plan"]
        
        with patch.dict(os.environ, {"ALIYUN_API_KEY": "sk-sp-env-test"}):
            client = MultiProviderClient(config)
            api_key = client._get_api_key(aliyun)
            assert api_key == "sk-sp-env-test"
            await client.close()


@pytest.mark.asyncio
async def test_full_flow_minimax():
    """Full integration test with MiniMax (mocked)."""
    config = MultiProviderConfig.defaults()
    minimax = config.providers["minimax"]
    minimax.api_key = "test_key"
    config.active_provider = "minimax"
    
    client = MultiProviderClient(config)
    
    mock_response_data = {
        "choices": [{
            "message": {
                "content": "I'll create a Python script to calculate compute power.",
                "tool_calls": [
                    {
                        "id": "call_bash_1",
                        "type": "function",
                        "function": {
                            "name": "Write",
                            "arguments": json.dumps({
                                "file_path": "/tmp/compute_power.py",
                                "content": "import os\nprint('Compute power test')"
                            })
                        }
                    }
                ]
            },
            "finish_reason": "tool_calls"
        }],
        "usage": {"prompt_tokens": 150, "completion_tokens": 30}
    }
    
    with patch.object(client, "_get_client") as mock_get_client:
        mock_http_client = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()
        mock_http_client.post = AsyncMock(return_value=mock_response)
        mock_get_client.return_value = mock_http_client
        
        response, usage, cost = await client.send_message(
            system_prompt="You are OpenLaoKe, a coding assistant.",
            messages=[{"role": "user", "content": "写一个代码计算本机算力"}],
            tools=client._convert_tools_to_openai_format([
                {"name": "Write", "description": "Write file", "input_schema": {}},
                {"name": "Bash", "description": "Run command", "input_schema": {}},
            ]),
        )
        
        assert response.content == "I'll create a Python script to calculate compute power."
        assert len(response.tool_uses) == 1
        assert response.tool_uses[0].name == "Write"
    
    await client.close()


@pytest.mark.asyncio
async def test_full_flow_aliyun():
    """Full integration test with Aliyun Coding Plan (mocked)."""
    config = MultiProviderConfig.defaults()
    aliyun = config.providers["aliyun_coding_plan"]
    aliyun.api_key = "sk-sp-test"
    config.active_provider = "aliyun_coding_plan"
    
    client = MultiProviderClient(config)
    
    mock_response_data = {
        "choices": [{
            "message": {
                "content": "好的，我来写一个计算算力的程序。",
                "tool_calls": [
                    {
                        "id": "call_write_1",
                        "type": "function",
                        "function": {
                            "name": "Bash",
                            "arguments": json.dumps({"command": "python3 --version"})
                        }
                    }
                ]
            },
            "finish_reason": "tool_calls"
        }],
        "usage": {"prompt_tokens": 100, "completion_tokens": 25}
    }
    
    with patch.object(client, "_get_client") as mock_get_client:
        mock_http_client = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()
        mock_http_client.post = AsyncMock(return_value=mock_response)
        mock_get_client.return_value = mock_http_client
        
        response, usage, cost = await client.send_message(
            system_prompt="你是 OpenLaoKe，一个编程助手。",
            messages=[{"role": "user", "content": "写一个代码计算本机算力"}],
            tools=client._convert_tools_to_openai_format([
                {"name": "Write", "description": "Write file", "input_schema": {}},
                {"name": "Bash", "description": "Run command", "input_schema": {}},
            ]),
        )
        
        assert "计算算力的程序" in response.content
        assert len(response.tool_uses) == 1
        assert response.tool_uses[0].name == "Bash"
    
    await client.close()