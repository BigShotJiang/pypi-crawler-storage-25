"""Chat widget for displaying messages and input."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QPushButton,
    QScrollArea,
    QLabel,
    QFrame,
    QSizePolicy,
)
from PySide6.QtCore import Qt, Signal, Slot, QTimer
from PySide6.QtGui import QFont, QTextCursor, QColor, QPalette

if TYPE_CHECKING:
    from openlaoke.core.state import AppState


class MessageBubble(QFrame):
    """A single message bubble."""
    
    def __init__(self, role: str, content: str, parent=None):
        super().__init__(parent)
        self.role = role
        self.content = content
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        
        role_label = QLabel(self.role.title())
        role_label.setStyleSheet("font-weight: bold; color: #888; font-size: 11px;")
        layout.addWidget(role_label)
        
        self.content_label = QLabel(self.content)
        self.content_label.setWordWrap(True)
        self.content_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.content_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        layout.addWidget(self.content_label)
        
        if self.role == "user":
            self.setStyleSheet("""
                MessageBubble {
                    background-color: #2a2a3e;
                    border-radius: 8px;
                    margin: 4px 60px 4px 8px;
                }
            """)
        else:
            self.setStyleSheet("""
                MessageBubble {
                    background-color: #1e1e2e;
                    border-radius: 8px;
                    margin: 4px 8px 4px 60px;
                }
            """)
    
    def append_content(self, text: str):
        """Append text to content."""
        self.content += text
        self.content_label.setText(self.content)


class ChatWidget(QWidget):
    """Main chat widget with message display and input."""
    
    message_sent = Signal(str)
    tool_executed = Signal(dict)
    code_block_clicked = Signal(str)
    
    def __init__(self, app_state: AppState | None = None, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._messages: list[dict[str, Any]] = []
        self._current_assistant_bubble: MessageBubble | None = None
        
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #12121a;
            }
        """)
        
        self._messages_container = QWidget()
        self._messages_layout = QVBoxLayout(self._messages_container)
        self._messages_layout.setContentsMargins(8, 8, 8, 8)
        self._messages_layout.setSpacing(8)
        self._messages_layout.addStretch()
        
        scroll_area.setWidget(self._messages_container)
        layout.addWidget(scroll_area, stretch=1)
        
        self._scroll_area = scroll_area
        
        input_frame = QFrame()
        input_frame.setStyleSheet("""
            QFrame {
                background-color: #1a1a24;
                border-top: 1px solid #333;
            }
        """)
        
        input_layout = QHBoxLayout(input_frame)
        input_layout.setContentsMargins(12, 8, 12, 8)
        
        self._input = QTextEdit()
        self._input.setPlaceholderText("Type a message... (Shift+Enter for new line)")
        self._input.setMaximumHeight(120)
        self._input.setStyleSheet("""
            QTextEdit {
                background-color: #252532;
                border: 1px solid #333;
                border-radius: 8px;
                padding: 8px;
                color: #ddd;
            }
        """)
        input_layout.addWidget(self._input, stretch=1)
        
        send_button = QPushButton("Send")
        send_button.setFixedWidth(80)
        send_button.setStyleSheet("""
            QPushButton {
                background-color: #2a82dd;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3a92ed;
            }
            QPushButton:pressed {
                background-color: #1a72cd;
            }
        """)
        send_button.clicked.connect(self._send_message)
        input_layout.addWidget(send_button)
        
        layout.addWidget(input_frame)
        
        self._input.installEventFilter(self)
    
    def eventFilter(self, obj, event):
        if obj == self._input:
            if event.type() == event.KeyPress:
                if event.key() == Qt.Key_Return and not event.modifiers() & Qt.ShiftModifier:
                    self._send_message()
                    return True
        return super().eventFilter(obj, event)
    
    @Slot()
    def _send_message(self):
        text = self._input.toPlainText().strip()
        if text:
            self.add_user_message(text)
            self._input.clear()
            self.message_sent.emit(text)
    
    def add_user_message(self, content: str):
        bubble = MessageBubble("user", content, self)
        self._messages_layout.insertWidget(self._messages_layout.count() - 1, bubble)
        self._messages.append({"role": "user", "content": content})
        self._scroll_to_bottom()
    
    def add_assistant_message(self, content: str = ""):
        bubble = MessageBubble("assistant", content, self)
        self._messages_layout.insertWidget(self._messages_layout.count() - 1, bubble)
        self._messages.append({"role": "assistant", "content": content})
        self._current_assistant_bubble = bubble
        self._scroll_to_bottom()
    
    def append_assistant_message(self, content: str):
        if self._current_assistant_bubble:
            self._current_assistant_bubble.append_content(content)
        else:
            self.add_assistant_message(content)
        self._scroll_to_bottom()
    
    def add_tool_message(self, tool_name: str, tool_input: dict, result: str = ""):
        content = f"🔧 {tool_name}\n```json\n{json.dumps(tool_input, indent=2)}\n```\n"
        if result:
            content += f"\n**Result:**\n```\n{result[:500]}...\n```"
        
        bubble = MessageBubble("tool", content, self)
        bubble.setStyleSheet("""
            MessageBubble {
                background-color: #1a2820;
                border: 1px solid #2a4a3a;
                border-radius: 8px;
                margin: 4px 20px;
            }
        """)
        self._messages_layout.insertWidget(self._messages_layout.count() - 1, bubble)
        self._messages.append({"role": "tool", "name": tool_name, "input": tool_input, "result": result})
        self._scroll_to_bottom()
    
    def finish_assistant_message(self):
        self._current_assistant_bubble = None
    
    def clear_messages(self):
        while self._messages_layout.count() > 1:
            item = self._messages_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._messages.clear()
        self._current_assistant_bubble = None
    
    def get_messages(self) -> list[dict[str, Any]]:
        return self._messages.copy()
    
    def _scroll_to_bottom(self):
        QTimer.singleShot(100, lambda: self._scroll_area.verticalScrollBar().setValue(
            self._scroll_area.verticalScrollBar().maximum()
        ))