"""Main window for OpenLaoKe GUI."""

from __future__ import annotations

import asyncio
import json
import os
from typing import TYPE_CHECKING, Any

from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QSplitter,
    QStatusBar,
    QMenuBar,
    QMenu,
    QToolBar,
    QLabel,
    QMessageBox,
    QFileDialog,
)
from PySide6.QtCore import Qt, QTimer, Signal, Slot, QThread
from PySide6.QtGui import QAction, QKeySequence, QCloseEvent

if TYPE_CHECKING:
    from openlaoke.core.state import AppState
    from openlaoke.utils.config import AppConfig


class WorkerThread(QThread):
    """Background worker for async operations."""
    
    finished = Signal(object)
    error = Signal(str)
    
    def __init__(self, coro, parent=None):
        super().__init__(parent)
        self.coro = coro
    
    def run(self):
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(self.coro)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))
        finally:
            loop.close()


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self, app_state: AppState | None = None, config: AppConfig | None = None):
        super().__init__()
        
        self.app_state = app_state
        self.config = config
        self._worker_threads: list[QThread] = []
        
        self._setup_window()
        self._setup_menu_bar()
        self._setup_toolbar()
        self._setup_central_widget()
        self._setup_status_bar()
        self._setup_shortcuts()
        
        self._load_window_state()
    
    def _setup_window(self):
        """Setup window properties."""
        self.setWindowTitle("OpenLaoKe - AI Coding Assistant")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
    
    def _setup_menu_bar(self):
        """Setup menu bar."""
        menubar = self.menuBar()
        
        file_menu = menubar.addMenu("&File")
        
        new_session_action = QAction("&New Session", self)
        new_session_action.setShortcut(QKeySequence.New)
        new_session_action.triggered.connect(self._new_session)
        file_menu.addAction(new_session_action)
        
        open_project_action = QAction("&Open Project...", self)
        open_project_action.setShortcut(QKeySequence.Open)
        open_project_action.triggered.connect(self._open_project)
        file_menu.addAction(open_project_action)
        
        file_menu.addSeparator()
        
        export_action = QAction("&Export Chat...", self)
        export_action.triggered.connect(self._export_chat)
        file_menu.addAction(export_action)
        
        file_menu.addSeparator()
        
        quit_action = QAction("&Quit", self)
        quit_action.setShortcut(QKeySequence.Quit)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)
        
        edit_menu = menubar.addMenu("&Edit")
        
        clear_action = QAction("&Clear Chat", self)
        clear_action.triggered.connect(self._clear_chat)
        edit_menu.addAction(clear_action)
        
        settings_action = QAction("&Settings...", self)
        settings_action.setShortcut(QKeySequence.Preferences)
        settings_action.triggered.connect(self._open_settings)
        edit_menu.addAction(settings_action)
        
        view_menu = menubar.addMenu("&View")
        
        toggle_sidebar_action = QAction("Toggle &Sidebar", self)
        toggle_sidebar_action.setShortcut(QKeySequence("Ctrl+B"))
        toggle_sidebar_action.triggered.connect(self._toggle_sidebar)
        view_menu.addAction(toggle_sidebar_action)
        
        toggle_files_action = QAction("Toggle &Files Panel", self)
        toggle_files_action.triggered.connect(self._toggle_files_panel)
        view_menu.addAction(toggle_files_action)
        
        provider_menu = menubar.addMenu("&Provider")
        
        self._provider_menu = provider_menu
        self._update_provider_menu()
        
        help_menu = menubar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)
        
        shortcuts_action = QAction("&Keyboard Shortcuts", self)
        shortcuts_action.triggered.connect(self._show_shortcuts)
        help_menu.addAction(shortcuts_action)
    
    def _update_provider_menu(self):
        """Update provider menu with available providers."""
        self._provider_menu.clear()
        
        if not self.config or not self.config.providers:
            return
        
        from openlaoke.types.providers import ProviderType
        
        for name, provider in self.config.providers.providers.items():
            if provider.is_configured():
                action = QAction(f"&{name.replace('_', ' ').title()}", self)
                action.setCheckable(True)
                action.setChecked(name == self.config.providers.active_provider)
                action.triggered.connect(lambda checked, n=name: self._switch_provider(n))
                self._provider_menu.addAction(action)
        
        self._provider_menu.addSeparator()
        
        config_action = QAction("&Configure Providers...", self)
        config_action.triggered.connect(self._open_provider_config)
        self._provider_menu.addAction(config_action)
    
    def _setup_toolbar(self):
        """Setup main toolbar."""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        new_action = QAction("New", self)
        new_action.triggered.connect(self._new_session)
        toolbar.addAction(new_action)
        
        open_action = QAction("Open", self)
        open_action.triggered.connect(self._open_project)
        toolbar.addAction(open_action)
        
        toolbar.addSeparator()
        
        clear_action = QAction("Clear", self)
        clear_action.triggered.connect(self._clear_chat)
        toolbar.addAction(clear_action)
        
        toolbar.addSeparator()
        
        self._provider_label = QLabel("Provider: ")
        self._provider_label.setStyleSheet("padding: 0 10px; color: #aaa;")
        toolbar.addWidget(self._provider_label)
        
        self._model_label = QLabel("Model: ")
        self._model_label.setStyleSheet("padding: 0 10px; color: #aaa;")
        toolbar.addWidget(self._model_label)
        
        self._update_status_labels()
    
    def _setup_central_widget(self):
        """Setup central widget with splitter layout."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QHBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        main_splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(main_splitter)
        
        from .components.sidebar import SidebarWidget
        self._sidebar = SidebarWidget(self.config)
        self._sidebar.setMaximumWidth(300)
        self._sidebar.setMinimumWidth(200)
        main_splitter.addWidget(self._sidebar)
        
        center_splitter = QSplitter(Qt.Vertical)
        main_splitter.addWidget(center_splitter)
        
        from .components.chat_widget import ChatWidget
        self._chat_widget = ChatWidget(self.app_state)
        center_splitter.addWidget(self._chat_widget)
        
        from .components.code_viewer import CodeViewerWidget
        self._code_viewer = CodeViewerWidget()
        self._code_viewer.setMinimumHeight(200)
        center_splitter.addWidget(self._code_viewer)
        
        center_splitter.setSizes([600, 200])
        
        from .components.file_tree import FileTreeWidget
        self._file_tree = FileTreeWidget()
        self._file_tree.setMaximumWidth(300)
        self._file_tree.setMinimumWidth(200)
        main_splitter.addWidget(self._file_tree)
        
        main_splitter.setSizes([250, 850, 300])
        
        self._main_splitter = main_splitter
        self._center_splitter = center_splitter
        
        self._connect_signals()
        
        if self.app_state and self.app_state.get_cwd():
            self._file_tree.set_root_path(self.app_state.get_cwd())
    
    def _connect_signals(self):
        """Connect internal signals."""
        self._sidebar.project_selected.connect(self._on_project_selected)
        self._sidebar.session_selected.connect(self._on_session_selected)
        
        self._file_tree.file_selected.connect(self._on_file_selected)
        self._file_tree.file_open_requested.connect(self._on_file_open)
        
        self._chat_widget.message_sent.connect(self._on_message_sent)
        self._chat_widget.tool_executed.connect(self._on_tool_executed)
        self._chat_widget.code_block_clicked.connect(self._on_code_block_clicked)
    
    def _setup_status_bar(self):
        """Setup status bar."""
        status_bar = QStatusBar()
        self.setStatusBar(status_bar)
        
        self._status_label = QLabel("Ready")
        status_bar.addWidget(self._status_label)
        
        status_bar.addPermanentWidget(QLabel(f"OpenLaoKe v0.1.1"))
    
    def _setup_shortcuts(self):
        """Setup keyboard shortcuts."""
        pass
    
    def _load_window_state(self):
        """Load window geometry and state."""
        if self.config and hasattr(self.config, 'window_geometry'):
            geometry = self.config.window_geometry
            if geometry:
                self.restoreGeometry(geometry)
    
    def _save_window_state(self):
        """Save window geometry and state."""
        pass
    
    @Slot()
    def _new_session(self):
        """Create a new session."""
        self._chat_widget.clear_messages()
        self._status_label.setText("New session")
    
    @Slot()
    def _open_project(self):
        """Open a project directory."""
        directory = QFileDialog.getExistingDirectory(
            self, "Open Project", os.path.expanduser("~")
        )
        if directory:
            self._file_tree.set_root_path(directory)
            if self.app_state:
                self.app_state.set_cwd(directory)
            self._status_label.setText(f"Opened: {directory}")
    
    @Slot()
    def _export_chat(self):
        """Export chat history."""
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Chat", "chat.json", "JSON Files (*.json)"
        )
        if filename:
            messages = self._chat_widget.get_messages()
            with open(filename, 'w') as f:
                json.dump(messages, f, indent=2)
            self._status_label.setText(f"Exported to: {filename}")
    
    @Slot()
    def _clear_chat(self):
        """Clear chat messages."""
        reply = QMessageBox.question(
            self, "Clear Chat",
            "Are you sure you want to clear the chat history?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self._chat_widget.clear_messages()
    
    @Slot()
    def _open_settings(self):
        """Open settings dialog."""
        from .dialogs.settings_dialog import SettingsDialog
        dialog = SettingsDialog(self.config, self)
        if dialog.exec():
            self._update_status_labels()
            self._update_provider_menu()
    
    @Slot()
    def _toggle_sidebar(self):
        """Toggle sidebar visibility."""
        self._sidebar.setVisible(not self._sidebar.isVisible())
    
    @Slot()
    def _toggle_files_panel(self):
        """Toggle files panel visibility."""
        self._file_tree.setVisible(not self._file_tree.isVisible())
    
    def _switch_provider(self, provider_name: str):
        """Switch active provider."""
        if self.config and provider_name in self.config.providers.providers:
            self.config.providers.active_provider = provider_name
            self._update_status_labels()
            self._update_provider_menu()
            self._status_label.setText(f"Switched to: {provider_name}")
    
    @Slot()
    def _open_provider_config(self):
        """Open provider configuration dialog."""
        from .dialogs.provider_dialog import ProviderConfigDialog
        dialog = ProviderConfigDialog(self.config, self)
        if dialog.exec():
            self._update_status_labels()
            self._update_provider_menu()
    
    @Slot()
    def _show_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self,
            "About OpenLaoKe",
            "<h2>OpenLaoKe v0.1.1</h2>"
            "<p>Open-source AI coding assistant</p>"
            "<p>Supports multiple LLM providers:</p>"
            "<ul>"
            "<li>Anthropic (Claude)</li>"
            "<li>OpenAI (GPT)</li>"
            "<li>MiniMax</li>"
            "<li>Aliyun Coding Plan</li>"
            "<li>Ollama (Local)</li>"
            "<li>LM Studio (Local)</li>"
            "</ul>"
            "<p>Features:</p>"
            "<ul>"
            "<li>Multi-turn conversations</li>"
            "<li>Tool integration (Bash, Read, Write, Edit, etc.)</li>"
            "<li>Code generation and editing</li>"
            "<li>File browsing and editing</li>"
            "</ul>"
        )
    
    @Slot()
    def _show_shortcuts(self):
        """Show keyboard shortcuts dialog."""
        shortcuts = """
<h2>Keyboard Shortcuts</h2>
<table>
<tr><td><b>Ctrl+N</b></td><td>New Session</td></tr>
<tr><td><b>Ctrl+O</b></td><td>Open Project</td></tr>
<tr><td><b>Ctrl+,</b></td><td>Settings</td></tr>
<tr><td><b>Ctrl+B</b></td><td>Toggle Sidebar</td></tr>
<tr><td><b>Ctrl+L</b></td><td>Clear Chat</td></tr>
<tr><td><b>Ctrl+Q</b></td><td>Quit</td></tr>
<tr><td><b>Enter</b></td><td>Send Message</td></tr>
<tr><td><b>Shift+Enter</b></td><td>New Line</td></tr>
</table>
        """
        QMessageBox.information(self, "Keyboard Shortcuts", shortcuts)
    
    def _update_status_labels(self):
        """Update provider and model labels."""
        if self.config:
            provider_name = self.config.providers.active_provider
            model_name = self.config.providers.get_active_model()
            
            self._provider_label.setText(f"Provider: {provider_name}")
            self._model_label.setText(f"Model: {model_name}")
    
    @Slot(str)
    def _on_project_selected(self, path: str):
        """Handle project selection from sidebar."""
        self._file_tree.set_root_path(path)
        if self.app_state:
            self.app_state.set_cwd(path)
        self._status_label.setText(f"Project: {path}")
    
    @Slot(str)
    def _on_session_selected(self, session_id: str):
        """Handle session selection from sidebar."""
        self._status_label.setText(f"Session: {session_id}")
    
    @Slot(str)
    def _on_file_selected(self, path: str):
        """Handle file selection."""
        self._code_viewer.load_file(path)
    
    @Slot(str)
    def _on_file_open(self, path: str):
        """Handle file open request."""
        self._code_viewer.load_file(path)
    
    @Slot(str)
    def _on_message_sent(self, message: str):
        """Handle message sent from chat."""
        self._status_label.setText("Processing...")
    
    @Slot(dict)
    def _on_tool_executed(self, tool_info: dict):
        """Handle tool execution."""
        tool_name = tool_info.get('name', 'unknown')
        self._status_label.setText(f"Tool: {tool_name}")
    
    @Slot(str)
    def _on_code_block_clicked(self, code: str):
        """Handle code block click."""
        self._code_viewer.set_code(code)
    
    def set_status(self, message: str):
        """Set status bar message."""
        self._status_label.setText(message)
    
    def closeEvent(self, event: QCloseEvent):
        """Handle window close."""
        reply = QMessageBox.question(
            self,
            "Quit OpenLaoKe?",
            "Are you sure you want to quit?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            for thread in self._worker_threads:
                if thread.isRunning():
                    thread.quit()
                    thread.wait()
            self._save_window_state()
            event.accept()
        else:
            event.ignore()