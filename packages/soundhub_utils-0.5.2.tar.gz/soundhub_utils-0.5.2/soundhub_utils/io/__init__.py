"""
IO Utilities Module

Input/Output utilities for various storage backends (AWS S3, GCS, HTTP)

License: BSD 3-Clause
"""