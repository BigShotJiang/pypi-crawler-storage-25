# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

import math
import os
from collections.abc import Callable
from copy import deepcopy
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Set, Tuple, Union, cast

import gmsh
import numpy as np
from gmsh import model as gmsh_model
from jinja2 import Environment, FileSystemLoader
from pydantic import BaseModel

from pycivil.EXAGeometry.geometry import Point3d, Vector3d
from pycivil.EXAGeometry.shapes import ShapesEnum
from pycivil.EXAUtils import EXAExceptions as Ex
from pycivil.EXAUtils import logging as log
from pycivil.settings import ServerSettings

myInt64 = Union[int, np.uint64, np.int32]

thisPath = os.path.dirname(os.path.abspath(__file__))
sp = ServerSettings().midas_templates_path

file_loader = FileSystemLoader(searchpath=sp)
env = Environment(loader=file_loader)
template = env.get_template("template-box.mgt")


class Dim(Enum):
    """Spatial dimension of a GMSH entity or mesh element."""

    DIM_0D = 0
    DIM_1D = 1
    DIM_2D = 2
    DIM_3D = 3


class Elem(Enum):
    """Mesh element type."""

    ELEM_POINT = 1
    ELEM_LINE = 2
    ELEM_TRIA = 3
    ELEM_QUAD = 4


class LoadType(str, Enum):
    """Category of load stored per load case."""

    FRAME_LOAD = "frameLoad"
    NODE_LOAD = "nodeLoad"
    SELF_WEIGHT = "selfWeight"


class NodalSpringsTp(str, Enum):
    """Behaviour type of a nodal spring support."""

    LINEAR = "LINEAR"  #: Linear (bilateral) spring.
    COMP = "COMP"      #: Compression-only spring.
    TENS = "TENS"      #: Tension-only spring.


class NodalSpringsDir(str, Enum):
    """Global direction of a nodal spring support."""

    DXP = "DX+"  #: Positive X direction.
    DXN = "DX-"  #: Negative X direction.
    DYP = "DY+"  #: Positive Y direction.
    DYN = "DY-"  #: Negative Y direction.
    DZP = "DZ+"  #: Positive Z direction.
    DZN = "DZ-"  #: Negative Z direction.


class SectionShape(BaseModel):
    """Base Pydantic model for a cross-section shape definition."""

    type: ShapesEnum
    param: List[float]
    name: str


class ShapeRect(SectionShape):
    """Rectangular cross-section shape.

    Attributes:
        param: ``[width, height]`` in model length units.
        name: Human-readable section name.
    """

    type: ShapesEnum = ShapesEnum.SHAPE_RECT
    param: List[float] = [0, 0]
    name: str = ""


class FEMaterial(BaseModel):
    """Material properties used by the FE model.

    Attributes:
        name: Human-readable material name.
        modulus: Young's modulus [MPa].
        poisson: Poisson's ratio [-].
        density: Mass density [kg/m³].
        thermal_expansion: Coefficient of thermal expansion [1/°C].
        conductivity: Thermal conductivity [kJ/s/m/°C].
        specific_heat: Specific heat capacity [kJ/kg/°C].
    """

    name: str = ""
    modulus: float = 0.0
    poisson: float = 0.0
    density: float = 0.0
    thermal_expansion: float = 0.0
    conductivity: float = 0.0
    specific_heat: float = 0.0


class PlateFaceSupport(BaseModel):
    """Winkler-type elastic foundation acting on a plate face.

    Attributes:
        k_normal: Normal (out-of-plane) subgrade stiffness [force/length³].
        k_lateral: Lateral (in-plane) subgrade stiffness [force/length³].
        compression_only: If ``True``, the support reacts only in compression.
        gap: Initial gap before the support activates [length units].
        local_3_direction: If ``True``, the normal direction is the plate
            local axis 3; otherwise the global Z axis is used.
    """

    k_normal: float
    k_lateral: float
    compression_only: bool = False
    gap: float = 0.0
    local_3_direction: bool = True


class FEModel:
    configData = {
        "LoadCaseType": [
            {"id": "U", "description": "User Defined Load"},
            {"id": "D", "description": "Dead Load"},
            {"id": "L", "description": "Live Load"},
            {"id": "R", "description": "Roof Live Load"},
            {"id": "W", "description": "Wind Load on Structure"},
            {"id": "E", "description": "Earthquake"},
            {"id": "T", "description": "Temperature"},
            {"id": "S", "description": "Snow Load"},
            {"id": "R", "description": "Rain Load"},
            {"id": "IL", "description": "Live Load Impact"},
            {"id": "EP", "description": "Earth Pressure"},
            {"id": "B", "description": "Buoyancy"},
            {"id": "WP", "description": "Ground Water Pressure"},
            {"id": "FP", "description": "Fluid Pressure"},
            {"id": "IP", "description": "Ice Pressure"},
            {"id": "WL", "description": "Wind Load on Live Load"},
            {"id": "BK", "description": "Longitudinal Force from Live Load"},
            {"id": "CF", "description": "Centrifugal Force"},
            {"id": "RS", "description": "Rib Shortening"},
            {"id": "SH", "description": "Shrinkage"},
            {"id": "CR", "description": "Creep"},
            {"id": "PS", "description": "Pre-stressing force"},
            {"id": "ER", "description": "Erection Load"},
            {"id": "CO", "description": "Collision Load"},
            {"id": "CS", "description": "Construction Stage Load"},
            {"id": "BL", "description": "Braking Load"},
            {"id": "STL", "description": "Settlement"},
            {"id": "WPL", "description": "Wave Pressure"},
            {"id": "CL", "description": "Crowd Load"},
            {"id": "TG", "description": "Temperature Gradient"},
            {"id": "SW", "description": "Self Weight"},
        ]
    }

    def __init__(self, descr: str = "", modelName: str = "default"):
        """Initialize the FEM model and the underlying GMSH session.

        Starts the GMSH library, creates an OCC (OpenCASCADE) geometry kernel,
        and registers the first model. Internal dictionaries for load cases,
        loads, combinations, supports, springs, materials, and section shapes
        are all created empty (or with a default rect section assigned as id=1).

        # Local axes default for beam (same convenction as Strand7):

        If the beam is parallel to the global Z axis (left image), the 2 direction is always in the positive global Y
        direction.

        If the beam is not parallel to the global Z axis, the 2 direction is given by the vector cross product of the
        global Z axis and a vector defined by nodes N1-N2. The 3 direction is directed from node N1 to node N2, with
        the 1 direction completing a right hand system.

        # Local axes for 3-Node and 4-Node elements (same convenction as Strand7):

        The default local axis system for these elements is constructed from the nodes N1, N2, N3 for the triangle and
        N1, N2, N3, N4 for the quadrilateral element as follows:

            1. Positive local x joins the mid-sides from side (N1,N4) to side (N2,N3) for the quadrilateral element,
              or goes from N1 to bisect side (N2,N3) for the triangle.
            2. Positive local y is normal to the local x axis directed away from side (N1,N2) and lies in the plane of
              the plate.
            3. In all plate elements the positive local z axis is normal to the plate surface completing a right hand
              system with the local x and y axes.

        Args:
            descr: Human-readable description of the model.
            modelName: Name used to identify the GMSH model; also stored as
                the first entry in the internal models list.
        """
        self.__logLevel: Literal[0, 1, 2, 3] = 3

        # GMSH init
        gmsh.initialize()

        # Using OCC as BREP for geometry
        self.__cad = gmsh_model.occ

        # Adding model and make current
        gmsh_model.add(modelName)
        gmsh_model.setCurrent(modelName)

        self.__models = [modelName]
        self.__description: str = descr

        # Load cases and combinations
        #
        self.__loadCase: Dict[str, Tuple[str, str]] = {}
        self.__loads: Dict[str, Dict[LoadType, Any]] = {}
        self.__loadCombinations: Dict[str, List[float]] = {}

        # Libraries for shapes and materials
        #
        self.__sectionShapes: Dict[int, SectionShape] = {
            1: ShapeRect(param=[1.0, 0.3], name="default")
        }
        self.__materialLibrary: Dict[int, FEMaterial] = {}

        # Values that don't depend on geometry or mesh
        #
        # [Load Case] = value
        self.__initialTemperatures: Dict[str, float] = {}
        self.__inertialAcceleration: Dict[str, Tuple[float, float, float]] = {}

        # [group tree name, physical]
        #
        self.__groupTree: Dict[str, str] = {}

        # ---------------------------------------------------------------------
        #                                 NODES
        # ---------------------------------------------------------------------
        #
        # Supports
        #
        self.__nodeSupports: Dict[
            myInt64, Tuple[bool, bool, bool, bool, bool, bool]
        ] = {}
        #
        # Springs
        #
        self.__nodeSprings: Dict[
            myInt64, Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]
        ] = {}
        #
        # Temperature
        #
        # [Load Case][Node Tag][Tp]
        self.__nodeTemperatures: Dict[str, Dict[int, Dict[str, float]]] = {}
        #
        # Macro elements
        #
        self.__macro_element_node: dict[int, Point3d] = {}

        # ---------------------------------------------------------------------
        #                                FRAMES
        # ---------------------------------------------------------------------
        #
        # Temperature
        #
        # [Load Case][Frame Tag][Tp]
        self.__frameTemperatures: Dict[
            str, Dict[int, Dict[str, Tuple[float, float]]]
        ] = {}
        #
        # Springs evenly distribuited in local direction
        #
        # Dict[id_frame, Tuple[LCDIR1, LCDIR2, ONLYCOMPRESSION]]
        self.__framesSprings: Dict[myInt64, Tuple[float, float, bool]] = {}
        #
        # Macro elements
        #
        # Dict[id_frame, Tuple[id_node_i, id_node_i]]
        self.__macro_element_frame: dict[int, tuple[int, int]] = {}
        #
        # Local axes supports
        #
        # Dict[id_frame, axis]
        self.__framesLocal2: Dict[myInt64, Vector3d] = {}
        #
        # Shape
        #
        self.__framesShapes: Dict[myInt64, int] = {}
        #
        # Material
        #
        self.__framesMaterial: Dict[myInt64, int] = {}
        #
        # Link between Frames and phisical Names
        #
        self.__framesPhysicalNames: Dict[myInt64, List[str]] = {}

        # ---------------------------------------------------------------------
        #                                PLATES
        # ---------------------------------------------------------------------
        #
        # Local axes supports
        #
        self.__platesLocal1: Dict[myInt64, Vector3d] = {}
        #
        # Macro elements
        #
        self.__macro_element_plate: dict[
            int, tuple[int, int, int, int] | tuple[int, int, int]
        ] = {}
        #
        # Mapping custom ID with macro elements composed of one element in
        # mesh space
        self.__tagToGroupForRename: Dict[Elem, Dict[int, int]] = {
            Elem.ELEM_POINT: {},
            Elem.ELEM_LINE: {},
            Elem.ELEM_TRIA: {},
            Elem.ELEM_QUAD: {},
        }
        #
        # Link between Plates and phisical Names
        #
        self.__platesPhysicalNames: Dict[myInt64, List[str]] = {}
        #
        # Material
        #
        self.__platesMaterial: Dict[myInt64, int] = {}
        #
        # Plate thicknesses
        #
        # Dict[id_plate, Tuple[bending_thick, membrane_thick]]
        self.__platesThicknesses: Dict[myInt64, Tuple[float, float]] = {}
        #
        # Plate Face supports
        #
        self.__platesFaceSupports: Dict[myInt64, PlateFaceSupport] = {}

    def __log(self, tp: Literal["INF", "WRN", "ERR"], msg: str) -> None:
        """Emit a log message at the configured log level.

        Args:
            tp: Message type tag — one of ``"INF"``, ``"WRN"``, or ``"ERR"``.
            msg: Message text.
        """
        log.log(tp, msg, self.__logLevel)

    def getMacroElementNode(self) -> dict[int, Point3d]:
        """Return a deep copy of the macro-element node dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each node macro-tag to its ``Point3d`` coordinates.
        """
        return deepcopy(self.__macro_element_node)

    def getMacroElementFrame(self) -> dict[int, tuple[int, int]]:
        """Return a deep copy of the macro-element frame dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each frame macro-tag to the tuple
            ``(start_node_tag, end_node_tag)``.
        """
        return deepcopy(self.__macro_element_frame)

    def getMacroElementPlate(self) -> dict[int, tuple[int, int, int, int] | tuple[int, int, int]]:
        """Return a deep copy of the macro-element plate dictionary.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Returns:
            A dict mapping each plate macro-tag to the tuple of corner node
            tags (3 values for triangles, 4 for quads).
        """
        return deepcopy(self.__macro_element_plate)

    @staticmethod
    def _elementConnectivity(
        dimension: Dim, elTag: myInt64 = -1
    ) -> Dict[Any, Tuple[Any, ...]]:
        """Return a connectivity dictionary for mesh elements of a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query (0D, 1D, 2D, or 3D).
            elTag: GMSH entity tag to restrict the query to. -1 queries all entities
                of the given dimension.

        Returns:
            A dict mapping each mesh element tag to a tuple of its node tags.
            For example, a line element returns ``(node_i, node_j)`` and a
            triangle returns ``(node_i, node_j, node_k)``.
        """
        elementTypes, elementTags, nodeTags = gmsh_model.mesh.getElements(
            dimension.value, elTag
        )
        el_type_node_nb_map = {0: 1, 1: 2, 2: 3, 3: 4}  # node  # line  # tria  # quad
        connectivity = {}
        for t, tp_element in enumerate(elementTypes):
            node_nb = el_type_node_nb_map[tp_element]
            for i, tag in enumerate(elementTags[t]):
                node_list = []
                for n in range(node_nb):
                    node_list.append(nodeTags[t][i * node_nb + n])
                connectivity[tag] = tuple(node_list)
        return connectivity

    @staticmethod
    def framesConnectivity(frameTag: myInt64 = -1) -> Dict[Any, Tuple[Any, ...]]:
        """Return connectivity for 1D (frame/beam) mesh elements.

        Args:
            frameTag: GMSH entity tag to restrict the query to. -1 queries all
                1D entities.

        Returns:
            A dict mapping each frame mesh element tag to a 2-tuple of its
            node tags ``(node_i, node_j)``.
        """
        return FEModel._elementConnectivity(Dim.DIM_1D, frameTag)

    @staticmethod
    def platesConnectivity(plateTag: myInt64 = -1) -> Dict[Any, Tuple[Any, ...]]:
        """Return connectivity for 2D (plate/shell) mesh elements.

        Args:
            plateTag: GMSH entity tag to restrict the query to. -1 queries all
                2D entities.

        Returns:
            A dict mapping each plate mesh element tag to a tuple of its node
            tags (3 values for triangles, 4 for quads).
        """
        return FEModel._elementConnectivity(Dim.DIM_2D, plateTag)

    @staticmethod
    def nodeCoords(nodeTags: myInt64) -> Tuple[float, float, float]:
        """Return the (x, y, z) coordinates of a single mesh node.

        Args:
            nodeTags: Tag of the mesh node to query.

        Returns:
            A 3-tuple ``(x, y, z)`` with the node coordinates.
        """
        coord, _, _, _ = gmsh_model.mesh.getNode(nodeTags)
        return coord

    @staticmethod
    def elementsTags(dimension: Dim) -> List[myInt64]:
        """Return a flat list of all mesh element tags for a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query
                (e.g. ``Dim.DIM_1D`` for frames, ``Dim.DIM_2D`` for plates).

        Returns:
            A flat list of mesh element tags across all entities of the
            requested dimension.
        """
        ft = []
        entities = gmsh_model.getEntities(dimension.value)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            ft += list(elemTags[0])
        return ft

    @staticmethod
    def framesTags() -> List[myInt64]:
        """Return a flat list of all 1D (frame/beam) mesh element tags.

        Returns:
            A flat list of mesh element tags for every frame element in the model.
        """
        return FEModel.elementsTags(Dim.DIM_1D)

    @staticmethod
    def platesTags() -> List[myInt64]:
        """Return a flat list of all 2D (plate/shell) mesh element tags.

        Returns:
            A flat list of mesh element tags for every plate element in the model.
        """
        return FEModel.elementsTags(Dim.DIM_2D)

    @staticmethod
    def getFrameNodesFromMacro(
        macroTags: List[myInt64] | List[List[myInt64]] | None = None,
        unique: bool = False,
    ) -> (
        Dict[myInt64, List[Tuple[myInt64, myInt64]]]
        | List[Tuple[myInt64, myInt64]]
        | List[myInt64]
    ):
        """Return node-tag pairs for all mesh frames belonging to macro-elements.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more underlying mesh entities after meshing.

        Args:
            macroTags: Controls which macro-elements to query.

                * ``None`` or empty list — return the full connectivity dict
                  ``{macro_tag: [(n1, n2), ...]}``.
                * A flat ``List[myInt64]`` — return a flat list of
                  ``(node_i, node_j)`` pairs for those macro-elements.
                * A ``List[List[myInt64]]`` — lists are merged into a single
                  flat list before querying.

            unique: When *macroTags* is provided, if ``True`` return a flat
                deduplicated list of individual node tags instead of pairs.
                Default is ``False``.

        Returns:
            * Full dict ``{macro_tag: [(n1, n2), ...]}`` when no *macroTags* are given.
            * List of ``(node_i, node_j)`` tuples when *macroTags* are given and
              *unique* is ``False``.
            * Flat list of unique node tags when *macroTags* are given and
              *unique* is ``True``.
        """
        if macroTags is None:
            macroTags = []
        else:
            if isinstance(macroTags, list):
                if len(macroTags) == 0:
                    return []
                else:
                    if isinstance(macroTags[0], list):
                        u_lst: list[Any] = []
                        for m in macroTags:
                            assert isinstance(m, list)
                            u_lst.extend(m)
                        macroTags = u_lst
            else:
                macroTags = [macroTags]

        ft: Dict[myInt64, List[Tuple[myInt64, myInt64]]] = {}
        entities = gmsh_model.getEntities(1)
        unique_tags: Set[myInt64] = set()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            nt = []
            for a in elemNodeTags[0].reshape(round(len(elemNodeTags[0]) / 2), 2):
                nt += [tuple(a)]
            ft[tag] = nt

        if len(macroTags) == 0:
            return ft
        else:
            tags: List[Tuple[myInt64, myInt64]] = []
            assert isinstance(ft, dict)
            for i in macroTags:
                assert isinstance(i, np.int32)
                tags += ft[i]

            if unique:
                for n in tags:
                    unique_tags.add(n[0])
                    unique_tags.add(n[1])
                return list(unique_tags)

            return tags

    # @staticmethod
    # def _elementsNodeTags(dimension: Dim) -> List[List[myInt64]]:
    #     ft = []
    #     entities = gmsh_model.getEntities(dimension.value)
    #     for e in entities:
    #         # Dimension and tag of the entity:
    #         dim = e[0]
    #         tag = e[1]
    #         # Get the mesh nodes for the entity (dim, tag):
    #         elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
    #         nt = []
    #         for a in elemNodeTags[0].reshape(len(elemNodeTags[0]) // 2 , 2):
    #             nt += [list(a)]
    #         ft += nt
    #     return ft

    @staticmethod
    def _elementsNodeTags(dimension: Dim) -> List[List[myInt64]]:
        """Return node tags for every mesh element of a given dimension.

        Args:
            dimension: Spatial dimension of the elements to query.

        Returns:
            A list of lists, where each inner list contains the node tags of
            one mesh element (ordered as returned by GMSH).
        """
        ft = []
        element_node_dict = FEModel._elementConnectivity(dimension)
        for el in element_node_dict:
            ft.append(list(element_node_dict[el]))
        return ft

    @staticmethod
    def framesNodeTags() -> List[List[myInt64]]:
        """Return node tags for every 1D (frame/beam) mesh element.

        Returns:
            A list of 2-element lists ``[node_i, node_j]``, one per frame
            element, in the same order as :meth:`framesTags`.
        """
        return FEModel._elementsNodeTags(Dim.DIM_1D)

    @staticmethod
    def platesNodeTags() -> List[List[myInt64]]:
        """Return node tags for every 2D (plate/shell) mesh element.

        Returns:
            A list of 3- or 4-element lists of node tags, one per plate
            element, in the same order as :meth:`platesTags`.
        """
        return FEModel._elementsNodeTags(Dim.DIM_2D)

    @staticmethod
    def nodesCoords() -> List[List[float]]:
        """Return the coordinates of all mesh nodes in the model.

        Returns:
            A list of ``[x, y, z]`` coordinate lists, one per mesh node,
            across all entities and dimensions.
        """
        nc = []
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            nc += nodeCoords.reshape(round(len(nodeCoords) / 3), 3).tolist()
        return nc

    @staticmethod
    def nodesGroups() -> Dict[Any, List[int]]:
        """Return the physical groups associated with each 0D (point) entity.

        Returns:
            A dict mapping each point entity tag to the list of physical group
            tags it belongs to.
        """
        ng = {}
        entities = gmsh_model.getEntities(0)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            ng[tag] = list(gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        return ng

    @staticmethod
    def framesGroups():
        fg = {}
        entities = gmsh_model.getEntities(1)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            fg[tag] = list(gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        return fg

    @staticmethod
    def printNodes() -> None:
        """Print all mesh node tags, coordinates, and physical groups to stdout.

        Iterates over every entity in the model and prints the node tags,
        their coordinates, and the physical groups they belong to.
        Intended for debugging purposes.
        """
        print("** start Nodes **")
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            print("nodeTags", nodeTags)
            print("nodeCoords", nodeCoords)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        print("** end Nodes **")

    @staticmethod
    def printFrames() -> None:
        """Print all 1D mesh element types, tags, node tags, and physical groups to stdout.

        Iterates over every 1D entity in the model and prints element types,
        element tags, node tags per element, and the physical groups they belong to.
        Intended for debugging purposes.
        """
        print("** start Frames **")
        entities = gmsh_model.getEntities(1)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh elements for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            print("elemTypes", elemTypes)
            print("elemTags", elemTags)
            print("elemNodeTags", elemNodeTags)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))
        print("** end Frames **")

    @staticmethod
    def printElements() -> None:
        """Print all mesh element types, tags, node tags, and physical groups to stdout.

        Iterates over every entity in the model (all dimensions) and prints
        element types, element tags, node tags per element, and the physical
        groups they belong to. Intended for debugging purposes.
        """
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]

            # Get the mesh elements for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            print("elemTypes", elemTypes)
            print("elemTags", elemTags)
            print("elemNodeTags", elemNodeTags)
            print("phisicalGroup", gmsh_model.getPhysicalGroupsForEntity(dim, tag))

    @staticmethod
    def show() -> None:
        """Open the GMSH FLTK graphical interface to visualise the current model."""
        gmsh.fltk.run()

    def addMaterialToLibrary(
        self,
        idMaterial: int,
        modulus: float,  # Mpa
        poisson: float,  # ...
        name: str,
        density: float = 0.0,  # kg/mc
        thermal_expansion: float = 0.0,  # 1/C
        conductivity: float = 0.0,  # KJ/s/m/C
        specific_heat: float = 0.0,  # KJ/kg/C
    ) -> None:
        """Register a material in the model material library.

        Args:
            idMaterial: Unique integer identifier for the material.
            modulus: Young's modulus [MPa].
            poisson: Poisson's ratio [-].
            name: Human-readable material name.
            density: Mass density [kg/m³]. Default is 0.0.
            thermal_expansion: Coefficient of thermal expansion [1/°C]. Default is 0.0.
            conductivity: Thermal conductivity [kJ/s/m/°C]. Default is 0.0.
            specific_heat: Specific heat capacity [kJ/kg/°C]. Default is 0.0.
        """
        self.__materialLibrary[idMaterial] = FEMaterial(
            name=name,
            modulus=modulus,
            poisson=poisson,
            density=density,
            thermal_expansion=thermal_expansion,
            conductivity=conductivity,
            specific_heat=specific_heat,
        )

    def addSectionShape(
        self, idShape: int, name: str, tp: ShapesEnum, dim: Optional[List[float]] = None
    ) -> None:
        """Register a cross-section shape in the model section library.

        Args:
            idShape: Unique integer identifier for the section shape.
                Must not already exist in the library.
            name: Human-readable name for the section.
            tp: Cross-section type from :class:`ShapesEnum`.
                Currently only ``ShapesEnum.SHAPE_RECT`` is supported.
            dim: Dimensions of the cross-section as a list of floats.
                For ``SHAPE_RECT`` exactly 2 values are required:
                ``[width, height]``.

        Raises:
            EXAExceptions: If ``idShape`` is already in use, if ``idShape`` is
                not an ``int``, if ``tp`` is not a ``ShapesEnum``, if ``dim``
                contains non-float values, or if the dimension list length does
                not match the shape type requirements.
        """
        if dim is None:
            dim = []

        if idShape in self.__sectionShapes.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0007", "idShape for shape must be unique", idShape
            )

        if not isinstance(idShape, int):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "idShape must be a int", type(idShape)
            )

        if not isinstance(tp, ShapesEnum):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "tp must be a ShapesEnum", type(tp)
            )

        if not all(isinstance(n, float) for n in dim):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0009", "dim must be float list", type(dim)
            )
        # else:
        #     np.array(dim, dtype=np.float32)

        if tp == ShapesEnum.SHAPE_RECT:
            if len(dim) != 2:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0004",
                    "For *RECTANGULAR* dim must have a two dim array",
                    len(dim),
                )

            self.__sectionShapes[idShape] = ShapeRect(name=name, param=dim)

    def sectionShapes(self) -> Dict[int, SectionShape]:
        """Return the section-shape library.

        Returns:
            A dict mapping each section shape id to its :class:`SectionShape` instance.
        """
        return self.__sectionShapes

    def sectionMaterials(self) -> Dict[int, FEMaterial]:
        """Return the material library.

        Returns:
            A dict mapping each material id to its :class:`FEMaterial` instance.
        """
        return self.__materialLibrary

    @staticmethod
    def getFrameLocal3(tagFrame: myInt64) -> Vector3d:
        """Return the local axis-3 (longitudinal) unit vector of a frame element.

        Local axis 3 runs from the start node to the end node of the frame,
        following the same convention as Strand7.

        Args:
            tagFrame: Mesh tag of the frame element.

        Returns:
            Normalised :class:`Vector3d` aligned with the frame axis (N1 → N2).

        Raises:
            EXAExceptions: If *tagFrame* is not present in the mesh.
        """
        nodes = FEModel.framesConnectivity().get(tagFrame, None)
        if nodes is None:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "tagFrame is not present", type(tagFrame)
            )
        n1 = FEModel.nodeCoords(nodes[0])
        n2 = FEModel.nodeCoords(nodes[1])

        return Vector3d(Point3d(*n1), Point3d(*n2)).normalize()

    @staticmethod
    def getPlateLocal3(tagPlate: myInt64) -> Vector3d:
        """Return the local axis-3 (normal) unit vector of a plate element.

        Local axis 3 is the outward normal to the plate surface, computed as
        the cross product of the vectors (N1→N2) × (N2→N3), following the
        same convention as Strand7.

        Args:
            tagPlate: Mesh tag of the plate element.

        Returns:
            Normalised :class:`Vector3d` normal to the plate surface.

        Raises:
            EXAExceptions: If *tagPlate* is not present in the mesh.
        """
        nodes = FEModel.platesConnectivity().get(tagPlate, None)
        if nodes is None:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "tagPlate is not present", type(tagPlate)
            )
        # Plates have 3 or 4 nodes than only 3 nodes are sufficient
        n1 = FEModel.nodeCoords(nodes[0])
        n2 = FEModel.nodeCoords(nodes[1])
        n3 = FEModel.nodeCoords(nodes[2])
        v1 = Vector3d(Point3d(*n1), Point3d(*n2))
        v2 = Vector3d(Point3d(*n2), Point3d(*n3))
        return v1.cross(v2).normalize()

    def getPlateLocal1(self, tagPlate: myInt64) -> Vector3d:
        """Return the local axis-1 unit vector of a plate element.

        Returns the user-assigned axis-1 if one has been set via
        :meth:`assignPlateLocal1`; otherwise falls back to the default
        computed from node positions (see :meth:`__getPlateLocal1Default`).

        Args:
            tagPlate: Mesh tag of the plate element.

        Returns:
            Normalised :class:`Vector3d` for local axis 1.
        """
        if self.__platesLocal1.get(tagPlate) is None:
            return FEModel.__getPlateLocal1Default(tagPlate)
        ax = self.__platesLocal1.get(tagPlate)
        assert ax is not None
        return ax

    def getPlateLocal2(self, tagPlate: myInt64) -> Vector3d:
        """Return the local axis-2 unit vector of a plate element.

        Computed as ``local3 × local1``, completing the right-hand local
        coordinate system of the plate.

        Args:
            tagPlate: Mesh tag of the plate element.

        Returns:
            Normalised :class:`Vector3d` for local axis 2.
        """
        return self.getPlateLocal3(tagPlate).cross(self.getPlateLocal1(tagPlate))

    @staticmethod
    def __getPlateLocal1Default(tagPlate: myInt64) -> Vector3d:
        """Compute the default local axis-1 direction for a plate element.

        For a triangle (nodes N1, N2, N3) axis 1 goes from N1 toward the
        midpoint of side N2–N3. For a quad (nodes N1, N2, N3, N4) it goes
        from the midpoint of side N1–N4 to the midpoint of side N2–N3.
        This matches the Strand7 convention described in :meth:`__init__`.

        Args:
            tagPlate: Mesh tag of the plate element.

        Returns:
            Normalised :class:`Vector3d` for the default local axis 1.

        Raises:
            EXAExceptions: If *tagPlate* is not in the mesh or the element has
                an unsupported number of nodes.
        """
        nodes = FEModel.platesConnectivity().get(tagPlate, None)
        if nodes is None:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "tagPlate is not present", type(tagPlate)
            )
        assert isinstance(nodes, list) and nodes is not None
        p1 = Point3d(*FEModel.nodeCoords(nodes[0]))
        p2 = Point3d(*FEModel.nodeCoords(nodes[1]))
        p3 = Point3d(*FEModel.nodeCoords(nodes[2]))
        m2 = p2.midpoint(p3)
        if len(nodes) == 3:
            return Vector3d(p1, m2).normalize()
        elif len(nodes) == 4:
            p4 = Point3d(*FEModel.nodeCoords(nodes[3]))
            m1 = p1.midpoint(p4)
            return Vector3d(m1, m2).normalize()
        else:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "len(nodes) must be 3 or 4", len(nodes)
            )

    @staticmethod
    def __getFrameLocal2Default(tagFrame: myInt64) -> Vector3d:
        """Compute the default local axis-2 direction for a frame element.

        When the frame is parallel to the global Z axis, axis 2 is set to the
        positive global Y direction. Otherwise axis 2 is computed as
        ``Z_global × local3``. This matches the Strand7 convention described
        in :meth:`__init__`.

        Args:
            tagFrame: Mesh tag of the frame element.

        Returns:
            Normalised :class:`Vector3d` for the default local axis 2.
        """
        local_3 = FEModel.getFrameLocal3(tagFrame)
        if local_3.cross(Vector3d(0.0, 0.0, 1.0)).norm() < 1e-16:
            return Vector3d(0.0, 1.0, 0.0)

        return Vector3d(0.0, 0.0, 1.0).cross(local_3)

    def getFrameLocal2(self, tagFrame: myInt64) -> Vector3d:
        """Return the local axis-2 unit vector of a frame element.

        Returns the user-assigned axis-2 if one has been set via
        :meth:`assignFrameLocal2`; otherwise falls back to the default
        computed from the frame orientation (see :meth:`__getFrameLocal2Default`).

        Args:
            tagFrame: Mesh tag of the frame element.

        Returns:
            Normalised :class:`Vector3d` for local axis 2.
        """
        if self.__framesLocal2.get(tagFrame) is None:
            return FEModel.__getFrameLocal2Default(tagFrame)
        ax = self.__framesLocal2.get(tagFrame)
        assert ax is not None
        return ax

    def getFrameLocal1(self, tagFrame: myInt64) -> Vector3d:
        """Return the local axis-1 unit vector of a frame element.

        Computed as ``local2 × local3``, completing the right-hand local
        coordinate system of the frame.

        Args:
            tagFrame: Mesh tag of the frame element.

        Returns:
            Normalised :class:`Vector3d` for local axis 1.
        """
        return self.getFrameLocal2(tagFrame).cross(FEModel.getFrameLocal3(tagFrame))

    def assignPlateLocal1(self, tagPlate: myInt64, axis: Vector3d) -> None:
        """Assign a custom local axis-1 direction to a single plate element.

        The supplied *axis* is projected onto the plate surface (i.e.
        orthogonalised against local axis 3) before being stored, so the
        resulting axis-1 always lies in the plane of the plate.

        Args:
            tagPlate: Mesh tag of the plate element.
            axis: Desired local axis-1 direction as a :class:`Vector3d`.
                Must not be parallel to the plate normal (local axis 3).

        Raises:
            EXAExceptions: If *tagPlate* is not an accepted integer type, if
                *axis* is not a :class:`Vector3d`, or if *axis* is parallel to
                the plate normal.
        """
        if not isinstance(tagPlate, (int, np.uint64, np.int32)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagPlate must be a int, np.uint64 or np.int32",
                type(tagPlate),
            )
        if not isinstance(axis, Vector3d):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "axis must be a Vector3d instance !!!",
                type(axis),
            )
        if FEModel.getFrameLocal3(tagPlate).cross(axis).norm() == 0.0:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "axis must not null and not parallel to local axis 3 !!!",
            )
        axis_3 = FEModel.getPlateLocal3(tagPlate)
        tmp_axis = axis_3.cross(axis).normalize()

        self.__platesLocal1[tagPlate] = axis_3.cross(tmp_axis).normalize()

    def assignMultiPlateLocal1(
        self,
        axis: Vector3d,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsPlate: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a custom local axis-1 direction to multiple plate elements.

        Exactly one of *tagsMacro* or *tagsPlate* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        plate elements that belong to those macro-elements (geometric objects).

        Args:
            axis: Desired local axis-1 direction as a :class:`Vector3d`.
            tagsMacro: List of macro-element tags whose mesh plates are targeted.
            tagsPlate: List of individual mesh plate element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsPlate* are provided,
                or if any individual assignment fails (see :meth:`assignPlateLocal1`).
        """
        FEModel._assignMultiElement(
            Dim.DIM_2D, self.assignPlateLocal1, axis, tagsMacro, tagsPlate
        )

    def assignMultiPlateMaterial(
        self,
        idMaterial: int,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsPlate: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a material to multiple plate elements.

        Exactly one of *tagsMacro* or *tagsPlate* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        plate elements that belong to those macro-elements (geometric objects).

        Args:
            idMaterial: Material id as registered in the material library.
            tagsMacro: List of macro-element tags whose mesh plates are targeted.
            tagsPlate: List of individual mesh plate element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsPlate* are provided,
                or if any individual assignment fails (see :meth:`assignPlateMaterial`).
        """
        FEModel._assignMultiElement(
            Dim.DIM_2D, self.assignPlateMaterial, idMaterial, tagsMacro, tagsPlate
        )

    def assignMultiPlateThicknesses(
        self,
        thicknesses: tuple[float, float],
        tagsMacro: Optional[List[myInt64]] = None,
        tagsPlate: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign bending and membrane thicknesses to multiple plate elements.

        Exactly one of *tagsMacro* or *tagsPlate* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        plate elements that belong to those macro-elements (geometric objects).

        Args:
            thicknesses: A 2-tuple ``(bending_thickness, membrane_thickness)``
                in model length units.
            tagsMacro: List of macro-element tags whose mesh plates are targeted.
            tagsPlate: List of individual mesh plate element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsPlate* are provided,
                or if any individual assignment fails (see :meth:`assignPlateThicknesses`).
        """
        FEModel._assignMultiElement(
            Dim.DIM_2D, self.assignPlateMaterial, thicknesses, tagsMacro, tagsPlate
        )

    def assignFrameLocal2(self, tagFrame: myInt64, axis: Vector3d) -> None:
        """Assign a custom local axis-2 direction to a single frame element.

        The supplied *axis* is orthogonalised against the frame's local axis 3
        (the longitudinal direction) before being stored, so the resulting
        axis-2 is always perpendicular to the frame axis.

        Args:
            tagFrame: Mesh tag of the frame element.
            axis: Desired local axis-2 direction as a :class:`Vector3d`.
                Must not be parallel to the frame axis (local axis 3).

        Raises:
            EXAExceptions: If *tagFrame* is not an accepted integer type, if
                *axis* is not a :class:`Vector3d`, or if *axis* is parallel to
                the frame axis.
        """
        if not isinstance(tagFrame, (int, np.uint64, np.int32)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagFrame must be a int, np.uint64 or np.int32",
                type(tagFrame),
            )
        if not isinstance(axis, Vector3d):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "axis must be a Vector3d instance !!!",
                type(tagFrame),
            )
        if FEModel.getFrameLocal3(tagFrame).cross(axis).norm() == 0.0:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "axis must not null and not parallel to local axis 3 !!!",
                type(tagFrame),
            )
        axis_3 = FEModel.getFrameLocal3(tagFrame)
        tmp_axis = axis.cross(axis_3).normalize()

        self.__framesLocal2[tagFrame] = axis_3.cross(tmp_axis).normalize()

    def assignMultiFrameLocal2(
        self,
        axis: Vector3d,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsFrames: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a custom local axis-2 direction to multiple frame elements.

        Exactly one of *tagsMacro* or *tagsFrames* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        frame elements that belong to those macro-elements (geometric objects).

        Args:
            axis: Desired local axis-2 direction as a :class:`Vector3d`.
            tagsMacro: List of macro-element tags whose mesh frames are targeted.
            tagsFrames: List of individual mesh frame element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsFrames* are provided,
                or if any individual assignment fails (see :meth:`assignFrameLocal2`).
        """
        FEModel._assignMultiElement(
            Dim.DIM_1D, self.assignFrameLocal2, axis, tagsMacro, tagsFrames
        )

    def __check_material_assign(self, tagElement: myInt64, idMaterial: int) -> None:
        """Validate arguments before assigning a material to an element.

        Args:
            tagElement: Mesh element tag (must be ``numpy.uint64``).
            idMaterial: Material id to validate against the material library.

        Raises:
            EXAExceptions: If *tagElement* is not ``numpy.uint64``, if
                *idMaterial* is not an ``int``, or if *idMaterial* is not
                present in the material library.
        """
        if not isinstance(tagElement, np.uint64):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagElement must be a int, nsignedinteger[_64Bit] or nsignedinteger[_32Bit]",
                type(tagElement),
            )

        if not isinstance(idMaterial, int):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "idMaterial must be a int",
                type(idMaterial),
            )

        if idMaterial not in self.__materialLibrary.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "idMaterial unknown in materialLibrary table",
                idMaterial,
            )

    def assignFrameSectionShape(self, tagFrame: myInt64, idShape: int) -> None:
        """Assign a cross-section shape to a single frame element.

        Args:
            tagFrame: Mesh tag of the frame element.
            idShape: Section shape id as registered in the section library.

        Raises:
            EXAExceptions: If *tagFrame* is not an accepted integer type, if
                *idShape* is not an ``int``, or if *idShape* is not present in
                the section library.
        """
        if not isinstance(tagFrame, (int, np.uint64, np.int32)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagFrame must be a int, np.uint64 or np.int32",
                type(tagFrame),
            )

        if not isinstance(idShape, int):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "idShape must be a int", type(idShape)
            )

        if idShape not in self.__sectionShapes.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "idShape unknown in sectionShapes table",
                idShape,
            )

        self.__framesShapes[tagFrame] = idShape

    def assignFrameMaterial(self, tagFrame: myInt64, idMaterial: int) -> None:
        """Assign a material to a single frame element.

        Args:
            tagFrame: Mesh tag of the frame element.
            idMaterial: Material id as registered in the material library.

        Raises:
            EXAExceptions: See :meth:`__check_material_assign` for validation details.
        """
        self.__check_material_assign(tagFrame, idMaterial)
        self.__framesMaterial[tagFrame] = idMaterial

    def assignPlateMaterial(self, tagPlate: myInt64, idMaterial: int) -> None:
        """Assign a material to a single plate element.

        Args:
            tagPlate: Mesh tag of the plate element.
            idMaterial: Material id as registered in the material library.

        Raises:
            EXAExceptions: See :meth:`__check_material_assign` for validation details.
        """
        self.__check_material_assign(tagPlate, idMaterial)
        self.__platesMaterial[tagPlate] = idMaterial

    def assignPlateThicknesses(
        self, tagPlate: myInt64, thicknesses: tuple[float, float]
    ) -> None:
        """Assign bending and membrane thicknesses to a single plate element.

        Args:
            tagPlate: Mesh tag of the plate element.
            thicknesses: A 2-tuple ``(bending_thickness, membrane_thickness)``
                in model length units. Both values must be floats.

        Raises:
            EXAExceptions: If *tagPlate* is not an accepted integer type, if
                *thicknesses* is not a 2-tuple, or if either value is not a float.
        """
        if not isinstance(tagPlate, (int, np.uint64, np.int32)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagPlate must be a int, np.uint64 or np.int32",
                type(tagPlate),
            )

        if not isinstance(thicknesses, tuple):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "thicknesses must be tuple",
                type(thicknesses),
            )

        if not len(thicknesses) == 2:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "len(thicknesses) must be tuple with len = 2",
                len(thicknesses),
            )

        if not isinstance(thicknesses[0], float) or not isinstance(
            thicknesses[0], float
        ):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "thicknesses must be tuple only of floats",
                len(thicknesses),
            )

        self.__platesThicknesses[tagPlate] = thicknesses

    def assignPlateFaceSupport(
        self, tagPlate: myInt64, support: PlateFaceSupport
    ) -> None:
        """Assign a face (Winkler-type) support to a single plate element.

        A face support models a distributed elastic foundation acting on the
        plate surface, defined by normal and lateral subgrade stiffnesses.

        Args:
            tagPlate: Mesh tag of the plate element.
            support: A :class:`PlateFaceSupport` instance describing the
                foundation stiffness properties.

        Raises:
            EXAExceptions: If *tagPlate* is not an accepted integer type or if
                *support* is not a :class:`PlateFaceSupport` instance.
        """
        if not isinstance(tagPlate, (int, np.uint64, np.int32)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagPlate must be a int, np.uint64 or np.int32",
                type(tagPlate),
            )

        if not isinstance(support, PlateFaceSupport):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "support must a PlateFaceSupport instance",
                type(PlateFaceSupport),
            )

        self.__platesFaceSupports[tagPlate] = support

    def assignMultiPlateFaceSupport(
        self,
        support: PlateFaceSupport,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsPlate: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a face support to multiple plate elements.

        Exactly one of *tagsMacro* or *tagsPlate* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        plate elements that belong to those macro-elements (geometric objects).

        Args:
            support: A :class:`PlateFaceSupport` instance describing the
                foundation stiffness properties.
            tagsMacro: List of macro-element tags whose mesh plates are targeted.
            tagsPlate: List of individual mesh plate element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsPlate* are provided,
                or if any individual assignment fails (see :meth:`assignPlateFaceSupport`).
        """
        FEModel._assignMultiElement(
            Dim.DIM_2D, self.assignPlateFaceSupport, support, tagsMacro, tagsPlate
        )

    def assignFrameWinklerSupport(
        self, tagFrame: myInt64, winkler_supports: Tuple[float, float, bool]
    ) -> None:
        """Assign a Winkler-type distributed support to a single frame element.

        Unlike :meth:`addMultiFrameWinklerSpring`, which converts the subgrade
        modulus into equivalent nodal springs, this method stores the support
        parameters directly on the frame element for later export (e.g. to the
        solver template). The support is treated as evenly distributed along
        the frame length.

        Args:
            tagFrame: Mesh tag of the frame element.
            winkler_supports: A 3-tuple
                ``(stiffness_local_dir1, stiffness_local_dir2, only_compression)``
                where the stiffnesses are in force/length² units and
                *only_compression* restricts the support to compressive contact only.
        """
        self.__framesSprings[tagFrame] = winkler_supports

    def getNodeTemperatures(self) -> Dict[str, Dict[int, Dict[str, float]]]:
        """Return the node temperature assignments.

        Returns:
            Nested dict structured as
            ``{load_case: {node_tag: {temperature_type: value}}}``.
            Temperature types are ``"fixed"``, ``"reference"``, or ``"initial"``.
        """
        return self.__nodeTemperatures

    def getFrameTemperatures(self) -> Dict[str, Dict[int, Dict[str, Tuple[float, float]]]]:
        """Return the frame temperature (gradient) assignments.

        Returns:
            Nested dict structured as
            ``{load_case: {frame_tag: {temperature_type: (value_i, value_j)}}}``.
            Currently only the ``"gradient"`` temperature type is supported.
        """
        return self.__frameTemperatures

    def getInitialTemperatures(self) -> Dict[str, float]:
        """Return the uniform initial temperature assigned to each load case.

        Returns:
            A dict mapping each load case id to its initial (reference)
            temperature value.
        """
        return self.__initialTemperatures

    def getInertialAcceleration(self) -> Dict[str, Tuple[float, float, float]]:
        """Return the inertial acceleration (body-force) assigned to each load case.

        Returns:
            A dict mapping each load case id to its acceleration vector
            ``(ax, ay, az)`` in model units.
        """
        return self.__inertialAcceleration

    def setInertialAcceleration(
        self, loadCase: str, acc: Tuple[float, float, float]
    ) -> None:
        """Set the inertial (body-force) acceleration for a load case.

        Args:
            loadCase: Id of an existing load case.
            acc: Acceleration vector ``(ax, ay, az)`` in model units.
                Must be a 3-tuple of floats.

        Raises:
            EXAExceptions: If *loadCase* is not a string, if *loadCase* is
                unknown, if *acc* is not a tuple, or if its length is not 3.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018",
                "loadCase arg must be a string",
                type(loadCase),
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0019", "loadCase case unknown", loadCase
            )

        if not isinstance(acc, tuple):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "acc must be float tuple", type(acc)
            )

        if len(acc) != 3:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "acc must have len = 3", len(acc)
            )
        self.__inertialAcceleration[loadCase] = acc

    def setInitialTemperature(self, loadCase: str, temp: float) -> None:
        """Set the uniform initial (reference) temperature for a load case.

        Args:
            loadCase: Id of an existing load case.
            temp: Initial temperature value in degrees Celsius.

        Raises:
            EXAExceptions: If *loadCase* is not a string, if *loadCase* is
                unknown, or if *temp* is not a float.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018",
                "First arg must be a string",
                type(loadCase),
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0019", "Load case unknown", loadCase
            )

        if not isinstance(temp, float):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "temp must be float list", type(temp)
            )

        self.__initialTemperatures[loadCase] = temp

    def assignNodeTemperature(
        self,
        loadCase: str,
        tagNode: int,
        temp: float,
        tpTemp: Literal["fixed", "reference", "initial"] = "fixed",
    ) -> None:
        """Assign a temperature value to a single mesh node for a given load case.

        Args:
            loadCase: Id of an existing load case.
            tagNode: Mesh tag of the target node.
            temp: Temperature value in degrees Celsius.
            tpTemp: Type of temperature assignment. One of:

                * ``"fixed"`` — node temperature is imposed (default).
                * ``"reference"`` — used as reference for thermal strain.
                * ``"initial"`` — initial condition temperature.

        Raises:
            EXAExceptions: If *loadCase* is not a string, if *loadCase* is
                unknown, if *tagNode* is not in the mesh, if *temp* is not a
                float, or if *tpTemp* is not a string.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018",
                "First arg must be a string",
                type(loadCase),
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0019", "Load case unknown", loadCase
            )

        if tagNode not in self.nodesTags():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0020", "Nodes tag unknown", tagNode
            )

        if not isinstance(temp, float):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "temp must be float list", type(temp)
            )

        if not isinstance(tpTemp, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "tpTemp must be str", type(tpTemp)
            )

        if loadCase not in self.__nodeTemperatures:
            self.__nodeTemperatures[loadCase] = {}

        if tagNode not in self.__nodeTemperatures[loadCase]:
            self.__nodeTemperatures[loadCase][tagNode] = {}

        self.__nodeTemperatures[loadCase][tagNode][tpTemp] = temp

    def assignFrameTemperature(
        self,
        loadCase: str,
        tagFrame: int,
        temp: Tuple[float, float],
        tpTemp: Literal["gradient"] = "gradient",
    ) -> None:
        """Assign a temperature gradient to a single frame element for a given load case.

        Args:
            loadCase: Id of an existing load case.
            tagFrame: Mesh tag of the target frame element.
            temp: Temperature pair ``(temp_top, temp_bottom)`` in degrees Celsius,
                representing the gradient across the section depth.
            tpTemp: Type of temperature assignment. Currently only
                ``"gradient"`` is supported.

        Raises:
            EXAExceptions: If *loadCase* is not a string, if *loadCase* is
                unknown, if *tagFrame* is not in the mesh, if *tpTemp* is not
                a valid type, or if *temp* is not a 2-tuple.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018",
                "First arg must be a string",
                type(loadCase),
            )

        if loadCase not in self.__loadCase:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0019", "loadCase unknown", loadCase
            )

        if tagFrame not in self.framesTags():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0013", "tagFrame unknown", tagFrame
            )

        if not isinstance(tpTemp, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0014", "tpTemp arg must be a string", type(tpTemp)
            )

        if tpTemp not in ["gradient"]:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0014",
                f"tpTemp arg not in {['gradient']}",
                type(tpTemp),
            )

        if not isinstance(temp, tuple):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0014", "temp arg must be a tuple", type(temp)
            )

        if len(temp) != 2:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0014", "temp arg must have len=2", len(temp)
            )

        if loadCase not in self.__frameTemperatures:
            self.__frameTemperatures[loadCase] = {}

        if tagFrame not in self.__frameTemperatures[loadCase]:
            self.__frameTemperatures[loadCase][tagFrame] = {}

        self.__frameTemperatures[loadCase][tagFrame][tpTemp] = temp

    def assignMultiFrameWinklerSupport(
        self,
        winkler_supports: Tuple[float, float, bool],
        tagsMacro: Optional[List[myInt64]] = None,
        tagsFrames: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a Winkler-type distributed support to multiple frame elements.

        Exactly one of *tagsMacro* or *tagsFrames* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        frame elements that belong to those macro-elements (geometric objects).

        Args:
            winkler_supports: A 3-tuple
                ``(stiffness_local_dir1, stiffness_local_dir2, only_compression)``
                (see :meth:`assignFrameWinklerSupport` for details).
            tagsMacro: List of macro-element tags whose mesh frames are targeted.
            tagsFrames: List of individual mesh frame element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsFrames* are provided.
        """
        FEModel._assignMultiElement(
            Dim.DIM_1D,
            self.assignFrameWinklerSupport,
            winkler_supports,
            tagsMacro,
            tagsFrames,
        )

    def frameSectionShape(self) -> Dict[myInt64, int]:
        """Return the section-shape assignment for frame elements.

        Returns:
            A dict mapping each frame mesh element tag to its section shape id.
        """
        return self.__framesShapes

    def frameMaterial(self) -> Dict[myInt64, int]:
        """Return the material assignment for frame elements.

        Returns:
            A dict mapping each frame mesh element tag to its material id.
        """
        return self.__framesMaterial

    def plateMaterial(self) -> Dict[myInt64, int]:
        """Return the material assignment for plate elements.

        Returns:
            A dict mapping each plate mesh element tag to its material id.
        """
        return self.__platesMaterial

    def plateThicknesses(self) -> Dict[myInt64, Tuple[float, float]]:
        """Return the thickness assignment for plate elements.

        Returns:
            A dict mapping each plate mesh element tag to a 2-tuple
            ``(bending_thickness, membrane_thickness)``.
        """
        return self.__platesThicknesses

    @staticmethod
    def _assignMultiElement(
        dimension: Dim,
        assign_fn: Callable[[Any, Any], None],
        assign_value: Any,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsElement: Optional[List[myInt64]] = None,
    ) -> None:
        """Apply a single-element assignment function to a collection of elements.

        This is the shared implementation used by all ``assignMulti*`` methods.
        Exactly one of *tagsMacro* or *tagsElement* must be non-empty.

        When *tagsMacro* is provided, the helper resolves each macro-element
        (geometric object) to its set of mesh elements for the given
        *dimension* and calls *assign_fn* for each one.

        Args:
            dimension: Spatial dimension of the elements
                (``Dim.DIM_1D`` for frames, ``Dim.DIM_2D`` for plates).
            assign_fn: Callable with signature
                ``assign_fn(element_tag, assign_value) -> None``.
            assign_value: The value to pass as the second argument to
                *assign_fn* for every targeted element.
            tagsMacro: List of macro-element (geometric entity) tags.
                Mutually exclusive with *tagsElement*.
            tagsElement: List of individual mesh element tags.
                Mutually exclusive with *tagsMacro*.

        Raises:
            EXAExceptions: If both lists are non-empty or both are empty.
        """
        if tagsMacro is None:
            tagsMacro = []
        if tagsElement is None:
            tagsElement = []

        assert tagsMacro is not None
        assert isinstance(tagsMacro, list)

        assert tagsElement is not None
        assert isinstance(tagsElement, list)

        if len(tagsMacro) == 0 and len(tagsElement) == 0:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagsMacro or tagsFrames must be null",
                len(tagsMacro),
            )

        if len(tagsMacro) != 0 and len(tagsElement) != 0:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004",
                "tagsMacro or tagsFrames must be not null",
                len(tagsMacro),
            )

        if len(tagsMacro) != 0:
            elementsTags = FEModel._getElementsFromMacroTags(dimension)
            assert isinstance(elementsTags, dict)
            for tag in tagsMacro:
                for t in elementsTags[tag]:
                    assign_fn(t, assign_value)
        else:
            for t in tagsElement:
                assign_fn(t, assign_value)

    def assignMultiFrameSectionShape(
        self,
        idShape: int,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsFrames: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a cross-section shape to multiple frame elements.

        Exactly one of *tagsMacro* or *tagsFrames* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        frame elements that belong to those macro-elements (geometric objects).

        Args:
            idShape: Section shape id as registered in the section library.
            tagsMacro: List of macro-element tags whose mesh frames are targeted.
            tagsFrames: List of individual mesh frame element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsFrames* are provided,
                or if any individual assignment fails (see :meth:`assignFrameSectionShape`).
        """
        self._assignMultiElement(
            Dim.DIM_1D, self.assignFrameSectionShape, idShape, tagsMacro, tagsFrames
        )

    def assignMultiFrameMaterial(
        self,
        idMaterial: int,
        tagsMacro: Optional[List[myInt64]] = None,
        tagsFrames: Optional[List[myInt64]] = None,
    ) -> None:
        """Assign a material to multiple frame elements.

        Exactly one of *tagsMacro* or *tagsFrames* must be non-empty.
        When *tagsMacro* is provided, the assignment is applied to all mesh
        frame elements that belong to those macro-elements (geometric objects).

        Args:
            idMaterial: Material id as registered in the material library.
            tagsMacro: List of macro-element tags whose mesh frames are targeted.
            tagsFrames: List of individual mesh frame element tags to target directly.

        Raises:
            EXAExceptions: If both or neither of *tagsMacro*/*tagsFrames* are provided,
                or if any individual assignment fails (see :meth:`assignFrameMaterial`).
        """
        self._assignMultiElement(
            Dim.DIM_1D, self.assignFrameMaterial, idMaterial, tagsMacro, tagsFrames
        )

    @staticmethod
    def clear() -> None:
        """Clear all GMSH data and finalise the GMSH session.

        Calls ``gmsh.clear()`` to remove all models and then ``gmsh.finalize()``
        to shut down the library. The :class:`FEModel` instance should not be
        used after this call.
        """
        gmsh.clear()
        gmsh.finalize()

    @staticmethod
    def nodesTags() -> List[myInt64]:
        """Return a flat list of all mesh node tags in the model.

        Returns:
            A flat list of node tags across all entities and dimensions.
        """
        nt = []
        entities = gmsh_model.getEntities()
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            nodeTags, nodeCoords, nodeParams = gmsh.model.mesh.getNodes(dim, tag)
            nt += list(nodeTags)
        return nt

    @staticmethod
    def _getElementsFromMacroTags(
        dimension: Dim,
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Resolve macro-element tags to their underlying mesh element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            dimension: Spatial dimension of the elements to query.
            macroTags: If ``None`` or empty, return the full mapping dict
                ``{macro_tag: [mesh_tag, ...]}``.  If a non-empty list of
                macro-element tags, return a flat list of all their mesh tags.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh element tags for the specified macro-elements.

        Raises:
            EXAExceptions: If *macroTags* is not a list.
        """
        if (macroTags is not None) and (not isinstance(macroTags, list)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0002",
                "First arg must be a string",
                type(macroTags),
            )

        if macroTags is None:
            macroTags = []

        ft: Dict[myInt64, List[myInt64]] = {}
        entities = gmsh_model.getEntities(dimension.value)
        for e in entities:
            # Dimension and tag of the entity:
            dim = e[0]
            tag = e[1]
            # Get the mesh nodes for the entity (dim, tag):
            elemTypes, elemTags, elemNodeTags = gmsh.model.mesh.getElements(dim, tag)
            ft[tag] = list(elemTags[0])

        assert isinstance(macroTags, list)
        if len(macroTags) == 0:
            return ft
        else:
            tags = []
            for i in macroTags:
                tags += ft[i]
            return tags

    @staticmethod
    def getPlatesFromMacroTags(
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Retrieve mesh plate element tags from macro-element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            macroTags: If ``None`` or empty, return a dict mapping every
                2D macro-element tag to its list of mesh plate tags.
                If a non-empty list, return a flat list of mesh plate tags
                for those macro-elements only.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh plate tags for the specified macro-elements.
        """
        return FEModel._getElementsFromMacroTags(Dim.DIM_2D, macroTags)

    @staticmethod
    def getFramesFromMacroTags(
        macroTags: List[myInt64] | None = None,
    ) -> Dict[myInt64, List[myInt64]] | List[myInt64]:
        """Retrieve mesh frame element tags from macro-element tags.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            macroTags: If ``None`` or empty, return a dict mapping every
                1D macro-element tag to its list of mesh frame tags.
                If a non-empty list, return a flat list of mesh frame tags
                for those macro-elements only.

        Returns:
            * Full dict ``{macro_tag: [mesh_tag, ...]}`` when *macroTags* is empty.
            * Flat list of mesh frame tags for the specified macro-elements.
        """
        return FEModel._getElementsFromMacroTags(Dim.DIM_1D, macroTags)

    def framesSupports(self) -> Dict[myInt64, Tuple[float, float, bool]]:
        """Return the Winkler support assignment for frame elements.

        Returns:
            A dict mapping each frame mesh element tag to its Winkler support
            tuple ``(stiffness_local_dir1, stiffness_local_dir2, only_compression)``.
        """
        return self.__framesSprings

    # llp: load combination list is related to load case. Order is the same. Starting from Python 3.6
    #      dictionaries hold ordee also. Then self.__loads even dict is ordered

    def addLoadCombination(self, keyCombination: str, combination: List[float]) -> None:
        """Register a load combination.

        The combination coefficients must appear in the same order as the load
        cases were added (Python dicts preserve insertion order from 3.7+).

        Args:
            keyCombination: Unique string identifier for the combination.
            combination: List of scale factors, one per load case in insertion order.
        """
        self.__loadCombinations[keyCombination] = combination

    def getLoadCombinations(self) -> Dict[str, List[float]]:
        """Return all registered load combinations.

        Returns:
            A dict mapping each combination id to its list of scale factors.
        """
        return self.__loadCombinations

    def addLoadCase(self, idCase: str, tp: str = "U", descr: str = "") -> None:
        """Register a new load case.

        Args:
            idCase: Unique string identifier for the load case.
            tp: Load case type code from ``configData["LoadCaseType"]``
                (e.g. ``"D"`` for Dead Load, ``"L"`` for Live Load,
                ``"W"`` for Wind, ``"E"`` for Earthquake).
                Default is ``"U"`` (User Defined).
            descr: Optional human-readable description.

        Raises:
            EXAExceptions: If *idCase* or *tp* are not strings, if *tp* is not
                a known type code, or if *idCase* already exists.
        """
        if not isinstance(idCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0002", "First arg must be a string", idCase
            )
        if not isinstance(tp, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0003", "Second arg must be a string", tp
            )
        else:
            find = False
            for v in self.configData["LoadCaseType"]:
                if v["id"] == tp:
                    find = True
                    print(
                        "Type *{}* of load case generic *{}*: {} ---> {}".format(
                            idCase, v["id"], v["description"], descr
                        )
                    )
                    break
            if not find:
                raise Ex.EXAExceptions("(EXAStructuralModel)-0005", "Type unknown", tp)

        if not isinstance(tp, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0004", "Third arg must be a string", descr
            )

        if idCase in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0006", "Load case must be unique", idCase
            )

        self.__loadCase[idCase] = (tp, descr)

    def getLoadCases(self) -> Dict[str, Tuple[str, str]]:
        """Return all registered load cases.

        Returns:
            A dict mapping each load case id to a tuple ``(type_code, description)``.
        """
        return self.__loadCase

    def getLoads(self) -> Dict[str, Dict[LoadType, Any]]:
        """Return all load data organised by load case.

        Returns:
            Nested dict structured as
            ``{load_case_id: {LoadType: load_data}}``.
        """
        return self.__loads

    def addSelfWeight(self, loadCase: str, GCS: List[float]) -> None:
        """Add a self-weight (gravity) load to a load case.

        Args:
            loadCase: Id of an existing load case.
            GCS: Global Coordinate System multipliers ``[Gx, Gy, Gz]``.
                Each value scales the gravitational acceleration in that global
                direction (e.g. ``[0.0, 0.0, -1.0]`` applies 1 g downward).
                All values must be floats and the list must have length 3.

        Raises:
            EXAExceptions: If *loadCase* is not a string, if *loadCase* is
                unknown, if *GCS* contains non-float values, or if its length
                is not 3.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0007", "First arg must be a string", loadCase
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0008", "Load case unknown", loadCase
            )

        if not all(isinstance(n, float) for n in GCS):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0009", "GCS must be float list", GCS
            )

        if len(GCS) != 3:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0010", "GCS must have len 3", len(GCS)
            )

        if loadCase not in self.__loads:
            self.__loads[loadCase] = {}

        self.__loads[loadCase][LoadType.SELF_WEIGHT] = GCS

    def addMultiFrameWinklerSpring(
        self,
        tagsMacro: List[myInt64],
        tp: NodalSpringsTp,
        dirSprings: NodalSpringsDir,
        subgradeModulus: float,
        Bref: int,
    ) -> None:
        """Convert a Winkler subgrade modulus into nodal springs for multiple frame macro-elements.

        For each mesh frame element belonging to the specified macro-elements,
        the tributary length is computed and the equivalent nodal spring
        stiffness is distributed equally to the two end nodes.

        Unlike :meth:`assignFrameWinklerSupport`, which stores the support
        parameters directly on the frame, this method immediately creates
        nodal springs by calling :meth:`addNodeSpring` on each node.

        Args:
            tagsMacro: List of macro-element tags whose mesh frames are processed.
            tp: Spring behaviour type (``LINEAR``, ``COMP``, or ``TENS``).
            dirSprings: Global direction of the spring (e.g. ``DZ+``).
            subgradeModulus: Winkler subgrade modulus [force/length³].
            Bref: Reference width used to convert the modulus to a linear
                stiffness per unit length [length].

        Raises:
            EXAExceptions: If *tagsMacro* is not a list.
        """
        # subgradeModulus: modulo di sottofondo alla Winkler
        # Bref: largezza di riferimento per il calcolo della pressione

        if not isinstance(tagsMacro, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0011", "tagsMacro must be a list", type(tagsMacro)
            )

        nodesTags = self.nodesTags()
        nodesCoords = self.nodesCoords()
        framesTags = self.getFramesFromMacroTags()
        assert isinstance(framesTags, dict)
        frameNodes = self.getFrameNodesFromMacro()
        assert isinstance(frameNodes, dict)

        for tag in tagsMacro:
            # TODO: move this in separate function for subFrames (meshed frames) and add tagsFrames
            #       in function args with two cases
            for i, _t in enumerate(framesTags[tag]):
                n1 = frameNodes[tag][i][0]
                n2 = frameNodes[tag][i][1]
                n1_coords = nodesCoords[nodesTags.index(n1)]
                n2_coords = nodesCoords[nodesTags.index(n2)]

                if "DX" in dirSprings:
                    idxDir1 = 1
                    idxDir2 = 2
                elif "DY" in dirSprings:
                    idxDir1 = 0
                    idxDir2 = 2
                else:  # "DZ" in dir:
                    idxDir1 = 0
                    idxDir2 = 0

                tributaryLength = math.sqrt(
                    pow(n2_coords[idxDir1] - n1_coords[idxDir1], 2)
                    + pow(n2_coords[idxDir2] - n1_coords[idxDir2], 2)
                )

                stiffness = tributaryLength * subgradeModulus * Bref

                self.addNodeSpring(n1, tp, dirSprings, stiffness, add=True)
                self.addNodeSpring(n2, tp, dirSprings, stiffness, add=True)

    def addMultiFrameLoadHydro(
        self,
        loadCase: str,
        tagsMacro: List[myInt64],
        dirLoad: Literal["GCX", "GCY", "GCZ"],
        gamma: float,
        K: float,
        H0: float,
        p0: float,
        Bref: float,
        local: bool = False,
        coordVariation: Literal["X", "Y", "Z"] = "Z",
        oneSignPositive: bool | None = None,
        constValue: bool = False,
    ) -> None:
        """
        Add a linear load on macro-element

        Args:
            constValue (): if true value is considered constant on frame p0 * Bref
            loadCase (): load case as str
            tagsMacro (): macro-element tag
            dirLoad (): load direction
            gamma (): peso del terreno specifico
            K (): coefficiente di spinta del terreno
            H0 (): distanza dallo zero della copertura del terreno
            p0 (): pressione di partenza ovvero il sovraccarico
            Bref (): largezza di riferimento per il calcolo della pressione
            local (): reference system for pressure direction
            coordVariation (): coordinate in global reference that for variation
            oneSignPositive (): If None function considers positive and negative values, If True function considers
                only positive values and negative values if it is False
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0011",
                "First arg must be a string",
                type(loadCase),
            )

        if not isinstance(tagsMacro, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0011", "tagsMacro must be a list", type(tagsMacro)
            )

        if dirLoad not in ("GCX", "GCY", "GCZ"):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022",
                "Third arg *dir* must be GCX, GCY, GCZ",
                dirLoad,
            )

        nodesTags = self.nodesTags()
        nodesCoords = self.nodesCoords()
        framesTags = self.getFramesFromMacroTags()
        assert isinstance(framesTags, dict)
        frameNodes = self.getFrameNodesFromMacro()
        assert isinstance(frameNodes, dict)

        if coordVariation == "X":
            coords_idx = 0
        elif coordVariation == "Y":
            coords_idx = 1
        else:  # coordVariation == 'Z'
            coords_idx = 2

        for tag in tagsMacro:
            # TODO: move this in separate function for subFrames (meshed frames) and add tagsFrames
            #       in function args with two cases
            for i, t in enumerate(framesTags[tag]):
                n1 = frameNodes[tag][i][0]
                n2 = frameNodes[tag][i][1]
                n1_coords = nodesCoords[nodesTags.index(n1)]
                n2_coords = nodesCoords[nodesTags.index(n2)]
                press_1 = ((H0 - n1_coords[coords_idx]) * gamma * K + p0) * Bref
                press_2 = ((H0 - n2_coords[coords_idx]) * gamma * K + p0) * Bref
                rel_dist_from_I_node_I = 0.0
                rel_dist_from_I_node_J = 1.0
                if not constValue:
                    if oneSignPositive is not None and press_1 != 0.0 or press_2 != 0.0:
                        zero_rel_dist_from_I = abs(
                            press_1 / (abs(press_1) + abs(press_2))
                        )
                        if oneSignPositive:
                            if press_1 <= 0.0 and press_2 <= 0.0:
                                press_1 = 0.0
                                press_2 = 0.0
                            elif press_1 * press_2 < 0.0:
                                if press_1 < 0.0:
                                    press_1 = 0.0
                                    rel_dist_from_I_node_I = 1 - zero_rel_dist_from_I
                                else:  # press_2 < 0.0:
                                    press_2 = 0.0
                                    rel_dist_from_I_node_J = zero_rel_dist_from_I
                            else:
                                pass
                        else:  # not oneSignPositive
                            if press_1 >= 0.0 and press_2 >= 0.0:
                                press_1 = 0.0
                                press_2 = 0.0
                            elif press_1 * press_2 < 0.0:
                                if press_1 > 0.0:
                                    press_1 = 0.0
                                    rel_dist_from_I_node_I = 1 - zero_rel_dist_from_I
                                else:  # press_2 < 0.0:
                                    press_2 = 0.0
                                    rel_dist_from_I_node_J = zero_rel_dist_from_I
                            else:
                                pass

                else:  # constValue == True
                    press_1 = p0 * Bref
                    press_2 = press_1
                    lenght = math.sqrt(
                        (n1_coords[coords_idx] - n2_coords[coords_idx]) ** 2
                    )
                    if n1_coords[coords_idx] >= H0 and n2_coords[coords_idx] >= H0:
                        rel_dist_from_I_node_I = 0.0
                        rel_dist_from_I_node_J = 1.0
                        press_1 = 0.0
                        press_2 = 0.0
                    else:
                        if n1_coords[coords_idx] <= H0 and n2_coords[coords_idx] <= H0:
                            rel_dist_from_I_node_I = 0.0
                            rel_dist_from_I_node_J = 1.0
                        else:
                            zero_rel_dist_from_I = (
                                abs(abs(H0) - abs(n1_coords[coords_idx])) / lenght
                            )
                            if n1_coords[coords_idx] < H0 <= n2_coords[coords_idx]:
                                rel_dist_from_I_node_I = 0.0
                                rel_dist_from_I_node_J = 1.0 - zero_rel_dist_from_I
                            else:
                                rel_dist_from_I_node_I = zero_rel_dist_from_I
                                rel_dist_from_I_node_J = 1.0

                if dirLoad == "GCX":
                    self.addFrameLoad(
                        loadCase,
                        t,
                        tp="force",
                        GCX1=[rel_dist_from_I_node_I, press_1],
                        GCX2=[rel_dist_from_I_node_J, press_2],
                        local=local,
                    )
                elif dirLoad == "GCY":
                    self.addFrameLoad(
                        loadCase,
                        t,
                        tp="force",
                        GCY1=[rel_dist_from_I_node_I, press_1],
                        GCY2=[rel_dist_from_I_node_J, press_2],
                        local=local,
                    )
                elif dirLoad == "GCZ":
                    self.addFrameLoad(
                        loadCase,
                        t,
                        tp="force",
                        GCZ1=[rel_dist_from_I_node_I, press_1],
                        GCZ2=[rel_dist_from_I_node_J, press_2],
                        local=local,
                    )
                else:
                    raise Ex.EXAExceptions(
                        "(EXAStructuralModel)-0011",
                        "unknown error in dirLoad",
                        type(dirLoad),
                    )

    def addMultiFrameLoad(
        self,
        loadCase: str,
        tagsFrames: List[myInt64],
        tp: Literal["force", "moment"],
        GCX1: Optional[List[float]] = None,
        GCX2: Optional[List[float]] = None,
        GCY1: Optional[List[float]] = None,
        GCY2: Optional[List[float]] = None,
        GCZ1: Optional[List[float]] = None,
        GCZ2: Optional[List[float]] = None,
        local: bool = False,
    ) -> None:
        """Apply a distributed load or moment to multiple frame mesh elements.

        Delegates to :meth:`addFrameLoad` for each tag in *tagsFrames*.
        See :meth:`addFrameLoad` for a full description of the load parameters.

        Args:
            loadCase: Id of an existing load case.
            tagsFrames: List of mesh frame element tags to load.
            tp: Load type — ``"force"`` for distributed force or
                ``"moment"`` for distributed moment.
            GCX1: ``[relative_distance, value]`` at the start of the load in X.
            GCX2: ``[relative_distance, value]`` at the end of the load in X.
            GCY1: ``[relative_distance, value]`` at the start of the load in Y.
            GCY2: ``[relative_distance, value]`` at the end of the load in Y.
            GCZ1: ``[relative_distance, value]`` at the start of the load in Z.
            GCZ2: ``[relative_distance, value]`` at the end of the load in Z.
            local: If ``True``, interpret directions in the element local
                coordinate system; otherwise in the global system.

        Raises:
            EXAExceptions: If *tagsFrames* is not a list, or if any per-element
                call to :meth:`addFrameLoad` fails.
        """
        if GCX1 is None:
            GCX1 = []
        if GCX2 is None:
            GCX2 = []
        if GCY1 is None:
            GCY1 = []
        if GCY2 is None:
            GCY2 = []
        if GCZ1 is None:
            GCZ1 = []
        if GCZ2 is None:
            GCZ2 = []

        if not isinstance(tagsFrames, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0011",
                "tagsFrames must be a list",
                type(tagsFrames),
            )

        for tag in tagsFrames:
            self.addFrameLoad(
                loadCase, tag, tp, GCX1, GCX2, GCY1, GCY2, GCZ1, GCZ2, local
            )

    def addFrameLoad(
        self,
        loadCase: str,
        tagFrame: myInt64,
        tp: Literal["force", "moment"],
        GCX1: Optional[List[float]] = None,
        GCX2: Optional[List[float]] = None,
        GCY1: Optional[List[float]] = None,
        GCY2: Optional[List[float]] = None,
        GCZ1: Optional[List[float]] = None,
        GCZ2: Optional[List[float]] = None,
        local: bool = False,
    ) -> None:
        """Apply a distributed load or moment to a single frame mesh element.

        Each direction is defined by two ``[relative_distance, value]`` pairs
        that describe a linearly varying load along the element length.
        Relative distances are in [0, 1] where 0 is the start node and 1 is
        the end node. Omitting *GCX2* / *GCY2* / *GCZ2* replicates the
        corresponding start value at the element end (uniform load).

        Args:
            loadCase: Id of an existing load case.
            tagFrame: Mesh tag of the target frame element.
            tp: Load type — ``"force"`` for distributed force or
                ``"moment"`` for distributed moment.
            GCX1: ``[relative_distance, value]`` at the start of the load in X.
            GCX2: ``[relative_distance, value]`` at the end of the load in X.
                If empty, copied from *GCX1* at position 1.0.
            GCY1: ``[relative_distance, value]`` at the start of the load in Y.
            GCY2: ``[relative_distance, value]`` at the end of the load in Y.
                If empty, copied from *GCY1* at position 1.0.
            GCZ1: ``[relative_distance, value]`` at the start of the load in Z.
            GCZ2: ``[relative_distance, value]`` at the end of the load in Z.
                If empty, copied from *GCZ1* at position 1.0.
            local: If ``True``, directions are in the element local coordinate
                system (prefix ``L``); otherwise in the global system (prefix ``G``).

        Raises:
            EXAExceptions: If *loadCase* is not a string or is unknown, if
                *tagFrame* is not in the mesh, if *tp* is invalid, if any load
                list has the wrong length or contains non-float values.
        """
        if GCX1 is None:
            GCX1 = []
        if GCX2 is None:
            GCX2 = []
        if GCY1 is None:
            GCY1 = []
        if GCY2 is None:
            GCY2 = []
        if GCZ1 is None:
            GCZ1 = []
        if GCZ2 is None:
            GCZ2 = []

        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0011",
                "First arg must be a string",
                type(loadCase),
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0012", "Load case unknown", loadCase
            )

        if tagFrame not in self.framesTags():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0013", "Frames tag unknown", tagFrame
            )

        if not isinstance(tp, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0014", "Third arg must be a string", type(tp)
            )

        if all(["force" != tp, "moment" != tp]):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0015", "tp option *force* or *moment*", tp
            )

        if (
            not isinstance(GCX1, list)
            or not isinstance(GCX2, list)
            or not isinstance(GCY1, list)
            or not isinstance(GCY2, list)
            or not isinstance(GCZ1, list)
            or not isinstance(GCZ2, list)
        ):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0016", "GCX1 ... GCZ2 arg must be lists", type(tp)
            )

        cond_null_X = all([len(GCX1) == 0, len(GCX2) == 0])
        cond_null_Y = all([len(GCY1) == 0, len(GCY2) == 0])
        cond_null_Z = all([len(GCZ1) == 0, len(GCZ2) == 0])

        if not cond_null_X:
            if len(GCX1) != 2:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0016", "GCX1 must have len 2", len(GCX1)
                )

            if not all(isinstance(n, float) for n in GCX1):
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0017", "GCX1 must be float list", GCX1
                )

            if len(GCX2) != 2 and len(GCX2) != 0:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0018", "GCX2 must have len 2 or 0", GCX2
                )

            if len(GCX2) == 0:
                GCX2 = GCX1[:]
                GCX2[0] = 1.0

        if not cond_null_Y:
            if len(GCY1) != 2:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0019", "GCY1 must have len 2", len(GCY1)
                )

            if not all(isinstance(n, float) for n in GCY1):
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0017", "GCY1 must be float list", GCY1
                )

            if len(GCY2) != 2 and len(GCY2) != 0:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0021", "GCX2 must have len 2 or 0", GCY2
                )

            if len(GCY2) == 0:
                GCY2 = GCY1[:]
                GCY2[0] = 1.0

        if not cond_null_Z:
            if len(GCZ1) != 2:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0022", "GCZ1 must have len 2", len(GCZ1)
                )

            if not all(isinstance(n, float) for n in GCZ1):
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0017", "GCZ1 must be float list", GCZ1
                )

            if len(GCZ1) != 2 and len(GCZ1) != 0:
                raise Ex.EXAExceptions(
                    "(EXAStructuralModel)-0024", "GCX2 must have len 2 or 0", GCZ1
                )

            if len(GCZ2) == 0:
                GCZ2 = GCZ1[:]
                GCZ2[0] = 1.0

        if loadCase not in self.__loads:
            self.__loads[loadCase] = {}

        if LoadType.FRAME_LOAD not in self.__loads[loadCase]:
            self.__loads[loadCase][LoadType.FRAME_LOAD] = {}

        if tagFrame not in self.__loads[loadCase][LoadType.FRAME_LOAD].keys():
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame] = {}

        if tp not in self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame].keys():
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp] = {}

        sfx = "G"
        if local:
            sfx = "L"

        if not cond_null_X:
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CX1"
            ] = GCX1
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CX2"
            ] = GCX2

        if not cond_null_Y:
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CY1"
            ] = GCY1
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CY2"
            ] = GCY2

        if not cond_null_Z:
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CZ1"
            ] = GCZ1
            self.__loads[loadCase][LoadType.FRAME_LOAD][tagFrame][tp][
                sfx + "CZ2"
            ] = GCZ2

    def addMultiNodeLoad(self, loadCase: str, tagsNodes: List[myInt64], NCS: List[float]) -> None:
        """Apply a nodal load to multiple mesh nodes.

        Delegates to :meth:`assignNodeLoad` for each tag in *tagsNodes*.

        Args:
            loadCase: Id of an existing load case.
            tagsNodes: List of mesh node tags to load.
            NCS: Nodal Coordinate System force/moment vector
                ``[Fx, Fy, Fz, Mx, My, Mz]`` — all values must be floats.

        Raises:
            EXAExceptions: If *tagsNodes* is not a list.
        """
        if not isinstance(tagsNodes, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
            )

        for tag in tagsNodes:
            self.assignNodeLoad(loadCase, tag, NCS)

    def assignNodeLoad(self, loadCase: str, tagNode: myInt64, NCS: List[float]) -> None:
        """Apply a nodal load to a single mesh node.

        Args:
            loadCase: Id of an existing load case.
            tagNode: Mesh tag of the target node.
            NCS: Nodal Coordinate System force/moment vector
                ``[Fx, Fy, Fz, Mx, My, Mz]``.
                All 6 values must be floats.

        Raises:
            EXAExceptions: If *loadCase* is not a string or is unknown, if
                *tagNode* is not in the mesh, if *NCS* contains non-float
                values, or if its length is not 6.
        """
        if not isinstance(loadCase, str):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018", "First arg must be a string", loadCase
            )

        if loadCase not in self.__loadCase.keys():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0019", "Load case unknown", loadCase
            )

        if tagNode not in self.nodesTags():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0020", "Nodes tag unknown", tagNode
            )

        if not all(isinstance(n, float) for n in NCS):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "NCS must be float list", NCS
            )

        if len(NCS) != 6:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022", "NCS must have len 6", len(NCS)
            )

        if loadCase not in self.__loads:
            self.__loads[loadCase] = {}

        if LoadType.NODE_LOAD not in self.__loads[loadCase]:
            self.__loads[loadCase][LoadType.NODE_LOAD] = {}

        self.__loads[loadCase][LoadType.NODE_LOAD][tagNode] = {"NCS": NCS}

    def addMultiNodeContraints(self, tagsNodes: List[myInt64], dof: List[bool]) -> None:
        """Apply boundary condition constraints to multiple mesh nodes.

        Delegates to :meth:`addNodeContraints` for each tag in *tagsNodes*.

        Args:
            tagsNodes: List of mesh node tags to constrain.
            dof: Degrees-of-freedom flags ``[Tx, Ty, Tz, Rx, Ry, Rz]``.
                ``True`` means the DOF is restrained.

        Raises:
            EXAExceptions: If *tagsNodes* is not a list.
        """
        if not isinstance(tagsNodes, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
            )

        for tag in tagsNodes:
            self.addNodeContraints(tag, dof)

    def addNodeContraints(self, tagNode: myInt64, dof: List[bool]) -> None:
        """Apply boundary condition constraints to a single mesh node.

        Args:
            tagNode: Mesh tag of the target node.
            dof: Degrees-of-freedom flags ``[Tx, Ty, Tz, Rx, Ry, Rz]``.
                ``True`` means the DOF is restrained. Must be a list of exactly
                6 booleans.

        Raises:
            EXAExceptions: If *tagNode* is not in the mesh, if *dof* contains
                non-bool values, or if its length is not 6.
        """
        if tagNode not in self.nodesTags():
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0034", "Nodes tag unknown", tagNode
            )

        if not all(isinstance(n, bool) for n in dof):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0021", "dof must be bool list", dof
            )

        if len(dof) != 6:
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022", "dof must have len 6", len(dof)
            )

        self.__nodeSupports[tagNode] = cast(Tuple[bool, bool, bool, bool, bool, bool], dof)

    def getNodeContraints(self) -> Dict[myInt64, Tuple[bool, bool, bool, bool, bool, bool]]:
        """Return all nodal boundary condition constraints.

        Returns:
            A dict mapping each constrained node tag to a 6-tuple of booleans
            ``(Tx, Ty, Tz, Rx, Ry, Rz)`` where ``True`` means the DOF is restrained.
        """
        return self.__nodeSupports

    def addMultiNodeSpring(
        self,
        tagsNodes: List[myInt64],
        tp: NodalSpringsTp,
        dirSpring: NodalSpringsDir,
        stiffness: float,
    ) -> None:
        """Add a nodal spring to multiple mesh nodes.

        Delegates to :meth:`addNodeSpring` for each tag in *tagsNodes*.

        Args:
            tagsNodes: List of mesh node tags to spring.
            tp: Spring behaviour type (``LINEAR``, ``COMP``, or ``TENS``).
            dirSpring: Direction of the spring (e.g. ``DZ+``).
            stiffness: Spring stiffness in force/length units.

        Raises:
            EXAExceptions: If *tagsNodes* is not a list.
        """
        if not isinstance(tagsNodes, list):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0018", "tagsNodes arg must be a list", tagsNodes
            )

        for tag in tagsNodes:
            self.addNodeSpring(tag, tp, dirSpring, stiffness)

    def addNodeSpring(
        self,
        tagNode: myInt64 | int,
        tp: NodalSpringsTp,
        dirSpring: NodalSpringsDir,
        stiffness: float,
        add: bool = False,
    ) -> None:
        """Add or accumulate a nodal spring on a single mesh node.

        Args:
            tagNode: Mesh tag of the target node (``int`` or ``numpy.uint64``).
            tp: Spring behaviour type (``LINEAR``, ``COMP``, or ``TENS``).
            dirSpring: Direction of the spring (e.g. ``DZ+``).
            stiffness: Spring stiffness in force/length units.
            add: If ``True`` and a spring of the same *tp* and *dirSpring*
                already exists on the node, the stiffness is accumulated
                (added). If ``False`` the existing value is overwritten.
                Default is ``False``.

        Raises:
            EXAExceptions: If *tagNode* is not an ``int`` or ``numpy.uint64``,
                if *tp* is not a :class:`NodalSpringsTp`, if *dirSpring* is not
                a :class:`NodalSpringsDir`, or if *stiffness* is not a float.
        """
        if not (isinstance(tagNode, int) or isinstance(tagNode, np.uint64)):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022",
                "First arg *tagNode* must be int or numpy.uint64",
                tagNode,
            )

        if not isinstance(tp, NodalSpringsTp):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022",
                "Second arg *tp* must be NodalSpringsTp",
                type(tp),
            )

        if not isinstance(dirSpring, NodalSpringsDir):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022",
                "Third arg *dir* must be NodalSpringsDir",
                type(tp),
            )

        if not isinstance(stiffness, float):
            raise Ex.EXAExceptions(
                "(EXAStructuralModel)-0022",
                "Fourth arg *stiffness* must be float",
                stiffness,
            )

        if tagNode not in self.__nodeSprings.keys():
            self.__nodeSprings[tagNode] = {}

        if tp not in self.__nodeSprings[tagNode].keys():
            self.__nodeSprings[tagNode][tp] = {}

        if dirSpring in self.__nodeSprings[tagNode][tp] and add:
            self.__nodeSprings[tagNode][tp][dirSpring] += stiffness
        else:
            self.__nodeSprings[tagNode][tp][dirSpring] = stiffness

    def getNodeSprings(self) -> Dict[myInt64, Dict[NodalSpringsTp, Dict[NodalSpringsDir, float]]]:
        """Return all nodal spring assignments.

        Returns:
            Nested dict structured as
            ``{node_tag: {spring_type: {direction: stiffness}}}``.
        """
        return self.__nodeSprings

    @staticmethod
    def getNodesPhysicalName() -> List[str]:
        """Return the names of all physical groups defined on 0D (point) entities.

        Returns:
            A list of physical group name strings for all 0D groups,
            preserving duplicates if multiple groups share the same name.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return names

    @staticmethod
    def getPhisicalNames() -> List[str]:
        """
        Get unique physical names defined.
        If many groups exist with same name returns unique values

        Returns:
            List of unique group names
        """
        groups = gmsh_model.getPhysicalGroups()
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return list(set(names))

    def getCustomIdForTag(self, tag: int, elem_type: Elem) -> int | None:
        """Return the custom physical-group id mapped to a mesh element tag.

        This lookup uses the internal ``tagToGroupForRename`` table, which is
        populated when elements are added with ``groupForRename=True``. It
        allows the caller to map a mesh-space tag back to a user-defined
        physical group id.

        Args:
            tag: Mesh element tag to look up.
            elem_type: Element type (``ELEM_POINT``, ``ELEM_LINE``,
                ``ELEM_TRIA``, or ``ELEM_QUAD``).

        Returns:
            The physical group id if a mapping exists, otherwise ``None``.
        """
        return self.__tagToGroupForRename[elem_type].get(tag)

    @staticmethod
    def getFramesPhysicalName() -> List[str]:
        """Return the names of all physical groups defined on 1D (curve) entities.

        Returns:
            A list of physical group name strings for all 1D groups,
            preserving duplicates if multiple groups share the same name.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        names = []
        for g in groups:
            names.append(gmsh_model.getPhysicalName(g[0], g[1]))
        return names

    @staticmethod
    def getNodesByPhysicalName(name: str) -> List[int]:
        """Return the entity tags of 0D entities belonging to a named physical group.

        Args:
            name: Physical group name to search for.

        Returns:
            List of 0D entity (point) tags in the matching group,
            or an empty list if the name is not found.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        for g in groups:
            if name == gmsh_model.getPhysicalName(g[0], g[1]):
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getNodesByPhysicalGroup(tagGroup: int) -> List[int]:
        """Return the entity tags of 0D entities belonging to a physical group by tag.

        Args:
            tagGroup: Physical group tag to search for.

        Returns:
            List of 0D entity (point) tags in the matching group,
            or an empty list if the tag is not found.
        """
        groups = gmsh_model.getPhysicalGroups(0)
        for g in groups:
            if g[1] == tagGroup:
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getMacroFramesByPhysicalName(name: str) -> List[myInt64]:
        """Return macro-element (curve entity) tags belonging to a named physical group.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.

        Args:
            name: Physical group name to search for.

        Returns:
            List of 1D entity (curve) tags in the matching group,
            or an empty list if the name is not found.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        for g in groups:
            if name == gmsh_model.getPhysicalName(g[0], g[1]):
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    @staticmethod
    def getFramesByPhysicalGroup(tagGroup: int) -> List[int]:
        """Return the entity tags of 1D entities belonging to a physical group by tag.

        Args:
            tagGroup: Physical group tag to search for.

        Returns:
            List of 1D entity (curve) tags in the matching group,
            or an empty list if the tag is not found.
        """
        groups = gmsh_model.getPhysicalGroups(1)
        for g in groups:
            if g[1] == tagGroup:
                return list(gmsh_model.getEntitiesForPhysicalGroup(g[0], g[1]))
        return []

    def __save_mgt(self, fileName: str) -> None:
        """Serialise the model to a MIDAS Gen MGT text file.

        Collects nodes, beam elements, section shapes, load cases, constraints,
        nodal springs, and load data, renders them via the Jinja2 template
        ``template-box.mgt``, and writes the result to ``<fileName>.mgt``.

        Args:
            fileName: Output file path without extension.
        """
        # ----------------
        # *NODE    ; Nodes
        # ; iNO, X, Y, Z
        # ----------------
        nodes = []
        nodesTags = self.nodesTags()
        nodesCoords = self.nodesCoords()
        for i, n in enumerate(nodesTags):
            strFormat = "{id:d},{x:.6f},{y:.6f},{z:.6f}"
            formatted = strFormat.format(
                id=n, x=nodesCoords[i][0], y=nodesCoords[i][1], z=nodesCoords[i][2]
            )
            nodes.append(formatted)

        # ------------------------------------------------------------------------------------
        # *ELEMENT    ; Elements
        # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, ANGLE, iSUB,                     ; Frame  Element
        # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, ANGLE, iSUB, EXVAL, EXVAL2, bLMT ; Comp/Tens Truss
        # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, iN3, iN4, iSUB, iWID , LCAXIS    ; Planar Element
        # ; iEL, TYPE, iMAT, iPRO, iN1, iN2, iN3, iN4, iN5, iN6, iN7, iN8     ; Solid  Element
        # ------------------------------------------------------------------------------------
        frames = []
        framesTags = self.framesTags()
        framesNodeTags = self.framesNodeTags()

        for i, f in enumerate(framesTags):
            if f in self.__framesShapes.keys():
                idShape = self.__framesShapes[f]
            else:
                idShape = 1
            strFormat = "{id:d},BEAM,1,{iPRO:d},{idStart:d},{idEnd:d},0,0"
            formatted = strFormat.format(
                id=f,
                iPRO=idShape,
                idStart=framesNodeTags[i][0],
                idEnd=framesNodeTags[i][1],
            )
            frames.append(formatted)

        # -----------------------------------------------------------------------------------------------------------
        # *SECTION    ; Section
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE, [DATA1], [DATA2]                    ; 1st line - DB/USER
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE, BLT, D1, ..., D8, iCEL              ; 1st line - VALUE
        # ;       AREA, ASy, ASz, Ixx, Iyy, Izz                                               ; 2nd line
        # ;       CyP, CyM, CzP, CzM, QyB, QzB, PERI_OUT, PERI_IN, Cy, Cz                     ; 3rd line
        # ;       Y1, Y2, Y3, Y4, Z1, Z2, Z3, Z4, Zyy, Zzz                                    ; 4th line
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE, ELAST, DEN, POIS, POIC, SF, THERMAL ; 1st line - SRC
        # ;       D1, D2, [SRC]                                                               ; 2nd line
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE, 1, DB, NAME1, NAME2, D1, D2         ; 1st line - COMBINED
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE, 2, D11, D12, D13, D14, D15, D21, D22, D23, D24
        # ; iSEC, TYPE, SNAME, [OFFSET2], bSD, bWE, SHAPE, iyVAR, izVAR, STYPE                ; 1st line - TAPERED
        # ;       DB, NAME1, NAME2                                                            ; 2nd line(STYPE=DB)
        # ;       [DIM1], [DIM2]                                                              ; 2nd line(STYPE=USER)
        # ;       D11, D12, D13, D14, D15, D16, D17, D18                                      ; 2nd line(STYPE=VALUE)
        # ;       AREA1, ASy1, ASz1, Ixx1, Iyy1, Izz1                                         ; 3rd line(STYPE=VALUE)
        # ;       CyP1, CyM1, CzP1, CzM1, QyB1, QzB1, PERI_OUT1, PERI_IN1, Cy1, Cz1           ; 4th line(STYPE=VALUE)
        # ;       Y11, Y12, Y13, Y14, Z11, Z12, Z13, Z14, Zyy1, Zyy2                          ; 5th line(STYPE=VALUE)
        # ;       D21, D22, D23, D24, D25, D26, D27, D28                                      ; 6th line(STYPE=VALUE)
        # ;       AREA2, ASy2, ASz2, Ixx2, Iyy2, Izz2                                         ; 7th line(STYPE=VALUE)
        # ;       CyP2, CyM2, CzP2, CzM2, QyB2, QzB2, PERI_OUT2, PERI_IN2, Cy2, Cz2           ; 8th line(STYPE=VALUE)
        # ;       Y21, Y22, Y23, Y24, Z21, Z22, Z23, Z24, Zyy2, Zzz2                          ; 9th line(STYPE=VALUE)
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE                                      ; 1st line - COMPOSITE-B
        # ;       Hw, tw, B1, Bf1, tf1, B2, Bf2, tf2                                          ; 2nd line
        # ;       [SHAPE-NUM], [STIFF-SHAPE], [STIFF-POS] (1~4)                               ; 3rd line
        # ;       SW, GN, CTC, Bc, Tc, Hh, EsEc, DsDc, Ps, Pc, TsTc, bMulti, Elong, Esh       ; 4th line
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE                                      ; 1st line - COMPOSITE-I
        # ;       Hw, tw, B1, tf1, B2, tf2                                                    ; 2nd line
        # ;       [SHAPE-NUM], [STIFF-SHAPE], [STIFF-POS] (1~2)                               ; 3rd line
        # ;       SW, GN, CTC, Bc, Tc, Hh, EsEc, DsDc, Ps, Pc, TsTc, bMulti, Elong, Esh       ; 4th line
        # ; iSEC, TYPE, SNAME, [OFFSET], bSD, bWE, SHAPE                                      ; 1st line - COMPOSITE-TUB
        # ;       Hw, tw, B1, Bf1, tf1, B2, Bf2, tf2, Bf3, tfp                                ; 2nd line
        # ;       [SHAPE-NUM], [STIFF-SHAPE], [STIFF-POS] (1~3)                               ; 3rd line
        # ;       SW, GN, CTC, Bc, Tc, Hh, EsEc, DsDc, Ps, Pc, TsTc, bMulti, Elong, Esh       ; 4th line
        # ; [DATA1] : 1, DB, NAME or 2, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10
        # ; [DATA2] : CCSHAPE or iCEL or iN1, iN2
        # ; [SRC]  : 1, DB, NAME1, NAME2 or 2, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, iN1, iN2
        # ; [DIM1], [DIM2] : D1, D2, D3, D4, D5, D6, D7, D8
        # ; [OFFSET] : OFFSET, iCENT, iREF, iHORZ, HUSER, iVERT, VUSER
        # ; [OFFSET2]: OFFSET, iCENT, iREF, iHORZ, HUSERI, HUSERJ, iVERT, VUSERI, VUSERJ
        # ; [SHAPE-NUM]: SHAPE-NUM, POS, STIFF-NUM1, STIFF-NUM2, STIFF-NUM3, STIFF-NUM4
        # ; [STIFF-SHAPE]: SHAPE-NUM, for(SHAPE-NUM) { NAME, SIZE1~8 }
        # ; [STIFF-POS]: STIFF-NUM, for(STIFF-NUM) { SPACING, iSHAPE, bCALC }
        # -----------------------------------------------------------------------------------------------------------

        sections = []
        for k, v in self.__sectionShapes.items():
            strFormat = "{idShape:>8d},DBUSER,{name:>16s}, CC, 0, 0, 0, 0, 0, 0, YES, NO, SB, 2,{width:>8.3f},{height:>8.3f},0,0,0,0,0,0,0,0"
            formatted = strFormat.format(
                idShape=k,
                name=v.name,
                width=v.param[0],
                height=v.param[1],
            )
            sections.append(formatted)

            # --------------------------------
        # *STLDCASE    ; Static Load Cases
        # ; LCNAME, LCTYPE, DESC
        # --------------------------------
        loadCases = []
        for key_load in self.__loadCase.keys():
            load = self.__loadCase[key_load]
            strFormat = "{LCNAME:>8s},{LCTYPE:>3s},{DESC:>40s}"
            formatted = strFormat.format(LCNAME=key_load, LCTYPE=load[0], DESC=load[1])
            loadCases.append(formatted)

        # --------------------------------------------
        # *CONSTRAINT    ; Supports
        # ; NODE_LIST, CONST(Dx,Dy,Dz,Rx,Ry,Rz), GROUP
        # --------------------------------------------
        nodeContraints = []
        if len(self.__nodeSupports) > 0:
            nodeContraints.append("*CONSTRAINT")
            for k_node, v_supp in self.__nodeSupports.items():
                strFormat = "{tag:d},{TX:d}{TY:d}{TZ:d}{RX:d}{RY:d}{RZ:d}"
                formatted = strFormat.format(
                    tag=k_node,
                    TX=int(v_supp[0]),
                    TY=int(v_supp[1]),
                    TZ=int(v_supp[2]),
                    RX=int(v_supp[3]),
                    RY=int(v_supp[4]),
                    RZ=int(v_supp[5]),
                )
                nodeContraints.append(formatted)

        # -----------------------------------------------------------------------------------------------------------------
        # *SPRING    ; Point Spring Supports
        # ; NODE_LIST, Type, F_SDx, F_SDy, F_SDz, F_SRx, F_SRy, F_SRz, SDx, SDy, SDz, SRx, SRy, SRz ...
        # ;                  DAMPING, Cx, Cy, Cz, CRx, CRy, CRz, GROUP, [DATA1]                                ; LINEAR
        # ; NODE_LIST, Type, Direction, Vx, Vy, Vz, Stiffness, GROUP, [DATA1]                                  ; COMP, TENS
        # ; NODE_LIST, Type, Direction, Vx, Vy, Vz, FUNCTION, GROUP, [DATA1]                                   ; MULTI
        # ; [DATA1] EFFAREA, Kx, Ky, Kz
        # -----------------------------------------------------------------------------------------------------------------
        springs = []
        if len(self.__nodeSprings) > 0:
            springs.append("*SPRING")
            for k_spring, v_spring in self.__nodeSprings.items():
                for kk, vv in v_spring.items():
                    if kk == "COMP":
                        Type = "COMP"
                    elif kk == "TENS":
                        Type = "TENS"
                    elif kk == "LINEAR":
                        Type = "LINEAR"
                    else:
                        raise Ex.EXAExceptions(
                            "(EXAStructuralModel)-0026", "key error in Type", kk
                        )
                    for kkk, vvv in vv.items():
                        if kkk == "DX+":
                            Direction = 0
                        elif kkk == "DX-":
                            Direction = 1
                        elif kkk == "DY+":
                            Direction = 2
                        elif kkk == "DY-":
                            Direction = 3
                        elif kkk == "DZ+":
                            Direction = 4
                        elif kkk == "DZ-":
                            Direction = 5
                        else:
                            raise Ex.EXAExceptions(
                                "(EXAStructuralModel)-0026",
                                "key error in Direction",
                                kkk,
                            )
                        strFormat = "{tag:d},{Type:s},{Direction:d},0,0,0,{Stiffness:.6f}, , 0, 0, 0, 0, 0"
                        formatted = strFormat.format(
                            tag=k_spring, Type=Type, Direction=Direction, Stiffness=vvv
                        )
                        springs.append(formatted)
            springs.append("")

        # -----------------
        # *USE-STLD, <name>
        # -----------------
        loadCasesUsed = []
        for k_load, v_load in self.__loads.items():
            strFormat = "*USE-STLD, {key:s}"
            formatted = strFormat.format(key=k_load)
            loadCasesUsed.append(formatted)
            loadCasesUsed.append("")
            for kk_load, vv_load in v_load.items():
                if kk_load == LoadType.FRAME_LOAD:
                    loadCasesUsed.append("*BEAMLOAD")
                    # *BEAMLOAD    ; Element Beam Loads
                    # ; ELEM_LIST, CMD, TYPE, DIR, bPROJ, [ECCEN], [VALUE], GROUP
                    # ; ELEM_LIST, CMD, TYPE, TYPE, DIR, VX, VY, VZ, bPROJ, [ECCEN], [VALUE], GROUP
                    # ; [VALUE]       : D1, P1, D2, P2, D3, P3, D4, P4
                    # ; [ECCEN]       : bECCEN, ECCDIR, I-END, J-END, bJ-END
                    # ; [ADDITIONAL]  : bADDITIONAL, ADDITIONAL_I-END, ADDITIONAL_J-END, bADDITIONAL_J-END
                    for kkk_load, vvv_load in vv_load.items():
                        for kkkk_load, vvvv_load in vvv_load.items():
                            if kkkk_load == "force":
                                tp = "UNILOAD"
                            elif kkkk_load == "moment":
                                tp = "UNIMOMENT"
                            else:
                                raise Ex.EXAExceptions(
                                    "(EXAStructuralModel)-0026",
                                    "key error in tp",
                                    kkkk_load,
                                )

                            if (
                                "GCX1" in vvvv_load.keys()
                                and "GCX2" in vvvv_load.keys()
                            ):
                                strFormat = "{tag: d}, BEAM   , {tp}, GX, NO , NO, aDir[1], , , , {GCX1D:.6f}, {GCX1P:.6f}, {GCX2D:.6f}, {GCX2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                                formatted = strFormat.format(
                                    tag=kkk_load,
                                    tp=tp,
                                    GCX1D=vvvv_load["GCX1"][0],
                                    GCX1P=vvvv_load["GCX1"][1],
                                    GCX2D=vvvv_load["GCX2"][0],
                                    GCX2P=vvvv_load["GCX2"][1],
                                )
                                loadCasesUsed.append(formatted)
                            if (
                                "GCY1" in vvvv_load.keys()
                                and "GCY2" in vvvv_load.keys()
                            ):
                                strFormat = "{tag: d}, BEAM   , {tp}, GY, NO , NO, aDir[1], , , , {GCY1D:.6f}, {GCY1P:.6f}, {GCY2D:.6f}, {GCY2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                                formatted = strFormat.format(
                                    tag=kkk_load,
                                    tp=tp,
                                    GCY1D=vvvv_load["GCY1"][0],
                                    GCY1P=vvvv_load["GCY1"][1],
                                    GCY2D=vvvv_load["GCY2"][0],
                                    GCY2P=vvvv_load["GCY2"][1],
                                )
                                loadCasesUsed.append(formatted)
                            if (
                                "GCZ1" in vvvv_load.keys()
                                and "GCZ2" in vvvv_load.keys()
                            ):
                                strFormat = "{tag: d}, BEAM   , {tp}, GZ, NO , NO, aDir[1], , , , {GCZ1D:.6f}, {GCZ1P:.6f}, {GCZ2D:.6f}, {GCZ2P:.6f}, 0, 0, 0, 0, , NO, 0, 0, NO,"
                                formatted = strFormat.format(
                                    tag=kkk_load,
                                    tp=tp,
                                    GCZ1D=vvvv_load["GCZ1"][0],
                                    GCZ1P=vvvv_load["GCZ1"][1],
                                    GCZ2D=vvvv_load["GCZ2"][0],
                                    GCZ2P=vvvv_load["GCZ2"][1],
                                )
                                loadCasesUsed.append(formatted)

                    loadCasesUsed.append("")

                elif kk_load == LoadType.NODE_LOAD:
                    loadCasesUsed.append("*CONLOAD")
                    # *CONLOAD    ; Nodal Loads
                    # ; NODE_LIST, FX, FY, FZ, MX, MY, MZ, GROUP
                    for kkk_load, vvv_load in vv_load.items():
                        strFormat = "{tag: d}, {FX:.6f}, {FY:.6f}, {FZ:.6f}, {MX:.6f}, {MY:.6f}, {MZ:.6f},"
                        formatted = strFormat.format(
                            tag=kkk_load,
                            FX=vvv_load["NCS"][0],
                            FY=vvv_load["NCS"][1],
                            FZ=vvv_load["NCS"][2],
                            MX=vvv_load["NCS"][3],
                            MY=vvv_load["NCS"][4],
                            MZ=vvv_load["NCS"][5],
                        )
                        loadCasesUsed.append(formatted)

                    loadCasesUsed.append("")

                elif kk_load == LoadType.SELF_WEIGHT:
                    loadCasesUsed.append("*SELFWEIGHT")
                    strFormat = "{DIRX: .6f}, {DIRY: .6f}, {DIRZ: .6f},"
                    formatted = strFormat.format(
                        DIRX=vv_load[0], DIRY=vv_load[1], DIRZ=vv_load[2]
                    )
                    loadCasesUsed.append(formatted)
                    loadCasesUsed.append("")
                else:
                    raise Ex.EXAExceptions(
                        "(EXAStructuralModel)-0025",
                        "key error in loadCasesUsed",
                        kk_load,
                    )

            loadCasesUsed.append(
                f"; End of data for load case {k_load} -------------------------"
            )

        output = template.render(
            udm="KN,M, BTU, C",
            nodes=nodes,
            elements=frames,
            loadCases=loadCases,
            loadCasesUsed=loadCasesUsed,
            contraints=nodeContraints,
            springs=springs,
            sections=sections,
        )

        # print(output)

        with open(fileName + ".mgt", "w") as fn:
            fn.write(output)

    def save(self, fileName: str, fileType: str = ".msh") -> None:
        """Save the model to file.

        Args:
            fileName: Output file path without extension.
            fileType: File format extension. Supported values:

                * ``".msh"`` — GMSH native mesh format (default).
                * ``".med"`` — MED/Salome format.
                * ``".mgt"`` — MIDAS Gen template format (see :meth:`__save_mgt`).

        Note:
            All mesh elements are saved regardless of physical group membership
            (``Mesh.SaveAll`` is set to 1 before writing).
        """
        print("Write ", fileName + fileType)
        gmsh.option.setNumber("Mesh.SaveAll", 1)
        if fileType == ".msh":
            gmsh.write(fileName + fileType)
            # logGmshFile(fileName + fileType)
        elif fileType == ".med":
            gmsh.write(fileName + fileType)
        elif fileType == ".mgt":
            self.__save_mgt(fileName)
        else:
            self.__log("ERR", f"File type unknoun *{fileType}*. None file saved !!!")

    def getCad(self):
        """Return the underlying OpenCASCADE (OCC) geometry kernel instance.

        Returns:
            The ``gmsh.model.occ`` object used to build and modify geometry.
        """
        return self.__cad

    @staticmethod
    def getModeler():
        """Main object that shapes geometry and mesh

        Returns:
            A gmsh modeler
        """
        return gmsh_model

    def addModel(self, name: str) -> bool:
        """Add a new GMSH model and register it in the session.

        Args:
            name: Non-empty unique name for the new model.

        Returns:
            ``True`` if the model was created successfully, ``False`` if *name*
            is empty or already registered.
        """
        if len(name) == 0:
            self.__log("ERR", "Arg must be a str not null !!!")
            return False
        else:
            if name in self.__models:
                self.__log("ERR", f"Model *{name}* is present !!!")
                return False
            else:
                gmsh_model.add(name)
                self.__models.append(name)
                self.__log("INF", f"Model *{name}* added !!!")
                return True

    def getModels(self) -> List[str]:
        """Return the list of GMSH model names registered in this session.

        Returns:
            A list of model name strings in the order they were added,
            starting with the name passed to ``__init__``.
        """
        return self.__models

    def setCurrentModel(self, name: str) -> bool:
        """Switch the active GMSH model.

        Args:
            name: Name of a previously registered model.

        Returns:
            ``True`` if the model was found and set as current, ``False``
            if *name* is not registered.
        """
        if name not in self.__models:
            self.__log("ERR", f"Model *{name}* not present !!!")
            return False
        else:
            gmsh_model.setCurrent(name)
            return True

    def addNodesToGroup(
        self, tags: List[myInt64], tagGroup: myInt64, physicalName: str = ""
    ) -> None:
        """Add 0D (point) entities to a physical group.

        Args:
            tags: List of 0D entity tags to add to the group.
            tagGroup: Physical group tag to assign.
            physicalName: Optional name to assign to the physical group.
        """
        self.__addElementToGroup(tags, tagGroup, Dim.DIM_0D, physicalName)

    @staticmethod
    def __addElementToGroup(
        tags: List[myInt64], tagGroup: myInt64, dim: Dim, physicalName: str = ""
    ) -> None:
        """Add entities to a GMSH physical group.

        Args:
            tags: List of entity tags to add to the group.
            tagGroup: Physical group tag to assign.
            dim: Spatial dimension of the entities.
            physicalName: Optional name to assign to the physical group.
        """
        gmsh_model.addPhysicalGroup(dim.value, tags, tagGroup)
        if len(physicalName) > 0:
            gmsh_model.setPhysicalName(dim.value, tagGroup, physicalName)

    @staticmethod
    def renumberFramesByNodeCoords(
        macroTags: List[myInt64], dirRule: Literal["+X", "+Y", "+Z", "-X", "-Y", "-Z"]
    ) -> Tuple[Any, Any]:
        """Sort mesh frame tags by their midpoint coordinate along a given axis.

        Produces the old and new tag ordering needed by :meth:`renumberArrange`
        to physically renumber elements in GMSH.

        Args:
            macroTags: List of macro-element tags whose mesh frames are sorted.
            dirRule: Sorting axis and direction.  The sign (``+`` / ``-``)
                controls ascending or descending order; the letter selects the
                coordinate axis (``X``, ``Y``, or ``Z``).

        Returns:
            A 2-tuple ``(old_frame_tags, new_frame_tags)`` where both are
            lists of mesh frame tags — *old* in original GMSH order and *new*
            in the sorted order.
        """
        oldFrameTags = FEModel.getFramesFromMacroTags(macroTags)
        oldNodesTags = FEModel.getFrameNodesFromMacro(macroTags)

        idxCoord = ["X", "Y", "Z"].index(dirRule[1])
        oldMediumCoord = np.zeros(len(oldFrameTags), dtype=np.uint64)
        assert isinstance(oldNodesTags, list)

        for i, t in enumerate(oldNodesTags):
            assert isinstance(t, tuple)
            assert len(t) == 2
            oldMediumCoord[i] = (
                FEModel.nodeCoords(t[0])[idxCoord] + FEModel.nodeCoords(t[0])[idxCoord]
            ) / 2

        oldTagCoords = zip(oldFrameTags, oldMediumCoord)

        rev = False
        if dirRule[0] == "-":
            rev = True

        oldTagCoordsSorted = sorted(oldTagCoords, key=lambda tc: tc[1], reverse=rev)

        newFrameTags = [0] * len(oldTagCoordsSorted)
        for i, t in enumerate(oldTagCoordsSorted):
            assert isinstance(i, int)
            newFrameTags[i] = int(oldTagCoordsSorted[i][0])

        return oldFrameTags, newFrameTags

    @staticmethod
    def renumberArrange(
        oldMacroTags: List[List[int]], newMacroTags: List[List[int]]
    ) -> None:
        """Apply an element renumbering to the GMSH mesh.

        Flattens *oldMacroTags* and *newMacroTags* into compact lists and
        calls ``gmsh.model.mesh.renumberElements`` to reassign element ids.

        Args:
            oldMacroTags: List of lists of current (old) mesh element tags,
                one inner list per macro-element group.
            newMacroTags: List of lists of desired (new) mesh element tags,
                in the same structure as *oldMacroTags*.
        """
        compactOldTags = oldMacroTags[0]
        for i in range(len(oldMacroTags) - 1):
            compactOldTags.extend(oldMacroTags[i + 1])

        compactNewTags = newMacroTags[0]
        for i in range(len(newMacroTags) - 1):
            compactNewTags.extend(newMacroTags[i + 1])

        gmsh.model.mesh.renumberElements(compactOldTags, compactNewTags)

    def addFramesToGroup(
        self, tags: List[myInt64] | int, tagGroup: myInt64, physicalName: str = ""
    ) -> None:
        """Add one or more 1D macro-elements (curves) to a physical group.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.
        The physical name is also recorded per mesh frame element so it can be
        retrieved later via :meth:`getPhysicalNamesForFrame`.

        Args:
            tags: A single macro-element tag (``int``) or a list of them.
            tagGroup: Physical group tag to assign.
            physicalName: Optional name to assign to the physical group.
        """
        if isinstance(tags, int):
            tags = [tags]

        self.__addElementToGroup(tags, tagGroup, Dim.DIM_1D, physicalName)
        for t in self.getFramesFromMacroTags(tags):
            if self.__framesPhysicalNames.get(t) is None:
                self.__framesPhysicalNames[t] = [physicalName]
            else:
                self.__framesPhysicalNames[t].append(physicalName)

    def getPhysicalNamesForFrame(self, tag: myInt64) -> List[str] | None:
        """Return the physical group names associated with a mesh frame element.

        Args:
            tag: Mesh frame element tag.

        Returns:
            List of physical group name strings the element belongs to,
            or ``None`` if the element has no recorded group.
        """
        return self.__framesPhysicalNames.get(tag)

    def addPlatesToGroup(
        self, tags: List[myInt64] | int, tagGroup: myInt64, physicalName: str = ""
    ) -> None:
        """Add one or more 2D macro-elements (surfaces) to a physical group.

        A *macro* element is a geometric object (a GMSH entity) that typically
        corresponds to one or more mesh elements after meshing.
        The physical name is also recorded per mesh plate element so it can be
        retrieved later via :meth:`getPhysicalNamesForPlate`.

        Args:
            tags: A single macro-element tag (``int``) or a list of them.
            tagGroup: Physical group tag to assign.
            physicalName: Optional name to assign to the physical group.
        """
        if isinstance(tags, int):
            tags = [tags]

        self.__addElementToGroup(tags, tagGroup, Dim.DIM_2D, physicalName)
        for t in FEModel.getPlatesFromMacroTags(tags):
            if self.__platesPhysicalNames.get(t) is None:
                self.__platesPhysicalNames[t] = [physicalName]
            else:
                self.__platesPhysicalNames[t].append(physicalName)

    def getPhysicalNamesForPlate(self, tag: myInt64) -> List[str] | None:
        """Return the physical group names associated with a mesh plate element.

        Args:
            tag: Mesh plate element tag.

        Returns:
            List of physical group name strings the element belongs to,
            or ``None`` if the element has no recorded group.
        """
        return self.__platesPhysicalNames.get(tag)

    def addNode(
        self,
        x: Union[int, float],
        y: Union[int, float],
        z: Union[int, float],
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        groupForRename: bool = False,
        meshSize: float = 0.0,
    ) -> int:
        """Create a 0D geometric point (node) and optionally add it to a physical group.

        Args:
            x: X coordinate.
            y: Y coordinate.
            z: Z coordinate.
            tag: Desired GMSH entity tag. -1 lets GMSH choose automatically.
            group: If ``True``, add the point to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            groupForRename: If ``True``, record the mapping between the mesh
                element tag and *tagGroup* in the internal rename table.
                Useful when the model is pre-meshed and tags need to be
                resolved back to user-defined ids.
            meshSize: Target mesh element size at this point. 0.0 inherits
                from the global mesh size setting.

        Returns:
            The GMSH entity tag of the created point.
        """
        tag = self.__cad.addPoint(x, y, z, meshSize=meshSize, tag=tag)
        self.__cad.synchronize()
        if group:
            # There are cases that tagGroup already exists e.g. using slice in 2d elements in pyvista
            #
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_0D.value, [tag], tag=tagGroup)
            except:
                self.__log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self.__log("INF", "Direct map node element to node meshed !!!")
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_0D.value, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        self.__tagToGroupForRename[Elem.ELEM_POINT][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self.__log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self.__macro_element_node[tag] = Point3d(x=x, y=y, z=z)
        return tag

    def addFrame(
        self,
        tagStart: int,
        tagEnd: int,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        nb: int = 1,
        groupForRename: bool = False,
        transfiniteCurve: bool = True,
    ) -> int:
        """Create a 1D straight frame element between two existing points.

        Args:
            tagStart: GMSH entity tag of the start point (node).
            tagEnd: GMSH entity tag of the end point (node).
            tag: Desired GMSH entity tag for the curve. -1 lets GMSH choose.
            group: If ``True``, add the curve to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            nb: Number of mesh elements along the frame. The transfinite
                algorithm places ``nb + 1`` nodes on the curve.
            groupForRename: If ``True``, record the mapping between the mesh
                element tag and *tagGroup* in the internal rename table.
                Only meaningful when *nb* = 1 (single-element frame).
            transfiniteCurve: If ``True``, apply a structured (transfinite)
                meshing algorithm and immediately generate the 1D mesh.

        Returns:
            The GMSH entity tag of the created curve.
        """
        tag = self.__cad.addLine(tagStart, tagEnd, tag=tag)
        self.__cad.synchronize()

        # mesh frame to have underlying mesh
        mesh = gmsh_model.mesh
        if transfiniteCurve:
            mesh.setTransfiniteCurve(tag, nb + 1)
            mesh.generate(1)

        if group:
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_1D.value, [tag], tag=tagGroup)
            except:
                self.__log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self.__log("INF", "Direct map frame element to frame meshed !!!")
                # getElements return mesh tag under model tag. meshTags has one elements because
                #
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_1D.value, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        self.__tagToGroupForRename[Elem.ELEM_LINE][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self.__log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self.__macro_element_frame[tag] = (tagStart, tagEnd)
        return tag

    def addPlate(
        self,
        tagLine_1: int | None = None,
        tagLine_2: int | None = None,
        tagLine_3: int | None = None,
        tagLine_4: int | None = None,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        groupForRename: bool = False,
        elType: Elem = Elem.ELEM_QUAD,
        transfiniteSurface: bool = True,
        nodes: list[int] | None = None,
        lines: list[int] | None = None,
        nb: int | None = None,
    ) -> int:
        """Create a planar surface bounded by 3 or 4 curves and generate its mesh.

        The boundary can be specified in three mutually exclusive ways:

        **Positional line args** — pass 3 or 4 pre-existing curve tags directly::

            plate = am.addPlate(f1, f2, f3, f4)
            plate = am.addPlate(f1, f2, f3)

        **Line list** (keyword ``lines``) — same as above but as a single list::

            plate = am.addPlate(lines=[f1, f2, f3, f4])
            plate = am.addPlate(lines=[f1, f2, f3])

        In both line modes, mesh density and transfinite settings are controlled
        by the nb/transfiniteCurve parameters used when those curves were created
        with addFrame.  Setting nb=1 on every boundary curve yields exactly one
        element covering the whole surface::

            f1 = am.addFrame(n1, n2, nb=1, transfiniteCurve=True)
            ...
            plate = am.addPlate(lines=[f1, f2, f3, f4])

        **Node list** (keyword ``nodes``) — pass 3 or 4 node tags; boundary
        curves are created internally as plain lines.  Use this when the
        boundary curves do not need to be referenced independently::

            plate = am.addPlate(nodes=[n1, n2, n3, n4])
            plate = am.addPlate(nodes=[n1, n2, n3])

        To force a single-element mesh in node mode, combine with ``nb=1``
        and ``transfiniteSurface=True``.  ``nb`` sets the number of elements
        per boundary edge (same convention as addFrame: nb+1 nodes per edge
        via setTransfiniteCurve), so ``nb=1`` places only the two endpoint
        nodes on each edge::

            plate = am.addPlate(nodes=[n1, n2, n3, n4], nb=1)
            plate = am.addPlate(nodes=[n1, n2, n3], nb=1, elType=Elem.ELEM_TRIA)

        Args:
            tagLine_1: Tag of the first boundary curve (positional line mode).
            tagLine_2: Tag of the second boundary curve (positional line mode).
            tagLine_3: Tag of the third boundary curve (positional line mode).
            tagLine_4: Tag of the fourth boundary curve (positional line mode),
                or None for a triangular surface.
            tag: Gmsh tag to assign to the surface.  -1 lets gmsh choose.
            group: If True, add the surface to a physical group.
            tagGroup: Physical group tag. Used only when group=True.
            groupForRename: If True, will be add tag to special maps that link
                model tag to mesh tag. This is usefull when you have to build
                a model that is already meshed.
            elType: Element type for the surface mesh.  ELEM_QUAD triggers
                setRecombine so triangles are merged into quads; ELEM_TRIA
                leaves the triangulation unchanged.
            transfiniteSurface: If True, apply setTransfiniteSurface for a
                structured mesh.  Set to False for an unstructured Delaunay
                mesh (required when embedding interior nodes via addNodesToPlate).
            nodes: List of 3 or 4 node tags (node mode).
            lines: List of 3 or 4 line tags (line list mode).
            nb: Number of elements per boundary edge, applied only in node
                mode (ignored for line modes).  Follows the same convention as
                addFrame: gmsh receives nb+1 nodes per edge via
                setTransfiniteCurve.  Use nb=1 to force a single-element mesh.
                When None (default) no transfinite setting is applied to the
                boundary curves.

        Returns:
            The gmsh surface tag of the created plate.

        Raises:
            ValueError: If the supplied list has a count other than 3 or 4,
                or if no boundary input is provided.
        """
        if nodes is not None:
            if len(nodes) not in (3, 4):
                raise ValueError(f"nodes must have 3 or 4 entries, got {len(nodes)}")
            resolved_lines = [
                self.__cad.addLine(nodes[i], nodes[(i + 1) % len(nodes)])
                for i in range(len(nodes))
            ]
            resolved_nodes = nodes
            if nb is not None:
                self.__cad.synchronize()
                for line_tag in resolved_lines:
                    gmsh_model.mesh.setTransfiniteCurve(line_tag, nb + 1)
        elif lines is not None:
            if len(lines) not in (3, 4):
                raise ValueError(f"lines must have 3 or 4 entries, got {len(lines)}")
            resolved_lines = lines
            resolved_nodes = []
            for l in resolved_lines:
                resolved_nodes.append(self.__macro_element_frame[l][0])
                resolved_nodes.append(self.__macro_element_frame[l][1])
            resolved_nodes = list(set(resolved_nodes))
        else:
            if tagLine_1 is None or tagLine_2 is None or tagLine_3 is None:
                raise ValueError(
                    "Provide boundary via nodes=[...], lines=[...], or tagLine_1/2/3"
                )
            resolved_lines = (
                [tagLine_1, tagLine_2, tagLine_3]
                if tagLine_4 is None
                else [tagLine_1, tagLine_2, tagLine_3, tagLine_4]
            )
            resolved_nodes = []
            for l in resolved_lines:
                resolved_nodes.append(self.__macro_element_frame[l][0])
                resolved_nodes.append(self.__macro_element_frame[l][1])
            resolved_nodes = list(set(resolved_nodes))

        wireId = self.__cad.addCurveLoop(resolved_lines)

        plateId = self.__cad.addPlaneSurface(wireTags=[wireId], tag=tag)
        self.__cad.synchronize()
        mesh = gmsh_model.mesh
        if transfiniteSurface:
            mesh.setTransfiniteSurface(tag=plateId, arrangement="left")
        if elType == Elem.ELEM_QUAD:
            mesh.setRecombine(dim=2, tag=plateId)

        mesh.generate(2)

        if group:
            try:
                gmsh_model.addPhysicalGroup(Dim.DIM_2D.value, [plateId], tag=tagGroup)
            except:
                self.__log("ERR", "addPhysicalGroup error !!!")

            if groupForRename:
                self.__log("INF", "Direct map plate element to plate meshed !!!")
                # getElements return mesh tag under model tag. meshTags has one elements because
                #
                _, meshTags, _ = gmsh_model.mesh.getElements(Dim.DIM_2D, tag)
                if len(meshTags) == 1:
                    if len(meshTags[0]) == 1:
                        tp_element = (
                            Elem.ELEM_TRIA
                            if len(resolved_lines) == 3
                            else Elem.ELEM_QUAD
                        )
                        self.__tagToGroupForRename[tp_element][
                            meshTags[0][0]
                        ] = tagGroup
                    else:
                        self.__log(
                            "WRN",
                            "meshTags can't be linked with tagGroup because has len != 1 !!!",
                        )

        self.__macro_element_plate[plateId] = cast(
            "tuple[int, int, int, int] | tuple[int, int, int]", tuple(resolved_nodes)
        )
        return plateId

    @staticmethod
    def addNodesToPlate(tags: list[int], tagPlate: int) -> None:
        """Embed existing nodes inside a plate surface and regenerate its mesh.

        Embedded nodes are forced to appear as vertices in the resulting
        triangulation, enabling mesh refinement around interior points.
        The plate must have been created with ``transfiniteSurface=False``
        to allow an unstructured mesh that can accommodate interior nodes.

        Args:
            tags: List of 0D entity (point) tags to embed in the surface.
            tagPlate: GMSH surface entity tag of the target plate.
        """
        gmsh_model.mesh.embed(0, tags, 2, tagPlate)
        gmsh_model.mesh.generate(2)

    def addArc(
        self,
        tagStart: int,
        tagMid: int,
        tagEnd: int,
        tag: int = -1,
        group: bool = False,
        tagGroup: int = -1,
        nb: int = 10,
    ) -> int:
        """Create a circular arc through three existing points.

        Args:
            tagStart: GMSH entity tag of the arc start point.
            tagMid: GMSH entity tag of a point on the arc (used to define
                the circle; does not need to be the midpoint).
            tagEnd: GMSH entity tag of the arc end point.
            tag: Desired GMSH entity tag for the curve. -1 lets GMSH choose.
            group: If ``True``, add the arc to a physical group.
            tagGroup: Physical group tag. Used only when *group* is ``True``.
            nb: Number of mesh elements along the arc. The transfinite
                algorithm places ``nb + 1`` nodes on the curve. Default is 10.

        Returns:
            The GMSH entity tag of the created arc curve.
        """
        tag = self.__cad.addCircleArc(tagStart, tagMid, tagEnd, tag=tag)
        self.__cad.synchronize()

        # mesh frame to have underlying mesh
        mesh = gmsh_model.mesh
        mesh.setTransfiniteCurve(tag, nb + 1)
        mesh.generate(1)

        if group:
            gmsh_model.addPhysicalGroup(Dim.DIM_1D.value, [tag], tag=tagGroup)
            # self.__cad.synchronize()
        return tag

    def assignGroupTreeToPhysical(
        self, treePath: List[str | None], physicalName: str
    ) -> None:
        """Map a hierarchical group-tree path to an existing physical group name.

        The tree path is a list of string labels representing hierarchy levels
        (e.g. ``["Structure", "Columns", None]``). ``None`` entries are allowed
        only as trailing placeholders and are ignored when building the path key.
        ``None`` values must not appear before non-``None`` values.

        Args:
            treePath: Non-empty list of path labels. The first element must not
                be ``None``. Any trailing ``None`` values are stripped.
            physicalName: An existing physical group name (must be already
                registered in the model).

        Raises:
            ValueError: If *treePath* is empty, starts with ``None``, if
                *physicalName* is empty, if *physicalName* is not a registered
                physical group, or if ``None`` entries appear before non-``None``
                entries.
        """
        if len(treePath) == 0:
            raise ValueError("treePath has len 0 !!!")

        if treePath[0] is None:
            raise ValueError("treePath starts with None type !!!")

        if physicalName == "":
            raise ValueError("physicalName has len 0 !!!")

        pn = self.getPhisicalNames()
        if physicalName not in pn:
            raise ValueError(f'physicalName given "{physicalName}" not in {pn} !!!')

        # check if None type are compacted at end of list
        hashStr = ""
        isNone = False
        for cols in treePath:
            if isNone:
                if cols is not None:
                    raise ValueError("None type within not none type !!!")
            if cols is None:
                isNone = True
            else:
                hashStr += cols + "/"

        self.__groupTree[hashStr] = physicalName

    def getGroupTreeToPhysical(self) -> Dict[str, str]:
        """Return the group-tree to physical-name mapping.

        Returns:
            A dict mapping each slash-delimited tree path string to the
            corresponding physical group name.
        """
        return self.__groupTree

    def __str__(self):
        s = f"Model Description: {self.__description:s}"
        return s
