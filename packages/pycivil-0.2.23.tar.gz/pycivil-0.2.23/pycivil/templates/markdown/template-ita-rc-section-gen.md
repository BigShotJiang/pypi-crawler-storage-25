<!-- Generic RC Section Definition -->

{% if geometryFigure %}
### Sezione trasversale

![Plot della sezione trasversale]({{ geometryUrl }}){width=90%}
{% endif %}

---

Si riportano nella tabella seguente le coordinate dei vertici della sezione ed il loro identificativo *id*:

### Tabella dei vertici

| **id** | $X$ | $Y$ |
|--------|-----|-----|
|        | *[mm]* | *[mm]* |
{% for v in vertices %}
| {{ v.id }} | {{ v.xPos }} | {{ v.yPos }} |
{% endfor %}

{% if namedVertices %}
---

La sezione e di forma specifica *{{ sectionShape }}* con i seguenti parametri:

{% if rectangularShape %}
| Parametro | Valore |
|-----------|--------|
| $b$ | {{ shape_width }} *mm* |
| $h$ | {{ shape_height }} *mm* |
{% endif %}

Le coordinate notevoli dei vertici sono espresse nella seguente tabella:

### Tabella dei vertici notevoli

| **id** | $X$ | $Y$ |
|--------|-----|-----|
|        | *[mm]* | *[mm]* |
{% for n in namedVertices %}
| {{ n.name }} | {{ n.xPos }} | {{ n.yPos }} |
{% endfor %}
{% endif %}

---

mentre nella seguente tabella si rappresenta la connettivita dei triangoli:

### Tabella dei triangoli e connettivita

| **id** | **id_1** | **id_2** | **id_3** |
|--------|----------|----------|----------|
{% for t in triangles %}
| {{ t.id }} | {{ t.id1 }} | {{ t.id2 }} | {{ t.id3 }} |
{% endfor %}

---

Di seguito la tabella relativa al posizionamento degli acciai, essendo *id* l'identificativo della barra, $X$ ed $Y$ le coordinate, $d$ il diametro e *idv* l'identificativo del vertice:

### Tabella dei rinforzi

| **id** | $X$ | $Y$ | $d$ | **idv** |
|--------|-----|-----|-----|---------|
|        | *[mm]* | *[mm]* | *[mm]* | |
{% for r in rebars %}
| {{ r.id }} | {{ r.xPos }} | {{ r.yPos }} | {{ r.diam }} | {{ r.id_v }} |
{% endfor %}
