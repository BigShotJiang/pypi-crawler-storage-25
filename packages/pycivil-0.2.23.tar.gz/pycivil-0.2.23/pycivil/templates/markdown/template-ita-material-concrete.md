<!-- Concrete Material Properties - NTC2018 -->

{% if glossary %}
<!-- Glossary symbols: f_ck, R_ck, f_ctm, E_cm, f_cm, e_c2, e_cu, gamma_c, sigma_c_car, sigma_c_qp, lambda, eta, alpha_cc, alpha_cc_f -->
{% endif %}

{% if byCode %}
Avendo scelto la seguente classe di calcestruzzo e l'ambiente di esposizione:

| Classe | Norma | Ambiente |
|--------|-------|----------|
| **{{ classe }}** | {{ norma }} | {{ environnment }} |

si assumono i seguenti valori caratteristici per il materiale
{% else %}
Per il materiale si scelgono i seguenti valori caratteristici:
{% endif %}

### Parametri del calcestruzzo

| Parametro | Valore | Parametro | Valore | Parametro | Valore |
|-----------|--------|-----------|--------|-----------|--------|
| $f_{ck}$ | {{ fck }} | $f_{cm}$ | {{ fcm }} | $f_{ctm}$ | {{ fctm }} |
| $E_{cm}$ | {{ Ecm }} | $\gamma_c$ | {{ gammac }} | | |
| $\sigma^{car}_{cd}$ | {{ sigmac_max_c }} | $\sigma^{qp}_{cd}$ | {{ sigmac_max_q }} | | |
| $e_{cu}$ | {{ ecu }} | $e_{c2}$ | {{ ec2 }} | | |
| $\lambda$ | {{ lambda }} | $\eta$ | {{ eta }} | | |
| $\alpha_{cc}$ | {{ alphacc }} | $\alpha^f_{cc}$ | {{ alphacc_fire }} | | |

{% if not byCode %}
Ai fini del calcolo a fessurazione si assume che il calcestruzzo sia in ambiente **{{ environnment }}**
{% endif %}
