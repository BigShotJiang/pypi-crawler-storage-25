Nella seguente tabella sono elencate le caratteristiche di sollecitazione nelle varie combinazioni di carico.

#figure(
  table(
    columns: (auto, auto, auto, auto, 5cm, auto, auto),
    align: (center, right, right, right, left, center, center),
    table.header(
      table.cell(rowspan: 4)[*id*],
      [$bold(F_x)$], [$bold(F_y)$], [$bold(F_z)$],
      table.cell(rowspan: 4)[*Descrizione*],
      table.cell(rowspan: 4)[*S.L.*],
      table.cell(rowspan: 4)[*FR.*],
      table.cell(colspan: 3, align: center)[#text(size: 8pt)[_\[KN\]_]],
      [$bold(M_x)$], [$bold(M_y)$], [$bold(M_z)$],
      table.cell(colspan: 3, align: center)[#text(size: 8pt)[_\[KNm\]_]],
    ),
    <%% for force in forces %%>
    table.cell(rowspan: 2)[<< force.id >>],
    [<< force.Fx >>], [<< force.Fy >>], [<< force.Fz >>],
    table.cell(rowspan: 2)[<< force.descr >>],
    table.cell(rowspan: 2)[<< force.limitState >>],
    table.cell(rowspan: 2)[<< force.frequency >>],
    [<< force.Mx >>], [<< force.My >>], [<< force.Mz >>],
    <%% endfor %%>
  ),
  caption: [Combinazioni di carico e sollecitazioni],
)

Ogni combinazione ha un identificativo unico (*id*).

La colonna *S.L.* contiene il tipo di stato limite rappresentato dalle seguenti possibilità:

- *SLU* Stati limite ultimi
- *SLE* Stati limite di esercizio

La colonna *FR.* contiene la combinazione di carico che rappresenta la frequenza:

- *RAR* Combinazione di carico rara
- *FRE* Combinazione di carico frequente
- *QP* Combinazione di carico quasi permanente
