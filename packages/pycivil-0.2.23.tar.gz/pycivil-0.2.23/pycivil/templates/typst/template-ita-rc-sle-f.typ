#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, center, right, right, right, right, right, center),
    table.header(
      table.cell(rowspan: 3)[*id*],
      table.cell(rowspan: 2)[$bold(N_(e d))$],
      table.cell(rowspan: 2)[$bold(M_(e d))$],
      [#text(size: 8pt)[*state*]],
      [$bold(w_k)$], [$bold(sigma_c)$], [$bold(sigma_s)$], [$bold(x_i)$], [$bold(epsilon_(s m))$],
      [*check*],
      [#text(size: 8pt)[*severity*]],
      [$bold(overline(w))$], [$bold(overline(sigma)_c)$], [$bold(sigma_(s,"stiff"))$], [$bold(Delta_(s m))$], [$bold(rho_("eff"))$],
      [$bold(F S)$],
      [_\[KN\]_], [_\[KNm\]_], [], [_\[mm\]_], [_\[N/mm²\]_], [_\[N/mm²\]_], [_\[mm\]_], [_\[...\]_], [],
    ),
    <%% for c in check_SLE_F %%>
    table.cell(rowspan: 2)[<< c.id >>],
    table.cell(rowspan: 2)[<< c.Ned >>],
    table.cell(rowspan: 2)[<< c.Med >>],
    [#text(size: 8pt)[<< c.state >>]],
    [<< c.wk >>], [<< c.sigmac >>], [<< c.sigmas >>], [<< c.xi >>], [#text(size: 8pt)[<< c.epsism >>]],
    [<< c.check >>],
    [#text(size: 8pt)[<< c.severity >>]],
    [<< c.wkMax >>], [<< c.fctcrack >>], [<< c.sigmasStiff >>], [<< c.deltasm >>], [#text(size: 8pt)[<< c.roeff >>]],
    [<< c.FS >>],
    <%% endfor %%>
  ),
  caption: [Verifiche FESSURAZIONE],
)

Il significato delle sigle contenute nella colonna *severity* è riportato nella tabella seguente.

#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto),
    align: (center, center, center, left, center, left, center),
    table.header(
      [*Gruppi di Esigenze*], [*Condizioni ambientali*], [*Combinazione di azioni*], [*Armatura Sensibile*], [$w_k$], [*Armatura Poco Sensibile*], [$w_k$],
    ),
    [A], [Ordinarie], [frequente], [apertura fessure A2FR], [$<= w_2$], [apertura fessure A1FR], [$<= w_3$],
    [], [], [quasi permanente], [apertura fessure A2QP], [$<= w_1$], [apertura fessure A1QP], [$<= w_2$],
    [B], [Aggressive], [frequente], [apertura fessure B2FR], [$<= w_1$], [apertura fessure B1FR], [$<= w_2$],
    [], [], [quasi permanente], [decompressione B2QP], [-], [apertura fessure B1QP], [$<= w_1$],
    [C], [Molto aggressive], [frequente], [formazione fessure C2FR], [-], [apertura fessure C1FR], [$<= w_1$],
    [], [], [quasi permanente], [decompressione C1QP], [-], [apertura fessure C2QP], [$<= w_1$],
  ),
  caption: [Tabella delle condizioni ambientali e delle armature],
)
