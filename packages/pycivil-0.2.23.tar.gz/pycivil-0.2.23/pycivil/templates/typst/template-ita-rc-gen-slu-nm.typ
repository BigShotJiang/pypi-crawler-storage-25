#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, right, right, center),
    table.header(
      [*id*], [$bold(N_(e d))$ \ _\[KN\]_], [$bold(M_(x e d))$ \ _\[KNm\]_], [$bold(M_(y e d))$ \ _\[KNm\]_], [$bold(N_(r d))$ \ _\[KN\]_], [$bold(M_(x r d))$ \ _\[KNm\]_], [$bold(M_(y r d))$ \ _\[KNm\]_], [$bold(F S)$ \ _\[...\]_], [$bold("check")$ \ _\[...\]_],
    ),
    <%% for c in check_SLU_MN %%>
    [<< c.id >>], [<< c.Ned >>], [<< c.Mxed >>], [<< c.Myed >>], [<< c.Nrd >>], [<< c.Mxrd >>], [<< c.Myrd >>], [<< c.FS >>], [<< c.check >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLU per pressoflessione retta],
)

<%% for f in figures %%>
#figure(
  grid(
    columns: 2,
    gutter: 1em,
    <%% for url in f.domainUrls %%>
    image("<< url.domainUrl >>", width: 100%),
    <%% endfor %%>
  ),
  caption: [Check agli SLU - Parte << f.figIndex >> di << nbFigs >>],
)
<%% endfor %%>
