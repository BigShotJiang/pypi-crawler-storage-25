<%% if byCode %%>
Avendo scelto la seguente classe di calcestruzzo e l'ambiente di esposizione:

$ "Classe" : underline("<< classe >>") quad "Norma" : underline("<< norma >>") quad "Ambiente" : underline("<< environnment >>") $

si assumono i seguenti valori caratteristici per il materiale
<%% else %%>
Per il materiale si scelgono i seguenti valori caratteristici:
<%% endif %%>

$ f_(c k) &= << fck >> quad& f_(c m) &= << fcm >> quad& f_(c t m) &= << fctm >> quad& E_(c m) &= << Ecm >> quad& gamma_c &= << gammac >> $

$ sigma^("car")_(c d) &= << sigmac_max_c >> quad& sigma^("qp")_(c d) &= << sigmac_max_q >> quad& e_(c u) &= << ecu >> quad& e_(c 2) &= << ec2 >> $

$ lambda &= << lambda >> quad& eta &= << eta >> quad& alpha_(c c) &= << alphacc >> quad& alpha^f_(c c) &= << alphacc_fire >> $

<%% if not byCode %%>
Ai fini del calcolo a fessurazione si assume che il calcestruzzo sia in ambiente _<< environnment >>_
<%% endif %%>
