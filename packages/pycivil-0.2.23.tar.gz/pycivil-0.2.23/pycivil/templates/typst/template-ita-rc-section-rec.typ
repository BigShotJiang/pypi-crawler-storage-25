<%% if shape == 'RECT' %%>
La sezione ha forma _rettangolare_ con le seguenti caratteristiche geometriche sono:

$ b &= << width >> " mm" quad& h &= << height >> " mm" $

ed è rappresentata nella seguente figura:

#figure(
  image("section.png", width: 60%),
  caption: [Sezione rettangolare in c.a.],
)

Essendo la sezione rettangolare appartenente comunque alle sezioni di tipo poligonale si riportano le coordinate dei vertici:

#figure(
  table(
    columns: (auto, auto, auto),
    align: (center, center, center),
    table.header(
      [*id*], [$bold(X)$ \ _\[mm\]_], [$bold(Y)$ \ _\[mm\]_],
    ),
    [$T L$], [<< xTL >>], [<< yTL >>],
    [$T R$], [<< xTR >>], [<< yTR >>],
    [$B L$], [<< xBL >>], [<< yBL >>],
    [$B R$], [<< xBR >>], [<< yBR >>],
  ),
  caption: [Tabella dei vertici],
)
<%% endif %%>

Di seguito la tabella relativa al posizionamento degli acciai, essendo $d$ il diametro ed $A$ l'area:

#figure(
  table(
    columns: (auto, auto, auto, auto, auto),
    align: (center, center, center, center, center),
    table.header(
      [*id*], [$bold(X)$ \ _\[mm\]_], [$bold(Y)$ \ _\[mm\]_], [$bold(d)$ \ _\[mm\]_], [$bold(A)$ \ _\[mm²\]_],
    ),
    <%% for r in rebars %%>
    [<< r.id >>], [<< r.xPos >>], [<< r.yPos >>], [<< r.diam >>], [<< r.area >>],
    <%% endfor %%>
  ),
  caption: [Tabella dei rinforzi],
)

Di seguito le caratteristiche dell'armatura trasversale (staffe):

$ A_(s w) &= << stirrupArea >> " mm²" quad& s &= << stirrupStep >> " mm" quad& alpha &= << stirrupAngle >> degree $
