<%% if byCode %%>
Avendo scelto la seguente classe di acciaio e la sensibilità dell'armatura:

$ "Classe" : underline("<< classe >>") quad "Norma" : underline("<< norma >>") quad "Sensibilità" : underline("<< sensitivity >>") $

si assumono i seguenti valori caratteristici per il materiale
<%% else %%>
Per il materiale si scelgono i seguenti valori caratteristici:
<%% endif %%>

$ f_(s y) &= << fsy >> quad& E_s &= << Es >> quad& gamma_s &= << gammas >> quad& sigma^("car")_(s d) &= << sigmas_max_c >> $

$ e_(s u) &= << esu >> quad& e_(s y) &= f_(s y) / E_s = << esy >> $

<%% if not byCode %%>
Ai fini del calcolo a fessurazione si assume che l'armatura sia di tipo _<< sensitivity >>_
<%% endif %%>
