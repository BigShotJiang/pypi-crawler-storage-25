#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, center),
    table.header(
      [*id*], [$bold(N_(e d))$ \ _\[KN\]_], [$bold(M_(e d))$ \ _\[KNm\]_], [$bold(N_(e r))$ \ _\[KN\]_], [$bold(M_(e r))$ \ _\[KNm\]_], [$bold(F S)$ \ _\[...\]_], [$bold("check")$ \ _\[...\]_],
    ),
    <%% for c in check_SLU_MN %%>
    [<< c.id >>], [<< c.Ned >>], [<< c.Med >>], [<< c.Ner >>], [<< c.Mer >>], [<< c.FS >>], [<< c.check >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLU per pressoflessione retta],
)

<%% if domain %%>
#figure(
  image("<< domainUrl >>", width: 90%),
  caption: [Dominio di interazione SLU per pressoflessione retta],
)
<%% endif %%>
