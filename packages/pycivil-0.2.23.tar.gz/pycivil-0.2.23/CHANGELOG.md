# Changelog

All notable changes to PyCivil will be documented in this file.

## Version 0.2.23

### New Features

1. **Plate element support in `FEModel`** — full plate pipeline now available:
   - `PlateFaceSupport` model for Winkler-type distributed face supports
   - `assignPlateFaceSupport` / `assignMultiPlateFaceSupport` — assign elastic foundation to one or many plate elements
   - `assignPlateMaterial` / `assignMultiPlateMaterial` — assign material to plate elements
   - `assignPlateThicknesses` / `assignMultiPlateThicknesses` — assign bending and membrane thicknesses
   - `platesMaterial()` and `plateThicknesses()` getters
2. **Plate local axes** — `getPlateLocal1`, `getPlateLocal2`, `getPlateLocal3`, `assignPlateLocal1`, `assignMultiPlateLocal1` following the Strand7 convention
3. **`platesTags()`** and **`platesNodesTags()`** static methods for retrieving all 2D mesh element tags and their node connectivity
4. **`platesConnectivity()`** — returns a dict of mesh plate tags to node-tag tuples
5. **Frame Winkler support** — `assignFrameWinklerSupport` / `assignMultiFrameWinklerSupport` store distributed Winkler support directly on frame elements (distinct from the nodal-spring conversion done by `addMultiFrameWinklerSpring`)
6. **Macro element concept** formalised — geometric GMSH entities (macro-elements) are explicitly tracked and mapped to their underlying mesh elements; `getMacroElementNode`, `getMacroElementFrame`, `getMacroElementPlate` return deep copies of these maps
7. **`Point3d.midpoint()`** — compute the midpoint between two 3D points

### Improvements

1. **`_assignMultiElement`** — new private generic helper that backs all `assignMulti*` methods; accepts a callable and a value, resolves macro-element tags to mesh tags, and dispatches the per-element assignment
2. Nodes are now tracked in the macro-element map when added with `addNode`, enabling round-trip lookup from geometric to mesh space

### Documentation

1. Comprehensive docstrings added to every public and protected method in `FEModel` (`fe.py`), including full `Args`, `Returns`, and `Raises` sections
2. All docstrings that mention macro-elements include the note: *a macro element is a geometric object (GMSH entity) that typically corresponds to one or more mesh entities after meshing*

### Bug Fixes

1. Fixed mypy errors in geometry and `fe` modules
2. Corrected `getMacroElementPlate` return type annotation (`tuple[int,int,int,int] | tuple[int,int,int]`)
3. Fixed `addNodeContraints` assignment: `List[bool]` is now properly cast to `Tuple[bool, bool, bool, bool, bool, bool]` before storing in `__nodeSupports`

## Version 0.2.21

### New Features

1. Extended `FEModel` with point/line element tracking (`ELEM_POINT`, `ELEM_LINE` added to `Elem` enum), custom ID-to-mesh-tag mapping via `getCustomIdForTag()`, and `groupForRename` parameter on `addNode` and `addFrame`
2. Added system-of-points support for applied vectors (`Vector3dApp`) in `EXAGeometry`, enabling operations on collections of applied 3D vectors

### Bug Fixes

1. Overrode `Vector3dApp.__add__` to preserve the applied vector type — previously `Vector3d.__add__` returned a plain `Vector3d`, causing `ForceCouple` to lose its origin after `+=` and raise `AttributeError` on `.o` access

### Improvements

1. `addFramesToGroup` now accepts a single `int` in the `tags` argument (in addition to a list)
2. `addPhysicalGroup` hardened with `try/except` for robustness; debug `print` removed
3. Fixed mypy errors in `pydmodelhelper`, `techparamplotter`, and `srvRcSecCheck`

## Version 0.2.20

### New Features

1. Added Typst report output format (`buildTypstReport()`) as a LaTeX-free alternative for PDF generation
2. Added shear reinforcement (stirrup) data to section report templates
3. Custom logo path now propagated to Markdown, HTML, and Typst report builders via `RCRectCalculator`

### Bug Fixes

1. Fixed steel tension limit for NTC2018:RFI
2. Fixed logo copy condition in `TypstReporter` using `Path.resolve()` for robust path comparison

### Improvements

1. Typst table headers now use `table.header()` for correct repeating headers on multi-page tables
2. Breakable tables enabled in the eng-cal Typst template
3. Adjusted Typst section heading levels for proper document hierarchy
4. Layout refinements in `template-eng-cal.typ` (top margin, header spacing, column widths)

## Version 0.2.19

### Bug Fixes

1. Added `Concrete_NTC2018_RFI_Enum` for NTC2018 RFI concrete support
2. Fixed `Check_SLE_F` crack value to be `bool` instead of `float`
3. Added NTC2018:RFI in known codes

## Version 0.2.18

### Bug Fixes

1. `RCRectCalculator.addForce()` now returns the `loadId` for better tracking and reference of added load cases

## Version 0.2.17

### Bug Fixes

1. Fixed markdown/HTML reports not including SLE-F (crack check), SLE-NM, and SLU-T verification results

### New Features

1. Added `pydmodelhelper.py` module in EXAUtils with helper functions to find Pydantic models in nested JSON structures:
   - `find_all_submodels()` - finds all matching model instances
   - `find_submodel()` - finds the first matching model instance

## Version 0.2.16

### Refactoring

1. Moved `SectionPlotViewEnum` and `SectionPlot` from `EXAStructural/plot.py` to `EXAStructural/rcgensolver/plot.py`

## Version 0.2.15

### Documentation

1. Added source code link to GitLab repository in README

## Version 0.2.14

### Bug Fixes

1. Logo can now be changed in reports
2. Reports now display an alternative phrase when material is not set by code
3. Steel with id -1 is no longer printed in output
4. Improved assertion handling in fe.py
5. Fixed area properties calculation in RCTemplRectEC2
6. Fixed cracked parameters computation in RCTemplRectEC2

### Improvements

1. Added copyright notice to all Python files
2. File extensions are now handled as uppercase for consistency
3. Reorganized test_obj into separate shapes and geometry test files
4. Moved version history from README to dedicated CHANGELOG.md

### Documentation

1. Added comprehensive tutorials with Quick Start examples and Marimo notebook examples
2. Expanded Docs section in README with MkDocs build instructions

## Version 0.2.13

1. Type checking improvements with mypy
2. Updated pandas-stubs and dependencies

## Version 0.2.6

1. New features in FEAModel: support for frames and load combinations

## Version 0.2.0

1. Available on PyPI via `pip install pycivil`
2. Module xstrumodeler for generic shape RC section is a requirement
3. Separated sws-mind backend to separate module
4. Added Strand7 post-processor tool
