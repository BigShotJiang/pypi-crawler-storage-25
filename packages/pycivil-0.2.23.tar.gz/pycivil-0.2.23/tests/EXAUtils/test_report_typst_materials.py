# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from pycivil.EXAStructural.codes import Code
from pycivil.EXAStructural.materials import Concrete, ConcreteSteel
from pycivil.EXAUtils.report import (
    EnumFBSection,
    ReportTemplateEnum,
    TypstReporter,
    getTypstTemplatesPath,
)
from pycivil.EXAUtils.typstReportMakers import ConcreteTypstFB, SteelConcreteTypstFB


def test_report_typst_concrete_01(tmp_path: Path):
    """Test concrete material typst fragment generation."""
    code = Code("NTC2018")

    concrete = Concrete()
    concrete.setByCode(codeObj=code, catstr="C25/30")

    typstTemplatePath = getTypstTemplatesPath()
    fragmentBuilder = ConcreteTypstFB(typstTemplatePath, concrete)

    fragmentBuilder.setFragmentOptions({"glossary": False})

    f = fragmentBuilder.buildFragment()

    reporter = TypstReporter(typstTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f], glossary=False
    )
    reporter.compileDocument(path=str(tmp_path), output_format="typ")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.typ").exists()

    # Verify content has concrete data
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "C25/30" in content or "25.0" in content

    # Compile to PDF
    reporter.compileDocument(path=str(tmp_path), output_format="pdf")
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0


def test_report_typst_steel_01(tmp_path: Path):
    """Test steel material typst fragment generation."""
    code = Code("NTC2018")

    steel = ConcreteSteel()
    steel.setByCode(code, "B450A")

    typstTemplatePath = getTypstTemplatesPath()

    fragmentBuilder = SteelConcreteTypstFB(typstTemplatePath, steel)

    fragmentBuilder.setFragmentOptions(
        {"section_title": "Acciaio B450A", "section_level": EnumFBSection.SEC_SECTION}
    )
    f1 = fragmentBuilder.buildFragment()

    steel.setByCode(code, "B450C")
    fragmentBuilder = SteelConcreteTypstFB(typstTemplatePath, steel)

    fragmentBuilder.setFragmentOptions(
        {"section_title": "Acciaio B450C", "section_level": EnumFBSection.SEC_SECTION}
    )

    # Here unsetted by code, the builder strip code used and kind of sensitivity
    steel.set_gammas(1.0)
    f2 = fragmentBuilder.buildFragment()

    reporter = TypstReporter(typstTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f1, f2])
    reporter.compileDocument(path=str(tmp_path), output_format="pdf")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0

    # Verify content has steel data
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "B450" in content or "450" in content


def test_report_typst_combined_materials(tmp_path: Path):
    """Test combined concrete and steel materials in one typst report."""
    code = Code("NTC2018")

    # Concrete
    concrete = Concrete()
    concrete.setByCode(codeObj=code, catstr="C25/30")
    typstTemplatePath = getTypstTemplatesPath()
    concreteFB = ConcreteTypstFB(typstTemplatePath, concrete)
    concreteFB.setFragmentOptions({"section_title": "Calcestruzzo C25/30"})
    f1 = concreteFB.buildFragment()

    # Steel
    steel = ConcreteSteel()
    steel.setByCode(code, "B450C")
    steelFB = SteelConcreteTypstFB(typstTemplatePath, steel)
    steelFB.setFragmentOptions({"section_title": "Acciaio B450C"})
    f2 = steelFB.buildFragment()

    reporter = TypstReporter(typstTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=[f1, f2])
    reporter.compileDocument(path=str(tmp_path), output_format="pdf")

    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "C25/30" in content or "25.0" in content
    assert "B450" in content or "450" in content
