# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from pycivil.EXAStructural.codes import Code
from pycivil.EXAUtils.report import (
    ReportTemplateEnum,
    TypstReporter,
    getTypstTemplatesPath,
)
from pycivil.EXAUtils.typstReportMakers import CodesTypstFB


def test_report_typst_codes(tmp_path: Path):
    """Test codes/bibliography typst fragment generation."""
    c1 = Code("NTC2008")
    c2 = Code("EC2:ITA")
    c3 = Code("CIRC2008")
    c4 = Code("CIRC2018")
    c5 = Code("EC2")

    typstTemplatePath = getTypstTemplatesPath()
    codes = CodesTypstFB(typstTemplatePath, [c1, c2, c3])
    codes.appendUniqueCode(c4)
    codes.appendUniqueCode(c3)
    codes.appendUniqueCode(c5)

    codes.setOptionNameList("Laws used")
    codes.setOptionSection()

    reporter = TypstReporter(typstTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.TYP_ENG_CAL,
        fragments=[codes.buildFragment()],
    )
    reporter.compileDocument(path=str(tmp_path), output_format="pdf")
    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0

    # Verify content has code references
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "Laws used" in content
