# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

"""Typst report generation tests for RC section checks.

These tests mirror test_report_markdown_rcsec_check.py but generate
Typst and PDF output instead of Markdown/HTML.
"""

import json
from pathlib import Path

from pycivil.EXAStructural.rcrecsolver.srvRcSecCheck import (
    ModelInputRcSecCheck,
    ModelOutputRcSecCheck,
    RcSecRectSolver,
)
from pycivil.EXAStructural.templateRCRect import SectionPlot
from pycivil.EXAUtils.report import (
    ReportProperties,
    ReportTemplateEnum,
    TypstReporter,
    getTypstTemplatesPath,
)


def _create_section_png(iData: ModelInputRcSecCheck, path: Path) -> None:
    """Create section plot PNG for Typst templates."""
    section = iData.buildRcsRectangular()
    if section is not None:
        plotter = SectionPlot(section)
        plotter.plot()
        plotter.save(path / "section.png")


def test_report_typst_rcsec_check_01(tmp_path: Path):
    """Test typst report generation for RC section check case 01."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_01.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_01.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    # Create section PNG
    _create_section_png(iData, tmp_path)

    typstTemplatePath = getTypstTemplatesPath()
    fragments = RcSecRectSolver.buildTypstReport(iData, oData, typstTemplatePath)

    reporter = TypstReporter(typstTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 01",
            module_name="PyCivil",
            module_version="0.2.20",
            report_designer="Test Engineer",
            report_date="2026-02-18",
            report_time="10:00",
            report_token="TYP-RCSEC-01",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=fragments)
    reporter.compileDocument(path=str(tmp_path), fileName="report", output_format="pdf")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0

    # Verify content
    content = tmp_path.joinpath("report.typ").read_text(encoding="utf-8")
    assert "Geometria della sezione" in content
    assert "Calcestruzzo" in content
    assert "Acciaio" in content


def test_report_typst_rcsec_check_02(tmp_path: Path):
    """Test typst report generation for RC section check case 02."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_02.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_02.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    # Create section PNG
    _create_section_png(iData, tmp_path)

    typstTemplatePath = getTypstTemplatesPath()
    fragments = RcSecRectSolver.buildTypstReport(iData, oData, typstTemplatePath)

    reporter = TypstReporter(typstTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 02",
            module_name="PyCivil",
            module_version="0.2.20",
            report_designer="Test Engineer",
            report_date="2026-02-18",
            report_time="11:00",
            report_token="TYP-RCSEC-02",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.TYP_ENG_CAL, fragments=fragments)
    reporter.compileDocument(path=str(tmp_path), fileName="report", output_format="pdf")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.typ").exists()
    assert tmp_path.joinpath("report.pdf").exists()
    assert tmp_path.joinpath("report.pdf").stat().st_size > 0
