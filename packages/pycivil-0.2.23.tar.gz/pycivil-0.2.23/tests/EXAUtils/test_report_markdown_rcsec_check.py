# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

"""Markdown report generation tests for RC section checks.

These tests mirror test_report_latex_rcsec_check.py but generate
markdown and HTML output instead of LaTeX/PDF.
"""

import json
from pathlib import Path

from pycivil.EXAStructural.rcrecsolver.srvRcSecCheck import (
    ModelInputRcSecCheck,
    ModelOutputRcSecCheck,
    RcSecRectSolver,
)
from pycivil.EXAUtils.report import (
    MarkdownReporter,
    ReportProperties,
    ReportTemplateEnum,
    getMarkdownTemplatesPath,
)


def test_report_markdown_rcsec_check_01(tmp_path: Path):
    """Test markdown report generation for RC section check case 01."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_01.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_01.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragments = RcSecRectSolver.buildMarkdownReport(iData, oData, markdownTemplatePath)

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 01",
            module_name="PyCivil",
            module_version="0.2.16",
            report_designer="Test Engineer",
            report_date="2026-02-03",
            report_time="10:00",
            report_token="MD-RCSEC-01",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=fragments)
    reporter.compileDocument(path=str(tmp_path), fileName="report", output_format="md")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()

    # Verify content
    content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
    assert "Geometria della sezione" in content
    assert "Calcestruzzo" in content
    assert "Acciaio" in content


def test_report_markdown_rcsec_check_01_html(tmp_path: Path):
    """Test HTML report generation for RC section check case 01."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_01.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_01.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragments = RcSecRectSolver.buildMarkdownReport(iData, oData, markdownTemplatePath)

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 01 HTML",
            module_name="PyCivil",
            module_version="0.2.16",
            report_designer="Test Engineer",
            report_date="2026-02-03",
            report_time="10:30",
            report_token="HTML-RCSEC-01",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=fragments)
    reporter.compileDocument(
        path=str(tmp_path), fileName="report", output_format="html"
    )

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()
    assert tmp_path.joinpath("report.html").exists()

    # Verify HTML content
    html_content = tmp_path.joinpath("report.html").read_text(encoding="utf-8")
    assert "<html>" in html_content
    assert "MathJax" in html_content  # Check that MathJax is included for formulas
    assert "<table>" in html_content or "<th>" in html_content


def test_report_markdown_rcsec_check_02(tmp_path: Path):
    """Test markdown report generation for RC section check case 02."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_02.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_02.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragments = RcSecRectSolver.buildMarkdownReport(iData, oData, markdownTemplatePath)

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 02",
            module_name="PyCivil",
            module_version="0.2.16",
            report_designer="Test Engineer",
            report_date="2026-02-03",
            report_time="11:00",
            report_token="MD-RCSEC-02",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=fragments)
    reporter.compileDocument(path=str(tmp_path), fileName="report", output_format="md")

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()


def test_report_markdown_rcsec_check_02_html(tmp_path: Path):
    """Test HTML report generation for RC section check case 02."""
    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_in_02.json"
    ) as jsonFile:
        jsonObjectIn = json.load(jsonFile)

    with open(
        Path(__file__).parent / "test_report_latex_rcsec_check_out_02.json"
    ) as jsonFile:
        jsonObjectOut = json.load(jsonFile)

    iData = ModelInputRcSecCheck(**jsonObjectIn)
    oData = ModelOutputRcSecCheck(**jsonObjectOut)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragments = RcSecRectSolver.buildMarkdownReport(iData, oData, markdownTemplatePath)

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.setProperties(
        ReportProperties(
            project_brief="RC Section Check - Test 02 HTML",
            module_name="PyCivil",
            module_version="0.2.16",
            report_designer="Test Engineer",
            report_date="2026-02-03",
            report_time="11:30",
            report_token="HTML-RCSEC-02",
        )
    )
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=fragments)
    reporter.compileDocument(
        path=str(tmp_path), fileName="report", output_format="html"
    )

    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()
    assert tmp_path.joinpath("report.html").exists()
