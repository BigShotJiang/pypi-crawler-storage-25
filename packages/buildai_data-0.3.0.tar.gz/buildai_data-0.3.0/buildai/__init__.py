"""BuildAI — the standard API for egocentric data."""

from buildai.client import BuildAI

__all__ = ["BuildAI"]
__version__ = "0.3.0"
