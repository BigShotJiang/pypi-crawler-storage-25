from __future__ import annotations

import json

import pytest

pydantic = pytest.importorskip("pydantic")

from time_unifier.integrations.pydantic import UTCTimeField, ZonedTimeField


class EventModel(pydantic.BaseModel):
    created_at: UTCTimeField
    local_at: ZonedTimeField


def test_pydantic_validates_and_serializes() -> None:
    payload = EventModel(
        created_at="2026-01-01T10:00:00Z",
        local_at="2026-01-01T11:00:00+01:00",
    )
    assert payload.created_at.to_iso() == "2026-01-01T10:00:00+00:00"
    encoded = (
        payload.model_dump(mode="json")
        if hasattr(payload, "model_dump")
        else json.loads(payload.json())
    )
    assert encoded["created_at"] == "2026-01-01T10:00:00+00:00"


def test_pydantic_rejects_boundary_violations() -> None:
    with pytest.raises(pydantic.ValidationError):
        EventModel(created_at="2026-01-01T10:00:00", local_at="2026-01-01T11:00:00+01:00")
    with pytest.raises(pydantic.ValidationError):
        EventModel(created_at="2026-01-01T10:00:00Z", local_at="2026-01-01T10:00:00Z")
