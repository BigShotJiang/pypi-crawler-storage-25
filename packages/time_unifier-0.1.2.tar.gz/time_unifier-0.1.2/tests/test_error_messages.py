from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from time_unifier import UTCTime, ZonedTime, ensure_utc, ensure_zoned, parse_iso, to_utc, to_zone
from time_unifier.errors import (
    AmbiguousDateTimeError,
    InvalidTimezoneError,
    MixedTimeTypeError,
    NaiveDateTimeError,
)


def test_naive_datetime_message_is_actionable() -> None:
    with pytest.raises(NaiveDateTimeError, match="Naive datetime is not allowed"):
        UTCTime(datetime(2026, 1, 1, 10, 0))
    with pytest.raises(NaiveDateTimeError, match="Use datetime.now\\(timezone.utc\\)"):
        UTCTime(datetime(2026, 1, 1, 10, 0))


def test_utc_required_message_is_actionable() -> None:
    with pytest.raises(InvalidTimezoneError, match="Convert explicitly"):
        UTCTime(datetime(2026, 1, 1, 11, 0, tzinfo=timezone(timedelta(hours=1))))


def test_zoned_required_message_is_actionable() -> None:
    with pytest.raises(InvalidTimezoneError, match="non-UTC"):
        ZonedTime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))


def test_mixed_type_compare_and_subtract_messages() -> None:
    utc_value = UTCTime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))
    zoned_value = to_zone(utc_value, "Europe/Stockholm")
    with pytest.raises(MixedTimeTypeError, match="Convert explicitly"):
        _ = utc_value == zoned_value  # type: ignore[comparison-overlap]
    with pytest.raises(MixedTimeTypeError, match="same type explicitly before subtracting"):
        _ = utc_value - zoned_value  # type: ignore[arg-type]


def test_convert_expected_type_messages() -> None:
    with pytest.raises(MixedTimeTypeError, match="Expected ZonedTime"):
        to_utc("bad-input")  # type: ignore[arg-type]
    with pytest.raises(MixedTimeTypeError, match="Expected UTCTime"):
        to_zone("bad-input", "Europe/Stockholm")  # type: ignore[arg-type]


def test_invalid_timezone_name_message() -> None:
    utc_value = UTCTime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))
    with pytest.raises(InvalidTimezoneError, match="valid IANA timezone"):
        to_zone(utc_value, "Invalid/Timezone")


def test_parse_iso_messages() -> None:
    with pytest.raises(NaiveDateTimeError, match="must include timezone information"):
        parse_iso("2026-01-01T10:00:00")
    with pytest.raises(AmbiguousDateTimeError, match="leading or trailing whitespace"):
        parse_iso(" 2026-01-01T10:00:00+00:00")
    with pytest.raises(ValueError, match="Invalid ISO datetime format"):
        parse_iso("2026-99-99T10:00:00+00:00")


def test_ensure_type_messages() -> None:
    with pytest.raises(TypeError, match="ensure_utc\\(\\.\\.\\.\\) expected datetime or UTCTime"):
        ensure_utc(123)  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="ensure_zoned\\(\\.\\.\\.\\) expected datetime or ZonedTime"):
        ensure_zoned(123)  # type: ignore[arg-type]


def test_pydantic_type_message_if_installed() -> None:
    pydantic = pytest.importorskip("pydantic")
    from time_unifier.integrations.pydantic import UTCTimeField

    class Payload(pydantic.BaseModel):
        created_at: UTCTimeField

    with pytest.raises(pydantic.ValidationError, match="Expected datetime or ISO datetime string"):
        Payload(created_at=123)
