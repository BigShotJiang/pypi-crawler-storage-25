from __future__ import annotations

import json
import subprocess
from pathlib import Path

from time_unifier.cli.check import apply_fixes, check_paths, should_fail
from time_unifier.cli.config import LintConfig, load_pyproject_config, merge_cli_overrides
from time_unifier.cli.output import render_json, render_text


def _config(fmt: str = "text") -> LintConfig:
    return LintConfig(exclude=[], ignore=set(), fail_on="warning", format=fmt)


def test_cli_detects_unsafe_patterns() -> None:
    sample = Path(__file__).parent / "fixtures" / "unsafe_datetimes.py"
    findings = check_paths([sample], _config())
    codes = {item.code for item in findings}
    assert {"TU001", "TU002", "TU003", "TU004", "TU005", "TU006", "TU007", "TU009"} <= codes
    assert should_fail(findings, "warning") is True


def test_cli_detects_default_datetime_and_mixed_types(tmp_path: Path) -> None:
    sample = tmp_path / "mixed.py"
    sample.write_text(
        "from dataclasses import dataclass, field\n"
        "from datetime import datetime, timezone\n"
        "from time_unifier import UTCTime, ZonedTime\n"
        "def bad_default(ts=datetime.now()):\n"
        "    return ts\n"
        "@dataclass\n"
        "class Job:\n"
        "    created_at: datetime = field(default=datetime.now())\n"
        "u = UTCTime(datetime.now(timezone.utc))\n"
        "z = ZonedTime(datetime(2026, 1, 1, 11, 0, tzinfo=timezone.utc).astimezone())\n"
        "x = u == z\n",
        encoding="utf-8",
    )
    findings = check_paths([sample], _config())
    codes = {item.code for item in findings}
    assert "TU008" in codes
    assert "TU010" in codes


def test_cli_detects_new_rules(tmp_path: Path) -> None:
    sample = tmp_path / "new_rules.py"
    sample.write_text(
        "from datetime import datetime, timezone\n"
        "from zoneinfo import ZoneInfo\n"
        "naive = datetime.now()\n"
        "aware = datetime.now(timezone.utc)\n"
        "a = naive.timestamp()\n"
        "b = naive < '2026-01-01T00:00:00+00:00'\n"
        "c = naive < aware\n"
        "d = aware.astimezone()\n"
        "e = ZoneInfo('Invalid/Timezone')\n",
        encoding="utf-8",
    )
    findings = check_paths([sample], _config())
    codes = {item.code for item in findings}
    assert {"TU011", "TU012", "TU013", "TU014", "TU015"} <= codes


def test_cli_json_output_shape(tmp_path: Path) -> None:
    sample = tmp_path / "sample.py"
    sample.write_text("from datetime import datetime\nx = datetime.now()\n", encoding="utf-8")
    findings = check_paths([sample], _config(fmt="json"))
    payload = json.loads(render_json(findings))
    assert payload[0]["code"] == "TU001"
    assert "suggestion" in payload[0]
    assert "consequence" in payload[0]


def test_cli_config_loading_and_overrides(tmp_path: Path) -> None:
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text(
        "[tool.time-unifier]\n"
        "exclude = [\"venv\", \".git\"]\n"
        "ignore = [\"TU007\"]\n"
        "fail_on = \"warning\"\n"
        "format = \"text\"\n",
        encoding="utf-8",
    )
    loaded = load_pyproject_config(pyproject)
    merged = merge_cli_overrides(
        loaded,
        exclude=["build"],
        ignore="TU001,TU002",
        fail_on="error",
        fmt="json",
    )
    assert "build" in merged.exclude
    assert "TU007" in merged.ignore
    assert "TU001" in merged.ignore
    assert merged.fail_on == "error"
    assert merged.format == "json"


def test_cli_text_output_includes_rule_code_and_consequence(tmp_path: Path) -> None:
    sample = tmp_path / "sample.py"
    sample.write_text("from datetime import datetime\nx = datetime.now()\n", encoding="utf-8")
    findings = check_paths([sample], _config())
    output = render_text(findings)
    assert "TU001" in output
    assert "consequence:" in output


def test_should_fail_behavior_for_warning_and_error(tmp_path: Path) -> None:
    sample = tmp_path / "warning_only.py"
    sample.write_text(
        "from datetime import datetime\n"
        "x = datetime.now().replace(tzinfo=None)\n",
        encoding="utf-8",
    )
    findings = check_paths([sample], _config())
    warning_only = [item for item in findings if item.code == "TU007"]
    assert warning_only
    assert should_fail(warning_only, "error") is False
    assert should_fail(warning_only, "warning") is True


def test_cli_fix_rewrites_safe_patterns(tmp_path: Path) -> None:
    sample = tmp_path / "fixme.py"
    sample.write_text(
        "from datetime import datetime\n"
        "a = datetime.utcnow()\n"
        "b = datetime.now()\n"
        "c = datetime.fromtimestamp(123)\n"
        "d = datetime.utcfromtimestamp(123)\n"
        "e = datetime.strptime('2026-01-01', '%Y-%m-%d')\n",
        encoding="utf-8",
    )

    changed = apply_fixes([sample], _config())
    assert sample in changed

    rewritten = sample.read_text(encoding="utf-8")
    assert "datetime.now(timezone.utc)" in rewritten
    assert "datetime.fromtimestamp(123, tz=timezone.utc)" in rewritten
    assert "TODO(time_unifier): datetime.strptime returns a naive datetime" in rewritten


# --- NEW: end-to-end CLI test --- #

def test_cli_command_execution(tmp_path: Path) -> None:
    sample = tmp_path / "sample.py"
    sample.write_text(
        "from datetime import datetime\nx = datetime.now()\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        ["time-unifier", "check", str(sample)],
        capture_output=True,
        text=True,
    )

    assert "TU001" in result.stdout
    assert result.returncode != 0