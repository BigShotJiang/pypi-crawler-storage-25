from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest

from time_unifier import UTCTime, ZonedTime, from_datetime, now_utc, to_zone, utc
from time_unifier.errors import InvalidTimezoneError, MixedTimeTypeError, NaiveDateTimeError


def test_utc_time_rejects_naive() -> None:
    with pytest.raises(NaiveDateTimeError):
        UTCTime(datetime(2026, 1, 1, 10, 0))


def test_zoned_time_rejects_naive() -> None:
    with pytest.raises(NaiveDateTimeError):
        ZonedTime(datetime(2026, 1, 1, 10, 0))


def test_utc_equivalence_accepts_zoneinfo_utc() -> None:
    value = UTCTime(datetime(2026, 1, 1, 10, 0, tzinfo=ZoneInfo("UTC")))
    assert value.to_datetime().tzinfo is timezone.utc
    assert value.to_datetime().utcoffset() == timedelta(0)


def test_zoned_time_rejects_utc_offsets() -> None:
    with pytest.raises(InvalidTimezoneError):
        ZonedTime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))


def test_stockholm_dst_changes_between_winter_and_summer() -> None:
    winter = UTCTime(datetime(2026, 1, 15, 12, 0, tzinfo=timezone.utc))
    summer = UTCTime(datetime(2026, 7, 15, 12, 0, tzinfo=timezone.utc))

    winter_local = to_zone(winter, "Europe/Stockholm")
    summer_local = to_zone(summer, "Europe/Stockholm")

    assert winter_local.offset() == timedelta(hours=1)
    assert summer_local.offset() == timedelta(hours=2)


def test_zoned_helpers_report_zone_metadata() -> None:
    value = ZonedTime(datetime(2026, 7, 15, 12, 0, tzinfo=ZoneInfo("Europe/Stockholm")))
    assert value.zone_name() == "Europe/Stockholm"
    assert value.has_named_zone() is True


def test_mixed_operations_raise_error() -> None:
    utc = now_utc()
    zoned = to_zone(utc, "Europe/Stockholm")
    with pytest.raises(MixedTimeTypeError):
        _ = utc == zoned  # type: ignore[comparison-overlap]
    with pytest.raises(MixedTimeTypeError):
        _ = utc < zoned  # type: ignore[operator]


def test_utc_alias_returns_utc_time() -> None:
    value = utc()
    assert isinstance(value, UTCTime)


def test_from_datetime_routes_to_safe_type() -> None:
    utc_value = from_datetime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))
    zoned_value = from_datetime(datetime(2026, 1, 1, 11, 0, tzinfo=ZoneInfo("Europe/Stockholm")))
    assert isinstance(utc_value, UTCTime)
    assert isinstance(zoned_value, ZonedTime)
