from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest


def test_mypy_plugin_flags_mixed_time_operations(tmp_path: Path) -> None:
    pytest.importorskip("mypy")

    target = tmp_path / "plugin_case.py"
    target.write_text(
        "from time_unifier import now_utc, to_zone\n"
        "u = now_utc()\n"
        "z = to_zone(u, 'Europe/Stockholm')\n"
        "x = u == z\n",
        encoding="utf-8",
    )

    config = tmp_path / "mypy.ini"
    config.write_text(
        "[mypy]\n"
        "plugins = time_unifier.mypy_plugin\n"
        "strict = True\n",
        encoding="utf-8",
    )

    proc = subprocess.run(
        [sys.executable, "-m", "mypy", str(target), "--config-file", str(config)],
        capture_output=True,
        text=True,
        check=False,
    )

    output = f"{proc.stdout}\n{proc.stderr}"
    assert proc.returncode != 0
    assert "time_unifier plugin: mixed-type UTC/Zoned comparison is unsafe" in output
