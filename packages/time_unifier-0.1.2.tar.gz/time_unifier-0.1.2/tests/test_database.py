from __future__ import annotations

from datetime import datetime, timezone

import pytest

from time_unifier import UTCTime, from_db_utc, to_db_utc
from time_unifier.errors import InvalidTimezoneError


def test_db_roundtrip_utc_only() -> None:
    value = UTCTime(datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc))
    serialized = to_db_utc(value)
    restored = from_db_utc(serialized)
    assert restored == value


def test_db_rejects_non_utc() -> None:
    with pytest.raises(InvalidTimezoneError):
        from_db_utc("2026-01-01T11:00:00+01:00")
