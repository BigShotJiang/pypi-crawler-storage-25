from __future__ import annotations

import pytest

from time_unifier import parse_iso, parse_utc_iso, parse_zoned_iso
from time_unifier.errors import AmbiguousDateTimeError, InvalidTimezoneError, NaiveDateTimeError
from time_unifier.integrations.fastapi import utc_param, zoned_param


@pytest.mark.parametrize("value", ["", " ", "2026-01-01", "2026-01-01T10:00:00"])
def test_parse_iso_rejects_invalid_and_naive_inputs(value: str) -> None:
    with pytest.raises((ValueError, AmbiguousDateTimeError, NaiveDateTimeError)):
        parse_iso(value)


def test_parse_utc_iso_accepts_z_suffix() -> None:
    parsed = parse_utc_iso("2026-01-01T10:00:00Z")
    assert parsed.to_iso() == "2026-01-01T10:00:00+00:00"


def test_parse_utc_iso_rejects_non_utc() -> None:
    with pytest.raises(InvalidTimezoneError):
        parse_utc_iso("2026-01-01T10:00:00+01:00")


def test_parse_zoned_iso_rejects_utc() -> None:
    with pytest.raises(InvalidTimezoneError):
        parse_zoned_iso("2026-01-01T10:00:00Z")


def test_fastapi_helpers_use_strict_parsers() -> None:
    assert utc_param("2026-01-01T10:00:00Z").to_iso() == "2026-01-01T10:00:00+00:00"
    assert zoned_param("2026-01-01T11:00:00+01:00").to_iso() == "2026-01-01T11:00:00+01:00"
