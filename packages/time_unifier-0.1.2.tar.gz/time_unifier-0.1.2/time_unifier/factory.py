from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .core import UTCTime, ZonedTime
from .errors import InvalidTimezoneError, invalid_timezone


def now_utc() -> UTCTime:
    return UTCTime(datetime.now(timezone.utc))


def utc() -> UTCTime:
    return now_utc()


def now_zone(name: str) -> ZonedTime:
    try:
        return ZonedTime(datetime.now(ZoneInfo(name)))
    except ZoneInfoNotFoundError as exc:
        raise InvalidTimezoneError(invalid_timezone(name)) from exc
