from __future__ import annotations

from .core import UTCTime, ZonedTime
from .errors import ErrorMessages
from .validation import parse_utc_iso, parse_zoned_iso


def to_json(value: UTCTime | ZonedTime) -> str:
    if isinstance(value, (UTCTime, ZonedTime)):
        return value.to_iso()
    raise TypeError(ErrorMessages.JSON_INVALID_TYPE)


def utc_from_json(value: str) -> UTCTime:
    return parse_utc_iso(value)


def zoned_from_json(value: str) -> ZonedTime:
    return parse_zoned_iso(value)
