from __future__ import annotations

from .core import UTCTime
from .errors import ErrorMessages, MixedTimeTypeError


def _require_utc_pair(a: UTCTime, b: UTCTime) -> tuple[UTCTime, UTCTime]:
    if not isinstance(a, UTCTime) or not isinstance(b, UTCTime):
        raise MixedTimeTypeError(ErrorMessages.COMPARE_HELPER_EXPECTS_UTC)
    return a, b


def is_before(a: UTCTime, b: UTCTime) -> bool:
    left, right = _require_utc_pair(a, b)
    return left.to_datetime() < right.to_datetime()


def is_after(a: UTCTime, b: UTCTime) -> bool:
    left, right = _require_utc_pair(a, b)
    return left.to_datetime() > right.to_datetime()


def is_same_instant(a: UTCTime, b: UTCTime) -> bool:
    left, right = _require_utc_pair(a, b)
    return left.to_datetime() == right.to_datetime()
