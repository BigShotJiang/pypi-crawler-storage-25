from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .errors import ErrorMessages, InvalidTimezoneError, MixedTimeTypeError, NaiveDateTimeError


@dataclass(frozen=True)
class Duration:
    _td: timedelta

    def __str__(self) -> str:
        total_seconds = int(self._td.total_seconds())
        sign = "-" if total_seconds < 0 else ""
        abs_seconds = abs(total_seconds)
        hours, remainder = divmod(abs_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"Duration({sign}{hours}:{minutes:02d}:{seconds:02d})"

    def __repr__(self) -> str:
        return self.__str__()

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Duration):
            raise TypeError(ErrorMessages.DURATION_COMPARE_TYPE)
        return self._td.total_seconds() == other._td.total_seconds()

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, Duration):
            raise TypeError(ErrorMessages.DURATION_COMPARE_TYPE)
        return self._td.total_seconds() < other._td.total_seconds()

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, Duration):
            raise TypeError(ErrorMessages.DURATION_COMPARE_TYPE)
        return self._td.total_seconds() > other._td.total_seconds()

    def __neg__(self) -> "Duration":
        return Duration(-self._td)

    def __abs__(self) -> "Duration":
        return Duration(abs(self._td))

    def seconds(self) -> float:
        return self._td.total_seconds()

    def minutes(self) -> float:
        return self._td.total_seconds() / 60

    def hours(self) -> float:
        return self._td.total_seconds() / 3600

    def days(self) -> float:
        return self._td.total_seconds() / 86400

    def is_negative(self) -> bool:
        return self._td.total_seconds() < 0

    def abs(self) -> "Duration":
        return Duration(abs(self._td))


@dataclass(frozen=True)
class UTCTime:
    _dt: datetime

    def __init__(self, dt: datetime) -> None:
        if dt.tzinfo is None or dt.utcoffset() is None:
            raise NaiveDateTimeError(ErrorMessages.NAIVE_DATETIME)
        if dt.utcoffset() != timedelta(0):
            raise InvalidTimezoneError(ErrorMessages.UTC_REQUIRED)
        object.__setattr__(self, "_dt", dt.astimezone(timezone.utc))

    def to_datetime(self) -> datetime:
        return self._dt

    def __str__(self) -> str:
        return str(self._dt)

    def __repr__(self) -> str:
        return f"UTCTime({self._dt.isoformat()})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, UTCTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt == other._dt

    def __sub__(self, other: "UTCTime") -> Duration:
        if not isinstance(other, UTCTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_SUBTRACT)
        return Duration(self._dt - other._dt)

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, UTCTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt < other._dt

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, UTCTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt > other._dt

    def to_iso(self) -> str:
        return self._dt.isoformat()

    def to_json(self) -> str:
        return self._dt.isoformat()

    def to_zone(self, name: str) -> "ZonedTime":
        from .convert import to_zone

        return to_zone(self, name)

    @classmethod
    def from_json(cls, value: str) -> "UTCTime":
        from .validation import parse_utc_iso

        return parse_utc_iso(value)


@dataclass(frozen=True)
class ZonedTime:
    _dt: datetime

    def __init__(self, dt: datetime) -> None:
        if dt.tzinfo is None or dt.utcoffset() is None:
            raise NaiveDateTimeError(ErrorMessages.NAIVE_DATETIME)
        if dt.utcoffset() == timedelta(0):
            raise InvalidTimezoneError(ErrorMessages.ZONED_REQUIRED)
        object.__setattr__(self, "_dt", dt)

    def to_datetime(self) -> datetime:
        return self._dt

    def __str__(self) -> str:
        return str(self._dt)

    def __repr__(self) -> str:
        return f"ZonedTime({self._dt.isoformat()})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ZonedTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt == other._dt

    def __sub__(self, other: "ZonedTime") -> Duration:
        if not isinstance(other, ZonedTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_SUBTRACT)
        return Duration(self._dt - other._dt)

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, ZonedTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt < other._dt

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, ZonedTime):
            raise MixedTimeTypeError(ErrorMessages.MIXED_TYPES_COMPARE)
        return self._dt > other._dt

    def to_iso(self) -> str:
        return self._dt.isoformat()

    def to_json(self) -> str:
        return self._dt.isoformat()

    def to_utc(self) -> UTCTime:
        from .convert import to_utc

        return to_utc(self)

    def zone_name(self) -> str | None:
        tzinfo = self._dt.tzinfo
        if isinstance(tzinfo, ZoneInfo):
            return tzinfo.key
        key = getattr(tzinfo, "key", None)
        if isinstance(key, str):
            return key
        name = self._dt.tzname()
        return name if name and name not in {"UTC", "GMT"} else None

    def offset(self) -> timedelta:
        offset = self._dt.utcoffset()
        assert offset is not None
        return offset

    def has_named_zone(self) -> bool:
        return self.zone_name() is not None

    @classmethod
    def from_json(cls, value: str) -> "ZonedTime":
        from .validation import parse_zoned_iso

        return parse_zoned_iso(value)
