from __future__ import annotations

from datetime import datetime

from .core import UTCTime
from .errors import ErrorMessages, InvalidTimezoneError
from .validation import ensure_utc, parse_utc_iso


def to_db_utc(value: UTCTime) -> str:
    return ensure_utc(value).to_iso()


def from_db_utc(value: str) -> UTCTime:
    return parse_utc_iso(value)


def assert_db_utc_datetime(value: datetime) -> UTCTime:
    try:
        return ensure_utc(value)
    except InvalidTimezoneError as exc:
        raise InvalidTimezoneError(ErrorMessages.DATABASE_UTC_ONLY) from exc
