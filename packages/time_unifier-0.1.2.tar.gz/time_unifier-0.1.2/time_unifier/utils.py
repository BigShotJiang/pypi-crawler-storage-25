from zoneinfo import available_timezones


def is_valid_zone(name: str) -> bool:
    return name in available_timezones()


def list_zones() -> list[str]:
    return sorted(available_timezones())
