from __future__ import annotations


def _actual_type_name(actual: object) -> str:
    return type(actual).__name__


class ErrorMessages:
    NAIVE_DATETIME = (
        "Naive datetime is not allowed. This can cause silent bugs in scheduling, auth expiry, "
        "and distributed systems. Use datetime.now(timezone.utc) or time_unifier.now_utc()."
    )
    UTC_REQUIRED = (
        "UTCTime requires a UTC datetime with offset +00:00. Non-UTC values break internal "
        "ordering guarantees and cross-service consistency. Convert explicitly with "
        "time_unifier.to_utc(...) before creating UTCTime."
    )
    ZONED_REQUIRED = (
        "ZonedTime requires a non-UTC timezone-aware datetime. Treating UTC as zoned boundary "
        "time hides conversion mistakes in APIs and UI rendering. Use UTCTime for UTC values, "
        "or time_unifier.to_zone(...) for display/local time."
    )
    MIXED_TYPES_COMPARE = (
        "Cannot compare different time types. Mixed UTC/local comparisons can flip ordering in "
        "backend workflows. Convert explicitly with time_unifier.to_utc(...) or "
        "time_unifier.to_zone(...) before comparing."
    )
    MIXED_TYPES_SUBTRACT = (
        "Cannot subtract different time types. Mixed subtraction can produce false durations in "
        "retry windows and SLA calculations. Convert both values to the same type explicitly "
        "before subtracting."
    )
    EXPECTED_UTC_TIME = (
        "Expected UTCTime. Pass a UTCTime value or convert explicitly with "
        "time_unifier.to_utc(...)."
    )
    EXPECTED_ZONED_TIME = (
        "Expected ZonedTime. Pass a ZonedTime value or convert explicitly with "
        "time_unifier.to_zone(...)."
    )
    ISO_EMPTY = "ISO datetime string must not be empty."
    ISO_WHITESPACE = "ISO datetime string must not contain leading or trailing whitespace."
    ISO_MISSING_TIME_SEPARATOR = (
        "ISO datetime string must include a time separator 'T', for example "
        "'2026-01-01T10:00:00+00:00'."
    )
    ISO_MISSING_TIMEZONE = (
        "ISO datetime string must include timezone information. Missing offsets create "
        "environment-dependent behavior in backend parsing. Use 'Z' or an explicit offset "
        "such as '+00:00'."
    )
    ISO_INVALID_FORMAT = (
        "Invalid ISO datetime format. Expected a timezone-aware ISO datetime such as "
        "'2026-01-01T10:00:00+00:00'."
    )
    UTC_ISO_REQUIRED = (
        "Expected a UTC ISO datetime with offset +00:00 or 'Z'. "
        "Non-UTC offsets must be parsed with parse_zoned_iso(...)."
    )
    ZONED_ISO_REQUIRED = (
        "Expected a non-UTC zoned ISO datetime. "
        "UTC values must be parsed with parse_utc_iso(...)."
    )
    INVALID_ENSURE_UTC_TYPE = (
        "ensure_utc(...) expected datetime or UTCTime. "
        "Pass a timezone-aware datetime or a UTCTime value."
    )
    INVALID_ENSURE_ZONED_TYPE = (
        "ensure_zoned(...) expected datetime or ZonedTime. "
        "Pass a non-UTC timezone-aware datetime or a ZonedTime value."
    )
    PYDANTIC_INVALID_TYPE = (
        "Expected datetime or ISO datetime string. "
        "time_unifier fields reject naive or ambiguous time values."
    )
    PYDANTIC_CORE_REQUIRED = "pydantic v2 support requires pydantic-core."
    DATABASE_UTC_ONLY = (
        "Database boundary accepts UTC only. Storing non-UTC values causes drift across workers "
        "and replicas. "
        "Store UTCTime values using time_unifier.to_db_utc(...)."
    )
    JSON_INVALID_TYPE = "JSON serialization expects UTCTime or ZonedTime."
    DURATION_COMPARE_TYPE = "Cannot compare Duration with non-Duration value."
    COMPARE_HELPER_EXPECTS_UTC = (
        "Comparison helpers expect UTCTime values. "
        "Convert explicitly with time_unifier.to_utc(...)."
    )


def invalid_timezone(name: str) -> str:
    return (
        f"Invalid timezone name: {name}. Unknown zones fail at runtime and can break "
        "scheduling and user-facing timestamps. Use a valid IANA timezone such as "
        "'UTC', 'Europe/Stockholm', or 'America/New_York'."
    )


def expected_type(expected: str, actual: object) -> str:
    return f"Expected {expected}. Received {_actual_type_name(actual)}."


def invalid_input_type(expected: str, actual: object) -> str:
    return (
        f"Invalid input type. Expected {expected}. "
        f"Received {_actual_type_name(actual)}."
    )


class TimeError(Exception):
    """Base error for all time_unifier exceptions."""


class NaiveDateTimeError(TimeError, ValueError):
    """Raised when datetime has no timezone info."""

    def __init__(self, message: str = ErrorMessages.NAIVE_DATETIME) -> None:
        super().__init__(message)


class InvalidTimezoneError(TimeError, ValueError):
    """Raised when a timezone name or value is invalid."""

    def __init__(self, message: str = ErrorMessages.UTC_REQUIRED) -> None:
        super().__init__(message)


class AmbiguousDateTimeError(TimeError, ValueError):
    """Raised when a datetime string cannot be interpreted unambiguously."""


class MixedTimeTypeError(TimeError, TypeError):
    """Raised when combining different wrapped time types."""

    def __init__(self, message: str = ErrorMessages.MIXED_TYPES_COMPARE) -> None:
        super().__init__(message)
