from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Literal
from zoneinfo import available_timezones

Severity = Literal["warning", "error"]
Kind = Literal["utc", "zoned", "naive_datetime", "aware_datetime", "string", "unknown"]
DATETIME_KINDS = {"naive_datetime", "aware_datetime"}


@dataclass(frozen=True)
class RuleSpec:
    code: str
    message: str
    consequence: str
    suggestion: str
    severity: Severity


RULES: dict[str, RuleSpec] = {
    "TU001": RuleSpec(
        "TU001",
        "datetime.now() used without timezone.",
        "Naive timestamps drift across hosts and can break auth, scheduling, and ordering logic.",
        "Use datetime.now(timezone.utc) or time_unifier.now_utc().",
        "error",
    ),
    "TU002": RuleSpec(
        "TU002",
        "datetime.utcnow() usage detected.",
        "utcnow() returns a naive datetime that often gets stored as local time by accident.",
        "Use datetime.now(timezone.utc) instead.",
        "error",
    ),
    "TU003": RuleSpec(
        "TU003",
        "datetime(...) constructor used without tzinfo.",
        "Naive constructor values silently cross timezone boundaries in backend services.",
        "Pass tzinfo=timezone.utc or parse a timezone-aware value.",
        "error",
    ),
    "TU004": RuleSpec(
        "TU004",
        "datetime.fromtimestamp() used without timezone.",
        "Timestamp conversion without tz depends on local machine settings and causes production drift.",
        "Use datetime.fromtimestamp(ts, tz=timezone.utc).",
        "error",
    ),
    "TU005": RuleSpec(
        "TU005",
        "datetime.utcfromtimestamp() usage detected.",
        "utcfromtimestamp() returns naive datetimes that are frequently misinterpreted later.",
        "Use datetime.fromtimestamp(ts, tz=timezone.utc) instead.",
        "error",
    ),
    "TU006": RuleSpec(
        "TU006",
        "datetime.strptime() creates a naive datetime.",
        "Parsed values without timezone metadata break boundary contracts and event ordering.",
        "Attach timezone explicitly and convert using time_unifier helpers.",
        "error",
    ),
    "TU007": RuleSpec(
        "TU007",
        "replace(tzinfo=...) usage detected.",
        "Patching tzinfo rewrites metadata without conversion and can corrupt real instants.",
        "Parse with timezone information or convert explicitly with to_utc(...) / to_zone(...).",
        "warning",
    ),
    "TU008": RuleSpec(
        "TU008",
        "Default datetime evaluated at import time.",
        "Import-time defaults freeze stale timestamps and break retries, expiry, and scheduler behavior.",
        "Use default_factory or compute the value inside function execution.",
        "error",
    ),
    "TU009": RuleSpec(
        "TU009",
        "isoformat() called on a naive datetime.",
        "Serializing naive datetimes leaks ambiguous API/database payloads.",
        "Ensure timezone awareness before serialization.",
        "error",
    ),
    "TU010": RuleSpec(
        "TU010",
        "Potential mixed UTCTime/ZonedTime operation.",
        "Comparing UTC and boundary-local types directly causes hidden conversion bugs.",
        "Convert explicitly using to_utc(...) or to_zone(...) before operating.",
        "warning",
    ),
    "TU011": RuleSpec(
        "TU011",
        "datetime.timestamp() used on a possibly naive datetime.",
        "epoch conversion on naive datetimes depends on local timezone and causes drift in queues and TTLs.",
        "Use timezone-aware datetime values before calling timestamp().",
        "error",
    ),
    "TU012": RuleSpec(
        "TU012",
        "Comparison between datetime and string detected.",
        "Lexical string comparisons hide chronological ordering bugs in backend decision paths.",
        "Parse strings to strict typed time values before comparing.",
        "error",
    ),
    "TU013": RuleSpec(
        "TU013",
        "Naive and timezone-aware datetime values are mixed.",
        "Mixed datetime awareness causes inconsistent ordering and cross-service incident noise.",
        "Normalize both sides to timezone-aware values, preferably UTC.",
        "error",
    ),
    "TU014": RuleSpec(
        "TU014",
        "Unknown timezone string literal detected.",
        "Invalid zones fail at runtime and can block scheduling or user-facing time rendering.",
        "Use a valid IANA zone name such as 'UTC' or 'Europe/Stockholm'.",
        "error",
    ),
    "TU015": RuleSpec(
        "TU015",
        "Implicit timezone conversion via astimezone() without target zone.",
        "Implicit local-zone conversion depends on host settings and environment drift.",
        "Pass an explicit zone to astimezone(...), or use time_unifier.to_zone(...).",
        "warning",
    ),
}


_KNOWN_ZONES = available_timezones()


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    column: int
    code: str
    message: str
    consequence: str
    suggestion: str
    severity: Severity


class RuleEngine(ast.NodeVisitor):
    def __init__(self, path: str) -> None:
        self.path = path
        self.findings: list[Finding] = []
        self.var_kinds: dict[str, Kind] = {}

    def visit_Assign(self, node: ast.Assign) -> None:
        kind = self._expr_kind(node.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.var_kinds[target.id] = kind
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if isinstance(node.target, ast.Name) and node.value is not None:
            self.var_kinds[node.target.id] = self._expr_kind(node.value)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        defaults = list(node.args.defaults) + [item for item in node.args.kw_defaults if item is not None]
        for default in defaults:
            if self._looks_like_eager_datetime(default):
                self._add(default, "TU008")
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        is_dataclass = any(self._is_dataclass_decorator(deco) for deco in node.decorator_list)
        if is_dataclass:
            for stmt in node.body:
                default_expr = self._extract_dataclass_default(stmt)
                if default_expr is not None and self._looks_like_eager_datetime(default_expr):
                    self._add(default_expr, "TU008")
        self.generic_visit(node)

    def visit_BinOp(self, node: ast.BinOp) -> None:
        left_kind = self._expr_kind(node.left)
        right_kind = self._expr_kind(node.right)
        if isinstance(node.op, ast.Sub):
            if self._is_mixed_time(left_kind, right_kind):
                self._add(node, "TU010")
            if self._is_naive_aware_mix(left_kind, right_kind):
                self._add(node, "TU013")
        self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> None:
        left_expr = node.left
        for right_expr in node.comparators:
            left_kind = self._expr_kind(left_expr)
            right_kind = self._expr_kind(right_expr)
            if self._is_mixed_time(left_kind, right_kind):
                self._add(node, "TU010")
            if self._is_naive_aware_mix(left_kind, right_kind):
                self._add(node, "TU013")
            if self._is_datetime_string_mix(left_kind, right_kind):
                self._add(node, "TU012")
            left_expr = right_expr
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if self._is_datetime_now(node) and not node.args and not self._has_keyword(node, "tz") and not self._has_keyword(node, "tzinfo"):
            self._add(node, "TU001")
        if self._is_datetime_utcnow(node):
            self._add(node, "TU002")
        if self._is_datetime_ctor(node) and not self._has_keyword(node, "tzinfo"):
            self._add(node, "TU003")
        if self._is_datetime_fromtimestamp(node) and not self._has_keyword(node, "tz"):
            self._add(node, "TU004")
        if self._is_datetime_utcfromtimestamp(node):
            self._add(node, "TU005")
        if self._is_datetime_strptime(node):
            self._add(node, "TU006")
        if self._is_replace_tzinfo(node):
            self._add(node, "TU007")
        if self._is_naive_isoformat(node):
            self._add(node, "TU009")
        if self._is_naive_timestamp(node):
            self._add(node, "TU011")
        if self._is_implicit_astimezone(node):
            self._add(node, "TU015")
        if self._has_invalid_zone_literal(node):
            self._add(node, "TU014")
        self.generic_visit(node)

    def _add(self, node: ast.AST, code: str) -> None:
        rule = RULES[code]
        self.findings.append(
            Finding(
                path=self.path,
                line=getattr(node, "lineno", 0),
                column=getattr(node, "col_offset", 0) + 1,
                code=rule.code,
                message=rule.message,
                consequence=rule.consequence,
                suggestion=rule.suggestion,
                severity=rule.severity,
            )
        )

    def _expr_kind(self, expr: ast.AST) -> Kind:
        if isinstance(expr, ast.Name):
            return self.var_kinds.get(expr.id, "unknown")
        if isinstance(expr, ast.Constant):
            if isinstance(expr.value, str):
                return "string"
            return "unknown"
        if not isinstance(expr, ast.Call):
            return "unknown"

        called = self._call_name(expr)
        if called in {"UTCTime", "now_utc", "to_utc", "parse_utc_iso", "ensure_utc", "from_db_utc", "utc_from_json"}:
            return "utc"
        if called in {"ZonedTime", "now_zone", "to_zone", "parse_zoned_iso", "ensure_zoned", "zoned_from_json"}:
            return "zoned"

        if called == "datetime.now":
            if expr.args or self._has_keyword(expr, "tz") or self._has_keyword(expr, "tzinfo"):
                return "aware_datetime"
            return "naive_datetime"
        if called == "datetime.utcnow":
            return "naive_datetime"
        if called == "datetime":
            return "aware_datetime" if self._has_keyword(expr, "tzinfo") else "naive_datetime"
        if called == "datetime.fromtimestamp":
            if len(expr.args) >= 2 or self._has_keyword(expr, "tz"):
                return "aware_datetime"
            return "naive_datetime"
        if called == "datetime.utcfromtimestamp":
            return "naive_datetime"
        if called == "datetime.strptime":
            return "naive_datetime"
        return "unknown"

    def _is_mixed_time(self, left: Kind, right: Kind) -> bool:
        return {left, right} == {"utc", "zoned"}

    def _is_naive_aware_mix(self, left: Kind, right: Kind) -> bool:
        return {left, right} == {"naive_datetime", "aware_datetime"}

    def _is_datetime_string_mix(self, left: Kind, right: Kind) -> bool:
        return ((left in DATETIME_KINDS and right == "string") or (right in DATETIME_KINDS and left == "string"))

    def _is_naive_isoformat(self, node: ast.Call) -> bool:
        if not (isinstance(node.func, ast.Attribute) and node.func.attr == "isoformat"):
            return False
        return self._expr_kind(node.func.value) == "naive_datetime"

    def _is_naive_timestamp(self, node: ast.Call) -> bool:
        if not (isinstance(node.func, ast.Attribute) and node.func.attr == "timestamp"):
            return False
        return self._expr_kind(node.func.value) == "naive_datetime"

    def _is_replace_tzinfo(self, node: ast.Call) -> bool:
        return isinstance(node.func, ast.Attribute) and node.func.attr == "replace" and self._has_keyword(node, "tzinfo")

    def _is_implicit_astimezone(self, node: ast.Call) -> bool:
        if not (isinstance(node.func, ast.Attribute) and node.func.attr == "astimezone"):
            return False
        return not node.args and not self._has_keyword(node, "tz")

    def _has_invalid_zone_literal(self, node: ast.Call) -> bool:
        called = self._call_name(node)
        zone_literal: str | None = None

        if called in {"ZoneInfo", "now_zone"} and node.args:
            zone_literal = self._string_literal(node.args[0])
        elif called == "to_zone":
            if len(node.args) >= 2:
                zone_literal = self._string_literal(node.args[1])
            else:
                for keyword in node.keywords:
                    if keyword.arg in {"name", "zone"}:
                        zone_literal = self._string_literal(keyword.value)
                        break

        if zone_literal is None:
            return False
        return zone_literal not in _KNOWN_ZONES

    def _looks_like_eager_datetime(self, expr: ast.AST) -> bool:
        kind = self._expr_kind(expr)
        return kind in {"naive_datetime", "aware_datetime"}

    def _extract_dataclass_default(self, stmt: ast.stmt) -> ast.AST | None:
        if isinstance(stmt, ast.AnnAssign):
            return self._extract_field_default(stmt.value)
        if isinstance(stmt, ast.Assign):
            return self._extract_field_default(stmt.value)
        return None

    def _extract_field_default(self, expr: ast.AST | None) -> ast.AST | None:
        if expr is None:
            return None
        if isinstance(expr, ast.Call) and self._call_name(expr) == "field":
            for keyword in expr.keywords:
                if keyword.arg == "default":
                    return keyword.value
        return expr

    def _is_dataclass_decorator(self, decorator: ast.expr) -> bool:
        if isinstance(decorator, ast.Name):
            return decorator.id == "dataclass"
        if isinstance(decorator, ast.Attribute):
            return decorator.attr == "dataclass"
        return False

    def _is_datetime_now(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime.now"

    def _is_datetime_utcnow(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime.utcnow"

    def _is_datetime_fromtimestamp(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime.fromtimestamp"

    def _is_datetime_utcfromtimestamp(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime.utcfromtimestamp"

    def _is_datetime_strptime(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime.strptime"

    def _is_datetime_ctor(self, node: ast.Call) -> bool:
        return self._call_name(node) == "datetime"

    def _call_name(self, node: ast.Call) -> str:
        func = node.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            base = self._expr_name(func.value)
            return f"{base}.{func.attr}" if base else func.attr
        return ""

    def _expr_name(self, expr: ast.expr) -> str:
        if isinstance(expr, ast.Name):
            return expr.id
        if isinstance(expr, ast.Attribute):
            base = self._expr_name(expr.value)
            return f"{base}.{expr.attr}" if base else expr.attr
        return ""

    def _has_keyword(self, node: ast.Call, name: str) -> bool:
        return any(keyword.arg == name for keyword in node.keywords)

    def _string_literal(self, node: ast.AST) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None
