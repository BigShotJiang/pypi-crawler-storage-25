from __future__ import annotations

from dataclasses import dataclass, field
import importlib
from pathlib import Path
from typing import Any


@dataclass
class LintConfig:
    exclude: list[str] = field(default_factory=lambda: ["venv", ".git", "__pycache__"])
    ignore: set[str] = field(default_factory=set)
    fail_on: str = "error"
    format: str = "text"


def _split_csv(values: str | list[str] | None) -> list[str]:
    if values is None:
        return []
    if isinstance(values, list):
        out: list[str] = []
        for value in values:
            out.extend(_split_csv(value))
        return out
    return [item.strip() for item in values.split(",") if item.strip()]


def load_pyproject_config(path: Path) -> LintConfig:
    config = LintConfig()
    if not path.exists():
        return config
    try:
        toml_module = importlib.import_module("tomllib")
    except ModuleNotFoundError:
        try:
            toml_module = importlib.import_module("tomli")
        except ModuleNotFoundError:
            return config
    raw: dict[str, Any]
    with path.open("rb") as fh:
        raw = toml_module.load(fh)
    section = raw.get("tool", {}).get("time-unifier", {})
    if not isinstance(section, dict):
        return config

    exclude = section.get("exclude")
    ignore = section.get("ignore")
    fail_on = section.get("fail_on")
    fmt = section.get("format")

    if isinstance(exclude, list):
        config.exclude = [str(item) for item in exclude]
    if isinstance(ignore, list):
        config.ignore = {str(item) for item in ignore}
    if isinstance(fail_on, str):
        config.fail_on = fail_on
    if isinstance(fmt, str):
        config.format = fmt
    return config


def merge_cli_overrides(
    config: LintConfig,
    exclude: list[str] | None,
    ignore: str | None,
    fail_on: str | None,
    fmt: str | None,
) -> LintConfig:
    merged = LintConfig(
        exclude=list(config.exclude),
        ignore=set(config.ignore),
        fail_on=config.fail_on,
        format=config.format,
    )
    if exclude:
        merged.exclude.extend(exclude)
    if ignore:
        merged.ignore.update(_split_csv(ignore))
    if fail_on:
        merged.fail_on = fail_on
    if fmt:
        merged.format = fmt
    return merged
