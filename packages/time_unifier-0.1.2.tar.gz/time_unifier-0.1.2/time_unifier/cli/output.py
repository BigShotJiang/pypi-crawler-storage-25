from __future__ import annotations

import json

from .rules import Finding


def render_text(findings: list[Finding]) -> str:
    lines: list[str] = []
    for finding in findings:
        lines.append(
            f"{finding.path}:{finding.line}:{finding.column}: "
            f"{finding.code} {finding.message}"
        )
        lines.append(f"  consequence: {finding.consequence}")
        lines.append(f"  suggestion: {finding.suggestion}")
    if findings:
        lines.append(f"{len(findings)} datetime safety issue(s) found")
    else:
        lines.append("No datetime safety issues found")
    return "\n".join(lines)


def render_json(findings: list[Finding]) -> str:
    payload = [
        {
            "path": finding.path,
            "line": finding.line,
            "column": finding.column,
            "code": finding.code,
            "message": finding.message,
            "consequence": finding.consequence,
            "suggestion": finding.suggestion,
            "severity": finding.severity,
        }
        for finding in findings
    ]
    return json.dumps(payload, indent=2, sort_keys=True)
