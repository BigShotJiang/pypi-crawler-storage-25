from __future__ import annotations

import ast
import fnmatch
from pathlib import Path
from typing import Sequence

from .config import LintConfig
from .fix import apply_safe_fixes
from .rules import Finding, RuleEngine


def _excluded(path: Path, patterns: Sequence[str]) -> bool:
    path_posix = path.as_posix()
    for pattern in patterns:
        if fnmatch.fnmatch(path_posix, pattern) or any(part == pattern for part in path.parts):
            return True
    return False


def iter_python_files(paths: Sequence[Path], exclude: Sequence[str]) -> list[Path]:
    files: list[Path] = []
    for path in paths:
        if _excluded(path, exclude):
            continue
        if path.is_file() and path.suffix == ".py":
            files.append(path)
        elif path.is_dir():
            for child in path.rglob("*.py"):
                if not _excluded(child, exclude):
                    files.append(child)
    return files


def check_paths(paths: Sequence[Path], config: LintConfig) -> list[Finding]:
    findings: list[Finding] = []
    for path in iter_python_files(paths, config.exclude):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError:
            continue
        engine = RuleEngine(str(path))
        engine.visit(tree)
        findings.extend(engine.findings)

    filtered = [finding for finding in findings if finding.code not in config.ignore]
    return filtered


def apply_fixes(paths: Sequence[Path], config: LintConfig) -> list[Path]:
    changed: list[Path] = []
    for path in iter_python_files(paths, config.exclude):
        source = path.read_text(encoding="utf-8")
        updated, was_changed = apply_safe_fixes(source)
        if not was_changed:
            continue
        path.write_text(updated, encoding="utf-8")
        changed.append(path)
    return changed


def should_fail(findings: list[Finding], fail_on: str) -> bool:
    if fail_on == "warning":
        return len(findings) > 0
    return any(finding.severity == "error" for finding in findings)
