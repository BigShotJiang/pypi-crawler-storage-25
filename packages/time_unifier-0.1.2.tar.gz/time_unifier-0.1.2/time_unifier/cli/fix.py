from __future__ import annotations

import ast
from dataclasses import dataclass


_STRPTIME_COMMENT = (
    "TODO(time_unifier): datetime.strptime returns a naive datetime; "
    "attach timezone explicitly before boundary use."
)


@dataclass(frozen=True)
class TextEdit:
    start: int
    end: int
    replacement: str


def apply_safe_fixes(source: str) -> tuple[str, bool]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source, False

    line_offsets = _line_offsets(source)
    edits: list[TextEdit] = []
    strptime_lines: set[int] = set()
    needs_timezone = False

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node)

        if call_name == "datetime.utcnow" and not node.args and not node.keywords:
            start, end = _span(node, line_offsets)
            edits.append(TextEdit(start, end, "datetime.now(timezone.utc)"))
            needs_timezone = True
            continue

        if call_name == "datetime.now" and not node.args and not node.keywords:
            start, end = _span(node, line_offsets)
            edits.append(TextEdit(start, end, "datetime.now(timezone.utc)"))
            needs_timezone = True
            continue

        if call_name == "datetime.fromtimestamp" and _can_fix_fromtimestamp(node):
            argument = ast.get_source_segment(source, node.args[0]) if node.args else None
            if argument:
                start, end = _span(node, line_offsets)
                edits.append(
                    TextEdit(
                        start,
                        end,
                        f"datetime.fromtimestamp({argument}, tz=timezone.utc)",
                    )
                )
                needs_timezone = True
            continue

        if call_name == "datetime.utcfromtimestamp" and len(node.args) == 1 and not node.keywords:
            argument = ast.get_source_segment(source, node.args[0])
            if argument:
                start, end = _span(node, line_offsets)
                edits.append(
                    TextEdit(
                        start,
                        end,
                        f"datetime.fromtimestamp({argument}, tz=timezone.utc)",
                    )
                )
                needs_timezone = True
            continue

        if call_name == "datetime.strptime":
            strptime_lines.add(node.lineno)

    if not edits and not strptime_lines:
        return source, False

    updated = _apply_edits(source, edits)
    updated = _add_strptime_comments(updated, strptime_lines)
    if needs_timezone:
        updated = _ensure_timezone_import(updated)
    return updated, updated != source


def _line_offsets(text: str) -> list[int]:
    offsets = [0]
    running = 0
    for line in text.splitlines(keepends=True):
        running += len(line)
        offsets.append(running)
    return offsets


def _span(node: ast.Call, line_offsets: list[int]) -> tuple[int, int]:
    if node.end_lineno is None or node.end_col_offset is None:
        raise ValueError("Autofix requires end position metadata.")
    start = line_offsets[node.lineno - 1] + node.col_offset
    end = line_offsets[node.end_lineno - 1] + node.end_col_offset
    return start, end


def _apply_edits(source: str, edits: list[TextEdit]) -> str:
    if not edits:
        return source
    ordered = sorted(edits, key=lambda edit: edit.start, reverse=True)
    updated = source
    for edit in ordered:
        updated = updated[: edit.start] + edit.replacement + updated[edit.end :]
    return updated


def _add_strptime_comments(source: str, lines: set[int]) -> str:
    if not lines:
        return source
    source_lines = source.splitlines(keepends=False)
    for line_no in sorted(lines):
        if line_no <= 0 or line_no > len(source_lines):
            continue
        line = source_lines[line_no - 1]
        if "datetime.strptime" not in line or _STRPTIME_COMMENT in line:
            continue
        if "#" in line:
            continue
        source_lines[line_no - 1] = f"{line}  # {_STRPTIME_COMMENT}"
    trailing_newline = source.endswith("\n")
    rebuilt = "\n".join(source_lines)
    if trailing_newline:
        rebuilt += "\n"
    return rebuilt


def _ensure_timezone_import(source: str) -> str:
    if "timezone.utc" not in source:
        return source
    if _has_timezone_import(source):
        return source

    lines = source.splitlines(keepends=True)
    insert_index = 0

    if lines and lines[0].startswith("#!"):
        insert_index = 1
    if insert_index < len(lines) and lines[insert_index].startswith("# -*- coding"):
        insert_index += 1

    try:
        tree = ast.parse(source)
    except SyntaxError:
        tree = None

    if tree and tree.body and isinstance(tree.body[0], ast.Expr):
        expr = tree.body[0].value
        if isinstance(expr, ast.Constant) and isinstance(expr.value, str):
            insert_index = max(insert_index, tree.body[0].end_lineno or insert_index)

    if tree:
        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                insert_index = max(insert_index, node.end_lineno or insert_index)

    lines.insert(insert_index, "from datetime import timezone\n")
    return "".join(lines)


def _has_timezone_import(source: str) -> bool:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return False
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and node.module == "datetime":
            if any(alias.name == "timezone" for alias in node.names):
                return True
    return False


def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        base = _expr_name(func.value)
        return f"{base}.{func.attr}" if base else func.attr
    return ""


def _expr_name(expr: ast.expr) -> str:
    if isinstance(expr, ast.Name):
        return expr.id
    if isinstance(expr, ast.Attribute):
        base = _expr_name(expr.value)
        return f"{base}.{expr.attr}" if base else expr.attr
    return ""


def _can_fix_fromtimestamp(node: ast.Call) -> bool:
    if node.keywords:
        return False
    if len(node.args) != 1:
        return False
    return True
