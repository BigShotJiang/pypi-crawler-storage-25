from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from .check import apply_fixes, check_paths, should_fail
from .config import load_pyproject_config, merge_cli_overrides
from .output import render_json, render_text


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="time-unifier")
    subparsers = parser.add_subparsers(dest="command", required=True)

    check_parser = subparsers.add_parser("check")
    check_parser.add_argument("paths", nargs="+")
    check_parser.add_argument("--format", choices=["text", "json"], dest="fmt")
    check_parser.add_argument("--fail-on", choices=["warning", "error"], dest="fail_on")
    check_parser.add_argument("--ignore")
    check_parser.add_argument("--exclude", action="append")
    check_parser.add_argument("--config", default="pyproject.toml")
    check_parser.add_argument("--fix", action="store_true")

    args = parser.parse_args(argv)
    if args.command != "check":
        return 2

    loaded = load_pyproject_config(Path(args.config))
    merged = merge_cli_overrides(
        loaded,
        exclude=args.exclude,
        ignore=args.ignore,
        fail_on=args.fail_on,
        fmt=args.fmt,
    )

    target_paths = [Path(path) for path in args.paths]
    if args.fix:
        changed = apply_fixes(target_paths, merged)
        if merged.format == "text":
            if changed:
                print(f"Applied safe fixes to {len(changed)} file(s).")
            else:
                print("No safe autofixes were applicable.")
    findings = check_paths(target_paths, merged)

    if merged.format == "json":
        print(render_json(findings))
    else:
        print(render_text(findings))

    return 1 if should_fail(findings, merged.fail_on) else 0


if __name__ == "__main__":
    raise SystemExit(main())
