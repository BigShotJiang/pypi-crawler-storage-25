from __future__ import annotations

from typing import Callable

from mypy.plugin import FunctionContext, MethodContext, Plugin
from mypy.types import AnyType, Instance, Type, UnionType, get_proper_type

UTC_FULLNAME = "time_unifier.core.UTCTime"
ZONED_FULLNAME = "time_unifier.core.ZonedTime"

_UTC_ONLY_FUNCTIONS = {
    "time_unifier.compare.is_before",
    "time_unifier.compare.is_after",
    "time_unifier.compare.is_same_instant",
}


def _is_named_or_union(value: Type, fullname: str) -> bool:
    proper = get_proper_type(value)
    if isinstance(proper, AnyType):
        return True
    if isinstance(proper, Instance):
        return proper.type.fullname == fullname
    if isinstance(proper, UnionType):
        return all(_is_named_or_union(item, fullname) for item in proper.items)
    return False


def _first_arg_type(ctx: FunctionContext | MethodContext) -> Type | None:
    if not ctx.arg_types:
        return None
    for candidates in ctx.arg_types:
        if candidates:
            return candidates[0]
    return None


def _check_expected(
    ctx: FunctionContext | MethodContext,
    value: Type | None,
    expected_fullname: str,
    message: str,
) -> None:
    if value is None:
        return
    if _is_named_or_union(value, expected_fullname):
        return
    ctx.api.fail(message, ctx.context)


def _method_hook(ctx: MethodContext, fullname: str) -> Type:
    method = fullname.rsplit(".", 1)[-1]
    receiver = ctx.type
    arg_type = _first_arg_type(ctx)

    if method in {"__eq__", "__lt__", "__gt__"}:
        if _is_named_or_union(receiver, UTC_FULLNAME):
            _check_expected(
                ctx,
                arg_type,
                UTC_FULLNAME,
                "time_unifier plugin: mixed-type UTC/Zoned comparison is unsafe. "
                "Convert explicitly with to_utc(...) or to_zone(...).",
            )
        if _is_named_or_union(receiver, ZONED_FULLNAME):
            _check_expected(
                ctx,
                arg_type,
                ZONED_FULLNAME,
                "time_unifier plugin: mixed-type UTC/Zoned comparison is unsafe. "
                "Convert explicitly with to_utc(...) or to_zone(...).",
            )

    if method == "__sub__":
        if _is_named_or_union(receiver, UTC_FULLNAME):
            _check_expected(
                ctx,
                arg_type,
                UTC_FULLNAME,
                "time_unifier plugin: UTCTime subtraction requires UTCTime on both sides.",
            )
        if _is_named_or_union(receiver, ZONED_FULLNAME):
            _check_expected(
                ctx,
                arg_type,
                ZONED_FULLNAME,
                "time_unifier plugin: ZonedTime subtraction requires ZonedTime on both sides.",
            )

    return ctx.default_return_type


def _function_hook(ctx: FunctionContext, fullname: str) -> Type:
    if fullname == "time_unifier.convert.to_utc":
        _check_expected(
            ctx,
            _first_arg_type(ctx),
            ZONED_FULLNAME,
            "time_unifier plugin: to_utc(...) expects ZonedTime input.",
        )
    elif fullname == "time_unifier.convert.to_zone":
        _check_expected(
            ctx,
            _first_arg_type(ctx),
            UTC_FULLNAME,
            "time_unifier plugin: to_zone(...) expects UTCTime input.",
        )
    elif fullname in _UTC_ONLY_FUNCTIONS:
        for arg_group in ctx.arg_types:
            if not arg_group:
                continue
            _check_expected(
                ctx,
                arg_group[0],
                UTC_FULLNAME,
                "time_unifier plugin: UTC comparison helpers accept UTCTime only.",
            )
    return ctx.default_return_type


class TimeUnifierPlugin(Plugin):
    def get_method_hook(self, fullname: str) -> Callable[[MethodContext], Type] | None:
        if fullname in {
            f"{UTC_FULLNAME}.__eq__",
            f"{UTC_FULLNAME}.__lt__",
            f"{UTC_FULLNAME}.__gt__",
            f"{UTC_FULLNAME}.__sub__",
            f"{ZONED_FULLNAME}.__eq__",
            f"{ZONED_FULLNAME}.__lt__",
            f"{ZONED_FULLNAME}.__gt__",
            f"{ZONED_FULLNAME}.__sub__",
        }:
            return lambda ctx: _method_hook(ctx, fullname)
        return None

    def get_function_hook(self, fullname: str) -> Callable[[FunctionContext], Type] | None:
        if fullname in {
            "time_unifier.convert.to_utc",
            "time_unifier.convert.to_zone",
            *_UTC_ONLY_FUNCTIONS,
        }:
            return lambda ctx: _function_hook(ctx, fullname)
        return None


def plugin(version: str) -> type[Plugin]:  # pragma: no cover
    return TimeUnifierPlugin
