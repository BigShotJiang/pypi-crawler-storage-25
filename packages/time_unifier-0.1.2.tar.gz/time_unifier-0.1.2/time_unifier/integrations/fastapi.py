from __future__ import annotations

from time_unifier.core import UTCTime, ZonedTime
from time_unifier.validation import parse_utc_iso, parse_zoned_iso


def utc_param(value: str) -> UTCTime:
    """Parse a FastAPI string parameter as strict UTC."""
    return parse_utc_iso(value)


def zoned_param(value: str) -> ZonedTime:
    """Parse a FastAPI string parameter as strict non-UTC zoned datetime."""
    return parse_zoned_iso(value)


def to_response(value: UTCTime | ZonedTime) -> str:
    """Serialize typed values back to ISO response payloads."""
    return value.to_iso()
