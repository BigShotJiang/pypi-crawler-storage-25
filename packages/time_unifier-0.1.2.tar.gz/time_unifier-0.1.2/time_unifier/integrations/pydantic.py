from __future__ import annotations

import importlib
from datetime import datetime
from typing import Any

from time_unifier.core import UTCTime, ZonedTime
from time_unifier.errors import ErrorMessages
from time_unifier.validation import parse_utc_iso, parse_zoned_iso


class UTCTimeField(UTCTime):
    @classmethod
    def _coerce(cls, value: Any) -> "UTCTimeField":
        if isinstance(value, cls):
            return value
        if isinstance(value, UTCTime):
            return cls(value.to_datetime())
        if isinstance(value, datetime):
            return cls(value)
        if isinstance(value, str):
            return cls(parse_utc_iso(value).to_datetime())
        raise TypeError(ErrorMessages.PYDANTIC_INVALID_TYPE)

    @classmethod
    def __get_validators__(cls) -> Any:
        yield cls._coerce

    @classmethod
    def __get_pydantic_core_schema__(cls, source: Any, handler: Any) -> Any:
        try:
            core_schema = importlib.import_module("pydantic_core").core_schema
        except ImportError as exc:
            raise RuntimeError(ErrorMessages.PYDANTIC_CORE_REQUIRED) from exc

        return core_schema.no_info_plain_validator_function(
            cls._coerce,
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda value: value.to_iso(),
                return_schema=core_schema.str_schema(),
            ),
        )


class ZonedTimeField(ZonedTime):
    @classmethod
    def _coerce(cls, value: Any) -> "ZonedTimeField":
        if isinstance(value, cls):
            return value
        if isinstance(value, ZonedTime):
            return cls(value.to_datetime())
        if isinstance(value, datetime):
            return cls(value)
        if isinstance(value, str):
            return cls(parse_zoned_iso(value).to_datetime())
        raise TypeError(ErrorMessages.PYDANTIC_INVALID_TYPE)

    @classmethod
    def __get_validators__(cls) -> Any:
        yield cls._coerce

    @classmethod
    def __get_pydantic_core_schema__(cls, source: Any, handler: Any) -> Any:
        try:
            core_schema = importlib.import_module("pydantic_core").core_schema
        except ImportError as exc:
            raise RuntimeError(ErrorMessages.PYDANTIC_CORE_REQUIRED) from exc

        return core_schema.no_info_plain_validator_function(
            cls._coerce,
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda value: value.to_iso(),
                return_schema=core_schema.str_schema(),
            ),
        )
