from __future__ import annotations

import importlib
from datetime import datetime
from typing import Any

from time_unifier.core import UTCTime
from time_unifier.database import from_db_utc, to_db_utc
from time_unifier.errors import ErrorMessages, expected_type


def _load_sqlalchemy_types() -> tuple[type[Any], Any]:
    try:
        types_module = importlib.import_module("sqlalchemy.types")
    except ModuleNotFoundError as exc:  # pragma: no cover
        raise RuntimeError("SQLAlchemy integration requires sqlalchemy>=1.4") from exc
    return types_module.TypeDecorator, types_module.DateTime


_TypeDecoratorBase, _DateTimeType = _load_sqlalchemy_types()


class UTCTimeType(_TypeDecoratorBase):  # type: ignore[valid-type,misc]
    """SQLAlchemy type decorator that enforces UTC-only database datetimes."""

    impl = _DateTimeType(timezone=True)
    cache_ok = True

    def process_bind_param(self, value: Any, dialect: Any) -> datetime | None:
        if value is None:
            return None
        if isinstance(value, UTCTime):
            return value.to_datetime()
        if isinstance(value, datetime):
            return from_db_utc(value.isoformat()).to_datetime()
        raise TypeError(
            f"{ErrorMessages.EXPECTED_UTC_TIME} "
            f"{expected_type('UTCTime or UTC-aware datetime', value)}"
        )

    def process_result_value(self, value: Any, dialect: Any) -> UTCTime | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return from_db_utc(value.isoformat())
        return from_db_utc(str(value))

    def process_literal_param(self, value: Any, dialect: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, UTCTime):
            return to_db_utc(value)
        if isinstance(value, datetime):
            return to_db_utc(from_db_utc(value.isoformat()))
        raise TypeError(
            f"{ErrorMessages.EXPECTED_UTC_TIME} "
            f"{expected_type('UTCTime or UTC-aware datetime', value)}"
        )
