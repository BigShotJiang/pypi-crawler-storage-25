from datetime import timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .core import UTCTime, ZonedTime
from .errors import ErrorMessages, InvalidTimezoneError, MixedTimeTypeError, invalid_timezone


def to_utc(z: ZonedTime) -> UTCTime:
    if not isinstance(z, ZonedTime):
        raise MixedTimeTypeError(ErrorMessages.EXPECTED_ZONED_TIME)
    dt = z.to_datetime().astimezone(timezone.utc)
    return UTCTime(dt)


def to_zone(u: UTCTime, name: str) -> ZonedTime:
    if not isinstance(u, UTCTime):
        raise MixedTimeTypeError(ErrorMessages.EXPECTED_UTC_TIME)
    try:
        dt = u.to_datetime().astimezone(ZoneInfo(name))
    except ZoneInfoNotFoundError as exc:
        raise InvalidTimezoneError(invalid_timezone(name)) from exc
    return ZonedTime(dt)
