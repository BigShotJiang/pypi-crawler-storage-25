from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Union

from .core import UTCTime, ZonedTime
from .errors import (
    ErrorMessages,
    AmbiguousDateTimeError,
    InvalidTimezoneError,
    NaiveDateTimeError,
    invalid_input_type,
)

_TZ_RE = re.compile(r"(Z|[+-]\d{2}:\d{2})$")


def _parse_iso_datetime(value: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(invalid_input_type("str", value))
    if value == "":
        raise ValueError(ErrorMessages.ISO_EMPTY)
    if value.strip() != value or any(char.isspace() for char in value):
        raise AmbiguousDateTimeError(ErrorMessages.ISO_WHITESPACE)
    text = value
    if "T" not in text:
        raise AmbiguousDateTimeError(ErrorMessages.ISO_MISSING_TIME_SEPARATOR)
    if not _TZ_RE.search(text):
        raise NaiveDateTimeError(ErrorMessages.ISO_MISSING_TIMEZONE)
    normalized = text[:-1] + "+00:00" if text.endswith("Z") else text
    try:
        dt = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ValueError(ErrorMessages.ISO_INVALID_FORMAT) from exc
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise NaiveDateTimeError(ErrorMessages.ISO_MISSING_TIMEZONE)
    return dt


def ensure_utc(dt: Union[datetime, UTCTime]) -> UTCTime:
    if isinstance(dt, UTCTime):
        return dt
    if not isinstance(dt, datetime):
        raise TypeError(ErrorMessages.INVALID_ENSURE_UTC_TYPE)
    return UTCTime(dt)


def ensure_zoned(dt: Union[datetime, ZonedTime]) -> ZonedTime:
    if isinstance(dt, ZonedTime):
        return dt
    if not isinstance(dt, datetime):
        raise TypeError(ErrorMessages.INVALID_ENSURE_ZONED_TYPE)
    return ZonedTime(dt)


def from_datetime(dt: datetime) -> Union[UTCTime, ZonedTime]:
    if not isinstance(dt, datetime):
        raise TypeError(invalid_input_type("datetime", dt))
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise NaiveDateTimeError(ErrorMessages.NAIVE_DATETIME)
    if dt.utcoffset() == timedelta(0):
        return UTCTime(dt)
    return ZonedTime(dt)


def parse_utc_iso(value: str) -> UTCTime:
    try:
        return UTCTime(_parse_iso_datetime(value))
    except InvalidTimezoneError as exc:
        raise InvalidTimezoneError(ErrorMessages.UTC_ISO_REQUIRED) from exc


def parse_zoned_iso(value: str) -> ZonedTime:
    try:
        return ZonedTime(_parse_iso_datetime(value))
    except InvalidTimezoneError as exc:
        raise InvalidTimezoneError(ErrorMessages.ZONED_ISO_REQUIRED) from exc


def parse_iso(value: str) -> Union[UTCTime, ZonedTime]:
    dt = _parse_iso_datetime(value)
    if dt.utcoffset() == timedelta(0):
        return UTCTime(dt)
    return ZonedTime(dt)
