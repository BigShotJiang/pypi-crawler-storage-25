---
name: no-fallbacks
description: No silent failures, no fallbacks unless explicitly requested. Errors must be visible.
---

## No fallbacks and No silent failures
- [ ] Do never allow for silent failures.
- [ ] Do never implement fallbacks unless user explicitly requests
- [ ] This is crucial to show errors as errors without hiding actual problems.
  - [ ] For fallbacks user confirmed, please comment it in source code.
  - [ ] Otherwise, no fallbacks accepted.
- [ ] Red cases are useful. We have opportunities to improve. Do not hide them.
- [ ] False positives are really difficult to find and fix. Do not workaround problems silently.
- [ ] Not working must be not working.
- [ ] Not complete must be not complete.
- [ ] Just make everything clear and honest without false information.
