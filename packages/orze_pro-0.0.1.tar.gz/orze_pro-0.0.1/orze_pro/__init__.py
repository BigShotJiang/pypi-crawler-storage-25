"""
orze-pro is distributed via private registry.

To install:
    1. Get your license key at https://orze.ai/pro
    2. pip install orze
    3. export ORZE_PRO_KEY="ORZE-PRO-..."
    4. orze run  (auto-installs orze-pro)

Or install manually:
    pip install orze-pro --extra-index-url https://__token__:${ORZE_PRO_KEY}@pypi.orze.ai/simple/

Questions? support@orze.ai
"""
import sys
print(__doc__, file=sys.stderr)
raise ImportError(
    "This is a stub package. Install the real orze-pro via: "
    "export ORZE_PRO_KEY='...' && orze run"
)
