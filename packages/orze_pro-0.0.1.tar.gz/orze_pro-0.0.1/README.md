# orze-pro

**orze-pro** is the autopilot add-on for [orze](https://orze.ai) — autonomous research agents, self-healing bug fixer, and GPU orchestration.

## Installation

orze-pro is distributed via private registry. To install:

```bash
pip install orze
export ORZE_PRO_KEY="ORZE-PRO-..."   # your license key
orze run                              # auto-installs orze-pro
```

Get your license key at **[orze.ai/pro](https://orze.ai/pro)**

## What you get

- 🔬 **Research agent** — reads papers, generates experiment ideas
- 🎓 **Professor agent** — reviews ideas, prunes duplicates, adjusts strategy  
- 🔧 **Bug fixer agent** — auto-diagnoses and fixes failed experiments
- 🔄 **Code evolution** — evolves training code based on results
- 📊 **FSM engine** — coordinates agent lifecycle with quality gates
- 🖥️ **GPU director** — self-driving GPU allocation across tasks

Questions? [support@orze.ai](mailto:support@orze.ai)
