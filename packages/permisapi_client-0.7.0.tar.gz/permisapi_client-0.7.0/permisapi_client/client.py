"""PermisAPI sync + async client.

Minimal, no ORM. Returns dict / list[dict] pour rester flexible aux
futurs changements de schema cote API.
"""
from __future__ import annotations

from typing import Any, Iterator, AsyncIterator

import httpx

from permisapi_client.exceptions import error_from_response

DEFAULT_BASE_URL = "https://api.permisapi.fr"
DEFAULT_TIMEOUT = 15.0
USER_AGENT = "permisapi-client-python/0.7.0"


def _raise_for_status(resp: httpx.Response) -> None:
    if 200 <= resp.status_code < 300:
        return
    try:
        payload = resp.json()
    except ValueError:
        payload = {"message": resp.text[:200] or "Erreur inconnue"}
    if "retry_after" not in payload and "Retry-After" in resp.headers:
        try:
            payload["retry_after"] = int(resp.headers["Retry-After"])
        except ValueError:
            pass
    raise error_from_response(resp.status_code, payload)


def _build_headers(api_key: str, extra: dict[str, str] | None = None) -> dict[str, str]:
    h = {
        "X-API-Key": api_key,
        "Accept": "application/json",
        "User-Agent": USER_AGENT,
    }
    if extra:
        h.update(extra)
    return h


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------


class _PermitsResource:
    def __init__(self, client: PermisAPI) -> None:
        self._c = client

    def list(self, **params: Any) -> dict[str, Any]:
        """GET /v1/permits avec filtres. Retourne {items, pagination}."""
        return self._c._get("/v1/permits", params=params)

    def iter_all(self, **params: Any) -> Iterator[dict[str, Any]]:
        """Itere sur toutes les pages (limite fixee par le plan)."""
        page = 1
        per_page = params.get("limit", 100)
        while True:
            p = {**params, "page": page, "limit": per_page}
            data = self.list(**p)
            items = data.get("items", [])
            if not items:
                return
            yield from items
            pages = (data.get("pagination") or {}).get("pages", 1)
            if page >= pages:
                return
            page += 1

    def get(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}."""
        return self._c._get(f"/v1/permits/{num_pa}")

    def near(
        self, *, lat: float, lng: float, radius_m: int, **filters: Any
    ) -> dict[str, Any]:
        """GET /v1/permits/near?lat&lng&radius_m (PostGIS)."""
        return self._c._get(
            "/v1/permits/near",
            params={"lat": lat, "lng": lng, "radius_m": radius_m, **filters},
        )

    def by_cadastre(self, *, section: str, numero: str) -> dict[str, Any]:
        return self._c._get(
            "/v1/permits/by-cadastre",
            params={"section": section, "numero": numero},
        )

    def dvf(
        self,
        num_pa: str,
        *,
        limit: int | None = None,
        type_local: str | None = None,
        include_terrains: bool | None = None,
        include_deps: bool | None = None,
        min_year: int | None = None,
        max_distance: int | None = None,
    ) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/dvf : top-K transactions DVF voisines.

        Plans Pro et superieurs uniquement (402 si Free / Explorer).
        Retourne {num_pa, permit_id, matches: [...], filters_applied,
        source, coverage}. Couverture 5 ans glissants 2021-2025.

        Filtres optionnels :
          - limit : 1-5, default 3
          - type_local : CSV "1,2,4" (1=Maison, 2=Appart, 3=Dep, 4=Local)
          - include_terrains : inclure terrains nus (type_local NULL)
          - include_deps : inclure dependances (type_local=3)
          - min_year : filtre temporel transactions
          - max_distance : cap distance en metres
        """
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if type_local is not None:
            params["type_local"] = type_local
        if include_terrains is not None:
            params["include_terrains"] = str(include_terrains).lower()
        if include_deps is not None:
            params["include_deps"] = str(include_deps).lower()
        if min_year is not None:
            params["min_year"] = min_year
        if max_distance is not None:
            params["max_distance"] = max_distance
        return self._c._get(f"/v1/permits/{num_pa}/dvf", params=params or None)

    def score_mdb(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/score : Score Opportunité MDB v0.1.

        Plans Pro et superieurs uniquement (402 si Free / Explorer).
        Retourne {num_pa, permit_id, score (0-100), tier (low/medium/
        high/premium), components (7 signaux ponderes), weights,
        version, method, dvf_matches_used, density_class}.

        Algo : heuristique ponderee qui combine type permis, surface,
        DVF voisin €/m², activite dep, demandeur (SCI vs promoteur),
        coherence DVF/permis, densite INSEE.
        """
        return self._c._get(f"/v1/permits/{num_pa}/score")

    def risks(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/risks : Georisques BRGM (commune-level).

        Plans Pro et superieurs uniquement (402 si Free / Explorer). Source :
        API Georisques (ministere Transition Ecologique + BRGM) live, pas de
        cache V0.1, latence 200-1000ms typique.

        Retourne {num_pa, comm_code, risk_score (0-100), risk_tier (low/
        moderate/high/critical), risks: [{code, label, has_ppr, ppr_type}],
        icpe_proches: [{nom, regime, distance_m, activite}], fetch_errors,
        source, fetched_at, disclaimer}.

        En cas d'erreur partielle (ex: ICPE OK mais /risques 500), retourne
        ce qui marche + liste les endpoints qui ont fail dans `fetch_errors`.
        """
        return self._c._get(f"/v1/permits/{num_pa}/risks")

    def plu(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/plu : zonage urbanisme PLU au point geocode.

        Plans Pro et superieurs uniquement (402 si Free / Explorer). Source :
        Geoportail de l'Urbanisme via apicarto.ign.fr (live API, latence
        200-500ms typique).

        Retourne {num_pa, lat, lng, has_plu, zonage : {code (UA/UB/AU/A/N..),
        libelle, type_zone, constructible (bool), constructible_reason,
        plu_revision_date, plu_partition}, other_zones, source, fetched_at}.

        Si la commune n'a pas digitalise son PLU sur Geoportail (~20% des
        communes FR), `has_plu=False` avec `not_covered_reason` explicite.
        """
        return self._c._get(f"/v1/permits/{num_pa}/plu")

    def full_view(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/360 : vue agregee 6-en-1 en 1 appel HTTP.

        Combine en 1 reponse : detail + sirene + dvf + score + plu + risks.
        Equivalent fonctionnel de 6 calls separes mais en 1 round-trip,
        avec parallelisation cote serveur des sub-fetches lents (PLU
        apicarto + Risks BRGM).

        Cout quota : 6 unites du quota mensuel pour Pro+, 1 unite pour
        Free / Explorer (qui recoivent juste `detail`, autres champs `null`
        avec `plan_required_for_full="pro"`). Le header de reponse
        `X-RateLimit-Cost` confirme le cout decompte.

        Best-effort : si une sous-feature echoue (timeout, 5xx tiers),
        son champ vaut `null` et l'erreur est listee dans `fetch_errors`.
        Les autres sous-features ne sont pas affectees.

        Latence typique 5-7s (dominee par PLU + Risks live, paralleles).

        Returns:
            dict avec cles : num_pa, detail, sirene, dvf, score, plu,
            risks, fetch_errors (list), subfetches_billed (int).
            Si plan Free/Explorer : `plan_required_for_full="pro"` est
            present et toutes les sous-features sauf detail sont null.
        """
        return self._c._get(f"/v1/permits/{num_pa}/360")

    def score_feedback(
        self,
        *,
        num_pa: str,
        score_received: int,
        tier_received: str,
        useful: bool,
        accuracy: str,
        comment: str,
        recommendation: str | None = None,
    ) -> dict[str, Any]:
        """POST /v1/score/feedback : envoyer un feedback sur un Score MDB.

        Plans Pro et superieurs uniquement. Le feedback est stocke en DB
        et un email est envoye au founder pour suivi rapide.

        Args:
            num_pa: identifiant du permis concerne
            score_received: score 0-100 que tu as recu via /score
            tier_received: "low" | "medium" | "high" | "premium"
            useful: True si le score t'a ete utile
            accuracy: "correct" | "too_high" | "too_low" | "wrong_signals"
            comment: ton retour libre (1-2000 chars)
            recommendation: optionnel, ce qui pourrait etre ameliore (1-2000 chars)

        Returns:
            {id, num_pa, email_sent, message}
        """
        body: dict[str, Any] = {
            "num_pa": num_pa,
            "score_received": score_received,
            "tier_received": tier_received,
            "useful": useful,
            "accuracy": accuracy,
            "comment": comment,
        }
        if recommendation is not None:
            body["recommendation"] = recommendation
        return self._c._post("/v1/score/feedback", json=body)

    def export(
        self,
        *,
        dep_code: str | None = None,
        comm_code: str | None = None,
        permit_type: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        etat_pa: int | None = None,
        max_rows: int | None = None,
    ) -> bytes:
        """GET /v1/permits/export : export streaming CSV bulk (Business+).

        Plans Business et Enterprise uniquement (403 si plan inferieur).
        Cap par defaut : 100k lignes Business, 1M Enterprise. Le user
        peut reduire via `max_rows` mais pas augmenter.

        Retourne le contenu CSV brut en bytes UTF-8 (header + rows). Pour
        sauver dans un fichier :

          csv_bytes = client.permits.export(dep_code="75")
          with open("paris.csv", "wb") as f:
              f.write(csv_bytes)

        Pour les gros exports (>100 MB), prefere le streaming via
        `client._http.stream("GET", "/v1/permits/export", params=...)`.
        """
        params: dict[str, Any] = {}
        if dep_code is not None:
            params["dep_code"] = dep_code
        if comm_code is not None:
            params["comm_code"] = comm_code
        if permit_type is not None:
            params["permit_type"] = permit_type
        if date_from is not None:
            params["date_from"] = date_from
        if date_to is not None:
            params["date_to"] = date_to
        if etat_pa is not None:
            params["etat_pa"] = etat_pa
        if max_rows is not None:
            params["max_rows"] = max_rows
        # Sortie binaire (CSV) -> on contourne _get qui parse en JSON.
        url = f"{self._c.base_url}/v1/permits/export"
        resp = self._c._http.get(url, params=params or None)
        _raise_for_status(resp)
        return resp.content


class _StatsResource:
    def __init__(self, client: PermisAPI) -> None:
        self._c = client

    def commune(self, code: str) -> dict[str, Any]:
        return self._c._get(f"/v1/stats/commune/{code}")

    def departement(self, code: str) -> dict[str, Any]:
        return self._c._get(f"/v1/stats/departement/{code}")

    def region(self, code: str) -> dict[str, Any]:
        return self._c._get(f"/v1/stats/region/{code}")

    def trends(
        self,
        *,
        dep_code: str | None = None,
        comm_code: str | None = None,
        group_by: str = "month",
    ) -> dict[str, Any]:
        params = {"group_by": group_by}
        if dep_code:
            params["dep_code"] = dep_code
        if comm_code:
            params["comm_code"] = comm_code
        return self._c._get("/v1/stats/trends", params=params)

    def latest_day(self) -> dict[str, Any]:
        return self._c._get("/v1/stats/latest-day")


class _AlertsResource:
    def __init__(self, client: PermisAPI) -> None:
        self._c = client

    def list(self) -> list[dict[str, Any]]:
        return self._c._get("/v1/alerts")

    def create(
        self,
        *,
        name: str,
        center_lat: float,
        center_lng: float,
        radius_km: float,
        webhook_url: str,
        permit_types: list[str] | None = None,
        min_superficie: int | None = None,
        etat_pa: int | None = None,
    ) -> dict[str, Any]:
        """Cree une alerte. Le `webhook_secret` renvoye n'est visible QU'ICI."""
        body: dict[str, Any] = {
            "name": name,
            "center_lat": center_lat,
            "center_lng": center_lng,
            "radius_km": radius_km,
            "webhook_url": webhook_url,
        }
        if permit_types:
            body["permit_types"] = permit_types
        if min_superficie is not None:
            body["min_superficie"] = min_superficie
        if etat_pa is not None:
            body["etat_pa"] = etat_pa
        return self._c._post("/v1/alerts", json=body)

    def get(self, alert_id: int) -> dict[str, Any]:
        return self._c._get(f"/v1/alerts/{alert_id}")

    def update(self, alert_id: int, **patch: Any) -> dict[str, Any]:
        return self._c._patch(f"/v1/alerts/{alert_id}", json=patch)

    def delete(self, alert_id: int) -> None:
        self._c._delete(f"/v1/alerts/{alert_id}")

    def replay(self, alert_id: int) -> dict[str, Any]:
        return self._c._post(f"/v1/alerts/{alert_id}/replay")


class _MeResource:
    def __init__(self, client: PermisAPI) -> None:
        self._c = client

    def get(self) -> dict[str, Any]:
        return self._c._get("/v1/me")

    def usage(self, days: int = 30) -> dict[str, Any]:
        return self._c._get("/v1/me/usage", params={"days": days})

    def regenerate_key(self) -> dict[str, Any]:
        """Rotate la cle. La nouvelle cle n'est visible QU'UNE FOIS."""
        return self._c._post("/v1/me/regenerate-key")


class PermisAPI:
    """Client sync. Thread-safe pour des lectures concurrentes.

    Args:
        api_key: ta cle `pk_live_...` (obtenue sur https://permisapi.fr/#pricing)
        base_url: override si tu self-host (defaut Railway prod)
        timeout: timeout HTTP par requete (defaut 15s)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        client: httpx.Client | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key est requise (pk_live_... ou pk_test_...)")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._http = client or httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=_build_headers(api_key),
        )
        self.permits = _PermitsResource(self)
        self.stats = _StatsResource(self)
        self.alerts = _AlertsResource(self)
        self.me = _MeResource(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> PermisAPI:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- internal HTTP helpers --

    def _get(self, path: str, *, params: dict | None = None) -> Any:
        resp = self._http.get(path, params=params)
        _raise_for_status(resp)
        return resp.json()

    def _post(self, path: str, *, json: dict | None = None) -> Any:
        resp = self._http.post(path, json=json)
        _raise_for_status(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    def _patch(self, path: str, *, json: dict | None = None) -> Any:
        resp = self._http.patch(path, json=json)
        _raise_for_status(resp)
        return resp.json()

    def _delete(self, path: str) -> None:
        resp = self._http.delete(path)
        _raise_for_status(resp)


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


class _AsyncPermitsResource:
    def __init__(self, client: AsyncPermisAPI) -> None:
        self._c = client

    async def list(self, **params: Any) -> dict[str, Any]:
        return await self._c._get("/v1/permits", params=params)

    async def iter_all(self, **params: Any) -> AsyncIterator[dict[str, Any]]:
        page = 1
        per_page = params.get("limit", 100)
        while True:
            p = {**params, "page": page, "limit": per_page}
            data = await self.list(**p)
            items = data.get("items", [])
            if not items:
                return
            for item in items:
                yield item
            pages = (data.get("pagination") or {}).get("pages", 1)
            if page >= pages:
                return
            page += 1

    async def get(self, num_pa: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/permits/{num_pa}")

    async def near(
        self, *, lat: float, lng: float, radius_m: int, **filters: Any
    ) -> dict[str, Any]:
        return await self._c._get(
            "/v1/permits/near",
            params={"lat": lat, "lng": lng, "radius_m": radius_m, **filters},
        )

    async def dvf(
        self,
        num_pa: str,
        *,
        limit: int | None = None,
        type_local: str | None = None,
        include_terrains: bool | None = None,
        include_deps: bool | None = None,
        min_year: int | None = None,
        max_distance: int | None = None,
    ) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/dvf : version async. Plans Pro+ only.
        Voir _PermitsResource.dvf pour la doc complete des params."""
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if type_local is not None:
            params["type_local"] = type_local
        if include_terrains is not None:
            params["include_terrains"] = str(include_terrains).lower()
        if include_deps is not None:
            params["include_deps"] = str(include_deps).lower()
        if min_year is not None:
            params["min_year"] = min_year
        if max_distance is not None:
            params["max_distance"] = max_distance
        return await self._c._get(f"/v1/permits/{num_pa}/dvf", params=params or None)

    async def score_mdb(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/score : version async. Plans Pro+ only."""
        return await self._c._get(f"/v1/permits/{num_pa}/score")

    async def plu(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/plu : version async. Plans Pro+ only.
        Voir _PermitsResource.plu pour la doc complete."""
        return await self._c._get(f"/v1/permits/{num_pa}/plu")

    async def risks(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/risks : version async. Plans Pro+ only.
        Voir _PermitsResource.risks pour la doc complete."""
        return await self._c._get(f"/v1/permits/{num_pa}/risks")

    async def full_view(self, num_pa: str) -> dict[str, Any]:
        """GET /v1/permits/{num_pa}/360 : version async. Vue agregee 6-en-1.

        Cout quota : 6 unites pour Pro+, 1 unite pour Free / Explorer.
        Le header `X-RateLimit-Cost` confirme le cout. Voir
        _PermitsResource.full_view pour la doc complete.
        """
        return await self._c._get(f"/v1/permits/{num_pa}/360")

    async def score_feedback(
        self,
        *,
        num_pa: str,
        score_received: int,
        tier_received: str,
        useful: bool,
        accuracy: str,
        comment: str,
        recommendation: str | None = None,
    ) -> dict[str, Any]:
        """POST /v1/score/feedback : version async. Plans Pro+ only.
        Voir _PermitsResource.score_feedback pour la doc complete."""
        body: dict[str, Any] = {
            "num_pa": num_pa,
            "score_received": score_received,
            "tier_received": tier_received,
            "useful": useful,
            "accuracy": accuracy,
            "comment": comment,
        }
        if recommendation is not None:
            body["recommendation"] = recommendation
        return await self._c._post("/v1/score/feedback", json=body)

    async def export(
        self,
        *,
        dep_code: str | None = None,
        comm_code: str | None = None,
        permit_type: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        etat_pa: int | None = None,
        max_rows: int | None = None,
    ) -> bytes:
        """GET /v1/permits/export : version async. Plans Business+ only.
        Voir _PermitsResource.export pour la doc complete des params."""
        params: dict[str, Any] = {}
        if dep_code is not None:
            params["dep_code"] = dep_code
        if comm_code is not None:
            params["comm_code"] = comm_code
        if permit_type is not None:
            params["permit_type"] = permit_type
        if date_from is not None:
            params["date_from"] = date_from
        if date_to is not None:
            params["date_to"] = date_to
        if etat_pa is not None:
            params["etat_pa"] = etat_pa
        if max_rows is not None:
            params["max_rows"] = max_rows
        url = f"{self._c.base_url}/v1/permits/export"
        resp = await self._c._http.get(url, params=params or None)
        _raise_for_status(resp)
        return resp.content


class _AsyncStatsResource:
    def __init__(self, client: AsyncPermisAPI) -> None:
        self._c = client

    async def commune(self, code: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/stats/commune/{code}")

    async def departement(self, code: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/stats/departement/{code}")

    async def region(self, code: str) -> dict[str, Any]:
        return await self._c._get(f"/v1/stats/region/{code}")

    async def trends(self, **params: Any) -> dict[str, Any]:
        return await self._c._get("/v1/stats/trends", params=params)


class _AsyncAlertsResource:
    def __init__(self, client: AsyncPermisAPI) -> None:
        self._c = client

    async def list(self) -> list[dict[str, Any]]:
        return await self._c._get("/v1/alerts")

    async def create(self, **body: Any) -> dict[str, Any]:
        return await self._c._post("/v1/alerts", json=body)

    async def delete(self, alert_id: int) -> None:
        await self._c._delete(f"/v1/alerts/{alert_id}")


class _AsyncMeResource:
    def __init__(self, client: AsyncPermisAPI) -> None:
        self._c = client

    async def get(self) -> dict[str, Any]:
        return await self._c._get("/v1/me")

    async def usage(self, days: int = 30) -> dict[str, Any]:
        return await self._c._get("/v1/me/usage", params={"days": days})


class AsyncPermisAPI:
    """Version async : `async with` et `await`."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key est requise (pk_live_... ou pk_test_...)")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._http = client or httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=_build_headers(api_key),
        )
        self.permits = _AsyncPermitsResource(self)
        self.stats = _AsyncStatsResource(self)
        self.alerts = _AsyncAlertsResource(self)
        self.me = _AsyncMeResource(self)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncPermisAPI:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def _get(self, path: str, *, params: dict | None = None) -> Any:
        resp = await self._http.get(path, params=params)
        _raise_for_status(resp)
        return resp.json()

    async def _post(self, path: str, *, json: dict | None = None) -> Any:
        resp = await self._http.post(path, json=json)
        _raise_for_status(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    async def _delete(self, path: str) -> None:
        resp = await self._http.delete(path)
        _raise_for_status(resp)
