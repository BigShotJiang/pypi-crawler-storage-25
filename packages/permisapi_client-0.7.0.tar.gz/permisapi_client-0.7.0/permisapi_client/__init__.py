"""Client Python officiel pour PermisAPI.

Usage sync :
    from permisapi_client import PermisAPI
    client = PermisAPI(api_key="pk_live_...")
    for permit in client.permits.list(dep_code="75", limit=10):
        print(permit["num_pa"], permit["adr_localite_ter"])

Usage async :
    from permisapi_client import AsyncPermisAPI
    async with AsyncPermisAPI(api_key="pk_live_...") as client:
        permits = await client.permits.near(lat=48.85, lng=2.35, radius_m=500)
"""
from permisapi_client.client import AsyncPermisAPI, PermisAPI
from permisapi_client.exceptions import (
    PermisAPIError,
    PermisAPIQuotaExceeded,
    PermisAPIRateLimited,
    PermisAPIUnauthorized,
    PermisAPIValidationError,
)

__all__ = [
    "PermisAPI",
    "AsyncPermisAPI",
    "PermisAPIError",
    "PermisAPIUnauthorized",
    "PermisAPIRateLimited",
    "PermisAPIQuotaExceeded",
    "PermisAPIValidationError",
]

__version__ = "0.7.0"
