"""Tests du SDK via respx (mock httpx transport)."""
from __future__ import annotations

import httpx
import pytest
import respx

from permisapi_client import (
    AsyncPermisAPI,
    PermisAPI,
    PermisAPIQuotaExceeded,
    PermisAPIRateLimited,
    PermisAPIUnauthorized,
    PermisAPIValidationError,
)
from permisapi_client.exceptions import PermisAPINotFound


BASE = "https://api.permisapi.fr"


def test_requires_api_key() -> None:
    with pytest.raises(ValueError, match="api_key"):
        PermisAPI(api_key="")


@respx.mock
def test_permits_list() -> None:
    route = respx.get(f"{BASE}/v1/permits").respond(
        json={
            "items": [{"num_pa": "PC 075 115 24 B0001", "dep_code": "75"}],
            "pagination": {"page": 1, "total": 1, "pages": 1},
        }
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        data = client.permits.list(dep_code="75", limit=5)
    assert route.called
    assert data["items"][0]["num_pa"] == "PC 075 115 24 B0001"
    # Header propage
    assert route.calls.last.request.headers["x-api-key"] == "pk_test_abc"


@respx.mock
def test_permits_get() -> None:
    respx.get(f"{BASE}/v1/permits/PC-123").respond(
        json={"num_pa": "PC-123", "dep_code": "75"}
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        permit = client.permits.get("PC-123")
    assert permit["num_pa"] == "PC-123"


@respx.mock
def test_unauthorized_raises() -> None:
    respx.get(f"{BASE}/v1/me").respond(
        status_code=401,
        json={"error": "unauthorized", "message": "API key manquante"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPIUnauthorized):
            client.me.get()


@respx.mock
def test_rate_limit_raises_with_retry_after() -> None:
    respx.get(f"{BASE}/v1/permits").respond(
        status_code=429,
        json={"error": "rate_limit_exceeded", "message": "burst"},
        headers={"Retry-After": "3"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPIRateLimited) as exc:
            client.permits.list()
    assert exc.value.retry_after == 3


@respx.mock
def test_quota_exceeded_subclass() -> None:
    respx.get(f"{BASE}/v1/permits").respond(
        status_code=429,
        json={"error": "quota_exceeded", "message": "mensuel"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPIQuotaExceeded):
            client.permits.list()


@respx.mock
def test_not_found() -> None:
    respx.get(f"{BASE}/v1/permits/UNKNOWN").respond(
        status_code=404,
        json={"error": "not_found", "message": "permit introuvable"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPINotFound):
            client.permits.get("UNKNOWN")


@respx.mock
def test_validation_error() -> None:
    respx.get(f"{BASE}/v1/permits").respond(
        status_code=400,
        json={"error": "validation_error", "message": "dep_code invalide"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPIValidationError):
            client.permits.list(dep_code="999999")


@respx.mock
def test_iter_all_paginates() -> None:
    respx.get(f"{BASE}/v1/permits", params={"page": "1", "limit": "2"}).respond(
        json={
            "items": [{"num_pa": "a"}, {"num_pa": "b"}],
            "pagination": {"page": 1, "total": 3, "pages": 2},
        }
    )
    respx.get(f"{BASE}/v1/permits", params={"page": "2", "limit": "2"}).respond(
        json={
            "items": [{"num_pa": "c"}],
            "pagination": {"page": 2, "total": 3, "pages": 2},
        }
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        results = list(client.permits.iter_all(limit=2))
    assert [p["num_pa"] for p in results] == ["a", "b", "c"]


@respx.mock
def test_alerts_create() -> None:
    respx.post(f"{BASE}/v1/alerts").respond(
        json={
            "id": 42,
            "name": "Paris 18",
            "webhook_secret": "super-secret-abc",
        }
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        alert = client.alerts.create(
            name="Paris 18",
            center_lat=48.88,
            center_lng=2.35,
            radius_km=3,
            webhook_url="https://x/hook",
        )
    assert alert["webhook_secret"] == "super-secret-abc"


@respx.mock
def test_alerts_delete_204() -> None:
    respx.delete(f"{BASE}/v1/alerts/42").respond(status_code=204)
    with PermisAPI(api_key="pk_test_abc") as client:
        client.alerts.delete(42)


# ---------------------------------------------------------------------------
# Async
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_async_permits_list() -> None:
    respx.get(f"{BASE}/v1/permits").respond(
        json={"items": [{"num_pa": "x"}], "pagination": {"pages": 1}}
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        data = await client.permits.list()
    assert data["items"][0]["num_pa"] == "x"


@pytest.mark.asyncio
@respx.mock
async def test_async_rate_limit() -> None:
    respx.get(f"{BASE}/v1/me").respond(
        status_code=429,
        json={"error": "rate_limit_exceeded", "message": "burst"},
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(PermisAPIRateLimited):
            await client.me.get()


# ---------------------------------------------------------------------------
# DVF cross-ref (Pro+)
# ---------------------------------------------------------------------------


@respx.mock
def test_permits_dvf_default_returns_top_3() -> None:
    """client.permits.dvf(num_pa) sans args -> defaults endpoint."""
    respx.get(f"{BASE}/v1/permits/PC-DVF-1/dvf").respond(
        json={
            "num_pa": "PC-DVF-1",
            "permit_id": 1,
            "matches": [
                {"rank": 1, "dvf_id_mutation": "M1", "valeur_fonciere": 420000.0},
                {"rank": 2, "dvf_id_mutation": "M2", "valeur_fonciere": 380000.0},
                {"rank": 3, "dvf_id_mutation": "M3", "valeur_fonciere": 360000.0},
            ],
            "filters_applied": {"limit": 3},
        }
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        result = client.permits.dvf("PC-DVF-1")
    assert len(result["matches"]) == 3
    assert result["matches"][0]["valeur_fonciere"] == 420000.0


@respx.mock
def test_permits_dvf_with_filters_passes_query_params() -> None:
    """Les params optionnels sont passes en query string."""
    route = respx.get(f"{BASE}/v1/permits/PC-DVF-2/dvf").respond(
        json={"num_pa": "PC-DVF-2", "permit_id": 2, "matches": []}
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        client.permits.dvf(
            "PC-DVF-2",
            limit=5,
            type_local="1,2",
            include_terrains=False,
            include_deps=False,
            min_year=2023,
            max_distance=100,
        )
    call = route.calls.last
    qs = dict(call.request.url.params)
    assert qs["limit"] == "5"
    assert qs["type_local"] == "1,2"
    assert qs["include_terrains"] == "false"
    assert qs["include_deps"] == "false"
    assert qs["min_year"] == "2023"
    assert qs["max_distance"] == "100"


@pytest.mark.asyncio
@respx.mock
async def test_async_permits_dvf() -> None:
    """Version async fonctionne identiquement."""
    respx.get(f"{BASE}/v1/permits/PC-DVF-A/dvf").respond(
        json={"num_pa": "PC-DVF-A", "permit_id": 99, "matches": []}
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        result = await client.permits.dvf("PC-DVF-A")
    assert result["num_pa"] == "PC-DVF-A"


# ---------------------------------------------------------------------------
# Export bulk CSV (Business+)
# ---------------------------------------------------------------------------


@respx.mock
def test_permits_export_returns_csv_bytes() -> None:
    """client.permits.export() retourne le CSV brut en bytes."""
    csv_body = (
        b"num_pa,dep_code,comm_code,permit_type\n"
        b"PC-1,75,75118,PC_LOGEMENT\n"
        b"PC-2,75,75118,PC_LOCAUX\n"
    )
    respx.get(f"{BASE}/v1/permits/export").respond(
        content=csv_body,
        headers={"content-type": "text/csv"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        result = client.permits.export(dep_code="75")
    assert isinstance(result, bytes)
    assert b"PC-1,75" in result
    assert result.startswith(b"num_pa,")


@respx.mock
def test_permits_export_passes_filters_as_query() -> None:
    route = respx.get(f"{BASE}/v1/permits/export").respond(content=b"num_pa\n")
    with PermisAPI(api_key="pk_test_abc") as client:
        client.permits.export(
            dep_code="75",
            comm_code="75118",
            permit_type="PC_LOGEMENT",
            date_from="2024-01-01",
            date_to="2024-12-31",
            etat_pa=1,
            max_rows=5000,
        )
    qs = dict(route.calls.last.request.url.params)
    assert qs["dep_code"] == "75"
    assert qs["comm_code"] == "75118"
    assert qs["permit_type"] == "PC_LOGEMENT"
    assert qs["date_from"] == "2024-01-01"
    assert qs["max_rows"] == "5000"


@respx.mock
def test_permits_export_403_for_explorer_plan() -> None:
    """Plan inferieur a Business -> 403 Forbidden remonte tel quel."""
    respx.get(f"{BASE}/v1/permits/export").respond(
        status_code=403,
        json={"error": "forbidden", "detail": "Plan Business+ requis"},
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        with pytest.raises(Exception):
            client.permits.export()


@respx.mock
def test_permits_score_mdb() -> None:
    respx.get(f"{BASE}/v1/permits/PC-1/score").respond(
        json={"num_pa": "PC-1", "score": 78, "tier": "high", "components": {}}
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        result = client.permits.score_mdb("PC-1")
    assert result["score"] == 78
    assert result["tier"] == "high"


@pytest.mark.asyncio
@respx.mock
async def test_async_permits_score_mdb() -> None:
    respx.get(f"{BASE}/v1/permits/PC-A/score").respond(
        json={"num_pa": "PC-A", "score": 42, "tier": "medium"}
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        result = await client.permits.score_mdb("PC-A")
    assert result["score"] == 42


@pytest.mark.asyncio
@respx.mock
async def test_async_permits_export() -> None:
    csv_body = b"num_pa,dep_code\nPC-A,75\n"
    respx.get(f"{BASE}/v1/permits/export").respond(
        content=csv_body, headers={"content-type": "text/csv"},
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        result = await client.permits.export(dep_code="75")
    assert isinstance(result, bytes)
    assert b"PC-A,75" in result


@respx.mock
def test_permits_full_view_sync() -> None:
    """Sync : full_view appelle GET /v1/permits/{num_pa}/360 et retourne
    le payload agrege complet."""
    respx.get(f"{BASE}/v1/permits/PC-360-001/360").respond(
        json={
            "num_pa": "PC-360-001",
            "detail": {"num_pa": "PC-360-001", "dep_code": "75"},
            "sirene": {"match": {"siren": "111222333"}},
            "dvf": {"matches": []},
            "score": {"score": 72, "tier": "high"},
            "plu": {"zonage": {"code": "UA", "constructible": True}},
            "risks": {"risk_tier": "low"},
            "fetch_errors": [],
            "subfetches_billed": 6,
        }
    )
    with PermisAPI(api_key="pk_test_abc") as client:
        view = client.permits.full_view("PC-360-001")
    assert view["num_pa"] == "PC-360-001"
    assert view["subfetches_billed"] == 6
    assert view["score"]["tier"] == "high"
    assert view["plu"]["zonage"]["constructible"] is True


@pytest.mark.asyncio
@respx.mock
async def test_async_permits_full_view() -> None:
    """Async : full_view appelle GET /v1/permits/{num_pa}/360."""
    respx.get(f"{BASE}/v1/permits/PC-FREE/360").respond(
        json={
            "num_pa": "PC-FREE",
            "detail": {"num_pa": "PC-FREE"},
            "sirene": None,
            "dvf": None,
            "score": None,
            "plu": None,
            "risks": None,
            "fetch_errors": [],
            "plan_required_for_full": "pro",
            "subfetches_billed": 1,
        }
    )
    async with AsyncPermisAPI(api_key="pk_test_abc") as client:
        view = await client.permits.full_view("PC-FREE")
    assert view["plan_required_for_full"] == "pro"
    assert view["subfetches_billed"] == 1
    assert view["sirene"] is None


def test_custom_base_url() -> None:
    client = PermisAPI(api_key="pk_test_abc", base_url="http://localhost:8000/")
    assert client.base_url == "http://localhost:8000"
    client.close()


def test_custom_http_client() -> None:
    """On peut injecter un httpx.Client pre-configure (proxy, retry, etc)."""
    h = httpx.Client(base_url=BASE, headers={"X-API-Key": "pk_test_xyz"})
    client = PermisAPI(api_key="pk_test_xyz", client=h)
    assert client._http is h
    client.close()
