# fclaude Gateway — Cloudflare Workers

API Gateway cho fclaude: authentication, rate limiting, usage tracking.

**Chi phí: $0** (Cloudflare Workers free tier — 100k requests/ngày)

## Quick Setup (5 phút)

```bash
cd gateway-cf
bash scripts/setup.sh
```

Script sẽ tự động:
1. Cài wrangler CLI
2. Login Cloudflare (mở browser)
3. Tạo KV namespaces (database)
4. Set secrets (JWT key, upstream URL, admin account)
5. Deploy lên Cloudflare

## Manual Setup

### 1. Prerequisites

```bash
npm install -g wrangler
wrangler login
```

### 2. Create KV Namespaces

```bash
wrangler kv namespace create USERS
wrangler kv namespace create SESSIONS
wrangler kv namespace create USAGE
wrangler kv namespace create INVITES
```

Copy các ID vào `wrangler.toml`.

### 3. Set Secrets

```bash
wrangler secret put JWT_SECRET          # random hex string
wrangler secret put UPSTREAM_URL        # real API endpoint
wrangler secret put UPSTREAM_TOKEN      # real API token
wrangler secret put ADMIN_EMAIL         # your email
wrangler secret put ADMIN_PASSWORD      # your password
```

### 4. Deploy

```bash
wrangler deploy
```

### 5. Custom Domain (optional)

Cloudflare Dashboard → Workers → fclaude-gateway → Settings → Triggers → Custom Domains → `api.fclaude.dev`

## API Endpoints

### Auth

| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/register` | Register `{email, username, password, invite_code}` |
| POST | `/auth/login` | Login `{email, password}` → JWT tokens |
| POST | `/auth/refresh` | Refresh access token |
| GET | `/auth/me` | Current user info + usage stats |

### API Proxy

| Method | Path | Description |
|--------|------|-------------|
| POST | `/v1/messages` | Proxy to Claude API (auth + rate limit) |

### Admin

| Method | Path | Description |
|--------|------|-------------|
| GET | `/admin/users` | List all users + stats |
| GET | `/admin/usage` | Today's usage per user |
| POST | `/admin/invite` | Create invite code `{plan, max_uses}` |
| GET | `/admin/invites` | List all invite codes |
| POST | `/admin/set-plan` | Change user plan `{email, plan}` |
| POST | `/admin/toggle-user` | Enable/disable user `{email, active}` |
| GET | `/health` | Health check |

## User Tiers

| Tier | Models | Daily Limit | How to Get |
|------|--------|-------------|------------|
| **free** | haiku, sonnet4 | 100 | Invite code (free) |
| **pro** | ALL (incl. opus4) | 1,000 | Invite code (pro) |
| **admin** | ALL | Unlimited | Set by admin |

## Workflows

### Tạo invite cho team member

```bash
# Login as admin
TOKEN=$(curl -s -X POST https://your-gateway.workers.dev/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@company.com","password":"xxx"}' | jq -r .access_token)

# Tạo 20 invite codes cho team (free tier)
curl -X POST https://your-gateway.workers.dev/admin/invite \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"plan":"free","max_uses":20}'
```

### Giám sát usage

```bash
# Xem tất cả users
curl -H "Authorization: Bearer $TOKEN" \
  https://your-gateway.workers.dev/admin/users | jq .

# Xem usage hôm nay
curl -H "Authorization: Bearer $TOKEN" \
  https://your-gateway.workers.dev/admin/usage | jq .
```

### Upgrade user lên pro

```bash
curl -X POST https://your-gateway.workers.dev/admin/set-plan \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"email":"user@company.com","plan":"pro"}'
```

## Local Development

```bash
npx wrangler dev
# → http://localhost:8787
```
