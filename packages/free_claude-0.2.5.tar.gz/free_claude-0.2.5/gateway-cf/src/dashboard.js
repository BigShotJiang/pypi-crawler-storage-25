/**
 * Admin Dashboard — imports HTML as a string.
 * Wrangler bundles this at build time.
 */
import HTML from './dashboard.html';

export function getDashboardHTML() {
  return HTML;
}
