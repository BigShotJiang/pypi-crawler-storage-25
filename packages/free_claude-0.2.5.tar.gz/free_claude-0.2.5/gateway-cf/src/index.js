/**
 * fclaude Gateway — Cloudflare Worker
 *
 * Endpoints:
 *   POST /auth/register    — Register with invite code
 *   POST /auth/login       — Login, get JWT
 *   POST /auth/refresh     — Refresh JWT
 *   GET  /auth/me          — Current user info + usage
 *   POST /v1/messages      — Proxy to upstream (with auth + rate limit)
 *   GET  /admin/users      — List users (admin)
 *   GET  /admin/usage      — Usage stats (admin)
 *   POST /admin/invite     — Create invite code (admin)
 *   GET  /health           — Health check
 *
 * KV Namespaces: USERS, SESSIONS, USAGE, INVITES
 * Secrets: JWT_SECRET, UPSTREAM_URL, UPSTREAM_TOKEN, ADMIN_EMAIL, ADMIN_PASSWORD
 */

import { createJWT, verifyJWT, hashPassword, verifyPassword, randomId } from './crypto.js';
import { getDashboardHTML } from './dashboard.js';

// ── Helpers ──────────────────────────────────────────────────────

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  });
}

function error(message, status = 400) {
  return json({ error: message }, status);
}

async function getBody(request) {
  try { return await request.json(); } catch { return {}; }
}

async function getUser(request, env) {
  const auth = request.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return null;
  try {
    const payload = await verifyJWT(auth.slice(7), env.JWT_SECRET);
    if (payload.type !== 'access') return null;
    const user = await env.USERS.get(`user:${payload.sub}`, 'json');
    return user;
  } catch {
    return null;
  }
}

async function requireUser(request, env) {
  const user = await getUser(request, env);
  if (!user) throw new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
  if (!user.active) throw new Response(JSON.stringify({ error: 'Account disabled' }), { status: 403 });
  return user;
}

async function requireAdmin(request, env) {
  const user = await requireUser(request, env);
  if (!user.is_admin) throw new Response(JSON.stringify({ error: 'Admin required' }), { status: 403 });
  return user;
}

function todayKey() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD
}

const PLAN_CONFIG = {
  vip:   { daily_limit: -1,     models: ['haiku', 'sonnet4', 'opus4', 'sonnet', 'opus'] },
  free:  { daily_limit: 100,    models: ['haiku', 'sonnet4'] },
  pro:   { daily_limit: 1000,   models: ['haiku', 'sonnet4', 'opus4', 'sonnet', 'opus'] },
  admin: { daily_limit: 999999, models: ['haiku', 'sonnet4', 'opus4', 'sonnet', 'opus'] },
};


// ── Upstream Token Management ────────────────────────────────────
// UPSTREAM_TOKEN in secrets is static (set via wrangler secret).
// For tokens that expire (e.g. Claude HFI sessions), we store
// a dynamic token in KV that takes priority over the secret.

async function getUpstreamToken(env) {
  // Priority 1: dynamic token from KV (can be refreshed)
  const dynamic = await env.SESSIONS.get('upstream:access_token');

  if (dynamic) {
    // Proactive refresh: if token expires within 10 minutes, refresh NOW
    const expiring = isTokenExpiringSoon(dynamic, 600);
    if (expiring === true) {
      console.log('🔄 Upstream token expiring soon, refreshing proactively...');
      const newToken = await refreshUpstreamToken(env);
      if (newToken) {
        console.log('✅ Upstream token refreshed proactively.');
        return newToken;
      }
      // Refresh failed — use existing token (might still work for a few min)
      console.warn('⚠️ Proactive refresh failed, using existing token.');
    }
    return dynamic;
  }

  // Priority 2: static secret (also check expiry)
  const staticToken = env.UPSTREAM_TOKEN;
  if (staticToken) {
    const expiring = isTokenExpiringSoon(staticToken, 600);
    if (expiring === true) {
      console.warn('⚠️ Static UPSTREAM_TOKEN is expiring! Attempting refresh...');
      const newToken = await refreshUpstreamToken(env);
      if (newToken) return newToken;
    }
  }

  return staticToken;
}

async function getUpstreamRefreshToken(env) {
  return await env.SESSIONS.get('upstream:refresh_token');
}

async function saveUpstreamTokens(env, accessToken, refreshToken) {
  if (accessToken) {
    await env.SESSIONS.put('upstream:access_token', accessToken);
  }
  if (refreshToken) {
    await env.SESSIONS.put('upstream:refresh_token', refreshToken);
  }
  // Log rotation event
  await env.USAGE.put(`upstream:rotated:${Date.now()}`, JSON.stringify({
    rotated_at: new Date().toISOString(),
    has_refresh: !!refreshToken,
  }), { expirationTtl: 86400 * 30 });
}


// ── JWT Expiry Check (upstream token) ────────────────────────────
function decodeJWTPayload(token) {
  /**
   * Decode JWT payload without verification (we only need exp claim).
   * Works in Cloudflare Workers (no atob, use custom base64url decode).
   */
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    // base64url → base64 → binary → text
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const pad = b64 + '=='.slice(0, (4 - b64.length % 4) % 4);
    const binary = atob(pad);
    return JSON.parse(binary);
  } catch {
    return null;
  }
}

function isTokenExpiringSoon(token, thresholdSeconds = 600) {
  /**
   * Check if a token (JWT or opaque) will expire within thresholdSeconds.
   * Returns: true = needs refresh, false = still valid, null = can't determine.
   * Default threshold: 10 minutes (600s) — gives enough time to refresh.
   */
  if (!token) return true;
  const payload = decodeJWTPayload(token);
  if (!payload || !payload.exp) return null; // can't determine, assume ok
  const now = Math.floor(Date.now() / 1000);
  return (payload.exp - now) < thresholdSeconds;
}

async function refreshUpstreamToken(env) {
  /**
   * Attempt to refresh the upstream token.
   * Supports:
   *   1. OAuth-style refresh (Auth0, etc): POST with grant_type + client_id
   *   2. Simple token refresh: POST with just refresh_token
   *   3. Bearer-auth refresh: POST with refresh_token in Authorization header
   *
   * Required secrets/KV:
   *   - UPSTREAM_REFRESH_URL: the token endpoint (e.g. https://auth.domain.com/oauth/token)
   *   - KV upstream:refresh_token: the refresh token
   * Optional secrets:
   *   - UPSTREAM_CLIENT_ID: OAuth client_id (for Auth0/OAuth flows)
   *
   * Returns new access token or null on failure.
   */
  const refreshToken = await getUpstreamRefreshToken(env);
  const refreshUrl = env.UPSTREAM_REFRESH_URL; // secret

  if (!refreshToken || !refreshUrl) return null;

  // Build request body — include client_id if configured (OAuth flow)
  const body = {
    grant_type: 'refresh_token',
    refresh_token: refreshToken,
  };
  if (env.UPSTREAM_CLIENT_ID) {
    body.client_id = env.UPSTREAM_CLIENT_ID;
  }

  try {
    console.log('🔄 Attempting upstream token refresh at:', refreshUrl);
    const resp = await fetch(refreshUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      console.error('🔄 Refresh failed:', resp.status, errText.slice(0, 200));
      return null;
    }

    const data = await resp.json();
    const newAccess = data.access_token || data.token || data.key;
    const newRefresh = data.refresh_token;

    if (newAccess) {
      await saveUpstreamTokens(env, newAccess, newRefresh || refreshToken);
      console.log('✅ Upstream token refreshed. Expires in:', data.expires_in, 'seconds');
      return newAccess;
    }

    console.error('🔄 Refresh response missing access_token:', JSON.stringify(data).slice(0, 200));
  } catch (e) {
    console.error('🔄 Upstream token refresh error:', e.message);
  }
  return null;
}


// Map short tier names to model name patterns
const MODEL_PATTERNS = {
  'haiku':   ['haiku'],
  'sonnet4': ['sonnet-4', 'sonnet4'],
  'opus4':   ['opus-4', 'opus4'],
  'sonnet':  ['sonnet'],
  'opus':    ['opus'],
};

function modelAllowed(requestedModel, allowedTiers) {
  if (!requestedModel) return true;
  const rm = requestedModel.toLowerCase();
  for (const tier of allowedTiers) {
    const patterns = MODEL_PATTERNS[tier] || [tier];
    if (patterns.some(p => rm.includes(p))) return true;
  }
  return false;
}

// ── Auth Endpoints ───────────────────────────────────────────────

// ── Email Verification Helpers ────────────────────────────────────

function generateOTP() {
  // 6-digit numeric OTP
  const arr = new Uint8Array(4);
  crypto.getRandomValues(arr);
  return String(((arr[0] << 24 | arr[1] << 16 | arr[2] << 8 | arr[3]) >>> 0) % 1000000).padStart(6, '0');
}

async function sendVerificationEmail(email, otp, env) {
  // Use Resend API to send OTP email
  const apiKey = env.RESEND_API_KEY;
  if (!apiKey) return false;

  const fromEmail = env.EMAIL_FROM || 'noreply@fclaude.dev';

  try {
    const resp = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: `fclaude <${fromEmail}>`,
        to: [email],
        subject: `${otp} — fclaude verification code`,
        html: `
          <div style="font-family:-apple-system,sans-serif;max-width:400px;margin:0 auto;padding:2rem">
            <h2 style="color:#7c3aed;margin-bottom:0.5rem">⚡ fclaude</h2>
            <p style="color:#64748b;font-size:0.9rem">Your verification code:</p>
            <div style="background:#f1f5f9;border-radius:12px;padding:1.5rem;text-align:center;margin:1rem 0">
              <span style="font-size:2rem;font-weight:800;letter-spacing:0.3em;color:#1e293b">${otp}</span>
            </div>
            <p style="color:#94a3b8;font-size:0.8rem">This code expires in 10 minutes. If you didn't request this, ignore this email.</p>
          </div>
        `,
      }),
    });
    return resp.ok;
  } catch {
    return false;
  }
}

// ── Register ─────────────────────────────────────────────────────

async function handleRegister(request, env) {
  const body = await getBody(request);
  const { email, username, password, invite_code } = body;

  if (!email || !username || !password) {
    return error('email, username, password required');
  }

  // Validate email format
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return error('Invalid email format');
  }

  // Check invite
  const requireInvite = env.REQUIRE_INVITE === 'true';
  let plan = 'free';
  let skipVerification = false;

  if (requireInvite) {
    if (!invite_code) return error('Invite code required');
    const invite = await env.INVITES.get(`invite:${invite_code}`, 'json');
    if (!invite) return error('Invalid invite code');
    if (invite.used >= invite.max_uses) return error('Invite code exhausted');
    if (invite.expires_at && new Date(invite.expires_at) < new Date()) {
      return error('Invite code expired');
    }

    // Phase 1: Pinned email check — invite locked to specific email
    if (invite.pinned_email) {
      if (email.toLowerCase().trim() !== invite.pinned_email) {
        return error(`This invite is reserved for ${invite.pinned_email}`, 403);
      }
      // Pinned invite = email is implicitly verified (admin knows the person)
      skipVerification = true;
    }

    plan = invite.plan || 'free';
    // Increment usage
    invite.used = (invite.used || 0) + 1;
    await env.INVITES.put(`invite:${invite_code}`, JSON.stringify(invite));
  }

  // Check duplicate
  const existingId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (existingId) return error('Email already registered', 409);

  // Phase 2: Email OTP verification (if Resend configured and not pinned)
  const hasResend = !!env.RESEND_API_KEY;
  const needsVerification = hasResend && !skipVerification;

  if (needsVerification) {
    // Store pending registration + send OTP
    const otp = generateOTP();
    const pendingKey = `pending:${email.toLowerCase()}`;

    await env.SESSIONS.put(pendingKey, JSON.stringify({
      email: email.toLowerCase(),
      username,
      password_hash: await hashPassword(password),
      plan,
      invite_code: invite_code || null,
      otp,
      attempts: 0,
      created_at: new Date().toISOString(),
    }), { expirationTtl: 600 }); // 10 minutes TTL

    const sent = await sendVerificationEmail(email, otp, env);
    if (!sent) {
      // Resend failed — fall back to no verification
      console.warn('⚠️ Email send failed, proceeding without verification');
    } else {
      return json({
        requires_verification: true,
        email: email.toLowerCase(),
        message: 'Verification code sent to your email. Use POST /auth/verify-email to complete registration.',
      }, 202);
    }
  }

  // Direct registration (pinned invite, or no Resend configured)
  return await completeRegistration(env, email, username, password, plan);
}

async function handleVerifyEmail(request, env) {
  const { email, code } = await getBody(request);
  if (!email || !code) return error('email and code required');

  const pendingKey = `pending:${email.toLowerCase()}`;
  const pending = await env.SESSIONS.get(pendingKey, 'json');

  if (!pending) {
    return error('No pending registration found. Code may have expired (10 min).', 404);
  }

  // Rate limit attempts
  if (pending.attempts >= 5) {
    await env.SESSIONS.delete(pendingKey);
    return error('Too many attempts. Please register again.', 429);
  }

  if (pending.otp !== code.trim()) {
    pending.attempts += 1;
    await env.SESSIONS.put(pendingKey, JSON.stringify(pending), { expirationTtl: 600 });
    return error(`Invalid code. ${5 - pending.attempts} attempts remaining.`, 401);
  }

  // OTP correct — complete registration
  await env.SESSIONS.delete(pendingKey);

  // Re-check email not taken (race condition guard)
  const existingId = await env.USERS.get(`email:${pending.email}`);
  if (existingId) return error('Email already registered', 409);

  return await completeRegistration(
    env,
    pending.email,
    pending.username,
    null, // password already hashed
    pending.plan,
    pending.password_hash,
  );
}

async function completeRegistration(env, email, username, password, plan, existingHash = null) {
  const userId = randomId(12);
  const config = PLAN_CONFIG[plan] || PLAN_CONFIG.free;
  const user = {
    id: userId,
    email: email.toLowerCase(),
    username,
    password_hash: existingHash || await hashPassword(password),
    plan,
    daily_limit: config.daily_limit,
    models_allowed: config.models,
    active: true,
    is_admin: false,
    email_verified: true,
    created_at: new Date().toISOString(),
    total_requests: 0,
    total_input_tokens: 0,
    total_output_tokens: 0,
  };

  await env.USERS.put(`user:${userId}`, JSON.stringify(user));
  await env.USERS.put(`email:${email.toLowerCase()}`, userId);

  // Add to user list
  const userList = await env.USERS.get('_user_list', 'json') || [];
  userList.push({ id: userId, email: user.email, username, plan, created_at: user.created_at });
  await env.USERS.put('_user_list', JSON.stringify(userList));

  // Issue tokens
  const expireHours = parseInt(env.JWT_EXPIRE_HOURS || '24');
  const accessToken = await createJWT(
    { sub: userId, email: user.email, plan, type: 'access' },
    env.JWT_SECRET, expireHours
  );
  const refreshToken = await createJWT(
    { sub: userId, type: 'refresh' },
    env.JWT_SECRET, 24 * 30
  );

  return json({
    access_token: accessToken,
    refresh_token: refreshToken,
    token_type: 'bearer',
    expires_in: expireHours * 3600,
    plan,
    daily_limit: config.daily_limit,
    models: config.models,
  }, 201);
}

async function handleLogin(request, env) {
  const { email, password } = await getBody(request);
  if (!email || !password) return error('email and password required');

  // Find user
  const userId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (!userId) return error('Invalid email or password', 401);

  const user = await env.USERS.get(`user:${userId}`, 'json');
  if (!user) return error('Invalid email or password', 401);
  if (!user.active) return error('Account disabled', 403);

  // Verify password
  const valid = await verifyPassword(password, user.password_hash);
  if (!valid) return error('Invalid email or password', 401);

  // Issue tokens
  const expireHours = parseInt(env.JWT_EXPIRE_HOURS || '24');
  const accessToken = await createJWT(
    { sub: userId, email: user.email, plan: user.plan, type: 'access' },
    env.JWT_SECRET, expireHours
  );
  const refreshToken = await createJWT(
    { sub: userId, type: 'refresh' },
    env.JWT_SECRET, 24 * 30
  );

  // Update last login
  user.last_login = new Date().toISOString();
  await env.USERS.put(`user:${userId}`, JSON.stringify(user));

  return json({
    access_token: accessToken,
    refresh_token: refreshToken,
    token_type: 'bearer',
    expires_in: expireHours * 3600,
    plan: user.plan,
    daily_limit: user.daily_limit,
    models: user.models_allowed,
  });
}

async function handleRefresh(request, env) {
  const auth = request.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return error('Bearer token required', 401);

  let payload;
  try {
    payload = await verifyJWT(auth.slice(7), env.JWT_SECRET);
  } catch (e) {
    return error('Invalid or expired refresh token', 401);
  }

  if (payload.type !== 'refresh') return error('Not a refresh token', 401);

  const user = await env.USERS.get(`user:${payload.sub}`, 'json');
  if (!user || !user.active) return error('User not found or disabled', 401);

  const expireHours = parseInt(env.JWT_EXPIRE_HOURS || '24');
  const accessToken = await createJWT(
    { sub: user.id, email: user.email, plan: user.plan, type: 'access' },
    env.JWT_SECRET, expireHours
  );
  const refreshToken = await createJWT(
    { sub: user.id, type: 'refresh' },
    env.JWT_SECRET, 24 * 30
  );

  return json({
    access_token: accessToken,
    refresh_token: refreshToken,
    token_type: 'bearer',
    expires_in: expireHours * 3600,
    plan: user.plan,
    daily_limit: user.daily_limit,
    models: user.models_allowed,
  });
}

async function handleMe(request, env) {
  const user = await requireUser(request, env);

  // Get today's usage
  const day = todayKey();
  const dailyUsage = await env.USAGE.get(`daily:${user.id}:${day}`, 'json') || {
    requests: 0, input_tokens: 0, output_tokens: 0
  };

  return json({
    id: user.id,
    email: user.email,
    username: user.username,
    plan: user.plan,
    daily_limit: user.daily_limit,
    models_allowed: user.models_allowed,
    today: {
      requests: dailyUsage.requests,
      input_tokens: dailyUsage.input_tokens,
      output_tokens: dailyUsage.output_tokens,
      remaining: user.daily_limit === -1 ? 'unlimited' : Math.max(0, user.daily_limit - dailyUsage.requests),
    },
    totals: {
      requests: user.total_requests,
      input_tokens: user.total_input_tokens,
      output_tokens: user.total_output_tokens,
    },
    created_at: user.created_at,
    last_login: user.last_login,
  });
}

// ── API Proxy ────────────────────────────────────────────────────

async function handleProxy(request, env, ctx) {
  const user = await requireUser(request, env);

  // Rate limit
  const day = todayKey();
  const usageKey = `daily:${user.id}:${day}`;
  const dailyUsage = await env.USAGE.get(usageKey, 'json') || {
    requests: 0, input_tokens: 0, output_tokens: 0
  };

  if (user.daily_limit !== -1 && dailyUsage.requests >= user.daily_limit) {
    return error(
      `Daily limit reached (${user.daily_limit} requests). Resets at midnight UTC.`,
      429
    );
  }

  // Parse request body
  const body = await request.text();
  let bodyJson = {};
  try { bodyJson = JSON.parse(body); } catch {}

  // Model access check
  const requestedModel = bodyJson.model || '';
  if (requestedModel) {
    const allowed = user.models_allowed || [];
    const hasAccess = modelAllowed(requestedModel, allowed);
    if (!hasAccess) {
      return error(
        `Model '${requestedModel}' not available on ${user.plan} plan. Allowed: ${allowed.join(', ')}`,
        403
      );
    }
  }

  // Forward to upstream (with auto-refresh on 401)
  const upstreamUrl = `${env.UPSTREAM_URL}/v1/messages`;
  let upstreamToken = await getUpstreamToken(env);
  const makeHeaders = (token) => {
    const h = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'anthropic-version': request.headers.get('anthropic-version') || '2023-06-01',
    };
    const beta = request.headers.get('anthropic-beta');
    if (beta) h['anthropic-beta'] = beta;
    return h;
  };

  const isStream = bodyJson.stream === true;

  let upstreamResponse = await fetch(upstreamUrl, {
    method: 'POST',
    headers: makeHeaders(upstreamToken),
    body,
  });

  // Auto-refresh: if upstream returns 401, try refreshing the token and retry once
  if (upstreamResponse.status === 401) {
    const newToken = await refreshUpstreamToken(env);
    if (newToken) {
      upstreamResponse = await fetch(upstreamUrl, {
        method: 'POST',
        headers: makeHeaders(newToken),
        body,
      });
    }
  }

  // Log usage (async, don't block response)
  const logUsage = async (inputTokens, outputTokens) => {
    // Update daily usage
    dailyUsage.requests += 1;
    dailyUsage.input_tokens += inputTokens;
    dailyUsage.output_tokens += outputTokens;
    await env.USAGE.put(usageKey, JSON.stringify(dailyUsage), {
      expirationTtl: 86400 * 3 // auto-cleanup after 3 days
    });

    // Update user totals
    user.total_requests += 1;
    user.total_input_tokens += inputTokens;
    user.total_output_tokens += outputTokens;
    await env.USERS.put(`user:${user.id}`, JSON.stringify(user));

    // Log individual request for admin audit
    const logKey = `log:${day}:${user.id}:${Date.now()}`;
    await env.USAGE.put(logKey, JSON.stringify({
      user_id: user.id,
      email: user.email,
      model: requestedModel,
      input_tokens: inputTokens,
      output_tokens: outputTokens,
      status: upstreamResponse.status,
      timestamp: new Date().toISOString(),
    }), { expirationTtl: 86400 * 30 }); // keep 30 days
  };

  if (isStream) {
    // Streaming: read the full stream, collect chunks, then return + log
    const reader = upstreamResponse.body.getReader();
    const chunks = [];
    let outputText = '';

    // Read all chunks
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      // Try to extract output tokens from SSE message_delta
      const chunkStr = new TextDecoder().decode(value);
      if (chunkStr.includes('"output_tokens"')) {
        const m = chunkStr.match(/"output_tokens"\s*:\s*(\d+)/);
        if (m) outputText = m[1];
      }
    }

    const approxInputTokens = Math.ceil(body.length / 4);
    const outputTokens = outputText ? parseInt(outputText) : 0;

    // Log usage BEFORE returning (ensures KV write completes)
    await logUsage(approxInputTokens, outputTokens);

    // Reconstruct stream body
    const fullBody = new Uint8Array(chunks.reduce((acc, c) => acc + c.length, 0));
    let offset = 0;
    for (const chunk of chunks) {
      fullBody.set(chunk, offset);
      offset += chunk.length;
    }

    return new Response(fullBody, {
      status: upstreamResponse.status,
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Access-Control-Allow-Origin': '*',
        'X-Accel-Buffering': 'no',
      },
    });
  } else {
    // Non-streaming: parse response for accurate token counts
    const responseBody = await upstreamResponse.text();
    let inputTokens = 0, outputTokens = 0;
    try {
      const respJson = JSON.parse(responseBody);
      inputTokens = respJson.usage?.input_tokens || 0;
      outputTokens = respJson.usage?.output_tokens || 0;
    } catch {}

    // Log usage BEFORE returning
    await logUsage(inputTokens, outputTokens);

    return new Response(responseBody, {
      status: upstreamResponse.status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
}

// ── Admin Endpoints ──────────────────────────────────────────────

async function handleAdminUsers(request, env) {
  await requireAdmin(request, env);
  const userList = await env.USERS.get('_user_list', 'json') || [];

  // Enrich with current stats
  const enriched = [];
  for (const entry of userList) {
    const user = await env.USERS.get(`user:${entry.id}`, 'json');
    if (!user) continue;

    const day = todayKey();
    const dailyUsage = await env.USAGE.get(`daily:${user.id}:${day}`, 'json') || {
      requests: 0, input_tokens: 0, output_tokens: 0
    };

    enriched.push({
      id: user.id,
      email: user.email,
      username: user.username,
      plan: user.plan,
      active: user.active,
      is_admin: user.is_admin,
      daily_limit: user.daily_limit,
      models: user.models_allowed,
      today: dailyUsage,
      totals: {
        requests: user.total_requests,
        input_tokens: user.total_input_tokens,
        output_tokens: user.total_output_tokens,
      },
      created_at: user.created_at,
      last_login: user.last_login,
    });
  }

  return json({ users: enriched, count: enriched.length });
}

async function handleAdminUsage(request, env) {
  await requireAdmin(request, env);

  const day = todayKey();
  const userList = await env.USERS.get('_user_list', 'json') || [];

  let totalRequests = 0, totalInput = 0, totalOutput = 0;
  const perUser = [];

  for (const entry of userList) {
    const usage = await env.USAGE.get(`daily:${entry.id}:${day}`, 'json');
    if (usage && usage.requests > 0) {
      totalRequests += usage.requests;
      totalInput += usage.input_tokens;
      totalOutput += usage.output_tokens;
      perUser.push({
        email: entry.email,
        requests: usage.requests,
        input_tokens: usage.input_tokens,
        output_tokens: usage.output_tokens,
      });
    }
  }

  // Sort by requests desc
  perUser.sort((a, b) => b.requests - a.requests);

  return json({
    date: day,
    totals: { requests: totalRequests, input_tokens: totalInput, output_tokens: totalOutput },
    per_user: perUser,
    active_users: perUser.length,
  });
}

async function handleAdminInvite(request, env) {
  await requireAdmin(request, env);
  const { plan = 'free', max_uses = 1, expires_hours, email: pinnedEmail } = await getBody(request);

  const code = randomId(16);
  const invite = {
    code,
    plan,
    max_uses,
    used: 0,
    pinned_email: pinnedEmail ? pinnedEmail.toLowerCase().trim() : null,
    created_at: new Date().toISOString(),
    expires_at: expires_hours
      ? new Date(Date.now() + expires_hours * 3600000).toISOString()
      : null,
  };

  await env.INVITES.put(`invite:${code}`, JSON.stringify(invite));

  // Track invite list
  const inviteList = await env.INVITES.get('_invite_list', 'json') || [];
  inviteList.push({ code, plan, max_uses, pinned_email: invite.pinned_email, created_at: invite.created_at });
  await env.INVITES.put('_invite_list', JSON.stringify(inviteList));

  return json({ invite_code: code, plan, max_uses, pinned_email: invite.pinned_email, expires_at: invite.expires_at }, 201);
}

async function handleAdminSetPlan(request, env) {
  await requireAdmin(request, env);
  const { email, plan } = await getBody(request);

  if (!email || !plan) return error('email and plan required');
  const config = PLAN_CONFIG[plan];
  if (!config) return error(`Invalid plan. Options: ${Object.keys(PLAN_CONFIG).join(', ')}`);

  const userId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (!userId) return error('User not found', 404);

  const user = await env.USERS.get(`user:${userId}`, 'json');
  user.plan = plan;
  user.daily_limit = config.daily_limit;
  user.models_allowed = config.models;
  if (plan === 'admin') user.is_admin = true;

  await env.USERS.put(`user:${userId}`, JSON.stringify(user));

  return json({ email, plan, daily_limit: config.daily_limit, models: config.models });
}

async function handleAdminToggleUser(request, env) {
  await requireAdmin(request, env);
  const { email, active } = await getBody(request);

  if (!email || active === undefined) return error('email and active (bool) required');

  const userId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (!userId) return error('User not found', 404);

  const user = await env.USERS.get(`user:${userId}`, 'json');
  user.active = !!active;
  await env.USERS.put(`user:${userId}`, JSON.stringify(user));

  return json({ email, active: user.active });
}

async function handleAdminInvites(request, env) {
  await requireAdmin(request, env);
  const inviteList = await env.INVITES.get('_invite_list', 'json') || [];

  const enriched = [];
  for (const entry of inviteList) {
    const invite = await env.INVITES.get(`invite:${entry.code}`, 'json');
    if (invite) enriched.push(invite);
  }

  return json({ invites: enriched, count: enriched.length });
}


async function handleAdminLogs(request, env) {
  await requireAdmin(request, env);
  const url = new URL(request.url);
  const day = url.searchParams.get('date') || todayKey();
  const limit = Math.min(parseInt(url.searchParams.get('limit') || '100'), 500);
  const userFilter = url.searchParams.get('user') || '';

  // List all log keys for the day
  const prefix = `log:${day}:`;
  const list = await env.USAGE.list({ prefix, limit: 1000 });

  const logs = [];
  for (const key of list.keys) {
    const entry = await env.USAGE.get(key.name, 'json');
    if (!entry) continue;
    if (userFilter && entry.email !== userFilter) continue;
    logs.push(entry);
    if (logs.length >= limit) break;
  }

  // Sort newest first
  logs.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));

  return json({ date: day, logs, count: logs.length });
}

async function handleAdminUsageHistory(request, env) {
  await requireAdmin(request, env);
  const url = new URL(request.url);
  const days = Math.min(parseInt(url.searchParams.get('days') || '7'), 30);

  const history = [];
  const now = new Date();

  for (let i = 0; i < days; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dayKey = d.toISOString().slice(0, 10);

    const userList = await env.USERS.get('_user_list', 'json') || [];
    let totalReq = 0, totalIn = 0, totalOut = 0, activeUsers = 0;
    const modelBreakdown = {};

    for (const entry of userList) {
      const usage = await env.USAGE.get(`daily:${entry.id}:${dayKey}`, 'json');
      if (usage && usage.requests > 0) {
        totalReq += usage.requests;
        totalIn += usage.input_tokens || 0;
        totalOut += usage.output_tokens || 0;
        activeUsers++;
      }
    }

    // Model breakdown from logs
    const logPrefix = `log:${dayKey}:`;
    const logList = await env.USAGE.list({ prefix: logPrefix, limit: 1000 });
    for (const key of logList.keys) {
      const log = await env.USAGE.get(key.name, 'json');
      if (log && log.model) {
        modelBreakdown[log.model] = (modelBreakdown[log.model] || 0) + 1;
      }
    }

    history.push({
      date: dayKey,
      requests: totalReq,
      input_tokens: totalIn,
      output_tokens: totalOut,
      active_users: activeUsers,
      models: modelBreakdown,
    });
  }

  return json({ days, history });
}

async function handleAdminDeleteUser(request, env) {
  await requireAdmin(request, env);
  const { email } = await getBody(request);
  if (!email) return error('email required');

  const userId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (!userId) return error('User not found', 404);

  // Remove from user list
  const userList = await env.USERS.get('_user_list', 'json') || [];
  const filtered = userList.filter(u => u.email.toLowerCase() !== email.toLowerCase());
  await env.USERS.put('_user_list', JSON.stringify(filtered));

  // Delete user data
  await env.USERS.delete(`user:${userId}`);
  await env.USERS.delete(`email:${email.toLowerCase()}`);

  return json({ message: `User ${email} deleted` });
}

async function handleAdminEditUser(request, env) {
  await requireAdmin(request, env);
  const { email, daily_limit, models_allowed } = await getBody(request);
  if (!email) return error('email required');

  const userId = await env.USERS.get(`email:${email.toLowerCase()}`);
  if (!userId) return error('User not found', 404);

  const user = await env.USERS.get(`user:${userId}`, 'json');
  if (daily_limit !== undefined) user.daily_limit = parseInt(daily_limit);
  if (models_allowed !== undefined) user.models_allowed = models_allowed;
  await env.USERS.put(`user:${userId}`, JSON.stringify(user));

  return json({ email, daily_limit: user.daily_limit, models: user.models_allowed });
}

async function handleAdminRevokeInvite(request, env) {
  await requireAdmin(request, env);
  const { code } = await getBody(request);
  if (!code) return error('code required');

  const invite = await env.INVITES.get(`invite:${code}`, 'json');
  if (!invite) return error('Invite not found', 404);

  invite.max_uses = invite.used || 0; // exhaust it
  await env.INVITES.put(`invite:${code}`, JSON.stringify(invite));

  return json({ message: `Invite ${code} revoked`, used: invite.used, max_uses: invite.max_uses });
}

// ── Auto-create admin on first request ───────────────────────────

async function ensureAdmin(env) {
  if (!env.ADMIN_EMAIL || !env.ADMIN_PASSWORD) return;
  const existing = await env.USERS.get(`email:${env.ADMIN_EMAIL.toLowerCase()}`);
  if (existing) return;

  const userId = randomId(12);
  const config = PLAN_CONFIG.admin;
  const user = {
    id: userId,
    email: env.ADMIN_EMAIL.toLowerCase(),
    username: 'admin',
    password_hash: await hashPassword(env.ADMIN_PASSWORD),
    plan: 'admin',
    daily_limit: config.daily_limit,
    models_allowed: config.models,
    active: true,
    is_admin: true,
    created_at: new Date().toISOString(),
    total_requests: 0,
    total_input_tokens: 0,
    total_output_tokens: 0,
  };

  await env.USERS.put(`user:${userId}`, JSON.stringify(user));
  await env.USERS.put(`email:${user.email}`, userId);

  const userList = await env.USERS.get('_user_list', 'json') || [];
  userList.push({ id: userId, email: user.email, username: 'admin', plan: 'admin', created_at: user.created_at });
  await env.USERS.put('_user_list', JSON.stringify(userList));
}


async function handleAdminUpstreamToken(request, env) {
  await requireAdmin(request, env);
  const method = request.method;

  if (method === 'GET') {
    // Show upstream token status (masked) + expiry info
    const dynamicToken = await env.SESSIONS.get('upstream:access_token');
    const refreshToken = await env.SESSIONS.get('upstream:refresh_token');
    const hasStatic = !!env.UPSTREAM_TOKEN;

    // Check active token expiry
    const activeToken = dynamicToken || env.UPSTREAM_TOKEN;
    let expiryInfo = null;
    if (activeToken) {
      const payload = decodeJWTPayload(activeToken);
      if (payload && payload.exp) {
        const now = Math.floor(Date.now() / 1000);
        const remaining = payload.exp - now;
        expiryInfo = {
          expires_at: new Date(payload.exp * 1000).toISOString(),
          remaining_seconds: remaining,
          remaining_human: remaining > 3600
            ? Math.floor(remaining / 3600) + 'h ' + Math.floor((remaining % 3600) / 60) + 'm'
            : Math.floor(remaining / 60) + 'm ' + (remaining % 60) + 's',
          is_expired: remaining <= 0,
          is_expiring_soon: remaining > 0 && remaining < 600,
          status: remaining <= 0 ? '🔴 EXPIRED' : remaining < 600 ? '🟡 EXPIRING SOON' : remaining < 3600 ? '🟠 <1h remaining' : '🟢 HEALTHY',
        };
      } else {
        expiryInfo = { status: '⚪ Unknown (opaque token)', is_jwt: false };
      }
    }

    // Get last cron refresh status
    const lastCron = await env.USAGE.get('upstream:last_cron_refresh', 'json');

    return json({
      has_static_secret: hasStatic,
      has_dynamic_token: !!dynamicToken,
      has_refresh_token: !!refreshToken,
      has_refresh_url: !!env.UPSTREAM_REFRESH_URL,
      dynamic_token_preview: dynamicToken
        ? dynamicToken.slice(0, 8) + '...' + dynamicToken.slice(-4)
        : null,
      active_source: dynamicToken ? 'kv_dynamic' : (hasStatic ? 'secret_static' : 'none'),
      expiry: expiryInfo,
      last_cron_refresh: lastCron,
      auto_refresh: {
        enabled: !!(refreshToken && env.UPSTREAM_REFRESH_URL),
        cron_schedule: 'every 1 hour',
        proactive_threshold: '10 minutes before expiry',
        reactive_on_401: true,
      },
    });
  }

  if (method === 'POST') {
    // Set/update upstream tokens
    const { access_token, refresh_token } = await getBody(request);
    if (!access_token) return error('access_token required');

    await saveUpstreamTokens(env, access_token, refresh_token);

    return json({
      message: 'Upstream tokens updated',
      has_refresh: !!refresh_token,
      token_preview: access_token.slice(0, 8) + '...' + access_token.slice(-4),
    });
  }

  if (method === 'DELETE') {
    // Clear dynamic tokens (fall back to static secret)
    await env.SESSIONS.delete('upstream:access_token');
    await env.SESSIONS.delete('upstream:refresh_token');
    return json({ message: 'Dynamic upstream tokens cleared. Using static secret.' });
  }

  return error('Method not allowed', 405);
}

async function handleAdminForceRefresh(request, env) {
  await requireAdmin(request, env);
  const newToken = await refreshUpstreamToken(env);
  if (newToken) {
    return json({
      message: 'Upstream token refreshed successfully',
      token_preview: newToken.slice(0, 8) + '...' + newToken.slice(-4),
    });
  }
  return error('Refresh failed. Check UPSTREAM_REFRESH_URL and refresh_token.', 500);
}

// ── Router ───────────────────────────────────────────────────────

export default {
  // Cron trigger: smart auto-refresh upstream token (every 6h)
  async scheduled(event, env, ctx) {
    console.log('⏰ Cron: checking upstream token status...');
    try {
      // Check if refresh is configured
      const refreshToken = await getUpstreamRefreshToken(env);
      if (!refreshToken || !env.UPSTREAM_REFRESH_URL) {
        console.log('⏰ No refresh token/URL configured, skipping.');
        return;
      }

      // Check current token expiry
      const currentToken = await env.SESSIONS.get('upstream:access_token') || env.UPSTREAM_TOKEN;
      const expiring = isTokenExpiringSoon(currentToken, 3600); // 1 hour threshold for cron

      if (expiring === true) {
        console.log('⏰ Token expiring within 1 hour, refreshing...');
        const newToken = await refreshUpstreamToken(env);
        if (newToken) {
          console.log('✅ Cron: upstream token refreshed. New token preview:', newToken.slice(0, 8) + '...');
          // Log successful rotation
          await env.USAGE.put('upstream:last_cron_refresh', JSON.stringify({
            time: new Date().toISOString(),
            success: true,
          }), { expirationTtl: 86400 * 7 });
        } else {
          console.error('❌ Cron: refresh FAILED! Manual intervention may be needed.');
          await env.USAGE.put('upstream:last_cron_refresh', JSON.stringify({
            time: new Date().toISOString(),
            success: false,
            error: 'refresh returned null',
          }), { expirationTtl: 86400 * 7 });
        }
      } else if (expiring === false) {
        console.log('⏰ Token still valid (>1h remaining), no refresh needed.');
      } else {
        // Can't determine (opaque token) — refresh anyway to be safe
        console.log('⏰ Cannot determine token expiry (opaque token), refreshing to be safe...');
        const newToken = await refreshUpstreamToken(env);
        if (newToken) {
          console.log('✅ Cron: refreshed opaque token.');
        }
      }
    } catch (e) {
      console.error('⏰ Cron error:', e.message);
      await env.USAGE.put('upstream:last_cron_refresh', JSON.stringify({
        time: new Date().toISOString(),
        success: false,
        error: e.message,
      }), { expirationTtl: 86400 * 7 });
    }
  },

  async fetch(request, env, ctx) {
    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Authorization, Content-Type, anthropic-version, anthropic-beta',
          'Access-Control-Max-Age': '86400',
        },
      });
    }

    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    try {
      // Auto-create admin user on first request
      await ensureAdmin(env);

      // ── Auth routes ──
      if (path === '/auth/register' && method === 'POST') return await handleRegister(request, env);
      if (path === '/auth/verify-email' && method === 'POST') return await handleVerifyEmail(request, env);
      if (path === '/auth/login'    && method === 'POST') return await handleLogin(request, env);
      if (path === '/auth/refresh'  && method === 'POST') return await handleRefresh(request, env);
      if (path === '/auth/me'       && method === 'GET')  return await handleMe(request, env);

      // ── API proxy ──
      if (path === '/v1/messages'   && method === 'POST') return await handleProxy(request, env, ctx);

      // ── Admin routes ──
      if (path === '/admin/users'    && method === 'GET')  return await handleAdminUsers(request, env);
      if (path === '/admin/usage'    && method === 'GET')  return await handleAdminUsage(request, env);
      if (path === '/admin/invite'   && method === 'POST') return await handleAdminInvite(request, env);
      if (path === '/admin/invites'  && method === 'GET')  return await handleAdminInvites(request, env);
      if (path === '/admin/set-plan' && method === 'POST') return await handleAdminSetPlan(request, env);
      if (path === '/admin/toggle-user' && method === 'POST') return await handleAdminToggleUser(request, env);

      // ── Upstream token management ──
      if (path === '/admin/upstream-token' && (method === 'GET' || method === 'POST' || method === 'DELETE')) {
        return await handleAdminUpstreamToken(request, env);
      }
      if (path === '/admin/upstream-refresh' && method === 'POST') {
        return await handleAdminForceRefresh(request, env);
      }
      if (path === '/admin/logs' && method === 'GET') return await handleAdminLogs(request, env);
      if (path === '/admin/usage-history' && method === 'GET') return await handleAdminUsageHistory(request, env);
      if (path === '/admin/delete-user' && method === 'POST') return await handleAdminDeleteUser(request, env);
      if (path === '/admin/edit-user' && method === 'POST') return await handleAdminEditUser(request, env);
      if (path === '/admin/revoke-invite' && method === 'POST') return await handleAdminRevokeInvite(request, env);

      // ── Dashboard ──
      if (path === '/admin' || path === '/admin/dashboard') {
        return new Response(getDashboardHTML(), {
          status: 200,
          headers: { 'Content-Type': 'text/html; charset=utf-8' },
        });
      }

      // ── Health ──
      if (path === '/health') return json({ status: 'ok', version: '1.0.0' });

      return error('Not found', 404);

    } catch (e) {
      if (e instanceof Response) return e;
      console.error('Unhandled error:', e);
      return error('Internal server error', 500);
    }
  },
};
