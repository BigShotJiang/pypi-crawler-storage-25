/**
 * Crypto utilities — JWT + password hashing for Cloudflare Workers.
 * Uses Web Crypto API (native in Workers, no dependencies).
 */

// ── Base64 URL helpers ───────────────────────────────────────────
function base64UrlEncode(data) {
  const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  const base64 = btoa(String.fromCharCode(...bytes));
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  const binary = atob(str);
  return new Uint8Array([...binary].map(c => c.charCodeAt(0)));
}

// ── JWT ──────────────────────────────────────────────────────────
async function getSigningKey(secret) {
  const keyData = new TextEncoder().encode(secret);
  return crypto.subtle.importKey(
    'raw', keyData, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']
  );
}

export async function createJWT(payload, secret, expiresInHours = 24) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);

  const fullPayload = {
    ...payload,
    iat: now,
    exp: now + (expiresInHours * 3600),
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;

  const key = await getSigningKey(secret);
  const signature = await crypto.subtle.sign(
    'HMAC', key, new TextEncoder().encode(signingInput)
  );

  return `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
}

export async function verifyJWT(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Invalid token format');

  const [encodedHeader, encodedPayload, encodedSignature] = parts;
  const signingInput = `${encodedHeader}.${encodedPayload}`;

  const key = await getSigningKey(secret);
  const signature = base64UrlDecode(encodedSignature);
  const valid = await crypto.subtle.verify(
    'HMAC', key, signature, new TextEncoder().encode(signingInput)
  );

  if (!valid) throw new Error('Invalid signature');

  const payload = JSON.parse(new TextDecoder().decode(base64UrlDecode(encodedPayload)));

  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
    throw new Error('Token expired');
  }

  return payload;
}

// ── Password Hashing (PBKDF2 — native Web Crypto) ───────────────
export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']
  );
  const hash = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial, 256
  );
  // Store as: salt$hash (both base64url)
  return `${base64UrlEncode(salt)}$${base64UrlEncode(new Uint8Array(hash))}`;
}

export async function verifyPassword(password, stored) {
  const [saltB64, hashB64] = stored.split('$');
  const salt = base64UrlDecode(saltB64);
  const expectedHash = base64UrlDecode(hashB64);

  const keyMaterial = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']
  );
  const actualHash = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial, 256
  );

  const actual = new Uint8Array(actualHash);
  if (actual.length !== expectedHash.length) return false;
  let match = true;
  for (let i = 0; i < actual.length; i++) {
    if (actual[i] !== expectedHash[i]) match = false; // constant time compare
  }
  return match;
}

// ── Random ID ────────────────────────────────────────────────────
export function randomId(length = 16) {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  return base64UrlEncode(bytes);
}
