# fclaude Token Gateway

API proxy + authentication server for fclaude.

## Architecture

```
User (fclaude CLI)
    │ Bearer <fclaude_token>
    ▼
gateway (FastAPI)
    ├── /auth/register     → create user account
    ├── /auth/login        → issue JWT
    ├── /auth/refresh      → refresh JWT
    ├── /v1/messages       → proxy to upstream (hidden)
    ├── /admin/users       → manage users (admin only)
    └── /admin/tokens      → manage invite codes
```

## Setup

```bash
cd gateway
pip install -r requirements.txt
cp .env.example .env     # configure upstream + secrets
uvicorn server:app --host 0.0.0.0 --port 8080
```

## Deploy

```bash
# Docker
docker build -t fclaude-gateway .
docker run -p 8080:8080 --env-file .env fclaude-gateway

# Or systemd
sudo cp fclaude-gateway.service /etc/systemd/system/
sudo systemctl enable --now fclaude-gateway
```
