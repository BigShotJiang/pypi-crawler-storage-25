"""Auto-delegate — intelligent task routing to specialized teammates.

Analyses user prompts and automatically:
1. Detects which specialist roles are needed
2. Ensures those teammates exist (auto-creates if missing)
3. Delegates sub-tasks in parallel
4. Streams realtime progress (tool calls, reasoning) to the user
5. Returns results WITHOUT blocking the main prompt
"""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import rich_ui as ui
from .teammates import AgentTeam, Task, TaskStatus, TeammateRole

# ── Role detection keywords ────────────────────────────────────────────
# Each role maps to keyword patterns (regex).  A prompt matching any pattern
# for a role will cause that role to be selected for delegation.

_ROLE_KEYWORDS: Dict[TeammateRole, List[str]] = {
    TeammateRole.CODE_REVIEWER: [
        r"\breview\b",
        r"\bcheck\s+(code|quality|style)\b",
        r"\bcode\s+quality\b",
        r"\blint\b",
        r"\bPR\b",
        r"\bpull\s+request\b",
        r"\bfeedback\b.*\bcode\b",
        r"\bkiểm tra\b.*\b(code|mã)\b",
        r"\breview\b.*\b(file|code|module)\b",
        r"\bcode\s+smell\b",
        r"\bbest\s+practice\b",
        r"\bclean\s+code\b",
        r"\banti[- ]?pattern\b",
    ],
    TeammateRole.TEST_WRITER: [
        r"\b(write|create|add|generate)\b.*\btests?\b",
        r"\bunit\s+tests?\b",
        r"\btest\s+cases?\b",
        r"\bcoverage\b",
        r"\bpytest\b",
        r"\bunittest\b",
        r"\bviết\b.*\btest\b",
        r"\btesting\b",
        r"\bedge\s+case\b",
        r"\bintegration\s+tests?\b",
        r"\btest\s+suite\b",
        r"\bwrite\b.*\btests\b",
        r"\bTDD\b",
        r"\bmock\b.*\btest\b",
    ],
    TeammateRole.DOCS_WRITER: [
        r"\b(write|create|generate|update)\b.*\b(doc|documentation|readme)\b",
        r"\bdocstring\b",
        r"\bcomment\b.*\b(code|function|class)\b",
        r"\bviết\b.*\b(tài liệu|doc|hướng dẫn)\b",
        r"\bAPI\s+doc\b",
        r"\bREADME\b",
        r"\bCHANGELOG\b",
        r"\busage\s+(guide|example)\b",
    ],
    TeammateRole.DEBUGGER: [
        r"\bdebug\b",
        r"\b(find|fix|trace|investigate)\b.*\b(bug|error|issue|crash)\b",
        r"\berror\b.*\b(message|trace|log)\b",
        r"\broot\s+cause\b",
        r"\btraceback\b",
        r"\bexception\b",
        r"\bcrash\b",
        r"\blỗi\b",
        r"\bsửa\b.*\bbug\b",
        r"\bfix\b.*\b(bug|issue|problem)\b",
        r"\bmemory\s+leak\b",
        r"\bsegfault\b",
        r"\bstack\s+trace\b",
        r"\bbreakpoint\b",
        r"\brace\s+condition\b",
    ],
    TeammateRole.REFACTORER: [
        r"\brefactor\b",
        r"\bimprove\b.*\b(code|structure|readability)\b",
        r"\bsimplify\b",
        r"\breduce\s+complexity\b",
        r"\bclean\s+up\b",
        r"\btechnical\s+debt\b",
        r"\bDRY\b",
        r"\bextract\s+(method|function|class)\b",
        r"\bcải thiện\b",
        r"\btối ưu\b.*\b(code|mã)\b",
        r"\bSOLID\b",
        r"\bdesign\s+pattern\b.*\bapply\b",
    ],
    TeammateRole.ARCHITECT: [
        r"\b(design|architect)\b.*\b(system|module|service|api)\b",
        r"\bmicroservice\b",
        r"\bscalability\b",
        r"\bsystem\s+design\b",
        r"\barchitecture\b",
        r"\bhigh[- ]level\b.*\bdesign\b",
        r"\bthiết kế\b.*\b(hệ thống|kiến trúc)\b",
        r"\btrade[- ]?off\b",
        r"\bmonolith\b",
        r"\bload\s+balanc\b",
        r"\bcaching\s+strategy\b",
        r"\bAPI\s+design\b",
        r"\bdata\s+model\b",
    ],
    TeammateRole.SECURITY_AUDITOR: [
        r"\bsecurity\b",
        r"\baudit\b",
        r"\bvulnerabilit\b",
        r"\binjection\b",
        r"\bXSS\b",
        r"\bCSRF\b",
        r"\bauth\b.*\b(issue|problem|check)\b",
        r"\bOWASP\b",
        r"\bpentest\b",
        r"\bbảo mật\b",
        r"\bsensitive\s+data\b",
        r"\bencryption\b",
        r"\bhash\b.*\bpassword\b",
        r"\baccess\s+control\b",
        r"\bprivilege\b",
    ],
}

# Minimum confidence: how many keyword hits before a role is considered
_MIN_HITS = 1


# ── Data structures ────────────────────────────────────────────────────


@dataclass
class DelegationPlan:
    """Describes which roles should handle which sub-tasks."""

    original_prompt: str
    assignments: List[RoleAssignment] = field(default_factory=list)
    # If no role matched, this is True → fall back to normal agent
    fallback: bool = False


@dataclass
class RoleAssignment:
    role: TeammateRole
    sub_task: str
    confidence: int = 0  # number of keyword hits


@dataclass
class DelegationResult:
    """Collected results from all teammates."""

    plan: DelegationPlan
    results: Dict[str, TaskResult] = field(default_factory=dict)
    elapsed: float = 0.0


@dataclass
class TaskResult:
    role: TeammateRole
    task_id: str
    status: str
    output: Optional[str] = None
    error: Optional[str] = None


# ── Core analyser ──────────────────────────────────────────────────────


class AutoDelegator:
    """Analyses prompts and orchestrates automatic delegation to teammates."""

    def __init__(self, team: AgentTeam):
        self.team = team
        self.enabled: bool = True
        self._last_plan: Optional[DelegationPlan] = None

    # ── 1. Analyse prompt → detect roles ───────────────────────────────

    def analyse(self, prompt: str) -> DelegationPlan:
        """Analyse a prompt and determine which roles should handle it.

        Returns a DelegationPlan. If no roles are detected (simple question),
        plan.fallback will be True.
        """
        prompt_lower = prompt.lower()
        hits: Dict[TeammateRole, int] = {}

        for role, patterns in _ROLE_KEYWORDS.items():
            count = 0
            for pattern in patterns:
                if re.search(pattern, prompt_lower):
                    count += 1
            if count >= _MIN_HITS:
                hits[role] = count

        if not hits:
            return DelegationPlan(original_prompt=prompt, fallback=True)

        # Sort by confidence (most hits first)
        sorted_roles = sorted(hits.items(), key=lambda x: x[1], reverse=True)

        assignments = []
        for role, confidence in sorted_roles:
            sub_task = self._build_sub_task(prompt, role)
            assignments.append(
                RoleAssignment(
                    role=role,
                    sub_task=sub_task,
                    confidence=confidence,
                )
            )

        plan = DelegationPlan(
            original_prompt=prompt,
            assignments=assignments,
        )
        self._last_plan = plan
        return plan

    def _build_sub_task(self, prompt: str, role: TeammateRole) -> str:
        """Build a role-specific sub-task description from the original prompt."""
        role_focus = {
            TeammateRole.CODE_REVIEWER: (
                "Focus on: code correctness, style issues, potential bugs, "
                "performance problems, and best practice violations."
            ),
            TeammateRole.TEST_WRITER: (
                "Focus on: writing comprehensive tests with good coverage. "
                "Include happy paths, edge cases, and error conditions. "
                "Use pytest style."
            ),
            TeammateRole.DOCS_WRITER: (
                "Focus on: writing clear, developer-friendly documentation. "
                "Include usage examples and explain the purpose of each component."
            ),
            TeammateRole.DEBUGGER: (
                "Focus on: identifying the root cause systematically. "
                "Trace the execution flow, analyse error messages, "
                "and suggest minimal, safe fixes."
            ),
            TeammateRole.REFACTORER: (
                "Focus on: safe, incremental improvements. "
                "Reduce complexity, improve readability, eliminate duplication. "
                "Preserve existing behaviour."
            ),
            TeammateRole.ARCHITECT: (
                "Focus on: high-level design decisions, scalability, "
                "component boundaries, and long-term maintainability. "
                "Provide concrete recommendations."
            ),
            TeammateRole.SECURITY_AUDITOR: (
                "Focus on: identifying security vulnerabilities — injection attacks, "
                "auth issues, data leaks, insecure defaults. "
                "Prioritise findings by severity."
            ),
        }
        focus = role_focus.get(role, "")
        return f"{prompt}\n\n[{role.value} instructions]: {focus}"

    # ── 2. Execute plan — auto-create teammates & delegate ─────────────

    def execute(self, plan: DelegationPlan, timeout: float = 120.0) -> DelegationResult:
        """Execute a delegation plan:
        1. Auto-create missing teammates
        2. Delegate sub-tasks in parallel
        3. Wait for all results with realtime progress display
        4. Return collected results
        """
        t0 = time.time()
        result = DelegationResult(plan=plan)

        if plan.fallback:
            return result

        tasks: List[Tuple[TeammateRole, Task]] = []

        for assignment in plan.assignments:
            # Auto-create teammate if not exists
            self._ensure_role(assignment.role)

            # Delegate
            task = self.team.delegate_task(
                title=plan.original_prompt[:80],
                description=assignment.sub_task,
                role=assignment.role,
                run_async=True,
            )
            tasks.append((assignment.role, task))

        # ── Realtime progress display while waiting ────────────────────
        # Instead of silently blocking, show a live progress panel
        _show_realtime_progress(self.team, tasks, timeout)

        # Collect results
        for role, task in tasks:
            updated = self.team.get_task(task.id)
            if updated:
                status = updated.status
                if status in (TaskStatus.ASSIGNED.value, TaskStatus.IN_PROGRESS.value):
                    status = TaskStatus.FAILED.value
                    error = updated.error or "Timed out waiting for teammate response"
                else:
                    error = updated.error
                result.results[role.value] = TaskResult(
                    role=role,
                    task_id=updated.id,
                    status=status,
                    output=updated.result,
                    error=error,
                )

        result.elapsed = time.time() - t0
        return result

    def _ensure_role(self, role: TeammateRole):
        """Add a teammate for this role if none exists yet."""
        existing = self.team.coordinator._by_role.get(role, [])
        if not existing:
            self.team.add_teammate(None, role)

    # ── 3. Format results into unified response ───────────────────────

    @staticmethod
    def format_results(result: DelegationResult) -> str:
        """Format delegation results into a readable Markdown report."""
        if not result.results:
            return ""

        parts = []
        parts.append("## 🤖 Auto-Delegate Report")
        parts.append(f"**Prompt:** {result.plan.original_prompt[:120]}")
        parts.append(f"**Teammates:** {len(result.results)} | **Time:** {result.elapsed:.1f}s")
        parts.append("")

        for role_name, task_result in result.results.items():
            emoji = _role_emoji(task_result.role)
            status_icon = "✅" if task_result.status == TaskStatus.DONE.value else "❌"

            parts.append("---")
            parts.append(f"### {emoji} {role_name} {status_icon}")
            parts.append("")

            if task_result.output:
                parts.append(task_result.output)
            elif task_result.error:
                parts.append(f"**Error:** {task_result.error}")
            else:
                parts.append("_(No output)_")
            parts.append("")

        return "\n".join(parts)

    @property
    def last_plan(self) -> Optional[DelegationPlan]:
        return self._last_plan


def _role_emoji(role: TeammateRole) -> str:
    return {
        TeammateRole.CODE_REVIEWER: "🔍",
        TeammateRole.TEST_WRITER: "🧪",
        TeammateRole.DOCS_WRITER: "📝",
        TeammateRole.DEBUGGER: "🐛",
        TeammateRole.REFACTORER: "♻️",
        TeammateRole.ARCHITECT: "🏗️",
        TeammateRole.SECURITY_AUDITOR: "🔒",
    }.get(role, "🤖")


# ── Realtime progress display ──────────────────────────────────────────


def _show_realtime_progress(
    team: AgentTeam, tasks: List[Tuple[TeammateRole, Task]], timeout: float
):
    """Show live progress of teammate work with realtime tool call / status updates.

    This replaces the old silent `wait_for_task` loop.
    The user sees exactly what each teammate is doing in realtime.
    """
    from rich import box
    from rich.live import Live
    from rich.table import Table
    from rich.text import Text

    deadline = time.time() + timeout

    # Collect realtime events from teammates via on_status callback
    events_lock = threading.Lock()
    latest_events: Dict[str, Dict] = {}  # teammate_name → latest event

    def _on_status(event: Dict):
        with events_lock:
            latest_events[event.get("teammate", "?")] = event

    # Wire callback to all teammates
    for _, task in tasks:
        if task.assigned_to:
            tm = team.get_teammate(task.assigned_to)
            if tm:
                tm.on_status = _on_status

    def _build_table():
        t = Table(
            box=box.SIMPLE_HEAD,
            header_style="bold cyan",
            padding=(0, 1),
            expand=True,
            show_edge=False,
        )
        t.add_column("Teammate", style="yellow", width=22, no_wrap=True)
        t.add_column("Status", width=14, no_wrap=True)
        t.add_column("Activity", style="dim", min_width=40)

        for role, task in tasks:
            updated = team.get_task(task.id)
            status = updated.status if updated else "pending"
            assigned = updated.assigned_to if updated else "?"

            # Color-coded status
            if status == TaskStatus.DONE.value:
                status_text = Text("✅ Done", style="bold green")
            elif status == TaskStatus.FAILED.value:
                status_text = Text("❌ Failed", style="bold red")
            elif status == TaskStatus.IN_PROGRESS.value:
                status_text = Text("⚙ Working", style="bold cyan")
            else:
                status_text = Text(f"⏳ {status}", style="yellow")

            # Latest activity from realtime events
            with events_lock:
                evt = latest_events.get(assigned, {})
            activity = evt.get("detail", "") if evt else ""
            event_type = evt.get("event", "") if evt else ""

            if event_type == "tool_call":
                activity_text = Text(f"🔧 {activity[:60]}", style="cyan")
            elif event_type == "tool_result":
                activity_text = Text(f"📦 {activity[:60]}", style="dim green")
            elif event_type == "thinking":
                activity_text = Text(f"🧠 {activity[:60]}", style="magenta")
            elif event_type == "task_done":
                activity_text = Text(f"✅ {activity[:60]}", style="green")
            elif event_type == "task_error":
                activity_text = Text(f"❌ {activity[:60]}", style="red")
            else:
                # Show tool call count if available
                if assigned:
                    tm = team.get_teammate(assigned)
                    if tm and tm.last_tool_calls:
                        n = len(tm.last_tool_calls)
                        activity_text = Text(f"({n} tool calls so far)", style="dim")
                    else:
                        activity_text = Text("starting...", style="dim")
                else:
                    activity_text = Text("queued", style="dim")

            t.add_row(
                f"{_role_emoji(role)} {assigned or role.value}",
                status_text,
                activity_text,
            )
        return t

    # Check if all tasks are already done (fast path)
    def _all_done():
        for _, task in tasks:
            updated = team.get_task(task.id)
            if not updated:
                return False
            if updated.status not in (
                TaskStatus.DONE.value,
                TaskStatus.FAILED.value,
                TaskStatus.CANCELLED.value,
            ):
                return False
        return True

    # Live progress display
    try:
        with Live(
            _build_table(), console=ui.console, refresh_per_second=4, transient=False
        ) as live:
            while time.time() < deadline:
                if _all_done():
                    live.update(_build_table())
                    break
                live.update(_build_table())
                time.sleep(0.25)
    except KeyboardInterrupt:
        ui.print_warning("Delegation interrupted — partial results may be available")


# ── UI helpers for displaying delegation ───────────────────────────────


def show_delegation_plan(plan: DelegationPlan):
    """Display the delegation plan in a pretty table."""
    from rich import box
    from rich.table import Table

    table = Table(
        title="🎯 Auto-Delegate Plan",
        box=box.ROUNDED,
        header_style="bold cyan",
        border_style="dim cyan",
        padding=(0, 2),
    )
    table.add_column("#", style="dim", width=3)
    table.add_column("Role", style="yellow", no_wrap=True)
    table.add_column("Confidence", style="magenta", justify="center", width=12)
    table.add_column("Status", style="green", width=10)

    for i, a in enumerate(plan.assignments, 1):
        stars = "★" * min(a.confidence, 5)
        table.add_row(str(i), a.role.value, stars, "→ delegating")

    ui.console.print()
    ui.console.print(table)
    ui.console.print()


def show_delegation_result(result: DelegationResult):
    """Display delegation results with role panels."""
    from rich.panel import Panel

    if not result.results:
        ui.print_info("No results from delegation")
        return

    ui.console.print()
    ui.console.print(
        f"[bold cyan]🤖 Auto-Delegate Complete[/bold cyan]  "
        f"[dim]({len(result.results)} teammates, {result.elapsed:.1f}s)[/dim]"
    )
    ui.console.print()

    for role_name, task_result in result.results.items():
        emoji = _role_emoji(task_result.role)
        if task_result.status == TaskStatus.DONE.value:
            border = "green"
            status = "✅ Done"
        elif task_result.status == TaskStatus.FAILED.value:
            border = "red"
            status = "❌ Failed"
        else:
            border = "yellow"
            status = f"⏳ {task_result.status}"

        title = f"{emoji} {role_name} — {status}"
        body = task_result.output or task_result.error or "_(No output)_"

        # Truncate very long results for display
        if len(body) > 3000:
            body = body[:3000] + "\n\n... (truncated, use /task result <id> for full output)"

        ui.console.print(Panel(body, title=title, border_style=border, padding=(1, 2)))
        ui.console.print()
