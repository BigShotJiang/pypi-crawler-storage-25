"""Production-grade Rich TUI for free-claude CLI.

Redesigned for a clean, professional look:
  - Branded ASCII-art banner with gradient
  - Unified color palette & spacing
  - Compact 1-line prompt with live stats
  - Tree-style tool output with timing badges
  - Tiered /help (essential ↔ full) in card layout
  - Actionable error panels
  - Persistent input history via prompt_toolkit
"""

import os
import subprocess
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from rich import box
from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# Enable readline support for input() — cross-platform
from .compat import setup_readline, setup_slash_completion

setup_readline()
setup_slash_completion()

console = Console(highlight=False, soft_wrap=True)
_current_model = ""
_tool_group_open = False
_tool_group_calls = 0

# ── Session counters ───────────────────────────────────────────────────────
_session_turns = 0
_session_tokens = 0

# ══════════════════════════════════════════════════════════════════════════════
#  DESIGN SYSTEM — single source of truth for colors, icons, spacing
# ══════════════════════════════════════════════════════════════════════════════

# ── Palette ────────────────────────────────────────────────────────────────
_P = "bright_cyan"  # primary
_S = "bright_magenta"  # secondary / accent
_OK = "bright_green"  # success
_WRN = "bright_yellow"  # warning
_ERR = "bright_red"  # error
_DIM = "dim"  # muted text
_BDR = "dim cyan"  # borders
_HDR = "bold bright_white"  # headings
_TOOL_C = "bold magenta"  # tool name

# ── Icons ──────────────────────────────────────────────────────────────────
_ICONS = {
    "ok": "✓",
    "err": "✗",
    "warn": "⚠",
    "info": "ℹ",
    "bot": "◆",
    "user": "❯",
    "tool": "⚙",
    "step": "┃",
    "branch": "",
    "timer": "⏱",
    "think": "🧠",
    "spark": "✦",
}


# ══════════════════════════════════════════════════════════════════════════════
#  UTILITIES
# ══════════════════════════════════════════════════════════════════════════════


def _tw() -> int:
    """Terminal width, clamped ≥ 60."""
    try:
        return max(console.size.width, 60)
    except Exception:
        return 100


def _fit(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max(max_len - 1, 0)] + "…" if max_len > 1 else text[:max_len]


def _app_version() -> str:
    try:
        from importlib.metadata import version

        return version("free-claude")
    except Exception:
        return "dev"


def _short_model_name(model: str) -> str:
    m = (model or "").lower()
    if not m:
        return "unknown"
    import re

    ver_match = re.search(r"-(\d)-(\d+)(?:-\d+)?$", m)
    ver = f"{ver_match.group(1)}.{ver_match.group(2)}" if ver_match else ""
    for name in ("opus", "sonnet", "haiku"):
        if name in m:
            return f"{name}{ver}" if ver else name
    return m[len("claude-") :] if m.startswith("claude-") else m


def _git_branch(cwd: Optional[str] = None) -> Optional[str]:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=cwd or os.getcwd(),
            capture_output=True,
            text=True,
            timeout=2.0,
            check=False,
        )
    except Exception:
        return None
    branch = (proc.stdout or "").strip()
    return branch if proc.returncode == 0 and branch and branch != "HEAD" else None


def _workspace_label(path: Optional[str] = None) -> str:
    path = path or os.getcwd()
    home = os.path.expanduser("~")
    display = path.replace(home, "~") if path.startswith(home) else path
    return _fit(display, max(28, _tw() - 32))


def _short_workspace(path: Optional[str] = None) -> str:
    return os.path.basename(path or os.getcwd()) or os.getcwd()


def _plugin_summary(plugin_names: Sequence[str], max_items: int = 3) -> str:
    names = [n for n in plugin_names if n]
    if not names:
        return "none"
    if len(names) <= max_items:
        return ", ".join(names)
    return ", ".join(names[:max_items]) + f" +{len(names) - max_items}"


def _format_tokens(n: int) -> str:
    if n < 1000:
        return str(n)
    if n < 10000:
        return f"{n / 1000:.1f}k"
    return f"{n // 1000}k"


def _summary_lines(text: str, max_lines: int = None, max_width: Optional[int] = None) -> List[str]:
    if max_lines is None:
        from .app_config import config as app_config

        max_lines = app_config.tool_result_lines
    if not text:
        return ["(no output)"]
    max_width = max_width or max(40, _tw() - 16)
    raw = [ln.rstrip() for ln in text.splitlines()]
    lines = [ln for ln in raw if ln.strip()] or ["(blank output)"]
    preview = [_fit(ln, max_width) for ln in lines[:max_lines]]
    remaining = len(lines) - len(preview)
    if remaining > 0:
        preview.append(f"… {remaining} more line{'s' if remaining != 1 else ''}")
    return preview


# ══════════════════════════════════════════════════════════════════════════════
#  STATEFUL API
# ══════════════════════════════════════════════════════════════════════════════


def set_current_model(model: str) -> None:
    global _current_model
    _current_model = model or ""


def update_session_stats(turns: int = 0, tokens: int = 0) -> None:
    global _session_turns, _session_tokens
    if turns:
        _session_turns = turns
    if tokens:
        _session_tokens = tokens


def increment_turn() -> None:
    global _session_turns
    _session_turns += 1


def add_tokens(n: int) -> None:
    global _session_tokens
    _session_tokens += n


def render_markdown(text: str) -> None:
    if text:
        console.print(Markdown(text))


# ══════════════════════════════════════════════════════════════════════════════
#  BANNER
# ══════════════════════════════════════════════════════════════════════════════

_LOGO_LINES = [
    "  ╭─────────────────────────────────────╮",
    "  │  ◈  f r e e - c l a u d e          │",
    "  ╰─────────────────────────────────────╯",
]

_LOGO_GRADIENT = ["bright_cyan", "cyan", "dim cyan"]


def print_banner(
    model: str,
    n_builtin: int,
    n_mcp: int,
    plugin_names: Optional[Iterable[str]] = None,
    thinking_budget: int = 0,
) -> None:
    from .app_config import config as app_config

    style = app_config.banner
    if style == "off":
        return

    plugin_names = list(plugin_names or [])
    if style == "compact":
        _print_compact_banner(model, n_builtin, n_mcp, plugin_names, thinking_budget)
    else:
        _print_full_banner(model, n_builtin, n_mcp, plugin_names, thinking_budget)


def _print_compact_banner(
    model: str,
    n_builtin: int,
    n_mcp: int,
    plugin_names: List[str],
    thinking_budget: int,
) -> None:
    console.print()
    # Logo
    for i, line in enumerate(_LOGO_LINES):
        console.print(Text(line, style=_LOGO_GRADIENT[i % len(_LOGO_GRADIENT)]))

    ver = _app_version()
    model_short = _short_model_name(model)
    total_tools = n_builtin + n_mcp

    # Info line
    info = Text()
    info.append("  ", style=_DIM)
    info.append(f"v{ver}", style=_DIM)
    info.append("  │  ", style="dim cyan")
    info.append(model_short, style="bold green")
    info.append("  │  ", style="dim cyan")
    info.append(f"{total_tools} tools", style="white")
    if plugin_names:
        info.append("  │  ", style="dim cyan")
        info.append(_plugin_summary(plugin_names), style="cyan")
    if thinking_budget:
        info.append("  │  ", style="dim cyan")
        info.append(f"🧠 {thinking_budget:,}", style="magenta")
    console.print(info)

    # Workspace line
    ws = Text()
    ws.append("  ", style=_DIM)
    ws.append("📂 ", style=_DIM)
    ws.append(_workspace_label(), style="yellow")
    branch = _git_branch()
    if branch:
        ws.append(f"  ({branch})", style="dim yellow")
    console.print(ws)

    # Quick help
    q = Text()
    q.append("  ", style=_DIM)
    q.append("/help", style=_P)
    q.append("  ", style=_DIM)
    q.append("/model", style=_P)
    q.append("  ", style=_DIM)
    q.append("/tools", style=_P)
    q.append("  ", style=_DIM)
    q.append("/dashboard", style=_P)
    q.append("  ", style=_DIM)
    q.append("Tab", style="yellow")
    q.append("=autocomplete", style=_DIM)
    console.print(q)
    console.print()


def _print_full_banner(
    model: str,
    n_builtin: int,
    n_mcp: int,
    plugin_names: List[str],
    thinking_budget: int,
) -> None:
    console.print()
    # Logo
    for i, line in enumerate(_LOGO_LINES):
        console.print(Text(line, style=_LOGO_GRADIENT[i % len(_LOGO_GRADIENT)]))

    ver = _app_version()
    think_value = f"on ({thinking_budget:,})" if thinking_budget else "off"

    rows = [
        ("🤖", "Model", _fit(model, 36), "green"),
        ("🔧", "Tools", f"{n_builtin} built-in  ·  {n_mcp} MCP", "white"),
        ("🔌", "Plugins", _plugin_summary(plugin_names), "cyan" if plugin_names else _DIM),
        ("🧠", "Thinking", think_value, "magenta" if thinking_budget else _DIM),
        ("📂", "Workspace", _workspace_label(), "yellow"),
    ]
    branch = _git_branch()
    if branch:
        rows.append(("", "Branch", branch, "dim yellow"))

    lines = []
    for icon, label, val, style in rows:
        t = Text()
        t.append(f"  {icon} " if icon else "     ", style=_DIM)
        t.append(f"{label:<10}", style="bold white")
        t.append(val, style=style)
        lines.append(t)

    console.print(
        Panel(
            Group(*lines),
            title=f"[{_P}]free-claude[/{_P}] [dim]v{ver}[/dim]",
            border_style=_BDR,
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )

    q = Text()
    q.append("  /help", style=_P)
    q.append("  ·  ", style=_DIM)
    q.append("/tools", style=_P)
    q.append("  ·  ", style=_DIM)
    q.append("/dashboard", style=_P)
    q.append("  ·  ", style=_DIM)
    q.append("\\", style="yellow")
    q.append(" multiline", style=_DIM)
    q.append("  ·  ", style=_DIM)
    q.append("Tab", style="yellow")
    q.append(" autocomplete", style=_DIM)
    console.print(q)
    console.print()


# ══════════════════════════════════════════════════════════════════════════════
#  ASSISTANT RESPONSE
# ══════════════════════════════════════════════════════════════════════════════


def print_assistant_header() -> None:
    console.print()
    t = Text()
    t.append(f"  {_ICONS['bot']} ", style=_P)
    t.append("Assistant", style=f"bold {_P}")
    console.print(t)


def print_response_end() -> None:
    console.print()


# ══════════════════════════════════════════════════════════════════════════════
#  TOOL STEP DISPLAY — tree-style with timing badges
# ══════════════════════════════════════════════════════════════════════════════


def print_step(step_num: int, max_steps: int) -> None:
    global _tool_group_open, _tool_group_calls
    _tool_group_open = True
    _tool_group_calls = 0
    console.print()

    if step_num >= max_steps - 5:
        label = f"Step {step_num}/{max_steps}"
    else:
        label = f"Step {step_num}"

    t = Text()
    t.append("  ┌─", style=_BDR)
    t.append(f" {label} ", style=f"bold {_P}")
    t.append("─" * max(0, _tw() - len(label) - 8), style=_BDR)
    console.print(t)


def print_step_end() -> None:
    global _tool_group_open, _tool_group_calls
    if _tool_group_open:
        t = Text()
        t.append("  └", style=_BDR)
        t.append("─" * max(10, _tw() - 5), style=_BDR)
        console.print(t)
    _tool_group_open = False
    _tool_group_calls = 0


def print_tool_call(name: str, detail: str = "", elapsed_ms: float = 0) -> None:
    global _tool_group_calls
    _tool_group_calls += 1

    t = Text()
    t.append("  ├ ", style=_BDR)
    t.append(f"{_ICONS['tool']} ", style=_DIM)
    t.append(name, style=_TOOL_C)

    if detail:
        compact = " ".join(detail.split())
        t.append(" → ", style=_DIM)
        t.append(_fit(compact, max(20, _tw() - 40)), style="white")

    if elapsed_ms > 0:
        if elapsed_ms >= 1000:
            badge = f" {elapsed_ms / 1000:.1f}s "
        else:
            badge = f" {int(elapsed_ms)}ms "
        t.append(f"  [{badge}]", style="dim yellow")

    console.print(t)


def print_tool_result(result: str) -> None:
    for idx, line in enumerate(_summary_lines(result)):
        t = Text()
        if idx == 0:
            t.append("  │  ↳ ", style=_BDR)
            t.append(line, style="white")
        else:
            t.append("  │    ", style=_BDR)
            t.append(line, style=_DIM)
        console.print(t)


# ══════════════════════════════════════════════════════════════════════════════
#  ADAPTIVE THINKING STATE
# ══════════════════════════════════════════════════════════════════════════════

_adaptive_enabled: bool = True


def set_adaptive_status(enabled: bool) -> None:
    global _adaptive_enabled
    _adaptive_enabled = enabled


# ══════════════════════════════════════════════════════════════════════════════
#  USER PROMPT
# ══════════════════════════════════════════════════════════════════════════════

_pt_session = None


def _get_prompt_session():
    global _pt_session
    if _pt_session is not None:
        return _pt_session
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.key_binding import KeyBindings

        try:
            from prompt_toolkit.history import FileHistory

            from .compat import DATA_DIR

            history_path = DATA_DIR / "input_history"
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            history = FileHistory(str(history_path))
        except Exception:
            from prompt_toolkit.history import InMemoryHistory

            history = InMemoryHistory()

        bindings = KeyBindings()

        @bindings.add("escape", "enter")
        def _insert_newline(event):
            event.current_buffer.insert_text("\n")

        _pt_session = PromptSession(
            history=history,
            key_bindings=bindings,
            multiline=False,
        )
    except Exception:
        _pt_session = None
    return _pt_session


def print_user_prompt(cwd: str) -> str:
    from .app_config import config as app_config

    cwd = cwd or os.path.basename(os.getcwd()) or os.getcwd()
    branch = _git_branch()
    model_short = _short_model_name(_current_model)

    if app_config.prompt_style == "classic":
        return _classic_prompt(cwd, branch, model_short)
    return _compact_prompt(cwd, branch, model_short)


def _compact_prompt(cwd: str, branch: Optional[str], model_short: str) -> str:
    """Clean single-line prompt:  fclaude dir (branch) model [stats] ❯"""
    parts = Text()
    parts.append("fclaude", style=f"bold {_P}")
    parts.append(" ", style=_DIM)
    parts.append(cwd, style="green")
    if branch:
        parts.append(f" ({branch})", style="dim yellow")
    if model_short:
        parts.append(f" {model_short}", style="magenta")
    if _session_turns > 0 or _session_tokens > 0:
        stats = []
        if _session_turns > 0:
            stats.append(f"{_session_turns}↻")
        if _session_tokens > 0:
            stats.append(f"{_format_tokens(_session_tokens)}⇅")
        parts.append(f" [{' '.join(stats)}]", style=_DIM)

    console.print(parts)

    pt = _get_prompt_session()
    if pt is not None:
        try:
            text = pt.prompt(f"{_ICONS['user']} ")
            return _process_backslash_continuation(text)
        except KeyboardInterrupt:
            raise
        except EOFError:
            raise
        except Exception:
            pass

    return _fallback_input(f"{_ICONS['user']} ")


def _classic_prompt(cwd: str, branch: Optional[str], model_short: str) -> str:
    top = Text()
    top.append("  ┌ ", style=_BDR)
    top.append(cwd, style="bold green")
    if branch:
        top.append("  ", style=_DIM)
        top.append(branch, style="yellow")
    if model_short:
        top.append("  ", style=_DIM)
        top.append(model_short, style="magenta")
    if _adaptive_enabled:
        top.append("  ", style=_DIM)
        top.append("🧠", style="dim magenta")
    if _session_turns > 0 or _session_tokens > 0:
        stats = []
        if _session_turns > 0:
            stats.append(f"{_session_turns}↻")
        if _session_tokens > 0:
            stats.append(f"{_format_tokens(_session_tokens)}⇅")
        top.append(f"  {' '.join(stats)}", style=_DIM)
    console.print(top)

    pt = _get_prompt_session()
    if pt is not None:
        try:
            text = pt.prompt("  └ ❯ ")
            return _process_backslash_continuation(text)
        except KeyboardInterrupt:
            raise
        except EOFError:
            raise
        except Exception:
            pass

    return _fallback_input("  └ ❯ ")


def _process_backslash_continuation(text: str) -> str:
    if "\\" not in text:
        return text
    lines = text.split("\n")
    result_lines = []
    for line in lines:
        if line.endswith("\\"):
            result_lines.append(line[:-1])
        else:
            result_lines.append(line)
            break
    if len(result_lines) < len(lines):
        result_lines.extend(lines[len(result_lines) :])
    return "\n".join(result_lines)


def _fallback_input(prompt_str: str) -> str:
    first_line = input(prompt_str)
    if not first_line.endswith("\\"):
        return first_line
    lines = [first_line[:-1]]
    while True:
        try:
            next_line = input("  … ")
        except (KeyboardInterrupt, EOFError):
            break
        if next_line.endswith("\\"):
            lines.append(next_line[:-1])
        else:
            lines.append(next_line)
            break
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  NOTIFICATIONS — consistent badge-style
# ══════════════════════════════════════════════════════════════════════════════


def _group_prefix() -> str:
    return "  │  " if _tool_group_open else "  "


def print_goodbye() -> None:
    console.print()
    t = Text()
    t.append("  👋 ", style="bold")
    t.append("See you next time!", style=f"bold {_P}")
    console.print(t)
    console.print()


def print_success(message: str) -> None:
    console.print(f"{_group_prefix()}[{_OK}]{_ICONS['ok']}[/{_OK}] {message}")


def print_info(message: str) -> None:
    console.print(f"{_group_prefix()}[{_P}]{_ICONS['info']}[/{_P}] {message}")


def print_warning(message: str) -> None:
    console.print(f"{_group_prefix()}[{_WRN}]{_ICONS['warn']}[/{_WRN}] {message}")


def print_error(message: str) -> None:
    console.print(f"{_group_prefix()}[{_ERR}]{_ICONS['err']}[/{_ERR}] {message}")


def print_interrupted() -> None:
    console.print()
    console.print(
        f"  [{_WRN}]⚠ Interrupted[/{_WRN}] — "
        f"type [bold {_P}]'continue'[/bold {_P}] to resume or start a new query."
    )


def print_summarizing() -> None:
    console.print(f"  [{_P}]📝 Summarizing final answer...[/{_P}]")


def print_plan(plan_text: str) -> None:
    console.print(
        Panel.fit(
            plan_text,
            title=f"[bold {_P}]Plan[/bold {_P}]",
            border_style=_BDR,
            box=box.ROUNDED,
        )
    )


def print_thinking_status(budget: int) -> None:
    console.print(f"  [{_S}]🧠 Extended thinking[/{_S}] — budget: [bold]{budget:,}[/bold] tokens")


# ══════════════════════════════════════════════════════════════════════════════
#  API ERROR — actionable panels
# ══════════════════════════════════════════════════════════════════════════════


def print_api_error(status_code: int, raw_body: str = "") -> None:
    if status_code in (401, 429, 500, 502, 503):
        _panels = {
            401: (
                "🔐 Authentication Failed",
                "Token may be expired or invalid.",
                [
                    ("Fix: ", _DIM),
                    ("fclaude token set <token>", "cyan"),
                    ("  or  ", _DIM),
                    ("fclaude token check", "cyan"),
                ],
            ),
            429: (
                "⏳ Rate Limited",
                "Too many requests — slow down.",
                [("Wait a moment, or switch model: ", _DIM), ("/model sonnet4", "cyan")],
            ),
            500: (
                "❌ Server Error (500)",
                "API is temporarily unavailable.",
                [("Try again in a few seconds, or ", _DIM), ("/model haiku", "cyan")],
            ),
            502: (
                "❌ Server Error (502)",
                "API gateway issue.",
                [("Try again in a few seconds.", _DIM)],
            ),
            503: (
                "❌ Server Error (503)",
                "API is overloaded.",
                [("Try again in a few seconds, or ", _DIM), ("/model haiku", "cyan")],
            ),
        }
        title, desc, fix_parts = _panels[status_code]
        body = Text()
        body.append(f"  {desc}\n\n", style="white")
        body.append("  ")
        body.append_text(Text.assemble(*fix_parts))
        console.print(
            Panel(
                body,
                title=f"[{_ERR}]{title}[/{_ERR}]",
                border_style=_ERR,
                box=box.ROUNDED,
                padding=(0, 1),
            )
        )
    elif status_code == 400:
        msg = raw_body[:200]
        try:
            import json

            data = json.loads(raw_body)
            msg = data.get("error", {}).get("message", raw_body[:200])
        except Exception:
            pass
        console.print(f"  [{_ERR}]❌ Bad request (400):[/{_ERR}] {msg}")
    else:
        console.print(f"  [{_ERR}]❌ API error ({status_code})[/{_ERR}]")
        if raw_body:
            console.print(f"  [{_DIM}]{raw_body[:200]}[/{_DIM}]")


# ══════════════════════════════════════════════════════════════════════════════
#  MODELS / TOOLS / PLUGINS TABLES
# ══════════════════════════════════════════════════════════════════════════════


def print_models_table(models: Dict[str, str], current_model: str) -> None:
    table = Table(
        title=f"[{_HDR}]Models[/{_HDR}]",
        box=box.ROUNDED,
        header_style=f"bold {_P}",
        border_style=_BDR,
        padding=(0, 2),
        show_edge=True,
    )
    table.add_column("Key", style="yellow", no_wrap=True)
    table.add_column("Model", style="white")
    table.add_column("", style=_OK, justify="center", width=3)

    for key, model in models.items():
        marker = "●" if model == current_model or key == current_model else ""
        table.add_row(key, model, marker)

    console.print()
    console.print(table)
    console.print(
        f"  [{_DIM}]Switch: [cyan]/model opus4[/cyan] or [cyan]/model claude-opus-4-6[/cyan][/{_DIM}]"
    )
    console.print()


def print_tools_table(tools: Iterable[Dict]) -> None:
    table = Table(
        title=f"[{_HDR}]Available Tools[/{_HDR}]",
        box=box.ROUNDED,
        header_style=f"bold {_P}",
        border_style=_BDR,
        padding=(0, 1),
        show_edge=True,
        row_styles=["", "on grey7"],
    )
    table.add_column("Type", style=_P, no_wrap=True, width=9)
    table.add_column("Name", style="yellow", no_wrap=True)
    table.add_column("Description", style="white", ratio=3)

    for tool in tools:
        if isinstance(tool, dict):
            name = tool.get("name", "?")
            desc = tool.get("description", "")
        else:
            name = str(tool)
            desc = ""
        ttype = "[dim]MCP[/dim]" if name.startswith("mcp_") else "Built-in"
        # Truncate long descriptions
        desc_short = _fit(desc, max(40, _tw() - 40))
        table.add_row(ttype, name, desc_short)

    console.print()
    console.print(table)
    console.print()


def print_plugins_table(plugins: Dict[str, Dict]) -> None:
    if not plugins:
        console.print(f"  [{_WRN}]No plugins discovered[/{_WRN}]")
        return

    table = Table(
        title=f"[{_HDR}]Plugins[/{_HDR}]",
        box=box.ROUNDED,
        header_style=f"bold {_P}",
        border_style=_BDR,
        padding=(0, 1),
        show_edge=True,
    )
    table.add_column("Plugin", style="yellow", no_wrap=True)
    table.add_column("Type", style=_P, no_wrap=True, width=8)
    table.add_column("Command / URL", style="white")

    for name, cfg in sorted(plugins.items()):
        transport = cfg.get("type", "stdio")
        location = cfg.get("command") or cfg.get("url") or ""
        table.add_row(name, transport, _fit(str(location), max(24, _tw() - 42)))

    console.print()
    console.print(table)
    console.print()


# ══════════════════════════════════════════════════════════════════════════════
#  HELP — tiered card layout
# ══════════════════════════════════════════════════════════════════════════════


def _help_table(title: str, rows: Sequence[Tuple[str, str, str]]) -> Table:
    table = Table(
        title=f"[bold]{title}[/bold]",
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style=f"bold {_P}",
        border_style=_BDR,
        padding=(0, 1),
        expand=True,
    )
    table.add_column("Command", style="yellow", no_wrap=True, width=22)
    table.add_column("What it does", style="white", ratio=2)
    table.add_column("Example", style=f"dim {_P}", ratio=2)
    for cmd, desc, example in rows:
        table.add_row(cmd, desc, example)
    return table


def print_help(show_all: bool = False) -> None:
    if show_all:
        _print_full_help()
    else:
        _print_essential_help()


def _print_essential_help() -> None:
    rows = [
        ("/help all", "Show ALL commands (team, sessions, plan…)", "/help all"),
        ("/quit", "Exit the session", "/quit"),
        ("/clear", "Clear conversation history", "/clear"),
        ("/model [key]", "Show models or switch", "/model sonnet4"),
        ("/tools", "List all available tools", "/tools"),
        ("/search <q>", "Search files in project", "/search auth --glob *.py"),
        ("/save [fmt]", "Save conversation (md/json/session)", "/save session"),
        ("/dashboard", "Live TUI team dashboard", "/dashboard"),
        ("!<cmd>", "Run a shell command", "!pytest -q"),
    ]
    table = _help_table("Essential Commands", rows)

    tips = Text()
    tips.append("  Tips: ", style="bold white")
    tips.append("\\", style="yellow")
    tips.append(" multiline  ·  ", style=_DIM)
    tips.append("Tab", style="yellow")
    tips.append(" autocomplete  ·  ", style=_DIM)
    tips.append("Alt+Enter", style="yellow")
    tips.append(" newline", style=_DIM)

    console.print()
    console.print(
        Panel(
            Group(table, tips),
            title=f"[bold {_P}]Help[/bold {_P}]",
            subtitle=f"[{_DIM}]/help all → complete reference[/{_DIM}]",
            border_style=_BDR,
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )
    console.print()


def _print_full_help() -> None:
    sections = [
        (
            "💬 Core Chat",
            [
                ("/quit", "Exit the chat session", "/quit"),
                ("/clear", "Clear the current conversation", "/clear"),
                (r"(multiline)", r"End a line with \ to continue", r"write a poem\↵about the sea"),
                ("/paste", "Paste mode — end with Ctrl+D or ---", "/paste"),
                ("/model [key|name]", "Show models or switch", "/model opus4"),
                ("model [key]", "Shortcut without /", "model claude-opus-4-6"),
                ("/system [text]", "Replace system prompt", "/system Be concise"),
                ("/think [off|N]", "Extended thinking", "/think 4000"),
                ("/adaptive [on|off]", "Auto-select thinking budget", "/adaptive on"),
            ],
        ),
        (
            "🔧 Tools & Plugins",
            [
                ("/tools", "List all tools", "/tools"),
                ("/plugins", "List discoverable plugins", "/plugins"),
                ("/plugin <name>", "Load a plugin", "/plugin playwright"),
                ("/mcp <name> <cmd>", "Add custom MCP server", "/mcp local node server.js"),
            ],
        ),
        (
            "📁 Project Workflow",
            [
                ("/search <query>", "Search project files", "/search auth --glob *.py"),
                ("/index [--force]", "Index project", "/index --force"),
                ("/cd <path>", "Change directory", "/cd ~/work/my-app"),
                ("!<command>", "Run shell command", "!pytest -q"),
            ],
        ),
        (
            "🧠 Planning & Team",
            [
                ("/plan new <goal>", "Create execution plan", "/plan new ship release"),
                ("/autoplan <goal>", "AI-generated plan", "/autoplan refactor auth"),
                ("/team <task>", "Auto-delegate to specialists", "/team review and test auth.py"),
                ("/team on|off", "Enable/disable auto-delegation", "/team on"),
                ("/teammate add <role>", "Add specialist teammate", "/teammate add debugger"),
                (
                    "/teammate ask <role> <q>",
                    "Ask teammate",
                    "/teammate ask architect how to split auth?",
                ),
                (
                    "/teammate delegate",
                    "Dispatch async task",
                    "/teammate delegate debugger fix timeout",
                ),
                ("/teammate list", "Show team status", "/teammate list"),
                ("/tasks [status]", "List tasks", "/tasks active"),
                ("/dashboard [once]", "Live TUI team dashboard", "/dashboard"),
                ("/task <id>", "Task detail", "/task <id>"),
            ],
        ),
        (
            "💾 Session & Memory",
            [
                ("/save [json|session]", "Export conversation", "/save session"),
                ("/resume [id]", "Resume saved session", "/resume 20260327"),
                ("/sessions", "List saved sessions", "/sessions"),
                ("/memory set <k> <v>", "Store a note", "/memory set repo main-app"),
                ("/memory get <k>", "Recall a note", "/memory get repo"),
            ],
        ),
        (
            "📊 Diagnostics",
            [
                ("/usage", "Token usage & rate limits", "/usage"),
                ("/config", "Show all config values", "/config"),
                ("/config <k> <v>", "Change config (instant, no restart)", "/config typewriter off"),
            ],
        ),
    ]

    tables = [_help_table(title, rows) for title, rows in sections]

    roles_note = Text()
    roles_note.append("  Roles: ", style="bold white")
    roles_note.append(
        "code_reviewer  test_writer  docs_writer  debugger  refactorer  architect  security_auditor",
        style=f"dim {_P}",
    )

    console.print()
    console.print(
        Panel(
            Group(*tables, roles_note),
            title=f"[bold {_P}]Complete Command Reference[/bold {_P}]",
            border_style=_BDR,
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )
    console.print()
