"""Hook system for fclaude — PreToolUse / PostToolUse interception.

Inspired by fclaude internal's hook architecture which tracks hookCount + hookTotalMs
per tool call. Hooks can block, modify, or observe tool execution.

Usage:
    hooks = HookSystem()
    hooks.register_pre("bash", dangerous_command_hook)
    hooks.register_post("*", audit_log_hook)

    result = await hooks.run_pre(ctx)
    if not result.allowed:
        return error(result.reason)
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)

# Hook callable signature: fn(ctx) -> HookResult
HookFn = Callable[["ToolHookContext"], "HookResult"]


# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class ToolHookContext:
    """Context passed to every hook."""

    tool_name: str
    tool_input: Dict[str, Any]
    iteration: int = 0
    agent_state: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HookResult:
    """Result returned by a hook."""

    allowed: bool = True
    modified_input: Optional[Dict[str, Any]] = None  # replace input if set
    reason: Optional[str] = None  # reason for block
    duration_ms: float = 0.0


@dataclass
class PostHookContext:
    """Context passed to post-execution hooks."""

    tool_name: str
    tool_input: Dict[str, Any]
    tool_output: str
    duration_ms: float = 0.0


@dataclass
class PostHookResult:
    """Result from a post-execution hook."""

    modified_output: Optional[str] = None  # replace output if set
    duration_ms: float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Core HookSystem
# ─────────────────────────────────────────────────────────────────────────────


class HookSystem:
    """Pre/Post tool-use hook registry.

    Compatible with both sync and simple async-style (blocking) hooks.
    Tracks aggregate hookCount and hookTotalMs for display in UI (mirrors fclaude).
    """

    def __init__(self) -> None:
        self._pre: Dict[str, List[HookFn]] = {}  # tool_name → [hook]
        self._post: Dict[str, List[HookFn]] = {}
        self.hook_count: int = 0
        self.hook_total_ms: float = 0.0

    # ── Registration ────────────────────────────────────────────────────────

    def register_pre(self, tool_name: str, hook: HookFn) -> None:
        """Register a pre-execution hook.

        Args:
            tool_name: Specific tool name or '*' for all tools.
            hook:      Callable(ToolHookContext) → HookResult
        """
        self._pre.setdefault(tool_name, []).append(hook)

    def register_post(self, tool_name: str, hook: HookFn) -> None:
        """Register a post-execution hook."""
        self._post.setdefault(tool_name, []).append(hook)

    def unregister_all(self, tool_name: str) -> None:
        self._pre.pop(tool_name, None)
        self._post.pop(tool_name, None)

    # ── Execution ────────────────────────────────────────────────────────────

    def run_pre(self, ctx: ToolHookContext) -> HookResult:
        """Run all pre-execution hooks for this tool.

        Returns first blocking HookResult, or allow if all pass.
        Modifies ctx.tool_input in-place if a hook returns modified_input.
        """
        hooks = self._pre.get(ctx.tool_name, []) + self._pre.get("*", [])
        if not hooks:
            return HookResult(allowed=True)

        t0 = time.perf_counter()
        result = HookResult(allowed=True)

        for hook in hooks:
            try:
                r = hook(ctx)
                if r.modified_input is not None:
                    ctx.tool_input = r.modified_input
                    result.modified_input = r.modified_input
                if not r.allowed:
                    result = r
                    break
            except Exception as e:
                log.warning("PreToolUse hook %s raised: %s", hook.__name__, e)

        elapsed = (time.perf_counter() - t0) * 1000
        self.hook_count += len(hooks)
        self.hook_total_ms += elapsed
        result.duration_ms = elapsed
        return result

    def run_post(self, ctx: PostHookContext) -> PostHookResult:
        """Run all post-execution hooks for this tool."""
        hooks = self._post.get(ctx.tool_name, []) + self._post.get("*", [])
        if not hooks:
            return PostHookResult()

        t0 = time.perf_counter()
        result = PostHookResult()

        for hook in hooks:
            try:
                r = hook(ctx)
                if r and r.modified_output is not None:
                    ctx.tool_output = r.modified_output
                    result.modified_output = r.modified_output
            except Exception as e:
                log.warning("PostToolUse hook %s raised: %s", hook.__name__, e)

        result.duration_ms = (time.perf_counter() - t0) * 1000
        self.hook_total_ms += result.duration_ms
        return result

    def stats_line(self) -> Optional[str]:
        """Return a UI display line like fclaude: 'Ran 3 PreToolUse hooks (0.5s)'"""
        if self.hook_count == 0:
            return None
        s = self.hook_total_ms / 1000
        word = "hook" if self.hook_count == 1 else "hooks"
        return f"  ⏿  Ran {self.hook_count} PreToolUse {word} ({s:.1f}s)"

    def reset_stats(self) -> None:
        self.hook_count = 0
        self.hook_total_ms = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Built-in safety hooks
# ─────────────────────────────────────────────────────────────────────────────

# Patterns that are ALWAYS blocked regardless of user permission
_ALWAYS_BLOCK: List[str] = [
    r"rm\s+-rf\s+/\s*$",  # rm -rf /
    r"rm\s+-rf\s+/\*",  # rm -rf /*
    r":\(\)\s*\{\s*:\|:&\s*\}",  # fork bomb
    r"dd\s+if=/dev/zero\s+of=/dev/[sh]d",  # disk wipe
    r"mkfs\.\w+\s+/dev/",  # format device
    r">\s*/dev/[sh]da",  # overwrite disk
    r"shred\s+.*\s+/dev/",
]

# Patterns that require user confirmation
_CONFIRM_PATTERNS: List[str] = [
    r"rm\s+-rf",  # rm -rf anything
    r"sudo\s+",  # any sudo
    r"chmod\s+777",  # world-writable
    r"curl\s+.*\s*\|\s*(ba)?sh",  # pipe to shell
    r"wget\s+.*\s*\|\s*(ba)?sh",
    r"DROP\s+TABLE",  # SQL destructive
    r"DELETE\s+FROM\s+\w+\s*;?\s*$",  # DELETE without WHERE
]


def make_safety_hook() -> HookFn:
    """Built-in hook: block/warn on dangerous bash commands."""
    block_re = [re.compile(p, re.IGNORECASE) for p in _ALWAYS_BLOCK]
    confirm_re = [re.compile(p, re.IGNORECASE) for p in _CONFIRM_PATTERNS]

    def hook(ctx: ToolHookContext) -> HookResult:
        if ctx.tool_name != "bash":
            return HookResult(allowed=True)
        cmd = ctx.tool_input.get("command", "")

        for pat in block_re:
            if pat.search(cmd):
                return HookResult(
                    allowed=False, reason=f"🚫 Blocked dangerous command (pattern: {pat.pattern!r})"
                )

        for pat in confirm_re:
            if pat.search(cmd):
                # Log warning but allow — permission system handles confirmation
                log.warning("[SafetyHook] Potentially dangerous command: %r", cmd[:120])

        return HookResult(allowed=True)

    hook.__name__ = "safety_hook"
    return hook


def make_audit_log_hook(log_path: Optional[str] = None) -> HookFn:
    """Post-hook: append every tool call to an audit log."""
    import os

    if log_path is None:
        log_path = os.path.join(os.getcwd(), ".free-claude", "audit.log")

    def hook(ctx: PostHookContext) -> PostHookResult:
        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            line = (
                f"{time.strftime('%Y-%m-%dT%H:%M:%S')} "
                f"[{ctx.tool_name}] "
                f"input={str(ctx.tool_input)[:200]} "
                f"duration={ctx.duration_ms:.0f}ms\n"
            )
            with open(log_path, "a") as f:
                f.write(line)
        except Exception:
            pass
        return PostHookResult()

    hook.__name__ = "audit_log_hook"
    return hook


def make_perf_hook() -> HookFn:
    """Post-hook: track tool execution times."""
    times: Dict[str, List[float]] = {}

    def hook(ctx: PostHookContext) -> PostHookResult:
        times.setdefault(ctx.tool_name, []).append(ctx.duration_ms)
        return PostHookResult()

    hook.__name__ = "perf_hook"
    hook.times = times  # type: ignore
    return hook


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton
# ─────────────────────────────────────────────────────────────────────────────

_global_hooks: Optional[HookSystem] = None


def get_hooks() -> HookSystem:
    """Return the global HookSystem, creating it with defaults on first call."""
    global _global_hooks
    if _global_hooks is None:
        _global_hooks = HookSystem()
        # Install built-in safety hook by default
        _global_hooks.register_pre("bash", make_safety_hook())
        _global_hooks.register_post("*", make_audit_log_hook())
    return _global_hooks


__all__ = [
    "HookSystem",
    "HookFn",
    "ToolHookContext",
    "HookResult",
    "PostHookContext",
    "PostHookResult",
    "get_hooks",
    "make_safety_hook",
    "make_audit_log_hook",
    "make_perf_hook",
]
