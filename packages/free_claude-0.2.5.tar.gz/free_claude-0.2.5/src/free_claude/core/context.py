"""Message context management — history, trimming, usage tracking."""

from typing import Dict, List

_MAX_CONTEXT_CHARS = 650_000  # ~185k tokens, near-max of Claude's 200k window

# How many messages to protect at the start (initial context/instructions)
_KEEP_HEAD = 4

# How many messages to protect at the end (recent conversation continuity)
_KEEP_TAIL = 20

# Rough chars-per-token estimate for Claude models (conservative)
_CHARS_PER_TOKEN = 3.5

# Anthropic Vision API charges ~1,600 tokens for a typical image (up to 1568px).
# We use this fixed estimate instead of counting the massive base64 string,
# which would blow up the char budget and trigger aggressive trimming.
_IMAGE_TOKEN_ESTIMATE = 1_600
_IMAGE_CHAR_ESTIMATE = int(_IMAGE_TOKEN_ESTIMATE * _CHARS_PER_TOKEN)  # ~5,600


def _estimate_tokens(text: str) -> int:
    """Estimate token count from character count."""
    return max(1, int(len(text) / _CHARS_PER_TOKEN))


def _is_image_block(block) -> bool:
    """Return True if *block* is a Vision API image content block."""
    return isinstance(block, dict) and block.get("type") == "image"


def _is_image_placeholder(block) -> bool:
    """Return True if *block* is a text placeholder left after scrubbing."""
    return (
        isinstance(block, dict)
        and block.get("type") == "text"
        and isinstance(block.get("text"), str)
        and block["text"].startswith("[Image already processed")
    )


def _content_block_chars(block) -> int:
    """Measure a single content block, treating images as a fixed estimate.

    This is the key fix: instead of ``len(str(image_dict))`` which includes
    the full base64 payload (~1.4 M chars for a 1 MB image), we return a
    small fixed value that approximates what Anthropic actually charges.
    """
    if _is_image_block(block):
        return _IMAGE_CHAR_ESTIMATE
    if _is_image_placeholder(block):
        return len(block.get("text", ""))
    if isinstance(block, dict):
        # Handle tool_result blocks that nest their own "content" list
        inner = block.get("content")
        if isinstance(inner, list):
            return sum(_content_block_chars(item) for item in inner)
        # Normal dict — use text field if present, else str() representation
        text = block.get("text") or block.get("content") or ""
        return len(str(text))
    return len(str(block))


class ContextManager:
    """Manages conversation history, context trimming, and token usage tracking."""

    def __init__(self):
        self.messages: List[Dict] = []
        self._total_input_tokens: int = 0
        self._total_output_tokens: int = 0
        self._total_requests: int = 0

    # ── Message history ────────────────────────────────────────────────

    def add_user(self, content) -> None:
        self.messages.append({"role": "user", "content": content})

    def add_assistant(self, content) -> None:
        self.messages.append({"role": "assistant", "content": content})

    def pop_last(self) -> None:
        if self.messages:
            self.messages.pop()

    def clear(self) -> None:
        self.messages.clear()

    def get(self) -> List[Dict]:
        """Return messages, trimmed to fit context window."""
        return self._trim(list(self.messages))

    # ── Image scrubbing ────────────────────────────────────────────────

    def scrub_images(self, keep_last: int = 0) -> int:
        """Replace base64 image data with lightweight text placeholders.

        After the API has already *seen* an image (i.e. the response that
        follows the tool_result has been received), the raw pixel data is no
        longer needed — Claude will not re-examine it.  Replacing it with a
        placeholder frees hundreds of KB per image from the context budget.

        Args:
            keep_last: Number of most-recent user messages whose images
                       should be kept intact (so the *current* API call can
                       still see them).  0 = scrub everything that is safe.

        Returns:
            Number of image blocks that were replaced.
        """
        scrubbed = 0

        # Identify the index boundary: messages before this are safe to scrub
        # We walk backwards to find the N-th user message from the end.
        user_indices = [i for i, m in enumerate(self.messages) if m.get("role") == "user"]
        if keep_last > 0 and user_indices:
            # Protect the last `keep_last` user messages
            cutoff = user_indices[-keep_last] if keep_last <= len(user_indices) else 0
        else:
            cutoff = len(self.messages)  # scrub all

        for idx in range(cutoff):
            msg = self.messages[idx]
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            for i, block in enumerate(content):
                # Direct image block at top level
                if _is_image_block(block):
                    fname = _extract_image_filename(block)
                    content[i] = _make_placeholder(fname)
                    scrubbed += 1
                    continue
                # Nested inside a tool_result
                if isinstance(block, dict) and isinstance(block.get("content"), list):
                    inner = block["content"]
                    for j, item in enumerate(inner):
                        if _is_image_block(item):
                            fname = _extract_image_filename(item, inner)
                            inner[j] = _make_placeholder(fname)
                            scrubbed += 1
        return scrubbed

    # ── Context trimming ───────────────────────────────────────────────

    def _content_chars(self, msg: Dict) -> int:
        """Measure content size of a single message.

        Image blocks are counted as a fixed estimate (~5,600 chars ≈ 1,600
        tokens) instead of the actual base64 length, which prevents a single
        image from exceeding the entire context budget.
        """
        content = msg.get("content", "")
        if isinstance(content, list):
            return sum(_content_block_chars(c) for c in content)
        return len(str(content))

    def _total_chars(self, messages: List[Dict]) -> int:
        return sum(self._content_chars(m) for m in messages)

    def estimated_tokens(self, messages: List[Dict] = None) -> int:
        """Estimate total token count for messages (or current history)."""
        msgs = messages if messages is not None else self.messages
        total_chars = sum(self._content_chars(m) for m in msgs)
        return max(1, int(total_chars / _CHARS_PER_TOKEN))

    def _trim(self, messages: List[Dict]) -> List[Dict]:
        """Drop oldest MIDDLE messages until under budget.

        Strategy: protect both ends of the conversation —
          - Keep the first _KEEP_HEAD messages (initial context, user's
            original request, early instructions — critical for continuity)
          - Keep the last _KEEP_TAIL messages (recent actions, tool results)
          - Drop from the middle outward (oldest non-protected messages first)

        This avoids the old bug where trimming from index 1 destroyed
        the user's original instructions and early important context.
        """
        if self._total_chars(messages) <= _MAX_CONTEXT_CHARS:
            return messages

        n = len(messages)
        keep_head = min(_KEEP_HEAD, n // 2)
        keep_tail = min(_KEEP_TAIL, n - keep_head)
        min_len = keep_head + keep_tail

        # Build: head + middle + tail
        head = messages[:keep_head]
        tail = messages[n - keep_tail :] if keep_tail > 0 else []
        middle = messages[keep_head : n - keep_tail] if n > min_len else []

        # Drop from middle (oldest first) until under budget
        while middle and self._total_chars(head + middle + tail) > _MAX_CONTEXT_CHARS:
            middle.pop(0)

        # If still over budget after dropping all middle, trim from head (except first)
        result = head + middle + tail
        while len(result) > 2 and self._total_chars(result) > _MAX_CONTEXT_CHARS:
            # Remove the second element (keep index 0 = very first message)
            result.pop(1)

        return result

    def needs_trim(self) -> bool:
        return self._total_chars(self.messages) > _MAX_CONTEXT_CHARS

    # ── Usage tracking ─────────────────────────────────────────────────

    def track_usage(self, usage: dict) -> None:
        self._total_input_tokens += usage.get("input_tokens", 0)
        self._total_output_tokens += usage.get("output_tokens", 0)
        self._total_requests += 1

    @property
    def total_tokens(self) -> int:
        return self._total_input_tokens + self._total_output_tokens

    def usage_summary(self) -> Dict:
        return {
            "requests": self._total_requests,
            "input_tokens": self._total_input_tokens,
            "output_tokens": self._total_output_tokens,
            "total_tokens": self.total_tokens,
        }

    def context_window_info(self) -> Dict:
        """Return detailed context window usage information."""
        current_chars = self._total_chars(self.messages)
        max_chars = _MAX_CONTEXT_CHARS
        current_tokens = self.estimated_tokens()
        max_tokens = int(max_chars / _CHARS_PER_TOKEN)
        pct = (current_chars / max_chars * 100) if max_chars > 0 else 0
        msg_count = len(self.messages)
        # Determine status
        if pct >= 90:
            status = "🔴 CRITICAL"
        elif pct >= 69:
            status = "🟠 HIGH"
        elif pct >= 45:
            status = "🟡 MODERATE"
        else:
            status = "🟢 OK"
        return {
            "current_chars": current_chars,
            "max_chars": max_chars,
            "current_tokens": current_tokens,
            "max_tokens": max_tokens,
            "percent_used": round(pct, 1),
            "message_count": msg_count,
            "status": status,
            "summarize_at_chars": 450_000,
            "summarize_at_pct": round(450_000 / max_chars * 100, 1),
            "trim_at_chars": max_chars,
        }


# ── Module-level helpers (used by scrub_images) ───────────────────────────


def _extract_image_filename(image_block: dict, siblings: list = None) -> str:
    """Best-effort extraction of the original filename from nearby context."""
    # Try to find filename from a sibling text block like "Image file: photo.png"
    if siblings:
        for sib in siblings:
            if isinstance(sib, dict) and sib.get("type") == "text":
                text = sib.get("text", "")
                if "Image file:" in text:
                    # "Image file: photo.png\n..."
                    line = text.split("\n")[0]
                    return line.replace("Image file:", "").strip()
    # Fallback — try media_type
    source = image_block.get("source", {})
    mime = source.get("media_type", "image/unknown")
    ext = mime.split("/")[-1]
    return f"image.{ext}"


def _make_placeholder(filename: str) -> dict:
    """Create a lightweight text block to replace a scrubbed image."""
    return {
        "type": "text",
        "text": (
            f"[Image already processed by Vision API: {filename}] "
            f"(base64 data removed from context to save tokens — "
            f"refer to the assistant's earlier analysis of this image)"
        ),
    }


__all__ = ["ContextManager"]
