"""MCP (Model Context Protocol) client for free-claude.
Supports stdio, SSE, and HTTP transport types.
Also supports auto-discovery from fclaude plugin marketplace.
"""

import json
import logging
import os
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

from .compat import IS_WINDOWS

_log = logging.getLogger(__name__)

# ── Plugin discovery locations (in priority order) ────────────────────────

# 1. Bundled plugins shipped with the package (always available, no fclaude needed)
_BUNDLED_PLUGINS_FILE = Path(__file__).parent / "plugins" / "builtin_plugins.json"

# 2. User-defined plugins in ~/.config/free-claude/plugins/ (custom additions)
_USER_PLUGINS_DIR = Path(
    os.environ.get("FREE_CLAUDE_PLUGINS_DIR", Path.home() / ".config" / "free-claude" / "plugins")
)

# 3. fclaude marketplace (only present if fclaude is installed)
_MARKETPLACE_PLUGINS_DIR = Path(
    os.environ.get(
        "FREE_CLAUDE_MARKETPLACE_PLUGINS_DIR",
        Path.home()
        / ".fclaude"
        / "plugins"
        / "marketplaces"
        / "claude-plugins-official"
        / "external_plugins",
    )
)

# Legacy alias kept for backwards compat
MARKETPLACE_PLUGINS_DIR = str(_MARKETPLACE_PLUGINS_DIR)


def _load_plugins_from_dir(plugins_dir: Path) -> dict:
    """Load plugins from a directory of per-plugin subdirs, each with .mcp.json."""
    plugins = {}
    if not plugins_dir.is_dir():
        return plugins
    for entry in plugins_dir.iterdir():
        if not entry.is_dir():
            continue
        mcp_file = entry / ".mcp.json"
        if not mcp_file.exists():
            continue
        try:
            data = json.loads(mcp_file.read_text())
            # Normalize: some files have top-level name, some have mcpServers wrapper
            if "mcpServers" in data:
                data = data["mcpServers"]
            for name, config in data.items():
                plugins[name] = config
        except Exception:
            pass
    return plugins


def _load_user_plugins() -> dict:
    """Load user-defined plugins from ~/.config/free-claude/plugins/*.json."""
    plugins = {}
    if not _USER_PLUGINS_DIR.is_dir():
        return plugins
    for f in _USER_PLUGINS_DIR.glob("*.json"):
        try:
            data = json.loads(f.read_text())
            if "mcpServers" in data:
                data = data["mcpServers"]
            for name, config in data.items():
                plugins[name] = config
        except Exception:
            pass
    return plugins


def discover_plugins() -> dict:
    """
    Discover available MCP plugins from all known locations:
    1. Bundled plugins shipped with free-claude (always available)
    2. User-defined plugins in ~/.config/free-claude/plugins/
    3. fclaude marketplace (if fclaude is installed)

    Later sources override earlier ones (user config wins over bundled).
    Returns dict: {name: {type, url/command, args, headers, ...}}
    """
    plugins = {}

    # 1. Bundled plugins (always available, no fclaude needed)
    if _BUNDLED_PLUGINS_FILE.exists():
        try:
            data = json.loads(_BUNDLED_PLUGINS_FILE.read_text())
            plugins.update(data)
        except Exception:
            pass

    # 2. User-defined plugins (override bundled)
    plugins.update(_load_user_plugins())

    # 3. fclaude marketplace (override all — most specific)
    plugins.update(_load_plugins_from_dir(_MARKETPLACE_PLUGINS_DIR))

    return plugins


def list_plugins() -> None:
    """Print available MCP plugins from all sources."""
    plugins = discover_plugins()
    if not plugins:
        print("  No MCP plugins found")
        print("  💡 Add custom plugins to: ~/.config/free-claude/plugins/")
        return

    # Figure out which come from which source
    marketplace = set(_load_plugins_from_dir(_MARKETPLACE_PLUGINS_DIR).keys())
    user = set(_load_user_plugins().keys())

    print(f"  📦 {len(plugins)} MCP plugins available:")
    for name, cfg in sorted(plugins.items()):
        transport = cfg.get("type", "stdio")
        desc = cfg.get("description", "")
        needs_auth = "headers" in cfg or "oauth" in cfg
        auth_note = " 🔑" if needs_auth else ""

        # Source tag
        if name in marketplace:
            src = "[marketplace]"
        elif name in user:
            src = "[user]"
        else:
            src = "[builtin]"

        if transport == "stdio":
            cmd = cfg.get("command", "") + " " + " ".join(cfg.get("args", []))
            detail = cmd[:40]
        else:
            detail = cfg.get("url", "")[:40]

        desc_str = f" — {desc}" if desc else ""
        print(f"    • {name:<20} {src:<10} [{transport}]{auth_note}  {detail}{desc_str}")

    print("\n  💡 Add custom plugins to: ~/.config/free-claude/plugins/<name>.json")


def create_mcp_client(name: str, config: dict, env: dict = None) -> "MCPClient":
    """Factory: create correct MCPClient based on transport type."""
    from .compat import resolve_command

    transport = config.get("type", "stdio")
    if transport == "stdio":
        cmd = [resolve_command(config["command"])] + config.get("args", [])
        return StdioMCPClient(name, cmd, env=env)
    elif transport in ("http", "sse"):
        url = config["url"]
        headers = config.get("headers", {})
        # Resolve env vars in headers (e.g. ${GITHUB_PERSONAL_ACCESS_TOKEN})
        # BUG4 FIX: use regex instead of str.strip() which only strips chars not substrings
        import re as _re

        def _resolve_header(v: str) -> str:
            def _replace(m):
                var = m.group(1)
                return os.environ.get(var, "") or (env.get(var, "") if env else "")

            return _re.sub(r"\$\{(\w+)\}", _replace, v)

        resolved_headers = {k: (_resolve_header(v) if "${" in v else v) for k, v in headers.items()}
        return HttpMCPClient(name, url, headers=resolved_headers, transport=transport)
    else:
        raise ValueError(f"Unknown MCP transport: {transport}")


class MCPClient:
    """Base MCP client."""

    def __init__(self, name: str):
        self.name = name
        self.tools: list = []

    def start(self) -> bool:
        raise NotImplementedError

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        raise NotImplementedError

    def stop(self):
        pass

    def get_tool_definitions(self) -> list:
        result = []
        for t in self.tools:
            result.append(
                {
                    "name": f"mcp_{self.name}_{t['name']}",
                    "description": f"[MCP:{self.name}] {t.get('description', '')}",
                    "input_schema": t.get("inputSchema", {"type": "object", "properties": {}}),
                }
            )
        return result


class StdioMCPClient(MCPClient):
    """MCP client via stdio transport (JSON-RPC 2.0).

    Handles slow-starting servers (e.g. Serena) that need a warm-up period
    before they begin reading stdin. Uses a readiness-probe strategy:
    send initialize, and retry if the server discards buffered data.
    """

    # ── Tunables ───────────────────────────────────────────────────────
    _WARMUP_TIMEOUT_SECS = 30  # max time to wait for server readiness
    _INIT_RECV_TIMEOUT_SECS = 8  # timeout per initialize recv attempt
    _INIT_MAX_RETRIES = 3  # how many times to re-send initialize
    _INIT_RETRY_DELAY_SECS = 2.0  # pause before each retry
    _TOOLS_RECV_TIMEOUT_SECS = 15  # timeout for tools/list response
    _TOOL_TIMEOUT_SECS = 300  # timeout for a single tool call
    _MAX_RESULT_CHARS = 150_000  # max chars per MCP tool result (~4k tokens)

    def __init__(self, name: str, command: list, env: dict = None):
        super().__init__(name)
        self.command = command
        self.env = env
        self.process = None
        self._msg_id = 0
        self._lock = threading.Lock()

    def _next_id(self) -> int:
        with self._lock:
            self._msg_id += 1
            return self._msg_id

    def start(self, verbose: bool = True) -> bool:
        """Start the MCP server process and perform handshake.

        Strategy for slow-starting servers (Serena, etc.):
        Some MCP servers need several seconds to warm up (loading config,
        building indexes, starting dashboards) before they begin reading
        stdin. If we send the `initialize` message during that warm-up
        period, the server may discard the buffered data when it finally
        starts reading — causing our `_recv()` to time out.

        Fix: We use a retry loop. If the first `initialize` times out,
        we assume the server just finished warming up (and discarded our
        buffered message), so we re-send `initialize` on a now-ready stdin.
        This typically succeeds on the 1st or 2nd retry.
        """
        try:
            proc_env = os.environ.copy()
            if self.env:
                proc_env.update(self.env)
            # On Windows, shell=True is needed to execute .cmd/.bat files
            # (e.g. npx.cmd). On Unix this is not needed and left as False.
            self.process = subprocess.Popen(
                self.command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                env=proc_env,
                shell=IS_WINDOWS,
            )

            # ── Initialize with retry (handles slow-starting servers) ──
            init_response = self._initialize_with_retry(verbose)
            if init_response is None:
                if verbose:
                    print(f"  ❌ MCP [{self.name}] failed: initialize timed out after retries")
                self.stop()
                return False

            # ── Discover tools ─────────────────────────────────────────
            self._send(
                {
                    "jsonrpc": "2.0",
                    "id": self._next_id(),
                    "method": "tools/list",
                    "params": {},
                }
            )
            resp = self._recv(
                timeout=self._TOOLS_RECV_TIMEOUT_SECS,
                timeout_error=f"[MCP TIMEOUT] tools/list took >{self._TOOLS_RECV_TIMEOUT_SECS}s",
            )
            if resp and "result" in resp:
                self.tools = resp["result"].get("tools", [])
            if verbose:
                print(f"  ✅ MCP [{self.name}] stdio: {len(self.tools)} tools")
            return True
        except Exception as e:
            if verbose:
                print(f"  ❌ MCP [{self.name}] failed: {e}")
            return False

    def _initialize_with_retry(self, verbose: bool = True) -> Optional[dict]:
        """Send initialize and retry if server wasn't ready yet.

        Returns the initialize response dict, or None if all retries failed.

        Flow:
          Attempt 1: send immediately after spawn (may land in buffer
                     before server reads stdin → server discards it)
          Attempt 2+: server should be warmed up by now → reads our
                      message immediately → responds.
        """
        deadline = time.monotonic() + self._WARMUP_TIMEOUT_SECS

        for attempt in range(1, self._INIT_MAX_RETRIES + 1):
            if time.monotonic() >= deadline:
                break

            # Check process is still alive
            if self.process.poll() is not None:
                _log.warning(
                    "MCP [%s] process exited during init (code=%s)",
                    self.name,
                    self.process.returncode,
                )
                return None

            _log.debug(
                "MCP [%s] initialize attempt %d/%d", self.name, attempt, self._INIT_MAX_RETRIES
            )

            self._send(
                {
                    "jsonrpc": "2.0",
                    "id": self._next_id(),
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "clientInfo": {"name": "free-claude", "version": "0.1.9"},
                        "capabilities": {},
                    },
                }
            )

            remaining = deadline - time.monotonic()
            recv_timeout = min(self._INIT_RECV_TIMEOUT_SECS, remaining)
            if recv_timeout <= 0:
                break

            resp = self._recv(timeout=recv_timeout)

            # Success — got a valid response
            if resp and "result" in resp:
                if attempt > 1 and verbose:
                    print(f"  ⚡ MCP [{self.name}] connected on attempt {attempt}")
                return resp

            # Got an error response — server is alive but unhappy.
            # Retry on explicit timeout-like signals, fail fast on real protocol errors.
            if resp and "error" in resp:
                err_text = str(resp["error"])
                if "timeout" in err_text.lower():
                    _log.debug("MCP [%s] initialize timeout-like response: %s", self.name, err_text)
                else:
                    _log.warning("MCP [%s] initialize error: %s", self.name, err_text)
                    return None

            # Timeout or empty response — server likely still warming up.
            # Wait a bit then retry (server should be ready by next attempt).
            if attempt < self._INIT_MAX_RETRIES:
                delay = min(self._INIT_RETRY_DELAY_SECS, deadline - time.monotonic())
                if delay > 0:
                    _log.debug("MCP [%s] init timeout, retrying in %.1fs...", self.name, delay)
                    time.sleep(delay)

        return None

    def _send(self, msg: dict):
        self.process.stdin.write(json.dumps(msg) + "\n")
        self.process.stdin.flush()

    def _recv(self, timeout: float = 30.0, timeout_error: Optional[str] = None):
        """Read one JSON-RPC response line with a timeout.

        If ``timeout_error`` is provided, return it as a structured MCP error.
        Otherwise, return None on timeout so callers can decide whether to retry.
        """
        result_holder = [None]
        error_holder = [None]

        def _read():
            try:
                line = self.process.stdout.readline()
                result_holder[0] = json.loads(line) if line else None
            except Exception as e:
                error_holder[0] = e

        t = threading.Thread(target=_read, daemon=True)
        t.start()
        t.join(timeout=timeout)

        if t.is_alive():
            if timeout_error:
                return {"error": timeout_error}
            return None
        if error_holder[0]:
            return None
        return result_holder[0]

    # ── Serena tool optimization ──────────────────────────────────────
    # Tools that are known to produce large results and need guardrails.
    # These safe defaults are injected ONLY when the caller didn't set them,
    # so explicit overrides from the LLM are always respected.
    _SERENA_SAFE_DEFAULTS = {
        "search_for_pattern": {
            "max_answer_chars": 30000,
            "context_lines_before": 2,
            "context_lines_after": 2,
        },
        "list_dir": {
            "max_answer_chars": 30000,
        },
        "find_symbol": {
            "max_answer_chars": 30000,
            "max_matches": 20,
        },
        "find_referencing_symbols": {
            "max_answer_chars": 30000,
        },
        "get_symbols_overview": {
            "max_answer_chars": 30000,
        },
        "read_file": {
            "max_answer_chars": 50000,
        },
    }

    def _optimize_serena_args(self, tool_name: str, arguments: dict) -> dict:
        """Inject safe defaults for Serena tools to prevent timeout from oversized results.

        Only applies to tools listed in _SERENA_SAFE_DEFAULTS.
        User-provided values always take precedence over defaults.
        """
        defaults = self._SERENA_SAFE_DEFAULTS.get(tool_name, {})
        if not defaults:
            return arguments
        optimized = dict(arguments)
        for key, default_val in defaults.items():
            if key not in optimized:
                optimized[key] = default_val
        return optimized

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        try:
            # Auto-optimize Serena tool arguments to prevent timeout
            optimized_args = self._optimize_serena_args(tool_name, arguments)
            self._send(
                {
                    "jsonrpc": "2.0",
                    "id": self._next_id(),
                    "method": "tools/call",
                    "params": {"name": tool_name, "arguments": optimized_args},
                }
            )
            resp = self._recv(
                timeout=self._TOOL_TIMEOUT_SECS,
                timeout_error=f"[MCP TIMEOUT] Tool took >{self._TOOL_TIMEOUT_SECS}s — result too large?",
            )
            if resp and "result" in resp:
                content = resp["result"].get("content", [])
                text = "\n".join(c.get("text", "") for c in content if c.get("type") == "text")
                # Truncate oversized results before sending to API
                if len(text) > self._MAX_RESULT_CHARS:
                    dropped = len(text) - self._MAX_RESULT_CHARS
                    text = (
                        text[: self._MAX_RESULT_CHARS]
                        + f"\n\n[... {dropped:,} characters truncated ...]"
                    )
                return text
            if resp and "error" in resp:
                return f"[MCP ERROR] {resp['error']}"
        except Exception as e:
            return f"[MCP ERROR] {e}"
        return "(no result)"

    def stop(self):
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass


class HttpMCPClient(MCPClient):
    """MCP client via HTTP or SSE transport."""

    def __init__(self, name: str, url: str, headers: dict = None, transport: str = "http"):
        super().__init__(name)
        self.base_url = url.rstrip("/")
        self.headers = headers or {}
        self.transport = transport
        self._session_id: Optional[str] = None
        self._msg_id = 0
        self._lock = threading.Lock()

    def _next_id(self) -> int:
        with self._lock:
            self._msg_id += 1
            return self._msg_id

    def _post(self, data: dict) -> dict:
        body = json.dumps(data).encode()
        req_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        req_headers.update(self.headers)
        if self._session_id:
            req_headers["Mcp-Session-Id"] = self._session_id

        req = urllib.request.Request(
            self.base_url,
            data=body,
            headers=req_headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            # Capture session ID if provided
            sid = resp.headers.get("Mcp-Session-Id")
            if sid:
                self._session_id = sid
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read().decode("utf-8", errors="replace")

        # Handle SSE response
        if "text/event-stream" in content_type:
            return self._parse_sse_response(raw)
        else:
            return json.loads(raw)

    def _parse_sse_response(self, raw: str) -> dict:
        """Extract JSON from SSE data lines."""
        for line in raw.splitlines():
            if line.startswith("data: "):
                try:
                    return json.loads(line[6:])
                except json.JSONDecodeError:
                    pass
        return {}

    def start(self, verbose: bool = True) -> bool:
        try:
            self._post(
                {
                    "jsonrpc": "2.0",
                    "id": self._next_id(),
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "clientInfo": {"name": "free-claude", "version": "0.1.9"},
                        "capabilities": {},
                    },
                }
            )
            # List tools
            resp2 = self._post(
                {"jsonrpc": "2.0", "id": self._next_id(), "method": "tools/list", "params": {}}
            )
            if resp2 and "result" in resp2:
                self.tools = resp2["result"].get("tools", [])
            if verbose:
                print(f"  ✅ MCP [{self.name}] {self.transport}: {len(self.tools)} tools")
            return True
        except urllib.error.HTTPError as e:
            if verbose:
                if e.code in (401, 403):
                    print(f"  ❌ MCP [{self.name}] auth required - check your API token/key")
                else:
                    print(f"  ❌ MCP [{self.name}] HTTP {e.code}: {e.reason}")
            return False
        except Exception as e:
            if verbose:
                print(f"  ❌ MCP [{self.name}] failed: {e}")
            return False

    # Max chars for HTTP MCP results (same as stdio)
    _MAX_RESULT_CHARS = 150_000

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        try:
            resp = self._post(
                {
                    "jsonrpc": "2.0",
                    "id": self._next_id(),
                    "method": "tools/call",
                    "params": {"name": tool_name, "arguments": arguments},
                }
            )
            if resp and "result" in resp:
                content = resp["result"].get("content", [])
                text = "\n".join(c.get("text", "") for c in content if c.get("type") == "text")
                if len(text) > self._MAX_RESULT_CHARS:
                    dropped = len(text) - self._MAX_RESULT_CHARS
                    text = (
                        text[: self._MAX_RESULT_CHARS]
                        + f"\n\n[... {dropped:,} characters truncated ...]"
                    )
                return text
            if resp and "error" in resp:
                return f"[MCP ERROR] {resp['error']}"
        except Exception as e:
            return f"[MCP ERROR] {e}"
        return "(no result)"
