#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║      🖥️  FCLAUDE TEAM DASHBOARD — LIVE TUI MONITOR          ║
║    Stream tiến trình làm việc của tất cả teammate lên màn    ║
║    hình quan sát với Rich Live + Table                        ║
╚══════════════════════════════════════════════════════════════╝

Tích hợp trực tiếp với hệ thống Teammate/Task/AgentTeam có sẵn.

Usage (standalone):
    python -m free_claude.team_dashboard                # Live dashboard
    python -m free_claude.team_dashboard --once          # Hiển thị 1 lần
    python -m free_claude.team_dashboard --demo          # Demo với fake data

Usage (from agent):
    /dashboard                                          # Mở live dashboard
    /dashboard once                                     # Hiển thị 1 lần
"""

import random
import sys
import time
from datetime import datetime
from typing import Optional

from rich import box
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .teammates import (
    AgentTeam,
    TaskStatus,
    TeammateRole,
)
from .teammates import (
    TeammateStatus as TmStatus,
)

# ─── Constants ───────────────────────────────────────────────
REFRESH_RATE = 1.0  # seconds

ROLE_ICONS = {
    TeammateRole.CODE_REVIEWER: "🔍",
    TeammateRole.TEST_WRITER: "🧪",
    TeammateRole.DOCS_WRITER: "📚",
    TeammateRole.DEBUGGER: "🐛",
    TeammateRole.REFACTORER: "♻️",
    TeammateRole.ARCHITECT: "🏗️",
    TeammateRole.SECURITY_AUDITOR: "🛡️",
}

ROLE_STYLES = {
    TeammateRole.CODE_REVIEWER: "bold cyan",
    TeammateRole.TEST_WRITER: "bold green",
    TeammateRole.DOCS_WRITER: "bold blue",
    TeammateRole.DEBUGGER: "bold red",
    TeammateRole.REFACTORER: "bold yellow",
    TeammateRole.ARCHITECT: "bold magenta",
    TeammateRole.SECURITY_AUDITOR: "bold bright_red",
}

STATUS_DISPLAY = {
    TmStatus.IDLE: ("💤 Idle", "dim green"),
    TmStatus.THINKING: ("🧠 Thinking", "bold yellow"),
    TmStatus.WORKING: ("⚡ Working", "bold bright_green"),
    TmStatus.BLOCKED: ("🚫 Blocked", "bold red"),
}

TASK_STATUS_DISPLAY = {
    TaskStatus.PENDING.value: ("📋 Pending", "dim"),
    TaskStatus.ASSIGNED.value: ("📌 Assigned", "bold cyan"),
    TaskStatus.IN_PROGRESS.value: ("🔄 In Progress", "bold yellow"),
    TaskStatus.DONE.value: ("✅ Done", "bold green"),
    TaskStatus.FAILED.value: ("❌ Failed", "bold red"),
    TaskStatus.BLOCKED.value: ("🚫 Blocked", "bold red"),
    TaskStatus.CANCELLED.value: ("🗑️ Cancelled", "dim"),
}


# ─── Progress Bar ────────────────────────────────────────────
def _progress_bar(done: int, total: int, width: int = 20) -> str:
    """Tạo progress bar dựa trên số task done/total."""
    if total == 0:
        return "[dim]░" * width + " 0/0[/dim]"
    ratio = done / total
    filled = int(width * ratio)
    empty = width - filled

    if ratio >= 1.0:
        color = "bold green"
    elif ratio >= 0.5:
        color = "yellow"
    elif ratio > 0:
        color = "dark_orange"
    else:
        color = "dim"

    pct = int(ratio * 100)
    bar = f"[{color}]{'█' * filled}[/{color}][dim]{'░' * empty}[/dim]"
    return f"{bar} [{color}]{pct}%[/{color}] [dim]({done}/{total})[/dim]"


# ─── Elapsed Time Format ────────────────────────────────────
def _elapsed(start: Optional[datetime]) -> str:
    if not start:
        return "-"
    delta = datetime.now() - start
    secs = int(delta.total_seconds())
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m {secs % 60}s"
    return f"{secs // 3600}h {(secs % 3600) // 60}m"


# ═════════════════════════════════════════════════════════════
#                    DASHBOARD BUILDER
# ═════════════════════════════════════════════════════════════


class TeamDashboard:
    """Live TUI dashboard cho AgentTeam."""

    def __init__(self, team: AgentTeam, console: Optional[Console] = None):
        self.team = team
        self.console = console or Console()
        self._tick = 0

    # ── Header ───────────────────────────────────────────────
    def _build_header(self) -> Panel:
        spinners = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        spinner = spinners[self._tick % len(spinners)]
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        dots = "." * (self._tick % 4)

        txt = Text()
        txt.append("  🖥️  ", style="bold")
        txt.append("FCLAUDE TEAM DASHBOARD", style="bold bright_white on blue")
        txt.append(f"\n  {spinner} ", style="bold green")
        txt.append(f"LIVE MONITORING{dots: <4}", style="bold green")
        txt.append(f"   🕐 {now}", style="dim white")
        txt.append(f"   👥 {len(self.team.teammates)} teammates", style="dim cyan")
        tasks = self.team.list_tasks("all")
        active = sum(
            1
            for t in tasks
            if t.status in {TaskStatus.ASSIGNED.value, TaskStatus.IN_PROGRESS.value}
        )
        txt.append(f"   📋 {len(tasks)} tasks ({active} active)", style="dim yellow")

        return Panel(txt, border_style="bright_blue", box=box.DOUBLE_EDGE, padding=(0, 1))

    # ── Team Overview Table ──────────────────────────────────
    def _build_team_table(self) -> Table:
        table = Table(
            title="👥 TEAM OVERVIEW — Tổng quan thành viên",
            box=box.ROUNDED,
            border_style="bright_blue",
            title_style="bold bright_white",
            header_style="bold bright_cyan on grey23",
            row_styles=["", "on grey7"],
            expand=True,
            padding=(0, 1),
        )

        table.add_column("", justify="center", width=3, no_wrap=True)
        table.add_column("Teammate", style="bold white", min_width=16)
        table.add_column("Role", min_width=18)
        table.add_column("Status", justify="center", min_width=14)
        table.add_column("Current Task", min_width=22)
        table.add_column("Progress", min_width=28)
        table.add_column("Tools", justify="center", width=8)
        table.add_column("Turns", justify="center", width=7)

        if not self.team.teammates:
            table.add_row(
                "🚫",
                "[dim]No teammates yet[/dim]",
                "",
                "",
                "[dim]Use /teammate add <role> to add[/dim]",
                "",
                "",
                "",
            )
            return table

        for name, tm in self.team.teammates.items():
            icon = ROLE_ICONS.get(tm.role, "👤")
            role_style = ROLE_STYLES.get(tm.role, "white")

            # Status with animation
            status_label, status_style = STATUS_DISPLAY.get(tm.status, ("❓ Unknown", "white"))
            if tm.status == TmStatus.WORKING:
                # Animate working indicator
                work_chars = ["⚡", "💫", "🔥", "⭐"]
                status_label = f"{work_chars[self._tick % 4]} Working"

            # Current task
            if tm.current_task:
                task_name = tm.current_task.title[:20]
                elapsed = _elapsed(tm.current_task.started_at)
                current = f"[bold yellow]{task_name}[/bold yellow] [dim]({elapsed})[/dim]"
            else:
                current = "[dim]— idle —[/dim]"

            # Progress: done / total assigned
            all_tasks = tm.assigned_tasks + tm.completed_tasks
            # De-duplicate (completed_tasks are also in assigned_tasks)
            seen_ids = set()
            unique_tasks = []
            for t in all_tasks:
                if t.id not in seen_ids:
                    seen_ids.add(t.id)
                    unique_tasks.append(t)
            total = len(unique_tasks)
            done = sum(1 for t in unique_tasks if t.status == TaskStatus.DONE.value)
            progress = _progress_bar(done, total, width=16)

            # Tools & turns
            tools_count = str(len(tm.tools)) if tm.tools else "[dim]0[/dim]"
            turns = str(len(tm.conversation) // 2)

            table.add_row(
                icon,
                name,
                f"[{role_style}]{tm.role.value.replace('_', ' ').title()}[/{role_style}]",
                f"[{status_style}]{status_label}[/{status_style}]",
                current,
                progress,
                tools_count,
                turns,
            )

        return table

    # ── Task Monitor Table ───────────────────────────────────
    def _build_task_table(self) -> Table:
        tasks = self.team.list_tasks("all")

        table = Table(
            title=f"📋 TASK MONITOR — Theo dõi tất cả tasks ({len(tasks)} total)",
            box=box.ROUNDED,
            border_style="bright_magenta",
            title_style="bold bright_white",
            header_style="bold bright_magenta on grey23",
            row_styles=["", "on grey7"],
            expand=True,
            padding=(0, 1),
        )

        table.add_column("#", justify="center", width=4, style="dim")
        table.add_column("Task ID", style="dim cyan", width=20, no_wrap=True)
        table.add_column("Title", min_width=24)
        table.add_column("Role", min_width=14)
        table.add_column("Assigned To", min_width=16)
        table.add_column("Status", justify="center", min_width=16)
        table.add_column("Priority", justify="center", width=8)
        table.add_column("Duration", justify="center", width=10)

        if not tasks:
            table.add_row(
                "",
                "",
                "[dim]No tasks yet[/dim]",
                "",
                "[dim]Use /teammate delegate <role> <task> to create[/dim]",
                "",
                "",
                "",
            )
            return table

        # Sort: active first, then by priority
        def sort_key(t):
            active_statuses = {
                TaskStatus.IN_PROGRESS.value: 0,
                TaskStatus.ASSIGNED.value: 1,
                TaskStatus.BLOCKED.value: 2,
                TaskStatus.PENDING.value: 3,
            }
            return (
                active_statuses.get(t.status, 10),
                -t.priority,
                t.created_at,
            )

        tasks_sorted = sorted(tasks, key=sort_key)

        for idx, task in enumerate(tasks_sorted[:30], 1):
            status_label, status_style = TASK_STATUS_DISPLAY.get(task.status, ("❓", "white"))

            # Animate in-progress tasks
            if task.status == TaskStatus.IN_PROGRESS.value:
                anim = ["🔄", "🔃", "🔁", "⏳"]
                status_label = f"{anim[self._tick % 4]} In Progress"

            # Title styling
            title = task.title[:22]
            if task.status == TaskStatus.IN_PROGRESS.value:
                title_styled = f"[bold yellow]{title}[/bold yellow]"
            elif task.status == TaskStatus.DONE.value:
                title_styled = f"[dim green]{title}[/dim green]"
            elif task.status == TaskStatus.FAILED.value:
                title_styled = f"[bold red]{title}[/bold red]"
            else:
                title_styled = title

            # Role
            try:
                role_enum = TeammateRole(task.role)
                role_icon = ROLE_ICONS.get(role_enum, "")
                role_text = f"{role_icon} {task.role}"
            except ValueError:
                role_text = task.role

            # Duration
            if task.started_at:
                duration = _elapsed(task.started_at)
            else:
                duration = "[dim]-[/dim]"

            # Priority stars
            priority = "★" * min(task.priority, 5)

            table.add_row(
                str(idx),
                task.id,
                title_styled,
                role_text,
                task.assigned_to or "[dim]unassigned[/dim]",
                f"[{status_style}]{status_label}[/{status_style}]",
                f"[bold yellow]{priority}[/bold yellow]",
                duration,
            )

        return table

    # ── Message Log ──────────────────────────────────────────
    def _build_message_log(self) -> Panel:
        messages = self.team.get_message_history()
        recent = messages[-8:] if messages else []

        log_text = Text()
        if not recent:
            log_text.append("  [dim]No messages yet — delegate tasks to see activity[/dim]\n")
        else:
            for msg in reversed(recent):
                ts = msg.get("timestamp", "")
                if ts:
                    try:
                        dt = datetime.fromisoformat(ts)
                        ts_short = dt.strftime("%H:%M:%S")
                    except Exception:
                        ts_short = ts[:8]
                else:
                    ts_short = "??:??:??"

                sender = msg.get("sender", "?")
                content = msg.get("content", "")[:50]
                attachments = msg.get("attachments", {})

                log_text.append(f"  [{ts_short}] ", style="dim")
                log_text.append(f"{sender}", style="bold cyan")
                log_text.append(" → ", style="dim")
                log_text.append(f"{content}", style="white")

                # Show tool call count if present
                tool_calls = attachments.get("tool_calls", 0)
                if tool_calls:
                    log_text.append(f" [🔧×{tool_calls}]", style="dim magenta")

                log_text.append("\n")

        return Panel(
            log_text,
            title="[bold]📡 MESSAGE LOG[/bold]",
            border_style="bright_yellow",
            box=box.ROUNDED,
            padding=(0, 0),
        )

    # ── Stats Panel ──────────────────────────────────────────
    def _build_stats(self) -> Panel:
        teammates = self.team.teammates
        tasks = self.team.list_tasks("all")

        total_tasks = len(tasks)
        done = sum(1 for t in tasks if t.status == TaskStatus.DONE.value)
        in_prog = sum(1 for t in tasks if t.status == TaskStatus.IN_PROGRESS.value)
        assigned = sum(1 for t in tasks if t.status == TaskStatus.ASSIGNED.value)
        pending = sum(1 for t in tasks if t.status == TaskStatus.PENDING.value)
        failed = sum(1 for t in tasks if t.status == TaskStatus.FAILED.value)
        blocked = sum(1 for t in tasks if t.status == TaskStatus.BLOCKED.value)

        idle_count = sum(1 for tm in teammates.values() if tm.status == TmStatus.IDLE)
        working_count = sum(1 for tm in teammates.values() if tm.status == TmStatus.WORKING)
        thinking_count = sum(1 for tm in teammates.values() if tm.status == TmStatus.THINKING)

        # Overall completion rate
        if total_tasks > 0:
            completion = (done / total_tasks) * 100
        else:
            completion = 0

        # Total tool calls across all teammates
        total_tool_calls = sum(len(tm.last_tool_calls) for tm in teammates.values())

        txt = Text()
        txt.append("  📊 Project Statistics\n", style="bold underline")
        txt.append("  ━━━━━━━━━━━━━━━━━━━━━━━━━\n", style="dim")
        txt.append("  👥 Teammates:   ", style="dim")
        txt.append(f"{len(teammates)}", style="bold bright_white")
        txt.append(f" ({working_count}⚡ {thinking_count}🧠 {idle_count}💤)\n", style="dim")
        txt.append("  📋 Total tasks: ", style="dim")
        txt.append(f"{total_tasks}\n", style="bold bright_white")
        txt.append("  ✅ Done:        ", style="dim")
        txt.append(f"{done}\n", style="bold green")
        txt.append("  🔄 In progress: ", style="dim")
        txt.append(f"{in_prog}\n", style="bold yellow")
        txt.append("  📌 Assigned:    ", style="dim")
        txt.append(f"{assigned}\n", style="bold cyan")
        txt.append("  📋 Pending:     ", style="dim")
        txt.append(f"{pending}\n", style="bold white")
        if failed > 0:
            txt.append("  ❌ Failed:      ", style="dim")
            txt.append(f"{failed}\n", style="bold red")
        if blocked > 0:
            txt.append("  🚫 Blocked:     ", style="dim")
            txt.append(f"{blocked}\n", style="bold red")
        txt.append("  ━━━━━━━━━━━━━━━━━━━━━━━━━\n", style="dim")
        txt.append("  🎯 Completion:  ", style="dim")
        c_style = (
            "bold bright_green"
            if completion >= 75
            else "bold yellow"
            if completion >= 40
            else "bold red"
        )
        txt.append(f"{completion:.1f}%\n", style=c_style)
        txt.append("  🔧 Tool calls:  ", style="dim")
        txt.append(f"{total_tool_calls}\n", style="bold magenta")
        txt.append("  💬 Messages:    ", style="dim")
        txt.append(f"{len(self.team.message_bus.history)}\n", style="bold cyan")

        return Panel(
            txt,
            title="[bold]📈 STATISTICS[/bold]",
            border_style="bright_green",
            box=box.ROUNDED,
            padding=(0, 0),
        )

    # ── Teammate Detail Cards ────────────────────────────────
    def _build_teammate_details(self) -> Panel:
        if not self.team.teammates:
            return Panel(
                "[dim]No teammates — use /teammate add <role> to create[/dim]",
                title="[bold]📋 CHI TIẾT TỪNG THÀNH VIÊN[/bold]",
                border_style="bright_cyan",
                box=box.ROUNDED,
            )

        cards = []
        for name, tm in self.team.teammates.items():
            icon = ROLE_ICONS.get(tm.role, "👤")
            role_style = ROLE_STYLES.get(tm.role, "white")

            card_table = Table(
                title=f"{icon} {name}",
                box=box.SIMPLE_HEAVY,
                border_style="dim cyan",
                title_style="bold bright_white",
                header_style="bold dim cyan",
                expand=True,
                padding=(0, 0),
                show_edge=False,
            )
            card_table.add_column("", width=12, style="dim")
            card_table.add_column("", min_width=18)

            status_label, status_style = STATUS_DISPLAY.get(tm.status, ("❓", "white"))
            card_table.add_row("Role", f"[{role_style}]{tm.role.value}[/{role_style}]")
            card_table.add_row("Status", f"[{status_style}]{status_label}[/{status_style}]")

            if tm.current_task:
                card_table.add_row("Task", f"[yellow]{tm.current_task.title[:25]}[/yellow]")
                card_table.add_row("Elapsed", _elapsed(tm.current_task.started_at))

            card_table.add_row("Completed", f"[green]{len(tm.completed_tasks)}[/green]")
            card_table.add_row("Tools", f"{len(tm.tools)}")
            card_table.add_row("Turns", f"{len(tm.conversation) // 2}")

            if tm.last_error:
                card_table.add_row("Error", f"[red]{tm.last_error[:30]}[/red]")

            cards.append(card_table)

        from rich.columns import Columns

        cols = Columns(cards, equal=True, expand=True)

        return Panel(
            cols,
            title="[bold]📋 CHI TIẾT TỪNG THÀNH VIÊN[/bold]",
            border_style="bright_cyan",
            box=box.ROUNDED,
        )

    # ── Footer ───────────────────────────────────────────────
    def _build_footer(self) -> Panel:
        txt = Text()
        txt.append("  ⌨️  ", style="bold")
        txt.append("Ctrl+C", style="bold red")
        txt.append(" thoát  │  ", style="dim")
        txt.append("/teammate add <role>", style="bold cyan")
        txt.append(" thêm  │  ", style="dim")
        txt.append("/teammate delegate <role> <task>", style="bold cyan")
        txt.append(" giao việc  │  ", style="dim")
        txt.append("/tasks", style="bold cyan")
        txt.append(" xem tasks", style="dim")
        return Panel(txt, border_style="dim", box=box.SIMPLE)

    # ── Full Layout ──────────────────────────────────────────
    def build_layout(self) -> Layout:
        self._tick += 1

        layout = Layout()

        n_teammates = len(self.team.teammates)
        overview_height = max(5, n_teammates + 4)
        n_tasks = len(self.team.list_tasks("all"))
        task_height = max(5, min(n_tasks + 4, 15))

        layout.split_column(
            Layout(name="header", size=5),
            Layout(name="body"),
            Layout(name="footer", size=3),
        )

        layout["body"].split_row(
            Layout(name="main", ratio=3),
            Layout(name="sidebar", ratio=1, minimum_size=30),
        )

        layout["main"].split_column(
            Layout(name="overview", size=overview_height),
            Layout(name="tasks", size=task_height),
            Layout(name="details"),
        )

        layout["sidebar"].split_column(
            Layout(name="stats", ratio=2),
            Layout(name="messages", ratio=1),
        )

        # Fill
        layout["header"].update(self._build_header())
        layout["overview"].update(self._build_team_table())
        layout["tasks"].update(self._build_task_table())
        layout["details"].update(self._build_teammate_details())
        layout["stats"].update(self._build_stats())
        layout["messages"].update(self._build_message_log())
        layout["footer"].update(self._build_footer())

        return layout

    # ── Static render (once) ─────────────────────────────────
    def render_once(self):
        """Hiển thị dashboard 1 lần rồi thoát."""
        self.console.print(self.build_layout())

    # ── Live stream ──────────────────────────────────────────
    def run_live(self, refresh_rate: float = REFRESH_RATE):
        """Chạy live dashboard streaming liên tục."""
        self.console.clear()
        try:
            with Live(
                self.build_layout(),
                console=self.console,
                refresh_per_second=max(1, int(1 / refresh_rate)),
                screen=True,
            ) as live:
                while True:
                    live.update(self.build_layout())
                    time.sleep(refresh_rate)
        except KeyboardInterrupt:
            self.console.clear()
            self.console.print(
                "\n[bold bright_cyan]  👋 Dashboard đã đóng. Quay lại agent...[/bold bright_cyan]\n"
            )


# ═════════════════════════════════════════════════════════════
#           DEMO MODE (chạy standalone với fake data)
# ═════════════════════════════════════════════════════════════


def _create_demo_team() -> AgentTeam:
    """Tạo team demo với fake teammates & tasks để test UI."""
    team = AgentTeam()

    # Add teammates
    team.add_teammate("Bảo", TeammateRole.ARCHITECT)
    team.add_teammate("Minh", TeammateRole.CODE_REVIEWER)
    team.add_teammate("Hùng", TeammateRole.DEBUGGER)
    team.add_teammate("Linh", TeammateRole.TEST_WRITER)
    team.add_teammate("Đức", TeammateRole.REFACTORER)

    # Create fake tasks with various statuses
    _demo_tasks = [
        ("Design API architecture", TeammateRole.ARCHITECT, "Bảo", TaskStatus.DONE),
        ("Review auth module", TeammateRole.CODE_REVIEWER, "Minh", TaskStatus.IN_PROGRESS),
        ("Fix timeout bug in MCP", TeammateRole.DEBUGGER, "Hùng", TaskStatus.IN_PROGRESS),
        ("Write unit tests for tools.py", TeammateRole.TEST_WRITER, "Linh", TaskStatus.ASSIGNED),
        ("Refactor config module", TeammateRole.REFACTORER, "Đức", TaskStatus.PENDING),
        ("Review streaming module", TeammateRole.CODE_REVIEWER, "Minh", TaskStatus.DONE),
        ("Debug agent loop crash", TeammateRole.DEBUGGER, "Hùng", TaskStatus.DONE),
        ("Write integration tests", TeammateRole.TEST_WRITER, "Linh", TaskStatus.PENDING),
    ]

    for i, (title, role, assigned, status) in enumerate(_demo_tasks):
        task = team.coordinator.create_task(
            title=title,
            description=f"Detailed description for: {title}",
            role=role,
            priority=random.randint(1, 3),
        )
        task.assigned_to = assigned
        task.status = status.value

        # Set timing for realism
        if status in (TaskStatus.DONE, TaskStatus.IN_PROGRESS):
            task.started_at = datetime.now()
        if status == TaskStatus.DONE:
            task.completed_at = datetime.now()
            task.result = f"Completed: {title}"

        # Find teammate and assign
        tm = team.get_teammate(assigned)
        if tm:
            tm.assigned_tasks.append(task)
            if status == TaskStatus.DONE:
                tm.completed_tasks.append(task)
            if status == TaskStatus.IN_PROGRESS:
                tm.current_task = task
                tm.status = TmStatus.WORKING

    # Fake message history
    bus = team.message_bus
    from .teammates import Message

    bus.publish(
        Message(sender="Bảo", receiver="leader", content="Task 'Design API architecture' completed")
    )
    bus.publish(Message(sender="leader", receiver="Minh", content="Please review auth module"))
    bus.publish(Message(sender="Minh", receiver="leader", content="Starting review of auth module"))
    bus.publish(
        Message(sender="Hùng", receiver="leader", content="Investigating timeout bug in MCP")
    )
    bus.publish(Message(sender="leader", receiver="Linh", content="Write tests for tools.py"))

    return team


# ═════════════════════════════════════════════════════════════
#                      ENTRY POINT
# ═════════════════════════════════════════════════════════════


def run_dashboard_cmd(team: Optional[AgentTeam] = None, mode: str = "live"):
    """Entry point gọi từ agent commands."""
    if team is None:
        team = _create_demo_team()

    console = Console()
    dashboard = TeamDashboard(team, console)

    if mode == "once":
        dashboard.render_once()
    else:
        dashboard.run_live()


def main():
    """CLI entry point."""
    mode = "live"
    demo = True

    for arg in sys.argv[1:]:
        if arg == "--once":
            mode = "once"
        elif arg == "--demo":
            demo = True
        elif arg == "--help":
            print(__doc__)
            return

    if demo:
        team = _create_demo_team()
    else:
        team = AgentTeam()

    run_dashboard_cmd(team, mode)


if __name__ == "__main__":
    main()
