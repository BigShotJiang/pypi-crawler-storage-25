"""Adaptive Thinking — auto-select thinking budget based on query complexity.

Inspired by fclaude internal's thinking.type='adaptive' pattern where Claude
self-determines when deep reasoning is needed.

Instead of the user manually toggling /think, this module:
1. Classifies query complexity (rule-based, zero API calls)
2. Selects the appropriate thinking budget
3. Optionally uses a fast classifier call for ambiguous queries

Usage:
    mgr = AdaptiveThinkingManager()
    budget = mgr.get_budget("refactor the auth module to use JWT")
    # → 12000 (complex)

    budget = mgr.get_budget("what is 2+2")
    # → 0 (trivial)
"""

from __future__ import annotations

import json
import logging
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Complexity levels & budgets
# ─────────────────────────────────────────────────────────────────────────────


class Complexity(str, Enum):
    TRIVIAL = "trivial"  # Greetings, math, simple Q&A
    SIMPLE = "simple"  # Single-file reads, explanations
    MEDIUM = "medium"  # Multi-step tasks, debugging
    COMPLEX = "complex"  # Refactoring, architecture, deep investigation
    EXPERT = "expert"  # System design, performance tuning, security


# Token budgets per complexity level
BUDGETS: Dict[Complexity, int] = {
    Complexity.TRIVIAL: 0,  # No thinking — wastes tokens
    Complexity.SIMPLE: 0,  # Direct answer fine
    Complexity.MEDIUM: 4000,  # Light thinking
    Complexity.COMPLEX: 10000,  # Deep thinking
    Complexity.EXPERT: 16000,  # Maximum depth
}

# Minimum message length to consider thinking (very short = trivial)
# NOTE: intentionally low — short queries can still be complex
# e.g. "fix the bug in auth.py" = 22 chars but MEDIUM
_MIN_THINKING_LENGTH = 15


# ─────────────────────────────────────────────────────────────────────────────
# Rule patterns (no API call needed — pure regex)
# ─────────────────────────────────────────────────────────────────────────────

# Patterns that indicate TRIVIAL (budget=0)
_TRIVIAL_PATTERNS = [
    r"^(hi|hello|hey|xin chào|chào|cảm ơn|thanks|thank you|ok|okay|yes|no|yep|nope)\b",
    r"^[\d\s\+\-\*\/\^\(\)\%\.]+[=\?]?\s*$",  # pure math
    r"^(what time|what date|what day|mấy giờ|hôm nay)\b",
    r"^(bye|goodbye|tạm biệt|cảm ơn nhé)\b",
]

# Patterns that indicate SIMPLE (budget=0)
_SIMPLE_PATTERNS = [
    r"^(what|who|when|where)\s+(is|are|was|were)\b",
    r"^(define|explain|describe|tell me about|giải thích)\b",
    r"^(translate|dịch)\b",
    r"^(list|name)\s+\d+\b",
    r"^(write a (poem|joke|story|haiku|song|limerick))\b",
    r"^(how do (i|you) (say|write|spell))\b",
    r"^translate\b",  # translate X to Y
    r"^dịch\b",
]

# Patterns that indicate MEDIUM (budget=4000)
_MEDIUM_PATTERNS = [
    r"\b(fix|debug|error|bug|issue|problem|không chạy|lỗi)\b",
    r"\b(read|show|display|print|get|fetch|look at)\b.*(file|code|function|class)\b",
    r"\b(explain|walk.?through|analyze)\b.*(code|function|class|module)\b",
    r"\b(add|create|write)\b.*(function|method|class|test|feature)\b",
    r"\b(how does|how do|cách nào|làm thế nào)\b",
    r"\b(convert|transform|format|parse)\b",
    r"\b(git|docker|pip|npm|bash|script)\b",
    r"\b(build|create)\b.*(api|rest|endpoint|server|service|app)\b",  # build REST API
    r"\b(implement)\b.*(queue|cache|pool|worker|handler)\b",  # implement components
]

# Patterns that indicate COMPLEX (budget=10000)
_COMPLEX_PATTERNS = [
    r"\b(refactor|rewrite|restructure|tái cấu trúc)\b",
    r"\b(architect|design|redesign|thiết kế)\b.*(system|module|api|service)\b",
    r"\b(optimize|improve performance|tăng tốc|performance)\b",
    r"\b(investigate|root cause|why.*not work|tại sao.*không)\b",
    r"\b(migrate|migration|upgrade|nâng cấp)\b",
    r"\b(implement|build)\b.*(system|framework|engine|service|pipeline)\b",
    r"\b(compare|trade.?off|pros.?and.?cons|so sánh)\b.*(approach|solution|library|framework)\b",
    r"\b(security|vulnerability|auth|authentication|authorization|bảo mật)\b",
    r"\b(scale|scalability|distributed|concurrent|parallel)\b",
    r"\b(multi.?step|multiple|several)\b.*(change|modify|update|file)\b",
]

# Patterns that indicate EXPERT (budget=16000)
_EXPERT_PATTERNS = [
    r"\b(design|architect)\b.*(entire|whole|complete|full)\b.*(system|app|backend|frontend)\b",
    r"\b(from scratch)\b.*(system|framework|platform|queue|engine)\b",  # implement X from scratch
    r"\b(implement)\b.*(distributed|message.?queue|event.?driven)\b.*(from scratch|ground up)\b",
    r"\b(performance.*critical|latency|throughput|bottleneck)\b",
    r"\b(concurrent|race.?condition|deadlock|thread.?safe)\b",
    r"\b(memory.?leak|profil|heap|stack.*overflow)\b",
    r"\b(cryptograph|encryption|cipher|hash.?collision)\b",
    r"\b(algorithm|data.?structure|complexity|O\(n\))\b.*\b(optimize|improve|better)\b",
    r"\b(machine.?learning|neural|model|train|inference)\b",
    r"\b(distributed)\b.*(message.?queue|event.?bus|pub.?sub)\b",  # distributed systems
]


def _compile(patterns: List[str]) -> List[re.Pattern]:
    return [re.compile(p, re.IGNORECASE) for p in patterns]


_TRIVIAL_RE = _compile(_TRIVIAL_PATTERNS)
_SIMPLE_RE = _compile(_SIMPLE_PATTERNS)
_MEDIUM_RE = _compile(_MEDIUM_PATTERNS)
_COMPLEX_RE = _compile(_COMPLEX_PATTERNS)
_EXPERT_RE = _compile(_EXPERT_PATTERNS)


# ─────────────────────────────────────────────────────────────────────────────
# Classification result
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class ClassificationResult:
    complexity: Complexity
    budget: int
    reason: str
    confidence: float  # 0.0–1.0
    used_api: bool = False
    duration_ms: float = 0.0

    def __str__(self) -> str:
        budget_str = f"{self.budget:,}" if self.budget else "disabled"
        return f"[{self.complexity.value.upper()}] thinking={budget_str} tokens  ({self.reason})"


# ─────────────────────────────────────────────────────────────────────────────
# AdaptiveThinkingManager
# ─────────────────────────────────────────────────────────────────────────────


class AdaptiveThinkingManager:
    """Auto-select thinking budget based on query complexity.

    Two modes:
    - ADAPTIVE (default): Rule-based classifier only (instant, zero cost)
    - ADAPTIVE_PLUS:      Rule-based first, API classifier for MEDIUM queries
                          where budget matters most
    """

    def __init__(
        self,
        enabled: bool = True,
        use_api_classifier: bool = False,
        api_base: Optional[str] = None,
        token: Optional[str] = None,
        classifier_model: str = "claude-haiku-4-5-20251001",
    ) -> None:
        self.enabled = enabled
        self.use_api_classifier = use_api_classifier
        self.api_base = api_base
        self.token = token
        self.classifier_model = classifier_model

        # Stats
        self._classifications: int = 0
        self._api_calls: int = 0
        self._total_budget: int = 0

    # ── Public API ──────────────────────────────────────────────────────────

    def classify(self, query: str, conversation_length: int = 0) -> ClassificationResult:
        """Classify query and return thinking budget recommendation.

        Args:
            query:               User query text.
            conversation_length: Number of messages in current conversation.

        Returns:
            ClassificationResult with complexity, budget, and reason.
        """
        t0 = time.perf_counter()
        text = query.strip()

        # Very short queries → trivial (unless they contain coding keywords)
        _CODING_QUICK = re.compile(
            r"\b(fix|bug|error|debug|refactor|optimize|test|run|build|"
            r"deploy|crash|fail|broken|lỗi|sửa|chạy)\b",
            re.IGNORECASE,
        )
        if len(text) < _MIN_THINKING_LENGTH and not _CODING_QUICK.search(text):
            result = self._make(Complexity.TRIVIAL, "very short query", 0.95)
        else:
            result = self._rule_classify(text)

        # Boost budget if deep in a long conversation (likely complex task)
        if (
            result.complexity == Complexity.MEDIUM
            and conversation_length >= 10
            and not result.used_api
        ):
            result = self._boost(
                result, Complexity.COMPLEX, "long conversation → boosted complexity"
            )

        # Optional: use API for ambiguous MEDIUM queries
        if (
            result.complexity == Complexity.MEDIUM
            and self.use_api_classifier
            and self.api_base
            and self.token
        ):
            api_result = self._api_classify(text)
            if api_result:
                result = api_result
                result.used_api = True
                self._api_calls += 1

        result.duration_ms = (time.perf_counter() - t0) * 1000
        self._classifications += 1
        self._total_budget += result.budget

        log.debug("[AdaptiveThinking] %s  (%.1fms)", result, result.duration_ms)
        return result

    def get_budget(self, query: str, conversation_length: int = 0) -> int:
        """Convenience method: return just the thinking budget."""
        if not self.enabled:
            return 0
        return self.classify(query, conversation_length).budget

    def enable(self) -> None:
        self.enabled = True

    def disable(self) -> None:
        self.enabled = False

    def stats(self) -> Dict:
        avg_budget = self._total_budget / self._classifications if self._classifications else 0
        return {
            "enabled": self.enabled,
            "classifications": self._classifications,
            "api_calls": self._api_calls,
            "avg_budget": int(avg_budget),
            "total_budget": self._total_budget,
        }

    # ── Rule-based classifier ────────────────────────────────────────────────

    def _rule_classify(self, text: str) -> ClassificationResult:
        """Pure regex classifier — instant, zero cost."""

        # Check from highest to lowest priority
        for pat in _EXPERT_RE:
            if pat.search(text):
                return self._make(Complexity.EXPERT, f"expert pattern: {pat.pattern[:50]}", 0.85)

        for pat in _COMPLEX_RE:
            if pat.search(text):
                return self._make(Complexity.COMPLEX, f"complex pattern: {pat.pattern[:50]}", 0.80)

        for pat in _TRIVIAL_RE:
            if pat.match(text):
                return self._make(Complexity.TRIVIAL, "trivial pattern match", 0.90)

        for pat in _SIMPLE_RE:
            if pat.match(text):
                return self._make(Complexity.SIMPLE, "simple pattern match", 0.85)

        for pat in _MEDIUM_RE:
            if pat.search(text):
                return self._make(Complexity.MEDIUM, f"medium pattern: {pat.pattern[:50]}", 0.70)

        # Default: use length as tiebreaker
        if len(text) > 200:
            return self._make(Complexity.MEDIUM, "long query → medium", 0.55)
        if len(text) > 80:
            return self._make(Complexity.SIMPLE, "medium query → simple", 0.60)

        return self._make(Complexity.TRIVIAL, "short query → trivial", 0.65)

    # ── API classifier (optional) ────────────────────────────────────────────

    def _api_classify(self, text: str) -> Optional[ClassificationResult]:
        """Optional: fast haiku classifier call for ambiguous queries."""
        _SYSTEM = (
            "You classify coding queries by complexity. "
            "Reply with exactly one word: trivial, simple, medium, complex, or expert. "
            "No explanation."
        )
        try:
            payload = {
                "model": self.classifier_model,
                "max_tokens": 10,
                "system": _SYSTEM,
                "messages": [{"role": "user", "content": text[:500]}],
                "temperature": 0,
            }
            req = urllib.request.Request(
                f"{self.api_base}/v1/messages",
                data=json.dumps(payload).encode(),
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01",
                    "User-Agent": "fclaude/1.0",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                result = json.loads(resp.read())
            raw = ""
            for block in result.get("content", []):
                if block.get("type") == "text":
                    raw = block["text"].strip().lower()
                    break

            mapping = {
                "trivial": Complexity.TRIVIAL,
                "simple": Complexity.SIMPLE,
                "medium": Complexity.MEDIUM,
                "complex": Complexity.COMPLEX,
                "expert": Complexity.EXPERT,
            }
            if raw in mapping:
                c = mapping[raw]
                return self._make(c, f"API classifier → {raw}", 0.90)
        except Exception as e:
            log.debug("[AdaptiveThinking] API classifier failed: %s", e)
        return None

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _make(complexity: Complexity, reason: str, confidence: float) -> ClassificationResult:
        return ClassificationResult(
            complexity=complexity,
            budget=BUDGETS[complexity],
            reason=reason,
            confidence=confidence,
        )

    @staticmethod
    def _boost(
        result: ClassificationResult, new_complexity: Complexity, reason: str
    ) -> ClassificationResult:
        return ClassificationResult(
            complexity=new_complexity,
            budget=BUDGETS[new_complexity],
            reason=reason,
            confidence=result.confidence * 0.9,
        )


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton
# ─────────────────────────────────────────────────────────────────────────────

_global_mgr: Optional[AdaptiveThinkingManager] = None


def get_adaptive_thinking() -> AdaptiveThinkingManager:
    global _global_mgr
    if _global_mgr is None:
        _global_mgr = AdaptiveThinkingManager()
    return _global_mgr


__all__ = [
    "AdaptiveThinkingManager",
    "ClassificationResult",
    "Complexity",
    "BUDGETS",
    "get_adaptive_thinking",
]
