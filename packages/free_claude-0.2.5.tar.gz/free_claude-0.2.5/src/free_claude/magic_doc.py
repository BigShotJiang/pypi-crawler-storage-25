"""Magic Doc system — auto-update project memory after each session.

Inspired by fclaude internal's Magic Doc pattern: a persistent markdown file
that accumulates project knowledge across sessions. Claude reads it at
startup and updates it after each conversation.

Usage:
    doc = MagicDocManager()
    system_extra = doc.load_into_context()  # inject into system prompt
    doc.update_after_session(messages, api_base, token)
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

_DEFAULT_DOC_NAME = "CLAUDE_MEMORY.md"
_UPDATE_MODEL = "claude-haiku-4-5-20251001"  # fast & cheap

_INITIAL_TEMPLATE = """\
# Project Memory

> Auto-managed by fclaude. Updated after each session.

## Project Overview
<!-- Describe project purpose, stack, and goals here -->

## Key Architecture Decisions
<!-- Record important design choices and their rationale -->

## Important Files & Locations
<!-- Map of key files/directories and their purposes -->

## Conventions & Patterns
<!-- Coding conventions, naming, style, patterns used -->

## Known Issues & TODOs
<!-- Bugs known, tasks pending, things to revisit -->

## Recent Changes
<!-- What was done recently (auto-updated) -->
"""

_UPDATE_PROMPT = """\
You are updating a project memory document based on a conversation.

Current document:
---
{current_doc}
---

Based on the conversation above, update the document to incorporate
any NEW learnings, insights, or information valuable to preserve.

Focus on:
- New patterns or approaches discovered
- Bugs found and their root causes
- Architecture decisions made
- Important file locations or purposes
- Conventions established
- Completed TODOs

Rules:
- DO NOT duplicate existing information
- Integrate naturally into existing sections
- Keep it concise — bullet points preferred
- Update "Recent Changes" section with what was done today
- Preserve all existing content that is still relevant
{custom_instructions}

Return ONLY the updated markdown document. No preamble, no commentary.
"""


class MagicDocManager:
    """Manages a persistent project memory markdown file."""

    def __init__(self, doc_path: Optional[str] = None) -> None:
        if doc_path is None:
            doc_path = os.path.join(os.getcwd(), _DEFAULT_DOC_NAME)
        self.doc_path = Path(doc_path)
        self.custom_instructions: str = ""

    # ── Public API ──────────────────────────────────────────────────────────

    def exists(self) -> bool:
        return self.doc_path.exists()

    def initialize(self) -> None:
        """Create initial magic doc if it doesn't exist."""
        if not self.doc_path.exists():
            self.doc_path.write_text(_INITIAL_TEMPLATE, encoding="utf-8")
            log.info("[MagicDoc] Created: %s", self.doc_path)

    def load_into_context(self) -> str:
        """Return doc content to inject into system prompt, or empty string."""
        if not self.doc_path.exists():
            return ""
        try:
            content = self.doc_path.read_text(encoding="utf-8")
            if len(content.strip()) < 50:
                return ""
            return f"\n\n## Project Memory\n{content}\n"
        except Exception:
            return ""

    def update_after_session(
        self, messages: List[Dict], api_base: str, token: str, min_messages: int = 4
    ) -> bool:
        """Auto-update the magic doc based on session conversation.

        Args:
            messages:     Full conversation history.
            api_base:     API base URL.
            token:        Auth token.
            min_messages: Minimum messages before triggering update.

        Returns:
            True if doc was updated, False otherwise.
        """
        if len(messages) < min_messages:
            return False

        if not self.doc_path.exists():
            self.initialize()

        current_doc = self.doc_path.read_text(encoding="utf-8")
        transcript = self._format_transcript(messages)

        custom_section = ""
        if self.custom_instructions:
            custom_section = f"\nCustom instructions: {self.custom_instructions}\n"

        system_prompt = _UPDATE_PROMPT.format(
            current_doc=current_doc,
            custom_instructions=custom_section,
        )

        try:
            updated = self._call_api(api_base, token, system_prompt, transcript)
            if updated and len(updated.strip()) > 100:
                self.doc_path.write_text(updated, encoding="utf-8")
                log.info("[MagicDoc] Updated: %s", self.doc_path)
                return True
        except Exception as e:
            log.warning("[MagicDoc] Update failed: %s", e)

        return False

    def show_path(self) -> str:
        return str(self.doc_path)

    # ── Internal ─────────────────────────────────────────────────────────────

    def _format_transcript(self, messages: List[Dict]) -> str:
        """Format messages as a readable transcript (max 8000 chars)."""
        lines = []
        for m in messages[-30:]:  # last 30 messages max
            role = m.get("role", "?").upper()
            content = m.get("content", "")
            if isinstance(content, list):
                parts = []
                for c in content:
                    if isinstance(c, dict):
                        if c.get("type") == "text":
                            parts.append(c.get("text", ""))
                        elif c.get("type") == "tool_use":
                            parts.append(f"[Tool: {c.get('name')}]")
                        elif c.get("type") == "tool_result":
                            parts.append(f"[Result: {str(c.get('content', ''))[:100]}]")
                content = " ".join(parts)
            lines.append(f"[{role}]: {str(content)[:400]}")
        transcript = "\n".join(lines)
        return transcript[:8000]

    def _call_api(self, api_base: str, token: str, system: str, user_content: str) -> str:
        """Call Claude API to get updated doc."""
        payload = {
            "model": _UPDATE_MODEL,
            "max_tokens": 2048,
            "system": system,
            "messages": [{"role": "user", "content": user_content}],
        }
        req = urllib.request.Request(
            f"{api_base}/v1/messages",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
                "User-Agent": "fclaude/1.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
        for block in result.get("content", []):
            if block.get("type") == "text":
                return block["text"]
        return ""


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton
# ─────────────────────────────────────────────────────────────────────────────

_global_doc: Optional[MagicDocManager] = None


def get_magic_doc() -> MagicDocManager:
    global _global_doc
    if _global_doc is None:
        _global_doc = MagicDocManager()
    return _global_doc


__all__ = ["MagicDocManager", "get_magic_doc"]
