"""Git-aware file indexer for fclaude.

Inspired by fclaude internal's [FileIndex] pattern: combines git-tracked files
with untracked files, applies ignore patterns, builds background index.

Usage:
    idx = GitAwareFileIndex("/path/to/project")
    idx.build()
    files = idx.get_files()
    tree  = idx.get_tree()
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
import threading
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

# Directories always excluded from indexing
_DEFAULT_EXCLUDES: List[str] = [
    r"\.git/",
    r"\.hg/",
    r"node_modules/",
    r"__pycache__/",
    r"\.pytest_cache/",
    r"\.mypy_cache/",
    r"\.ruff_cache/",
    r"\.tox/",
    r"venv/",
    r"\.venv/",
    r"env/",
    r"\.env/",
    r"dist/",
    r"build/",
    r"\.eggs/",
    r".*\.egg-info/",
    r"\.DS_Store",
    r"Thumbs\.db",
    r"\.free-claude/cache/",
]


class GitAwareFileIndex:
    """Background file indexer that uses git ls-files as primary source.

    Mirrors the fclaude pattern:
    - Tracked files  → git ls-files
    - Untracked files → git ls-files --others --exclude-standard
    - Combined + ignore-filtered
    - Background thread, non-blocking
    """

    def __init__(self, root: str, extra_excludes: Optional[List[str]] = None) -> None:
        self.root = str(Path(root).resolve())
        self._tracked: List[str] = []
        self._untracked: List[str] = []
        self._all_files: List[str] = []
        self._ready = threading.Event()
        self._lock = threading.Lock()
        self._exclude_re = [re.compile(p) for p in (_DEFAULT_EXCLUDES + (extra_excludes or []))]

    # ── Public API ──────────────────────────────────────────────────────────

    def build(self, background: bool = True) -> None:
        """Start indexing. Non-blocking if background=True."""
        if background:
            t = threading.Thread(target=self._build_sync, daemon=True)
            t.start()
        else:
            self._build_sync()

    def wait(self, timeout: float = 10.0) -> bool:
        """Wait for background indexing to complete."""
        return self._ready.wait(timeout)

    def get_files(self, wait: bool = False) -> List[str]:
        """Return indexed files. Optionally wait for background index."""
        if wait:
            self.wait()
        with self._lock:
            return list(self._all_files)

    def get_tree(self, wait: bool = False) -> Dict:
        """Return directory tree structure."""
        files = self.get_files(wait=wait)
        return self._build_tree(files)

    def stats(self) -> Dict:
        with self._lock:
            return {
                "ready": self._ready.is_set(),
                "tracked": len(self._tracked),
                "untracked": len(self._untracked),
                "total": len(self._all_files),
                "root": self.root,
            }

    def is_git_repo(self) -> bool:
        """Check if root is a git repository."""
        return Path(self.root, ".git").exists()

    def search_files(self, pattern: str) -> List[str]:
        """Filter indexed files by glob-style or regex pattern."""
        import fnmatch

        files = self.get_files()
        try:
            return [f for f in files if fnmatch.fnmatch(f, pattern)]
        except Exception:
            rx = re.compile(pattern, re.IGNORECASE)
            return [f for f in files if rx.search(f)]

    # ── Internal ─────────────────────────────────────────────────────────────

    def _build_sync(self) -> None:
        """Build index synchronously (runs in background thread)."""
        try:
            if self.is_git_repo():
                tracked = self._git_tracked()
                untracked = self._git_untracked()
            else:
                # Fallback: walk directory
                tracked = self._walk_dir()
                untracked = []

            all_files = tracked + untracked
            filtered = self._apply_excludes(all_files)

            with self._lock:
                self._tracked = tracked
                self._untracked = untracked
                self._all_files = filtered

            log.info(
                "[FileIndex] Ready: %d tracked + %d untracked = %d files (root: %s)",
                len(tracked),
                len(untracked),
                len(filtered),
                self.root,
            )
        except Exception as e:
            log.warning("[FileIndex] Build failed: %s", e)
        finally:
            self._ready.set()

    def _git_tracked(self) -> List[str]:
        result = subprocess.run(
            ["git", "ls-files"], cwd=self.root, capture_output=True, text=True, timeout=10
        )
        if result.returncode != 0:
            return []
        return [f for f in result.stdout.strip().split("\n") if f]

    def _git_untracked(self) -> List[str]:
        result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=self.root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        files = [f for f in result.stdout.strip().split("\n") if f]
        log.debug("[FileIndex] background untracked fetch: %d files", len(files))
        return files

    def _walk_dir(self) -> List[str]:
        """Fallback: os.walk for non-git repos."""
        files = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            # Prune excluded dirs in-place
            dirnames[:] = [
                d for d in dirnames if not self._is_excluded(os.path.join(dirpath, d) + "/")
            ]
            for fn in filenames:
                rel = os.path.relpath(os.path.join(dirpath, fn), self.root)
                files.append(rel)
        return files

    def _is_excluded(self, path: str) -> bool:
        for rx in self._exclude_re:
            if rx.search(path):
                return True
        return False

    def _apply_excludes(self, files: List[str]) -> List[str]:
        before = len(files)
        result = [f for f in files if not self._is_excluded(f)]
        if before != len(result):
            log.debug("[FileIndex] applied ignore patterns: %d -> %d files", before, len(result))
        return result

    def _build_tree(self, files: List[str]) -> Dict:
        """Build nested dict tree from flat file list."""
        tree: Dict = {}
        for f in files:
            parts = Path(f).parts
            node = tree
            for part in parts[:-1]:
                node = node.setdefault(part, {})
            node[parts[-1]] = None  # leaf node
        return tree


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton per-directory
# ─────────────────────────────────────────────────────────────────────────────

_indexes: Dict[str, GitAwareFileIndex] = {}


def get_file_index(root: Optional[str] = None, start_background: bool = True) -> GitAwareFileIndex:
    """Return (and optionally start) a GitAwareFileIndex for root."""
    if root is None:
        root = os.getcwd()
    root = str(Path(root).resolve())
    if root not in _indexes:
        idx = GitAwareFileIndex(root)
        if start_background:
            idx.build(background=True)
        _indexes[root] = idx
    return _indexes[root]


__all__ = ["GitAwareFileIndex", "get_file_index"]
