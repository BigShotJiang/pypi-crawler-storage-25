"""Agent teammates and swarms — role-based AI specialists with task orchestration.

Teammates now support tool use: when tools and a tool_executor are provided,
teammates can read files, run bash commands, and interact with the filesystem
just like the main Agent — eliminating the "I don't have filesystem access" problem.
"""

import json
import logging
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)

# Maximum tool-use iterations per API call to prevent infinite loops
_MAX_TOOL_ITERATIONS = 15

# Maximum chars to keep from a single tool result
_MAX_TOOL_RESULT_CHARS = 60_000

# ── Language matching instruction (injected into every teammate) ────────
_LANGUAGE_INSTRUCTION = (
    "\n\nIMPORTANT: You MUST detect the language of the user's message and "
    "respond in the SAME language. If the user writes in Vietnamese, reply in Vietnamese. "
    "If in English, reply in English. If in Japanese, reply in Japanese. Etc. "
    "Always match the user's language — never default to English."
)


class TeammateRole(str, Enum):
    CODE_REVIEWER = "code_reviewer"
    TEST_WRITER = "test_writer"
    DOCS_WRITER = "docs_writer"
    DEBUGGER = "debugger"
    REFACTORER = "refactorer"
    ARCHITECT = "architect"
    SECURITY_AUDITOR = "security_auditor"


class TeammateStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    WORKING = "working"
    BLOCKED = "blocked"


class TaskStatus(str, Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


ROLE_DESCRIPTIONS: Dict[TeammateRole, str] = {
    TeammateRole.CODE_REVIEWER: "Review correctness, style, maintainability, and risks in code changes.",
    TeammateRole.TEST_WRITER: "Design and write tests for happy paths, edge cases, and regressions.",
    TeammateRole.DOCS_WRITER: "Write developer-facing documentation, examples, and usage guides.",
    TeammateRole.DEBUGGER: "Investigate failures, identify root causes, and suggest minimal safe fixes.",
    TeammateRole.REFACTORER: "Improve structure and readability while preserving current behavior.",
    TeammateRole.ARCHITECT: "Provide higher-level design guidance, decomposition, and trade-off analysis.",
    TeammateRole.SECURITY_AUDITOR: "Inspect security risks, unsafe defaults, and potential vulnerabilities.",
}


_SYSTEM_PROMPTS: Dict[TeammateRole, str] = {
    TeammateRole.CODE_REVIEWER: (
        "You are an expert code reviewer. Review code for correctness, style, "
        "performance, and best practices. Be concise, constructive, and specific. "
        "Respond in plain text with clear sections: Issues, Suggestions, Summary.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to inspect the actual code before giving your review."
    ),
    TeammateRole.TEST_WRITER: (
        "You are a testing specialist. Write comprehensive, maintainable tests. "
        "Cover edge cases, happy paths, and error conditions. "
        "Output working pytest/unittest code with clear docstrings.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to understand the existing code before writing tests."
    ),
    TeammateRole.DOCS_WRITER: (
        "You are a documentation expert. Write clear, concise documentation. "
        "Include usage examples. Target developers of all levels. "
        "Output clean Markdown.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to understand the code structure before writing documentation."
    ),
    TeammateRole.DEBUGGER: (
        "You are a debugging expert. Identify root causes systematically. "
        "Analyse error messages, trace execution, suggest minimal fixes. "
        "Be precise and methodical.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to inspect logs, code, and reproduce the issue."
    ),
    TeammateRole.REFACTORER: (
        "You are a refactoring expert. Suggest safe, incremental improvements. "
        "Improve readability, reduce complexity, eliminate duplication. "
        "Always preserve existing behaviour.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to understand the code before suggesting refactorings."
    ),
    TeammateRole.ARCHITECT: (
        "You are a software architect. Think long-term: scalability, maintainability, "
        "design patterns, component boundaries. Provide high-level guidance with "
        "concrete recommendations.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to understand the project structure and codebase."
    ),
    TeammateRole.SECURITY_AUDITOR: (
        "You are a security expert. Identify vulnerabilities: injection attacks, "
        "auth issues, data leaks, insecure defaults. Be thorough and err on the "
        "side of caution. Prioritise findings by severity.\n\n"
        "You have access to tools to read files, list directories, run bash commands, etc. "
        "USE THEM to inspect the code for security vulnerabilities."
    ),
}


@dataclass
class Message:
    sender: str
    receiver: str
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    task_id: Optional[str] = None
    attachments: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "sender": self.sender,
            "receiver": self.receiver,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "task_id": self.task_id,
            "attachments": self.attachments,
        }


class MessageBus:
    def __init__(self):
        self._subs: Dict[str, List[Callable]] = {}
        self.history: List[Message] = []
        self._lock = threading.Lock()

    def subscribe(self, channel: str, cb: Callable):
        with self._lock:
            self._subs.setdefault(channel, []).append(cb)

    def publish(self, msg: Message):
        with self._lock:
            self.history.append(msg)
            callbacks = self._subs.get(msg.receiver, []) + self._subs.get("*", [])
        for cb in callbacks:
            try:
                cb(msg)
            except Exception:
                pass


@dataclass
class Task:
    id: str
    title: str
    description: str
    role: str
    assigned_to: Optional[str] = None
    priority: int = 1
    status: str = TaskStatus.PENDING.value
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    updated_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    result: Optional[str] = None
    error: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "role": self.role,
            "assigned_to": self.assigned_to,
            "priority": self.priority,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "updated_at": self.updated_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result,
            "error": self.error,
            "context": self.context,
        }


class Teammate:
    """An AI specialist with role-specific instructions, its own conversation
    history, and optional tool-use capability.

    When ``tools`` and ``tool_executor`` are provided, the teammate can use
    tools (bash, read_file, write_file, list_dir, etc.) just like the main
    Agent.  This allows teammates to actually access the filesystem, run
    commands, and inspect code — instead of replying with "I don't have
    direct access to your filesystem".
    """

    def __init__(
        self,
        name: str,
        role: TeammateRole,
        message_bus: MessageBus,
        api_base: str = "",
        token: str = "",
        model: str = "claude-sonnet-4-6",
        tools: Optional[List[Dict]] = None,
        tool_executor: Optional[Callable] = None,
        on_status: Optional[Callable] = None,
    ):
        self.name = name
        self.role = role
        self.message_bus = message_bus
        self.api_base = api_base
        self.token = token
        self.model = model
        self.tools = tools or []
        self.tool_executor = tool_executor
        self.on_status = on_status  # callback for realtime UI updates
        self.status = TeammateStatus.IDLE
        self.conversation: List[Dict] = []
        self.assigned_tasks: List[Task] = []
        self.completed_tasks: List[Task] = []
        self.current_task: Optional[Task] = None
        self.last_error: Optional[str] = None
        self.last_result: Optional[str] = None
        # Track tool calls made during the last run for observability
        self.last_tool_calls: List[Dict[str, Any]] = []

    def _emit(self, event: str, detail: str = ""):
        """Emit a realtime status update via the on_status callback."""
        if self.on_status:
            try:
                self.on_status(
                    {
                        "teammate": self.name,
                        "role": self.role.value,
                        "event": event,
                        "detail": detail,
                        "timestamp": datetime.now().isoformat(),
                    }
                )
            except Exception:
                pass

    def get_system_prompt(self) -> str:
        base = _SYSTEM_PROMPTS.get(self.role, "You are a helpful AI assistant.")
        return base + _LANGUAGE_INSTRUCTION

    def run_task(self, task: Task) -> str:
        self.status = TeammateStatus.WORKING
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS.value
        task.started_at = datetime.now()
        task.updated_at = task.started_at
        self.last_error = None
        self.last_tool_calls = []

        self._emit("task_start", f"Starting: {task.title[:60]}")

        self.conversation.append(
            {
                "role": "user",
                "content": f"Task: {task.title}\n\n{task.description}",
            }
        )

        try:
            result = self._call_api_with_tools()
        except Exception as e:
            result = f"[ERROR] {str(e)}"
            task.status = TaskStatus.FAILED.value
            task.error = str(e)
            self.last_error = str(e)
            self._emit("task_error", str(e)[:100])
        else:
            task.status = TaskStatus.DONE.value
            task.result = result
            self.last_result = result
            self._emit("task_done", f"Completed: {task.title[:60]}")

        task.completed_at = datetime.now()
        task.updated_at = task.completed_at
        self.conversation.append({"role": "assistant", "content": result})
        self.completed_tasks.append(task)
        self.current_task = None
        self.status = TeammateStatus.IDLE if not self.last_error else TeammateStatus.BLOCKED

        self.message_bus.publish(
            Message(
                sender=self.name,
                receiver="leader",
                content=(
                    f"Task '{task.title}' completed"
                    if task.status == TaskStatus.DONE.value
                    else f"Task '{task.title}' failed"
                ),
                task_id=task.id,
                attachments={
                    "status": task.status,
                    "role": self.role.value,
                    "tool_calls": len(self.last_tool_calls),
                },
            )
        )
        if self.status == TeammateStatus.BLOCKED:
            self.status = TeammateStatus.IDLE
        return result

    def ask(self, question: str) -> str:
        self.status = TeammateStatus.THINKING
        self.conversation.append({"role": "user", "content": question})
        self.last_tool_calls = []
        self._emit("thinking", "Processing question...")
        try:
            result = self._call_api_with_tools()
            self.last_result = result
            self.last_error = None
        except Exception as e:
            result = f"[ERROR] {str(e)}"
            self.last_error = str(e)
        self.conversation.append({"role": "assistant", "content": result})
        self.status = TeammateStatus.IDLE
        return result

    # ── API call with tool-use loop ─────────────────────────────────────

    def _call_api_with_tools(self) -> str:
        """Call the Claude API and handle tool_use loop if tools are available.

        This is the core improvement: when tools are provided, the teammate
        enters the same kind of agentic loop as the main Agent — calling
        tools, feeding results back, and continuing until Claude says end_turn.

        Without tools, it falls back to a simple single-shot API call.
        """
        has_tools = bool(self.tools and self.tool_executor)

        for iteration in range(_MAX_TOOL_ITERATIONS):
            response = self._raw_api_call(include_tools=has_tools)

            stop_reason = response.get("stop_reason", "end_turn")
            content = response.get("content", [])

            # ── end_turn: extract final text and return ────────────────
            if stop_reason == "end_turn" or not has_tools:
                return self._extract_text(content)

            # ── tool_use: execute tools and continue ───────────────────
            if stop_reason == "tool_use":
                # Append the assistant response (with tool_use blocks) to conversation
                self.conversation.append({"role": "assistant", "content": content})

                tool_results = []
                for block in content:
                    if block.get("type") != "tool_use":
                        continue

                    tool_name = block["name"]
                    tool_input = block.get("input", {})
                    tool_id = block["id"]

                    log.info(
                        "[Teammate:%s] Tool call: %s(%s)",
                        self.name,
                        tool_name,
                        json.dumps(tool_input, ensure_ascii=False)[:200],
                    )
                    self._emit(
                        "tool_call",
                        f"{tool_name}({json.dumps(tool_input, ensure_ascii=False)[:80]})",
                    )

                    # Execute the tool
                    try:
                        result_str = str(self.tool_executor(tool_name, tool_input))
                    except Exception as e:
                        result_str = f"[ERROR] Tool execution failed: {e}"

                    # Truncate oversized results
                    if len(result_str) > _MAX_TOOL_RESULT_CHARS:
                        dropped = len(result_str) - _MAX_TOOL_RESULT_CHARS
                        result_str = (
                            result_str[:_MAX_TOOL_RESULT_CHARS]
                            + f"\n\n[... {dropped:,} chars truncated ...]"
                        )

                    # Strip vision sentinel — teammates don't handle images
                    if result_str.startswith("__IMAGE_VISION__:"):
                        result_str = (
                            "[Image file detected — image analysis not available in "
                            "teammate mode. Use the main agent for image tasks.]"
                        )

                    self.last_tool_calls.append(
                        {
                            "tool": tool_name,
                            "input": tool_input,
                            "output_length": len(result_str),
                        }
                    )
                    self._emit("tool_result", f"{tool_name} → {len(result_str)} chars")

                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": result_str,
                        }
                    )

                # Feed tool results back as a user message
                self.conversation.append({"role": "user", "content": tool_results})
                continue

            # ── Unknown stop_reason: extract text and return ───────────
            return self._extract_text(content)

        # If we hit the iteration limit, extract whatever we have
        log.warning(
            "[Teammate:%s] Hit max tool iterations (%d)",
            self.name,
            _MAX_TOOL_ITERATIONS,
        )
        return self._extract_text(content)

    def _raw_api_call(self, include_tools: bool = False) -> dict:
        """Make a single API call to Claude and return the full response dict."""
        # Filter conversation: remove empty messages that can cause API errors
        clean_messages = []
        for msg in self.conversation[-40:]:
            if isinstance(msg.get("content"), str) and not msg["content"].strip():
                continue
            if isinstance(msg.get("content"), list) and not msg["content"]:
                continue
            clean_messages.append(msg)

        if not clean_messages:
            raise RuntimeError("No messages to send to API")

        payload: Dict[str, Any] = {
            "model": self.model,
            "max_tokens": 8192,
            "system": self.get_system_prompt(),
            "messages": clean_messages,
        }
        if include_tools and self.tools:
            payload["tools"] = self.tools

        log.debug(
            "[Teammate:%s] API call: model=%s, messages=%d, tools=%s",
            self.name,
            self.model,
            len(clean_messages),
            len(self.tools) if include_tools else 0,
        )

        req = urllib.request.Request(
            f"{self.api_base}/v1/messages",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
                "User-Agent": "fclaude/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode()[:500]
            except Exception:
                pass
            log.error("[Teammate:%s] API HTTP %d: %s", self.name, e.code, body)
            raise RuntimeError(f"API error {e.code}: {body[:200]}") from e

    @staticmethod
    def _extract_text(content: list) -> str:
        """Extract concatenated text from API content blocks."""
        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block["text"])
        return " ".join(texts).strip() if texts else ""

    # ── Legacy: simple single-shot call (kept for backward compat) ─────

    def _call_api(self) -> str:
        """Simple single-shot API call without tool support.

        Deprecated: use _call_api_with_tools() instead.
        """
        return self._call_api_with_tools()

    def get_status(self) -> Dict[str, Any]:
        active_tasks = sum(
            1
            for t in self.assigned_tasks
            if t.status
            in {
                TaskStatus.PENDING.value,
                TaskStatus.ASSIGNED.value,
                TaskStatus.IN_PROGRESS.value,
                TaskStatus.BLOCKED.value,
            }
        )
        return {
            "role": self.role.value,
            "status": self.status.value,
            "tasks_assigned": len(self.assigned_tasks),
            "active_tasks": active_tasks,
            "tasks_completed": len(self.completed_tasks),
            "current_task": self.current_task.title if self.current_task else None,
            "last_task": self.completed_tasks[-1].title if self.completed_tasks else None,
            "last_error": self.last_error,
            "conversation_turns": len(self.conversation) // 2,
            "tools_available": len(self.tools),
            "last_tool_calls": len(self.last_tool_calls),
        }


class TaskCoordinator:
    def __init__(self, message_bus: MessageBus):
        self.message_bus = message_bus
        self.tasks: Dict[str, Task] = {}
        self._by_role: Dict[TeammateRole, List[Teammate]] = {}
        self._lock = threading.Lock()

    def register(self, teammate: Teammate):
        with self._lock:
            self._by_role.setdefault(teammate.role, []).append(teammate)

    def unregister(self, teammate: Teammate):
        with self._lock:
            teammates = self._by_role.get(teammate.role, [])
            self._by_role[teammate.role] = [tm for tm in teammates if tm.name != teammate.name]
            if not self._by_role[teammate.role]:
                self._by_role.pop(teammate.role, None)

    def create_task(
        self,
        title: str,
        description: str,
        role: Optional[TeammateRole] = None,
        priority: int = 1,
        context: Dict[str, Any] = None,
    ) -> Task:
        now = datetime.now()
        task = Task(
            id=f"task_{now.strftime('%H%M%S_%f')}",
            title=title,
            description=description,
            role=role.value if role else "unassigned",
            priority=priority,
            context=context or {},
            updated_at=now,
        )
        with self._lock:
            self.tasks[task.id] = task
        return task

    @staticmethod
    def _active_load(teammate: Teammate) -> int:
        return sum(
            1
            for task in teammate.assigned_tasks
            if task.status
            in {
                TaskStatus.PENDING.value,
                TaskStatus.ASSIGNED.value,
                TaskStatus.IN_PROGRESS.value,
                TaskStatus.BLOCKED.value,
            }
        )

    def assign_to_role(self, task: Task, role: TeammateRole) -> Optional[Teammate]:
        with self._lock:
            candidates = list(self._by_role.get(role, []))
        if not candidates:
            return None
        candidates.sort(key=lambda tm: (self._active_load(tm), tm.name))
        teammate = candidates[0]
        task.assigned_to = teammate.name
        task.status = TaskStatus.ASSIGNED.value
        task.updated_at = datetime.now()
        teammate.assigned_tasks.append(task)
        return teammate

    def get_task(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self.tasks.get(task_id)

    def get_tasks(self, status: Optional[str] = None) -> List[Task]:
        with self._lock:
            tasks = list(self.tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        return sorted(tasks, key=lambda t: (t.created_at, t.priority), reverse=True)

    def get_pending_tasks(self) -> List[Task]:
        return self.get_tasks(TaskStatus.PENDING.value)

    def get_active_tasks(self) -> List[Task]:
        return [
            t
            for t in self.get_tasks()
            if t.status
            in {
                TaskStatus.ASSIGNED.value,
                TaskStatus.IN_PROGRESS.value,
                TaskStatus.BLOCKED.value,
            }
        ]


class AgentTeam:
    """Orchestrates a team of AI specialists.

    When ``tools`` and ``tool_executor`` are provided, every teammate created
    by this team will inherit tool access — allowing them to read files,
    run bash commands, and interact with the codebase.
    """

    def __init__(
        self,
        api_base: str = "",
        token: str = "",
        model: str = "claude-sonnet-4-6",
        tools: Optional[List[Dict]] = None,
        tool_executor: Optional[Callable] = None,
        on_status: Optional[Callable] = None,
    ):
        self.api_base = api_base
        self.token = token
        self.model = model
        self.tools = tools or []
        self.tool_executor = tool_executor
        self.on_status = on_status  # callback passed to all teammates
        self.message_bus = MessageBus()
        self.coordinator = TaskCoordinator(self.message_bus)
        self.teammates: Dict[str, Teammate] = {}
        self._workers: Dict[str, threading.Thread] = {}
        self._lock = threading.Lock()

    def set_runtime(
        self,
        token: Optional[str] = None,
        model: Optional[str] = None,
        tools: Optional[List[Dict]] = None,
        tool_executor: Optional[Callable] = None,
        on_status: Optional[Callable] = None,
    ):
        if token is not None:
            self.token = token
        if model is not None:
            self.model = model
        if tools is not None:
            self.tools = tools
        if tool_executor is not None:
            self.tool_executor = tool_executor
        if on_status is not None:
            self.on_status = on_status
        # Propagate to all existing teammates
        for teammate in self.teammates.values():
            if token is not None:
                teammate.token = token
            if model is not None:
                teammate.model = model
            if tools is not None:
                teammate.tools = tools
            if tool_executor is not None:
                teammate.tool_executor = tool_executor
            if on_status is not None:
                teammate.on_status = on_status

    def _make_name(self, role: TeammateRole) -> str:
        idx = 1
        while f"{role.value}_{idx}" in self.teammates:
            idx += 1
        return f"{role.value}_{idx}"

    def add_teammate(self, name: Optional[str], role: TeammateRole) -> Teammate:
        actual_name = name or self._make_name(role)
        if actual_name in self.teammates:
            raise ValueError(f"Teammate '{actual_name}' already exists")
        tm = Teammate(
            actual_name,
            role,
            self.message_bus,
            self.api_base,
            self.token,
            self.model,
            tools=self.tools,
            tool_executor=self.tool_executor,
            on_status=self.on_status,
        )
        self.teammates[actual_name] = tm
        self.coordinator.register(tm)
        return tm

    def remove_teammate(self, name: str) -> bool:
        teammate = self.teammates.get(name)
        if not teammate:
            return False
        if teammate.current_task is not None:
            return False
        self.coordinator.unregister(teammate)
        del self.teammates[name]
        return True

    def get_teammate(self, name: str) -> Optional[Teammate]:
        return self.teammates.get(name)

    def delegate_task(
        self,
        title: str,
        description: str,
        role: TeammateRole,
        priority: int = 1,
        run_async: bool = True,
        context: Dict[str, Any] = None,
    ) -> Task:
        task = self.coordinator.create_task(title, description, role, priority, context)
        teammate = self.coordinator.assign_to_role(task, role)
        if not teammate:
            return task

        if run_async:
            worker = threading.Thread(target=teammate.run_task, args=(task,), daemon=True)
            with self._lock:
                self._workers[task.id] = worker
            worker.start()
        else:
            teammate.run_task(task)
        return task

    def ask_teammate(self, role: TeammateRole, question: str) -> Optional[str]:
        candidates = sorted(
            self.coordinator._by_role.get(role, []),
            key=lambda tm: (tm.status != TeammateStatus.IDLE, tm.name),
        )
        if not candidates:
            return None
        return candidates[0].ask(question)

    def get_task(self, task_id: str) -> Optional[Task]:
        return self.coordinator.get_task(task_id)

    def list_tasks(self, status: Optional[str] = None) -> List[Task]:
        if status == "active":
            return self.coordinator.get_active_tasks()
        if status == "all" or status is None:
            return self.coordinator.get_tasks()
        return self.coordinator.get_tasks(status)

    def wait_for_task(self, task_id: str, timeout: Optional[float] = None) -> bool:
        with self._lock:
            worker = self._workers.get(task_id)
        if not worker:
            return True
        worker.join(timeout=timeout)
        return not worker.is_alive()

    def get_team_status(self) -> Dict[str, Dict[str, Any]]:
        return {name: tm.get_status() for name, tm in self.teammates.items()}

    def get_message_history(self) -> List[Dict[str, Any]]:
        return [m.to_dict() for m in self.message_bus.history]

    def list_roles(self) -> List[TeammateRole]:
        return list(TeammateRole)

    def role_descriptions(self) -> Dict[str, str]:
        return {role.value: ROLE_DESCRIPTIONS[role] for role in TeammateRole}

    def broadcast(self, content: str):
        self.message_bus.publish(Message(sender="leader", receiver="broadcast", content=content))


__all__ = [
    "Teammate",
    "AgentTeam",
    "TaskCoordinator",
    "MessageBus",
    "Task",
    "Message",
    "TeammateRole",
    "TeammateStatus",
    "TaskStatus",
    "ROLE_DESCRIPTIONS",
]
