"""PluginMixin — MCP plugin loading and management for Agent."""

from __future__ import annotations

import contextlib
import io
import shutil
import threading
import time
from typing import TYPE_CHECKING

from . import rich_ui as ui
from .mcp import StdioMCPClient, create_mcp_client, discover_plugins

if TYPE_CHECKING:
    pass


class PluginMixin:
    """Mixin that provides MCP plugin loading and management methods."""

    # ── Plugin loading ─────────────────────────────────────────────────

    def _auto_load_plugins(self):
        """Auto-discover and load MCP plugins in parallel with progress feedback."""
        from rich.text import Text

        plugins = discover_plugins()
        if not plugins:
            return

        _AUTOLOAD_WHITELIST = {"context7", "serena", "playwright"}

        candidates = {}
        skipped_reasons = {}
        for name, config in plugins.items():
            transport = config.get("type", "stdio")
            headers = config.get("headers", {})
            if name not in _AUTOLOAD_WHITELIST:
                skipped_reasons[name] = f"not in auto-load list — use: fclaude --plugin {name}"
                continue
            if any("${" in v for v in headers.values()):
                skipped_reasons[name] = "needs API key (env var not set)"
                continue
            if transport == "stdio":
                cmd = config.get("command", "")
                from .compat import resolve_command

                if cmd and not shutil.which(resolve_command(cmd)):
                    install_hint = {
                        "npx": "install Node.js: brew install node (macOS) | apt install nodejs npm (Linux)",
                        "node": "install Node.js: brew install node (macOS) | apt install nodejs npm (Linux)",
                        "uvx": "install uv: pip install uv  OR  curl -Lsf https://astral.sh/uv/install.sh | sh",
                        "php": "install PHP: brew install php (macOS) | apt install php (Linux)",
                    }.get(cmd, f"install {cmd!r} and ensure it is on your PATH")
                    skipped_reasons[name] = f"command not found: {cmd!r} — {install_hint}"
                    continue
            candidates[name] = config

        if not candidates:
            if plugins and skipped_reasons:
                ui.console.print(
                    Text.assemble(
                        ("  ⚙ ", "dim"),
                        ("MCP: ", "dim cyan"),
                        (f"0/{len(plugins)} plugins available ", "dim"),
                        ("(run 'fclaude --plugins' to see requirements)", "dim"),
                    )
                )
            return

        results_lock = threading.Lock()
        loaded_clients = []  # list of (client, new_tools)

        def _try_start_one(name, config):
            try:
                client = create_mcp_client(name, config)
                success_holder = [False]

                def _start():
                    buf = io.StringIO()
                    try:
                        with contextlib.redirect_stdout(buf):
                            success_holder[0] = client.start(verbose=False)
                    except Exception:
                        success_holder[0] = False

                st = threading.Thread(target=_start, daemon=True)
                st.start()
                st.join(timeout=35)

                if success_holder[0]:
                    new_tools = client.get_tool_definitions()
                    with results_lock:
                        loaded_clients.append((client, new_tools))
            except Exception:
                pass

        workers = []
        for name, config in candidates.items():
            w = threading.Thread(target=_try_start_one, args=(name, config), daemon=True)
            workers.append(w)
            w.start()

        deadline = time.monotonic() + 45.0
        while any(w.is_alive() for w in workers):
            if time.monotonic() > deadline:
                break
            time.sleep(0.05)
        for w in workers:
            w.join(timeout=0.05)

        loaded_names = []
        for client, new_tools in loaded_clients:
            self.mcp_clients.append(client)
            self.tools.extend(new_tools)
            loaded_names.append(f"{client.name}({len(new_tools)})")

        ok = len(loaded_clients)
        if ok > 0:
            ui.console.print(
                Text.assemble(
                    ("  ✓ ", "bold green"),
                    ("MCP: ", "dim cyan"),
                    (f"{ok} plugin{'s' if ok != 1 else ''} loaded", "green"),
                    (f" — {', '.join(loaded_names)}", "dim"),
                )
            )
        if skipped_reasons:
            ui.console.print(
                Text.assemble(
                    ("  ⚙ ", "dim"),
                    (
                        f"{len(skipped_reasons)} plugin{'s' if len(skipped_reasons) != 1 else ''} skipped",
                        "dim",
                    ),
                    (" (run 'fclaude --plugins' for details)", "dim"),
                )
            )

    def _load_plugin(self, parts: list):
        """Load a plugin by name (/plugin <name>)."""
        if len(parts) < 2:
            ui.print_info("Usage: /plugin <name>")
            return
        plugin_name = parts[1]
        available = discover_plugins()
        if plugin_name not in available:
            ui.print_error(f"Plugin '{plugin_name}' not found. Use /plugins to list.")
            return
        try:
            client = create_mcp_client(plugin_name, available[plugin_name])
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"Plugin [{plugin_name}]: {len(new_tools)} tools added")
        except Exception as e:
            ui.print_error(f"Plugin error: {e}")

    def _add_mcp(self, parts: list):
        """Add a raw stdio MCP server (/mcp <name> <command> [args...])."""
        if len(parts) >= 3:
            name, mcp_cmd = parts[1], parts[2:]
            client = StdioMCPClient(name, mcp_cmd)
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"MCP [{name}]: {len(new_tools)} tools added")
        else:
            ui.print_info("Usage: /mcp <name> <command> [args...]")
            for c in self.mcp_clients:
                ui.print_info(f"Active: {c.name} ({len(c.tools)} tools)")

    def _wait_for_plugins(self, timeout: float = 12.0):
        """Wait for background plugin loading to finish."""
        if self._bg_plugin_thread and self._bg_plugin_thread.is_alive():
            self._bg_plugin_thread.join(timeout=timeout)
