"""Authentication for free-claude.

Token resolution order (highest priority first):
  1. FREE_CLAUDE_TOKEN env var   — CI/CD, Docker, scripts
  2. ~/.config/free-claude/token.json — saved via 'fclaude token set' or 'fclaude-login'
  3. Error — prompt user to set token
"""

import base64
import hashlib
import json
import os
import secrets
import threading
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

from .compat import secure_file
from .config import OAUTH_CONFIG, TOKEN_FILE

# Env var name for direct token injection (CI/CD, Docker, scripts)
TOKEN_ENV_VAR = "FREE_CLAUDE_TOKEN"


def ensure_config_dir():
    os.makedirs(os.path.dirname(TOKEN_FILE), exist_ok=True)


def is_logged_in() -> bool:
    """True if token is available via env var OR saved token file."""
    return bool(os.environ.get(TOKEN_ENV_VAR)) or os.path.exists(TOKEN_FILE)


def _jwt_expiring_soon(token_str, threshold_seconds=300):
    """Check if a JWT token will expire within threshold_seconds (default 5 min).

    Decodes JWT payload (base64) without verification — we only need the exp claim.
    Returns True if token expires soon or is already expired, False otherwise.
    Returns False on any decode error (treat as not expiring).
    """
    import time

    try:
        parts = token_str.split(".")
        if len(parts) != 3:
            return False
        # Decode payload (part 1), add padding
        payload_b64 = parts[1]
        payload_b64 += "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        exp = payload.get("exp")
        if exp is None:
            return False
        return (exp - time.time()) < threshold_seconds
    except Exception:
        return False


def get_token() -> str:
    """Get auth token. Checks env var first, then token file.

    For gateway tokens: auto-refreshes if token expires within 5 minutes.
    """
    # Priority 1: env var (CI/CD, Docker, quick scripts)
    env_token = os.environ.get(TOKEN_ENV_VAR, "").strip()
    if env_token:
        return env_token

    # Priority 2: saved token file
    if not os.path.exists(TOKEN_FILE):
        print("❌ Not logged in.")
        print("   Option 1 (quick): export FREE_CLAUDE_TOKEN=<your_token>")
        print("   Option 2 (save):  fclaude token set <your_token>")
        print("   Option 3 (OAuth): fclaude-login")
        raise SystemExit(1)
    with open(TOKEN_FILE) as f:
        saved = json.load(f)

    access_token = saved.get("accessToken", "")

    # Auto-refresh gateway tokens if expiring soon (< 5 min)
    if saved.get("source") == "gateway" and access_token:
        if _jwt_expiring_soon(access_token, threshold_seconds=300):
            refreshed = gateway_refresh()
            if refreshed:
                return refreshed

    return access_token


def set_token(token: str) -> None:
    """Save a token directly to the token file. Cross-platform."""
    token = token.strip()
    if not token:
        raise ValueError("Token cannot be empty")
    ensure_config_dir()
    token_data = {
        "accessToken": token,
        "refreshToken": None,
        "source": "manual",
    }
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_data, f, indent=2)
    secure_file(TOKEN_FILE)


def clear_token() -> bool:
    """Remove saved token file. Returns True if file existed."""
    if os.path.exists(TOKEN_FILE):
        os.remove(TOKEN_FILE)
        return True
    return False


def show_token() -> str:
    """Return masked token for display (shows first 8 + last 4 chars)."""
    env_token = os.environ.get(TOKEN_ENV_VAR, "").strip()
    source = "env var" if env_token else "file"
    try:
        token = get_token()
        if len(token) > 12:
            masked = token[:8] + "..." + token[-4:]
        else:
            masked = token[:4] + "..."
        return masked, source
    except SystemExit:
        return None, None


def refresh_token() -> str:
    """Refresh access token. Tries gateway first, then legacy OAuth."""
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as f:
        saved = json.load(f)

    # Gateway tokens: use gateway refresh
    if saved.get("source") == "gateway":
        return gateway_refresh()

    if not saved.get("refreshToken"):
        return saved.get("accessToken")
    try:
        data = {
            "grant_type": "refresh_token",
            "refresh_token": saved["refreshToken"],
            "client_id": OAUTH_CONFIG["clientId"],
        }
        req = urllib.request.Request(
            OAUTH_CONFIG["tokenUrl"],
            data=json.dumps(data).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
        saved["accessToken"] = result["access_token"]
        if "refresh_token" in result:
            saved["refreshToken"] = result["refresh_token"]
        ensure_config_dir()
        with open(TOKEN_FILE, "w") as f:
            json.dump(saved, f, indent=2)
        return saved["accessToken"]
    except Exception:
        return saved.get("accessToken")


def _gen_verifier() -> str:
    return base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode()


def _gen_challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode()).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def login(open_browser: bool = True) -> str:
    """Full OAuth PKCE login flow. Returns access token."""
    verifier = _gen_verifier()
    challenge = _gen_challenge(verifier)
    state = secrets.token_urlsafe(32)

    auth_code = [None]
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            if parsed.path == "/code" and "code" in params:
                auth_code[0] = params["code"][0]
                html = (
                    b"<html><body><h1>Login successful!</h1>"
                    b"<p>You can close this window.</p>"
                    b"<script>window.close()</script></body></html>"
                )
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(html)
                done.set()
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(("localhost", 3000), Handler)
    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()

    params = {
        "client_id": OAUTH_CONFIG["clientId"],
        "response_type": "code",
        "redirect_uri": OAUTH_CONFIG["redirectUri"],
        "scope": OAUTH_CONFIG["scope"],
        "audience": OAUTH_CONFIG["audience"],
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    url = f"{OAUTH_CONFIG['authorizeUrl']}?{urllib.parse.urlencode(params)}"

    print("\n🌐 Opening browser for login...")
    print(f"   URL: {url}\n")
    if open_browser:
        webbrowser.open(url)
    print("⏳ Waiting for callback... (120s timeout)")

    done.wait(timeout=120)
    server.shutdown()

    if not auth_code[0]:
        raise RuntimeError("Login timeout - no authorization code received")

    # Exchange code for tokens
    data = {
        "grant_type": "authorization_code",
        "code": auth_code[0],
        "redirect_uri": OAUTH_CONFIG["redirectUri"],
        "client_id": OAUTH_CONFIG["clientId"],
        "code_verifier": verifier,
    }
    req = urllib.request.Request(
        OAUTH_CONFIG["tokenUrl"],
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        tokens = json.loads(resp.read())

    ensure_config_dir()
    token_data = {
        "accessToken": tokens["access_token"],
        "refreshToken": tokens.get("refresh_token"),
        "idToken": tokens.get("id_token"),
        "expiresIn": tokens.get("expires_in"),
    }
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_data, f, indent=2)
    # Cross-platform file permission hardening (Unix: chmod 600, Windows: icacls)
    secure_file(TOKEN_FILE)
    print(f"\n✅ Logged in! Token saved to {TOKEN_FILE}")
    return tokens["access_token"]


# ── Gateway Authentication ─────────────────────────────────────────────────
# These functions talk to the fclaude Gateway (Cloudflare Workers) for
# user registration, login, and token refresh — no OAuth/external auth needed.


def _gateway_request(method, path, data=None, token=None):
    """Make an HTTP request to the Gateway. Uses Node.js fetch for TLS 1.3 compat."""
    import subprocess

    from .config import GATEWAY_URL

    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    # Try Python urllib first
    try:
        req = urllib.request.Request(
            f"{GATEWAY_URL}{path}",
            data=json.dumps(data).encode() if data else None,
            headers=headers,
            method=method,
        )
        req.add_header("User-Agent", "fclaude/1.0")
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        # 403 from Cloudflare = User-Agent/TLS block, fall through to Node
        if e.code == 403:
            pass  # Try Node fallback below
        else:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            return e.code, body
    except Exception:
        pass  # SSL error etc → try Node

    # Fallback: use Node.js fetch (handles modern TLS/ECH)
    try:
        js_headers = json.dumps(headers)
        js_body = f"body: JSON.stringify({json.dumps(data)})," if data else ""
        js_code = f"""
        const r = await fetch("{GATEWAY_URL}{path}", {{
            method: "{method}",
            headers: {js_headers},
            {js_body}
        }});
        const text = await r.text();
        console.log(JSON.stringify({{status: r.status, body: text}}));
        """
        result = subprocess.run(
            ["node", "--input-type=module", "-e", js_code],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0:
            parsed = json.loads(result.stdout.strip())
            body = json.loads(parsed["body"]) if parsed["body"] else {}
            return parsed["status"], body
    except Exception:
        pass

    return 0, {"error": "Cannot connect to gateway. Check your network connection."}


def _save_gateway_token(data):
    """Save gateway token data to disk."""
    ensure_config_dir()
    from .config import GATEWAY_URL

    token_data = {
        "accessToken": data["access_token"],
        "refreshToken": data.get("refresh_token", ""),
        "gateway": GATEWAY_URL,
        "plan": data.get("plan", "free"),
        "source": "gateway",
    }
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_data, f, indent=2)
    secure_file(TOKEN_FILE)


def gateway_register(email, username, password, invite_code):
    """Register a new account on the fclaude Gateway.

    Returns (success: bool, data: dict)
    - success=True, data has access_token  -> registration complete
    - success=False, data has requires_verification -> need OTP
    - success=False, data has error -> registration failed
    """
    status, data = _gateway_request(
        "POST",
        "/auth/register",
        {
            "email": email,
            "username": username,
            "password": password,
            "invite_code": invite_code,
        },
    )

    if status == 202 and data.get("requires_verification"):
        # Email OTP required - caller must handle verification flow
        return False, data

    if status == 201 and data.get("access_token"):
        _save_gateway_token(data)
        return True, data

    return False, data


def gateway_verify_email(email, code):
    """Verify email OTP code to complete registration.

    Returns (success: bool, data: dict)
    """
    status, data = _gateway_request(
        "POST",
        "/auth/verify-email",
        {"email": email, "code": code},
    )

    if status == 201 and data.get("access_token"):
        _save_gateway_token(data)
        return True, data

    return False, data


def gateway_login(email, password):
    """Login to the fclaude Gateway.

    Returns (success: bool, data: dict)
    """
    status, data = _gateway_request(
        "POST",
        "/auth/login",
        {
            "email": email,
            "password": password,
        },
    )

    if status == 200 and data.get("access_token"):
        _save_gateway_token(data)
        return True, data

    return False, data


def gateway_refresh():
    """Refresh access token using the Gateway refresh endpoint.

    Returns new access token or None.
    """
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as f:
        saved = json.load(f)

    if saved.get("source") != "gateway":
        return None  # Not a gateway token, use legacy refresh

    refresh_tok = saved.get("refreshToken")
    if not refresh_tok:
        return saved.get("accessToken")

    status, data = _gateway_request("POST", "/auth/refresh", token=refresh_tok)

    if status == 200 and data.get("access_token"):
        saved["accessToken"] = data["access_token"]
        if data.get("refresh_token"):
            saved["refreshToken"] = data["refresh_token"]
        ensure_config_dir()
        with open(TOKEN_FILE, "w") as f:
            json.dump(saved, f, indent=2)
        return data["access_token"]

    return saved.get("accessToken")


def gateway_me(token=None):
    """Get current user info from Gateway.

    Returns (success: bool, data: dict)
    """
    if token is None:
        try:
            token = get_token()
        except SystemExit:
            return False, {"error": "Not logged in"}

    status, data = _gateway_request("GET", "/auth/me", token=token)
    return status == 200, data
