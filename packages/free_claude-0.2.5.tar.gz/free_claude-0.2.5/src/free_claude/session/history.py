"""Session history — persist and reload conversation sessions."""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..compat import CONFIG_DIR

_log = logging.getLogger(__name__)


_SESSIONS_DIR = CONFIG_DIR / "sessions"


@dataclass
class Session:
    """A saved conversation session."""

    id: str
    title: str
    model: str
    messages: List[Dict] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    tags: List[str] = field(default_factory=list)

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def preview(self) -> str:
        """First user message as preview."""
        for m in self.messages:
            if m.get("role") == "user":
                content = m.get("content", "")
                if isinstance(content, str):
                    return content[:80]
        return "(empty)"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "model": self.model,
            "messages": self.messages,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Session":
        return cls(**d)


class SessionHistory:
    """
    Manages saved conversation sessions on disk.

    Sessions stored as JSON files in the OS-appropriate config directory:
        - Linux:   ~/.config/free-claude/sessions/
        - macOS:   ~/Library/Application Support/free-claude/sessions/
        - Windows: %APPDATA%/free-claude/sessions/

    Usage:
        history = SessionHistory()
        session = history.save(messages, model="claude-opus-4-6", title="Debug session")
        history.list()                   # → [Session, ...]
        history.load("abc123")           # → Session
        history.delete("abc123")
    """

    def __init__(self, sessions_dir: Path = None):
        self._dir = Path(sessions_dir) if sessions_dir else _SESSIONS_DIR
        self._dir.mkdir(parents=True, exist_ok=True)

    def save(
        self,
        messages: List[Dict],
        model: str,
        title: str = None,
        session_id: str = None,
        tags: List[str] = None,
    ) -> Session:
        """Save a conversation. Returns the saved Session."""
        sid = session_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        # Auto-generate title from first user message
        if not title:
            for m in messages:
                if m.get("role") == "user":
                    content = m.get("content", "")
                    if isinstance(content, str):
                        title = content[:50]
                        break
            title = title or "Untitled session"

        session = Session(
            id=sid,
            title=title,
            model=model,
            messages=messages,
            tags=tags or [],
        )
        self._write(session)
        return session

    def load(self, session_id: str) -> Optional[Session]:
        """Load a session by ID."""
        path = self._dir / f"{session_id}.json"
        if not path.exists():
            # Try partial match
            matches = list(self._dir.glob(f"{session_id}*.json"))
            if len(matches) == 1:
                path = matches[0]
            elif not matches:
                return None
            else:
                return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Session.from_dict(data)
        except json.JSONDecodeError as e:
            _log.warning("Session file %s is corrupted: %s", path, e)
            return None
        except Exception as e:
            _log.error("Failed to load session %s: %s", path, e)
            return None

    def list(self, limit: int = 20) -> List[Session]:
        """List recent sessions, newest first."""
        sessions = []
        for path in sorted(self._dir.glob("*.json"), reverse=True)[:limit]:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                sessions.append(Session.from_dict(data))
            except json.JSONDecodeError:
                _log.warning("Skipping corrupted session file: %s", path.name)
                continue
            except Exception as e:
                _log.error("Error reading session %s: %s", path.name, e)
                continue
        return sessions

    def delete(self, session_id: str) -> bool:
        """Delete a session by ID."""
        path = self._dir / f"{session_id}.json"
        if path.exists():
            path.unlink()
            return True
        return False

    def update(self, session_id: str, messages: List[Dict]) -> bool:
        """Update messages in an existing session."""
        session = self.load(session_id)
        if not session:
            return False
        session.messages = messages
        session.updated_at = datetime.now().isoformat()
        self._write(session)
        return True

    def _write(self, session: Session):
        path = self._dir / f"{session.id}.json"
        try:
            path.write_text(
                json.dumps(session.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except PermissionError as e:
            _log.error("Permission denied writing session %s: %s", session.id, e)
            raise
        except Exception as e:
            _log.error("Failed to write session %s: %s", session.id, e)
            raise


__all__ = ["SessionHistory", "Session"]
