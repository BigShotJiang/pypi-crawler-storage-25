"""UIMixin — display helpers (usage, config, help, team UI) for Agent."""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import rich_ui as ui
from .teammates import ROLE_DESCRIPTIONS, TaskStatus

if TYPE_CHECKING:
    pass


class UIMixin:
    """Mixin that provides display/UI helper methods."""

    def _show_usage(self):
        from rich import box
        from rich.table import Table

        summary = self._ctx.usage_summary()
        rl = self._rate_limits

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
            show_edge=True,
        )
        table.add_column("Metric", style="yellow", min_width=26, no_wrap=True)
        table.add_column("Value", style="white", justify="right")

        table.add_row("[bold]Session[/bold]", "")
        table.add_row("  Requests", str(summary["requests"]))
        table.add_row("  Input tokens", f"{summary['input_tokens']:,}")
        table.add_row("  Output tokens", f"{summary['output_tokens']:,}")
        table.add_row("  Total tokens", f"[bold]{summary['total_tokens']:,}[/bold]")

        if rl:
            table.add_row("", "")
            table.add_row("[bold]Rate Limits[/bold]", "")
            table.add_row(
                "  Input tokens  (remaining/limit)",
                f"{rl.get('anthropic-ratelimit-input-tokens-remaining', '?')} / "
                f"{rl.get('anthropic-ratelimit-input-tokens-limit', '?')}",
            )
            table.add_row(
                "  Output tokens (remaining/limit)",
                f"{rl.get('anthropic-ratelimit-output-tokens-remaining', '?')} / "
                f"{rl.get('anthropic-ratelimit-output-tokens-limit', '?')}",
            )
            table.add_row(
                "  Requests      (remaining/limit)",
                f"{rl.get('anthropic-ratelimit-requests-remaining', '?')} / "
                f"{rl.get('anthropic-ratelimit-requests-limit', '?')}",
            )
            table.add_row("  Resets at", rl.get("anthropic-ratelimit-tokens-reset", "?"))
        else:
            table.add_row("", "")
            table.add_row("[dim]Rate limits[/dim]", "[dim](make a request first)[/dim]")

        table.add_row("", "")
        table.add_row("Cost", "[bold green]$0.00 — FREE! 🎉[/bold green]")
        ui.console.print()
        ui.console.print(table)
        ui.console.print()

    def _show_config(self):
        from rich import box
        from rich.table import Table

        from .app_config import _CONFIG_FILE
        from .app_config import config as app_config

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
            show_edge=True,
        )
        table.add_column("Key", style="yellow", min_width=22, no_wrap=True)
        table.add_column("Value", style="white")
        table.add_column("Source", style="dim", justify="center")

        file_exists = _CONFIG_FILE.exists()

        for k, v in app_config._data.items():
            table.add_row(k, str(v), "file" if file_exists else "default")

        ui.console.print()
        ui.console.print(f"[dim]Config file: {_CONFIG_FILE}[/dim]")
        ui.console.print(table)
        ui.console.print(
            f"[dim]Set inline: [cyan]/config key value[/cyan] · Or edit {_CONFIG_FILE} and restart.[/dim]"
        )
        ui.console.print()

    def _show_help(self):
        ui.print_help()

    def _show_teammate_roles(self):
        from rich import box
        from rich.table import Table

        table = Table(
            title="Teammate roles",
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
            show_edge=True,
        )
        table.add_column("Role", style="yellow", no_wrap=True)
        table.add_column("Use it for", style="white")
        for role, desc in ROLE_DESCRIPTIONS.items():
            table.add_row(role.value, desc)
        ui.console.print()
        ui.console.print(table)
        ui.console.print("[dim]Example:[/dim] [cyan]/teammate add debugger[/cyan]")
        ui.console.print()

    def _show_task_detail(self, task):
        from rich.console import Group
        from rich.panel import Panel
        from rich.text import Text

        body = Group(
            Text.assemble(("ID: ", "bold"), (task.id, "yellow")),
            Text.assemble(("Role: ", "bold"), (task.role, "cyan")),
            Text.assemble(("Assigned: ", "bold"), ((task.assigned_to or "unassigned"), "white")),
            Text.assemble(
                ("Status: ", "bold"),
                (task.status, "green" if task.status == TaskStatus.DONE.value else "yellow"),
            ),
            Text.assemble(("Priority: ", "bold"), (str(task.priority), "magenta")),
            Text.assemble(
                ("Created: ", "bold"), (task.created_at.strftime("%Y-%m-%d %H:%M:%S"), "dim")
            ),
            Text.assemble(
                ("Started: ", "bold"),
                (task.started_at.strftime("%Y-%m-%d %H:%M:%S") if task.started_at else "-", "dim"),
            ),
            Text.assemble(
                ("Completed: ", "bold"),
                (
                    task.completed_at.strftime("%Y-%m-%d %H:%M:%S") if task.completed_at else "-",
                    "dim",
                ),
            ),
            Text(""),
            Text("Description", style="bold cyan"),
            Text(task.description),
        )
        ui.console.print()
        ui.console.print(Panel(body, title=f"Task {task.id}", border_style="cyan"))
        if task.result:
            ui.console.print(Panel(task.result, title="Result", border_style="green"))
        elif task.error:
            ui.console.print(Panel(task.error, title="Error", border_style="red"))
        ui.console.print()
