//! `aegis-verifier-py` — `PyO3` 0.28 + abi3-py311 Python bindings for Aegis.
//!
//! Exposes a single top-level function [`verify_inclusion`] and a
//! [`VerificationResult`] dataclass to Python 3.11+.
//!
//! # Domain separation
//!
//! All ML-DSA-65 signatures in Aegis use dual-layer domain separation
//! (AD-1.6-02, HC #34):
//! - Envelope context string `"AEGIS-STH-v1"` embedded in `sth_bytes`
//!   (auditor-visible in the wire bytes).
//! - FIPS 204 §5.2 ctx parameter `b"AEGIS-STH-v1"` passed to
//!   `verify_with_ctx_str` (cryptographically bound; NOT in wire bytes).
//!
//! External verifiers MUST pass `b"AEGIS-STH-v1"` as the ctx string; without
//! it, ML-DSA-65 will reject the signature even if the public key is correct.
//!
//! # OQS init (footgun #37, DF-1.6-03)
//!
//! `oqs::init()` is called explicitly as the FIRST statement in
//! [`aegis_verifier`]. The cdylib boundary breaks the static-dedup that works
//! inside an rlib; relying on a transitive `init()` call from
//! `MlDsaSigner::new()` is not safe across the boundary.

use aegis_core::serialization::{decode_inclusion_proof_v1, decode_sth_envelope_v1, WIRE_VERSION};
use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};
// Alias the crate to avoid ambiguity with the #[pymodule] function below,
// which is also named `aegis_verifier` (the Python module name).
// The `::` prefix resolves ambiguity per compiler recommendation (E0659).
use ::aegis_verifier as verifier_sdk;
use oqs::init as oqs_init;
use pyo3::exceptions::PyException;
use pyo3::prelude::*;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Exception hierarchy (create_exception! — NOT #[pyclass(extends=...)]; footgun #36)
// ---------------------------------------------------------------------------

// Exception definitions (create_exception! — NOT #[pyclass(extends=...)]; footgun #36).
// Note: doc comments before macro invocations are unused by rustdoc; exception
// documentation lives in the module-level //! docs above and in README.md.
//
// AegisVerificationError — base class, subclass of Python Exception.
// AegisInvalidProofError — proof/signature verification failed; subclass of base.
// AegisStaleSthError     — STH older than max_age; subclass of base.
pyo3::create_exception!(aegis_verifier, AegisVerificationError, PyException);
pyo3::create_exception!(
    aegis_verifier,
    AegisInvalidProofError,
    AegisVerificationError
);
pyo3::create_exception!(aegis_verifier, AegisStaleSthError, AegisVerificationError);

// ---------------------------------------------------------------------------
// VerificationResult
// ---------------------------------------------------------------------------

/// Result returned by a successful [`verify_inclusion`] call.
///
/// All fields are read-only (`#[pyo3(get)]`). There is intentionally no
/// `verified: bool` field — a successful return ALWAYS implies verification
/// passed; failure paths raise exceptions (AD-1.6-05 / Stage 6 WARN-8).
///
/// ```python
/// result = aegis_verifier.verify_inclusion(
///     leaf_bytes=..., proof_bytes=..., sth_bytes=...,
///     signature=..., ca_public_key=...,
/// )
/// print(result.leaf_index, result.tree_size, result.timestamp_ms)
/// ```
// skip_from_py_object: VerificationResult is write-once from Rust; Python callers
// read attributes but never pass VerificationResult instances back to Rust.
// Avoids the pyo3 0.28 HasAutomaticFromPyObject deprecation warning.
#[pyclass(skip_from_py_object)]
#[derive(Clone)]
pub struct VerificationResult {
    /// 0-based index of the verified leaf in the batch Merkle tree.
    #[pyo3(get)]
    pub leaf_index: u64,
    /// Number of leaves in the batch Merkle tree at issuance time.
    #[pyo3(get)]
    pub tree_size: u64,
    /// STH timestamp in milliseconds since Unix epoch (RFC 9162 §4.9).
    #[pyo3(get)]
    pub timestamp_ms: u64,
}

#[pymethods]
impl VerificationResult {
    fn __repr__(&self) -> String {
        format!(
            "VerificationResult(leaf_index={}, tree_size={}, timestamp_ms={})",
            self.leaf_index, self.tree_size, self.timestamp_ms
        )
    }
}

// ---------------------------------------------------------------------------
// verify_inclusion
// ---------------------------------------------------------------------------

/// Verifies full MTAC provenance: STH signature, Merkle inclusion, and leaf hash.
///
/// This function RAISES on ALL failure paths — it never returns a
/// ``verified=False`` sentinel (AD-1.6-05 / Stage 6 WARN-8).
///
/// # Parameters
///
/// - `leaf_bytes`: dcbor-encoded `MtacLeaf` (RFC 8949 §4.2.1 CDER profile,
///   same format as `MtacLeaf.serialize_canonical()` in Rust).
/// - `proof_bytes`: wire-v1 encoded `InclusionProof` per
///   `encode_inclusion_proof_v1` (CBOR `array(3)` of `[uint, uint, array<bstr(32)>]`).
/// - `sth_bytes`: wire-v1 STH envelope per `encode_signed_tree_head`
///   (CBOR `array(2)` of `[tstr("AEGIS-STH-v1"), bstr(body)]`). This is the
///   EXACT byte string that was passed to ML-DSA-65 `sign_with_ctx_str`.
/// - `signature`: 3309-byte ML-DSA-65 (FIPS 204) signature over `sth_bytes`
///   with ctx `b"AEGIS-STH-v1"`.
/// - `ca_public_key`: 1952-byte raw ML-DSA-65 public key (NOT CBOR-encoded).
///
/// # Returns
///
/// On success: `VerificationResult(leaf_index, tree_size, timestamp_ms)`.
///
/// # Errors
///
/// Returns `PyErr` (which Python sees as one of the exception types below) on
/// any failure. Never returns `Ok` with a "not verified" sentinel.
///
/// - `AegisInvalidProofError` — STH signature invalid, Merkle inclusion failed,
///   or leaf hash mismatch.
/// - `AegisVerificationError` — malformed input bytes, wrong public key length,
///   or other structural failures.
///
/// # Domain separation
///
/// The FIPS 204 §5.2 ctx string `b"AEGIS-STH-v1"` is applied at the ML-DSA-65
/// layer (not visible in `sth_bytes`). External verifiers MUST pass this ctx
/// string; passing an empty ctx will reject valid Aegis signatures.
#[pyfunction]
pub fn verify_inclusion(
    leaf_bytes: &[u8],
    proof_bytes: &[u8],
    sth_bytes: &[u8],
    signature: &[u8],
    ca_public_key: &[u8],
) -> PyResult<VerificationResult> {
    // Step 1: Direct ML-DSA-65 signature verification over sth_bytes.
    // sth_bytes IS the bytes_to_sign (the wire-v1 envelope output of
    // encode_signed_tree_head); we verify before any further parsing.
    // Dual-layer domain separation per AD-1.6-02 / HC #34:
    // - "AEGIS-STH-v1" envelope tstr is embedded in sth_bytes (auditor-visible)
    // - b"AEGIS-STH-v1" ctx is the FIPS 204 §5.2 parameter (cryptographically bound)
    let sig_scheme = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65)
        .map_err(|e| AegisVerificationError::new_err(format!("oqs init failed: {e}")))?;

    let pk_ref = sig_scheme
        .public_key_from_bytes(ca_public_key)
        .ok_or_else(|| {
            AegisVerificationError::new_err(format!(
                "ca_public_key rejected by oqs (expected {} bytes, got {})",
                sig_scheme.length_public_key(),
                ca_public_key.len()
            ))
        })?;

    let sig_ref = sig_scheme.signature_from_bytes(signature).ok_or_else(|| {
        AegisInvalidProofError::new_err(format!(
            "signature rejected by oqs (expected {} bytes, got {})",
            sig_scheme.length_signature(),
            signature.len()
        ))
    })?;

    sig_scheme
        .verify_with_ctx_str(sth_bytes, sig_ref, WIRE_VERSION.as_bytes(), pk_ref)
        .map_err(|_| AegisInvalidProofError::new_err("ML-DSA-65 signature verification failed"))?;

    // Step 2: Decode wire-v1 STH envelope — extracts the 5 signed fields.
    let decoded_sth = decode_sth_envelope_v1(sth_bytes)
        .map_err(|e| AegisVerificationError::new_err(format!("STH envelope decode failed: {e}")))?;

    // Step 3: Decode wire-v1 InclusionProof.
    let proof = decode_inclusion_proof_v1(proof_bytes).map_err(|e| {
        AegisVerificationError::new_err(format!("inclusion proof decode failed: {e}"))
    })?;

    // Step 4: Decode dcbor-encoded MtacLeaf.
    let leaf = aegis_core::leaf::MtacLeaf::deserialize(leaf_bytes)
        .map_err(|e| AegisVerificationError::new_err(format!("leaf decode failed: {e}")))?;

    // Step 5: Reconstruct SignedTreeHead with the separate signature parameter
    // plus the decoded body fields.
    let sth = SignedTreeHead {
        log_id: decoded_sth.log_id,
        tree_head: TreeHeadDataV2 {
            tree_size: decoded_sth.tree_size,
            timestamp: decoded_sth.timestamp,
            root_hash: decoded_sth.root_hash,
            sth_extensions: decoded_sth.sth_extensions,
        },
        signature_bytes: signature.to_vec(),
    };

    // Step 6: Construct MTACIssuanceResult for verify_mtac composition.
    // batch_id is not part of the Python API surface — use a nil UUID as a
    // transport placeholder (verify_mtac does not inspect batch_id).
    let leaf_index = proof.leaf_index;
    let issuance_result = verifier_sdk::MTACIssuanceResult {
        batch_id: Uuid::nil(),
        leaf_index,
        inclusion_proof: proof,
        signed_tree_head: sth,
    };

    // Step 7: Full MTAC provenance verification (STH signature re-checked +
    // leaf hash + Merkle inclusion via verify_mtac composition order).
    // ca_public_key must be exactly 1952 bytes for the typed parameter.
    let ca_pk_typed: &[u8; 1952] = ca_public_key.try_into().map_err(|_| {
        AegisVerificationError::new_err(format!(
            "ca_public_key must be 1952 bytes (ML-DSA-65), got {}",
            ca_public_key.len()
        ))
    })?;

    verifier_sdk::verify_mtac(&leaf, &issuance_result, ca_pk_typed).map_err(|e| match e {
        verifier_sdk::MtacVerifyError::InclusionProofInvalid => {
            AegisInvalidProofError::new_err("Merkle inclusion proof invalid")
        }
        verifier_sdk::MtacVerifyError::LeafHashingFailed(le) => {
            AegisVerificationError::new_err(format!("leaf hashing failed: {le}"))
        }
        verifier_sdk::MtacVerifyError::SthVerification(ve) => match ve {
            verifier_sdk::VerifyError::StaleSth { age_ms, max_age_ms } => {
                AegisStaleSthError::new_err(format!(
                    "STH is stale: age {age_ms}ms exceeds max_age {max_age_ms}ms"
                ))
            }
            _ => AegisInvalidProofError::new_err(format!("STH verification failed: {ve}")),
        },
    })?;

    Ok(VerificationResult {
        leaf_index,
        tree_size: decoded_sth.tree_size,
        timestamp_ms: decoded_sth.timestamp,
    })
}

// ---------------------------------------------------------------------------
// Module init (footgun #37 — oqs::init() FIRST, before any m.add() call)
// ---------------------------------------------------------------------------

/// Aegis ML-DSA-65 post-quantum verifier Python module.
///
/// Exposes:
/// - `AegisVerificationError` — base exception (subclass of `Exception`)
/// - `AegisInvalidProofError` — proof/signature verification failed
/// - `AegisStaleSthError` — STH older than `max_age`
/// - `VerificationResult` — result dataclass with `leaf_index`, `tree_size`,
///   `timestamp_ms` read-only attributes
/// - `verify_inclusion(leaf_bytes, proof_bytes, sth_bytes, signature,
///   ca_public_key)` — full MTAC provenance verification; raises on failure
#[pymodule]
fn aegis_verifier(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // OQS_INIT cdylib double-static fix (footgun #37, DF-1.6-03, AD-1.6-05).
    // Idempotent: OQS internal Once guard ensures actual init fires only once.
    // MUST be called FIRST — cdylib boundary breaks static dedup inside rlib.
    oqs_init();

    // Register Python exception types.
    m.add(
        "AegisVerificationError",
        m.py().get_type::<AegisVerificationError>(),
    )?;
    m.add(
        "AegisInvalidProofError",
        m.py().get_type::<AegisInvalidProofError>(),
    )?;
    m.add(
        "AegisStaleSthError",
        m.py().get_type::<AegisStaleSthError>(),
    )?;

    // Register result class.
    m.add_class::<VerificationResult>()?;

    // Register top-level function.
    m.add_function(wrap_pyfunction!(verify_inclusion, m)?)?;

    Ok(())
}
