# fixture_gen JSON Schema

Schema version: `fixture_gen_v1`

## Single-fixture output (`--count 1`)

```json
{
  "schema_version": "fixture_gen_v1",
  "leaf_bytes":    "<hex-encoded dcbor MtacLeaf>",
  "proof_bytes":   "<hex-encoded wire-v1 InclusionProof>",
  "sth_bytes":     "<hex-encoded wire-v1 STH envelope>",
  "signature":     "<hex-encoded 3309-byte ML-DSA-65 signature>",
  "ca_public_key": "<hex-encoded 1952-byte ML-DSA-65 public key>"
}
```

## Multi-fixture output (`--count N > 1`)

JSON array of the above objects. All entries share the same `ca_public_key`
and `sth_bytes` (single CA, single committed batch), with distinct `leaf_bytes`
and `proof_bytes` per leaf.

## Field names

Field names MUST match `pyo3-api-v1.md` `verify_inclusion` parameter names
exactly (no naming drift from API spec).

## Seed to fixture mapping

| `--seed` | `--count` | consumer file            | AC       | purpose                      |
|----------|-----------|--------------------------|----------|------------------------------|
| 1        | 1         | `test_kat.py`            | 1.6-32   | KAT-style deterministic probe |
| 33       | 100       | `test_interop.py`        | 1.6-33   | 100-leaf single-batch interop |
| 51       | 1         | `test_byte_equivalence.py` | 1.6-51 | wire-v1 byte-equivalence      |

## Determinism notes

The CA keypair is generated via liboqs's internal PRNG (not user-seeded), so
`ca_public_key` and `signature` will differ across fixture_gen invocations.
This is intentional: tests verify the LIVE fixture output rather than comparing
against committed golden bytes. The `--seed` flag only controls the
user-space RNG used for agent ID generation (ensuring distinct agent IDs within
a batch for multi-leaf tests).

For `test_byte_equivalence.py` (AC-1.6-51), what matters is that the Python
wire-v1 encoder produces the same bytes as the Rust encoder for the SAME input
data — the seed controls which input data is used, not which key is used.

## Feature gate

`fixture_gen` is compiled only under the `test-fixtures` Cargo feature:
```
cargo build -p aegis-verifier-py --features test-fixtures
```

Release wheel builds (without `--features test-fixtures`) do NOT include this
binary. It never ships in the published `.whl`. (D-145)
