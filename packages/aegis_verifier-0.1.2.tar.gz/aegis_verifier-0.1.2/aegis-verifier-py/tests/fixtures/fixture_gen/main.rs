//! `fixture_gen` — deterministic test-fixture generator for Aegis Phase 5 pytest suite.
//!
//! Emits JSON to stdout. Callers parse via `json.loads(result.stdout)`.
//!
//! # Usage
//!
//! ```text
//! cargo run --features test-fixtures --bin fixture_gen -- --seed 1 --count 1
//! ```
//!
//! # Seed to fixture mapping (per SCHEMA.md)
//!
//! | seed | count | consumer              | AC       |
//! |------|-------|-----------------------|----------|
//! | 1    | 1     | `test_kat.py`         | 1.6-32   |
//! | 33   | 100   | `test_interop.py`     | 1.6-33   |
//! | 51   | 1     | `test_byte_equiv.py`  | 1.6-51   |
//!
//! # JSON schema
//!
//! Single fixture:
//! ```json
//! {
//!   "schema_version": "fixture_gen_v1",
//!   "leaf_bytes": "<hex>",
//!   "proof_bytes": "<hex>",
//!   "sth_bytes": "<hex>",
//!   "signature": "<hex>",
//!   "ca_public_key": "<hex>"
//! }
//! ```
//!
//! Multiple fixtures (`--count N > 1`): JSON array of the above objects,
//! all sharing the same `ca_public_key` and `sth_bytes` (single CA, single batch).
//!
//! # Determinism
//!
//! Agent IDs are derived from the seed and leaf index.
//! The CA keypair is ML-DSA-65 (oqs); `oqs::sig::Sig::keypair()` is NOT
//! deterministic from a user-supplied seed — each call generates a fresh
//! keypair via the underlying liboqs PRNG. This means `ca_public_key` will
//! differ across runs, but the fixture JSON for a given seed will be
//! regenerated identically in structure, and `test_kat.py` regenerates and
//! re-verifies each run (no committed golden bytes).
//!
//! For AC-1.6-51 byte-equivalence, the test compares Rust encoder output
//! against Python-reimplemented encoder output from the SAME fixture
//! data — determinism of the ENCODING is what matters, not the keypair.

use std::env;

use aegis_ca::CertificateAuthority;
use aegis_core::leaf::MtacLeaf;
use aegis_core::serialization::{encode_inclusion_proof_v1, encode_signed_tree_head};
use aegis_core::signing::MlDsaSigner;
use rand::SeedableRng;
use rand_chacha::ChaCha20Rng;
use serde_json::{json, Value};

fn main() {
    let args: Vec<String> = env::args().collect();

    let seed: u64 = parse_flag(&args, "--seed").unwrap_or(1);
    let count: usize = parse_flag::<usize>(&args, "--count").unwrap_or(1);

    // Seed the user-space RNG for agent ID generation.
    // NOTE: the CA keypair uses liboqs's own PRNG (non-deterministic across runs).
    // This is acceptable: tests re-verify the live fixture rather than comparing
    // against committed golden bytes (except `test_byte_equivalence` which checks
    // the encoding layer, not the keypair bytes).
    let mut rng = ChaCha20Rng::seed_from_u64(seed);

    // Build CA and register `count` leaves.
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new failed — oqs init problem");
    let ca_public_key_bytes: [u8; 1952] = signer.public_key_owned();
    let ca = CertificateAuthority::new(signer);

    let mut leaves: Vec<MtacLeaf> = Vec::with_capacity(count);
    for i in 0..count {
        #[allow(clippy::cast_possible_truncation)]
        let leaf_index = i as u64;
        let agent_id = deterministic_agent_id(seed, leaf_index, &mut rng);
        let leaf = MtacLeaf::new(
            agent_id,
            "sponsor@fixture.example".to_string(),
            vec!["scope:read".to_string(), "scope:attest".to_string()],
            1_713_600_000_u64,
            1_745_136_000_u64,
        );
        leaves.push(leaf.clone());
        let _receipt = ca
            .register_agent(&leaf)
            .unwrap_or_else(|e| panic!("register_agent failed for leaf {i}: {e}"));
    }

    let summary = ca.commit_batch().expect("commit_batch failed");

    // Collect the STH wire bytes (same for all leaves in this batch).
    let sth_bytes = encode_signed_tree_head(&summary.signed_tree_head);

    // Emit JSON.
    if count == 1 {
        let result = ca
            .issuance_result(summary.batch_id, 0)
            .expect("issuance_result(0) failed");
        let proof_bytes = encode_inclusion_proof_v1(&result.inclusion_proof);
        let leaf_bytes = leaves[0]
            .serialize_canonical()
            .expect("leaf serialize failed");

        let obj = fixture_json(
            &leaf_bytes,
            &proof_bytes,
            &sth_bytes,
            &summary.signed_tree_head.signature_bytes,
            &ca_public_key_bytes,
        );
        println!(
            "{}",
            serde_json::to_string(&obj).expect("json serialize failed")
        );
    } else {
        let mut arr: Vec<Value> = Vec::with_capacity(count);
        for (i, leaf) in leaves.iter().enumerate() {
            #[allow(clippy::cast_possible_truncation)]
            let leaf_index = i as u64;
            let result = ca
                .issuance_result(summary.batch_id, leaf_index)
                .unwrap_or_else(|e| panic!("issuance_result({i}) failed: {e}"));
            let proof_bytes = encode_inclusion_proof_v1(&result.inclusion_proof);
            let leaf_bytes = leaf.serialize_canonical().expect("leaf serialize failed");
            arr.push(fixture_json(
                &leaf_bytes,
                &proof_bytes,
                &sth_bytes,
                &summary.signed_tree_head.signature_bytes,
                &ca_public_key_bytes,
            ));
        }
        println!(
            "{}",
            serde_json::to_string(&arr).expect("json array serialize failed")
        );
    }
}

fn fixture_json(
    leaf_bytes: &[u8],
    proof_bytes: &[u8],
    sth_bytes: &[u8],
    signature: &[u8],
    ca_public_key: &[u8],
) -> Value {
    json!({
        "schema_version": "fixture_gen_v1",
        "leaf_bytes":    hex::encode(leaf_bytes),
        "proof_bytes":   hex::encode(proof_bytes),
        "sth_bytes":     hex::encode(sth_bytes),
        "signature":     hex::encode(signature),
        "ca_public_key": hex::encode(ca_public_key),
    })
}

/// Generates a deterministic agent ID string from seed + leaf index.
/// Uses the RNG to produce a hex suffix for uniqueness within the batch.
fn deterministic_agent_id(seed: u64, index: u64, rng: &mut ChaCha20Rng) -> String {
    use rand::RngCore;
    let mut suffix = [0u8; 8];
    rng.fill_bytes(&mut suffix);
    format!(
        "urn:aegis:agent:fixture-s{seed:04x}-i{index:04x}-{}",
        hex::encode(suffix)
    )
}

/// Parses `--flag VALUE` from the argument list.
fn parse_flag<T: std::str::FromStr>(args: &[String], flag: &str) -> Option<T> {
    args.windows(2)
        .find(|w| w[0] == flag)
        .and_then(|w| w[1].parse().ok())
}
