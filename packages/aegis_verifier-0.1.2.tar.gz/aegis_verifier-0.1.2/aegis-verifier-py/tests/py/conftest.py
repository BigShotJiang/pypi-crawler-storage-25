"""conftest.py — pytest fixtures for aegis-verifier-py Phase 5 test suite.

Session-scoped fixtures invoke the ``fixture_gen`` Rust binary (compiled
under the ``test-fixtures`` Cargo feature) to produce deterministic
hex-encoded 5-tuples consumed by ``aegis_verifier.verify_inclusion``.

The binary emits JSON to stdout per ``tests/fixtures/SCHEMA.md``.

Seed mapping (D-145 / SCHEMA.md):
- seed=1,  count=1   → KAT single fixture  (test_kat.py, AC-1.6-32)
- seed=33, count=100 → 100-tuple batch     (test_interop.py, AC-1.6-33)
- seed=51, count=1   → byte-equiv fixture  (test_byte_equivalence.py, AC-1.6-51)
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

import pytest

# Absolute path to the aegis-verifier-py Cargo.toml so the subprocess invocation
# works regardless of pytest invocation directory (cwd mismatch per GitHub #50280).
_MANIFEST = str(
    Path(__file__).resolve().parent.parent.parent / "Cargo.toml"
)


def _run_fixture_gen(seed: int, count: int) -> Any:
    """Run fixture_gen and return parsed JSON."""
    result = subprocess.run(
        [
            "cargo",
            "run",
            "--features",
            "test-fixtures",
            "--bin",
            "fixture_gen",
            "--manifest-path",
            _MANIFEST,
            "--",
            "--seed",
            str(seed),
            "--count",
            str(count),
        ],
        capture_output=True,
        check=True,
        env={**os.environ, "PYO3_PYTHON": "python3.11"},
    )
    return json.loads(result.stdout)


# ---------------------------------------------------------------------------
# Session-scoped fixtures — generated once per pytest session to amortise
# the ~20s oqs key-generation cost over all tests that need the same fixture.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def fixture_seed1() -> dict[str, str]:
    """Single-leaf fixture at seed=1 for KAT and basic tests (AC-1.6-29, 32)."""
    return _run_fixture_gen(seed=1, count=1)


@pytest.fixture(scope="session")
def fixture_seed33() -> list[dict[str, str]]:
    """100-leaf batch fixture at seed=33 for interop test (AC-1.6-33)."""
    return _run_fixture_gen(seed=33, count=100)


@pytest.fixture(scope="session")
def fixture_seed51() -> dict[str, str]:
    """Single-leaf fixture at seed=51 for byte-equivalence test (AC-1.6-51)."""
    return _run_fixture_gen(seed=51, count=1)


# ---------------------------------------------------------------------------
# Helper: decode a fixture dict into bytes for verify_inclusion.
# ---------------------------------------------------------------------------


def decode_fixture(f: dict[str, str]) -> tuple[bytes, bytes, bytes, bytes, bytes]:
    """Return (leaf_bytes, proof_bytes, sth_bytes, signature, ca_public_key)."""
    return (
        bytes.fromhex(f["leaf_bytes"]),
        bytes.fromhex(f["proof_bytes"]),
        bytes.fromhex(f["sth_bytes"]),
        bytes.fromhex(f["signature"]),
        bytes.fromhex(f["ca_public_key"]),
    )
