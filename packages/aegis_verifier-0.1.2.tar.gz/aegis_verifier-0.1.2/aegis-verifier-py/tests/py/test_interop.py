"""test_interop.py — interop test: 100 distinct (leaf, proof) pairs, single CA/STH.

AC-1.6-33 (Lead-ratified single-batch interpretation):
    1 CA, 1 STH, 100 distinct (MtacLeaf, InclusionProof) pairs all committed
    in the same batch against the shared STH.

    This verifies:
    - All 100 leaf proofs independently pass verify_inclusion.
    - Each produces the correct leaf_index (0..99).
    - All produce the same tree_size (100) and timestamp_ms (from the shared STH).
    - Cross-index tamper detection: proof for leaf i does not verify for leaf j (i≠j).
"""

from __future__ import annotations

from typing import Any

import aegis_verifier
import pytest

from conftest import decode_fixture


# ---------------------------------------------------------------------------
# AC-1.6-33: all 100 leaves verify successfully
# ---------------------------------------------------------------------------


def test_all_100_leaves_verify_successfully(fixture_seed33: list) -> None:
    """All 100 (leaf, proof) pairs in the seed=33 batch pass verify_inclusion."""
    assert len(fixture_seed33) == 100, (
        f"Expected 100 fixtures from seed=33, got {len(fixture_seed33)}"
    )
    for i, f in enumerate(fixture_seed33):
        leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(f)
        result = aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )
        assert result.leaf_index == i, (
            f"Leaf {i}: expected leaf_index={i}, got {result.leaf_index}"
        )
        assert result.tree_size == 100, (
            f"Leaf {i}: expected tree_size=100, got {result.tree_size}"
        )


def test_all_leaves_share_same_sth_bytes(fixture_seed33: list) -> None:
    """All 100 leaves in seed=33 batch share identical sth_bytes (single STH)."""
    sth_set = {f["sth_bytes"] for f in fixture_seed33}
    assert len(sth_set) == 1, (
        f"Expected 1 unique sth_bytes in the batch, got {len(sth_set)}"
    )


def test_all_leaves_share_same_ca_public_key(fixture_seed33: list) -> None:
    """All 100 leaves in seed=33 batch share identical ca_public_key (single CA)."""
    pk_set = {f["ca_public_key"] for f in fixture_seed33}
    assert len(pk_set) == 1, (
        f"Expected 1 unique ca_public_key, got {len(pk_set)}"
    )


def test_all_leaves_share_same_signature(fixture_seed33: list) -> None:
    """All 100 leaves share the same STH signature (one signing event per batch)."""
    sig_set = {f["signature"] for f in fixture_seed33}
    assert len(sig_set) == 1, (
        f"Expected 1 unique signature in the batch, got {len(sig_set)}"
    )


def test_all_leaf_bytes_are_distinct(fixture_seed33: list) -> None:
    """All 100 leaf_bytes are distinct (each leaf has a unique agent_id)."""
    leaf_set = {f["leaf_bytes"] for f in fixture_seed33}
    assert len(leaf_set) == 100, (
        f"Expected 100 distinct leaf_bytes, got {len(leaf_set)}"
    )


def test_all_proof_bytes_are_distinct(fixture_seed33: list) -> None:
    """All 100 proof_bytes are distinct (each leaf has a unique position in the tree)."""
    proof_set = {f["proof_bytes"] for f in fixture_seed33}
    assert len(proof_set) == 100, (
        f"Expected 100 distinct proof_bytes, got {len(proof_set)}"
    )


def test_all_timestamp_ms_are_equal(fixture_seed33: list) -> None:
    """All 100 results have the same timestamp_ms (from the shared STH)."""
    _, _, sth_bytes, sig, pk = decode_fixture(fixture_seed33[0])
    timestamps = set()
    for f in fixture_seed33:
        leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(f)
        result = aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )
        timestamps.add(result.timestamp_ms)
    assert len(timestamps) == 1, (
        f"Expected 1 unique timestamp_ms across all leaves, got {len(timestamps)}"
    )


def test_cross_index_tamper_rejected(fixture_seed33: list) -> None:
    """Proof for leaf 0 does not verify for leaf 1's bytes (cross-index tamper)."""
    f0 = fixture_seed33[0]
    f1 = fixture_seed33[1]
    # Use leaf 1's content but leaf 0's proof (wrong position binding).
    leaf_bytes_1 = bytes.fromhex(f1["leaf_bytes"])
    proof_bytes_0 = bytes.fromhex(f0["proof_bytes"])
    _, _, sth_bytes, sig, pk = decode_fixture(f0)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes_1,
            proof_bytes=proof_bytes_0,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )
