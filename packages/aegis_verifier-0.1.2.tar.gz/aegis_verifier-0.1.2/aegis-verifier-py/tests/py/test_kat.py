"""test_kat.py — Known-Answer Tests for the aegis_verifier wheel.

AC-1.6-32: ML-DSA-65 verification against deterministic KAT-style fixtures.

KAT approach for Aegis:
    The NIST CAVP ML-DSA-65 SigVer test vectors require the official NIST
    package (network access prohibited per testing rules). Instead, we use
    the ``fixture_gen`` Rust binary with ``--seed 1`` to produce a
    deterministic round-trip fixture: a real ML-DSA-65 keypair, a real
    MtacLeaf, a real Merkle proof, and a real STH signature.  The test
    asserts:

    1. The verifier accepts the fixture (positive KAT).
    2. One-bit flips in every field produce rejection (negative KAT).
    3. The ``VerificationResult`` fields match expected structural invariants.

    This is equivalent to a KAT because the acceptance/rejection behavior is
    deterministic for valid vs. corrupted inputs: ML-DSA-65 is a deterministic
    signature scheme (FIPS 204 §5.2), and the Merkle proof check is
    deterministic given the leaf hash and inclusion path.

    The ``--seed 1`` convention is documented in ``tests/fixtures/SCHEMA.md``.
"""

from __future__ import annotations

import aegis_verifier
import pytest

from conftest import decode_fixture


# ---------------------------------------------------------------------------
# Positive KAT — verifier accepts a valid fixture from seed=1
# ---------------------------------------------------------------------------


def test_kat_seed1_verifies_successfully(fixture_seed1: dict) -> None:
    """KAT seed=1: valid fixture passes verify_inclusion without exception."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert isinstance(result, aegis_verifier.VerificationResult)
    assert result.leaf_index == 0
    assert result.tree_size == 1


def test_kat_result_fields_are_consistent(fixture_seed1: dict) -> None:
    """KAT seed=1: leaf_index < tree_size (structural invariant)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert result.leaf_index < result.tree_size


def test_kat_timestamp_ms_is_in_plausible_range(fixture_seed1: dict) -> None:
    """KAT seed=1: timestamp_ms is within a plausible Unix-epoch range.

    The fixture uses timestamp 1_713_600_000_000 ms (April 2024) or the
    current wall-clock time at issuance. Either way it must exceed
    1_000_000_000_000 ms (year 2001) and be below 4_000_000_000_000 ms
    (year 2096), which is a safe 70-year window.
    """
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    # Lower bound: January 2001 in ms
    assert result.timestamp_ms > 1_000_000_000_000
    # Upper bound: year 2096 in ms (generous headroom)
    assert result.timestamp_ms < 4_000_000_000_000


# ---------------------------------------------------------------------------
# Negative KAT — one-bit flips must reject
# ---------------------------------------------------------------------------


def _flip(data: bytes, idx: int) -> bytes:
    arr = bytearray(data)
    arr[idx % len(arr)] ^= 0x01
    return bytes(arr)


def test_kat_flipped_signature_byte_rejected(fixture_seed1: dict) -> None:
    """KAT seed=1: flipping one bit in the ML-DSA-65 signature causes rejection."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_sig = _flip(sig, 100)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=bad_sig,
            ca_public_key=pk,
        )


def test_kat_flipped_sth_byte_rejected(fixture_seed1: dict) -> None:
    """KAT seed=1: flipping one bit in the STH envelope causes signature rejection."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_sth = _flip(sth_bytes, 20)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=bad_sth,
            signature=sig,
            ca_public_key=pk,
        )


def test_kat_flipped_leaf_byte_rejected(fixture_seed1: dict) -> None:
    """KAT seed=1: flipping one bit in the leaf CBOR causes rejection.

    Depending on which byte is flipped, the CBOR decoder may fail outright
    (AegisVerificationError: malformed CBOR) or the leaf hash may mismatch
    after decode (AegisInvalidProofError). Both are AegisVerificationError
    subclasses — the invariant is that tampering always raises.
    """
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_leaf = _flip(leaf_bytes, 10)
    # Wrong pk → signature rejection (AegisInvalidProofError).
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=_flip(pk, 0),
        )
    # Tampered leaf with valid sig/sth → CBOR decode failure or hash mismatch
    # (both are AegisVerificationError subclasses).
    with pytest.raises(aegis_verifier.AegisVerificationError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=bad_leaf,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )


def test_kat_wrong_ca_public_key_rejected(fixture_seed1: dict) -> None:
    """KAT seed=1: a different 1952-byte public key causes log_id mismatch rejection."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    wrong_pk = bytes([0xBB] * 1952)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=wrong_pk,
        )
