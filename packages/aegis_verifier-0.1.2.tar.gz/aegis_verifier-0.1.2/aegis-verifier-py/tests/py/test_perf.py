"""test_perf.py — performance tests for ``aegis_verifier.verify_inclusion``.

AC-1.6-39 (D2 contribution — p99 latency):

Thresholds per AC-1.6-39:
- Cold start (module import): < 100ms.  Measured by C at ~10ms; this test
  asserts the import is available (cold-start latency is hard to measure
  reliably inside a single pytest run because the module is already imported
  by the time this file runs).
- ``verify_inclusion`` p99 latency (warm): < 10ms per call.

Methodology:
- 50 sequential calls, take the 99th percentile (the 50th call in sorted order
  = p100, so we take the 49th = p98; with 50 samples we round up to the max).
  50 samples is sufficient to detect gross regressions; the p99 contract is
  verified conservatively as max(50 samples) < 10ms.
- Uses ``fixture_seed1`` (single-leaf batch, shared session fixture).

Note: ``verify_inclusion`` runs a full ML-DSA-65 verification + Merkle proof
check + dcbor decode per call. The 10ms threshold is conservative; the release
build target is sub-1ms.
"""

from __future__ import annotations

import time
from typing import Generator

import pytest

import aegis_verifier

from conftest import decode_fixture

# Performance thresholds
_P99_THRESHOLD_MS = 10.0  # AC-1.6-39 contract
_SAMPLE_COUNT = 50


# ---------------------------------------------------------------------------
# AC-1.6-39: warm p99 latency < 10ms
# ---------------------------------------------------------------------------


def test_verify_inclusion_p99_under_10ms(fixture_seed1: dict) -> None:
    """verify_inclusion warm p99 latency must be < 10ms (AC-1.6-39).

    Runs ``_SAMPLE_COUNT`` sequential calls, asserts the maximum observed
    latency (conservative p99 proxy) is below the threshold.
    """
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)

    # Warm-up call (discarded from measurement).
    aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )

    latencies_ms: list[float] = []
    for _ in range(_SAMPLE_COUNT):
        t0 = time.monotonic_ns()
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )
        elapsed_ms = (time.monotonic_ns() - t0) / 1_000_000.0
        latencies_ms.append(elapsed_ms)

    latencies_ms.sort()
    p99_ms = latencies_ms[-1]  # max of 50 samples = conservative p99

    assert p99_ms < _P99_THRESHOLD_MS, (
        f"verify_inclusion p99 latency {p99_ms:.3f}ms exceeds {_P99_THRESHOLD_MS}ms "
        f"threshold (AC-1.6-39). "
        f"Median: {latencies_ms[len(latencies_ms) // 2]:.3f}ms. "
        f"Min: {latencies_ms[0]:.3f}ms."
    )


def test_verify_inclusion_is_callable_without_import_error() -> None:
    """Smoke test: aegis_verifier module imports cleanly and exposes verify_inclusion.

    Cold-start timing is measured at C's Phase 5 baseline (~10ms).  This test
    only verifies that the import succeeds (module is already loaded).
    """
    assert hasattr(aegis_verifier, "verify_inclusion")
    assert callable(aegis_verifier.verify_inclusion)


def test_verify_inclusion_median_under_5ms(fixture_seed1: dict) -> None:
    """verify_inclusion median latency must be < 5ms (sanity check below p99 floor)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)

    latencies_ms: list[float] = []
    for _ in range(_SAMPLE_COUNT):
        t0 = time.monotonic_ns()
        aegis_verifier.verify_inclusion(
            leaf_bytes=leaf_bytes,
            proof_bytes=proof_bytes,
            sth_bytes=sth_bytes,
            signature=sig,
            ca_public_key=pk,
        )
        latencies_ms.append((time.monotonic_ns() - t0) / 1_000_000.0)

    latencies_ms.sort()
    median_ms = latencies_ms[len(latencies_ms) // 2]

    assert median_ms < 5.0, (
        f"verify_inclusion median latency {median_ms:.3f}ms exceeds 5ms sanity floor. "
        f"p99 proxy: {latencies_ms[-1]:.3f}ms."
    )
