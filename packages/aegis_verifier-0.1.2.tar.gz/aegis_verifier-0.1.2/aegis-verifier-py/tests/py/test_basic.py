"""test_basic.py — happy-path tests for ``aegis_verifier.verify_inclusion``.

AC-1.6-29: verify_inclusion returns a correct ``VerificationResult`` for a
valid (leaf_bytes, proof_bytes, sth_bytes, signature, ca_public_key) tuple.
"""

from __future__ import annotations

import aegis_verifier

from conftest import decode_fixture


# ---------------------------------------------------------------------------
# AC-1.6-29: happy path
# ---------------------------------------------------------------------------


def test_verify_inclusion_returns_verification_result(fixture_seed1: dict) -> None:
    """verify_inclusion returns VerificationResult (not None, not an exception)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert isinstance(result, aegis_verifier.VerificationResult)


def test_result_leaf_index_is_zero_for_single_leaf_batch(fixture_seed1: dict) -> None:
    """Single-leaf batch produces leaf_index=0."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert result.leaf_index == 0


def test_result_tree_size_is_one_for_single_leaf_batch(fixture_seed1: dict) -> None:
    """Single-leaf batch produces tree_size=1."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert result.tree_size == 1


def test_result_timestamp_ms_is_positive(fixture_seed1: dict) -> None:
    """timestamp_ms is a positive integer (STH carries a real timestamp)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    assert isinstance(result.timestamp_ms, int)
    assert result.timestamp_ms > 0


def test_result_repr_contains_all_three_fields(fixture_seed1: dict) -> None:
    """repr(VerificationResult) contains leaf_index, tree_size, timestamp_ms labels."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    r = repr(result)
    assert "leaf_index=" in r
    assert "tree_size=" in r
    assert "timestamp_ms=" in r


def test_result_leaf_index_attribute_is_readonly(fixture_seed1: dict) -> None:
    """VerificationResult attributes are read-only (AD-1.6-05 / Stage 6 WARN-8)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )
    try:
        result.leaf_index = 999  # type: ignore[misc]
        # If no exception, pyo3 may silently ignore it on some versions;
        # the important thing is the attribute is not writable for users who
        # expect immutability. Check it was not changed.
        assert result.leaf_index != 999, "leaf_index must not be settable"
    except (AttributeError, TypeError):
        pass  # Expected: attribute is read-only.


def test_module_exposes_verification_result_class() -> None:
    """aegis_verifier module exposes VerificationResult as a named attribute."""
    assert hasattr(aegis_verifier, "VerificationResult")


def test_module_exposes_verify_inclusion_callable() -> None:
    """aegis_verifier module exposes verify_inclusion as a callable."""
    assert callable(aegis_verifier.verify_inclusion)
