"""test_exception_hierarchy.py — exception class existence, hierarchy, and raisability.

AC-1.6-31 (DEFERRED with architectural reframe — F-119):

    Original spec (AC-1.6-31): stale STH raises ``AegisStaleSthError``.

    Architectural reframe (F-119, per Drafter+Moderator review):
    ``verify_inclusion`` is a stateless cryptographic primitive; freshness is
    an operational-policy concern that varies by deployment context (Slice 3
    Gateway vs. on-chain batch audit vs. direct SDK use).  Stuffing ``max_age``
    into the primitive API conflates cryptographic verification with application
    policy — the same architectural mis-fit that drove the F-114→F-117 Model B
    cascade.

    Industry precedent: oqs, OpenSSL, NaCl, JWS/COSE_Sign1, and PASETO all keep
    stateless verify primitives free of freshness policy; freshness is the
    caller's responsibility.

    ``AegisStaleSthError`` STAYS exported in the wheel's exception hierarchy as a
    forward-compat hook for stateful freshness wrappers in Slice 1.7+ and for
    user-built policy layers.

    Functional freshness test DEFERRED → ``docs/slices/SLICE-1.6-DEFERRED-FINDINGS.md``
    (AC-1.6-47 scope, authored at Phase 6).

    When a stateful freshness API is added (Slice 1.7+), the functional test
    pattern will be:

        max_age = timedelta(minutes=5)
        with pytest.raises(aegis_verifier.AegisStaleSthError):
            aegis_verifier.verify_inclusion_fresh(
                ..., max_age=max_age
            )

This file verifies only the class-existence and hierarchy invariants that are
unconditionally true regardless of whether a freshness API exists.
"""

from __future__ import annotations

import pytest

import aegis_verifier


# ---------------------------------------------------------------------------
# Exception class existence
# ---------------------------------------------------------------------------


def test_aegis_verification_error_exists_in_module() -> None:
    """AegisVerificationError is exported from the aegis_verifier module."""
    assert hasattr(aegis_verifier, "AegisVerificationError")


def test_aegis_invalid_proof_error_exists_in_module() -> None:
    """AegisInvalidProofError is exported from the aegis_verifier module."""
    assert hasattr(aegis_verifier, "AegisInvalidProofError")


def test_aegis_stale_sth_error_exists_in_module() -> None:
    """AegisStaleSthError is exported from the aegis_verifier module (forward-compat hook)."""
    assert hasattr(aegis_verifier, "AegisStaleSthError")


# ---------------------------------------------------------------------------
# Exception class hierarchy
# ---------------------------------------------------------------------------


def test_aegis_verification_error_is_subclass_of_exception() -> None:
    """AegisVerificationError is a subclass of Python's built-in Exception."""
    assert issubclass(aegis_verifier.AegisVerificationError, Exception)


def test_aegis_invalid_proof_error_is_subclass_of_aegis_verification_error() -> None:
    """AegisInvalidProofError is a subclass of AegisVerificationError."""
    assert issubclass(
        aegis_verifier.AegisInvalidProofError,
        aegis_verifier.AegisVerificationError,
    )


def test_aegis_stale_sth_error_is_subclass_of_aegis_verification_error() -> None:
    """AegisStaleSthError is a subclass of AegisVerificationError (not a sibling of it)."""
    assert issubclass(
        aegis_verifier.AegisStaleSthError,
        aegis_verifier.AegisVerificationError,
    )


# ---------------------------------------------------------------------------
# Raisability — forward-compat hook must be usable by Python callers
# ---------------------------------------------------------------------------


def test_aegis_stale_sth_error_is_raisable() -> None:
    """User Python code can raise AegisStaleSthError without error."""
    with pytest.raises(aegis_verifier.AegisStaleSthError):
        raise aegis_verifier.AegisStaleSthError("stale test")


def test_aegis_stale_sth_error_is_catchable_as_base_class() -> None:
    """AegisStaleSthError raised by user code is catchable as AegisVerificationError."""
    with pytest.raises(aegis_verifier.AegisVerificationError):
        raise aegis_verifier.AegisStaleSthError("catchable as base")


# ---------------------------------------------------------------------------
# AC-1.6-31 functional test — DEFERRED (F-119)
# ---------------------------------------------------------------------------


@pytest.mark.skip(
    reason=(
        "AC-1.6-31 functional test DEFERRED per F-119: verify_inclusion is a "
        "stateless cryptographic primitive (Model B / F-117); freshness is a "
        "higher-layer operational concern not in scope for this primitive. "
        "AegisStaleSthError is exported as a forward-compat hook for Slice 1.7+ "
        "or user-built freshness wrappers. See SLICE-1.6-DEFERRED-FINDINGS.md."
    )
)
def test_stale_sth_raises_aegis_stale_sth_error_functional() -> None:
    """Functional freshness test: stale STH timestamp raises AegisStaleSthError.

    This test is DEFERRED because ``verify_inclusion`` does not accept a
    ``max_age`` parameter (stateless primitive per Model B / F-117 amendment).

    When a stateful freshness API is added in Slice 1.7+, implement as:

        max_age = timedelta(minutes=5)
        with pytest.raises(aegis_verifier.AegisStaleSthError):
            aegis_verifier.verify_inclusion_fresh(
                leaf_bytes=...,
                proof_bytes=...,
                sth_bytes=...,  # STH with timestamp older than now - max_age
                signature=...,
                ca_public_key=...,
                max_age=max_age,
            )
    """
