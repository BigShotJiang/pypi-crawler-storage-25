"""test_tamper.py — tamper-detection tests for ``aegis_verifier.verify_inclusion``.

AC-1.6-30: tampered inputs MUST raise an exception — there is NO silent-fail path.

Exception classes tested:
- ``AegisInvalidProofError`` — signature invalid, Merkle inclusion failed, leaf
  hash mismatch.
- ``AegisVerificationError`` — malformed input, wrong public key length.
"""

from __future__ import annotations

import pytest

import aegis_verifier

from conftest import decode_fixture


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _flip_byte(data: bytes, index: int = 0) -> bytes:
    """Return a copy of data with one byte flipped (XOR 0xFF)."""
    arr = bytearray(data)
    arr[index % len(arr)] ^= 0xFF
    return bytes(arr)


def _call(
    leaf_bytes: bytes,
    proof_bytes: bytes,
    sth_bytes: bytes,
    sig: bytes,
    pk: bytes,
) -> aegis_verifier.VerificationResult:
    return aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_bytes,
        sth_bytes=sth_bytes,
        signature=sig,
        ca_public_key=pk,
    )


# ---------------------------------------------------------------------------
# AC-1.6-30: tampered cases — all must raise, never silently return a result
# ---------------------------------------------------------------------------


def test_tampered_signature_raises(fixture_seed1: dict) -> None:
    """Flipping one byte of the ML-DSA-65 signature raises AegisInvalidProofError."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_sig = _flip_byte(sig, index=42)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        _call(leaf_bytes, proof_bytes, sth_bytes, bad_sig, pk)


def test_tampered_sth_bytes_raises(fixture_seed1: dict) -> None:
    """Mutating sth_bytes (the signed envelope) raises AegisInvalidProofError."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_sth = _flip_byte(sth_bytes, index=10)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        _call(leaf_bytes, proof_bytes, bad_sth, sig, pk)


def test_tampered_leaf_bytes_raises(fixture_seed1: dict) -> None:
    """Mutating leaf_bytes raises AegisVerificationError (or a subclass).

    Depending on which byte is flipped, the CBOR decoder may fail outright
    (AegisVerificationError: malformed input) or the leaf hash may mismatch
    after successful decode (AegisInvalidProofError: hash/proof failure).
    Both are subclasses of AegisVerificationError — the invariant is that
    NO silent-fail path exists: the function always raises.
    """
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_leaf = _flip_byte(leaf_bytes, index=5)
    # The STH signature still verifies (sth_bytes and sig are untouched);
    # the leaf-hash check, Merkle proof check, or CBOR decode will fail.
    with pytest.raises(aegis_verifier.AegisVerificationError):
        _call(bad_leaf, proof_bytes, sth_bytes, sig, pk)


def test_tampered_proof_bytes_raises(fixture_seed1: dict) -> None:
    """Mutating proof_bytes (inclusion proof) raises AegisInvalidProofError or
    AegisVerificationError (malformed CBOR if the tamper breaks the wire format)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_proof = _flip_byte(proof_bytes, index=0)
    with pytest.raises(aegis_verifier.AegisVerificationError):
        _call(leaf_bytes, bad_proof, sth_bytes, sig, pk)


def test_wrong_ca_public_key_raises(fixture_seed1: dict) -> None:
    """Using a different 1952-byte public key raises AegisInvalidProofError
    (log_id derived from the key won't match the STH log_id field)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    # Construct a wrong-but-valid-length key (all 0xAA bytes).
    wrong_pk = bytes([0xAA] * 1952)
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        _call(leaf_bytes, proof_bytes, sth_bytes, sig, wrong_pk)


def test_truncated_signature_raises(fixture_seed1: dict) -> None:
    """A truncated (wrong-length) signature raises AegisInvalidProofError."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    short_sig = sig[:100]
    with pytest.raises(aegis_verifier.AegisInvalidProofError):
        _call(leaf_bytes, proof_bytes, sth_bytes, short_sig, pk)


def test_truncated_ca_public_key_raises(fixture_seed1: dict) -> None:
    """A wrong-length public key raises AegisVerificationError (not a silent fail)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    short_pk = pk[:100]
    with pytest.raises(aegis_verifier.AegisVerificationError):
        _call(leaf_bytes, proof_bytes, sth_bytes, sig, short_pk)


def test_empty_leaf_bytes_raises(fixture_seed1: dict) -> None:
    """Empty leaf_bytes raises AegisVerificationError (CBOR decode fails)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    with pytest.raises(aegis_verifier.AegisVerificationError):
        _call(b"", proof_bytes, sth_bytes, sig, pk)


def test_empty_sth_bytes_raises(fixture_seed1: dict) -> None:
    """Empty sth_bytes raises AegisInvalidProofError (signature check fails first)."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    with pytest.raises(aegis_verifier.AegisVerificationError):
        _call(leaf_bytes, proof_bytes, b"", sig, pk)


def test_no_silent_fail_path(fixture_seed1: dict) -> None:
    """verify_inclusion never returns a result with tampered signature — it always raises."""
    leaf_bytes, proof_bytes, sth_bytes, sig, pk = decode_fixture(fixture_seed1)
    bad_sig = _flip_byte(sig, index=0)
    raised = False
    try:
        _call(leaf_bytes, proof_bytes, sth_bytes, bad_sig, pk)
    except aegis_verifier.AegisVerificationError:
        raised = True
    assert raised, (
        "verify_inclusion returned a result for a tampered signature — "
        "there must be no silent-fail path (AD-1.6-05 / Stage 6 WARN-8)"
    )
