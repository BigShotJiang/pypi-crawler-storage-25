"""test_byte_equivalence.py — Python wire-v1 encoder must byte-match Rust encoder output.

AC-1.6-51: ``encode_signed_tree_head`` and ``encode_inclusion_proof_v1`` are
           the canonical Rust encoders (footgun #46).  This test implements the
           same RFC 8949 §4.2.1 CDE encoding rules in Python and asserts
           byte-for-byte equality with the Rust-generated fixture bytes.

           If the Python and Rust encoders diverge, it would mean that an
           external Python verifier re-implementing the wire-v1 spec would
           produce incompatible bytes.

Reference spec:
    ``aegis-core/src/serialization.rs`` — ``encode_signed_tree_head``,
    ``encode_inclusion_proof_v1``.

Seed: seed=51 (per SCHEMA.md).
"""

from __future__ import annotations

import struct
from typing import Sequence

from conftest import decode_fixture

# ---------------------------------------------------------------------------
# Pure-Python wire-v1 encoder — mirrors aegis-core/src/serialization.rs exactly
# ---------------------------------------------------------------------------

WIRE_VERSION = "AEGIS-STH-v1"  # must match aegis_core::serialization::WIRE_VERSION


def _encode_head(major: int, value: int) -> bytes:
    """Encode a CBOR head byte per RFC 8949 §4.2.1 CDE.

    major: 0=uint, 2=bstr, 3=tstr, 4=array
    value: argument (length or value)
    """
    tag = major << 5
    if value <= 23:
        return bytes([tag | value])
    if value <= 0xFF:
        return bytes([tag | 24, value])
    if value <= 0xFFFF:
        return bytes([tag | 25]) + struct.pack(">H", value)
    if value <= 0xFFFF_FFFF:
        return bytes([tag | 26]) + struct.pack(">I", value)
    return bytes([tag | 27]) + struct.pack(">Q", value)


def _encode_uint(value: int) -> bytes:
    return _encode_head(0, value)


def _encode_bstr32(data: bytes) -> bytes:
    assert len(data) == 32, f"bstr32 requires exactly 32 bytes, got {len(data)}"
    return _encode_head(2, 32) + data


def encode_sth_body_v1_py(
    log_id: bytes,
    tree_size: int,
    timestamp: int,
    root_hash: bytes,
    extensions: Sequence[tuple[int, bytes]] = (),
) -> bytes:
    """Python mirror of ``encode_sth_body_v1`` in aegis-core/src/serialization.rs.

    Encodes the 5-field STH body as CBOR ``array(5)`` per the wire-v1 spec.
    Extensions are ``(extension_type: u16, extension_data: bytes)`` tuples.
    """
    out = bytearray()
    out += b"\x85"  # CBOR array(5)
    out += _encode_bstr32(log_id)
    out += _encode_uint(tree_size)
    out += _encode_uint(timestamp)
    out += _encode_bstr32(root_hash)
    # Extensions array
    out += _encode_head(4, len(extensions))
    for ext_type, ext_data in extensions:
        out += b"\x82"  # array(2)
        out += _encode_uint(ext_type)
        out += _encode_head(2, len(ext_data)) + ext_data
    return bytes(out)


def encode_sth_envelope_v1_py(body: bytes) -> bytes:
    """Python mirror of ``encode_sth_envelope_v1`` in aegis-core/src/serialization.rs.

    Wraps the body in ``array(2) [tstr("AEGIS-STH-v1"), bstr(body)]``.
    """
    out = bytearray()
    out += b"\x82"  # CBOR array(2)
    version_bytes = WIRE_VERSION.encode("utf-8")
    out += _encode_head(3, len(version_bytes))
    out += version_bytes
    out += _encode_head(2, len(body))
    out += body
    return bytes(out)


def encode_inclusion_proof_v1_py(
    tree_size: int,
    leaf_index: int,
    inclusion_path: list[bytes],
) -> bytes:
    """Python mirror of ``encode_inclusion_proof_v1`` in aegis-core/src/serialization.rs.

    Encodes ``array(3) [uint(tree_size), uint(leaf_index), array<bstr(32)>]``.
    """
    out = bytearray()
    out += b"\x83"  # CBOR array(3)
    out += _encode_uint(tree_size)
    out += _encode_uint(leaf_index)
    out += _encode_head(4, len(inclusion_path))
    for sib in inclusion_path:
        out += _encode_bstr32(sib)
    return bytes(out)


# ---------------------------------------------------------------------------
# Wire-v1 decoder helpers (for the tests that need to parse fixture bytes
# back into individual fields for re-encoding comparison)
# ---------------------------------------------------------------------------


def _parse_sth_bytes(sth_bytes: bytes) -> tuple[bytes, int, int, bytes]:
    """Parse sth_bytes (wire-v1 STH envelope) to recover
    (log_id, tree_size, timestamp, root_hash) for re-encoding comparison.

    Uses the ``aegis_core`` decoder via the ``decode_sth_envelope_v1``
    function exposed in C's lib.rs.  We call it here indirectly via the
    fixture_gen which pre-extracted these fields.

    For the byte-equivalence test we derive these fields by parsing the
    raw fixture sth_bytes manually:
    - Outer array(2): 0x82
    - tstr(12) "AEGIS-STH-v1": 0x6c + 12 bytes
    - bstr(body): 0x58 XX + body bytes
    Body is array(5): 0x85, bstr32 log_id, uint tree_size, uint timestamp,
    bstr32 root_hash, array(0) extensions.
    """
    pos = 0

    def read_byte() -> int:
        nonlocal pos
        b = sth_bytes[pos]
        pos += 1
        return b

    def read_n(n: int) -> bytes:
        nonlocal pos
        data = sth_bytes[pos : pos + n]
        pos += n
        return data

    def read_cbor_uint_val(initial_byte: int) -> int:
        ai = initial_byte & 0x1F
        if ai <= 23:
            return ai
        if ai == 24:
            return read_byte()
        if ai == 25:
            return struct.unpack(">H", read_n(2))[0]
        if ai == 26:
            return struct.unpack(">I", read_n(4))[0]
        return struct.unpack(">Q", read_n(8))[0]

    # Outer array(2)
    assert read_byte() == 0x82
    # tstr "AEGIS-STH-v1"
    tstr_head = read_byte()
    tstr_len = read_cbor_uint_val(tstr_head)
    wire_ver = read_n(tstr_len).decode("utf-8")
    assert wire_ver == WIRE_VERSION, f"Expected {WIRE_VERSION!r}, got {wire_ver!r}"
    # bstr(body)
    bstr_head = read_byte()
    body_len = read_cbor_uint_val(bstr_head)
    body = read_n(body_len)

    # Parse body: array(5)
    bpos = 0

    def b_read_byte() -> int:
        nonlocal bpos
        v = body[bpos]
        bpos += 1
        return v

    def b_read_n(n: int) -> bytes:
        nonlocal bpos
        data = body[bpos : bpos + n]
        bpos += n
        return data

    def b_read_cbor_uint_val(initial_byte: int) -> int:
        ai = initial_byte & 0x1F
        if ai <= 23:
            return ai
        if ai == 24:
            return b_read_byte()
        if ai == 25:
            return struct.unpack(">H", b_read_n(2))[0]
        if ai == 26:
            return struct.unpack(">I", b_read_n(4))[0]
        return struct.unpack(">Q", b_read_n(8))[0]

    assert b_read_byte() == 0x85  # array(5)
    # log_id: bstr(32)
    log_id_head = b_read_byte()
    log_id_len = b_read_cbor_uint_val(log_id_head)
    log_id = b_read_n(log_id_len)
    # tree_size: uint
    ts_head = b_read_byte()
    tree_size = b_read_cbor_uint_val(ts_head)
    # timestamp: uint
    t_head = b_read_byte()
    timestamp = b_read_cbor_uint_val(t_head)
    # root_hash: bstr(32)
    rh_head = b_read_byte()
    rh_len = b_read_cbor_uint_val(rh_head)
    root_hash = b_read_n(rh_len)
    # extensions array (we support only empty arrays for now)
    _ = b_read_byte()  # array(0) or similar — ignored for re-encoding

    return log_id, tree_size, timestamp, root_hash


def _parse_proof_bytes(
    proof_bytes: bytes,
) -> tuple[int, int, list[bytes]]:
    """Parse wire-v1 proof_bytes to recover (tree_size, leaf_index, inclusion_path)."""
    pos = 0

    def read_byte() -> int:
        nonlocal pos
        b = proof_bytes[pos]
        pos += 1
        return b

    def read_n(n: int) -> bytes:
        nonlocal pos
        data = proof_bytes[pos : pos + n]
        pos += n
        return data

    def read_cbor_uint_val(initial_byte: int) -> int:
        ai = initial_byte & 0x1F
        if ai <= 23:
            return ai
        if ai == 24:
            return read_byte()
        if ai == 25:
            return struct.unpack(">H", read_n(2))[0]
        if ai == 26:
            return struct.unpack(">I", read_n(4))[0]
        return struct.unpack(">Q", read_n(8))[0]

    assert read_byte() == 0x83  # array(3)
    ts_head = read_byte()
    tree_size = read_cbor_uint_val(ts_head)
    li_head = read_byte()
    leaf_index = read_cbor_uint_val(li_head)
    path_head = read_byte()
    path_len = read_cbor_uint_val(path_head)
    path: list[bytes] = []
    for _ in range(path_len):
        sib_head = read_byte()
        sib_len = read_cbor_uint_val(sib_head)
        path.append(read_n(sib_len))
    return tree_size, leaf_index, path


# ---------------------------------------------------------------------------
# AC-1.6-51: byte-equivalence tests
# ---------------------------------------------------------------------------


def test_sth_bytes_python_encoder_matches_rust_output(fixture_seed51: dict) -> None:
    """Python re-encoding of the fixture STH fields byte-matches sth_bytes from Rust."""
    sth_bytes = bytes.fromhex(fixture_seed51["sth_bytes"])
    log_id, tree_size, timestamp, root_hash = _parse_sth_bytes(sth_bytes)

    # Re-encode with the Python mirror encoder.
    body_py = encode_sth_body_v1_py(log_id, tree_size, timestamp, root_hash)
    envelope_py = encode_sth_envelope_v1_py(body_py)

    assert envelope_py == sth_bytes, (
        "Python wire-v1 STH encoder output does not byte-match Rust encoder output.\n"
        f"Python ({len(envelope_py)} bytes): {envelope_py.hex()}\n"
        f"Rust   ({len(sth_bytes)} bytes):   {sth_bytes.hex()}"
    )


def test_proof_bytes_python_encoder_matches_rust_output(fixture_seed51: dict) -> None:
    """Python re-encoding of the fixture proof fields byte-matches proof_bytes from Rust."""
    proof_bytes = bytes.fromhex(fixture_seed51["proof_bytes"])
    tree_size, leaf_index, inclusion_path = _parse_proof_bytes(proof_bytes)

    # Re-encode with the Python mirror encoder.
    proof_py = encode_inclusion_proof_v1_py(tree_size, leaf_index, inclusion_path)

    assert proof_py == proof_bytes, (
        "Python wire-v1 proof encoder output does not byte-match Rust encoder output.\n"
        f"Python ({len(proof_py)} bytes): {proof_py.hex()}\n"
        f"Rust   ({len(proof_bytes)} bytes):   {proof_bytes.hex()}"
    )


def test_wire_version_constant_matches_rust(fixture_seed51: dict) -> None:
    """Python WIRE_VERSION constant matches the Rust WIRE_VERSION embedded in sth_bytes."""
    sth_bytes = bytes.fromhex(fixture_seed51["sth_bytes"])
    # sth_bytes[0] = 0x82 (array(2)), sth_bytes[1] = 0x6c (tstr(12))
    assert sth_bytes[0] == 0x82, "sth_bytes must start with CBOR array(2) = 0x82"
    assert sth_bytes[1] == 0x6C, "tstr head for 12-byte WIRE_VERSION must be 0x6c"
    embedded_version = sth_bytes[2:14].decode("utf-8")
    assert embedded_version == WIRE_VERSION, (
        f"Embedded version in sth_bytes ({embedded_version!r}) "
        f"does not match Python WIRE_VERSION ({WIRE_VERSION!r})"
    )


def test_python_encoder_produces_valid_fixture(fixture_seed51: dict) -> None:
    """Python-re-encoded sth_bytes and proof_bytes pass verify_inclusion."""
    import aegis_verifier

    leaf_bytes = bytes.fromhex(fixture_seed51["leaf_bytes"])
    sth_bytes = bytes.fromhex(fixture_seed51["sth_bytes"])
    proof_bytes = bytes.fromhex(fixture_seed51["proof_bytes"])
    sig = bytes.fromhex(fixture_seed51["signature"])
    pk = bytes.fromhex(fixture_seed51["ca_public_key"])

    # Parse and re-encode both.
    log_id, tree_size, timestamp, root_hash = _parse_sth_bytes(sth_bytes)
    body_py = encode_sth_body_v1_py(log_id, tree_size, timestamp, root_hash)
    sth_py = encode_sth_envelope_v1_py(body_py)

    ts_p, li_p, path_p = _parse_proof_bytes(proof_bytes)
    proof_py = encode_inclusion_proof_v1_py(ts_p, li_p, path_p)

    # Verify using the Python-re-encoded bytes (must be byte-identical → also verifies).
    result = aegis_verifier.verify_inclusion(
        leaf_bytes=leaf_bytes,
        proof_bytes=proof_py,
        sth_bytes=sth_py,
        signature=sig,
        ca_public_key=pk,
    )
    assert result.leaf_index == 0
    assert result.tree_size == 1
