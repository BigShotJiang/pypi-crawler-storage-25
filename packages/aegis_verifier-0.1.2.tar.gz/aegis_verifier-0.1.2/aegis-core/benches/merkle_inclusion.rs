use aegis_core::merkle::{verify, MerkleTree};
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn depth20_verify(c: &mut Criterion) {
    let leaves: Vec<[u8; 32]> = (0..1_048_576_u32)
        .map(|i| {
            let mut leaf = [0u8; 32];
            leaf[..4].copy_from_slice(&i.to_le_bytes());
            leaf
        })
        .collect();
    let tree = MerkleTree::new(&leaves).expect("depth-20 tree construction");
    let root = tree.root();
    let proof = tree.proof(500_000).expect("proof for index 500000");
    let leaf_hash = leaves[500_000];

    c.bench_function("depth20_verify", |b| {
        b.iter(|| verify(black_box(leaf_hash), black_box(&proof), black_box(root)));
    });
}

criterion_group!(benches, depth20_verify);
criterion_main!(benches);
