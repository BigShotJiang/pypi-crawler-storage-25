//! Integration tests: load each .cbor fixture and round-trip it through
//! `MtacLeaf::deserialize` -> `serialize_canonical`. The re-serialised bytes
//! MUST be byte-identical to the on-disk fixture. If they differ, either
//! the schema has drifted or canonical encoding has regressed.

use aegis_core::leaf::MtacLeaf;
use std::fs;

const FIXTURE_DIR: &str = "tests/fixtures/leaves";
const FIXTURE_NAMES: &[&str] = &[
    "01_minimal.cbor",
    "02_empty_scopes.cbor",
    "03_max_length_agent_id.cbor",
    "04_zero_duration.cbor",
    "05_inverted_window.cbor",
    "06_many_scopes.cbor",
    "07_unicode_agent_id.cbor",
    "08_unicode_scope.cbor",
    "09_past_dated.cbor",
    "10_far_future.cbor",
];

#[test]
fn fixtures_roundtrip_all_10() {
    for name in FIXTURE_NAMES {
        let path = format!("{FIXTURE_DIR}/{name}");
        let bytes = fs::read(&path).unwrap_or_else(|e| panic!("read {path}: {e}"));
        let leaf =
            MtacLeaf::deserialize(&bytes).unwrap_or_else(|e| panic!("deserialize {name}: {e}"));
        let reser = leaf
            .serialize_canonical()
            .unwrap_or_else(|e| panic!("serialize {name}: {e}"));
        assert_eq!(
            bytes, reser,
            "fixture {name} did not round-trip byte-identically"
        );
    }
}

#[test]
fn fixture_05_inverted_window_serializes() {
    // Confirms the value-agnostic serialization rule: fixture 5 has
    // not_after < not_before. Semantic validation belongs in the CA
    // (Sub-Slice 1.5), not here.
    let bytes = fs::read(format!("{FIXTURE_DIR}/05_inverted_window.cbor")).unwrap();
    let leaf = MtacLeaf::deserialize(&bytes).expect("must deserialize");
    assert!(
        leaf.not_after < leaf.not_before,
        "fixture 5 is inverted by design"
    );
}
