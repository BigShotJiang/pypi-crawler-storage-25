//! Extension serialization tests for wire-v1 format.
//!
//! Per AC-1.6-11: tests that `Vec<Extension>` encodes correctly for all
//! boundary cases per wire-v1.md §9.
//!
//! Empty case: `Vec<Extension>::new()` encodes as `0x80` (CBOR empty array).
//!
//! Nonempty boundary cases:
//! - `extension_type ∈ {0, 23, 24, 255, 256, 65535}` (all `encode_head` transitions for u16)
//! - `extension_data` sizes ∈ {empty=0x40, 1 byte, 24 bytes, 25 bytes, 300 bytes}
//!
//! Phase 1 compile-skip: encoder functions and `Extension` type are gated behind
//! `wire-v1-encoder` feature. Teammate A activates these tests in Phase 2 by
//! removing the cfg gate once the encoder lands.

// ---------------------------------------------------------------------------
// Phase 2+: encoder functions now available; cfg gate removed by Teammate A.
// ---------------------------------------------------------------------------
mod extension_tests {
    use aegis_core::serialization::{encode_sth_body_v1, Extension};

    const LOG_ID: [u8; 32] = [0xAA; 32];
    const ROOT_HASH: [u8; 32] = [0xBB; 32];
    const TREE_SIZE: u64 = 1;
    const TIMESTAMP: u64 = 1_000_000;

    // -----------------------------------------------------------------------
    // Helper: extract the extensions bytes from a body, starting at the
    // extensions array head. Dynamically computes the offset by scanning
    // the variable-length tree_size and timestamp uint fields.
    // -----------------------------------------------------------------------
    fn extensions_bytes(body: &[u8]) -> &[u8] {
        // array(5)[1] + bstr32(log_id)[2+32=34] = 35 fixed bytes
        let mut offset = 1 + 34;

        // skip uint(tree_size)
        let ts_add = body[offset] & 0x1f;
        let ts_skip: usize = match ts_add {
            0..=23 => 1,
            24 => 2,
            25 => 3,
            26 => 5,
            27 => 9,
            _ => panic!(),
        };
        offset += ts_skip;

        // skip uint(timestamp)
        let stamp_add = body[offset] & 0x1f;
        let stamp_skip: usize = match stamp_add {
            0..=23 => 1,
            24 => 2,
            25 => 3,
            26 => 5,
            27 => 9,
            _ => panic!(),
        };
        offset += stamp_skip;

        // skip bstr32(root_hash): always 2+32=34 bytes
        offset += 34;

        &body[offset..]
    }

    // -----------------------------------------------------------------------
    // Test: empty extensions encodes as 0x80 (CBOR empty array)
    // -----------------------------------------------------------------------
    #[test]
    fn empty_extensions_encodes_as_0x80() {
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(ext_bytes, &[0x80], "empty extensions must encode as 0x80");
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 0 → uint 0x00 (1-byte, [0..=23] range)
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_zero_one_byte_encoding() {
        let ext = Extension {
            extension_type: 0,
            extension_data: vec![0x42],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(ext_bytes[0], 0x81, "array(1) head");
        assert_eq!(ext_bytes[1], 0x82, "extension is array(2)");
        assert_eq!(
            ext_bytes[2], 0x00,
            "extension_type=0 must encode as uint 0x00"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 23 → uint 0x17 (1-byte, upper boundary of [0..=23])
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_23_one_byte_encoding() {
        let ext = Extension {
            extension_type: 23,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(ext_bytes[2], 0x17, "extension_type=23 must encode as 0x17");
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 24 → 0x18 0x18 (2-byte, lower boundary of [24..=255])
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_24_two_byte_encoding() {
        let ext = Extension {
            extension_type: 24,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[2..4],
            &[0x18, 0x18],
            "extension_type=24 must encode as 0x18 0x18"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 255 → 0x18 0xFF (2-byte, upper boundary of [24..=255])
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_255_two_byte_encoding() {
        let ext = Extension {
            extension_type: 255,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[2..4],
            &[0x18, 0xFF],
            "extension_type=255 must encode as 0x18 0xFF"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 256 → 0x19 0x01 0x00 (3-byte, lower boundary [256..=65535])
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_256_three_byte_encoding() {
        let ext = Extension {
            extension_type: 256,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[2..5],
            &[0x19, 0x01, 0x00],
            "extension_type=256 must encode as 0x19 0x01 0x00"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_type = 65535 → 0x19 0xFF 0xFF (3-byte, upper boundary of u16)
    // -----------------------------------------------------------------------
    #[test]
    fn extension_type_65535_three_byte_encoding() {
        let ext = Extension {
            extension_type: 65535,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[2..5],
            &[0x19, 0xFF, 0xFF],
            "extension_type=65535 must encode as 0x19 0xFF 0xFF"
        );
    }

    // -----------------------------------------------------------------------
    // Test: empty extension_data → CBOR empty bstr 0x40
    // (major type 2, additional 0: length 0)
    // -----------------------------------------------------------------------
    #[test]
    fn empty_extension_data_encodes_as_0x40() {
        let ext = Extension {
            extension_type: 1,
            extension_data: vec![],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        // [0]=0x81 [1]=0x82 [2]=0x01 (uint 1) [3]=0x40 (empty bstr)
        assert_eq!(
            ext_bytes[3], 0x40,
            "empty extension_data must encode as 0x40"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_data of 1 byte → bstr head 0x41, then the byte
    // -----------------------------------------------------------------------
    #[test]
    fn extension_data_1_byte_encodes_with_0x41_head() {
        let ext = Extension {
            extension_type: 1,
            extension_data: vec![0xDE],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            ext_bytes[3], 0x41,
            "1-byte extension_data bstr head must be 0x41"
        );
        assert_eq!(ext_bytes[4], 0xDE, "1-byte extension_data content");
    }

    // -----------------------------------------------------------------------
    // Test: extension_data of 24 bytes → 2-byte bstr head 0x58 0x18
    // (boundary between 1-byte and 2-byte bstr heads)
    // -----------------------------------------------------------------------
    #[test]
    fn extension_data_24_bytes_two_byte_head() {
        let ext = Extension {
            extension_type: 1,
            extension_data: vec![0xAB; 24],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[3..5],
            &[0x58, 0x18],
            "24-byte extension_data must have 2-byte bstr head 0x58 0x18"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_data of 25 bytes → 2-byte head 0x58 0x19
    // -----------------------------------------------------------------------
    #[test]
    fn extension_data_25_bytes_two_byte_head() {
        let ext = Extension {
            extension_type: 1,
            extension_data: vec![0xCD; 25],
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[3..5],
            &[0x58, 0x19],
            "25-byte extension_data must have 2-byte bstr head 0x58 0x19"
        );
    }

    // -----------------------------------------------------------------------
    // Test: extension_data of 300 bytes → 3-byte bstr head 0x59 0x01 0x2C
    // (major type 2, additional 25: 2-byte BE length follows, value 300 = 0x012C)
    // -----------------------------------------------------------------------
    #[test]
    fn extension_data_300_bytes_three_byte_head() {
        let data = vec![0xEF; 300];
        let ext = Extension {
            extension_type: 1,
            extension_data: data.clone(),
        };
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &[ext]);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            &ext_bytes[3..6],
            &[0x59, 0x01, 0x2C],
            "300-byte extension_data must have 3-byte bstr head 0x59 0x01 0x2C"
        );
        assert_eq!(
            &ext_bytes[6..6 + 300],
            data.as_slice(),
            "300-byte extension_data content must follow the 3-byte head"
        );
    }

    // -----------------------------------------------------------------------
    // Test: two extensions produce CBOR array(2) head = 0x82
    // -----------------------------------------------------------------------
    #[test]
    fn multiple_extensions_array_count() {
        let exts = vec![
            Extension {
                extension_type: 1,
                extension_data: vec![0x01, 0x02],
            },
            Extension {
                extension_type: 100,
                extension_data: vec![0xFF; 10],
            },
        ];
        let body = encode_sth_body_v1(&LOG_ID, TREE_SIZE, TIMESTAMP, &ROOT_HASH, &exts);
        let ext_bytes = extensions_bytes(&body);
        assert_eq!(
            ext_bytes[0], 0x82,
            "two extensions must produce array head 0x82"
        );
    }
}
