//! AC-1.5-32 — Concurrent `sign_tree_root` stress test.
//!
//! 32 threads × 100 `sign_tree_root` calls on a shared `Arc<MlDsaSigner>` = 3200 total.
//! Confirms the Slice 1.4 compile-time `Send + Sync` assertion (AC-1.4-36) at runtime.
//!
//! A sampling of 64 signatures (every 50th) is verified via `oqs` primitives directly
//! (aegis-verifier cannot be a dev-dep here — it would create a circular dependency since
//! aegis-verifier already depends on aegis-core). Verification uses `verify_with_ctx_str`
//! with ctx `b"AEGIS-STH-v1"` per AD-1.6-02 dual-layer domain separation.

use std::sync::Arc;

use aegis_core::serialization::encode_signed_tree_head;
use aegis_core::signing::{
    compute_log_id, ensure_oqs_init, MlDsaSigner, SignedTreeHead, TreeHeadDataV2,
};

/// AC-1.5-32: 32 threads × 100 calls on shared `Arc<MlDsaSigner>` — no panic, no data corruption.
#[test]
fn concurrent_sign_32_threads_100_calls_shared_signer_no_panic() {
    ensure_oqs_init();
    let signer = Arc::new(MlDsaSigner::new().unwrap());
    let ca_pubkey: [u8; 1952] = signer.public_key().try_into().unwrap();

    let handles: Vec<_> = (0u64..32)
        .map(|thread_id| {
            let s = Arc::clone(&signer);
            std::thread::spawn(move || {
                let mut sigs = Vec::with_capacity(100);
                for i in 0..100u64 {
                    // Deterministic, monotonic-within-thread timestamps.
                    let tree_head = TreeHeadDataV2 {
                        timestamp: 1_700_000_000_000 + (thread_id * 100) + i,
                        tree_size: 1,
                        root_hash: [0xAA; 32],
                        sth_extensions: vec![],
                    };
                    let sig = s.sign_tree_root(&tree_head).unwrap();
                    sigs.push((tree_head, sig));
                }
                sigs
            })
        })
        .collect();

    let mut all_sigs: Vec<(TreeHeadDataV2, Vec<u8>)> = Vec::with_capacity(32 * 100);
    for h in handles {
        all_sigs.extend(h.join().unwrap());
    }
    assert_eq!(all_sigs.len(), 3200, "must produce exactly 3200 signatures");

    // Verify a sampling to confirm no data corruption under concurrency.
    // step_by(50) gives 64 samples, fitting comfortably within the 5s budget.
    // Verification uses oqs primitives directly (avoids circular aegis-verifier dep).
    // Uses verify_with_ctx_str per AD-1.6-02 dual-layer domain separation.
    let sig_alg = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65)
        .expect("oqs MlDsa65 must initialize for sampling verification");
    let log_id = compute_log_id(&ca_pubkey);
    let pk_ref = sig_alg
        .public_key_from_bytes(&ca_pubkey)
        .expect("valid 1952-byte public key must parse");

    let mut verified_count = 0usize;
    for (tree_head, sig_bytes) in all_sigs.iter().step_by(50) {
        // Compute the expected log_id and confirm it matches (sanity check).
        assert_eq!(
            log_id,
            compute_log_id(&ca_pubkey),
            "log_id must be stable across concurrent sign calls"
        );

        // Reconstruct bytes_to_sign via the single canonical extraction path (footgun #46).
        let sth = SignedTreeHead {
            log_id,
            tree_head: tree_head.clone(),
            signature_bytes: Vec::new(),
        };
        let message = encode_signed_tree_head(&sth);

        // Verify using verify_with_ctx_str with FIPS 204 §5.2 ctx (AD-1.6-02).
        let sig_ref = sig_alg
            .signature_from_bytes(sig_bytes)
            .expect("sampled signature bytes must parse (3309-byte invariant)");
        assert!(
            sig_alg
                .verify_with_ctx_str(&message, sig_ref, b"AEGIS-STH-v1", pk_ref)
                .is_ok(),
            "sampled signature must verify with ctx: tree_head={tree_head:?}"
        );
        verified_count += 1;
    }
    eprintln!("concurrent_sign: verified {verified_count} sampled signatures out of 3200 total");
}
