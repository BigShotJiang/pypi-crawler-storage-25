//! Tests confirming oqs runtime capabilities for Aegis Alpha.
//!
//! AC-1.4-37: `MlDsa65` is enabled under workspace's narrowed oqs features.
//! AC-1.6-16: `has_ctx_str_support()` returns true for ML-DSA-65 in the pinned oqs
//!            build (positive); the negative guard path is covered by the inline
//!            unit test in `aegis_core::signing::tests`.

use aegis_core::signing::MlDsaSigner;

/// AC-1.4-37 — `MlDsa65` is enabled under workspace's narrowed oqs features.
///
/// Permanent test replacing the transient Phase 0 P0-3 probe.
/// Per rev-2 Amendment 10 (Stage 5 F-RT-32).
#[test]
fn mldsa65_enabled_under_narrowed_features() {
    oqs::init();
    assert!(
        oqs::sig::Algorithm::MlDsa65.is_enabled(),
        "ML-DSA-65 must be enabled with workspace features [ml_dsa, sigs, std]"
    );
}

/// AC-1.6-16 (positive) — `has_ctx_str_support()` returns `true` for ML-DSA-65
/// in the pinned liboqs 0.13.0 build.
///
/// This test verifies the invariant that our vendored liboqs supports the
/// FIPS 204 §5.2 ctx parameter API. If this test fails, the liboqs version
/// must be updated before Aegis can sign tree heads.
#[test]
fn mldsa65_has_ctx_str_support_is_true() {
    oqs::init();
    let sig = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65)
        .expect("oqs::sig::Sig::new(MlDsa65) must succeed");
    assert!(
        sig.has_ctx_str_support(),
        "ML-DSA-65 must report has_ctx_str_support() = true in liboqs 0.13.0 (pinned)"
    );
}

/// AC-1.6-16 (positive, via `MlDsaSigner`) — `MlDsaSigner::new()` succeeds when
/// `has_ctx_str_support()` returns true, confirming the guard does not block normal operation.
#[test]
fn mldsa_signer_new_succeeds_with_ctx_str_support() {
    let result = MlDsaSigner::new();
    assert!(
        result.is_ok(),
        "MlDsaSigner::new() must return Ok(()) when has_ctx_str_support() is true"
    );
}
