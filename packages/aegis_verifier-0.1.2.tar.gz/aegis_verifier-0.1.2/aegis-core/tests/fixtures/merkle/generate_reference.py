#!/usr/bin/env python3
"""
Aegis Slice 1.3 — RFC 9162 §2.1.1 + §2.1.3.1 reference implementation.

Purpose: Generate trustworthy ground-truth fixture data for conformance testing
of the Rust `aegis_core::merkle` module. This script is the load-bearing
P0-5 CRITICAL gate per SLICE-1.3-BRIEF.md — if the script's self-check fails,
the conformance fixture is untrustworthy and Phase 0 must abort.

This script is committed to the repo as the locked specification of how the
fixture is constructed. Any modification to this script requires Planning Space
authorization and constitutes a deviation (D-N emission).

Locked by Aegis Planning Space council, 2026-04-21, alongside D-9-S1.3.
"""
import hashlib
import json
import sys

# =============================================================================
# Locked self-check constants — both independently verified by Planning Space.
# Computed via Python hashlib in Planning Space, 2026-04-21.
# Cross-verified against RFC 9162 §2.1.1 reference (Zenn walkthrough + RFC primary source).
# =============================================================================

# Two-leaf root: SHA-256(0x01 || [0x00; 32] || [0x01; 32])
# Per RFC 9162 §2.1.1: MTH({d[0], d[1]}) where d[i] are pre-hashed leaves.
# This constant is the LOCKED self-check anchor inherited from SLICE-1.3-BRIEF.md §11 footgun 5.
EXPECTED_TWO_LEAF_ROOT_HEX = "2ad82c3a51e8ed6418cb5bf267c5f9e521b99f7ab4fce657f460a8f1a3e87b2e"

# Seven-leaf root: MTH on convention (c) leaves where leaf[i] = bytes([i] * 32).
# Tree shape per §2.1.5 example: split-at-largest-power-of-2 with k=4 for n=7.
# Independently computed by Planning Space; embedded as defense-in-depth.
EXPECTED_SEVEN_LEAF_ROOT_HEX = "98ae081d6eda8de09ed5f8c5e8c7dfeec6b128e9b7f37670b3c5c2ede966212b"

# =============================================================================
# RFC 9162 §2.1.1 Merkle Tree Hash (MTH) reference implementation.
# Aegis pre-hashed-leaf convention: input list elements are already SHA-256(0x00 || leaf_data).
# Therefore MTH({d[0]}) returns d[0] directly (single-leaf identity), per §11 footgun 3.
# =============================================================================

def sha256(data: bytes) -> bytes:
    """SHA-256 hash. Returns 32 bytes."""
    return hashlib.sha256(data).digest()


def mth(leaves):
    """
    Merkle Tree Hash per RFC 9162 §2.1.1.

    Args:
        leaves: list of 32-byte values (pre-hashed leaves under Aegis convention)

    Returns:
        32-byte root hash

    Note: For single-leaf input under Aegis convention, returns leaves[0] directly.
    This is §2.1.1 conformant because Aegis leaves are pre-hashed via hash_leaf()
    BEFORE entering this MTH function. See SLICE-1.3-BRIEF.md §11 footgun 3.
    """
    n = len(leaves)
    if n == 0:
        # Empty tree: §2.1.1 says MTH({}) = HASH(""). Aegis rejects empty trees
        # at MerkleTree::new (returns EmptyTree error), so this branch should
        # never fire from production code; included for §2.1.1 completeness.
        return sha256(b'')
    if n == 1:
        # Single-leaf identity per Aegis pre-hashed-leaf convention.
        return leaves[0]
    # Find k = largest power of 2 strictly less than n.
    k = 1
    while k * 2 < n:
        k *= 2
    left = mth(leaves[:k])
    right = mth(leaves[k:])
    # Internal-node prefix 0x01 per §2.1.1 second-preimage-resistance domain separation.
    return sha256(bytes([0x01]) + left + right)


def path(m: int, leaves) -> list:
    """
    Inclusion proof PATH(m, D_n) per RFC 9162 §2.1.3.1.

    Args:
        m: 0-based leaf index (must satisfy 0 <= m < len(leaves))
        leaves: list of 32-byte values

    Returns:
        list of 32-byte sibling hashes constituting the inclusion path

    Per §2.1.3.1 recursive definition:
        PATH(0, {d[0]}) = {}
        PATH(m, D_n) = PATH(m, D[0:k]) : MTH(D[k:n])     for m < k
        PATH(m, D_n) = PATH(m - k, D[k:n]) : MTH(D[0:k]) for m >= k
    where k is the largest power of 2 strictly less than n.
    """
    n = len(leaves)
    if n == 1:
        return []
    k = 1
    while k * 2 < n:
        k *= 2
    if m < k:
        return path(m, leaves[:k]) + [mth(leaves[k:])]
    else:
        return path(m - k, leaves[k:]) + [mth(leaves[:k])]


# =============================================================================
# Self-check: BOTH locked constants must reproduce. Failure = abort Phase 0.
# =============================================================================

def run_self_check() -> bool:
    """
    Two independent self-checks against locked constants.
    Both must pass; either failure means the script logic is wrong
    (not the fixture data) and Phase 0 must abort.
    """
    # Check 1: Two-leaf root — direct §2.1.1 computation
    two_leaf_input = bytes([0x01]) + bytes([0x00] * 32) + bytes([0x01] * 32)
    two_leaf_actual = sha256(two_leaf_input).hex()
    if two_leaf_actual != EXPECTED_TWO_LEAF_ROOT_HEX:
        print(f"SELF-CHECK FAIL: two-leaf root mismatch", file=sys.stderr)
        print(f"  expected: {EXPECTED_TWO_LEAF_ROOT_HEX}", file=sys.stderr)
        print(f"  actual:   {two_leaf_actual}", file=sys.stderr)
        return False

    # Check 2: Seven-leaf root via mth() on convention (c) leaves
    seven_leaves = [bytes([i] * 32) for i in range(7)]
    seven_leaf_actual = mth(seven_leaves).hex()
    if seven_leaf_actual != EXPECTED_SEVEN_LEAF_ROOT_HEX:
        print(f"SELF-CHECK FAIL: seven-leaf root mismatch", file=sys.stderr)
        print(f"  expected: {EXPECTED_SEVEN_LEAF_ROOT_HEX}", file=sys.stderr)
        print(f"  actual:   {seven_leaf_actual}", file=sys.stderr)
        return False

    # Both checks passed
    return True


# =============================================================================
# Fixture emission.
# =============================================================================

def generate_fixture():
    """Generate the 7-leaf fixture JSON per SLICE-1.3-BRIEF.md §5 P0-5 spec."""
    leaves = [bytes([i] * 32) for i in range(7)]
    root = mth(leaves)
    covered_indices = [0, 2, 3, 4, 6]

    fixture = {
        "spec": "RFC 9162 §2.1.1 + §2.1.3.1",
        "convention": "Aegis pre-hashed-leaf convention (c): leaf[i] = bytes([i] * 32) for i in 0..7",
        "tree_size": 7,
        "leaves_hex": [leaf.hex() for leaf in leaves],
        "root_hex": root.hex(),
        "inclusion_proofs": [
            {
                "leaf_index": idx,
                "leaf_hex": leaves[idx].hex(),
                "inclusion_path_hex": [sibling.hex() for sibling in path(idx, leaves)],
            }
            for idx in covered_indices
        ],
    }
    return fixture


# =============================================================================
# Main.
# =============================================================================

def main():
    # Self-check ALWAYS runs first. If it fails, abort with non-zero exit.
    if not run_self_check():
        print("SELF-CHECK FAIL — script logic is wrong, do NOT trust fixture output", file=sys.stderr)
        sys.exit(1)

    # Self-check passed. Print pass marker as first stdout line per brief §5 P0-5 spec.
    print("SELF-CHECK PASS")

    # Emit fixture JSON to stdout for capture (Claude Code redirects to .json file).
    fixture = generate_fixture()
    print(json.dumps(fixture, indent=2))


if __name__ == "__main__":
    main()
