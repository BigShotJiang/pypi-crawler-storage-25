//! AC-1.5-07 — JSON round-trip for [`MTACIssuanceResult`].
//!
//! Constructs a fixture `MTACIssuanceResult` with deterministic values,
//! serializes to JSON via `serde_json`, deserializes back, and asserts equality.
//! No cryptographic verification — this is a serde round-trip test only.

use aegis_core::issuance::MTACIssuanceResult;
use aegis_core::merkle::InclusionProof;
use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};
use uuid::Uuid;

/// Build a deterministic [`MTACIssuanceResult`] fixture.
///
/// 2-leaf tree: inclusion proof has one 32-byte sibling.
/// Signature bytes are zeroed (not cryptographically valid — serde only).
fn fixture_issuance_result() -> MTACIssuanceResult {
    // Fixed UUID v7 string — deterministic for test repeatability.
    let batch_id = Uuid::parse_str("018d6b9a-2c3d-7000-8000-000000000001").unwrap();

    let inclusion_proof = InclusionProof {
        tree_size: 2,
        leaf_index: 1,
        // One sibling: the left leaf hash in a 2-leaf tree.
        inclusion_path: vec![[0xAA; 32]],
    };

    let signed_tree_head = SignedTreeHead {
        log_id: [0xAA; 32],
        tree_head: TreeHeadDataV2 {
            timestamp: 12345,
            tree_size: 4,
            root_hash: [0xBB; 32],
            sth_extensions: vec![],
        },
        // 3309 zero bytes — structurally valid length, not a real signature.
        signature_bytes: vec![0u8; 3309],
    };

    MTACIssuanceResult {
        batch_id,
        leaf_index: 3,
        inclusion_proof,
        signed_tree_head,
    }
}

/// AC-1.5-07: `MTACIssuanceResult` survives a JSON serialize → deserialize round-trip.
#[test]
fn issuance_result_json_roundtrip() {
    let original = fixture_issuance_result();
    let json = serde_json::to_string(&original).expect("serialize MTACIssuanceResult to JSON");
    let restored: MTACIssuanceResult =
        serde_json::from_str(&json).expect("deserialize MTACIssuanceResult from JSON");
    assert_eq!(
        original, restored,
        "MTACIssuanceResult must survive a JSON round-trip unchanged"
    );
}
