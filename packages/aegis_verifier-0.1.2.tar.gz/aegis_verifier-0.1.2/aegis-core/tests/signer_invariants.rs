//! Compile-time invariants for `MlDsaSigner` trait bounds.
//! Covers AC-1.4-36 (rev-2 Amendment 8, Stage 5 F-RT-36 + F-PP-009).
//!
//! These assertions encode hard constraints:
//! - HC #23: `MlDsaSigner` must NOT derive `Clone`, `Debug`, or `Default`.
//!   Secret key material must not be cloneable or debug-printable.
//! - Slice 3 Gateway concurrent-use precondition: `MlDsaSigner` must be `Send + Sync`.

use aegis_core::signing::MlDsaSigner;
use static_assertions::{assert_impl_all, assert_not_impl_any};

// Concurrent-use invariant: `MlDsaSigner` must be usable across thread boundaries.
// `oqs::sig::Sig` has `unsafe impl Sync + Send`; `Zeroizing<Vec<u8>>` is `Send + Sync`;
// `oqs::sig::PublicKey` (Vec<u8> wrapper) is `Send + Sync`.
assert_impl_all!(MlDsaSigner: Send, Sync);

// Security invariant: secret key material must not be cloneable or debug-printable.
// HC #23 mandates no `#[derive(Clone, Debug, Default)]` on `MlDsaSigner`.
assert_not_impl_any!(MlDsaSigner: Clone, std::fmt::Debug, Default);

/// AC-1.4-36 — `MlDsaSigner` compile-time invariants (Send + Sync; !Clone + !Debug + !Default).
///
/// The static assertions above encode the invariants at compile time.
/// This `#[test]` function exists so they are visible in `cargo nextest` output.
#[test]
fn signer_send_sync_not_clone_debug_default() {
    // The compile-time assertions above are the real checks.
    // If we reach this line, all invariants held.
}
