//! Envelope encoding tests for wire-v1 format.
//!
//! Per AC-1.6-10: verifies that:
//! - `encode_sth_envelope_v1` produces a CBOR array of 2 elements (first byte = 0x82).
//! - Element 0 is text "AEGIS-STH-v1", verified VIA `WIRE_VERSION` constant (NOT a
//!   hardcoded string literal in the assertion).
//! - Element 1 is bstr containing body bytes verbatim.
//!
//! Phase 1 compile-skip: encoder functions are gated behind `wire-v1-encoder` feature.
//! The `wire_version_constant_is_aegis_sth_v1` test compiles and runs immediately in
//! Phase 1 since it only depends on `WIRE_VERSION` (present in the Phase 1 stub).
//!
//! Teammate A activates the gated tests in Phase 2 by removing the cfg gate or adding
//! the `wire-v1-encoder` feature.

// ---------------------------------------------------------------------------
// Phase 1: compile immediately — only depends on WIRE_VERSION
// ---------------------------------------------------------------------------

/// AC-1.6-10 (Phase 1): `WIRE_VERSION` constant value and 255-byte FIPS 204 invariant.
///
/// The test verifies the value, length, and FIPS 204 §5.2 constraint without
/// depending on the Phase 2 encoder.
#[test]
fn wire_version_constant_is_aegis_sth_v1() {
    use aegis_core::serialization::WIRE_VERSION;
    assert_eq!(WIRE_VERSION, "AEGIS-STH-v1");
    assert_eq!(
        WIRE_VERSION.len(),
        12,
        "WIRE_VERSION must be exactly 12 bytes"
    );
    assert!(
        WIRE_VERSION.len() <= 255,
        "WIRE_VERSION must fit in FIPS 204 ctx (255 bytes)"
    );
}

// ---------------------------------------------------------------------------
// Phase 2: encoder functions now available; cfg gate removed by Teammate A.
// ---------------------------------------------------------------------------
mod envelope_encoder_tests {
    use aegis_core::serialization::{encode_sth_body_v1, encode_sth_envelope_v1, WIRE_VERSION};

    // -----------------------------------------------------------------------
    // Helper: parse a CBOR bstr head at `buf[offset]`.
    // Returns (header_len, data_len) for definite-length bstr (major type 2).
    // -----------------------------------------------------------------------
    fn parse_bstr_head(buf: &[u8], offset: usize) -> (usize, usize) {
        let head = buf[offset];
        let major = head >> 5;
        assert_eq!(major, 2, "expected bstr (major type 2) at offset {offset}");
        let additional = head & 0x1f;
        match additional {
            0..=23 => (1, additional as usize),
            24 => (2, buf[offset + 1] as usize),
            25 => {
                let len = u16::from_be_bytes([buf[offset + 1], buf[offset + 2]]) as usize;
                (3, len)
            }
            26 => {
                let len = u32::from_be_bytes([
                    buf[offset + 1],
                    buf[offset + 2],
                    buf[offset + 3],
                    buf[offset + 4],
                ]) as usize;
                (5, len)
            }
            _ => panic!("unsupported bstr additional value {additional}"),
        }
    }

    // -----------------------------------------------------------------------
    // Helper: parse a CBOR tstr head at `buf[offset]`.
    // Returns (header_len, str_len) for definite-length tstr (major type 3).
    // -----------------------------------------------------------------------
    fn parse_tstr_head(buf: &[u8], offset: usize) -> (usize, usize) {
        let head = buf[offset];
        let major = head >> 5;
        assert_eq!(major, 3, "expected tstr (major type 3) at offset {offset}");
        let additional = head & 0x1f;
        match additional {
            0..=23 => (1, additional as usize),
            24 => (2, buf[offset + 1] as usize),
            25 => {
                let len = u16::from_be_bytes([buf[offset + 1], buf[offset + 2]]) as usize;
                (3, len)
            }
            _ => panic!("unsupported tstr additional value {additional}"),
        }
    }

    fn canonical_body() -> Vec<u8> {
        encode_sth_body_v1(&[0xAA; 32], 42, 1_713_787_200_000, &[0xBB; 32], &[])
    }

    // -----------------------------------------------------------------------
    // Test: envelope starts with CBOR array(2) = 0x82
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_starts_with_array2() {
        let body = canonical_body();
        let envelope = encode_sth_envelope_v1(&body);
        assert_eq!(
            envelope[0], 0x82,
            "envelope must begin with CBOR array(2) byte 0x82"
        );
    }

    // -----------------------------------------------------------------------
    // Test: element 0 of envelope is tstr equal to WIRE_VERSION (not hardcoded)
    //
    // IMPORTANT: assertion uses `WIRE_VERSION` constant per AC-1.6-10 requirement.
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_element_0_is_wire_version_tstr() {
        let body = canonical_body();
        let envelope = encode_sth_envelope_v1(&body);

        // element 0 starts at index 1 (after 0x82 array head)
        let (head_len, str_len) = parse_tstr_head(&envelope, 1);
        assert_eq!(
            str_len,
            WIRE_VERSION.len(),
            "tstr length must equal WIRE_VERSION.len()"
        );

        let str_start = 1 + head_len;
        let actual_str = std::str::from_utf8(&envelope[str_start..str_start + str_len])
            .expect("element 0 tstr must be valid UTF-8");
        assert_eq!(
            actual_str, WIRE_VERSION,
            "envelope element 0 must equal WIRE_VERSION"
        );
    }

    // -----------------------------------------------------------------------
    // Test: element 1 of envelope is bstr containing body bytes verbatim
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_element_1_is_body_bstr() {
        let body = canonical_body();
        let envelope = encode_sth_envelope_v1(&body);

        let (tstr_head_len, tstr_str_len) = parse_tstr_head(&envelope, 1);
        let elem1_offset = 1 + tstr_head_len + tstr_str_len;

        let (bstr_head_len, bstr_data_len) = parse_bstr_head(&envelope, elem1_offset);
        assert_eq!(
            bstr_data_len,
            body.len(),
            "bstr in element 1 must match body length"
        );

        let data_start = elem1_offset + bstr_head_len;
        assert_eq!(
            &envelope[data_start..data_start + bstr_data_len],
            body.as_slice(),
            "envelope element 1 bstr content must be byte-identical to the body"
        );
    }

    // -----------------------------------------------------------------------
    // Test: total envelope length equals sum of all parts
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_total_length_is_sum_of_parts() {
        let body = canonical_body();
        let envelope = encode_sth_envelope_v1(&body);

        let wire_len = WIRE_VERSION.len();
        // tstr head: wire_len = 12 ≤ 23 → 1-byte head
        let tstr_head_len = if wire_len <= 23 { 1usize } else { 2 };

        let body_len = body.len();
        let bstr_head_len = if body_len <= 23 {
            1usize
        } else if body_len <= 255 {
            2
        } else {
            3
        };

        let expected_total = 1 + tstr_head_len + wire_len + bstr_head_len + body_len;
        assert_eq!(envelope.len(), expected_total, "envelope total length");
    }

    // -----------------------------------------------------------------------
    // Test: encode_sth_envelope_v1 is deterministic
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_is_deterministic() {
        let body = canonical_body();
        let env1 = encode_sth_envelope_v1(&body);
        let env2 = encode_sth_envelope_v1(&body);
        assert_eq!(env1, env2, "encode_sth_envelope_v1 must be deterministic");
    }

    // -----------------------------------------------------------------------
    // Test: envelope wraps an empty body as CBOR bstr(0) = 0x40
    // -----------------------------------------------------------------------
    #[test]
    fn envelope_wraps_empty_body() {
        let empty_body: &[u8] = &[];
        let envelope = encode_sth_envelope_v1(empty_body);

        let wire_len = WIRE_VERSION.len();
        let tstr_head_len = if wire_len <= 23 { 1usize } else { 2 };
        // empty bstr = 0x40 (major 2, additional 0)
        let last_idx = 1 + tstr_head_len + wire_len;
        assert_eq!(
            envelope[last_idx], 0x40u8,
            "empty body must be encoded as bstr(0) = 0x40"
        );
        assert_eq!(
            envelope.len(),
            last_idx + 1,
            "envelope with empty body has no trailing bytes"
        );
    }
}
