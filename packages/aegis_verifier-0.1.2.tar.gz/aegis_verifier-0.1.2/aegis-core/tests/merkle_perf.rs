//! Perf-gated test. Run via: cargo nextest run --workspace --features perf-gate

#![cfg(feature = "perf-gate")]

use std::time::Instant;

use aegis_core::merkle::{verify, MerkleTree};

/// `BASELINE_NS` captured at end of Phase 4 via `cargo bench --bench merkle_inclusion`
/// on user's WSL2 dev machine. See F-6-S1.3 in HANDOVER-1.3.md §10 for measurement
/// context.
///
/// Release-mode criterion benchmark line:
///   `depth20_verify time: [1.9046 µs 1.9126 µs 1.9210 µs]`
/// Point estimate: 1.9126 µs = 1912.6 ns (release mode).
///
/// This perf-gate test runs under `cargo nextest` (unoptimized/debug profile),
/// which is ~40× slower than release for SHA-256-heavy workloads.
/// Debug-mode median observed during Phase 4: ~75,561 ns.
/// `BASELINE_NS` is therefore set from the debug-mode observation, rounded to
/// nearest 1000 ns = 76,000 ns.  The 2× gate catches real regressions (≥ 152 µs
/// debug-mode) while ignoring transient scheduler noise.
///
/// # D-10-S1.3 deviation
///
/// Brief §8 Phase 3 step 3.5 line 483 directs the `BASELINE_NS` value to come from
/// the `cargo bench` criterion point estimate (release-mode). This file overrides
/// that directive and sources `BASELINE_NS` from debug-mode `Instant` samples
/// instead. Rationale: the brief §16 exit gate runs `cargo nextest run --workspace
/// --features perf-gate`, which is the default debug profile; a release-mode
/// `BASELINE_NS` would render the `median_ns <= 2 * BASELINE_NS` gate meaningless
/// because debug-mode SHA-256 is ~40× slower than release. The gate is calibrated
/// to the actual execution profile so it can catch real regressions without
/// triggering on every run. SSOT revision block scheduled for Phase 6 per HC 23.
const BASELINE_NS: u64 = 76_000;

/// Median-of-5 sampling. N=5 balances signal (absorbs ~30% per-sample scheduler
/// jitter) vs test runtime (~50ms total). Perplexity red-team Vector 6 moderator
/// decision: median-of-5 > single-shot.
const PERF_SAMPLES: usize = 5;

#[test]
fn depth20_verify_perf() {
    // Construct depth-20 tree with deterministic leaves
    let leaves: Vec<[u8; 32]> = (0..1_048_576_u32)
        .map(|i| {
            let mut leaf = [0u8; 32];
            leaf[..4].copy_from_slice(&i.to_le_bytes());
            leaf
        })
        .collect();
    let tree = MerkleTree::new(&leaves).expect("depth-20 tree construction");
    let root = tree.root();
    let proof = tree.proof(500_000).expect("proof for index 500000");
    let leaf_hash = leaves[500_000];

    // Warmup (populate caches, warm instruction pipeline)
    for _ in 0..10 {
        let _ = verify(leaf_hash, &proof, root);
    }

    // Median-of-5 sampling
    let mut samples = [0u64; PERF_SAMPLES];
    for (i, sample) in samples.iter_mut().enumerate() {
        let start = Instant::now();
        let ok = verify(leaf_hash, &proof, root);
        *sample = u64::try_from(start.elapsed().as_nanos())
            .expect("128-bit nanos overflow — unreachable");
        assert!(ok, "verify returned false on valid proof (sample {i})");
    }
    samples.sort_unstable();
    let median_ns = samples[PERF_SAMPLES / 2]; // index 2 for N=5

    assert!(
        median_ns <= 2 * BASELINE_NS,
        "depth-20 verify median {median_ns}ns over {PERF_SAMPLES} runs, gate = 2×{BASELINE_NS} = {gate}ns. All samples (sorted ns): {samples:?}",
        gate = 2 * BASELINE_NS
    );
}
