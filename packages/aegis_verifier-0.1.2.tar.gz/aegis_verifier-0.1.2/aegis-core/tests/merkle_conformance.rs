//! Integration tests for RFC 9162 §2.1.1 + §2.1.3.1 + §2.1.3.2 conformance against
//! the Planning-locked `generate_reference.py` fixture. See D-9-S1.3.

use aegis_core::merkle::{verify, InclusionProof, MerkleTree};
use serde::Deserialize;

const FIXTURE_JSON: &str = include_str!("fixtures/merkle/rfc9162_7leaf_vectors.json");

#[derive(Deserialize)]
struct Fixture {
    tree_size: u64,
    leaves_hex: Vec<String>,
    root_hex: String,
    inclusion_proofs: Vec<FixtureProof>,
}

#[derive(Deserialize)]
struct FixtureProof {
    leaf_index: u64,
    leaf_hex: String,
    inclusion_path_hex: Vec<String>,
}

fn decode_32(hex_str: &str) -> [u8; 32] {
    let bytes = hex::decode(hex_str).expect("invalid hex in fixture");
    assert_eq!(bytes.len(), 32, "expected 32-byte hex in fixture");
    let mut arr = [0u8; 32];
    arr.copy_from_slice(&bytes);
    arr
}

fn load_fixture() -> Fixture {
    serde_json::from_str(FIXTURE_JSON).expect("fixture JSON parse failed")
}

fn leaves_from_fixture(f: &Fixture) -> Vec<[u8; 32]> {
    f.leaves_hex.iter().map(|s| decode_32(s)).collect()
}

#[test]
fn seven_leaf_root_matches_fixture() {
    // AC-1.3-06
    let f = load_fixture();
    let leaves = leaves_from_fixture(&f);
    let tree = MerkleTree::new(&leaves).expect("seven-leaf tree construction");
    assert_eq!(tree.tree_size(), f.tree_size);
    assert_eq!(tree.root(), decode_32(&f.root_hex));
}

#[test]
fn seven_leaf_proof_all_covered_indices() {
    // AC-1.3-09 — parameterized over indices 0, 2, 3, 4, 6
    let f = load_fixture();
    let leaves = leaves_from_fixture(&f);
    let tree = MerkleTree::new(&leaves).expect("seven-leaf tree construction");
    for fp in &f.inclusion_proofs {
        let proof = tree.proof(fp.leaf_index).expect("proof generation");
        assert_eq!(
            proof.tree_size, f.tree_size,
            "tree_size for leaf {}",
            fp.leaf_index
        );
        assert_eq!(proof.leaf_index, fp.leaf_index, "leaf_index");
        assert_eq!(
            proof.inclusion_path.len(),
            fp.inclusion_path_hex.len(),
            "path length for leaf {}",
            fp.leaf_index
        );
        for (i, (computed, expected)) in proof
            .inclusion_path
            .iter()
            .zip(fp.inclusion_path_hex.iter())
            .enumerate()
        {
            assert_eq!(
                *computed,
                decode_32(expected),
                "path[{}] for leaf {}",
                i,
                fp.leaf_index
            );
        }
    }
}

#[test]
fn seven_leaf_proof_rightmost_length_two() {
    // AC-1.3-10 — explicit unbalanced-tree-shape invariant
    let f = load_fixture();
    let leaves = leaves_from_fixture(&f);
    let tree = MerkleTree::new(&leaves).expect("seven-leaf tree construction");
    let proof = tree.proof(6).expect("proof for rightmost leaf");
    assert_eq!(proof.inclusion_path.len(), 2);
}

#[test]
fn fixture_proofs_all_verify() {
    // AC-1.3-16 — all 5 fixture proofs (indices 0, 2, 3, 4, 6) verify GREEN.
    // Indices 2 and 4 are the rev-1-bug-class regression net: they fail under
    // the incorrect pseudocode (inner loop hoisted above branch) and pass only
    // under the correct rev-2 pseudocode. See §11 footgun 21 and rev-2 §1 item 1.
    let f = load_fixture();
    let leaves = leaves_from_fixture(&f);
    let tree = MerkleTree::new(&leaves).expect("seven-leaf tree construction");
    let root = decode_32(&f.root_hex);
    assert_eq!(tree.root(), root);

    for fp in &f.inclusion_proofs {
        let inclusion_path: Vec<[u8; 32]> =
            fp.inclusion_path_hex.iter().map(|s| decode_32(s)).collect();
        let proof = InclusionProof {
            tree_size: f.tree_size,
            leaf_index: fp.leaf_index,
            inclusion_path,
        };
        let leaf_hash = decode_32(&fp.leaf_hex);
        assert!(
            verify(leaf_hash, &proof, root),
            "verify failed for leaf_index {}",
            fp.leaf_index
        );
    }
}

// AC-1.3-20a: Python attestation — feature-gated on `python-attestation`.
//
// Runs `generate_reference.py`, verifies it emits "SELF-CHECK PASS" on the
// first stdout line, then compares its JSON output structurally against the
// committed `rfc9162_7leaf_vectors.json` fixture.  Any drift between the
// Python reference implementation and the committed fixture is a hard failure.
#[cfg(feature = "python-attestation")]
#[test]
fn fixture_matches_reference_script() {
    use std::process::Command;

    let script_path = format!(
        "{}/tests/fixtures/merkle/generate_reference.py",
        env!("CARGO_MANIFEST_DIR")
    );

    let output = Command::new("python3")
        .arg(&script_path)
        .output()
        .expect("python3 not available or script missing — RESEARCH REQUESTED");

    assert!(
        output.status.success(),
        "generate_reference.py failed: stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    let mut lines = stdout.lines();
    let first = lines.next().expect("empty stdout — RESEARCH REQUESTED");
    assert_eq!(
        first, "SELF-CHECK PASS",
        "Python script self-check failed — RESEARCH REQUESTED"
    );

    let json_text: String = lines.collect::<Vec<_>>().join("\n");
    let script_val: serde_json::Value =
        serde_json::from_str(&json_text).expect("script emitted invalid JSON");

    // Structural comparison — handles whitespace and key-ordering differences.
    let committed: serde_json::Value =
        serde_json::from_str(FIXTURE_JSON).expect("committed fixture JSON failed to parse");

    assert_eq!(
        script_val, committed,
        "script output differs from committed fixture — fixture drift detected"
    );
}
