//! Tests for `SigError` display format.
//! Covers AC-1.4-12, AC-1.4-16, AC-1.6-16.

use aegis_core::signing::SigError;

/// AC-1.4-12 / AC-1.6-16 — All five `SigError` variants have correctly formatted
/// `Display` output.
#[test]
fn sig_error_display_format() {
    // KeygenFailed: prefix must match exactly.
    let e = SigError::KeygenFailed(oqs::Error::Error);
    let s = e.to_string();
    assert!(
        s.starts_with("ML-DSA-65 keypair generation failed: "),
        "KeygenFailed display must start with expected prefix, got: {s:?}"
    );

    // SignFailed: prefix must match exactly.
    let e = SigError::SignFailed(oqs::Error::Error);
    let s = e.to_string();
    assert!(
        s.starts_with("ML-DSA-65 signing failed: "),
        "SignFailed display must start with expected prefix, got: {s:?}"
    );

    // SignatureLengthInvariant: exact format with embedded length.
    let e = SigError::SignatureLengthInvariant(0);
    let s = e.to_string();
    assert_eq!(
        s, "signature length invariant violated: expected 3309, got 0",
        "SignatureLengthInvariant(0) display must match exactly"
    );

    // SecretKeyReconstructionFailed: exact format (no payload).
    let e = SigError::SecretKeyReconstructionFailed;
    let s = e.to_string();
    assert_eq!(
        s, "ML-DSA-65 secret key reconstruction from stored bytes failed",
        "SecretKeyReconstructionFailed display must match exactly"
    );

    // CtxStrNotSupported: must contain key phrase describing the requirement.
    let e = SigError::CtxStrNotSupported;
    let s = e.to_string();
    assert!(
        s.contains("ctx_str signing not supported"),
        "CtxStrNotSupported display must mention ctx_str, got: {s:?}"
    );
}

/// AC-1.4-16 — `SigError::SignatureLengthInvariant(N)` has exact display format.
#[test]
fn signature_length_invariant_display() {
    let s0 = SigError::SignatureLengthInvariant(0).to_string();
    assert_eq!(
        s0, "signature length invariant violated: expected 3309, got 0",
        "SignatureLengthInvariant(0) must produce exact string"
    );

    let s9999 = SigError::SignatureLengthInvariant(9999).to_string();
    assert_eq!(
        s9999, "signature length invariant violated: expected 3309, got 9999",
        "SignatureLengthInvariant(9999) must produce exact string"
    );
}
