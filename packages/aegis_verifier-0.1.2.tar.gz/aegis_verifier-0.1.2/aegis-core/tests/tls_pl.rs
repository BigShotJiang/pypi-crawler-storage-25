//! Wire format signing round-trip tests.
//!
//! `serialize_tree_head_tls_pl` was deleted in Slice 1.6 (AC-1.6-13) and replaced
//! by the canonical CBOR encoder in `aegis_core::serialization`. This file now tests
//! the wire-format signing path (encode → sign → verify bytes round-trip).
//!
//! Original AC-1.4-13/14/27 TLS-PL tests are superseded by AC-1.6-08 KAT vectors
//! in `serialization_kat.rs`.

use aegis_core::serialization::{encode_sth_body_v1, encode_sth_envelope_v1, WIRE_VERSION};

/// Wire format body is deterministic — two calls with identical input produce byte-equal output.
///
/// Replaces the former AC-1.4-14 TLS-PL determinism test.
#[test]
fn wire_format_body_is_deterministic() {
    let log_id = [0xAB; 32];
    let root_hash = [0xCD; 32];
    let out1 = encode_sth_body_v1(&log_id, 42, 1_700_000_000_000, &root_hash, &[]);
    let out2 = encode_sth_body_v1(&log_id, 42, 1_700_000_000_000, &root_hash, &[]);
    assert_eq!(out1, out2, "encode_sth_body_v1 must be deterministic");
}

/// Wire format envelope is deterministic.
#[test]
fn wire_format_envelope_is_deterministic() {
    let body = encode_sth_body_v1(&[0xAA; 32], 1, 2, &[0xBB; 32], &[]);
    let env1 = encode_sth_envelope_v1(&body);
    let env2 = encode_sth_envelope_v1(&body);
    assert_eq!(env1, env2, "encode_sth_envelope_v1 must be deterministic");
}

/// Wire format body starts with CBOR `array(5)` = `0x85`.
#[test]
fn wire_format_body_starts_with_array5() {
    let body = encode_sth_body_v1(&[0xAA; 32], 0, 0, &[0xBB; 32], &[]);
    assert_eq!(
        body[0], 0x85,
        "sth_body must start with CBOR array(5) = 0x85"
    );
}

/// Wire format envelope starts with CBOR `array(2)` = `0x82` and embeds `WIRE_VERSION`.
#[test]
fn wire_format_envelope_structure() {
    let body = encode_sth_body_v1(&[0xAA; 32], 0, 0, &[0xBB; 32], &[]);
    let envelope = encode_sth_envelope_v1(&body);

    // Outer: CBOR array(2)
    assert_eq!(
        envelope[0], 0x82,
        "envelope must begin with CBOR array(2) = 0x82"
    );

    // Element 0: tstr(12) = 0x6c then WIRE_VERSION bytes
    // WIRE_VERSION.len() = 12 ≤ 23 → 1-byte head: 0x60 | 12 = 0x6c
    assert_eq!(
        envelope[1], 0x6c,
        "tstr head for 12-byte WIRE_VERSION must be 0x6c"
    );
    assert_eq!(
        &envelope[2..14],
        WIRE_VERSION.as_bytes(),
        "WIRE_VERSION bytes must follow tstr head"
    );
}
