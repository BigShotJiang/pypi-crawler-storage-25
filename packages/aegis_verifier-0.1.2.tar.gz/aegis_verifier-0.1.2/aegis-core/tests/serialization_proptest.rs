//! Property-based tests for the wire-v1 encoder.
//!
//! Per AC-1.6-09: ≥1024 random `SignedTreeHead` instances; round-trip determinism
//! (`encode(x) == encode(x)`) holds across reruns.
//!
//! Phase 1 compile-skip: tests depending on Phase 2 encoder functions are gated
//! behind the `wire-v1-encoder` feature (which does not exist in Phase 1).
//! Teammate A activates them in Phase 2 by removing the cfg gate or adding the feature.
//!
//! Config note: AC-1.6-09 requires ≥1024 cases. These use `cases: 1024` via
//! `ProptestConfig`. If wall-clock exceeds 30s, emit F-140 and reduce to 256.

// Phase 2+: encoder functions now available; cfg gate removed by Teammate A.
mod encoder_proptests {
    use aegis_core::serialization::{encode_sth_body_v1, Extension};
    use proptest::prelude::*;

    // -----------------------------------------------------------------------
    // Proptest strategies
    // -----------------------------------------------------------------------

    fn arb_hash32() -> impl Strategy<Value = [u8; 32]> {
        proptest::array::uniform32(any::<u8>())
    }

    fn arb_extension() -> impl Strategy<Value = Extension> {
        (
            any::<u16>(),
            proptest::collection::vec(any::<u8>(), 0..=300usize),
        )
            .prop_map(|(extension_type, extension_data)| Extension {
                extension_type,
                extension_data,
            })
    }

    fn arb_extensions() -> impl Strategy<Value = Vec<Extension>> {
        proptest::collection::vec(arb_extension(), 0..=5usize)
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09: encode_sth_body_v1 is deterministic (1024 cases)
    //
    // Two calls with identical inputs must produce bit-identical output.
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 1024,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_encode_sth_body_deterministic(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            let out1 = encode_sth_body_v1(&log_id, tree_size, timestamp, &root_hash, &extensions);
            let out2 = encode_sth_body_v1(&log_id, tree_size, timestamp, &root_hash, &extensions);
            prop_assert_eq!(out1, out2, "encode_sth_body_v1 must be deterministic");
        }
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09: output is non-empty (1024 cases)
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 1024,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_encode_sth_body_nonempty(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            let out = encode_sth_body_v1(&log_id, tree_size, timestamp, &root_hash, &extensions);
            prop_assert!(!out.is_empty(), "encode_sth_body_v1 must never produce empty output");
        }
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09: first byte is always 0x85 (CBOR array(5)) (1024 cases)
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 1024,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_encode_sth_body_starts_with_array5(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            let out = encode_sth_body_v1(&log_id, tree_size, timestamp, &root_hash, &extensions);
            prop_assert_eq!(out[0], 0x85u8, "sth_body must always begin with CBOR array(5) = 0x85");
        }
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09: different log_id inputs produce different outputs (512 cases)
    //
    // Changing log_id must change the output — guards against incorrect field
    // omission or merging.
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 512,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_different_log_id_produces_different_output(
            log_id_a in arb_hash32(),
            log_id_b in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            prop_assume!(log_id_a != log_id_b);
            let out_a = encode_sth_body_v1(&log_id_a, tree_size, timestamp, &root_hash, &extensions);
            let out_b = encode_sth_body_v1(&log_id_b, tree_size, timestamp, &root_hash, &extensions);
            prop_assert_ne!(
                out_a, out_b,
                "different log_id inputs must produce different encoded outputs"
            );
        }
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09 (Phase 3): encode_signed_tree_head determinism (1024 cases)
    //
    // After Phase 3 lands (sth_extensions migrated to Vec<Extension>,
    // encode_signed_tree_head added per wire-v1.md §3.2), this verifies the
    // full-STH encoding path.
    //
    // Depends on AC-1.6-12 (sth_extensions migration) and Phase 3 code.
    // Currently gated with the rest of the Phase 2 tests; a separate activation
    // step is needed when Phase 3 lands.
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 1024,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_encode_signed_tree_head_deterministic(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            use aegis_core::serialization::encode_signed_tree_head;
            use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};

            let sth = SignedTreeHead {
                log_id,
                tree_head: TreeHeadDataV2 {
                    timestamp,
                    tree_size,
                    root_hash,
                    sth_extensions: extensions,
                },
                signature_bytes: vec![0xAB; 3309],
            };
            let out1 = encode_signed_tree_head(&sth);
            let out2 = encode_signed_tree_head(&sth);
            prop_assert_eq!(out1, out2, "encode_signed_tree_head must be deterministic");
        }
    }

    // -----------------------------------------------------------------------
    // AC-1.6-09: extension list order is preserved (256 cases)
    //
    // [ext_a, ext_b] and [ext_b, ext_a] must produce DIFFERENT outputs when
    // ext_a != ext_b — encoder preserves list order, does not sort.
    // -----------------------------------------------------------------------
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 256,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_extension_encoding_order_preserved(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            ext_a in arb_extension(),
            ext_b in arb_extension(),
        ) {
            let out_ab = encode_sth_body_v1(
                &log_id, tree_size, timestamp, &root_hash,
                &[ext_a.clone(), ext_b.clone()],
            );
            let out_ba = encode_sth_body_v1(
                &log_id, tree_size, timestamp, &root_hash,
                &[ext_b.clone(), ext_a.clone()],
            );
            if ext_a == ext_b {
                prop_assert_eq!(
                    out_ab, out_ba,
                    "identical extensions in both orders produce same bytes"
                );
            } else {
                prop_assert_ne!(
                    out_ab, out_ba,
                    "encoder must preserve extension list order"
                );
            }
        }
    }
}

// Phase 5 / F-117 — round-trip tests for new wire-v1 decoder helpers.
mod wire_v1_round_trip {
    use aegis_core::merkle::InclusionProof;
    use aegis_core::serialization::{
        decode_inclusion_proof_v1, decode_sth_envelope_v1, encode_inclusion_proof_v1,
        encode_sth_body_v1, encode_sth_envelope_v1, DecodedSth, Extension,
    };
    use proptest::prelude::*;

    fn arb_hash32() -> impl Strategy<Value = [u8; 32]> {
        proptest::array::uniform32(any::<u8>())
    }

    fn arb_extension() -> impl Strategy<Value = Extension> {
        (
            any::<u16>(),
            proptest::collection::vec(any::<u8>(), 0..=300usize),
        )
            .prop_map(|(extension_type, extension_data)| Extension {
                extension_type,
                extension_data,
            })
    }

    fn arb_extensions() -> impl Strategy<Value = Vec<Extension>> {
        proptest::collection::vec(arb_extension(), 0..=5usize)
    }

    // F-117 Model B — round-trip property: decode(encode(x)) == x for STH envelope.
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 256,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_sth_envelope_round_trip(
            log_id in arb_hash32(),
            tree_size in any::<u64>(),
            timestamp in any::<u64>(),
            root_hash in arb_hash32(),
            extensions in arb_extensions(),
        ) {
            let body = encode_sth_body_v1(&log_id, tree_size, timestamp, &root_hash, &extensions);
            let envelope = encode_sth_envelope_v1(&body);
            let decoded = decode_sth_envelope_v1(&envelope).expect("decode must succeed for valid encoding");
            let expected = DecodedSth {
                log_id,
                tree_size,
                timestamp,
                root_hash,
                sth_extensions: extensions,
            };
            prop_assert_eq!(decoded, expected, "STH envelope round-trip must preserve all fields");
        }
    }

    // F-117 Model B — round-trip property: decode(encode(p)) == p for InclusionProof.
    proptest! {
        #![proptest_config(proptest::test_runner::Config {
            cases: 256,
            ..proptest::test_runner::Config::default()
        })]

        #[test]
        fn prop_inclusion_proof_round_trip(
            tree_size in any::<u64>(),
            leaf_index in any::<u64>(),
            inclusion_path in proptest::collection::vec(arb_hash32(), 0..=20usize),
        ) {
            let proof = InclusionProof {
                tree_size,
                leaf_index,
                inclusion_path,
            };
            let bytes = encode_inclusion_proof_v1(&proof);
            let decoded = decode_inclusion_proof_v1(&bytes).expect("decode must succeed for valid encoding");
            prop_assert_eq!(decoded, proof, "InclusionProof round-trip must preserve all fields");
        }
    }

    // F-117 — decoder rejects trailing garbage.
    #[test]
    fn decode_sth_envelope_rejects_trailing_garbage() {
        let body = encode_sth_body_v1(&[0u8; 32], 0, 0, &[0u8; 32], &[]);
        let mut envelope = encode_sth_envelope_v1(&body);
        envelope.push(0xFF); // trailing garbage byte
        let result = decode_sth_envelope_v1(&envelope);
        assert!(matches!(
            result,
            Err(aegis_core::serialization::WireError::TrailingGarbage { trailing: 1 })
        ));
    }

    // F-117 — decoder rejects wrong WIRE_VERSION tstr.
    #[test]
    fn decode_sth_envelope_rejects_wrong_wire_version() {
        // Hand-craft an envelope with tstr "WRONG-VERSION" (12 bytes — same len, different content)
        let body = encode_sth_body_v1(&[0u8; 32], 0, 0, &[0u8; 32], &[]);
        let mut bad = Vec::new();
        bad.push(0x82); // array(2)
        bad.push(0x6c); // tstr(12) — major 3, len 12
        bad.extend_from_slice(b"WRONG-VERSON"); // 12 bytes
        bad.push(0x59); // bstr(2-byte length follows)
        bad.extend_from_slice(
            &u16::try_from(body.len())
                .expect("test body fits in u16")
                .to_be_bytes(),
        );
        bad.extend_from_slice(&body);
        let result = decode_sth_envelope_v1(&bad);
        assert!(matches!(
            result,
            Err(aegis_core::serialization::WireError::InvalidWireVersion { .. })
        ));
    }
}
