//! `SignedTreeHead` roundtrip tests — JSON serde and wire-v1 byte format.
//!
//! AC-1.4-31: JSON serde roundtrip for `SignedTreeHead` (structural identity).
//! AC-1.6-17: Wire-v1 byte format equivalence — `encode_signed_tree_head` produces
//!            byte-identical output given the same `SignedTreeHead` fields; encoding
//!            is deterministic and the outer array structure matches AD-1.6-01.

use aegis_core::serialization::{
    encode_signed_tree_head, encode_sth_body_v1, encode_sth_envelope_v1,
};
use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};

/// AC-1.4-31 — JSON serde roundtrip is byte-identical.
#[test]
fn json_roundtrip() {
    let sth = SignedTreeHead {
        log_id: [0xAB; 32],
        tree_head: TreeHeadDataV2 {
            timestamp: 1_713_787_200_000,
            tree_size: 7,
            root_hash: [0xCD; 32],
            sth_extensions: vec![],
        },
        signature_bytes: vec![0xEF; 3309],
    };

    let json = serde_json::to_string(&sth).expect("serde_json serialize");
    let round: SignedTreeHead = serde_json::from_str(&json).expect("serde_json deserialize");
    assert_eq!(sth, round);
}

/// AC-1.6-17 — `encode_signed_tree_head` is deterministic: two calls with the same
/// `SignedTreeHead` produce byte-identical output.
#[test]
fn encode_signed_tree_head_is_deterministic() {
    let sth = SignedTreeHead {
        log_id: [0xAB; 32],
        tree_head: TreeHeadDataV2 {
            timestamp: 1_713_787_200_000,
            tree_size: 42,
            root_hash: [0xCD; 32],
            sth_extensions: vec![],
        },
        signature_bytes: vec![0xEF; 3309],
    };

    let bytes1 = encode_signed_tree_head(&sth);
    let bytes2 = encode_signed_tree_head(&sth);
    assert_eq!(
        bytes1, bytes2,
        "encode_signed_tree_head must be deterministic"
    );
}

/// AC-1.6-17 — `encode_signed_tree_head` is equivalent to composing
/// `encode_sth_envelope_v1(encode_sth_body_v1(...))` with the same fields.
///
/// Verifies the single-call shorthand matches the two-step composition.
#[test]
fn encode_signed_tree_head_equals_manual_composition() {
    let log_id = [0xAA_u8; 32];
    let root_hash = [0xBB_u8; 32];
    let tree_size: u64 = 7;
    let timestamp: u64 = 1_713_787_200_000;

    let sth = SignedTreeHead {
        log_id,
        tree_head: TreeHeadDataV2 {
            timestamp,
            tree_size,
            root_hash,
            sth_extensions: vec![],
        },
        signature_bytes: vec![0xFF; 3309],
    };

    let via_helper = encode_signed_tree_head(&sth);
    let via_composition = encode_sth_envelope_v1(&encode_sth_body_v1(
        &log_id,
        tree_size,
        timestamp,
        &root_hash,
        &[],
    ));

    assert_eq!(
        via_helper, via_composition,
        "encode_signed_tree_head must equal manual envelope(body(...)) composition"
    );
}

/// AC-1.6-17 — Two distinct `SignedTreeHead` values (different `log_id`) produce
/// different wire bytes, confirming `log_id` participates in the encoding.
#[test]
fn different_log_id_produces_different_wire_bytes() {
    let make_sth = |log_id: [u8; 32]| SignedTreeHead {
        log_id,
        tree_head: TreeHeadDataV2 {
            timestamp: 1_000_000,
            tree_size: 1,
            root_hash: [0xCC; 32],
            sth_extensions: vec![],
        },
        signature_bytes: vec![0xDD; 3309],
    };

    let bytes_a = encode_signed_tree_head(&make_sth([0xAA; 32]));
    let bytes_b = encode_signed_tree_head(&make_sth([0xBB; 32]));
    assert_ne!(
        bytes_a, bytes_b,
        "distinct log_id values must produce distinct wire bytes"
    );
}
