//! Compile-time assertion that `MlDsaSigner` implements `zeroize::ZeroizeOnDrop`.
//! Covers AC-1.4-34 (rev-2 Amendment 2, Path (a) per P0-9 RED + §11 footgun #25).
//!
//! The structural promise: `secret_key: Zeroizing<Vec<u8>>` carries the actual
//! zeroization (via `Zeroizing<Z: Zeroize>`'s `Drop` impl). The manual
//! `impl ZeroizeOnDrop for MlDsaSigner {}` declares the API-level guarantee.

use aegis_core::signing::MlDsaSigner;
use static_assertions::assert_impl_all;

// Compile-time assertion — if `MlDsaSigner` does not implement `ZeroizeOnDrop`,
// this will fail to compile, which nextest surfaces as a build failure.
assert_impl_all!(MlDsaSigner: zeroize::ZeroizeOnDrop);

/// AC-1.4-34 — `MlDsaSigner` implements `zeroize::ZeroizeOnDrop` (compile-time proof).
///
/// The static assertion above already encodes the invariant at compile time.
/// This `#[test]` function exists so the assertion is visible in `cargo nextest` output.
#[test]
fn signer_is_zeroize_on_drop() {
    // The compile-time assertion above is the real check.
    // If we reach this line, the trait bound held.
}
