//! Tests for `MlDsaSigner::sign_tree_root`.
//!
//! Covers AC-1.4-15 (3,309-byte signature length) and AC-1.4-17 (hedged non-reproducibility
//! via 256-sample `HashSet` distinctness check per rev-2 Amendment 7).

use aegis_core::signing::{MlDsaSigner, TreeHeadDataV2};
use std::collections::HashSet;

/// AC-1.4-15: `sign_tree_root` produces a 3,309-byte ML-DSA-65 signature.
///
/// 3,309 bytes is the FIPS 204 final Table 2 signature size for ML-DSA-65.
/// Runtime guard in `sign_tree_root` enforces this via `SignatureLengthInvariant`.
#[test]
fn sig_is_3309_bytes() {
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new must succeed");
    let th = TreeHeadDataV2 {
        timestamp: 1_700_000_000_000, // ms since epoch
        tree_size: 42,
        root_hash: [0xBB; 32],
        sth_extensions: vec![],
    };
    let sig = signer
        .sign_tree_root(&th)
        .expect("sign_tree_root must succeed");
    assert_eq!(
        sig.len(),
        3309,
        "ML-DSA-65 signature must be exactly 3309 bytes"
    );
}

/// AC-1.4-17 (rev-2 Amendment 7): Hedged signing — 256 `sign_tree_root` calls with
/// identical input produce 256 DISTINCT `signature_bytes`.
///
/// Uses `HashSet` for O(n) deduplication rather than O(n²) pairwise comparison.
/// The ML-DSA-65 hedged variant (FIPS 204 §3.5) introduces per-call randomness,
/// making collision of any two 3,309-byte signatures astronomically improbable.
///
/// Per `.claude/rules/testing.md`: 256 signatures is a measured-reason exception to
/// the 5s integration-test budget — ML-DSA-65 sign is fast (< few ms per call).
/// Wall-clock is logged in the Phase 3 commit body.
#[test]
fn hedged_signing_256_distinct() {
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new must succeed");
    let th = TreeHeadDataV2 {
        timestamp: 42,
        tree_size: 7,
        root_hash: [0xCC; 32],
        sth_extensions: vec![],
    };
    let mut sigs: HashSet<Vec<u8>> = HashSet::with_capacity(256);
    for _ in 0..256 {
        let sig = signer
            .sign_tree_root(&th)
            .expect("sign_tree_root must succeed");
        sigs.insert(sig);
    }
    assert_eq!(
        sigs.len(),
        256,
        "hedged signing must produce 256 distinct signatures"
    );
}
