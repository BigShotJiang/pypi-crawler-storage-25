//! Tests for `compute_log_id`.
//! Covers AC-1.4-11.

use aegis_core::signing::{compute_log_id, MlDsaSigner};
use sha2::{Digest, Sha256};

/// AC-1.4-11 — `compute_log_id(pk)` returns the SHA-256 fingerprint of `pk`.
///
/// Verified with two distinct inputs:
/// 1. A deterministic 1952-byte fixture (`[0xAB; 1952]`).
/// 2. A real `MlDsaSigner` public key.
#[test]
fn compute_log_id_is_sha256() {
    // Case 1: deterministic fixture.
    let fixture_pk = [0xAB_u8; 1952];
    let expected: [u8; 32] = Sha256::digest(fixture_pk).into();
    let got = compute_log_id(&fixture_pk);
    assert_eq!(
        got, expected,
        "compute_log_id must equal Sha256::digest for fixture input"
    );

    // Case 2: real ML-DSA-65 public key.
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new() must succeed");
    let real_pk: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let expected_real: [u8; 32] = Sha256::digest(real_pk).into();
    let got_real = compute_log_id(real_pk);
    assert_eq!(
        got_real, expected_real,
        "compute_log_id must equal Sha256::digest for real ML-DSA-65 public key"
    );
}
