//! Known-Answer Tests (KAT) for the wire-v1 encoder.
//!
//! Per AC-1.6-08: ≥5 KAT vectors covering all `encode_head` size ranges:
//! - [0..=23]             — 1-byte head
//! - [24..=255]           — 2-byte head
//! - [256..=65535]        — 3-byte head
//! - [65536..=4294967295] — 5-byte head
//! - [≥2^32]              — 9-byte head
//!
//! All assertions are derived byte-for-byte from the RFC 8949 §4.2.1 encoding
//! rules and the wire-v1.md §5 (body) and §4.1 (envelope) specs.
//!
//! Phase 1 compile-skip: the encoder functions (`encode_sth_body_v1`,
//! `encode_sth_envelope_v1`, `Extension`) are gated behind the `wire-v1-encoder`
//! feature which does not exist yet. Teammate A activates these tests in Phase 2
//! by adding that feature or by removing the cfg gate once the encoder lands.
//!
//! The one test that only depends on `WIRE_VERSION` (exists in Phase 1) compiles
//! and runs immediately.

// ---------------------------------------------------------------------------
// Phase 1: compile immediately — depends only on WIRE_VERSION (already in stub)
// ---------------------------------------------------------------------------

/// AC-1.6-10 (Phase 1): `WIRE_VERSION` constant has correct value and length.
///
/// This test compiles and runs in Phase 1 because it only depends on the stub.
#[test]
fn wire_version_value_and_length() {
    use aegis_core::serialization::WIRE_VERSION;
    assert_eq!(WIRE_VERSION, "AEGIS-STH-v1");
    assert_eq!(
        WIRE_VERSION.len(),
        12,
        "WIRE_VERSION must be exactly 12 bytes"
    );
    assert!(
        WIRE_VERSION.len() <= 255,
        "WIRE_VERSION must fit in FIPS 204 ctx (255 bytes max per FIPS 204 §5.2)"
    );
}

// ---------------------------------------------------------------------------
// Phase 2: encoder functions now available; cfg gate removed by Teammate A.
// ---------------------------------------------------------------------------
mod kat_encoder_tests {
    use aegis_core::serialization::{
        encode_sth_body_v1, encode_sth_envelope_v1, Extension, WIRE_VERSION,
    };

    const LOG_ID_AA: [u8; 32] = [0xAA; 32];
    const ROOT_HASH_BB: [u8; 32] = [0xBB; 32];

    /// Helper: build expected CBOR uint per RFC 8949 §4.2.1.
    #[allow(clippy::cast_possible_truncation)]
    fn expected_uint(v: u64) -> Vec<u8> {
        // Safety: casts within each branch are sound — branch constraint guarantees fit.
        match v {
            0..=23 => vec![v as u8],
            24..=0xFF => vec![0x18, v as u8],
            0x100..=0xFFFF => {
                let mut out = vec![0x19];
                out.extend_from_slice(&(v as u16).to_be_bytes());
                out
            }
            0x10000..=0xFFFF_FFFF => {
                let mut out = vec![0x1a];
                out.extend_from_slice(&(v as u32).to_be_bytes());
                out
            }
            _ => {
                let mut out = vec![0x1b];
                out.extend_from_slice(&v.to_be_bytes());
                out
            }
        }
    }

    /// Helper: expected bstr32 head (length 32 is always [24..=255] → 0x58 0x20).
    fn expected_bstr32(bytes: &[u8; 32]) -> Vec<u8> {
        let mut v = vec![0x58, 0x20];
        v.extend_from_slice(bytes);
        v
    }

    /// Reference encoder — mirrors the locked spec without using the encoder under test.
    #[allow(clippy::cast_possible_truncation)]
    fn expected_sth_body(
        log_id: &[u8; 32],
        tree_size: u64,
        timestamp: u64,
        root_hash: &[u8; 32],
        extensions: &[Extension],
    ) -> Vec<u8> {
        // Safety: all `as uN` casts are within branch-constrained ranges and are sound.
        let mut out = vec![0x85]; // CBOR array(5)
        out.extend_from_slice(&expected_bstr32(log_id));
        out.extend_from_slice(&expected_uint(tree_size));
        out.extend_from_slice(&expected_uint(timestamp));
        out.extend_from_slice(&expected_bstr32(root_hash));
        // Extensions array
        let n = extensions.len() as u64;
        let arr_head: Vec<u8> = match n {
            0..=23 => vec![0x80u8 | n as u8],
            24..=0xFF => vec![0x98, n as u8],
            0x100..=0xFFFF => {
                let mut h = vec![0x99];
                h.extend_from_slice(&(n as u16).to_be_bytes());
                h
            }
            _ => {
                let mut h = vec![0x9a];
                h.extend_from_slice(&(n as u32).to_be_bytes());
                h
            }
        };
        out.extend_from_slice(&arr_head);
        for e in extensions {
            out.push(0x82); // array(2)
            out.extend_from_slice(&expected_uint(u64::from(e.extension_type)));
            let dl = e.extension_data.len() as u64;
            let data_head: Vec<u8> = match dl {
                0..=23 => vec![0x40u8 | dl as u8],
                24..=0xFF => vec![0x58, dl as u8],
                0x100..=0xFFFF => {
                    let mut h = vec![0x59];
                    h.extend_from_slice(&(dl as u16).to_be_bytes());
                    h
                }
                _ => {
                    let mut h = vec![0x5a];
                    h.extend_from_slice(&(dl as u32).to_be_bytes());
                    h
                }
            };
            out.extend_from_slice(&data_head);
            out.extend_from_slice(&e.extension_data);
        }
        out
    }

    // -----------------------------------------------------------------------
    // KAT vector 1 — tree_size = 0, timestamp = 7 (1-byte head range [0..=23])
    //
    // Verifies the [0..=23] branch of encode_head for uint fields.
    // tree_size = 0 encodes as 0x00; timestamp = 7 encodes as 0x07.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_tree_size_zero_one_byte_head() {
        let body = encode_sth_body_v1(&LOG_ID_AA, 0, 7, &ROOT_HASH_BB, &[]);
        let expected = expected_sth_body(&LOG_ID_AA, 0, 7, &ROOT_HASH_BB, &[]);
        assert_eq!(
            body, expected,
            "KAT 1: tree_size=0, timestamp=7 (1-byte heads)"
        );
        assert_eq!(
            body[0], 0x85,
            "sth_body must begin with CBOR array(5) = 0x85"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 2 — tree_size = 24, timestamp = 255 (2-byte head range [24..=255])
    //
    // tree_size = 24 → 0x18 0x18; timestamp = 255 → 0x18 0xFF.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_tree_size_24_two_byte_head() {
        let body = encode_sth_body_v1(&LOG_ID_AA, 24, 255, &ROOT_HASH_BB, &[]);
        let expected = expected_sth_body(&LOG_ID_AA, 24, 255, &ROOT_HASH_BB, &[]);
        assert_eq!(
            body, expected,
            "KAT 2: tree_size=24, timestamp=255 (2-byte heads)"
        );

        // tree_size offset: 1 (array head) + 2+32 (bstr32 log_id) = 35
        let ts_offset = 1 + 2 + 32;
        assert_eq!(
            &body[ts_offset..ts_offset + 2],
            &[0x18, 0x18],
            "tree_size=24 must encode as 0x18 0x18"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 3 — tree_size = 256, timestamp = 65535 (3-byte head [256..=65535])
    //
    // tree_size = 256 → 0x19 0x01 0x00; timestamp = 65535 → 0x19 0xFF 0xFF.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_tree_size_256_three_byte_head() {
        let body = encode_sth_body_v1(&LOG_ID_AA, 256, 65535, &ROOT_HASH_BB, &[]);
        let expected = expected_sth_body(&LOG_ID_AA, 256, 65535, &ROOT_HASH_BB, &[]);
        assert_eq!(
            body, expected,
            "KAT 3: tree_size=256, timestamp=65535 (3-byte heads)"
        );

        let ts_offset = 1 + 2 + 32;
        assert_eq!(
            &body[ts_offset..ts_offset + 3],
            &[0x19, 0x01, 0x00],
            "tree_size=256 must encode as 0x19 0x01 0x00"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 4 — tree_size = 65536, timestamp = u32::MAX (5-byte head [65536..=u32::MAX])
    //
    // tree_size = 65536 → 0x1a 0x00 0x01 0x00 0x00.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_tree_size_65536_five_byte_head() {
        let body = encode_sth_body_v1(&LOG_ID_AA, 65536, u64::from(u32::MAX), &ROOT_HASH_BB, &[]);
        let expected =
            expected_sth_body(&LOG_ID_AA, 65536, u64::from(u32::MAX), &ROOT_HASH_BB, &[]);
        assert_eq!(body, expected, "KAT 4: tree_size=65536 (5-byte head)");

        let ts_offset = 1 + 2 + 32;
        assert_eq!(
            &body[ts_offset..ts_offset + 5],
            &[0x1a, 0x00, 0x01, 0x00, 0x00],
            "tree_size=65536 must encode as 0x1a 0x00 0x01 0x00 0x00"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 5 — tree_size = u64::MAX (9-byte head range [≥2^32])
    //
    // tree_size = u64::MAX → 0x1b 0xFF 0xFF 0xFF 0xFF 0xFF 0xFF 0xFF 0xFF.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_tree_size_u64_max_nine_byte_head() {
        let body = encode_sth_body_v1(
            &LOG_ID_AA,
            u64::MAX,
            1_000_000_000_000u64,
            &ROOT_HASH_BB,
            &[],
        );
        let expected = expected_sth_body(
            &LOG_ID_AA,
            u64::MAX,
            1_000_000_000_000u64,
            &ROOT_HASH_BB,
            &[],
        );
        assert_eq!(body, expected, "KAT 5: tree_size=u64::MAX (9-byte head)");

        let ts_offset = 1 + 2 + 32;
        assert_eq!(
            &body[ts_offset..ts_offset + 9],
            &[0x1b, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
            "tree_size=u64::MAX must encode as 0x1b followed by 8 0xFF bytes"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 6 — full envelope canonical vector (byte-for-byte regression anchor)
    //
    // Verifies the complete output of `encode_sth_envelope_v1(encode_sth_body_v1(...))`.
    // -----------------------------------------------------------------------
    #[test]
    fn kat_full_envelope_canonical_vector() {
        let log_id = [0xAA; 32];
        let root_hash = [0xBB; 32];

        let body = encode_sth_body_v1(&log_id, 1u64, 2u64, &root_hash, &[]);
        let envelope = encode_sth_envelope_v1(&body);

        // Outer: CBOR array(2)
        assert_eq!(
            envelope[0], 0x82,
            "envelope must begin with CBOR array(2) = 0x82"
        );

        // Element 0: tstr "AEGIS-STH-v1" (12 bytes → head 0x6c = 0x60 | 12)
        assert_eq!(
            envelope[1], 0x6c,
            "tstr head for 12-byte WIRE_VERSION must be 0x6c"
        );
        assert_eq!(
            &envelope[2..14],
            WIRE_VERSION.as_bytes(),
            "envelope element 0 must equal WIRE_VERSION bytes"
        );

        // Element 1: bstr containing body
        let body_start = 14; // 1 + 1 + 12
                             // body.len() is ~70 bytes → head 0x58 + 1 length byte
        assert_eq!(
            envelope[body_start], 0x58,
            "body bstr head byte 0x58 expected"
        );
        let body_len = envelope[body_start + 1] as usize;
        assert_eq!(
            body_len,
            body.len(),
            "bstr length must match actual body length"
        );
        assert_eq!(
            &envelope[body_start + 2..],
            body.as_slice(),
            "body bytes must follow header verbatim"
        );
    }

    // -----------------------------------------------------------------------
    // KAT vector 7 — bstr32 head is always 0x58 0x20
    //
    // log_id and root_hash are 32-byte bstr fields. Length 32 is in [24..=255]
    // → always encodes as 0x58 0x20 (2-byte head).
    // -----------------------------------------------------------------------
    #[test]
    fn kat_bstr32_head_is_always_0x58_0x20() {
        let body = encode_sth_body_v1(&[0x00u8; 32], 0, 0, &[0xFFu8; 32], &[]);

        // log_id starts at index 1 (after 0x85)
        assert_eq!(
            &body[1..3],
            &[0x58, 0x20],
            "log_id bstr32 head must be 0x58 0x20"
        );

        // root_hash: after array(5)[1] + bstr32(log_id)[34] + uint(0)[1] + uint(0)[1] = 37
        assert_eq!(
            &body[37..39],
            &[0x58, 0x20],
            "root_hash bstr32 head must be 0x58 0x20"
        );
    }
}
