//! Smoke tests for `MlDsaSigner` construction and key accessor.
//! Covers AC-1.4-09, AC-1.4-10, AC-1.4-28.

use aegis_core::signing::MlDsaSigner;

/// AC-1.4-09 — `MlDsaSigner::new()` returns `Ok` and the internal sizes match FIPS 204.
#[test]
fn new_returns_ok_with_correct_sizes() {
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new() must succeed");
    // Public key length: FIPS 204 Table 2, ML-DSA-65.
    assert_eq!(
        signer.public_key().len(),
        1952,
        "public key must be 1952 bytes"
    );
    // Secret key length invariant: confirmed via oqs API, not stored directly.
    let sig = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65)
        .expect("Sig::new must succeed for MlDsa65");
    assert_eq!(
        sig.length_secret_key(),
        4032,
        "secret key must be 4032 bytes (FIPS 204 Table 2)"
    );
}

/// AC-1.4-10 — `MlDsaSigner::public_key()` returns `&[u8]` of exactly 1952 bytes.
#[test]
fn public_key_returns_1952_bytes() {
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new() must succeed");
    let pk: &[u8] = signer.public_key();
    assert_eq!(
        pk.len(),
        1952,
        "public_key() must return exactly 1952 bytes"
    );
}

/// AC-1.4-28 — Two `MlDsaSigner::new()` calls in the same process both succeed.
/// Confirms re-entrancy of the `OQS_INIT` Once guard: calling `ensure_oqs_init()`
/// multiple times is safe and the second call does not re-invoke `oqs::init()` via FFI.
#[test]
fn once_guarded_init_safe_under_repeat() {
    let signer1 = MlDsaSigner::new().expect("first MlDsaSigner::new() must succeed");
    let signer2 = MlDsaSigner::new().expect("second MlDsaSigner::new() must succeed");
    // Both produce valid 1952-byte public keys (confirms actual keygen succeeded).
    assert_eq!(signer1.public_key().len(), 1952);
    assert_eq!(signer2.public_key().len(), 1952);
    // Keys must be distinct (different keypairs; probability of collision is negligible).
    assert_ne!(
        signer1.public_key(),
        signer2.public_key(),
        "two independently generated keypairs must be distinct"
    );
}
