//! Errors raised by `aegis-core` protocol primitives.

use thiserror::Error;

/// Errors from leaf serialisation, deserialisation, and hashing.
#[allow(clippy::module_name_repetitions)]
#[derive(Debug, Error)]
pub enum LeafError {
    /// `CBOR` encoding failed.
    #[error("CBOR encode error: {0}")]
    Encode(String),

    /// `CBOR` decoding failed.
    #[error("CBOR decode error: {0}")]
    Decode(String),

    /// `schema_version` field was present but did not equal the locked value.
    #[error("unsupported schema_version: expected 1, got {0}")]
    UnsupportedSchemaVersion(u64),

    /// A required field was missing or had the wrong `CBOR` type.
    #[error("malformed leaf: {0}")]
    Malformed(String),
}

/// Errors from [`MerkleTree`][crate::merkle::MerkleTree] construction and operations.
#[allow(clippy::module_name_repetitions)] // matches LeafError pattern (MD-10-S1.2)
#[derive(Debug, Error, PartialEq, Eq)]
pub enum MerkleError {
    /// Attempted to build a `MerkleTree` from an empty leaf slice.
    #[error("empty tree not permitted: MerkleTree::new requires at least 1 leaf")]
    EmptyTree,

    /// The requested leaf index is out of range for this tree.
    #[error("leaf_index {leaf_index} out of range for tree of size {tree_size}")]
    LeafIndexOutOfRange {
        /// The index that was requested.
        leaf_index: u64,
        /// The actual number of leaves in the tree.
        tree_size: u64,
    },
}
