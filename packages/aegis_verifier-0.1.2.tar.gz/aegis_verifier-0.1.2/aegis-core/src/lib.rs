//! aegis-core: protocol primitives for the Aegis post-quantum agent identity platform.
//!
//! This crate is the single source of truth for the `MtacLeaf` wire format
//! (schema-v1), canonical `CBOR` serialisation in the dcbor profile (a strict
//! subset of `CDE` per draft-ietf-cbor-cde, itself a strict subset of `RFC` 8949
//! §4.2.1 `CDER`), and the leaf hash preimage construction that binds a leaf
//! to its issuing `CA`.
//!
//! # Schema lock
//!
//! Once this crate compiles on `main` and is tagged `schema-v1`, the wire
//! format and hash preimage are immutable. Any change requires bumping
//! `leaf::SCHEMA_VERSION` to 2 with a parallel migration plan across every
//! consumer (`CA`, Verifier `SDK`, on-chain anchor).

#![doc(html_no_source)]

pub mod error;
pub mod issuance;
pub mod leaf;
pub mod merkle;
pub mod serialization;
pub mod signing;
