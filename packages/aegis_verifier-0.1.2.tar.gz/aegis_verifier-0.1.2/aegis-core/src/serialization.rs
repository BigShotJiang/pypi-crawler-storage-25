//! Wire format encoder for `SignedTreeHead` per AD-1.6-01.
//!
//! Handrolled RFC 8949 §4.2.1 CDE-compatible canonical encoder (~55 LOC,
//! zero external dependency). Produces canonical bytes for the
//! `SignedTreeHead` envelope:
//!
//! ```text
//! [                               // outer CBOR array(2)
//!   tstr("AEGIS-STH-v1"),         // version + protocol domain separator
//!   bstr(sth_body_encoded)        // serialized SignedTreeHead body
//! ]
//! ```
//!
//! See `docs/interfaces/wire-v1.md` for the full normative contract.
//!
//! # Encoder consistency (footgun #45)
//!
//! ALL byte-emission sites go through the [`encode_head`] dispatcher.
//! No inlined hardcoded major-type/argument bytes appear anywhere in the
//! encoder body — only the two array-head constants `0x85` and `0x82` are
//! emitted directly (as CBOR `array(5)` and `array(2)` respectively).
//!
//! # Single extraction call site (footgun #46)
//!
//! [`encode_signed_tree_head`] is the ONE canonical path from a
//! `SignedTreeHead` to `bytes_to_sign`. ALL signing and verification call
//! sites MUST use this helper; never duplicate field extraction.

/// Wire format protocol identifier. Used as both:
///   (a) envelope context string (auditor-visible in serialized bytes)
///   (b) FIPS 204 §5.2 ctx parameter to `oqs::Sig::sign_with_ctx_str`
///       (cryptographically bound, NOT visible in serialized bytes)
pub const WIRE_VERSION: &str = "AEGIS-STH-v1";

// Compile-time guard: FIPS 204 §5.2 caps ctx at 255 bytes (footgun #43).
// NEVER remove this assertion.
const _: () = assert!(
    WIRE_VERSION.len() <= 255,
    "WIRE_VERSION must fit in FIPS 204 ctx (255 bytes)"
);

/// RFC 9162 §4.9 extension entry.
///
/// An extension is a `[extension_type, extension_data]` pair encoded as a
/// 2-element CBOR array per RFC 9162 §4.9:
/// - `extension_type`: u16 integer (CBOR uint)
/// - `extension_data`: opaque byte string (CBOR bstr)
///
/// In Aegis Alpha the `sth_extensions` list is always empty; this type exists
/// for forward-compatibility and correct encoding of non-empty lists.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Extension {
    /// RFC 9162 §4.9 extension type identifier.
    pub extension_type: u16,
    /// RFC 9162 §4.9 opaque extension payload.
    pub extension_data: Vec<u8>,
}

/// Encodes a `SignedTreeHead` body (inner 5-element CBOR array) per AD-1.6-01.
///
/// Layout:
/// ```text
/// array(5) [
///   bstr(32) log_id,
///   uint     tree_size,
///   uint     timestamp,
///   bstr(32) root_hash,
///   array    sth_extensions   // empty → 0x80; nonempty → array of [uint, bstr]
/// ]
/// ```
///
/// All encoding uses the [`encode_head`] dispatcher; no raw CBOR bytes are
/// inlined except the leading `0x85` (`array(5)`) constant.
#[must_use]
pub fn encode_sth_body_v1(
    log_id: &[u8; 32],
    tree_size: u64,
    timestamp: u64,
    root_hash: &[u8; 32],
    extensions: &[Extension],
) -> Vec<u8> {
    let mut out = Vec::with_capacity(128);
    out.push(0x85); // CBOR array(5) — major type 4, length 5
    encode_bstr32(&mut out, log_id);
    encode_uint(&mut out, tree_size);
    encode_uint(&mut out, timestamp);
    encode_bstr32(&mut out, root_hash);
    encode_extensions_array(&mut out, extensions);
    out
}

/// Wraps a serialized body in the outer 2-element CBOR envelope per AD-1.6-01.
///
/// Layout:
/// ```text
/// array(2) [
///   tstr("AEGIS-STH-v1"),     // version + protocol domain separator
///   bstr(body)                // opaque body bytes
/// ]
/// ```
///
/// The `WIRE_VERSION` constant drives the tstr length field; no raw string
/// literal is inlined.
#[must_use]
pub fn encode_sth_envelope_v1(body: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(body.len() + 24);
    out.push(0x82); // CBOR array(2)
    encode_head(&mut out, 3, WIRE_VERSION.len() as u64); // tstr, length from constant (footgun #45)
    out.extend_from_slice(WIRE_VERSION.as_bytes());
    encode_head(&mut out, 2, body.len() as u64); // bstr head
    out.extend_from_slice(body);
    out
}

/// Single canonical `SignedTreeHead → bytes_to_sign` extraction call site
/// (footgun #46).
///
/// Returns the envelope bytes that are signed with ML-DSA-65. ALL signing
/// and verification call sites MUST use this helper; never duplicate the
/// field extraction logic.
#[must_use]
pub fn encode_signed_tree_head(sth: &crate::signing::SignedTreeHead) -> Vec<u8> {
    encode_sth_envelope_v1(&encode_sth_body_v1(
        &sth.log_id,
        sth.tree_head.tree_size,
        sth.tree_head.timestamp,
        &sth.tree_head.root_hash,
        &sth.tree_head.sth_extensions,
    ))
}

// ---------------------------------------------------------------------------
// Private encoding helpers — all use encode_head dispatcher (footgun #45)
// ---------------------------------------------------------------------------

fn encode_uint(out: &mut Vec<u8>, v: u64) {
    encode_head(out, 0, v);
}

fn encode_bstr32(out: &mut Vec<u8>, b: &[u8; 32]) {
    // Length 32 is in [24..=255] → always 0x58 0x20 (2-byte head)
    encode_head(out, 2, 32);
    out.extend_from_slice(b);
}

/// Core CBOR argument encoder — RFC 8949 §4.2.1 shortest-form encoding.
///
/// Maps `(major_type, argument)` to the canonical CBOR header bytes:
/// - `arg ∈ [0..=23]`          → 1 byte:  `major<<5 | arg`
/// - `arg ∈ [24..=0xFF]`       → 2 bytes: `major<<5 | 0x18`, `arg`
/// - `arg ∈ [0x100..=0xFFFF]`  → 3 bytes: `major<<5 | 0x19`, arg as BE u16
/// - `arg ∈ [0x10000..=0xFFFF_FFFF]` → 5 bytes: `major<<5 | 0x1a`, arg as BE u32
/// - `arg ≥ 0x1_0000_0000`     → 9 bytes: `major<<5 | 0x1b`, arg as BE u64
///
/// # Casting safety
///
/// All `as uN` casts within match branches are sound — each branch's range
/// constraint guarantees the value fits in the target type:
/// - `arg as u8` in `0..=23` branch: arg ≤ 23, fits in u8.
/// - `arg as u8` in `24..=0xFF` branch: arg ≤ 255, fits in u8.
/// - `arg as u16` in `0x100..=0xFFFF` branch: arg ≤ 65535, fits in u16.
/// - `arg as u32` in `0x10000..=0xFFFF_FFFF` branch: arg ≤ `u32::MAX`, fits in u32.
fn encode_head(out: &mut Vec<u8>, major: u8, arg: u64) {
    let m = major << 5;
    match arg {
        #[allow(clippy::cast_possible_truncation)]
        0..=23 => out.push(m | arg as u8),
        #[allow(clippy::cast_possible_truncation)]
        24..=0xFF => {
            out.push(m | 0x18);
            out.push(arg as u8);
        }
        #[allow(clippy::cast_possible_truncation)]
        0x100..=0xFFFF => {
            out.push(m | 0x19);
            out.extend_from_slice(&(arg as u16).to_be_bytes());
        }
        #[allow(clippy::cast_possible_truncation)]
        0x10000..=0xFFFF_FFFF => {
            out.push(m | 0x1a);
            out.extend_from_slice(&(arg as u32).to_be_bytes());
        }
        _ => {
            out.push(m | 0x1b);
            out.extend_from_slice(&arg.to_be_bytes());
        }
    }
}

fn encode_extensions_array(out: &mut Vec<u8>, exts: &[Extension]) {
    encode_head(out, 4, exts.len() as u64); // array head
    for e in exts {
        out.push(0x82); // array(2) for [extension_type, extension_data]
        encode_uint(out, u64::from(e.extension_type));
        encode_head(out, 2, e.extension_data.len() as u64); // bstr head
        out.extend_from_slice(&e.extension_data);
    }
}

// ---------------------------------------------------------------------------
// Phase 5 wire-v1 decoder + InclusionProof encoder/decoder (per F-117 Model B
// architectural amendment). PURE ADDITIONS — no modification of A's Phase 2
// encoder functions above.
// ---------------------------------------------------------------------------

/// Errors returned by [`decode_sth_envelope_v1`] and [`decode_inclusion_proof_v1`].
#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum WireError {
    /// Input ended before the requested field could be read.
    #[error("unexpected end of input at offset {offset} while reading {what}")]
    UnexpectedEof { offset: usize, what: &'static str },
    /// CBOR major type at the position did not match expectation.
    #[error(
        "expected CBOR major type {expected} at offset {offset}, got {got} (while reading {what})"
    )]
    UnexpectedMajor {
        got: u8,
        expected: u8,
        offset: usize,
        what: &'static str,
    },
    /// CBOR argument additional-info byte was indefinite-length or reserved.
    #[error("invalid CBOR argument info {info} at offset {offset} (while reading {what})")]
    InvalidArgument {
        info: u8,
        offset: usize,
        what: &'static str,
    },
    /// Envelope tstr did not equal `WIRE_VERSION` ("AEGIS-STH-v1").
    #[error("expected tstr WIRE_VERSION at offset {offset}, got {got_len}-byte tstr")]
    InvalidWireVersion { offset: usize, got_len: usize },
    /// Array length did not match expectation (e.g., outer envelope must be array(2)).
    #[error(
        "expected array length {expected} at offset {offset}, got {got} (while reading {what})"
    )]
    UnexpectedArrayLength {
        expected: u64,
        got: u64,
        offset: usize,
        what: &'static str,
    },
    /// Byte-string length did not match expectation (e.g., `log_id` must be 32 bytes).
    #[error(
        "expected bstr length {expected} at offset {offset}, got {got} (while reading {what})"
    )]
    UnexpectedBstrLength {
        expected: u64,
        got: u64,
        offset: usize,
        what: &'static str,
    },
    /// Decoder finished but bytes remain in the input.
    #[error("trailing garbage: {trailing} bytes remain after decode")]
    TrailingGarbage { trailing: usize },
    /// Extension type does not fit in u16.
    #[error("extension_type {got} exceeds u16::MAX at offset {offset}")]
    ExtensionTypeOverflow { got: u64, offset: usize },
}

/// Fields decoded from a wire-v1 STH envelope. Mirrors `TreeHeadDataV2` plus `log_id`.
///
/// Returned by [`decode_sth_envelope_v1`]. The decoder does NOT include the signature
/// (under Model B per F-117, signatures travel as a separate parameter, not embedded
/// in the envelope).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DecodedSth {
    pub log_id: [u8; 32],
    pub tree_size: u64,
    pub timestamp: u64,
    pub root_hash: [u8; 32],
    pub sth_extensions: Vec<Extension>,
}

struct Decoder<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Decoder<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, pos: 0 }
    }

    fn remaining(&self) -> usize {
        self.bytes.len() - self.pos
    }

    fn read_byte(&mut self, what: &'static str) -> Result<u8, WireError> {
        if self.pos >= self.bytes.len() {
            return Err(WireError::UnexpectedEof {
                offset: self.pos,
                what,
            });
        }
        let b = self.bytes[self.pos];
        self.pos += 1;
        Ok(b)
    }

    fn read_n(&mut self, n: usize, what: &'static str) -> Result<&'a [u8], WireError> {
        if self.pos + n > self.bytes.len() {
            return Err(WireError::UnexpectedEof {
                offset: self.pos,
                what,
            });
        }
        let slice = &self.bytes[self.pos..self.pos + n];
        self.pos += n;
        Ok(slice)
    }

    fn read_head(&mut self, expected_major: u8, what: &'static str) -> Result<u64, WireError> {
        let head_offset = self.pos;
        let initial = self.read_byte(what)?;
        let major = initial >> 5;
        if major != expected_major {
            return Err(WireError::UnexpectedMajor {
                got: major,
                expected: expected_major,
                offset: head_offset,
                what,
            });
        }
        let info = initial & 0x1f;
        let arg = match info {
            0..=23 => u64::from(info),
            24 => u64::from(self.read_byte(what)?),
            25 => {
                let bytes = self.read_n(2, what)?;
                u64::from(u16::from_be_bytes([bytes[0], bytes[1]]))
            }
            26 => {
                let bytes = self.read_n(4, what)?;
                u64::from(u32::from_be_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]))
            }
            27 => {
                let bytes = self.read_n(8, what)?;
                u64::from_be_bytes([
                    bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
                ])
            }
            _ => {
                return Err(WireError::InvalidArgument {
                    info,
                    offset: head_offset,
                    what,
                })
            }
        };
        Ok(arg)
    }

    fn read_uint(&mut self, what: &'static str) -> Result<u64, WireError> {
        self.read_head(0, what)
    }

    fn read_bstr_n(
        &mut self,
        expected_len: u64,
        what: &'static str,
    ) -> Result<&'a [u8], WireError> {
        let head_offset = self.pos;
        let len = self.read_head(2, what)?;
        if len != expected_len {
            return Err(WireError::UnexpectedBstrLength {
                expected: expected_len,
                got: len,
                offset: head_offset,
                what,
            });
        }
        // Cast u64 → usize: on 64-bit it's lossless; on 32-bit, an oversized length
        // saturates to usize::MAX which causes read_n to error with UnexpectedEof
        // (the input slice is necessarily ≤ usize::MAX bytes anyway).
        self.read_n(usize::try_from(len).unwrap_or(usize::MAX), what)
    }

    fn read_bstr_any(&mut self, what: &'static str) -> Result<&'a [u8], WireError> {
        let len = self.read_head(2, what)?;
        self.read_n(usize::try_from(len).unwrap_or(usize::MAX), what)
    }

    fn read_tstr_any(&mut self, what: &'static str) -> Result<&'a [u8], WireError> {
        let len = self.read_head(3, what)?;
        self.read_n(usize::try_from(len).unwrap_or(usize::MAX), what)
    }

    fn read_array_n(&mut self, expected_len: u64, what: &'static str) -> Result<(), WireError> {
        let head_offset = self.pos;
        let len = self.read_head(4, what)?;
        if len != expected_len {
            return Err(WireError::UnexpectedArrayLength {
                expected: expected_len,
                got: len,
                offset: head_offset,
                what,
            });
        }
        Ok(())
    }

    fn read_array_any(&mut self, what: &'static str) -> Result<u64, WireError> {
        self.read_head(4, what)
    }
}

/// Decodes a wire-v1 STH envelope into its constituent fields per AD-1.6-01.
///
/// Inverse of [`encode_signed_tree_head`] for the envelope-payload portion: extracts
/// the 5 fields signed under the FIPS 204 ctx (`log_id`, `tree_size`, `timestamp`,
/// `root_hash`, `sth_extensions`). Does NOT include the signature — under Model B
/// (F-117) the signature is a separate parameter to `verify_inclusion`, NOT embedded
/// in the envelope.
///
/// # Errors
///
/// Returns [`WireError`] variants for malformed input — short input, wrong CBOR major
/// type at any position, indefinite-length encoding, wrong tstr version, or trailing
/// garbage after the envelope.
///
/// # Panics
///
/// The internal `try_into()` calls on slices returned by `read_bstr_n(32)` are
/// structurally unreachable: `read_bstr_n(32)` either returns exactly 32 bytes or
/// returns a [`WireError`]. The `expect()` is documentation of this invariant.
pub fn decode_sth_envelope_v1(envelope_bytes: &[u8]) -> Result<DecodedSth, WireError> {
    let mut d = Decoder::new(envelope_bytes);

    // Outer array(2) [tstr WIRE_VERSION, bstr body]
    d.read_array_n(2, "envelope outer array")?;

    // Element 0: tstr matching WIRE_VERSION
    let version_offset = d.pos;
    let version = d.read_tstr_any("envelope version tstr")?;
    if version != WIRE_VERSION.as_bytes() {
        return Err(WireError::InvalidWireVersion {
            offset: version_offset,
            got_len: version.len(),
        });
    }

    // Element 1: bstr body
    let body = d.read_bstr_any("envelope body bstr")?;

    if d.remaining() != 0 {
        return Err(WireError::TrailingGarbage {
            trailing: d.remaining(),
        });
    }

    // Body: array(5) of [bstr(32) log_id, uint tree_size, uint timestamp, bstr(32) root_hash, array extensions]
    let mut bd = Decoder::new(body);
    bd.read_array_n(5, "body array(5)")?;

    let log_id_slice = bd.read_bstr_n(32, "log_id bstr(32)")?;
    let log_id: [u8; 32] = log_id_slice
        .try_into()
        .expect("read_bstr_n(32) returns 32 bytes");

    let tree_size = bd.read_uint("tree_size")?;
    let timestamp = bd.read_uint("timestamp")?;

    let root_hash_slice = bd.read_bstr_n(32, "root_hash bstr(32)")?;
    let root_hash: [u8; 32] = root_hash_slice
        .try_into()
        .expect("read_bstr_n(32) returns 32 bytes");

    // Extensions: array of [uint extension_type, bstr extension_data] pairs
    let ext_count = bd.read_array_any("extensions array")?;
    let mut sth_extensions = Vec::with_capacity(usize::try_from(ext_count).unwrap_or(0));
    for _ in 0..ext_count {
        bd.read_array_n(2, "extension pair")?;
        let ext_offset = bd.pos;
        let ext_type = bd.read_uint("extension_type")?;
        if ext_type > u64::from(u16::MAX) {
            return Err(WireError::ExtensionTypeOverflow {
                got: ext_type,
                offset: ext_offset,
            });
        }
        let ext_data = bd.read_bstr_any("extension_data")?.to_vec();
        #[allow(clippy::cast_possible_truncation)]
        sth_extensions.push(Extension {
            extension_type: ext_type as u16,
            extension_data: ext_data,
        });
    }

    if bd.remaining() != 0 {
        return Err(WireError::TrailingGarbage {
            trailing: bd.remaining(),
        });
    }

    Ok(DecodedSth {
        log_id,
        tree_size,
        timestamp,
        root_hash,
        sth_extensions,
    })
}

/// Encodes a wire-v1 `InclusionProof` per F-117 Model B amendment.
///
/// Wire format:
/// ```text
/// array(3) [
///   uint  tree_size,
///   uint  leaf_index,
///   array inclusion_path   // array of bstr(32) sibling hashes
/// ]
/// ```
///
/// All byte-emission goes through `encode_head` per footgun #45; only the leading
/// `0x83` (CBOR array(3)) constant is emitted directly.
#[must_use]
pub fn encode_inclusion_proof_v1(proof: &crate::merkle::InclusionProof) -> Vec<u8> {
    let mut out = Vec::with_capacity(32 + proof.inclusion_path.len() * 33);
    out.push(0x83); // CBOR array(3)
    encode_uint(&mut out, proof.tree_size);
    encode_uint(&mut out, proof.leaf_index);
    encode_head(&mut out, 4, proof.inclusion_path.len() as u64); // array head
    for sib in &proof.inclusion_path {
        encode_bstr32(&mut out, sib);
    }
    out
}

/// Decodes a wire-v1 `InclusionProof` per F-117 Model B amendment. Inverse of
/// [`encode_inclusion_proof_v1`].
///
/// # Errors
///
/// Returns [`WireError`] variants for malformed input — same conditions as
/// [`decode_sth_envelope_v1`].
///
/// # Panics
///
/// The internal `try_into()` call on slices returned by `read_bstr_n(32)` is
/// structurally unreachable: `read_bstr_n(32)` either returns exactly 32 bytes or
/// returns a [`WireError`]. The `expect()` is documentation of this invariant.
pub fn decode_inclusion_proof_v1(
    proof_bytes: &[u8],
) -> Result<crate::merkle::InclusionProof, WireError> {
    let mut d = Decoder::new(proof_bytes);
    d.read_array_n(3, "inclusion proof array(3)")?;
    let tree_size = d.read_uint("tree_size")?;
    let leaf_index = d.read_uint("leaf_index")?;
    let path_count = d.read_array_any("inclusion_path array")?;
    let mut inclusion_path = Vec::with_capacity(usize::try_from(path_count).unwrap_or(0));
    for _ in 0..path_count {
        let sib_slice = d.read_bstr_n(32, "inclusion_path bstr(32)")?;
        inclusion_path.push(
            sib_slice
                .try_into()
                .expect("read_bstr_n(32) returns 32 bytes"),
        );
    }
    if d.remaining() != 0 {
        return Err(WireError::TrailingGarbage {
            trailing: d.remaining(),
        });
    }
    Ok(crate::merkle::InclusionProof {
        tree_size,
        leaf_index,
        inclusion_path,
    })
}
