//! MTAC issuance result type — Sub-Slice 1.5 CA pipeline.
//!
//! This module contains [`MTACIssuanceResult`], the four-field
//! `SignedTreeHead`-wrapping struct returned by
//! `CertificateAuthority::issuance_result`.
//!
//! The struct is re-exported from `aegis-verifier` per DF-1.5-02 so that
//! verifier crates only need to depend on `aegis-verifier`, not on
//! `aegis-core` directly.
//!
//! # Shape
//!
//! ```text
//! MTACIssuanceResult {
//!     batch_id:       uuid::Uuid,                    // UUID v7, time-ordered
//!     leaf_index:     u64,                           // 0-based position in the batch
//!     inclusion_proof: crate::merkle::InclusionProof, // RFC 9162 §2.1.3.1 proof
//!     signed_tree_head: crate::signing::SignedTreeHead, // STH envelope + ML-DSA-65 sig
//! }
//! ```

use serde::{Deserialize, Serialize};

use crate::merkle::InclusionProof;
use crate::signing::SignedTreeHead;

/// The result of registering an agent and committing the batch in the Aegis CA pipeline.
///
/// Returned by `CertificateAuthority::issuance_result(batch_id, leaf_index)`.
///
/// The four-field SignedTreeHead-wrapping shape preserves the `log_id` envelope
/// binding inside the type system (see §4.3 erratum in `SLICE-1.5-BRIEF.md` for
/// why the earlier flat-6-field shape was superseded).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MTACIssuanceResult {
    /// UUID v7 batch identifier (RFC 9562 §5.7). Time-ordered for sortability.
    pub batch_id: uuid::Uuid,
    /// 0-based index of this leaf in the batch Merkle tree.
    pub leaf_index: u64,
    /// RFC 9162 §2.1.3.1 inclusion proof for `leaf_index` in `signed_tree_head`.
    pub inclusion_proof: InclusionProof,
    /// RFC 9162 §4.10 `SignedTreeHead` envelope — contains `log_id`, `tree_head`
    /// (`TreeHeadDataV2`), and the ML-DSA-65 signature over the TLS-PL serialization.
    pub signed_tree_head: SignedTreeHead,
}
