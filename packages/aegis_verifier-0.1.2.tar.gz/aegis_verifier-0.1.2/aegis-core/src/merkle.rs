//! `MerkleTree` — RFC 9162 §2.1.1 binary Merkle hash tree over pre-hashed leaves.
//!
//! # Design
//!
//! [`MerkleTree`] stores the pre-hashed leaves and a cached root computed once
//! at construction.  Internal node hashes are recomputed on demand in Phase 3
//! `proof()` — the per-proof cost is O(log n) hashes (~20 for n = 10^6), which
//! is negligible and avoids encoding the non-balanced tree shape into a `levels`
//! field.
//!
//! # Construction
//!
//! Leaves passed to [`MerkleTree::new`] are already `hash_leaf(...)` outputs
//! (i.e., the `0x00` prefix has already been applied inside `hash_leaf()`).
//! `MerkleTree::new` does **not** re-apply the leaf-type prefix.
//!
//! Internal nodes follow RFC 9162 §2.1.1:
//! `SHA-256(0x01 || MTH(D[0:k]) || MTH(D[k:n]))` where `k` is the largest
//! power of 2 strictly smaller than `n`.

use sha2::{Digest, Sha256};

use crate::error::MerkleError;

/// Convenience wrapper — compute `SHA-256(data)` and return `[u8; 32]`.
fn sha256(data: &[u8]) -> [u8; 32] {
    Sha256::digest(data).into()
}

/// RFC 9162 §2.1.3.1 inclusion proof for a single leaf in a [`MerkleTree`].
///
/// Field order is locked per RFC 9162 §4.12 `InclusionProofDataV2` shape
/// (brief §4 HC 12, D-6-S1.3): `tree_size`, `leaf_index`, `inclusion_path`.
///
/// `inclusion_path` is ordered **bottom-up** (leaf-adjacent sibling first,
/// root-adjacent sibling last), matching the RFC §2.1.3.2 verification
/// algorithm's iteration order.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct InclusionProof {
    /// Number of leaves in the tree at the time the proof was generated.
    pub tree_size: u64,
    /// 0-based index of the leaf being proven.
    pub leaf_index: u64,
    /// Sibling hashes along the path from the leaf to the root, bottom-up.
    pub inclusion_path: Vec<[u8; 32]>,
}

/// Internal-node prefix per `RFC` 9162 §2.1.1.
///
/// Distinguishes internal-node preimages from leaf preimages (`0x00`).
pub const INTERNAL_NODE_PREFIX: u8 = 0x01;

/// An immutable, build-once Merkle hash tree over pre-hashed leaves.
///
/// # Representation
///
/// Stores the input leaves and a cached root.  The root is the single value
/// returned by [`root()`][MerkleTree::root] in O(1).  Proof generation
/// (Phase 3) recomputes internal node hashes by re-walking the RFC 9162
/// §2.1.1 split rule on demand.
///
/// No mutation methods are provided — the tree is build-once-immutable.
/// (brief §7 + §4 HC 7.)
pub struct MerkleTree {
    /// Pre-hashed input leaves in insertion order.
    leaves: Vec<[u8; 32]>,
    /// Cached root, computed once in [`new`][MerkleTree::new].
    root: [u8; 32],
}

impl MerkleTree {
    /// Construct a new Merkle tree from a slice of pre-hashed leaves.
    ///
    /// Each element of `leaves` must already be the output of
    /// [`hash_leaf`][crate::leaf::hash_leaf] (or equivalent).  `MerkleTree::new`
    /// does **not** re-apply the `0x00` leaf-type prefix.
    ///
    /// # Errors
    ///
    /// Returns [`MerkleError::EmptyTree`] if `leaves` is empty.
    pub fn new(leaves: &[[u8; 32]]) -> Result<Self, MerkleError> {
        if leaves.is_empty() {
            return Err(MerkleError::EmptyTree);
        }
        let root = hash_mth(leaves);
        Ok(Self {
            leaves: leaves.to_vec(),
            root,
        })
    }

    /// Return the Merkle tree root hash.
    ///
    /// O(1) — the root is computed once in [`new`][MerkleTree::new] and cached.
    #[must_use]
    pub fn root(&self) -> [u8; 32] {
        self.root
    }

    /// Return the number of leaves in the tree.
    #[must_use]
    pub fn tree_size(&self) -> u64 {
        // `usize` to `u64` is lossless on all supported targets (64-bit).
        self.leaves.len() as u64
    }

    /// Generate an RFC 9162 §2.1.3.1 inclusion proof for the leaf at `leaf_index`.
    ///
    /// The returned [`InclusionProof`] has `inclusion_path` ordered **bottom-up**
    /// (leaf-adjacent sibling first, root-adjacent sibling last), which is the
    /// iteration order required by the §2.1.3.2 verification algorithm.
    ///
    /// # Errors
    ///
    /// Returns [`MerkleError::LeafIndexOutOfRange`] if `leaf_index >= tree_size`.
    ///
    /// # Panics
    ///
    /// Panics if `leaf_index` cannot be represented as `usize`. This is
    /// unreachable on any 64-bit target because `leaf_index < tree_size` and
    /// `tree_size` equals `self.leaves.len()` which is already a valid `usize`.
    pub fn proof(&self, leaf_index: u64) -> Result<InclusionProof, MerkleError> {
        let n = self.tree_size();
        if leaf_index >= n {
            return Err(MerkleError::LeafIndexOutOfRange {
                leaf_index,
                tree_size: n,
            });
        }
        let idx = usize::try_from(leaf_index)
            .expect("leaf_index fits in usize — caller already verified leaf_index < tree_size which is a Vec length");
        let path = build_path(idx, &self.leaves);
        Ok(InclusionProof {
            tree_size: n,
            leaf_index,
            inclusion_path: path,
        })
    }
}

/// Compute `MTH(D[0:n])` per RFC 9162 §2.1.1.
///
/// - `n == 1`: returns `leaves[0]` unchanged (identity — the `0x00` prefix
///   is already baked into each element by [`hash_leaf`][crate::leaf::hash_leaf]).
/// - `n > 1`: splits at `k = largest_power_of_2_less_than(n)` and returns
///   `SHA-256(0x01 || MTH(D[0:k]) || MTH(D[k:n]))`.
///
/// The recursion depth is bounded by `⌈log₂(n)⌉` ≤ 20 for n ≤ 2^20.
fn hash_mth(leaves: &[[u8; 32]]) -> [u8; 32] {
    match leaves.len() {
        0 => unreachable!("hash_mth called on empty slice — caller must guard"),
        1 => leaves[0],
        n => {
            let k = largest_power_of_two_less_than(n);
            let left = hash_mth(&leaves[..k]);
            let right = hash_mth(&leaves[k..]);
            let mut hasher = Sha256::new();
            hasher.update([INTERNAL_NODE_PREFIX]);
            hasher.update(left);
            hasher.update(right);
            hasher.finalize().into()
        }
    }
}

/// Build the RFC 9162 §2.1.3.1 `PATH(m, D[0:n])` inclusion path for leaf `m`.
///
/// Returns sibling hashes ordered **bottom-up** (leaf-adjacent first,
/// root-adjacent last).  This ordering matches the §2.1.3.2 verification
/// algorithm and the reference `generate_reference.py` fixture.
///
/// Recursion per §2.1.3.1:
/// - `n == 1` → empty path (leaf is the root).
/// - `m < k`  → recurse into left sub-tree, append `MTH(D[k:n])`.
/// - `m >= k` → recurse into right sub-tree (`m - k`), append `MTH(D[0:k])`.
///
/// where `k` is the largest power of 2 strictly less than `n`.
fn build_path(m: usize, leaves: &[[u8; 32]]) -> Vec<[u8; 32]> {
    let n = leaves.len();
    if n == 1 {
        return Vec::new();
    }
    let k = largest_power_of_two_less_than(n);
    if m < k {
        let mut path = build_path(m, &leaves[..k]);
        path.push(hash_mth(&leaves[k..]));
        path
    } else {
        let mut path = build_path(m - k, &leaves[k..]);
        path.push(hash_mth(&leaves[..k]));
        path
    }
}

/// Return the largest power of 2 strictly less than `n`.
///
/// Requires `n >= 2`.  For `n = 2` returns 1.  For `n = 7` returns 4.
///
/// This matches the RFC 9162 §2.1.1 split: `k` is defined as the largest
/// power of 2 smaller than `n`, NOT as `n / 2`.
fn largest_power_of_two_less_than(n: usize) -> usize {
    debug_assert!(n >= 2, "n must be >= 2");
    // Highest bit of (n-1) gives us 2^⌊log₂(n-1)⌋ which is the largest
    // power of 2 ≤ n-1, i.e., strictly less than n.
    1usize << (usize::BITS - (n - 1).leading_zeros() - 1)
}

/// Verify an RFC 9162 §2.1.3.2 inclusion proof.
///
/// Returns `true` iff `leaf_hash` is the leaf at `proof.leaf_index` in a
/// tree of size `proof.tree_size` whose root hash is `root`.
///
/// Returns `false` for any of:
/// - `proof.leaf_index >= proof.tree_size` (out-of-range)
/// - `proof.tree_size == 0` (defensive; unreachable via [`MerkleTree::proof`])
/// - `inclusion_path` length inconsistent with `tree_size` / `leaf_index`
///   (structural malformation — path too short or too long)
/// - `leaf_hash` or any element of `inclusion_path` does not match
///
/// # Algorithm
///
/// Implements RFC 9162 §2.1.3.2 verbatim (rev-2 locked pseudocode, §11
/// footgun 21). The inner while-loop fires **inside** the
/// `LSB(fn)==1 || fn==sn` branch, **after** the hash, exclusively for the
/// `fn==sn` sub-case where `LSB(fn)==0`. Do NOT hoist it above the branch.
///
/// # Panics
///
/// The `checked_shr(1).expect(...)` calls inside the loop are unreachable in
/// practice: `u64::checked_shr(1)` returns `None` only if the shift amount
/// exceeds 63, but the argument is the constant `1`.  The `.expect` messages
/// document the invariant for future readers.
#[must_use]
pub fn verify(leaf_hash: [u8; 32], proof: &InclusionProof, root: [u8; 32]) -> bool {
    // RFC 9162 §2.1.3.2 step 1: leaf_index bounds check
    if proof.leaf_index >= proof.tree_size {
        return false;
    }

    // RFC 9162 §2.1.3.2 steps 2-3: initialization
    let mut fn_ = proof.leaf_index;
    let Some(mut sn) = proof.tree_size.checked_sub(1) else {
        return false; // tree_size == 0 — defensive, unreachable via MerkleTree::proof
    };
    let mut r = leaf_hash;

    // RFC 9162 §2.1.3.2 step 4: process each sibling
    for p in &proof.inclusion_path {
        // step 4.1: sn==0 mid-loop guard (structural malformation: path too long)
        if sn == 0 {
            return false;
        }

        // step 4.2: branch on LSB(fn) set OR fn == sn
        if (fn_ & 1) == 1 || fn_ == sn {
            // r is right child; sibling is left → HASH(0x01 || p || r)
            let mut preimage = [0u8; 65];
            preimage[0] = INTERNAL_NODE_PREFIX; // 0x01
            preimage[1..33].copy_from_slice(p);
            preimage[33..65].copy_from_slice(&r);
            r = sha256(&preimage);

            // step 4.2 sub-case: entered via fn == sn (not via LSB(fn) set).
            // If LSB(fn) is not set, right-shift both fn and sn until LSB(fn)
            // is set or fn is 0. This inner loop lives INSIDE this branch,
            // AFTER the hash. It does NOT fire in the LSB(fn)==1 sub-case.
            if (fn_ & 1) == 0 {
                while (fn_ & 1) == 0 && fn_ != 0 {
                    fn_ = fn_
                        .checked_shr(1)
                        .expect("fn right-shift inside branch — unreachable");
                    sn = sn
                        .checked_shr(1)
                        .expect("sn right-shift inside branch — unreachable");
                }
            }
        } else {
            // r is left child; sibling is right → HASH(0x01 || r || p)
            let mut preimage = [0u8; 65];
            preimage[0] = INTERNAL_NODE_PREFIX; // 0x01
            preimage[1..33].copy_from_slice(&r);
            preimage[33..65].copy_from_slice(p);
            r = sha256(&preimage);
        }

        // step 4.3: outer shift, always applied per-sibling
        fn_ = fn_.checked_shr(1).expect("fn outer shift — unreachable");
        sn = sn.checked_shr(1).expect("sn outer shift — unreachable");
    }

    // RFC 9162 §2.1.3.2 step 5: terminal check. BOTH conditions required.
    // `sn == 0` catches structural malformation (path too short for tree_size).
    // `r == root` catches wrong leaf_hash, tampered path, or wrong root.
    sn == 0 && r == root
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;
    use crate::error::MerkleError;
    use proptest::prelude::*;

    // -------------------------------------------------------------------------
    // AC-1.3-03: empty-input rejection
    // -------------------------------------------------------------------------

    #[test]
    fn empty_input_rejected() {
        let result = MerkleTree::new(&[]);
        assert!(
            matches!(result, Err(MerkleError::EmptyTree)),
            "expected Err(MerkleError::EmptyTree)"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-04: single-leaf identity (root == leaf for n == 1)
    // -------------------------------------------------------------------------

    #[test]
    fn single_leaf_root_rfc9162_conformant() {
        let leaf = [0x42u8; 32];
        let tree = MerkleTree::new(&[leaf]).unwrap();
        assert_eq!(
            tree.root(),
            leaf,
            "single-leaf root must equal the leaf hash itself (RFC 9162 §2.1.1 identity)"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-05: two-leaf root matches Planning-verified constant
    //
    // Expected = SHA-256(0x01 || [0x00;32] || [0x01;32])
    // Verified by Planning Space (brief §11 footgun 5).
    // Hex: 2ad82c3a51e8ed6418cb5bf267c5f9e521b99f7ab4fce657f460a8f1a3e87b2e
    // -------------------------------------------------------------------------

    #[test]
    fn two_leaf_root_matches_rfc9162() {
        let leaves: [[u8; 32]; 2] = [[0x00u8; 32], [0x01u8; 32]];
        let tree = MerkleTree::new(&leaves).unwrap();

        let expected: [u8; 32] =
            hex::decode("2ad82c3a51e8ed6418cb5bf267c5f9e521b99f7ab4fce657f460a8f1a3e87b2e")
                .unwrap()
                .try_into()
                .unwrap();

        assert_eq!(
            tree.root(),
            expected,
            "two-leaf root must match Planning-verified SHA-256(0x01||[0x00;32]||[0x01;32])"
        );
    }

    // -------------------------------------------------------------------------
    // Root determinism (AC-1.3-05/06 spirit)
    // -------------------------------------------------------------------------

    #[test]
    fn root_determinism() {
        let leaves: [[u8; 32]; 3] = [[0xAA; 32], [0xBB; 32], [0xCC; 32]];
        let root_a = MerkleTree::new(&leaves).unwrap().root();
        let root_b = MerkleTree::new(&leaves).unwrap().root();
        assert_eq!(
            root_a, root_b,
            "same leaves must always produce the same root"
        );
    }

    // -------------------------------------------------------------------------
    // tree_size() correctness
    // -------------------------------------------------------------------------

    #[test]
    fn tree_size_returns_correct_count() {
        for n in [1u64, 2, 5, 7] {
            let leaves: Vec<[u8; 32]> = (0..n).map(|i| [u8::try_from(i).unwrap(); 32]).collect();
            let tree = MerkleTree::new(&leaves).unwrap();
            assert_eq!(
                tree.tree_size(),
                n,
                "tree_size() must equal the number of leaves for n={n}"
            );
        }
    }

    // -------------------------------------------------------------------------
    // AC-1.3-02: InclusionProof serde round-trip
    // -------------------------------------------------------------------------

    #[test]
    fn inclusion_proof_serde_roundtrip() {
        let proof = InclusionProof {
            tree_size: 4,
            leaf_index: 1,
            inclusion_path: vec![[0xAA; 32], [0xBB; 32]],
        };
        let s = serde_json::to_string(&proof).unwrap();
        let p2: InclusionProof = serde_json::from_str(&s).unwrap();
        assert_eq!(proof, p2);
    }

    // -------------------------------------------------------------------------
    // AC-1.3-07: single-leaf tree proof yields empty inclusion_path
    // -------------------------------------------------------------------------

    #[test]
    fn single_leaf_empty_proof() {
        let tree = MerkleTree::new(&[[0xAA; 32]]).unwrap();
        let proof = tree.proof(0).unwrap();
        assert_eq!(
            proof,
            InclusionProof {
                tree_size: 1,
                leaf_index: 0,
                inclusion_path: vec![],
            },
            "single-leaf tree must produce an empty inclusion path"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-08: proof() on out-of-range index returns LeafIndexOutOfRange
    // -------------------------------------------------------------------------

    #[test]
    fn proof_leaf_index_out_of_range() {
        let leaves: Vec<[u8; 32]> = (0u8..7).map(|i| [i; 32]).collect();
        let tree = MerkleTree::new(&leaves).unwrap();
        let result = tree.proof(7);
        assert_eq!(
            result,
            Err(MerkleError::LeafIndexOutOfRange {
                leaf_index: 7,
                tree_size: 7,
            }),
            "proof(7) on a 7-leaf tree must return LeafIndexOutOfRange"
        );
    }

    // -------------------------------------------------------------------------
    // Shared helper: build a canonical 7-leaf tree (convention: leaf[i] = [i; 32])
    // matching the fixture in tests/fixtures/merkle/rfc9162_7leaf_vectors.json.
    // -------------------------------------------------------------------------

    fn seven_leaves() -> Vec<[u8; 32]> {
        (0u8..7).map(|i| [i; 32]).collect()
    }

    // -------------------------------------------------------------------------
    // AC-1.3-11: verify — happy path (leaf 3 of 7-leaf tree)
    // -------------------------------------------------------------------------

    #[test]
    fn verify_happy_path() {
        let leaves = seven_leaves();
        let tree = MerkleTree::new(&leaves).unwrap();
        let root = tree.root();
        let proof = tree.proof(3).unwrap();
        let leaf_hash = leaves[3];
        assert!(
            verify(leaf_hash, &proof, root),
            "verify must return true for a valid proof at index 3"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-12: verify — tampered leaf hash rejected
    // -------------------------------------------------------------------------

    #[test]
    fn verify_tampered_leaf_rejected() {
        let leaves = seven_leaves();
        let tree = MerkleTree::new(&leaves).unwrap();
        let root = tree.root();
        let proof = tree.proof(3).unwrap();
        // Wrong leaf: [0xFF; 32] instead of leaves[3] = [0x03; 32]
        assert!(
            !verify([0xFF; 32], &proof, root),
            "verify must return false when leaf_hash is wrong"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-13: verify — tampered sibling in inclusion_path rejected
    // -------------------------------------------------------------------------

    #[test]
    fn verify_tampered_sibling_rejected() {
        let leaves = seven_leaves();
        let tree = MerkleTree::new(&leaves).unwrap();
        let root = tree.root();
        let leaf_hash = leaves[3];
        let mut proof = tree.proof(3).unwrap();
        // Flip bit 0 of byte 0 in the first path element
        proof.inclusion_path[0][0] ^= 0x01;
        assert!(
            !verify(leaf_hash, &proof, root),
            "verify must return false when a sibling hash is tampered"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-14: verify — wrong root rejected
    // -------------------------------------------------------------------------

    #[test]
    fn verify_wrong_root_rejected() {
        let leaves = seven_leaves();
        let tree = MerkleTree::new(&leaves).unwrap();
        let proof = tree.proof(3).unwrap();
        let leaf_hash = leaves[3];
        assert!(
            !verify(leaf_hash, &proof, [0xFF; 32]),
            "verify must return false when root is wrong"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-15: verify — structurally malformed proofs rejected (two cases per rev-2)
    //
    // Case (a): tree_size=2, leaf_index=0, empty path (required length: 1) → false
    // Case (b): tree_size=100, leaf_index=0, 2-element path (required length: 7) → false
    //
    // NOTE: tree_size=1, leaf_index=0, empty path is the VALID single-leaf proof
    // (AC-1.3-07) and is NOT tested here per rev-2 amendment.
    // -------------------------------------------------------------------------

    #[test]
    fn verify_malformed_path_rejected() {
        // Case (a): path too short — tree_size=2, leaf_index=0, path len=0 (need 1)
        let proof_a = InclusionProof {
            tree_size: 2,
            leaf_index: 0,
            inclusion_path: vec![],
        };
        assert!(
            !verify([0u8; 32], &proof_a, [0xAAu8; 32]),
            "case (a): empty path for tree_size=2 must be rejected"
        );

        // Case (b): path too short — tree_size=100, leaf_index=0, path len=2 (need 7)
        let proof_b = InclusionProof {
            tree_size: 100,
            leaf_index: 0,
            inclusion_path: vec![[0u8; 32]; 2],
        };
        assert!(
            !verify([0u8; 32], &proof_b, [0xAAu8; 32]),
            "case (b): 2-element path for tree_size=100 must be rejected"
        );
    }

    // -------------------------------------------------------------------------
    // AC-1.3-17: prop_roundtrip_verify — random tree + proof + verify always true
    //
    // Strategy: random tree_size in 2..=100, random leaf_index in 0..tree_size,
    // random leaves of correct length (nested prop_flat_map removes prop_assume).
    // 256 cases mandatory per brief §11 footgun 14.
    // -------------------------------------------------------------------------

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(256))]

        #[test]
        fn prop_roundtrip_verify(
            (tree_size, leaf_index, leaves) in (2_usize..=100_usize).prop_flat_map(|n| {
                (
                    Just(n),
                    0_usize..n,
                    proptest::collection::vec(proptest::array::uniform32(any::<u8>()), n),
                )
            }),
        ) {
            let tree = MerkleTree::new(&leaves).expect("tree new");
            let proof = tree.proof(leaf_index as u64).expect("proof");
            let ok = verify(leaves[leaf_index], &proof, tree.root());
            prop_assert!(
                ok,
                "verify returned false for valid proof tree_size={} leaf_index={}",
                tree_size,
                leaf_index
            );
        }
    }

    // -------------------------------------------------------------------------
    // AC-1.3-18: prop_mutated_proof_rejected — single-bit-flip always rejected
    //
    // Three mutation classes (brief §8 Phase 5):
    //   (a) class 0: flip one bit in one inclusion_path entry
    //   (b) class 1: flip one bit in leaf_index
    //   (c) class 2: flip one bit in tree_size — narrowed to bit 63 only; see
    //               F-7-S1.3 / D-11-S1.3 below
    //
    // path_entry_idx is any::<usize>() clamped via %; avoids prop_assume rejection.
    // 256 cases mandatory per brief §11 footgun 14.
    //
    // F-7-S1.3 finding (discovered via proptest shrink during Phase 5):
    //   RFC 9162 §2.1.3.2 `verify` is not injective in `tree_size` for
    //   neighbouring values that share `floor(log2(n))`.  Example:
    //   tree_size=96 and tree_size=97 with leaf_index=0 produce identical
    //   verification traces, because the bit-shift loop depends only on
    //   `sn = tree_size - 1` and LSB(fn) patterns at each iteration. This is
    //   correct RFC behaviour reflecting the algorithm's bit-shift structure,
    //   not a defect in the render from §8 Phase 4. Low-bit flips in
    //   `tree_size` can therefore leave a proof verifying as true, which
    //   would falsify the class (c) invariant if the full "random bit" space
    //   were used.
    //
    // D-11-S1.3 deviation (forced by F-7-S1.3):
    //   Brief §8 Phase 5 / §6 AC-1.3-18 spec says "flip one bit in
    //   `tree_size`" with an unconstrained random bit position. This impl
    //   restricts class (c) to bit 63 (MSB) unconditionally, because only
    //   MSB flips guarantee verification rejection across every valid
    //   (tree_size, leaf_index) pair in the 2..=100 range. All three
    //   mutation classes remain present; the narrowing is within class (c)
    //   only. SSOT revision block scheduled for Phase 6 per HC 23.
    // -------------------------------------------------------------------------

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(256))]

        #[test]
        fn prop_mutated_proof_rejected(
            (tree_size, leaf_index, leaves, mutation_class, path_entry_idx, bit_idx, byte_idx)
                in (2_usize..=100_usize).prop_flat_map(|n| {
                    (
                        Just(n),
                        0_usize..n,
                        proptest::collection::vec(proptest::array::uniform32(any::<u8>()), n),
                        0_u8..3_u8,
                        any::<usize>(),
                        0_u32..8_u32,
                        0_usize..32_usize,
                    )
                }),
        ) {
            let tree = MerkleTree::new(&leaves).expect("tree new");
            let original_proof = tree.proof(leaf_index as u64).expect("proof");
            let root = tree.root();

            let mut mutated = original_proof.clone();
            match mutation_class {
                0 => {
                    // Class (a): flip one bit in one inclusion_path entry.
                    // tree_size >= 2 guarantees inclusion_path is non-empty, but
                    // the defensive fallback to class (b) guards future strategy evolution.
                    if mutated.inclusion_path.is_empty() {
                        mutated.leaf_index ^= 1;
                    } else {
                        let entry_idx = path_entry_idx % mutated.inclusion_path.len();
                        mutated.inclusion_path[entry_idx][byte_idx] ^= 1_u8 << bit_idx;
                    }
                }
                1 => {
                    // Class (b): flip one bit in leaf_index.
                    // After flip the index may land on a different valid leaf; verify
                    // still returns false because leaves[original_leaf_index] does not
                    // match the new leaf's path (2^-256 collision probability for
                    // non-degenerate random leaves — guaranteed by prop_assume above).
                    let shift = bit_idx % 64;
                    mutated.leaf_index ^= 1_u64 << shift;
                }
                _ => {
                    // Class (c): flip one bit in tree_size.
                    //
                    // RFC 9162 §2.1.3.2 verify is NOT injective in tree_size for all
                    // leaf_index values: pairs (n, n+1) with floor(log2(n)) ==
                    // floor(log2(n+1)) produce the same verification trace for
                    // leaf_index=0, so a low-bit flip can go undetected.
                    //
                    // To guarantee rejection we flip the MSB (bit 63).  This either:
                    //   - sets the MSB → mutated_tree_size >= 2^63, making the
                    //     inclusion_path astronomically too short → sn never reaches
                    //     0 → verify returns false; or
                    //   - clears the MSB on a tree_size that had it set → produces
                    //     a structurally different tree whose root differs from the
                    //     committed root (or bounds check fails).
                    // Either way verify returns false.
                    mutated.tree_size ^= 1_u64 << 63;
                }
            }

            let ok = verify(leaves[leaf_index], &mutated, root);
            prop_assert!(
                !ok,
                "mutated proof verified true (class={}, tree_size={}, leaf_index={})",
                mutation_class,
                tree_size,
                leaf_index
            );
        }
    }
}
