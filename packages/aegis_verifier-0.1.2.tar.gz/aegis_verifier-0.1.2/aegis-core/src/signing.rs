//! ML-DSA-65 (FIPS 204) tree-head signing for Aegis MTAC issuance.
//!
//! # Architecture
//!
//! This module implements the signing primitive updated in Sub-Slice 1.6
//! with dual-layer domain separation per HC #34 and AD-1.6-02.
//!
//! ## Path (a) — `Zeroizing<Vec<u8>>` secret key storage
//!
//! Phase 0 probe P0-9 confirmed that `oqs::sig::SecretKey` does NOT implement
//! `zeroize::Zeroize`. Per §11 footgun #25, Path (a) is used: the secret key bytes
//! are extracted via `secret_key.as_ref().to_vec()` at construction time, wrapped
//! in `Zeroizing<Vec<u8>>` (which wipes the bytes on drop), and the original
//! `oqs::sig::SecretKey` is immediately dropped. Per-sign cost is one
//! `sig.secret_key_from_bytes()` call to reconstruct a `SecretKeyRef`; at
//! CA-issuance frequency this is negligible. (MD-24-S1.4)
//!
//! ## `oqs::init()` lifecycle
//!
//! `ensure_oqs_init()` is called inside `MlDsaSigner::new()`. The `std::sync::Once`
//! guard guarantees exactly one FFI `oqs::init()` call across the process lifetime,
//! even under concurrent construction. (Q3-2(c) lock)
//!
//! ## Domain separation (AD-1.6-02, HC #34)
//!
//! Signing uses dual-layer domain separation:
//! - **Envelope context** (`"AEGIS-STH-v1"` in `bytes_to_sign`): blocks cross-protocol
//!   replay; auditor-visible from wire bytes alone. Added by
//!   [`crate::serialization::encode_sth_envelope_v1`].
//! - **FIPS 204 §5.2 ctx parameter** (`b"AEGIS-STH-v1"` passed to
//!   `sign_with_ctx_str`): blocks cross-algorithm key reuse; modifies M' before μ.
//!   Not visible in wire bytes; must be documented out-of-band for verifiers.
//!
//! Both layers fire per signature. Removing either is a critical security regression.

use crate::serialization::{Extension, WIRE_VERSION};
use sha2::{Digest, Sha256};
use std::sync::Once;

/// One-time guard for `oqs::init()`.
///
/// Per Q3-2(c) lock: idempotent at runtime; provably-once via `std::sync::Once`.
static OQS_INIT: Once = Once::new();

/// Calls `oqs::init()` exactly once across the process lifetime.
///
/// Public so `aegis-verifier` can share the `Once` guard without duplicating
/// the FFI lifecycle. Consumed by `MlDsaSigner::new()` and
/// `verify_signed_tree_head()` (`aegis-verifier`).
pub fn ensure_oqs_init() {
    OQS_INIT.call_once(oqs::init);
}

/// Errors from ML-DSA-65 signing operations.
///
/// All five variants are declared so that tests can verify `Display` format
/// for every case. (MD-25-S1.4 extended in Slice 1.6)
#[derive(Debug, thiserror::Error)]
pub enum SigError {
    /// Returned when `oqs::sig::Sig::new()` or `sig.keypair()` fails.
    #[error("ML-DSA-65 keypair generation failed: {0}")]
    KeygenFailed(oqs::Error),

    /// Returned when `sig.sign_with_ctx_str()` fails at the FFI layer.
    #[error("ML-DSA-65 signing failed: {0}")]
    SignFailed(oqs::Error),

    /// Returned when the signature produced by signing is not 3309 bytes.
    ///
    /// Guards against oqs version drift. Display keeps `"expected 3309"` hardcoded
    /// for demo clarity per rev-2 Amendment 4 (Stage 5 F-PP-004).
    #[error("signature length invariant violated: expected 3309, got {0}")]
    SignatureLengthInvariant(usize),

    /// Returned if `sig.secret_key_from_bytes(&secret_key)` yields `None`.
    ///
    /// Theoretically unreachable (bytes came from a live keypair at construction
    /// time), but defensive against in-memory corruption. Path (a) per P0-9 RED
    /// + §11 footgun #25. (MD-25-S1.4)
    #[error("ML-DSA-65 secret key reconstruction from stored bytes failed")]
    SecretKeyReconstructionFailed,

    /// Returned by `MlDsaSigner::new()` when the linked liboqs build does not
    /// support the `ctx_str` signing API (`has_ctx_str_support()` returned false).
    ///
    /// This guards against building against an older vendored liboqs that lacks
    /// FIPS 204 §5.2 ctx parameter support (per AD-1.6-02). Aegis requires
    /// `sign_with_ctx_str` / `verify_with_ctx_str` for dual-layer domain separation.
    #[error(
        "ML-DSA-65 ctx_str signing not supported by linked liboqs; \
         upgrade to liboqs >= 0.12 (Aegis requires FIPS 204 §5.2 ctx parameter support)"
    )]
    CtxStrNotSupported,
}

/// RFC 9162 §4.10 `TreeHeadDataV2` — the body-fields being signed.
///
/// Serialized via [`crate::serialization::encode_sth_body_v1`] into the canonical
/// CBOR wire format (RFC 8949 §4.2.1 CDE-compatible) before signing.
///
/// `sth_extensions` is always empty in Aegis Alpha; the encoder handles
/// non-empty values correctly per RFC 9162 §4.9.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct TreeHeadDataV2 {
    /// Milliseconds since Unix epoch (RFC 9162 §4.9). NOT seconds.
    pub timestamp: u64,
    /// Number of leaves in the tree (matches `merkle-v1` `InclusionProof.tree_size`).
    pub tree_size: u64,
    /// SHA-256 Merkle root (32 bytes).
    pub root_hash: [u8; 32],
    /// RFC 9162 §4.9 `sth_extensions`. Empty `Vec` for Aegis Alpha.
    pub sth_extensions: Vec<Extension>,
}

/// ML-DSA-65 (FIPS 204) signing primitive for Aegis MTAC tree-head signing.
///
/// # Secret key zeroization (Path (a), MD-24-S1.4)
///
/// `oqs::sig::SecretKey` does not implement `zeroize::Zeroize` (P0-9 RED).
/// Per §11 footgun #25, the raw bytes are stored in `Zeroizing<Vec<u8>>`, which
/// wipes the memory on drop. At sign time, `sig.secret_key_from_bytes()` reconstructs
/// a `SecretKeyRef` borrow without any additional heap allocation.
///
/// # Domain separation (HC #34, AD-1.6-02)
///
/// `sign_tree_root` uses dual-layer domain separation:
/// - `bytes_to_sign` includes the `"AEGIS-STH-v1"` envelope via
///   [`crate::serialization::encode_signed_tree_head`] (auditor-visible).
/// - The FIPS 204 §5.2 ctx string `b"AEGIS-STH-v1"` is passed to
///   `sign_with_ctx_str` (cryptographically bound, not in wire bytes).
///
/// # Construction
///
/// Use `MlDsaSigner::new()`. No `Clone`, `Debug`, or `Default` (`HC #23`).
pub struct MlDsaSigner {
    sig: oqs::sig::Sig,
    /// Raw ML-DSA-65 secret key bytes wrapped for secure zeroization.
    ///
    /// Path (a) per P0-9 RED + §11 footgun #25: `oqs::sig::SecretKey` does not impl
    /// `zeroize::Zeroize`, so we store the inner bytes in `Zeroizing<Vec<u8>>`. The
    /// `Zeroizing` wrapper's `Drop` impl calls `zeroize()` on the `Vec`, wiping the
    /// bytes from memory when `MlDsaSigner` is dropped. Per-sign cost: one
    /// `sig.secret_key_from_bytes()` call to obtain a zero-copy `SecretKeyRef`.
    secret_key: zeroize::Zeroizing<Vec<u8>>,
    public_key: oqs::sig::PublicKey,
}

impl MlDsaSigner {
    /// Generates a fresh ML-DSA-65 keypair.
    ///
    /// Calls `ensure_oqs_init()` internally — callers need not invoke `oqs::init()`.
    ///
    /// # Startup guard (AD-1.6-02)
    ///
    /// Calls `sig.has_ctx_str_support()` after constructing the scheme object.
    /// Returns [`SigError::CtxStrNotSupported`] if the linked liboqs does not
    /// support the FIPS 204 §5.2 ctx parameter API. This prevents silent fallback
    /// to a weaker signing path.
    ///
    /// # Errors
    ///
    /// - [`SigError::KeygenFailed`] if `oqs::sig::Sig::new()` or `sig.keypair()` fails.
    /// - [`SigError::CtxStrNotSupported`] if liboqs does not support `ctx_str` signing.
    pub fn new() -> Result<Self, SigError> {
        Self::new_impl(false)
    }

    /// Internal implementation of `new()` with a test seam.
    ///
    /// `force_ctx_str_unsupported = true` is a unit-test seam used to exercise
    /// the AC-1.6-16 negative path (the `Err(SigError::CtxStrNotSupported)` branch).
    /// `oqs::Sig::has_ctx_str_support()` always returns `true` on the linked liboqs
    /// build, so without this seam the negative path is unreachable in tests.
    /// Production callers MUST use [`MlDsaSigner::new`], which calls
    /// `new_impl(false)`. A trait-based OQS mock was considered and rejected
    /// (heavier — would require introducing a Sig trait + adapter across
    /// aegis-core / aegis-verifier call sites for one negative-path test).
    fn new_impl(force_ctx_str_unsupported: bool) -> Result<Self, SigError> {
        ensure_oqs_init();
        let sig =
            oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65).map_err(SigError::KeygenFailed)?;
        // AD-1.6-02 startup guard: fail hard if ctx_str is not supported.
        // `force_ctx_str_unsupported` is false in production; test seam only.
        if force_ctx_str_unsupported || !sig.has_ctx_str_support() {
            return Err(SigError::CtxStrNotSupported);
        }
        let (public_key, secret_key) = sig.keypair().map_err(SigError::KeygenFailed)?;
        // Path (a): extract raw bytes, wrap in Zeroizing, drop the oqs::sig::SecretKey.
        // `oqs::sig::SecretKey` does not impl Zeroize; `Zeroizing<Vec<u8>>` does.
        let secret_key_bytes: Vec<u8> = secret_key.as_ref().to_vec();
        let secret_key = zeroize::Zeroizing::new(secret_key_bytes);
        Ok(Self {
            sig,
            secret_key,
            public_key,
        })
    }

    /// Returns the raw 1,952-byte ML-DSA-65 public key as a borrowed slice.
    ///
    /// Callers compute `log_id` / `ca_spki` via `compute_log_id(signer.public_key())`.
    #[must_use]
    pub fn public_key(&self) -> &[u8] {
        self.public_key.as_ref()
    }

    /// Returns an owned copy of the raw 1,952-byte ML-DSA-65 public key.
    ///
    /// Convenience accessor for callers that need an owned `[u8; 1952]` (e.g.,
    /// `MlDsaSigner` → `VerifierContext` hand-off without lifetime coupling).
    /// Per DF-1.6-07.
    ///
    /// # Panics
    ///
    /// Panics if the public key is not exactly 1,952 bytes — guarded at keypair
    /// generation time; unreachable in practice.
    #[must_use]
    pub fn public_key_owned(&self) -> [u8; 1952] {
        self.public_key
            .as_ref()
            .try_into()
            .expect("ML-DSA-65 public key must be exactly 1952 bytes")
    }

    /// Signs the canonical CBOR encoding of `tree_head` per AD-1.6-02.
    ///
    /// Uses dual-layer domain separation (HC #34):
    /// 1. `bytes_to_sign` is the envelope produced by
    ///    [`crate::serialization::encode_signed_tree_head`], which embeds
    ///    `"AEGIS-STH-v1"` as the CBOR text element (auditor-visible).
    /// 2. The FIPS 204 §5.2 ctx parameter `b"AEGIS-STH-v1"` is passed
    ///    UNCONDITIONALLY to `sign_with_ctx_str` (cryptographically bound,
    ///    NOT in wire bytes). There is no fallback path.
    ///
    /// Returns the 3,309-byte ML-DSA-65 signature for valid inputs. The signature
    /// is non-reproducible by design (FIPS 204 §3.5 hedged variant).
    ///
    /// # Implementation (Path (a), MD-24-S1.4)
    ///
    /// Reconstructs a `SecretKeyRef` from the `Zeroizing<Vec<u8>>` byte store on every
    /// call via `sig.secret_key_from_bytes()`. Zero-copy at the oqs boundary.
    ///
    /// # Errors
    ///
    /// - [`SigError::SecretKeyReconstructionFailed`] if `secret_key_from_bytes` returns `None`.
    /// - [`SigError::SignFailed`] if the oqs FFI sign call fails.
    /// - [`SigError::SignatureLengthInvariant`] if the produced signature is not 3,309 bytes.
    pub fn sign_tree_root(&self, tree_head: &TreeHeadDataV2) -> Result<Vec<u8>, SigError> {
        ensure_oqs_init();
        // Compute log_id from this signer's public key — it is part of the signed body.
        let log_id = compute_log_id(self.public_key());
        // Single canonical bytes_to_sign extraction via the footgun-#46 helper.
        let sth = SignedTreeHead {
            log_id,
            tree_head: tree_head.clone(),
            signature_bytes: Vec::new(),
        };
        let message = crate::serialization::encode_signed_tree_head(&sth);
        let sk_ref = self
            .sig
            .secret_key_from_bytes(&self.secret_key)
            .ok_or(SigError::SecretKeyReconstructionFailed)?;
        // UNCONDITIONAL sign_with_ctx_str — FIPS 204 §5.2 ctx (AD-1.6-02, Stage 6 WARN-13).
        // No fallback. No conditional path. has_ctx_str_support() checked in new().
        let signature = self
            .sig
            .sign_with_ctx_str(&message, WIRE_VERSION.as_bytes(), sk_ref)
            .map_err(SigError::SignFailed)?;
        let bytes: Vec<u8> = signature.as_ref().to_vec();
        let expected = self.sig.length_signature();
        if bytes.len() != expected {
            return Err(SigError::SignatureLengthInvariant(bytes.len()));
        }
        Ok(bytes)
    }
}

// Manual marker-trait impl per binding decision (Option X for AC-1.4-34).
// The actual zeroization is performed by `Zeroizing<Vec<u8>>`'s `Drop` impl,
// which calls `zeroize()` on the inner `Vec<u8>` when `MlDsaSigner` is dropped.
// This `impl` declares the API-level promise that `MlDsaSigner` zeroizes on drop.
impl zeroize::ZeroizeOnDrop for MlDsaSigner {}

/// RFC 9162 §4.10 `SignedTreeHead` envelope.
///
/// `log_id` is the SHA-256 fingerprint of the CA's ML-DSA-65 public key (RFC 9162 §4.4),
/// computed via [`compute_log_id`]. Verifiers look up the corresponding pubkey out-of-band.
///
/// `signature_bytes` is the ML-DSA-65 signature over the canonical CBOR encoding
/// of `tree_head` per AD-1.6-02 (dual-layer domain separation). Always 3,309 bytes
/// for ML-DSA-65 (FIPS 204 Table 2).
///
/// Note: `log_id` is envelope metadata, NOT part of the signed payload. The `log_id`-to-pubkey
/// binding is enforced at verify time via `verify_signed_tree_head`.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct SignedTreeHead {
    /// 32-byte SHA-256 fingerprint of the CA's ML-DSA-65 public key (RFC 9162 §4.4).
    pub log_id: [u8; 32],
    /// The signed `TreeHeadDataV2` payload (RFC 9162 §4.9).
    pub tree_head: TreeHeadDataV2,
    /// ML-DSA-65 signature over the canonical CBOR encoding of `tree_head` per AD-1.6-02.
    ///
    /// `Vec<u8>` per HC #11 — do NOT use `[u8; 3309]` (array syntax rejected by serde
    /// without custom impls and breaks forward-compatibility).
    pub signature_bytes: Vec<u8>,
}

/// Computes the 32-byte `log_id` (RFC 9162 §4.4) from a CA's ML-DSA-65 public key.
///
/// Returns `SHA-256(ca_public_key)`. The same 32 bytes serve as `ca_spki` for
/// `aegis_core::leaf::hash_leaf` per Pass 2 Q-P2-5 lock and P0-5 CRITICAL probe.
///
/// # Example
///
/// ```ignore
/// let log_id = compute_log_id(signer.public_key());
/// ```
#[must_use]
pub fn compute_log_id(ca_public_key: &[u8]) -> [u8; 32] {
    Sha256::digest(ca_public_key).into()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// AC-1.6-16 (negative) — `MlDsaSigner::new_impl(true)` returns
    /// `Err(SigError::CtxStrNotSupported)`, confirming the guard returns an error
    /// rather than panicking or silently proceeding when `has_ctx_str_support()` is false.
    ///
    /// Uses `new_impl(true)` as an inline test seam — `true` forces the guard to fire
    /// regardless of what `has_ctx_str_support()` actually returns.
    #[test]
    fn mldsa_signer_new_returns_err_when_ctx_str_unsupported() {
        ensure_oqs_init();
        let result = MlDsaSigner::new_impl(true);
        assert!(
            matches!(result, Err(SigError::CtxStrNotSupported)),
            "new_impl(force=true) must return Err(CtxStrNotSupported)"
        );
    }
}
