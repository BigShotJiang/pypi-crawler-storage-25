//! `MtacLeaf` — schema-v1 wire format.
//!
//! Frozen in Sub-Slice 1.2. Do not modify field ordering, field names,
//! or field types without bumping [`SCHEMA_VERSION`].

use crate::error::LeafError;
use dcbor::prelude::*;

/// Current schema version. Strict equality: any encoded leaf whose
/// `schema_version` field is not equal to this constant is rejected at
/// deserialize time.
pub const SCHEMA_VERSION: u8 = 1;

/// A single agent identity assertion, version 1 of the Aegis wire format.
///
/// Fields are immutable after construction. Field order is normative —
/// the canonical `CBOR` encoder relies on the bytewise-lexicographic sort
/// of encoded keys (`RFC` 8949 §4.2.1), which is insertion-order-independent,
/// but Rust struct field ordering here is the human-readable reference.
///
/// # Fields
///
/// - `schema_version`: always 1 in this protocol version. Strict equality enforced.
/// - `agent_id`: issuer-scoped identifier. Recommended format: `urn:aegis:agent:<uuid>`
///   internally; `did:aegis:<uuid>` externally. Uniqueness is the `CA`'s responsibility,
///   not the schema's.
/// - `sponsor_id`: the human or organisational principal that authorised the agent.
/// - `authorized_scopes`: the capabilities this agent is permitted to exercise.
///   Opaque strings at the schema layer. Scope vocabulary is enforced in
///   Sub-Slice 1.5 (`CA` layer) and Sub-Slice 3.1 (Scope Engine).
/// - `not_before`, `not_after`: Unix epoch seconds, inclusive validity window.
///   Semantic validation (window coherence) is deferred to the `CA` layer —
///   this struct will serialise any two `u64` values without complaint.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MtacLeaf {
    pub schema_version: u8,
    pub agent_id: String,
    pub sponsor_id: String,
    pub authorized_scopes: Vec<String>,
    pub not_before: u64,
    pub not_after: u64,
}

impl MtacLeaf {
    /// Construct a new leaf with `schema_version` fixed to [`SCHEMA_VERSION`].
    #[must_use]
    pub fn new(
        agent_id: String,
        sponsor_id: String,
        authorized_scopes: Vec<String>,
        not_before: u64,
        not_after: u64,
    ) -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            agent_id,
            sponsor_id,
            authorized_scopes,
            not_before,
            not_after,
        }
    }
}

impl MtacLeaf {
    /// Encode this leaf as canonical `CBOR` in the dcbor profile
    /// (subset of `CDE` per `draft-ietf-cbor-cde`, subset of `RFC` 8949 §4.2.1 `CDER`).
    ///
    /// The resulting bytes are deterministic: two independent serialisations
    /// of structurally identical leaves produce byte-identical output.
    /// This is the property relied upon by the leaf hash preimage and
    /// therefore by every downstream signature.
    ///
    /// # Errors
    ///
    /// Returns [`LeafError::Encode`] if `dcbor` rejects any field value.
    /// In schema-v1 this is unreachable with well-typed Rust inputs but
    /// surfaced as an error type for forward compatibility.
    pub fn serialize_canonical(&self) -> Result<Vec<u8>, LeafError> {
        let mut m = Map::new();
        m.insert("schema_version", self.schema_version);
        m.insert("agent_id", self.agent_id.clone());
        m.insert("sponsor_id", self.sponsor_id.clone());
        m.insert("authorized_scopes", self.authorized_scopes.clone());
        m.insert("not_before", self.not_before);
        m.insert("not_after", self.not_after);
        Ok(CBOR::from(m).to_cbor_data())
    }

    /// Decode a canonical `CBOR` byte string into an `MtacLeaf`.
    ///
    /// # Errors
    ///
    /// - [`LeafError::Decode`] if `bytes` is not valid `CBOR`.
    /// - [`LeafError::Malformed`] if required fields are missing or have wrong types.
    /// - [`LeafError::UnsupportedSchemaVersion`] if `schema_version != 1`.
    pub fn deserialize(bytes: &[u8]) -> Result<Self, LeafError> {
        let cbor = CBOR::try_from_data(bytes).map_err(|e| LeafError::Decode(e.to_string()))?;
        let map: Map = match cbor.into_case() {
            CBORCase::Map(m) => m,
            _ => {
                return Err(LeafError::Malformed(
                    "expected map at top level".to_string(),
                ))
            }
        };

        // Field extraction — every missing field is malformed.
        let schema_version: u64 = map
            .extract("schema_version")
            .map_err(|e| LeafError::Malformed(format!("schema_version: {e}")))?;
        if schema_version != u64::from(SCHEMA_VERSION) {
            return Err(LeafError::UnsupportedSchemaVersion(schema_version));
        }
        let agent_id: String = map
            .extract("agent_id")
            .map_err(|e| LeafError::Malformed(format!("agent_id: {e}")))?;
        let sponsor_id: String = map
            .extract("sponsor_id")
            .map_err(|e| LeafError::Malformed(format!("sponsor_id: {e}")))?;
        let authorized_scopes: Vec<String> = map
            .extract("authorized_scopes")
            .map_err(|e| LeafError::Malformed(format!("authorized_scopes: {e}")))?;
        let not_before: u64 = map
            .extract("not_before")
            .map_err(|e| LeafError::Malformed(format!("not_before: {e}")))?;
        let not_after: u64 = map
            .extract("not_after")
            .map_err(|e| LeafError::Malformed(format!("not_after: {e}")))?;

        Ok(Self {
            schema_version: SCHEMA_VERSION,
            agent_id,
            sponsor_id,
            authorized_scopes,
            not_before,
            not_after,
        })
    }
}

use sha2::{Digest, Sha256};

/// 16-byte domain-separation label prefixed to every leaf hash preimage.
///
/// Format: `ASCII` `aegis-leaf/v1` followed by newline (0x0a) and two `NUL`
/// bytes (0x00, 0x00), padded to exactly 16 bytes. Chosen to be `ASCII`-printable
/// for debuggability while still containing unambiguous binary terminators.
///
/// Changing this label is a protocol break requiring a `schema_version` bump.
pub const DOMAIN_LABEL: &[u8; 16] = b"aegis-leaf/v1\n\0\0";

/// Leaf-type byte prefix per `RFC` 9162 §2.1: leaf hashes begin with 0x00,
/// internal node hashes begin with 0x01. This is the single most important
/// structural marker for anyone auditing an Aegis Merkle tree against
/// `RFC` 9162.
const LEAF_TYPE_BYTE: u8 = 0x00;

/// Build the byte string that [`hash_leaf`] will hash.
///
/// Exposed for testing and debugging. Also available for other `aegis-core`
/// components that need to verify the preimage construction without
/// duplicating the concatenation logic.
///
/// # Preimage layout
///
/// ```text
/// Offset  Length    Contents
/// ------  --------  -----------------------------------------
/// 0       1         LEAF_TYPE_BYTE = 0x00 (RFC 9162 §2.1)
/// 1       16        DOMAIN_LABEL
/// 17      32        SHA-256 fingerprint of issuing CA's SPKI
/// 49      variable  Canonical dcbor encoding of the leaf
/// ```
///
/// # Errors
///
/// Propagates any error from [`MtacLeaf::serialize_canonical`].
pub fn hash_preimage(leaf: &MtacLeaf, ca_spki: &[u8; 32]) -> Result<Vec<u8>, LeafError> {
    let leaf_bytes = leaf.serialize_canonical()?;
    let mut buf = Vec::with_capacity(1 + 16 + 32 + leaf_bytes.len());
    buf.push(LEAF_TYPE_BYTE);
    buf.extend_from_slice(DOMAIN_LABEL);
    buf.extend_from_slice(ca_spki);
    buf.extend_from_slice(&leaf_bytes);
    Ok(buf)
}

/// Compute the 32-byte `SHA-256` leaf hash for this leaf, bound to a specific
/// issuing `CA`'s public-key fingerprint.
///
/// # Preimage (`RFC` 9162 §2.1 shape + Aegis domain separation)
///
/// ```text
/// SHA-256(
///     0x00                         //  1 byte  — RFC 9162 leaf-type prefix
///  || DOMAIN_LABEL                 // 16 bytes — "aegis-leaf/v1\n\0\0"
///  || ca_spki                      // 32 bytes — SHA-256 of CA ML-DSA-65 public key
///  || canonical_cbor(leaf)         // variable — dcbor ⊂ CDE ⊂ RFC 8949 §4.2.1 CDER
/// )
/// ```
///
/// # Design notes
///
/// - **`0x00` leaf-type prefix** preserves `RFC` 9162 §2.1 leaf-hash shape.
///   A Merkle auditor can cite `RFC` 9162 §2.1 verbatim when reviewing this
///   tree; the deviation is additive (via the label and `SPKI`), not
///   structural.
/// - **`DOMAIN_LABEL`** separates Aegis leaf hashes from any other Aegis
///   hash context (tree-head signatures, future extensions). Without the
///   label, an adversary with signing oracle access over one hash context
///   could produce forgeries in another.
/// - **`ca_spki` fingerprint** binds the leaf to its issuer. `MTC` assumes
///   single-trust-root-per-deployment; Aegis is multi-`CA` by design. Binding
///   the issuer into the preimage prevents a `CA`-A leaf from being
///   syntactically re-anchored under `CA`-B even if their batch trees
///   coincidentally share structure.
/// - **Leaf index and batch epoch are deliberately NOT in the preimage.**
///   Per `RFC` 9162 §2.1.3.2, position in the tree is bound by the
///   `InclusionProof` object and the verification algorithm that uses
///   `leaf_index` bits to drive sibling-folding. Hashing position into
///   the leaf is redundant and breaks `RFC` 9162 shape. (Slice 1.2 rev-2
///   amendment — see brief §4 Hard Constraint 8.)
///
/// # Errors
///
/// Propagates [`LeafError::Encode`] from canonical serialisation.
pub fn hash_leaf(leaf: &MtacLeaf, ca_spki: &[u8; 32]) -> Result<[u8; 32], LeafError> {
    let preimage = hash_preimage(leaf, ca_spki)?;
    let mut hasher = Sha256::new();
    hasher.update(&preimage);
    Ok(hasher.finalize().into())
}

// Struct definition and constructor tests added Phase 2.
// Serialization and deserialization tests added Phase 3.
// Leaf hash (hash_leaf, hash_preimage, DOMAIN_LABEL) added Phase 4.

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn schema_version_is_one() {
        assert_eq!(SCHEMA_VERSION, 1);
    }

    #[test]
    fn construct_minimal_leaf() {
        let leaf = MtacLeaf::new(
            "urn:aegis:agent:test-001".to_string(),
            "alice@acme.example".to_string(),
            vec!["scope:read".to_string()],
            1_713_600_000,
            1_745_136_000,
        );
        assert_eq!(leaf.schema_version, 1);
        assert_eq!(leaf.agent_id, "urn:aegis:agent:test-001");
        assert_eq!(leaf.sponsor_id, "alice@acme.example");
        assert_eq!(leaf.authorized_scopes, vec!["scope:read"]);
        assert_eq!(leaf.not_before, 1_713_600_000);
        assert_eq!(leaf.not_after, 1_745_136_000);
    }

    #[test]
    fn canonical_roundtrip_minimal() {
        let leaf = MtacLeaf::new(
            "urn:aegis:agent:rt-001".to_string(),
            "alice@acme.example".to_string(),
            vec!["scope:read".to_string()],
            1_713_600_000,
            1_745_136_000,
        );
        let bytes = leaf.serialize_canonical().expect("serialize");
        let back = MtacLeaf::deserialize(&bytes).expect("deserialize");
        assert_eq!(leaf, back);

        // Determinism: two independent serialisations produce byte-identical output.
        let bytes2 = leaf.serialize_canonical().expect("serialize 2");
        assert_eq!(bytes, bytes2);
    }

    #[test]
    fn canonical_order_independent() {
        // Two leaves with identical content encode identically regardless of
        // whatever internal key-visit order `dcbor` uses — dcbor ⊂ CDE ⊂ RFC 8949 §4.2.1 CDER.
        let a = MtacLeaf::new(
            "agent-1".into(),
            "sponsor-1".into(),
            vec!["scope:x".into(), "scope:y".into()],
            100,
            200,
        );
        let b = MtacLeaf::new(
            "agent-1".into(),
            "sponsor-1".into(),
            vec!["scope:x".into(), "scope:y".into()],
            100,
            200,
        );
        assert_eq!(
            a.serialize_canonical().unwrap(),
            b.serialize_canonical().unwrap()
        );
    }

    #[test]
    fn reject_schema_version_two() {
        // Hand-craft a CBOR map with schema_version: 2 — must be rejected.
        let bad = build_leaf_bytes_with_schema_version(2);
        let result = MtacLeaf::deserialize(&bad);
        assert!(
            matches!(
                result,
                Err(crate::error::LeafError::UnsupportedSchemaVersion(2))
            ),
            "expected UnsupportedSchemaVersion(2), got {result:?}"
        );
    }

    // Test helper: build a valid-shape CBOR leaf map but with an arbitrary
    // schema_version. Used only by the schema-version rejection test.
    fn build_leaf_bytes_with_schema_version(v: u8) -> Vec<u8> {
        use dcbor::prelude::*;
        let mut m = Map::new();
        m.insert("schema_version", v);
        m.insert("agent_id", "agent-x".to_string());
        m.insert("sponsor_id", "sponsor-x".to_string());
        m.insert("authorized_scopes", Vec::<String>::new());
        m.insert("not_before", 0_u64);
        m.insert("not_after", 0_u64);
        CBOR::from(m).to_cbor_data()
    }

    // -------------------------------------------------------------------------
    // Phase 4 — leaf hash tests (AC-1.2-09 .. AC-1.2-12)
    // -------------------------------------------------------------------------

    // Shared test fixtures for Phase 4
    fn make_test_leaf() -> MtacLeaf {
        MtacLeaf::new(
            "urn:aegis:agent:hash-001".into(),
            "sponsor@acme.example".into(),
            vec!["scope:read".into()],
            1_713_600_000,
            1_745_136_000,
        )
    }

    const FAKE_SPKI_A: [u8; 32] = [0xAA; 32];
    const FAKE_SPKI_B: [u8; 32] = [0xBB; 32];

    #[test]
    fn leaf_hash_is_32_bytes() {
        let leaf = make_test_leaf();
        let h = hash_leaf(&leaf, &FAKE_SPKI_A).expect("hash");
        assert_eq!(h.len(), 32);
    }

    #[test]
    fn leaf_hash_changes_with_ca_spki() {
        let leaf = make_test_leaf();
        let h_a = hash_leaf(&leaf, &FAKE_SPKI_A).unwrap();
        let h_b = hash_leaf(&leaf, &FAKE_SPKI_B).unwrap();
        assert_ne!(h_a, h_b, "different CA SPKI must produce different hash");
    }

    #[test]
    fn leaf_hash_preimage_structure() {
        // White-box: hash_preimage() exposes the bytes-about-to-be-hashed.
        // Verify RFC 9162 §2.1 shape (0x00 leaf-type prefix) plus Aegis
        // domain separation (label + CA SPKI).
        let leaf = make_test_leaf();
        let preimage = hash_preimage(&leaf, &FAKE_SPKI_A).unwrap();

        // Byte 0: RFC 9162 leaf-type prefix
        assert_eq!(
            preimage[0], 0x00,
            "leading byte must be 0x00 per RFC 9162 §2.1"
        );

        // Bytes 1..17: 16-byte domain-separation label
        assert_eq!(&preimage[1..17], DOMAIN_LABEL.as_slice());

        // Bytes 17..49: 32-byte CA SPKI fingerprint
        assert_eq!(&preimage[17..49], &FAKE_SPKI_A);

        // Bytes 49..: canonical dcbor encoding of the leaf
        let expected_cbor = leaf.serialize_canonical().unwrap();
        assert_eq!(&preimage[49..], &expected_cbor[..]);
    }

    #[test]
    fn domain_label_length() {
        // DOMAIN_LABEL is exactly 16 bytes — changing this is a protocol break.
        assert_eq!(DOMAIN_LABEL.len(), 16);
    }

    // -------------------------------------------------------------------------
    // Phase 5 — property-based tests (AC-1.2-15, AC-1.2-16)
    // -------------------------------------------------------------------------

    use proptest::prelude::*;

    fn arb_leaf() -> impl Strategy<Value = MtacLeaf> {
        (
            "[a-zA-Z0-9:_./-]{1,256}",                             // agent_id
            "[a-zA-Z0-9@._+-]{1,256}",                             // sponsor_id
            prop::collection::vec("[a-zA-Z0-9:_.-]{1,64}", 0..16), // scopes
            any::<u64>(),                                          // not_before
            any::<u64>(),                                          // not_after
        )
            .prop_map(|(aid, sid, scopes, nb, na)| MtacLeaf::new(aid, sid, scopes, nb, na))
    }

    proptest! {
        #[test]
        fn prop_random_leaves_roundtrip(leaf in arb_leaf()) {
            let bytes = leaf.serialize_canonical().expect("serialize");
            let back = MtacLeaf::deserialize(&bytes).expect("deserialize");
            prop_assert_eq!(leaf, back);
        }

        #[test]
        fn prop_field_order_hash_invariant(
            leaf in arb_leaf(),
            ca_spki_byte in any::<u8>(),
        ) {
            // Two independent hashes of the same leaf+CA-SPKI must produce
            // the same output. This is the determinism contract relied upon
            // by every signature and Merkle tree in the system.
            let spki = [ca_spki_byte; 32];
            let h1 = hash_leaf(&leaf, &spki).expect("h1");
            let h2 = hash_leaf(&leaf.clone(), &spki).expect("h2");
            prop_assert_eq!(h1, h2);
        }
    }
}
