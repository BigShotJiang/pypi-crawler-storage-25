//! AC-1.5-29, AC-1.5-30, AC-1.5-43 — E2E demo tests.
//!
//! `demo_e2e_three_register_one_commit_three_verify` is parameterized on build
//! profile via `cfg!(debug_assertions)` so it closes both AC-1.5-29 (debug < 200ms)
//! and AC-1.5-43 (release < 100ms) from the same test function.
//!
//! `sequential_two_batches_distinct_ids_and_roots_and_monotonic_timestamps` covers
//! AC-1.5-30: two sequential batches have distinct IDs, distinct roots, and
//! strictly-increasing UUID v7 timestamps.

use aegis_ca::CertificateAuthority;
use aegis_core::{
    leaf::MtacLeaf,
    signing::{ensure_oqs_init, MlDsaSigner},
};
use aegis_verifier::verify_mtac;

/// Build a deterministic test leaf indexed by `n`.
fn make_demo_leaf(n: u64) -> MtacLeaf {
    MtacLeaf::new(
        format!("urn:aegis:agent:demo-e2e-{n}"),
        "demo-sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// AC-1.5-29 (debug) + AC-1.5-43 (release):
/// 3 `register_agent` → 1 `commit_batch` → 3 `issuance_result` → 3 `verify_mtac`.
///
/// Total wall-clock must be < 200ms in debug (`cfg!(debug_assertions)`)
/// and < 100ms in release (`!cfg!(debug_assertions)`).
///
/// Both thresholds are generous relative to the M-1.5-G measurement of ~315µs.
#[test]
fn demo_e2e_three_register_one_commit_three_verify() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca = CertificateAuthority::new(signer);
    let leaves: Vec<MtacLeaf> = (0..3).map(make_demo_leaf).collect();

    let start = std::time::Instant::now();
    let receipts: Vec<_> = leaves
        .iter()
        .map(|l| ca.register_agent(l).unwrap())
        .collect();
    let _summary = ca.commit_batch().unwrap();
    let results: Vec<_> = receipts
        .iter()
        .map(|r| ca.issuance_result(r.batch_id, r.leaf_index).unwrap())
        .collect();
    let ca_pubkey = ca.ca_public_key();
    for (leaf, result) in leaves.iter().zip(results.iter()) {
        verify_mtac(leaf, result, ca_pubkey).unwrap();
    }
    let elapsed_ms = start.elapsed().as_millis();

    let threshold_ms: u128 = if cfg!(debug_assertions) { 200 } else { 100 };
    let profile = if cfg!(debug_assertions) {
        "debug"
    } else {
        "release"
    };
    assert!(
        elapsed_ms < threshold_ms,
        "demo_e2e {profile} runtime {elapsed_ms}ms exceeds {threshold_ms}ms threshold"
    );
    eprintln!("demo_e2e {profile} runtime: {elapsed_ms}ms (threshold {threshold_ms}ms)");
}

/// AC-1.5-30: two sequential batches have distinct `batch_id`s, distinct tree roots,
/// and both UUID v7 timestamps are strictly increasing.
///
/// The 2ms sleep between commits guards against `TimestampNotMonotonic` when
/// `current_ms()` has 1ms clock granularity.
#[test]
fn sequential_two_batches_distinct_ids_and_roots_and_monotonic_timestamps() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca = CertificateAuthority::new(signer);

    // Batch 1
    let leaf_1 = make_demo_leaf(0);
    let receipt_1 = ca.register_agent(&leaf_1).unwrap();
    let summary_1 = ca.commit_batch().unwrap();

    // Ensure next commit_batch observes a strictly greater timestamp.
    std::thread::sleep(std::time::Duration::from_millis(2));

    // Batch 2
    let leaf_2 = make_demo_leaf(1);
    let receipt_2 = ca.register_agent(&leaf_2).unwrap();
    let summary_2 = ca.commit_batch().unwrap();

    assert_ne!(summary_1.batch_id, summary_2.batch_id, "distinct batch_ids");
    assert_ne!(
        summary_1.signed_tree_head.tree_head.root_hash,
        summary_2.signed_tree_head.tree_head.root_hash,
        "distinct tree roots"
    );
    // UUID v7 embeds timestamps — strictly increasing ordering.
    assert!(
        summary_2.batch_id > summary_1.batch_id,
        "UUID v7 timestamps strictly increasing"
    );
    assert!(
        summary_2.signed_tree_head.tree_head.timestamp
            > summary_1.signed_tree_head.tree_head.timestamp,
        "STH timestamps strictly increasing"
    );

    // Both must verify via verify_mtac.
    let r1 = ca
        .issuance_result(receipt_1.batch_id, receipt_1.leaf_index)
        .unwrap();
    let r2 = ca
        .issuance_result(receipt_2.batch_id, receipt_2.leaf_index)
        .unwrap();
    let pk = ca.ca_public_key();
    verify_mtac(&leaf_1, &r1, pk).unwrap();
    verify_mtac(&leaf_2, &r2, pk).unwrap();
}
