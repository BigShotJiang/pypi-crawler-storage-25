//! AC-1.5-09 — JSON round-trips for public `aegis-ca` types.
//!
//! Tests `PendingReceipt` and `BatchSummary` (both `pub`).
//! `BatchRecord` is `pub(crate)` and cannot be reached from here;
//! its round-trip test lives in `aegis_ca::ca::tests`.

use aegis_ca::{BatchSummary, PendingReceipt};
use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};
use uuid::Uuid;

/// Build a deterministic [`PendingReceipt`] fixture.
fn fixture_pending_receipt() -> PendingReceipt {
    let batch_id = Uuid::parse_str("018d6b9a-2c3d-7000-8000-000000000003").unwrap();
    PendingReceipt {
        batch_id,
        leaf_index: 7,
        max_finalize_at: 1_700_000_000_000 + 1000,
    }
}

/// Build a deterministic [`BatchSummary`] fixture.
fn fixture_batch_summary() -> BatchSummary {
    let batch_id = Uuid::parse_str("018d6b9a-2c3d-7000-8000-000000000004").unwrap();

    let sth = SignedTreeHead {
        log_id: [0xDD; 32],
        tree_head: TreeHeadDataV2 {
            timestamp: 1_700_000_001_000,
            tree_size: 5,
            root_hash: [0xEE; 32],
            sth_extensions: vec![],
        },
        signature_bytes: vec![0u8; 3309],
    };

    BatchSummary {
        batch_id,
        leaves_count: 5,
        finalized_at: 1_700_000_001_000,
        signed_tree_head: sth,
    }
}

/// AC-1.5-09: `PendingReceipt` survives a JSON round-trip.
#[test]
fn pending_receipt_json_roundtrip() {
    let original = fixture_pending_receipt();
    let json = serde_json::to_string(&original).expect("serialize PendingReceipt to JSON");
    let restored: PendingReceipt =
        serde_json::from_str(&json).expect("deserialize PendingReceipt from JSON");
    assert_eq!(
        original, restored,
        "PendingReceipt must survive a JSON round-trip unchanged"
    );
}

/// AC-1.5-09: `BatchSummary` survives a JSON round-trip.
#[test]
fn batch_summary_json_roundtrip() {
    let original = fixture_batch_summary();
    let json = serde_json::to_string(&original).expect("serialize BatchSummary to JSON");
    let restored: BatchSummary =
        serde_json::from_str(&json).expect("deserialize BatchSummary from JSON");
    assert_eq!(
        original, restored,
        "BatchSummary must survive a JSON round-trip unchanged"
    );
}
