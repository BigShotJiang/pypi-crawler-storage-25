//! M-1.5-G Phase-4-exit measurement per D-12-S1.5.
//!
//! Single round-trip latency in debug mode: `register_agent` + `commit_batch` +
//! `issuance_result` + `verify_mtac`. Measurement only — no assertion.
//!
//! Per SLICE-1.5-BRIEF.md §5 M-1.5-G spec (Phase-2-exit-deferred-to-Phase-4-exit):
//! - Run in default (debug) mode.
//! - Capture the `eprintln!` line verbatim.
//! - Report to Moderator; Moderator locks AC-1.5-29 threshold via formula
//!   `ceil(M × 2 / 100) × 100`, minimum 200 ms.

use aegis_ca::CertificateAuthority;
use aegis_core::leaf::MtacLeaf;
use aegis_core::signing::{ensure_oqs_init, MlDsaSigner};
use aegis_verifier::verify_mtac;
use std::time::Instant;

/// Construct a deterministic test leaf for the latency probe.
fn make_demo_leaf() -> MtacLeaf {
    MtacLeaf::new(
        "urn:aegis:agent:probe-m-1-5-g".to_string(),
        "probe-sponsor@acme.example".to_string(),
        vec!["scope:read".to_string(), "scope:write".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// M-1.5-G: single round-trip latency in debug mode (measurement only).
///
/// Measures: `register_agent` + `commit_batch` + `issuance_result` + `verify_mtac`.
/// No assertion — the measurement is reported to the Moderator for AC-1.5-29
/// threshold locking.
///
/// Run via:
/// ```
/// cargo nextest run --workspace _probe_latency -E 'test(m_1_5_g_round_trip_latency_debug)' --no-capture
/// ```
#[test]
fn m_1_5_g_round_trip_latency_debug() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca = CertificateAuthority::new(signer);
    let leaf = make_demo_leaf();

    let start = Instant::now();
    let receipt = ca.register_agent(&leaf).unwrap();
    let _summary = ca.commit_batch().unwrap();
    let result = ca
        .issuance_result(receipt.batch_id, receipt.leaf_index)
        .unwrap();
    let ca_pubkey: &[u8; 1952] = ca.ca_public_key();
    verify_mtac(&leaf, &result, ca_pubkey).unwrap();
    let elapsed = start.elapsed();

    eprintln!("M-1.5-G round-trip latency in debug: {elapsed:?}");
    // No assertion — measurement only (brief §5 spec).
}
