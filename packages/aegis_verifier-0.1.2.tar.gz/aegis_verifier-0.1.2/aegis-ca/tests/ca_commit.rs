//! AC-1.5-14, 15, 17, 41-full, 42 — `CertificateAuthority::commit_batch` tests.
//!
//! Note: AC-1.5-16 (`last_signed_at` updated) and AC-1.5-18 (monotonicity) are in
//! `aegis_ca::ca::tests` (unit tests inside `ca.rs`) because those tests require
//! direct access to the private `last_signed_at` field.

use aegis_ca::{CaError, CertificateAuthority};
use aegis_core::{
    leaf::MtacLeaf,
    signing::{compute_log_id, ensure_oqs_init, MlDsaSigner},
};
use aegis_verifier::{verify_mtac, verify_signed_tree_head};

/// Build a deterministic test leaf.
fn make_leaf(agent_id: &str) -> MtacLeaf {
    MtacLeaf::new(
        agent_id.to_string(),
        "sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// Build a CA, ready for testing.
fn make_ca() -> CertificateAuthority {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    CertificateAuthority::new(signer)
}

/// AC-1.5-14: `commit_batch()` on an empty pending buffer returns `EmptyBatch`.
#[test]
fn commit_on_empty_batch_returns_empty_batch_error() {
    let ca = make_ca();
    let err = ca.commit_batch().unwrap_err();
    assert!(
        matches!(err, CaError::EmptyBatch),
        "expected CaError::EmptyBatch, got: {err:?}"
    );
}

/// AC-1.5-15: `commit_batch()` on N=3 leaves returns correct `BatchSummary` with
/// verifiable STH.
#[test]
fn commit_three_leaves_returns_correct_summary_with_valid_sth() {
    let ca = make_ca();
    let ca_pubkey = ca.ca_public_key().to_owned();

    ca.register_agent(&make_leaf("agent-0")).unwrap();
    ca.register_agent(&make_leaf("agent-1")).unwrap();
    ca.register_agent(&make_leaf("agent-2")).unwrap();

    let summary = ca.commit_batch().unwrap();

    assert_eq!(
        summary.leaves_count, 3,
        "BatchSummary.leaves_count must be 3"
    );
    assert_eq!(
        summary.signed_tree_head.tree_head.tree_size, 3,
        "STH.tree_head.tree_size must be 3"
    );

    // STH signature must verify against the CA's public key.
    assert!(
        verify_signed_tree_head(&summary.signed_tree_head, &ca_pubkey).is_ok(),
        "STH signature must verify against CA's public key"
    );
}

/// AC-1.5-17: after `commit_batch()`, a new `register_agent` returns a DIFFERENT
/// `batch_id`, confirming UUID rotation.
///
/// Also observably tests that `pending.leaf_hashes` cleared (new register returns
/// `leaf_index` 0, not a continuation index).
#[test]
fn commit_rotates_batch_id_and_clears_pending() {
    let ca = make_ca();

    let receipt_1 = ca.register_agent(&make_leaf("agent-batch1")).unwrap();
    let b_old = receipt_1.batch_id;

    ca.commit_batch().unwrap();

    // Register into the next batch.
    let receipt_2 = ca.register_agent(&make_leaf("agent-batch2")).unwrap();
    let b_new = receipt_2.batch_id;

    assert_ne!(
        b_old, b_new,
        "batch_id must rotate after commit_batch (UUID v7 rotation per HC-P3-2)"
    );

    // Leaf index must be 0 — confirming the buffer was cleared.
    assert_eq!(
        receipt_2.leaf_index, 0,
        "first register after commit must return leaf_index 0 (buffer was cleared)"
    );
}

/// AC-1.5-41 full (P3 structural + P4 `verify_mtac`): single-leaf batch has empty
/// `inclusion_path`, root equals leaf hash, and `verify_mtac` returns `Ok(())`.
///
/// P3 closed the structural sub-clauses; P4 adds the `verify_mtac` assertion
/// that fully closes AC-1.5-41 per SLICE-1.5-BRIEF.md §6.
#[test]
fn single_leaf_batch_has_empty_proof_path_and_root_equals_leaf_hash() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca_spki = compute_log_id(signer.public_key());
    let ca = CertificateAuthority::new(signer);

    let leaf = make_leaf("agent-single");
    let receipt = ca.register_agent(&leaf).unwrap();
    let summary = ca.commit_batch().unwrap();
    let result = ca
        .issuance_result(receipt.batch_id, receipt.leaf_index)
        .unwrap();

    // Structural sub-clauses — AC-1.5-41 P3 portion.
    assert_eq!(
        result.inclusion_proof.inclusion_path.len(),
        0,
        "single-leaf tree must have empty inclusion_path"
    );

    // Root equals leaf hash (single-leaf tree invariant from RFC 9162 §2.1.1).
    let expected_leaf_hash =
        aegis_core::leaf::hash_leaf(&leaf, &ca_spki).expect("hash_leaf must not fail");
    assert_eq!(
        summary.signed_tree_head.tree_head.root_hash, expected_leaf_hash,
        "single-leaf tree root must equal the leaf hash"
    );

    // AC-1.5-41 P4 closure: verify_mtac must return Ok(()) for a real CA round-trip.
    let ca_pubkey_ref: &[u8; 1952] = ca.ca_public_key();
    verify_mtac(&leaf, &result, ca_pubkey_ref)
        .expect("verify_mtac must return Ok(()) for a valid single-leaf CA round-trip");
}

/// AC-1.5-42: `BatchSummary.finalized_at == signed_tree_head.tree_head.timestamp`.
#[test]
fn finalized_at_equals_sth_timestamp() {
    let ca = make_ca();
    ca.register_agent(&make_leaf("agent-ts")).unwrap();
    let summary = ca.commit_batch().unwrap();

    assert_eq!(
        summary.finalized_at, summary.signed_tree_head.tree_head.timestamp,
        "BatchSummary.finalized_at must equal STH timestamp (AC-1.5-42)"
    );
}
