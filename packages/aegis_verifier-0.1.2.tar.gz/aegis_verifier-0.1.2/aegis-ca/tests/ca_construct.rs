//! AC-1.5-10, AC-1.5-40 — `CertificateAuthority` construction tests.

use aegis_ca::CertificateAuthority;
use aegis_core::signing::{ensure_oqs_init, MlDsaSigner};

/// AC-1.5-10: `CertificateAuthority::new` constructs successfully and
/// exposes a 1952-byte public key.
#[test]
fn new_constructs_successfully_and_exposes_1952_byte_pubkey() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca = CertificateAuthority::new(signer);
    assert_eq!(
        ca.ca_public_key().len(),
        1952,
        "ca_public_key() must return exactly 1952 bytes (ML-DSA-65 FIPS 204 Table 2)"
    );
}

/// AC-1.5-40: `ca.ca_public_key()` matches the signer's public key byte-for-byte.
///
/// The signer's public key is snapshotted BEFORE the move into `CertificateAuthority::new`
/// because `MlDsaSigner` does not implement `Clone`.
#[test]
fn cached_pubkey_matches_signer() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    // Snapshot the public key BEFORE the move.
    let expected_pk: Vec<u8> = signer.public_key().to_vec();
    let ca = CertificateAuthority::new(signer);
    assert_eq!(
        ca.ca_public_key().as_slice(),
        expected_pk.as_slice(),
        "cached ca_public_key must be byte-for-byte equal to the signer's public key"
    );
}
