//! AC-1.5-11, AC-1.5-12, AC-1.5-13 — `CertificateAuthority::register_agent` tests.

use aegis_ca::{CaConfig, CaError, CertificateAuthority};
use aegis_core::{
    leaf::MtacLeaf,
    signing::{ensure_oqs_init, MlDsaSigner},
};

/// Build a deterministic test leaf with a unique `agent_id`.
fn make_leaf(agent_id: &str) -> MtacLeaf {
    MtacLeaf::new(
        agent_id.to_string(),
        "sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// Build a CA with default config, ready for testing.
fn make_ca() -> CertificateAuthority {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    CertificateAuthority::new(signer)
}

/// AC-1.5-11: sequential `register_agent` calls return `leaf_index` 0, 1, 2 in order.
#[test]
fn sequential_register_returns_increasing_leaf_indices() {
    let ca = make_ca();

    let r0 = ca.register_agent(&make_leaf("agent-0")).unwrap();
    let r1 = ca.register_agent(&make_leaf("agent-1")).unwrap();
    let r2 = ca.register_agent(&make_leaf("agent-2")).unwrap();

    assert_eq!(r0.leaf_index, 0, "first register must return leaf_index 0");
    assert_eq!(r1.leaf_index, 1, "second register must return leaf_index 1");
    assert_eq!(r2.leaf_index, 2, "third register must return leaf_index 2");

    // All three receipts must share the same batch_id (same open batch).
    assert_eq!(
        r0.batch_id, r1.batch_id,
        "all registers in the same batch must share the same batch_id"
    );
    assert_eq!(r1.batch_id, r2.batch_id);
}

/// AC-1.5-12: first `register_agent` on an empty buffer sets `opened_at` to a
/// real wall-clock millisecond timestamp (observable via `max_finalize_at`).
///
/// If `opened_at` were left at 0, then `max_finalize_at = 0 + max_batch_age_ms`
/// which is a tiny number (1000 ms past epoch, year 1970). The wall-clock value
/// in 2026 is ~1.7 × 10^12 ms, so `max_finalize_at` must far exceed the
/// config's `max_batch_age_ms`.
#[test]
fn first_register_sets_opened_at_to_current_ms() {
    let ca = make_ca();
    let receipt = ca.register_agent(&make_leaf("agent-opened-at")).unwrap();

    // Year-2001 sanity floor: 2001-01-01 00:00:00 UTC ≈ 978_307_200 seconds = 978_307_200_000 ms
    assert!(
        receipt.max_finalize_at > 1_000_000_000_000u64,
        "max_finalize_at = {} implies opened_at was 0, not current_ms()",
        receipt.max_finalize_at
    );
}

/// AC-1.5-13: the (`max_batch_size` + 1)th call returns `BufferFull { max: max_batch_size }`.
///
/// Uses a small config (`max_batch_size` = 4) to avoid wall-clock budget issues —
/// 1024 leaves × `hash_leaf` in debug mode may exceed the 5s integration-test budget.
/// The semantic is identical to the spec's "1025th call returns `BufferFull { max: 1024 }`".
#[test]
fn buffer_full_returns_error_at_max_plus_one() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let config = CaConfig {
        max_batch_size: 4,
        max_batch_age_ms: 1000,
    };
    let ca = CertificateAuthority::with_config(signer, config);

    // Fill to capacity (4 leaves — each succeeds).
    for i in 0..4 {
        ca.register_agent(&make_leaf(&format!("agent-fill-{i}")))
            .unwrap();
    }

    // 5th call must return BufferFull { max: 4 }.
    let err = ca.register_agent(&make_leaf("agent-overflow")).unwrap_err();
    assert!(
        matches!(err, CaError::BufferFull { max: 4 }),
        "expected CaError::BufferFull {{ max: 4 }}, got: {err:?}"
    );
}
