//! AC-1.5-31 — Concurrent `register_agent` + periodic `commit_batch` stress test.
//!
//! Structure (per HC-P5-1 rev-2 Amendment A2):
//! - 16 register threads × 50 `register_agent` calls = 800 total registrations.
//!   (Kept below the 1024 max-batch-size to avoid `BufferFull` confounder.)
//! - 1 periodic committer thread calls `commit_batch()` at ≥ 2ms intervals DURING
//!   registration, using an `Arc<AtomicBool>` signal to exit.
//! - After all 16 register threads join, the signal is set and the committer is joined.
//! - Main thread calls `commit_batch()` ONE FINAL TIME as the terminal drain (retry
//!   loop: up to 100 iterations, 1ms sleep on `TimestampNotMonotonic`, exit on
//!   `EmptyBatch` or `Ok`).
//!
//! Invariant: `sum(summary.leaves_count for summary in all_successful_commits) == 800`.
//!
//! Benign errors (swallowed in both periodic committer AND terminal drain):
//! - `CaError::EmptyBatch` — pending was drained by a sibling commit
//! - `CaError::TimestampNotMonotonic` — retry after short sleep
//!
//! Any other `CaError` variant panics immediately (indicates an actual bug).

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use aegis_ca::{CaError, CertificateAuthority};
use aegis_core::{
    leaf::MtacLeaf,
    signing::{ensure_oqs_init, MlDsaSigner},
};
use parking_lot::Mutex;

/// Build a deterministic leaf for a given thread and call index.
/// Deterministic construction ensures `hash_leaf` never fails due to randomness.
fn make_deterministic_leaf(thread_id: usize, call_idx: usize) -> MtacLeaf {
    MtacLeaf::new(
        format!("urn:aegis:agent:conc-t{thread_id}-c{call_idx}"),
        "concurrent-sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// AC-1.5-31: 16 × 50 concurrent registrations + periodic commit.
/// Invariant: total leaves across all committed batches == 800.
#[test]
fn concurrent_register_800_leaves_invariant() {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca = Arc::new(CertificateAuthority::new(signer));

    // Aggregate committed leaves_count across ALL successful commits.
    let committed_counts: Arc<Mutex<Vec<u64>>> = Arc::new(Mutex::new(Vec::new()));

    // Signal: set to true when all register threads have finished.
    let done_registering = Arc::new(AtomicBool::new(false));

    // ─── Periodic committer thread ───────────────────────────────────────────
    let ca_committer = Arc::clone(&ca);
    let counts_committer = Arc::clone(&committed_counts);
    let done_flag = Arc::clone(&done_registering);

    let committer_handle = std::thread::spawn(move || {
        loop {
            // Check exit condition FIRST (SeqCst for visibility with store in main thread).
            if done_flag.load(Ordering::SeqCst) {
                break;
            }

            // Sleep at least 2ms between commits (guards against TimestampNotMonotonic
            // flake when clock granularity is 1ms).
            std::thread::sleep(std::time::Duration::from_millis(2));

            match ca_committer.commit_batch() {
                Ok(summary) => {
                    // Acquire the aggregate lock ONLY while pushing — not during commit_batch.
                    counts_committer.lock().push(summary.leaves_count);
                }
                // Benign: empty or timestamp collision — continue the loop.
                Err(CaError::EmptyBatch | CaError::TimestampNotMonotonic { .. }) => {}
                Err(other) => {
                    panic!("periodic committer: unexpected CaError: {other:?}");
                }
            }
        }
    });

    // ─── 16 register threads ─────────────────────────────────────────────────
    let register_handles: Vec<_> = (0..16)
        .map(|thread_id| {
            let ca_reg = Arc::clone(&ca);
            std::thread::spawn(move || {
                for call_idx in 0..50 {
                    let leaf = make_deterministic_leaf(thread_id, call_idx);
                    ca_reg
                        .register_agent(&leaf)
                        .expect("register_agent must not fail in concurrent test");
                }
            })
        })
        .collect();

    // Wait for all register threads to finish.
    for h in register_handles {
        h.join().expect("register thread must not panic");
    }

    // Signal the periodic committer to exit.
    done_registering.store(true, Ordering::SeqCst);

    // Join the committer.
    committer_handle
        .join()
        .expect("periodic committer thread must not panic");

    // ─── Terminal drain ───────────────────────────────────────────────────────
    // Call commit_batch() ONE FINAL TIME to drain any remaining pending leaves.
    // Retry up to 100 times on TimestampNotMonotonic; exit on EmptyBatch or Ok.
    for attempt in 0..100u32 {
        match ca.commit_batch() {
            Ok(summary) => {
                committed_counts.lock().push(summary.leaves_count);
                break;
            }
            Err(CaError::EmptyBatch) => {
                // All leaves already committed by the periodic committer.
                break;
            }
            Err(CaError::TimestampNotMonotonic { .. }) => {
                // Clock didn't advance; sleep 1ms and retry.
                if attempt < 99 {
                    std::thread::sleep(std::time::Duration::from_millis(1));
                }
            }
            Err(other) => {
                panic!("terminal drain: unexpected CaError: {other:?}");
            }
        }
    }

    // ─── Invariant check ─────────────────────────────────────────────────────
    let counts = committed_counts.lock();
    let total: u64 = counts.iter().sum();
    assert_eq!(
        total,
        800,
        "sum of all committed leaves_count must equal 800 (16 threads × 50 calls). \
         Got {total} across {} commits: {counts:?}",
        counts.len()
    );
}
