//! AC-1.5-19, AC-1.5-20 (A+B), AC-1.5-21 — `CertificateAuthority::issuance_result` tests.

use aegis_ca::{CaError, CertificateAuthority};
use aegis_core::{
    leaf::MtacLeaf,
    signing::{ensure_oqs_init, MlDsaSigner},
};
use uuid::Uuid;

/// Build a deterministic test leaf.
fn make_leaf(agent_id: &str) -> MtacLeaf {
    MtacLeaf::new(
        agent_id.to_string(),
        "sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// Build a CA, ready for testing.
fn make_ca() -> CertificateAuthority {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    CertificateAuthority::new(signer)
}

/// AC-1.5-19: `issuance_result(valid_batch_id, valid_leaf_index)` returns a
/// correctly populated `MTACIssuanceResult` with all 4 fields.
#[test]
fn issuance_result_returns_correctly_populated_result() {
    let ca = make_ca();
    let leaf = make_leaf("agent-lookup-0");
    let receipt = ca.register_agent(&leaf).unwrap();
    let summary = ca.commit_batch().unwrap();

    let result = ca
        .issuance_result(receipt.batch_id, receipt.leaf_index)
        .unwrap();

    // All 4 fields must be populated correctly.
    assert_eq!(
        result.batch_id, receipt.batch_id,
        "result.batch_id must match the receipt.batch_id"
    );
    assert_eq!(
        result.leaf_index, receipt.leaf_index,
        "result.leaf_index must match the receipt.leaf_index"
    );
    assert_eq!(
        result.signed_tree_head, summary.signed_tree_head,
        "result.signed_tree_head must match the committed STH"
    );
    // For a single-leaf tree, inclusion_path is empty but still a valid proof.
    // The structural validity is also tested in ca_commit::single_leaf_batch_...
    // Here we confirm the proof is present and refers to the correct leaf.
    assert_eq!(
        result.inclusion_proof.leaf_index, receipt.leaf_index,
        "inclusion_proof.leaf_index must equal the requested leaf_index"
    );
    assert_eq!(
        result.inclusion_proof.tree_size, summary.signed_tree_head.tree_head.tree_size,
        "inclusion_proof.tree_size must match the committed tree_size"
    );
}

/// AC-1.5-20 Sub-case A: `issuance_result(unknown_batch_id, _)` returns `BatchNotFound`.
#[test]
fn issuance_result_unknown_batch_id_returns_batch_not_found() {
    let ca = make_ca();
    // Do not register anything — use a completely random UUID v7.
    let random = Uuid::now_v7();
    let err = ca.issuance_result(random, 0).unwrap_err();
    assert!(
        matches!(err, CaError::BatchNotFound { batch_id } if batch_id == random),
        "expected CaError::BatchNotFound {{ batch_id: {random} }}, got: {err:?}"
    );
}

/// AC-1.5-20 Sub-case B: `issuance_result(pending_batch_id, _)` returns `BatchNotFound`.
///
/// Per §11 footgun #26, a pending-but-not-committed batch collapses to `BatchNotFound`
/// (no separate `PendingNotFinalized` variant in Slice 1.5). This tests that
/// `issuance_log` only contains committed batches and the pending `batch_id` is not in it.
#[test]
fn issuance_result_pending_batch_id_returns_batch_not_found() {
    let ca = make_ca();
    // Register a leaf to get the pending batch_id — but do NOT commit.
    let receipt = ca.register_agent(&make_leaf("agent-pending")).unwrap();
    // The batch is still in the pending buffer, not in issuance_log.
    let err = ca.issuance_result(receipt.batch_id, 0).unwrap_err();
    assert!(
        matches!(err, CaError::BatchNotFound { batch_id } if batch_id == receipt.batch_id),
        "expected CaError::BatchNotFound for pending (uncommitted) batch_id, got: {err:?}"
    );
}

/// AC-1.5-21: `issuance_result(valid_batch_id, leaves_count)` returns `LeafIndexOutOfRange`.
///
/// `leaf_index == leaves_count` is the first out-of-range index (0-based).
#[test]
fn issuance_result_out_of_range_leaf_index_returns_error() {
    let ca = make_ca();

    // Register 3 leaves.
    for i in 0..3u64 {
        ca.register_agent(&make_leaf(&format!("agent-{i}")))
            .unwrap();
    }
    let summary = ca.commit_batch().unwrap();

    // leaf_index = 3 == leaves_count → first out-of-range.
    let err = ca.issuance_result(summary.batch_id, 3).unwrap_err();
    assert!(
        matches!(
            err,
            CaError::LeafIndexOutOfRange {
                requested: 3,
                leaves_count: 3,
            }
        ),
        "expected CaError::LeafIndexOutOfRange {{ requested: 3, leaves_count: 3 }}, got: {err:?}"
    );
}
