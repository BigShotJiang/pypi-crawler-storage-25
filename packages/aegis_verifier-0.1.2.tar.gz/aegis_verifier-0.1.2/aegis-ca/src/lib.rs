//! aegis-ca: `MTAC` Certificate Authority.
//!
//! Implementation begins Sub-Slice 1.2 (leaf schema) onwards.
//! Sub-Slice 1.1 contains only the oqs ML-DSA-65 API smoke tests.
//! Sub-Slice 1.5 introduces the in-memory CA pipeline.

pub mod ca;

pub use ca::{BatchSummary, CaConfig, CaError, CertificateAuthority, PendingReceipt};

#[cfg(test)]
mod tests {
    use oqs::sig::{Algorithm, Sig};

    #[test]
    fn ml_dsa65_keygen_sign_verify_roundtrip() {
        let sig = Sig::new(Algorithm::MlDsa65).expect("ML-DSA-65 init failed");
        let (pk, sk) = sig.keypair().expect("keygen failed");
        let message = b"aegis-alpha-smoke-test";
        let signature = sig.sign(message, &sk).expect("sign failed");
        assert!(
            sig.verify(message, &signature, &pk).is_ok(),
            "verify failed",
        );
    }

    #[test]
    fn ml_dsa65_tampered_message_rejected() {
        let sig = Sig::new(Algorithm::MlDsa65).expect("ML-DSA-65 init failed");
        let (pk, sk) = sig.keypair().expect("keygen failed");
        let message = b"aegis-alpha-smoke-test";
        let signature = sig.sign(message, &sk).expect("sign failed");
        let tampered = b"aegis-alpha-smoke-TAMPERED";
        assert!(
            sig.verify(tampered, &signature, &pk).is_err(),
            "tampered message must be rejected — signature verification should fail",
        );
    }
}
