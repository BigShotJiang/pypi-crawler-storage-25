//! In-memory `CertificateAuthority` pipeline — Sub-Slice 1.5.
//!
//! # Architecture
//!
//! `CertificateAuthority` wires together the Slice 1.2/1.3/1.4 primitives into a
//! four-method API:
//!
//! - [`CertificateAuthority::register_agent`] — hashes the leaf and appends to the
//!   pending batch; returns a [`PendingReceipt`].
//! - [`CertificateAuthority::commit_batch`] — builds the Merkle tree, signs the STH,
//!   stores the [`BatchRecord`], resets pending state; returns a [`BatchSummary`].
//! - [`CertificateAuthority::issuance_result`] — looks up a finalized batch and
//!   reconstructs [`aegis_core::issuance::MTACIssuanceResult`].
//! - [`CertificateAuthority::ca_public_key`] — returns the cached CA public key.
//!
//! # In-memory only
//!
//! HC #26: No persistence backend in Slice 1.5. Slice 2.x adds
//! `BatchRecordStore` + `MonotonicityStore` traits (source-breaking constructor change).
//!
//! # Footgun #30
//!
//! `MtacLeaf` has no serde derives (schema-v1 D-3 locked dcbor-only). Leaf bytes
//! are never stored after `hash_leaf` at `register_agent` time. `BatchRecord` stores
//! only `Vec<InclusionProof>`, not leaves.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

use serde::{Deserialize, Serialize};
use uuid::Uuid;

use aegis_core::error::{LeafError, MerkleError};
use aegis_core::issuance::MTACIssuanceResult;
use aegis_core::leaf::{hash_leaf, MtacLeaf};
use aegis_core::merkle::{InclusionProof, MerkleTree};
use aegis_core::signing::{compute_log_id, MlDsaSigner, SigError, SignedTreeHead, TreeHeadDataV2};

// ─── Private helper ───────────────────────────────────────────────────────────

/// Return the current wall-clock time as milliseconds since the Unix epoch.
///
/// # Panics
///
/// Panics if the system clock is set before the Unix epoch (year < 1970) or if
/// the duration-since-epoch overflows `u64` (year > 2554). Neither condition
/// can occur in Aegis Alpha's operational lifetime.
fn current_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("system clock before UNIX epoch")
        .as_millis()
        .try_into()
        .expect("duration-since-epoch overflows u64 in year 2554+")
}

// ─── CaConfig ────────────────────────────────────────────────────────────────

/// Configuration for [`CertificateAuthority`] batching behavior.
///
/// All fields have sensible defaults per Aegis Alpha GA spec:
/// - `max_batch_size`: 1024 leaves per batch.
/// - `max_batch_age_ms`: 1000 ms maximum batch age before the caller must commit.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CaConfig {
    /// Maximum number of leaves in a pending batch before `register_agent` returns
    /// [`CaError::BufferFull`].
    pub max_batch_size: usize,
    /// Maximum pending batch age in milliseconds. Used by [`PendingReceipt::max_finalize_at`]
    /// as the Slice-3 Gateway MMD contract surface.
    pub max_batch_age_ms: u64,
}

impl Default for CaConfig {
    fn default() -> Self {
        Self {
            max_batch_size: 1024,
            max_batch_age_ms: 1000,
        }
    }
}

// ─── PendingReceipt ──────────────────────────────────────────────────────────

/// Acknowledgement returned by [`CertificateAuthority::register_agent`].
///
/// `PendingReceipt` is **unsigned** — Aegis is RFC-9162-INSPIRED, not conformant.
/// Cost amortization via batch-only ML-DSA-65 signing; no per-leaf SCT.
///
/// The `max_finalize_at` field is the Slice-3 Gateway MMD contract surface:
/// `opened_at + config.max_batch_age_ms`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PendingReceipt {
    /// UUID v7 of the batch this leaf was registered into.
    pub batch_id: Uuid,
    /// 0-based index of this leaf within the batch.
    pub leaf_index: u64,
    /// Latest wall-clock ms by which the batch must be committed (`opened_at + max_batch_age_ms`).
    ///
    /// Slice-3 Gateway uses this as the Maximum Merge Delay contract surface.
    pub max_finalize_at: u64,
}

// ─── BatchSummary ────────────────────────────────────────────────────────────

/// Summary returned by [`CertificateAuthority::commit_batch`].
///
/// `finalized_at == signed_tree_head.tree_head.timestamp` per AC-1.5-42.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BatchSummary {
    /// UUID v7 of the committed batch.
    pub batch_id: Uuid,
    /// Number of leaves in this batch (== `signed_tree_head.tree_head.tree_size`).
    pub leaves_count: u64,
    /// Wall-clock ms at which the batch was committed (== `signed_tree_head.tree_head.timestamp`).
    pub finalized_at: u64,
    /// The ML-DSA-65 signed tree head for this batch.
    pub signed_tree_head: SignedTreeHead,
}

// ─── BatchRecord ─────────────────────────────────────────────────────────────

/// Per-batch record stored in [`CertificateAuthority::issuance_log`].
///
/// `pub(crate)` — not part of the public API. Callers retrieve individual results
/// via [`CertificateAuthority::issuance_result`].
///
/// Stores per-leaf inclusion proofs and the batch's STH so that
/// `issuance_result(batch_id, leaf_index)` can reconstruct a full
/// [`MTACIssuanceResult`] without re-signing.
///
/// Per footgun #30: does NOT store `Vec<MtacLeaf>` — only pre-computed proofs.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct BatchRecord {
    pub(crate) batch_id: Uuid,
    pub(crate) leaves_count: u64,
    pub(crate) signed_tree_head: SignedTreeHead,
    pub(crate) inclusion_proofs: Vec<InclusionProof>,
}

// ─── PendingBatch ────────────────────────────────────────────────────────────

/// Open accumulation buffer for the current in-flight batch.
///
/// Private — only `CertificateAuthority` creates and mutates this.
///
/// Per footgun #30: stores `Vec<[u8; 32]>` (pre-hashed leaf outputs from
/// `hash_leaf`) rather than `Vec<MtacLeaf>`, keeping the no-serde gap
/// structurally unreachable from any public API.
struct PendingBatch {
    /// UUID v7 for the current open batch.
    batch_id: Uuid,
    /// Pre-hashed leaf outputs from `aegis_core::leaf::hash_leaf`.
    leaf_hashes: Vec<[u8; 32]>,
    /// Wall-clock ms at which the first `register_agent` in this batch was called.
    /// `0` means the batch is empty (no leaf registered yet).
    opened_at: u64,
}

// ─── CaError ─────────────────────────────────────────────────────────────────

/// Errors returned by [`CertificateAuthority`] pipeline methods.
#[derive(Debug, thiserror::Error)]
pub enum CaError {
    /// `commit_batch()` was called on an empty pending buffer.
    #[error("pending batch is empty")]
    EmptyBatch,

    /// `register_agent()` was called when the pending buffer is already full.
    ///
    /// The caller must `commit_batch()` first to drain the buffer.
    #[error("pending buffer is full: {max} leaves")]
    BufferFull {
        /// The maximum batch size (`CaConfig::max_batch_size`).
        max: usize,
    },

    /// `commit_batch()` detected a non-monotonic timestamp.
    ///
    /// Per RFC 9162 §4.10, STH timestamps must be monotonically increasing.
    /// The current batch's timestamp (`attempted`) must be strictly greater than
    /// the previous batch's timestamp (`previous`).
    #[error("timestamp not monotonic: previous={previous}, attempted={attempted}")]
    TimestampNotMonotonic {
        /// The timestamp of the most recently committed batch.
        previous: u64,
        /// The timestamp that was attempted for the current batch.
        attempted: u64,
    },

    /// `issuance_result()` was called with a `batch_id` that is not in the
    /// finalized log — including the case where `batch_id` is the currently-open
    /// pending batch (not yet committed).
    ///
    /// Per §11 footgun #26: pending-but-not-committed batches collapse to
    /// `BatchNotFound` rather than a separate `PendingNotFinalized` variant.
    #[error("batch not found: {batch_id}")]
    BatchNotFound {
        /// The batch ID that was not found in the finalized log.
        batch_id: Uuid,
    },

    /// `issuance_result()` was called with a `leaf_index` that is out of range
    /// for the specified batch.
    #[error("leaf index {requested} out of range for batch of {leaves_count} leaves")]
    LeafIndexOutOfRange {
        /// The requested leaf index.
        requested: u64,
        /// The number of leaves in the batch.
        leaves_count: u64,
    },

    /// `register_agent()` failed because `hash_leaf` returned an error.
    #[error("leaf hashing failed: {0}")]
    LeafHashing(#[from] LeafError),

    /// `commit_batch()` failed because `MlDsaSigner::sign_tree_root` returned an error.
    #[error("signing failed: {0}")]
    Signing(#[from] SigError),

    /// `commit_batch()` failed because `MerkleTree::new` returned an error.
    #[error("merkle tree construction failed: {0}")]
    Merkle(#[from] MerkleError),
}

// ─── CertificateAuthority ─────────────────────────────────────────────────────

/// In-memory Aegis ML-DSA-65 Certificate Authority.
///
/// # Construction
///
/// ```ignore
/// let signer = MlDsaSigner::new()?;
/// let ca = CertificateAuthority::new(signer);
/// ```
///
/// `with_config` overrides the default batch sizing:
///
/// ```ignore
/// let ca = CertificateAuthority::with_config(signer, CaConfig { max_batch_size: 512, max_batch_age_ms: 500 });
/// ```
///
/// # Thread safety
///
/// `CertificateAuthority` is `Send + Sync`. All mutable state is guarded by
/// `parking_lot::Mutex` (non-poisoning) or `AtomicU64`. Wrapping in `Arc` is
/// the standard pattern for sharing across tasks.
///
/// # In-memory only (HC #26)
///
/// No persistence in Slice 1.5. Restart loses all pending and finalized state.
/// Slice 2.x adds `BatchRecordStore` + `MonotonicityStore` traits via a
/// source-breaking constructor change (see `SLICE-1.5-BRIEF.md §13`).
pub struct CertificateAuthority {
    signer: MlDsaSigner,
    /// Cached 1952-byte ML-DSA-65 public key, extracted at construction (AC-1.5-40).
    ca_pubkey: [u8; 1952],
    /// SHA-256(ca_pubkey) — precomputed `log_id` / `ca_spki` used in both
    /// `register_agent` (passed to `hash_leaf`) and `commit_batch` (written to STH).
    ///
    /// Option I: cache once at construction; zero per-register recomputation.
    /// (Option II — per-register `sha2::digest` — was rejected as wasteful and adds a dep.)
    log_id: [u8; 32],
    config: CaConfig,
    pending: parking_lot::Mutex<PendingBatch>,
    issuance_log: parking_lot::Mutex<HashMap<Uuid, BatchRecord>>,
    /// Timestamp of the most recently committed batch (ms). `AtomicU64` for
    /// lock-free reads; updated inside `pending.lock()` for wall-clock fidelity
    /// (§11 footgun #28).
    last_signed_at: AtomicU64,
}

impl CertificateAuthority {
    /// Construct a `CertificateAuthority` with default [`CaConfig`].
    #[must_use]
    pub fn new(signer: MlDsaSigner) -> Self {
        Self::with_config(signer, CaConfig::default())
    }

    /// Construct a `CertificateAuthority` with a custom [`CaConfig`].
    ///
    /// # Panics
    ///
    /// Panics if `signer.public_key()` is not exactly 1952 bytes. This cannot occur
    /// in practice because [`MlDsaSigner`] always produces ML-DSA-65 keys (FIPS 204
    /// Table 2, pk = 1952 bytes). The panic is a defense against oqs version drift.
    #[must_use]
    pub fn with_config(signer: MlDsaSigner, config: CaConfig) -> Self {
        let ca_pubkey_slice: &[u8] = signer.public_key();
        let ca_pubkey: [u8; 1952] = ca_pubkey_slice
            .try_into()
            .expect("MlDsaSigner::public_key is ML-DSA-65; length invariant is 1952 bytes");
        // Option I: compute log_id once at construction. Same SHA-256(pk) used for both
        // hash_leaf (ca_spki param) and commit_batch (sth.log_id field).
        let log_id = compute_log_id(&ca_pubkey);
        Self {
            signer,
            ca_pubkey,
            log_id,
            config,
            pending: parking_lot::Mutex::new(PendingBatch {
                batch_id: Uuid::now_v7(),
                leaf_hashes: Vec::new(),
                opened_at: 0,
            }),
            issuance_log: parking_lot::Mutex::new(HashMap::new()),
            last_signed_at: AtomicU64::new(0),
        }
    }

    /// Return the cached 1952-byte ML-DSA-65 CA public key.
    ///
    /// The public key is fixed for the lifetime of this `CertificateAuthority`
    /// instance and is extracted once at construction (AC-1.5-40).
    #[must_use]
    pub fn ca_public_key(&self) -> &[u8; 1952] {
        &self.ca_pubkey
    }

    /// Register an agent leaf into the pending batch.
    ///
    /// Hashes the leaf via `aegis_core::leaf::hash_leaf` and appends the hash to
    /// the pending buffer. Returns a [`PendingReceipt`] with the batch ID and
    /// 0-based leaf index.
    ///
    /// # Errors
    ///
    /// - [`CaError::BufferFull`] — pending buffer is already at `max_batch_size`.
    /// - [`CaError::LeafHashing`] — `hash_leaf` returned a [`LeafError`].
    pub fn register_agent(&self, leaf: &MtacLeaf) -> Result<PendingReceipt, CaError> {
        // Compute leaf hash outside the lock — hash_leaf is pure, no shared state.
        let leaf_hash = hash_leaf(leaf, &self.log_id)?;

        let mut pending = self.pending.lock();

        // HC-P3-3: buffer-full check BEFORE push.
        if pending.leaf_hashes.len() >= self.config.max_batch_size {
            return Err(CaError::BufferFull {
                max: self.config.max_batch_size,
            });
        }

        // HC-P3-4: opened_at set only on first leaf of a fresh batch.
        if pending.leaf_hashes.is_empty() {
            pending.opened_at = current_ms();
        }

        let leaf_index = pending.leaf_hashes.len() as u64;
        let batch_id = pending.batch_id;
        let max_finalize_at = pending.opened_at + self.config.max_batch_age_ms;

        pending.leaf_hashes.push(leaf_hash);

        Ok(PendingReceipt {
            batch_id,
            leaf_index,
            max_finalize_at,
        })
    }

    /// Commit the pending batch: build the Merkle tree, sign the STH, store the
    /// [`BatchRecord`], and reset pending state.
    ///
    /// # Operation order (HC-P3-1, RFC 9162 §4.10 conformance)
    ///
    /// All steps (a)–(l) execute inside `pending.lock()` except step (j) which
    /// acquires `issuance_log` in a separate lock call after the sign step.
    ///
    /// # Panics
    ///
    /// Panics if `MerkleTree::proof(i)` fails for an in-range index `i`. This is
    /// a Merkle-tree invariant violation (`i < tree_size` guarantees the proof succeeds)
    /// and indicates a bug in the Slice-1.3 Merkle surface if triggered.
    ///
    /// # Errors
    ///
    /// - [`CaError::EmptyBatch`] — pending buffer is empty.
    /// - [`CaError::TimestampNotMonotonic`] — `current_ms() <= last_signed_at`.
    /// - [`CaError::Merkle`] — Merkle tree construction failed.
    /// - [`CaError::Signing`] — ML-DSA-65 signing failed.
    pub fn commit_batch(&self) -> Result<BatchSummary, CaError> {
        // (a) Acquire pending lock — parking_lot, no poisoning.
        let mut pending = self.pending.lock();

        // (b) EmptyBatch guard.
        if pending.leaf_hashes.is_empty() {
            return Err(CaError::EmptyBatch);
        }

        // (c) Read now_ms INSIDE lock.
        let now_ms = current_ms();

        // (d) Read prev INSIDE lock.
        let prev = self.last_signed_at.load(Ordering::SeqCst);

        // (e) Monotonicity check: now_ms must be strictly greater than prev.
        if now_ms <= prev {
            return Err(CaError::TimestampNotMonotonic {
                previous: prev,
                attempted: now_ms,
            });
        }

        // (f) Build Merkle tree from pending.leaf_hashes.
        let tree = MerkleTree::new(&pending.leaf_hashes)?;
        let tree_size = tree.tree_size();
        let root_hash = tree.root();

        // (g) Construct TreeHeadDataV2.
        let tree_head = TreeHeadDataV2 {
            timestamp: now_ms,
            tree_size,
            root_hash,
            sth_extensions: vec![],
        };

        // (h) Sign via self.signer.sign_tree_root.
        let signature_bytes = self.signer.sign_tree_root(&tree_head)?;

        let sth = SignedTreeHead {
            log_id: self.log_id,
            tree_head,
            signature_bytes,
        };

        // (i) Store timestamp INSIDE lock, AFTER signing.
        self.last_signed_at.store(now_ms, Ordering::SeqCst);

        // Snapshot the old batch_id BEFORE rotating (HC-P3-2).
        let old_batch_id = pending.batch_id;
        let leaves_count = tree_size;

        // Collect inclusion proofs for every leaf.
        let inclusion_proofs: Vec<InclusionProof> = (0..leaves_count)
            .map(|i| {
                tree.proof(i)
                    .expect("Merkle tree invariant: i < tree_size; proof must succeed")
            })
            .collect();

        // (j) Construct BatchSummary + BatchRecord with OLD batch_id; insert into
        //     issuance_log (separate lock acquisition is OK — pending lock held).
        let record = BatchRecord {
            batch_id: old_batch_id,
            leaves_count,
            signed_tree_head: sth.clone(),
            inclusion_proofs,
        };

        {
            let mut log = self.issuance_log.lock();
            log.insert(old_batch_id, record);
        }

        // (k) Rotate: new UUID v7, clear leaf_hashes, reset opened_at.
        pending.batch_id = Uuid::now_v7();
        pending.leaf_hashes.clear();
        pending.opened_at = 0;

        // (l) pending lock released here (end of scope).

        Ok(BatchSummary {
            batch_id: old_batch_id,
            leaves_count,
            finalized_at: now_ms,
            signed_tree_head: sth,
        })
    }

    /// Reconstruct a full [`MTACIssuanceResult`] from a finalized batch.
    ///
    /// # Errors
    ///
    /// - [`CaError::BatchNotFound`] — `batch_id` is not in the finalized log (including
    ///   the case where it is the currently-open pending batch, per §11 footgun #26).
    /// - [`CaError::LeafIndexOutOfRange`] — `leaf_index >= batch.leaves_count`.
    pub fn issuance_result(
        &self,
        batch_id: Uuid,
        leaf_index: u64,
    ) -> Result<MTACIssuanceResult, CaError> {
        let log = self.issuance_log.lock();
        let record = log
            .get(&batch_id)
            .ok_or(CaError::BatchNotFound { batch_id })?;

        // usize::try_from: on 64-bit targets this is lossless; on 32-bit targets a leaf_index
        // exceeding usize::MAX would also exceed any Vec length, so the .get() would return None
        // anyway — but using try_from avoids clippy::cast_possible_truncation.
        let proof_idx = usize::try_from(leaf_index).unwrap_or(usize::MAX);
        let proof = record
            .inclusion_proofs
            .get(proof_idx)
            .ok_or(CaError::LeafIndexOutOfRange {
                requested: leaf_index,
                leaves_count: record.leaves_count,
            })?;

        Ok(MTACIssuanceResult {
            batch_id,
            leaf_index,
            inclusion_proof: proof.clone(),
            signed_tree_head: record.signed_tree_head.clone(),
        })
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;
    use std::sync::atomic::Ordering;

    use aegis_core::signing::ensure_oqs_init;

    /// Build a deterministic test leaf.
    fn make_leaf(agent_id: &str) -> MtacLeaf {
        MtacLeaf::new(
            agent_id.to_string(),
            "sponsor@acme.example".to_string(),
            vec!["scope:read".to_string()],
            1_713_600_000,
            1_745_136_000,
        )
    }

    /// Build a [`BatchRecord`] fixture for serde tests.
    fn fixture_batch_record() -> BatchRecord {
        use aegis_core::signing::TreeHeadDataV2;

        let batch_id = Uuid::parse_str("018d6b9a-2c3d-7000-8000-000000000002").unwrap();

        let sth = SignedTreeHead {
            log_id: [0xAA; 32],
            tree_head: TreeHeadDataV2 {
                timestamp: 99999,
                tree_size: 2,
                root_hash: [0xCC; 32],
                sth_extensions: vec![],
            },
            signature_bytes: vec![0u8; 3309],
        };

        let proofs = vec![
            InclusionProof {
                tree_size: 2,
                leaf_index: 0,
                inclusion_path: vec![[0xBB; 32]],
            },
            InclusionProof {
                tree_size: 2,
                leaf_index: 1,
                inclusion_path: vec![[0xAA; 32]],
            },
        ];

        BatchRecord {
            batch_id,
            leaves_count: 2,
            signed_tree_head: sth,
            inclusion_proofs: proofs,
        }
    }

    /// AC-1.5-09 (unit portion): `BatchRecord` survives a JSON round-trip.
    ///
    /// `BatchRecord` is `pub(crate)` and cannot be reached from integration tests;
    /// the round-trip test lives here per `.claude/rules/testing.md`.
    #[test]
    fn batch_record_json_roundtrip() {
        let original = fixture_batch_record();
        let json = serde_json::to_string(&original).expect("serialize BatchRecord to JSON");
        let restored: BatchRecord =
            serde_json::from_str(&json).expect("deserialize BatchRecord from JSON");
        assert_eq!(
            original, restored,
            "BatchRecord must survive a JSON round-trip unchanged"
        );
    }

    /// AC-1.5-16: after `commit_batch()`, `last_signed_at` equals the STH timestamp.
    ///
    /// Placed here (unit test) because `last_signed_at` is a private field, only
    /// accessible from within this module.
    #[test]
    fn commit_batch_updates_last_signed_at_to_sth_timestamp() {
        ensure_oqs_init();
        let signer = MlDsaSigner::new().unwrap();
        let ca = CertificateAuthority::new(signer);

        ca.register_agent(&make_leaf("agent-ts-check")).unwrap();
        let summary = ca.commit_batch().unwrap();

        let stored = ca.last_signed_at.load(Ordering::SeqCst);
        assert_eq!(
            stored, summary.signed_tree_head.tree_head.timestamp,
            "last_signed_at must equal the committed STH timestamp after commit_batch"
        );
    }

    /// AC-1.5-18: force `last_signed_at` to `u64::MAX`; second commit returns
    /// `TimestampNotMonotonic`.
    ///
    /// Placed here (unit test) because `last_signed_at` is private. This test
    /// directly manipulates the `AtomicU64` to simulate a prior commit whose
    /// timestamp is impossible to exceed.
    ///
    /// Note: AC-1.5-18 placement adjusted to unit test inside `ca.rs` per
    /// privacy constraint on `last_signed_at` field — no change to binary
    /// pass condition.
    #[test]
    fn commit_batch_detects_non_monotonic_timestamp() {
        ensure_oqs_init();
        let signer = MlDsaSigner::new().unwrap();
        let ca = CertificateAuthority::new(signer);

        // Force last_signed_at to the maximum possible value — no future clock
        // reading can exceed this.
        ca.last_signed_at.store(u64::MAX, Ordering::SeqCst);

        // Register a leaf so the batch is non-empty.
        ca.register_agent(&make_leaf("agent-monotonic")).unwrap();

        // commit_batch must detect now_ms <= u64::MAX and return the error.
        let err = ca.commit_batch().unwrap_err();
        assert!(
            matches!(
                err,
                CaError::TimestampNotMonotonic {
                    previous: u64::MAX,
                    ..
                }
            ),
            "expected TimestampNotMonotonic {{ previous: u64::MAX, .. }}, got: {err:?}"
        );
    }
}
