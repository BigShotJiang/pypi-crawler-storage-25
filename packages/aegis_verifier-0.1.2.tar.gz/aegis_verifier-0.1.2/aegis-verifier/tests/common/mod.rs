//! Shared test fixtures for aegis-verifier integration tests.
//!
//! Builds `MTACIssuanceResult` without using `CertificateAuthority` to
//! avoid the dev-dep cycle described in SLICE-1.5-BRIEF.md §14.2 + Phase 4
//! implementation notes. All primitives come from `aegis-core` directly.

// Each test binary that includes this module compiles it independently.
// Not every function is called by every binary — suppress the resulting
// dead_code lints that are harmless for shared test helpers.
#![allow(dead_code)]

use aegis_core::issuance::MTACIssuanceResult;
use aegis_core::leaf::{hash_leaf, MtacLeaf};
use aegis_core::merkle::MerkleTree;
use aegis_core::signing::{
    compute_log_id, ensure_oqs_init, MlDsaSigner, SignedTreeHead, TreeHeadDataV2,
};

/// Build a deterministic test leaf.
pub fn make_leaf(agent_id: &str) -> MtacLeaf {
    MtacLeaf::new(
        agent_id.to_string(),
        "sponsor@acme.example".to_string(),
        vec!["scope:read".to_string()],
        1_713_600_000,
        1_745_136_000,
    )
}

/// Builds a full single-leaf round-trip `MTACIssuanceResult` without using
/// `CertificateAuthority`.
///
/// Returns `(leaf, result, ca_public_key)`.
///
/// The `batch_id` is a nil UUID — the value is not part of any cryptographic
/// commitment verified by `verify_mtac`.
pub fn build_round_trip_fixture() -> (MtacLeaf, MTACIssuanceResult, [u8; 1952]) {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca_public_key: [u8; 1952] = signer.public_key().try_into().unwrap();
    let log_id = compute_log_id(&ca_public_key);

    let leaf = make_leaf("urn:aegis:agent:fixture-001");
    let leaf_hash = hash_leaf(&leaf, &log_id).unwrap();

    let tree = MerkleTree::new(&[leaf_hash]).unwrap();
    let root_hash = tree.root();
    let proof = tree.proof(0).unwrap();

    let tree_head = TreeHeadDataV2 {
        timestamp: 1_713_600_000,
        tree_size: 1,
        root_hash,
        sth_extensions: vec![],
    };
    let signature_bytes = signer.sign_tree_root(&tree_head).unwrap();
    let sth = SignedTreeHead {
        log_id,
        tree_head,
        signature_bytes,
    };

    let result = MTACIssuanceResult {
        // batch_id: nil UUID — not part of any cryptographic commitment
        #[allow(clippy::default_trait_access)]
        batch_id: Default::default(),
        leaf_index: 0,
        inclusion_proof: proof,
        signed_tree_head: sth,
    };

    (leaf, result, ca_public_key)
}

/// Builds a multi-leaf round-trip fixture so that `inclusion_proof.inclusion_path`
/// is non-empty (required for AC-1.5-26: tampered audit-path test).
///
/// Uses 2 leaves so the tree is minimal but non-trivial.
///
/// Returns `(leaf_0, result_0, ca_public_key)` — the result for leaf 0, whose
/// inclusion proof contains one sibling hash (the hash of leaf 1).
pub fn build_round_trip_fixture_multi_leaf() -> (MtacLeaf, MTACIssuanceResult, [u8; 1952]) {
    ensure_oqs_init();
    let signer = MlDsaSigner::new().unwrap();
    let ca_public_key: [u8; 1952] = signer.public_key().try_into().unwrap();
    let log_id = compute_log_id(&ca_public_key);

    let leaf0 = make_leaf("urn:aegis:agent:multi-000");
    let leaf1 = make_leaf("urn:aegis:agent:multi-001");

    let hash0 = hash_leaf(&leaf0, &log_id).unwrap();
    let hash1 = hash_leaf(&leaf1, &log_id).unwrap();

    let tree = MerkleTree::new(&[hash0, hash1]).unwrap();
    let root_hash = tree.root();
    let proof0 = tree.proof(0).unwrap();

    // Sanity: inclusion_path must be non-empty for 2-leaf tree.
    assert!(
        !proof0.inclusion_path.is_empty(),
        "2-leaf tree must produce non-empty inclusion_path"
    );

    let tree_head = TreeHeadDataV2 {
        timestamp: 1_713_600_001,
        tree_size: 2,
        root_hash,
        sth_extensions: vec![],
    };
    let signature_bytes = signer.sign_tree_root(&tree_head).unwrap();
    let sth = SignedTreeHead {
        log_id,
        tree_head,
        signature_bytes,
    };

    let result = MTACIssuanceResult {
        #[allow(clippy::default_trait_access)]
        batch_id: Default::default(),
        leaf_index: 0,
        inclusion_proof: proof0,
        signed_tree_head: sth,
    };

    (leaf0, result, ca_public_key)
}
