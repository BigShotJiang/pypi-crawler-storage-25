//! Tests for `verify_signed_tree_head` — tampering, malformed keys, `log_id` binding.
//!
//! AC-1.4-20 (valid round-trip), AC-1.4-21 (tampered sig), AC-1.4-22 (tampered `tree_head`),
//! AC-1.4-23 (malformed pubkey), AC-1.4-26 (wrong pubkey → `SignatureInvalid`),
//! AC-1.4-32 (truncated sig), AC-1.4-33 (`log_id` mutation → `LogIdMismatch`).

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::{verify_signed_tree_head, VerifyError};
use sha2::{Digest, Sha256};

/// Build a valid [`SignedTreeHead`] using the provided signer.
fn make_valid_sth(signer: &MlDsaSigner) -> SignedTreeHead {
    let th = TreeHeadDataV2 {
        timestamp: 1_713_787_200_000,
        tree_size: 7,
        root_hash: [0xAB; 32],
        sth_extensions: vec![],
    };
    let signature_bytes = signer.sign_tree_root(&th).expect("sign must succeed");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head: th,
        signature_bytes,
    }
}

/// AC-1.4-20 — valid STH verifies `Ok(())`.
#[test]
fn valid_sth_verifies() {
    let signer = MlDsaSigner::new().expect("keygen");
    let sth = make_valid_sth(&signer);
    assert!(
        verify_signed_tree_head(&sth, signer.public_key()).is_ok(),
        "valid STH must verify Ok(())"
    );
}

/// AC-1.4-21 — flip one interior byte of the signature → `Err(SignatureInvalid)`.
#[test]
fn tampered_signature_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    // Flip an interior byte (index 100) so the length is unchanged.
    sth.signature_bytes[100] ^= 0xFF;
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "tampered signature must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-22 — mutating `timestamp` → `Err(SignatureInvalid)`.
#[test]
fn tampered_timestamp_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    sth.tree_head.timestamp = sth.tree_head.timestamp.wrapping_add(1);
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "tampered timestamp must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-22 — mutating `tree_size` → `Err(SignatureInvalid)`.
#[test]
fn tampered_tree_size_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    sth.tree_head.tree_size = sth.tree_head.tree_size.wrapping_add(1);
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "tampered tree_size must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-22 — mutating `root_hash[0]` → `Err(SignatureInvalid)`.
#[test]
fn tampered_root_hash_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    sth.tree_head.root_hash[0] ^= 0x01;
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "tampered root_hash must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-23 — pubkey of length 100 → `Err(KeyDeserializationFailed { expected: 1952, got: 100 })`.
///
/// Post-DF-1.5-01, `KeyDeserializationFailed` fires first for wrong-length pubkey input
/// (`try_into` is the first step in `verify_signed_tree_head`). For correct-length-but-wrong-key
/// input, `LogIdMismatch` fires.
///
/// AC-1.4-23 reference: this test confirms the `KeyDeserializationFailed` path is still
/// reachable. We construct a second STH whose `log_id` equals `SHA-256([0xAA; 100])` to
/// exercise the pre-DF-1.5-01 path ordering for documentation purposes; post-DF-1.5-01 the
/// `try_into` fires first and the `LogIdMismatch` guard is bypassed for wrong-length input.
#[test]
fn malformed_pubkey_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let sth = make_valid_sth(&signer);
    let short_key = vec![0xAAu8; 100];

    // Confirm the original call (log_id mismatch path) still produces an error.
    let result = verify_signed_tree_head(&sth, &short_key);
    assert!(result.is_err(), "malformed pubkey must always error");

    // Build an STH whose log_id equals SHA-256([0xAA;100]) to bypass the Amendment 1 check
    // and reach the KeyDeserializationFailed path.
    let fake_log_id: [u8; 32] = Sha256::digest(&short_key).into();
    let sth_with_matching_log_id = SignedTreeHead {
        log_id: fake_log_id,
        tree_head: sth.tree_head.clone(),
        signature_bytes: sth.signature_bytes.clone(),
    };
    let result2 = verify_signed_tree_head(&sth_with_matching_log_id, &short_key);
    assert!(
        matches!(
            result2,
            Err(VerifyError::KeyDeserializationFailed {
                expected: 1952,
                got: 100
            })
        ),
        "malformed pubkey (len=100, log_id matched) must yield KeyDeserializationFailed{{expected:1952,got:100}}, got {result2:?}"
    );
}

/// AC-1.4-26 — wrong pubkey with `log_id` pre-aligned to `pk_B` → `Err(SignatureInvalid)`.
///
/// The test pre-aligns `sth.log_id` to `pk_B`'s fingerprint so the `LogIdMismatch` check
/// passes, then the cryptographic verify fails because the payload was signed with `pk_A`'s
/// secret key. This produces `Err(SignatureInvalid)` (distinct from `LogIdMismatch`).
#[test]
fn wrong_pubkey_rejected() {
    let signer_a = MlDsaSigner::new().expect("keygen A");
    let signer_b = MlDsaSigner::new().expect("keygen B");

    // Sign with A's secret key.
    let th = TreeHeadDataV2 {
        timestamp: 1_713_787_200_000,
        tree_size: 7,
        root_hash: [0xCD; 32],
        sth_extensions: vec![],
    };
    let signature_bytes = signer_a.sign_tree_root(&th).expect("sign with A");

    // Set log_id to B's fingerprint so the Amendment 1 binding check passes.
    // The crypto verify must then fail because the signature was made with A's key.
    let pk_b_typed: &[u8; 1952] = signer_b
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = SignedTreeHead {
        log_id: compute_log_id(pk_b_typed),
        tree_head: th,
        signature_bytes,
    };

    let result = verify_signed_tree_head(&sth, signer_b.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "wrong pubkey (log_id aligned to B, signed with A) must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-32 — truncated signature (3309 → 3000 bytes) → `Err(SignatureInvalid)` without panic.
#[test]
fn truncated_signature_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    // Truncate to 3000 bytes — well below the required 3309.
    sth.signature_bytes.truncate(3000);
    let result = verify_signed_tree_head(&sth, signer.public_key());
    // Must return Err without panicking.
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "truncated signature must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.4-33 — `log_id` mutation → `Err(LogIdMismatch { sth_log_id, ca_log_id })` both fields populated.
#[test]
fn log_id_mismatch_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    // Overwrite log_id with a foreign value.
    let foreign_log_id = [0xBBu8; 32];
    sth.log_id = foreign_log_id;

    let result = verify_signed_tree_head(&sth, signer.public_key());
    match result {
        Err(VerifyError::LogIdMismatch {
            sth_log_id,
            ca_log_id,
        }) => {
            assert_eq!(
                sth_log_id, foreign_log_id,
                "sth_log_id must equal the foreign value we injected"
            );
            let pk_typed: &[u8; 1952] = signer
                .public_key()
                .try_into()
                .expect("ML-DSA-65 public key must be exactly 1952 bytes");
            let expected_ca_log_id = compute_log_id(pk_typed);
            assert_eq!(
                ca_log_id, expected_ca_log_id,
                "ca_log_id must equal SHA-256(pk)"
            );
        }
        other => panic!("expected LogIdMismatch, got {other:?}"),
    }
}
