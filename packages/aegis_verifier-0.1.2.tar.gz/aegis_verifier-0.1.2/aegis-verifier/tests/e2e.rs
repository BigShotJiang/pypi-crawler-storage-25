//! End-to-end signing path test (signing path only per VERIFY-5).
//!
//! AC-1.4-24 — `MlDsaSigner::new` → `TreeHeadDataV2` → `sign_tree_root` →
//! assemble `SignedTreeHead` → `verify_signed_tree_head` → `Ok(())`.

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::verify_signed_tree_head;

/// AC-1.4-24 — full signing-path E2E round-trip produces Ok(()).
#[test]
fn signing_path_e2e() {
    let signer = MlDsaSigner::new().expect("MlDsaSigner::new must succeed");

    let tree_head = TreeHeadDataV2 {
        timestamp: 1_713_787_200_000,
        tree_size: 42,
        root_hash: [0x7Fu8; 32],
        sth_extensions: vec![],
    };

    let signature_bytes = signer
        .sign_tree_root(&tree_head)
        .expect("sign_tree_root must succeed");

    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head,
        signature_bytes,
    };

    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        result.is_ok(),
        "E2E signing-path round-trip must return Ok(()), got: {result:?}"
    );
}
