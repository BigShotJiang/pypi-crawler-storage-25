//! Tests for `VerifyError` enum variants and their `Display` formatting.
//!
//! AC-1.4-35 — `VerifyError::SigInitFailed` Display prefix matches expected string.

use aegis_verifier::VerifyError;

/// AC-1.4-35 — `SigInitFailed` variant is constructible and `Display` output
/// begins with `"oqs ML-DSA-65 init failed at verify time: "`.
#[test]
fn sig_init_failed_display() {
    let err = VerifyError::SigInitFailed(oqs::Error::Error);
    let msg = format!("{err}");
    assert!(
        msg.starts_with("oqs ML-DSA-65 init failed at verify time: "),
        "SigInitFailed Display must start with expected prefix, got: {msg:?}"
    );
}
