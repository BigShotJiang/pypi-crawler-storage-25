//! AC-1.5-24 — `verify_mtac` happy-path test.
//!
//! Verifies that `verify_mtac` returns `Ok(())` for a valid leaf + result + CA key
//! built from a real round-trip fixture (no `CertificateAuthority` dep, per Phase 4
//! dev-dep cycle avoidance in SLICE-1.5-BRIEF.md §14.2).

mod common;

use aegis_verifier::verify_mtac;

/// AC-1.5-24: `verify_mtac` returns `Ok(())` for unmodified single-leaf round-trip.
#[test]
fn verify_mtac_happy_path() {
    let (leaf, result, ca_public_key) = common::build_round_trip_fixture();
    assert!(
        verify_mtac(&leaf, &result, &ca_public_key).is_ok(),
        "verify_mtac must return Ok(()) for a valid leaf + result + ca_public_key"
    );
}
