//! AC-1.5-25, 26, 27, 28 — `verify_mtac` tampering-rejection tests.
//!
//! Each sub-test mutates one component of a valid round-trip and asserts that
//! `verify_mtac` returns the expected `MtacVerifyError` variant.
//!
//! AC-1.5-25 sub-case B (tampered leaf that breaks `MtacLeaf` structure via
//! `hash_leaf`) cannot be reached through the public `MtacLeaf` constructor:
//! `hash_leaf` only fails if `serialize_canonical` fails, which in schema-v1
//! is unreachable with well-typed Rust inputs — `MtacLeaf::new` enforces all
//! structural constraints at construction time and there is no way to create an
//! `MtacLeaf` value whose `serialize_canonical` would return `Err`.
//! F-10-S1.5: `LeafHashingFailed` variant is structurally unreachable through
//! the `MtacLeaf` public API in schema-v1; the variant exists as a forward-compat
//! hook for future schema evolution.

mod common;

use aegis_core::signing::{ensure_oqs_init, MlDsaSigner};
use aegis_verifier::{verify_mtac, MtacVerifyError, VerifyError};

/// AC-1.5-25 sub-case A: mutating a leaf field (while keeping it structurally valid)
/// causes `hash_leaf` to produce a different hash, and Merkle verify fails.
///
/// Expected error: `MtacVerifyError::InclusionProofInvalid`.
#[test]
fn tampered_leaf_field_rejected_as_inclusion_proof_invalid() {
    let (mut leaf, result, ca_public_key) = common::build_round_trip_fixture();

    // Mutate a field — leaf remains structurally valid but hash changes.
    leaf.not_after += 1;

    let err = verify_mtac(&leaf, &result, &ca_public_key).unwrap_err();
    assert!(
        matches!(err, MtacVerifyError::InclusionProofInvalid),
        "tampered leaf field must yield InclusionProofInvalid, got: {err:?}"
    );
}

/// AC-1.5-26: mutating `inclusion_proof.inclusion_path` causes Merkle verify to fail.
///
/// Uses a multi-leaf fixture so `inclusion_path` is non-empty (single-leaf trees
/// have empty `inclusion_path` — tampering it would be a no-op).
///
/// Expected error: `MtacVerifyError::InclusionProofInvalid`.
#[test]
fn tampered_audit_path_rejected() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture_multi_leaf();

    // Flip the first byte of the first sibling hash.
    result.inclusion_proof.inclusion_path[0][0] ^= 0x01;

    let err = verify_mtac(&leaf, &result, &ca_public_key).unwrap_err();
    assert!(
        matches!(err, MtacVerifyError::InclusionProofInvalid),
        "tampered audit path must yield InclusionProofInvalid, got: {err:?}"
    );
}

/// AC-1.5-27: mutating `signed_tree_head.signature_bytes` causes STH verification to fail.
///
/// STH verify is step (a) in the HC-P4-1 composition order, so this fires before
/// any leaf hashing or Merkle verification.
///
/// Expected error: `MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)`.
#[test]
fn tampered_sth_signature_rejected() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture();

    // Flip the first byte of the ML-DSA-65 signature.
    result.signed_tree_head.signature_bytes[0] ^= 0x01;

    let err = verify_mtac(&leaf, &result, &ca_public_key).unwrap_err();
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)
        ),
        "tampered STH signature must yield SthVerification(SignatureInvalid), got: {err:?}"
    );
}

/// AC-1.5-28: supplying a different valid 1952-byte CA public key (key B) against a
/// result signed by key A yields `LogIdMismatch`, because the `log_id` inside the STH
/// was computed from key A but key B derives a different `log_id`.
///
/// This is the "wrong CA" misuse vector; per §11 footgun #29 the behavior requires
/// that both keys are correct-length (1952 bytes). Wrong-length keys would trip
/// `KeyDeserializationFailed` instead (different test vector, not covered here).
///
/// Expected error: `MtacVerifyError::SthVerification(VerifyError::LogIdMismatch { .. })`.
#[test]
fn wrong_ca_public_key_rejected_as_log_id_mismatch() {
    let (leaf, result, _ca_public_key_a) = common::build_round_trip_fixture();

    // Generate a DIFFERENT valid ML-DSA-65 keypair (key B).
    ensure_oqs_init();
    let signer_b = MlDsaSigner::new().unwrap();
    let ca_public_key_b: [u8; 1952] = signer_b.public_key().try_into().unwrap();

    let err = verify_mtac(&leaf, &result, &ca_public_key_b).unwrap_err();
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::LogIdMismatch { .. })
        ),
        "wrong CA public key must yield SthVerification(LogIdMismatch), got: {err:?}"
    );
}
