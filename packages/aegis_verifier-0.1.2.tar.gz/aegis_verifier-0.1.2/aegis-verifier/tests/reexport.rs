//! Sanity-checks that `aegis_verifier::verify` resolves to `aegis_core::merkle::verify`
//! behaviourally. `fn_addr_eq` strengthening deferred to Slice 1.6 per DF-1.6-06.

use aegis_core::merkle::{InclusionProof, MerkleTree};
use sha2::{Digest, Sha256};

fn leaf_hash(bytes: &[u8]) -> [u8; 32] {
    Sha256::digest(bytes).into()
}

#[test]
fn verify_reexport_resolves_to_merkle_verify() {
    let leaves: Vec<[u8; 32]> = (0u8..4).map(|i| leaf_hash(&[i; 4])).collect();
    let tree = MerkleTree::new(&leaves).expect("build tree");
    let root = tree.root();
    let proof: InclusionProof = tree.proof(0).expect("proof for leaf 0");
    let leaf = leaves[0];

    // Call via the re-export and via the origin — both should agree.
    let via_reexport = aegis_verifier::verify(leaf, &proof, root);
    let via_origin = aegis_core::merkle::verify(leaf, &proof, root);
    assert_eq!(via_reexport, via_origin);
    assert!(via_reexport, "valid proof must verify true");
}
