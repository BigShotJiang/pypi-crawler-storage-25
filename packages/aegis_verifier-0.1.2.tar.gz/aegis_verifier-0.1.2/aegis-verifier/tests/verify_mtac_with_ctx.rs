//! Tests for `verify_mtac` with the Slice 1.6 wire format.
//!
//! AC-1.6-23: `verify_mtac` handles the new wire format; `ctx_str` passed correctly
//! through `verify_signed_tree_head` (dual-layer domain separation per AD-1.6-02).
//!
//! These tests confirm that:
//! (a) `verify_mtac` succeeds end-to-end with STHs signed under the new wire-v1
//!     format (envelope CBOR array + FIPS 204 ctx `"AEGIS-STH-v1"`).
//! (b) Tampering with the envelope context string or FIPS 204 ctx produces
//!     `MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)`.
//! (c) The composition order (STH first, hash second, Merkle third) is preserved.
//!
//! Design: tests reuse `common::build_round_trip_fixture()` and
//! `common::build_round_trip_fixture_multi_leaf()` to construct valid `MTACIssuanceResult`s
//! without depending on `CertificateAuthority`.

mod common;

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::{verify_mtac, MtacVerifyError, VerifyError};

/// AC-1.6-23 — `verify_mtac` returns `Ok(())` for a valid leaf + result signed
/// under the new wire-v1 format (CBOR envelope + FIPS 204 ctx).
///
/// This is the end-to-end happy path through the new signing stack.
#[test]
fn verify_mtac_succeeds_with_wire_v1_format() {
    let (leaf, result, ca_public_key) = common::build_round_trip_fixture();
    assert!(
        verify_mtac(&leaf, &result, &ca_public_key).is_ok(),
        "verify_mtac must return Ok(()) for a valid wire-v1 signed MTAC"
    );
}

/// AC-1.6-23 — `verify_mtac` succeeds for a multi-leaf tree (non-trivial inclusion proof).
///
/// Confirms that the Merkle path is checked correctly and that the wire-v1 STH
/// carries the correct root hash for the multi-leaf tree.
#[test]
fn verify_mtac_succeeds_with_multi_leaf_tree() {
    let (leaf, result, ca_public_key) = common::build_round_trip_fixture_multi_leaf();
    assert!(
        verify_mtac(&leaf, &result, &ca_public_key).is_ok(),
        "verify_mtac must return Ok(()) for a multi-leaf tree with non-empty inclusion path"
    );
}

/// AC-1.6-23 — `verify_mtac` fails with `SthVerification(SignatureInvalid)` when
/// the signature is tampered (one byte flipped).
///
/// This proves the wire-v1 signature is cryptographically bound: any byte change
/// in the signature bytes propagates through the `ctx_str` verification path and fails.
#[test]
fn verify_mtac_fails_with_tampered_signature() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture();
    result.signed_tree_head.signature_bytes[42] ^= 0xFF;
    let err = verify_mtac(&leaf, &result, &ca_public_key).expect_err("tampered sig must fail");
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)
        ),
        "tampered signature must yield SthVerification(SignatureInvalid), got {err:?}"
    );
}

/// AC-1.6-23 — `verify_mtac` fails with `SthVerification(SignatureInvalid)` when
/// the timestamp field is mutated.
///
/// The timestamp is encoded in the CBOR body (inner array field 2). Mutating it
/// changes the envelope bytes, making the FIPS 204 ctx verification fail.
#[test]
fn verify_mtac_fails_with_tampered_timestamp() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture();
    result.signed_tree_head.tree_head.timestamp =
        result.signed_tree_head.tree_head.timestamp.wrapping_add(1);
    let err =
        verify_mtac(&leaf, &result, &ca_public_key).expect_err("tampered timestamp must fail");
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)
        ),
        "tampered timestamp must yield SthVerification(SignatureInvalid), got {err:?}"
    );
}

/// AC-1.6-23 — `verify_mtac` fails with `SthVerification(SignatureInvalid)` when
/// `root_hash` is tampered.
///
/// `root_hash` is encoded in the CBOR body (inner array field 3). Mutating it
/// changes both the envelope bytes (making signature verification fail) and would
/// also change the Merkle root check — the STH check fires first per composition order.
#[test]
fn verify_mtac_fails_with_tampered_root_hash() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture();
    result.signed_tree_head.tree_head.root_hash[0] ^= 0x01;
    let err =
        verify_mtac(&leaf, &result, &ca_public_key).expect_err("tampered root_hash must fail");
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)
        ),
        "tampered root_hash must yield SthVerification(SignatureInvalid), got {err:?}"
    );
}

/// AC-1.6-23 — `verify_mtac` fails with `InclusionProofInvalid` when the leaf is tampered
/// but the STH is authentic.
///
/// The leaf hash changes, so the inclusion proof does not match the root in the
/// (untampered, authentic) STH. The STH verify passes first; the Merkle check fails.
#[test]
fn verify_mtac_fails_with_tampered_leaf() {
    let (mut leaf, result, ca_public_key) = common::build_round_trip_fixture();
    // Mutate a field that is part of the leaf's canonical encoding.
    leaf.agent_id.push('X');
    let err = verify_mtac(&leaf, &result, &ca_public_key).expect_err("tampered leaf must fail");
    assert!(
        matches!(err, MtacVerifyError::InclusionProofInvalid),
        "tampered leaf must yield InclusionProofInvalid, got {err:?}"
    );
}

/// AC-1.6-23 — `verify_mtac` fails with `InclusionProofInvalid` when an audit path
/// hash is tampered.
///
/// Uses the multi-leaf fixture so the proof has a non-empty `inclusion_path`.
/// The STH verifies correctly (untampered); the Merkle check fails.
#[test]
fn verify_mtac_fails_with_tampered_inclusion_path() {
    let (leaf, mut result, ca_public_key) = common::build_round_trip_fixture_multi_leaf();
    // Flip a byte in the first sibling hash in the inclusion path.
    assert!(
        !result.inclusion_proof.inclusion_path.is_empty(),
        "multi-leaf fixture must have non-empty inclusion_path"
    );
    result.inclusion_proof.inclusion_path[0][0] ^= 0xFF;
    let err =
        verify_mtac(&leaf, &result, &ca_public_key).expect_err("tampered inclusion path must fail");
    assert!(
        matches!(err, MtacVerifyError::InclusionProofInvalid),
        "tampered inclusion path must yield InclusionProofInvalid, got {err:?}"
    );
}

/// AC-1.6-23 — composition order: STH verification failure takes precedence over
/// Merkle failure even when both would fail.
///
/// When both the signature and the leaf are tampered simultaneously, the error must
/// be `SthVerification`, not `InclusionProofInvalid` — confirming the "STH first"
/// composition order is preserved in the wire-v1 path.
#[test]
fn composition_order_sth_before_merkle() {
    let (mut leaf, mut result, ca_public_key) = common::build_round_trip_fixture_multi_leaf();
    // Tamper both: signature AND leaf.
    result.signed_tree_head.signature_bytes[0] ^= 0xFF;
    leaf.agent_id.push('Z');
    let err = verify_mtac(&leaf, &result, &ca_public_key).expect_err("both tampered must fail");
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::SignatureInvalid)
        ),
        "STH check must fire before Merkle check; expected SthVerification, got {err:?}"
    );
}

/// AC-1.6-23 — `verify_mtac` with wrong CA key returns `SthVerification(LogIdMismatch)`
/// when `log_id` is consistent with the wrong key.
///
/// Build an STH signed with key A; pass key B. The `log_id` in the STH = `SHA-256(pk_A)`,
/// but `compute_log_id(pk_B)` = `SHA-256(pk_B)`. These differ → `LogIdMismatch`.
#[test]
fn verify_mtac_fails_with_wrong_ca_key() {
    use aegis_core::issuance::MTACIssuanceResult;
    use aegis_core::leaf::hash_leaf;
    use aegis_core::merkle::MerkleTree;

    let signer_a = MlDsaSigner::new().expect("keygen A");
    let signer_b = MlDsaSigner::new().expect("keygen B");

    let pk_a: &[u8; 1952] = signer_a
        .public_key()
        .try_into()
        .expect("pk_a must be 1952 bytes");
    let pk_b: &[u8; 1952] = signer_b
        .public_key()
        .try_into()
        .expect("pk_b must be 1952 bytes");

    let log_id_a = compute_log_id(pk_a);

    // Build a leaf hash against log A's log_id.
    let leaf = common::make_leaf("urn:aegis:agent:wrong-key-test");
    let leaf_hash = hash_leaf(&leaf, &log_id_a).unwrap();

    let tree = MerkleTree::new(&[leaf_hash]).unwrap();
    let root_hash = tree.root();
    let proof = tree.proof(0).unwrap();

    let tree_head = TreeHeadDataV2 {
        timestamp: 1_713_600_000,
        tree_size: 1,
        root_hash,
        sth_extensions: vec![],
    };
    let signature_bytes = signer_a.sign_tree_root(&tree_head).unwrap();
    let sth = SignedTreeHead {
        log_id: log_id_a,
        tree_head,
        signature_bytes,
    };

    let result = MTACIssuanceResult {
        #[allow(clippy::default_trait_access)]
        batch_id: Default::default(),
        leaf_index: 0,
        inclusion_proof: proof,
        signed_tree_head: sth,
    };

    // Verify with pk_B — log_id in STH was built with pk_A → mismatch.
    let err = verify_mtac(&leaf, &result, pk_b).expect_err("wrong CA key must fail");
    assert!(
        matches!(
            err,
            MtacVerifyError::SthVerification(VerifyError::LogIdMismatch { .. })
        ),
        "wrong CA key must yield SthVerification(LogIdMismatch), got {err:?}"
    );
}
