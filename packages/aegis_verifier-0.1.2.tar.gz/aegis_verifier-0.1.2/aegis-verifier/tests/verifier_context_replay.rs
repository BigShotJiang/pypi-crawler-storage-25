//! Tests for `VerifierContext::verify_signed_tree_head_fresh` — replay detection.
//!
//! AC-1.6-21: rejects STH with timestamp ≤ previously-seen STH for same `log_id`
//! with `VerifyError::ReplayedSth`.
//!
//! Replay semantics per the contract:
//! - A new STH must have `timestamp > prev.timestamp` for the same `log_id`.
//! - An STH with `timestamp == prev.timestamp` is treated as a replay (strict GT).
//! - An STH with `timestamp < prev.timestamp` is obviously a replay.
//! - The check is keyed on `log_id` — two different signers are independent.
//!
//! These tests use `max_age = None` throughout to isolate replay behaviour from
//! freshness behaviour (which is covered by `verifier_context_freshness.rs`).

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::{VerifierContext, VerifyError};

/// Builds a valid [`SignedTreeHead`] with the given timestamp (Unix ms).
fn make_sth_with_timestamp(signer: &MlDsaSigner, timestamp_ms: u64) -> SignedTreeHead {
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let tree_head = TreeHeadDataV2 {
        timestamp: timestamp_ms,
        tree_size: 1,
        root_hash: [0xAB; 32],
        sth_extensions: vec![],
    };
    let signature_bytes = signer
        .sign_tree_root(&tree_head)
        .expect("sign must succeed");
    SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head,
        signature_bytes,
    }
}

/// AC-1.6-21 — second STH with equal timestamp is rejected as a replay.
///
/// Per the contract: identical timestamps for the same `log_id` are considered
/// replays — a signer should never emit two STHs with identical timestamps.
#[test]
fn equal_timestamp_rejected_as_replay() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let log_id = compute_log_id(pk_typed);

    let sth_first = make_sth_with_timestamp(&signer, 1_713_600_000_000);
    // Second STH has the same timestamp — must be rejected.
    let sth_replay = make_sth_with_timestamp(&signer, 1_713_600_000_000);

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_first, pk_typed, None)
        .expect("first STH must be accepted");

    let result = ctx.verify_signed_tree_head_fresh(&sth_replay, pk_typed, None);
    match result {
        Err(VerifyError::ReplayedSth { log_id: err_log_id }) => {
            assert_eq!(
                err_log_id, log_id,
                "ReplayedSth.log_id must match the signer's log_id"
            );
        }
        other => panic!("expected ReplayedSth, got {other:?}"),
    }
}

/// AC-1.6-21 — second STH with strictly older timestamp is rejected as a replay.
///
/// Timestamps going backward indicate clock rewind or a captured old STH.
#[test]
fn older_timestamp_rejected_as_replay() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let log_id = compute_log_id(pk_typed);

    let sth_newer = make_sth_with_timestamp(&signer, 1_713_600_001_000);
    let sth_older = make_sth_with_timestamp(&signer, 1_713_600_000_000); // 1s earlier

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_newer, pk_typed, None)
        .expect("newer STH must be accepted first");

    let result = ctx.verify_signed_tree_head_fresh(&sth_older, pk_typed, None);
    match result {
        Err(VerifyError::ReplayedSth { log_id: err_log_id }) => {
            assert_eq!(
                err_log_id, log_id,
                "ReplayedSth.log_id must match the signer's log_id"
            );
        }
        other => panic!("expected ReplayedSth for older timestamp, got {other:?}"),
    }
}

/// AC-1.6-21 — STH with strictly newer timestamp is accepted (not a replay).
///
/// The happy path: each new STH has a higher timestamp than the last.
#[test]
fn newer_timestamp_accepted_not_replay() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");

    let sth_first = make_sth_with_timestamp(&signer, 1_000);
    let sth_second = make_sth_with_timestamp(&signer, 2_000); // strictly newer
    let sth_third = make_sth_with_timestamp(&signer, 3_000); // strictly newer still

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_first, pk_typed, None)
        .expect("first STH (ts=1000) must be accepted");
    ctx.verify_signed_tree_head_fresh(&sth_second, pk_typed, None)
        .expect("second STH (ts=2000) must be accepted");
    ctx.verify_signed_tree_head_fresh(&sth_third, pk_typed, None)
        .expect("third STH (ts=3000) must be accepted");
}

/// AC-1.6-21 — first STH for a log is never a replay (context is empty for that log).
#[test]
fn first_sth_is_never_a_replay() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    // Even timestamp=0 (Unix epoch) is not a replay on first presentation.
    let sth = make_sth_with_timestamp(&signer, 0);
    let mut ctx = VerifierContext::new();
    let result = ctx.verify_signed_tree_head_fresh(&sth, pk_typed, None);
    assert!(
        result.is_ok(),
        "first STH (even at ts=0) must not be rejected as replay, got {result:?}"
    );
}

/// AC-1.6-21 — replay check is keyed on `log_id`; two different signers are independent.
///
/// `STH_A` from signer A followed by `STH_B` from signer B are independent. A second
/// call with `STH_A'` (same log as A, older ts) is a replay for A's log. But B's
/// first STH remains unaffected.
#[test]
fn replay_check_keyed_on_log_id() {
    let signer_a = MlDsaSigner::new().expect("keygen A");
    let signer_b = MlDsaSigner::new().expect("keygen B");
    let pk_a: &[u8; 1952] = signer_a
        .public_key()
        .try_into()
        .expect("pk_a must be 1952 bytes");
    let pk_b: &[u8; 1952] = signer_b
        .public_key()
        .try_into()
        .expect("pk_b must be 1952 bytes");

    let sth_for_a = make_sth_with_timestamp(&signer_a, 2_000);
    let sth_for_b = make_sth_with_timestamp(&signer_b, 1_000); // independent log

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_for_a, pk_a, None)
        .expect("A's first STH must be accepted");
    ctx.verify_signed_tree_head_fresh(&sth_for_b, pk_b, None)
        .expect("B's first STH must be accepted (independent log)");

    // Replay A with an older timestamp — this is a replay for log A only.
    let sth_a_replay = make_sth_with_timestamp(&signer_a, 1_000);
    let result_a = ctx.verify_signed_tree_head_fresh(&sth_a_replay, pk_a, None);
    assert!(
        matches!(result_a, Err(VerifyError::ReplayedSth { .. })),
        "replay on log A must be rejected, got {result_a:?}"
    );

    // B's log is unaffected — a new STH for B with ts > prev still passes.
    let sth_b_next = make_sth_with_timestamp(&signer_b, 2_000);
    ctx.verify_signed_tree_head_fresh(&sth_b_next, pk_b, None)
        .expect("B's second STH (after A's replay rejection) must still be accepted");
}

/// AC-1.6-21 — failed replay check does NOT update state.
///
/// A replayed STH is rejected without updating `seen_sths`. The last-seen STH
/// for the log must remain the one from the last successful verify.
#[test]
fn failed_replay_check_does_not_update_state() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let log_id = compute_log_id(pk_typed);

    let ts_good: u64 = 5_000;
    let sth_good = make_sth_with_timestamp(&signer, ts_good);
    let sth_replay = make_sth_with_timestamp(&signer, ts_good); // same ts = replay

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_good, pk_typed, None)
        .expect("good STH must be accepted");

    // Attempt replay.
    let result = ctx.verify_signed_tree_head_fresh(&sth_replay, pk_typed, None);
    assert!(
        matches!(result, Err(VerifyError::ReplayedSth { .. })),
        "replay must be rejected, got {result:?}"
    );

    // State must be unchanged: last_seen still reflects ts_good.
    let seen = ctx
        .last_seen(&log_id)
        .expect("last_seen must be Some after good verify");
    assert_eq!(
        seen.tree_head.timestamp, ts_good,
        "state must not be updated after a replay rejection"
    );
}

/// AC-1.6-21 — `ReplayedSth.log_id` field matches the log that was replayed.
///
/// Explicit field-level check so that a future refactor that populates the wrong
/// `log_id` in the error is caught.
#[test]
fn replayed_sth_error_carries_correct_log_id() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let expected_log_id = compute_log_id(pk_typed);

    let sth_v1 = make_sth_with_timestamp(&signer, 10_000);
    let sth_v1_replay = make_sth_with_timestamp(&signer, 10_000);

    let mut ctx = VerifierContext::new();
    ctx.verify_signed_tree_head_fresh(&sth_v1, pk_typed, None)
        .expect("first STH must be accepted");
    let result = ctx.verify_signed_tree_head_fresh(&sth_v1_replay, pk_typed, None);
    match result {
        Err(VerifyError::ReplayedSth { log_id }) => {
            assert_eq!(
                log_id, expected_log_id,
                "ReplayedSth.log_id must match SHA-256(ca_public_key)"
            );
        }
        other => panic!("expected ReplayedSth with correct log_id, got {other:?}"),
    }
}
