//! Property-based tests for `verify_signed_tree_head`.
//!
//! AC-1.4-29 — 256 random (`root`, `tree_size`, `timestamp`) inputs always verify `Ok(())`.
//! AC-1.4-30 — 4 mutation classes all produce `Err(SignatureInvalid)`.
//! AC-1.5-33 — byte-swap mutation class: swapping two distinct positions in `signature_bytes`
//!   is always rejected (256 cases).
//! AC-1.5-34 — boundary-value mutation: setting first or last byte of `signature_bytes` to
//!   `0x00` or `0xFF` is always rejected (256 cases).
//!
//! Note on `tree_size` mutation (AC-1.4-30 class 2):
//! This proptest mutates the `tree_head.tree_size` field in the *signed payload* of a
//! `SignedTreeHead`. This is distinct from the F-7-S1.3 finding (RFC 9162 §2.1.3.2
//! `verify` non-injectivity in `tree_size`) — that finding concerns the Merkle inclusion
//! proof verifier's tolerance of adjacent `tree_size` values, not ML-DSA-65 signature
//! verification. Here, `tree_size` is part of the TLS-PL signed payload, so any change
//! to it invalidates the signature unconditionally.

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::{verify_signed_tree_head, VerifyError};
use proptest::prelude::*;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(256))]

    /// AC-1.4-29 — random (root, tree_size, timestamp) always verifies Ok(()).
    #[test]
    fn prop_sign_verify_roundtrip(
        root_bytes in any::<[u8; 32]>(),
        tree_size in any::<u64>(),
        timestamp in any::<u64>(),
    ) {
        let signer = MlDsaSigner::new().unwrap();
        let th = TreeHeadDataV2 {
            timestamp,
            tree_size,
            root_hash: root_bytes,
            sth_extensions: vec![],
        };
        let pk_typed: &[u8; 1952] = signer
            .public_key()
            .try_into()
            .expect("ML-DSA-65 public key must be exactly 1952 bytes");
        let sig_bytes = signer.sign_tree_root(&th).unwrap();
        let sth = SignedTreeHead {
            log_id: compute_log_id(pk_typed),
            tree_head: th,
            signature_bytes: sig_bytes,
        };
        prop_assert!(verify_signed_tree_head(&sth, signer.public_key()).is_ok());
    }

    /// AC-1.4-30 — four mutation classes, each produces Err(SignatureInvalid).
    ///
    /// Per HC #17 and §11 footgun #3, `log_id` is envelope (handled by AC-1.4-33);
    /// this proptest covers signed-payload mutations only.
    #[test]
    fn prop_mutated_rejected(
        root_bytes in any::<[u8; 32]>(),
        tree_size in any::<u64>(),
        timestamp in any::<u64>(),
        sig_mutation_index in 0usize..3309usize,
        class in 0u8..4u8,
    ) {
        let signer = MlDsaSigner::new().unwrap();
        let th = TreeHeadDataV2 {
            timestamp,
            tree_size,
            root_hash: root_bytes,
            sth_extensions: vec![],
        };
        let pk_typed: &[u8; 1952] = signer
            .public_key()
            .try_into()
            .expect("ML-DSA-65 public key must be exactly 1952 bytes");
        let sig_bytes = signer.sign_tree_root(&th).unwrap();
        let mut sth = SignedTreeHead {
            log_id: compute_log_id(pk_typed),
            tree_head: th,
            signature_bytes: sig_bytes,
        };

        match class {
            0 => {
                // Flip one bit inside the signature (length unchanged).
                sth.signature_bytes[sig_mutation_index] ^= 1;
            }
            1 => {
                // Flip the timestamp (part of TLS-PL signed payload).
                sth.tree_head.timestamp = sth.tree_head.timestamp.wrapping_add(1);
            }
            2 => {
                // Flip the tree_size (part of TLS-PL signed payload).
                // Distinct from F-7-S1.3 merkle non-injectivity — here the mutation
                // invalidates the ML-DSA-65 signature unconditionally.
                sth.tree_head.tree_size = sth.tree_head.tree_size.wrapping_add(1);
            }
            3 => {
                // Flip one bit in root_hash (part of TLS-PL signed payload).
                sth.tree_head.root_hash[0] ^= 1;
            }
            _ => unreachable!(),
        }

        let outcome = verify_signed_tree_head(&sth, signer.public_key());
        prop_assert!(matches!(outcome, Err(VerifyError::SignatureInvalid)));
    }

    /// AC-1.5-33 — byte-swap mutation class.
    ///
    /// Swapping two DISTINCT byte positions within `signature_bytes` (when the positions
    /// differ and the bytes at those positions are different) must always cause verification
    /// to fail. When `i == j` or `bytes[i] == bytes[j]` the swap is a no-op and the
    /// existing signature remains valid — so we only assert rejection when the swap is
    /// non-trivial. This covers the case where the mutation is observable.
    ///
    /// The signature is exactly 3,309 bytes (ML-DSA-65 FIPS 204 Table 2).
    /// Positions are clamped to `sig_len - 1` via modulo to stay within bounds.
    #[test]
    fn prop_byte_swap_mutation_rejected(
        root_bytes in any::<[u8; 32]>(),
        tree_size in any::<u64>(),
        timestamp in any::<u64>(),
        raw_i in any::<usize>(),
        raw_j in any::<usize>(),
    ) {
        let signer = MlDsaSigner::new().unwrap();
        let th = TreeHeadDataV2 {
            timestamp,
            tree_size,
            root_hash: root_bytes,
            sth_extensions: vec![],
        };
        let pk_typed: &[u8; 1952] = signer
            .public_key()
            .try_into()
            .expect("ML-DSA-65 public key must be exactly 1952 bytes");
        let sig_bytes = signer.sign_tree_root(&th).unwrap();
        let sig_len = sig_bytes.len(); // always 3309 by sign_tree_root invariant

        let i = raw_i % sig_len;
        let j = raw_j % sig_len;

        // If i == j or the bytes are already equal, the swap is a no-op and the
        // signature remains valid — skip the assertion in that case.
        if i != j && sig_bytes[i] != sig_bytes[j] {
            let mut mutated_sig = sig_bytes.clone();
            mutated_sig.swap(i, j);

            let mut sth = SignedTreeHead {
                log_id: compute_log_id(pk_typed),
                tree_head: th,
                signature_bytes: mutated_sig,
            };
            // Restore the original tree_head data to ensure the only mutation is in sig bytes.
            sth.tree_head = TreeHeadDataV2 {
                timestamp,
                tree_size,
                root_hash: root_bytes,
                sth_extensions: vec![],
            };

            let outcome = verify_signed_tree_head(&sth, signer.public_key());
            prop_assert!(
                matches!(outcome, Err(VerifyError::SignatureInvalid)),
                "byte-swap at ({i}, {j}) must be rejected; got: {outcome:?}"
            );
        }
    }

    /// AC-1.5-34 — boundary-value mutation class.
    ///
    /// Setting the first or last byte of `signature_bytes` to `0x00` or `0xFF` must
    /// always cause verification to fail — unless the target byte already has that value
    /// (no-op mutation, skip assertion in that case).
    #[test]
    fn prop_boundary_value_mutation_rejected(
        root_bytes in any::<[u8; 32]>(),
        tree_size in any::<u64>(),
        timestamp in any::<u64>(),
        first_or_last in proptest::bool::ANY,
        fill_byte in prop_oneof![Just(0x00u8), Just(0xFFu8)],
    ) {
        let signer = MlDsaSigner::new().unwrap();
        let th = TreeHeadDataV2 {
            timestamp,
            tree_size,
            root_hash: root_bytes,
            sth_extensions: vec![],
        };
        let pk_typed: &[u8; 1952] = signer
            .public_key()
            .try_into()
            .expect("ML-DSA-65 public key must be exactly 1952 bytes");
        let sig_bytes = signer.sign_tree_root(&th).unwrap();
        let sig_len = sig_bytes.len(); // always 3309 by sign_tree_root invariant

        let target_idx = if first_or_last { 0 } else { sig_len - 1 };
        let original_byte = sig_bytes[target_idx];

        // Skip if no-op (byte already equals fill_byte — mutation has no effect).
        if original_byte != fill_byte {
            let mut mutated_sig = sig_bytes.clone();
            mutated_sig[target_idx] = fill_byte;

            let sth = SignedTreeHead {
                log_id: compute_log_id(pk_typed),
                tree_head: th,
                signature_bytes: mutated_sig,
            };

            let outcome = verify_signed_tree_head(&sth, signer.public_key());
            prop_assert!(
                matches!(outcome, Err(VerifyError::SignatureInvalid)),
                "boundary-value mutation (idx={target_idx}, fill=0x{fill_byte:02x}) must be rejected; got: {outcome:?}"
            );
        }
    }
}
