//! Tests for dual-layer domain separation per AD-1.6-02 (HC #34).
//!
//! AC-1.6-24: sign with envelope ctx + FIPS 204 ctx; verify with same; tampering
//! with EITHER layer fails verification.
//!
//! Two independent domain-separation layers per AD-1.6-02:
//!
//! Layer 1 — Envelope context string (auditor-visible in `bytes_to_sign`):
//!   The outer CBOR array contains `tstr("AEGIS-STH-v1")` as its first element.
//!   Changing any field in the STH changes the CBOR body, which changes the
//!   full envelope bytes that are cryptographically signed.
//!
//! Layer 2 — FIPS 204 §5.2 ctx parameter (cryptographically bound, NOT in wire bytes):
//!   `MlDsaSigner::sign_tree_root` calls `sign_with_ctx_str(b"AEGIS-STH-v1")`.
//!   `verify_signed_tree_head` calls `verify_with_ctx_str(b"AEGIS-STH-v1")`.
//!   A signature produced with a different ctx (e.g., b"") against the same envelope
//!   bytes is cryptographically invalid under the correct ctx.
//!
//! Defense-in-depth threat model:
//! - Layer 1 (envelope) blocks cross-protocol replay: an attacker cannot take a
//!   valid Aegis STH and use it as a non-Aegis message because the "AEGIS-STH-v1"
//!   context string is embedded in the signed bytes.
//! - Layer 2 (FIPS 204 ctx) blocks cross-algorithm key reuse: even if an attacker
//!   can observe the wire bytes, they cannot reconstruct M' (which mixes the ctx
//!   into the signing input) without knowing the ctx string out-of-band.
//!
//! Test strategy for layer 2: use `oqs` directly (a dev-dep of aegis-verifier) to
//! produce a signature over the correct envelope bytes but with an EMPTY ctx string
//! (`b""`). Then pass this "wrong-ctx" signature to `verify_signed_tree_head` and
//! assert that it is rejected — proving the FIPS 204 ctx parameter is checked.

use aegis_core::serialization::{encode_signed_tree_head, WIRE_VERSION};
use aegis_core::signing::{
    compute_log_id, ensure_oqs_init, MlDsaSigner, SignedTreeHead, TreeHeadDataV2,
};
use aegis_verifier::{verify_signed_tree_head, VerifyError};

/// Builds a valid [`SignedTreeHead`] using `MlDsaSigner` (both domain-separation
/// layers active).
fn make_valid_sth(signer: &MlDsaSigner) -> SignedTreeHead {
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let tree_head = TreeHeadDataV2 {
        timestamp: 1_713_787_200_000,
        tree_size: 7,
        root_hash: [0xAB; 32],
        sth_extensions: vec![],
    };
    let signature_bytes = signer
        .sign_tree_root(&tree_head)
        .expect("sign must succeed");
    SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head,
        signature_bytes,
    }
}

/// AC-1.6-24 — valid sign+verify round-trip with both domain-separation layers active.
///
/// `MlDsaSigner::sign_tree_root` uses both layers (CBOR envelope + FIPS 204 ctx).
/// `verify_signed_tree_head` verifies against both. This is the expected happy path.
#[test]
fn both_layers_active_round_trip() {
    let signer = MlDsaSigner::new().expect("keygen");
    let sth = make_valid_sth(&signer);
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        result.is_ok(),
        "valid sign+verify with both domain-separation layers must succeed, got {result:?}"
    );
}

/// AC-1.6-24 — Layer 1 (envelope context): mutating the STH timestamp changes
/// the CBOR envelope bytes and breaks verification.
///
/// The timestamp is encoded as field 2 in the inner CBOR array. Changing it
/// changes `encode_signed_tree_head(sth)`, making the envelope bytes differ from
/// what was signed. Verification with the original `b"AEGIS-STH-v1"` ctx fails.
#[test]
fn tampering_envelope_layer_breaks_verification() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);

    // Capture the original envelope bytes (pre-tamper).
    let original_envelope = encode_signed_tree_head(&sth);

    // Mutate the timestamp — changes the inner CBOR body, and thus the outer envelope.
    sth.tree_head.timestamp = sth.tree_head.timestamp.wrapping_add(1);

    // Confirm the envelope actually changed after the mutation.
    let tampered_envelope = encode_signed_tree_head(&sth);
    assert_ne!(
        original_envelope, tampered_envelope,
        "envelope must change when timestamp is mutated"
    );

    // Verify must fail because the signature was over the original envelope.
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "tampered envelope (mutated timestamp) must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.6-24 — Layer 1 (envelope): the `WIRE_VERSION` constant `"AEGIS-STH-v1"` is present
/// in the signed envelope bytes.
///
/// Proves that the envelope context string is actually embedded in the bytes that
/// are signed — not just passed as a side-channel parameter. An auditor with only the
/// wire bytes can confirm which protocol version was signed.
#[test]
fn envelope_context_string_present_in_signed_bytes() {
    let signer = MlDsaSigner::new().expect("keygen");
    let sth = make_valid_sth(&signer);
    let envelope = encode_signed_tree_head(&sth);

    // The WIRE_VERSION string must appear as a literal substring in the envelope.
    let version_bytes = WIRE_VERSION.as_bytes();
    let found = envelope
        .windows(version_bytes.len())
        .any(|w| w == version_bytes);
    assert!(
        found,
        "WIRE_VERSION '{WIRE_VERSION}' must appear in the signed envelope bytes"
    );
}

/// AC-1.6-24 — Layer 2 (FIPS 204 ctx): a signature produced with an empty ctx
/// (`b""`) over the CORRECT envelope bytes is rejected by `verify_signed_tree_head`.
///
/// `verify_signed_tree_head` always calls `verify_with_ctx_str(b"AEGIS-STH-v1")`.
/// Even when the envelope bytes are identical, a signature produced with `b""` as
/// the FIPS 204 ctx is cryptographically invalid under `b"AEGIS-STH-v1"`.
///
/// This test constructs the "wrong-ctx" signature directly via `oqs` to bypass the
/// production `MlDsaSigner` path and prove the FIPS 204 ctx layer is independently
/// enforced.
#[test]
fn wrong_fips204_ctx_breaks_verification() {
    ensure_oqs_init();

    // Design: generate a fresh oqs keypair and sign the envelope bytes with an EMPTY ctx
    // (b""). Build an STH with the new keypair's pk whose signature was made with b"" ctx.
    // The verify call uses b"AEGIS-STH-v1" ctx → fails, proving the FIPS 204 ctx layer is
    // independently enforced even when the envelope bytes are correct.
    //
    // The MlDsaSigner secret key is intentionally not exposed (zeroize-on-drop, Slice 1.4
    // MD-24). A fresh oqs keypair is the correct boundary for this test.
    let sig_scheme = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65).expect("oqs init");
    let (pk_raw, sk_raw) = sig_scheme.keypair().expect("keypair");
    let pk_fresh_typed: &[u8; 1952] = pk_raw
        .as_ref()
        .try_into()
        .expect("ML-DSA-65 pk must be 1952 bytes");
    let fresh_log_id = compute_log_id(pk_fresh_typed);

    // Build envelope bytes for the fresh key's log_id.
    let tree_head_for_fresh = TreeHeadDataV2 {
        timestamp: 1_713_787_200_002,
        tree_size: 5,
        root_hash: [0xDD; 32],
        sth_extensions: vec![],
    };
    let sth_for_fresh_pk = SignedTreeHead {
        log_id: fresh_log_id,
        tree_head: tree_head_for_fresh.clone(),
        signature_bytes: vec![0u8; 3309],
    };
    let envelope_for_fresh = encode_signed_tree_head(&sth_for_fresh_pk);

    // Sign with EMPTY ctx — bypassing the production MlDsaSigner path.
    let sk_ref = sig_scheme
        .secret_key_from_bytes(sk_raw.as_ref())
        .expect("sk must be valid");
    let wrong_ctx_sig = sig_scheme
        .sign_with_ctx_str(&envelope_for_fresh, b"", sk_ref)
        .expect("sign with empty ctx must succeed at the oqs level");

    // Build an STH with the fresh log_id and the wrong-ctx signature.
    let sth_wrong_ctx = SignedTreeHead {
        log_id: fresh_log_id,
        tree_head: tree_head_for_fresh,
        signature_bytes: wrong_ctx_sig.as_ref().to_vec(),
    };

    // verify_signed_tree_head uses b"AEGIS-STH-v1" ctx — must reject the wrong-ctx signature.
    let result = verify_signed_tree_head(&sth_wrong_ctx, pk_raw.as_ref());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "signature produced with empty FIPS 204 ctx must fail when verified with 'AEGIS-STH-v1' ctx, got {result:?}"
    );
}

/// AC-1.6-24 — Layer 2 (FIPS 204 ctx): correct signature is rejected when we supply
/// a different public key (complementary to the wrong-ctx test above).
///
/// This confirms that the ctx check and the key check are both independently active.
#[test]
fn wrong_ctx_and_wrong_key_both_independently_rejected() {
    ensure_oqs_init();

    // Fresh oqs keypair signed with b"wrong-ctx".
    let sig_scheme = oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65).expect("oqs init");
    let (pk_raw, sk_raw) = sig_scheme.keypair().expect("keypair");
    let pk_typed: &[u8; 1952] = pk_raw
        .as_ref()
        .try_into()
        .expect("ML-DSA-65 pk must be 1952 bytes");
    let log_id = compute_log_id(pk_typed);

    let tree_head = TreeHeadDataV2 {
        timestamp: 1_000,
        tree_size: 1,
        root_hash: [0xEE; 32],
        sth_extensions: vec![],
    };
    let sth_placeholder = SignedTreeHead {
        log_id,
        tree_head: tree_head.clone(),
        signature_bytes: vec![0u8; 3309],
    };
    let envelope = encode_signed_tree_head(&sth_placeholder);

    let sk_ref = sig_scheme
        .secret_key_from_bytes(sk_raw.as_ref())
        .expect("sk must be valid");
    let wrong_ctx_sig = sig_scheme
        .sign_with_ctx_str(&envelope, b"wrong-ctx-string", sk_ref)
        .expect("oqs sign with wrong ctx");

    let sth = SignedTreeHead {
        log_id,
        tree_head,
        signature_bytes: wrong_ctx_sig.as_ref().to_vec(),
    };

    // Must fail — wrong FIPS 204 ctx even though envelope and key are correct.
    let result = verify_signed_tree_head(&sth, pk_raw.as_ref());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "wrong FIPS 204 ctx string must fail even with correct envelope bytes and key, got {result:?}"
    );
}

/// AC-1.6-24 — Tampering the signature bytes (not the ctx, not the message) also fails.
///
/// Confirms the basic cryptographic binding: a bit-flip in the signature bytes
/// is detected by the FIPS 204 verifier regardless of the ctx.
#[test]
fn tampered_signature_bytes_rejected() {
    let signer = MlDsaSigner::new().expect("keygen");
    let mut sth = make_valid_sth(&signer);
    sth.signature_bytes[500] ^= 0x01;
    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        matches!(result, Err(VerifyError::SignatureInvalid)),
        "bit-flipped signature must yield SignatureInvalid, got {result:?}"
    );
}

/// AC-1.6-24 — Layer 1 and Layer 2 together: mutating BOTH the envelope fields AND
/// re-signing with the correct ctx and key produces a valid STH.
///
/// This is the positive confirmation that the two layers work together correctly —
/// when both the envelope and the signing are done consistently, verification passes.
#[test]
fn both_layers_consistent_rerequested_sig_verifies() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");

    // Build a second STH with different timestamp — sign it legitimately.
    let tree_head = TreeHeadDataV2 {
        timestamp: 9_999_999_999_999,
        tree_size: 42,
        root_hash: [0xFF; 32],
        sth_extensions: vec![],
    };
    let new_signature = signer
        .sign_tree_root(&tree_head)
        .expect("sign must succeed");
    let sth = SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head,
        signature_bytes: new_signature,
    };

    let result = verify_signed_tree_head(&sth, signer.public_key());
    assert!(
        result.is_ok(),
        "consistently signed STH (new fields, new sig, correct ctx) must verify, got {result:?}"
    );
}
