//! Tests for `VerifierContext::verify_signed_tree_head_fresh` — freshness checking.
//!
//! AC-1.6-20: accepts STH with timestamp within `max_age`; rejects STH with timestamp
//! older than `max_age` with `VerifyError::StaleSth`.
//!
//! Design note on time control: `VerifierContext` uses `SystemTime::now()` directly
//! (no injected Clock trait per the contract). Tests control the apparent age of an
//! STH by choosing `sth.tree_head.timestamp`:
//! - "Fresh" STH: timestamp = current Unix epoch in ms (age ≈ 0ms, always within any
//!   reasonable `max_age`).
//! - "Stale" STH: timestamp = 0 (Unix epoch 1970-01-01, age ≈ 55+ years, always exceeds
//!   any practical `max_age`).
//!
//! This approach has no wall-clock races because the margins are large enough that no
//! real test execution could bridge the gap (55 years vs. `max_age` of 5 minutes).

use std::time::{Duration, SystemTime, UNIX_EPOCH};

use aegis_core::signing::{compute_log_id, MlDsaSigner, SignedTreeHead, TreeHeadDataV2};
use aegis_verifier::{VerifierContext, VerifyError};

/// Returns the current Unix timestamp in milliseconds.
#[allow(clippy::cast_possible_truncation)]
fn now_ms() -> u64 {
    // as_millis() returns u128; u64 can hold ~584 million years of ms — truncation
    // is unreachable for any real system clock value.
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or(Duration::ZERO)
        .as_millis() as u64
}

/// Builds a valid [`SignedTreeHead`] with the given timestamp (Unix ms).
fn make_sth_with_timestamp(signer: &MlDsaSigner, timestamp_ms: u64) -> SignedTreeHead {
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let tree_head = TreeHeadDataV2 {
        timestamp: timestamp_ms,
        tree_size: 1,
        root_hash: [0xAB; 32],
        sth_extensions: vec![],
    };
    let signature_bytes = signer
        .sign_tree_root(&tree_head)
        .expect("sign must succeed");
    SignedTreeHead {
        log_id: compute_log_id(pk_typed),
        tree_head,
        signature_bytes,
    }
}

/// AC-1.6-20 — STH timestamped "now" is accepted when `max_age` = 5 minutes.
///
/// The STH age is approximately zero; it must pass the freshness check regardless
/// of wall-clock jitter in the test runner.
#[test]
fn fresh_sth_accepted_within_max_age() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = make_sth_with_timestamp(&signer, now_ms());
    let mut ctx = VerifierContext::new();
    let result = ctx.verify_signed_tree_head_fresh(
        &sth,
        pk_typed,
        Some(Duration::from_secs(300)), // 5-minute window
    );
    assert!(
        result.is_ok(),
        "STH timestamped now must be accepted with max_age=5m, got {result:?}"
    );
}

/// AC-1.6-20 — STH timestamped at Unix epoch (1970) is rejected with `StaleSth`.
///
/// The STH is 55+ years old — guaranteed to exceed any practical `max_age`. The
/// error must carry both the actual age and the supplied `max_age`.
#[test]
fn stale_sth_rejected_with_stale_sth_error() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = make_sth_with_timestamp(&signer, 0); // timestamp = Unix epoch
    let mut ctx = VerifierContext::new();
    let max_age = Duration::from_secs(300); // 5 minutes
    let result = ctx.verify_signed_tree_head_fresh(&sth, pk_typed, Some(max_age));
    match result {
        Err(VerifyError::StaleSth { age_ms, max_age_ms }) => {
            // age must be >> max_age (55+ years in ms)
            assert!(
                age_ms > max_age_ms,
                "StaleSth.age_ms ({age_ms}) must exceed max_age_ms ({max_age_ms})"
            );
            assert_eq!(
                max_age_ms, 300_000,
                "max_age_ms must reflect the 5-minute window we supplied"
            );
        }
        other => panic!("expected StaleSth, got {other:?}"),
    }
}

/// AC-1.6-20 — `max_age = None` disables freshness checking; stale STH is accepted.
///
/// The stateful path still checks replay (first call for a fresh context always
/// passes replay). Signature must still verify.
#[test]
fn no_max_age_skips_freshness_check() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = make_sth_with_timestamp(&signer, 0); // stale timestamp = Unix epoch
    let mut ctx = VerifierContext::new();
    // With max_age = None, freshness is NOT checked — the stale timestamp must not
    // trigger StaleSth.
    let result = ctx.verify_signed_tree_head_fresh(&sth, pk_typed, None);
    assert!(
        result.is_ok(),
        "max_age=None must skip freshness check even for stale STH, got {result:?}"
    );
}

/// AC-1.6-20 — `StaleSth.age_ms` and `StaleSth.max_age_ms` fields are correctly populated.
///
/// Verifies that the error carries the *actual* `max_age` we supplied (not some default
/// or incorrectly-converted value). Uses a 1-second `max_age` for precision.
#[test]
fn stale_sth_error_fields_correct() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let sth = make_sth_with_timestamp(&signer, 0); // Unix epoch — guaranteed stale
    let mut ctx = VerifierContext::new();
    let max_age = Duration::from_secs(1);
    match ctx.verify_signed_tree_head_fresh(&sth, pk_typed, Some(max_age)) {
        Err(VerifyError::StaleSth { age_ms, max_age_ms }) => {
            assert_eq!(
                max_age_ms, 1_000,
                "max_age_ms must be 1000 (1 second in ms)"
            );
            // age of a 1970-epoch STH is ~55 years = well above 1 second
            assert!(
                age_ms > 1_000,
                "age_ms of epoch-0 STH must exceed 1000ms, got {age_ms}"
            );
        }
        other => panic!("expected StaleSth, got {other:?}"),
    }
}

/// AC-1.6-20 — A fresh STH with `max_age=None` followed by verification with `max_age` set
/// on a SECOND call with updated timestamp — the second call is fresh and accepted.
///
/// This tests that state is updated after the first successful verify: `last_seen()` returns
/// the first STH after the first call, and a new fresh STH on the second call succeeds.
#[test]
fn successive_fresh_sths_both_accepted() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");

    let ts_first = now_ms();
    let ts_second = ts_first + 1_000; // 1 second later — strictly greater

    let sth_first = make_sth_with_timestamp(&signer, ts_first);
    let sth_second = make_sth_with_timestamp(&signer, ts_second);

    let mut ctx = VerifierContext::new();
    let max_age = Duration::from_secs(300);

    ctx.verify_signed_tree_head_fresh(&sth_first, pk_typed, Some(max_age))
        .expect("first fresh STH must be accepted");

    ctx.verify_signed_tree_head_fresh(&sth_second, pk_typed, Some(max_age))
        .expect("second fresh STH (1s newer) must also be accepted");
}

/// AC-1.6-20 — `last_seen()` returns the most recently verified STH for a `log_id`.
///
/// After one successful verify, `last_seen(&log_id)` must return `Some` pointing to
/// the verified STH. Before any verify, it must return `None`.
#[test]
fn last_seen_reflects_verified_sth() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let log_id = compute_log_id(pk_typed);
    let sth = make_sth_with_timestamp(&signer, now_ms());
    let mut ctx = VerifierContext::new();

    // Before any verify, last_seen returns None.
    assert!(
        ctx.last_seen(&log_id).is_none(),
        "last_seen must be None before first verify"
    );

    ctx.verify_signed_tree_head_fresh(&sth, pk_typed, None)
        .expect("fresh STH must be accepted");

    // After successful verify, last_seen returns the STH we just verified.
    let seen = ctx.last_seen(&log_id);
    assert!(
        seen.is_some(),
        "last_seen must be Some after successful verify"
    );
    assert_eq!(
        seen.unwrap().tree_head.timestamp,
        sth.tree_head.timestamp,
        "last_seen timestamp must match the verified STH"
    );
}

/// AC-1.6-20 — state is NOT updated when freshness check fails.
///
/// A failed verify must leave the context in the same state as before. Calling
/// `last_seen()` after a failed verify must still return `None` (first call).
#[test]
fn failed_freshness_check_does_not_update_state() {
    let signer = MlDsaSigner::new().expect("keygen");
    let pk_typed: &[u8; 1952] = signer
        .public_key()
        .try_into()
        .expect("ML-DSA-65 public key must be exactly 1952 bytes");
    let log_id = compute_log_id(pk_typed);
    let stale_sth = make_sth_with_timestamp(&signer, 0);
    let mut ctx = VerifierContext::new();

    let result =
        ctx.verify_signed_tree_head_fresh(&stale_sth, pk_typed, Some(Duration::from_secs(1)));
    assert!(
        matches!(result, Err(VerifyError::StaleSth { .. })),
        "stale STH must be rejected, got {result:?}"
    );

    // State must NOT be updated — last_seen should still be None.
    assert!(
        ctx.last_seen(&log_id).is_none(),
        "state must not be updated after a failed freshness check"
    );
}
