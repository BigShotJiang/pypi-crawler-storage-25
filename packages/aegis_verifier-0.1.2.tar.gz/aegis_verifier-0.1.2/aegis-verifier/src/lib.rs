//! Aegis MTAC verifier — verify-side surface for Slice 1.4 / 1.5 / 1.6.
//!
//! Updated in Slice 1.6: `verify_signed_tree_head` uses the canonical CBOR wire format
//! per AD-1.6-01 and dual-layer domain separation per AD-1.6-02 (HC #34).
//! The old TLS-PL serializer (`serialize_tree_head_tls_pl`) was removed per AC-1.6-13.
//!
//! Slice 1.6 Phase 4 adds [`VerifierContext`] for stateful replay/freshness checking.
//! The stateless [`verify_signed_tree_head`] is preserved per DF-1.6-02 contract.
//!
//! See `AEGIS_ALPHA_SSOT.md` §11 Sub-Slice 1.4 + `HANDOVER-1.3.md` §17.6.

pub mod context;

pub use aegis_core::issuance::MTACIssuanceResult;
pub use aegis_core::merkle::verify;
pub use aegis_core::merkle::InclusionProof;
pub use aegis_core::signing::{SignedTreeHead, TreeHeadDataV2};
pub use context::VerifierContext;

// AC-1.6-22 / DF-1.6-06: `verify` re-export identity check.
// `core::ptr::fn_addr_eq` is not `const fn` in stable Rust 1.95 and cannot appear
// in `const _: () = { ... }`. The equivalent runtime assertion lives in the test
// module below (`verify_re_export_is_canonical`), which fires on every `cargo test`
// or `cargo nextest run` invocation. The function-pointer type (per F-102 fix):
//   fn([u8; 32], &InclusionProof, [u8; 32]) -> bool

use aegis_core::error::LeafError;
use aegis_core::leaf::{hash_leaf, MtacLeaf};
use aegis_core::serialization::encode_signed_tree_head;
use aegis_core::signing::{compute_log_id, ensure_oqs_init};

/// Errors returned by [`verify_signed_tree_head`].
#[derive(Debug, thiserror::Error)]
pub enum VerifyError {
    /// The ML-DSA-65 signature did not verify for the supplied signed payload and public key.
    ///
    /// Also returned for truncated signatures (length != 3,309) and rejected byte strings.
    #[error("ML-DSA-65 signature is invalid")]
    SignatureInvalid,

    /// The supplied `ca_public_key` slice has the wrong length or was rejected by oqs.
    #[error("public key deserialization failed (expected {expected} bytes, got {got})")]
    KeyDeserializationFailed { expected: usize, got: usize },

    /// rev-2 Amendment 1 (Stage 5 F-RT-01 CRITICAL): `log_id` binding mismatch.
    ///
    /// Returned when `compute_log_id(ca_public_key) != sth.log_id`. Prevents
    /// envelope-forgery where an attacker substitutes a foreign `log_id` into a
    /// valid signed tree head.
    #[error("log_id mismatch: STH claims {sth_log_id:?}, but ca_public_key derives {ca_log_id:?}")]
    LogIdMismatch {
        sth_log_id: [u8; 32],
        ca_log_id: [u8; 32],
    },

    /// rev-2 Amendment 3 (Stage 5 F-RT-05): `oqs::sig::Sig::new()` runtime failure at verify time.
    ///
    /// Replaces a prior `expect()` panic path. Caller may retry, process-restart, or escalate.
    #[error("oqs ML-DSA-65 init failed at verify time: {0}")]
    SigInitFailed(oqs::Error),

    /// AC-1.6-19 / AD-1.6-04: the STH timestamp is older than the caller-supplied `max_age`.
    ///
    /// `age_ms` is the computed age of the STH at check time (milliseconds since epoch minus
    /// `sth.tree_head.timestamp`). `max_age_ms` is the caller-supplied limit converted to
    /// milliseconds. A `StaleSth` error does NOT imply the signature is invalid — the signature
    /// is still cryptographically correct; this is a freshness-policy rejection.
    ///
    /// Callers in environments with NTP-adjusted or VM-drifted clocks may see spurious
    /// `StaleSth` on freshly-minted STHs. Implement retry with back-off if operationally needed.
    #[error("STH is stale: age {age_ms}ms exceeds max_age {max_age_ms}ms")]
    StaleSth { age_ms: u64, max_age_ms: u64 },

    /// AC-1.6-19 / AD-1.6-04: an STH for this `log_id` was already seen with an equal or newer
    /// timestamp, indicating a replay or clock-rewind.
    ///
    /// The `log_id` is the SHA-256 fingerprint of the CA's ML-DSA-65 public key (RFC 9162 §4.4).
    /// Strict greater-than is required: an STH with `timestamp == prev.timestamp` for the same
    /// log is treated as a replay (a signer MUST advance the timestamp per RFC 9162 §4.10).
    #[error("STH replayed for log_id {log_id:?}: timestamp not strictly greater than last seen")]
    ReplayedSth { log_id: [u8; 32] },
}

/// Verifies an Aegis [`SignedTreeHead`] against the CA's ML-DSA-65 public key.
///
/// This is the **stateless** low-level path. For production use where replay protection and
/// freshness guarantees are required, prefer [`VerifierContext::verify_signed_tree_head_fresh`]
/// instead — it adds freshness (`max_age`) and replay-detection on top of this function.
///
/// For full MTAC provenance verification (leaf + Merkle inclusion + STH), use [`verify_mtac`]
/// which composes this function with [`hash_leaf`] and [`aegis_core::merkle::verify`] in the
/// security-correct composition order.
///
/// # See also
///
/// - [`VerifierContext::verify_signed_tree_head_fresh`] — recommended stateful API with
///   freshness and replay protection (AD-1.6-04 / AC-1.6-18).
/// - [`verify_mtac`] — full leaf-inclusion verification against a specific MTAC issuance.
///
/// Precondition: caller need not call `oqs::init()` — handled internally via `Once` guard.
///
/// # Security
///
/// This function is **stateless** and does NOT enforce timestamp monotonicity, freshness,
/// or replay protection (rev-2 Amendment 12 / §11 footgun #24). A captured `SignedTreeHead`
/// from time `T` will verify indefinitely. Callers in Slice 1.5 / Slice 3 Gateway / Slice 4
/// on-chain anchoring MUST add their own freshness-check at the boundary where ordering
/// matters. Use [`VerifierContext::verify_signed_tree_head_fresh`] to enforce freshness and
/// detect replays in a single call.
///
/// What this function attests on success:
/// - The signature is valid for the canonical CBOR encoding of `(sth.log_id, sth.tree_head)`
///   signed with dual-layer domain separation per AD-1.6-02 (HC #34):
///   - envelope context string `"AEGIS-STH-v1"` in `bytes_to_sign` (auditor-visible)
///   - FIPS 204 §5.2 ctx `b"AEGIS-STH-v1"` (cryptographically bound, NOT in wire bytes)
/// - The holder of the ML-DSA-65 secret key corresponding to `ca_public_key` produced the signature.
/// - `sth.log_id == SHA-256(ca_public_key)` (rev-2 Amendment 1 binding check).
///
/// What it does NOT attest:
/// - Freshness or ordering of this STH relative to others.
/// - Persistence-layer state (consistency proofs, log monotonicity).
///
/// # Errors
///
/// Returns [`VerifyError::LogIdMismatch`] if `compute_log_id(ca_public_key) != sth.log_id`
/// (envelope-forgery guard). Returns [`VerifyError::KeyDeserializationFailed`] if
/// `ca_public_key.len() != 1952` or oqs rejects the pubkey bytes. Returns
/// [`VerifyError::SignatureInvalid`] on (a) signature length != 3,309 (truncated-sig guard per
/// §11 footgun #16), (b) `signature_from_bytes` rejection, (c) cryptographic verification
/// failure. Returns [`VerifyError::SigInitFailed`] if `oqs::sig::Sig::new()` returns `Err`
/// at verify time.
pub fn verify_signed_tree_head(
    sth: &SignedTreeHead,
    ca_public_key: &[u8],
) -> Result<(), VerifyError> {
    ensure_oqs_init();
    // rev-2 Amendment 3: replace expect() with ? against SigInitFailed.
    let sig =
        oqs::sig::Sig::new(oqs::sig::Algorithm::MlDsa65).map_err(VerifyError::SigInitFailed)?;

    // DF-1.5-01: typed-slice try_into guards wrong-LENGTH input before any other operation.
    // Post-DF-1.5-01 behavioral order: KeyDeserializationFailed fires first for wrong-length
    // input (try_into fails), then LogIdMismatch fires for correct-length-but-wrong-key input.
    // See §11 footgun #29 in SLICE-1.5-BRIEF.md for the behavioral-order observable.
    let ca_pk_typed: &[u8; 1952] =
        ca_public_key
            .try_into()
            .map_err(|_| VerifyError::KeyDeserializationFailed {
                expected: 1952,
                got: ca_public_key.len(),
            })?;

    // rev-2 Amendment 1 (Stage 5 F-RT-01 CRITICAL): bind log_id to ca_public_key BEFORE
    // any other crypto operation. Prevents envelope-forgery where a valid signature is paired
    // with a foreign log_id. Per RFC 9162 §4.10, log_id identifies the log; without binding,
    // log_id is unauthenticated metadata.
    let computed_log_id = compute_log_id(ca_pk_typed);
    if computed_log_id != sth.log_id {
        return Err(VerifyError::LogIdMismatch {
            sth_log_id: sth.log_id,
            ca_log_id: computed_log_id,
        });
    }

    // Downstream pubkey length check: try_into above already guarantees the correct length,
    // so this guard catches well-length-but-ML-DSA-rejected bytes from oqs.
    // Both guards must remain: try_into catches wrong-LENGTH input; this catches oqs rejection
    // of correct-length-but-cryptographically-invalid pubkey bytes.
    if ca_public_key.len() != sig.length_public_key() {
        return Err(VerifyError::KeyDeserializationFailed {
            expected: sig.length_public_key(),
            got: ca_public_key.len(),
        });
    }
    let pk_ref =
        sig.public_key_from_bytes(ca_public_key)
            .ok_or(VerifyError::KeyDeserializationFailed {
                expected: sig.length_public_key(),
                got: ca_public_key.len(),
            })?;

    // Defense against permissive `<=` semantics in oqs's `signature_from_bytes`
    // (per `oqs/sig.rs:368-374` — accepts `buf.len() <= length_signature()`; rev-2 Amendment 6
    // corrected cite from prior `:387`). For ML-DSA-65 the signature MUST be exactly 3,309
    // bytes (FIPS 204 Table 2). A truncated sig could otherwise pass `signature_from_bytes` and
    // fail at the C library — empirical guard per §11 footgun #16 + AC-1.4-32.
    if sth.signature_bytes.len() != sig.length_signature() {
        return Err(VerifyError::SignatureInvalid);
    }
    let sig_ref = sig
        .signature_from_bytes(&sth.signature_bytes)
        .ok_or(VerifyError::SignatureInvalid)?;

    // Single canonical bytes_to_sign extraction (footgun #46).
    // Uses dual-layer domain separation per AD-1.6-02 (HC #34):
    // - envelope tstr "AEGIS-STH-v1" is in the serialized bytes (auditor-visible)
    // - ctx parameter b"AEGIS-STH-v1" is the FIPS 204 §5.2 ctx (cryptographically bound)
    let message = encode_signed_tree_head(sth);

    sig.verify_with_ctx_str(&message, sig_ref, b"AEGIS-STH-v1", pk_ref)
        .map_err(|_| VerifyError::SignatureInvalid)
}

// ─── MtacVerifyError ─────────────────────────────────────────────────────────

/// Errors returned by [`verify_mtac`].
///
/// Three variants cover the three distinct failure modes in the composition order:
/// 1. STH verification failure (wrong key, invalid signature, `log_id` mismatch)
/// 2. Leaf hashing failure (structurally invalid leaf input)
/// 3. Merkle inclusion proof failure (tampered leaf or tampered audit path)
///
/// Per §11 footgun #27: `InclusionProofInvalid` is intentionally coarse-grained —
/// the Merkle verifier cannot distinguish tampered leaf bytes from tampered audit path
/// without breaking the frozen `merkle-v1` surface.
///
/// Per §11 footgun #32: `LeafHashingFailed(LeafError)` wraps the `schema-v1` frozen
/// `LeafError`. Future `hash_leaf` failure modes that require new `LeafError` variants
/// implicitly become schema-v1 amendments (deferred forward-compat note, no known
/// pressure today).
#[derive(Debug, thiserror::Error)]
pub enum MtacVerifyError {
    /// STH signature verification failed, `log_id` mismatched, or key was rejected.
    #[error("signed tree head verification failed: {0}")]
    SthVerification(#[from] VerifyError),

    /// Leaf canonical serialization failed before hashing.
    #[error("leaf hashing failed: {0}")]
    LeafHashingFailed(#[from] LeafError),

    /// Merkle inclusion proof did not verify for the given leaf and root.
    ///
    /// This covers both tampered leaf bytes (where the leaf still parses but hashes
    /// differently) and tampered audit-path hashes. The two causes are indistinguishable
    /// at the Merkle-verifier boundary — see §11 footgun #27.
    #[error("inclusion proof invalid")]
    InclusionProofInvalid,
}

// ─── verify_mtac ─────────────────────────────────────────────────────────────

/// Verifies full MTAC provenance: STH signature, leaf hash, and Merkle inclusion.
///
/// # Composition order (HC-P4-1 — NON-NEGOTIABLE)
///
/// 1. **STH verify first** — authenticates `result.signed_tree_head.log_id == SHA-256(ca_public_key)`.
///    This authentication is what lets step 2 use `signed_tree_head.log_id` as `ca_spki`
///    without a second SPKI hash computation.
/// 2. **Leaf hash second** — using the now-authenticated `log_id` as `ca_spki`.
/// 3. **Merkle verify third** — checks the inclusion proof against the STH root hash.
///
/// # Security
///
/// `verify_mtac` proves **cryptographic provenance** of the MTAC against the CA public key
/// (ML-DSA-65 signature + Merkle inclusion). It does NOT imply:
///
/// - **Agent-identity validity window** — caller MUST check `leaf.not_after` against wall
///   clock independently. An expired leaf verifies here without error.
/// - **Revocation status** — revocation surface is out of scope for Slice 1.5; Slice 2.x /
///   Slice 3 adds the revocation layer. A revoked MTAC verifies here without error.
/// - **Freshness / replay protection** — no replay or freshness check is performed at this
///   boundary. A captured `MTACIssuanceResult` from time `T` will verify indefinitely.
///   DF-1.6-02 routes the freshness-check to the Slice 1.6 SDK boundary (AD-1.6-04).
///   **Time-of-check-to-time-of-use (TOCTOU) gap:** an STH that was fresh at the time
///   `verify_mtac` was called may become stale before the caller acts on the result. For
///   authorization flows, callers MUST re-check freshness at the point of enforcement, not
///   at the point of verification. Use [`VerifierContext::verify_signed_tree_head_fresh`]
///   to enforce a freshness policy as part of the verification call itself.
///
/// **Callers integrating `verify_mtac` into authorization flows MUST layer these checks
/// out-of-band.** This mirrors the `verify_signed_tree_head` stateless-replay security note
/// (§11 footgun #24 / rev-2 Amendment 12) applied to the composite provenance path.
///
/// *RFC 9162 §2.1.3.2 non-injectivity note (F-7-S1.3):* Merkle `verify` is not injective
/// in `tree_size` for neighboring values sharing `floor(log2(n))`. This is correct RFC
/// behaviour reflecting the algorithm's bit-shift structure; it does not transfer to ML-DSA-65
/// verification (signature invalidity is an independent check) and does not weaken the
/// cryptographic provenance guarantee on success.
///
/// # Errors
///
/// - [`MtacVerifyError::SthVerification`] — STH signature invalid, `log_id` mismatch, or
///   `ca_public_key` rejected. See [`VerifyError`] for sub-causes.
/// - [`MtacVerifyError::LeafHashingFailed`] — leaf canonical serialization failed before
///   the hash could be computed.
/// - [`MtacVerifyError::InclusionProofInvalid`] — Merkle inclusion proof did not verify
///   for the computed leaf hash and STH root. Covers tampered leaf bytes (hash-changes)
///   and tampered audit-path hashes.
pub fn verify_mtac(
    leaf: &MtacLeaf,
    result: &MTACIssuanceResult,
    ca_public_key: &[u8; 1952],
) -> Result<(), MtacVerifyError> {
    // (a) STH verify FIRST. Propagates VerifyError via From<VerifyError>.
    //     Authenticates result.signed_tree_head.log_id == SHA-256(ca_public_key).
    verify_signed_tree_head(&result.signed_tree_head, ca_public_key)?;

    // (b) hash_leaf SECOND, using the now-authenticated log_id as ca_spki.
    //     Propagates LeafError via From<LeafError>.
    let leaf_hash = hash_leaf(leaf, &result.signed_tree_head.log_id)?;

    // (c) Merkle verify THIRD. merkle::verify returns bool (NOT Result).
    //     Map false to MtacVerifyError::InclusionProofInvalid EXPLICITLY.
    let root = result.signed_tree_head.tree_head.root_hash;
    if !aegis_core::merkle::verify(leaf_hash, &result.inclusion_proof, root) {
        return Err(MtacVerifyError::InclusionProofInvalid);
    }

    Ok(())
}

// ─── Unit tests ──────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    /// AC-1.6-22 / DF-1.6-06: verify that the public `crate::verify` re-export aliases
    /// `aegis_core::merkle::verify` and has not been shadowed by other code.
    ///
    /// `core::ptr::fn_addr_eq` is NOT `const fn` in stable Rust 1.95, so this check
    /// runs at test time rather than compile time. It fires on every `cargo nextest run`
    /// or `cargo test` invocation, providing the same regression-detection guarantee.
    ///
    /// The fn-pointer type is `fn([u8; 32], &InclusionProof, [u8; 32]) -> bool` —
    /// the actual frozen `aegis_core::merkle::verify` signature (F-102 correction).
    #[test]
    fn verify_re_export_is_canonical() {
        let a: fn([u8; 32], &InclusionProof, [u8; 32]) -> bool = aegis_core::merkle::verify;
        let b: fn([u8; 32], &InclusionProof, [u8; 32]) -> bool = crate::verify;
        assert!(
            core::ptr::fn_addr_eq(a, b),
            "aegis_verifier::verify must alias aegis_core::merkle::verify — re-export shadowing detected"
        );
    }
}
