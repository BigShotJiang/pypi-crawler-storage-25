//! Stateful verifier context for replay and freshness checking.
//!
//! See [`VerifierContext`] for the primary type.

use std::collections::HashMap;
use std::time::{Duration, SystemTime};

use aegis_core::signing::SignedTreeHead;

use crate::{verify_signed_tree_head, VerifyError};

/// Stateful verifier context for replay/freshness checking.
///
/// # Thread safety
///
/// `VerifierContext` holds mutable state (the seen-STH map). It is `Send`
/// but NOT designed for concurrent access without synchronization.
///
/// **Recommended wrapping patterns** for concurrent use:
/// - **Per-request (HTTP gateway):** instantiate a fresh `VerifierContext`
///   per request. No sharing, no synchronization needed.
/// - **Shared cache (long-lived service):** wrap in `Arc<Mutex<VerifierContext>>`
///   or `Arc<parking_lot::Mutex<VerifierContext>>`. Lock for the duration of
///   each `verify_signed_tree_head_fresh` call.
///
/// Slice 3 Gateway will use the per-request pattern; Slice 4+ on-chain
/// anchoring may use the shared-cache pattern depending on workload.
///
/// # Time semantics
///
/// Freshness checks compare `sth.timestamp` against `SystemTime::now()`.
/// `SystemTime` is NOT monotonic — NTP adjustments and VM clock drift can
/// cause spurious `StaleSth` rejections. Callers should implement retry
/// on `StaleSth` if clock drift is operationally expected.
pub struct VerifierContext {
    /// Map from `log_id` (SHA-256 of CA public key) to the last-seen STH for that log.
    seen_sths: HashMap<[u8; 32], SignedTreeHead>,
}

impl Default for VerifierContext {
    /// Creates an empty `VerifierContext`. Delegates to [`VerifierContext::new`].
    fn default() -> Self {
        Self::new()
    }
}

impl VerifierContext {
    /// Creates a new empty `VerifierContext`.
    ///
    /// The context starts with no seen STHs. Each call to
    /// [`verify_signed_tree_head_fresh`][Self::verify_signed_tree_head_fresh]
    /// that succeeds adds the STH to the seen map.
    #[must_use]
    pub fn new() -> Self {
        Self {
            seen_sths: HashMap::new(),
        }
    }

    /// Stateful verify: checks signature AND freshness (if `max_age` given) AND
    /// replay (timestamp must be strictly greater than last seen for the same `log_id`).
    ///
    /// # Check order (fail-fast)
    ///
    /// 1. **Signature verification** via [`verify_signed_tree_head`] — existing error
    ///    variants propagate unchanged.
    /// 2. **Freshness** (only when `max_age.is_some()`): if the STH timestamp is older
    ///    than `max_age` relative to `SystemTime::now()`, returns
    ///    [`VerifyError::StaleSth`].
    /// 3. **Replay** (always): if a previous STH for the same `log_id` has been seen
    ///    with `timestamp >= sth.timestamp`, returns [`VerifyError::ReplayedSth`].
    /// 4. **State update** on success only: records the new STH as the last-seen for
    ///    its `log_id`.
    ///
    /// # Errors
    ///
    /// All existing [`VerifyError`] variants from the stateless path propagate
    /// unchanged. New variants:
    ///
    /// - [`VerifyError::StaleSth`] — STH timestamp is older than `max_age`.
    /// - [`VerifyError::ReplayedSth`] — STH timestamp is not strictly greater than the
    ///   last-seen STH for the same `log_id` (replay or clock-rewind detected).
    ///
    /// # Time semantics
    ///
    /// `SystemTime` is not monotonic. NTP adjustments or VM clock drift can produce
    /// spurious `StaleSth` rejections on freshly-minted STHs. Callers in clock-drift
    /// environments should implement retry logic on `StaleSth`.
    pub fn verify_signed_tree_head_fresh(
        &mut self,
        sth: &SignedTreeHead,
        ca_public_key: &[u8; 1952],
        max_age: Option<Duration>,
    ) -> Result<(), VerifyError> {
        // Step 1: signature + log_id binding (stateless path).
        verify_signed_tree_head(sth, ca_public_key)?;

        // Step 2: freshness check (only when max_age is provided).
        if let Some(max_age_dur) = max_age {
            let now_since_epoch = SystemTime::now()
                .duration_since(SystemTime::UNIX_EPOCH)
                .unwrap_or(Duration::ZERO);
            let sth_ts = Duration::from_millis(sth.tree_head.timestamp);
            // age_dur = how old the STH is (saturate to zero for future-dated timestamps).
            let age_dur = now_since_epoch.saturating_sub(sth_ts);
            if age_dur > max_age_dur {
                // as_millis() returns u128; saturate-clamp to u64::MAX for the error field.
                // In practice, any age representable by SystemTime fits easily in u64 ms
                // (u64 ms covers ~584 million years), so truncation is unreachable in practice.
                let age_ms = u64::try_from(age_dur.as_millis()).unwrap_or(u64::MAX);
                let max_age_ms = u64::try_from(max_age_dur.as_millis()).unwrap_or(u64::MAX);
                return Err(VerifyError::StaleSth { age_ms, max_age_ms });
            }
        }

        // Step 3: replay check (always — regardless of max_age).
        if let Some(prev) = self.seen_sths.get(&sth.log_id) {
            if sth.tree_head.timestamp <= prev.tree_head.timestamp {
                return Err(VerifyError::ReplayedSth { log_id: sth.log_id });
            }
        }

        // Step 4: state update on success only.
        self.seen_sths.insert(sth.log_id, sth.clone());
        Ok(())
    }

    /// Returns the last-seen [`SignedTreeHead`] for the given `log_id`, or `None` if
    /// no STH for that log has been successfully verified by this context yet.
    #[must_use]
    pub fn last_seen(&self, log_id: &[u8; 32]) -> Option<&SignedTreeHead> {
        self.seen_sths.get(log_id)
    }
}
