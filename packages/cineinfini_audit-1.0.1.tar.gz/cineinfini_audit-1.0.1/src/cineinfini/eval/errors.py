"""Error metrics (RMSE, MAE) with bootstrap confidence intervals.

Same contract as :mod:`.correlations`: validate, compute, bootstrap.
We do *not* compute "MOS-scale" RMSE without an explicit prediction-to-
MOS mapping (see :mod:`.calibration`); raw RMSE on un-aligned scales is
meaningless. The user is expected to call :func:`fit_logistic_4p` first
when comparing across datasets.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Optional

import numpy as np

from .correlations import _validate_pair, bootstrap_ci


@dataclass
class ErrorResult:
    value: float
    ci_low: float
    ci_high: float
    n: int
    method: str
    n_bootstrap: int = 0
    confidence_level: float = 0.95

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    def __str__(self) -> str:
        return (
            f"{self.method}={self.value:.4f} "
            f"[{self.ci_low:.4f}, {self.ci_high:.4f}] (n={self.n})"
        )


def _rmse(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.sqrt(np.mean((a - b) ** 2)))


def _mae(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.mean(np.abs(a - b)))


def rmse(predictions, targets, *, n_bootstrap: int = 1000,
         confidence_level: float = 0.95,
         seed: Optional[int] = 42) -> ErrorResult:
    """Root-mean-squared error with bootstrap CI."""
    p, t = _validate_pair(predictions, targets)
    val = _rmse(p, t)
    low, high = bootstrap_ci(p, t, _rmse,
                             n_bootstrap=n_bootstrap,
                             confidence_level=confidence_level, seed=seed)
    return ErrorResult(value=val, ci_low=low, ci_high=high, n=len(p),
                       method="RMSE", n_bootstrap=n_bootstrap,
                       confidence_level=confidence_level)


def mae(predictions, targets, *, n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        seed: Optional[int] = 42) -> ErrorResult:
    """Mean absolute error with bootstrap CI."""
    p, t = _validate_pair(predictions, targets)
    val = _mae(p, t)
    low, high = bootstrap_ci(p, t, _mae,
                             n_bootstrap=n_bootstrap,
                             confidence_level=confidence_level, seed=seed)
    return ErrorResult(value=val, ci_low=low, ci_high=high, n=len(p),
                       method="MAE", n_bootstrap=n_bootstrap,
                       confidence_level=confidence_level)


__all__ = ["rmse", "mae", "ErrorResult"]
