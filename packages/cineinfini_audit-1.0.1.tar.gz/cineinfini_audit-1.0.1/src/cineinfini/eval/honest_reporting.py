"""Tier A/B/C claim classification, reviewer-risk detection, and
deterministic Markdown reporting.

Mission
-------
Transform a list of evaluation results (typically built from
:func:`cineinfini.eval.evaluate_predictions` outputs) into a
reviewer-safe Markdown report that:

1. classifies each claim into Tier A / B / C using *declarative*,
   *auditable* rules (no hidden heuristics, no ML);
2. detects mechanical reviewer-risk patterns (CI overlapping null,
   small samples, single-dataset strong claims, missing FDR, etc.);
3. emits a fully deterministic Markdown report (same inputs → same
   bytes, byte-identical between runs).

What this module does NOT do
----------------------------
* compute statistics (that lives in ``correlations.py`` /
  ``significance.py`` / ``runner.py``);
* read or write files (the caller persists the Markdown);
* call out to a network or LLM;
* mutate any data — every dataclass is frozen.

This file is the implementation of the spec validated for v1.0.0
phase 2.1 (priority #1). It carries ``__status__ = "staging"`` until
two real-world uses confirm the tiering and risk thresholds; promotion
to ``"stable"`` is a documentation change, not a code change.
"""
from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence

__status__ = "staging"
__version__ = "1.0.0"


# ---------------------------------------------------------------------------
# Tier enum
# ---------------------------------------------------------------------------

class ClaimTier(str, Enum):
    """Three-tier honesty hierarchy used across CineInfini docs.

    The string values are kept short (one letter) so that JSON
    serialization produces compact, human-readable output.
    """

    A = "A"  # Validated
    B = "B"  # Conditional
    C = "C"  # Speculative


# ---------------------------------------------------------------------------
# Tiering policy (parameterizable, but defaults are frozen and documented)
# ---------------------------------------------------------------------------

#: Minimum sample size for a claim to be eligible for Tier A.
#: Reference: bootstrap CIs become unreliable for very small n
#: (Efron & Tibshirani 1993, "An Introduction to the Bootstrap"). 50
#: is the conventional floor in MOS-correlation literature.
DEFAULT_MIN_N_FOR_TIER_A: int = 50

#: Maximum p-value for a claim to be eligible for Tier A. Stricter
#: than the conventional 0.05 because we do not (here) apply FDR
#: correction across the claims of a single report.
DEFAULT_MAX_P_FOR_TIER_A: float = 0.01

#: Minimum independent replications for Tier A.
DEFAULT_MIN_REPLICATIONS_FOR_TIER_A: int = 2

#: Effect-size sanity check: an unreplicated correlation above this
#: magnitude should be flagged as suspicious (more likely a bug than
#: a real finding).
UNREALISTIC_CORRELATION_THRESHOLD: float = 0.95

#: Minimum number of p-value-bearing claims in a single report
#: before we flag missing FDR correction as a low-severity risk.
MIN_PVALUES_BEFORE_FDR_RISK: int = 3


@dataclass(frozen=True)
class TieringPolicy:
    """Parameterizable thresholds. Defaults are frozen by convention."""
    min_n_for_tier_a: int = DEFAULT_MIN_N_FOR_TIER_A
    max_p_for_tier_a: float = DEFAULT_MAX_P_FOR_TIER_A
    min_replications_for_tier_a: int = DEFAULT_MIN_REPLICATIONS_FOR_TIER_A
    unrealistic_correlation_threshold: float = UNREALISTIC_CORRELATION_THRESHOLD


DEFAULT_POLICY = TieringPolicy()

#: Allowed values of ``ClaimEvidence.effect_kind``.
ALLOWED_EFFECT_KINDS = frozenset({
    "correlation", "error", "classification", "fraction",
})


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def _is_finite(x: Any) -> bool:
    """True iff x is a real number that is neither NaN nor +/-inf."""
    return isinstance(x, (int, float)) and math.isfinite(float(x))


def _md_escape(text: str) -> str:
    """Escape characters that would break a Markdown table cell.

    We only escape what's strictly necessary inside a table cell:
    pipe, backtick, backslash. The Markdown body uses lists and
    paragraphs, not raw HTML, so we don't need full sanitization.
    """
    if not isinstance(text, str):
        text = str(text)
    return (
        text.replace("\\", "\\\\")
            .replace("|", "\\|")
            .replace("`", "\\`")
            .replace("\n", " ")
    )


# ---------------------------------------------------------------------------
# Core dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ClaimEvidence:
    """Numeric evidence backing one claim.

    All fields are explicit so the tiering rules can inspect them
    deterministically. ``__post_init__`` validates fail-fast: a NaN
    estimate or an inverted CI raises ``ValueError`` *here*, not three
    files away when something downstream divides by zero.

    Parameters
    ----------
    point_estimate : float
        The headline number (e.g. SRCC = 0.563).
    ci_low, ci_high : float, optional
        Bootstrap (or otherwise) CI bounds. Both required together.
    n : int, optional
        Sample size used to compute ``point_estimate``. Required for
        Tier A eligibility but not for Tier C claims.
    p_value : float, optional
        Two-sided p-value. Must be in [0, 1] when given.
    effect_kind : str
        One of ``correlation``, ``error``, ``classification``,
        ``fraction``. Determines how Rule R-A2 is interpreted.
    notes : list of str
        Free-form caveats; appended verbatim to the Markdown.
    """
    point_estimate: float
    ci_low: Optional[float] = None
    ci_high: Optional[float] = None
    n: Optional[int] = None
    p_value: Optional[float] = None
    effect_kind: str = "correlation"
    notes: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not _is_finite(self.point_estimate):
            raise ValueError(
                f"point_estimate must be finite; got {self.point_estimate!r}"
            )
        if self.effect_kind not in ALLOWED_EFFECT_KINDS:
            raise ValueError(
                f"effect_kind must be one of {sorted(ALLOWED_EFFECT_KINDS)}; "
                f"got {self.effect_kind!r}"
            )
        # CI: both must be present, both finite, low <= high.
        if (self.ci_low is None) != (self.ci_high is None):
            raise ValueError(
                "ci_low and ci_high must be both None or both provided; "
                f"got ci_low={self.ci_low!r}, ci_high={self.ci_high!r}"
            )
        if self.ci_low is not None:
            if not (_is_finite(self.ci_low) and _is_finite(self.ci_high)):
                raise ValueError(
                    f"CI bounds must be finite; got "
                    f"[{self.ci_low!r}, {self.ci_high!r}]"
                )
            if self.ci_low > self.ci_high:
                raise ValueError(
                    f"ci_low ({self.ci_low}) > ci_high ({self.ci_high})"
                )
        # n
        if self.n is not None:
            if not isinstance(self.n, int) or self.n <= 0:
                raise ValueError(f"n must be a positive int; got {self.n!r}")
        # p-value
        if self.p_value is not None:
            if not _is_finite(self.p_value):
                raise ValueError(
                    f"p_value must be finite; got {self.p_value!r}"
                )
            if not (0.0 <= self.p_value <= 1.0):
                raise ValueError(
                    f"p_value must be in [0, 1]; got {self.p_value!r}"
                )


@dataclass(frozen=True)
class Claim:
    """A single claim with its evidence and metadata.

    Parameters
    ----------
    claim_id : str
        Stable, lowercase, snake_case identifier. Used to cross-
        reference from risks; must be unique within a report.
    statement : str
        Plain English statement of the claim, ≤ 200 chars. Pipes are
        Markdown-escaped automatically.
    evidence : ClaimEvidence
        Numeric backing.
    dataset : str, optional
        Human-readable dataset name (e.g. ``"KoNViD-1k (n=392)"``).
    n_replications : int
        Number of *independent* datasets on which the claim has been
        confirmed. Defaults to 1; needs ≥ 2 for Tier A.
    requires_external_rerun : bool
        True if the claim compares against an externally-reported SOTA
        number that has not been re-run locally. Such claims cannot
        be Tier A.
    """
    claim_id: str
    statement: str
    evidence: ClaimEvidence
    dataset: Optional[str] = None
    n_replications: int = 1
    requires_external_rerun: bool = False

    def __post_init__(self) -> None:
        if not self.claim_id or not isinstance(self.claim_id, str):
            raise ValueError(f"claim_id must be a non-empty string; got {self.claim_id!r}")
        if not self.statement or not isinstance(self.statement, str):
            raise ValueError("statement must be a non-empty string")
        if len(self.statement) > 200:
            raise ValueError(
                f"statement too long ({len(self.statement)} chars); "
                f"keep it ≤ 200 chars for review readability"
            )
        if not isinstance(self.n_replications, int) or self.n_replications < 1:
            raise ValueError(
                f"n_replications must be an int ≥ 1; got {self.n_replications!r}"
            )


@dataclass(frozen=True)
class TieredClaim:
    """Output of :func:`tier_claim`: a claim with its assigned tier
    and a list of which rule IDs fired during the decision."""
    claim: Claim
    assigned_tier: ClaimTier
    rules_triggered: List[str]
    softening_suggestion: Optional[str] = None


@dataclass(frozen=True)
class ReviewerRisk:
    """A potential reviewer objection identified mechanically.

    ``severity`` is a totally-ordered string in ``high > medium > low``;
    we sort risks by (severity, risk_id) for stable Markdown rendering.
    """
    risk_id: str
    severity: str  # "low" | "medium" | "high"
    affected_claim_ids: List[str]
    description: str
    mitigation: str

    def __post_init__(self) -> None:
        if self.severity not in ("low", "medium", "high"):
            raise ValueError(
                f"severity must be 'low', 'medium', or 'high'; "
                f"got {self.severity!r}"
            )


# ---------------------------------------------------------------------------
# Tiering rules — declarative, auditable
# ---------------------------------------------------------------------------

# Rule registry kept in module-level dicts so the appendix can render
# them verbatim without duplicating text. Touching these dicts changes
# both the logic AND the documentation in lock-step.

_RULE_DESCRIPTIONS: Dict[str, str] = {
    # Tier A entry conditions
    "R-A1": "Both ci_low and ci_high are provided.",
    "R-A2": (
        "For correlation: CI excludes zero (ci_low > 0 or ci_high < 0). "
        "For classification/fraction: ci_low > 0.5. "
        "For error: always satisfied (no zero-exclusion semantics)."
    ),
    "R-A3": f"Sample size n ≥ {DEFAULT_MIN_N_FOR_TIER_A}.",
    "R-A4": f"p-value provided AND p < {DEFAULT_MAX_P_FOR_TIER_A}.",
    "R-A5": (
        f"At least {DEFAULT_MIN_REPLICATIONS_FOR_TIER_A} independent "
        f"replications (n_replications)."
    ),
    "R-A6": "Claim does not depend on an externally-reported SOTA number "
            "that was not locally re-run.",
    # Tier C breakdown
    "R-C1": "CI is missing.",
    "R-C2": "CI includes the null value (zero for correlations, 0.5 for "
            "classification, etc.).",
    "R-C3": f"n is missing or < {DEFAULT_MIN_N_FOR_TIER_A}.",
    "R-C4": f"p-value is missing or ≥ {DEFAULT_MAX_P_FOR_TIER_A}.",
    "R-C5": "No replication AND no CI.",
}


def _rule_R_A1(claim: Claim) -> bool:
    e = claim.evidence
    return e.ci_low is not None and e.ci_high is not None


def _rule_R_A2(claim: Claim, policy: TieringPolicy) -> bool:
    """CI excludes the null value for the given effect kind.

    The semantics of "null" depend on ``effect_kind``:

    * ``correlation``  → null = 0  (CI must be entirely above or below)
    * ``classification``, ``fraction`` → null = 0.5 (random binary
      baseline). For multi-class the user should supply a custom
      threshold via ``notes`` — we conservatively assume 0.5.
    * ``error`` → no zero-exclusion semantics (RMSE/MAE are ≥ 0); we
      return True because R-A2 is moot for error metrics.
    """
    e = claim.evidence
    if e.ci_low is None or e.ci_high is None:
        return False
    if e.effect_kind == "correlation":
        return e.ci_low > 0.0 or e.ci_high < 0.0
    if e.effect_kind in ("classification", "fraction"):
        return e.ci_low > 0.5
    if e.effect_kind == "error":
        return True
    # Should be unreachable thanks to ClaimEvidence validator.
    return False


def _rule_R_A3(claim: Claim, policy: TieringPolicy) -> bool:
    return claim.evidence.n is not None and claim.evidence.n >= policy.min_n_for_tier_a


def _rule_R_A4(claim: Claim, policy: TieringPolicy) -> bool:
    p = claim.evidence.p_value
    return p is not None and p < policy.max_p_for_tier_a


def _rule_R_A5(claim: Claim, policy: TieringPolicy) -> bool:
    return claim.n_replications >= policy.min_replications_for_tier_a


def _rule_R_A6(claim: Claim) -> bool:
    return not claim.requires_external_rerun


def _evaluate_tier_a_rules(
    claim: Claim, policy: TieringPolicy,
) -> Dict[str, bool]:
    """Run all six Tier A rules; return ID → bool."""
    return {
        "R-A1": _rule_R_A1(claim),
        "R-A2": _rule_R_A2(claim, policy),
        "R-A3": _rule_R_A3(claim, policy),
        "R-A4": _rule_R_A4(claim, policy),
        "R-A5": _rule_R_A5(claim, policy),
        "R-A6": _rule_R_A6(claim),
    }


def _diagnose_tier_c(claim: Claim, policy: TieringPolicy) -> List[str]:
    """Return the list of R-C* IDs that explain why a claim is Tier C.

    Multiple may fire simultaneously (e.g. small sample AND missing CI).
    """
    failures: List[str] = []
    e = claim.evidence
    if e.ci_low is None or e.ci_high is None:
        failures.append("R-C1")
    elif e.effect_kind == "correlation":
        if not (e.ci_low > 0.0 or e.ci_high < 0.0):
            failures.append("R-C2")
    elif e.effect_kind in ("classification", "fraction"):
        if not (e.ci_low > 0.5):
            failures.append("R-C2")
    if e.n is None or e.n < policy.min_n_for_tier_a:
        failures.append("R-C3")
    if e.p_value is None or e.p_value >= policy.max_p_for_tier_a:
        failures.append("R-C4")
    if claim.n_replications == 1 and (e.ci_low is None or e.ci_high is None):
        failures.append("R-C5")
    return failures


def _softening_suggestion(claim: Claim, c_rules: List[str]) -> Optional[str]:
    """Build a single-sentence softening suggestion from the Tier C
    rule(s) that fired. Deterministic given the same input."""
    parts: List[str] = []
    if "R-C1" in c_rules:
        parts.append("attach a 1000-resample bootstrap 95% CI before claiming")
    if "R-C2" in c_rules:
        parts.append(
            "soften from \"X is correlated with Y\" to \"X may be correlated"
            " with Y; CI overlaps the null\""
        )
    if "R-C3" in c_rules:
        parts.append("either collect more data or downgrade to a pilot finding")
    if "R-C4" in c_rules:
        parts.append("report the p-value explicitly and note non-significance")
    if "R-C5" in c_rules:
        parts.append("replicate on a second dataset before any strong wording")
    if not parts:
        return None
    return "Consider: " + "; ".join(parts) + "."


# ---------------------------------------------------------------------------
# Public tiering API
# ---------------------------------------------------------------------------

def tier_claim(claim: Claim, *,
               policy: TieringPolicy = DEFAULT_POLICY) -> TieredClaim:
    """Apply the Tier A/B/C rule engine to a single claim.

    Returns
    -------
    TieredClaim
        Frozen result with the assigned tier, the list of rule IDs
        that fired, and (for Tier C) a softening suggestion.
    """
    a_results = _evaluate_tier_a_rules(claim, policy)
    a_passing = [rid for rid, ok in a_results.items() if ok]
    a_failing = [rid for rid, ok in a_results.items() if not ok]

    # Tier A iff all six pass.
    if not a_failing:
        return TieredClaim(
            claim=claim,
            assigned_tier=ClaimTier.A,
            rules_triggered=sorted(a_passing),
            softening_suggestion=None,
        )

    # Tier B iff R-A1..R-A4 pass and the only failures are R-A5/R-A6.
    core_a = {"R-A1", "R-A2", "R-A3", "R-A4"}
    if core_a.issubset(set(a_passing)):
        return TieredClaim(
            claim=claim,
            assigned_tier=ClaimTier.B,
            rules_triggered=sorted(a_passing) + ["missing:" + r for r in sorted(a_failing)],
            softening_suggestion=None,
        )

    # Tier C: diagnose which R-C* rules fire.
    c_rules = _diagnose_tier_c(claim, policy)
    return TieredClaim(
        claim=claim,
        assigned_tier=ClaimTier.C,
        rules_triggered=c_rules,
        softening_suggestion=_softening_suggestion(claim, c_rules),
    )


# ---------------------------------------------------------------------------
# Reviewer-risk detectors — each is independent and commutative
# ---------------------------------------------------------------------------

def _risk_ci_overlaps_null(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    affected: List[str] = []
    for c in claims:
        e = c.evidence
        if e.ci_low is None or e.ci_high is None:
            continue
        if e.effect_kind == "correlation":
            if e.ci_low <= 0.0 <= e.ci_high:
                affected.append(c.claim_id)
        elif e.effect_kind in ("classification", "fraction"):
            if e.ci_low <= 0.5 <= e.ci_high:
                affected.append(c.claim_id)
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="ci_overlaps_null",
        severity="high",
        affected_claim_ids=affected,
        description=(
            "Confidence interval(s) include the null value, undermining "
            "any directional claim."
        ),
        mitigation=(
            "Either widen the sample to tighten the CI, or explicitly "
            "soften the claim wording (\"may correlate\" instead of "
            "\"correlates\")."
        ),
    )


def _risk_small_sample(claims: Sequence[Claim],
                       policy: TieringPolicy) -> Optional[ReviewerRisk]:
    affected = [
        c.claim_id for c in claims
        if c.evidence.n is not None and c.evidence.n < policy.min_n_for_tier_a
    ]
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="small_sample",
        severity="medium",
        affected_claim_ids=affected,
        description=(
            f"Sample size below n={policy.min_n_for_tier_a}: "
            "bootstrap CIs are wide, statistical power is low."
        ),
        mitigation=(
            "Treat as exploratory pilot finding; collect more data or "
            "downgrade to Tier C wording."
        ),
    )


def _risk_single_dataset_strong_claim(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    affected = [c.claim_id for c in claims if c.n_replications == 1]
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="single_dataset_strong_claim",
        severity="medium",
        affected_claim_ids=affected,
        description=(
            "Result rests on a single dataset; generalization across "
            "regimes (natural / AIGC / cinema) is not demonstrated."
        ),
        mitigation=(
            "Replicate the protocol on a second dataset of a different "
            "regime before claiming generalization."
        ),
    )


def _risk_external_sota_no_local_rerun(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    affected = [c.claim_id for c in claims if c.requires_external_rerun]
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="external_sota_no_local_rerun",
        severity="high",
        affected_claim_ids=affected,
        description=(
            "Comparison relies on externally-reported SOTA numbers that "
            "have not been re-run locally on the same splits."
        ),
        mitigation=(
            "Re-run the SOTA baseline locally on the same train/test "
            "splits, or scope the claim explicitly as \"paper-reported, "
            "not directly comparable\"."
        ),
    )


def _risk_missing_ci(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    affected = [
        c.claim_id for c in claims
        if c.evidence.ci_low is None or c.evidence.ci_high is None
    ]
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="missing_ci",
        severity="high",
        affected_claim_ids=affected,
        description=(
            "Claim is reported as a point estimate without a confidence "
            "interval; modern reviewers expect a bootstrap or analytic CI."
        ),
        mitigation=(
            "Compute a 1000-resample percentile bootstrap via "
            "cineinfini.eval.evaluate_predictions and attach ci_low/ci_high."
        ),
    )


def _risk_p_value_without_correction(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    """Flag if ≥3 claims carry p-values and none mention FDR/Bonferroni.

    We look for the substrings ``"FDR"``, ``"Bonferroni"`` (case-
    insensitive) in any claim's statement or in any ``ClaimEvidence``
    note.
    """
    p_claims = [c for c in claims if c.evidence.p_value is not None]
    if len(p_claims) < MIN_PVALUES_BEFORE_FDR_RISK:
        return None
    haystack = " ".join(
        [c.statement for c in claims]
        + [n for c in claims for n in c.evidence.notes]
    ).lower()
    if "fdr" in haystack or "bonferroni" in haystack or "benjamini" in haystack:
        return None
    return ReviewerRisk(
        risk_id="p_value_without_correction",
        severity="low",
        affected_claim_ids=[c.claim_id for c in p_claims],
        description=(
            f"{len(p_claims)} p-values reported without any mention of "
            "multiple-comparison correction (FDR / Bonferroni)."
        ),
        mitigation=(
            "Apply Benjamini-Hochberg FDR across the family of p-values "
            "and report the corrected q-values, or explicitly note that "
            "the family is too small to require correction."
        ),
    )


def _risk_unrealistic_effect_size(claims: Sequence[Claim],
                                  policy: TieringPolicy) -> Optional[ReviewerRisk]:
    affected: List[str] = []
    for c in claims:
        if c.evidence.effect_kind != "correlation":
            continue
        if c.n_replications >= policy.min_replications_for_tier_a:
            continue
        if abs(c.evidence.point_estimate) > policy.unrealistic_correlation_threshold:
            affected.append(c.claim_id)
    if not affected:
        return None
    return ReviewerRisk(
        risk_id="unrealistic_effect_size",
        severity="medium",
        affected_claim_ids=affected,
        description=(
            "Unreplicated correlation magnitude above "
            f"{policy.unrealistic_correlation_threshold}; on real-world "
            "MOS data this is more often a leakage / shuffle / "
            "feature-target overlap bug than a genuine finding."
        ),
        mitigation=(
            "Audit the train/test split, check for label leakage, and "
            "replicate on an independent dataset before publishing."
        ),
    )


def _risk_inconsistent_n_across_claims(claims: Sequence[Claim]) -> Optional[ReviewerRisk]:
    ns = [c.evidence.n for c in claims if c.evidence.n is not None]
    if len(ns) < 2:
        return None
    if max(ns) <= 2 * min(ns):
        return None
    affected = [c.claim_id for c in claims if c.evidence.n is not None]
    return ReviewerRisk(
        risk_id="inconsistent_n_across_claims",
        severity="low",
        affected_claim_ids=affected,
        description=(
            f"Sample sizes vary by more than 2× across claims "
            f"(min={min(ns)}, max={max(ns)}). Cross-claim comparisons "
            "may be confounded by power differences."
        ),
        mitigation=(
            "When comparing claims, restrict to the smallest common "
            "subsample, or report effect sizes with their CIs side-by-side."
        ),
    )


_ALL_RISK_DETECTORS = [
    "ci_overlaps_null",
    "small_sample",
    "single_dataset_strong_claim",
    "external_sota_no_local_rerun",
    "missing_ci",
    "p_value_without_correction",
    "unrealistic_effect_size",
    "inconsistent_n_across_claims",
]


def detect_reviewer_risks(
    claims: Sequence[Claim],
    *,
    policy: TieringPolicy = DEFAULT_POLICY,
) -> List[ReviewerRisk]:
    """Run all eight detectors and return the risks that fired.

    The order of returned risks is: by severity (high → medium → low),
    then lexicographic by ``risk_id``. This is what
    :meth:`HonestReport.to_markdown` relies on for deterministic output.
    """
    raw = [
        _risk_ci_overlaps_null(claims),
        _risk_small_sample(claims, policy),
        _risk_single_dataset_strong_claim(claims),
        _risk_external_sota_no_local_rerun(claims),
        _risk_missing_ci(claims),
        _risk_p_value_without_correction(claims),
        _risk_unrealistic_effect_size(claims, policy),
        _risk_inconsistent_n_across_claims(claims),
    ]
    risks = [r for r in raw if r is not None]
    severity_order = {"high": 0, "medium": 1, "low": 2}
    risks.sort(key=lambda r: (severity_order[r.severity], r.risk_id))
    return risks


# ---------------------------------------------------------------------------
# HonestReport
# ---------------------------------------------------------------------------

@dataclass
class HonestReport:
    """Complete report. Pickle-/JSON-serializable; rendered to
    Markdown via :meth:`to_markdown`."""
    title: str
    generated_at_utc: str
    tiered_claims: List[TieredClaim]
    risks: List[ReviewerRisk]
    summary_counts: Dict[str, int]
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        # We use dataclasses.asdict on a shallow copy because the
        # nested frozen dataclasses serialize cleanly via that path.
        return {
            "title": self.title,
            "generated_at_utc": self.generated_at_utc,
            "tiered_claims": [
                {
                    "claim": dataclasses.asdict(tc.claim),
                    "assigned_tier": tc.assigned_tier.value,
                    "rules_triggered": list(tc.rules_triggered),
                    "softening_suggestion": tc.softening_suggestion,
                }
                for tc in self.tiered_claims
            ],
            "risks": [dataclasses.asdict(r) for r in self.risks],
            "summary_counts": dict(self.summary_counts),
            "notes": list(self.notes),
        }

    def to_markdown(self, *, include_appendix: bool = True) -> str:
        return _render_markdown(self, include_appendix=include_appendix)


def build_honest_report(
    claims: Sequence[Claim],
    *,
    title: str = "CineInfini — Honest Report",
    extra_notes: Optional[Sequence[str]] = None,
    policy: TieringPolicy = DEFAULT_POLICY,
    now: Optional[datetime] = None,
) -> HonestReport:
    """Tier every claim, detect risks, return a deterministic report.

    Parameters
    ----------
    claims : sequence of Claim
        Claim list. Must have unique ``claim_id`` values.
    title : str
        Report title (Markdown H1).
    extra_notes : sequence of str, optional
        Additional notes appended to the summary section.
    policy : TieringPolicy
        Threshold overrides (defaults are documented and frozen).
    now : datetime, optional
        Used by tests to pin the timestamp; defaults to
        ``datetime.now(timezone.utc)``.

    Returns
    -------
    HonestReport
    """
    seen: set = set()
    for c in claims:
        if c.claim_id in seen:
            raise ValueError(
                f"duplicate claim_id {c.claim_id!r}; report claim_ids must be unique"
            )
        seen.add(c.claim_id)

    tiered = [tier_claim(c, policy=policy) for c in claims]
    risks = detect_reviewer_risks(claims, policy=policy)

    counts = {"tier_A": 0, "tier_B": 0, "tier_C": 0}
    for tc in tiered:
        counts[f"tier_{tc.assigned_tier.value}"] += 1

    if now is None:
        now = datetime.now(timezone.utc)
    ts = now.astimezone(timezone.utc).isoformat()

    return HonestReport(
        title=title,
        generated_at_utc=ts,
        tiered_claims=tiered,
        risks=risks,
        summary_counts=counts,
        notes=list(extra_notes) if extra_notes else [],
    )


# ---------------------------------------------------------------------------
# Adapter from evaluate_predictions output
# ---------------------------------------------------------------------------

_EVAL_METRIC_PATHS = {
    "srcc": ("srcc", "correlation"),
    "krcc": ("krcc", "correlation"),
    "plcc_fitted": ("plcc_fitted", "correlation"),
    "rmse_fitted": ("rmse_fitted", "error"),
}


def claim_from_evaluation_report(
    eval_report: Dict[str, Any],
    *,
    claim_id: str,
    statement: str,
    dataset: Optional[str] = None,
    use_metric: str = "srcc",
    n_replications: int = 1,
    requires_external_rerun: bool = False,
) -> Claim:
    """Build a :class:`Claim` from an :func:`evaluate_predictions`
    output (typically ``rep.to_dict()``).

    The user explicitly states which metric of the report (``srcc``,
    ``krcc``, ``plcc_fitted`` or ``rmse_fitted``) the claim is about.
    No magic: pick the wrong metric and you get a wrong-but-honest
    claim, not a silently-correct one.
    """
    if use_metric not in _EVAL_METRIC_PATHS:
        raise KeyError(
            f"use_metric must be one of {sorted(_EVAL_METRIC_PATHS)}; "
            f"got {use_metric!r}"
        )
    metric_key, effect_kind = _EVAL_METRIC_PATHS[use_metric]
    if metric_key not in eval_report:
        raise KeyError(
            f"eval_report missing key {metric_key!r}; "
            f"available top-level keys: {sorted(eval_report.keys())}"
        )
    sub = eval_report[metric_key]
    # ErrorResult and CorrelationResult share the same ci_low/ci_high
    # field names; CorrelationResult uses 'coefficient', ErrorResult
    # uses 'value'.
    if "coefficient" in sub:
        point = float(sub["coefficient"])
    elif "value" in sub:
        point = float(sub["value"])
    else:
        raise KeyError(
            f"eval_report[{metric_key!r}] missing 'coefficient' or 'value'; "
            f"got keys {sorted(sub.keys())}"
        )
    n = int(sub.get("n", eval_report.get("n", 0))) or None
    p_value = sub.get("p_value")
    p_value = float(p_value) if p_value is not None else None
    ci_low = sub.get("ci_low")
    ci_high = sub.get("ci_high")
    # NaN bounds happen when bootstrap couldn't compute; treat as missing.
    if ci_low is not None and not _is_finite(ci_low):
        ci_low = None
    if ci_high is not None and not _is_finite(ci_high):
        ci_high = None
    if (ci_low is None) != (ci_high is None):
        ci_low = None
        ci_high = None
    evidence = ClaimEvidence(
        point_estimate=point,
        ci_low=float(ci_low) if ci_low is not None else None,
        ci_high=float(ci_high) if ci_high is not None else None,
        n=n,
        p_value=p_value,
        effect_kind=effect_kind,
        notes=[],
    )
    return Claim(
        claim_id=claim_id,
        statement=statement,
        evidence=evidence,
        dataset=dataset,
        n_replications=n_replications,
        requires_external_rerun=requires_external_rerun,
    )


# ---------------------------------------------------------------------------
# Markdown rendering — fully deterministic
# ---------------------------------------------------------------------------

def _format_estimate_line(e: ClaimEvidence) -> str:
    """Render the evidence one-liner used in each claim's bullet list."""
    if e.effect_kind == "error":
        head = f"{e.effect_kind} = {e.point_estimate:.4f}"
    else:
        head = f"{e.effect_kind} = {e.point_estimate:+.4f}"
    if e.ci_low is not None and e.ci_high is not None:
        if e.effect_kind == "error":
            head += f" [{e.ci_low:.4f}, {e.ci_high:.4f}]"
        else:
            head += f" [{e.ci_low:+.4f}, {e.ci_high:+.4f}]"
    if e.n is not None:
        head += f", n={e.n}"
    if e.p_value is not None:
        head += f", p={e.p_value:.2e}"
    return head


def _render_appendix() -> str:
    lines = ["## Appendix — Tiering rules reference", ""]
    lines.append("### Tier A entry conditions (all must be satisfied)")
    lines.append("")
    for rid in ("R-A1", "R-A2", "R-A3", "R-A4", "R-A5", "R-A6"):
        lines.append(f"- **{rid}** — {_RULE_DESCRIPTIONS[rid]}")
    lines.append("")
    lines.append("### Tier B")
    lines.append("")
    lines.append(
        "- R-A1 through R-A4 satisfied, but R-A5 (replication) "
        "or R-A6 (no external SOTA) fails."
    )
    lines.append("")
    lines.append("### Tier C diagnostics")
    lines.append("")
    for rid in ("R-C1", "R-C2", "R-C3", "R-C4", "R-C5"):
        lines.append(f"- **{rid}** — {_RULE_DESCRIPTIONS[rid]}")
    lines.append("")
    lines.append("### Risk detectors")
    lines.append("")
    for rid in _ALL_RISK_DETECTORS:
        lines.append(f"- `{rid}`")
    lines.append("")
    return "\n".join(lines)


def _render_claims_section(
    title: str, tcs: List[TieredClaim], with_softening: bool,
) -> str:
    if not tcs:
        return ""
    out = [f"## {title}", ""]
    for tc in tcs:
        c = tc.claim
        ds = c.dataset if c.dataset else "no dataset"
        out.append(f"### {_md_escape(c.claim_id)} — {_md_escape(ds)}")
        out.append("")
        out.append(f"> {_md_escape(c.statement)}")
        out.append("")
        out.append(f"- **Evidence:** {_format_estimate_line(c.evidence)}")
        out.append(f"- **Replications:** {c.n_replications} dataset(s)")
        if tc.rules_triggered:
            out.append(
                "- **Rules triggered:** "
                + ", ".join(_md_escape(r) for r in tc.rules_triggered)
            )
        if c.requires_external_rerun:
            out.append("- **External SOTA rerun pending:** yes")
        if c.evidence.notes:
            out.append("- **Notes:**")
            for n in c.evidence.notes:
                out.append(f"    - {_md_escape(n)}")
        if with_softening and tc.softening_suggestion:
            out.append(f"- **Softening suggestion:** {_md_escape(tc.softening_suggestion)}")
        out.append("")
    return "\n".join(out)


def _render_risks_section(risks: List[ReviewerRisk]) -> str:
    if not risks:
        return ""
    out = ["## Reviewer-risk inventory", ""]
    by_sev: Dict[str, List[ReviewerRisk]] = {"high": [], "medium": [], "low": []}
    for r in risks:
        by_sev[r.severity].append(r)
    for sev in ("high", "medium", "low"):
        items = by_sev[sev]
        if not items:
            continue
        out.append(f"### {sev.upper()}")
        out.append("")
        for r in items:
            out.append(f"#### `{r.risk_id}`")
            out.append("")
            out.append(
                "- **Affects:** "
                + ", ".join(_md_escape(cid) for cid in r.affected_claim_ids)
            )
            out.append(f"- **Description:** {_md_escape(r.description)}")
            out.append(f"- **Mitigation:** {_md_escape(r.mitigation)}")
            out.append("")
    return "\n".join(out)


def _render_markdown(report: HonestReport, *, include_appendix: bool) -> str:
    parts: List[str] = []
    parts.append(f"# {report.title}")
    parts.append("")
    parts.append(f"*Generated {report.generated_at_utc}.*")
    parts.append("")
    parts.append("## Summary")
    parts.append("")
    parts.append("| Tier | Count | What it means |")
    parts.append("|---|---|---|")
    parts.append(
        f"| **A** | {report.summary_counts.get('tier_A', 0)} | "
        f"Validated: CI excludes null, n≥{DEFAULT_MIN_N_FOR_TIER_A}, "
        f"p<{DEFAULT_MAX_P_FOR_TIER_A}, ≥{DEFAULT_MIN_REPLICATIONS_FOR_TIER_A} replications |"
    )
    parts.append(
        f"| **B** | {report.summary_counts.get('tier_B', 0)} | "
        "Conditional: same evidence as A but single dataset |"
    )
    parts.append(
        f"| **C** | {report.summary_counts.get('tier_C', 0)} | "
        "Speculative: weak evidence, see softening suggestions |"
    )
    parts.append("")
    if report.notes:
        parts.append("### Notes")
        parts.append("")
        for n in report.notes:
            parts.append(f"- {_md_escape(n)}")
        parts.append("")
    if not report.tiered_claims:
        parts.append("*No claims provided.*")
        parts.append("")

    by_tier: Dict[ClaimTier, List[TieredClaim]] = {
        ClaimTier.A: [], ClaimTier.B: [], ClaimTier.C: [],
    }
    for tc in report.tiered_claims:
        by_tier[tc.assigned_tier].append(tc)
    parts.append(_render_claims_section(
        "Tier A — Validated claims", by_tier[ClaimTier.A], with_softening=False))
    parts.append(_render_claims_section(
        "Tier B — Conditional claims", by_tier[ClaimTier.B], with_softening=False))
    parts.append(_render_claims_section(
        "Tier C — Speculative claims", by_tier[ClaimTier.C], with_softening=True))

    parts.append(_render_risks_section(report.risks))

    if include_appendix:
        parts.append(_render_appendix())

    # Collapse runs of blank lines and ensure trailing newline.
    body = "\n".join(p for p in parts if p is not None)
    while "\n\n\n" in body:
        body = body.replace("\n\n\n", "\n\n")
    if not body.endswith("\n"):
        body += "\n"
    return body


__all__ = [
    "ClaimTier",
    "ClaimEvidence",
    "Claim",
    "TieredClaim",
    "ReviewerRisk",
    "TieringPolicy",
    "DEFAULT_POLICY",
    "HonestReport",
    "tier_claim",
    "detect_reviewer_risks",
    "build_honest_report",
    "claim_from_evaluation_report",
]
