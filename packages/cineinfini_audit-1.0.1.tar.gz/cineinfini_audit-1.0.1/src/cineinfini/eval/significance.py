"""Significance tests for VQA / MOS evaluation.

Three families of tests live here, organised by usage pattern:

1. **Paired-correlation comparison** — :func:`steiger_z`.
   When papers claim "metric A correlates better with MOS than metric B",
   the right test is Steiger's Z₁* for two dependent correlations
   sharing a variable (here, the MOS column). Comparing the two
   bootstrap CIs by themselves underestimates power because the
   correlations are computed on the same subjects.
   Reference: Steiger, J. H. (1980). "Tests for comparing elements of
   a correlation matrix." Psychological Bulletin, 87(2), 245-251.

2. **Two-sample distribution match** — :func:`ks_test_distribution_match`.
   Two-sample Kolmogorov-Smirnov test for whether two empirical samples
   are drawn from the same distribution. Primary use case: verifying a
   subset of a benchmark is MOS-distribution-equivalent to the full
   set (item §3.3 in ``docs/REVIEW_ANALYSIS.md``). The convention is
   the standard one (small p → reject equivalence); a large p means we
   *fail to reject* the null, which is **not** a proof of equivalence.

3. **Multiple-testing correction** — :func:`benjamini_hochberg_fdr`.
   Benjamini-Hochberg step-up FDR correction. Primary use case: the
   sign-flip cross-regime analysis in the paper draft, which generates
   tens of p-values and needs a defensible correction.
   Reference: Benjamini, Y. and Hochberg, Y. (1995). "Controlling the
   False Discovery Rate." Journal of the Royal Statistical Society
   Series B, 57(1):289-300.

Module status: ``"staging"`` — promoted to ``"stable"`` after at least
two real-world uses confirm the implementation matches paper-side
reference outputs.
"""
from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
from scipy.stats import ks_2samp, norm, pearsonr

from .correlations import _validate_pair


__status__ = "staging"
__version__ = "1.1.0"


# ---------------------------------------------------------------------------
# Steiger Z (existing — unchanged for backwards compat)
# ---------------------------------------------------------------------------

@dataclass
class SignificanceResult:
    z_statistic: float
    p_value: float
    r_xy: float
    r_xz: float
    r_yz: float
    n: int
    method: str = "steiger_z"

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    def __str__(self) -> str:
        return (
            f"Steiger Z={self.z_statistic:.4f}, p={self.p_value:.2e} "
            f"(r_xy={self.r_xy:.3f}, r_xz={self.r_xz:.3f}, "
            f"r_yz={self.r_yz:.3f}, n={self.n})"
        )


def steiger_z(metric_a: np.ndarray, metric_b: np.ndarray,
              mos: np.ndarray) -> SignificanceResult:
    """Compare corr(metric_a, mos) vs corr(metric_b, mos) on the same sample.

    Implements Steiger's Z₁* (the "asymptotic" form), which is the
    standard parametric test for two Pearson correlations sharing a
    common variable. We use Pearson here because it has a known
    sampling distribution; a Spearman version would require ranking
    inputs first then applying the same formula on ranks.

    Returns
    -------
    SignificanceResult
        Two-tailed p-value under the null H₀: r(a, mos) = r(b, mos).
    """
    a = np.asarray(metric_a, dtype=np.float64).ravel()
    b = np.asarray(metric_b, dtype=np.float64).ravel()
    z = np.asarray(mos, dtype=np.float64).ravel()
    if not (a.shape == b.shape == z.shape):
        raise ValueError("all three inputs must have the same shape")
    mask = np.isfinite(a) & np.isfinite(b) & np.isfinite(z)
    if mask.sum() < 10:
        raise ValueError(
            f"need ≥10 finite triples for Steiger Z; got {int(mask.sum())}"
        )
    a, b, z = a[mask], b[mask], z[mask]
    n = a.size

    r_xy, _ = pearsonr(a, z)   # metric_a vs mos
    r_xz, _ = pearsonr(b, z)   # metric_b vs mos
    r_yz, _ = pearsonr(a, b)   # metric_a vs metric_b

    # Fisher Z transform on the two correlations of interest.
    z1 = 0.5 * np.log((1 + r_xy) / (1 - r_xy))
    z2 = 0.5 * np.log((1 + r_xz) / (1 - r_xz))
    rm2 = (r_xy ** 2 + r_xz ** 2) / 2.0
    f = (1 - r_yz) / (2 * (1 - rm2))
    h = (1 - f * rm2) / (1 - rm2)
    # Asymptotic standard error of (z1 - z2).
    se = np.sqrt((2 * (1 - r_yz) * h) / (n - 3))
    z_stat = (z1 - z2) / se if se > 0 else float("nan")
    p_two_sided = 2.0 * (1.0 - norm.cdf(abs(z_stat))) if np.isfinite(z_stat) else float("nan")

    return SignificanceResult(
        z_statistic=float(z_stat),
        p_value=float(p_two_sided),
        r_xy=float(r_xy), r_xz=float(r_xz), r_yz=float(r_yz),
        n=int(n),
    )


# ---------------------------------------------------------------------------
# Two-sample Kolmogorov-Smirnov
# ---------------------------------------------------------------------------

#: Minimum finite-sample size at which the asymptotic KS p-value is
#: considered usable. Below this, the test should not be applied.
KS_MIN_SAMPLE_SIZE: int = 5


@dataclass(frozen=True)
class DistributionMatchResult:
    """Two-sample KS test for distribution equivalence.

    The convention follows ``scipy.stats.ks_2samp``: the null
    hypothesis is that the two samples are drawn from the same
    distribution. A small p-value REJECTS that null. A large p-value
    FAILS to reject — which is **not** the same as proving equivalence,
    only "no evidence of difference at this n".
    """

    ks_statistic: float
    p_value: float
    n_a: int
    n_b: int
    alpha: float
    is_representative: bool   # p_value >= alpha → fail to reject H0
    method: str = "ks_2samp"
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    def __str__(self) -> str:
        verdict = "fail to reject H₀ (representative)" if self.is_representative \
            else "reject H₀ (distributions differ)"
        return (
            f"KS D={self.ks_statistic:.4f}, p={self.p_value:.2e} "
            f"(n_a={self.n_a}, n_b={self.n_b}, α={self.alpha}): {verdict}"
        )


def _clean_finite(arr, drop_nans: bool, name: str) -> Tuple[np.ndarray, int]:
    """Coerce to 1-D float64; optionally drop non-finite; return cleaned + dropped count."""
    a = np.asarray(arr, dtype=np.float64).ravel()
    finite_mask = np.isfinite(a)
    n_dropped = int((~finite_mask).sum())
    if not drop_nans and n_dropped > 0:
        raise ValueError(
            f"{name} contains {n_dropped} non-finite values and drop_nans=False"
        )
    return a[finite_mask], n_dropped


def ks_test_distribution_match(
    sample_a: Sequence[float],
    sample_b: Sequence[float],
    *,
    alpha: float = 0.05,
    drop_nans: bool = True,
) -> DistributionMatchResult:
    """Two-sample Kolmogorov-Smirnov test for distribution equivalence.

    Parameters
    ----------
    sample_a, sample_b : 1-D arrays of floats
        Need not have the same length. NaN/Inf are dropped if
        ``drop_nans=True`` (the default), with the count recorded in
        ``notes``. With ``drop_nans=False``, the first non-finite
        value triggers a ``ValueError``.
    alpha : float in (0, 1)
        Significance level for the ``is_representative`` verdict:
        ``is_representative = (p_value >= alpha)``.
    drop_nans : bool

    Returns
    -------
    DistributionMatchResult
        Frozen, JSON-serializable.

    Raises
    ------
    ValueError
        If either sample has fewer than :data:`KS_MIN_SAMPLE_SIZE`
        finite values after cleaning, or alpha is out of range.

    Notes
    -----
    The KS test is sensitive to tail differences and median shifts
    but has limited power for differences in scale at fixed median.
    For VQA work, the typical use is to verify a subsample of a
    benchmark is MOS-distribution-equivalent to the full set
    (``docs/REVIEW_ANALYSIS.md`` §3.3). For that use case the test
    is well-suited and conservatively interpreted: a large p-value
    means "no evidence of difference at this n", **not** "proven
    equivalent".
    """
    if not (0.0 < alpha < 1.0):
        raise ValueError(f"alpha must be in (0, 1); got {alpha}")

    cleaned_a, dropped_a = _clean_finite(sample_a, drop_nans, "sample_a")
    cleaned_b, dropped_b = _clean_finite(sample_b, drop_nans, "sample_b")

    if cleaned_a.size < KS_MIN_SAMPLE_SIZE:
        raise ValueError(
            f"sample_a has fewer than {KS_MIN_SAMPLE_SIZE} finite values "
            f"({cleaned_a.size})"
        )
    if cleaned_b.size < KS_MIN_SAMPLE_SIZE:
        raise ValueError(
            f"sample_b has fewer than {KS_MIN_SAMPLE_SIZE} finite values "
            f"({cleaned_b.size})"
        )

    notes: List[str] = []
    if dropped_a:
        notes.append(f"dropped {dropped_a} non-finite values from sample_a")
    if dropped_b:
        notes.append(f"dropped {dropped_b} non-finite values from sample_b")

    res = ks_2samp(cleaned_a, cleaned_b, alternative="two-sided", method="auto")
    p_value = float(res.pvalue)
    return DistributionMatchResult(
        ks_statistic=float(res.statistic),
        p_value=p_value,
        n_a=int(cleaned_a.size),
        n_b=int(cleaned_b.size),
        alpha=float(alpha),
        is_representative=bool(p_value >= alpha),
        notes=notes,
    )


# ---------------------------------------------------------------------------
# Benjamini-Hochberg FDR
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FDRResult:
    """Benjamini-Hochberg FDR correction on a family of p-values.

    Implements the BH (1995) step-up procedure. Returns same-length
    arrays of q-values (BH-adjusted) and rejection booleans at the
    given FDR level α. Input order is preserved across all output
    arrays.
    """

    p_values: List[float]
    q_values: List[float]
    rejected: List[bool]
    alpha: float
    n_tests: int
    n_rejected: int
    method: str = "benjamini_hochberg"

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    def __str__(self) -> str:
        return (
            f"BH-FDR @ α={self.alpha}: rejected {self.n_rejected}/{self.n_tests} "
            f"hypotheses"
        )


def _validate_p_values(p_values: Sequence[float]) -> List[float]:
    """Validate every p-value is finite and in [0, 1]; coerce to list[float]."""
    if len(p_values) == 0:
        raise ValueError("p_values is empty")
    out: List[float] = []
    for i, p in enumerate(p_values):
        try:
            v = float(p)
        except (TypeError, ValueError):
            raise ValueError(
                f"p_values[{i}]={p!r} is not coercible to float"
            )
        if not math.isfinite(v):
            raise ValueError(f"p_values[{i}]={v} is not finite")
        if not (0.0 <= v <= 1.0):
            raise ValueError(
                f"p_values[{i}]={v}; expected finite value in [0, 1]"
            )
        out.append(v)
    return out


def benjamini_hochberg_fdr(
    p_values: Sequence[float],
    *,
    alpha: float = 0.05,
) -> FDRResult:
    """Benjamini-Hochberg step-up FDR correction.

    Parameters
    ----------
    p_values : sequence of floats in [0, 1]
        The family of p-values to correct. Order is preserved in the
        output ``q_values`` and ``rejected`` arrays.
    alpha : float in (0, 1)
        Target false-discovery rate.

    Returns
    -------
    FDRResult

    Raises
    ------
    ValueError
        On empty ``p_values``, on any value outside [0, 1], or on any
        non-finite entry. ``alpha`` must be strictly in (0, 1).

    Notes
    -----
    Algorithm (BH 1995, step-up):

    1. Let m = len(p_values). Sort p in ascending order:
       p_(1) ≤ p_(2) ≤ ... ≤ p_(m).
    2. For i = 1..m, the BH critical value is c_i = (i / m) * α.
    3. Find the largest k with p_(k) ≤ c_k. Reject every hypothesis
       with p_(i) ≤ p_(k) (i.e. the k smallest p-values).
    4. BH-adjusted q-values: q_(i) = min_{j ≥ i} (m * p_(j) / j),
       clipped to [0, 1] and made monotone non-decreasing in the
       sorted order.
    5. Restore input order in ``q_values`` and ``rejected``.

    The q-values returned here are the standard "BH-adjusted p-values"
    used by ``statsmodels.stats.multitest.multipletests(method='fdr_bh')``
    and by R ``p.adjust(method='BH')``.

    References
    ----------
    Benjamini, Y. and Hochberg, Y. (1995). "Controlling the False
    Discovery Rate: A Practical and Powerful Approach to Multiple
    Testing." Journal of the Royal Statistical Society: Series B,
    57(1):289-300.
    """
    if not (0.0 < alpha < 1.0):
        raise ValueError(f"alpha must be in (0, 1); got {alpha}")

    p_list = _validate_p_values(p_values)
    m = len(p_list)
    p_arr = np.asarray(p_list, dtype=np.float64)

    # Sort indices ascending by p-value.
    order = np.argsort(p_arr, kind="stable")
    p_sorted = p_arr[order]
    ranks = np.arange(1, m + 1, dtype=np.float64)

    # Step 4: BH-adjusted q-values, monotone in sorted order.
    # raw_i = m * p_(i) / i, then q_(i) = min over j >= i of raw_j.
    raw = m * p_sorted / ranks
    # Cumulative minimum from the right:
    q_sorted = np.minimum.accumulate(raw[::-1])[::-1]
    # Clip to [0, 1].
    q_sorted = np.clip(q_sorted, 0.0, 1.0)

    # Step 3: rejections by the step-up rule. Find the largest k such
    # that p_(k) <= (k/m)*α.
    crit = (ranks / m) * alpha
    eligible = p_sorted <= crit
    if eligible.any():
        k = int(np.flatnonzero(eligible).max()) + 1   # 1-indexed
    else:
        k = 0
    rejected_sorted = np.zeros(m, dtype=bool)
    if k > 0:
        rejected_sorted[:k] = True

    # Step 5: restore input order.
    q_values = np.empty(m, dtype=np.float64)
    rejected = np.empty(m, dtype=bool)
    q_values[order] = q_sorted
    rejected[order] = rejected_sorted

    return FDRResult(
        p_values=list(p_list),
        q_values=[float(v) for v in q_values],
        rejected=[bool(v) for v in rejected],
        alpha=float(alpha),
        n_tests=int(m),
        n_rejected=int(rejected.sum()),
    )


__all__ = [
    # Steiger Z
    "steiger_z", "SignificanceResult",
    # KS test
    "ks_test_distribution_match", "DistributionMatchResult", "KS_MIN_SAMPLE_SIZE",
    # BH FDR
    "benjamini_hochberg_fdr", "FDRResult",
]
