"""VQEG-standard 4-parameter logistic mapping from predictions to MOS.

This is the canonical step before computing PLCC / RMSE across
heterogeneous metrics. Without it, you're not measuring agreement,
you're measuring scale mismatch.

Reference: VQEG HDTV Phase I Final Report, eq. (3) — the same form
used by every modern VQA paper that reports PLCC after non-linear
fitting.

f(x) = β1 * (0.5 - 1 / (1 + exp(β2 * (x - β3)))) + β4 * x + β5

We expose the simpler 4-parameter variant (β5 = 0) by default since
it's the most common in the literature; pass ``with_linear=True`` to
get the 5-parameter form with the linear term.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
from scipy.optimize import curve_fit


@dataclass
class LogisticFit:
    """Resolved 4- or 5-parameter logistic fit."""
    params: List[float] = field(default_factory=list)
    param_names: List[str] = field(default_factory=list)
    rmse_residual: float = 0.0
    n: int = 0
    converged: bool = False
    with_linear: bool = False
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


def _logistic4(x: np.ndarray, b1: float, b2: float, b3: float, b4: float) -> np.ndarray:
    # Use np.clip to avoid overflow in exp() for extreme intermediate
    # values during curve_fit's parameter exploration. The clip range
    # ±500 keeps the logistic essentially saturated at 0/1 (well within
    # float64 range) without changing the fitted optimum.
    z = np.clip(b2 * (x - b3), -500.0, 500.0)
    return b1 * (0.5 - 1.0 / (1.0 + np.exp(z))) + b4


def _logistic5(x: np.ndarray, b1: float, b2: float, b3: float,
               b4: float, b5: float) -> np.ndarray:
    z = np.clip(b2 * (x - b3), -500.0, 500.0)
    return b1 * (0.5 - 1.0 / (1.0 + np.exp(z))) + b4 * x + b5


def fit_logistic_4p(predictions: np.ndarray, mos: np.ndarray,
                    *, with_linear: bool = False,
                    max_iter: int = 5000) -> LogisticFit:
    """Fit a 4- or 5-parameter logistic mapping prediction → MOS.

    The initial guess follows VQEG: β1 ≈ max(MOS) − min(MOS),
    β2 ≈ 1 / std(predictions), β3 ≈ mean(predictions),
    β4 ≈ min(MOS) − 0.5 * β1.

    Returns
    -------
    LogisticFit
        Fit parameters + residual RMSE. ``converged=False`` indicates
        the optimizer raised — we then return the initial guess so the
        caller can still build a downstream metric (with a noted caveat).
    """
    p = np.asarray(predictions, dtype=np.float64).ravel()
    m = np.asarray(mos, dtype=np.float64).ravel()
    if p.shape != m.shape:
        raise ValueError(f"predictions and mos must have same shape; "
                         f"got {p.shape} vs {m.shape}")
    mask = np.isfinite(p) & np.isfinite(m)
    p, m = p[mask], m[mask]
    if p.size < 5:
        raise ValueError(f"need ≥5 finite paired samples; got {p.size}")

    # VQEG-style initial guess.
    b1_0 = float(m.max() - m.min()) if m.max() != m.min() else 1.0
    b2_0 = float(1.0 / (np.std(p) + 1e-12))
    b3_0 = float(np.mean(p))
    b4_0 = float(m.min() - 0.5 * b1_0)
    notes: List[str] = []
    converged = True

    if with_linear:
        p0 = [b1_0, b2_0, b3_0, b4_0, 0.0]
        names = ["b1", "b2", "b3", "b4", "b5"]
        fn = _logistic5
    else:
        p0 = [b1_0, b2_0, b3_0, b4_0]
        names = ["b1", "b2", "b3", "b4"]
        fn = _logistic4

    try:
        popt, _ = curve_fit(fn, p, m, p0=p0, maxfev=max_iter)
        params = list(map(float, popt))
    except Exception as e:  # noqa: BLE001
        # Optimizer failed — fall back to the initial guess and warn loudly.
        converged = False
        notes.append(f"curve_fit failed: {e}; returning initial guess")
        params = list(map(float, p0))

    fitted = fn(p, *params)
    residual = float(np.sqrt(np.mean((fitted - m) ** 2)))

    return LogisticFit(
        params=params, param_names=names,
        rmse_residual=residual, n=int(p.size),
        converged=converged, with_linear=with_linear, notes=notes,
    )


def apply_logistic_4p(fit: LogisticFit, predictions: np.ndarray) -> np.ndarray:
    """Apply a previously-fitted logistic to new predictions."""
    p = np.asarray(predictions, dtype=np.float64)
    fn = _logistic5 if fit.with_linear else _logistic4
    return fn(p, *fit.params)


__all__ = ["fit_logistic_4p", "apply_logistic_4p", "LogisticFit"]
