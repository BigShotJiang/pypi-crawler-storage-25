"""Real evaluation primitives for VQA benchmarking.

This module contains the statistical machinery to compare a metric's
predictions against human MOS scores. Every function here is honest
about its assumptions and returns confidence intervals.

Public API:

- :func:`pearson` / :func:`spearman` / :func:`kendall`: rank/linear
  correlations with bootstrap 95% CIs and asymptotic p-values.
- :func:`plcc` / :func:`srcc` / :func:`krcc`: aliases used by the VQA
  literature (PLCC == Pearson, SRCC == Spearman, KRCC == Kendall).
- :func:`rmse` / :func:`mae`: error metrics with bootstrap CIs.
- :func:`fit_logistic_4p`: 4-parameter logistic mapping for
  prediction-to-MOS calibration (VQEG standard before computing PLCC).
- :func:`bootstrap_ci`: generic non-parametric bootstrap.
- :func:`compare_metrics`: pairwise significance test between two
  metrics' correlation coefficients on the same data (Steiger's Z).
- :func:`evaluate_predictions`: one-shot summary that runs all of the
  above and returns a dict ready to be dropped into a manifest.
- :func:`build_honest_report` and friends (``honest_reporting``): turn
  evaluation results into a Tier A/B/C reviewer-safe Markdown report.
"""
from __future__ import annotations

from .correlations import (
    pearson, spearman, kendall, plcc, srcc, krcc,
    bootstrap_ci, CorrelationResult,
)
from .errors import rmse, mae, ErrorResult
from .calibration import fit_logistic_4p, apply_logistic_4p, LogisticFit
from .significance import (
    steiger_z, SignificanceResult,
    ks_test_distribution_match, DistributionMatchResult, KS_MIN_SAMPLE_SIZE,
    benjamini_hochberg_fdr, FDRResult,
)
from .runner import evaluate_predictions, EvaluationReport
from .sensitivity import (
    hyperparameter_sensitivity, HyperparamPoint, SensitivityReport,
)
from .honest_reporting import (
    ClaimTier, ClaimEvidence, Claim, TieredClaim, ReviewerRisk,
    TieringPolicy, DEFAULT_POLICY, HonestReport,
    tier_claim, detect_reviewer_risks, build_honest_report,
    claim_from_evaluation_report,
)

__all__ = [
    "pearson", "spearman", "kendall", "plcc", "srcc", "krcc",
    "bootstrap_ci", "CorrelationResult",
    "rmse", "mae", "ErrorResult",
    "fit_logistic_4p", "apply_logistic_4p", "LogisticFit",
    "steiger_z", "SignificanceResult",
    "ks_test_distribution_match", "DistributionMatchResult", "KS_MIN_SAMPLE_SIZE",
    "benjamini_hochberg_fdr", "FDRResult",
    "evaluate_predictions", "EvaluationReport",
    "hyperparameter_sensitivity", "HyperparamPoint", "SensitivityReport",
    # honest_reporting
    "ClaimTier", "ClaimEvidence", "Claim", "TieredClaim", "ReviewerRisk",
    "TieringPolicy", "DEFAULT_POLICY", "HonestReport",
    "tier_claim", "detect_reviewer_risks", "build_honest_report",
    "claim_from_evaluation_report",
]
