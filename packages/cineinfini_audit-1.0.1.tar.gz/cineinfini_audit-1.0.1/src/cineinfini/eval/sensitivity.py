"""Hyperparameter sensitivity analysis with bootstrap CIs.

This module formalises what ``scripts/v1_bootstrap_all_datasets.py``
already does ad-hoc: run a small grid of model configurations through
the same K-fold CV protocol, compute the bootstrap-CI'd Spearman
correlation per configuration, and report the spread (Δ_max).

Why this matters
----------------
Item §3.2 of ``docs/REVIEW_ANALYSIS.md`` flags hyperparameter
sensitivity as a HIGH-leverage paper improvement: a reviewer asking
"does the headline ρ swing if I change n_estimators or max_depth?"
should be answered with a 4-row table, not a hand-wave.

Public API
----------
- :class:`HyperparamPoint`: one (model_class, hyperparams, oof_predictions, eval_report) record.
- :class:`SensitivityReport`: aggregate over all points; reports Δ_max and the configuration list.
- :func:`hyperparameter_sensitivity`: run a grid through a CV protocol.

Status: ``"staging"``. Promoted to ``"stable"`` after independent
re-run on a 5th dataset confirms the bootstrap CIs match the existing
``v1_bootstrap_summary.json``.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence

import numpy as np

from .runner import evaluate_predictions, EvaluationReport


__status__ = "staging"
__version__ = "1.0.0"


@dataclass(frozen=True)
class HyperparamPoint:
    """One configuration's evaluation result."""
    config_id: str
    model_class: str
    params: Dict[str, Any]
    n: int
    eval_report: Dict[str, Any]   # EvaluationReport.to_dict()

    @property
    def srcc(self) -> float:
        return float(self.eval_report["srcc"]["coefficient"])

    @property
    def srcc_ci_low(self) -> float:
        return float(self.eval_report["srcc"]["ci_low"])

    @property
    def srcc_ci_high(self) -> float:
        return float(self.eval_report["srcc"]["ci_high"])

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass(frozen=True)
class SensitivityReport:
    """Aggregated sensitivity report over a hyperparameter grid."""
    dataset: str
    n: int
    points: List[HyperparamPoint]
    srcc_min: float
    srcc_max: float
    srcc_delta: float                   # max - min
    most_robust_config: Optional[str]   # config_id with widest CI
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "dataset": self.dataset,
            "n": self.n,
            "n_configs": len(self.points),
            "srcc_min": self.srcc_min,
            "srcc_max": self.srcc_max,
            "srcc_delta": self.srcc_delta,
            "most_robust_config": self.most_robust_config,
            "points": [p.to_dict() for p in self.points],
            "notes": list(self.notes),
        }

    def __str__(self) -> str:
        return (
            f"Sensitivity report on {self.dataset} (n={self.n}, "
            f"{len(self.points)} configs): SRCC range "
            f"[{self.srcc_min:.4f}, {self.srcc_max:.4f}], Δ={self.srcc_delta:.4f}"
        )


def hyperparameter_sensitivity(
    X,
    y,
    *,
    grid: Sequence[Dict[str, Any]],
    model_factory,
    cv,
    dataset_name: str = "unnamed",
    n_bootstrap: int = 1000,
    seed: int = 42,
) -> SensitivityReport:
    """Run a grid of hyperparameters through a CV protocol; report sensitivity.

    Parameters
    ----------
    X : array-like, shape (n_samples, n_features)
        Feature matrix.
    y : array-like, shape (n_samples,)
        Target (typically MOS).
    grid : sequence of dicts
        Each dict is a hyperparameter set passed to ``model_factory``.
    model_factory : callable(params: dict) -> sklearn-like estimator
        Receives one element of ``grid`` and returns a fresh estimator.
        Must support ``fit(X, y)`` and ``predict(X)``.
    cv : sklearn-compatible CV splitter
        Used by ``cross_val_predict``. Caller is responsible for seeding
        any randomness (e.g. ``KFold(shuffle=True, random_state=...)``).
    dataset_name : str
        Recorded in the report for traceability.
    n_bootstrap : int
        Bootstrap resamples for ``evaluate_predictions``.
    seed : int
        Forwarded to ``evaluate_predictions`` for CI reproducibility.

    Returns
    -------
    SensitivityReport
        Frozen, JSON-serializable summary of the grid.

    Raises
    ------
    ValueError if ``grid`` is empty or ``X`` / ``y`` are inconsistent.

    Notes
    -----
    This function does NOT do hyperparameter *selection* — it only
    quantifies sensitivity. The "best" configuration is for the user
    to choose; we report the spread so the choice is informed.
    """
    # Lazy import to keep sklearn out of the import path of pure-stats users.
    from sklearn.model_selection import cross_val_predict

    if len(grid) == 0:
        raise ValueError("grid is empty")
    X_arr = np.asarray(X, dtype=np.float64)
    y_arr = np.asarray(y, dtype=np.float64).ravel()
    if X_arr.ndim != 2:
        raise ValueError(f"X must be 2-D; got shape {X_arr.shape}")
    if X_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"X and y row count mismatch: {X_arr.shape[0]} vs {y_arr.shape[0]}"
        )

    n = int(X_arr.shape[0])
    points: List[HyperparamPoint] = []
    for params in grid:
        if not isinstance(params, dict):
            raise ValueError(f"grid entry is not a dict: {params!r}")
        config_id = "_".join(f"{k}={v}" for k, v in sorted(params.items()))
        model = model_factory(params)
        # n_jobs=1 inside ``cross_val_predict`` is a deliberate choice:
        # it serializes the per-fold work but eliminates a large source
        # of non-determinism on shared sandboxes.
        preds = cross_val_predict(model, X_arr, y_arr, cv=cv, n_jobs=1)
        rep = evaluate_predictions(preds, y_arr,
                                   n_bootstrap=n_bootstrap, seed=seed)
        points.append(HyperparamPoint(
            config_id=config_id,
            model_class=type(model).__name__,
            params=dict(params),
            n=n,
            eval_report=rep.to_dict(),
        ))

    srccs = np.array([p.srcc for p in points])
    srcc_min = float(srccs.min())
    srcc_max = float(srccs.max())
    delta = float(srcc_max - srcc_min)

    # "Most robust": the config whose CI is widest is the LEAST robust
    # to bootstrap resampling. We surface that as a flag for the user.
    widths = np.array([p.srcc_ci_high - p.srcc_ci_low for p in points])
    if widths.size:
        widest_idx = int(np.argmax(widths))
        widest = points[widest_idx].config_id
    else:
        widest = None

    return SensitivityReport(
        dataset=dataset_name,
        n=n,
        points=points,
        srcc_min=srcc_min,
        srcc_max=srcc_max,
        srcc_delta=delta,
        most_robust_config=widest,
    )


__all__ = [
    "HyperparamPoint",
    "SensitivityReport",
    "hyperparameter_sensitivity",
]
