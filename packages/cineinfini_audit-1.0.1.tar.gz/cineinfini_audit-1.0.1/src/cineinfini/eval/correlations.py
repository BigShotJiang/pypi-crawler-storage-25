"""Correlation coefficients with bootstrap confidence intervals.

We implement Pearson, Spearman, Kendall, plus the VQA-literature
aliases PLCC / SRCC / KRCC. Every function returns a
:class:`CorrelationResult` containing:

- the point estimate,
- the asymptotic two-sided p-value (from scipy.stats),
- a non-parametric 95% bootstrap CI,
- the sample size used.

Why bootstrap CIs and not Fisher-Z? Fisher-Z gives correct CIs only for
Pearson under bivariate normality — an assumption that is *routinely
false* on VQA data (long-tailed MOS distributions, bounded supports).
The percentile bootstrap is distribution-free and matches what
top-tier VQA papers (e.g. DOVER, FAST-VQA evaluations) report.

All functions are pure: no plotting, no I/O, no mutation of inputs.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Callable, Optional, Tuple

import numpy as np
from scipy.stats import pearsonr, spearmanr, kendalltau


@dataclass
class CorrelationResult:
    """Bootstrap-stabilized correlation result."""
    coefficient: float
    p_value: float
    ci_low: float
    ci_high: float
    n: int
    method: str
    n_bootstrap: int = 0
    confidence_level: float = 0.95

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    def __str__(self) -> str:
        return (
            f"{self.method}={self.coefficient:.4f} "
            f"[{self.ci_low:.4f}, {self.ci_high:.4f}] "
            f"(n={self.n}, p={self.p_value:.2e})"
        )


def _validate_pair(x, y) -> Tuple[np.ndarray, np.ndarray]:
    """Coerce, drop non-finite pairs, validate length."""
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()
    if x.shape != y.shape:
        raise ValueError(f"x and y must have same shape; got {x.shape} vs {y.shape}")
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3:
        raise ValueError(
            f"need ≥3 finite paired observations; got {int(mask.sum())}"
        )
    return x[mask], y[mask]


def bootstrap_ci(
    x: np.ndarray,
    y: np.ndarray,
    statistic: Callable[[np.ndarray, np.ndarray], float],
    *,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    seed: Optional[int] = 42,
) -> Tuple[float, float]:
    """Non-parametric percentile bootstrap CI on a paired statistic.

    Parameters
    ----------
    x, y : 1-D arrays of equal length.
    statistic : callable
        Function ``f(x, y) -> float``. Must handle small samples
        gracefully — we resample with replacement.
    n_bootstrap : int
        Number of bootstrap resamples. 1000 is the standard floor in
        VQA papers; 10000 for tight CIs.
    confidence_level : float
        Coverage of the returned interval, in (0, 1).
    seed : int or None
        RNG seed for reproducibility. ``None`` → fresh randomness.

    Returns
    -------
    (low, high) : tuple of float
        Percentile bounds. NaN-safe.
    """
    if not (0.0 < confidence_level < 1.0):
        raise ValueError(f"confidence_level must be in (0, 1); got {confidence_level}")
    if n_bootstrap < 1:
        raise ValueError(f"n_bootstrap must be ≥1; got {n_bootstrap}")
    rng = np.random.default_rng(seed)
    n = len(x)
    estimates = np.empty(n_bootstrap, dtype=np.float64)
    for i in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        try:
            estimates[i] = statistic(x[idx], y[idx])
        except Exception:
            estimates[i] = np.nan
    finite = estimates[np.isfinite(estimates)]
    if finite.size < max(10, int(0.5 * n_bootstrap)):
        # Most resamples failed — refuse to fabricate a CI.
        return float("nan"), float("nan")
    alpha = 1.0 - confidence_level
    low, high = np.percentile(finite, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(low), float(high)


# -----------------------------------------------------------------------------
# Correlation coefficients
# -----------------------------------------------------------------------------

def pearson(x, y, *, n_bootstrap: int = 1000,
            confidence_level: float = 0.95,
            seed: Optional[int] = 42) -> CorrelationResult:
    """Pearson linear correlation with bootstrap CI."""
    x, y = _validate_pair(x, y)
    r, p = pearsonr(x, y)
    low, high = bootstrap_ci(
        x, y, lambda a, b: pearsonr(a, b)[0],
        n_bootstrap=n_bootstrap, confidence_level=confidence_level, seed=seed,
    )
    return CorrelationResult(
        coefficient=float(r), p_value=float(p),
        ci_low=low, ci_high=high, n=len(x), method="pearson",
        n_bootstrap=n_bootstrap, confidence_level=confidence_level,
    )


def spearman(x, y, *, n_bootstrap: int = 1000,
             confidence_level: float = 0.95,
             seed: Optional[int] = 42) -> CorrelationResult:
    """Spearman rank correlation with bootstrap CI."""
    x, y = _validate_pair(x, y)
    r, p = spearmanr(x, y)
    low, high = bootstrap_ci(
        x, y, lambda a, b: spearmanr(a, b).statistic,
        n_bootstrap=n_bootstrap, confidence_level=confidence_level, seed=seed,
    )
    return CorrelationResult(
        coefficient=float(r), p_value=float(p),
        ci_low=low, ci_high=high, n=len(x), method="spearman",
        n_bootstrap=n_bootstrap, confidence_level=confidence_level,
    )


def kendall(x, y, *, n_bootstrap: int = 1000,
            confidence_level: float = 0.95,
            seed: Optional[int] = 42,
            variant: str = "b") -> CorrelationResult:
    """Kendall's τ with bootstrap CI.

    ``variant='b'`` is the tie-corrected version standard in VQA work.
    """
    x, y = _validate_pair(x, y)
    res = kendalltau(x, y, variant=variant)
    low, high = bootstrap_ci(
        x, y, lambda a, b: kendalltau(a, b, variant=variant).statistic,
        n_bootstrap=n_bootstrap, confidence_level=confidence_level, seed=seed,
    )
    return CorrelationResult(
        coefficient=float(res.statistic), p_value=float(res.pvalue),
        ci_low=low, ci_high=high, n=len(x), method=f"kendall_{variant}",
        n_bootstrap=n_bootstrap, confidence_level=confidence_level,
    )


# VQA-literature aliases. We keep them as thin wrappers so people
# searching for "PLCC" land on real code, not a comment.
def plcc(x, y, **kw) -> CorrelationResult:
    """Pearson Linear Correlation Coefficient (VQA alias)."""
    out = pearson(x, y, **kw)
    out.method = "PLCC"
    return out


def srcc(x, y, **kw) -> CorrelationResult:
    """Spearman Rank Correlation Coefficient (VQA alias)."""
    out = spearman(x, y, **kw)
    out.method = "SRCC"
    return out


def krcc(x, y, **kw) -> CorrelationResult:
    """Kendall Rank Correlation Coefficient (VQA alias)."""
    out = kendall(x, y, **kw)
    out.method = "KRCC"
    return out


__all__ = [
    "CorrelationResult", "bootstrap_ci",
    "pearson", "spearman", "kendall",
    "plcc", "srcc", "krcc",
]
