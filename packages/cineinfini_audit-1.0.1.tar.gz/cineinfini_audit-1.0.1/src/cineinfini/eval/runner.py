"""One-shot evaluation: predictions vs MOS → full statistical report.

This is the function most users should call. It chains:

    1. (optional) 4-parameter logistic mapping prediction → MOS scale
    2. SRCC + KRCC on raw predictions (rank correlations are invariant
       to monotone transforms; no need to fit first)
    3. PLCC + RMSE on the *fitted* predictions (VQEG protocol)
    4. Bootstrap CIs on every reported number

The output is a dataclass that JSON-serializes cleanly into an
:class:`~cineinfini.repro.ExperimentTracker` manifest.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import numpy as np

from .calibration import LogisticFit, apply_logistic_4p, fit_logistic_4p
from .correlations import _validate_pair, krcc, plcc, srcc
from .errors import rmse


@dataclass
class EvaluationReport:
    """Self-describing evaluation result.

    The four fields ``srcc``, ``krcc``, ``plcc_fitted``, ``rmse_fitted``
    are dicts (from ``CorrelationResult.to_dict()`` /
    ``ErrorResult.to_dict()``) so the whole report is JSON-serializable
    without further work.
    """
    n: int
    n_dropped: int
    srcc: Dict[str, Any] = field(default_factory=dict)
    krcc: Dict[str, Any] = field(default_factory=dict)
    plcc_fitted: Dict[str, Any] = field(default_factory=dict)
    rmse_fitted: Dict[str, Any] = field(default_factory=dict)
    logistic_fit: Optional[Dict[str, Any]] = None
    notes: list = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


def evaluate_predictions(
    predictions: np.ndarray,
    mos: np.ndarray,
    *,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    seed: Optional[int] = 42,
    fit_logistic: bool = True,
    with_linear_term: bool = False,
) -> EvaluationReport:
    """Compute SRCC, KRCC, PLCC-after-fit, RMSE-after-fit with CIs.

    Parameters
    ----------
    predictions, mos : array-like of equal length
        Raw metric outputs and human MOS scores. NaN/Inf pairs are
        dropped (count reported in ``n_dropped``).
    n_bootstrap : int
        Bootstrap resamples for every CI. 1000 is the literature floor.
    confidence_level : float
        Coverage of returned CIs.
    seed : int or None
        For reproducibility.
    fit_logistic : bool
        If True (default), fit a 4-parameter logistic before computing
        PLCC/RMSE. This is the VQEG-standard protocol. Set False if
        you've already aligned scales upstream.
    with_linear_term : bool
        Use the 5-parameter (β₅·x added) form. Rarely needed.

    Returns
    -------
    EvaluationReport
        Full statistical summary with CIs and a logistic fit record.
    """
    p_raw = np.asarray(predictions, dtype=np.float64).ravel()
    m_raw = np.asarray(mos, dtype=np.float64).ravel()
    n_raw = max(p_raw.size, m_raw.size)
    p_clean, m_clean = _validate_pair(p_raw, m_raw)
    n_dropped = n_raw - p_clean.size
    notes = []

    # 1. Rank correlations on raw predictions (monotone-invariant).
    s = srcc(p_clean, m_clean,
             n_bootstrap=n_bootstrap,
             confidence_level=confidence_level, seed=seed)
    k = krcc(p_clean, m_clean,
             n_bootstrap=n_bootstrap,
             confidence_level=confidence_level, seed=seed)

    # 2. Logistic mapping → PLCC/RMSE on fitted predictions.
    fit_dict: Optional[Dict[str, Any]] = None
    if fit_logistic:
        try:
            fit = fit_logistic_4p(p_clean, m_clean,
                                  with_linear=with_linear_term)
            p_fitted = apply_logistic_4p(fit, p_clean)
            fit_dict = fit.to_dict()
            if not fit.converged:
                notes.append(
                    "logistic fit did not converge; PLCC/RMSE use "
                    "initial-guess parameters"
                )
        except Exception as e:  # noqa: BLE001
            notes.append(f"logistic fit raised ({e}); using raw predictions")
            p_fitted = p_clean
    else:
        p_fitted = p_clean

    pc = plcc(p_fitted, m_clean,
              n_bootstrap=n_bootstrap,
              confidence_level=confidence_level, seed=seed)
    rm = rmse(p_fitted, m_clean,
              n_bootstrap=n_bootstrap,
              confidence_level=confidence_level, seed=seed)

    return EvaluationReport(
        n=int(p_clean.size),
        n_dropped=int(n_dropped),
        srcc=s.to_dict(),
        krcc=k.to_dict(),
        plcc_fitted=pc.to_dict(),
        rmse_fitted=rm.to_dict(),
        logistic_fit=fit_dict,
        notes=notes,
    )


__all__ = ["evaluate_predictions", "EvaluationReport"]
