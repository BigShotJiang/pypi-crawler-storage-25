"""Capture the runtime environment for reproducibility.

What we record:
    - Python version, executable path, platform string.
    - OS uname.
    - Selected dependency versions (from importlib.metadata).
    - GPU info if torch + CUDA visible.
    - Git revision + dirty flag of the current working directory if any.

What we deliberately do NOT record:
    - Environment variables (may contain secrets).
    - Full ``pip freeze`` (too noisy; we record the deps that matter).
    - User home / username (privacy).

The output is a plain dataclass that serializes cleanly to JSON.
"""
from __future__ import annotations

import dataclasses
import importlib.metadata
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


# Deps we care about for VQA reproducibility. We resolve their versions
# defensively — missing deps are fine, we just record "not_installed".
_TRACKED_DEPS = (
    "numpy", "scipy", "scikit-image", "scikit-learn", "opencv-python",
    "matplotlib", "pandas", "torch", "torchvision", "onnxruntime",
    "open-clip-torch", "transformers", "PyYAML", "click",
    "dtaidistance", "fastdtw",
)


@dataclass
class EnvironmentCapture:
    """Self-contained environment fingerprint."""
    python_version: str = ""
    python_executable: str = ""
    platform: str = ""
    os_name: str = ""
    os_release: str = ""
    machine: str = ""
    deps: Dict[str, str] = field(default_factory=dict)
    dep_hashes: Dict[str, str] = field(default_factory=dict)  # v1.0.0 Item 4
    cuda_available: Optional[bool] = None
    cuda_devices: List[Dict[str, Any]] = field(default_factory=list)
    git_commit: Optional[str] = None
    git_dirty: Optional[bool] = None
    git_diff_lines: Optional[int] = None  # v1.0.0 Item 4
    git_branch: Optional[str] = None
    cineinfini_version: Optional[str] = None
    pip_freeze: Optional[List[str]] = None  # v1.0.0 Item 4 — opt-in
    capture_caveats: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


def _resolve_dep_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "not_installed"


def get_git_diff_size(repo_path: Optional[Path] = None) -> int:
    """Return approximate number of modified lines in the git working tree.

    Defensive: any failure returns 0 (the caller can interpret 0 as
    "either clean tree or git unavailable" and look at the dirty flag
    elsewhere in the manifest).
    """
    try:
        cmd = ["git", "diff", "--stat"]
        if repo_path:
            cmd = ["git", "-C", str(repo_path), "diff", "--stat"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            import re
            numbers = re.findall(r'(\d+)', result.stdout)
            return sum(int(n) for n in numbers) if numbers else 0
        return 0
    except Exception:  # noqa: BLE001
        return 0


def get_package_hashes(packages: Optional[List[str]] = None) -> Dict[str, Optional[str]]:
    """Return installed package versions (placeholder for future true hashing).

    The current implementation returns version strings; the field name
    keeps the door open to swap in a real RECORD-file hash later
    without an API change.
    """
    if packages is None:
        packages = [
            "cineinfini",
            "numpy",
            "scipy",
            "pandas",
            "torch",
            "opencv-python",
        ]
    hashes: Dict[str, Optional[str]] = {}
    for pkg in packages:
        try:
            dist = importlib.metadata.distribution(pkg)
            hashes[pkg] = dist.version
        except Exception:  # noqa: BLE001
            hashes[pkg] = None
    return hashes


def get_pip_freeze() -> str:
    """Return ``pip freeze`` output as a single string. Off by default."""
    try:
        result = subprocess.run(
            ["pip", "freeze"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout if result.returncode == 0 else ""
    except Exception:  # noqa: BLE001
        return ""


def _query_git(repo_dir: Optional[Path]) -> Dict[str, Any]:
    """Return git commit/branch/dirty/diff_lines if `repo_dir` is inside a git tree.

    Defensive: any failure (no git binary, not a repo, permissions) is
    recorded as None and noted in caveats — never raised.

    The ``diff_lines`` field is the count of lines that ``git diff HEAD``
    would print (insertions + deletions across all unstaged + staged
    changes). It's a simple "how dirty is dirty" metric — a small dirty
    repo is much less worrying for reproducibility than a heavily-modified
    one. We cap the diff-line measurement at a few thousand lines for
    perf safety; very large diffs return that cap and a caveat.
    """
    info: Dict[str, Any] = {"commit": None, "dirty": None, "branch": None,
                            "diff_lines": None, "caveat": None}
    if repo_dir is None:
        repo_dir = Path.cwd()
    try:
        commit = subprocess.run(
            ["git", "-C", str(repo_dir), "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=2, check=False,
        )
        if commit.returncode == 0:
            info["commit"] = commit.stdout.strip() or None
        branch = subprocess.run(
            ["git", "-C", str(repo_dir), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=2, check=False,
        )
        if branch.returncode == 0:
            info["branch"] = branch.stdout.strip() or None
        status = subprocess.run(
            ["git", "-C", str(repo_dir), "status", "--porcelain"],
            capture_output=True, text=True, timeout=2, check=False,
        )
        if status.returncode == 0:
            info["dirty"] = bool(status.stdout.strip())
            # If dirty, compute diff size cheaply via numstat
            if info["dirty"]:
                diff = subprocess.run(
                    ["git", "-C", str(repo_dir), "diff", "HEAD", "--numstat"],
                    capture_output=True, text=True, timeout=4, check=False,
                )
                if diff.returncode == 0:
                    total = 0
                    for line in diff.stdout.splitlines():
                        parts = line.split("\t")
                        if len(parts) >= 2:
                            for tok in parts[:2]:
                                # "-" appears for binary files; ignore.
                                if tok.isdigit():
                                    total += int(tok)
                    info["diff_lines"] = int(total)
            else:
                info["diff_lines"] = 0
    except FileNotFoundError:
        info["caveat"] = "git binary not found"
    except subprocess.TimeoutExpired:
        info["caveat"] = "git query timed out"
    except Exception as e:  # noqa: BLE001
        info["caveat"] = f"git query failed: {e}"
    return info


def _query_cuda() -> Dict[str, Any]:
    """Return CUDA availability + per-device info via torch.

    No torch → all None and a caveat. Torch present but no CUDA → False
    + empty device list. We do NOT shell out to nvidia-smi: that path is
    fragile and adds no info beyond what torch reports.
    """
    info: Dict[str, Any] = {"available": None, "devices": [], "caveat": None}
    try:
        import torch  # type: ignore
        info["available"] = bool(torch.cuda.is_available())
        if info["available"]:
            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                info["devices"].append({
                    "index": i,
                    "name": props.name,
                    "total_memory_gb": round(props.total_memory / 1024**3, 2),
                    "capability": f"{props.major}.{props.minor}",
                })
    except ImportError:
        info["caveat"] = "torch not installed; cuda info unavailable"
    except Exception as e:  # noqa: BLE001
        info["caveat"] = f"cuda query failed: {e}"
    return info


def capture_environment(
    *,
    repo_dir: Optional[Path] = None,
    capture_pip_freeze: bool = False,
) -> EnvironmentCapture:
    """Snapshot the runtime environment.

    Parameters
    ----------
    repo_dir : Path or None
        Directory whose git status to capture. None → cwd.
    capture_pip_freeze : bool
        If True, run ``pip freeze`` and store its output in
        ``EnvironmentCapture.pip_freeze``. Off by default — pip freeze
        adds ~100 lines of noise to a typical manifest and is rarely
        needed for reproducibility (versioned deps + dep_hashes are
        usually enough).

    Returns
    -------
    EnvironmentCapture
        Frozen, JSON-serializable record.
    """
    cap = EnvironmentCapture()
    cap.python_version = sys.version.split()[0]
    cap.python_executable = sys.executable
    cap.platform = sys.platform
    uname = platform.uname()
    cap.os_name = uname.system
    cap.os_release = uname.release
    cap.machine = uname.machine
    cap.deps = {name: _resolve_dep_version(name) for name in _TRACKED_DEPS}
    # v1.0.0 Item 4: package version table (and future hash slot).
    cap.dep_hashes = {k: v for k, v in get_package_hashes().items() if v is not None}

    cuda = _query_cuda()
    cap.cuda_available = cuda["available"]
    cap.cuda_devices = cuda["devices"]
    if cuda["caveat"]:
        cap.capture_caveats.append(cuda["caveat"])

    git = _query_git(repo_dir)
    cap.git_commit = git["commit"]
    cap.git_dirty = git["dirty"]
    cap.git_branch = git["branch"]
    # v1.0.0 Item 4: git diff size as a "how dirty is dirty" indicator.
    cap.git_diff_lines = git.get("diff_lines")
    if cap.git_diff_lines is None:
        cap.git_diff_lines = get_git_diff_size(repo_dir)
    if git["caveat"]:
        cap.capture_caveats.append(git["caveat"])

    # v1.0.0 Item 4: pip_freeze opt-in.
    if capture_pip_freeze:
        freeze_text = get_pip_freeze()
        if freeze_text:
            cap.pip_freeze = [line for line in freeze_text.splitlines() if line.strip()]

    try:
        cap.cineinfini_version = importlib.metadata.version("cineinfini-audit")
    except importlib.metadata.PackageNotFoundError:
        try:
            from cineinfini import __version__ as _v
            cap.cineinfini_version = _v
        except Exception:  # noqa: BLE001
            cap.cineinfini_version = None

    return cap


__all__ = [
    "capture_environment", "EnvironmentCapture",
    "get_git_diff_size", "get_package_hashes", "get_pip_freeze",
]
