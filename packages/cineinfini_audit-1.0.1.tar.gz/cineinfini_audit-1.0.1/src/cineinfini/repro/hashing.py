"""Stable content hashes for files and directories.

We use SHA-256 streamed in chunks. For directories, we hash the sorted
list of (relative_path, file_hash) pairs to produce a Merkle-style root
hash that's stable under filesystem reordering.

This is the right primitive to attach to dataset manifests: if the
hash matches, the bytes match — independent of where they live on disk.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Iterable, Optional


_CHUNK = 1024 * 1024  # 1 MiB streaming chunks


def compute_file_hash(path: str | os.PathLike, *, algo: str = "sha256") -> str:
    """SHA-256 (default) of a single file, streamed.

    Raises FileNotFoundError if path doesn't exist or isn't a file.
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"not a file: {p}")
    h = hashlib.new(algo)
    with p.open("rb") as f:
        while True:
            chunk = f.read(_CHUNK)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def compute_dir_hash(
    root: str | os.PathLike,
    *,
    algo: str = "sha256",
    include_glob: Optional[Iterable[str]] = None,
    exclude_glob: Optional[Iterable[str]] = None,
) -> str:
    """Merkle-style hash of a directory.

    The hash is over the sorted list of ``"<relpath>\\t<file_hash>\\n"``
    entries. Identical directory contents (same files, same bytes) →
    identical root hash, regardless of the OS, listing order, or
    inode timestamps.

    Parameters
    ----------
    root : path
        Directory to hash. Symlinks are followed for files only.
    include_glob : iterable of str, optional
        If given, only files matching at least one glob are hashed.
        Patterns are matched against the path *relative* to root.
    exclude_glob : iterable of str, optional
        If given, files matching any pattern are skipped (applied after
        include filter).

    Returns
    -------
    str
        Hex digest (64 chars for sha256).
    """
    root_p = Path(root)
    if not root_p.is_dir():
        raise NotADirectoryError(f"not a directory: {root_p}")
    include = tuple(include_glob) if include_glob else None
    exclude = tuple(exclude_glob) if exclude_glob else None

    entries = []
    for sub in sorted(root_p.rglob("*")):
        if not sub.is_file():
            continue
        rel = sub.relative_to(root_p).as_posix()
        if include is not None and not any(sub.match(g) for g in include):
            continue
        if exclude is not None and any(sub.match(g) for g in exclude):
            continue
        entries.append((rel, compute_file_hash(sub, algo=algo)))

    h = hashlib.new(algo)
    for rel, fh in sorted(entries):
        h.update(f"{rel}\t{fh}\n".encode("utf-8"))
    return h.hexdigest()


__all__ = ["compute_file_hash", "compute_dir_hash"]
