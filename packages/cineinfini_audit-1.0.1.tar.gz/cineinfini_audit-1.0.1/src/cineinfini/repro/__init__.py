"""CineInfini reproducibility utilities.

Real reproducibility primitives — no marketing claims. Provides:

- ``set_seeds(seed)``: pin Python / numpy / torch (if installed) RNGs.
- ``capture_environment()``: collect OS / Python / dep / GPU / git info into
  a dict suitable for serialization next to results.
- ``compute_file_hash(path)``: stable SHA-256 of a file (streamed).
- ``ExperimentTracker``: write a self-describing JSON manifest containing
  config snapshot, env capture, dataset hashes, runtime, results, so that
  the experiment can be reproduced exactly.

The design follows the directive: every claim must be reproducible from
the manifest alone.
"""
from __future__ import annotations

from .seeds import set_seeds, get_seed_state
from .env import (
    capture_environment, EnvironmentCapture,
    get_git_diff_size, get_package_hashes, get_pip_freeze,
)
from .hashing import compute_file_hash, compute_dir_hash
from .tracker import ExperimentTracker, ExperimentManifest

__all__ = [
    "set_seeds",
    "get_seed_state",
    "capture_environment",
    "EnvironmentCapture",
    "get_git_diff_size",
    "get_package_hashes",
    "get_pip_freeze",
    "compute_file_hash",
    "compute_dir_hash",
    "ExperimentTracker",
    "ExperimentManifest",
]
