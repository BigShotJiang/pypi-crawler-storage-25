"""Experiment manifest writer.

An ``ExperimentTracker`` collects everything needed to reproduce a run:
config snapshot, environment capture, dataset hashes, runtime, and
results. On ``finalize()`` it writes a single JSON file that another
person (or future-you) can open and re-derive the experiment.

This is intentionally minimal — no remote logging, no fancy UI.
The JSON is the contract.
"""
from __future__ import annotations

import dataclasses
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .env import EnvironmentCapture, capture_environment
from .hashing import compute_dir_hash, compute_file_hash
from .seeds import set_seeds


@dataclass
class ExperimentManifest:
    """Self-describing experiment record.

    Everything in this object should be enough, in principle, to
    reconstruct the experiment. We do not store full config bodies
    if they are huge; instead we record the config hash + an inline
    snapshot when small.
    """
    experiment_id: str
    name: str
    started_at_utc: str
    finished_at_utc: Optional[str] = None
    duration_seconds: Optional[float] = None
    seed: Optional[int] = None
    seeded_libraries: Dict[str, Any] = field(default_factory=dict)
    environment: Dict[str, Any] = field(default_factory=dict)
    config_snapshot: Dict[str, Any] = field(default_factory=dict)
    datasets: List[Dict[str, Any]] = field(default_factory=list)
    inputs: List[Dict[str, Any]] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    artifacts: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    status: str = "running"
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


class ExperimentTracker:
    """Write a JSON manifest describing an experiment run.

    Typical usage::

        with ExperimentTracker(name="konvid_calibration",
                               output_dir="./out") as tr:
            tr.set_seed(42)
            tr.record_config(config_dict)
            tr.record_dataset("KoNViD-1k", path="/data/konvid",
                              include_glob=["*.csv"])
            # ... run experiment ...
            tr.record_metric("spearman_mean", 0.566)
            tr.add_artifact(out_dir / "results.json")

    On context-manager exit (or explicit ``finalize()``) the manifest
    JSON is written.
    """

    def __init__(
        self,
        name: str,
        output_dir: Union[str, Path],
        *,
        capture_env: bool = True,
        repo_dir: Optional[Union[str, Path]] = None,
        capture_pip_freeze: bool = False,
    ) -> None:
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._t0 = time.time()
        self.manifest = ExperimentManifest(
            experiment_id=str(uuid.uuid4()),
            name=name,
            started_at_utc=datetime.now(timezone.utc).isoformat(),
        )
        if capture_env:
            env = capture_environment(
                repo_dir=Path(repo_dir) if repo_dir else None,
                capture_pip_freeze=capture_pip_freeze,
            )
            self.manifest.environment = env.to_dict()

    # -- context manager ---------------------------------------------------

    def __enter__(self) -> "ExperimentTracker":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc is not None:
            self.manifest.status = "failed"
            self.manifest.error = f"{exc_type.__name__}: {exc}"
        else:
            self.manifest.status = "completed"
        self.finalize()

    # -- recording API -----------------------------------------------------

    def set_seed(self, seed: int, *, deterministic_torch: bool = True) -> None:
        """Pin RNGs and record what was actually pinned."""
        info = set_seeds(seed, deterministic_torch=deterministic_torch)
        self.manifest.seed = int(seed)
        self.manifest.seeded_libraries = info

    def record_config(self, config: Dict[str, Any]) -> None:
        """Snapshot a config dict (deep-copied via JSON round-trip).

        We do the round-trip up-front so we fail fast on non-serializable
        values instead of crashing at finalize().
        """
        self.manifest.config_snapshot = json.loads(json.dumps(config, default=str))

    def record_dataset(
        self,
        name: str,
        *,
        path: Optional[Union[str, Path]] = None,
        url: Optional[str] = None,
        include_glob: Optional[List[str]] = None,
        exclude_glob: Optional[List[str]] = None,
        n_samples: Optional[int] = None,
        notes: Optional[str] = None,
    ) -> None:
        """Record a dataset used in this experiment.

        If ``path`` is given and is a file → file hash; if dir → merkle
        hash with optional glob filters. If hashing fails (e.g. the data
        is not on this machine), we record the failure and continue —
        the user gets to decide whether that's acceptable.
        """
        entry: Dict[str, Any] = {"name": name, "url": url, "n_samples": n_samples}
        if path is not None:
            p = Path(path)
            entry["path"] = str(p)
            if p.is_file():
                try:
                    entry["sha256"] = compute_file_hash(p)
                except Exception as e:  # noqa: BLE001
                    entry["hash_error"] = str(e)
            elif p.is_dir():
                try:
                    entry["sha256_merkle"] = compute_dir_hash(
                        p, include_glob=include_glob, exclude_glob=exclude_glob,
                    )
                    entry["include_glob"] = list(include_glob) if include_glob else None
                    entry["exclude_glob"] = list(exclude_glob) if exclude_glob else None
                except Exception as e:  # noqa: BLE001
                    entry["hash_error"] = str(e)
            else:
                entry["hash_error"] = "path does not exist"
        if notes:
            entry["notes"] = notes
        self.manifest.datasets.append(entry)

    def record_input(self, role: str, path: Union[str, Path],
                     **extra: Any) -> None:
        """Record a single input file (e.g. a video being audited)."""
        p = Path(path)
        entry: Dict[str, Any] = {"role": role, "path": str(p), **extra}
        try:
            if p.is_file():
                entry["sha256"] = compute_file_hash(p)
                entry["size_bytes"] = p.stat().st_size
        except Exception as e:  # noqa: BLE001
            entry["hash_error"] = str(e)
        self.manifest.inputs.append(entry)

    def record_metric(self, key: str, value: Any) -> None:
        """Record a single result metric. Nested dicts are allowed."""
        self.manifest.metrics[key] = value

    def record_metrics(self, mapping: Dict[str, Any]) -> None:
        for k, v in mapping.items():
            self.record_metric(k, v)

    def add_artifact(self, path: Union[str, Path],
                     description: Optional[str] = None) -> None:
        """Record a file produced by the experiment (figure, csv, etc.)."""
        p = Path(path)
        entry: Dict[str, Any] = {"path": str(p)}
        if description:
            entry["description"] = description
        try:
            if p.is_file():
                entry["sha256"] = compute_file_hash(p)
                entry["size_bytes"] = p.stat().st_size
        except Exception as e:  # noqa: BLE001
            entry["hash_error"] = str(e)
        self.manifest.artifacts.append(entry)

    def add_note(self, note: str) -> None:
        self.manifest.notes.append(note)

    # -- finalize ----------------------------------------------------------

    def finalize(self) -> Path:
        """Write the manifest JSON. Idempotent."""
        self.manifest.finished_at_utc = datetime.now(timezone.utc).isoformat()
        self.manifest.duration_seconds = round(time.time() - self._t0, 4)
        out = self.output_dir / f"manifest_{self.manifest.experiment_id}.json"
        out.write_text(
            json.dumps(self.manifest.to_dict(), indent=2, default=str),
            encoding="utf-8",
        )
        return out


__all__ = ["ExperimentTracker", "ExperimentManifest"]
