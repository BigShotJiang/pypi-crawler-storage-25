"""Pin all RNGs (Python, numpy, torch) to a single seed.

We keep this minimal and honest: we can only affect RNGs that are
actually available in the current environment. We never silently
import optional dependencies.

The function returns the resolved set of libraries it actually pinned,
so callers (and the ExperimentTracker) can record exactly what was
seeded. This avoids the common pitfall of code that *claims* to be
deterministic but silently skipped torch because it wasn't installed.
"""
from __future__ import annotations

import os
import random
from typing import Any, Dict, List, Optional

import numpy as np


def set_seeds(seed: int = 42, *, deterministic_torch: bool = True) -> Dict[str, Any]:
    """Pin RNGs across libraries actually available in this process.

    Parameters
    ----------
    seed : int
        Master seed. Same value is broadcast to all RNGs we can find.
    deterministic_torch : bool
        If True and torch is available, also set
        ``torch.use_deterministic_algorithms(True)`` and the CUBLAS
        workspace env var. This trades a small speed cost for full
        reproducibility on GPU.

    Returns
    -------
    dict
        Report of what was actually pinned. Keys are library names;
        values are the seed (or True for env vars).
    """
    if seed < 0 or seed > 2**32 - 1:
        raise ValueError(f"seed must fit in uint32; got {seed}")

    pinned: Dict[str, Any] = {"seed": int(seed)}

    # Python stdlib RNG
    random.seed(seed)
    pinned["random"] = seed

    # numpy global + new-style default rng
    np.random.seed(seed)
    pinned["numpy"] = seed

    # PYTHONHASHSEED affects dict ordering in some edge cases; we set it
    # but note it only takes effect for *child* processes, not the
    # current one. We record this caveat.
    os.environ["PYTHONHASHSEED"] = str(seed)
    pinned["PYTHONHASHSEED"] = str(seed)
    pinned["PYTHONHASHSEED_caveat"] = (
        "only affects subprocesses; current process inherits launch-time value"
    )

    # Optional: torch
    try:
        import torch  # type: ignore
        torch.manual_seed(seed)
        pinned["torch"] = seed
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            pinned["torch.cuda"] = seed
        if deterministic_torch:
            try:
                # CUBLAS workspace must be set for deterministic CUDA matmul
                os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
                torch.use_deterministic_algorithms(True, warn_only=True)
                pinned["torch.deterministic"] = True
            except Exception as e:
                # Some torch builds don't support this; record honestly.
                pinned["torch.deterministic"] = f"unavailable: {e}"
    except ImportError:
        pinned["torch"] = "not_installed"

    return pinned


def get_seed_state() -> Dict[str, Any]:
    """Snapshot the current RNG state (for debugging).

    This is a *snapshot*, not a seed — restoring requires
    ``random.setstate`` / ``np.random.set_state`` with the same payload.
    We don't expose those here because round-tripping these structures
    through JSON is fragile; if you need full state restore, use pickle.
    """
    state: Dict[str, Any] = {
        "random_state_hash": hash(str(random.getstate())),
        "numpy_state_hash": hash(str(np.random.get_state()[1].tobytes())),
    }
    try:
        import torch  # type: ignore
        state["torch_initial_seed"] = int(torch.initial_seed())
    except ImportError:
        pass
    return state


__all__ = ["set_seeds", "get_seed_state"]
