"""Parallel map with graceful degradation.

The simplest useful primitive: take a function and a list of inputs,
return the list of outputs, possibly in parallel.

Key design choices:
    * If ``n_workers=1`` we run serially — no executor overhead, no
      pickling cost, easier to debug. This is the default when
      ``DeviceInfo`` cannot detect more cores.
    * Errors in workers are *re-raised in the caller* by default
      (``raise_on_error=True``). When set to False, we return a
      ``WorkerError`` placeholder per failed item so a partial run
      can still be inspected.
    * Threading vs multiprocessing: callers pass ``backend="thread"``
      (default; right for I/O- or numpy-heavy tasks that release the
      GIL) or ``backend="process"`` (CPU-bound pure-Python work).
"""
from __future__ import annotations

import dataclasses
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Optional, TypeVar

T = TypeVar("T")
R = TypeVar("R")


@dataclass
class WorkerError:
    """Placeholder returned for failed items when raise_on_error=False."""
    index: int
    error_type: str
    message: str


class ParallelMap:
    """Context-managed parallel map.

    Example
    -------
    >>> with ParallelMap(n_workers=4) as pmap:
    ...     results = pmap.map(compute_score, video_paths)
    """

    def __init__(self, n_workers: int = 1, *, backend: str = "thread") -> None:
        if n_workers < 1:
            raise ValueError(f"n_workers must be ≥1; got {n_workers}")
        if backend not in ("thread", "process"):
            raise ValueError(f"backend must be 'thread' or 'process'; got {backend!r}")
        self.n_workers = n_workers
        self.backend = backend
        self._executor = None

    def __enter__(self) -> "ParallelMap":
        if self.n_workers == 1:
            self._executor = None  # Run serially.
            return self
        cls = ThreadPoolExecutor if self.backend == "thread" else ProcessPoolExecutor
        self._executor = cls(max_workers=self.n_workers)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=True)
            self._executor = None

    def map(self, fn: Callable[[T], R], items: Iterable[T],
            *, raise_on_error: bool = True) -> List[Any]:
        """Apply ``fn`` to each item; preserve input order in output."""
        items = list(items)
        if self._executor is None:
            results: List[Any] = []
            for i, x in enumerate(items):
                try:
                    results.append(fn(x))
                except Exception as e:  # noqa: BLE001
                    if raise_on_error:
                        raise
                    results.append(WorkerError(
                        index=i, error_type=type(e).__name__, message=str(e),
                    ))
            return results

        # Parallel path. We submit with index → out-of-order completion
        # is fine, we sort by index at the end to preserve input order.
        future_to_idx = {
            self._executor.submit(fn, x): i for i, x in enumerate(items)
        }
        out: List[Any] = [None] * len(items)
        for fut in as_completed(future_to_idx):
            i = future_to_idx[fut]
            try:
                out[i] = fut.result()
            except Exception as e:  # noqa: BLE001
                if raise_on_error:
                    raise
                out[i] = WorkerError(
                    index=i, error_type=type(e).__name__, message=str(e),
                )
        return out


def run_parallel(fn: Callable[[T], R], items: Iterable[T],
                 *, n_workers: int = 1, backend: str = "thread",
                 raise_on_error: bool = True) -> List[Any]:
    """One-shot helper: ``with ParallelMap(...): pmap.map(...)``."""
    with ParallelMap(n_workers=n_workers, backend=backend) as pmap:
        return pmap.map(fn, items, raise_on_error=raise_on_error)


__all__ = ["ParallelMap", "run_parallel", "WorkerError"]
