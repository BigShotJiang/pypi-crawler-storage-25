"""Performance / parallelism utilities for CineInfini.

This is the engineering layer extracted (and simplified) from v0.8.0:

- :class:`ParallelMap`: a thin context manager around
  ``ThreadPoolExecutor`` / ``ProcessPoolExecutor`` with sensible
  defaults and graceful degradation to serial when ``n_workers=1``.
- :class:`PerformanceProfiler`: minimal scope timer that aggregates
  per-name statistics (count, mean, p50, p95, total).
- :class:`DeviceInfo`: queries available compute devices (CPU cores,
  CUDA devices via torch if installed) without introducing torch as
  a hard dependency.

Design rules:
    * No global state. Every utility is a class / function the user
      explicitly creates.
    * No "auto-magic" device pinning. We *report* what's available;
      the caller decides.
    * Honest fallbacks: optional deps (torch, psutil) absent → we
      report what we can and never crash.
"""
from __future__ import annotations

from .device import DeviceInfo, query_devices
from .parallel import ParallelMap, run_parallel
from .profiler import PerformanceProfiler, ScopeTimer

__all__ = [
    "DeviceInfo", "query_devices",
    "ParallelMap", "run_parallel",
    "PerformanceProfiler", "ScopeTimer",
]
