"""Minimal scope profiler: aggregate timings under named scopes.

Designed for "I want to know where the audit pipeline spends its
time" without pulling in a full APM library.

Example
-------
>>> prof = PerformanceProfiler()
>>> with prof.scope("shot_detection"):
...     detect_shots(video)
>>> with prof.scope("module:motion_coherence"):
...     run_motion_metric(frames)
>>> prof.report()
{
    'shot_detection': {'count': 1, 'mean_s': ..., 'p95_s': ..., 'total_s': ...},
    'module:motion_coherence': {...},
}

The profiler is *not* thread-safe by default — use one per worker, or
add a lock around ``_record`` if you need it.
"""
from __future__ import annotations

import time
from collections import defaultdict
from typing import Any, Dict, List, Optional

import numpy as np


class ScopeTimer:
    """Context manager that records elapsed time on exit."""

    def __init__(self, profiler: "PerformanceProfiler", name: str) -> None:
        self._profiler = profiler
        self._name = name
        self._t0: Optional[float] = None

    def __enter__(self) -> "ScopeTimer":
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._t0 is None:
            return
        elapsed = time.perf_counter() - self._t0
        self._profiler._record(self._name, elapsed)


class PerformanceProfiler:
    def __init__(self) -> None:
        self._timings: Dict[str, List[float]] = defaultdict(list)

    # Public API ----------------------------------------------------------

    def scope(self, name: str) -> ScopeTimer:
        """Open a timing scope: ``with prof.scope("foo"): ...``."""
        return ScopeTimer(self, name)

    def record(self, name: str, seconds: float) -> None:
        """Manually log a duration (for callers that already measured)."""
        self._record(name, seconds)

    def stats(self, name: str) -> Optional[Dict[str, Any]]:
        """Aggregate stats for one scope, or None if it never ran."""
        ts = self._timings.get(name)
        if not ts:
            return None
        arr = np.asarray(ts, dtype=np.float64)
        return {
            "count": int(arr.size),
            "mean_s": float(arr.mean()),
            "p50_s": float(np.median(arr)),
            "p95_s": float(np.percentile(arr, 95)) if arr.size >= 2 else float(arr[0]),
            "min_s": float(arr.min()),
            "max_s": float(arr.max()),
            "total_s": float(arr.sum()),
        }

    def report(self) -> Dict[str, Any]:
        """Aggregate stats for all scopes."""
        return {name: self.stats(name) for name in self._timings}

    def reset(self) -> None:
        """Forget all timings."""
        self._timings.clear()

    # Internal ------------------------------------------------------------

    def _record(self, name: str, seconds: float) -> None:
        self._timings[name].append(float(seconds))


__all__ = ["PerformanceProfiler", "ScopeTimer"]
