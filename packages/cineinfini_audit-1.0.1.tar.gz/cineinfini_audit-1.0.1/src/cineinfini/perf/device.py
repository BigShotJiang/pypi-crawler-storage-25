"""Query available compute devices.

We do *not* try to abstract over device backends — different
metrics have very different shapes. We just *report* what's there so
upstream code (or the user) can dispatch.
"""
from __future__ import annotations

import dataclasses
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class DeviceInfo:
    cpu_count_logical: Optional[int] = None
    cpu_count_physical: Optional[int] = None
    ram_gb: Optional[float] = None
    cuda_available: bool = False
    cuda_devices: List[Dict[str, Any]] = field(default_factory=list)
    mps_available: bool = False
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    @property
    def has_gpu(self) -> bool:
        return self.cuda_available or self.mps_available

    def recommended_workers(self, *, reserve_for_main: int = 1,
                            cap: int = 8) -> int:
        """Sensible default for ThreadPoolExecutor sizing on CPU work.

        We use logical cores minus a small reservation, capped at
        ``cap`` to avoid scheduler thrashing on big machines for
        tasks that don't actually scale linearly.
        """
        n = self.cpu_count_logical or os.cpu_count() or 1
        return max(1, min(cap, n - reserve_for_main))


def query_devices() -> DeviceInfo:
    """Snapshot what the current process can use, without crashing."""
    info = DeviceInfo()

    info.cpu_count_logical = os.cpu_count()
    try:
        import psutil  # type: ignore
        info.cpu_count_physical = psutil.cpu_count(logical=False)
        info.ram_gb = round(psutil.virtual_memory().total / 1024**3, 2)
    except ImportError:
        info.notes.append("psutil not installed; physical core count / RAM unknown")

    try:
        import torch  # type: ignore
        info.cuda_available = bool(torch.cuda.is_available())
        if info.cuda_available:
            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                info.cuda_devices.append({
                    "index": i,
                    "name": props.name,
                    "total_memory_gb": round(props.total_memory / 1024**3, 2),
                    "capability": f"{props.major}.{props.minor}",
                })
        # MPS (Apple Silicon).
        info.mps_available = bool(getattr(torch.backends, "mps", None)
                                  and torch.backends.mps.is_available())
    except ImportError:
        info.notes.append("torch not installed; GPU detection skipped")
    except Exception as e:  # noqa: BLE001
        info.notes.append(f"torch device query failed: {e}")

    return info


__all__ = ["DeviceInfo", "query_devices"]
