"""High-level orchestrator over ``core.registry``.

Reads ``__status__`` from each registered module's defining package
(if present) and offers filtering / dependency-validation views.
"""
from __future__ import annotations

import dataclasses
import importlib
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Set

from ..core.registry import all_modules, ModuleEntry


VALID_STATUSES = ("stable", "staging", "experimental")


@dataclass(frozen=True)
class ModuleInfo:
    """View over a registered module."""
    mod_id: str
    description: str
    version: str
    requires: List[str]
    status: Optional[str]            # None if no __status__ found
    source_module: Optional[str]     # importable name e.g. "cineinfini.modules.foo"

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


def _resolve_status(entry: ModuleEntry) -> tuple[Optional[str], Optional[str]]:
    """Return (status, source_module_name) for a registered ModuleEntry.

    The status comes from the ``__status__`` attribute of the module
    that owns ``entry.func``. If the function's module isn't loaded
    (very rare — would mean it deregistered), we return (None, None).
    """
    func = entry.func
    mod_name = getattr(func, "__module__", None)
    if not mod_name:
        return None, None
    mod = sys.modules.get(mod_name)
    if mod is None:
        return None, mod_name
    status = getattr(mod, "__status__", None)
    if status is not None and status not in VALID_STATUSES:
        # Don't crash: surface the bad value as-is. This makes
        # mistakes visible without breaking the registry.
        return status, mod_name
    return status, mod_name


def list_modules(
    *,
    status_filter: Optional[str] = None,
) -> List[ModuleInfo]:
    """List registered modules; optionally filter by ``__status__``.

    Parameters
    ----------
    status_filter : "stable" | "staging" | "experimental" | None
        If None, return all modules. If a status string, return only
        modules whose owning module exposes ``__status__ == status_filter``.
        A module with **no** ``__status__`` attribute is excluded from
        any filtered query — to surface the missing-metadata case, call
        :func:`list_modules` with ``status_filter=None`` and inspect
        ``info.status is None``.

    Returns
    -------
    list of ModuleInfo
        Sorted by ``mod_id`` for stable output.

    Raises
    ------
    ValueError if status_filter is not in VALID_STATUSES (and not None).
    """
    if status_filter is not None and status_filter not in VALID_STATUSES:
        raise ValueError(
            f"status_filter must be one of {VALID_STATUSES} or None; "
            f"got {status_filter!r}"
        )
    out: List[ModuleInfo] = []
    for mod_id, entry in sorted(all_modules().items()):
        status, source_module = _resolve_status(entry)
        if status_filter is not None and status != status_filter:
            continue
        out.append(ModuleInfo(
            mod_id=mod_id,
            description=entry.description,
            version=entry.version,
            requires=list(entry.requires),
            status=status,
            source_module=source_module,
        ))
    return out


@dataclass(frozen=True)
class DependencyReport:
    """Structured view of which modules are runnable in this env."""
    n_total: int
    n_runnable: int
    n_missing_deps: int
    runnable: List[str]                       # mod_ids
    missing: Dict[str, List[str]]             # mod_id -> missing dep keys
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "n_total": self.n_total,
            "n_runnable": self.n_runnable,
            "n_missing_deps": self.n_missing_deps,
            "runnable": list(self.runnable),
            "missing": dict(self.missing),
            "notes": list(self.notes),
        }


# Mapping from a "requires" key (used by the v0.4.14 modules) to the
# python import name we should test for. The v0.4.14 modules use
# string keys like "torch", "open_clip", "dover", etc. Many of these
# correspond directly to a python package name; some (like "dover")
# are pre-trained model weights, NOT pip packages. We make the
# distinction explicit.
_DEP_KEY_TO_IMPORT = {
    "torch": "torch",
    "torchvision": "torchvision",
    "open_clip": "open_clip",
    "transformers": "transformers",
    "onnxruntime": "onnxruntime",
    "dtaidistance": "dtaidistance",
    "fastdtw": "fastdtw",
}

# Dependencies that are model-weights, not python packages. We can't
# verify their presence by importlib; we report them as "weights:foo"
# in the missing list with a note.
_WEIGHT_DEPS = {"dover", "fast_vqa", "clip"}


def validate_dependencies(
    *,
    extra_mapping: Optional[Dict[str, str]] = None,
) -> DependencyReport:
    """Check that every registered module's deps can be imported.

    Parameters
    ----------
    extra_mapping : dict, optional
        Extra entries for the dep-key → import-name table. Useful when
        a downstream consumer registers modules with custom keys.

    Returns
    -------
    DependencyReport
        Frozen, JSON-serializable. Modules with **no** unmet deps go
        into ``runnable``; modules with unmet deps go into ``missing``
        (mapping mod_id → the list of dep keys that failed).

    Notes
    -----
    Optional weight-only dependencies (DOVER, FAST-VQA, CLIP weights)
    are treated honestly: they are listed in ``missing`` with a
    ``"weights:..."`` prefix, with a corresponding entry in ``notes``
    that explains they cannot be verified by importlib alone.
    """
    mapping: Dict[str, str] = dict(_DEP_KEY_TO_IMPORT)
    if extra_mapping:
        mapping.update(extra_mapping)

    runnable: List[str] = []
    missing: Dict[str, List[str]] = {}
    notes: List[str] = []
    weight_warned = False

    # Cache import results across modules.
    import_cache: Dict[str, bool] = {}

    def _can_import(name: str) -> bool:
        if name in import_cache:
            return import_cache[name]
        try:
            importlib.import_module(name)
            import_cache[name] = True
        except Exception:
            import_cache[name] = False
        return import_cache[name]

    for mod_id, entry in all_modules().items():
        unmet: List[str] = []
        for key in entry.requires:
            if key in _WEIGHT_DEPS:
                unmet.append(f"weights:{key}")
                if not weight_warned:
                    notes.append(
                        "Some modules require pre-trained model weights "
                        "(DOVER, FAST-VQA, CLIP) which cannot be verified by "
                        "importlib. The 'weights:...' entries indicate model "
                        "files that must be downloaded separately."
                    )
                    weight_warned = True
                continue
            import_name = mapping.get(key, key)
            if not _can_import(import_name):
                unmet.append(key)
        if unmet:
            missing[mod_id] = unmet
        else:
            runnable.append(mod_id)

    return DependencyReport(
        n_total=len(all_modules()),
        n_runnable=len(runnable),
        n_missing_deps=len(missing),
        runnable=sorted(runnable),
        missing={k: missing[k] for k in sorted(missing)},
        notes=notes,
    )


__all__ = [
    "ModuleInfo",
    "DependencyReport",
    "list_modules",
    "validate_dependencies",
    "VALID_STATUSES",
]
