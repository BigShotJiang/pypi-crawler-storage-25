"""Registry orchestrator (v1.0.0 phase 2.1, Item 5).

This package layers a higher-level registry orchestrator on top of the
existing ``cineinfini.core.registry`` (which holds the ``@register_module``
decorator and the 21 v0.4.14 module registrations). The lower layer is
unchanged and remains the source of truth for "what modules exist".

What the orchestrator adds:

- :func:`list_modules` — enumerate all registered modules, optionally
  filtering by ``__status__`` ("stable" | "staging" | "experimental").
  This consumes the ``__status__`` metadata added in Item 6.
- :func:`validate_dependencies` — check that every registered module's
  Python-import dependencies are reachable in the current environment.
  Returns a structured report rather than raising — callers (e.g. the
  CLI ``cineinfini repro-info``) can decide how to surface it.

Design decisions (per the project's anti-bloat policy):

- We do NOT replace ``core/registry.py``. The 21 existing modules
  continue to register themselves the same way they always have.
- We do NOT introduce a plugin discovery hook in this commit. The
  feature-roadmap document lists ``plugins/`` as Phase 2.3+; adding it
  now would be premature and likely produce stubs.
- The orchestrator is purely read-only over the module registry: it
  never imports a module unless asked to (lazy ``validate_dependencies``).
"""
from __future__ import annotations

from .orchestrator import (
    list_modules,
    validate_dependencies,
    ModuleInfo,
    DependencyReport,
)

__status__ = "staging"
__version__ = "1.0.0"

__all__ = [
    "list_modules",
    "validate_dependencies",
    "ModuleInfo",
    "DependencyReport",
]
