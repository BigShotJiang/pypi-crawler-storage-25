"""Tests for cineinfini.registry orchestrator (Item 5)."""
from __future__ import annotations

import json

import pytest

from cineinfini.registry import (
    list_modules,
    validate_dependencies,
    ModuleInfo,
    DependencyReport,
)
from cineinfini.registry.orchestrator import VALID_STATUSES


# Importing cineinfini.modules.* triggers all v0.4.14 module
# registrations (decorator side-effects). That's the standard way to
# populate the registry.
def _ensure_modules_loaded():
    import importlib
    importlib.import_module("cineinfini.modules")


def test_list_modules_returns_modules_after_import():
    _ensure_modules_loaded()
    mods = list_modules()
    # The repo ships 21 v0.4.14 modules; allow some flex if extras are
    # registered later.
    assert len(mods) >= 10
    assert all(isinstance(m, ModuleInfo) for m in mods)


def test_list_modules_sorted_by_id():
    _ensure_modules_loaded()
    mods = list_modules()
    ids = [m.mod_id for m in mods]
    assert ids == sorted(ids)


def test_list_modules_invalid_status_raises():
    with pytest.raises(ValueError, match="status_filter"):
        list_modules(status_filter="bogus")


def test_list_modules_status_filter_excludes_modules_without_status():
    _ensure_modules_loaded()
    # No __status__ has been added yet → filter by "stable" returns
    # only modules that DO have __status__ == "stable". If none do,
    # the result is empty.
    stable_only = list_modules(status_filter="stable")
    for m in stable_only:
        assert m.status == "stable"


def test_validate_dependencies_returns_structured_report():
    _ensure_modules_loaded()
    report = validate_dependencies()
    assert isinstance(report, DependencyReport)
    assert report.n_total == report.n_runnable + report.n_missing_deps
    # Result is JSON-serializable.
    json.dumps(report.to_dict(), default=str)


def test_validate_dependencies_reports_runnable_pure_cv_modules():
    """Pure-CV modules should be marked runnable in any environment with
    numpy + scipy + opencv (which our test env has)."""
    _ensure_modules_loaded()
    report = validate_dependencies()
    # We just check the report is consistent: no module appears in both
    # runnable and missing.
    runnable_set = set(report.runnable)
    missing_set = set(report.missing.keys())
    assert not (runnable_set & missing_set)


def test_validate_dependencies_weight_deps_flagged_with_prefix():
    _ensure_modules_loaded()
    report = validate_dependencies()
    # Look for any "weights:..." entry in any module's missing list.
    has_weight_entry = any(
        any(d.startswith("weights:") for d in deps)
        for deps in report.missing.values()
    )
    if has_weight_entry:
        # If we found one, there must be a note explaining it.
        assert any("weights" in n.lower() for n in report.notes)


def test_module_info_serializable():
    _ensure_modules_loaded()
    mods = list_modules()
    if mods:
        d = mods[0].to_dict()
        # Round-trip through JSON.
        s = json.dumps(d, default=str)
        assert "mod_id" in s


def test_valid_statuses_constant():
    assert "stable" in VALID_STATUSES
    assert "staging" in VALID_STATUSES
    assert "experimental" in VALID_STATUSES
    assert len(VALID_STATUSES) == 3
