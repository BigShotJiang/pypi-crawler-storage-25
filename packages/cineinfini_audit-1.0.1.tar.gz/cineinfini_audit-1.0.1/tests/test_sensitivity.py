"""Tests for cineinfini.eval.sensitivity (Item 3)."""
from __future__ import annotations

import json

import numpy as np
import pytest
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold

from cineinfini.eval.sensitivity import (
    HyperparamPoint,
    SensitivityReport,
    hyperparameter_sensitivity,
    __status__,
    __version__,
)


# -----------------------------------------------------------------------------
# Module status
# -----------------------------------------------------------------------------

def test_module_status_metadata():
    assert __status__ == "staging"
    assert __version__ == "1.0.0"


# -----------------------------------------------------------------------------
# Synthetic data fixture
# -----------------------------------------------------------------------------

def _make_dataset(seed: int = 0, n: int = 200, d: int = 8):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, d))
    # y is a noisy non-linear function of X — RF should beat ridge.
    y = (X[:, 0] ** 2) + 0.5 * X[:, 1] + rng.normal(size=n) * 0.3
    return X, y


def _rf_factory(params):
    return RandomForestRegressor(random_state=42, n_jobs=1, **params)


# -----------------------------------------------------------------------------
# hyperparameter_sensitivity
# -----------------------------------------------------------------------------

def test_sensitivity_basic_run():
    X, y = _make_dataset()
    grid = [{"n_estimators": 50}, {"n_estimators": 100}]
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    rep = hyperparameter_sensitivity(
        X, y,
        grid=grid,
        model_factory=_rf_factory,
        cv=cv,
        dataset_name="synth",
        n_bootstrap=200,
    )
    assert isinstance(rep, SensitivityReport)
    assert rep.n == 200
    assert len(rep.points) == 2
    assert rep.srcc_min <= rep.srcc_max
    assert rep.srcc_delta == pytest.approx(rep.srcc_max - rep.srcc_min, abs=1e-12)


def test_sensitivity_empty_grid_raises():
    X, y = _make_dataset(n=50)
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    with pytest.raises(ValueError, match="grid is empty"):
        hyperparameter_sensitivity(X, y, grid=[],
                                   model_factory=_rf_factory, cv=cv)


def test_sensitivity_xy_mismatch_raises():
    X = np.zeros((10, 3))
    y = np.zeros(9)
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    with pytest.raises(ValueError, match="row count mismatch"):
        hyperparameter_sensitivity(X, y, grid=[{"n_estimators": 5}],
                                   model_factory=_rf_factory, cv=cv)


def test_sensitivity_x_not_2d_raises():
    X = np.zeros(10)
    y = np.zeros(10)
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    with pytest.raises(ValueError, match="2-D"):
        hyperparameter_sensitivity(X, y, grid=[{"n_estimators": 5}],
                                   model_factory=_rf_factory, cv=cv)


def test_sensitivity_grid_non_dict_raises():
    X, y = _make_dataset(n=50)
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    with pytest.raises(ValueError, match="not a dict"):
        hyperparameter_sensitivity(X, y, grid=["bogus"],
                                   model_factory=_rf_factory, cv=cv)


def test_sensitivity_config_ids_are_unique_and_stable():
    X, y = _make_dataset()
    grid = [
        {"n_estimators": 50, "max_depth": None},
        {"n_estimators": 100, "max_depth": None},
        {"n_estimators": 50, "max_depth": 8},
    ]
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    rep = hyperparameter_sensitivity(X, y, grid=grid,
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    ids = [p.config_id for p in rep.points]
    assert len(set(ids)) == len(ids)  # unique
    # Stable order: sorted-by-key inside each config.
    assert ids[0] == "max_depth=None_n_estimators=50"


def test_sensitivity_serialization_roundtrip():
    X, y = _make_dataset(n=120)
    grid = [{"n_estimators": 50}]
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    rep = hyperparameter_sensitivity(X, y, grid=grid,
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    s = json.dumps(rep.to_dict(), default=str)
    parsed = json.loads(s)
    assert parsed["n"] == 120
    assert parsed["n_configs"] == 1
    assert parsed["points"][0]["model_class"] == "RandomForestRegressor"


def test_sensitivity_widest_ci_flagged():
    X, y = _make_dataset(n=80)   # smaller n → wider CI
    grid = [{"n_estimators": 50}, {"n_estimators": 200}]
    cv = KFold(n_splits=4, shuffle=True, random_state=42)
    rep = hyperparameter_sensitivity(X, y, grid=grid,
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    # most_robust_config is the LEAST robust (widest CI). Just check it's
    # one of the configs we passed in.
    assert rep.most_robust_config in [p.config_id for p in rep.points]


def test_sensitivity_srcc_in_expected_range():
    X, y = _make_dataset(n=300)
    grid = [{"n_estimators": 100}]
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    rep = hyperparameter_sensitivity(X, y, grid=grid,
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    # Synthetic data is mildly predictable; SRCC should be positive.
    assert rep.srcc_min > 0.0
    assert rep.srcc_max <= 1.0


def test_sensitivity_str_representation():
    X, y = _make_dataset(n=100)
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    rep = hyperparameter_sensitivity(X, y, grid=[{"n_estimators": 50}],
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    s = str(rep)
    assert "Sensitivity report" in s
    assert "Δ=" in s


# -----------------------------------------------------------------------------
# HyperparamPoint
# -----------------------------------------------------------------------------

def test_hyperparam_point_properties_match_eval_report():
    X, y = _make_dataset(n=100)
    grid = [{"n_estimators": 50}]
    cv = KFold(n_splits=3, shuffle=True, random_state=0)
    rep = hyperparameter_sensitivity(X, y, grid=grid,
                                     model_factory=_rf_factory, cv=cv,
                                     n_bootstrap=200)
    p = rep.points[0]
    assert p.srcc == p.eval_report["srcc"]["coefficient"]
    assert p.srcc_ci_low == p.eval_report["srcc"]["ci_low"]
    assert p.srcc_ci_high == p.eval_report["srcc"]["ci_high"]
