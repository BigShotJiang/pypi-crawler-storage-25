"""Tests for cineinfini.eval.honest_reporting.

Every test is deterministic — no RNG, no time-dependent assertion.
The module under test is itself fully deterministic given the same
inputs (including the optional ``now`` parameter for build_honest_report).
"""
from __future__ import annotations

import math
from datetime import datetime, timezone

import pytest

from cineinfini.eval.honest_reporting import (
    Claim,
    ClaimEvidence,
    ClaimTier,
    DEFAULT_POLICY,
    HonestReport,
    TieringPolicy,
    build_honest_report,
    claim_from_evaluation_report,
    detect_reviewer_risks,
    tier_claim,
)


# Helper: a minimally-evidenced "perfect" Tier A claim
def _make_perfect_claim(claim_id: str = "perfect") -> Claim:
    return Claim(
        claim_id=claim_id,
        statement="Strong, replicated, well-powered correlation result.",
        evidence=ClaimEvidence(
            point_estimate=0.6,
            ci_low=0.5,
            ci_high=0.7,
            n=400,
            p_value=1e-30,
            effect_kind="correlation",
        ),
        dataset="DemoSet",
        n_replications=2,
        requires_external_rerun=False,
    )


# ---------------------------------------------------------------------------
# 1. Tier assignment
# ---------------------------------------------------------------------------

def test_tier_a_when_all_conditions_met():
    tc = tier_claim(_make_perfect_claim())
    assert tc.assigned_tier == ClaimTier.A
    # All six R-A* rules must appear
    for rid in ("R-A1", "R-A2", "R-A3", "R-A4", "R-A5", "R-A6"):
        assert rid in tc.rules_triggered
    assert tc.softening_suggestion is None


def test_tier_b_when_single_dataset():
    c = Claim(
        claim_id="single_ds",
        statement="Strong correlation on one dataset only.",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=400, p_value=1e-30, effect_kind="correlation",
        ),
        n_replications=1,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.B
    # Should record the missing rule explicitly.
    assert any(r.startswith("missing:R-A5") for r in tc.rules_triggered)


def test_tier_b_when_external_sota_rerun_pending():
    c = Claim(
        claim_id="ext_sota",
        statement="Match against externally-reported SOTA without local rerun.",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=400, p_value=1e-30, effect_kind="correlation",
        ),
        n_replications=2,  # has 2 replications but external SOTA
        requires_external_rerun=True,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.B
    assert any(r.startswith("missing:R-A6") for r in tc.rules_triggered)


def test_tier_c_when_ci_overlaps_zero():
    c = Claim(
        claim_id="overlap",
        statement="Correlation whose CI crosses zero.",
        evidence=ClaimEvidence(
            point_estimate=0.1, ci_low=-0.1, ci_high=0.3,
            n=200, p_value=0.001, effect_kind="correlation",
        ),
        n_replications=2,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.C
    assert "R-C2" in tc.rules_triggered


def test_tier_c_when_n_too_small():
    c = Claim(
        claim_id="small",
        statement="Same protocol but on a 30-sample pilot.",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=30, p_value=1e-9, effect_kind="correlation",
        ),
        n_replications=2,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.C
    assert "R-C3" in tc.rules_triggered


def test_tier_c_when_p_value_high():
    c = Claim(
        claim_id="weak_p",
        statement="Sizeable but not significant correlation.",
        evidence=ClaimEvidence(
            point_estimate=0.5, ci_low=0.4, ci_high=0.6,
            n=200, p_value=0.07, effect_kind="correlation",
        ),
        n_replications=2,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.C
    assert "R-C4" in tc.rules_triggered


def test_tier_c_softening_suggestion_present():
    # Claim with two C-rule failures -> softening should be a single
    # non-empty string mentioning both issues.
    c = Claim(
        claim_id="multi_c",
        statement="Pilot finding with no CI and small n.",
        evidence=ClaimEvidence(
            point_estimate=0.4, n=20, effect_kind="correlation",
        ),
        n_replications=1,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.C
    assert tc.softening_suggestion is not None
    assert "bootstrap" in tc.softening_suggestion.lower()


def test_tier_a_with_error_metric_rmse():
    c = Claim(
        claim_id="rmse_demo",
        statement="RMSE on MOS scale, low and tight.",
        evidence=ClaimEvidence(
            point_estimate=0.5, ci_low=0.45, ci_high=0.55,
            n=400, p_value=1e-30, effect_kind="error",
        ),
        n_replications=2,
    )
    tc = tier_claim(c)
    # Rule R-A2 is automatically satisfied for error metrics.
    assert tc.assigned_tier == ClaimTier.A


def test_tier_c_for_classification_below_random():
    c = Claim(
        claim_id="weak_clf",
        statement="Classifier accuracy CI overlaps random baseline.",
        evidence=ClaimEvidence(
            point_estimate=0.55, ci_low=0.45, ci_high=0.65,
            n=400, p_value=0.05, effect_kind="classification",
        ),
        n_replications=2,
    )
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.C
    assert "R-C2" in tc.rules_triggered


# ---------------------------------------------------------------------------
# 2. ClaimEvidence / Claim validation (fail-fast)
# ---------------------------------------------------------------------------

def test_invalid_ci_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, ci_low=0.7, ci_high=0.3)


def test_partial_ci_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, ci_low=0.4, ci_high=None)
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, ci_low=None, ci_high=0.6)


def test_nan_estimate_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=float("nan"))


def test_inf_estimate_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=float("inf"))


def test_unknown_effect_kind_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, effect_kind="bogus")


def test_n_zero_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, n=0)


def test_p_value_out_of_range_raises():
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, p_value=1.5)
    with pytest.raises(ValueError):
        ClaimEvidence(point_estimate=0.5, p_value=-0.01)


def test_too_long_statement_raises():
    with pytest.raises(ValueError):
        Claim(
            claim_id="long",
            statement="x" * 250,
            evidence=ClaimEvidence(point_estimate=0.5),
        )


def test_n_replications_below_one_raises():
    with pytest.raises(ValueError):
        Claim(
            claim_id="noreps",
            statement="No replications.",
            evidence=ClaimEvidence(point_estimate=0.5),
            n_replications=0,
        )


def test_duplicate_claim_id_raises():
    a = _make_perfect_claim("dupe")
    b = _make_perfect_claim("dupe")
    with pytest.raises(ValueError):
        build_honest_report([a, b])


# ---------------------------------------------------------------------------
# 3. Reviewer-risk detectors
# ---------------------------------------------------------------------------

def test_risk_ci_overlaps_null_fires():
    c = Claim(
        claim_id="ovl",
        statement="Correlation whose CI crosses zero.",
        evidence=ClaimEvidence(
            point_estimate=0.1, ci_low=-0.1, ci_high=0.3,
            n=200, p_value=0.5, effect_kind="correlation",
        ),
    )
    risks = detect_reviewer_risks([c])
    ids = {r.risk_id for r in risks}
    assert "ci_overlaps_null" in ids


def test_risk_external_sota_no_local_rerun_fires():
    c = Claim(
        claim_id="ext",
        statement="Comparison vs paper-reported SOTA.",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=400, p_value=1e-9,
        ),
        requires_external_rerun=True,
    )
    risks = detect_reviewer_risks([c])
    assert "external_sota_no_local_rerun" in {r.risk_id for r in risks}


def test_risk_unrealistic_effect_size_fires():
    c = Claim(
        claim_id="suspicious",
        statement="Suspiciously high single-dataset correlation.",
        evidence=ClaimEvidence(
            point_estimate=0.99, ci_low=0.97, ci_high=1.0,
            n=400, p_value=1e-30, effect_kind="correlation",
        ),
        n_replications=1,  # not yet replicated
    )
    risks = detect_reviewer_risks([c])
    assert "unrealistic_effect_size" in {r.risk_id for r in risks}


def test_risk_p_value_without_correction_fires_at_three():
    claims = [
        Claim(
            claim_id=f"p{i}",
            statement="p-bearing claim.",
            evidence=ClaimEvidence(
                point_estimate=0.3 + i * 0.01,
                ci_low=0.2, ci_high=0.4, n=300, p_value=0.001,
            ),
            n_replications=2,
        )
        for i in range(3)
    ]
    risks = detect_reviewer_risks(claims)
    assert "p_value_without_correction" in {r.risk_id for r in risks}


def test_risk_p_value_without_correction_skipped_when_fdr_mentioned():
    claims = [
        Claim(
            claim_id=f"p{i}",
            statement="p-bearing claim with FDR explicitly applied.",
            evidence=ClaimEvidence(
                point_estimate=0.3 + i * 0.01,
                ci_low=0.2, ci_high=0.4, n=300, p_value=0.001,
                notes=["Benjamini-Hochberg FDR applied across the family."],
            ),
            n_replications=2,
        )
        for i in range(3)
    ]
    risks = detect_reviewer_risks(claims)
    assert "p_value_without_correction" not in {r.risk_id for r in risks}


def test_risk_inconsistent_n_fires_when_2x_difference():
    big = Claim(
        claim_id="big",
        statement="Big sample claim.",
        evidence=ClaimEvidence(
            point_estimate=0.4, ci_low=0.3, ci_high=0.5,
            n=400, p_value=1e-9,
        ),
        n_replications=2,
    )
    small = Claim(
        claim_id="small",
        statement="Small sample claim.",
        evidence=ClaimEvidence(
            point_estimate=0.4, ci_low=0.2, ci_high=0.6,
            n=50, p_value=0.005,
        ),
        n_replications=2,
    )
    risks = detect_reviewer_risks([big, small])
    assert "inconsistent_n_across_claims" in {r.risk_id for r in risks}


def test_risk_ordering_high_first_then_lexico():
    # Construct a claim that triggers high-severity 'missing_ci' AND
    # medium-severity 'small_sample' AND medium-severity
    # 'single_dataset_strong_claim' simultaneously.
    c = Claim(
        claim_id="multi",
        statement="No CI, small n, single dataset.",
        evidence=ClaimEvidence(point_estimate=0.4, n=30, p_value=0.001),
        n_replications=1,
    )
    risks = detect_reviewer_risks([c])
    sevs = [r.severity for r in risks]
    # All highs must come before all mediums must come before all lows.
    last = "high"
    order = ["high", "medium", "low"]
    last_idx = 0
    for s in sevs:
        i = order.index(s)
        assert i >= last_idx
        last_idx = i
    # And within the same severity, lexicographic by risk_id.
    medium_ids = [r.risk_id for r in risks if r.severity == "medium"]
    assert medium_ids == sorted(medium_ids)


# ---------------------------------------------------------------------------
# 4. Determinism and Markdown rendering
# ---------------------------------------------------------------------------

_FROZEN_NOW = datetime(2026, 5, 8, 12, 0, 0, tzinfo=timezone.utc)


def test_to_markdown_deterministic_byte_for_byte():
    claims = [
        _make_perfect_claim("a"),
        _make_perfect_claim("b"),
    ]
    r1 = build_honest_report(claims, title="Deterministic test", now=_FROZEN_NOW)
    r2 = build_honest_report(claims, title="Deterministic test", now=_FROZEN_NOW)
    md1 = r1.to_markdown()
    md2 = r2.to_markdown()
    assert md1 == md2


def test_to_markdown_handles_empty_claims_list():
    r = build_honest_report([], title="Empty", now=_FROZEN_NOW)
    md = r.to_markdown()
    assert "# Empty" in md
    assert "No claims provided." in md
    # Summary table should still render.
    assert "| **A** | 0 |" in md


def test_md_escape_pipes_in_statement_does_not_break_layout():
    c = Claim(
        claim_id="pipes",
        statement="Comparison: A | B | C across all datasets.",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=400, p_value=1e-30,
        ),
        n_replications=2,
    )
    r = build_honest_report([c], now=_FROZEN_NOW)
    md = r.to_markdown()
    # Pipes inside the claim must be escaped, not raw.
    assert "A \\| B \\| C" in md or r"A \| B \| C" in md


def test_appendix_includes_all_rule_ids():
    r = build_honest_report([_make_perfect_claim()], now=_FROZEN_NOW)
    md = r.to_markdown(include_appendix=True)
    for rid in ("R-A1", "R-A2", "R-A3", "R-A4", "R-A5", "R-A6",
                "R-C1", "R-C2", "R-C3", "R-C4", "R-C5"):
        assert rid in md
    # All eight risk detector IDs must appear in the appendix.
    for risk_id in (
        "ci_overlaps_null", "small_sample", "single_dataset_strong_claim",
        "external_sota_no_local_rerun", "missing_ci",
        "p_value_without_correction", "unrealistic_effect_size",
        "inconsistent_n_across_claims",
    ):
        assert risk_id in md


def test_appendix_omitted_when_requested():
    r = build_honest_report([_make_perfect_claim()], now=_FROZEN_NOW)
    md = r.to_markdown(include_appendix=False)
    assert "Appendix" not in md


def test_summary_counts_match_tier_assignments():
    claims = [
        _make_perfect_claim("a"),  # Tier A
        Claim(
            claim_id="b",
            statement="Single-dataset Tier B claim.",
            evidence=ClaimEvidence(
                point_estimate=0.6, ci_low=0.5, ci_high=0.7,
                n=400, p_value=1e-30, effect_kind="correlation",
            ),
            n_replications=1,
        ),  # Tier B
        Claim(
            claim_id="c",
            statement="Underpowered, no CI: Tier C.",
            evidence=ClaimEvidence(point_estimate=0.3, n=20),
            n_replications=1,
        ),  # Tier C
    ]
    r = build_honest_report(claims, now=_FROZEN_NOW)
    assert r.summary_counts == {"tier_A": 1, "tier_B": 1, "tier_C": 1}


def test_to_dict_round_trips_via_json():
    import json
    r = build_honest_report([_make_perfect_claim()], now=_FROZEN_NOW)
    d = r.to_dict()
    s = json.dumps(d, default=str)
    parsed = json.loads(s)
    assert parsed["summary_counts"]["tier_A"] == 1


# ---------------------------------------------------------------------------
# 5. claim_from_evaluation_report adapter
# ---------------------------------------------------------------------------

def _fake_eval_report() -> dict:
    return {
        "n": 392,
        "n_dropped": 0,
        "srcc": {
            "method": "SRCC",
            "coefficient": 0.5634,
            "p_value": 3.27e-34,
            "ci_low": 0.4832,
            "ci_high": 0.6290,
            "n": 392,
            "n_bootstrap": 1000,
            "confidence_level": 0.95,
        },
        "krcc": {
            "method": "KRCC",
            "coefficient": 0.40,
            "p_value": 1e-12,
            "ci_low": 0.34,
            "ci_high": 0.46,
            "n": 392,
            "n_bootstrap": 1000,
            "confidence_level": 0.95,
        },
        "plcc_fitted": {
            "method": "PLCC",
            "coefficient": 0.582,
            "p_value": 1e-32,
            "ci_low": 0.508,
            "ci_high": 0.650,
            "n": 392,
            "n_bootstrap": 1000,
            "confidence_level": 0.95,
        },
        "rmse_fitted": {
            "method": "RMSE",
            "value": 0.530,
            "ci_low": 0.488,
            "ci_high": 0.571,
            "n": 392,
            "n_bootstrap": 1000,
            "confidence_level": 0.95,
        },
        "logistic_fit": None,
        "notes": [],
    }


def test_claim_from_evaluation_report_srcc_path():
    rep = _fake_eval_report()
    c = claim_from_evaluation_report(
        rep,
        claim_id="rf_konvid_srcc",
        statement="Random Forest 16-feature predicts MOS at SRCC ~0.56 on KoNViD.",
        dataset="KoNViD-1k",
        use_metric="srcc",
        n_replications=1,
    )
    assert c.evidence.point_estimate == pytest.approx(0.5634)
    assert c.evidence.ci_low == pytest.approx(0.4832)
    assert c.evidence.ci_high == pytest.approx(0.6290)
    assert c.evidence.n == 392
    assert c.evidence.effect_kind == "correlation"
    # Tier B because n_replications=1.
    tc = tier_claim(c)
    assert tc.assigned_tier == ClaimTier.B


def test_claim_from_evaluation_report_rmse_uses_value_field():
    rep = _fake_eval_report()
    c = claim_from_evaluation_report(
        rep,
        claim_id="rf_konvid_rmse",
        statement="Logistic-fitted RMSE is 0.53 on KoNViD.",
        dataset="KoNViD-1k",
        use_metric="rmse_fitted",
    )
    assert c.evidence.point_estimate == pytest.approx(0.530)
    assert c.evidence.effect_kind == "error"


def test_claim_from_evaluation_report_unknown_metric_raises():
    rep = _fake_eval_report()
    with pytest.raises(KeyError):
        claim_from_evaluation_report(
            rep,
            claim_id="bogus",
            statement="...",
            use_metric="bogus_metric",
        )


def test_claim_from_evaluation_report_drops_nan_ci():
    rep = _fake_eval_report()
    rep["srcc"]["ci_low"] = float("nan")
    rep["srcc"]["ci_high"] = float("nan")
    c = claim_from_evaluation_report(
        rep,
        claim_id="srcc_nan_ci",
        statement="SRCC with degenerate (NaN) bootstrap CI.",
        use_metric="srcc",
    )
    # Both bounds should have been dropped to None.
    assert c.evidence.ci_low is None
    assert c.evidence.ci_high is None


# ---------------------------------------------------------------------------
# 6. TieringPolicy override
# ---------------------------------------------------------------------------

def test_tiering_policy_override_relaxes_n_threshold():
    c = Claim(
        claim_id="small",
        statement="n=30 claim, normally Tier C, but...",
        evidence=ClaimEvidence(
            point_estimate=0.6, ci_low=0.5, ci_high=0.7,
            n=30, p_value=1e-9, effect_kind="correlation",
        ),
        n_replications=2,
    )
    relaxed = TieringPolicy(min_n_for_tier_a=20)
    tc = tier_claim(c, policy=relaxed)
    assert tc.assigned_tier == ClaimTier.A


# ---------------------------------------------------------------------------
# 7. Module status metadata
# ---------------------------------------------------------------------------

def test_module_exposes_status_metadata():
    from cineinfini.eval import honest_reporting as hr
    assert hasattr(hr, "__status__")
    assert hr.__status__ in ("stable", "staging", "experimental")


def test_module_status_is_staging_at_first_release():
    from cineinfini.eval import honest_reporting as hr
    assert hr.__status__ == "staging"
