"""Tests for cineinfini.eval."""
from __future__ import annotations

import json

import numpy as np
import pytest

from cineinfini.eval import (
    apply_logistic_4p,
    bootstrap_ci,
    evaluate_predictions,
    fit_logistic_4p,
    kendall,
    krcc,
    mae,
    pearson,
    plcc,
    rmse,
    spearman,
    srcc,
    steiger_z,
)


# -----------------------------------------------------------------------------
# Pearson / Spearman / Kendall
# -----------------------------------------------------------------------------

def test_pearson_perfect_correlation():
    x = np.linspace(0, 10, 50)
    y = 2 * x + 3
    res = pearson(x, y, n_bootstrap=200)
    assert res.coefficient == pytest.approx(1.0, abs=1e-9)
    assert res.n == 50
    assert res.method == "pearson"
    # CI must contain the point estimate.
    assert res.ci_low <= res.coefficient <= res.ci_high + 1e-9


def test_pearson_anti_correlation():
    x = np.linspace(0, 10, 50)
    y = -3 * x + 1
    res = pearson(x, y, n_bootstrap=200)
    assert res.coefficient == pytest.approx(-1.0, abs=1e-9)


def test_spearman_monotone_invariant():
    rng = np.random.default_rng(0)
    x = rng.normal(size=100)
    y = np.exp(x)  # strictly monotone transform
    res = spearman(x, y, n_bootstrap=200)
    assert res.coefficient == pytest.approx(1.0, abs=1e-9)


def test_kendall_basic():
    x = [1, 2, 3, 4, 5]
    y = [1, 2, 3, 4, 5]
    res = kendall(x, y, n_bootstrap=200)
    assert res.coefficient == pytest.approx(1.0, abs=1e-9)
    assert "kendall" in res.method


def test_correlation_aliases_match():
    rng = np.random.default_rng(1)
    x = rng.normal(size=80)
    y = 0.7 * x + 0.3 * rng.normal(size=80)
    a = pearson(x, y, n_bootstrap=100)
    b = plcc(x, y, n_bootstrap=100)
    assert a.coefficient == pytest.approx(b.coefficient)
    a = spearman(x, y, n_bootstrap=100)
    b = srcc(x, y, n_bootstrap=100)
    assert a.coefficient == pytest.approx(b.coefficient)
    a = kendall(x, y, n_bootstrap=100)
    b = krcc(x, y, n_bootstrap=100)
    assert a.coefficient == pytest.approx(b.coefficient)


def test_correlation_validates_length_mismatch():
    with pytest.raises(ValueError):
        pearson([1, 2, 3], [1, 2])


def test_correlation_validates_too_few_samples():
    with pytest.raises(ValueError):
        pearson([1, 2], [1, 2])


def test_correlation_drops_nans():
    x = [1.0, 2.0, np.nan, 4.0, 5.0]
    y = [1.0, 2.0, 3.0, np.nan, 5.0]
    # 3 finite paired samples remain → must succeed.
    res = pearson(x, y, n_bootstrap=100)
    assert res.n == 3


def test_correlation_to_dict_serializable():
    res = pearson([1, 2, 3, 4, 5], [2, 4, 6, 8, 10], n_bootstrap=50)
    s = json.dumps(res.to_dict())
    assert "coefficient" in s


def test_bootstrap_ci_reproducible_with_seed():
    rng = np.random.default_rng(0)
    x = rng.normal(size=60)
    y = 0.5 * x + rng.normal(size=60) * 0.3

    def stat(a, b):
        return float(np.corrcoef(a, b)[0, 1])

    a = bootstrap_ci(x, y, stat, n_bootstrap=300, seed=42)
    b = bootstrap_ci(x, y, stat, n_bootstrap=300, seed=42)
    assert a == b


def test_bootstrap_ci_low_le_high():
    rng = np.random.default_rng(0)
    x = rng.normal(size=80)
    y = 0.4 * x + rng.normal(size=80) * 0.5
    low, high = bootstrap_ci(x, y, lambda a, b: float(np.corrcoef(a, b)[0, 1]),
                             n_bootstrap=300, seed=1)
    assert low <= high


# -----------------------------------------------------------------------------
# RMSE / MAE
# -----------------------------------------------------------------------------

def test_rmse_zero_for_identical():
    x = np.linspace(0, 1, 30)
    res = rmse(x, x, n_bootstrap=100)
    assert res.value == pytest.approx(0.0, abs=1e-12)


def test_mae_correct():
    p = np.array([1.0, 2.0, 3.0])
    t = np.array([1.5, 2.5, 3.5])
    res = mae(p, t, n_bootstrap=100)
    assert res.value == pytest.approx(0.5, abs=1e-9)


# -----------------------------------------------------------------------------
# Logistic fit
# -----------------------------------------------------------------------------

def test_logistic_fit_recovers_monotone_relation():
    rng = np.random.default_rng(2)
    raw = rng.uniform(0, 1, 200)
    # MOS-like target: monotone non-linear in raw.
    mos = 1.0 + 4.0 * (1.0 / (1.0 + np.exp(-6 * (raw - 0.5))))
    fit = fit_logistic_4p(raw, mos)
    assert fit.converged
    assert fit.n == 200
    # Fitted predictions should correlate near-perfectly with MOS.
    fitted = apply_logistic_4p(fit, raw)
    r = np.corrcoef(fitted, mos)[0, 1]
    assert r > 0.99


def test_logistic_fit_too_few_samples_raises():
    with pytest.raises(ValueError):
        fit_logistic_4p([0.1, 0.2, 0.3], [1.0, 2.0, 3.0])


def test_logistic_fit_with_linear_term():
    rng = np.random.default_rng(3)
    x = rng.uniform(0, 1, 100)
    y = 0.5 + 3.0 * x + rng.normal(size=100) * 0.05
    fit = fit_logistic_4p(x, y, with_linear=True)
    assert fit.with_linear
    assert len(fit.params) == 5


# -----------------------------------------------------------------------------
# Steiger Z
# -----------------------------------------------------------------------------

def test_steiger_z_better_metric_significantly_lower_p():
    rng = np.random.default_rng(4)
    n = 300
    mos = rng.normal(size=n)
    # metric_a is strongly correlated with MOS; metric_b is weakly.
    metric_a = 0.9 * mos + rng.normal(size=n) * 0.4
    metric_b = 0.1 * mos + rng.normal(size=n) * 1.0
    res = steiger_z(metric_a, metric_b, mos)
    assert abs(res.r_xy) > abs(res.r_xz)
    assert res.p_value < 1e-6  # very significant difference


def test_steiger_z_insignificant_when_metrics_equivalent():
    rng = np.random.default_rng(5)
    n = 300
    mos = rng.normal(size=n)
    # Two metrics with the same true correlation, just different noise.
    metric_a = 0.6 * mos + rng.normal(size=n) * 0.5
    metric_b = 0.6 * mos + rng.normal(size=n) * 0.5
    res = steiger_z(metric_a, metric_b, mos)
    assert res.p_value > 0.05


# -----------------------------------------------------------------------------
# evaluate_predictions
# -----------------------------------------------------------------------------

def test_evaluate_predictions_full_report():
    rng = np.random.default_rng(6)
    n = 200
    mos = rng.uniform(1, 5, n)
    # Predictions: monotone, on a different scale (0–1), with noise.
    raw = (mos - 1) / 4.0 + rng.normal(size=n) * 0.05
    rep = evaluate_predictions(raw, mos, n_bootstrap=200)
    assert rep.n == 200
    assert rep.n_dropped == 0
    assert rep.srcc["coefficient"] > 0.9
    assert rep.plcc_fitted["coefficient"] > 0.9
    # RMSE-after-fit should be close to the noise level.
    assert rep.rmse_fitted["value"] < 0.5
    # Logistic fit must be present and converged.
    assert rep.logistic_fit is not None
    assert rep.logistic_fit["converged"]


def test_evaluate_predictions_drops_nans_and_reports_count():
    p = [0.1, 0.2, np.nan, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    m = [1.0, 2.0, 3.0, 4.0, np.nan, 5.0, 6.0, 7.0, 8.0, 9.0]
    rep = evaluate_predictions(p, m, n_bootstrap=100)
    assert rep.n == 8
    assert rep.n_dropped == 2


def test_evaluate_predictions_skip_logistic():
    rng = np.random.default_rng(7)
    n = 150
    x = rng.uniform(1, 5, n)
    y = x + rng.normal(size=n) * 0.2
    rep = evaluate_predictions(x, y, n_bootstrap=100, fit_logistic=False)
    assert rep.logistic_fit is None
    assert rep.plcc_fitted["coefficient"] > 0.9


def test_evaluate_predictions_serializable():
    rng = np.random.default_rng(8)
    x = rng.uniform(0, 1, 50)
    y = 2 * x + rng.normal(size=50) * 0.1
    rep = evaluate_predictions(x, y, n_bootstrap=100)
    s = json.dumps(rep.to_dict(), default=str)
    assert "srcc" in s
    assert "plcc_fitted" in s
