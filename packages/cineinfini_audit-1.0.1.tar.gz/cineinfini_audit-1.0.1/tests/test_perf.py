"""Tests for cineinfini.perf."""
from __future__ import annotations

import time

import pytest

from cineinfini.perf import (
    DeviceInfo,
    ParallelMap,
    PerformanceProfiler,
    query_devices,
    run_parallel,
)
from cineinfini.perf.parallel import WorkerError


# -----------------------------------------------------------------------------
# Device info
# -----------------------------------------------------------------------------

def test_query_devices_returns_basic_info():
    info = query_devices()
    assert isinstance(info, DeviceInfo)
    assert info.cpu_count_logical is not None and info.cpu_count_logical >= 1
    # cuda_available defaults to False if torch missing — must be bool either way.
    assert isinstance(info.cuda_available, bool)
    assert isinstance(info.mps_available, bool)


def test_recommended_workers_clamps_to_at_least_one():
    info = DeviceInfo(cpu_count_logical=1)
    assert info.recommended_workers() == 1


def test_recommended_workers_caps():
    info = DeviceInfo(cpu_count_logical=64)
    # Cap default is 8.
    assert info.recommended_workers(cap=4) == 4


def test_device_info_to_dict_serializable():
    import json
    info = query_devices()
    json.dumps(info.to_dict(), default=str)


# -----------------------------------------------------------------------------
# ParallelMap
# -----------------------------------------------------------------------------

def _square(x: int) -> int:
    return x * x


def test_parallel_map_serial_path():
    with ParallelMap(n_workers=1) as pmap:
        assert pmap.map(_square, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]


def test_parallel_map_threaded():
    with ParallelMap(n_workers=4, backend="thread") as pmap:
        result = pmap.map(_square, list(range(20)))
    assert result == [i * i for i in range(20)]


def test_parallel_map_preserves_input_order():
    def slow_for_small_indices(x: int) -> int:
        # Tasks finish in non-input order, but we should still get
        # output in input order.
        time.sleep(0.01 if x % 2 == 0 else 0.0)
        return x * 10
    with ParallelMap(n_workers=4) as pmap:
        result = pmap.map(slow_for_small_indices, list(range(10)))
    assert result == [i * 10 for i in range(10)]


def test_parallel_map_raises_by_default():
    def boom(x: int) -> int:
        if x == 3:
            raise ValueError("nope")
        return x

    with ParallelMap(n_workers=2) as pmap:
        with pytest.raises(ValueError):
            pmap.map(boom, [1, 2, 3, 4])


def test_parallel_map_records_errors_when_asked():
    def boom(x: int) -> int:
        if x == 3:
            raise ValueError("nope")
        return x

    with ParallelMap(n_workers=2) as pmap:
        result = pmap.map(boom, [1, 2, 3, 4], raise_on_error=False)
    assert result[0] == 1
    assert result[1] == 2
    assert isinstance(result[2], WorkerError)
    assert result[2].error_type == "ValueError"
    assert result[3] == 4


def test_run_parallel_helper():
    out = run_parallel(_square, [1, 2, 3], n_workers=2)
    assert out == [1, 4, 9]


def test_parallel_map_rejects_bad_args():
    with pytest.raises(ValueError):
        ParallelMap(n_workers=0)
    with pytest.raises(ValueError):
        ParallelMap(n_workers=2, backend="bogus")


# -----------------------------------------------------------------------------
# Profiler
# -----------------------------------------------------------------------------

def test_profiler_records_a_scope():
    prof = PerformanceProfiler()
    with prof.scope("foo"):
        time.sleep(0.005)
    stats = prof.stats("foo")
    assert stats is not None
    assert stats["count"] == 1
    assert stats["total_s"] >= 0.004


def test_profiler_aggregates_multiple_calls():
    prof = PerformanceProfiler()
    for _ in range(5):
        with prof.scope("bar"):
            pass
    stats = prof.stats("bar")
    assert stats["count"] == 5


def test_profiler_returns_none_for_unknown_scope():
    prof = PerformanceProfiler()
    assert prof.stats("never_called") is None


def test_profiler_report_covers_all_scopes():
    prof = PerformanceProfiler()
    with prof.scope("a"):
        pass
    with prof.scope("b"):
        pass
    rep = prof.report()
    assert set(rep.keys()) == {"a", "b"}


def test_profiler_reset_clears_state():
    prof = PerformanceProfiler()
    with prof.scope("x"):
        pass
    prof.reset()
    assert prof.stats("x") is None


def test_profiler_manual_record():
    prof = PerformanceProfiler()
    prof.record("manual", 0.123)
    prof.record("manual", 0.456)
    stats = prof.stats("manual")
    assert stats["count"] == 2
    assert stats["total_s"] == pytest.approx(0.579)
