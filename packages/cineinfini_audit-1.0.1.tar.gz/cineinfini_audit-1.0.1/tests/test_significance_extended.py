"""Tests for cineinfini.eval.significance — extended (Item 2).

Covers ks_test_distribution_match (KS 2-sample) and
benjamini_hochberg_fdr (BH step-up). The existing steiger_z tests
remain in tests/test_eval.py; we add a regression test here to make
sure the rewrite did not change steiger_z behaviour.
"""
from __future__ import annotations

import json
import math

import numpy as np
import pytest

from cineinfini.eval.significance import (
    ks_test_distribution_match,
    benjamini_hochberg_fdr,
    steiger_z,
    DistributionMatchResult,
    FDRResult,
    KS_MIN_SAMPLE_SIZE,
    __status__,
    __version__,
)


# -----------------------------------------------------------------------------
# Module status
# -----------------------------------------------------------------------------

def test_module_exposes_status_metadata():
    assert __status__ in ("stable", "staging", "experimental")


def test_module_status_is_staging_at_first_release():
    assert __status__ == "staging"
    assert __version__ == "1.1.0"


# -----------------------------------------------------------------------------
# KS test
# -----------------------------------------------------------------------------

def test_ks_identical_samples_returns_p_value_1():
    rng = np.random.default_rng(0)
    sample = rng.normal(size=200)
    res = ks_test_distribution_match(sample, sample, alpha=0.05)
    assert res.ks_statistic == 0.0
    assert res.p_value == pytest.approx(1.0, abs=1e-9)
    assert res.is_representative is True
    assert res.method == "ks_2samp"


def test_ks_disjoint_samples_rejects_null():
    a = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    b = np.array([10.0, 11.0, 12.0, 13.0, 14.0])
    res = ks_test_distribution_match(a, b, alpha=0.05)
    assert res.ks_statistic == pytest.approx(1.0)
    assert res.is_representative is False


def test_ks_subsample_of_normal_is_representative():
    rng = np.random.default_rng(42)
    full = rng.normal(loc=3.0, scale=0.7, size=200)
    # Random subsample of size 80 of the same distribution
    idx = rng.choice(len(full), size=80, replace=False)
    sub = full[idx]
    res = ks_test_distribution_match(full, sub, alpha=0.05)
    # A truly drawn subsample should not be rejected at α=0.05
    assert res.is_representative is True
    assert res.n_a == 200
    assert res.n_b == 80


def test_ks_drop_nans_default():
    a = np.array([1.0, 2.0, np.nan, 3.0, 4.0, 5.0, 6.0])
    b = np.array([1.5, 2.5, 3.5, 4.5, 5.5])
    res = ks_test_distribution_match(a, b)
    assert res.n_a == 6  # 1 NaN dropped
    assert any("non-finite" in n for n in res.notes)


def test_ks_drop_nans_false_raises():
    a = np.array([1.0, 2.0, np.nan, 3.0, 4.0, 5.0])
    b = np.array([1.5, 2.5, 3.5, 4.5, 5.5])
    with pytest.raises(ValueError, match="non-finite"):
        ks_test_distribution_match(a, b, drop_nans=False)


def test_ks_n_too_small_raises():
    a = [1.0, 2.0, 3.0]   # only 3 finite values, < KS_MIN_SAMPLE_SIZE=5
    b = [1.5, 2.5, 3.5, 4.5, 5.5]
    with pytest.raises(ValueError, match="fewer than"):
        ks_test_distribution_match(a, b)


def test_ks_alpha_out_of_range_raises():
    a = np.linspace(0, 1, 10)
    b = np.linspace(0, 1, 10)
    with pytest.raises(ValueError, match="alpha"):
        ks_test_distribution_match(a, b, alpha=1.0)
    with pytest.raises(ValueError, match="alpha"):
        ks_test_distribution_match(a, b, alpha=0.0)
    with pytest.raises(ValueError, match="alpha"):
        ks_test_distribution_match(a, b, alpha=-0.1)


def test_ks_to_dict_serializable():
    rng = np.random.default_rng(1)
    res = ks_test_distribution_match(rng.normal(size=100), rng.normal(size=100))
    d = res.to_dict()
    s = json.dumps(d, default=str)
    assert "ks_statistic" in s
    parsed = json.loads(s)
    assert parsed["n_a"] == 100
    assert parsed["n_b"] == 100


def test_ks_str_representation_contains_verdict():
    rng = np.random.default_rng(2)
    res = ks_test_distribution_match(rng.normal(size=50), rng.normal(size=50))
    s = str(res)
    assert "KS D=" in s
    assert ("representative" in s or "differ" in s)


# -----------------------------------------------------------------------------
# BH FDR
# -----------------------------------------------------------------------------

def test_bh_empty_raises():
    with pytest.raises(ValueError, match="empty"):
        benjamini_hochberg_fdr([])


def test_bh_p_out_of_range_raises():
    with pytest.raises(ValueError, match=r"\[0, 1\]"):
        benjamini_hochberg_fdr([0.5, 1.5, 0.3])
    with pytest.raises(ValueError, match=r"\[0, 1\]"):
        benjamini_hochberg_fdr([-0.01, 0.5])


def test_bh_nan_raises():
    with pytest.raises(ValueError, match="not finite"):
        benjamini_hochberg_fdr([0.1, float("nan"), 0.5])


def test_bh_inf_raises():
    with pytest.raises(ValueError, match="not finite"):
        benjamini_hochberg_fdr([0.1, float("inf"), 0.5])


def test_bh_alpha_out_of_range_raises():
    with pytest.raises(ValueError, match="alpha"):
        benjamini_hochberg_fdr([0.05], alpha=0.0)
    with pytest.raises(ValueError, match="alpha"):
        benjamini_hochberg_fdr([0.05], alpha=1.0)


def test_bh_all_p_one_no_rejection():
    res = benjamini_hochberg_fdr([1.0, 1.0, 1.0], alpha=0.05)
    assert res.n_rejected == 0
    assert res.q_values == [1.0, 1.0, 1.0]
    assert res.rejected == [False, False, False]
    assert res.n_tests == 3


def test_bh_all_p_zero_all_rejected():
    res = benjamini_hochberg_fdr([0.0, 0.0, 0.0], alpha=0.05)
    assert res.n_rejected == 3
    assert all(q == 0.0 for q in res.q_values)
    assert res.rejected == [True, True, True]


def test_bh_classic_example_from_literature():
    """The canonical worked example used in many BH tutorials.

    p-values: [0.001, 0.008, 0.039, 0.041, 0.042, 0.060, 0.074, 0.205, 0.212, 0.216]
    α = 0.05, m = 10. Critical values: [0.005, 0.010, 0.015, 0.020, 0.025,
    0.030, 0.035, 0.040, 0.045, 0.050]. The largest k with p_(k) <= c_k is
    k=5 (p_(5)=0.042 ≤ 0.025? no. p_(4)=0.041 ≤ 0.020? no. p_(3)=0.039 ≤
    0.015? no. p_(2)=0.008 ≤ 0.010? yes. p_(5)=0.042 ≤ 0.025? no. p_(6)=
    0.060 ≤ 0.030? no.). At k=2 we reject the 2 smallest. Independently
    cross-checked against R's p.adjust(method='BH').
    """
    p_values = [0.001, 0.008, 0.039, 0.041, 0.042, 0.060, 0.074,
                0.205, 0.212, 0.216]
    res = benjamini_hochberg_fdr(p_values, alpha=0.05)
    # The 2 smallest p-values are rejected (p_(1)=0.001 ≤ 0.005 ✓,
    # p_(2)=0.008 ≤ 0.010 ✓; p_(3)=0.039 ≤ 0.015 ✗ so k=2).
    assert res.n_rejected == 2
    assert res.rejected[0] is True   # 0.001 → rejected
    assert res.rejected[1] is True   # 0.008 → rejected
    assert all(r is False for r in res.rejected[2:])
    # Q-values should be monotone non-decreasing in sorted order and in [0, 1].
    sorted_idx = np.argsort(p_values)
    q_sorted = [res.q_values[i] for i in sorted_idx]
    for i in range(len(q_sorted) - 1):
        assert q_sorted[i] <= q_sorted[i + 1] + 1e-12


def test_bh_q_values_monotone_in_sorted_order():
    rng = np.random.default_rng(7)
    p_values = list(rng.uniform(0, 1, size=50))
    res = benjamini_hochberg_fdr(p_values, alpha=0.05)
    order = np.argsort(p_values)
    q_sorted = [res.q_values[i] for i in order]
    for i in range(len(q_sorted) - 1):
        assert q_sorted[i] <= q_sorted[i + 1] + 1e-12


def test_bh_q_values_in_zero_one():
    rng = np.random.default_rng(8)
    p_values = list(rng.uniform(0, 1, size=100))
    res = benjamini_hochberg_fdr(p_values, alpha=0.05)
    for q in res.q_values:
        assert 0.0 <= q <= 1.0


def test_bh_input_order_preserved():
    p_values = [0.5, 0.001, 0.04]   # not sorted
    res = benjamini_hochberg_fdr(p_values, alpha=0.05)
    # Same order in p_values and q_values
    assert res.p_values == p_values
    # The smallest p (0.001 at index 1) should have the smallest q.
    assert res.q_values[1] < res.q_values[2]
    assert res.q_values[2] < res.q_values[0]


def test_bh_single_element():
    res = benjamini_hochberg_fdr([0.05], alpha=0.05)
    assert res.n_tests == 1
    # With m=1 and α=0.05: p ≤ (1/1)*0.05 ⇒ rejected.
    assert res.n_rejected == 1


def test_bh_to_dict_serializable():
    res = benjamini_hochberg_fdr([0.001, 0.05, 0.5], alpha=0.05)
    d = res.to_dict()
    s = json.dumps(d, default=str)
    parsed = json.loads(s)
    assert parsed["n_tests"] == 3
    assert "rejected" in parsed


# -----------------------------------------------------------------------------
# Steiger Z regression — make sure the rewrite did not change behaviour
# -----------------------------------------------------------------------------

def test_existing_steiger_z_still_works():
    """Same synthetic test as in tests/test_eval.py — rewriting the
    significance module must not change steiger_z's numbers."""
    rng = np.random.default_rng(4)
    n = 300
    mos = rng.normal(size=n)
    metric_a = 0.9 * mos + rng.normal(size=n) * 0.4
    metric_b = 0.1 * mos + rng.normal(size=n) * 1.0
    res = steiger_z(metric_a, metric_b, mos)
    assert abs(res.r_xy) > abs(res.r_xz)
    assert res.p_value < 1e-6
