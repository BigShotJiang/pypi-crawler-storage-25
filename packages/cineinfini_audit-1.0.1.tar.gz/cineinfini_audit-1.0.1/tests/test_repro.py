"""Tests for cineinfini.repro."""
from __future__ import annotations

import json
import random
from pathlib import Path

import numpy as np
import pytest

from cineinfini.repro import (
    ExperimentTracker,
    capture_environment,
    compute_dir_hash,
    compute_file_hash,
    set_seeds,
)


# -----------------------------------------------------------------------------
# Seeds
# -----------------------------------------------------------------------------

def test_set_seeds_pins_python_and_numpy_rngs():
    set_seeds(123)
    py_a = random.random()
    np_a = np.random.rand()
    set_seeds(123)
    py_b = random.random()
    np_b = np.random.rand()
    assert py_a == py_b
    assert np_a == np_b


def test_set_seeds_returns_resolved_libraries():
    info = set_seeds(7)
    assert info["seed"] == 7
    assert info["random"] == 7
    assert info["numpy"] == 7
    assert info["PYTHONHASHSEED"] == "7"
    # torch may or may not be installed; either is acceptable.
    assert "torch" in info


def test_set_seeds_rejects_out_of_range_seed():
    with pytest.raises(ValueError):
        set_seeds(-1)
    with pytest.raises(ValueError):
        set_seeds(2**33)


# -----------------------------------------------------------------------------
# Environment capture
# -----------------------------------------------------------------------------

def test_capture_environment_returns_basic_fields():
    env = capture_environment()
    d = env.to_dict()
    assert d["python_version"]
    assert d["python_executable"]
    assert d["platform"]
    assert isinstance(d["deps"], dict)
    # numpy must be there since this test imports it.
    assert d["deps"]["numpy"] != "not_installed"


def test_capture_environment_handles_non_repo_dir(tmp_path):
    env = capture_environment(repo_dir=tmp_path)
    # Either git wasn't found, or it correctly reported "not a repo" via None.
    assert env.git_commit is None or isinstance(env.git_commit, str)


def test_capture_environment_json_serializable():
    env = capture_environment()
    # Should round-trip without errors.
    s = json.dumps(env.to_dict(), default=str)
    parsed = json.loads(s)
    assert parsed["python_version"] == env.python_version


# -----------------------------------------------------------------------------
# Hashing
# -----------------------------------------------------------------------------

def test_compute_file_hash_stable(tmp_path):
    p = tmp_path / "test.txt"
    p.write_bytes(b"hello world")
    h1 = compute_file_hash(p)
    h2 = compute_file_hash(p)
    assert h1 == h2
    # Known SHA-256 of "hello world".
    assert h1 == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"


def test_compute_file_hash_distinguishes_content(tmp_path):
    a = tmp_path / "a.txt"
    b = tmp_path / "b.txt"
    a.write_bytes(b"alpha")
    b.write_bytes(b"beta")
    assert compute_file_hash(a) != compute_file_hash(b)


def test_compute_file_hash_missing_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        compute_file_hash(tmp_path / "nope.txt")


def test_compute_dir_hash_stable_and_order_invariant(tmp_path):
    (tmp_path / "a.txt").write_bytes(b"A")
    (tmp_path / "b.txt").write_bytes(b"B")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "c.txt").write_bytes(b"C")
    h1 = compute_dir_hash(tmp_path)
    # Touch unrelated mtime — content hash must not change.
    (tmp_path / "a.txt").touch()
    h2 = compute_dir_hash(tmp_path)
    assert h1 == h2


def test_compute_dir_hash_changes_with_content(tmp_path):
    (tmp_path / "a.txt").write_bytes(b"A")
    h1 = compute_dir_hash(tmp_path)
    (tmp_path / "a.txt").write_bytes(b"A_modified")
    h2 = compute_dir_hash(tmp_path)
    assert h1 != h2


def test_compute_dir_hash_respects_include_glob(tmp_path):
    (tmp_path / "keep.csv").write_bytes(b"data")
    (tmp_path / "drop.bin").write_bytes(b"binary")
    h_csv_only = compute_dir_hash(tmp_path, include_glob=["*.csv"])
    # Adding more .bin files should NOT change the hash.
    (tmp_path / "drop2.bin").write_bytes(b"another")
    h_csv_only_2 = compute_dir_hash(tmp_path, include_glob=["*.csv"])
    assert h_csv_only == h_csv_only_2


# -----------------------------------------------------------------------------
# ExperimentTracker
# -----------------------------------------------------------------------------

def test_tracker_writes_manifest_on_clean_exit(tmp_path):
    with ExperimentTracker(name="unit_test", output_dir=tmp_path) as tr:
        tr.set_seed(42)
        tr.record_config({"foo": 1, "bar": [1, 2, 3]})
        tr.record_metric("dummy", 0.5)

    files = list(tmp_path.glob("manifest_*.json"))
    assert len(files) == 1
    data = json.loads(files[0].read_text())
    assert data["status"] == "completed"
    assert data["seed"] == 42
    assert data["metrics"]["dummy"] == 0.5
    assert data["config_snapshot"]["foo"] == 1


def test_tracker_records_failure_on_exception(tmp_path):
    with pytest.raises(RuntimeError):
        with ExperimentTracker(name="failing_test", output_dir=tmp_path) as tr:
            tr.set_seed(1)
            raise RuntimeError("boom")

    files = list(tmp_path.glob("manifest_*.json"))
    data = json.loads(files[0].read_text())
    assert data["status"] == "failed"
    assert "RuntimeError" in data["error"]
    assert "boom" in data["error"]


def test_tracker_record_dataset_with_path_hashes_it(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "labels.csv").write_bytes(b"a,b\n1,2\n")
    out = tmp_path / "out"

    with ExperimentTracker(name="ds_test", output_dir=out) as tr:
        tr.record_dataset("MyDataset", path=data_dir, n_samples=1)

    manifest = json.loads(next(out.glob("manifest_*.json")).read_text())
    assert manifest["datasets"][0]["name"] == "MyDataset"
    assert "sha256_merkle" in manifest["datasets"][0]
    assert len(manifest["datasets"][0]["sha256_merkle"]) == 64


def test_tracker_record_input_records_size_and_hash(tmp_path):
    f = tmp_path / "video.mp4"
    f.write_bytes(b"fake video bytes")
    out = tmp_path / "out"
    with ExperimentTracker(name="t", output_dir=out) as tr:
        tr.record_input("audit_target", f)
    manifest = json.loads(next(out.glob("manifest_*.json")).read_text())
    inp = manifest["inputs"][0]
    assert inp["size_bytes"] == 16
    assert len(inp["sha256"]) == 64


def test_tracker_environment_captured_by_default(tmp_path):
    with ExperimentTracker(name="env_test", output_dir=tmp_path) as tr:
        tr.set_seed(0)
    manifest = json.loads(next(tmp_path.glob("manifest_*.json")).read_text())
    assert manifest["environment"]["python_version"]
    assert "deps" in manifest["environment"]


# -----------------------------------------------------------------------------
# v1.0.0 Item 4 — env enrichment helpers
# -----------------------------------------------------------------------------

def test_get_git_diff_size_returns_non_negative_int(tmp_path):
    """get_git_diff_size should never raise; returns int >= 0 even
    when called outside a git repo."""
    from cineinfini.repro import get_git_diff_size
    # Outside a git repo (tmp_path) it must return 0 (not raise).
    val = get_git_diff_size(tmp_path)
    assert isinstance(val, int)
    assert val >= 0


def test_get_package_hashes_returns_dict_with_known_packages():
    """get_package_hashes returns a dict {pkg: version_str_or_None}."""
    from cineinfini.repro import get_package_hashes
    hashes = get_package_hashes(["numpy", "scipy", "absolutely-not-a-package"])
    assert isinstance(hashes, dict)
    assert hashes["numpy"] is not None  # numpy must be installed in test env
    assert hashes["scipy"] is not None
    assert hashes["absolutely-not-a-package"] is None


def test_capture_environment_with_pip_freeze_opt_in(tmp_path):
    """capture_environment honours the capture_pip_freeze flag."""
    from cineinfini.repro import capture_environment
    # Off by default → pip_freeze is None
    cap_off = capture_environment(repo_dir=tmp_path)
    assert cap_off.pip_freeze is None
    # Has the new fields populated
    assert isinstance(cap_off.dep_hashes, dict)
    assert cap_off.git_diff_lines is not None
    assert cap_off.git_diff_lines >= 0
