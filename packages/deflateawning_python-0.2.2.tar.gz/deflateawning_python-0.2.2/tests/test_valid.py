"""Basic tests."""

from collections.abc import Callable


def test_main_can_be_imported() -> None:
    """Test that the dapython_main() function can be imported."""
    from deflateawning_python import dapython_main  # noqa: PLC0415

    assert isinstance(dapython_main, Callable)
