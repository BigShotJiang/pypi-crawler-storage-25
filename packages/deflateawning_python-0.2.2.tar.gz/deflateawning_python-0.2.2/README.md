# dapython

A quick, opinionated, batteries-included version of IPython with tools I use often

## Run

```bash
uv tool install "git+https://gitlab.com/DeflateAwning/dapython"
# -- or --
uv tool install deflateawning-python

dapython
```

## Details

* Inspired by discussion: https://github.com/astral-sh/uv/issues/18996
