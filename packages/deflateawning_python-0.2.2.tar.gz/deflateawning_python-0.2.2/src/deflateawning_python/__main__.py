"""`dapython` package entry, when invoked as `python -m dapython`."""

from deflateawning_python.main import dapython_main

if __name__ == "__main__":
    dapython_main()
