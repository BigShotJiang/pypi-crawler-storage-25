"""`dapython` package."""

from deflateawning_python.main import dapython_main

__all__ = [
    "dapython_main",
]

if __name__ == "__main__":
    dapython_main()
