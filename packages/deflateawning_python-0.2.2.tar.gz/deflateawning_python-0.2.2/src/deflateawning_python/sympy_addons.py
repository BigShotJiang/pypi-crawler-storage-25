"""Small features that improve the usability of common sympy tasks."""

from typing import Any

import sympy
from sympy import Eq, init_session, solve, sqrt, symbols
from sympy.physics.units import convert_to
from sympy.physics.units.systems import SI
from sympy.physics.units.util import quantity_simplify


def sympy_solve(equation: Any, *variables: Any) -> list[Any] | Any:
    """Solve with sympy."""
    sympy.pprint(equation)
    print(f"Solve for {variables}")
    print()

    solutions = solve(equation, *variables)

    output_solutions: list[Any] = []
    for sol_idx, sol in enumerate(solutions, start=1):
        print(f"==== Solution {sol_idx}/{len(solutions)} ====")
        sympy.pprint(sol)

        # Simplify units by joining.
        sol_simple: Any = quantity_simplify(
            sol,
            across_dimensions=True,  # Important part!
            unit_system=SI,
        )

        if sol != sol_simple:
            sympy.pprint(sol_simple)

        sol_simple_evalf = sol_simple.evalf()
        if sol_simple != sol_simple_evalf:
            sympy.pprint(sol_simple_evalf)

        output_solutions.append(sol_simple_evalf)
        print()  # Add a gap.

    # Return for pretty-printing.
    if len(output_solutions) == 1:
        return output_solutions[0]
    return output_solutions
