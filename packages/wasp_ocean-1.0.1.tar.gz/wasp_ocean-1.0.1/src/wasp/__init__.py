"""
WASP - Wave Spectra Partitioning
Watershed algorithm for partitioning ocean wave spectra from models and observations.
"""

__version__ = "1.0.1"
__author__ = "J.T. Carvalho"
__email__ = "jtcarvalho@gmail.com"

from .partition import partition_spectrum
from .wave_params import calculate_wave_parameters
from .plotting import plot_directional_spectrum
from .utils import load_config

__all__ = [
    "partition_spectrum",
    "calculate_wave_parameters",
    "plot_directional_spectrum",
    "load_config",
    "__version__",
]
