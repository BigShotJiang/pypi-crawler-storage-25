"""Tests for reviewer-flagged M5 regressions.

Covers the inheritance-aware required-field logic (Content child
records may omit schema-inheritable fields) and the split between
structural presence and meaningful content (attribute-only elements
are structurally present but do not satisfy leaf-field requirements).
"""

from __future__ import annotations

from eidr.models import ContentRecord

CONTENT_ID = "10.5240/7791-8534-2C23-9030-8610-5"
PARENT_ID = "10.5240/0000-0000-0000-0000-0000-X"
REGISTRANT_ID = "10.5237/7791-8534"

NS = ' xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _content_xml(base_body: str, extra_body: str = "") -> bytes:
    xml = f"<FullMetadata{NS}><BaseObjectData>{base_body}</BaseObjectData>"
    if extra_body:
        xml += f"<ExtraObjectMetadata>{extra_body}</ExtraObjectMetadata>"
    xml += "</FullMetadata>"
    return xml.encode()


# ─────────────────────────────────────────────────────────────────────────────
# Inheritance-aware required fields
# ─────────────────────────────────────────────────────────────────────────────


class TestRootRecordsMustSupplyAllRequiredFields:
    """Basic, Series, and Compilation records have no parent to inherit
    from; every schema-required field must be supplied directly."""

    def test_basic_missing_resource_name_rejected(self) -> None:
        # Basic record (no CreationType block) must have ResourceName.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            # No ResourceName
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(_content_xml(base)).validate()
        assert any(
            e.path == "BaseObjectData/ResourceName" and e.code == "content.required_field.missing"
            for e in report
        )

    def test_series_missing_resource_name_rejected(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Series</ReferentType>"
            # No ResourceName
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(
            _content_xml(base, "<SeriesInfo><SeriesClass>Program</SeriesClass></SeriesInfo>")
        ).validate()
        assert any(e.path == "BaseObjectData/ResourceName" for e in report)

    def test_compilation_missing_resource_name_rejected(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            # No ResourceName
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(
            _content_xml(
                base,
                "<CompilationInfo><CompilationClass>Anthology</CompilationClass></CompilationInfo>",
            )
        ).validate()
        assert any(e.path == "BaseObjectData/ResourceName" for e in report)


class TestChildRecordsMayInheritFields:
    """Episode, Edit, Clip, Manifestation may omit inheritable fields.
    Per common.xsd, ResourceName is NOT inheritable for Season/Episode
    (the registry uses business rules to system-generate titles there),
    but IS inheritable for Edit/Clip/Manifestation.
    """

    def test_edit_may_omit_resource_name(self) -> None:
        # Edit is a child record; ResourceName is inheritable for Edits.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            # No ResourceName — may be inherited from parent
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        edit_block = (
            f"<EditInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<EditClass>default</EditClass>"
            "<EditUse>default</EditUse></EditInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, edit_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report), (
            f"Edit should be allowed to omit ResourceName; got {list(report)}"
        )

    def test_clip_may_omit_resource_name(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        clip_block = f"<ClipInfo><Parent><ID>{PARENT_ID}</ID></Parent></ClipInfo>"
        report = ContentRecord.from_xml(_content_xml(base, clip_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report)

    def test_manifestation_may_omit_resource_name(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        mf_block = (
            f"<ManifestationInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<ManifestationClass>Complete</ManifestationClass>"
            "</ManifestationInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, mf_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report)

    def test_child_may_omit_original_language(self) -> None:
        # OriginalLanguage is inheritable for all child records.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>The Edit</ResourceName>"
            # No OriginalLanguage — may be inherited
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        edit_block = (
            f"<EditInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<EditClass>default</EditClass><EditUse>default</EditUse></EditInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, edit_block)).validate()
        assert not any(e.path == "BaseObjectData/OriginalLanguage" for e in report)


class TestChildRecordsMayOmitPopulatableFields:
    """The library applies a uniform rule: any child record (Season,
    Episode, Edit, Clip, Manifestation) may omit fields the registry
    *may* populate from outside the submitted record.

    This covers both inheritance (Edit/Clip/Manifestation ResourceName
    comes from the parent) and system-generation (Season/Episode
    ResourceName comes from parent context plus the submitted record's
    other fields). The library can't predict whether the fill-in
    will succeed — that requires the parent in hand and modeling of
    the registry's business rules — so it permits omission and lets
    the registry decide. Callers who want stricter pre-submission
    checks should inspect the record themselves.
    """

    def test_episode_may_omit_resource_name(self) -> None:
        # Season/Episode ResourceName is system-generated (not
        # inherited) when missing. The library can't verify
        # generation will succeed, but since it also can't verify
        # inheritance will succeed for other child kinds, it applies
        # the same permissive rule uniformly.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>TV</ReferentType>"
            # No ResourceName
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        ep_block = (
            f"<EpisodeInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<EpisodeClass>Standard</EpisodeClass></EpisodeInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, ep_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report), (
            f"Episode may rely on system-generated title; got {list(report)}"
        )

    def test_season_may_omit_resource_name(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>TV</ReferentType>"
            # No ResourceName
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        season_block = (
            f"<SeasonInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<SequenceNumber>1</SequenceNumber></SeasonInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, season_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report), (
            f"Season may rely on system-generated title; got {list(report)}"
        )

    def test_edit_may_omit_resource_name(self) -> None:
        # Edit ResourceName is inherited from parent — also allowed.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        edit_block = (
            f"<EditInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<EditClass>default</EditClass>"
            "<EditUse>default</EditUse></EditInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, edit_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report)

    def test_episode_with_resource_name_also_validates(self) -> None:
        # Supplying ResourceName is fine too — the registry just won't
        # need to generate one.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>TV</ReferentType>"
            "<ResourceName>Pilot</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        ep_block = (
            f"<EpisodeInfo><Parent><ID>{PARENT_ID}</ID></Parent>"
            "<EpisodeClass>Standard</EpisodeClass></EpisodeInfo>"
        )
        report = ContentRecord.from_xml(_content_xml(base, ep_block)).validate()
        assert not any(e.path == "BaseObjectData/ResourceName" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# Structural presence vs meaningful content
# ─────────────────────────────────────────────────────────────────────────────


class TestAttributeOnlyShellsOnLeafFields:
    """An element with only attributes, no text and no children, is
    NOT meaningful content for leaf-like required fields such as
    ``ResourceName``. It is structurally present (the registry would
    not reject it as an empty tag, since the attribute keeps it
    alive), but it does not carry a value, and the required-field
    check should flag it."""

    def test_attribute_only_resource_name_rejected_on_root_record(self) -> None:
        # Basic record where ResourceName has only an @lang attribute
        # and no content. The empty-tag rule allows this (the attribute
        # counts as content). But the required-field rule should flag
        # it — we need a real title on a root record.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            '<ResourceName lang="en"></ResourceName>'  # attribute only
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(_content_xml(base)).validate()
        assert any(
            e.path == "BaseObjectData/ResourceName" and e.code == "content.required_field.missing"
            for e in report
        ), f"Attribute-only ResourceName should be flagged as missing content; got {list(report)}"

    def test_attribute_only_registrant_rejected(self) -> None:
        # Administrators/Registrant with only an @idType attribute,
        # no actual ID. Should be flagged — the registrant is required
        # and must be a real EIDR Party ID, not an attribute hull.
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>The Movie</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            '<Administrators><Registrant idType="EIDRPartyID"></Registrant></Administrators>'
        )
        report = ContentRecord.from_xml(_content_xml(base)).validate()
        assert any(e.path == "BaseObjectData/Administrators/Registrant" for e in report), (
            f"Attribute-only Registrant should be flagged; got {list(report)}"
        )


class TestAttributeOnlyReferencesThatAreAllowed:
    """AssociatedOrg with only an organizationID attribute IS valid —
    the registry applies a business rule to populate DisplayName from
    the Party ID registry. The library should not flag this case;
    AssociatedOrg is a reference-type element where attributes ARE
    the content."""

    def test_attribute_only_associated_org_accepted(self) -> None:
        base = (
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>The Movie</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            '<AssociatedOrg idType="EIDRPartyID" organizationID="10.5237/1D47-3EB3"'
            ' role="producer"></AssociatedOrg>'
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        rec = ContentRecord.from_xml(_content_xml(base))
        report = rec.validate()
        # AssociatedOrg isn't on _BASE_REQUIRED_FIELDS, so there's no
        # "missing" complaint, but we also shouldn't have an empty-tag
        # complaint for it (the attributes keep it alive).
        assert not any(e.path and "AssociatedOrg" in e.path for e in report), (
            f"Attribute-only AssociatedOrg should be accepted; got {list(report)}"
        )
