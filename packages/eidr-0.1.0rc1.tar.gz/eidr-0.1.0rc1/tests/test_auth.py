"""Tests for ``eidr.auth``."""

from __future__ import annotations

import base64
import hashlib

from eidr.auth import make_auth_header, password_shadow


class TestPasswordShadow:
    def test_deterministic(self) -> None:
        assert password_shadow("hunter2") == password_shadow("hunter2")

    def test_different_passwords_produce_different_shadows(self) -> None:
        assert password_shadow("a") != password_shadow("b")

    def test_matches_sha256_b64_manual_computation(self) -> None:
        expected = base64.b64encode(hashlib.sha256(b"pw").digest()).decode("ascii")
        assert password_shadow("pw") == expected

    def test_output_is_44_ascii_chars(self) -> None:
        result = password_shadow("any password at all")
        assert len(result) == 44
        assert result.isascii()


class TestMakeAuthHeader:
    def test_format(self) -> None:
        header = make_auth_header("10.5238/user", "10.5237/AAAA-BBBB", "pw")
        assert header.startswith("Eidr ")
        # Three colon-separated parts after "Eidr ":
        # user, party, shadow
        parts = header[len("Eidr ") :].split(":")
        assert parts[0] == "10.5238/user"
        # party is "10.5237/AAAA-BBBB"; note it itself contains no colon
        # (the "/" keeps it intact after the split on ":")
        assert parts[1] == "10.5237/AAAA-BBBB"
        # Shadow is the 3rd component:
        assert parts[2] == password_shadow("pw")

    def test_deterministic(self) -> None:
        a = make_auth_header("u", "p", "pw")
        b = make_auth_header("u", "p", "pw")
        assert a == b

    def test_password_not_in_output(self) -> None:
        # The password itself must not appear anywhere in the header
        password = "this_specific_plaintext"
        header = make_auth_header("u", "p", password)
        assert password not in header

    def test_unicode_password(self) -> None:
        # Passwords are encoded as UTF-8 before hashing
        header = make_auth_header("u", "p", "pässwörd")
        assert header.startswith("Eidr u:p:")
        # Same password, different encoding, should match UTF-8 path
        expected_shadow = password_shadow("pässwörd")
        assert header.endswith(expected_shadow)
