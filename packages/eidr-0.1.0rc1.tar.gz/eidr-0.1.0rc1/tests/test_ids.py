"""Tests for ``eidr.models.ids.EIDRID``."""

from __future__ import annotations

import pytest

from eidr.errors import EIDRIDFormatError
from eidr.models.ids import EIDRID, IDCategory

# Real, currently-valid EIDR IDs harvested from the baseline XML fixtures.
# Used throughout this module for positive-case testing.
REAL_CONTENT_IDS = [
    "10.5240/7791-8534-2C23-9030-8610-5",  # "The Great Train Robbery"
    "10.5240/F85A-E100-B068-5B8F-B1C8-T",  # from spec
    "10.5240/B17A-4DAF-9496-C586-C1F5-9",  # from spec
    "10.5240/CA51-02D0-3269-23C9-DB5A-E",  # from spec
    "10.5240/7481-838B-59CA-63D0-B9A8-E",  # from spec
]


# ─────────────────────────────────────────────────────────────────────────────
# parse()
# ─────────────────────────────────────────────────────────────────────────────


class TestParse:
    @pytest.mark.parametrize("value", REAL_CONTENT_IDS)
    def test_accepts_real_content_ids(self, value: str) -> None:
        eid = EIDRID.parse(value)
        assert eid.category is IDCategory.CONTENT
        assert str(eid) == value

    @pytest.mark.parametrize(
        ("value", "expected_category"),
        [
            ("10.5240/7791-8534-2C23-9030-8610-5", IDCategory.CONTENT),
            ("10.5237/AAAA-BBBB", IDCategory.PARTY),
            ("10.5239/1234-5678", IDCategory.SERVICE),
            ("10.5238/testuser", IDCategory.USER),
        ],
    )
    def test_categorizes_by_subprefix(self, value: str, expected_category: IDCategory) -> None:
        assert EIDRID.parse(value).category is expected_category

    def test_accepts_lowercase_content_id_normalizes_to_upper(self) -> None:
        eid = EIDRID.parse("10.5240/7791-8534-2c23-9030-8610-5")
        assert eid.suffix == "7791-8534-2C23-9030-8610-5"
        assert str(eid) == "10.5240/7791-8534-2C23-9030-8610-5"

    def test_strips_whitespace(self) -> None:
        eid = EIDRID.parse("  10.5237/AAAA-BBBB  ")
        assert str(eid) == "10.5237/AAAA-BBBB"

    @pytest.mark.parametrize(
        "bad_value",
        [
            "",
            "   ",
            "not a doi",
            "10.5240/XXXX",  # too short
            "10.5240/7791-8534-2C23-9030-8610",  # no check char
            "10.5240/7791-8534-2C23-9030-8610-5-X",  # too long
            "10.5240/77918534-2C23-9030-8610-5",  # wrong grouping
            "10.5240/ZZZZ-8534-2C23-9030-8610-5",  # non-hex (Z allowed ONLY as check)
            "10.9999/AAAA-BBBB",  # unknown sub-prefix
            "11.5237/AAAA-BBBB",  # not a DOI
            "10.5237/AAAA",  # Party ID too short
            "10.5239/AAAA-BBBB-CCCC",  # Service ID too long
        ],
    )
    def test_rejects_malformed(self, bad_value: str) -> None:
        with pytest.raises(EIDRIDFormatError):
            EIDRID.parse(bad_value)

    def test_rejects_non_string(self) -> None:
        with pytest.raises(EIDRIDFormatError, match="must be a string"):
            EIDRID.parse(123)  # type: ignore[arg-type]

    def test_preserves_original_case_in_error(self) -> None:
        with pytest.raises(EIDRIDFormatError) as excinfo:
            EIDRID.parse("bad-id")
        # The .value attribute preserves the original caller input
        assert excinfo.value.value == "bad-id"


# ─────────────────────────────────────────────────────────────────────────────
# Equality / hashing
# ─────────────────────────────────────────────────────────────────────────────


class TestEquality:
    def test_case_insensitive_equal(self) -> None:
        a = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        b = EIDRID.parse("10.5240/7791-8534-2c23-9030-8610-5")
        assert a == b
        assert hash(a) == hash(b)

    def test_equal_to_string(self) -> None:
        a = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        assert a == "10.5240/7791-8534-2C23-9030-8610-5"
        assert a == "10.5240/7791-8534-2c23-9030-8610-5"

    def test_not_equal_to_invalid_string(self) -> None:
        a = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        assert a != "not-an-id"

    def test_not_equal_to_different_id(self) -> None:
        a = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        b = EIDRID.parse("10.5240/F85A-E100-B068-5B8F-B1C8-T")
        assert a != b

    def test_usable_as_dict_key_with_mixed_case(self) -> None:
        d = {EIDRID.parse("10.5237/AAAA-BBBB"): "value"}
        assert d[EIDRID.parse("10.5237/aaaa-bbbb")] == "value"


# ─────────────────────────────────────────────────────────────────────────────
# Category properties
# ─────────────────────────────────────────────────────────────────────────────


class TestCategoryProperties:
    def test_is_content(self) -> None:
        eid = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        assert eid.is_content and not (eid.is_party or eid.is_service or eid.is_user)

    def test_is_party(self) -> None:
        eid = EIDRID.parse("10.5237/AAAA-BBBB")
        assert eid.is_party and not (eid.is_content or eid.is_service or eid.is_user)

    def test_is_service(self) -> None:
        eid = EIDRID.parse("10.5239/AAAA-BBBB")
        assert eid.is_service and not (eid.is_content or eid.is_party or eid.is_user)

    def test_is_user(self) -> None:
        eid = EIDRID.parse("10.5238/myuser")
        assert eid.is_user and not (eid.is_content or eid.is_party or eid.is_service)


# ─────────────────────────────────────────────────────────────────────────────
# Output forms
# ─────────────────────────────────────────────────────────────────────────────


class TestOutputForms:
    def test_canonical_no_hyphens(self) -> None:
        eid = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        assert eid.canonical_no_hyphens() == "10.5240/779185342C2390308610-5".replace("-", "")
        # Equivalent check, clearer:
        assert eid.canonical_no_hyphens() == "10.5240/779185342C23903086105"

    def test_filename_form(self) -> None:
        eid = EIDRID.parse("10.5240/7481-838B-59CA-63D0-B9A8-E")
        # From EIDR ID Format v1.51 §3.7.1, example value
        assert eid.to_filename() == "10-5240-7481-838B-59CA-63D0-B9A8-E"

    def test_urn(self) -> None:
        eid = EIDRID.parse("10.5240/B17A-4DAF-9496-C586-C1F5-9")
        # From spec §3.5.1
        assert eid.to_urn() == "urn:eidr:10.5240:B17A-4DAF-9496-C586-C1F5-9"

    def test_doi_urn(self) -> None:
        eid = EIDRID.parse("10.5240/3466-F12C-391A-D60B-206B-Y")
        # From spec §3.5.2
        assert eid.to_doi_urn() == "urn:doi:10.5240:3466-F12C-391A-D60B-206B-Y"

    def test_proxy_url_https(self) -> None:
        eid = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        assert eid.to_proxy_url() == ("https://doi.org/10.5240/7791-8534-2C23-9030-8610-5")

    def test_proxy_url_http(self) -> None:
        eid = EIDRID.parse("10.5237/AAAA-BBBB")
        assert eid.to_proxy_url(scheme="http") == "http://doi.org/10.5237/AAAA-BBBB"

    def test_proxy_url_rejects_unknown_scheme(self) -> None:
        eid = EIDRID.parse("10.5237/AAAA-BBBB")
        with pytest.raises(ValueError, match="scheme must be"):
            eid.to_proxy_url(scheme="ftp")

    def test_compact_binary_content(self) -> None:
        # From spec §3.1.1: 10.5240/F85A-E100-B068-5B8F-B1C8-T
        # → 0x1478 F85A E100 B068 5B8F B1C8
        eid = EIDRID.parse("10.5240/F85A-E100-B068-5B8F-B1C8-T")
        assert eid.to_compact_binary() == bytes.fromhex("1478F85AE100B0685B8FB1C8")

    def test_compact_binary_party(self) -> None:
        # From spec §3.1.1: 10.5237/9DD9-E249 → 0x14759DD9E249000000000000
        eid = EIDRID.parse("10.5237/9DD9-E249")
        assert eid.to_compact_binary() == bytes.fromhex("14759DD9E249000000000000")

    def test_base64url_content(self) -> None:
        # From spec §3.2
        eid = EIDRID.parse("10.5240/F85A-E100-B068-5B8F-B1C8-T")
        assert eid.to_base64url() == "FHj4WuEAsGhbj7HI"

    def test_base64url_party(self) -> None:
        # From spec §3.2
        eid = EIDRID.parse("10.5237/9DD9-E249")
        assert eid.to_base64url() == "FHWd2eJJAAAAAAAA"


# ─────────────────────────────────────────────────────────────────────────────
# from_any() — multi-format parsing
# ─────────────────────────────────────────────────────────────────────────────


class TestFromAny:
    def test_accepts_canonical(self) -> None:
        eid = EIDRID.from_any("10.5240/7791-8534-2C23-9030-8610-5")
        assert eid.category is IDCategory.CONTENT

    def test_accepts_filename_form(self) -> None:
        eid = EIDRID.from_any("10-5240-7481-838B-59CA-63D0-B9A8-E")
        assert str(eid) == "10.5240/7481-838B-59CA-63D0-B9A8-E"

    def test_accepts_eidr_f(self) -> None:
        eid = EIDRID.from_any("EIDR-F-7481-838B-59CA-63D0-B9A8-E")
        assert str(eid) == "10.5240/7481-838B-59CA-63D0-B9A8-E"

    def test_accepts_eidr_f_lowercase(self) -> None:
        eid = EIDRID.from_any("eidr-f-7481-838b-59ca-63d0-b9a8-e")
        assert str(eid) == "10.5240/7481-838B-59CA-63D0-B9A8-E"

    def test_accepts_urn(self) -> None:
        eid = EIDRID.from_any("urn:eidr:10.5240:B17A-4DAF-9496-C586-C1F5-9")
        assert str(eid) == "10.5240/B17A-4DAF-9496-C586-C1F5-9"

    def test_accepts_doi_urn(self) -> None:
        eid = EIDRID.from_any("urn:doi:10.5240:3466-F12C-391A-D60B-206B-Y")
        assert str(eid) == "10.5240/3466-F12C-391A-D60B-206B-Y"

    def test_accepts_doi_proxy_url(self) -> None:
        eid = EIDRID.from_any("https://doi.org/10.5240/7791-8534-2C23-9030-8610-5")
        assert str(eid) == "10.5240/7791-8534-2C23-9030-8610-5"

    def test_accepts_dx_doi_proxy_url(self) -> None:
        eid = EIDRID.from_any("http://dx.doi.org/10.5237/AAAA-BBBB")
        assert str(eid) == "10.5237/AAAA-BBBB"

    def test_accepts_proxy_url_with_urn(self) -> None:
        eid = EIDRID.from_any("https://doi.org/urn:eidr:10.5240:B17A-4DAF-9496-C586-C1F5-9")
        assert str(eid) == "10.5240/B17A-4DAF-9496-C586-C1F5-9"

    def test_accepts_base64url_for_party(self) -> None:
        # Content IDs can't be fully reconstructed from base64url (need check char)
        # but Party IDs can be.
        eid = EIDRID.from_any("FHWd2eJJAAAAAAAA")
        assert str(eid) == "10.5237/9DD9-E249"

    def test_rejects_unrecognizable(self) -> None:
        with pytest.raises(EIDRIDFormatError):
            EIDRID.from_any("neither one thing nor the other")


# ─────────────────────────────────────────────────────────────────────────────
# Round-trips
# ─────────────────────────────────────────────────────────────────────────────


class TestRoundTrip:
    @pytest.mark.parametrize("canonical", REAL_CONTENT_IDS)
    def test_canonical_to_urn_and_back(self, canonical: str) -> None:
        eid = EIDRID.parse(canonical)
        round_tripped = EIDRID.from_urn(eid.to_urn())
        assert round_tripped == eid

    @pytest.mark.parametrize("canonical", REAL_CONTENT_IDS)
    def test_canonical_to_filename_and_back(self, canonical: str) -> None:
        eid = EIDRID.parse(canonical)
        round_tripped = EIDRID.from_any(eid.to_filename())
        assert round_tripped == eid

    def test_party_canonical_to_base64_and_back(self) -> None:
        eid = EIDRID.parse("10.5237/9DD9-E249")
        assert EIDRID.from_base64url(eid.to_base64url()) == eid

    @pytest.mark.parametrize("canonical", REAL_CONTENT_IDS)
    def test_content_id_canonical_to_base64_and_back(self, canonical: str) -> None:
        """Content IDs round-trip through base64url losslessly.

        The check character is not stored in compact binary but is a
        deterministic function of the suffix, so reconstruction is exact.
        """
        eid = EIDRID.parse(canonical)
        assert EIDRID.from_base64url(eid.to_base64url()) == eid


# ─────────────────────────────────────────────────────────────────────────────
# Direct construction via __init__
# ─────────────────────────────────────────────────────────────────────────────


class TestDirectConstruction:
    def test_valid_construction(self) -> None:
        eid = EIDRID(
            prefix="10.5237",
            suffix="AAAA-BBBB",
            category=IDCategory.PARTY,
        )
        assert str(eid) == "10.5237/AAAA-BBBB"

    def test_prefix_category_mismatch_raises(self) -> None:
        with pytest.raises(EIDRIDFormatError, match="does not match category"):
            EIDRID(
                prefix="10.5240",
                suffix="AAAA-BBBB",
                category=IDCategory.PARTY,
            )

    def test_suffix_shape_mismatch_raises(self) -> None:
        with pytest.raises(EIDRIDFormatError):
            EIDRID(
                prefix="10.5237",
                suffix="AAAA-BBBB-CCCC",  # too long for Party
                category=IDCategory.PARTY,
            )


# ─────────────────────────────────────────────────────────────────────────────
# Check-character validation
# ─────────────────────────────────────────────────────────────────────────────


class TestCheckCharacter:
    @pytest.mark.parametrize("valid_id", REAL_CONTENT_IDS)
    def test_real_ids_pass_check_char_verification(self, valid_id: str) -> None:
        """Every real Content ID has a valid check character."""
        eid = EIDRID.parse(valid_id)
        assert eid.verify_check_char()

    def test_parse_rejects_bad_check_char_by_default(self) -> None:
        """A Content ID with a wrong check character is rejected on parse."""
        # 10.5240/7791-8534-2C23-9030-8610-5 has check 5; swap to X
        with pytest.raises(EIDRIDFormatError, match="check character"):
            EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-X")

    def test_parse_accepts_bad_check_char_when_opted_out(self) -> None:
        """verify_check=False lets malformed IDs through for cleanup workflows."""
        eid = EIDRID.parse(
            "10.5240/7791-8534-2C23-9030-8610-X",
            verify_check=False,
        )
        assert eid.suffix == "7791-8534-2C23-9030-8610-X"
        assert eid.verify_check_char() is False

    def test_verify_check_char_returns_true_for_non_content(self) -> None:
        """Party, Service, and User IDs have no check character; always True."""
        assert EIDRID.parse("10.5237/AAAA-BBBB").verify_check_char()
        assert EIDRID.parse("10.5239/AAAA-BBBB").verify_check_char()
        assert EIDRID.parse("10.5238/username").verify_check_char()

    def test_loads_all_real_ids_from_sample_file(self, fixtures_dir) -> None:
        """Bulk test: parse every real ID from the sandbox sample.

        Skipped if the fixture file isn't present (the sample corpus is
        checked in under tests/fixtures/random_ids.txt).
        """
        sample = fixtures_dir / "random_ids.txt"
        if not sample.exists():
            pytest.skip(f"Sample file not found: {sample}")
        count = 0
        for line in sample.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            # Every line should parse without error and verify successfully.
            eid = EIDRID.parse(line)
            assert eid.verify_check_char(), f"Check char failed for {line}"
            count += 1
        assert count > 0, "Sample file appears to be empty"
