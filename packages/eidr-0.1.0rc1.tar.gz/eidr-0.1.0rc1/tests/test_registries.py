"""Tests for ``eidr.registries``."""

from __future__ import annotations

import pytest

from eidr import registries
from eidr.registries import (
    ALL_REGISTRIES,
    PRODUCTION,
    RESOLVE,
    SANDBOX1,
    SANDBOX2,
    SANDBOX2_MIRROR,
    Registry,
    by_name,
)


class TestCanonicalRegistries:
    def test_production_is_writable(self) -> None:
        assert PRODUCTION.writable is True
        assert "registry1.eidr.org" in PRODUCTION.url

    def test_sandbox1_is_writable(self) -> None:
        assert SANDBOX1.writable is True
        assert "sandbox1.eidr.org" in SANDBOX1.url

    def test_sandbox2_is_writable(self) -> None:
        assert SANDBOX2.writable is True
        assert "sandbox2.eidr.org" in SANDBOX2.url

    def test_sandbox2_mirror_is_read_only(self) -> None:
        assert SANDBOX2_MIRROR.writable is False
        assert "sandbox2-mirror.eidr.org" in SANDBOX2_MIRROR.url

    def test_resolve_is_read_only(self) -> None:
        assert RESOLVE.writable is False
        assert "resolve.eidr.org" in RESOLVE.url

    def test_sandbox3_temp_is_NOT_exported(self) -> None:
        # SANDBOX3_TEMP was explicitly excluded from the registry list
        # (Richard noted it was included by mistake in earlier materials).
        assert not hasattr(registries, "SANDBOX3_TEMP")
        for reg in ALL_REGISTRIES:
            assert "sandbox3" not in reg.url.lower()

    def test_all_registries_are_immutable(self) -> None:
        # Registry is a frozen dataclass; attribute assignment should fail
        with pytest.raises(AttributeError):
            SANDBOX2.url = "http://evil.example.com"  # type: ignore[misc]

    def test_all_registries_tuple_covers_every_canonical_registry(self) -> None:
        assert set(ALL_REGISTRIES) == {
            PRODUCTION,
            SANDBOX1,
            SANDBOX2,
            SANDBOX2_MIRROR,
            RESOLVE,
        }

    def test_str_includes_name_and_url(self) -> None:
        s = str(SANDBOX2)
        assert "SANDBOX2" in s
        assert SANDBOX2.url in s


class TestByName:
    @pytest.mark.parametrize(
        ("name", "expected"),
        [
            ("PRODUCTION", PRODUCTION),
            ("production", PRODUCTION),
            ("prod", PRODUCTION),
            ("SANDBOX1", SANDBOX1),
            ("sandbox1", SANDBOX1),
            ("sb1", SANDBOX1),
            ("SANDBOX2", SANDBOX2),
            ("sandbox2", SANDBOX2),
            ("sb2", SANDBOX2),
            ("sandbox", SANDBOX2),  # bare "sandbox" resolves to Sandbox 2
            ("SANDBOX2_MIRROR", SANDBOX2_MIRROR),
            ("sandbox2_mirror", SANDBOX2_MIRROR),
            ("RESOLVE", RESOLVE),
            ("resolve", RESOLVE),
        ],
    )
    def test_resolves_known_names_case_insensitively(self, name: str, expected: Registry) -> None:
        assert by_name(name) is expected

    def test_accepts_leading_trailing_whitespace(self) -> None:
        assert by_name("  sandbox2  ") is SANDBOX2

    def test_raises_on_unknown_name(self) -> None:
        with pytest.raises(KeyError, match="Unknown EIDR registry name"):
            by_name("nonexistent")

    def test_error_message_lists_valid_names(self) -> None:
        with pytest.raises(KeyError) as excinfo:
            by_name("???")
        msg = str(excinfo.value)
        for canonical in ("PRODUCTION", "SANDBOX2", "RESOLVE"):
            assert canonical in msg


class TestCustomRegistry:
    def test_can_construct_custom_registry(self) -> None:
        custom = Registry(
            name="MYLAB",
            url="https://custom.example.com/EIDR",
            writable=True,
            description="Custom lab instance.",
        )
        assert custom.writable
        assert custom.url == "https://custom.example.com/EIDR"

    def test_custom_registry_can_be_read_only(self) -> None:
        custom = Registry(
            name="ARCHIVE",
            url="https://archive.example.com/EIDR",
            writable=False,
            description="Archival read-only snapshot.",
        )
        assert not custom.writable
