"""Tests for schema hints and the bundled Conversion Table artifact."""

from __future__ import annotations

import json
from pathlib import Path

from eidr.codecs import xml as xml_codec
from eidr.codecs._rules import is_multi
from eidr.codecs._schema_hints import (
    EIDR_MULTI_ELEMENTS,
    EIDR_MULTI_LOCAL,
    EIDR_MULTI_QUALIFIED,
)

EIDR_NS = "http://www.eidr.org/schema"
MD_NS = "http://www.movielabs.com/schema/md/v2.8/md"


class TestSchemaHintsShape:
    def test_multi_qualified_is_non_empty(self) -> None:
        assert len(EIDR_MULTI_QUALIFIED) > 100, (
            f"XSD-derived hints should have over 100 entries; we found {len(EIDR_MULTI_QUALIFIED)}"
        )

    def test_multi_local_derives_from_qualified(self) -> None:
        # Every local name in EIDR_MULTI_LOCAL should come from EIDR_MULTI_QUALIFIED
        derived = {local for _, local in EIDR_MULTI_QUALIFIED}
        assert derived == EIDR_MULTI_LOCAL

    def test_multi_elements_alias_matches(self) -> None:
        # EIDR_MULTI_ELEMENTS is the backward-compat alias for EIDR_MULTI_LOCAL
        assert EIDR_MULTI_ELEMENTS is EIDR_MULTI_LOCAL

    def test_response_wrappers_included(self) -> None:
        # These appear multiple times in bulk responses even though the XSD
        # doesn't declare them multi directly
        for local in ("FullMetadata", "SelfDefinedMetadata", "ProvenanceMetadata"):
            assert (EIDR_NS, local) in EIDR_MULTI_QUALIFIED

    def test_common_multi_elements_present(self) -> None:
        # Spot-check a handful of well-known multi-valued EIDR elements
        for local in (
            "AlternateID",
            "AlternateResourceName",
            "AssociatedOrg",
            "CountryOfOrigin",
            "Director",
            "Actor",
            "ManifestationClass",
            "EditClass",
        ):
            assert (EIDR_NS, local) in EIDR_MULTI_QUALIFIED, (
                f"{local} should be in the EIDR-namespaced multi set"
            )

    def test_md_namespace_multi_elements_present(self) -> None:
        # Elements from the MovieLabs MD v2.8 namespace that should be multi
        for local in ("Track", "Audio", "Video", "People", "Job"):
            assert (MD_NS, local) in EIDR_MULTI_QUALIFIED, (
                f"{local} should be in the MD-namespaced multi set"
            )


class TestIsMultiQualifiedPath:
    """Verify the qualified-matching path in ``is_multi``."""

    def test_qualified_match_wins_over_local_miss(self) -> None:
        # EIDR/AltID isn't in the local set, but (EIDR, AltID) is in qualified.
        # In that scenario qualified should match.
        qualified = f"{{{EIDR_NS}}}AlternateID"
        assert is_multi(
            qualified,
            "AlternateID",
            multi_elements=frozenset(),  # empty local
            multi_qualified=EIDR_MULTI_QUALIFIED,
        )

    def test_local_fallback_still_works(self) -> None:
        # No qualified match but local is in the set
        assert is_multi(
            "SomethingCustom",
            "SomethingCustom",
            multi_elements={"SomethingCustom"},
            multi_qualified=EIDR_MULTI_QUALIFIED,
        )

    def test_neither_match_returns_false(self) -> None:
        assert not is_multi(
            "Nonexistent",
            "Nonexistent",
            multi_elements=frozenset(),
            multi_qualified=EIDR_MULTI_QUALIFIED,
        )

    def test_qualified_only_matches_the_right_namespace(self) -> None:
        # Put a qualified entry in a different namespace; local should not match
        qualified = "{http://www.some-other.example}AlternateID"
        assert not is_multi(
            qualified,
            "AlternateID",
            multi_elements=frozenset(),
            multi_qualified=EIDR_MULTI_QUALIFIED,
        )


class TestCodecUsesQualifiedHints:
    """Verify the codec honors qualified EIDR multi-hints end to end."""

    def test_md_track_emits_as_list_even_when_single(self) -> None:
        # In the MD namespace, Track is multi-valued. A single occurrence
        # should still emit as a list.
        xml = (f'<Container xmlns:md="{MD_NS}"><md:Track>only one</md:Track></Container>').encode()
        cd = xml_codec.to_codec_dict(xml)
        assert isinstance(cd, dict)
        container = cd["Container"]
        assert isinstance(container, dict)
        # The key in the dict uses the md: prefix per the display-key
        # convention; the value should be a list due to the qualified
        # multi-hint.
        track_value = container["md:Track"]
        assert isinstance(track_value, list), (
            f"md:Track should be a list (qualified multi-hint), got "
            f"{type(track_value).__name__}: {track_value!r}"
        )
        assert track_value == ["only one"]

    def test_eidr_alt_id_emits_as_list_when_single(self) -> None:
        # AlternateID is multi-valued in the EIDR namespace per the XSD.
        xml = (f'<Root xmlns="{EIDR_NS}"><AlternateID>10/abc</AlternateID></Root>').encode()
        cd = xml_codec.to_codec_dict(xml)
        root = cd["Root"]
        assert isinstance(root, dict)
        alt = root["AlternateID"]
        assert isinstance(alt, list), f"AlternateID should be a list, got {type(alt).__name__}"


class TestBundledConversionTable:
    """Verify the bundled Conversion Table JSON artifact."""

    def _load(self) -> dict:
        path = (
            Path(__file__).parent.parent
            / "src"
            / "eidr"
            / "schemas"
            / "bundled"
            / "conversion_table.json"
        )
        return json.loads(path.read_text(encoding="utf-8"))

    def test_artifact_exists(self) -> None:
        path = (
            Path(__file__).parent.parent
            / "src"
            / "eidr"
            / "schemas"
            / "bundled"
            / "conversion_table.json"
        )
        assert path.exists(), "Conversion Table JSON artifact must be bundled"

    def test_has_expected_row_count(self) -> None:
        data = self._load()
        assert data["row_count"] == len(data["paths"])
        assert data["row_count"] == 271, (
            f"Expected 271 rows from the v1 Conversion Table; got {data['row_count']}. "
            "If the Conversion Table has been updated, this test's expected count "
            "needs to be bumped."
        )

    def test_paths_dedup_to_about_140(self) -> None:
        # After collapsing Full/Self duplicates, we should have ~140 distinct paths
        data = self._load()
        dedup_set = {p["xml_path_dedup"] for p in data["paths"]}
        assert 130 < len(dedup_set) < 160, (
            f"Expected ~140 distinct paths after Full/Self collapse; got {len(dedup_set)}"
        )

    def test_every_path_has_json_key(self) -> None:
        data = self._load()
        missing = [p["xml_path"] for p in data["paths"] if not p["json_key"]]
        assert not missing, f"Paths missing JSON key: {missing[:5]}"

    def test_attribute_detection(self) -> None:
        data = self._load()
        attrs = [p for p in data["paths"] if p["is_attribute"]]
        # At least 23 attribute rows in the v1 table
        assert len(attrs) >= 20, f"Expected at least 20 attribute rows; got {len(attrs)}"

    def test_namespace_decls_flagged(self) -> None:
        data = self._load()
        ns_decls = [p for p in data["paths"] if p["is_namespace_decl"]]
        # There are a handful — root + md + xsi per root element
        assert 3 <= len(ns_decls) <= 15, (
            f"Expected ~5-10 namespace declarations; got {len(ns_decls)}"
        )
