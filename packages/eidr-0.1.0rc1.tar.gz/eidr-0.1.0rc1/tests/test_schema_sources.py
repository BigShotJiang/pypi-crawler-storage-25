"""Tests for the schema-source plumbing and the [digital] extra opt-in.

The :class:`SchemaSource` abstraction is foundational for M8 (used
by the codegen tooling) and will be reused by M9+ runtime
validation features. Default behavior, file lookup, list semantics,
and remote URL composition are all covered here.
"""

from __future__ import annotations

import pytest

from eidr.schemas import (
    BundledSchemaSource,
    RemoteSchemaSource,
    SchemaSource,
    default_schema_source,
)

# ─── BundledSchemaSource ────────────────────────────────────────────────────


class TestBundledSchemaSource:
    """Reads from the in-package ``src/eidr/schemas/bundled/`` snapshot."""

    def test_read_known_file(self) -> None:
        src = BundledSchemaSource()
        data = src.read("md-v2_8.xsd")
        assert isinstance(data, bytes)
        # Sanity: the file should be a real XSD, not empty
        assert len(data) > 1000
        assert b"<?xml" in data[:200] or b"<xs:schema" in data[:1000]

    def test_read_missing_file_raises(self) -> None:
        src = BundledSchemaSource()
        with pytest.raises(FileNotFoundError, match="No bundled schema named"):
            src.read("does-not-exist.xsd")

    def test_read_rejects_path_separators(self) -> None:
        """The ``read`` contract is bare filenames only — slashes
        would let a caller escape the package directory."""
        src = BundledSchemaSource()
        with pytest.raises(ValueError, match="bare filename"):
            src.read("subdir/md-v2_8.xsd")
        with pytest.raises(ValueError, match="bare filename"):
            src.read("..\\md-v2_8.xsd")

    def test_list_returns_only_xsd_files(self) -> None:
        src = BundledSchemaSource()
        files = list(src.list())
        assert all(name.endswith(".xsd") for name in files)
        # Sanity: the bundled set should include the headline EIDR
        # schemas. If a future maintainer drops one of these,
        # they'll need to update this test along with the rest of
        # the SDK.
        for must_have in ("md-v2_8.xsd", "md-v28-eidr.xsd", "common.xsd"):
            assert must_have in files

    def test_protocol_compliance(self) -> None:
        """A :class:`BundledSchemaSource` instance satisfies the
        :class:`SchemaSource` Protocol via runtime check."""
        src = BundledSchemaSource()
        assert isinstance(src, SchemaSource)


# ─── RemoteSchemaSource ────────────────────────────────────────────────────


class TestRemoteSchemaSource:
    """Tests the URL-composition shape and contract; does not
    actually fetch from the network. A live-fetch test would belong
    in the integration lane."""

    def test_default_base_url(self) -> None:
        src = RemoteSchemaSource()
        assert src.base_url == "https://www.eidr.org/schema/"

    def test_custom_base_url(self) -> None:
        src = RemoteSchemaSource("https://example.com/eidr/")
        assert src.base_url == "https://example.com/eidr/"

    def test_base_url_normalized_to_trailing_slash(self) -> None:
        src = RemoteSchemaSource("https://example.com/eidr")
        assert src.base_url == "https://example.com/eidr/"

    def test_read_rejects_path_separators(self) -> None:
        src = RemoteSchemaSource()
        with pytest.raises(ValueError, match="bare filename"):
            src.read("subdir/file.xsd")

    def test_list_returns_curated_manifest(self) -> None:
        """The remote source can't enumerate a real directory; it
        returns a hand-maintained manifest. Sanity-check it covers
        the headline files."""
        src = RemoteSchemaSource()
        files = list(src.list())
        for must_have in ("md-v2_8.xsd", "md-v28-eidr.xsd", "common.xsd"):
            assert must_have in files

    def test_protocol_compliance(self) -> None:
        src = RemoteSchemaSource()
        assert isinstance(src, SchemaSource)


# ─── default_schema_source ──────────────────────────────────────────────────


class TestDefaultSchemaSource:
    def test_default_is_bundled(self) -> None:
        """The default is bundled — predictable, offline-friendly,
        deterministic. Future env-var-driven override is documented
        in :func:`default_schema_source` but not implemented yet."""
        src = default_schema_source()
        assert isinstance(src, BundledSchemaSource)


# ─── [digital] extra opt-in error ───────────────────────────────────────────


class TestDigitalExtraOptIn:
    """The :mod:`eidr.models.digital` module raises a friendly
    :class:`ModuleNotFoundError` at import time if any of the
    runtime dependencies of the ``[digital]`` extra are missing
    (``pydantic``, ``xsdata``, ``xsdata_pydantic``).

    Verified by patching :mod:`builtins.__import__` to simulate
    each dependency's absence.
    """

    @pytest.mark.parametrize(
        "missing_dep",
        ["pydantic", "xsdata", "xsdata_pydantic"],
    )
    def test_friendly_error_for_each_missing_dep(
        self,
        monkeypatch: pytest.MonkeyPatch,
        missing_dep: str,
    ) -> None:
        """Each dep, simulated absent in turn, produces a clear
        ``[digital]`` error pointing at the correct missing
        package name.

        The check fires at :mod:`eidr.models.digital` module load
        time, so we drop the cached module first so a fresh
        import re-runs the check.
        """
        import builtins
        import sys

        real_import = builtins.__import__

        def blocked_import(name: str, *args: object, **kwargs: object) -> object:
            if name == missing_dep or name.startswith(f"{missing_dep}."):
                raise ModuleNotFoundError(f"No module named {name!r}")
            return real_import(name, *args, **kwargs)  # type: ignore[arg-type]

        # Clear cached modules so a fresh import re-runs the check
        for mod_name in list(sys.modules):
            if mod_name == "eidr.models.digital" or mod_name.startswith(missing_dep):
                monkeypatch.delitem(sys.modules, mod_name, raising=False)

        monkeypatch.setattr(builtins, "__import__", blocked_import)

        with pytest.raises(ModuleNotFoundError, match=r"\[digital\] install extra") as excinfo:
            import eidr.models.digital  # noqa: F401

        # The message names the specific missing dep, so a user
        # debugging a partial install knows what's wrong.
        assert missing_dep in str(excinfo.value)


# ─── Schema provenance manifest ────────────────────────────────────────────


class TestSchemaManifest:
    """Tests for the bundled-schema provenance manifest.

    The manifest records SHA-256 hashes of each XSD in the
    bundled snapshot, plus a single rolled-up hash for the whole
    set. This locks the generated artifacts (e.g.,
    ``_digital_generated.py``) to the exact schema bytes they
    were built from.
    """

    def test_compute_manifest_round_trip(self) -> None:
        """:func:`compute_manifest` produces a stable hash for a
        given schema source — calling it twice on the same source
        gives the same answer."""
        from eidr.schemas import compute_manifest

        m1 = compute_manifest()
        m2 = compute_manifest()
        assert m1["manifest_sha256"] == m2["manifest_sha256"]
        assert m1["files"] == m2["files"]

    def test_manifest_has_format_version(self) -> None:
        from eidr.schemas import MANIFEST_FORMAT_VERSION, compute_manifest

        m = compute_manifest()
        assert m["format_version"] == MANIFEST_FORMAT_VERSION

    def test_manifest_covers_all_bundled_xsds(self) -> None:
        """Every XSD that :class:`BundledSchemaSource.list` reports
        must appear in the manifest. A regression here means the
        manifest writer skipped a file."""
        from eidr.schemas import BundledSchemaSource, compute_manifest

        files = set(BundledSchemaSource().list())
        m = compute_manifest()
        manifest_files = set(m["files"].keys())  # type: ignore[union-attr]
        assert files == manifest_files

    def test_load_manifest_reads_disk_copy(self) -> None:
        """The on-disk manifest at ``MANIFEST.json`` matches the
        live computation. If they drift, someone edited XSDs
        without re-running ``tools/write_schema_manifest.py``."""
        from eidr.schemas import compute_manifest, load_manifest

        on_disk = load_manifest()
        assert on_disk is not None, (
            "MANIFEST.json missing from bundled/. Run tools/write_schema_manifest.py to regenerate."
        )
        live = compute_manifest()
        assert on_disk["manifest_sha256"] == live["manifest_sha256"], (
            "Bundled XSDs have been edited without regenerating "
            "MANIFEST.json. Run tools/write_schema_manifest.py "
            "and tools/generate_digital.py."
        )

    def test_generated_module_embeds_correct_hash(self) -> None:
        """The :mod:`eidr.models._digital_generated` module's
        header records the manifest hash at generation time. If
        the live manifest hash differs, the typed Digital model
        is out of date relative to the bundled XSDs.
        """
        import re

        from eidr.schemas import manifest_sha256

        gen_path = (__import__("eidr.models._digital_generated", fromlist=[""])).__file__
        assert gen_path is not None
        text = open(gen_path, encoding="utf-8").read()  # noqa: SIM115
        match = re.search(r"# Schema manifest SHA-256: ([0-9a-f]{64})", text)
        assert match is not None, (
            "Generated module is missing the schema manifest SHA-256 "
            "comment. Re-run tools/generate_digital.py."
        )
        embedded = match.group(1)
        live = manifest_sha256()
        assert embedded == live, (
            f"Embedded hash {embedded} differs from live {live}. "
            f"Bundled XSDs changed since last generation; rerun "
            f"tools/generate_digital.py."
        )

    def test_manifest_sha256_helper(self) -> None:
        """The ``manifest_sha256()`` helper is just sugar for
        ``compute_manifest()["manifest_sha256"]``."""
        from eidr.schemas import compute_manifest, manifest_sha256

        full = compute_manifest()
        assert manifest_sha256() == full["manifest_sha256"]
