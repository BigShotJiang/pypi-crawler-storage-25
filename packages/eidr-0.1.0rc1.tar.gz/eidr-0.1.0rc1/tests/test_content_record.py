"""Tests for :class:`eidr.models.content.ContentRecord`."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import pytest
from lxml import etree

from eidr.models import (
    EIDRID,
    ClipInfo,
    CompilationInfo,
    CompositeInfo,
    ContentRecord,
    Credit,
    EditInfo,
    EpisodeInfo,
    ManifestationInfo,
    Mode,
    SeasonInfo,
    SeriesInfo,
    Status,
    StructuralType,
)
from eidr.models.enums import CreationType, ReferentType

FIXTURES = Path(__file__).parent / "fixtures"
EIDR_NS = "http://www.eidr.org/schema"


# ─────────────────────────────────────────────────────────────────────────────
# Synthetic-XML basic shape tests
# ─────────────────────────────────────────────────────────────────────────────


def _wrap_full_metadata(inner_xml: str) -> str:
    """Build a minimal FullMetadata wrapper around inner BaseObjectData/Extra XML."""
    return (
        '<FullMetadata xmlns="http://www.eidr.org/schema"'
        ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
        ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        f"{inner_xml}"
        "</FullMetadata>"
    )


class TestConstruction:
    def test_from_xml_string(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData>"
            "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
            "<ResourceName>The Great Train Robbery</ResourceName>"
            "</BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        assert rec.resource_name == "The Great Train Robbery"
        assert str(rec.id) == "10.5240/7791-8534-2C23-9030-8610-5"

    def test_from_xml_bytes(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID></BaseObjectData>"
        )
        # Bytes constructor should also work
        rec = ContentRecord.from_xml(xml.encode("utf-8"))
        assert rec.id is not None

    def test_rejects_non_dict(self) -> None:
        from eidr.errors import EIDRClientError

        with pytest.raises(EIDRClientError, match="requires a dict"):
            ContentRecord("not a dict")  # type: ignore[arg-type]

    def test_data_is_underlying_codec_dict(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID></BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        assert isinstance(rec.data, dict)
        # Mutation of .data should be reflected in subsequent accessor calls
        assert "FullMetadata" in rec.data


# ─────────────────────────────────────────────────────────────────────────────
# BaseObjectData accessors
# ─────────────────────────────────────────────────────────────────────────────


class TestBaseObjectDataAccessors:
    def _record(self, base_xml: str) -> ContentRecord:
        return ContentRecord.from_xml(
            _wrap_full_metadata(f"<BaseObjectData>{base_xml}</BaseObjectData>")
        )

    def test_id_parses_to_eidrid(self) -> None:
        rec = self._record("<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>")
        assert isinstance(rec.id, EIDRID)
        assert rec.id.is_content

    def test_id_returns_none_when_missing(self) -> None:
        rec = self._record("")
        assert rec.id is None

    def test_id_returns_none_when_unparseable(self) -> None:
        # Wrapper does not raise on bad data; surface as None and let
        # callers escape to .data if they want the raw string.
        rec = self._record("<ID>not-an-eidr-id</ID>")
        assert rec.id is None

    def test_referent_type_returns_enum(self) -> None:
        rec = self._record("<ReferentType>Movie</ReferentType>")
        assert rec.referent_type == ReferentType.Movie
        assert rec.referent_type == "Movie"  # str-enum equality

    def test_referent_type_unknown_returns_string(self) -> None:
        rec = self._record("<ReferentType>NewfangledType</ReferentType>")
        assert rec.referent_type == "NewfangledType"
        # Not an enum member when unknown
        assert not isinstance(rec.referent_type, ReferentType)

    def test_structural_type_returns_enum(self) -> None:
        rec = self._record("<StructuralType>Abstraction</StructuralType>")
        assert rec.structural_type == StructuralType.Abstraction

    def test_mode_returns_enum(self) -> None:
        rec = self._record("<Mode>AudioVisual</Mode>")
        assert rec.mode == Mode.AudioVisual

    def test_status_returns_enum(self) -> None:
        rec = self._record("<Status>valid</Status>")
        assert rec.status == Status.valid

    def test_resource_name_with_lang(self) -> None:
        rec = self._record('<ResourceName lang="en">My Title</ResourceName>')
        assert rec.resource_name == "My Title"
        assert rec.resource_name_lang == "en"

    def test_resource_name_without_attrs(self) -> None:
        rec = self._record("<ResourceName>My Title</ResourceName>")
        assert rec.resource_name == "My Title"
        assert rec.resource_name_lang is None

    def test_release_date(self) -> None:
        rec = self._record("<ReleaseDate>1903-12-01</ReleaseDate>")
        assert rec.release_date == "1903-12-01"

    def test_country_of_origin_single(self) -> None:
        rec = self._record("<CountryOfOrigin>US</CountryOfOrigin>")
        assert rec.country_of_origin == ["US"]

    def test_country_of_origin_multi(self) -> None:
        rec = self._record(
            "<CountryOfOrigin>US</CountryOfOrigin><CountryOfOrigin>CA</CountryOfOrigin>"
        )
        assert rec.country_of_origin == ["US", "CA"]

    def test_languages(self) -> None:
        rec = self._record(
            "<OriginalLanguage>en</OriginalLanguage>"
            "<VersionLanguage>en</VersionLanguage>"
            "<VersionLanguage>fr</VersionLanguage>"
        )
        assert rec.original_languages == ["en"]
        assert rec.version_languages == ["en", "fr"]

    def test_registrant_and_authority(self) -> None:
        rec = self._record(
            "<Administrators>"
            "<Registrant>10.5237/AAAA-BBBB</Registrant>"
            "<MetadataAuthority>10.5237/CCCC-DDDD</MetadataAuthority>"
            "</Administrators>"
        )
        assert rec.registrant == "10.5237/AAAA-BBBB"
        assert rec.metadata_authorities == ["10.5237/CCCC-DDDD"]

    def test_directors_and_actors(self) -> None:
        rec = self._record(
            "<Credits>"
            "<Director><md:DisplayName>Jane Director</md:DisplayName></Director>"
            "<Actor>"
            "<md:DisplayName>Alice Actor</md:DisplayName>"
            "<md:SortName>Actor, Alice</md:SortName>"
            "</Actor>"
            "<Actor><md:DisplayName>Bob Actor</md:DisplayName></Actor>"
            "</Credits>"
        )
        assert rec.directors == [Credit(display_name="Jane Director")]
        assert rec.actors == [
            Credit(display_name="Alice Actor", sort_name="Actor, Alice"),
            Credit(display_name="Bob Actor"),
        ]


# ─────────────────────────────────────────────────────────────────────────────
# AlternateID
# ─────────────────────────────────────────────────────────────────────────────


class TestAlternateID:
    def test_full_attributes(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData>"
            '<AlternateID xsi:type="IMDB" relation="IsSameAs" domain="http://imdb.com">tt0123456</AlternateID>'
            "</BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        ids = rec.alternate_ids
        assert len(ids) == 1
        assert ids[0].value == "tt0123456"
        assert ids[0].relation == "IsSameAs"
        assert ids[0].domain == "http://imdb.com"

    def test_multiple_alt_ids(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData>"
            "<AlternateID>id1</AlternateID>"
            "<AlternateID>id2</AlternateID>"
            "</BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        assert [a.value for a in rec.alternate_ids] == ["id1", "id2"]

    def test_no_alt_ids_returns_empty_list(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID></BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        assert rec.alternate_ids == []


# ─────────────────────────────────────────────────────────────────────────────
# CreationType-specific block dispatch
# ─────────────────────────────────────────────────────────────────────────────


class TestCreationBlockDispatch:
    def test_basic_record_has_no_creation_block(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData><ReferentType>Movie</ReferentType></BaseObjectData>"
            )
        )
        assert rec.creation_type == CreationType.Basic
        assert rec.creation_block is None

    def test_series_creation_block_returns_seriesinfo(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData/>"
                "<ExtraObjectMetadata><SeriesInfo><SeriesClass>Series</SeriesClass></SeriesInfo></ExtraObjectMetadata>"
            )
        )
        assert rec.creation_type == CreationType.Series
        assert isinstance(rec.creation_block, SeriesInfo)
        assert rec.creation_block.series_class == "Series"

    def test_episode_creation_block(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData/>"
                "<ExtraObjectMetadata>"
                "<EpisodeInfo>"
                "<Parent><ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID><RelationshipType>IsEpisodeOf</RelationshipType></Parent>"
                "<EpisodeClass>Standard</EpisodeClass>"
                "</EpisodeInfo>"
                "</ExtraObjectMetadata>"
            )
        )
        assert rec.creation_type == CreationType.Episode
        assert isinstance(rec.creation_block, EpisodeInfo)
        assert rec.creation_block.episode_class == "Standard"
        assert rec.creation_block.parent is not None
        assert rec.creation_block.parent.id == "10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I"
        assert rec.creation_block.parent.relationship_type == "IsEpisodeOf"

    def test_composite_info_is_separate_from_creation_block(self) -> None:
        # A Basic record can carry CompositeInfo
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData/>"
                "<ExtraObjectMetadata>"
                "<CompositeInfo>"
                "<CompositeClass>Anthology</CompositeClass>"
                "</CompositeInfo>"
                "</ExtraObjectMetadata>"
            )
        )
        # CreationType is Basic since no CreationType-bearing block is present
        assert rec.creation_type == CreationType.Basic
        assert rec.creation_block is None
        # But CompositeInfo accessor finds it
        assert isinstance(rec.composite_info, CompositeInfo)
        assert rec.composite_info.composite_class == "Anthology"

    def test_episode_with_composite_info(self) -> None:
        # Episodes can also carry CompositeInfo
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData/>"
                "<ExtraObjectMetadata>"
                "<EpisodeInfo><EpisodeClass>Standard</EpisodeClass></EpisodeInfo>"
                "<CompositeInfo><CompositeClass>X</CompositeClass></CompositeInfo>"
                "</ExtraObjectMetadata>"
            )
        )
        assert rec.creation_type == CreationType.Episode
        assert isinstance(rec.creation_block, EpisodeInfo)
        assert rec.composite_info is not None
        assert rec.composite_info.composite_class == "X"


# ─────────────────────────────────────────────────────────────────────────────
# Lightweight relationships
# ─────────────────────────────────────────────────────────────────────────────


class TestLightweightRelationships:
    def test_packaging_info_list(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap_full_metadata(
                "<BaseObjectData/>"
                "<ExtraObjectMetadata>"
                "<PackagingInfo><PackagingClass>X</PackagingClass></PackagingInfo>"
                "</ExtraObjectMetadata>"
            )
        )
        # PackagingInfo is multi per the bundled XSD hints, even singletons → list
        assert len(rec.packaging_infos) == 1


# ─────────────────────────────────────────────────────────────────────────────
# Round-trip
# ─────────────────────────────────────────────────────────────────────────────


class TestSerializationRoundTrip:
    def test_xml_roundtrip(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData>"
            "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
            "<ResourceName>The Great Train Robbery</ResourceName>"
            "</BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        out = rec.to_xml(xml_declaration=False)
        rec2 = ContentRecord.from_xml(out)
        assert rec.id == rec2.id
        assert rec.resource_name == rec2.resource_name
        assert rec.data == rec2.data

    def test_json_roundtrip(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/7791-8534-2C23-9030-8610-5</ID></BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        jtext = rec.to_json()
        rec2 = ContentRecord.from_json(jtext)
        assert rec.id == rec2.id
        assert rec.data == rec2.data

    def test_canonical_xml_byte_stable(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/7791-8534-2C23-9030-8610-5</ID></BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        c1 = rec.to_xml_canonical()
        c2 = rec.to_xml_canonical()
        assert c1 == c2

    def test_canonical_json_byte_stable(self) -> None:
        xml = _wrap_full_metadata(
            "<BaseObjectData><ID>10.5240/7791-8534-2C23-9030-8610-5</ID></BaseObjectData>"
        )
        rec = ContentRecord.from_xml(xml)
        c1 = rec.to_json_canonical()
        c2 = rec.to_json_canonical()
        assert c1 == c2


# ─────────────────────────────────────────────────────────────────────────────
# Real corpus acceptance
# ─────────────────────────────────────────────────────────────────────────────


def _load_corpus_records() -> list[ContentRecord]:
    """Parse every FullMetadata record from the corpus."""
    tree = etree.parse(str(FIXTURES / "random_full.xml"))
    records = tree.findall(f".//{{{EIDR_NS}}}FullMetadata")
    return [ContentRecord.from_xml(etree.tostring(node)) for node in records]


class TestRealCorpusAcceptance:
    """The wrapper must parse every real record without exception."""

    @pytest.fixture(scope="class")
    def records(self) -> list[ContentRecord]:
        return _load_corpus_records()

    def test_all_records_parse(self, records: list[ContentRecord]) -> None:
        assert len(records) == 229

    def test_every_record_has_an_id(self, records: list[ContentRecord]) -> None:
        for rec in records:
            assert rec.id is not None, f"Record without ID: {rec.data!r}"
            assert rec.id.is_content

    def test_every_record_has_resource_name(self, records: list[ContentRecord]) -> None:
        # Every real EIDR record has a ResourceName
        missing = [str(rec.id) for rec in records if not rec.resource_name]
        assert not missing, f"Records without ResourceName: {missing[:3]}"

    def test_creation_type_distribution_matches_corpus(self, records: list[ContentRecord]) -> None:
        # We confirmed in the audit that the corpus contains:
        #   48 Episode, 30 Edit, 24 Manifestation, 14 Series, 13 Season,
        #   12 Compilation, 11 Clip, 4 Basic, plus a few other lightweight rels.
        # Verify the wrapper's creation_type matches that mix.
        types = Counter(rec.creation_type for rec in records)
        # Spot check the largest categories
        assert types[CreationType.Episode] >= 40
        assert types[CreationType.Edit] >= 25
        assert types[CreationType.Manifestation] >= 20
        assert types[CreationType.Basic] >= 1

    def test_creation_block_matches_creation_type(self, records: list[ContentRecord]) -> None:
        # When a record has a CreationType-bearing block, the type must match.
        type_to_view = {
            CreationType.Series: SeriesInfo,
            CreationType.Season: SeasonInfo,
            CreationType.Episode: EpisodeInfo,
            CreationType.Edit: EditInfo,
            CreationType.Clip: ClipInfo,
            CreationType.Manifestation: ManifestationInfo,
            CreationType.Compilation: CompilationInfo,
        }
        mismatches: list[tuple[str, str, str]] = []
        for rec in records:
            ct = rec.creation_type
            block = rec.creation_block
            if ct == CreationType.Basic:
                assert block is None
                continue
            assert block is not None, f"Record {rec.id} typed {ct} but no block"
            expected_cls = type_to_view[ct]
            if not isinstance(block, expected_cls):
                mismatches.append((str(rec.id), ct.value, type(block).__name__))
        assert not mismatches, f"Block/type mismatches: {mismatches[:3]}"

    def test_round_trip_preserves_data(self, records: list[ContentRecord]) -> None:
        """Every record's ContentRecord wrapper must round-trip XML→ContentRecord→XML losslessly.

        We don't require byte-identical output (the codec is infoset-level
        round-trip, not lexical), but the re-parsed record must equal the
        original at the codec-dict level.
        """
        for rec in records:
            xml_out = rec.to_xml(xml_declaration=False)
            rec2 = ContentRecord.from_xml(xml_out)
            assert rec.data == rec2.data, f"Round-trip drift on record {rec.id}"

    def test_json_canonical_round_trip(self, records: list[ContentRecord]) -> None:
        """JSON canonical → JSON parse → ContentRecord must equal original."""
        for rec in records[:30]:  # bounded; keep test fast
            jtext = rec.to_json_canonical()
            rec2 = ContentRecord.from_json(jtext)
            # Canonical JSON sorts keys, so dict equality should still hold
            # (Python dict equality is key-order-independent).
            assert rec.data == rec2.data


class TestRecordWrapperUnwrapping:
    """Reviewer 1 (M10 v1) flagged that ``_root_value`` only unwrapped
    ``FullMetadata`` / ``SelfDefinedMetadata`` / ``SimpleMetadata``,
    not ``ProvenanceMetadata`` or ``InheritedMetadata``. The top-level
    docs and ``ContentRecord`` API surface implied those wrappers
    were also handled.

    These tests pin the v2 fix: all five wrapper types unwrap the
    same way at the codec-dict layer, and the standard accessors
    (``id``, ``resource_name``, ``base``) work consistently across
    them.
    """

    _BODY = (
        "<BaseObjectData>"
        "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
        "<StructuralType>Performance</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ResourceName>Test Title</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        '<AssociatedOrg idType="eidrPartyID" '
        'organizationID="10.5237/FFDA-9947" role="registrant"/>'
        "<ReleaseDate>2026</ReleaseDate>"
        "<CountryOfOrigin>US</CountryOfOrigin>"
        "<Status>valid</Status>"
        "<ReferentType>CreateBasic</ReferentType>"
        "</BaseObjectData>"
    )

    @pytest.mark.parametrize(
        "wrapper",
        [
            "FullMetadata",
            "SelfDefinedMetadata",
            "SimpleMetadata",
            "ProvenanceMetadata",
            "InheritedMetadata",
        ],
    )
    def test_each_wrapper_exposes_id_and_resource_name(self, wrapper: str) -> None:
        # SimpleMetadata has the BaseObjectData fields hoisted to the root,
        # so its body looks slightly different. For this regression test
        # the FullMetadata-style wrapping is enough — _root_value should
        # treat all five wrappers the same way structurally.
        if wrapper == "SimpleMetadata":
            # Hoist fields to the top level (no <BaseObjectData> child)
            body = self._BODY.replace("<BaseObjectData>", "").replace("</BaseObjectData>", "")
        else:
            body = self._BODY
        xml = (
            f'<{wrapper} xmlns="http://www.eidr.org/schema"'
            ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            f"{body}"
            f"</{wrapper}>"
        )
        rec = ContentRecord.from_xml(xml)
        assert str(rec.id) == "10.5240/7791-8534-2C23-9030-8610-5", (
            f"{wrapper}: .id accessor failed; _root_value may not be unwrapping this wrapper type"
        )
        assert rec.resource_name == "Test Title", f"{wrapper}: .resource_name accessor failed"
