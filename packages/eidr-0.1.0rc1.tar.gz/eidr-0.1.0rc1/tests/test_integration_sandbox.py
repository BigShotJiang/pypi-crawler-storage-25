"""Live-registry integration tests against the EIDR sandbox.

Marked ``@pytest.mark.integration``; **skipped by default**. Run
explicitly with::

    pytest -m integration tests/test_integration_sandbox.py

Required environment:

* ``EIDR_TEST_USER_ID``   — full user ID (e.g., ``10.5238/myuser``)
* ``EIDR_TEST_PARTY_ID``  — party ID (e.g., ``10.5237/AAAA-BBBB``)
* ``EIDR_TEST_PASSWORD``  — password

If any of these is missing, the test is skipped with a clear reason
rather than failing — keeps CI green when secrets aren't configured.

Coverage target (per reviewer guidance for an HTTP client milestone):

* Anonymous resolve against the public RESOLVE registry — verifies
  the read path end-to-end with no credentials.
* Authenticated resolve against SANDBOX2 — verifies auth header
  shape against the real registry.
* Status-lookup with a synthetic token — verifies the GET ``/status/``
  endpoint and the registry's well-formed-but-token-not-found
  error path.
* Non-destructive Match against SANDBOX2 — exercises the write path
  (POST with multipart body, immediate response handling) without
  changing registry state.

Deliberately NOT covered here: register, modify, delete, promote,
alias, and relationship writes — those mutate state and aren't
appropriate for an automatic test lane. Add them if and when a
dedicated test party with cleanup tooling is available.
"""

from __future__ import annotations

import os

import pytest

from eidr import (
    Client,
    Credentials,
    registries,
)
from eidr.client import QueryResults
from eidr.errors import EIDRNotFoundError, EIDRProtocolError
from eidr.models.content import ContentRecord
from eidr.models.enums import CreationType

pytestmark = pytest.mark.integration


# A well-known stable test record ID. EIDR's own documentation uses
# "The Great Train Robbery" (1903) as a canonical resolve example;
# it has been registered since EIDR's early days and is unlikely to
# change. If this ID ever stops resolving, the test failure points
# at a real registry regression, not flaky test infrastructure.
GREAT_TRAIN_ROBBERY = "10.5240/7791-8534-2C23-9030-8610-5"


def _live_credentials() -> Credentials:
    """Build credentials from environment variables, or skip.

    Avoids using :meth:`Credentials.load` because that pulls from
    multiple sources (config file, AWS, etc.) — for integration
    tests we want the credentials path to be explicit and obvious.
    """
    user_id = os.environ.get("EIDR_TEST_USER_ID")
    party_id = os.environ.get("EIDR_TEST_PARTY_ID")
    password = os.environ.get("EIDR_TEST_PASSWORD")
    if not (user_id and party_id and password):
        pytest.skip(
            "Live integration tests require EIDR_TEST_USER_ID, "
            "EIDR_TEST_PARTY_ID, and EIDR_TEST_PASSWORD environment "
            "variables. Set them and run pytest -m integration."
        )
    return Credentials(
        user_id=user_id,
        party_id=party_id,
        password=password,
    )


# ─── Anonymous resolve ──────────────────────────────────────────────────────


class TestLiveAnonymousResolve:
    """Resolve a known record against the public RESOLVE endpoint
    without credentials. This exercises the GET path, response
    parsing, and the codec layer end-to-end with zero local state —
    if this passes, the most basic SDK→registry round-trip works."""

    def test_resolve_great_train_robbery_anonymous(self) -> None:
        with Client(registries.RESOLVE) as client:
            record = client.resolve(GREAT_TRAIN_ROBBERY)

        assert isinstance(record, ContentRecord)
        # Don't assert on the resource name itself — the registry's
        # canonical title may evolve. Just verify the record is shaped
        # like a real movie record.
        assert record.id is not None
        assert record.referent_type is not None


# ─── Authenticated resolve ──────────────────────────────────────────────────


class TestLiveAuthenticatedResolve:
    """Authenticated resolve against SANDBOX2. Verifies the auth
    header is accepted; sandbox returns the same record content as
    anonymous, plus alternate IDs (which anonymous does not return)."""

    def test_resolve_with_credentials(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            record = client.resolve(GREAT_TRAIN_ROBBERY)
        assert isinstance(record, ContentRecord)
        assert record.id is not None


# ─── Status lookup ──────────────────────────────────────────────────────────


class TestLiveStatusLookup:
    """A status-lookup against a synthetic token returns a
    well-formed error envelope (token not found / invalid). The test
    asserts the SDK's error-mapping fires correctly, NOT that the
    registry accepts the bogus token."""

    def test_synthetic_token_raises_mapped_error(self) -> None:
        creds = _live_credentials()
        # The registry will reject this with a "not found" or
        # "syntax error" mapping — either is correct evidence that
        # the round-trip and error-mapping layers work.
        with (
            Client(registries.SANDBOX2, creds) as client,
            pytest.raises((EIDRNotFoundError, EIDRProtocolError)),
        ):
            client.status_lookup("definitely-not-a-real-token-12345")


# ─── Non-destructive Match ──────────────────────────────────────────────────


class TestLiveMatch:
    """A Match call exercises the POST/multipart write path without
    changing registry state. The dedupe response is whatever the
    registry returns — we don't assert content, just that the
    operation completes and the response shape is valid."""

    def test_match_against_resolved_record(self) -> None:
        """Resolve a known record, rewrite its registrant to the
        test party, then submit for Match.

        The registry enforces "Registrant must match the Party ID"
        on Create/Match payloads — submitting a foreign-party record
        unchanged returns code=4 validation error. We rewrite the
        ``<Administrators><Registrant>`` to the test party so the
        match payload is registry-acceptable. The dedupe outcome
        itself is a separate concern (we just check the method
        returned something parseable).

        Tracing is enabled so that any failure has the registry's
        actual response body in the trace file for diagnosis. The
        log file appears in the working directory as
        ``m9_match_integration_<timestamp>.log``.
        """
        import datetime as _dt

        from eidr.client import FileSink

        creds = _live_credentials()
        timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        trace = FileSink(f"m9_match_integration_{timestamp}.log")
        with Client(registries.SANDBOX2, creds, tracing=trace) as client:
            record = client.resolve(GREAT_TRAIN_ROBBERY)
            assert isinstance(record, ContentRecord)

            # Rewrite the registrant to our test party — registry
            # rejects Match payloads whose <Administrators><Registrant>
            # doesn't match the authenticating party.
            from lxml import etree

            xml = record.to_xml()
            tree = etree.fromstring(xml)
            ns = {"e": "http://www.eidr.org/schema"}
            registrant = tree.find("e:BaseObjectData/e:Administrators/e:Registrant", ns)
            assert registrant is not None, (
                "resolved record has no <Administrators><Registrant> to rewrite"
            )
            registrant.text = creds.party_id
            rewritten_xml = etree.tostring(tree, encoding="UTF-8", xml_declaration=True)
            rewritten = ContentRecord.from_xml(rewritten_xml)

            # Submit for match. The result is either:
            #  - a ContentRecord (the dedupe candidate, if the
            #    registry found one and returned its body inline)
            #  - a Token (deferred match — registry returns the
            #    request token for status_lookup polling)
            # Either is a valid wire-shape outcome.
            result = client.match(rewritten)
            assert result is not None


# ─── Anonymous query (light-touch read coverage) ────────────────────────────


class TestLiveQuery:
    """A simple ID-only query against SANDBOX2. Verifies the
    POST-with-XML-body path (envelope construction, multipart, query
    response parsing). Uses a query expected to return at least one
    result against the populated sandbox."""

    def test_query_id_only(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            # Narrow query: a known stable record by ID. The registry
            # supports queries by /BaseObjectData/ID equality.
            results = client.query(
                f'/FullMetadata/BaseObjectData/ID IS "{GREAT_TRAIN_ROBBERY}"',
                page_number=1,
                page_size=10,
                id_only=True,
            )
        assert isinstance(results, QueryResults)
        # We don't strictly require a hit (sandbox state varies), but
        # if there is one, its ID should match.
        if results.ids:
            assert GREAT_TRAIN_ROBBERY in results.ids


# ─── M9 integration tests ──────────────────────────────────────────────────
#
# Live-registry verification of M9 endpoints. Wire shapes for these
# methods are based on the Java reference SDK (PartyAdmin.java,
# ServiceAdmin.java) — Claude's development environment was blocked
# from sandbox access by the EIDR IP allowlist, so the sync/async
# unit tests are the only verification CI runs. Integration tests
# below are how the maintainer (running from an allowlisted host)
# actually closes the loop.


class TestM9VirtualFields:
    """Virtual fields retrieval against a stable public record.

    Read-only, safest of the M9 endpoints to live-test. No state
    is mutated; if the registry returns nothing useful the test
    just asserts the response was structurally valid.
    """

    def test_virtual_fields_against_public_record(self) -> None:
        from eidr.models.virtual import VirtualFields

        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            vf = client.virtual_fields(GREAT_TRAIN_ROBBERY)
        assert isinstance(vf, VirtualFields)
        assert vf.id == GREAT_TRAIN_ROBBERY
        # At least one of the views should be populated for a
        # public record. We don't constrain which — the registry
        # decides what's in scope.
        populated = [v for v in (vf.full, vf.self_defined, vf.alias) if v is not None]
        # Tolerate empty for sandbox vagaries — if all three are
        # None, the assertion will skip with a clear message.
        if not populated:
            pytest.skip(
                "sandbox returned virtual_fields with no view bodies — "
                "registry-side state may not be populated for this record"
            )

    def test_virtual_fields_requires_authentication(self) -> None:
        """Anonymous access to the ``RESOLVE`` registry's
        ``/virtual/object/`` endpoint is **blocked by the EIDR
        registry's security policy**. Per the maintainer (M9
        review): when EIDR tightened anonymous-access security,
        only ID resolution remained public (with alternate IDs
        stripped from the response), and virtual-fields retrieval
        is among the operations that require credentials.

        This test asserts the registry's actual policy: an
        unauthenticated call to ``/virtual/object/`` returns
        ``code=4 authentication error``, surfaced as
        :class:`EIDRAuthenticationError`. If the registry ever
        re-opens this endpoint to anonymous access, this test
        will need to be updated to accept either behavior.
        """
        from eidr.errors import EIDRAuthenticationError

        with (
            Client(registries.RESOLVE) as client,
            pytest.raises(EIDRAuthenticationError) as exc_info,
        ):
            client.virtual_fields(GREAT_TRAIN_ROBBERY)
        # Confirm the failure is the "auth required" path
        # (code=4) not some other error type. The
        # EIDRAuthenticationError pulls the code+type from the
        # response envelope.
        assert "authentication error" in str(exc_info.value)


class TestM9ServiceRoundTrip:
    """Service create → modify → delete round-trip against the sandbox.

    State-mutating. Uses ``try/finally`` to guarantee cleanup even
    on assertion failure, so a partially-completed test doesn't
    leave a stranded service in the sandbox registry.

    **Skipped by default even within the integration lane** unless
    ``EIDR_TEST_SERVICE_WRITES=1`` is set, because:

    1. Service creation may be subject to per-party quotas.
    2. The sandbox's service tree is shared with other testers; a
       failure mode that leaves a service stranded is more
       expensive than for a content record.

    The maintainer should set the env var when actively reviewing
    M9 wire shapes.
    """

    def test_service_create_modify_delete(self) -> None:
        if os.environ.get("EIDR_TEST_SERVICE_WRITES") != "1":
            pytest.skip(
                "Service-write integration tests are opt-in. "
                "Set EIDR_TEST_SERVICE_WRITES=1 to enable."
            )

        from eidr.models.service import ServiceRecord

        # Build a minimal valid service body. The registrant is
        # the test party; the registry will populate the ID.
        new_svc_xml = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b'<Service xmlns="http://www.eidr.org/schema"'
            b' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            b"<ServiceName>"
            b"<md:DisplayName>SDK Test Service (delete me)</md:DisplayName>"
            b"<md:SortName>SDK Test Service</md:SortName>"
            b"</ServiceName>"
            b"<Active>true</Active>"
            b"</Service>"
        )
        new_svc = ServiceRecord.from_xml(new_svc_xml)

        creds = _live_credentials()
        created_id: str | None = None
        with Client(registries.SANDBOX2, creds) as client:
            try:
                result = client.create_service(new_svc)
                assert isinstance(result, ServiceRecord)
                assert result.id is not None
                assert result.id.startswith("10.5239/")
                created_id = result.id

                # Modify: change the display name. The registry's
                # modify operation requires the full record body, so
                # we update on the typed surface and submit.
                modified_xml = (
                    '<?xml version="1.0" encoding="UTF-8"?>'
                    '<Service xmlns="http://www.eidr.org/schema"'
                    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
                    f"<ID>{created_id}</ID>"
                    "<ServiceName>"
                    "<md:DisplayName>SDK Test Service (renamed)</md:DisplayName>"
                    "<md:SortName>SDK Test Service Renamed</md:SortName>"
                    "</ServiceName>"
                    "<Active>true</Active>"
                    "</Service>"
                ).encode()
                modified = client.modify_service(ServiceRecord.from_xml(modified_xml))
                assert isinstance(modified, ServiceRecord)
                assert modified.id == created_id
            finally:
                if created_id is not None:
                    # Cleanup: delete the test service. Don't let a
                    # cleanup failure mask the real assertion failure.
                    try:
                        client.delete_service(created_id)
                    except Exception as cleanup_exc:
                        pytest.fail(
                            f"Cleanup of test service {created_id} "
                            f"failed: {cleanup_exc}. "
                            f"Manually delete and try again."
                        )


# ─── M10: Service-graph reads ───────────────────────────────────────────────


class TestM10ServiceParent:
    """M10-B: ``service_parent(id)`` against sandbox2.

    Two cases:

    1. A service that *does* have a parent — we resolve through to a
       real ``ServiceRecord``. The maintainer is expected to set
       ``EIDR_TEST_CHILD_SERVICE_ID`` to a known sandbox child
       service. If unset, this part of the test is skipped (rather
       than failing on a hardcoded sandbox ID that may not exist
       in the test maintainer's lane).
    2. A service with *no* parent (a root service) — the SDK
       translates the registry's ``Code 4 not found`` envelope into
       a ``None`` return. We expect a clear None, not an exception.

    The root-service test uses ``EIDR_TEST_ROOT_SERVICE_ID`` if set;
    if unset, we skip rather than guess. (The wire format —
    ``GET /service/parent/{id}`` returning an envelope — is well
    enough verified by unit tests; this integration confirms the
    end-to-end live behavior, not the wire shape.)
    """

    def test_resolves_existing_parent(self) -> None:
        from eidr.models.service import ServiceRecord

        child_id = os.environ.get("EIDR_TEST_CHILD_SERVICE_ID")
        if not child_id:
            pytest.skip(
                "Set EIDR_TEST_CHILD_SERVICE_ID to a known sandbox "
                "child Service ID to exercise this test."
            )
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            parent = client.service_parent(child_id)
        assert parent is not None, (
            f"Expected {child_id} to have a parent service, but service_parent returned None."
        )
        assert isinstance(parent, ServiceRecord)
        assert parent.id is not None

    def test_returns_none_for_root_service(self) -> None:
        root_id = os.environ.get("EIDR_TEST_ROOT_SERVICE_ID")
        if not root_id:
            pytest.skip(
                "Set EIDR_TEST_ROOT_SERVICE_ID to a known sandbox "
                "root Service ID to exercise this test."
            )
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            parent = client.service_parent(root_id)
        assert parent is None, (
            f"Expected {root_id} to be at the root of its hierarchy "
            f"(parent should be None), but got: {parent!r}"
        )


class TestM10ServiceChildrenIncludeInactive:
    """M10-B: ``service_children(id, include_inactive=...)``.

    Verifies the ``?all=true|false`` query parameter is wired
    correctly. The test only confirms the request goes through;
    asserting on the response shape requires a known sandbox
    service with both active and inactive children, which the
    test runner can't assume.
    """

    def test_include_inactive_query_works(self) -> None:
        parent_id = os.environ.get("EIDR_TEST_PARENT_SERVICE_ID")
        if not parent_id:
            pytest.skip(
                "Set EIDR_TEST_PARENT_SERVICE_ID to a known sandbox "
                "parent Service ID with children."
            )
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            # Both calls should succeed; the registry handles the
            # filtering. We just verify the wire format doesn't
            # cause a server-side error.
            active_only = client.service_children(parent_id)
            with_inactive = client.service_children(parent_id, include_inactive=True)
        assert active_only.status_code == 0
        assert with_inactive.status_code == 0


# ─── M10-C: Modification base ───────────────────────────────────────────────


class TestM10ModificationBase:
    """M10-C: ``modification_base(asset_id, creation_type=...)``.

    The Great Train Robbery is a Basic-creation-type record. Per
    the wire contract we GET ``/object/modificationbase/{id}?type=CreateBasic``
    and parse the response as a ``ContentRecord``.

    This is the **highest-value** M10 integration test: the
    response shape is unverified. The Java SDK's typed accessors
    don't constrain the body shape; the schema docs don't pin it
    down precisely. We capture the live response and assert that:

    1. The SDK doesn't raise on parsing.
    2. The returned ``ContentRecord`` has the expected ID.

    If this test surfaces a parsing issue, that's a real signal
    we need to refine ``ContentRecord.from_xml``'s permissive
    handling — same pattern as the M9 round-by-round live-test
    discoveries. Roadmap: if the response shape needs adjustment,
    that lands as M10 v2.
    """

    def test_get_modification_base_for_basic_record(self) -> None:
        """Live test for the ``modification_base`` envelope handling.

        Captures a wire trace via :class:`FileSink` so any failure
        has the registry's actual response body in
        ``m12_modbase_basic_<timestamp>.log`` for diagnosis. The
        M10 v1 live test surfaced a registry envelope shape the
        SDK didn't handle; M10 v2 fixed it. Re-running this test
        with tracing on each release confirms the fix still holds
        (and surfaces any further envelope shape changes the
        registry might roll out).
        """
        import datetime as _dt

        from eidr.client import FileSink

        creds = _live_credentials()
        timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        trace = FileSink(f"m12_modbase_basic_{timestamp}.log")
        with Client(registries.SANDBOX2, creds, tracing=trace) as client:
            base = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)
        assert isinstance(base, ContentRecord), f"Expected ContentRecord, got {type(base).__name__}"
        # The response should carry the asset's ID. If it doesn't,
        # the wire trace in m12_modbase_basic_<timestamp>.log will
        # show the registry's actual envelope shape, which is the
        # diagnostic data we need to refine the SDK's handling.
        assert base.id is not None, (
            "modification_base returned a ContentRecord with no ID. "
            "Captured wire trace in m12_modbase_basic_<timestamp>.log — "
            "share with maintainer for envelope shape analysis."
        )
        assert str(base.id) == GREAT_TRAIN_ROBBERY


# ─── M10-A: Status lookup variants ──────────────────────────────────────────


class TestM10StatusLookupByUser:
    """M10-A: ``status_lookup_by_user(user_id, ...)``.

    Calls the live POST path against sandbox2 and verifies the
    response shape. We use a tiny page size (5) to keep the test
    fast even if the user has thousands of recent operations.

    The test only asserts that the call succeeds and returns a
    valid envelope — the actual content depends on what the test
    user has been submitting recently, and is not predictable.
    """

    def test_status_lookup_by_user_round_trip(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            response = client.status_lookup_by_user(creds.user_id, page_number=1, page_size=5)
        # Response should be Code 0 (success). Any other code at
        # the request level indicates a wire-shape regression.
        assert response.status_code == 0, (
            f"Status lookup returned non-zero status: "
            f"code={response.status_code}, type={response.status_type!r}"
        )


class TestM10StatusLookupByRegistrant:
    """M10-A: ``status_lookup_by_registrant(party_id, ...)``."""

    def test_status_lookup_by_registrant_round_trip(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            response = client.status_lookup_by_registrant(
                creds.party_id, page_number=1, page_size=5
            )
        assert response.status_code == 0, (
            f"Status lookup returned non-zero status: "
            f"code={response.status_code}, type={response.status_type!r}"
        )


class TestM10StatusLookupSuperparty:
    """M10-A: ``status_lookup_superparty(...)``.

    The test creds are NOT Superparty (they're a normal sandbox
    user/party), so the registry should reject this call with
    ``EIDRAuthorizationError``. That **is** the expected behavior
    — and verifying it confirms two things at once: (a) the wire
    shape is valid (otherwise we'd get a different error) and
    (b) the SDK doesn't gate this method client-side (otherwise
    we'd get ``EIDRSDKPolicyError`` instead).

    Skipped by default for normal test creds. Set
    ``EIDR_TEST_SUPERPARTY_AVAILABLE=1`` if you have Superparty
    credentials and want to verify the success path; the test
    then asserts a normal Code 0 response instead.
    """

    def test_non_superparty_creds_get_authorization_error(self) -> None:
        from eidr.errors import EIDRAuthorizationError

        if os.environ.get("EIDR_TEST_SUPERPARTY_AVAILABLE") == "1":
            # Test creds are Superparty — assert success.
            creds = _live_credentials()
            with Client(registries.SANDBOX2, creds) as client:
                response = client.status_lookup_superparty(page_number=1, page_size=5)
            assert response.status_code == 0
            return

        # Normal path: non-Superparty creds get rejected server-side.
        creds = _live_credentials()
        with (
            Client(registries.SANDBOX2, creds) as client,
            pytest.raises(EIDRAuthorizationError),
        ):
            client.status_lookup_superparty(page_number=1, page_size=5)


# Note: Party round-trip integration tests are deliberately NOT
# included in this file. Party records carry credentials and have
# a more sensitive lifecycle than content or service records;
# the test party (10.5237/FFDA-9947) is the same party used for
# authentication, so a buggy modify_party could lock the
# integration test lane out of the sandbox. Maintainer: if you
# want to add party-mutation tests, please use a dedicated test
# party with no credential dependency on the test runner's auth.


# ─── M11 (0.1.0b2): typed query helpers + iter_query + non-Basic
#  modification base — live integration coverage. Built per Reviewer 1
#  #5/#7/#10 ("live integration coverage behind beta claim"). These
#  tests need a live sandbox run by the maintainer to verify against
#  current registry behavior; the SDK side has unit-test coverage of
#  the request/response shapes against fixtures.
# ─────────────────────────────────────────────────────────────────────────


@pytest.mark.integration
class TestM11FindParties:
    """Read-only live tests for the typed Party query helpers."""

    def test_find_parties_by_name_movielabs(self) -> None:
        """MovieLabs is a well-known catalog party; should return at
        least one match. Verifies the typed wrapper unpacks the live
        wire response correctly.

        Trace captured in ``m12_find_parties_<timestamp>.log`` so any
        envelope-shape mismatches surface for analysis.
        """
        import datetime as _dt

        from eidr.client import FileSink

        creds = _live_credentials()
        timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        trace = FileSink(f"m12_find_parties_{timestamp}.log")
        with Client(registries.SANDBOX2, creds, tracing=trace) as client:
            results = client.find_parties_by_name("MovieLabs", page_size=5)

        # Total matches reported by the registry should be > 0
        assert results.total_matches is not None
        assert results.total_matches > 0
        # Either party_ids (default ID-only) or parties (full) populated
        assert results.party_ids or results.parties

    def test_find_parties_by_name_with_full(self) -> None:
        """``full=True`` should return Party records, not just IDs."""
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            results = client.find_parties_by_name("MovieLabs", page_size=3, full=True)

        # When full=True, the parties list (XML strings) should be
        # populated and party_ids should be empty.
        if results.total_matches and results.total_matches > 0:
            assert results.parties != []
            for xml in results.parties:
                assert xml.startswith("<Party")

    def test_find_parties_from_catalog(self) -> None:
        """Catalog search for a known organization."""
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            results = client.find_parties_from_catalog("MovieLabs", page_size=5)

        assert results.total_matches is not None


@pytest.mark.integration
class TestM11FindServices:
    """Read-only live tests for the typed Service query helpers."""

    def test_find_services_by_name(self) -> None:
        """Look up a well-known streaming service by name."""
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            results = client.find_services_by_name("Netflix", page_size=3)

        # Whether or not the sandbox has Netflix populated, the
        # typed wrapper should unpack cleanly.
        assert results.total_matches is not None

    def test_find_services_from_catalog(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            results = client.find_services_from_catalog("Netflix", page_size=3)

        assert results.total_matches is not None


@pytest.mark.integration
class TestM11IterQuery:
    """Auto-paging iter_query/iter_query_ids against live data.

    Bounded by max_results to keep tests cheap regardless of result
    set size.
    """

    def test_iter_query_ids_yields_matches(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            ids = list(
                client.iter_query_ids(
                    "/FullMetadata/BaseObjectData/ReferentType IS Movie",
                    page_size=10,
                    max_results=15,
                )
            )

        # Should get up to 15 matches without manual pagination.
        assert len(ids) <= 15
        # Each yielded item is an EIDR ID string.
        for id_str in ids:
            assert id_str.startswith("10.5240/")

    def test_iter_query_yields_records(self) -> None:
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            records = list(
                client.iter_query(
                    "/FullMetadata/BaseObjectData/ReferentType IS Movie",
                    page_size=5,
                    max_results=8,
                )
            )

        assert len(records) <= 8
        # Each yielded item is a typed ContentRecord.
        for record in records:
            assert isinstance(record, ContentRecord)


@pytest.mark.integration
class TestM11ModificationBaseNonBasic:
    """Live verification that the synthesized <FullMetadata> wrapper
    around <BaseObjectData> + <ExtraObjectMetadata> siblings (M11-C)
    works against actual non-Basic registry responses.

    Skips if no known non-Basic test ID is configured. Maintainer:
    set ``EIDR_TEST_SERIES_ID`` to a known Series asset in the
    sandbox to enable.
    """

    def test_modification_base_for_series(self) -> None:
        """Live test for non-Basic modification base.

        The M11-C synthesis of ``<FullMetadata>`` around multi-child
        envelopes is verified against unit-test fixtures; this test
        confirms the assumption against the live registry. Trace
        captured in ``m12_modbase_series_<timestamp>.log`` so any
        envelope-shape variance surfaces for analysis (this is the
        highest-risk envelope shape, since the multi-child handling
        was designed without live data to verify against).
        """
        import datetime as _dt
        import os

        from eidr.client import FileSink

        series_id = os.environ.get("EIDR_TEST_SERIES_ID")
        if not series_id:
            pytest.skip(
                "Set EIDR_TEST_SERIES_ID to a known Series asset ID "
                "in the sandbox to run this test."
            )

        creds = _live_credentials()
        timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        trace = FileSink(f"m12_modbase_series_{timestamp}.log")
        with Client(registries.SANDBOX2, creds, tracing=trace) as client:
            base = client.modification_base(series_id, creation_type=CreationType.Series)

        # The typed accessors should work on the synthesized FullMetadata
        # wrapper around BaseObjectData + ExtraObjectMetadata.
        assert str(base.id) == series_id
        # Should round-trip through modify (unit-tested; live test
        # confirms the registry's actual envelope shape matches).
        from eidr.client._operations import build_modify

        inner = build_modify(base.to_xml(), series_id, CreationType.Series)
        assert '<Modify type="CreateSeries">' in inner
        assert "<Series" in inner
        assert "<BaseObjectData>" in inner
        assert "<ExtraObjectMetadata>" in inner

    def test_modification_base_auto_for_known_basic_record(self) -> None:
        """``modification_base_auto`` resolves first to infer creation
        type. Verifies the resolve-then-modification-base round trip
        against a known Basic test record (The Great Train Robbery)."""
        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            base = client.modification_base_auto(GREAT_TRAIN_ROBBERY)

        assert str(base.id) == GREAT_TRAIN_ROBBERY


@pytest.mark.integration
class TestM11IterStatusByUser:
    """Live verification of the auto-paging status iterator."""

    def test_iter_status_by_user_auto_paginates(self) -> None:
        from datetime import UTC, datetime, timedelta

        # Last 30 days, capped at 50 results to keep cheap.
        now = datetime.now(UTC)
        thirty_days_ago = now - timedelta(days=30)

        creds = _live_credentials()
        with Client(registries.SANDBOX2, creds) as client:
            entries = list(
                client.iter_status_by_user(
                    creds.user_id,
                    after=thirty_days_ago,
                    before=now,
                    page_size=20,
                    max_results=50,
                )
            )

        # Either zero entries (clean test account) or some entries —
        # both are valid outcomes. The contract is the iterator
        # auto-paginates without raising.
        assert isinstance(entries, list)
        for entry in entries:
            # Each yielded entry has the typed fields populated where
            # the registry returned them.
            assert entry.element is not None  # always present
