"""Async mirror of :mod:`tests.test_client_m9_writes`.

Same coverage scope (URL, body, response handling for each new
M9 method) but using :class:`AsyncClient` and an async
:class:`httpx.MockTransport`. Tests are explicit ``async def``
with ``pytest-asyncio`` in auto mode.

The shapes mirror the sync tests — in many cases the assertions
are identical character-for-character. This is intentional: the
sync/async parity contract is exactly that the request wire shape
and response handling don't differ between the two clients.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import AsyncClient, AsyncToken
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.models.virtual import VirtualFields
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
READONLY = Registry(
    name="TEST_RO",
    url="https://test-ro.example/EIDR",
    writable=False,
    description="Read-only",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

EIDR_NS = 'xmlns="http://www.eidr.org/schema"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
    enforce_superparty_gate: bool = False,
) -> AsyncClient:
    """Build an AsyncClient with a MockTransport mapped to ``handler``.

    The Superparty gate is disabled by default in this helper —
    these tests exercise the wire shape of Party-administration
    operations, not the gate's policy logic. The gate has its own
    dedicated tests.
    """
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(
        registry,
        CREDS,
        transport_config=config,
        enforce_superparty_gate=enforce_superparty_gate,
    )


def _success_envelope() -> str:
    return f"<Response {EIDR_NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"


def _success_envelope_with_token(token: str = "tok-abc") -> str:
    return (
        f"<Response {EIDR_NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        f"<Token>{token}</Token>"
        "</Response>"
    )


def _service_record(*, with_id: bool = False) -> ServiceRecord:
    id_elem = "<ID>10.5239/AAAA-BBBB</ID>" if with_id else ""
    return ServiceRecord.from_xml(
        (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<Service {EIDR_NS}>"
            f"{id_elem}"
            "<ServiceName>"
            "<DisplayName>Test Service</DisplayName>"
            "<SortName>Test Service</SortName>"
            "</ServiceName>"
            "<Active>true</Active>"
            "</Service>"
        ).encode()
    )


def _party_record(*, with_id: bool = False) -> PartyRecord:
    id_elem = "<ID>10.5237/FFFF-1111</ID>" if with_id else ""
    return PartyRecord.from_xml(
        (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<Party {EIDR_NS}>"
            f"{id_elem}"
            "<PartyName>"
            "<DisplayName>Test Party</DisplayName>"
            "<SortName>Test Party</SortName>"
            "</PartyName>"
            "</Party>"
        ).encode()
    )


def _registered_service_response_xml() -> str:
    return (
        f"<Service {EIDR_NS}>"
        "<ID>10.5239/CCCC-DDDD</ID>"
        "<ServiceName>"
        "<DisplayName>Test Service</DisplayName>"
        "<SortName>Test Service</SortName>"
        "</ServiceName>"
        "<Active>true</Active>"
        "</Service>"
    )


def _registered_party_response_xml() -> str:
    return (
        f"<Party {EIDR_NS}>"
        "<ID>10.5237/EEEE-FFFF</ID>"
        "<PartyName>"
        "<DisplayName>Test Party</DisplayName>"
        "<SortName>Test Party</SortName>"
        "</PartyName>"
        "</Party>"
    )


# ─── Service writes ────────────────────────────────────────────────────────


class TestAsyncCreateService:
    async def test_posts_to_create_service_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_service_response_xml())

        async with make_client(handler) as client:
            result = await client.create_service(_service_record())

        assert captured["url"] == "https://test.example/EIDR/service/create/"
        assert captured["method"] == "POST"
        body_str = str(captured["body"])
        assert "CreateService" in body_str
        assert isinstance(result, ServiceRecord)

    async def test_returns_async_token_when_deferred(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token("svc-tok"))

        async with make_client(handler) as client:
            result = await client.create_service(_service_record())

        assert isinstance(result, AsyncToken)
        assert result.value == "svc-tok"

    async def test_handles_envelope_wrapped_response(self) -> None:
        """Async mirror of the envelope-wrapped record regression
        test on the sync client. See the sync test for the bug
        details."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response {EIDR_NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<Service>"
                    "<ID>10.5239/EEEE-FFFF</ID>"
                    "<ServiceName>"
                    "<DisplayName>Wrapped</DisplayName>"
                    "<SortName>Wrapped</SortName>"
                    "</ServiceName>"
                    "<Active>true</Active>"
                    "</Service>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            result = await client.create_service(_service_record())

        assert isinstance(result, ServiceRecord)
        assert result.id == "10.5239/EEEE-FFFF"


class TestAsyncModifyService:
    async def test_posts_to_modify_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_service_response_xml())

        async with make_client(handler) as client:
            result = await client.modify_service(_service_record(with_id=True))

        assert captured["url"] == "https://test.example/EIDR/service/modify/"
        body_str = str(captured["body"])
        assert "<Service" in body_str
        assert "ModifyService" not in body_str
        assert isinstance(result, ServiceRecord)

    async def test_rejects_record_without_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match=r"record\.id"):
                await client.modify_service(_service_record(with_id=False))


class TestAsyncSimpleServiceOps:
    async def test_delete_service(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.delete_service("10.5239/AAAA-BBBB")

        assert "/service/delete/10.5239/AAAA-BBBB" in str(captured["url"])

    async def test_alias_service(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.alias_service("10.5239/AAAA-BBBB", "10.5239/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/service/alias/10.5239/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("target") == ["10.5239/CCCC-DDDD"]

    async def test_set_service_parent(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.set_service_parent("10.5239/AAAA-BBBB", "10.5239/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/service/parent/10.5239/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("parent") == ["10.5239/CCCC-DDDD"]

    async def test_service_children(self) -> None:
        from eidr.client import ServiceChildrenResults

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            result = await client.service_children("10.5239/AAAA-BBBB")

        assert captured["method"] == "GET"
        assert "/service/children/10.5239/AAAA-BBBB" in str(captured["url"])
        # 0.1.0rc1: typed return.
        assert isinstance(result, ServiceChildrenResults)
        assert result.service_id == "10.5239/AAAA-BBBB"
        assert result.raw_response is not None
        assert result.raw_response.status_code == 0

    async def test_service_children_include_inactive_default_false(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.service_children("10.5239/AAAA-BBBB")

        assert "all=false" in str(captured["url"])

    async def test_service_children_include_inactive_true(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.service_children("10.5239/AAAA-BBBB", include_inactive=True)

        assert "all=true" in str(captured["url"])

    async def test_service_parent_returns_servicerecord(self) -> None:
        parent_xml = (
            '<Service xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<ID>10.5239/AAAA-1111</ID>"
            "<ServiceName><md:DisplayName>Parent</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=parent_xml)

        async with make_client(handler) as client:
            result = await client.service_parent("10.5239/BBBB-2222")

        from eidr.models.service import ServiceRecord

        assert isinstance(result, ServiceRecord)
        assert str(result.id) == "10.5239/AAAA-1111"

    async def test_service_parent_returns_none_for_root(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>not found</Type></Status>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            result = await client.service_parent("10.5239/CCCC-3333")

        assert result is None


# ─── Party writes ──────────────────────────────────────────────────────────


class TestAsyncCreateParty:
    async def test_embeds_password_in_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_party_response_xml())

        async with make_client(handler) as client:
            result = await client.create_party(_party_record(), "secret-pw")

        body_str = str(captured["body"])
        assert "/party/create/" in str(captured["url"])
        assert "CreateParty" in body_str
        assert "<Password>secret-pw</Password>" in body_str
        assert isinstance(result, PartyRecord)

    async def test_rejects_empty_password(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match="password"):
                await client.create_party(_party_record(), "")


class TestAsyncModifyParty:
    async def test_no_password_in_modify_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_party_response_xml())

        async with make_client(handler) as client:
            result = await client.modify_party(_party_record(with_id=True))

        body_str = str(captured["body"])
        assert "<Party" in body_str
        assert "ModifyParty" not in body_str
        assert "<Password>" not in body_str
        assert isinstance(result, PartyRecord)


class TestAsyncSimplePartyOps:
    async def test_delete_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.delete_party("10.5237/AAAA-BBBB")

        assert "/party/delete/10.5237/AAAA-BBBB" in str(captured["url"])

    async def test_alias_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.alias_party("10.5237/AAAA-BBBB", "10.5237/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/party/alias/10.5237/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("target") == ["10.5237/CCCC-DDDD"]

    async def test_activate_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.activate_party("10.5237/AAAA-BBBB")

        assert "/party/activate/10.5237/AAAA-BBBB" in str(captured["url"])

    async def test_deactivate_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.deactivate_party("10.5237/AAAA-BBBB")

        assert "/party/deactivate/10.5237/AAAA-BBBB" in str(captured["url"])

    async def test_change_party_password(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.change_party_password("10.5237/AAAA-BBBB", "new-pw")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/party/password/10.5237/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("password") == ["new-pw"]


# ─── Virtual fields ────────────────────────────────────────────────────────


class TestAsyncVirtualFields:
    async def test_gets_from_virtual_object_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(
                200,
                text=(
                    f"<Response {EIDR_NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<VirtualFields>"
                    "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
                    "<Full>&lt;FullMetadata&gt;...&lt;/FullMetadata&gt;</Full>"
                    "</VirtualFields>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            vf = await client.virtual_fields("10.5240/7791-8534-2C23-9030-8610-5")

        assert captured["method"] == "GET"
        assert "/virtual/object/10.5240/7791-8534-2C23-9030-8610-5" in str(captured["url"])
        assert isinstance(vf, VirtualFields)
        assert vf.id == "10.5240/7791-8534-2C23-9030-8610-5"
        assert vf.full is not None
        assert "FullMetadata" in vf.full

    async def test_rejects_empty_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match="non-empty"):
                await client.virtual_fields("")
