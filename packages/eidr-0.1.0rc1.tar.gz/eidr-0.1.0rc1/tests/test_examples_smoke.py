"""Smoke tests for the examples directory.

R1#12 (0.1.0b2): example scripts should be tested at least at the
import + syntax level so they don't drift faster than the library
tests. These smoke tests verify:

1. Each example module parses as valid Python (catches syntax errors).
2. Each example module imports cleanly given the SDK's full extras
   are installed (catches missing-dependency issues like a missed
   ``import asyncio`` or a typo in an SDK symbol name).
3. Examples that gate destructive writes behind ``EXAMPLE_ENABLE_WRITES``
   exit cleanly when that env var is unset (verifies the guard works).

These tests intentionally do not run any example end-to-end — that
would require live registry access. The examples are documentation,
not automated workflows; the smoke tests just keep them from rotting.
"""

from __future__ import annotations

import ast
import contextlib
import importlib.util
import sys
from pathlib import Path

import pytest

EXAMPLES_DIR = Path(__file__).parent.parent / "examples"


def _example_files() -> list[Path]:
    """All Python example files (not __init__, not tests)."""
    return sorted(p for p in EXAMPLES_DIR.glob("*.py") if not p.name.startswith("_"))


@pytest.mark.parametrize("path", _example_files(), ids=lambda p: p.name)
def test_example_parses(path: Path) -> None:
    """Each example must be syntactically valid Python."""
    src = path.read_text()
    try:
        ast.parse(src)
    except SyntaxError as exc:
        raise AssertionError(f"{path.name} has a syntax error: {exc}") from exc


@pytest.mark.parametrize("path", _example_files(), ids=lambda p: p.name)
def test_example_imports(path: Path) -> None:
    """Each example must import cleanly.

    Loads the module from its file path. If the module's top level
    references a removed/renamed SDK symbol or has a missing
    dependency, the import will fail and this test will surface it.

    Examples that read from environment variables on import are
    fine — we don't care about runtime behavior, just that the
    module body executes its imports and definitions.
    """
    spec = importlib.util.spec_from_file_location(f"_example_smoke_{path.stem}", path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    # Avoid polluting sys.modules across tests (and avoid cross-test
    # state if two examples define overlapping names).
    # Some examples raise SystemExit at import time if required env
    # vars aren't set; that's fine — they imported cleanly before
    # failing the env check.
    with contextlib.suppress(SystemExit):
        spec.loader.exec_module(module)


def test_register_and_modify_exits_cleanly_without_writes_flag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The destructive-write example gates on EXAMPLE_ENABLE_WRITES=1.

    Without it, the example must exit cleanly via SystemExit rather
    than attempting any registry operation. Verifies the guard
    works as documented.
    """
    monkeypatch.delenv("EXAMPLE_ENABLE_WRITES", raising=False)
    # Set credentials so the env check passes; the writes guard
    # should fire first regardless.
    monkeypatch.setenv("EIDR_USER_ID", "10.5238/test")
    monkeypatch.setenv("EIDR_PARTY_ID", "10.5237/AAAA-AAAA")
    monkeypatch.setenv("EIDR_PASSWORD", "test-pw")

    spec = importlib.util.spec_from_file_location(
        "_example_register_modify_smoke", EXAMPLES_DIR / "register_and_modify.py"
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    # main() should raise SystemExit because EXAMPLE_ENABLE_WRITES != "1"
    with pytest.raises(SystemExit, match="EXAMPLE_ENABLE_WRITES"):
        module.main()


def test_examples_directory_has_readme() -> None:
    """The examples directory should have a README documenting the
    scripts. This is a structural test — if someone deletes the
    README, they should be reminded to keep it as a navigation aid.
    """
    readme = EXAMPLES_DIR / "README.md"
    assert readme.exists(), f"{readme} is missing"
    content = readme.read_text()
    # Each example file should be referenced in the README.
    for path in _example_files():
        assert path.name in content, (
            f"Example {path.name} is not mentioned in {readme}; "
            "add a brief description so users can find it."
        )


def test_no_uploads_dir_pollution() -> None:
    """Smoke check: examples shouldn't leak /tmp or workspace files
    on import. (We can't verify perfect cleanliness, but we can
    flag obvious mistakes like an example writing a file at
    module-level.)
    """
    # All example modules should have any side effects gated behind
    # `if __name__ == "__main__":` blocks. A simple check: each module
    # must define a `main` function (the public entry point).
    for path in _example_files():
        src = path.read_text()
        tree = ast.parse(src)
        has_main = any(
            isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef) and node.name == "main"
            for node in tree.body
        )
        assert has_main, (
            f"{path.name} should define a `main()` function as its "
            "entry point so `if __name__ == '__main__': main()` works "
            "and side effects don't fire on import."
        )


# Avoid a leftover import-time module reference issue across test runs.
@pytest.fixture(autouse=True)
def _isolate_example_modules() -> None:
    """Remove any synthetic example modules from sys.modules between tests."""
    yield
    for name in list(sys.modules):
        if name.startswith("_example_"):
            del sys.modules[name]
