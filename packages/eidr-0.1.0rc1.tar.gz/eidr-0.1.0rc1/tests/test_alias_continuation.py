"""Tests for :class:`eidr.models.AliasContinuation`."""

from __future__ import annotations

import pytest

from eidr.models import AliasContinuation, ContentRecord

# Canonical-form EIDR IDs with valid check characters (from the corpus)
SOURCE_ID = "10.5240/0000-0000-0000-0000-0000-X"
TARGET_ID = "10.5240/7791-8534-2C23-9030-8610-5"


class TestAliasContinuationStandalone:
    """Parse an ``<AliasContinuation>`` root element (the registry's
    response when a bare alias is resolved with auto-follow off)."""

    def _xml(self) -> bytes:
        return (
            f'<AliasContinuation xmlns="http://www.eidr.org/schema">'
            f"<LastAliased>{SOURCE_ID}</LastAliased>"
            f"<TargetOfLastAliased>{TARGET_ID}</TargetOfLastAliased>"
            f"</AliasContinuation>"
        ).encode()

    def test_from_xml(self) -> None:
        alias = AliasContinuation.from_xml(self._xml())
        assert alias is not None
        assert alias.last_aliased == SOURCE_ID
        assert alias.target_of_last_aliased == TARGET_ID

    def test_from_xml_accepts_text(self) -> None:
        alias = AliasContinuation.from_xml(self._xml().decode("utf-8"))
        assert alias is not None

    def test_is_frozen(self) -> None:
        alias = AliasContinuation.from_xml(self._xml())
        assert alias is not None
        with pytest.raises((AttributeError, Exception)):
            alias.last_aliased = "something else"  # type: ignore[misc]

    def test_equal_values_equal_objects(self) -> None:
        a1 = AliasContinuation(last_aliased=SOURCE_ID, target_of_last_aliased=TARGET_ID)
        a2 = AliasContinuation(last_aliased=SOURCE_ID, target_of_last_aliased=TARGET_ID)
        assert a1 == a2

    def test_to_codec_roundtrip(self) -> None:
        original = AliasContinuation(last_aliased=SOURCE_ID, target_of_last_aliased=TARGET_ID)
        cd = original.to_codec()
        assert cd == {
            "LastAliased": SOURCE_ID,
            "TargetOfLastAliased": TARGET_ID,
        }
        restored = AliasContinuation.from_codec(cd)
        assert restored == original

    def test_from_codec_accepts_wrapped_form(self) -> None:
        # Codec may present either the inner dict or the wrapped form
        wrapped = {
            "AliasContinuation": {
                "LastAliased": SOURCE_ID,
                "TargetOfLastAliased": TARGET_ID,
            }
        }
        alias = AliasContinuation.from_codec(wrapped)
        assert alias is not None
        assert alias.last_aliased == SOURCE_ID

    def test_from_codec_returns_none_for_bad_input(self) -> None:
        assert AliasContinuation.from_codec(None) is None
        assert AliasContinuation.from_codec("not a dict") is None
        assert AliasContinuation.from_codec({}) is None
        assert AliasContinuation.from_codec({"LastAliased": SOURCE_ID}) is None
        assert AliasContinuation.from_codec({"TargetOfLastAliased": TARGET_ID}) is None


class TestAliasContinuationOnContentRecord:
    """Aliased records returned from resolve with auto-follow disabled
    carry the alias marker alongside their base metadata.
    Detecting this is NOT an error — callers are expected to inspect it."""

    def _xml_aliased_record(self) -> bytes:
        """An aliased FullMetadata record (carries a nested AliasContinuation)."""
        return (
            '<FullMetadata xmlns="http://www.eidr.org/schema"'
            ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
            ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            "<BaseObjectData>"
            f"<ID>{SOURCE_ID}</ID>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>Original Title</ResourceName>"
            "</BaseObjectData>"
            "<AliasContinuation>"
            f"<LastAliased>{SOURCE_ID}</LastAliased>"
            f"<TargetOfLastAliased>{TARGET_ID}</TargetOfLastAliased>"
            "</AliasContinuation>"
            "</FullMetadata>"
        ).encode()

    def test_detects_alias_on_record(self) -> None:
        rec = ContentRecord.from_xml(self._xml_aliased_record())
        alias = rec.alias_continuation
        assert alias is not None
        assert alias.last_aliased == SOURCE_ID
        assert alias.target_of_last_aliased == TARGET_ID

    def test_aliased_record_still_parses_other_fields(self) -> None:
        # Alias does not prevent normal field access — this is the critical point
        rec = ContentRecord.from_xml(self._xml_aliased_record())
        assert str(rec.id) == SOURCE_ID
        assert rec.resource_name == "Original Title"
        assert rec.alias_continuation is not None

    def test_non_aliased_record_has_no_alias(self) -> None:
        xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema"'
            ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
            ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            "<BaseObjectData>"
            f"<ID>{TARGET_ID}</ID>"
            "<ReferentType>Movie</ReferentType>"
            "</BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        assert rec.alias_continuation is None


class TestAliasContinuationExportedFromTopLevel:
    """Regression: AliasContinuation must be reachable from the top-level
    ``eidr.models`` import and from :mod:`eidr` itself (planned)."""

    def test_importable_from_eidr_models(self) -> None:
        import eidr.models

        assert eidr.models.AliasContinuation is AliasContinuation
