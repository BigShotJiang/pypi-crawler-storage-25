"""Tests for query-side operations: ``query``, ``graph_traversal``,
``party_query``, ``service_query``, plus the inner-XML builders and
the :class:`QueryResults` parser.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

import httpx
import pytest

from eidr.client import Client, GraphTraversalType, QueryResults
from eidr.client._http import TransportConfig
from eidr.client._operations import build_graph_traversal, build_query
from eidr.client._query_results import parse_query_results
from eidr.client._response import parse_response
from eidr.credentials import Credentials
from eidr.errors import EIDRProtocolError
from eidr.models.content import ContentRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


# ─────────────────────────────────────────────────────────────────────────────
# build_query
# ─────────────────────────────────────────────────────────────────────────────


class TestBuildQuery:
    def test_basic_shape(self) -> None:
        xml = build_query(
            "/FullMetadata/BaseObjectData/Status valid",
            page_number=1,
            page_size=25,
        )
        assert xml.startswith("<Query>")
        assert xml.endswith("</Query>")
        assert "<Expression>/FullMetadata/BaseObjectData/Status valid</Expression>" in xml
        assert "<PageNumber>1</PageNumber>" in xml
        assert "<PageSize>25</PageSize>" in xml

    def test_expression_escaped(self) -> None:
        # Ampersands inside expressions survive XML-escaping
        xml = build_query("a & b", page_number=1, page_size=10)
        assert "<Expression>a &amp; b</Expression>" in xml

    def test_defaults(self) -> None:
        xml = build_query("foo")
        assert "<PageNumber>1</PageNumber>" in xml
        assert "<PageSize>25</PageSize>" in xml

    def test_rejects_non_positive_page_number(self) -> None:
        with pytest.raises(ValueError, match="page_number"):
            build_query("x", page_number=0)

    def test_rejects_non_positive_page_size(self) -> None:
        with pytest.raises(ValueError, match="page_size"):
            build_query("x", page_size=0)


# ─────────────────────────────────────────────────────────────────────────────
# build_graph_traversal
# ─────────────────────────────────────────────────────────────────────────────


class TestBuildGraphTraversal:
    def test_get_parent_minimal(self) -> None:
        xml = build_graph_traversal(GraphTraversalType.GET_PARENT, "10.5240/X")
        assert xml == "<GetParent><ID>10.5240/X</ID></GetParent>"

    def test_find_ancestors_minimal(self) -> None:
        xml = build_graph_traversal(GraphTraversalType.FIND_ANCESTORS, "10.5240/X")
        assert xml == "<FindAncestors><ID>10.5240/X</ID></FindAncestors>"

    def test_find_descendants_with_all_filters(self) -> None:
        xml = build_graph_traversal(
            GraphTraversalType.FIND_DESCENDANTS,
            "10.5240/X",
            referent_type_filter="Movie",
            structural_type_filter="Performance",
            relationship_type_filter="IsPackagingOf",
        )
        assert "<FindDescendants>" in xml
        assert "<ID>10.5240/X</ID>" in xml
        assert "<ReferentTypeFilter>Movie</ReferentTypeFilter>" in xml
        assert "<StructuralTypeFilter>Performance</StructuralTypeFilter>" in xml
        assert "<RelationshipTypeFilter>IsPackagingOf</RelationshipTypeFilter>" in xml

    def test_filter_order_matches_schema_sequence(self) -> None:
        xml = build_graph_traversal(
            GraphTraversalType.FIND_DESCENDANTS,
            "10.5240/X",
            referent_type_filter="Movie",
            structural_type_filter="Performance",
            relationship_type_filter="IsPackagingOf",
        )
        ref_pos = xml.find("<ReferentTypeFilter>")
        struct_pos = xml.find("<StructuralTypeFilter>")
        rel_pos = xml.find("<RelationshipTypeFilter>")
        assert 0 < ref_pos < struct_pos < rel_pos

    def test_id_escaped(self) -> None:
        xml = build_graph_traversal(GraphTraversalType.GET_PARENT, "10.5240/A&B")
        assert "10.5240/A&amp;B" in xml

    def test_all_nine_operations_produce_correct_tag(self) -> None:
        for op in GraphTraversalType:
            xml = build_graph_traversal(op, "10.5240/X")
            assert f"<{op.value}>" in xml
            assert f"</{op.value}>" in xml


# ─────────────────────────────────────────────────────────────────────────────
# parse_query_results
# ─────────────────────────────────────────────────────────────────────────────


def _query_envelope(
    *,
    current_size: int,
    total_matches: int,
    items_xml: str = "",
    continuation_token: str | None = None,
) -> str:
    cont = (
        f"<ContinuationToken>{continuation_token}</ContinuationToken>" if continuation_token else ""
    )
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<QueryResults>"
        f"<CurrentSize>{current_size}</CurrentSize>"
        f"<TotalMatches>{total_matches}</TotalMatches>"
        f"{cont}"
        f"{items_xml}"
        "</QueryResults>"
        "</Response>"
    )


def _simple_metadata_item(eidr_id: str, name: str) -> str:
    # SimpleMetadata is a registry-defined shape; for parsing, we just
    # need a full-metadata-parseable envelope. ContentRecord's from_xml
    # accepts FullMetadata or SimpleMetadata roots.
    return (
        "<SimpleMetadata>"
        f"<ID>{eidr_id}</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        f"<ResourceName>{name}</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</SimpleMetadata>"
    )


class TestParseQueryResults:
    def test_empty_results(self) -> None:
        body = _query_envelope(current_size=0, total_matches=0)
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed)
        assert qr.current_size == 0
        assert qr.total_matches == 0
        assert qr.records == []
        assert qr.ids == []
        assert qr.continuation_token is None

    def test_single_simple_metadata_result(self) -> None:
        item = _simple_metadata_item("10.5240/0000-02ED-1DCE-6AAF-99F7-M", "A Movie")
        body = _query_envelope(current_size=1, total_matches=1, items_xml=item)
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed)
        assert qr.current_size == 1
        assert qr.total_matches == 1
        assert len(qr.records) == 1
        assert isinstance(qr.records[0], ContentRecord)
        assert qr.records[0].resource_name == "A Movie"
        assert qr.ids == []

    def test_id_only_results(self) -> None:
        items = (
            "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID><ID>10.5240/0000-043A-FEBE-F925-2E1C-7</ID>"
        )
        body = _query_envelope(current_size=2, total_matches=2, items_xml=items)
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed)
        assert qr.current_size == 2
        assert qr.ids == [
            "10.5240/0000-02ED-1DCE-6AAF-99F7-M",
            "10.5240/0000-043A-FEBE-F925-2E1C-7",
        ]
        assert qr.records == []

    def test_continuation_token_captured(self) -> None:
        body = _query_envelope(
            current_size=25,
            total_matches=1000,
            continuation_token="cont-abc-123",
        )
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed)
        assert qr.continuation_token == "cont-abc-123"

    def test_has_more_pages_true(self) -> None:
        body = _query_envelope(current_size=25, total_matches=100)
        parsed = parse_response(body, operation="query")
        # page 1 of 25 with 100 total → 25 cumulative < 100 → more pages
        qr = parse_query_results(parsed, page_number=1, page_size=25)
        assert qr.has_more_pages is True

    def test_has_more_pages_false_when_exhausted(self) -> None:
        body = _query_envelope(current_size=25, total_matches=25)
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed, page_number=1, page_size=25)
        assert qr.has_more_pages is False

    def test_has_more_pages_false_on_last_partial_page(self) -> None:
        # page 4 of 25, current_size=10 (partial), total_matches=85.
        # The old current_size < total_matches heuristic would return True
        # (10 < 85) which is wrong — we're on the last page, having
        # cumulatively fetched 4 * 25 = 100 ≥ 85 items.
        body = _query_envelope(current_size=10, total_matches=85)
        parsed = parse_response(body, operation="query")
        qr = parse_query_results(parsed, page_number=4, page_size=25)
        assert qr.has_more_pages is False

    def test_has_more_pages_false_without_page_context(self) -> None:
        # Graph-traversal results don't carry page context.
        body = _query_envelope(current_size=5, total_matches=100)
        parsed = parse_response(body, operation="graph_traversal x")
        qr = parse_query_results(parsed)
        assert qr.has_more_pages is False
        assert qr.page_number is None
        assert qr.page_size is None

    def test_missing_query_results_raises(self) -> None:
        body = (
            f"<Response {NS}>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            # No QueryResults element
            "</Response>"
        )
        parsed = parse_response(body, operation="query")
        with pytest.raises(EIDRProtocolError, match="QueryResults"):
            parse_query_results(parsed)


# ─────────────────────────────────────────────────────────────────────────────
# Client.query()
# ─────────────────────────────────────────────────────────────────────────────


class TestClientQuery:
    def test_posts_to_query_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=_query_envelope(current_size=0, total_matches=0),
            )

        with make_client(handler) as client:
            qr = client.query("/FullMetadata/BaseObjectData/Status valid")

        assert captured["url"] == "https://test.example/EIDR/query/"
        body = cast(str, captured["body"])
        assert "<Query>" in body
        assert "<Expression>/FullMetadata/BaseObjectData/Status valid</Expression>" in body
        assert "<PageNumber>1</PageNumber>" in body
        assert "<PageSize>25</PageSize>" in body
        assert isinstance(qr, QueryResults)

    def test_id_only_adds_type_param(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(
                200,
                text=_query_envelope(
                    current_size=1,
                    total_matches=1,
                    items_xml="<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>",
                ),
            )

        with make_client(handler) as client:
            qr = client.query("foo", id_only=True)

        assert "?type=ID" in cast(str, captured["url"])
        assert qr.ids == ["10.5240/0000-02ED-1DCE-6AAF-99F7-M"]

    def test_pagination_parameters_passed(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=_query_envelope(current_size=0, total_matches=0),
            )

        with make_client(handler) as client:
            client.query("foo", page_number=3, page_size=50)

        body = cast(str, captured["body"])
        assert "<PageNumber>3</PageNumber>" in body
        assert "<PageSize>50</PageSize>" in body

    def test_wrapped_in_request_operation_envelope(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=_query_envelope(current_size=0, total_matches=0),
            )

        with make_client(handler) as client:
            client.query("foo")

        body = cast(str, captured["body"])
        # <Request><Operation><Query>...</Query></Operation></Request>
        assert "<Request " in body
        assert "<Operation>" in body
        # <Query> must be inside <Operation>, not bare at request root
        req_start = body.find("<Request ")
        op_start = body.find("<Operation>")
        query_start = body.find("<Query>")
        assert req_start < op_start < query_start


# ─────────────────────────────────────────────────────────────────────────────
# Client.graph_traversal()
# ─────────────────────────────────────────────────────────────────────────────


class TestClientGraphTraversal:
    def test_posts_to_graph_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        with make_client(handler) as client:
            client.graph_traversal(
                GraphTraversalType.FIND_ANCESTORS,
                "10.5240/0000-02ED-1DCE-6AAF-99F7-M",
            )

        assert captured["url"] == "https://test.example/EIDR/object/graph/"
        body = cast(str, captured["body"])
        assert "<FindAncestors>" in body
        assert "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>" in body

    def test_filters_appear_in_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        with make_client(handler) as client:
            client.graph_traversal(
                GraphTraversalType.FIND_DESCENDANTS,
                "10.5240/X",
                referent_type_filter="Movie",
                structural_type_filter="Performance",
            )

        body = cast(str, captured["body"])
        assert "<ReferentTypeFilter>Movie</ReferentTypeFilter>" in body
        assert "<StructuralTypeFilter>Performance</StructuralTypeFilter>" in body

    def test_returns_records(self) -> None:
        item = _simple_metadata_item("10.5240/0000-02ED-1DCE-6AAF-99F7-M", "Series Ancestor")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_query_envelope(current_size=1, total_matches=1, items_xml=item),
            )

        with make_client(handler) as client:
            qr = client.graph_traversal(
                GraphTraversalType.GET_PARENT,
                "10.5240/X",
            )
        assert qr.current_size == 1
        assert qr.records[0].resource_name == "Series Ancestor"


# ─────────────────────────────────────────────────────────────────────────────
# Client.party_query() / service_query()
# ─────────────────────────────────────────────────────────────────────────────


class TestRawQueryEndpoints:
    def test_party_query_posts_to_party_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
                ),
            )

        query_xml = (
            '<FindPartiesByName xmlns="http://www.eidr.org/schema">'
            "<Name>Acme</Name>"
            "</FindPartiesByName>"
        )
        with make_client(handler) as client:
            parsed = client.party_query(query_xml)

        assert captured["url"] == "https://test.example/EIDR/party/query/"
        # Body must contain the query XML directly, NOT wrapped in
        # <Request><Operation> — that's the Party-specific wire rule.
        body = cast(str, captured["body"])
        assert "<FindPartiesByName" in body
        # The multipart wrapper's name= parameter varies; what matters
        # is the inner payload is the raw query element.
        assert "<Request " not in body  # no Request/Operation wrapper
        assert parsed.status_code == 0

    def test_service_query_posts_to_service_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
                ),
            )

        query_xml = (
            '<FindServicesByName xmlns="http://www.eidr.org/schema">'
            "<Name>TestService</Name>"
            "</FindServicesByName>"
        )
        with make_client(handler) as client:
            parsed = client.service_query(query_xml)

        assert captured["url"] == "https://test.example/EIDR/service/query/"
        body = cast(str, captured["body"])
        assert "<FindServicesByName" in body
        assert "<Request " not in body
        assert parsed.status_code == 0

    def test_party_query_rejects_empty(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="empty"):
            client.party_query("")

    def test_service_query_rejects_empty(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="empty"):
            client.service_query("   \n ")
