"""Async-client mirrors of the M10 unit tests.

Same structure as :mod:`tests.test_client_m10`; covers
``service_parent``, ``service_children(include_inactive=...)``
(in :mod:`tests.test_async_client_m9_writes`), ``modification_base``,
and the three status-lookup-by-* methods on :class:`AsyncClient`.

These tests are smaller and lighter than the sync versions —
they exist to confirm the async path enforces the same wire
contract as the sync path (URL construction, body shape, return
type), since the underlying operation builders are shared. Where
the sync tests already cover edge cases (validation errors,
parametrize-style coverage of options), the async tests just spot-
check one or two representative paths.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

import httpx
import pytest

from eidr.client import AsyncClient
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.enums import CreationType
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

GREAT_TRAIN_ROBBERY = "10.5240/7791-8534-2C23-9030-8610-5"


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> AsyncClient:
    """Build an AsyncClient with a MockTransport."""
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(REGISTRY, CREDS, transport_config=config)


def _content_record_xml(asset_id: str = GREAT_TRAIN_ROBBERY) -> str:
    """Envelope-wrapped modification-base response (live registry shape)."""
    return (
        '<Response xmlns="http://www.eidr.org/schema" '
        'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md" '
        'version="2.7.1">'
        "<Status><Code>0</Code><Type>success</Type></Status>"
        "<BaseObjectData>"
        f"<ID>{asset_id}</ID>"
        "<StructuralType>Performance</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ResourceName>Test Title</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        '<AssociatedOrg idType="eidrPartyID" '
        'organizationID="10.5237/FFDA-9947" role="registrant"/>'
        "<ReleaseDate>2026</ReleaseDate>"
        "<CountryOfOrigin>US</CountryOfOrigin>"
        "<Status>valid</Status>"
        "<ReferentType>CreateBasic</ReferentType>"
        "<BasicData>"
        "<MovieInfo><Length>PT1H30M</Length></MovieInfo>"
        "</BasicData>"
        "</BaseObjectData>"
        "</Response>"
    )


def _empty_statusrequest_response() -> str:
    return (
        '<Response xmlns="http://www.eidr.org/schema">'
        "<Status><Code>0</Code><Type>success</Type></Status>"
        "</Response>"
    )


def _statusrequest_part_of(request: httpx.Request) -> str:
    """Extract the multipart-form-wrapped XML payload from a status POST."""
    text = request.content.decode("utf-8")
    parts = text.split("\r\n\r\n", 1)
    if len(parts) != 2:
        parts = text.split("\n\n", 1)
    body_after_headers = parts[1]
    boundary_marker = "\n--"
    boundary_idx = body_after_headers.rfind(boundary_marker)
    if boundary_idx != -1:
        body_after_headers = body_after_headers[:boundary_idx]
    return body_after_headers.strip()


# ─── M10-C: modification_base async mirror ──────────────────────────────────


class TestAsyncModificationBase:
    @pytest.mark.asyncio
    async def test_gets_modificationbase_endpoint_with_default_basic_type(
        self,
    ) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=_content_record_xml())

        async with make_client(handler) as client:
            await client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

        assert captured["method"] == "GET"
        assert "/object/modificationbase/" in str(captured["url"])
        assert "type=CreateBasic" in str(captured["url"])

    @pytest.mark.asyncio
    async def test_creation_type_param_is_create_plus_value(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_record_xml())

        async with make_client(handler) as client:
            await client.modification_base(
                GREAT_TRAIN_ROBBERY,
                creation_type=CreationType.Series,
            )

        assert "type=CreateSeries" in str(captured["url"])

    @pytest.mark.asyncio
    async def test_returns_typed_contentrecord(self) -> None:
        from eidr.models.content import ContentRecord

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_content_record_xml())

        async with make_client(handler) as client:
            result = await client.modification_base(
                GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic
            )

        assert isinstance(result, ContentRecord)

    @pytest.mark.asyncio
    async def test_propagates_not_found_error(self) -> None:
        from eidr.errors import EIDRNotFoundError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>not found</Type></Status>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            with pytest.raises(EIDRNotFoundError):
                await client.modification_base(
                    GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic
                )


# ─── M10-A: status-lookup variants async mirror ─────────────────────────────


class TestAsyncStatusLookupByUser:
    @pytest.mark.asyncio
    async def test_posts_to_status_endpoint_with_userid(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        async with make_client(handler) as client:
            await client.status_lookup_by_user("10.5238/richardkroon")

        assert captured["method"] == "POST"
        assert "/status/" in str(captured["url"])
        body = str(captured["body"])
        assert "<UserID>10.5238/richardkroon</UserID>" in body
        # Async path must use the same UserID-not-User special case as sync.
        assert "<User>" not in body

    @pytest.mark.asyncio
    async def test_after_and_before_emit_from_to(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        async with make_client(handler) as client:
            await client.status_lookup_by_user(
                "10.5238/richardkroon",
                after=datetime(2026, 4, 1, tzinfo=UTC),
                before=datetime(2026, 4, 27, tzinfo=UTC),
            )

        body = str(captured["body"])
        assert "<From>2026-04-01T00:00:00+00:00</From>" in body
        assert "<To>2026-04-27T00:00:00+00:00</To>" in body


class TestAsyncStatusLookupByRegistrant:
    @pytest.mark.asyncio
    async def test_posts_with_registrant_element(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        async with make_client(handler) as client:
            await client.status_lookup_by_registrant("10.5237/FFDA-9947")

        body = str(captured["body"])
        assert "<Registrant>10.5237/FFDA-9947</Registrant>" in body
        assert "<UserID>" not in body


class TestAsyncStatusLookupSuperparty:
    @pytest.mark.asyncio
    async def test_posts_without_tag_element(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        async with make_client(handler) as client:
            await client.status_lookup_superparty()

        body = str(captured["body"])
        assert "<UserID>" not in body
        assert "<Registrant>" not in body
        assert "<PageNumber>1</PageNumber>" in body
