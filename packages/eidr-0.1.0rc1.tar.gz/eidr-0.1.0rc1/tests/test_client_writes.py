"""End-to-end write-operation tests for :class:`eidr.client.Client`.

Uses :class:`httpx.MockTransport` to simulate the registry. Tests
verify the request wire shape (URL, headers, body) and the response
handling (Token vs record).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

import httpx
import pytest

from eidr.client import (
    Client,
    DedupeMode,
    ListSink,
    RelationshipType,
    Token,
    TokenStatus,
    TraceRecord,
)
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.content import ContentRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

READONLY = Registry(
    name="TEST_RO",
    url="https://test-ro.example/EIDR",
    writable=False,
    description="Read-only",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _content_record_xml(
    *,
    with_id: bool = True,
    creation_type: str = "Basic",
) -> bytes:
    """A minimal but validator-accepted FullMetadata for a content record."""
    # Valid EIDR ID with correct Mod 37,36 check character (from fixtures).
    id_elem = "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>" if with_id else ""
    extra = f"<ExtraObjectMetadata><{creation_type}/></ExtraObjectMetadata>"
    if creation_type == "Basic":
        # Basic is the implicit default — no ExtraObjectMetadata needed
        extra = ""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<FullMetadata {NS}>"
        "<BaseObjectData>"
        f"{id_elem}"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        f"{extra}"
        "</FullMetadata>"
    ).encode()


def _content_record(**kwargs: object) -> ContentRecord:
    return ContentRecord.from_xml(_content_record_xml(**kwargs))  # type: ignore[arg-type]


def _success_envelope_with_token(token: str = "tok-abc") -> str:
    """Build a successful envelope response carrying a Token."""
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        f"<Token>{token}</Token>"
        "</Response>"
    )


def _success_envelope() -> str:
    """Build a bare success envelope (no token — common for delete etc.)."""
    return f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"


def _registered_record_xml() -> str:
    """A registry-returned FullMetadata after a successful register.

    Uses a known-valid EIDR ID (correct Mod 37,36 check character) from
    the fixture set so ContentRecord.id parses correctly.
    """
    return (
        f"<FullMetadata {NS}>"
        "<BaseObjectData>"
        # Valid EIDR ID with correct Mod 37,36 check char
        "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
    tracing: ListSink | None = None,
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(
        registry,
        CREDS,
        transport_config=config,
        tracing=tracing,
    )


# ─────────────────────────────────────────────────────────────────────────────
# register
# ─────────────────────────────────────────────────────────────────────────────


class TestRegister:
    def test_posts_to_register_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["immediate"] = request.headers.get("Immediate-Response")
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            result = client.register(_content_record(), immediate=True)

        assert captured["url"] == "https://test.example/EIDR/register/"
        assert captured["method"] == "POST"
        assert captured["immediate"] == "true"
        body = cast(str, captured["body"])
        assert '<Create type="CreateBasic">' in body
        assert "<Request " in body
        # Returned a ContentRecord with the new ID parsed from the response
        assert isinstance(result, ContentRecord)
        assert result.id is not None
        assert "0000-02ED-1DCE-6AAF-99F7" in str(result.id)

    def test_async_returns_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.headers.get("Immediate-Response") == "false"
            return httpx.Response(200, text=_success_envelope_with_token())

        with make_client(handler) as client:
            result = client.register(_content_record(), immediate=False)

        assert isinstance(result, Token)
        assert result.value == "tok-abc"

    def test_dedupe_mode_appears_in_envelope(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope_with_token())

        with make_client(handler) as client:
            client.register(
                _content_record(),
                immediate=False,
                dedupe_mode=DedupeMode.MANUAL,
            )
        assert 'dedupMode="manual"' in cast(str, captured["body"])

    def test_dedupe_mode_absent_by_default(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope_with_token())

        with make_client(handler) as client:
            client.register(_content_record(), immediate=False)
        body = cast(str, captured["body"])
        # When the caller doesn't specify, no dedupMode attribute appears
        # (normal mode is the implicit default)
        assert "dedupMode" not in body

    def test_readonly_registry_refuses(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        from eidr.errors import EIDRReadOnlyRegistryError

        with (
            make_client(handler, registry=READONLY) as client,
            pytest.raises(EIDRReadOnlyRegistryError),
        ):
            client.register(_content_record(), immediate=True)


# ─────────────────────────────────────────────────────────────────────────────
# match
# ─────────────────────────────────────────────────────────────────────────────


class TestMatch:
    def test_posts_to_match_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["immediate"] = request.headers.get("Immediate-Response")
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            client.match(_content_record())

        assert captured["url"] == "https://test.example/EIDR/match/"
        # Match is always immediate
        assert captured["immediate"] == "true"

    def test_match_handles_status_details_id_response(self) -> None:
        """Reviewer-flagged regression from M9 live-test pass:

        ``match()`` against an existing record returns a success
        envelope with the matched-record ID in ``<Status><Details>``,
        not an inline record body. Previously this raised
        ``EIDRProtocolError`` ("succeeded but the registry returned
        neither a record nor a token"). With the live-test fix,
        ``_submit_write`` extracts the ID from ``<Details>`` and
        follows up with ``resolve()`` to return the matched record.

        This test simulates the two-stage interaction.
        """
        matched_id = "10.5240/7791-8534-2C23-9030-8610-5"

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST":
                # Initial match POST — registry returns just the ID
                # of the duplicate it found, in <Status><Details>.
                return httpx.Response(
                    200,
                    text=(
                        f'<Response xmlns="http://www.eidr.org/schema">'
                        "<Status>"
                        "<Code>0</Code><Type>success</Type>"
                        f"<Details>{matched_id}</Details>"
                        "</Status>"
                        "</Response>"
                    ),
                )
            # Follow-up resolve GET — registry returns the matched
            # record body.
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            result = client.match(_content_record())

        # Match must return a ContentRecord, not None and not a Token.
        from eidr.models import ContentRecord

        assert isinstance(result, ContentRecord), (
            f"expected ContentRecord, got {type(result).__name__}: {result!r}"
        )

    def test_match_handles_operationresult_wrapped_details(self) -> None:
        """Variant of the ID-in-Details shape: Content writes (which
        use the ``<Operations>`` envelope) typically receive
        responses with ``<Details>`` nested inside
        ``<OperationResult>`` rather than at top-level ``<Status>``::

            <Response>
              <OperationResult>
                <Status>
                  <Code>0</Code>
                  <Type>success</Type>
                  <Details>10.5240/...</Details>
                </Status>
              </OperationResult>
            </Response>

        This is the shape M9 live-test pass round 2 didn't anticipate
        in its initial round-2 fix; the extractor now handles both
        top-level and OperationResult-wrapped variants.
        """
        matched_id = "10.5240/7791-8534-2C23-9030-8610-5"

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST":
                return httpx.Response(
                    200,
                    text=(
                        f'<Response xmlns="http://www.eidr.org/schema">'
                        "<OperationResult>"
                        "<Status>"
                        "<Code>0</Code><Type>success</Type>"
                        f"<Details>{matched_id}</Details>"
                        "</Status>"
                        "</OperationResult>"
                        "</Response>"
                    ),
                )
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            result = client.match(_content_record())

        from eidr.models import ContentRecord

        assert isinstance(result, ContentRecord), (
            f"expected ContentRecord, got {type(result).__name__}: {result!r}"
        )

    def test_match_resolves_duplicate_id_from_response(self) -> None:
        """Reviewer-flagged regression from M9 live-test pass round 5:

        The live ``sandbox2.eidr.org`` registry's ``match`` response
        for a found-duplicate result includes both a request-level
        ``<Token>`` and the matched record's ID inline, in
        ``<OperationStatus>/<Duplicate>/<ID>``::

            <Response>
              <Status><Code>0</Code><Type>success</Type></Status>
              <RequestStatus><Token>...</Token></RequestStatus>
              <RequestStatusResults>
                <CurrentSize>1</CurrentSize>
                <TotalMatches>1</TotalMatches>
                <OperationStatus>
                  <Token>...</Token>
                  <Status><Code>0</Code><Type>success</Type></Status>
                  <Duplicate score="95" lowThreshold="60"
                             highThreshold="90">
                    <ID>10.5240/...</ID>
                  </Duplicate>
                </OperationStatus>
              </RequestStatusResults>
            </Response>

        Without the round-5 fix, the SDK would only see the
        request-level token and return that as a deferred ``Token``,
        forcing the caller to poll ``status_lookup`` for an answer
        already in the body. With the fix, the SDK resolves the
        duplicate ID inline and returns a ``ContentRecord``.
        """
        matched_id = "10.5240/7791-8534-2C23-9030-8610-5"

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST":
                # Match POST → dup-found envelope
                return httpx.Response(
                    200,
                    text=(
                        '<Response xmlns="http://www.eidr.org/schema">'
                        "<Status><Code>0</Code><Type>success</Type></Status>"
                        "<RequestStatus><Token>1777250952014000067</Token></RequestStatus>"
                        "<RequestStatusResults>"
                        "<CurrentSize>1</CurrentSize>"
                        "<TotalMatches>1</TotalMatches>"
                        "<OperationStatus>"
                        "<Token>1777250952014000067</Token>"
                        "<Status><Code>0</Code><Type>success</Type></Status>"
                        '<Duplicate score="95" lowThreshold="60" highThreshold="90">'
                        f"<ID>{matched_id}</ID>"
                        "</Duplicate>"
                        "</OperationStatus>"
                        "</RequestStatusResults>"
                        "</Response>"
                    ),
                )
            # GET (the resolve follow-up) → return a record body
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            result = client.match(_content_record())

        from eidr.models import ContentRecord

        assert isinstance(result, ContentRecord), (
            f"expected ContentRecord, got {type(result).__name__}: {result!r}"
        )

    def test_match_surfaces_operation_level_validation_error(self) -> None:
        """Reviewer-flagged regression from M9 live-test pass round 4:

        The registry can return ``Code 0 success`` at the request
        level while reporting an *operation-level* error — for
        example, when ``match`` is called with a record whose
        ``<Administrators><Registrant>`` doesn't match the
        authenticating party::

            <Response>
              <Status><Code>0</Code><Type>success</Type></Status>
              <RequestStatus><Token>...</Token></RequestStatus>
              <RequestStatusResults>
                <OperationStatus>
                  <Token>...</Token>
                  <Status>
                    <Code>4</Code>
                    <Type>validation error</Type>
                    <Details>Registrant must match the Party ID</Details>
                  </Status>
                </OperationStatus>
              </RequestStatusResults>
            </Response>

        Previously this was treated as a generic
        ``EIDRProtocolError`` ("registry returned neither a record
        nor a token"), hiding the actionable diagnostic. Now the
        operation-level ``<Status>`` is checked before other
        extraction paths and surfaces the proper typed exception
        with full code/type/details context.
        """
        from eidr.errors import EIDRValidationError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>0</Code><Type>success</Type></Status>"
                    "<RequestStatus><Token>1777249423649000061</Token></RequestStatus>"
                    "<RequestStatusResults>"
                    "<CurrentSize>1</CurrentSize>"
                    "<TotalMatches>1</TotalMatches>"
                    "<OperationStatus>"
                    "<Token>1777249423649000061</Token>"
                    "<Status>"
                    "<Code>4</Code>"
                    "<Type>validation error</Type>"
                    "<Details>Registrant must match the Party ID</Details>"
                    "</Status>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        with (
            make_client(handler) as client,
            pytest.raises(EIDRValidationError) as exc_info,
        ):
            client.match(_content_record())

        # The full diagnostic — code, type, details — must be
        # surfaced to the caller.
        assert "Registrant must match the Party ID" in str(exc_info.value)


# ─────────────────────────────────────────────────────────────────────────────
# modify
# ─────────────────────────────────────────────────────────────────────────────
# Pre-submission pipeline (validate / normalize / strip_empty)
# ─────────────────────────────────────────────────────────────────────────────


class TestPreSubmissionPipeline:
    """The ``validate`` / ``normalize`` / ``strip_empty`` flags on
    :meth:`Client.register` and :meth:`Client.modify` apply optional
    pre-submission transforms. All three default to ``False`` to
    avoid silent mutation of caller data."""

    def test_default_no_transforms_applied(self) -> None:
        """When no flags are set, register submits without invoking
        the validator. (Whitespace normalization at the XML codec
        layer is unconditional and unrelated.)"""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_registered_record_xml())

        # Build a record that would FAIL validation if validate=True
        # (no OriginalLanguage), and confirm register accepts it.
        record_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<FullMetadata {NS}>"
            "<BaseObjectData>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>Test</ResourceName>"
            "<Status>valid</Status>"
            "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
            "</BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(record_xml)

        with make_client(handler) as client:
            # No flags → no validation, no error.
            client.register(rec, immediate=True)

    def test_normalize_does_not_break_round_trip(self) -> None:
        """``normalize=True`` produces a record that still serializes
        cleanly. (The codec layer already strips leading/trailing
        whitespace from text content, so the observable difference
        from ``normalize=True`` for typical records is small —
        normalization mostly matters for codec dicts constructed
        programmatically without going through the XML round-trip.)"""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_registered_record_xml())

        rec = _content_record()
        with make_client(handler) as client:
            result = client.register(rec, immediate=True, normalize=True)
        assert isinstance(result, ContentRecord)

    def test_validate_true_raises_on_missing_required_fields(self) -> None:
        """A record missing required fields fails validation when
        ``validate=True`` and never reaches the transport."""
        from eidr.errors import EIDRValidationError

        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        # Record missing OriginalLanguage (required for Movie).
        record_xml = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f"<FullMetadata {NS}>"
            "<BaseObjectData>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>Test</ResourceName>"
            "<Status>valid</Status>"
            "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
            "</BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(record_xml)

        with make_client(handler) as client, pytest.raises(EIDRValidationError):
            client.register(rec, immediate=True, validate=True)

    def test_validate_create_mode_rejects_id_present(self) -> None:
        """Register-mode validation enforces ID-must-be-absent."""
        from eidr.errors import EIDRValidationError

        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        # ID set on a Create-mode record → validation failure.
        rec = _content_record(with_id=True)
        with make_client(handler) as client, pytest.raises(EIDRValidationError):
            client.register(rec, immediate=True, validate=True)

    def test_validate_modify_mode_requires_id(self) -> None:
        """Modify-mode validation enforces ID-must-be-present.
        Without an ID the upstream ValueError fires before validation."""

        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        rec = _content_record(with_id=False)
        with make_client(handler) as client, pytest.raises(ValueError, match=r"record\.id"):
            client.modify(rec, immediate=True, validate=True)

    def test_does_not_mutate_caller_record(self) -> None:
        """The pre-submission pipeline operates on a copy; the
        caller's record is unchanged after the call."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_registered_record_xml())

        rec = _content_record()
        # Snapshot the record's data before the call. CodecDicts are
        # not hashable, but they ARE comparable via equality.
        original_data = dict(rec.data)

        with make_client(handler) as client:
            client.register(rec, immediate=True, normalize=True, strip_empty=True)

        # Caller's record was not modified.
        assert rec.data == original_data

    def test_posts_to_modify_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_record_xml())

        with make_client(handler) as client:
            client.modify(_content_record(), immediate=True)

        assert captured["url"] == "https://test.example/EIDR/modify/"
        body = cast(str, captured["body"])
        assert '<Modify type="CreateBasic">' in body
        assert "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>" in body

    def test_requires_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match=r"record\.id"):
            client.modify(_content_record(with_id=False))


# ─────────────────────────────────────────────────────────────────────────────
# delete / promote / alias
# ─────────────────────────────────────────────────────────────────────────────


class TestDelete:
    def test_delete_immediate_returns_none(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            result = client.delete("10.5240/DOOMED", immediate=True)

        assert "<Delete><ID>10.5240/DOOMED</ID></Delete>" in cast(str, captured["body"])
        # delete has no inline result — None on immediate success
        assert result is None

    def test_delete_async_returns_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token("del-1"))

        with make_client(handler) as client:
            tok = client.delete("10.5240/X", immediate=False)
        assert isinstance(tok, Token)
        assert tok.value == "del-1"


class TestPromote:
    def test_promote_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            result = client.promote("10.5240/X", immediate=True)

        assert "<Promote><ID>10.5240/X</ID></Promote>" in cast(str, captured["body"])
        assert result is None


class TestAlias:
    def test_alias_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.alias("10.5240/SRC", "10.5240/TGT", immediate=True)

        body = cast(str, captured["body"])
        assert "<Alias>" in body
        assert "<ID>10.5240/SRC</ID>" in body
        assert "<TargetID>10.5240/TGT</TargetID>" in body


# ─────────────────────────────────────────────────────────────────────────────
# Relationship operations
# ─────────────────────────────────────────────────────────────────────────────


class TestAddRelationship:
    def test_add_relationship_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        info = "<PromotionInfo><ID>10.5240/TGT</ID></PromotionInfo>"
        with make_client(handler) as client:
            client.add_relationship(
                "10.5240/SRC",
                RelationshipType.PROMOTIONAL,
                info,
                immediate=True,
            )

        body = cast(str, captured["body"])
        assert '<AddRelationship type="PromotionalRelationship">' in body
        assert "<ID>10.5240/SRC</ID>" in body
        assert info in body


class TestRemoveReplaceRelationship:
    def test_remove(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.remove_relationship(
                "10.5240/SRC",
                RelationshipType.COMPOSITE,
                immediate=True,
            )
        body = cast(str, captured["body"])
        assert '<RemoveRelationship type="CompositeRelationship">' in body

    def test_replace(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        info = "<PackagingInfo><ID>10.5240/P</ID></PackagingInfo>"
        with make_client(handler) as client:
            client.replace_relationship(
                "10.5240/SRC",
                RelationshipType.PACKAGING,
                info,
                immediate=True,
            )
        body = cast(str, captured["body"])
        assert '<ReplaceRelationship type="PackagingRelationship">' in body
        assert info in body


# ─────────────────────────────────────────────────────────────────────────────
# wait_timeout polling behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestWaitTimeout:
    def test_wait_returns_token_when_still_pending(self) -> None:
        """If the token hasn't resolved within wait_timeout, return the Token."""
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] == 1:
                # First call: register POST
                return httpx.Response(200, text=_success_envelope_with_token("pending-tok"))
            # Subsequent calls: status lookup always says pending
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<RequestStatusResults>"
                    "<OperationStatus>"
                    "<Token>sub-pending</Token>"
                    "<Status><Code>2</Code><Type>pending</Type></Status>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            result = client.register(
                _content_record(),
                immediate=False,
                wait_timeout=0.05,  # Tiny timeout
            )
        # wait_timeout exhausted without resolving → Token returned
        assert isinstance(result, Token)
        assert result.status is TokenStatus.PENDING

    def test_wait_none_does_not_poll(self) -> None:
        """wait_timeout=None means "return Token immediately, no polling"."""
        poll_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            if "/status/" in str(request.url):
                poll_count[0] += 1
            return httpx.Response(200, text=_success_envelope_with_token("t"))

        with make_client(handler) as client:
            client.register(_content_record(), immediate=False, wait_timeout=None)
        assert poll_count[0] == 0


# ─────────────────────────────────────────────────────────────────────────────
# Tracing captures write operations too
# ─────────────────────────────────────────────────────────────────────────────


class TestWriteTracing:
    def test_register_captures_full_request_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_registered_record_xml())

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.register(_content_record(), immediate=True)

        assert len(sink.records) == 1
        rec: TraceRecord = sink.records[0]
        assert rec.method == "POST"
        # The tracing captures the FULL multipart request body
        assert rec.request_body is not None
        assert "--314159" in rec.request_body
        assert '<Create type="CreateBasic">' in rec.request_body

    def test_dedupe_mode_appears_in_trace(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token())

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.register(
                _content_record(),
                immediate=False,
                dedupe_mode=DedupeMode.MANUAL,
            )

        rec = sink.records[0]
        assert rec.request_body is not None
        assert 'dedupMode="manual"' in rec.request_body

    def test_authorization_still_redacted(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token())

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.register(_content_record(), immediate=False)

        rec = sink.records[0]
        auth_values = [v for n, v in rec.request_headers if n.lower() == "authorization"]
        assert len(auth_values) == 1
        assert "REDACTED" in auth_values[0]
