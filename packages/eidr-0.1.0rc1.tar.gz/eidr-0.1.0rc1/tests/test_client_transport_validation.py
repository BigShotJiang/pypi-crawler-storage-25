"""Tests for sync/async transport mismatch detection.

The :class:`TransportConfig` field types make wrong assignments a
static type error in ``mypy --strict`` — pass a sync transport to
``async_httpx_transport`` and mypy flags it. But for callers using
untyped code (dynamic plugin loading, JSON config, REPL exploration)
the validator helpers in :mod:`eidr.client._http` are belt-and-
suspenders: they raise :class:`TypeError` with a precise message
when the runtime type is wrong.

These tests bypass the static type system (``# type: ignore`` on
the wrong assignment) to verify the runtime backstop works.
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from eidr.client import AsyncClient, Client
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test",
)
CREDS = Credentials(
    user_id="10.5238/u",
    party_id="10.5237/FFDA-9947",
    password="p",
)


class _SyncOnlyTransport(httpx.BaseTransport):
    """A transport that only implements the sync protocol."""

    def handle_request(self, request: httpx.Request) -> httpx.Response:  # pragma: no cover
        return httpx.Response(200, content=b"ok")


class _AsyncOnlyTransport(httpx.AsyncBaseTransport):
    """A transport that only implements the async protocol."""

    async def handle_async_request(  # pragma: no cover
        self, request: httpx.Request
    ) -> httpx.Response:
        return httpx.Response(200, content=b"ok")


class TestSyncTransportMismatch:
    """Pass an async-only transport via ``httpx_transport`` (the
    sync field) → :class:`TypeError` at sync Client construction.

    Static type check would catch this at the assignment site, but
    untyped code paths bypass that. The validator runs from the
    transport's __init__ before any httpx call is issued."""

    def test_async_only_transport_rejected_by_sync_client(self) -> None:
        # Cast to Any to bypass mypy — simulating untyped caller code.
        bad: Any = _AsyncOnlyTransport()
        config = TransportConfig(httpx_transport=bad)
        with pytest.raises(TypeError, match=r"httpx\.BaseTransport"):
            Client(REGISTRY, CREDS, transport_config=config)

    def test_error_message_recommends_correct_field(self) -> None:
        bad: Any = _AsyncOnlyTransport()
        config = TransportConfig(httpx_transport=bad)
        with pytest.raises(TypeError) as excinfo:
            Client(REGISTRY, CREDS, transport_config=config)
        msg = str(excinfo.value)
        assert "async_httpx_transport" in msg
        assert "AsyncClient" in msg


class TestAsyncTransportMismatch:
    """Mirror: pass a sync-only transport via ``async_httpx_transport``
    → :class:`TypeError` at AsyncClient construction."""

    def test_sync_only_transport_rejected_by_async_client(self) -> None:
        bad: Any = _SyncOnlyTransport()
        config = TransportConfig(async_httpx_transport=bad)
        with pytest.raises(TypeError, match=r"httpx\.AsyncBaseTransport"):
            AsyncClient(REGISTRY, CREDS, transport_config=config)

    def test_error_message_recommends_correct_field(self) -> None:
        bad: Any = _SyncOnlyTransport()
        config = TransportConfig(async_httpx_transport=bad)
        with pytest.raises(TypeError) as excinfo:
            AsyncClient(REGISTRY, CREDS, transport_config=config)
        msg = str(excinfo.value)
        assert "httpx_transport" in msg
        # Specifically the sync field name, so look for it without the
        # "async_" prefix preceding it.
        assert "Client" in msg


class TestMockTransportPassesEither:
    """``httpx.MockTransport`` inherits from both base classes; either
    field accepts it. This is the "shared mock between sync and async
    tests" use case."""

    def test_mock_in_sync_field(self) -> None:
        mock = httpx.MockTransport(lambda r: httpx.Response(200, content=b"ok"))
        config = TransportConfig(httpx_transport=mock)
        # Constructs without raising
        client = Client(REGISTRY, CREDS, transport_config=config)
        client.close()

    def test_mock_in_async_field(self) -> None:
        mock = httpx.MockTransport(lambda r: httpx.Response(200, content=b"ok"))
        config = TransportConfig(async_httpx_transport=mock)
        # Constructs without raising
        client = AsyncClient(REGISTRY, CREDS, transport_config=config)
        # No await needed — close is fast since httpx never made a call
        import asyncio

        asyncio.run(client.aclose())

    def test_none_passes_either(self) -> None:
        # Both default to None, no transport injected; default path
        config = TransportConfig()
        Client(REGISTRY, CREDS, transport_config=config).close()
        import asyncio

        asyncio.run(AsyncClient(REGISTRY, CREDS, transport_config=config).aclose())
