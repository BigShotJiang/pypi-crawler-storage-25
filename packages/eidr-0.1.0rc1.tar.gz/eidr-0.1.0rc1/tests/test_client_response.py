"""Tests for :mod:`eidr.client._response`.

Pure-function tests: no HTTP, no httpx. We build response bodies as
strings and pass them through :func:`parse_response`.
"""

from __future__ import annotations

import pytest

from eidr.client._response import (
    extract_record_xml,
    extract_token,
    iter_sub_tokens,
    parse_response,
)
from eidr.errors import (
    EIDRAuthenticationError,
    EIDRAuthorizationError,
    EIDRDuplicateError,
    EIDRNotFoundError,
    EIDRProtocolError,
    EIDRRegistryError,
    EIDRValidationError,
)

NS = ' xmlns="http://www.eidr.org/schema"'


def _envelope(code: int, type_str: str = "", body: str = "", details: str = "") -> str:
    """Build a <Response> envelope with the given status.

    ``details`` goes inside ``<Status>`` as ``<Details>``; ``body``
    goes after ``</Status>`` for e.g. ``<RequestStatusResults>``.
    """
    status_extra = f"<Details>{details}</Details>" if details else ""
    return (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<Response{NS} version="2.7.1">'
        f"<Status><Code>{code}</Code><Type>{type_str}</Type>{status_extra}</Status>"
        f"{body}"
        f"</Response>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Resolution-style responses (record roots)
# ─────────────────────────────────────────────────────────────────────────────


class TestRecordResponses:
    """Root elements from the record-family are returned as kind='record'."""

    def test_full_metadata_parses_as_record(self) -> None:
        body = f"<FullMetadata{NS}><BaseObjectData/></FullMetadata>"
        parsed = parse_response(body, operation="resolve test")
        assert parsed.kind == "record"
        assert parsed.status_code is None
        assert parsed.status_type is None

    def test_self_defined_metadata_parses_as_record(self) -> None:
        body = f"<SelfDefinedMetadata{NS}><BaseObjectData/></SelfDefinedMetadata>"
        parsed = parse_response(body, operation="resolve test")
        assert parsed.kind == "record"

    def test_provenance_metadata_parses_as_record(self) -> None:
        body = f"<ProvenanceMetadata{NS}><BaseObjectData/></ProvenanceMetadata>"
        parsed = parse_response(body, operation="resolve test")
        assert parsed.kind == "record"

    def test_inherited_metadata_parses_as_record(self) -> None:
        body = f"<InheritedMetadata{NS}><BaseObjectData/></InheritedMetadata>"
        parsed = parse_response(body, operation="resolve test")
        assert parsed.kind == "record"

    def test_alias_continuation_parses_as_record(self) -> None:
        body = (
            f"<AliasContinuation{NS}>"
            f"<CurrentID>10.5240/0000-0000-0000-0000-0000-A</CurrentID>"
            f"<Alias>10.5240/0000-0000-0000-0000-0000-B</Alias>"
            f"</AliasContinuation>"
        )
        parsed = parse_response(body, operation="resolve test")
        assert parsed.kind == "record"

    def test_extract_record_xml_roundtrip(self) -> None:
        body = f"<FullMetadata{NS}><BaseObjectData/></FullMetadata>"
        parsed = parse_response(body, operation="resolve test")
        xml = extract_record_xml(parsed)
        assert b"FullMetadata" in xml
        assert b"BaseObjectData" in xml

    def test_extract_record_xml_rejects_envelope(self) -> None:
        parsed = parse_response(_envelope(0, "Success"), operation="x")
        with pytest.raises(ValueError, match="expects a record response"):
            extract_record_xml(parsed)


# ─────────────────────────────────────────────────────────────────────────────
# Envelope responses — status code zero (success)
# ─────────────────────────────────────────────────────────────────────────────


class TestEnvelopeSuccess:
    def test_zero_code_returns_envelope(self) -> None:
        parsed = parse_response(_envelope(0, "Success"), operation="x")
        assert parsed.kind == "envelope"
        assert parsed.status_code == 0
        assert parsed.status_type == "Success"

    def test_zero_code_default_type_when_blank(self) -> None:
        parsed = parse_response(_envelope(0, ""), operation="x")
        assert parsed.status_type == "Success"

    def test_extract_token_from_success_envelope(self) -> None:
        body = _envelope(0, "Success", "<Token>abc123-def456</Token>")
        parsed = parse_response(body, operation="x")
        assert extract_token(parsed) == "abc123-def456"

    def test_extract_token_from_nested_request_status(self) -> None:
        """Regression test for M9 live-test pass round 4:

        The ``match`` operation's response carries the
        request-level Token nested inside ``<RequestStatus>``
        rather than at top level. The previous implementation only
        looked at ``<Response>/<Token>``, so it returned None for
        match responses and ``_submit_write`` fell through to its
        bare-success branch, raising ``EIDRProtocolError``. Verified
        against the live ``sandbox2.eidr.org`` registry.
        """
        body = _envelope(
            0,
            "Success",
            "<RequestStatus><Token>1777249423649000061</Token></RequestStatus>",
        )
        parsed = parse_response(body, operation="x")
        assert extract_token(parsed) == "1777249423649000061"

    def test_extract_token_returns_none_when_absent(self) -> None:
        parsed = parse_response(_envelope(0, "Success"), operation="x")
        assert extract_token(parsed) is None

    def test_extract_token_returns_none_for_record(self) -> None:
        body = f"<FullMetadata{NS}><BaseObjectData/></FullMetadata>"
        parsed = parse_response(body, operation="x")
        assert extract_token(parsed) is None


# ─────────────────────────────────────────────────────────────────────────────
# Envelope responses — status code nonzero (failure)
# ─────────────────────────────────────────────────────────────────────────────


class TestEnvelopeStatusCodeMapping:
    """Verifies that response-envelope errors map to typed exceptions.

    Uses the Type strings the EIDR registry actually emits, per REST API
    Reference Tables 5 (top-level status) and 6 (per-operation status).
    The mapping is driven by the Type string first, with code as
    fallback — because REST API code values and Operation Status code
    values overlap numerically but mean different things, while the
    Type strings are unambiguous.
    """

    def test_duplicate_type_raises_duplicate(self) -> None:
        # Operation status code 1 = "duplicate" per Table 6.
        with pytest.raises(EIDRDuplicateError) as exc_info:
            parse_response(_envelope(1, "duplicate"), operation="register x")
        assert exc_info.value.code == 1  # type: ignore[attr-defined]
        assert exc_info.value.type == "duplicate"  # type: ignore[attr-defined]

    def test_validation_type_raises_validation(self) -> None:
        # Operation status code 4 = "validation error" per Table 6.
        with pytest.raises(EIDRValidationError):
            parse_response(_envelope(4, "validation error"), operation="x")

    def test_invalid_xml_raises_validation(self) -> None:
        # Top-level status code 9 = "syntax error" — also validation-class.
        with pytest.raises(EIDRValidationError):
            parse_response(_envelope(9, "syntax error"), operation="x")

    def test_authentication_type_raises_authentication(self) -> None:
        # Top-level code 4 = "authentication error" per Table 5.
        with pytest.raises(EIDRAuthenticationError):
            parse_response(_envelope(4, "authentication error"), operation="x")

    def test_authorization_code_5_raises_authorization(self) -> None:
        # Top-level code 5 = "authorization error" per Table 5.
        # Previously this SDK wrongly mapped code 5 → NotFoundError; this
        # test guards against that regression.
        with pytest.raises(EIDRAuthorizationError):
            parse_response(_envelope(5, "authorization error"), operation="x")

    def test_bad_id_raises_not_found(self) -> None:
        # Top-level code 8 = "bad id error" per Table 5. Not-found-ish.
        with pytest.raises(EIDRNotFoundError):
            parse_response(_envelope(8, "bad id error"), operation="x")

    def test_unmapped_type_raises_generic_registry_error(self) -> None:
        with pytest.raises(EIDRRegistryError) as exc_info:
            parse_response(_envelope(42, "something unexpected"), operation="x")
        assert exc_info.value.code == 42  # type: ignore[attr-defined]
        assert exc_info.value.type == "something unexpected"  # type: ignore[attr-defined]

    def test_details_extracted_and_attached(self) -> None:
        # The registry's <Details> carries the actionable diagnostic.
        body = _envelope(
            4,
            "validation error",
            details="Referent Type must be one of 'TV', 'Movie', 'Short', 'Web'",
        )
        with pytest.raises(EIDRValidationError) as exc_info:
            parse_response(body, operation="register x")
        assert exc_info.value.details == (  # type: ignore[attr-defined]
            "Referent Type must be one of 'TV', 'Movie', 'Short', 'Web'"
        )
        # Details also surfaces in the exception message for quick triage.
        assert "Referent Type" in str(exc_info.value)


# ─────────────────────────────────────────────────────────────────────────────
# OperationStatus / sub-token extraction
# ─────────────────────────────────────────────────────────────────────────────


class TestOperationStatusExtraction:
    def test_sub_tokens_pulled_from_operation_status(self) -> None:
        body = _envelope(
            0,
            "Success",
            "<RequestStatusResults>"
            "<OperationStatus><Token>sub-token-1</Token><Status><Code>100</Code></Status></OperationStatus>"
            "<OperationStatus><Token>sub-token-2</Token><Status><Code>100</Code></Status></OperationStatus>"
            "</RequestStatusResults>",
        )
        parsed = parse_response(body, operation="x")
        assert iter_sub_tokens(parsed) == ["sub-token-1", "sub-token-2"]

    def test_sub_tokens_empty_for_simple_envelope(self) -> None:
        parsed = parse_response(_envelope(0, "Success"), operation="x")
        assert iter_sub_tokens(parsed) == []

    def test_operation_status_elements_accessible(self) -> None:
        body = _envelope(
            0,
            "Success",
            "<RequestStatusResults>"
            "<OperationStatus><Token>a</Token><Status><Code>0</Code></Status></OperationStatus>"
            "</RequestStatusResults>",
        )
        parsed = parse_response(body, operation="x")
        ops = parsed.operation_status_elements()
        assert len(ops) == 1


# ─────────────────────────────────────────────────────────────────────────────
# Malformed / edge-case inputs
# ─────────────────────────────────────────────────────────────────────────────


class TestMalformedInputs:
    def test_empty_body_raises_protocol(self) -> None:
        with pytest.raises(EIDRProtocolError, match="Empty response body"):
            parse_response("", operation="x")

    def test_whitespace_only_body_raises_protocol(self) -> None:
        with pytest.raises(EIDRProtocolError, match="Empty response body"):
            parse_response("   \n  \t ", operation="x")

    def test_non_xml_body_raises_protocol(self) -> None:
        with pytest.raises(EIDRProtocolError, match="Malformed XML"):
            parse_response("This is not XML at all", operation="x")

    def test_unexpected_root_raises_protocol(self) -> None:
        body = f"<SomethingWeird{NS}/>"
        with pytest.raises(EIDRProtocolError, match="Unexpected root element"):
            parse_response(body, operation="x")

    def test_response_without_status_raises_protocol(self) -> None:
        body = f"<Response{NS}><SomeOtherChild/></Response>"
        with pytest.raises(EIDRProtocolError, match="lacks <Status>"):
            parse_response(body, operation="x")

    def test_response_with_non_integer_status_code_raises_protocol(self) -> None:
        body = (
            f"<Response{NS}>"
            f"<Status><Code>not-a-number</Code><Type>Whatever</Type></Status>"
            f"</Response>"
        )
        with pytest.raises(EIDRProtocolError, match="non-integer status"):
            parse_response(body, operation="x")


# ─────────────────────────────────────────────────────────────────────────────
# ParsedResponse helpers
# ─────────────────────────────────────────────────────────────────────────────


class TestParsedResponseHelpers:
    def test_operation_status_elements_empty_for_record(self) -> None:
        body = f"<FullMetadata{NS}><BaseObjectData/></FullMetadata>"
        parsed = parse_response(body, operation="x")
        assert parsed.operation_status_elements() == []

    def test_raw_body_preserved(self) -> None:
        body = _envelope(0, "Success")
        parsed = parse_response(body, operation="x")
        assert parsed.raw_body == body

    def test_ParsedResponse_frozen(self) -> None:
        parsed = parse_response(_envelope(0, "Success"), operation="x")
        # Frozen dataclasses raise FrozenInstanceError on field assignment.
        # FrozenInstanceError is a subclass of AttributeError.
        with pytest.raises(AttributeError):
            parsed.status_code = 99  # type: ignore[misc]
