"""Unit tests for the Party-write Superparty gate.

The gate is the SDK's client-side enforcement of a registry-side
policy: only the Party whose ID matches the registry's hard-coded
"Superparty" is permitted to execute Party-administration
operations. The registry rejects non-Superparty callers
server-side; the SDK refuses earlier with a clearer message and a
typed exception (:class:`~eidr.errors.EIDRSDKPolicyError`).

These tests cover:

1. **Default-strict mode** refuses every gated method when the
   configured Party ID doesn't match the Superparty ID.
2. **Matching credentials** pass through — the wire request goes
   out as expected.
3. **Disabling the gate** (``enforce_superparty_gate=False``) lets
   non-Superparty callers proceed.
4. **Custom Superparty ID** — passing a non-default value works.
5. **Anonymous client** is refused with a clear message.
6. **Read operations** (``resolve_party``, ``party_query``) are
   *never* gated.
7. **Service writes** are not gated (Party Roles handle that).
8. **Exception shape** — ``EIDRSDKPolicyError`` carries
   ``policy``, ``operation``, ``configured_value``,
   ``required_value`` attributes.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import AsyncClient, Client
from eidr.client._http import TransportConfig
from eidr.client._shared import DEFAULT_SUPERPARTY_ID
from eidr.credentials import Credentials
from eidr.errors import EIDRSDKPolicyError
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

NON_SUPERPARTY_CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",  # NOT the superparty
    password="testpw",
)
SUPERPARTY_CREDS = Credentials(
    user_id="10.5238/superuser",
    party_id=DEFAULT_SUPERPARTY_ID,  # 10.5237/superparty
    password="testpw",
)


def _no_wire_handler(request: httpx.Request) -> httpx.Response:
    """Handler that fails the test if any request reaches the wire.

    Used by negative-path tests to verify the gate refuses *before*
    any HTTP traffic — that's the whole point of a client-side
    gate.
    """
    raise AssertionError(
        f"Gated method should have refused before any HTTP request "
        f"was issued, but got {request.method} {request.url}"
    )


def _success_handler(request: httpx.Request) -> httpx.Response:
    """Handler that returns a bare-success envelope for any request."""
    return httpx.Response(
        200,
        text=(
            '<Response xmlns="http://www.eidr.org/schema">'
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "</Response>"
        ),
    )


def _make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    credentials: Credentials | None = NON_SUPERPARTY_CREDS,
    superparty_id: str = DEFAULT_SUPERPARTY_ID,
    enforce_superparty_gate: bool = True,
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(
        REGISTRY,
        credentials,
        transport_config=config,
        superparty_id=superparty_id,
        enforce_superparty_gate=enforce_superparty_gate,
    )


def _make_async_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    credentials: Credentials | None = NON_SUPERPARTY_CREDS,
    superparty_id: str = DEFAULT_SUPERPARTY_ID,
    enforce_superparty_gate: bool = True,
) -> AsyncClient:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(
        REGISTRY,
        credentials,
        transport_config=config,
        superparty_id=superparty_id,
        enforce_superparty_gate=enforce_superparty_gate,
    )


def _party_record() -> PartyRecord:
    """A minimal valid PartyRecord for tests that need one (modify_party).

    For methods that take a record, the gate fires before any
    XML serialization, so the record body content doesn't matter
    much — but we use a complete one so an accidentally-passing
    test (gate didn't fire) doesn't fail later for unrelated XML
    reasons.
    """
    xml = (
        b'<Party xmlns="http://www.eidr.org/schema" '
        b'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
        b"<ID>10.5237/AAAA-BBBB</ID>"
        b"<OrgName><md:DisplayName>Test Org</md:DisplayName></OrgName>"
        b"<Description>Test</Description>"
        b"<ContactInfo>"
        b"<Contact>"
        b"<md:DisplayName>Test Contact</md:DisplayName>"
        b"<Email>test@example.com</Email>"
        b"</Contact>"
        b"</ContactInfo>"
        b"<Status>active</Status>"
        b"<Type>Other</Type>"
        b"<DOIRegistration>NotApplicable</DOIRegistration>"
        b"</Party>"
    )
    return PartyRecord.from_xml(xml)


# ─── Group 1: every gated method refuses non-Superparty creds ──────────────

# (operation_name, callable_factory)
GATED_OPERATIONS: list[tuple[str, Callable[[Client], object]]] = [
    ("create_party", lambda c: c.create_party(_party_record(), "newpw")),
    ("modify_party", lambda c: c.modify_party(_party_record())),
    ("delete_party", lambda c: c.delete_party("10.5237/AAAA-BBBB")),
    ("alias_party", lambda c: c.alias_party("10.5237/AAAA-BBBB", "10.5237/CCCC-DDDD")),
    ("activate_party", lambda c: c.activate_party("10.5237/AAAA-BBBB")),
    ("deactivate_party", lambda c: c.deactivate_party("10.5237/AAAA-BBBB")),
    (
        "change_party_password",
        lambda c: c.change_party_password("10.5237/AAAA-BBBB", "newpw"),
    ),
]


class TestGateRefusesNonSuperparty:
    """Default-strict mode refuses every gated method."""

    @pytest.mark.parametrize(
        ("operation", "call"),
        GATED_OPERATIONS,
        ids=[op for op, _ in GATED_OPERATIONS],
    )
    def test_refuses_at_method_entry(
        self,
        operation: str,
        call: Callable[[Client], object],
    ) -> None:
        with (
            _make_client(_no_wire_handler) as client,
            pytest.raises(EIDRSDKPolicyError) as exc_info,
        ):
            call(client)

        # Exception shape: full diagnostic context.
        err = exc_info.value
        assert err.policy == "superparty_required"
        assert err.operation == operation
        assert err.configured_value == NON_SUPERPARTY_CREDS.party_id
        assert err.required_value == DEFAULT_SUPERPARTY_ID

        # Message readability: name the operation, the configured value,
        # the required value, and the override flag, so a developer who
        # hits this in production has enough info to act on without
        # reading the SDK source.
        message = str(err)
        assert operation in message
        assert NON_SUPERPARTY_CREDS.party_id in message
        assert DEFAULT_SUPERPARTY_ID in message
        assert "enforce_superparty_gate" in message


# ─── Group 2: matching Superparty credentials pass through ─────────────────


class TestGateAllowsSuperpartyCredentials:
    @pytest.mark.parametrize(
        ("operation", "call"),
        GATED_OPERATIONS,
        ids=[op for op, _ in GATED_OPERATIONS],
    )
    def test_allows_when_party_id_matches_superparty(
        self,
        operation: str,
        call: Callable[[Client], object],
    ) -> None:
        # When creds match, the request should go out. We don't
        # assert on the response shape (these methods have varied
        # return contracts); we just confirm the gate didn't refuse
        # and that the wire was reached.
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return _success_handler(request)

        with _make_client(handler, credentials=SUPERPARTY_CREDS) as client:
            try:
                call(client)
            except EIDRSDKPolicyError:
                pytest.fail(
                    f"{operation}() raised EIDRSDKPolicyError despite "
                    f"caller's party_id matching superparty_id"
                )
            except Exception:
                # Other exceptions (e.g. response-shape parsing) are
                # tolerated here — we're testing the gate, not the
                # method's full success path. As long as the gate
                # didn't raise and the wire was reached, the gate
                # passed.
                pass

        assert wire_reached, (
            f"{operation}() did not reach the wire even though caller's "
            f"party_id matched superparty_id"
        )


# ─── Group 3: enforce_superparty_gate=False bypasses ───────────────────────


class TestGateDisabled:
    @pytest.mark.parametrize(
        ("operation", "call"),
        GATED_OPERATIONS,
        ids=[op for op, _ in GATED_OPERATIONS],
    )
    def test_disabled_gate_lets_non_superparty_through(
        self,
        operation: str,
        call: Callable[[Client], object],
    ) -> None:
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return _success_handler(request)

        client = _make_client(
            handler,
            credentials=NON_SUPERPARTY_CREDS,
            enforce_superparty_gate=False,
        )
        with client:
            try:
                call(client)
            except EIDRSDKPolicyError:
                pytest.fail("Gate fired despite enforce_superparty_gate=False")
            except Exception:
                pass

        assert wire_reached, f"{operation}() did not reach the wire with the gate disabled"


# ─── Group 4: custom Superparty ID ─────────────────────────────────────────


class TestCustomSuperpartyId:
    """A non-default Superparty ID still enforces strictly."""

    def test_custom_id_allows_matching_party(self) -> None:
        custom_id = "10.5237/CUSTOM-SUPER"
        custom_creds = Credentials(
            user_id="10.5238/u",
            party_id=custom_id,
            password="pw",
        )
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return _success_handler(request)

        with _make_client(
            handler,
            credentials=custom_creds,
            superparty_id=custom_id,
        ) as client:
            client.delete_party("10.5237/AAAA-BBBB")

        assert wire_reached

    def test_custom_id_rejects_default_id(self) -> None:
        """Caller carrying the default ID is *not* the custom Superparty."""
        custom_id = "10.5237/CUSTOM-SUPER"
        with (
            _make_client(
                _no_wire_handler,
                credentials=SUPERPARTY_CREDS,  # has DEFAULT_SUPERPARTY_ID
                superparty_id=custom_id,
            ) as client,
            pytest.raises(EIDRSDKPolicyError) as exc_info,
        ):
            client.delete_party("10.5237/AAAA-BBBB")

        assert exc_info.value.required_value == custom_id
        assert exc_info.value.configured_value == DEFAULT_SUPERPARTY_ID


# ─── Group 5: anonymous client refused ─────────────────────────────────────


class TestGateRefusesAnonymous:
    """An anonymous client (no credentials) cannot pass the gate.

    Without credentials, the seven gated operations would fail
    server-side with auth error anyway; the SDK surfaces a clearer
    client-side error.
    """

    def test_anonymous_client_refused(self) -> None:
        with (
            _make_client(_no_wire_handler, credentials=None) as client,
            pytest.raises(EIDRSDKPolicyError) as exc_info,
        ):
            client.delete_party("10.5237/AAAA-BBBB")

        err = exc_info.value
        assert err.policy == "superparty_required"
        assert err.operation == "delete_party"
        assert err.configured_value is None
        assert err.required_value == DEFAULT_SUPERPARTY_ID
        # Message should explain that credentials are missing entirely,
        # not just that they don't match.
        assert "without credentials" in str(err)


# ─── Group 6: read operations are never gated ──────────────────────────────


class TestReadOperationsNeverGated:
    """``resolve_party`` and ``party_query`` work for any caller."""

    def test_resolve_party_works_with_non_superparty_creds(self) -> None:
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return httpx.Response(
                200,
                text=(
                    '<Party xmlns="http://www.eidr.org/schema" '
                    'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
                    "<ID>10.5237/AAAA-BBBB</ID>"
                    "<OrgName><md:DisplayName>X</md:DisplayName></OrgName>"
                    "<Description>x</Description>"
                    "<ContactInfo>"
                    "<Contact>"
                    "<md:DisplayName>x</md:DisplayName>"
                    "<Email>x@x.com</Email>"
                    "</Contact>"
                    "</ContactInfo>"
                    "<Status>active</Status>"
                    "<Type>Other</Type>"
                    "<DOIRegistration>NotApplicable</DOIRegistration>"
                    "</Party>"
                ),
            )

        with _make_client(handler) as client:
            client.resolve("10.5237/AAAA-BBBB")

        assert wire_reached, "resolve_party should not be gated — read ops are open to all"


# ─── Group 7: Service writes are never gated ───────────────────────────────


class TestServiceWritesNeverGated:
    """Service writes are governed by Party Roles, not the Superparty.

    The gate is intentionally Party-only.
    """

    def test_create_service_works_with_non_superparty_creds(self) -> None:
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>0</Code><Type>success</Type>"
                    "<Details>10.5239/AAAA-BBBB</Details>"
                    "</Status>"
                    "</Response>"
                ),
            )

        # Use a registry resolve handler for the follow-up GET that
        # the SDK does after a Status/Details response.
        def combined_handler(request: httpx.Request) -> httpx.Response:
            if request.method == "GET":
                return httpx.Response(
                    200,
                    text=(
                        '<Service xmlns="http://www.eidr.org/schema" '
                        'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
                        "<ID>10.5239/AAAA-BBBB</ID>"
                        "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                        "<Active>true</Active>"
                        "</Service>"
                    ),
                )
            return handler(request)

        service_xml = (
            b'<Service xmlns="http://www.eidr.org/schema" '
            b'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            b"<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
            b"<Active>true</Active>"
            b"</Service>"
        )
        record = ServiceRecord.from_xml(service_xml)

        with _make_client(combined_handler) as client:
            result = client.create_service(record)

        assert wire_reached
        assert result is not None


# ─── Group 8: AsyncClient mirror ───────────────────────────────────────────


class TestAsyncGateMirror:
    """Smoke tests confirming the async path enforces the same gate."""

    @pytest.mark.asyncio
    async def test_async_create_party_refused_for_non_superparty(self) -> None:
        client = _make_async_client(_no_wire_handler)
        async with client:
            with pytest.raises(EIDRSDKPolicyError) as exc_info:
                await client.create_party(_party_record(), "newpw")

        assert exc_info.value.policy == "superparty_required"
        assert exc_info.value.operation == "create_party"

    @pytest.mark.asyncio
    async def test_async_delete_party_refused_for_non_superparty(self) -> None:
        client = _make_async_client(_no_wire_handler)
        async with client:
            with pytest.raises(EIDRSDKPolicyError):
                await client.delete_party("10.5237/AAAA-BBBB")

    @pytest.mark.asyncio
    async def test_async_disabled_gate_lets_through(self) -> None:
        wire_reached: list[bool] = []

        def handler(request: httpx.Request) -> httpx.Response:
            wire_reached.append(True)
            return _success_handler(request)

        client = _make_async_client(handler, enforce_superparty_gate=False)
        async with client:
            await client.delete_party("10.5237/AAAA-BBBB")

        assert wire_reached
