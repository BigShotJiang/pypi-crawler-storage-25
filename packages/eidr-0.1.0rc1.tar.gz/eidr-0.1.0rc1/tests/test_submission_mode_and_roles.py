"""Tests for reviewer fixes: submission-mode-aware ID handling and
AllowedRoles vocabulary."""

from __future__ import annotations

import pytest

from eidr.errors import EIDRValidationError
from eidr.models import PartyRecord, ServiceRecord

PARTY_ID = "10.5237/7791-8534"
SERVICE_ID = "10.5239/7791-8534"

NS = ' xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _party_xml(*, with_id: bool = True) -> bytes:
    id_part = f"<ID>{PARTY_ID}</ID>" if with_id else ""
    return (
        f"<Party{NS}>"
        + id_part
        + "<PartyName><md:DisplayName>Acme Studios</md:DisplayName></PartyName>"
        + "<ContactInfo>"
        + "<Name>Jane Doe</Name>"
        + "<PrimaryEmail>jane@acme.example</PrimaryEmail>"
        + "</ContactInfo>"
        + "<Active>true</Active>"
        + "</Party>"
    ).encode()


def _service_xml(*, with_id: bool = True) -> bytes:
    id_part = f"<ID>{SERVICE_ID}</ID>" if with_id else ""
    return (
        f"<Service{NS}>"
        + id_part
        + "<ServiceName><md:DisplayName>Netflix</md:DisplayName></ServiceName>"
        + "<Active>true</Active>"
        + "</Service>"
    ).encode()


# ─────────────────────────────────────────────────────────────────────────────
# Submission-mode-aware ID handling
# ─────────────────────────────────────────────────────────────────────────────


class TestPartyCreateMode:
    """``mode="create"`` rejects a present ID and is happy with absence."""

    def test_create_with_id_rejected(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=True))
        report = rec.validate(mode="create")
        assert any(e.code == "party.id.unexpected" and e.path == "Party/ID" for e in report), (
            f"Create-mode with ID should be flagged; got {list(report)}"
        )

    def test_create_without_id_ok(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=False))
        report = rec.validate(mode="create")
        assert not any("ID" in (e.path or "") for e in report), (
            f"Create-mode without ID should pass; got {list(report)}"
        )


class TestPartyModifyMode:
    """``mode="modify"`` requires a present ID and validates its format."""

    def test_modify_without_id_rejected(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=False))
        report = rec.validate(mode="modify")
        assert any(
            e.code == "party.required_field.missing" and e.path == "Party/ID" for e in report
        ), f"Modify-mode without ID should be flagged; got {list(report)}"

    def test_modify_with_valid_id_ok(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=True))
        report = rec.validate(mode="modify")
        assert not any("ID" in (e.path or "") for e in report), (
            f"Modify-mode with valid ID should pass; got {list(report)}"
        )

    def test_modify_strict_raises_when_id_absent(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=False))
        with pytest.raises(EIDRValidationError):
            rec.validate_strict(mode="modify")


class TestPartyNullMode:
    """``mode=None`` (default) validates ID format only when present."""

    def test_null_mode_with_id_ok(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=True))
        report = rec.validate()
        assert not any("ID" in (e.path or "") for e in report)

    def test_null_mode_without_id_ok(self) -> None:
        rec = PartyRecord.from_xml(_party_xml(with_id=False))
        report = rec.validate()
        assert not any(
            e.code in ("party.id.unexpected", "party.required_field.missing")
            and e.path == "Party/ID"
            for e in report
        )


class TestServiceCreateModifyMode:
    """Service parallels Party — same registry behavior."""

    def test_service_create_with_id_rejected(self) -> None:
        rec = ServiceRecord.from_xml(_service_xml(with_id=True))
        report = rec.validate(mode="create")
        assert any(e.code == "service.id.unexpected" and e.path == "Service/ID" for e in report)

    def test_service_modify_without_id_rejected(self) -> None:
        rec = ServiceRecord.from_xml(_service_xml(with_id=False))
        report = rec.validate(mode="modify")
        assert any(
            e.code == "service.required_field.missing" and e.path == "Service/ID" for e in report
        )


# ─────────────────────────────────────────────────────────────────────────────
# AllowedRoles vocabulary
# ─────────────────────────────────────────────────────────────────────────────


class TestAllowedRolesVocabulary:
    """Party AllowedRoles must come from the 8-value administratorTypeType enum."""

    VALID_ROLES = (
        "AssociatedOrg",
        "Registrant",
        "MetadataAuthority",
        "EncodingAgent",
        "Writer",
        "Reader",
        "ServiceAdmin",
        "AltIDWriter",
    )

    @pytest.mark.parametrize("role", VALID_ROLES)
    def test_valid_role_accepted(self, role: str) -> None:
        xml = (
            f"<Party{NS}>"
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
            f"<AllowedRoles>{role}</AllowedRoles>"
            "</Party>"
        ).encode()
        rec = PartyRecord.from_xml(xml)
        report = rec.validate()
        assert not any(e.code == "party.vocabulary.invalid" for e in report), (
            f"{role!r} should be a valid AllowedRoles value"
        )

    def test_invalid_role_rejected(self) -> None:
        xml = (
            f"<Party{NS}>"
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
            "<AllowedRoles>Superuser</AllowedRoles>"
            "</Party>"
        ).encode()
        rec = PartyRecord.from_xml(xml)
        report = rec.validate()
        vocab = [e for e in report if e.code == "party.vocabulary.invalid"]
        assert len(vocab) == 1
        assert vocab[0].value == "Superuser"

    def test_multiple_roles_partial_invalid(self) -> None:
        xml = (
            f"<Party{NS}>"
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
            "<AllowedRoles>Registrant</AllowedRoles>"
            "<AllowedRoles>WrongRole</AllowedRoles>"
            "<AllowedRoles>MetadataAuthority</AllowedRoles>"
            "</Party>"
        ).encode()
        rec = PartyRecord.from_xml(xml)
        report = rec.validate()
        bad = [e for e in report if e.code == "party.vocabulary.invalid"]
        assert len(bad) == 1
        assert bad[0].value == "WrongRole"
