"""Async query/graph-traversal tests — mirror of ``test_client_queries.py``.

Uses the same helper patterns as ``test_async_client_writes.py``
for MockTransport + AsyncClient construction.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

import httpx
import pytest

from eidr.client import AsyncClient, GraphTraversalType, QueryResults
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test",
)

READONLY = Registry(
    name="RO",
    url="https://ro.example/EIDR",
    writable=False,
    description="Read-only",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _query_envelope(
    *,
    current_size: int,
    total_matches: int,
    items_xml: str = "",
    continuation_token: str | None = None,
) -> str:
    cont = (
        f"<ContinuationToken>{continuation_token}</ContinuationToken>" if continuation_token else ""
    )
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<QueryResults>"
        f"<CurrentSize>{current_size}</CurrentSize>"
        f"<TotalMatches>{total_matches}</TotalMatches>"
        f"{cont}"
        f"{items_xml}"
        "</QueryResults>"
        "</Response>"
    )


def _simple_metadata_item(eidr_id: str, name: str) -> str:
    return (
        "<SimpleMetadata>"
        f"<ID>{eidr_id}</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        f"<ResourceName>{name}</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</SimpleMetadata>"
    )


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
) -> AsyncClient:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(registry, CREDS, transport_config=config)


# ─── Client.query() ─────────────────────────────────────────────────────────


class TestAsyncQuery:
    async def test_posts_to_query_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=_query_envelope(current_size=0, total_matches=0),
            )

        async with make_client(handler) as client:
            qr = await client.query("/FullMetadata/BaseObjectData/Status valid")

        assert captured["url"] == "https://test.example/EIDR/query/"
        body = cast(str, captured["body"])
        assert "<Query>" in body
        assert isinstance(qr, QueryResults)

    async def test_id_only_adds_type_param(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(
                200,
                text=_query_envelope(
                    current_size=1,
                    total_matches=1,
                    items_xml="<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>",
                ),
            )

        async with make_client(handler) as client:
            qr = await client.query("foo", id_only=True)

        assert "?type=ID" in cast(str, captured["url"])
        assert qr.ids == ["10.5240/0000-02ED-1DCE-6AAF-99F7-M"]

    async def test_pagination_params_passed_through(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_query_envelope(current_size=25, total_matches=100))

        async with make_client(handler) as client:
            qr = await client.query("foo", page_number=3, page_size=50)

        body = cast(str, captured["body"])
        assert "<PageNumber>3</PageNumber>" in body
        assert "<PageSize>50</PageSize>" in body
        # Page context preserved on result.
        assert qr.page_number == 3
        assert qr.page_size == 50

    async def test_records_parsed_from_simple_metadata(self) -> None:
        item = _simple_metadata_item("10.5240/0000-02ED-1DCE-6AAF-99F7-M", "A Movie")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_query_envelope(current_size=1, total_matches=1, items_xml=item),
            )

        async with make_client(handler) as client:
            qr = await client.query("foo")
        assert len(qr.records) == 1
        assert qr.records[0].resource_name == "A Movie"

    async def test_works_against_readonly_registry(self) -> None:
        """Query is a semantic read that happens to use POST — it must
        work against a writable=False registry."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        async with make_client(handler, registry=READONLY) as client:
            qr = await client.query("foo")
        assert qr.current_size == 0


# ─── Client.graph_traversal() ───────────────────────────────────────────────


class TestAsyncGraphTraversal:
    async def test_find_ancestors_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        async with make_client(handler) as client:
            await client.graph_traversal(GraphTraversalType.FIND_ANCESTORS, "10.5240/X")

        assert captured["url"] == "https://test.example/EIDR/object/graph/"
        body = cast(str, captured["body"])
        assert "<FindAncestors>" in body
        assert "<ID>10.5240/X</ID>" in body

    async def test_filters_appear_in_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        async with make_client(handler) as client:
            await client.graph_traversal(
                GraphTraversalType.FIND_DESCENDANTS,
                "10.5240/X",
                referent_type_filter="Movie",
                structural_type_filter="Performance",
            )

        body = cast(str, captured["body"])
        assert "<ReferentTypeFilter>Movie</ReferentTypeFilter>" in body
        assert "<StructuralTypeFilter>Performance</StructuralTypeFilter>" in body

    async def test_all_nine_operations_send_correct_tag(self) -> None:
        captured: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(request.content.decode("utf-8"))
            return httpx.Response(200, text=_query_envelope(current_size=0, total_matches=0))

        async with make_client(handler) as client:
            for op in GraphTraversalType:
                await client.graph_traversal(op, "10.5240/X")

        for op, body in zip(GraphTraversalType, captured, strict=True):
            assert f"<{op.value}>" in body
            assert f"</{op.value}>" in body


# ─── party_query / service_query ────────────────────────────────────────────


class TestAsyncRawQueries:
    async def test_party_query_posts_raw(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
                ),
            )

        query_xml = (
            '<FindPartiesByName xmlns="http://www.eidr.org/schema"><n>Acme</n></FindPartiesByName>'
        )
        async with make_client(handler) as client:
            parsed = await client.party_query(query_xml)

        assert captured["url"] == "https://test.example/EIDR/party/query/"
        body = cast(str, captured["body"])
        # Raw payload — no Request/Operation wrapper.
        assert "<FindPartiesByName" in body
        assert "<Request " not in body
        assert parsed.status_code == 0

    async def test_service_query_posts_raw(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
                ),
            )

        query_xml = (
            '<FindServicesByName xmlns="http://www.eidr.org/schema"><n>X</n></FindServicesByName>'
        )
        async with make_client(handler) as client:
            parsed = await client.service_query(query_xml)

        assert captured["url"] == "https://test.example/EIDR/service/query/"
        assert "<Request " not in cast(str, captured["body"])
        assert parsed.status_code == 0

    async def test_party_query_rejects_empty(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match="empty"):
                await client.party_query("")

    async def test_service_query_rejects_empty(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match="empty"):
                await client.service_query("   ")
