"""Tests for :func:`eidr.models.normalize_whitespace` and the
``max_errors`` cap on :class:`ValidationReport`."""

from __future__ import annotations

from eidr.codecs._rules import ATTR_PREFIX, TEXT_KEY
from eidr.models import (
    ContentRecord,
    ValidationError,
    ValidationReport,
    find_empty_tags,
    normalize_whitespace,
    strip_empty_tags,
)

CONTENT_ID = "10.5240/7791-8534-2C23-9030-8610-5"
REGISTRANT_ID = "10.5237/7791-8534"

NS = (
    ' xmlns="http://www.eidr.org/schema"'
    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
)


def _valid_base() -> str:
    return (
        f"<ID>{CONTENT_ID}</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>X</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# normalize_whitespace — text content (xs:string semantics)
# ─────────────────────────────────────────────────────────────────────────────


class TestNormalizeTextContent:
    def test_strips_leading_and_trailing(self) -> None:
        d = {"ResourceName": "  The Matrix  "}
        normalize_whitespace(d)
        assert d["ResourceName"] == "The Matrix"

    def test_collapses_internal_runs(self) -> None:
        d = {"ResourceName": "The    Matrix"}
        normalize_whitespace(d)
        assert d["ResourceName"] == "The Matrix"

    def test_collapses_mixed_whitespace(self) -> None:
        # Tabs, newlines, and multiple spaces all collapse to a single space
        d = {"Description": "Line one\n\tand line two\t\nstill going"}
        normalize_whitespace(d)
        assert d["Description"] == "Line one and line two still going"

    def test_whitespace_only_becomes_empty(self) -> None:
        # xs:string normalization turns whitespace-only into empty string
        d = {"Note": "   \t\n  "}
        normalize_whitespace(d)
        assert d["Note"] == ""

    def test_preserves_single_spaces(self) -> None:
        d = {"ResourceName": "The Matrix Reloaded"}
        normalize_whitespace(d)
        assert d["ResourceName"] == "The Matrix Reloaded"

    def test_idempotent(self) -> None:
        d = {"ResourceName": "  The    Matrix  "}
        normalize_whitespace(d)
        first = d["ResourceName"]
        normalize_whitespace(d)
        assert d["ResourceName"] == first


# ─────────────────────────────────────────────────────────────────────────────
# normalize_whitespace — attribute values (xs:token semantics)
# ─────────────────────────────────────────────────────────────────────────────


class TestNormalizeAttributeValues:
    def test_strips_leading_trailing(self) -> None:
        d = {f"{ATTR_PREFIX}lang": "  en  "}
        normalize_whitespace(d)
        assert d[f"{ATTR_PREFIX}lang"] == "en"

    def test_collapses_internal_whitespace_in_attributes(self) -> None:
        # xs:token collapses internal runs and strips edges.
        # (Previously the library preserved internal whitespace for
        # attributes; the registry actually collapses it, so we now
        # match the registry's behavior.)
        d = {f"{ATTR_PREFIX}domain": "  http://example.com/foo   bar  "}
        normalize_whitespace(d)
        assert d[f"{ATTR_PREFIX}domain"] == "http://example.com/foo bar"

    def test_namespace_declarations_also_trimmed(self) -> None:
        # _xmlns is still an attribute key — leading/trailing whitespace
        # would be exotic but we strip it consistently.
        d = {f"{ATTR_PREFIX}xmlns": "  http://www.eidr.org/schema  "}
        normalize_whitespace(d)
        assert d[f"{ATTR_PREFIX}xmlns"] == "http://www.eidr.org/schema"


# ─────────────────────────────────────────────────────────────────────────────
# normalize_whitespace — nested structures
# ─────────────────────────────────────────────────────────────────────────────


class TestNormalizeNested:
    def test_nested_dict_descended(self) -> None:
        d = {
            "BaseObjectData": {
                "ResourceName": "  The   Matrix  ",
                "Description": "A film",
            }
        }
        normalize_whitespace(d)
        bod = d["BaseObjectData"]
        assert isinstance(bod, dict)
        assert bod["ResourceName"] == "The Matrix"
        assert bod["Description"] == "A film"

    def test_list_entries_normalized(self) -> None:
        d = {
            "AlternateID": [
                "  id-one  ",
                "id-two",
                "  id three with   spaces  ",
            ]
        }
        normalize_whitespace(d)
        assert d["AlternateID"] == ["id-one", "id-two", "id three with spaces"]

    def test_text_with_attrs_shape(self) -> None:
        # The {"value": text, "_attr": ...} shape
        d = {
            "ResourceName": {
                TEXT_KEY: "   The  Matrix   ",
                f"{ATTR_PREFIX}lang": "  en  ",
            }
        }
        normalize_whitespace(d)
        rn = d["ResourceName"]
        assert isinstance(rn, dict)
        assert rn[TEXT_KEY] == "The Matrix"
        assert rn[f"{ATTR_PREFIX}lang"] == "en"


# ─────────────────────────────────────────────────────────────────────────────
# normalize + strip pipeline
# ─────────────────────────────────────────────────────────────────────────────


class TestNormalizeAndStripPipeline:
    def test_whitespace_only_content_becomes_empty_then_stripped(self) -> None:
        # The canonical pre-submit workflow: normalize first, then strip.
        # A field with only whitespace collapses to "", then the strip
        # pass removes the empty tag.
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + _valid_base()
            + "<Description>   \t   </Description>"
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        normalize_whitespace(rec.data)
        strip_empty_tags(rec.data)
        # Description is gone from the submitted record, not sitting
        # there empty
        bod = rec.data["FullMetadata"]["BaseObjectData"]
        assert "Description" not in bod
        # And there are no empty tags left
        assert find_empty_tags(rec.data) == []

    def test_real_content_survives_pipeline(self) -> None:
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + _valid_base()
            + "<Description>  A great   movie.  </Description>"
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        normalize_whitespace(rec.data)
        strip_empty_tags(rec.data)
        assert rec.description == "A great movie."


# ─────────────────────────────────────────────────────────────────────────────
# max_errors cap on ValidationReport
# ─────────────────────────────────────────────────────────────────────────────


class TestMaxErrorsCap:
    def test_default_cap_is_50(self) -> None:
        report = ValidationReport()
        assert report.max_errors == 50

    def test_cap_stops_collection(self) -> None:
        report = ValidationReport(max_errors=3)
        for i in range(10):
            report.add(code=f"test.{i}", message=f"error {i}")
        # Total entries <= max_errors. With max_errors=3 and many errors,
        # we get 2 real + 1 sentinel = 3 total.
        assert len(report) == 3
        assert report.errors[-1].code == "validation.truncated"

    def test_sentinel_appears_exactly_once(self) -> None:
        report = ValidationReport(max_errors=2)
        for _ in range(50):
            report.add(code="x", message="x")
        truncated = [e for e in report if e.code == "validation.truncated"]
        assert len(truncated) == 1

    def test_below_cap_no_sentinel(self) -> None:
        report = ValidationReport(max_errors=10)
        for i in range(5):
            report.add(code=f"test.{i}", message=f"error {i}")
        assert not any(e.code == "validation.truncated" for e in report)
        assert len(report) == 5

    def test_cap_exactly_reached_no_sentinel(self) -> None:
        # Adding max_errors-1 real errors should not trigger truncation
        # and should leave room for more. Adding the max_errors-th entry
        # does trigger truncation (that entry becomes the sentinel).
        report = ValidationReport(max_errors=3)
        report.add(code="a", message="a")
        report.add(code="b", message="b")
        assert len(report) == 2
        assert not any(e.code == "validation.truncated" for e in report)
        # The 3rd add hits the cap — becomes the sentinel, not the real error
        report.add(code="c", message="c")
        assert len(report) == 3
        assert report.errors[-1].code == "validation.truncated"

    def test_max_errors_one_is_fail_fast(self) -> None:
        # max_errors=1 gives the first real error, no sentinel —
        # same shape as the registry's fail-fast behavior.
        report = ValidationReport(max_errors=1)
        report.add(code="first", message="first error")
        report.add(code="second", message="second error")
        assert len(report) == 1
        assert report.errors[0].code == "first"

    def test_max_errors_zero_rejected(self) -> None:
        import pytest

        with pytest.raises(ValueError, match="max_errors must be >= 1"):
            ValidationReport(max_errors=0)

    def test_max_errors_negative_rejected(self) -> None:
        import pytest

        with pytest.raises(ValueError, match="max_errors must be >= 1"):
            ValidationReport(max_errors=-5)

    def test_extend_honors_cap(self) -> None:
        big = ValidationReport(max_errors=100)
        for i in range(10):
            big.add(code=f"big.{i}", message="x")

        small = ValidationReport(max_errors=3)
        small.extend(big)
        # 2 real + 1 sentinel = 3 total
        assert len(small) == 3
        assert small.errors[-1].code == "validation.truncated"

    def test_truncation_flag_set(self) -> None:
        # With max_errors=1 (fail-fast), the flag is set as soon as
        # the slot is full — that is, after the first successful add.
        # Subsequent adds are dropped.
        report = ValidationReport(max_errors=1)
        report.add(code="a", message="a")
        assert report.truncated
        assert len(report) == 1

        # With max_errors>1, the flag isn't set until the sentinel
        # would replace a real error
        report2 = ValidationReport(max_errors=3)
        report2.add(code="a", message="a")
        assert not report2.truncated
        report2.add(code="b", message="b")
        assert not report2.truncated
        # Third add triggers the sentinel
        report2.add(code="c", message="c")
        assert report2.truncated

    def test_further_adds_after_truncation_are_noop(self) -> None:
        report = ValidationReport(max_errors=1)
        report.add(code="a", message="a")
        report.add(code="b", message="b")  # triggers truncation sentinel
        length_after_trunc = len(report)
        report.add(code="c", message="c")
        report.add(code="d", message="d")
        assert len(report) == length_after_trunc  # unchanged


class TestMaxErrorsThreading:
    """The cap must actually flow through record.validate()."""

    def test_content_validate_passes_max_errors(self) -> None:
        # Build a record with several errors — missing just about everything
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + "<ReferentType>BogusType</ReferentType>"  # vocabulary error
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)

        # Default cap should let all of these through (few errors expected)
        default_report = rec.validate()
        assert not default_report.truncated

        # Cap of 1 is fail-fast: the first real error, no sentinel
        capped = rec.validate(max_errors=1)
        assert capped.truncated
        assert len(capped) == 1
        assert capped.errors[0].code != "validation.truncated"

    def test_content_validate_high_cap_sees_everything(self) -> None:
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + "<ReferentType>Bogus</ReferentType>"
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        report = rec.validate(max_errors=10_000)
        assert not report.truncated


# ─────────────────────────────────────────────────────────────────────────────
# Type re-exports sanity checks
# ─────────────────────────────────────────────────────────────────────────────


class TestPublicExports:
    def test_normalize_whitespace_is_public(self) -> None:
        from eidr.models import normalize_whitespace as nw

        assert nw is normalize_whitespace

    def test_validation_types_importable(self) -> None:
        # Just confirm the public names stay put
        assert ValidationReport is not None
        assert ValidationError is not None
