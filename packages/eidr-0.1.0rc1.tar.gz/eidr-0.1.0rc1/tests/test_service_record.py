"""Tests for :class:`eidr.models.service.ServiceRecord`."""

from __future__ import annotations

import pytest

from eidr.errors import EIDRClientError
from eidr.models import OrgName, ServiceRecord
from eidr.models.ids import EIDRID

# Synthetic EIDR Service IDs (shape-valid for construction; real
# Service IDs would have valid check characters)
SERVICE_ID = "10.5239/7791-8534"
PARENT_SERVICE_ID = "10.5239/8534-7791"

NS_ATTRS = (
    ' xmlns="http://www.eidr.org/schema"'
    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
)


def _wrap(inner: str) -> bytes:
    return f"<Service{NS_ATTRS}>{inner}</Service>".encode()


class TestServiceRecordConstruction:
    def test_rejects_non_dict(self) -> None:
        with pytest.raises(EIDRClientError, match="requires a dict"):
            ServiceRecord("not a dict")  # type: ignore[arg-type]

    def test_minimal_record(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName>"
                "<md:DisplayName>Netflix</md:DisplayName>"
                "</ServiceName>"
                "<Active>true</Active>"
            )
        )
        assert rec.active is True


class TestServiceAccessors:
    def test_service_name(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>HBO Max</md:DisplayName></ServiceName>"
                "<Active>true</Active>"
            )
        )
        name = rec.service_name
        assert isinstance(name, OrgName)
        assert name.display_name == "HBO Max"

    def test_service_name_abbreviation_flag(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                '<ServiceName abbreviation="true">'
                "<md:DisplayName>NBC</md:DisplayName>"
                "</ServiceName>"
                "<Active>true</Active>"
            )
        )
        assert rec.service_name_is_abbreviation is True

    def test_service_name_abbreviation_flag_false_by_default(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName>"
                "<md:DisplayName>National Broadcasting Co.</md:DisplayName>"
                "</ServiceName>"
                "<Active>true</Active>"
            )
        )
        assert rec.service_name_is_abbreviation is False

    def test_alternate_service_names(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                "<AlternateServiceName>Xtra</AlternateServiceName>"
                "<AlternateServiceName>X Channel</AlternateServiceName>"
                "<Active>true</Active>"
            )
        )
        assert rec.alternate_service_names == ["Xtra", "X Channel"]

    def test_alternate_ids(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                '<AlternateID type="gracenote" domain="http://gracenote.com">GN-12345</AlternateID>'
                "<Active>true</Active>"
            )
        )
        assert len(rec.alternate_ids) == 1
        assert rec.alternate_ids[0].value == "GN-12345"
        assert rec.alternate_ids[0].type == "gracenote"

    def test_description(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                "<Description>A streaming video service.</Description>"
                "<Active>true</Active>"
            )
        )
        assert rec.description == "A streaming video service."

    def test_parent_service_id(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>HBO Max</md:DisplayName></ServiceName>"
                f"<Parent>{PARENT_SERVICE_ID}</Parent>"
                "<Active>true</Active>"
            )
        )
        assert isinstance(rec.parent, EIDRID)
        assert str(rec.parent) == PARENT_SERVICE_ID

    def test_parent_absent(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                "<Active>true</Active>"
            )
        )
        assert rec.parent is None

    def test_other_affiliations(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                f"<OtherAffiliation>{PARENT_SERVICE_ID}</OtherAffiliation>"
                "<Active>true</Active>"
            )
        )
        assert rec.other_affiliations == [PARENT_SERVICE_ID]

    def test_descriptive_fields(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
                "<Active>true</Active>"
                "<PrimaryTimeZone>America/Los_Angeles</PrimaryTimeZone>"
                "<Region>Los Angeles DMA</Region>"
                "<PrimaryAudioLanguage>en-US</PrimaryAudioLanguage>"
                "<DeliveryModel>Linear</DeliveryModel>"
                "<DeliveryModel>VOD</DeliveryModel>"
            )
        )
        assert rec.primary_time_zone == "America/Los_Angeles"
        assert rec.region == "Los Angeles DMA"
        assert rec.primary_audio_language == "en-US"
        assert rec.delivery_models == ["Linear", "VOD"]


class TestServiceRoundTrip:
    def _xml(self) -> bytes:
        return _wrap(
            f"<ID>{SERVICE_ID}</ID>"
            '<ServiceName abbreviation="false">'
            "<md:DisplayName>Hulu</md:DisplayName>"
            "</ServiceName>"
            "<AlternateServiceName>Hulu Plus</AlternateServiceName>"
            "<Description>A streaming video service.</Description>"
            f"<Parent>{PARENT_SERVICE_ID}</Parent>"
            "<Active>true</Active>"
            "<PrimaryTimeZone>America/Los_Angeles</PrimaryTimeZone>"
            "<Region>USA</Region>"
            "<PrimaryAudioLanguage>en-US</PrimaryAudioLanguage>"
            "<DeliveryModel>Linear</DeliveryModel>"
            "<DeliveryModel>VOD</DeliveryModel>"
        )

    def test_xml_roundtrip(self) -> None:
        rec = ServiceRecord.from_xml(self._xml())
        rec2 = ServiceRecord.from_xml(rec.to_xml(xml_declaration=False))
        assert rec.data == rec2.data

    def test_json_roundtrip(self) -> None:
        rec = ServiceRecord.from_xml(self._xml())
        rec2 = ServiceRecord.from_json(rec.to_json())
        assert rec.data == rec2.data

    def test_canonical_byte_stable(self) -> None:
        rec = ServiceRecord.from_xml(self._xml())
        assert rec.to_xml_canonical() == rec.to_xml_canonical()
        assert rec.to_json_canonical() == rec.to_json_canonical()

    def test_accessors_after_roundtrip(self) -> None:
        rec = ServiceRecord.from_xml(self._xml())
        rec2 = ServiceRecord.from_xml(rec.to_xml(xml_declaration=False))
        assert rec.service_name == rec2.service_name
        assert rec.parent == rec2.parent
        assert rec.delivery_models == rec2.delivery_models
