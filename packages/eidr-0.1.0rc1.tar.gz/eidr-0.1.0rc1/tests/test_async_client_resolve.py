"""Tests for :class:`eidr.client.AsyncClient` — resolve, status_lookup,
lifecycle. Mirrors the sync ``test_client_resolve.py`` plus context
manager verification.

Uses :class:`httpx.MockTransport` to simulate the registry. The
mock transport works identically with :class:`httpx.AsyncClient` —
the handler callback stays synchronous (the MockTransport bridges
sync callbacks to async calls internally).
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import AsyncClient
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.errors import (
    EIDRAuthenticationError,
    EIDRProtocolError,
)
from eidr.models.content import ContentRecord
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test",
)

READONLY = Registry(
    name="RO",
    url="https://ro.example/EIDR",
    writable=False,
    description="Read-only",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

NS_ATTRS = (
    ' xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
)


def _content_body() -> str:
    return (
        f"<FullMetadata{NS_ATTRS}>"
        "<BaseObjectData>"
        "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


def _party_body() -> str:
    return (
        f"<Party{NS_ATTRS}>"
        "<ID>10.5237/FFDA-9947</ID>"
        "<Name>Test Party</Name>"
        "<PartyType>Organization</PartyType>"
        "<Status>Active</Status>"
        "</Party>"
    )


def _service_body() -> str:
    return (
        f"<Service{NS_ATTRS}>"
        "<ID>10.5239/AAAA-BBBB</ID>"
        "<ProviderName>Test</ProviderName>"
        "<Platform>Web</Platform>"
        "<RegionCoverage>US</RegionCoverage>"
        "<Status>Active</Status>"
        "</Service>"
    )


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
) -> AsyncClient:
    """Build an AsyncClient whose transport is a MockTransport using ``handler``.

    The handler is synchronous — httpx's MockTransport bridges this
    to the async client's awaits internally.
    """
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(registry, CREDS, transport_config=config)


# ─────────────────────────────────────────────────────────────────────────────
# Context manager lifecycle
# ─────────────────────────────────────────────────────────────────────────────


class TestAsyncClientLifecycle:
    """``async with AsyncClient(...)`` properly opens and closes."""

    async def test_context_manager_yields_self(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_content_body())

        async with make_client(handler) as client:
            assert isinstance(client, AsyncClient)
            # Registry property is accessible and correct
            assert client.registry is REGISTRY

    async def test_aclose_closes_httpx(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_content_body())

        client = make_client(handler)
        await client.aclose()
        # After close, the underlying client's closed state is set
        assert client._transport._httpx.is_closed


# ─────────────────────────────────────────────────────────────────────────────
# resolve
# ─────────────────────────────────────────────────────────────────────────────


class TestAsyncResolve:
    async def test_resolve_content(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=_content_body())

        async with make_client(handler) as client:
            record = await client.resolve("10.5240/0000-02ED-1DCE-6AAF-99F7-M")

        assert captured["method"] == "GET"
        assert "/object/10.5240/0000-02ED-1DCE-6AAF-99F7-M" in str(captured["url"])
        assert isinstance(record, ContentRecord)
        assert record.resource_name == "Test"

    async def test_resolve_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_party_body())

        async with make_client(handler) as client:
            record = await client.resolve("10.5237/FFDA-9947")

        assert "/party/resolve/10.5237/FFDA-9947" in str(captured["url"])
        assert isinstance(record, PartyRecord)

    async def test_resolve_service(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_service_body())

        async with make_client(handler) as client:
            record = await client.resolve("10.5239/AAAA-BBBB")

        assert "/service/resolve/10.5239/AAAA-BBBB" in str(captured["url"])
        assert isinstance(record, ServiceRecord)

    async def test_resolve_passes_type_parameter(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        async with make_client(handler) as client:
            await client.resolve("10.5240/foo", resolution_type="Self")

        assert "type=Self" in str(captured["url"])

    async def test_resolve_combines_params(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        async with make_client(handler) as client:
            await client.resolve(
                "10.5240/foo",
                resolution_type="Provenance",
                follow_alias=False,
            )
        url = str(captured["url"])
        assert "type=Provenance" in url
        assert "followAlias=false" in url

    async def test_resolve_default_no_params(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        async with make_client(handler) as client:
            await client.resolve("10.5240/foo")

        assert "?" not in str(captured["url"])

    async def test_resolve_auth_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response{NS_ATTRS}>"
                    "<Status><Code>4</Code><Type>authentication error</Type></Status>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            with pytest.raises(EIDRAuthenticationError):
                await client.resolve("10.5240/foo")

    async def test_resolve_envelope_response_raises_protocol(self) -> None:
        """Receiving an envelope where a record was expected is a protocol bug."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response{NS_ATTRS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<Token>unexpected-token</Token>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            with pytest.raises(EIDRProtocolError, match="record response"):
                await client.resolve("10.5240/foo")


# ─────────────────────────────────────────────────────────────────────────────
# status_lookup
# ─────────────────────────────────────────────────────────────────────────────


class TestAsyncStatusLookup:
    async def test_status_lookup_gets_token_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(
                200,
                text=(
                    f"<Response{NS_ATTRS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            parsed = await client.status_lookup("my-token-abc")

        assert str(captured["url"]).endswith("/status/my-token-abc")
        assert parsed.status_code == 0

    async def test_status_lookup_rejects_empty_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match="non-empty"):
                await client.status_lookup("")


# ─── aclose idempotence ─────────────────────────────────────────────────────


class TestAsyncCloseIdempotence:
    """``AsyncClient.aclose()`` is safe to call more than once.

    Matches :meth:`Client.close`'s contract. Double-close is a real
    scenario — an explicit ``aclose`` inside an ``async with`` block,
    a teardown helper that closes a client the owner already closed,
    or shared-context patterns where ownership is ambiguous. Forcing
    callers to track close-count for no safety benefit would be
    user-hostile.
    """

    async def test_aclose_called_twice_is_safe(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        client = make_client(handler)
        await client.aclose()
        await client.aclose()  # No exception
        # Underlying httpx client is still closed
        assert client._transport._httpx.is_closed
        assert client._transport._closed is True

    async def test_aclose_after_async_with_is_safe(self) -> None:
        """``async with`` calls aclose on exit; an explicit aclose
        afterwards must not raise."""

        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        client = make_client(handler)
        async with client:
            pass
        # Exit ran aclose; this second call is idempotent.
        await client.aclose()

    async def test_aclose_called_three_times(self) -> None:
        """Belt-and-suspenders: more than two calls is also safe."""

        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        client = make_client(handler)
        await client.aclose()
        await client.aclose()
        await client.aclose()
