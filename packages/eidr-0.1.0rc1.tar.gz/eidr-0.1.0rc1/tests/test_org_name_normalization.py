"""Tests for ``md:`` namespace normalization on Service / Party records.

The MovieLabs MD-v2.8 schema requires elements like ``DisplayName``,
``SortName``, and ``AlternateName`` (inside ``ServiceName`` /
``PartyName``) to be in the MovieLabs MD namespace. The codec layer
preserves whatever shape was parsed; without normalization, a
bare-namespaced input would round-trip back to the registry as
schema-invalid bytes.

Regression for the M9 review-pass live-test failure:

    cvc-complex-type.2.4.a: Invalid content was found starting with
    element 'DisplayName'. One of
    '{"http://www.movielabs.com/schema/md/v2.8/md":DisplayName}'
    is expected.
"""

from __future__ import annotations

from eidr.models._org_name_norm import (
    ensure_md_namespace_declared,
    normalize_org_name_block,
)
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord


class TestNormalizeOrgNameBlock:
    """Tests for the ``normalize_org_name_block()`` helper directly."""

    def test_bare_displayname_becomes_md_prefixed(self) -> None:
        block = {"DisplayName": "Foo"}
        out = normalize_org_name_block(block)
        assert out == {"md:DisplayName": "Foo"}

    def test_already_prefixed_passes_through(self) -> None:
        block = {"md:DisplayName": "Foo"}
        out = normalize_org_name_block(block)
        assert out == {"md:DisplayName": "Foo"}

    def test_idempotent_on_normalized_input(self) -> None:
        block = {"md:DisplayName": "Foo", "md:SortName": "Foo"}
        once = normalize_org_name_block(block)
        twice = normalize_org_name_block(once)
        assert once == twice

    def test_preserves_attributes(self) -> None:
        # Attribute keys are prefixed with @ in the codec
        block = {"@organizationID": "urn:dun:123", "DisplayName": "Foo"}
        out = normalize_org_name_block(block)
        assert out == {"@organizationID": "urn:dun:123", "md:DisplayName": "Foo"}

    def test_handles_all_three_md_fields(self) -> None:
        block = {
            "DisplayName": "Foo",
            "SortName": "Foo Inc",
            "AlternateName": ["FooCorp", "F"],
        }
        out = normalize_org_name_block(block)
        assert out == {
            "md:DisplayName": "Foo",
            "md:SortName": "Foo Inc",
            "md:AlternateName": ["FooCorp", "F"],
        }

    def test_mixed_prefixed_and_unprefixed(self) -> None:
        # Mixed input — prefixed survives, bare gets prefixed
        block = {"md:DisplayName": "Foo", "SortName": "Foo Inc"}
        out = normalize_org_name_block(block)
        assert out == {"md:DisplayName": "Foo", "md:SortName": "Foo Inc"}

    def test_passes_through_non_dict(self) -> None:
        # Defensive: if a scalar slips in, just return it
        assert normalize_org_name_block("scalar") == "scalar"
        assert normalize_org_name_block(None) is None


class TestEnsureMdNamespaceDeclared:
    """Tests for the ``ensure_md_namespace_declared()`` helper."""

    def test_adds_declaration_when_absent(self) -> None:
        root: dict = {"ServiceName": {"md:DisplayName": "Foo"}}
        ensure_md_namespace_declared(root)
        # Codec layer uses "_" as the attribute-key prefix
        assert root["_xmlns:md"] == "http://www.movielabs.com/schema/md/v2.8/md"

    def test_idempotent_when_present(self) -> None:
        root = {
            "_xmlns:md": "http://www.movielabs.com/schema/md/v2.8/md",
            "ServiceName": {"md:DisplayName": "Foo"},
        }
        ensure_md_namespace_declared(root)
        # Still exactly one declaration with the right URI
        assert root["_xmlns:md"] == "http://www.movielabs.com/schema/md/v2.8/md"

    def test_preserves_existing_keys(self) -> None:
        root = {"ID": "10.5239/AAAA-BBBB", "Active": "true"}
        ensure_md_namespace_declared(root)
        assert root["ID"] == "10.5239/AAAA-BBBB"
        assert root["Active"] == "true"


class TestServiceRecordNormalization:
    """End-to-end: ServiceRecord round-trip emits schema-valid XML."""

    def test_bare_namespaced_input_emits_md_prefixed_output(self) -> None:
        """The M9 review-pass live-test failure shape: input has
        bare ``<DisplayName>`` (in EIDR namespace, no ``md:``
        prefix). After parse + serialize, output should be in
        the MovieLabs MD namespace.
        """
        xml = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b'<Service xmlns="http://www.eidr.org/schema">'
            b"<ServiceName>"
            b"<DisplayName>Test Service</DisplayName>"
            b"<SortName>Test Service</SortName>"
            b"</ServiceName>"
            b"<Active>true</Active>"
            b"</Service>"
        )
        record = ServiceRecord.from_xml(xml)
        out = record.to_xml().decode()
        # md namespace declared at root
        assert 'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"' in out
        # Children use the md: prefix
        assert "<md:DisplayName>" in out
        assert "<md:SortName>" in out
        # Bare-namespaced elements are gone
        assert "<DisplayName>" not in out
        assert "<SortName>" not in out

    def test_already_correct_input_is_idempotent(self) -> None:
        """Input that is already schema-correct must round-trip
        unchanged (modulo whitespace and attribute ordering)."""
        xml = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b'<Service xmlns="http://www.eidr.org/schema"'
            b' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            b"<ServiceName>"
            b"<md:DisplayName>FOX Sports on Tubi</md:DisplayName>"
            b"</ServiceName>"
            b"<Active>true</Active>"
            b"</Service>"
        )
        record = ServiceRecord.from_xml(xml)
        out = record.to_xml().decode()
        assert "<md:DisplayName>FOX Sports on Tubi</md:DisplayName>" in out
        # No corruption introduced (no double-prefix, no stray bare element)
        assert "md:md:" not in out


class TestPartyRecordNormalization:
    """End-to-end: PartyRecord round-trip emits schema-valid XML."""

    def test_bare_namespaced_input_emits_md_prefixed_output(self) -> None:
        xml = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b'<Party xmlns="http://www.eidr.org/schema">'
            b"<PartyName>"
            b"<DisplayName>Test Party</DisplayName>"
            b"</PartyName>"
            b"</Party>"
        )
        record = PartyRecord.from_xml(xml)
        out = record.to_xml().decode()
        assert 'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"' in out
        assert "<md:DisplayName>Test Party</md:DisplayName>" in out
        assert "<DisplayName>Test Party</DisplayName>" not in out
