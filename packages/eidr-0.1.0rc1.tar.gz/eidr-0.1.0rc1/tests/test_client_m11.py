"""Unit tests for the M11 surface (auto-paging iterators, typed query helpers).

M11-A: ``iter_status_by_user`` / ``iter_status_by_registrant`` /
       ``iter_status_superparty`` — auto-paging iterators that yield
       :class:`OperationStatusEntry` per ``<OperationStatus>`` element
       across pages.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import Client
from eidr.client._http import TransportConfig
from eidr.client._response import OperationStatusEntry
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


def _entries_envelope(entries: list[tuple[str, int, str, str | None]]) -> str:
    """Build a status-lookup response containing N OperationStatus children.

    Each entry is (token, status_code, status_type, details).
    """
    parts = ['<Response xmlns="http://www.eidr.org/schema">']
    parts.append("<Status><Code>0</Code><Type>success</Type></Status><RequestStatusResults>")
    for token, code, type_text, details in entries:
        parts.append("<OperationStatus>")
        parts.append(
            f"<Status><Code>{code}</Code><Type>{type_text}</Type>"
            + (f"<Details>{details}</Details>" if details else "")
            + "</Status>"
        )
        parts.append(f"<Token>{token}</Token>")
        parts.append("</OperationStatus>")
    parts.append("</RequestStatusResults></Response>")
    return "".join(parts)


class TestOperationStatusEntry:
    """The typed wrapper itself."""

    def test_extracts_all_four_fields(self) -> None:
        from lxml import etree

        xml = (
            '<OperationStatus xmlns="http://www.eidr.org/schema">'
            "<Status><Code>0</Code><Type>success</Type>"
            "<Details>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-F</Details></Status>"
            "<Token>1777250952014000067</Token>"
            "</OperationStatus>"
        )
        entry = OperationStatusEntry.from_element(etree.fromstring(xml))
        assert entry.token == "1777250952014000067"
        assert entry.status_code == 0
        assert entry.status_type == "success"
        assert entry.details == "10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-F"

    def test_handles_missing_token_and_details(self) -> None:
        from lxml import etree

        xml = (
            '<OperationStatus xmlns="http://www.eidr.org/schema">'
            "<Status><Code>4</Code><Type>validation error</Type></Status>"
            "</OperationStatus>"
        )
        entry = OperationStatusEntry.from_element(etree.fromstring(xml))
        assert entry.token is None
        assert entry.status_code == 4
        assert entry.status_type == "validation error"
        assert entry.details is None

    def test_extracts_resulting_id_when_present(self) -> None:
        """R1#9 (0.1.0b2): completed register/modify operations carry
        a resulting <ID> child of <OperationStatus> with the
        registry-assigned EIDR ID. Surface it as a typed field rather
        than forcing callers into XML access.
        """
        from lxml import etree

        xml = (
            '<OperationStatus xmlns="http://www.eidr.org/schema">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<Token>1777250952014000067</Token>"
            "<ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-F</ID>"
            "</OperationStatus>"
        )
        entry = OperationStatusEntry.from_element(etree.fromstring(xml))
        assert entry.resulting_id == "10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-F"

    def test_resulting_id_none_for_pending_operations(self) -> None:
        """Pending operations have no <ID> yet — the registry hasn't
        assigned one. ``resulting_id`` is ``None`` in that case.
        """
        from lxml import etree

        xml = (
            '<OperationStatus xmlns="http://www.eidr.org/schema">'
            "<Status><Code>0</Code><Type>pending</Type></Status>"
            "<Token>1777250952014000067</Token>"
            "</OperationStatus>"
        )
        entry = OperationStatusEntry.from_element(etree.fromstring(xml))
        assert entry.resulting_id is None
        assert entry.token == "1777250952014000067"


class TestIterStatusByUserAutoPaging:
    """M11-A: ``iter_status_by_user`` auto-paging."""

    def test_single_page_yields_all_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope(
                    [
                        ("token-1", 0, "success", None),
                        ("token-2", 0, "success", None),
                        ("token-3", 0, "success", None),
                    ]
                ),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_user("10.5238/u", page_size=20))

        assert len(entries) == 3
        assert [e.token for e in entries] == ["token-1", "token-2", "token-3"]

    def test_pages_until_short_page(self) -> None:
        """Auto-paging stops when a page returns fewer entries than page_size."""
        # Page 1: 3 entries (full page); Page 2: 1 entry (short page → stop)
        page_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            page_count[0] += 1
            if page_count[0] == 1:
                return httpx.Response(
                    200,
                    text=_entries_envelope(
                        [
                            ("token-1", 0, "success", None),
                            ("token-2", 0, "success", None),
                            ("token-3", 0, "success", None),
                        ]
                    ),
                )
            return httpx.Response(
                200,
                text=_entries_envelope([("token-4", 0, "success", None)]),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_user("10.5238/u", page_size=3))

        # Both pages were fetched; iteration stopped after the short page.
        assert page_count[0] == 2
        assert len(entries) == 4
        assert [e.token for e in entries] == [
            "token-1",
            "token-2",
            "token-3",
            "token-4",
        ]

    def test_empty_page_terminates(self) -> None:
        """A response with zero <OperationStatus> children stops iteration."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_entries_envelope([]))

        with make_client(handler) as client:
            entries = list(client.iter_status_by_user("10.5238/u"))

        assert entries == []

    def test_max_results_cap(self) -> None:
        """``max_results`` stops iteration mid-page once reached."""
        page_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            page_count[0] += 1
            return httpx.Response(
                200,
                text=_entries_envelope(
                    [(f"token-p{page_count[0]}-{i}", 0, "success", None) for i in range(20)]
                ),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_user("10.5238/u", page_size=20, max_results=5))

        # Should stop after the 5th entry — only one page fetched.
        assert page_count[0] == 1
        assert len(entries) == 5

    def test_passes_filters_through_to_status_lookup_by_user(self) -> None:
        """Status, after, before kwargs reach the underlying call."""
        from datetime import UTC, datetime

        captured_bodies: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            text = request.content.decode("utf-8")
            captured_bodies.append(text)
            return httpx.Response(200, text=_entries_envelope([]))

        with make_client(handler) as client:
            list(
                client.iter_status_by_user(
                    "10.5238/u",
                    status="completed",
                    after=datetime(2026, 4, 1, tzinfo=UTC),
                    before=datetime(2026, 4, 27, tzinfo=UTC),
                )
            )

        assert any("<Status>completed</Status>" in b for b in captured_bodies)
        assert any("<From>2026-04-01" in b for b in captured_bodies)


class TestIterStatusByRegistrantAutoPaging:
    def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([("tok", 0, "success", "10.5240/details")]),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_registrant("10.5237/AAAA-BBBB"))

        assert len(entries) == 1
        assert entries[0].details == "10.5240/details"


class TestIterStatusSuperparty:
    def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([("tok-sp", 0, "success", None)]),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_superparty(page_size=5))

        assert len(entries) == 1
        assert entries[0].token == "tok-sp"

    def test_authorization_error_propagates(self) -> None:
        """Non-Superparty creds → server-side EIDRAuthorizationError."""
        from eidr.errors import EIDRAuthorizationError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>authorization error</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client, pytest.raises(EIDRAuthorizationError):
            list(client.iter_status_superparty())


# ─── M11-A v2 (0.1.0b2): iter_status_by_token (R1#4) ───────────────────────


class TestIterStatusByToken:
    """Reviewer 1 #4: status-token responses can also be paginated
    (M10 v2 added pagination kwargs to ``status_lookup(token)``); the
    iterator was missing. This test class covers it.
    """

    def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope(
                    [
                        ("sub-1", 0, "success", "10.5240/AAAA"),
                        ("sub-2", 0, "success", "10.5240/BBBB"),
                    ]
                ),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_token("batch-token-12345", page_size=20))

        assert len(entries) == 2
        assert [e.token for e in entries] == ["sub-1", "sub-2"]

    def test_paginates(self) -> None:
        page_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            page_count[0] += 1
            if page_count[0] == 1:
                return httpx.Response(
                    200,
                    text=_entries_envelope([(f"sub-p1-{i}", 0, "success", None) for i in range(3)]),
                )
            return httpx.Response(200, text=_entries_envelope([("sub-p2-1", 0, "success", None)]))

        with make_client(handler) as client:
            entries = list(client.iter_status_by_token("batch-token", page_size=3))

        assert page_count[0] == 2
        assert len(entries) == 4

    def test_max_results_cap(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([(f"t-{i}", 0, "success", None) for i in range(20)]),
            )

        with make_client(handler) as client:
            entries = list(client.iter_status_by_token("batch-token", page_size=20, max_results=5))

        assert len(entries) == 5

    def test_uses_post_path(self) -> None:
        """Pagination switches to the POST path (Java parity with
        ``statusLookupViaToken(..., pageNumber, pageSize)``)."""
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_entries_envelope([]))

        with make_client(handler) as client:
            list(client.iter_status_by_token("batch-token-12345", page_size=5))

        assert captured["method"] == "POST"
        assert "<Token>batch-token-12345</Token>" in str(captured["body"])
        assert "<PageSize>5</PageSize>" in str(captured["body"])

    def test_rejects_empty_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="token"):
            list(client.iter_status_by_token(""))


# ─── R2#1 (0.1.0b2): iter_query / iter_query_ids auto-paging ───────────────


def _query_results_envelope(records: list[tuple[str, str]], total: int | None = None) -> str:
    """Build a query response with N <SimpleMetadata> records.

    Each entry is (id, resource_name).
    """
    if total is None:
        total = len(records)
    parts = [
        '<Response xmlns="http://www.eidr.org/schema">',
        "<Status><Code>0</Code><Type>success</Type></Status>",
        "<QueryResults>",
        f"<TotalMatches>{total}</TotalMatches>",
    ]
    for asset_id, name in records:
        parts.append(
            "<SimpleMetadata>"
            f"<ID>{asset_id}</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            f"<ResourceName>{name}</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            '<AssociatedOrg idType="eidrPartyID" '
            'organizationID="10.5237/FFDA-9947" role="registrant"/>'
            "<ReleaseDate>2026</ReleaseDate>"
            "<CountryOfOrigin>US</CountryOfOrigin>"
            "<Status>valid</Status>"
            "<ReferentType>Movie</ReferentType>"
            "</SimpleMetadata>"
        )
    parts.append("</QueryResults></Response>")
    return "".join(parts)


def _query_ids_envelope(ids: list[str], total: int | None = None) -> str:
    if total is None:
        total = len(ids)
    parts = [
        '<Response xmlns="http://www.eidr.org/schema">',
        "<Status><Code>0</Code><Type>success</Type></Status>",
        "<QueryResults>",
        f"<TotalMatches>{total}</TotalMatches>",
    ]
    for asset_id in ids:
        parts.append(f"<ID>{asset_id}</ID>")
    parts.append("</QueryResults></Response>")
    return "".join(parts)


class TestIterQuery:
    """Reviewer 2 #1 (0.1.0b2): asset-query auto-paging for ergonomic
    parity with the status-lookup iterators.
    """

    def test_yields_records(self) -> None:
        records = [
            ("10.5240/AAAA-AAAA-AAAA-AAAA-AAAA-A", "Movie A"),
            ("10.5240/BBBB-BBBB-BBBB-BBBB-BBBB-B", "Movie B"),
        ]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_results_envelope(records))

        with make_client(handler) as client:
            yielded = list(client.iter_query("ReferentType IS Movie"))

        assert len(yielded) == 2
        assert yielded[0].resource_name == "Movie A"
        assert yielded[1].resource_name == "Movie B"

    def test_paginates_until_no_more_pages(self) -> None:
        """Stops when has_more_pages is False (cumulative >= total).

        Page 1: 5 records (page_size=5), total=7.
        Page 2: 2 records, page_size=5 → cumulative 7 >= total 7 → stop.
        """
        page_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            page_count[0] += 1
            if page_count[0] == 1:
                records = [(f"10.5240/AAAA-AAAA-AAAA-AAAA-{i:04X}-A", f"M{i}") for i in range(5)]
                return httpx.Response(200, text=_query_results_envelope(records, total=7))
            records = [(f"10.5240/BBBB-BBBB-BBBB-BBBB-{i:04X}-B", f"N{i}") for i in range(2)]
            return httpx.Response(200, text=_query_results_envelope(records, total=7))

        with make_client(handler) as client:
            yielded = list(client.iter_query("ReferentType IS Movie", page_size=5))

        assert page_count[0] == 2
        assert len(yielded) == 7

    def test_max_results_cap(self) -> None:
        records = [(f"10.5240/AAAA-AAAA-AAAA-AAAA-{i:04X}-A", f"M{i}") for i in range(20)]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_results_envelope(records, total=100))

        with make_client(handler) as client:
            yielded = list(client.iter_query("ReferentType IS Movie", page_size=20, max_results=5))

        assert len(yielded) == 5

    def test_empty_results_terminates(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_results_envelope([], total=0))

        with make_client(handler) as client:
            yielded = list(client.iter_query("ReferentType IS Bogus"))

        assert yielded == []


class TestIterQueryIds:
    """ID-only iterator: yields strings, much lighter wire payload."""

    def test_yields_id_strings(self) -> None:
        ids = ["10.5240/AAAA-AAAA-AAAA-AAAA-AAAA-A", "10.5240/BBBB-BBBB-BBBB-BBBB-BBBB-B"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_ids_envelope(ids))

        with make_client(handler) as client:
            yielded = list(client.iter_query_ids("ReferentType IS Movie"))

        assert yielded == ids

    def test_uses_id_only_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_query_ids_envelope([]))

        with make_client(handler) as client:
            list(client.iter_query_ids("ReferentType IS Movie"))

        # ID-only mode hits /query/?type=ID
        assert "type=ID" in str(captured["url"])

    def test_max_results_cap(self) -> None:
        ids = [f"10.5240/AAAA-AAAA-AAAA-AAAA-{i:04X}-A" for i in range(20)]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_query_ids_envelope(ids, total=100))

        with make_client(handler) as client:
            yielded = list(
                client.iter_query_ids("ReferentType IS Movie", page_size=20, max_results=3)
            )

        assert len(yielded) == 3


# ─── M11-B: Typed query helpers ─────────────────────────────────────────────


def _empty_party_query_response() -> str:
    """Empty PartyQueryResults — matches the live registry shape per
    api.xsd. The wire shape is ``<PartyQueryResults>`` as the document
    root (NOT wrapped in ``<Response>``); confirmed against the
    integration trace m12_find_parties_*.log captured during the
    0.1.0b2 → 0.1.0b3 wire-shape investigation.
    """
    return (
        '<PartyQueryResults xmlns="http://www.eidr.org/schema">'
        "<CurrentSize>0</CurrentSize>"
        "<TotalMatches>0</TotalMatches>"
        "</PartyQueryResults>"
    )


def _empty_service_query_response() -> str:
    """Empty ServiceQueryResults — matches the live registry shape
    per service.xsd. ``<ServiceQueryResults>`` as the document root.
    """
    return (
        '<ServiceQueryResults xmlns="http://www.eidr.org/schema">'
        "<CurrentSize>0</CurrentSize>"
        "<TotalMatches>0</TotalMatches>"
        "</ServiceQueryResults>"
    )


class TestFindPartiesByName:
    def test_posts_findpartiesbyname_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            result = client.find_parties_by_name("Universal")

        assert captured["method"] == "POST"
        assert "/party/query" in str(captured["url"])
        body = str(captured["body"])
        assert "<FindPartiesByName" in body
        assert "<PartyName>Universal</PartyName>" in body
        # Per api.xsd, includeAlternateNames is an attribute on the
        # root element (lowercase camelCase), not a child element.
        # 0.1.0b1/b2 emitted it as <IncludeAlternateNames> child;
        # 0.1.0b3 fixed this after the live integration run rejected
        # the malformed body with Code 9 syntax error.
        assert 'includeAlternateNames="true"' in body
        # Default active_filter="all"
        # Default active_filter="active" — matches Java's
        # findPartiesByName default (Reviewer 1 RC item: behavioral
        # parity with reference implementation).
        assert "<ActiveFilter>active</ActiveFilter>" in body
        # Default page params
        assert "<PageNumber>1</PageNumber>" in body
        assert "<PageSize>20</PageSize>" in body
        # Returns typed wrapper, not raw ParsedResponse (R1#3, #8 — typed
        # query results were added in 0.1.0b2 to address Reviewer 1's
        # critique that named convenience helpers should return stable
        # typed objects rather than forcing callers into XML/XPath
        # inspection).
        from eidr.client import PartyQueryResults

        assert isinstance(result, PartyQueryResults)
        assert result.total_matches == 0
        assert result.party_ids == []
        assert result.parties == []

    def test_role_filter_emitted(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            client.find_parties_by_name("Universal", role_filter="registrant")

        assert "<RoleFilter>registrant</RoleFilter>" in str(captured["body"])

    def test_admin_response_error_raises_validation_error(self) -> None:
        """0.1.0b3 regression: when /party/query rejects a malformed
        request, the registry returns ``<AdminResponse>`` (not
        ``<Response>``) with the status code/type at the top level.
        Captured from the M12 live integration trace
        (m12_find_parties_20260427_151134.log); the registry's
        Code 9 ``syntax error`` for the malformed
        ``<IncludeAlternateNames>`` element exposed both bugs.
        """
        from eidr.errors import EIDRValidationError

        admin_error_body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<AdminResponse xmlns="http://www.eidr.org/schema">'
            "<Code>9</Code>"
            "<Type>syntax error</Type>"
            "<Details>cvc-complex-type.2.4.a: Invalid content was found</Details>"
            "</AdminResponse>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=admin_error_body)

        with (
            make_client(handler) as client,
            pytest.raises(EIDRValidationError) as exc_info,
        ):
            client.find_parties_by_name("Universal")

        assert "syntax error" in str(exc_info.value)

    def test_root_level_party_query_results(self) -> None:
        """0.1.0b3: per api.xsd, successful party queries return
        ``<PartyQueryResults>`` as the **document root**, not wrapped
        in ``<Response>``. Captured from the M12 integration trace
        (m12_find_parties_from_catalog returned this shape directly).
        """
        # No <Response> envelope — <PartyQueryResults> is the root.
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<PartyQueryResults xmlns="http://www.eidr.org/schema">'
            "<CurrentSize>2</CurrentSize>"
            "<TotalMatches>2</TotalMatches>"
            "<PartyID>10.5237/9DD9-E249</PartyID>"
            "<PartyID>10.5237/50D1-E164</PartyID>"
            "</PartyQueryResults>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.find_parties_from_catalog("MovieLabs")

        assert result.total_matches == 2
        assert result.current_size == 2
        assert result.party_ids == ["10.5237/9DD9-E249", "10.5237/50D1-E164"]
        assert result.parties == []
        assert len(result) == 2

    def test_include_alt_names_false(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            client.find_parties_by_name("Universal", include_alt_names=False)

        # Per api.xsd, includeAlternateNames is an attribute on the
        # root element. 0.1.0b3 fix.
        assert 'includeAlternateNames="false"' in str(captured["body"])
        # And not as a child element (the 0.1.0b1/b2 form that the
        # registry rejected with Code 9 syntax error).
        assert "<IncludeAlternateNames>" not in str(captured["body"])

    def test_full_kwarg_appends_type_full_param(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            client.find_parties_by_name("Universal", full=True)

        assert "type=full" in str(captured["url"])

    def test_pagination_kwargs_passed_through(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            client.find_parties_by_name("Universal", page_number=3, page_size=100)

        body = str(captured["body"])
        assert "<PageNumber>3</PageNumber>" in body
        assert "<PageSize>100</PageSize>" in body

    def test_continuation_token(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            client.find_parties_by_name("Universal", continuation_token="abc-token")

        assert "<ContinuationToken>abc-token</ContinuationToken>" in str(captured["body"])

    def test_rejects_empty_name(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="party_name"):
            client.find_parties_by_name("")

    def test_rejects_invalid_active_filter(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with (
            make_client(handler) as client,
            pytest.raises(ValueError, match="active_filter"),
        ):
            client.find_parties_by_name("Universal", active_filter="bogus")


class TestFindPartiesFromCatalog:
    def test_posts_findpartiesfromcatalog_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            result = client.find_parties_from_catalog("MovieLabs")

        body = str(captured["body"])
        assert "<FindPartiesFromCatalog" in body
        assert "<PartyName>MovieLabs</PartyName>" in body
        # No IncludeAlternateNames in the catalog variant
        assert "<IncludeAlternateNames>" not in body
        # Returns typed wrapper
        from eidr.client import PartyQueryResults

        assert isinstance(result, PartyQueryResults)


class TestFindServicesByName:
    def test_posts_findservicesbyname_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_service_query_response())

        with make_client(handler) as client:
            result = client.find_services_by_name("Netflix")

        assert "/service/query" in str(captured["url"])
        body = str(captured["body"])
        assert "<FindServicesByName" in body
        assert "<ServiceName>Netflix</ServiceName>" in body
        # No RoleFilter on services
        assert "<RoleFilter>" not in body
        # Returns typed wrapper
        from eidr.client import ServiceQueryResults

        assert isinstance(result, ServiceQueryResults)


class TestFindServicesFromCatalog:
    def test_posts_findservicesfromcatalog_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_service_query_response())

        with make_client(handler) as client:
            result = client.find_services_from_catalog("Hulu")

        body = str(captured["body"])
        assert "<FindServicesFromCatalog" in body
        assert "<ServiceName>Hulu</ServiceName>" in body
        from eidr.client import ServiceQueryResults

        assert isinstance(result, ServiceQueryResults)

    def test_root_level_service_query_results(self) -> None:
        """0.1.0b3: per service.xsd, successful service queries return
        ``<ServiceQueryResults>`` as the **document root**, not wrapped
        in ``<Response>``. Mirrors the party-query case captured from
        the M12 integration trace.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<ServiceQueryResults xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<CurrentSize>1</CurrentSize>"
            "<TotalMatches>1</TotalMatches>"
            "<Service>"
            "<ID>10.5239/AAAA-AAAA</ID>"
            "<ServiceName><md:DisplayName>Hulu</md:DisplayName></ServiceName>"
            "<PrimaryAudioLanguage>en</PrimaryAudioLanguage>"
            "<DeliveryModel>VOD</DeliveryModel>"
            "</Service>"
            "</ServiceQueryResults>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.find_services_from_catalog("Hulu")

        assert result.total_matches == 1
        assert result.current_size == 1
        assert len(result.services) == 1
        assert "<ID>10.5239/AAAA-AAAA</ID>" in result.services[0]


class TestPartyQueryResultsWrapper:
    """Reviewer 1 #3, #8: ``find_parties_*`` should return stable typed
    objects, not raw ``ParsedResponse``. The :class:`PartyQueryResults`
    wrapper exposes the wire-level fields of a ``<PartyQueryResults>``
    envelope.
    """

    def _id_only_response(
        self,
        ids: list[str],
        *,
        total: int | None = None,
        token: str | None = None,
    ) -> str:
        if total is None:
            total = len(ids)
        parts = [
            '<Response xmlns="http://www.eidr.org/schema">',
            "<Status><Code>0</Code><Type>success</Type></Status>",
            "<PartyQueryResults>",
            f"<CurrentSize>{len(ids)}</CurrentSize>",
            f"<TotalMatches>{total}</TotalMatches>",
        ]
        if token is not None:
            parts.append(f"<ContinuationToken>{token}</ContinuationToken>")
        for i in ids:
            parts.append(f"<PartyID>{i}</PartyID>")
        parts.append("</PartyQueryResults></Response>")
        return "".join(parts)

    def _full_response(self, party_ids: list[str]) -> str:
        parts = [
            '<Response xmlns="http://www.eidr.org/schema">',
            "<Status><Code>0</Code><Type>success</Type></Status>",
            "<PartyQueryResults>",
            f"<CurrentSize>{len(party_ids)}</CurrentSize>",
            f"<TotalMatches>{len(party_ids)}</TotalMatches>",
        ]
        for i in party_ids:
            parts.append(f"<Party><ID>{i}</ID><DisplayName>Test Party</DisplayName></Party>")
        parts.append("</PartyQueryResults></Response>")
        return "".join(parts)

    def test_id_only_response_populates_party_ids(self) -> None:
        ids = ["10.5237/AAAA-AAAA", "10.5237/BBBB-BBBB", "10.5237/CCCC-CCCC"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._id_only_response(ids, total=42))

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test")

        assert result.current_size == 3
        assert result.total_matches == 42
        assert result.party_ids == ids
        assert result.parties == []
        assert len(result) == 3
        assert bool(result) is True

    def test_full_response_populates_parties(self) -> None:
        ids = ["10.5237/AAAA-AAAA", "10.5237/BBBB-BBBB"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._full_response(ids))

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test", full=True)

        assert result.current_size == 2
        assert result.total_matches == 2
        # ID-only list is empty when caller asked for full records.
        assert result.party_ids == []
        # Full <Party> elements come back as serialized XML strings.
        assert len(result.parties) == 2
        for xml in result.parties:
            assert xml.startswith("<Party")
            assert "<DisplayName>Test Party</DisplayName>" in xml

    def test_party_records_property_parses_to_typed(self) -> None:
        """0.1.0rc1 (R1#8): the .party_records accessor parses the
        XML strings into typed PartyRecord instances so callers don't
        have to call PartyRecord.from_xml() themselves.
        """
        from eidr.models.party import PartyRecord

        ids = ["10.5237/AAAA-AAAA", "10.5237/BBBB-BBBB"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._full_response(ids))

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test", full=True)

        records = result.party_records
        assert len(records) == 2
        for record in records:
            assert isinstance(record, PartyRecord)
        # 0.1.0rc1: the property is cached_property, so repeated
        # access returns the same list object without re-parsing.
        assert result.party_records is records

    def test_party_records_empty_for_id_only_response(self) -> None:
        """ID-only responses produce empty .party_records — callers
        should use .party_ids and resolve_party() per ID."""
        ids = ["10.5237/AAAA-AAAA"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._id_only_response(ids))

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test")

        assert result.party_ids == ids
        assert result.parties == []
        assert result.party_records == []

    def test_continuation_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=self._id_only_response(
                    ["10.5237/AAAA-AAAA"], total=1000, token="opaque-cont-12345"
                ),
            )

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test")

        assert result.continuation_token == "opaque-cont-12345"

    def test_empty_results_yields_empty_lists(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_party_query_response())

        with make_client(handler) as client:
            result = client.find_parties_by_name("Nonexistent")

        assert result.party_ids == []
        assert result.parties == []
        assert result.continuation_token is None
        assert len(result) == 0
        assert bool(result) is False

    def test_raw_response_escape_hatch(self) -> None:
        """Advanced callers can drop down to the underlying ParsedResponse."""
        from eidr.client._response import ParsedResponse

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=self._id_only_response(["10.5237/AAAA-AAAA"]),
            )

        with make_client(handler) as client:
            result = client.find_parties_by_name("Test")

        assert isinstance(result.raw_response, ParsedResponse)
        # The raw response root is the <Response> envelope.
        assert result.raw_response.root.tag.endswith("}Response")


class TestServiceQueryResultsWrapper:
    """Reviewer 1 #3, #8 — service variant.

    The Service-query schema only supports full records (no
    ID-only ``<ServiceID>`` choice in serviceQueryResultsType),
    so :class:`ServiceQueryResults` only has :attr:`services`,
    not a parallel ``service_ids`` field.
    """

    def _full_response(self, service_ids: list[str]) -> str:
        parts = [
            '<Response xmlns="http://www.eidr.org/schema">',
            "<Status><Code>0</Code><Type>success</Type></Status>",
            "<ServiceQueryResults>",
            f"<CurrentSize>{len(service_ids)}</CurrentSize>",
            f"<TotalMatches>{len(service_ids)}</TotalMatches>",
        ]
        for i in service_ids:
            parts.append(f"<Service><ID>{i}</ID><ServiceName>Test Service</ServiceName></Service>")
        parts.append("</ServiceQueryResults></Response>")
        return "".join(parts)

    def test_response_populates_services(self) -> None:
        ids = ["10.5239/AAAA-AAAA", "10.5239/BBBB-BBBB"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._full_response(ids))

        with make_client(handler) as client:
            result = client.find_services_by_name("Test")

        assert result.current_size == 2
        assert result.total_matches == 2
        assert len(result.services) == 2
        for xml in result.services:
            assert xml.startswith("<Service")
            assert "<ServiceName>Test Service</ServiceName>" in xml

    def test_service_records_property_parses_to_typed(self) -> None:
        """0.1.0rc1 (R1#8): the .service_records accessor parses the
        XML strings into typed ServiceRecord instances.
        """
        from eidr.models.service import ServiceRecord

        ids = ["10.5239/AAAA-AAAA", "10.5239/BBBB-BBBB"]

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._full_response(ids))

        with make_client(handler) as client:
            result = client.find_services_by_name("Test")

        records = result.service_records
        assert len(records) == 2
        for record in records:
            assert isinstance(record, ServiceRecord)
        # 0.1.0rc1: cached_property — repeated access returns the
        # same list.
        assert result.service_records is records

    def test_empty_results(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_service_query_response())

        with make_client(handler) as client:
            result = client.find_services_by_name("Nonexistent")

        assert result.services == []
        assert len(result) == 0
        assert bool(result) is False
