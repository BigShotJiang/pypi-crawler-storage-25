"""Unit tests for the M9 Service / Party / Virtual-fields surface.

These tests use :class:`httpx.MockTransport` to verify the request
wire shape (URL, headers, body) and response handling for the new
M9 client methods. Live-sandbox verification belongs in the
``@pytest.mark.integration`` lane.

Test coverage rationale: every M9 client method on :class:`Client`
gets at least one happy-path test verifying:

1. The correct URL path (including query parameters where used).
2. The HTTP method (POST / GET).
3. The request body's wire shape (envelope wrapper element name,
   namespace handling, password embedding for create_party).
4. The response handling (typed return type, identity).

Plus negative tests for argument validation (empty IDs, missing
passwords, missing record IDs on modify operations).

The test fixtures are minimal enough to read in one sitting; they
mirror the wire shapes from the Java reference SDK
(``PartyAdmin.java`` and ``ServiceAdmin.java``) which is the
canonical reference for these endpoints.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import Client, Token
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.models.virtual import VirtualFields
from eidr.registries import Registry

# ─── shared fixtures ──────────────────────────────────────────────────────


REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
READONLY = Registry(
    name="TEST_RO",
    url="https://test-ro.example/EIDR",
    writable=False,
    description="Read-only",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
EIDR_NS = 'xmlns="http://www.eidr.org/schema"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
    tracing: object | None = None,
    enforce_superparty_gate: bool = False,
) -> Client:
    """Build a Client with a MockTransport mapped to ``handler``.

    The Superparty gate is **disabled by default** in this helper
    because most tests in this module exercise the *wire shape* of
    Party-administration operations, not the gate's policy logic.
    The gate itself has dedicated tests in
    :class:`TestSuperpartyGate`. Tests that want to verify the gate
    fires can pass ``enforce_superparty_gate=True``.
    """
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(
        registry,
        CREDS,
        transport_config=config,
        tracing=tracing,
        enforce_superparty_gate=enforce_superparty_gate,
    )


def _success_envelope() -> str:
    """Bare success envelope — common for ack-only operations (delete, alias, etc.)."""
    return f"<Response {EIDR_NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"


def _success_envelope_with_token(token: str = "tok-abc") -> str:
    """Successful envelope carrying a Token (registry deferred to async)."""
    return (
        f"<Response {EIDR_NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        f"<Token>{token}</Token>"
        "</Response>"
    )


def _service_record_xml(*, with_id: bool = False) -> bytes:
    """A minimal Service record body, suitable for ``ServiceRecord.from_xml``."""
    id_elem = "<ID>10.5239/AAAA-BBBB</ID>" if with_id else ""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<Service {EIDR_NS}>"
        f"{id_elem}"
        "<ServiceName>"
        "<DisplayName>Test Service</DisplayName>"
        "<SortName>Test Service</SortName>"
        "</ServiceName>"
        "<Active>true</Active>"
        "</Service>"
    ).encode()


def _party_record_xml(*, with_id: bool = False) -> bytes:
    """A minimal Party record body, suitable for ``PartyRecord.from_xml``."""
    id_elem = "<ID>10.5237/FFFF-1111</ID>" if with_id else ""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<Party {EIDR_NS}>"
        f"{id_elem}"
        "<PartyName>"
        "<DisplayName>Test Party</DisplayName>"
        "<SortName>Test Party</SortName>"
        "</PartyName>"
        "</Party>"
    ).encode()


def _service_record(*, with_id: bool = False) -> ServiceRecord:
    return ServiceRecord.from_xml(_service_record_xml(with_id=with_id))


def _party_record(*, with_id: bool = False) -> PartyRecord:
    return PartyRecord.from_xml(_party_record_xml(with_id=with_id))


def _registered_service_response_xml() -> str:
    """Registry-returned Service after a successful create."""
    return (
        f"<Service {EIDR_NS}>"
        "<ID>10.5239/CCCC-DDDD</ID>"
        "<ServiceName>"
        "<DisplayName>Test Service</DisplayName>"
        "<SortName>Test Service</SortName>"
        "</ServiceName>"
        "<Active>true</Active>"
        "</Service>"
    )


def _registered_party_response_xml() -> str:
    """Registry-returned Party after a successful create."""
    return (
        f"<Party {EIDR_NS}>"
        "<ID>10.5237/EEEE-FFFF</ID>"
        "<PartyName>"
        "<DisplayName>Test Party</DisplayName>"
        "<SortName>Test Party</SortName>"
        "</PartyName>"
        "</Party>"
    )


# ─── Service writes ────────────────────────────────────────────────────────


class TestCreateService:
    def test_posts_to_create_service_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_service_response_xml())

        with make_client(handler) as client:
            result = client.create_service(_service_record())

        assert captured["url"] == "https://test.example/EIDR/service/create/"
        assert captured["method"] == "POST"
        # Body is wrapped in <CreateService>, not <Service>
        body_str = str(captured["body"])
        assert "CreateService" in body_str
        assert "<ServiceName>" in body_str
        # Should be inline ServiceRecord on success
        assert isinstance(result, ServiceRecord)
        assert result.id == "10.5239/CCCC-DDDD"

    def test_returns_token_when_registry_defers(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token("svc-tok"))

        with make_client(handler) as client:
            result = client.create_service(_service_record())

        assert isinstance(result, Token)
        assert result.value == "svc-tok"

    def test_refused_against_readonly_registry(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        from eidr.errors import EIDRReadOnlyRegistryError

        with (
            make_client(handler, registry=READONLY) as client,
            pytest.raises(EIDRReadOnlyRegistryError),
        ):
            client.create_service(_service_record())

    def test_handles_envelope_wrapped_response(self) -> None:
        """The registry may return the inline record in two
        shapes: as the document root (``<Service>...</Service>``)
        or wrapped inside the standard envelope
        (``<Response><Status/><Service>...</Service></Response>``).

        Both shapes carry the same record body. A previous bug
        silently returned ``None`` for the envelope shape because
        the parser classified it as ``kind="envelope"`` and the
        helper only looked for records on bare-root responses.

        Regression test for that bug — verify that an
        envelope-wrapped service response still produces a
        :class:`ServiceRecord`.
        """

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response {EIDR_NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<Service>"
                    "<ID>10.5239/EEEE-FFFF</ID>"
                    "<ServiceName>"
                    "<DisplayName>Wrapped</DisplayName>"
                    "<SortName>Wrapped</SortName>"
                    "</ServiceName>"
                    "<Active>true</Active>"
                    "</Service>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            result = client.create_service(_service_record())

        assert isinstance(result, ServiceRecord), (
            f"expected ServiceRecord, got {type(result).__name__}: {result!r}"
        )
        assert result.id == "10.5239/EEEE-FFFF"

    def test_handles_status_details_id_response(self) -> None:
        """Reviewer-flagged regression from the M9 live-test pass:

        The live registry's ``create_service`` returns a *third*
        response shape — neither a bare record root nor an
        envelope-wrapped record, but the new ID embedded in
        ``<Status><Details>``::

            <Response>
              <Status>
                <Code>0</Code>
                <Type>success</Type>
                <Details>10.5239/52C0-0B32</Details>
              </Status>
            </Response>

        The previous handler returned ``None`` for this shape,
        which surprised callers and broke the smoke script's
        cleanup logic (no ID → no delete). With the live-test
        fix, ``_submit_admin`` extracts the ID from
        ``<Details>``, follows up with ``resolve()`` to get the
        full record, and returns that.

        This test simulates the two-stage interaction (POST then
        follow-up GET) and verifies the returned record has the
        registry-assigned ID.
        """
        new_id = "10.5239/52C0-0B32"

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST":
                # Initial create POST — registry returns the
                # ID-in-Details success envelope.
                return httpx.Response(
                    200,
                    text=(
                        f"<Response {EIDR_NS}>"
                        "<Status>"
                        "<Code>0</Code><Type>success</Type>"
                        f"<Details>{new_id}</Details>"
                        "</Status>"
                        "</Response>"
                    ),
                )
            # Follow-up resolve GET — registry returns the
            # newly-created record body.
            return httpx.Response(
                200,
                text=(
                    f"<Service {EIDR_NS} "
                    'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
                    f"<ID>{new_id}</ID>"
                    "<ServiceName>"
                    "<md:DisplayName>Resolved Service</md:DisplayName>"
                    "</ServiceName>"
                    "<Active>true</Active>"
                    "</Service>"
                ),
            )

        with make_client(handler) as client:
            result = client.create_service(_service_record())

        assert isinstance(result, ServiceRecord), (
            f"expected ServiceRecord, got {type(result).__name__}: {result!r}"
        )
        assert result.id == new_id


class TestModifyService:
    def test_posts_to_modify_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_service_response_xml())

        with make_client(handler) as client:
            result = client.modify_service(_service_record(with_id=True))

        assert captured["url"] == "https://test.example/EIDR/service/modify/"
        # Body is wrapped in <Service> (NOT <ModifyService> — schema asymmetry)
        body_str = str(captured["body"])
        assert "<Service" in body_str
        assert "ModifyService" not in body_str
        assert isinstance(result, ServiceRecord)

    def test_rejects_record_without_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with (
            make_client(handler) as client,
            pytest.raises(ValueError, match=r"record\.id"),
        ):
            client.modify_service(_service_record(with_id=False))


class TestDeleteService:
    def test_posts_to_delete_endpoint_with_empty_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.delete_service("10.5239/AAAA-BBBB")

        assert "/service/delete/10.5239/AAAA-BBBB" in str(captured["url"])

    def test_accepts_eidrid_value_object(self) -> None:
        """Reviewer-flagged regression from M9 live-test pass round 2:

        After ``client.create_service(record)`` returns a
        ``ServiceRecord``, the natural caller pattern is::

            new_record = client.create_service(...)
            ...
            client.delete_service(new_record.id)   # ← cleanup

        But ``ServiceRecord.id`` returns an ``EIDRID`` value object,
        not a string. Previously, this failed deep inside the
        validation with ``AttributeError: 'EIDRID' object has no
        attribute 'strip'``. The fix routes ID validation through
        ``coerce_id_to_str``, which accepts any value with
        ``__str__``.
        """
        from eidr.models.ids import EIDRID

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        eidr_id = EIDRID.parse("10.5239/AAAA-BBBB")
        with make_client(handler) as client:
            # Should NOT raise AttributeError — the helper coerces.
            client.delete_service(eidr_id)  # type: ignore[arg-type]

        assert "/service/delete/10.5239/AAAA-BBBB" in str(captured["url"])

    def test_rejects_empty_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="non-empty"):
            client.delete_service("")


class TestAliasService:
    def test_posts_to_alias_endpoint_with_target_query_param(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.alias_service("10.5239/AAAA-BBBB", "10.5239/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/service/alias/10.5239/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("target") == ["10.5239/CCCC-DDDD"]

    def test_rejects_empty_source(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="source_id"):
            client.alias_service("", "10.5239/CCCC-DDDD")

    def test_rejects_empty_target(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="target_id"):
            client.alias_service("10.5239/AAAA-BBBB", "")


class TestSetServiceParent:
    def test_posts_to_parent_endpoint_with_query_param(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.set_service_parent("10.5239/AAAA-BBBB", "10.5239/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/service/parent/10.5239/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("parent") == ["10.5239/CCCC-DDDD"]


class TestServiceChildren:
    def test_gets_from_children_endpoint(self) -> None:
        from eidr.client import ServiceChildrenResults

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        assert captured["method"] == "GET"
        assert "/service/children/10.5239/AAAA-BBBB" in str(captured["url"])
        # 0.1.0rc1: service_children returns a typed
        # :class:`ServiceChildrenResults` wrapping the underlying
        # :class:`ParsedResponse` (Reviewer 1 #9 — typed wrapper for
        # the service-graph reads).
        assert isinstance(result, ServiceChildrenResults)
        assert result.service_id == "10.5239/AAAA-BBBB"
        assert result.raw_response is not None
        assert result.raw_response.status_code == 0

    def test_include_inactive_default_is_false(self) -> None:
        """M10: default behavior matches Java's ``includeInactive=false``."""
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.service_children("10.5239/AAAA-BBBB")

        assert "all=false" in str(captured["url"])

    def test_include_inactive_true_passes_all_true(self) -> None:
        """M10: ``include_inactive=True`` produces ``?all=true``."""
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.service_children("10.5239/AAAA-BBBB", include_inactive=True)

        assert "all=true" in str(captured["url"])

    def test_extracts_child_ids_from_id_only_response(self) -> None:
        """0.1.0rc1: when the registry returns child IDs (the common
        shape — most service hierarchies have a small fixed set),
        ``ServiceChildrenResults.child_ids`` is populated.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<ID>10.5239/CCCC-1111</ID>"
            "<ID>10.5239/CCCC-2222</ID>"
            "<ID>10.5239/CCCC-3333</ID>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        assert result.service_id == "10.5239/AAAA-BBBB"
        assert result.child_ids == [
            "10.5239/CCCC-1111",
            "10.5239/CCCC-2222",
            "10.5239/CCCC-3333",
        ]
        assert result.children == []
        assert len(result) == 3
        assert bool(result) is True
        assert result.child_records == []  # no full bodies → no parsed records

    def test_extracts_full_child_records_when_provided(self) -> None:
        """0.1.0rc1: when the registry returns full child <Service>
        bodies, ``ServiceChildrenResults.child_records`` parses them
        to typed ServiceRecord instances.
        """
        from eidr.models.service import ServiceRecord

        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<Service>"
            "<ID>10.5239/CCCC-1111</ID>"
            "<ServiceName><md:DisplayName>Child One</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
            "<Service>"
            "<ID>10.5239/CCCC-2222</ID>"
            "<ServiceName><md:DisplayName>Child Two</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        # 0.1.0rc1 (R1#3): when the registry returns full <Service>
        # bodies, the IDs inside them belong to the records, NOT to
        # a separate child_ids list. The ID-only list (`child_ids`)
        # is empty here; the inner IDs are accessible via
        # `child_records[i].id` after parsing.
        assert result.child_ids == []
        assert len(result.children) == 2
        records = result.child_records
        assert len(records) == 2
        assert all(isinstance(r, ServiceRecord) for r in records)

    def test_empty_for_parent_with_no_children(self) -> None:
        """0.1.0rc1: a parent service with no children produces a
        falsy result whose ``child_ids`` and ``children`` are both
        empty lists.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        assert result.child_ids == []
        assert result.children == []
        assert len(result) == 0
        assert bool(result) is False

    def test_extraction_excludes_parent_id_if_echoed(self) -> None:
        """0.1.0rc1 (R1#3): if the registry echoes the parent's
        own ID into the response (defensive case), the parent
        ID is excluded from the child_ids list.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<ID>10.5239/AAAA-BBBB</ID>"  # parent's own ID, echoed
            "<ID>10.5239/CCCC-1111</ID>"
            "<ID>10.5239/CCCC-2222</ID>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        assert "10.5239/AAAA-BBBB" not in result.child_ids
        assert result.child_ids == ["10.5239/CCCC-1111", "10.5239/CCCC-2222"]

    def test_extraction_deduplicates_child_ids(self) -> None:
        """0.1.0rc1 (R1#3): duplicate IDs in the response (which
        could happen if the registry includes the same child via
        multiple paths) are deduplicated, preserving first-seen
        order.
        """
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<ID>10.5239/CCCC-1111</ID>"
            "<ID>10.5239/CCCC-2222</ID>"
            "<ID>10.5239/CCCC-1111</ID>"  # duplicate
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        assert result.child_ids == ["10.5239/CCCC-1111", "10.5239/CCCC-2222"]

    def test_extraction_prefers_structured_container_when_present(
        self,
    ) -> None:
        """0.1.0rc1 (R1#3): when a known children-container is
        present (``<ServiceChildren>`` etc.), only IDs inside it
        are extracted. IDs sitting elsewhere in the envelope (e.g.
        in a ``<RelatedID>`` or similar surrounding metadata) are
        ignored.
        """
        # Hypothetical structured shape — ``<ServiceChildren>``
        # contains the actual children; surrounding metadata
        # references some other Service IDs that should NOT be
        # treated as children.
        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<RelatedID>10.5239/UNRELATED-1</RelatedID>"
            "<ServiceChildren>"
            "<ID>10.5239/CCCC-1111</ID>"
            "<ID>10.5239/CCCC-2222</ID>"
            "</ServiceChildren>"
            "<RelatedID>10.5239/UNRELATED-2</RelatedID>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        # Only the IDs inside <ServiceChildren> count as children.
        assert result.child_ids == ["10.5239/CCCC-1111", "10.5239/CCCC-2222"]
        assert "10.5239/UNRELATED-1" not in result.child_ids
        assert "10.5239/UNRELATED-2" not in result.child_ids

    def test_cached_property_caches_child_records(self) -> None:
        """0.1.0rc1 (R1+R2): child_records uses functools.cached_property
        so repeated access doesn't re-parse the XML.
        """
        from eidr.models.service import ServiceRecord

        body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Response xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md" version="2.7.1">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<Service>"
            "<ID>10.5239/CCCC-1111</ID>"
            "<ServiceName><md:DisplayName>Child One</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=body)

        with make_client(handler) as client:
            result = client.service_children("10.5239/AAAA-BBBB")

        first = result.child_records
        second = result.child_records
        # Same list object — cached, not re-parsed.
        assert first is second
        assert isinstance(first[0], ServiceRecord)


class TestServiceParent:
    """M10: ``service_parent(id)`` — read counterpart to ``set_service_parent``."""

    def test_gets_from_parent_endpoint_and_returns_servicerecord(self) -> None:
        parent_xml = (
            '<Service xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<ID>10.5239/AAAA-1111</ID>"
            "<ServiceName><md:DisplayName>Parent Service</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
        )
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=parent_xml)

        with make_client(handler) as client:
            result = client.service_parent("10.5239/BBBB-2222")

        assert captured["method"] == "GET"
        assert "/service/parent/10.5239/BBBB-2222" in str(captured["url"])
        from eidr.models.service import ServiceRecord

        assert isinstance(result, ServiceRecord)
        assert str(result.id) == "10.5239/AAAA-1111"

    def test_returns_none_for_root_service(self) -> None:
        """A service with no parent gets a ``Code 4 not found`` envelope.

        The SDK translates that to ``None`` rather than forcing the
        caller to catch ``EIDRNotFoundError``.
        """

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>not found</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            result = client.service_parent("10.5239/CCCC-3333")

        assert result is None

    def test_other_errors_propagate(self) -> None:
        """Auth / validation errors are *not* translated to None."""
        from eidr.errors import EIDRAuthenticationError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>authentication error</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client, pytest.raises(EIDRAuthenticationError):
            client.service_parent("10.5239/DDDD-4444")

    def test_accepts_eidrid_value_object(self) -> None:
        """Same regression as the M9 round-3 ``coerce_id_to_str`` fix."""
        from eidr.models.ids import EIDRID

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>not found</Type></Status>"
                    "</Response>"
                ),
            )

        eidr_id = EIDRID.parse("10.5239/AAAA-BBBB")
        with make_client(handler) as client:
            result = client.service_parent(eidr_id)  # type: ignore[arg-type]

        assert result is None


# ─── Party writes ──────────────────────────────────────────────────────────


class TestCreateParty:
    def test_posts_to_party_create_with_password_embedded(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_party_response_xml())

        with make_client(handler) as client:
            result = client.create_party(_party_record(), "secret-pw")

        body_str = str(captured["body"])
        # Verify endpoint + wrapper
        assert "/party/create/" in str(captured["url"])
        assert "CreateParty" in body_str
        # Password is embedded in the body
        assert "<Password>secret-pw</Password>" in body_str
        # Returns inline PartyRecord
        assert isinstance(result, PartyRecord)
        assert result.id == "10.5237/EEEE-FFFF"

    def test_rejects_empty_password(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="password"):
            client.create_party(_party_record(), "")


class TestModifyParty:
    def test_posts_to_party_modify_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_party_response_xml())

        with make_client(handler) as client:
            result = client.modify_party(_party_record(with_id=True))

        body_str = str(captured["body"])
        # Body is wrapped in <Party> (NOT <ModifyParty> — schema asymmetry)
        assert "<Party" in body_str
        assert "ModifyParty" not in body_str
        # No password in modify body
        assert "<Password>" not in body_str
        assert isinstance(result, PartyRecord)

    def test_rejects_record_without_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with (
            make_client(handler) as client,
            pytest.raises(ValueError, match=r"record\.id"),
        ):
            client.modify_party(_party_record(with_id=False))


class TestSimplePartyOperations:
    """One test per parameter-only operation
    (delete / alias / activate / deactivate / change_password)."""

    def test_delete_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.delete_party("10.5237/AAAA-BBBB")

        assert "/party/delete/10.5237/AAAA-BBBB" in str(captured["url"])

    def test_alias_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.alias_party("10.5237/AAAA-BBBB", "10.5237/CCCC-DDDD")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/party/alias/10.5237/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("target") == ["10.5237/CCCC-DDDD"]

    def test_activate_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.activate_party("10.5237/AAAA-BBBB")

        assert "/party/activate/10.5237/AAAA-BBBB" in str(captured["url"])

    def test_deactivate_party(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.deactivate_party("10.5237/AAAA-BBBB")

        assert "/party/deactivate/10.5237/AAAA-BBBB" in str(captured["url"])

    def test_change_party_password(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.change_party_password("10.5237/AAAA-BBBB", "new-pw")

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        assert "/party/password/10.5237/AAAA-BBBB" in parts.path
        query = parse_qs(parts.query)
        assert query.get("password") == ["new-pw"]

    def test_change_party_password_rejects_empty(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="new_password"):
            client.change_party_password("10.5237/AAAA-BBBB", "")

    def test_change_party_password_url_encodes_special_chars(self) -> None:
        """Reviewer-flagged regression: a password containing reserved
        URL characters (``&``, ``+``, ``%``, ``=``, space) used to
        corrupt the request because the password was string-interpolated
        directly into the URL. With ``params={...}`` the value is
        properly percent-encoded by httpx, so the registry sees the
        original password verbatim.
        """
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_success_envelope())

        tricky = "p&w%=ord+with spaces"
        with make_client(handler) as client:
            client.change_party_password("10.5237/AAAA-BBBB", tricky)

        from urllib.parse import parse_qs, urlsplit

        parts = urlsplit(str(captured["url"]))
        # Path is unchanged
        assert "/party/password/10.5237/AAAA-BBBB" in parts.path
        # Query value, after URL-decoding by parse_qs, equals the
        # original password — i.e., the encoding round-trips correctly.
        query = parse_qs(parts.query)
        assert query.get("password") == [tricky]

    def test_change_party_password_redacted_in_trace(self) -> None:
        """Reviewer-flagged regression: passwords used to leak into
        trace ``url`` fields because the param was interpolated into
        the request URL. The trace builder now redacts known-sensitive
        query parameter names (``password``) regardless of how the
        URL was constructed.
        """
        from eidr.client import ListSink

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope())

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.change_party_password("10.5237/AAAA-BBBB", "secret-password")

        assert sink.records, "trace sink received no records"
        record = sink.records[0]
        # Real password must NOT appear anywhere in the trace's URL
        assert "secret-password" not in record.url
        # The redaction marker should be present
        assert "REDACTED" in record.url

    def test_empty_body_operations_send_literal_empty_body(self) -> None:
        """Reviewer-flagged regression: URL-only operations
        (delete, alias, activate, deactivate, set-parent,
        change-password) have no XML payload but used to wrap
        ``""`` in a multipart boundary envelope. Java's Post.java
        sends literal zero bytes when ``data == ""`` (its
        ``preparePayload`` is skipped). This test verifies the
        Python transport now matches that wire shape.

        Content-Type still says multipart (matches Java); only the
        body bytes differ.
        """
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content
            captured["content_type"] = request.headers.get("content-type", "")
            return httpx.Response(200, text=_success_envelope())

        with make_client(handler) as client:
            client.delete_party("10.5237/AAAA-BBBB")

        # Body is exactly empty (matches Java)
        assert captured["body"] == b"", (
            f"expected empty body, got {len(captured['body'])} bytes: {captured['body']!r}"
        )
        # Content-Type still says multipart (also matches Java)
        assert "multipart/form-data" in str(captured["content_type"])


# ─── Virtual fields ────────────────────────────────────────────────────────


class TestVirtualFields:
    def test_gets_from_virtual_object_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(
                200,
                text=(
                    f"<Response {EIDR_NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<VirtualFields>"
                    "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
                    "<Full>&lt;FullMetadata&gt;...&lt;/FullMetadata&gt;</Full>"
                    "<SelfDefined>&lt;SelfDefinedMetadata&gt;...&lt;/SelfDefinedMetadata&gt;</SelfDefined>"
                    "</VirtualFields>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            vf = client.virtual_fields("10.5240/7791-8534-2C23-9030-8610-5")

        assert captured["method"] == "GET"
        assert "/virtual/object/10.5240/7791-8534-2C23-9030-8610-5" in str(captured["url"])
        assert isinstance(vf, VirtualFields)
        assert vf.id == "10.5240/7791-8534-2C23-9030-8610-5"
        assert vf.full is not None
        assert "FullMetadata" in vf.full
        assert vf.self_defined is not None
        assert vf.alias is None

    def test_handles_id_only_response(self) -> None:
        """The registry may return only the ID with no view bodies
        (e.g., a record that has no aliases and no self-defined
        metadata to summarize)."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response {EIDR_NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<VirtualFields>"
                    "<ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-X</ID>"
                    "</VirtualFields>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            vf = client.virtual_fields("10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-X")

        assert vf.full is None
        assert vf.self_defined is None
        assert vf.alias is None

    def test_rejects_empty_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="non-empty"):
            client.virtual_fields("")


# ─── Wire-shape parity: build_create_*_body and build_modify_*_body ────────


class TestEnvelopeBuilders:
    """Tests for the underlying body-rename helpers — verifying the
    asymmetric Create-vs-Modify wrapper element naming. These are
    structural tests; they don't go through the transport."""

    def test_create_party_renames_root(self) -> None:
        from eidr.client._operations import build_create_party_body

        body = (
            f"<Party {EIDR_NS}>"
            "<PartyName><DisplayName>X</DisplayName>"
            "<SortName>X</SortName></PartyName>"
            "</Party>"
        )
        result = build_create_party_body(body)
        assert "<CreateParty" in result
        assert "</CreateParty>" in result
        # Inner content preserved
        assert "<PartyName>" in result

    def test_modify_party_keeps_party_root(self) -> None:
        from eidr.client._operations import build_modify_party_body

        body = (
            f"<Party {EIDR_NS}>"
            "<ID>10.5237/X-Y</ID>"
            "<PartyName><DisplayName>X</DisplayName>"
            "<SortName>X</SortName></PartyName>"
            "</Party>"
        )
        result = build_modify_party_body(body)
        assert "<Party" in result
        assert "ModifyParty" not in result
        assert "10.5237/X-Y" in result

    def test_create_service_renames_root(self) -> None:
        from eidr.client._operations import build_create_service_body

        body = (
            f"<Service {EIDR_NS}>"
            "<ServiceName><DisplayName>X</DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
        )
        result = build_create_service_body(body)
        assert "<CreateService" in result

    def test_create_party_rejects_wrong_root(self) -> None:
        from eidr.client._operations import build_create_party_body
        from eidr.errors import EIDRClientError

        with pytest.raises(EIDRClientError, match="Expected body XML root"):
            build_create_party_body(
                f"<Service {EIDR_NS}>"
                "<ServiceName><DisplayName>X</DisplayName></ServiceName>"
                "<Active>true</Active>"
                "</Service>"
            )


class TestEmbedPartyPassword:
    """Tests for ``embed_party_password`` — the helper that splices
    a ``<Password>`` element into a party body for create."""

    def test_appends_password_element(self) -> None:
        from eidr.client._shared import embed_party_password

        body = (
            f"<Party {EIDR_NS}>"
            "<PartyName><DisplayName>X</DisplayName>"
            "<SortName>X</SortName></PartyName>"
            "</Party>"
        )
        result = embed_party_password(body, "the-password")
        assert "<Password>the-password</Password>" in result
        # Password is the last child, after PartyName
        partyname_pos = result.index("<PartyName>")
        password_pos = result.index("<Password>")
        assert password_pos > partyname_pos

    def test_replaces_existing_password(self) -> None:
        """If the body already has a Password (e.g., template
        contains a placeholder), the helper replaces it."""
        from eidr.client._shared import embed_party_password

        body = (
            f"<Party {EIDR_NS}>"
            "<PartyName><DisplayName>X</DisplayName>"
            "<SortName>X</SortName></PartyName>"
            "<Password>old-password</Password>"
            "</Party>"
        )
        result = embed_party_password(body, "new-password")
        assert "old-password" not in result
        assert "<Password>new-password</Password>" in result

    def test_xml_escapes_password(self) -> None:
        """A password containing XML metacharacters must be
        properly escaped so the resulting XML stays well-formed.
        lxml handles this for us — verify the result parses back."""
        from lxml import etree

        from eidr.client._shared import embed_party_password

        body = (
            f"<Party {EIDR_NS}>"
            "<PartyName><DisplayName>X</DisplayName>"
            "<SortName>X</SortName></PartyName>"
            "</Party>"
        )
        # A password with characters that would break naive
        # string concatenation
        tricky = 'pw<tag>"&\\'
        result = embed_party_password(body, tricky)
        # Round-trip parse: the password should come out unchanged
        parsed = etree.fromstring(result.encode("utf-8"))
        ns = etree.QName(parsed).namespace
        password_tag = f"{{{ns}}}Password" if ns else "Password"
        password_el = parsed.find(password_tag)
        assert password_el is not None
        assert password_el.text == tricky
