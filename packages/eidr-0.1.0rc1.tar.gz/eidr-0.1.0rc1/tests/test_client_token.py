"""Tests for :mod:`eidr.client._token`."""

from __future__ import annotations

from collections.abc import Callable
from unittest.mock import MagicMock

import httpx
import pytest

from eidr.client import Client, Token, TokenStatus
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.errors import EIDRProtocolError, EIDRTimeoutError
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


NS = ' xmlns="http://www.eidr.org/schema"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


def _status_response(op_code: int, *, with_sub_token: bool = False, with_id: str = "") -> str:
    """Build a status-lookup envelope response with a single <OperationStatus>."""
    inner = f"<Status><Code>{op_code}</Code></Status>"
    if with_sub_token:
        inner = "<Token>sub-token-123</Token>" + inner
    if with_id:
        inner += f"<ID>{with_id}</ID>"
    return (
        f"<Response{NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<RequestStatusResults>"
        f"<OperationStatus>{inner}</OperationStatus>"
        "</RequestStatusResults>"
        "</Response>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Construction
# ─────────────────────────────────────────────────────────────────────────────


class TestTokenConstruction:
    def test_valid_string(self) -> None:
        t = Token(value="abc-123")
        assert t.value == "abc-123"
        assert t.status is TokenStatus.PENDING
        assert t.last_response is None

    def test_empty_string_rejected(self) -> None:
        with pytest.raises(ValueError, match="non-empty string"):
            Token(value="")

    def test_non_string_rejected(self) -> None:
        with pytest.raises(ValueError, match="non-empty string"):
            Token(value=123)  # type: ignore[arg-type]


# ─────────────────────────────────────────────────────────────────────────────
# poll
# ─────────────────────────────────────────────────────────────────────────────


class TestPoll:
    def test_poll_without_client_raises(self) -> None:
        t = Token(value="x")
        with pytest.raises(EIDRProtocolError, match="no associated Client"):
            t.poll()

    def test_poll_success_updates_status(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(0, with_id="10.5240/abc"))

        with make_client(handler) as client:
            t = Token(value="tok-1", _client=client)
            status = t.poll()
        assert status is TokenStatus.SUCCESS
        assert t.status is TokenStatus.SUCCESS
        assert t.last_response is not None

    def test_poll_pending_keeps_status_pending(self) -> None:
        # Code != 0 with a sub-token = still pending (awaiting review)
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_status_response(100, with_sub_token=True),
            )

        with make_client(handler) as client:
            t = Token(value="tok-2", _client=client)
            status = t.poll()
        assert status is TokenStatus.PENDING

    def test_poll_failure(self) -> None:
        # Code != 0 with no sub-token = failed
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(99))

        with make_client(handler) as client:
            t = Token(value="tok-3", _client=client)
            status = t.poll()
        assert status is TokenStatus.FAILURE


# ─────────────────────────────────────────────────────────────────────────────
# wait
# ─────────────────────────────────────────────────────────────────────────────


class TestWait:
    def test_wait_returns_immediately_on_success(self) -> None:
        calls = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            calls[0] += 1
            return httpx.Response(200, text=_status_response(0, with_id="10.5240/x"))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            status = t.wait(timeout=10.0)
        assert status is TokenStatus.SUCCESS
        assert calls[0] == 1  # No retry needed

    def test_wait_polls_until_resolved(self) -> None:
        calls = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            calls[0] += 1
            if calls[0] < 3:
                return httpx.Response(200, text=_status_response(100, with_sub_token=True))
            return httpx.Response(200, text=_status_response(0, with_id="10.5240/x"))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            status = t.wait(timeout=5.0, initial_delay=0.001, max_delay=0.01)
        assert status is TokenStatus.SUCCESS
        assert calls[0] == 3

    def test_wait_times_out_on_persistent_pending(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(100, with_sub_token=True))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            with pytest.raises(EIDRTimeoutError, match="still pending after"):
                t.wait(timeout=0.1, initial_delay=0.01, max_delay=0.01)
        # Token status still pending; can poll again later
        assert t.status is TokenStatus.PENDING

    def test_wait_timeout_zero_is_single_poll(self) -> None:
        calls = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            calls[0] += 1
            return httpx.Response(200, text=_status_response(0))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            t.wait(timeout=0.0)
        assert calls[0] == 1

    def test_wait_timeout_zero_raises_if_pending(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(100, with_sub_token=True))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            with pytest.raises(EIDRTimeoutError, match="single poll"):
                t.wait(timeout=0.0)

    def test_wait_negative_timeout_rejected(self) -> None:
        t = Token(value="x", _client=MagicMock())
        with pytest.raises(ValueError, match="timeout must be >= 0"):
            t.wait(timeout=-1.0)


# ─────────────────────────────────────────────────────────────────────────────
# result
# ─────────────────────────────────────────────────────────────────────────────


class TestResult:
    def test_result_returns_response_on_success(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(0, with_id="10.5240/x"))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            parsed = t.result(timeout=1.0)
        assert parsed.status_code == 0

    def test_result_raises_on_failure(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(99))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            with pytest.raises(EIDRProtocolError, match="resolved to FAILURE"):
                t.result(timeout=1.0)

    def test_result_timeout_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(100, with_sub_token=True))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            with pytest.raises(EIDRTimeoutError):
                t.result(timeout=0.1)


# ─────────────────────────────────────────────────────────────────────────────
# result_id
# ─────────────────────────────────────────────────────────────────────────────


class TestResultId:
    def test_extracts_id_from_operation_status(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_status_response(0, with_id="10.5240/abc-def"),
            )

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            t.poll()
        assert t.result_id() == "10.5240/abc-def"

    def test_none_when_never_polled(self) -> None:
        t = Token(value="tok")
        assert t.result_id() is None

    def test_none_when_still_pending(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_status_response(100, with_sub_token=True),
            )

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            t.poll()
        assert t.result_id() is None

    def test_none_when_no_id_in_response(self) -> None:
        # Successful op with no ID (e.g., match-only or something exotic)
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(0))

        with make_client(handler) as client:
            t = Token(value="tok", _client=client)
            t.poll()
        assert t.result_id() is None


# ─────────────────────────────────────────────────────────────────────────────
# attach
# ─────────────────────────────────────────────────────────────────────────────


class TestAttach:
    def test_attach_enables_polling(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_status_response(0))

        t = Token(value="tok")
        # Can't poll without a client
        with pytest.raises(EIDRProtocolError):
            t.poll()
        # Attach and retry
        with make_client(handler) as client:
            t.attach(client)
            t.poll()
        assert t.status is TokenStatus.SUCCESS
