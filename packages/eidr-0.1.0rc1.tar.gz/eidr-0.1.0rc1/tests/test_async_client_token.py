"""Tests for :class:`AsyncToken` and :meth:`Token.to_async`.

Covers:
- AsyncToken.poll / wait / operation_result / result / result_id / attach
- Token.to_async() conversion (sync-under-load fallback bridge into async)
- Cancellation propagation (asyncio.CancelledError)
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable

import httpx
import pytest

from eidr.client import (
    AsyncClient,
    AsyncToken,
    Client,
    OperationResult,
    Token,
    TokenStatus,
)
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.errors import EIDRProtocolError, EIDRTimeoutError
from eidr.registries import Registry

REGISTRY = Registry(name="T", url="https://t.example/E", writable=True, description="t")
CREDS = Credentials(user_id="10.5238/u", party_id="10.5237/FFDA-9947", password="p")
NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _envelope_pending(sub_token: str = "sub-pending") -> str:
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<RequestStatusResults>"
        "<OperationStatus>"
        f"<Token>{sub_token}</Token>"
        "<Status><Code>2</Code><Type>pending</Type></Status>"
        "</OperationStatus>"
        "</RequestStatusResults>"
        "</Response>"
    )


def _envelope_success_with_id(eidr_id: str) -> str:
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<RequestStatusResults>"
        "<OperationStatus>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        f"<ID>{eidr_id}</ID>"
        "</OperationStatus>"
        "</RequestStatusResults>"
        "</Response>"
    )


def make_async_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> AsyncClient:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(REGISTRY, CREDS, transport_config=config)


def make_sync_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


# ─── AsyncToken.poll ────────────────────────────────────────────────────────


class TestAsyncTokenPoll:
    async def test_poll_returns_success_immediately(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200, text=_envelope_success_with_id("10.5240/0000-02ED-1DCE-6AAF-99F7-M")
            )

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            status = await tok.poll()
        assert status is TokenStatus.SUCCESS
        assert tok.last_response is not None
        assert tok.last_response.status_code == 0

    async def test_poll_detects_pending(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_pending())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            status = await tok.poll()
        assert status is TokenStatus.PENDING

    async def test_poll_requires_client(self) -> None:
        tok = AsyncToken(value="my-tok")  # no _client
        with pytest.raises(EIDRProtocolError, match="no associated AsyncClient"):
            await tok.poll()


# ─── AsyncToken.wait ────────────────────────────────────────────────────────


class TestAsyncTokenWait:
    async def test_wait_returns_on_first_success(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            return httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            status = await tok.wait(timeout=2.0)
        assert status is TokenStatus.SUCCESS
        assert attempts[0] == 1

    async def test_wait_polls_until_resolved(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] < 3:
                return httpx.Response(200, text=_envelope_pending())
            return httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            # Short backoff so the test runs quickly
            status = await tok.wait(
                timeout=5.0, initial_delay=0.01, backoff_factor=1.1, max_delay=0.05
            )
        assert status is TokenStatus.SUCCESS
        assert attempts[0] == 3

    async def test_wait_raises_timeout_if_still_pending(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_pending())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            with pytest.raises(EIDRTimeoutError):
                await tok.wait(timeout=0.05, initial_delay=0.01, max_delay=0.02)
        # Token state preserved for later retry.
        assert tok.status is TokenStatus.PENDING

    async def test_wait_timeout_zero_performs_one_poll(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            return httpx.Response(200, text=_envelope_pending())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            with pytest.raises(EIDRTimeoutError):
                await tok.wait(timeout=0)
        assert attempts[0] == 1

    async def test_wait_rejects_negative_timeout(self) -> None:
        async with make_async_client(
            lambda r: httpx.Response(200, text=_envelope_pending())
        ) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            with pytest.raises(ValueError, match="timeout"):
                await tok.wait(timeout=-1)

    async def test_wait_respects_cancellation(self) -> None:
        """Cancellation propagates cleanly; token state reflects the last poll."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_pending())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)

            async def wait_long() -> TokenStatus:
                return await tok.wait(timeout=10.0, initial_delay=5.0, max_delay=5.0)

            task = asyncio.create_task(wait_long())
            # Let the first poll complete, then cancel during sleep
            await asyncio.sleep(0.05)
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            # Last poll state is preserved
            assert tok.status is TokenStatus.PENDING
            assert tok.last_response is not None


# ─── AsyncToken.operation_result ────────────────────────────────────────────


class TestAsyncTokenOperationResult:
    async def test_resolved_success_returns_operation_result(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_envelope_success_with_id("10.5240/0000-02ED-1DCE-6AAF-99F7-M"),
            )

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            result = await tok.operation_result(timeout=1.0)
        assert isinstance(result, OperationResult)
        assert result.status is TokenStatus.SUCCESS
        assert result.id == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"

    async def test_pending_timeout_returns_pending_result(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_pending())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            result = await tok.operation_result(timeout=0.05)
        assert result.status is TokenStatus.PENDING
        assert result.sub_tokens == ["sub-pending"]

    async def test_detached_token_raises(self) -> None:
        tok = AsyncToken(value="my-tok")  # no client
        with pytest.raises(EIDRProtocolError):
            await tok.operation_result(timeout=1.0)


# ─── AsyncToken.result / result_id / attach ─────────────────────────────────


class TestAsyncTokenResultAccessors:
    async def test_result_returns_parsed_response(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            resp = await tok.result(timeout=1.0)
        assert resp.status_code == 0

    async def test_result_id_extracts_from_last_response(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200, text=_envelope_success_with_id("10.5240/0000-02ED-1DCE-6AAF-99F7-M")
            )

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok", _client=client)
            await tok.poll()
        assert tok.result_id() == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"

    async def test_result_id_returns_none_before_polling(self) -> None:
        tok = AsyncToken(value="my-tok")
        assert tok.result_id() is None

    async def test_attach_binds_client(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="my-tok")  # detached
            with pytest.raises(EIDRProtocolError):
                await tok.poll()
            tok.attach(client)
            status = await tok.poll()
        assert status is TokenStatus.SUCCESS

    async def test_construction_rejects_empty_value(self) -> None:
        with pytest.raises(ValueError, match="non-empty"):
            AsyncToken(value="")


# ─── Token.to_async conversion ──────────────────────────────────────────────


class TestTokenToAsync:
    """Covers the sync-under-load fallback bridge.

    The typical scenario: a sync ``client.register(record, immediate=True)``
    call returns a Token (not a record) because the registry deferred
    to async under load. The caller is in an async workflow and wants
    to ``await`` the completion rather than blocking.
    """

    async def test_conversion_preserves_token_value(self) -> None:
        sync_client = make_sync_client(lambda r: httpx.Response(200, text=_envelope_pending()))
        try:
            tok = Token(value="my-tok", _client=sync_client)

            async with make_async_client(
                lambda r: httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))
            ) as async_client:
                async_tok = tok.to_async(async_client)
                assert isinstance(async_tok, AsyncToken)
                assert async_tok.value == tok.value
                assert async_tok._client is async_client
        finally:
            sync_client.close()

    async def test_conversion_preserves_last_response_and_status(self) -> None:
        # Set up a sync token that has been polled to PENDING once
        sync_handler_calls = [0]

        def sync_handler(request: httpx.Request) -> httpx.Response:
            sync_handler_calls[0] += 1
            return httpx.Response(200, text=_envelope_pending())

        sync_client = make_sync_client(sync_handler)
        try:
            tok = Token(value="my-tok", _client=sync_client)
            # One sync poll to populate last_response
            tok.poll()
            assert tok.status is TokenStatus.PENDING
            assert tok.last_response is not None

            # Convert to async and verify state survives
            async with make_async_client(
                lambda r: httpx.Response(200, text=_envelope_success_with_id("10.5240/X"))
            ) as async_client:
                async_tok = tok.to_async(async_client)
                assert async_tok.status is TokenStatus.PENDING
                assert async_tok.last_response is tok.last_response

                # Now poll async — should succeed
                status = await async_tok.poll()
                assert status is TokenStatus.SUCCESS
        finally:
            sync_client.close()

    async def test_conversion_does_not_detach_original(self) -> None:
        """``to_async`` is non-destructive — the original sync Token
        remains fully usable."""
        sync_client = make_sync_client(lambda r: httpx.Response(200, text=_envelope_pending()))
        try:
            tok = Token(value="my-tok", _client=sync_client)

            async with make_async_client(
                lambda r: httpx.Response(200, text=_envelope_pending())
            ) as async_client:
                async_tok = tok.to_async(async_client)
                # Both tokens are independently usable
                assert tok._client is sync_client
                assert async_tok._client is async_client
                assert tok.value == async_tok.value
        finally:
            sync_client.close()


# ─── AsyncToken.result FAILURE parity with sync Token.result ────────────────


def _envelope_failure(op_code: int = 99) -> str:
    """A status-lookup envelope reporting a terminal failure.

    Mirrors the sync test's ``_status_response(op_code)`` shape: a
    non-zero <OperationStatus><Status><Code> with no sub-<Token>
    classifies as FAILURE per :func:`_status_from_response`.
    """
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        "<RequestStatusResults>"
        "<OperationStatus>"
        f"<Status><Code>{op_code}</Code></Status>"
        "</OperationStatus>"
        "</RequestStatusResults>"
        "</Response>"
    )


class TestAsyncTokenResultFailureParity:
    """Mirror of sync ``TestTokenResult.test_result_raises_on_failure``.

    Documents and locks the sync/async parity contract: equivalent
    method names have equivalent semantics. Sync ``Token.result()``
    raises ``EIDRProtocolError`` on terminal failure; async
    ``AsyncToken.result()`` must do the same.
    """

    async def test_result_raises_on_failure(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_envelope_failure())

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="failing-tok", _client=client)
            with pytest.raises(EIDRProtocolError, match="resolved to FAILURE"):
                await tok.result(timeout=1.0)

    async def test_result_failure_message_includes_status_type(self) -> None:
        """The error message includes the registry-supplied status
        type when present, matching sync behavior."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<RequestStatusResults>"
                    "<OperationStatus>"
                    "<Status>"
                    "<Code>5</Code>"
                    "<Type>authorization error</Type>"
                    "</Status>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        async with make_async_client(handler) as client:
            tok = AsyncToken(value="auth-fail-tok", _client=client)
            with pytest.raises(EIDRProtocolError) as excinfo:
                await tok.result(timeout=1.0)
        # The reason string should reference either the type or the
        # numeric code; we accept either since sync and async use
        # the same _envelope-derived reason extraction.
        msg = str(excinfo.value)
        assert "FAILURE" in msg
        assert "auth-fail-tok" in msg
