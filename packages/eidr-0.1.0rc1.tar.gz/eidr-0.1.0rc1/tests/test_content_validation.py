"""Tests for pre-submission validation on :class:`ContentRecord`."""

from __future__ import annotations

import pytest

from eidr.errors import EIDRValidationError
from eidr.models import ContentRecord, ValidationError, ValidationReport

CONTENT_ID = "10.5240/7791-8534-2C23-9030-8610-5"
PARENT_ID = "10.5240/0000-0000-0000-0000-0000-X"
REGISTRANT_ID = "10.5237/7791-8534"

NS = (
    ' xmlns="http://www.eidr.org/schema"'
    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
)


def _wrap(base_xml: str, extra_xml: str = "") -> bytes:
    xml = f"<FullMetadata{NS}><BaseObjectData>{base_xml}</BaseObjectData>"
    if extra_xml:
        xml += f"<ExtraObjectMetadata>{extra_xml}</ExtraObjectMetadata>"
    xml += "</FullMetadata>"
    return xml.encode()


def _minimal_valid_base(with_id: bool = True) -> str:
    """A BaseObjectData body that passes all required-field checks."""
    parts = []
    if with_id:
        parts.append(f"<ID>{CONTENT_ID}</ID>")
    parts.extend(
        [
            "<StructuralType>Abstraction</StructuralType>",
            "<Mode>AudioVisual</Mode>",
            "<ReferentType>Movie</ReferentType>",
            "<ResourceName>A Test Movie</ResourceName>",
            "<OriginalLanguage>en</OriginalLanguage>",
            "<Status>valid</Status>",
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>",
        ]
    )
    return "".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# Basic structure
# ─────────────────────────────────────────────────────────────────────────────


class TestValidationReturnType:
    def test_returns_validation_report(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base()))
        report = rec.validate()
        assert isinstance(report, ValidationReport)

    def test_happy_path_returns_empty_report(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base()))
        report = rec.validate()
        assert not report  # truthy iff non-empty
        assert len(report) == 0

    def test_report_is_iterable(self) -> None:
        rec = ContentRecord.from_xml(_wrap("<ReferentType>Movie</ReferentType>"))
        report = rec.validate()
        assert len(report) > 0
        errors = list(report)
        assert all(isinstance(e, ValidationError) for e in errors)

    def test_validate_strict_raises_on_error(self) -> None:
        rec = ContentRecord.from_xml(_wrap("<ReferentType>Movie</ReferentType>"))
        with pytest.raises(EIDRValidationError) as exc_info:
            rec.validate_strict()
        assert exc_info.value.errors  # non-empty

    def test_validate_strict_no_op_on_success(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base()))
        rec.validate_strict()  # must not raise


# ─────────────────────────────────────────────────────────────────────────────
# Required fields
# ─────────────────────────────────────────────────────────────────────────────


class TestRequiredFields:
    def test_missing_referent_type(self) -> None:
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        rec = ContentRecord.from_xml(xml)
        report = rec.validate()
        codes = [e.code for e in report]
        assert "content.required_field.missing" in codes
        paths = [e.path for e in report]
        assert "BaseObjectData/ReferentType" in paths

    def test_missing_resource_name(self) -> None:
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        assert any(e.path == "BaseObjectData/ResourceName" for e in report)

    def test_missing_registrant(self) -> None:
        # Administrators present but Registrant missing → report Registrant
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            "<Administrators><MetadataAuthority>someone</MetadataAuthority></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        assert any(e.path == "BaseObjectData/Administrators/Registrant" for e in report)

    def test_empty_administrators_reported_as_missing(self) -> None:
        # Empty <Administrators/> is a missing container
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            "<Administrators></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        assert any(e.path == "BaseObjectData/Administrators" for e in report)

    def test_missing_base_object_data(self) -> None:
        xml = f"<FullMetadata{NS}></FullMetadata>".encode()
        report = ContentRecord.from_xml(xml).validate()
        assert any(e.path == "BaseObjectData" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# Controlled vocabularies
# ─────────────────────────────────────────────────────────────────────────────


class TestControlledVocabularies:
    def test_invalid_referent_type(self) -> None:
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Hologram</ReferentType>"  # not a real value
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        vocab_errors = [e for e in report if e.code == "content.vocabulary.invalid"]
        assert len(vocab_errors) == 1
        assert vocab_errors[0].value == "Hologram"
        assert "ReferentType" in vocab_errors[0].message

    def test_invalid_mode(self) -> None:
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>4D</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        assert any(
            e.code == "content.vocabulary.invalid" and e.path == "BaseObjectData/Mode"
            for e in report
        )

    def test_all_vocabularies_valid(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base()))
        report = rec.validate()
        assert not any(e.code == "content.vocabulary.invalid" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# CreationType consistency
# ─────────────────────────────────────────────────────────────────────────────


class TestCreationTypeConsistency:
    def test_multiple_creation_blocks_rejected(self) -> None:
        # Both SeriesInfo AND EditInfo — mutually exclusive!
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<SeriesInfo><SeriesClass>X</SeriesClass></SeriesInfo>"
                "<EditInfo>"
                f"<Parent><ID>{PARENT_ID}</ID></Parent>"
                "<EditClass>default</EditClass>"
                "<EditUse>default</EditUse>"
                "</EditInfo>",
            )
        )
        report = rec.validate()
        assert any(e.code == "content.creation_type.multiple_blocks" for e in report)

    def test_single_creation_block_ok(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<SeriesInfo><SeriesClass>Program</SeriesClass></SeriesInfo>",
            )
        )
        report = rec.validate()
        assert not any(e.code == "content.creation_type.multiple_blocks" for e in report)

    def test_basic_with_no_blocks_ok(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base()))
        report = rec.validate()
        assert not any(e.code.startswith("content.creation_type.") for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# Per-CreationType required fields
# ─────────────────────────────────────────────────────────────────────────────


class TestBlockRequiredFields:
    def test_episode_requires_parent(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<EpisodeInfo><EpisodeClass>Standard</EpisodeClass></EpisodeInfo>",
            )
        )
        report = rec.validate()
        assert any(
            e.path == "ExtraObjectMetadata/EpisodeInfo/Parent"
            and e.code == "content.required_field.missing"
            for e in report
        )

    def test_series_requires_series_class(self) -> None:
        # SeriesInfo present with a different (unrelated) required-optional
        # field, but no SeriesClass. An empty <SeriesInfo/> would instead
        # trigger the empty-tag check, which is a separate validation rule.
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<SeriesInfo><DateRequired>true</DateRequired></SeriesInfo>",
            )
        )
        report = rec.validate()
        assert any(e.path == "ExtraObjectMetadata/SeriesInfo/SeriesClass" for e in report)

    def test_edit_requires_edit_class_and_use(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                f"<EditInfo><Parent><ID>{PARENT_ID}</ID></Parent></EditInfo>",
            )
        )
        report = rec.validate()
        paths = {e.path for e in report}
        assert "ExtraObjectMetadata/EditInfo/EditClass" in paths
        assert "ExtraObjectMetadata/EditInfo/EditUse" in paths

    def test_compilation_requires_compilation_class(self) -> None:
        # CompilationInfo present with other content but missing CompilationClass
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<CompilationInfo><md:Entry><md:ContentID>"
                "10.5240/0000-0000-0000-0000-0000-X</md:ContentID></md:Entry>"
                "</CompilationInfo>",
            )
        )
        report = rec.validate()
        assert any(e.path == "ExtraObjectMetadata/CompilationInfo/CompilationClass" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# CompositeInfo placement
# ─────────────────────────────────────────────────────────────────────────────


class TestCompositeInfoPlacement:
    def test_composite_on_basic_ok(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<CompositeInfo><CompositeClass>Anthology</CompositeClass></CompositeInfo>",
            )
        )
        report = rec.validate()
        assert not any(e.code == "content.composite_info.misplaced" for e in report)

    def test_composite_on_episode_ok(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<EpisodeInfo>"
                f"<Parent><ID>{PARENT_ID}</ID></Parent>"
                "<EpisodeClass>Standard</EpisodeClass>"
                "</EpisodeInfo>"
                "<CompositeInfo><CompositeClass>X</CompositeClass></CompositeInfo>",
            )
        )
        report = rec.validate()
        assert not any(e.code == "content.composite_info.misplaced" for e in report)

    def test_composite_on_series_rejected(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<SeriesInfo><SeriesClass>X</SeriesClass></SeriesInfo>"
                "<CompositeInfo><CompositeClass>Y</CompositeClass></CompositeInfo>",
            )
        )
        report = rec.validate()
        assert any(e.code == "content.composite_info.misplaced" for e in report)

    def test_composite_on_edit_rejected(self) -> None:
        rec = ContentRecord.from_xml(
            _wrap(
                _minimal_valid_base(),
                "<EditInfo>"
                f"<Parent><ID>{PARENT_ID}</ID></Parent>"
                "<EditClass>default</EditClass>"
                "<EditUse>default</EditUse>"
                "</EditInfo>"
                "<CompositeInfo><CompositeClass>X</CompositeClass></CompositeInfo>",
            )
        )
        report = rec.validate()
        assert any(e.code == "content.composite_info.misplaced" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# Credit bounds (EIDR profile)
# ─────────────────────────────────────────────────────────────────────────────


class TestCreditBounds:
    def _with_credits(self, *, n_dirs: int = 0, n_actors: int = 0) -> ContentRecord:
        credits = "".join(
            f"<Director><md:DisplayName>D{i}</md:DisplayName></Director>" for i in range(n_dirs)
        ) + "".join(
            f"<Actor><md:DisplayName>A{i}</md:DisplayName></Actor>" for i in range(n_actors)
        )
        return ContentRecord.from_xml(
            _wrap(_minimal_valid_base() + f"<Credits>{credits}</Credits>")
        )

    def test_two_directors_ok(self) -> None:
        report = self._with_credits(n_dirs=2).validate()
        assert not any(e.code == "content.credits.too_many_directors" for e in report)

    def test_three_directors_rejected(self) -> None:
        report = self._with_credits(n_dirs=3).validate()
        errors = [e for e in report if e.code == "content.credits.too_many_directors"]
        assert len(errors) == 1
        assert errors[0].value == 3

    def test_four_actors_ok(self) -> None:
        report = self._with_credits(n_actors=4).validate()
        assert not any(e.code == "content.credits.too_many_actors" for e in report)

    def test_five_actors_rejected(self) -> None:
        report = self._with_credits(n_actors=5).validate()
        assert any(e.code == "content.credits.too_many_actors" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# Submission-mode-aware ID handling
# ─────────────────────────────────────────────────────────────────────────────


class TestSubmissionMode:
    def test_id_not_required_by_default(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base(with_id=False)))
        report = rec.validate()
        # No ID present, mode=None so no complaint
        assert not any(
            e.code == "content.required_field.missing" and e.path == "BaseObjectData/ID"
            for e in report
        )

    def test_modify_mode_requires_id(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base(with_id=False)))
        report = rec.validate(mode="modify")
        assert any(
            e.code == "content.required_field.missing" and e.path == "BaseObjectData/ID"
            for e in report
        )

    def test_create_mode_rejects_present_id(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base(with_id=True)))
        report = rec.validate(mode="create")
        assert any(
            e.code == "content.id.unexpected" and e.path == "BaseObjectData/ID" for e in report
        )

    def test_create_mode_without_id_ok(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base(with_id=False)))
        report = rec.validate(mode="create")
        assert not any(e.path == "BaseObjectData/ID" for e in report)

    def test_modify_mode_with_valid_id_ok(self) -> None:
        rec = ContentRecord.from_xml(_wrap(_minimal_valid_base(with_id=True)))
        report = rec.validate(mode="modify")
        assert not any(e.path == "BaseObjectData/ID" for e in report)

    def test_invalid_id_rejected_even_when_not_required(self) -> None:
        xml = _wrap("<ID>not-an-eidr-id</ID>" + _minimal_valid_base(with_id=False))
        report = ContentRecord.from_xml(xml).validate()
        assert any(e.code == "content.id.invalid" for e in report)


# ─────────────────────────────────────────────────────────────────────────────
# ValidationError record
# ─────────────────────────────────────────────────────────────────────────────


class TestValidationErrorRecord:
    def test_error_fields_populated(self) -> None:
        xml = _wrap(
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>LaserDisc</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
        )
        report = ContentRecord.from_xml(xml).validate()
        err = next(e for e in report if e.code == "content.vocabulary.invalid")
        assert err.path == "BaseObjectData/Mode"
        assert err.value == "LaserDisc"
        assert "LaserDisc" in err.message
        assert "AudioVisual" in err.message  # valid options listed

    def test_report_preserves_error_order(self) -> None:
        # Multiple problems — make sure we get all of them in sequence
        xml = _wrap(
            "<Mode>Nope</Mode><ReferentType>AlsoNope</ReferentType><ResourceName>X</ResourceName>"
        )
        report = ContentRecord.from_xml(xml).validate()
        assert len(report) >= 2  # at minimum, 2 vocabulary errors + missing fields
