"""Tests for :class:`eidr.models.party.PartyRecord`.

No real Party corpus ships with the SDK, so these tests use
hand-written fixtures derived from the XSD.
"""

from __future__ import annotations

from eidr.errors import EIDRClientError
from eidr.models import ContactInfo, OrgName, PartyRecord, Phone

PARTY_ID = "10.5237/7791-8534"  # synthetic; shape-valid for the wrapper

NS_ATTRS = (
    ' xmlns="http://www.eidr.org/schema"'
    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
)


def _wrap(inner: str) -> bytes:
    """Wrap inner XML in a <Party> root with the right namespaces."""
    return f"<Party{NS_ATTRS}>{inner}</Party>".encode()


class TestPartyRecordConstruction:
    def test_rejects_non_dict(self) -> None:
        import pytest

        with pytest.raises(EIDRClientError, match="requires a dict"):
            PartyRecord("not a dict")  # type: ignore[arg-type]

    def test_minimal_record_parses(self) -> None:
        xml = _wrap(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>Acme Studios</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>Jane Doe</Name>"
            "<PrimaryEmail>jane@acme.example</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
        )
        rec = PartyRecord.from_xml(xml)
        assert rec is not None
        assert str(rec.id) == PARTY_ID
        assert rec.active is True


class TestPartyNameAndContactAccessors:
    def _record(self, inner: str) -> PartyRecord:
        return PartyRecord.from_xml(_wrap(inner))

    def test_party_name_basic(self) -> None:
        rec = self._record(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName>"
            "<md:DisplayName>BBC Studios</md:DisplayName>"
            "<md:SortName>BBC Studios, The</md:SortName>"
            "</PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
        )
        name = rec.party_name
        assert isinstance(name, OrgName)
        assert name.display_name == "BBC Studios"
        assert name.sort_name == "BBC Studios, The"
        assert name.alternate_names == ()

    def test_party_name_with_alternates_and_org_id(self) -> None:
        rec = self._record(
            f"<ID>{PARTY_ID}</ID>"
            '<PartyName idType="DUNS" organizationID="123456789">'
            "<md:DisplayName>Beeb</md:DisplayName>"
            "<md:AlternateName>BBC</md:AlternateName>"
            "<md:AlternateName>British Broadcasting Corporation</md:AlternateName>"
            "</PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
        )
        name = rec.party_name
        assert name is not None
        assert name.display_name == "Beeb"
        assert name.alternate_names == ("BBC", "British Broadcasting Corporation")
        assert name.organization_id == "123456789"
        assert name.id_type == "DUNS"

    def test_alternate_party_names(self) -> None:
        rec = self._record(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<AlternatePartyName>X Corp</AlternatePartyName>"
            "<AlternatePartyName>Ex Group</AlternatePartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
        )
        assert rec.alternate_party_names == ["X Corp", "Ex Group"]

    def test_contact_info_all_fields(self) -> None:
        rec = self._record(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>Ops Team</Name>"
            "<PrimaryEmail>ops@acme.example</PrimaryEmail>"
            "<AlternateEmail>ops-backup@acme.example</AlternateEmail>"
            "<AlternateEmail>ops-escalation@acme.example</AlternateEmail>"
            "<Address>123 Studio Way, Burbank CA</Address>"
            '<Phone type="office">+1-555-0100</Phone>'
            '<Phone type="mobile">+1-555-0199</Phone>'
            "</ContactInfo>"
            "<Active>true</Active>"
        )
        contact = rec.contact_info
        assert isinstance(contact, ContactInfo)
        assert contact.name == "Ops Team"
        assert contact.primary_email == "ops@acme.example"
        assert contact.alternate_emails == (
            "ops-backup@acme.example",
            "ops-escalation@acme.example",
        )
        assert contact.addresses == ("123 Studio Way, Burbank CA",)
        assert len(contact.phones) == 2
        assert contact.phones[0] == Phone(number="+1-555-0100", type="office")
        assert contact.phones[1] == Phone(number="+1-555-0199", type="mobile")

    def test_contact_info_minimal(self) -> None:
        rec = self._record(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>ops</Name>"
            "<PrimaryEmail>ops@x.z</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
        )
        contact = rec.contact_info
        assert contact is not None
        assert contact.alternate_emails == ()
        assert contact.addresses == ()
        assert contact.phones == ()


class TestActiveBooleanCoercion:
    def _rec(self, active_literal: str) -> PartyRecord:
        xml = _wrap(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            f"<Active>{active_literal}</Active>"
        )
        return PartyRecord.from_xml(xml)

    def test_true_literal(self) -> None:
        assert self._rec("true").active is True

    def test_one_literal(self) -> None:
        assert self._rec("1").active is True

    def test_false_literal(self) -> None:
        assert self._rec("false").active is False

    def test_zero_literal(self) -> None:
        assert self._rec("0").active is False


class TestAllowedRoles:
    def test_empty(self) -> None:
        xml = _wrap(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
        )
        rec = PartyRecord.from_xml(xml)
        assert rec.allowed_roles == []

    def test_multiple(self) -> None:
        xml = _wrap(
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
            "<AllowedRoles>Registrant</AllowedRoles>"
            "<AllowedRoles>MetadataAuthority</AllowedRoles>"
        )
        rec = PartyRecord.from_xml(xml)
        assert rec.allowed_roles == ["Registrant", "MetadataAuthority"]


class TestPartyRoundTrip:
    def _xml(self) -> bytes:
        return _wrap(
            f"<ID>{PARTY_ID}</ID>"
            '<PartyName idType="DUNS">'
            "<md:DisplayName>Acme</md:DisplayName>"
            "<md:AlternateName>Acme Co</md:AlternateName>"
            "</PartyName>"
            "<AlternatePartyName>Acme Corp</AlternatePartyName>"
            "<ContactInfo>"
            "<Name>Ops</Name>"
            "<PrimaryEmail>ops@acme.example</PrimaryEmail>"
            '<Phone type="office">+1-555-0100</Phone>'
            "</ContactInfo>"
            "<Active>true</Active>"
            "<PartyAccountName>acme_admin</PartyAccountName>"
            "<AllowedRoles>Registrant</AllowedRoles>"
        )

    def test_xml_roundtrip(self) -> None:
        rec = PartyRecord.from_xml(self._xml())
        out = rec.to_xml(xml_declaration=False)
        rec2 = PartyRecord.from_xml(out)
        assert rec.data == rec2.data, "XML round-trip must preserve data"

    def test_json_roundtrip(self) -> None:
        rec = PartyRecord.from_xml(self._xml())
        jtext = rec.to_json()
        rec2 = PartyRecord.from_json(jtext)
        assert rec.data == rec2.data

    def test_canonical_byte_stable(self) -> None:
        rec = PartyRecord.from_xml(self._xml())
        assert rec.to_xml_canonical() == rec.to_xml_canonical()
        assert rec.to_json_canonical() == rec.to_json_canonical()

    def test_accessors_after_roundtrip(self) -> None:
        rec = PartyRecord.from_xml(self._xml())
        rec2 = PartyRecord.from_xml(rec.to_xml(xml_declaration=False))
        assert rec.id == rec2.id
        assert rec.party_name == rec2.party_name
        assert rec.contact_info == rec2.contact_info
        assert rec.allowed_roles == rec2.allowed_roles
