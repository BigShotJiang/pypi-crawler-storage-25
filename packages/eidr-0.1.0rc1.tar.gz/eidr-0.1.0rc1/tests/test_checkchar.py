"""Tests for ``eidr.models._checkchar``.

Validates the ISO 7064 Mod 37,36 check-character algorithm used by EIDR
Content IDs. Tests include:

* Worked examples from the EIDR ID Format specification.
* The worked ISAN example from the ISAN Check Characters document
  (as a sanity check of the ISO 7064 implementation, acknowledging that
  ISAN uses a 16-hex-digit input rather than EIDR's 20).
* A full sweep against 229 real EIDR Content IDs sampled from the
  Sandbox 2 registry.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from eidr.models._checkchar import (
    CHECK_CHAR_ALPHABET,
    compute_check_char,
    verify_check_char,
)

# Worked examples from EIDR ID Format v1.51 and other EIDR publications.
KNOWN_PAIRS = [
    ("F85AE100B0685B8FB1C8", "T"),  # v1.51 §3.1.1
    ("779185342C2390308610", "5"),  # "The Great Train Robbery"
    ("7481838B59CA63D0B9A8", "E"),  # v1.51 §3.7.1 filename example
    ("CA5102D0326923C9DB5A", "E"),  # v1.51 §3.5.2 URN example
    ("B17A4DAF9496C586C1F5", "9"),  # "Mr. Edison at Work..."
    ("3466F12C391AD60B206B", "Y"),  # v1.51 §3.5.2 DOI URN example
    ("1E632E9A11ABFE881B89", "M"),  # EIDR-S example
]


class TestComputeCheckChar:
    @pytest.mark.parametrize(("suffix_hex", "expected"), KNOWN_PAIRS)
    def test_known_eidr_examples(self, suffix_hex: str, expected: str) -> None:
        assert compute_check_char(suffix_hex) == expected

    def test_accepts_lowercase_hex(self) -> None:
        # The algorithm is based on hex values, not character case.
        assert compute_check_char("f85ae100b0685b8fb1c8") == "T"

    def test_rejects_wrong_length(self) -> None:
        with pytest.raises(ValueError, match="exactly 20 hex digits"):
            compute_check_char("AAAA-BBBB")  # has hyphen, wrong length
        with pytest.raises(ValueError, match="exactly 20 hex digits"):
            compute_check_char("7791853")  # too short
        with pytest.raises(ValueError, match="exactly 20 hex digits"):
            compute_check_char("779185342C2390308610AA")  # too long

    def test_rejects_non_hex(self) -> None:
        with pytest.raises(ValueError, match="non-hex"):
            compute_check_char("ZZZZZZZZZZZZZZZZZZZZ")  # Zs aren't hex

    def test_output_is_always_single_char_in_alphabet(self) -> None:
        # Sweep: every valid output must be one character in CHECK_CHAR_ALPHABET.
        for suffix_hex, _ in KNOWN_PAIRS:
            result = compute_check_char(suffix_hex)
            assert len(result) == 1
            assert result in CHECK_CHAR_ALPHABET


class TestVerifyCheckChar:
    @pytest.mark.parametrize(("suffix_hex", "check"), KNOWN_PAIRS)
    def test_accepts_valid(self, suffix_hex: str, check: str) -> None:
        assert verify_check_char(suffix_hex, check)

    def test_rejects_wrong_check(self) -> None:
        assert not verify_check_char("779185342C2390308610", "X")

    def test_case_insensitive_check(self) -> None:
        # Check character itself may be compared case-insensitively
        assert verify_check_char("779185342C2390308610", "5")
        # Lowercase-only chars: 0-9 have no case so this mostly tests A-Z
        assert verify_check_char("F85AE100B0685B8FB1C8", "t")
        assert verify_check_char("F85AE100B0685B8FB1C8", "T")

    def test_malformed_input_returns_false(self) -> None:
        # verify_check_char should not raise on bad input; it returns False.
        assert not verify_check_char("not-hex-at-all", "5")
        assert not verify_check_char("", "5")


class TestBulkSampleValidation:
    """Run the algorithm against the full 229-record real-ID sample."""

    def test_all_229_sample_ids_pass(self) -> None:
        sample_file = Path(__file__).parent / "fixtures" / "random_ids.txt"
        if not sample_file.exists():
            pytest.skip(f"Sample file not found: {sample_file}")

        failures = []
        total = 0
        for line in sample_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            total += 1
            # Parse the canonical form: 10.5240/XXXX-XXXX-XXXX-XXXX-XXXX-C
            suffix_with_check = line.split("/", 1)[1]
            parts = suffix_with_check.split("-")
            if len(parts) != 6:
                failures.append((line, "malformed line"))
                continue
            suffix_hex = "".join(parts[:5])
            expected = parts[5]
            computed = compute_check_char(suffix_hex)
            if computed != expected:
                failures.append((line, f"expected {expected}, computed {computed}"))

        assert not failures, (
            f"{len(failures)} of {total} sample IDs failed check-char validation. "
            f"First 3: {failures[:3]}"
        )
        assert total > 200, f"Sample file too small: {total} records"


class TestISANCompatibility:
    """The ISAN doc's worked example uses a 16-hex-digit input.

    The procedure is identical except for input length. We test it here
    by extending the algorithm to accept variable length as a unit-level
    verification that our ISO 7064 implementation matches the ISAN doc
    exactly. (The public ``compute_check_char`` rejects non-20-digit
    input because EIDR Content IDs are always 20 hex digits.)
    """

    def test_isan_worked_example_is_consistent(self) -> None:
        # From the ISAN doc: B159D8FA01240000 → K (value 20)
        # We can't call compute_check_char directly because it enforces 20 digits.
        # Instead, pad left with zeros to 20 digits and verify the pad does NOT
        # change the final check char...  Actually that's not a valid trick
        # because the pre-carry algorithm is sensitive to all input. So we
        # import the algorithm directly and run it with a 16-digit input.
        from eidr.models._checkchar import _hex_value

        suffix = "B159D8FA01240000"
        carry = 36
        for ch in suffix:
            d = _hex_value(ch)
            intermediate = carry + d
            ais = intermediate - 36 if intermediate >= 36 else intermediate
            if ais == 0:
                ais = 36
            product = ais * 2
            carry = product - 37 if product >= 37 else product
        check_value = 0 if carry == 1 else 37 - carry
        assert CHECK_CHAR_ALPHABET[check_value] == "K"


class TestAgainstReferenceImplementation:
    """Cross-validate against ``python-stdnum``'s Mod 37,36 implementation.

    ``python-stdnum`` is an independent, widely-deployed identifier-validation
    library with its own Mod 37,36 implementation. If our implementation
    and theirs ever disagree on *any* input, that is a serious bug on at
    least one side and we want to know immediately.

    This test is skipped when ``python-stdnum`` is not installed, so CI
    without the reference dep still passes. Developers can install it via::

        pip install python-stdnum
    """

    def test_matches_stdnum_on_sample(self) -> None:
        stdnum = pytest.importorskip("stdnum.iso7064.mod_37_36")

        sample_file = Path(__file__).parent / "fixtures" / "random_ids.txt"
        if not sample_file.exists():
            pytest.skip(f"Sample file not found: {sample_file}")

        mismatches = []
        for line in sample_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            suffix_hex = line.split("/", 1)[1].replace("-", "")[:-1]
            ours = compute_check_char(suffix_hex)
            theirs = stdnum.calc_check_digit(suffix_hex)
            if ours != theirs:
                mismatches.append((line, ours, theirs))

        assert not mismatches, (
            f"{len(mismatches)} disagreement(s) between our impl and python-stdnum. "
            f"First 3: {mismatches[:3]}"
        )

    @pytest.mark.parametrize(("suffix_hex", "expected"), KNOWN_PAIRS)
    def test_matches_stdnum_on_known_pairs(self, suffix_hex: str, expected: str) -> None:
        stdnum = pytest.importorskip("stdnum.iso7064.mod_37_36")
        assert compute_check_char(suffix_hex) == stdnum.calc_check_digit(suffix_hex)
