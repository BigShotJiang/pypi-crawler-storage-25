"""Tests for the M8 typed Digital sub-model.

Covers:

* Round-trip equality (typed → dict → typed → dict)
* Realistic wire-format dict → typed parsing (the shape an EIDR
  resolve response actually produces)
* The :class:`ManifestationInfo` ``digital_typed`` / ``set_digital``
  bridge
* Opt-in import behavior — the module raises a friendly
  :class:`ModuleNotFoundError` if pydantic isn't installed
* Sanity checks on the generated module's class count, so a future
  regeneration that accidentally drops types fails the test
* The ``[digital]`` extra's :class:`SchemaSource` plumbing

These tests assume pydantic is available — they're skipped if the
``[digital]`` extra is not installed.
"""

from __future__ import annotations

import pytest

# Skip the entire module if pydantic isn't available — matches the
# opt-in-extra contract documented on :mod:`eidr.models.digital`.
pytest.importorskip("pydantic")
pytest.importorskip("xsdata_pydantic")

from eidr.models import _digital_generated as _gen
from eidr.models._digital_codec import (
    codec_dict_to_digital_tracks,
    digital_tracks_to_codec_dict,
)
from eidr.models.digital import (
    Container,
    DigitalAssetAudio,
    DigitalAssetVideo,
    DigitalTracks,
    Track,
)

# ─── Generated module sanity checks ─────────────────────────────────────────


class TestGeneratedModuleSanity:
    """Spot-checks on the generated module to catch regen mishaps.

    A future ``tools/generate_digital.py`` run that accidentally
    targets the wrong schema (or hits an xsdata bug) might silently
    produce a much smaller output. These tests fail loudly if that
    happens, before downstream tests start mysteriously failing on
    missing types.
    """

    def test_class_count_in_expected_range(self) -> None:
        """The generated module should have ~290 classes. A drop
        below 200 means generation lost something major."""
        class_count = sum(
            1 for k in dir(_gen) if not k.startswith("_") and isinstance(getattr(_gen, k), type)
        )
        assert class_count >= 200, (
            f"Generated module has only {class_count} classes; "
            f"expected ~290. Did the generator target the wrong "
            f"schema entry point?"
        )

    def test_critical_types_present(self) -> None:
        """The headline types the SDK relies on must exist."""
        for name in (
            "DigitalTracksType",
            "DigitalAssetMetadataType",
            "ContainerMetadataType",
            "DigitalAssetAudioDataType",
            "DigitalAssetVideoDataType",
            "DigitalAssetSubtitleDataType",
            "DigitalAssetImageDataType",
            "DigitalAssetInteractiveDataType",
            "DigitalAssetAncillaryDataType",
        ):
            assert hasattr(_gen, name), f"missing generated type {name!r}"

    def test_aliases_match_generated_classes(self) -> None:
        """The curated aliases in :mod:`eidr.models.digital` must be
        exact-identity references to the underlying generated
        classes — not subclasses, not wrappers."""
        assert DigitalTracks is _gen.DigitalTracksType
        assert Track is _gen.DigitalAssetMetadataType
        assert Container is _gen.ContainerMetadataType
        assert DigitalAssetAudio is _gen.DigitalAssetAudioDataType
        assert DigitalAssetVideo is _gen.DigitalAssetVideoDataType


# ─── Direct construction & XML round-trip ──────────────────────────────────


def _make_audio_track() -> DigitalAssetMetadataType:  # noqa: F821
    """Helper: build a minimal-but-valid audio track."""
    audio = DigitalAssetAudio(
        type_value="primary",
        language=_gen.DigitalAssetAudioLanguageType(value="en"),
    )
    return Track(choice=audio)


class TestDirectConstruction:
    """Building typed instances directly. Verifies the generated
    schema's required-vs-optional contract is intact and that
    ``arbitrary_types_allowed=True`` was correctly applied (without
    it, instantiation fails on the xsdata custom types)."""

    def test_minimal_audio_track_constructs(self) -> None:
        track = _make_audio_track()
        assert isinstance(track, Track)
        assert isinstance(track.choice, DigitalAssetAudio)
        assert track.choice.language is not None
        assert track.choice.language.value == "en"

    def test_audio_requires_language(self) -> None:
        """Per the schema, an audio asset must have a Language
        element. Constructing one without it should raise a
        pydantic :class:`ValidationError` at the construction
        site, not at submission time."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError, match="language"):
            DigitalAssetAudio(type_value="primary")  # type: ignore[call-arg]

    def test_strict_typing_on_non_xsdata_classes(self) -> None:
        """Reviewer #1 #7 / Reviewer #2: the codegen narrows
        ``arbitrary_types_allowed=True`` to classes that
        transitively use xsdata custom types
        (:class:`XmlDuration`, :class:`XmlDate`, etc.). Classes
        without those types — the bulk of the tree — keep strict
        pydantic typing.

        This test verifies that strict typing is intact on a class
        that doesn't touch xsdata custom types. Assigning a wholly
        wrong Python type (a list to a string field) should raise
        :class:`ValidationError`.
        """
        from pydantic import ValidationError

        # ``DigitalAssetAudioLanguageType.value`` is a plain
        # ``str``. A list-of-int is wrong.
        with pytest.raises(ValidationError):
            _gen.DigitalAssetAudioLanguageType(value=[1, 2, 3])  # type: ignore[arg-type]

    def test_strict_typing_on_audio_data(self) -> None:
        """Same regression check on a different class. The
        ``language`` field on audio data is typed as
        :class:`DigitalAssetAudioLanguageType` — assigning a raw
        string should be rejected."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            DigitalAssetAudio(
                type_value="primary",
                language="en",  # should be DigitalAssetAudioLanguageType, not str
            )

    def test_xsdata_custom_types_classes_have_relaxed_config(self) -> None:
        """The codegen patches ``arbitrary_types_allowed=True`` on
        classes that mention :class:`XmlDuration` etc. Sanity-check
        that the patch is in place where we need it.

        We pick :class:`AudienceType` (top-level, references xsdata
        custom date types in its body) — but the test is robust to
        the specific class name changing across regenerations.
        """
        # Find any top-level class with the relaxation; if none
        # exists, that's a regression in the codegen — every
        # generated module should have at least the date/time
        # carrier types.
        relaxed = [
            name
            for name in dir(_gen)
            if not name.startswith("_")
            and isinstance(getattr(_gen, name), type)
            and getattr(getattr(_gen, name), "model_config", {}).get("arbitrary_types_allowed")
            is True
        ]
        assert relaxed, (
            "No generated classes have arbitrary_types_allowed=True. "
            "The codegen narrowing should still patch ~40 classes "
            "that use XmlDuration/XmlDate/etc. Did the generator "
            "regress?"
        )

    def test_non_xsdata_classes_have_strict_config(self) -> None:
        """The narrowing means most classes do NOT have
        ``arbitrary_types_allowed=True``. Spot-check a class that
        doesn't use any xsdata custom types."""
        cfg = _gen.DigitalAssetAudioLanguageType.model_config
        assert cfg.get("arbitrary_types_allowed") is not True

    def test_digital_tracks_with_multiple_track_kinds(self) -> None:
        """Track and Container are flat-listed in the same field."""
        audio_track = _make_audio_track()
        container = Container(type_value="MP4")
        tracks = DigitalTracks(track_or_container=[audio_track, container])
        assert len(tracks.track_or_container) == 2

    def test_empty_digital_tracks_is_legal(self) -> None:
        """The schema allows zero Track/Container children."""
        tracks = DigitalTracks()
        assert tracks.track_or_container == []


# ─── Codec-dict ↔ typed round-trip ─────────────────────────────────────────


class TestCodecDictRoundTrip:
    """The whole point of the M8 bridge: codec dicts and typed
    instances are convertible without loss for valid inputs."""

    def test_typed_to_dict_to_typed(self) -> None:
        """typed → dict → typed produces an equal typed instance."""
        original = DigitalTracks(track_or_container=[_make_audio_track()])
        as_dict = digital_tracks_to_codec_dict(original)
        roundtripped = codec_dict_to_digital_tracks(as_dict, DigitalTracks)
        assert original == roundtripped

    def test_typed_to_dict_to_typed_to_dict(self) -> None:
        """The dict-form survives an additional round-trip identical."""
        original = DigitalTracks(track_or_container=[_make_audio_track()])
        d1 = digital_tracks_to_codec_dict(original)
        typed_back = codec_dict_to_digital_tracks(d1, DigitalTracks)
        d2 = digital_tracks_to_codec_dict(typed_back)
        assert d1 == d2

    def test_realistic_wire_dict_parses(self) -> None:
        """A codec dict in the prefix shape an EIDR resolve
        response produces (default-namespace EIDR, ``md:`` prefix
        for MovieLabs children) parses correctly. This is what
        :meth:`ManifestationInfo.digital_typed` will see in
        production."""
        wire_dict = {
            "_xmlns": "http://www.eidr.org/schema",
            "_xmlns:md": "http://www.movielabs.com/schema/md/v2.8/md",
            "Track": [
                {
                    "md:Audio": [
                        {
                            "md:Type": ["primary"],
                            "md:Language": ["en"],
                        }
                    ]
                }
            ],
        }
        typed = codec_dict_to_digital_tracks(wire_dict, DigitalTracks)
        assert len(typed.track_or_container) == 1
        track = typed.track_or_container[0]
        assert isinstance(track, Track)
        assert isinstance(track.choice, DigitalAssetAudio)
        assert track.choice.language is not None
        assert track.choice.language.value == "en"

    def test_empty_dict_produces_empty_tracks(self) -> None:
        empty_dict: dict = {}
        typed = codec_dict_to_digital_tracks(empty_dict, DigitalTracks)
        assert isinstance(typed, DigitalTracks)
        assert typed.track_or_container == []


# ─── ManifestationInfo bridge ──────────────────────────────────────────────


class TestManifestationInfoBridge:
    """The user-facing bridge — :meth:`ManifestationInfo.digital_typed`
    and :meth:`set_digital`. These are the entry points most callers
    will use."""

    def _make_manifestation_record_xml(self, *, with_digital: bool) -> bytes:
        """Construct a minimal ManifestationInfo record.

        Crucially, the ``ManifestationInfo`` block lives under
        ``<ExtraObjectMetadata>``, not as a direct sibling of
        ``<BaseObjectData>`` — that's how the wire format places
        creation blocks. The SDK's ``creation_block`` accessor
        reads from there.
        """
        digital = ""
        if with_digital:
            digital = (
                "<Digital>"
                "<Track>"
                "<md:Audio>"
                "<md:Type>primary</md:Type>"
                "<md:Language>en</md:Language>"
                "</md:Audio>"
                "</Track>"
                "</Digital>"
            )
        return (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<FullMetadata xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<BaseObjectData>"
            "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Manifestation</ReferentType>"
            "<ResourceName>Test Manifestation</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            "<Administrators><Registrant>10.5237/FFDA-9947</Registrant>"
            "</Administrators>"
            "</BaseObjectData>"
            "<ExtraObjectMetadata>"
            "<ManifestationInfo>"
            "<Parent>"
            "<ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID>"
            "<RelationshipType>IsManifestationOf</RelationshipType>"
            "</Parent>"
            "<ManifestationClass>HD</ManifestationClass>"
            f"{digital}"
            "</ManifestationInfo>"
            "</ExtraObjectMetadata>"
            "</FullMetadata>"
        ).encode()

    def test_digital_typed_returns_none_when_absent(self) -> None:
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=False))
        manifest = rec.creation_block
        assert manifest is not None
        assert manifest.digital_typed() is None  # type: ignore[union-attr]

    def test_digital_typed_returns_typed_when_present(self) -> None:
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=True))
        manifest = rec.creation_block
        assert manifest is not None
        typed = manifest.digital_typed()  # type: ignore[union-attr]
        assert isinstance(typed, DigitalTracks)
        assert len(typed.track_or_container) == 1

    def test_set_digital_writes_typed_to_dict(self) -> None:
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=False))
        manifest = rec.creation_block
        assert manifest is not None
        new_tracks = DigitalTracks(track_or_container=[_make_audio_track()])
        manifest.set_digital(new_tracks)  # type: ignore[union-attr]

        # Round-trip back: the dict should contain a Digital block now.
        assert manifest.digital is not None  # type: ignore[union-attr]
        # And the typed view of the modified record should equal what
        # we set.
        typed_again = manifest.digital_typed()  # type: ignore[union-attr]
        assert typed_again == new_tracks

    def test_set_digital_none_clears(self) -> None:
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=True))
        manifest = rec.creation_block
        assert manifest is not None
        manifest.set_digital(None)  # type: ignore[union-attr]
        assert manifest.digital is None  # type: ignore[union-attr]
        assert manifest.digital_typed() is None  # type: ignore[union-attr]

    def test_set_digital_rejects_raw_dict(self) -> None:
        """The strict type-check on ``set_digital`` blocks raw dicts.
        Callers wanting that path can mutate ``record.data`` directly."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=False))
        manifest = rec.creation_block
        assert manifest is not None
        with pytest.raises(TypeError, match="DigitalTracks or None"):
            manifest.set_digital({"Track": []})  # type: ignore[union-attr,arg-type]

    def test_typed_view_is_transient(self) -> None:
        """Mutations on a typed view do *not* propagate to the
        underlying dict unless ``set_digital`` is called explicitly.
        This is the design contract for the transient-view pattern."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(self._make_manifestation_record_xml(with_digital=True))
        manifest = rec.creation_block
        assert manifest is not None
        typed_v1 = manifest.digital_typed()  # type: ignore[union-attr]
        assert isinstance(typed_v1, DigitalTracks)
        original_track_count = len(typed_v1.track_or_container)

        # Mutate the typed view (without calling set_digital)
        typed_v1.track_or_container.append(_make_audio_track())
        assert len(typed_v1.track_or_container) == original_track_count + 1

        # Fetch a fresh typed view; it shouldn't reflect the mutation
        typed_v2 = manifest.digital_typed()  # type: ignore[union-attr]
        assert isinstance(typed_v2, DigitalTracks)
        assert len(typed_v2.track_or_container) == original_track_count


# ─── Real-Manifestation round-trip fixture ─────────────────────────────────


# A realistic resolved-Manifestation XML carrying a multi-track
# ``<Digital>`` block. Built to look like what an EIDR Sandbox
# resolve actually returns for a Manifestation: default-namespace
# EIDR with ``md:`` prefix for MovieLabs MD types, multiple
# ``<Track>`` elements with different choice content, and a
# ``<Container>`` element with packaging metadata.
#
# This is the highest-leverage test we have: any regression in
# parsing, in the typed bridge, in prefix handling, or in
# wire-format serialization will fail this test before more
# narrow tests catch it.
_REAL_MANIFESTATION_XML = (
    b'<?xml version="1.0" encoding="UTF-8"?>'
    b'<FullMetadata xmlns="http://www.eidr.org/schema" '
    b'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
    b"<BaseObjectData>"
    b"<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
    b"<StructuralType>Performance</StructuralType>"
    b"<Mode>AudioVisual</Mode>"
    b"<ReferentType>Manifestation</ReferentType>"
    b"<ResourceName>Realistic Manifestation</ResourceName>"
    b"<OriginalLanguage>en</OriginalLanguage>"
    b"<Status>valid</Status>"
    b"<Administrators><Registrant>10.5237/FFDA-9947</Registrant>"
    b"</Administrators>"
    b"</BaseObjectData>"
    b"<ExtraObjectMetadata>"
    b"<ManifestationInfo>"
    b"<Parent>"
    b"<ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-I</ID>"
    b"<RelationshipType>IsManifestationOf</RelationshipType>"
    b"</Parent>"
    b"<ManifestationClass>HD</ManifestationClass>"
    b"<Digital>"
    # Audio track (English primary)
    b"<Track>"
    b"<md:Audio>"
    b"<md:Type>primary</md:Type>"
    b"<md:Language>en</md:Language>"
    b"</md:Audio>"
    b"</Track>"
    # Audio track (Spanish dub)
    b"<Track>"
    b"<md:Audio>"
    b"<md:Type>primary</md:Type>"
    b"<md:Language dubbed='true'>es</md:Language>"
    b"</md:Audio>"
    b"</Track>"
    # Subtitle track
    b"<Track>"
    b"<md:Subtitle>"
    b"<md:Type>normal</md:Type>"
    b"<md:Language>en</md:Language>"
    b"</md:Subtitle>"
    b"</Track>"
    b"</Digital>"
    b"</ManifestationInfo>"
    b"</ExtraObjectMetadata>"
    b"</FullMetadata>"
)


class TestRealManifestationRoundTrip:
    """The strongest M8 round-trip test: parse a realistic resolved
    record, walk through the typed bridge, write back, and serialize
    to wire XML. Prefix handling must not pollute output (no
    ``ns0:`` / ``ns1:`` leakage from xsdata's auto-generated
    prefixes).
    """

    def test_resolve_to_typed_round_trip(self) -> None:
        """Read path: realistic XML → ContentRecord → typed view.
        Verify all three track types are visible at the typed level."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(_REAL_MANIFESTATION_XML)
        manifest = rec.creation_block
        assert manifest is not None
        typed = manifest.digital_typed()  # type: ignore[union-attr]
        assert isinstance(typed, DigitalTracks)

        # Three Track entries (two audio, one subtitle)
        assert len(typed.track_or_container) == 3

        from eidr.models import _digital_generated as gen

        # First two: Audio Tracks
        assert isinstance(typed.track_or_container[0], Track)
        assert isinstance(
            typed.track_or_container[0].choice,
            gen.DigitalAssetAudioDataType,
        )
        assert typed.track_or_container[0].choice.language.value == "en"
        assert isinstance(typed.track_or_container[1], Track)
        spanish_audio = typed.track_or_container[1].choice
        assert spanish_audio.language.value == "es"
        assert spanish_audio.language.dubbed is True

        # Third: Subtitle Track
        assert isinstance(
            typed.track_or_container[2].choice,
            gen.DigitalAssetSubtitleDataType,
        )

    def test_set_digital_preserves_wire_format_prefixes(self) -> None:
        """After ``set_digital(typed)``, the underlying codec dict
        must use wire-format prefixes (``Track`` not ``ns0:Track``,
        ``md:Audio`` not ``ns1:Audio``). Re-serializing the whole
        record to XML must not leak xsdata's ``nsN:`` prefixes."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(_REAL_MANIFESTATION_XML)
        manifest = rec.creation_block
        assert manifest is not None

        # Read typed, modify (drop the Spanish dub track), set back.
        typed = manifest.digital_typed()
        assert isinstance(typed, DigitalTracks)
        modified = DigitalTracks(
            track_or_container=[
                typed.track_or_container[0],  # English audio
                typed.track_or_container[2],  # English subtitle
            ]
        )
        manifest.set_digital(modified)

        # The codec dict for the Digital block must NOT contain
        # xsdata's ns0/ns1 prefixes.
        digital_dict = manifest.digital
        assert digital_dict is not None
        flat = repr(digital_dict)
        assert "ns0:" not in flat, f"xsdata's ns0: prefix leaked into codec dict: {flat!r}"
        assert "ns1:" not in flat, f"xsdata's ns1: prefix leaked into codec dict: {flat!r}"
        assert "_xmlns:ns0" not in flat
        assert "_xmlns:ns1" not in flat

        # Wire-format prefixes are present
        assert "Track" in flat
        assert "md:Audio" in flat or "md:Subtitle" in flat

    def test_full_record_serializes_to_clean_xml(self) -> None:
        """The whole record (BaseObjectData + ExtraObjectMetadata
        + the modified Digital block) must serialize back to XML
        without ``ns0:`` / ``ns1:`` prefixes appearing anywhere
        in the output bytes. End-to-end wire-format guarantee
        callers depend on for re-submission."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(_REAL_MANIFESTATION_XML)
        manifest = rec.creation_block
        assert manifest is not None

        # Round-trip: read typed, set the same content back
        typed = manifest.digital_typed()
        manifest.set_digital(typed)

        # Serialize the whole record back to XML
        xml_out = rec.to_xml()
        as_text = xml_out.decode("utf-8")

        # The wire output must use the EIDR-record dialect,
        # not xsdata's auto-generated prefix scheme.
        assert "ns0:" not in as_text, f"xsdata's ns0: leaked into wire XML: {as_text}"
        assert "ns1:" not in as_text, f"xsdata's ns1: leaked into wire XML: {as_text}"

        # The round-tripped record's typed view must equal the
        # original typed view — full bidirectional fidelity.
        rec2 = ContentRecord.from_xml(xml_out)
        manifest2 = rec2.creation_block
        assert manifest2 is not None
        typed2 = manifest2.digital_typed()
        assert typed == typed2

    def test_modify_typed_persists_through_full_round_trip(self) -> None:
        """The full lifecycle: parse → typed → mutate → set_digital
        → serialize → re-parse → typed. The mutation must be
        visible in the final typed view."""
        from eidr.models.content import ContentRecord

        rec = ContentRecord.from_xml(_REAL_MANIFESTATION_XML)
        manifest = rec.creation_block
        assert manifest is not None

        # Drop everything but the first audio track
        typed = manifest.digital_typed()
        assert isinstance(typed, DigitalTracks)
        first_audio_only = DigitalTracks(track_or_container=[typed.track_or_container[0]])
        manifest.set_digital(first_audio_only)

        # Full XML round-trip
        xml_out = rec.to_xml()
        rec2 = ContentRecord.from_xml(xml_out)
        manifest2 = rec2.creation_block
        assert manifest2 is not None
        typed2 = manifest2.digital_typed()

        # Final typed view should have exactly one entry
        assert isinstance(typed2, DigitalTracks)
        assert len(typed2.track_or_container) == 1
        from eidr.models import _digital_generated as gen

        only = typed2.track_or_container[0]
        assert isinstance(only, Track)
        assert isinstance(only.choice, gen.DigitalAssetAudioDataType)
        assert only.choice.language.value == "en"
