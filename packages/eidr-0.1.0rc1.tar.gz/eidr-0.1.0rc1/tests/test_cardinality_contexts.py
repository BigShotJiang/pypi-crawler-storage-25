"""Regression fixtures for cardinality context-ambiguity cases.

Many qualified names in the EIDR/MovieLabs schemas appear in multiple
XSD complex types with *different* ``maxOccurs`` declarations.
The harvester in :mod:`tools.harvest_cardinality` resolves the
ambiguity by distinguishing *record-level* contexts from *transport/response-wrapper*
contexts (``queryResultsType``, ``responseType``, etc.): a name is
treated as multi iff it is declared multi in any record-level context.

This test module pins the current behavior for the known ambiguous
names. If a future schema change or harvester refactor flips any of
these, the tests fire — forcing a deliberate review of what the new
behavior should be rather than a silent regression.

The ambiguous names documented by the harvester at time of writing:

* ``ID`` — multi in ``queryResultsType`` (transport); singleton in 30+
  record-level types including ``BaseObjectData``.
* ``Status`` — multi in ``reportQueryType`` (transport); singleton in
  ``provenanceInfoType`` and elsewhere.
* ``ReferentType`` — multi in ``reportQueryType``; singleton in
  ``simpleInfoType`` and ``BaseObjectData``.
* ``StructuralType`` — multi in ``reportQueryType``; singleton in
  ``simpleInfoType`` and ``BaseObjectData``.
* ``Token`` — multi in ``tokenCancellationRequestType``; singleton in
  ``operationStatusType``.
* ``UserID`` — multi in ``userDOIListType``; singleton in
  ``requestStatusType``.
* ``Party`` / ``Service`` — multi in query-result types; singleton
  when embedded elsewhere.
* ``AlternateID`` — multi in ``alternateIDsType`` and
  ``BaseObjectData``; singleton inside a single linked-alt-ID wrapper.
  (Record-level multi wins.)

The tests below exercise the record-level interpretation (which is
what SDK users care about when parsing actual metadata records)
rather than the transport-level interpretation.
"""

from __future__ import annotations

import pytest

from eidr.codecs import EIDR_MULTI_QUALIFIED
from eidr.codecs import xml as xml_codec

EIDR_NS = "http://www.eidr.org/schema"
MD_NS = "http://www.movielabs.com/schema/md/v2.8/md"


class TestRecordLevelSingletonNames:
    """Names that are multi in transport contexts must remain singleton
    at the record level. These are the names that caused real bugs
    before the context filter was added.
    """

    @pytest.mark.parametrize(
        "local_name",
        [
            "ID",
            "Status",
            "ReferentType",
            "StructuralType",
            "Token",
            "UserID",
            "Party",
            "Service",
            "Mode",
            "ResourceName",
        ],
    )
    def test_not_in_multi_qualified_for_eidr_ns(self, local_name: str) -> None:
        """The record-level cardinality map must NOT flag these as multi.

        This guards against a harvester change where we forgot to filter
        transport contexts, which would silently wrap singleton fields
        into arrays in JSON output.
        """
        assert (EIDR_NS, local_name) not in EIDR_MULTI_QUALIFIED, (
            f"({local_name!r}) must be singleton at record level; if the "
            "schema actually changed, update the harvester's "
            "TRANSPORT_CONTEXT_TYPES list rather than flipping this test."
        )


class TestRecordLevelMultiNames:
    """Names that are record-level multi must remain multi."""

    @pytest.mark.parametrize(
        "local_name",
        [
            "AlternateID",
            "AlternateResourceName",
            "AssociatedOrg",
            "CountryOfOrigin",
            "OriginalLanguage",
            "VersionLanguage",
            "Actor",
            "Director",
            "EditClass",
            "ManifestationClass",
            "PackagingInfo",
            "PromotionInfo",
            "SupplementalContentInfo",
            "AlternateContentInfo",
        ],
    )
    def test_in_multi_qualified_for_eidr_ns(self, local_name: str) -> None:
        assert (EIDR_NS, local_name) in EIDR_MULTI_QUALIFIED, (
            f"({local_name!r}) must be multi at record level; field-multiplicity "
            "regressions break JSON encoding in user code."
        )

    @pytest.mark.parametrize(
        "local_name",
        [
            "Track",
            "Audio",
            "Video",
            "People",
            "Job",
        ],
    )
    def test_md_namespace_multi(self, local_name: str) -> None:
        assert (MD_NS, local_name) in EIDR_MULTI_QUALIFIED


class TestCodecHonorsContextInterpretation:
    """End-to-end: parsing a record-shaped document produces a scalar
    for names that are transport-level-multi-but-record-level-singleton."""

    def test_id_emits_as_scalar_in_record(self) -> None:
        """A <BaseObjectData> record has a single <ID>; it must parse as a string,
        not as a one-element list — the original bug that motivated the
        context-aware cardinality harvester."""
        xml = (
            f'<FullMetadata xmlns="{EIDR_NS}">'
            "<BaseObjectData>"
            "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
            "<ReferentType>Movie</ReferentType>"
            "<Status>valid</Status>"
            "</BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        cd = xml_codec.to_codec_dict(xml)
        bod = cd["FullMetadata"]["BaseObjectData"]  # type: ignore[index,call-overload]
        # All three should be bare strings, not single-element lists
        assert isinstance(bod["ID"], str), f"ID should be scalar, got {type(bod['ID'])}"
        assert isinstance(bod["ReferentType"], str), (
            f"ReferentType should be scalar, got {type(bod['ReferentType'])}"
        )
        assert isinstance(bod["Status"], str), f"Status should be scalar, got {type(bod['Status'])}"

    def test_alternate_id_emits_as_list_even_when_single(self) -> None:
        """The inverse — AlternateID must always be a list even with one entry."""
        xml = (
            f'<FullMetadata xmlns="{EIDR_NS}">'
            "<BaseObjectData>"
            "<AlternateID>10/abc</AlternateID>"
            "</BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        cd = xml_codec.to_codec_dict(xml)
        bod = cd["FullMetadata"]["BaseObjectData"]  # type: ignore[index,call-overload]
        assert isinstance(bod["AlternateID"], list)
        assert len(bod["AlternateID"]) == 1

    def test_md_track_emits_as_list_even_when_single(self) -> None:
        """md:Track is declared multi in the MovieLabs MD v2.8 schema."""
        xml = (
            f'<Container xmlns="{EIDR_NS}" xmlns:md="{MD_NS}">'
            "<md:Track>only one</md:Track>"
            "</Container>"
        ).encode()
        cd = xml_codec.to_codec_dict(xml)
        assert isinstance(cd["Container"]["md:Track"], list)  # type: ignore[index,call-overload]
