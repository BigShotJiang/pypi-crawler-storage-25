"""Tests for :class:`eidr.client.OperationResult`.

Covers the structured-view factory (envelope shapes the registry
emits in practice), the convenience properties, and
``Token.operation_result()`` polling behaviour.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import (
    Client,
    OperationResult,
    Token,
    TokenStatus,
)
from eidr.client._http import TransportConfig
from eidr.client._operation_result import operation_result_from
from eidr.client._response import parse_response
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test",
)
CREDS = Credentials(user_id="10.5238/x", party_id="10.5237/FFDA-9947", password="x")
NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


# ─── operation_result_from ──────────────────────────────────────────────────


class TestOperationResultFromEnvelope:
    """The factory builds OperationResult from various envelope shapes."""

    def test_bare_success_envelope(self) -> None:
        # Delete/promote/alias return only a Status.
        body = f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
        parsed = parse_response(body, operation="delete x")
        result = operation_result_from(parsed)
        assert result.status is TokenStatus.SUCCESS
        assert result.ids == []
        assert result.id is None
        assert result.record is None
        assert result.sub_tokens == []
        assert result.raw_response is parsed

    def test_envelope_with_top_level_id(self) -> None:
        # Some immediate registers carry the new ID at the envelope root.
        body = (
            f"<Response {NS}>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
            "</Response>"
        )
        parsed = parse_response(body, operation="register x")
        result = operation_result_from(parsed)
        assert result.ids == ["10.5240/0000-02ED-1DCE-6AAF-99F7-M"]
        assert result.id == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"

    def test_envelope_with_per_operation_ids(self) -> None:
        # A multi-op batch status response. Two completed operations,
        # each with its own ID.
        body = (
            f"<Response {NS}>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<RequestStatusResults>"
            "<OperationStatus>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
            "</OperationStatus>"
            "<OperationStatus>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<ID>10.5240/0000-043A-FEBE-F925-2E1C-7</ID>"
            "</OperationStatus>"
            "</RequestStatusResults>"
            "</Response>"
        )
        parsed = parse_response(body, operation="batch")
        result = operation_result_from(parsed)
        assert result.ids == [
            "10.5240/0000-02ED-1DCE-6AAF-99F7-M",
            "10.5240/0000-043A-FEBE-F925-2E1C-7",
        ]
        assert result.id == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"

    def test_envelope_with_sub_tokens(self) -> None:
        # Pending sub-operations carry tokens, not IDs yet.
        body = (
            f"<Response {NS}>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<RequestStatusResults>"
            "<OperationStatus>"
            "<Token>sub-tok-A</Token>"
            "<Status><Code>2</Code><Type>pending</Type></Status>"
            "</OperationStatus>"
            "<OperationStatus>"
            "<Token>sub-tok-B</Token>"
            "<Status><Code>2</Code><Type>pending</Type></Status>"
            "</OperationStatus>"
            "</RequestStatusResults>"
            "</Response>"
        )
        parsed = parse_response(body, operation="batch")
        result = operation_result_from(parsed)
        assert result.sub_tokens == ["sub-tok-A", "sub-tok-B"]
        assert result.ids == []

    def test_inline_record_passed_through(self) -> None:
        # The factory accepts a ContentRecord echoed by an immediate
        # register/modify and stores it on the result.
        from eidr.models.content import ContentRecord

        body = f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
        parsed = parse_response(body, operation="register x")
        rec = ContentRecord.from_xml(
            (
                f"<FullMetadata {NS}>"
                "<BaseObjectData>"
                "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
                "<StructuralType>Abstraction</StructuralType>"
                "<Mode>AudioVisual</Mode>"
                "<ReferentType>Movie</ReferentType>"
                "<ResourceName>Test</ResourceName>"
                "<OriginalLanguage>en</OriginalLanguage>"
                "<Status>valid</Status>"
                "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
                "</BaseObjectData>"
                "</FullMetadata>"
            ).encode()
        )
        result = operation_result_from(parsed, record=rec)
        assert result.record is rec
        assert result.record.resource_name == "Test"

    def test_failure_status_passed_through(self) -> None:
        body = f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
        parsed = parse_response(body, operation="x")
        result = operation_result_from(parsed, status=TokenStatus.FAILURE)
        assert result.status is TokenStatus.FAILURE


# ─── Token.operation_result() ───────────────────────────────────────────────


class TestTokenOperationResult:
    """Token.operation_result() runs polling and returns OperationResult."""

    def test_resolved_success_returns_ids(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<RequestStatusResults>"
                    "<OperationStatus>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        with _make_client(handler) as client:
            tok = Token(value="my-tok", _client=client)
            result = tok.operation_result(timeout=1.0)
        assert isinstance(result, OperationResult)
        assert result.status is TokenStatus.SUCCESS
        assert result.id == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"
        # One call to status_lookup.
        assert attempts[0] >= 1

    def test_pending_timeout_returns_pending_result(self) -> None:
        # Status-lookup always returns pending; operation_result()
        # should yield a PENDING OperationResult, not raise.
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<RequestStatusResults>"
                    "<OperationStatus>"
                    "<Token>still-pending</Token>"
                    "<Status><Code>2</Code><Type>pending</Type></Status>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        with _make_client(handler) as client:
            tok = Token(value="my-tok", _client=client)
            result = tok.operation_result(timeout=0.05)
        assert result.status is TokenStatus.PENDING
        # The pending sub-token is surfaced for follow-up polling.
        assert result.sub_tokens == ["still-pending"]

    def test_unpolled_token_timeout_raises(self) -> None:
        # If the token has never been polled and wait() can't run a
        # poll (no client attached), the underlying poll path raises
        # EIDRProtocolError. operation_result() lets it propagate
        # rather than swallowing it into a fake PENDING result.
        from eidr.errors import EIDRProtocolError

        # Detached token with no client at all.
        tok = Token(value="my-tok")
        with pytest.raises(EIDRProtocolError):
            tok.operation_result(timeout=1.0)


# ─── OperationResult.id convenience ─────────────────────────────────────────


class TestOperationResultIDProperty:
    def test_id_returns_first_when_present(self) -> None:
        body = (
            f"<Response {NS}>"
            "<Status><Code>0</Code><Type>Success</Type></Status>"
            "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
            "</Response>"
        )
        parsed = parse_response(body, operation="x")
        result = operation_result_from(parsed)
        assert result.id == "10.5240/0000-02ED-1DCE-6AAF-99F7-M"

    def test_id_returns_none_when_empty(self) -> None:
        body = f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"
        parsed = parse_response(body, operation="x")
        result = operation_result_from(parsed)
        assert result.id is None
