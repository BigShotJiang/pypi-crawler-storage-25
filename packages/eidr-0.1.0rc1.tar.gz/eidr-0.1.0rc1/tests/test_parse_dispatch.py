"""Tests for :func:`eidr.models.parse` — the root-element-driven dispatcher."""

from __future__ import annotations

import pytest

import eidr
from eidr.errors import EIDRClientError
from eidr.models import (
    AliasContinuation,
    ContentRecord,
    PartyRecord,
    ServiceRecord,
    parse,
)

CONTENT_ID = "10.5240/7791-8534-2C23-9030-8610-5"
PARTY_ID = "10.5237/7791-8534"
SERVICE_ID = "10.5239/7791-8534"
TARGET_ID = "10.5240/0000-0000-0000-0000-0000-X"


class TestParseRootElements:
    def test_content_full_metadata(self) -> None:
        xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema">'
            f"<BaseObjectData><ID>{CONTENT_ID}</ID><ResourceName>X</ResourceName></BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, ContentRecord)
        assert str(rec.id) == CONTENT_ID

    def test_content_self_defined_metadata(self) -> None:
        xml = (
            '<SelfDefinedMetadata xmlns="http://www.eidr.org/schema">'
            f"<BaseObjectData><ID>{CONTENT_ID}</ID></BaseObjectData>"
            "</SelfDefinedMetadata>"
        ).encode()
        assert isinstance(parse(xml), ContentRecord)

    def test_content_provenance_metadata(self) -> None:
        xml = (
            '<ProvenanceMetadata xmlns="http://www.eidr.org/schema">'
            f"<ID>{CONTENT_ID}</ID>"
            "</ProvenanceMetadata>"
        ).encode()
        assert isinstance(parse(xml), ContentRecord)

    def test_party(self) -> None:
        xml = (
            '<Party xmlns="http://www.eidr.org/schema"'
            ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>Acme</md:DisplayName></PartyName>"
            "<ContactInfo><Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
            "<Active>true</Active>"
            "</Party>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, PartyRecord)
        assert str(rec.id) == PARTY_ID

    def test_service(self) -> None:
        xml = (
            '<Service xmlns="http://www.eidr.org/schema"'
            ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            f"<ID>{SERVICE_ID}</ID>"
            "<ServiceName><md:DisplayName>Netflix</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "</Service>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, ServiceRecord)
        assert str(rec.id) == SERVICE_ID

    def test_alias_continuation(self) -> None:
        xml = (
            '<AliasContinuation xmlns="http://www.eidr.org/schema">'
            f"<LastAliased>{CONTENT_ID}</LastAliased>"
            f"<TargetOfLastAliased>{TARGET_ID}</TargetOfLastAliased>"
            "</AliasContinuation>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, AliasContinuation)
        assert rec.last_aliased == CONTENT_ID
        assert rec.target_of_last_aliased == TARGET_ID

    def test_party_alias_continuation(self) -> None:
        xml = (
            '<PartyAliasContinuation xmlns="http://www.eidr.org/schema">'
            f"<LastAliased>{PARTY_ID}</LastAliased>"
            "<TargetOfLastAliased>10.5237/9999-8888</TargetOfLastAliased>"
            "</PartyAliasContinuation>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, AliasContinuation)

    def test_service_alias_continuation(self) -> None:
        xml = (
            '<ServiceAliasContinuation xmlns="http://www.eidr.org/schema">'
            f"<LastAliased>{SERVICE_ID}</LastAliased>"
            "<TargetOfLastAliased>10.5239/9999-8888</TargetOfLastAliased>"
            "</ServiceAliasContinuation>"
        ).encode()
        rec = parse(xml)
        assert isinstance(rec, AliasContinuation)


class TestParseRejectsUnknown:
    def test_unknown_root_raises(self) -> None:
        xml = b'<SomeUnknownThing xmlns="http://x.example"><X>1</X></SomeUnknownThing>'
        with pytest.raises(EIDRClientError, match="Unrecognized root element"):
            parse(xml)

    def test_empty_raises(self) -> None:
        with pytest.raises(EIDRClientError):
            parse(b"<Empty/>")

    def test_multiple_roots_rejected(self) -> None:
        # When a codec dict has multiple top-level data keys, we don't
        # know which to dispatch on — require caller to iterate.
        from eidr.models._parse import parse_codec_dict

        with pytest.raises(EIDRClientError, match="single root element"):
            parse_codec_dict({"Party": {}, "Service": {}})


class TestParseIgnoresNamespaceDecls:
    """The codec dict surfaces xmlns declarations as ``_xmlns`` keys.
    These must not confuse the dispatcher."""

    def test_xmlns_keys_dont_count_as_roots(self) -> None:
        xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema">'
            f"<BaseObjectData><ID>{CONTENT_ID}</ID></BaseObjectData>"
            "</FullMetadata>"
        ).encode()
        # This XML produces a codec dict like:
        #   {"FullMetadata": {"_xmlns": "...", "BaseObjectData": {...}}}
        # The outer dict has exactly one non-attr key, so dispatch works.
        assert isinstance(parse(xml), ContentRecord)


class TestTopLevelParseExport:
    """`eidr.parse` should be the same function as `eidr.models.parse`."""

    def test_reexport(self) -> None:
        assert eidr.parse is parse
