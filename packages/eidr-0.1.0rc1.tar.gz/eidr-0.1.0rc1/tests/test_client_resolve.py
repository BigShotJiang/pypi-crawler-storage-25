"""Tests for :mod:`eidr.client._client`.

End-to-end tests with :class:`httpx.MockTransport` as the backend.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import Client
from eidr.client._http import TransportConfig
from eidr.client._shared import resolve_resource_path
from eidr.credentials import Credentials
from eidr.errors import EIDRAuthenticationError, EIDRProtocolError
from eidr.models.content import ContentRecord
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


NS_EIDR = "http://www.eidr.org/schema"
NS_MD = "http://www.movielabs.com/schema/md/v2.8/md"
NS_ATTRS = f' xmlns="{NS_EIDR}" xmlns:md="{NS_MD}"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    config = TransportConfig(
        max_retries=1,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


def _content_body() -> str:
    """A minimal but valid-enough FullMetadata body."""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<FullMetadata{NS_ATTRS}>"
        "<BaseObjectData>"
        "<ID>10.5240/7791-8534-2C23-9030-8610-5</ID>"
        "<StructuralType>Performance</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


def _party_body() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<Party{NS_ATTRS}>"
        "<ID>10.5237/FFDA-9947</ID>"
        "<PartyName><md:DisplayName>Acme</md:DisplayName></PartyName>"
        "<ContactInfo>"
        "<Name>Jane Doe</Name>"
        "<PrimaryEmail>jane@acme.example</PrimaryEmail>"
        "</ContactInfo>"
        "<Active>true</Active>"
        "</Party>"
    )


def _service_body() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<Service{NS_ATTRS}>"
        "<ID>10.5239/7791-8534</ID>"
        "<ServiceName><md:DisplayName>TestService</md:DisplayName></ServiceName>"
        "<Active>true</Active>"
        "</Service>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# resolve
# ─────────────────────────────────────────────────────────────────────────────


class TestResolveHappy:
    def test_resolve_content_returns_ContentRecord(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/EIDR/object/10.5240/7791-8534-2C23-9030-8610-5"
            return httpx.Response(200, text=_content_body())

        with make_client(handler) as client:
            rec = client.resolve("10.5240/7791-8534-2C23-9030-8610-5")
        assert isinstance(rec, ContentRecord)
        assert rec.resource_name == "Test Movie"

    def test_resolve_party_routes_to_party_endpoint(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/EIDR/party/resolve/10.5237/FFDA-9947"
            return httpx.Response(200, text=_party_body())

        with make_client(handler) as client:
            rec = client.resolve("10.5237/FFDA-9947")
        assert isinstance(rec, PartyRecord)

    def test_resolve_service_routes_to_service_endpoint(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/EIDR/service/resolve/10.5239/7791-8534"
            return httpx.Response(200, text=_service_body())

        with make_client(handler) as client:
            rec = client.resolve("10.5239/7791-8534")
        assert isinstance(rec, ServiceRecord)

    def test_resolve_passes_type_parameter(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        with make_client(handler) as client:
            client.resolve("10.5240/foo", resolution_type="Self")
        assert "type=Self" in captured["url"]

    def test_resolve_follow_alias_false(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        with make_client(handler) as client:
            client.resolve("10.5240/foo", follow_alias=False)
        assert "followAlias=false" in captured["url"]

    def test_resolve_default_no_params_in_url(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        with make_client(handler) as client:
            client.resolve("10.5240/foo")
        # Default resolution_type=Full and follow_alias=True → no query string
        assert "?" not in captured["url"]

    def test_resolve_combines_type_and_follow_alias(self) -> None:
        # Both params present; httpx joins with & and URL-encodes values.
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_body())

        with make_client(handler) as client:
            client.resolve(
                "10.5240/foo",
                resolution_type="Provenance",
                follow_alias=False,
            )
        url = captured["url"]
        assert "type=Provenance" in url
        assert "followAlias=false" in url
        # Query separator is exactly one '?'
        assert url.count("?") == 1


class TestResolveErrors:
    def test_resolve_envelope_response_raises_protocol(self) -> None:
        """If a resolve comes back as an envelope instead of record, that's
        a protocol violation — resolves should yield record bodies on success."""

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=f"<Response{NS_ATTRS}><Status><Code>0</Code><Type>Success</Type></Status></Response>",
            )

        with (
            make_client(handler) as client,
            pytest.raises(EIDRProtocolError, match="record response"),
        ):
            client.resolve("10.5240/foo")

    def test_resolve_auth_error_surfaces_from_envelope(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<Response{NS_ATTRS}>"
                    # Real registry type string, per REST API Reference Table 5.
                    "<Status><Code>4</Code><Type>authentication error</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client, pytest.raises(EIDRAuthenticationError):
            client.resolve("10.5240/foo")


# ─────────────────────────────────────────────────────────────────────────────
# status_lookup
# ─────────────────────────────────────────────────────────────────────────────


class TestStatusLookup:
    def test_status_lookup_uses_status_endpoint(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(
                200,
                text=(
                    f"<Response{NS_ATTRS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client:
            parsed = client.status_lookup("my-token-123")
        assert "/EIDR/status/my-token-123" in captured["url"]
        assert parsed.kind == "envelope"
        assert parsed.status_code == 0

    def test_status_lookup_rejects_empty_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("Transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="non-empty string"):
            client.status_lookup("")


# ─────────────────────────────────────────────────────────────────────────────
# Client lifecycle
# ─────────────────────────────────────────────────────────────────────────────


class TestClientLifecycle:
    def test_context_manager_closes(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<Ok/>")

        client = make_client(handler)
        assert client._transport._httpx.is_closed is False
        client.close()
        assert client._transport._httpx.is_closed is True

    def test_context_manager_enter_returns_self(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<Ok/>")

        with make_client(handler) as client:
            assert isinstance(client, Client)

    def test_registry_property(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<Ok/>")

        with make_client(handler) as client:
            assert client.registry is REGISTRY


# ─────────────────────────────────────────────────────────────────────────────
# URL-path helper
# ─────────────────────────────────────────────────────────────────────────────


class TestResolveResourcePath:
    def test_content_id_maps_to_object(self) -> None:
        assert resolve_resource_path("10.5240/abc") == "/object/10.5240/abc"

    def test_party_id_maps_to_party_resolve(self) -> None:
        assert resolve_resource_path("10.5237/abc") == "/party/resolve/10.5237/abc"

    def test_service_id_maps_to_service_resolve(self) -> None:
        assert resolve_resource_path("10.5239/abc") == "/service/resolve/10.5239/abc"

    def test_whitespace_stripped(self) -> None:
        assert resolve_resource_path("  10.5240/abc  ") == "/object/10.5240/abc"

    def test_unknown_prefix_defaults_to_content(self) -> None:
        # Invalid prefix → default to content; registry handles not-found
        assert resolve_resource_path("10.9999/xyz") == "/object/10.9999/xyz"
