"""Tests for :mod:`eidr.client._envelope`."""

from __future__ import annotations

import re

import pytest

from eidr.client._envelope import DedupeMode, build_request_envelope


class TestBasicEnvelope:
    def test_single_operation_wrapped(self) -> None:
        xml = build_request_envelope(["<Delete><ID>10.5240/x</ID></Delete>"])
        assert xml.startswith("<Request ")
        assert xml.endswith("</Request>")
        assert "<Operation>" in xml
        assert "<Delete><ID>10.5240/x</ID></Delete>" in xml
        assert "</Operation>" in xml

    def test_namespaces_declared(self) -> None:
        xml = build_request_envelope(["<X/>"])
        assert 'xmlns="http://www.eidr.org/schema"' in xml
        assert 'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"' in xml
        assert 'xmlns:doi="http://doi.org/doi_handbook/XML_Schema"' in xml
        assert 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' in xml

    def test_multiple_operations(self) -> None:
        xml = build_request_envelope(
            [
                "<Delete><ID>10.5240/a</ID></Delete>",
                "<Delete><ID>10.5240/b</ID></Delete>",
                "<Delete><ID>10.5240/c</ID></Delete>",
            ]
        )
        # Three <Operation>...</Operation> blocks
        assert xml.count("<Operation>") == 3
        assert xml.count("</Operation>") == 3
        assert "10.5240/a" in xml
        assert "10.5240/b" in xml
        assert "10.5240/c" in xml

    def test_empty_list_rejected(self) -> None:
        with pytest.raises(ValueError, match="At least one operation"):
            build_request_envelope([])


class TestRequestUserToken:
    def test_token_added_as_attribute(self) -> None:
        xml = build_request_envelope(["<X/>"], request_user_token="tok-42")
        assert 'userToken="tok-42"' in xml
        # On the <Request> tag, not the Operation
        assert "<Operation>" in xml
        assert "Request " in xml.split(">", 1)[0] or "Request" in xml[:120]
        # More precise: find what's inside the Request opening tag
        match = re.search(r"<Request\b([^>]*)>", xml)
        assert match is not None
        assert 'userToken="tok-42"' in match.group(1)

    def test_no_token_when_none(self) -> None:
        xml = build_request_envelope(["<X/>"])
        request_open = xml.split(">", 1)[0]
        assert "userToken" not in request_open

    def test_token_escaped_when_contains_special_chars(self) -> None:
        xml = build_request_envelope(["<X/>"], request_user_token="a&b<c>d")
        # Attribute values must escape &, <, >
        assert "a&amp;b&lt;c&gt;d" in xml
        # Original characters must not appear inside Request attributes
        request_open = xml.split(">", 1)[0]
        assert "a&b<c>d" not in request_open


class TestOperationUserTokens:
    def test_per_operation_tokens(self) -> None:
        xml = build_request_envelope(
            ["<A/>", "<B/>"],
            operation_user_tokens=["op-1", "op-2"],
        )
        assert '<Operation userToken="op-1">' in xml
        assert '<Operation userToken="op-2">' in xml

    def test_none_entry_skips_token(self) -> None:
        xml = build_request_envelope(
            ["<A/>", "<B/>"],
            operation_user_tokens=["op-1", None],
        )
        assert '<Operation userToken="op-1">' in xml
        # Second operation should have no userToken
        operations = re.findall(r"<Operation[^>]*>", xml)
        assert len(operations) == 2
        assert "op-1" in operations[0]
        assert "userToken" not in operations[1]

    def test_length_mismatch_rejected(self) -> None:
        with pytest.raises(ValueError, match="operation_user_tokens"):
            build_request_envelope(
                ["<A/>", "<B/>"],
                operation_user_tokens=["op-1"],
            )


class TestDedupeMode:
    def test_normal_mode(self) -> None:
        xml = build_request_envelope(["<A/>"], dedupe_modes=[DedupeMode.NORMAL])
        assert '<Operation dedupMode="normal">' in xml

    def test_manual_mode(self) -> None:
        xml = build_request_envelope(["<A/>"], dedupe_modes=[DedupeMode.MANUAL])
        assert '<Operation dedupMode="manual">' in xml

    def test_accept_mode(self) -> None:
        xml = build_request_envelope(["<A/>"], dedupe_modes=[DedupeMode.ACCEPT])
        assert '<Operation dedupMode="accept">' in xml

    def test_none_entry_omits_attribute(self) -> None:
        xml = build_request_envelope(
            ["<A/>", "<B/>"],
            dedupe_modes=[DedupeMode.MANUAL, None],
        )
        operations = re.findall(r"<Operation[^>]*>", xml)
        assert 'dedupMode="manual"' in operations[0]
        assert "dedupMode" not in operations[1]

    def test_length_mismatch_rejected(self) -> None:
        with pytest.raises(ValueError, match="dedupe_modes"):
            build_request_envelope(
                ["<A/>", "<B/>"],
                dedupe_modes=[DedupeMode.NORMAL],
            )


class TestCombined:
    def test_token_and_dedupe_mode_coexist(self) -> None:
        xml = build_request_envelope(
            ["<A/>"],
            operation_user_tokens=["op-1"],
            dedupe_modes=[DedupeMode.ACCEPT],
        )
        match = re.search(r"<Operation([^>]*)>", xml)
        assert match is not None
        attrs = match.group(1)
        assert 'userToken="op-1"' in attrs
        assert 'dedupMode="accept"' in attrs

    def test_request_and_op_tokens_independent(self) -> None:
        xml = build_request_envelope(
            ["<A/>"],
            request_user_token="req-1",
            operation_user_tokens=["op-1"],
        )
        # Request has one token, Operation has another
        req_match = re.search(r"<Request\b([^>]*)>", xml)
        op_match = re.search(r"<Operation\b([^>]*)>", xml)
        assert req_match is not None
        assert op_match is not None
        assert 'userToken="req-1"' in req_match.group(1)
        assert 'userToken="op-1"' in op_match.group(1)


class TestDedupeModeEnum:
    def test_values_match_registry_protocol(self) -> None:
        assert DedupeMode.NORMAL.value == "normal"
        assert DedupeMode.MANUAL.value == "manual"
        assert DedupeMode.ACCEPT.value == "accept"

    def test_is_str_enum(self) -> None:
        # StrEnum means instances compare equal to their string values
        assert DedupeMode.NORMAL == "normal"
