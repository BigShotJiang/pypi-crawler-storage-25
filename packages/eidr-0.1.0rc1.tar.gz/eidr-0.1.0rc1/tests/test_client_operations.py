"""Tests for :mod:`eidr.client._operations`."""

from __future__ import annotations

import re

import pytest

from eidr.client._operations import (
    RelationshipType,
    _record_to_creation_inner,
    build_add_relationship,
    build_alias,
    build_create,
    build_delete,
    build_modify,
    build_promote,
    build_remove_relationship,
    build_replace_relationship,
)
from eidr.errors import EIDRClientError
from eidr.models.enums import CreationType

# Minimal sample full-metadata XML docs for each CreationType.
# These use the 2.8 MovieLabs MD namespace prefix to match current fixtures.

_NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _basic_record() -> str:
    """Basic record — no ExtraObjectMetadata (Basic is the implicit default)."""
    return (
        '<?xml version="1.0"?>'
        f"<FullMetadata {_NS}>"
        "<BaseObjectData>"
        "<ID>10.5240/ABCD-EFAB-CDEF-ABCD-EFAB-1</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


def _series_record() -> str:
    """Series record — has ExtraObjectMetadata with SeriesInfo."""
    return (
        '<?xml version="1.0"?>'
        f"<FullMetadata {_NS}>"
        "<BaseObjectData>"
        "<ID>10.5240/SSSS-SSSS-SSSS-SSSS-SSSS-2</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>TV</ReferentType>"
        "<ResourceName>Test Series</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "<ExtraObjectMetadata>"
        "<SeriesInfo><EndDate>2020</EndDate></SeriesInfo>"
        "</ExtraObjectMetadata>"
        "</FullMetadata>"
    )


# ─────────────────────────────────────────────────────────────────────────────
# _record_to_creation_inner — the rename helper
# ─────────────────────────────────────────────────────────────────────────────


class TestRecordToCreationInner:
    def test_basic_record_renamed_to_Basic(self) -> None:
        inner = _record_to_creation_inner(_basic_record(), CreationType.Basic)
        # The outer element is renamed; the namespace is preserved.
        assert "<Basic" in inner
        # BaseObjectData children preserved
        assert "<BaseObjectData>" in inner
        # <ID> must be stripped — the Create payload's schema
        # (creationFullInfo / creationSelfDefinedInfo) does not
        # include ID because the registry assigns it on Create.
        # Resubmitting a resolved record without stripping ID is
        # rejected by the live registry. See
        # _record_to_creation_inner's docstring for the schema
        # citation.
        assert "<ID>10.5240/ABCD-EFAB-CDEF-ABCD-EFAB-1</ID>" not in inner
        assert "<ID>" not in inner
        # No <FullMetadata> element anywhere
        assert "<FullMetadata" not in inner

    def test_series_record_renamed_to_Series(self) -> None:
        inner = _record_to_creation_inner(_series_record(), CreationType.Series)
        assert "<Series" in inner
        # Both BaseObjectData AND ExtraObjectMetadata preserved
        assert "<BaseObjectData>" in inner
        assert "<ExtraObjectMetadata>" in inner
        assert "<SeriesInfo>" in inner
        assert "<FullMetadata" not in inner
        # ID is stripped — see test_basic_record_renamed_to_Basic
        # for the schema rationale.
        assert "<ID>" not in inner

    def test_id_stripped_from_basedata_regression(self) -> None:
        """Regression test for the M9 review-pass live-test failure:

        ``cvc-complex-type.2.4.a: Invalid content was found starting
        with element 'ID'. One of '{...}:StructuralType' is expected.``

        The Create payload's schema (``creationFullInfo`` in
        ``eidr-base.xsd``) has ``StructuralType`` first; ``<ID>`` is
        not part of the type. When a resolved record is resubmitted
        for Create or Match, the helper must strip ``<ID>`` from
        ``<BaseObjectData>``.

        This test verifies the strip happens regardless of
        record shape.
        """
        # Build a minimal record body with <ID> as the first child
        # of <BaseObjectData>, matching what a live resolve returns.
        record = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<FullMetadata xmlns="http://www.eidr.org/schema">'
            "<BaseObjectData>"
            "<ID>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-X</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>Test</ResourceName>"
            "</BaseObjectData>"
            "</FullMetadata>"
        )
        inner = _record_to_creation_inner(record, CreationType.Basic)
        # ID is gone
        assert "<ID>" not in inner
        # StructuralType is now the first child of BaseObjectData
        # (it may have a namespace prefix, so look for it loosely)
        assert "<StructuralType>" in inner
        # And the structure is otherwise intact
        assert "<BaseObjectData>" in inner
        assert "<Mode>AudioVisual</Mode>" in inner

    def test_namespace_preserved(self) -> None:
        inner = _record_to_creation_inner(_basic_record(), CreationType.Basic)
        # EIDR namespace should still be declared
        assert "http://www.eidr.org/schema" in inner

    def test_self_defined_metadata_root_also_accepted(self) -> None:
        xml = (
            '<?xml version="1.0"?>'
            f"<SelfDefinedMetadata {_NS}>"
            "<BaseObjectData>"
            "<ID>10.5240/X</ID>"
            "</BaseObjectData>"
            "</SelfDefinedMetadata>"
        )
        inner = _record_to_creation_inner(xml, CreationType.Basic)
        assert "<Basic" in inner

    def test_provenance_metadata_root_also_accepted(self) -> None:
        xml = (
            '<?xml version="1.0"?>'
            f"<ProvenanceMetadata {_NS}>"
            "<BaseObjectData>"
            "<ID>10.5240/X</ID>"
            "</BaseObjectData>"
            "</ProvenanceMetadata>"
        )
        inner = _record_to_creation_inner(xml, CreationType.Basic)
        assert "<Basic" in inner

    def test_accepts_bytes_input(self) -> None:
        inner = _record_to_creation_inner(_basic_record().encode("utf-8"), CreationType.Basic)
        assert "<Basic" in inner

    def test_rejects_malformed_xml(self) -> None:
        with pytest.raises(EIDRClientError, match="not well-formed"):
            _record_to_creation_inner("<not closed", CreationType.Basic)

    def test_rejects_unexpected_root(self) -> None:
        with pytest.raises(EIDRClientError, match="FullMetadata"):
            _record_to_creation_inner(f"<SomethingElse {_NS}/>", CreationType.Basic)

    def test_rejects_alias_creation_type(self) -> None:
        with pytest.raises(EIDRClientError, match="Alias operation"):
            _record_to_creation_inner(_basic_record(), CreationType.Alias)


# ─────────────────────────────────────────────────────────────────────────────
# build_create
# ─────────────────────────────────────────────────────────────────────────────


class TestBuildCreate:
    def test_basic_type_attribute_and_shape(self) -> None:
        xml = build_create(_basic_record(), CreationType.Basic)
        assert xml.startswith('<Create type="CreateBasic">')
        assert xml.endswith("</Create>")
        # Inner <Basic> wraps <BaseObjectData>
        assert "<Basic" in xml
        assert "<BaseObjectData>" in xml

    def test_series_type_and_inner(self) -> None:
        xml = build_create(_series_record(), CreationType.Series)
        assert 'type="CreateSeries"' in xml
        assert "<Series" in xml
        # ExtraObjectMetadata + SeriesInfo preserved
        assert "<ExtraObjectMetadata>" in xml
        assert "<SeriesInfo>" in xml

    def test_fullmetadata_envelope_removed(self) -> None:
        # No <FullMetadata> should ever appear in a Create payload
        xml = build_create(_basic_record(), CreationType.Basic)
        assert "FullMetadata" not in xml

    def test_all_creation_types_mapped(self) -> None:
        from eidr.client._operations import _creation_type_attr

        for ct in CreationType:
            if ct == CreationType.Alias:
                continue
            assert _creation_type_attr(ct) == f"Create{ct.value}"


# ─────────────────────────────────────────────────────────────────────────────
# build_modify
# ─────────────────────────────────────────────────────────────────────────────


class TestBuildModify:
    def test_includes_id_and_inner(self) -> None:
        xml = build_modify(
            _basic_record(),
            "10.5240/ABCD-EFAB-CDEF-ABCD-EFAB-1",
            CreationType.Basic,
        )
        assert '<Modify type="CreateBasic">' in xml
        assert "<ID>10.5240/ABCD-EFAB-CDEF-ABCD-EFAB-1</ID>" in xml
        assert "</Modify>" in xml
        # Inner <Basic> present
        assert "<Basic" in xml

    def test_id_comes_before_inner_basic(self) -> None:
        xml = build_modify(
            _basic_record(),
            "10.5240/X",
            CreationType.Basic,
        )
        id_pos = xml.find("<ID>10.5240/X</ID>")
        # <Basic element (namespaced form) — first <Basic after the <Modify open
        basic_open = xml.find("<Basic", xml.find("<Modify"))
        assert id_pos >= 0 and basic_open >= 0
        assert id_pos < basic_open

    def test_id_with_special_chars_escaped(self) -> None:
        xml = build_modify(
            _basic_record(),
            "10.5240/A&B",
            CreationType.Basic,
        )
        assert "10.5240/A&amp;B" in xml


# ─────────────────────────────────────────────────────────────────────────────
# Simple operations: delete, promote, alias
# ─────────────────────────────────────────────────────────────────────────────


class TestSimpleOps:
    def test_delete_shape(self) -> None:
        assert build_delete("10.5240/X") == "<Delete><ID>10.5240/X</ID></Delete>"

    def test_promote_shape(self) -> None:
        assert build_promote("10.5240/X") == "<Promote><ID>10.5240/X</ID></Promote>"

    def test_alias_shape(self) -> None:
        xml = build_alias("10.5240/SRC", "10.5240/TGT")
        assert xml == ("<Alias><ID>10.5240/SRC</ID><TargetID>10.5240/TGT</TargetID></Alias>")

    def test_delete_escapes_id(self) -> None:
        xml = build_delete("10.5240/A<B")
        assert "&lt;" in xml


# ─────────────────────────────────────────────────────────────────────────────
# Relationship operations
# ─────────────────────────────────────────────────────────────────────────────


class TestAddRelationship:
    def test_promotional_shape(self) -> None:
        info = "<PromotionInfo><ID>10.5240/X</ID></PromotionInfo>"
        xml = build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)
        assert '<AddRelationship type="PromotionalRelationship">' in xml
        assert "<ID>10.5240/SRC</ID>" in xml
        assert info in xml
        assert "</AddRelationship>" in xml

    def test_composite_with_composite_info(self) -> None:
        info = "<CompositeInfo><ID>10.5240/X</ID></CompositeInfo>"
        xml = build_add_relationship("10.5240/SRC", RelationshipType.COMPOSITE, info)
        assert 'type="CompositeRelationship"' in xml

    def test_info_tag_mismatch_rejected(self) -> None:
        info = "<CompositeInfo><ID>10.5240/X</ID></CompositeInfo>"
        with pytest.raises(EIDRClientError, match="PROMOTIONAL"):
            build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)

    def test_all_six_relationship_types(self) -> None:
        cases: list[tuple[RelationshipType, str]] = [
            (RelationshipType.COMPOSITE, "<CompositeInfo/>"),
            (RelationshipType.LANGUAGE, "<LanguageConstructionInfo/>"),
            (RelationshipType.PACKAGING, "<PackagingInfo/>"),
            (RelationshipType.ADJUNCT, "<AdjunctContentInfo/>"),
            (RelationshipType.PROMOTIONAL, "<PromotionInfo/>"),
            (RelationshipType.ALTERNATE_CONTENT, "<AlternateContentInfo/>"),
        ]
        for rel, info in cases:
            xml = build_add_relationship("10.5240/SRC", rel, info)
            assert f'type="{rel.value}"' in xml

    def test_namespace_prefixed_info_accepted(self) -> None:
        info = (
            '<eidr:PromotionInfo xmlns:eidr="http://www.eidr.org/schema">'
            "<eidr:ID>10.5240/X</eidr:ID>"
            "</eidr:PromotionInfo>"
        )
        xml = build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)
        assert info in xml

    def test_malformed_info_xml_rejected(self) -> None:
        # Unclosed tag — well-formedness matters now that we parse.
        with pytest.raises(EIDRClientError, match="well-formed"):
            build_add_relationship(
                "10.5240/SRC",
                RelationshipType.PROMOTIONAL,
                "<PromotionInfo><ID>10.5240/X</ID>",
            )

    def test_empty_info_xml_rejected(self) -> None:
        with pytest.raises(EIDRClientError, match="empty"):
            build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, "")

    def test_unexpected_namespace_rejected(self) -> None:
        info = (
            '<PromotionInfo xmlns="http://example.com/not-eidr"><ID>10.5240/X</ID></PromotionInfo>'
        )
        with pytest.raises(EIDRClientError, match="namespace"):
            build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)

    def test_trailing_content_after_root_is_dropped(self) -> None:
        """A fragment with content after the root element must not
        leak that content into the envelope. The builder parses and
        re-serializes the root only."""
        # lxml rejects trailing content at parse time for a document
        # with a single root, so technically well-formed fragments
        # can't carry it. The guard below uses a DOCTYPE-ish prefix
        # instead — something lxml parses as noise but that would
        # show up in a naive string-concat approach.
        info = (
            "<!-- sneaky comment before root --><PromotionInfo><ID>10.5240/TGT</ID></PromotionInfo>"
        )
        xml = build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)
        assert "sneaky comment" not in xml
        assert "<PromotionInfo>" in xml
        assert "<ID>10.5240/TGT</ID>" in xml

    def test_xml_declaration_in_caller_fragment_is_dropped(self) -> None:
        """An XML declaration inside the caller's fragment shouldn't
        appear mid-envelope after embedding."""
        info = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            "<PromotionInfo><ID>10.5240/TGT</ID></PromotionInfo>"
        )
        xml = build_add_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)
        # Embedded '<?xml ...?>' inside an envelope would be a
        # serialization violation. The re-serialize step strips it.
        assert "<?xml" not in xml


class TestRemoveReplace:
    def test_remove_shape(self) -> None:
        xml = build_remove_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL)
        assert xml == (
            '<RemoveRelationship type="PromotionalRelationship">'
            "<ID>10.5240/SRC</ID>"
            "</RemoveRelationship>"
        )

    def test_replace_shape(self) -> None:
        info = "<PromotionInfo/>"
        xml = build_replace_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)
        assert '<ReplaceRelationship type="PromotionalRelationship">' in xml
        assert "<ID>10.5240/SRC</ID>" in xml
        assert info in xml

    def test_replace_enforces_info_tag(self) -> None:
        info = "<WrongInfo/>"
        with pytest.raises(EIDRClientError):
            build_replace_relationship("10.5240/SRC", RelationshipType.PROMOTIONAL, info)


class TestRelationshipTypeEnum:
    def test_six_values(self) -> None:
        assert len(list(RelationshipType)) == 6

    def test_wire_values_match_registry(self) -> None:
        expected_values = {
            "CompositeRelationship",
            "LanguageRelationship",
            "PackagingRelationship",
            "AdjunctRelationship",
            "PromotionalRelationship",
            "AlternateContentRelationship",
        }
        actual = {rel.value for rel in RelationshipType}
        assert actual == expected_values


# ─────────────────────────────────────────────────────────────────────────────
# Integration: combine with envelope
# ─────────────────────────────────────────────────────────────────────────────


class TestIntegration:
    """Compose an inner-XML builder with the envelope and spot-check shape."""

    def test_create_wrapped_in_envelope(self) -> None:
        from eidr.client._envelope import build_request_envelope

        inner = build_create(_basic_record(), CreationType.Basic)
        envelope = build_request_envelope([inner])

        assert "<Operation>" in envelope
        assert "</Operation>" in envelope
        assert '<Create type="CreateBasic">' in envelope
        # <Basic> inside <Create> inside <Operation>
        m = re.search(
            r"<Operation>\s*<Create[^>]*>\s*<Basic",
            envelope,
        )
        assert m is not None

    def test_delete_wrapped_in_envelope(self) -> None:
        from eidr.client._envelope import build_request_envelope

        inner = build_delete("10.5240/X")
        envelope = build_request_envelope([inner])
        assert "<Operation><Delete><ID>10.5240/X</ID></Delete></Operation>" in envelope
