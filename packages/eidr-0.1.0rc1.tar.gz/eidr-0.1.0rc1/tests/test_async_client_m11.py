"""Async-client mirrors of the M11 unit tests.

Spot-checks the async iterator paths. The bulk of behavior is
already covered by the sync tests in ``test_client_m11.py``;
these tests confirm the async-iteration variant works cleanly.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client import AsyncClient
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> AsyncClient:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(REGISTRY, CREDS, transport_config=config)


def _entries_envelope(entries: list[tuple[str, int, str]]) -> str:
    parts = ['<Response xmlns="http://www.eidr.org/schema">']
    parts.append("<Status><Code>0</Code><Type>success</Type></Status><RequestStatusResults>")
    for token, code, type_text in entries:
        parts.append("<OperationStatus>")
        parts.append(f"<Status><Code>{code}</Code><Type>{type_text}</Type></Status>")
        parts.append(f"<Token>{token}</Token>")
        parts.append("</OperationStatus>")
    parts.append("</RequestStatusResults></Response>")
    return "".join(parts)


class TestAsyncIterStatusByUser:
    @pytest.mark.asyncio
    async def test_async_iter_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope(
                    [
                        ("token-1", 0, "success"),
                        ("token-2", 0, "success"),
                    ]
                ),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_user("10.5238/u", page_size=20):
                entries.append(entry)

        assert len(entries) == 2
        assert [e.token for e in entries] == ["token-1", "token-2"]

    @pytest.mark.asyncio
    async def test_async_iter_paginates(self) -> None:
        page_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            page_count[0] += 1
            if page_count[0] == 1:
                return httpx.Response(
                    200,
                    text=_entries_envelope([(f"t-p1-{i}", 0, "success") for i in range(3)]),
                )
            return httpx.Response(
                200,
                text=_entries_envelope([("t-p2-1", 0, "success")]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_user("10.5238/u", page_size=3):
                entries.append(entry)

        assert page_count[0] == 2
        assert len(entries) == 4

    @pytest.mark.asyncio
    async def test_async_iter_max_results(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([(f"t-{i}", 0, "success") for i in range(20)]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_user("10.5238/u", page_size=20, max_results=3):
                entries.append(entry)

        assert len(entries) == 3


class TestAsyncIterStatusByRegistrant:
    @pytest.mark.asyncio
    async def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([("tok", 0, "success")]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_registrant("10.5237/AAAA-BBBB"):
                entries.append(entry)

        assert len(entries) == 1


class TestAsyncIterStatusSuperparty:
    @pytest.mark.asyncio
    async def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([("tok-sp", 0, "success")]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_superparty():
                entries.append(entry)

        assert len(entries) == 1
        assert entries[0].token == "tok-sp"


class TestAsyncIterStatusByToken:
    """Async mirror of TestIterStatusByToken."""

    @pytest.mark.asyncio
    async def test_yields_entries(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([("sub-1", 0, "success"), ("sub-2", 0, "success")]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_token("batch-token"):
                entries.append(entry)

        assert len(entries) == 2

    @pytest.mark.asyncio
    async def test_max_results(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=_entries_envelope([(f"t-{i}", 0, "success") for i in range(20)]),
            )

        async with make_client(handler) as client:
            entries = []
            async for entry in client.iter_status_by_token(
                "batch-token", page_size=20, max_results=3
            ):
                entries.append(entry)

        assert len(entries) == 3


# ─── M11-B: Async typed query helpers ──────────────────────────────────────


def _empty_party_query_response() -> str:
    """Empty <PartyQueryResults> as document root — live registry shape."""
    return (
        '<PartyQueryResults xmlns="http://www.eidr.org/schema">'
        "<CurrentSize>0</CurrentSize>"
        "<TotalMatches>0</TotalMatches>"
        "</PartyQueryResults>"
    )


def _empty_service_query_response() -> str:
    """Empty <ServiceQueryResults> as document root — live registry shape."""
    return (
        '<ServiceQueryResults xmlns="http://www.eidr.org/schema">'
        "<CurrentSize>0</CurrentSize>"
        "<TotalMatches>0</TotalMatches>"
        "</ServiceQueryResults>"
    )


class TestAsyncFindParties:
    @pytest.mark.asyncio
    async def test_async_find_parties_by_name(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        async with make_client(handler) as client:
            result = await client.find_parties_by_name("Universal")

        body = str(captured["body"])
        assert "<FindPartiesByName" in body
        assert "<PartyName>Universal</PartyName>" in body
        # Returns typed wrapper (R1#3, #8 — typed query results in 0.1.0b2)
        from eidr.client import PartyQueryResults

        assert isinstance(result, PartyQueryResults)
        assert result.party_ids == []

    @pytest.mark.asyncio
    async def test_async_find_parties_from_catalog(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_party_query_response())

        async with make_client(handler) as client:
            result = await client.find_parties_from_catalog("MovieLabs")

        assert "<FindPartiesFromCatalog" in str(captured["body"])
        from eidr.client import PartyQueryResults

        assert isinstance(result, PartyQueryResults)


class TestAsyncFindServices:
    @pytest.mark.asyncio
    async def test_async_find_services_by_name(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_service_query_response())

        async with make_client(handler) as client:
            result = await client.find_services_by_name("Netflix")

        assert "<FindServicesByName" in str(captured["body"])
        from eidr.client import ServiceQueryResults

        assert isinstance(result, ServiceQueryResults)

    @pytest.mark.asyncio
    async def test_async_find_services_from_catalog(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_empty_service_query_response())

        async with make_client(handler) as client:
            result = await client.find_services_from_catalog("Hulu")

        assert "<FindServicesFromCatalog" in str(captured["body"])
        from eidr.client import ServiceQueryResults

        assert isinstance(result, ServiceQueryResults)
