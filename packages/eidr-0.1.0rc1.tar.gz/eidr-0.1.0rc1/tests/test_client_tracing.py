"""Tests for :mod:`eidr.client._tracing`.

Covers the sinks, redaction, the resolve-tracing-arg normalization,
and the end-to-end behavior of tracing applied to a :class:`Client`.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path

import httpx
import pytest

from eidr.client import (
    Client,
    FileSink,
    ListSink,
    LoggerSink,
    TraceRecord,
    TraceSink,
)
from eidr.client._http import TransportConfig
from eidr.client._tracing import (
    _REDACTED,
    _SENSITIVE_HEADER_NAMES,
    make_trace_record,
    redact_headers,
    resolve_tracing_arg,
)
from eidr.credentials import Credentials
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

NS = ' xmlns="http://www.eidr.org/schema"'


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    tracing: TraceSink | bool | None = None,
    trace_max_body_chars: int | None = 100_000,
    trace_redact_bodies: bool = False,
) -> Client:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
        trace_max_body_chars=trace_max_body_chars,
        trace_redact_bodies=trace_redact_bodies,
    )
    return Client(REGISTRY, CREDS, transport_config=config, tracing=tracing)


# ─────────────────────────────────────────────────────────────────────────────
# Redaction
# ─────────────────────────────────────────────────────────────────────────────


class TestRedaction:
    def test_authorization_header_redacted(self) -> None:
        result = dict(redact_headers({"Authorization": "Eidr user:party:shadow"}))
        assert result["Authorization"] == _REDACTED

    def test_lowercase_authorization_redacted(self) -> None:
        # Case-insensitive match
        result = dict(redact_headers({"authorization": "secret"}))
        assert result["authorization"] == _REDACTED

    def test_mixed_case_authorization_redacted(self) -> None:
        result = dict(redact_headers({"AuThOrIzAtIoN": "secret"}))
        assert result["AuThOrIzAtIoN"] == _REDACTED

    def test_proxy_authorization_redacted(self) -> None:
        result = dict(redact_headers({"Proxy-Authorization": "Basic xyz"}))
        assert result["Proxy-Authorization"] == _REDACTED

    def test_cookie_redacted(self) -> None:
        result = dict(redact_headers({"Cookie": "session=xyz"}))
        assert result["Cookie"] == _REDACTED

    def test_set_cookie_redacted(self) -> None:
        result = dict(redact_headers({"Set-Cookie": "s=1"}))
        assert result["Set-Cookie"] == _REDACTED

    def test_non_sensitive_headers_preserved(self) -> None:
        result = dict(
            redact_headers(
                {
                    "Content-Type": "text/xml",
                    "EIDR-Version": "2.7.1",
                    "User-Agent": "test",
                }
            )
        )
        assert result["Content-Type"] == "text/xml"
        assert result["EIDR-Version"] == "2.7.1"
        assert result["User-Agent"] == "test"

    def test_order_preserved(self) -> None:
        input_headers = {"A": "1", "Authorization": "secret", "B": "2"}
        result = redact_headers(input_headers)
        names = [name for name, _ in result]
        assert names == ["A", "Authorization", "B"]

    def test_sensitive_header_list_is_lowercased(self) -> None:
        # Documents the invariant that the internal set uses lowercase.
        for name in _SENSITIVE_HEADER_NAMES:
            assert name == name.lower()


# ─────────────────────────────────────────────────────────────────────────────
# TraceRecord formatting
# ─────────────────────────────────────────────────────────────────────────────


class TestTraceRecordFormat:
    def _simple_record(self) -> TraceRecord:
        return make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={"A": "1"},
            request_body=None,
            response_status=200,
            response_headers={"B": "2"},
            response_body="<Ok/>",
            start_time=0.0,  # Duration will be ~now; we don't assert on it
            exception=None,
            attempt=0,
        )

    def test_format_includes_method_and_url(self) -> None:
        text = self._simple_record().format_plain()
        assert "GET https://x/y" in text

    def test_format_includes_headers(self) -> None:
        text = self._simple_record().format_plain()
        assert "A: 1" in text
        assert "B: 2" in text

    def test_format_includes_response_body(self) -> None:
        text = self._simple_record().format_plain()
        assert "<Ok/>" in text

    def test_format_shows_no_response_on_failure(self) -> None:
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={"A": "1"},
            request_body=None,
            response_status=None,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=TimeoutError("slow"),
            attempt=1,
        )
        text = rec.format_plain()
        assert "NO RESPONSE" in text
        assert "Exception: TimeoutError: slow" in text
        assert "attempt 2" in text  # attempt is zero-indexed, shown 1-indexed

    def test_format_includes_request_body_for_post(self) -> None:
        rec = make_trace_record(
            method="POST",
            url="https://x/register/",
            request_headers={"Content-Type": "multipart/form-data"},
            request_body="--314159\r\n<Request/>\r\n--314159",
            response_status=200,
            response_headers={},
            response_body="<Response/>",
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        text = rec.format_plain()
        assert "--314159" in text


# ─────────────────────────────────────────────────────────────────────────────
# make_trace_record
# ─────────────────────────────────────────────────────────────────────────────


class TestMakeTraceRecord:
    def test_redacts_authorization_in_request(self) -> None:
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={"Authorization": "Eidr secret"},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body="<Ok/>",
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        names = [n for n, _ in rec.request_headers]
        values = [v for _, v in rec.request_headers]
        assert "Authorization" in names
        assert _REDACTED in values
        assert "Eidr secret" not in values

    def test_bytes_request_body_decoded_to_text(self) -> None:
        rec = make_trace_record(
            method="POST",
            url="https://x/y",
            request_headers={},
            request_body=b"<Request/>",
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        assert rec.request_body == "<Request/>"

    def test_non_utf8_bytes_fall_back_to_repr(self) -> None:
        rec = make_trace_record(
            method="POST",
            url="https://x/y",
            request_headers={},
            request_body=b"\xff\xfe not utf8",
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        # repr() result — starts with a quote
        assert rec.request_body is not None
        assert "\\xff" in rec.request_body or "b'" in rec.request_body

    def test_duration_is_positive(self) -> None:
        import time

        start = time.monotonic()
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=start,
            exception=None,
            attempt=0,
        )
        assert rec.duration_seconds >= 0.0

    def test_exception_formatted_as_type_plus_message(self) -> None:
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={},
            request_body=None,
            response_status=None,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=ValueError("bad input"),
            attempt=0,
        )
        assert rec.exception == "ValueError: bad input"


# ─────────────────────────────────────────────────────────────────────────────
# ListSink
# ─────────────────────────────────────────────────────────────────────────────


class TestListSink:
    def test_write_accumulates(self) -> None:
        sink = ListSink()
        assert sink.records == []
        rec = make_trace_record(
            method="GET",
            url="x",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)
        assert sink.records == [rec]

    def test_clear_empties(self) -> None:
        sink = ListSink()
        rec = make_trace_record(
            method="GET",
            url="x",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)
        sink.write(rec)
        sink.clear()
        assert sink.records == []

    def test_implements_trace_sink_protocol(self) -> None:
        sink = ListSink()
        assert isinstance(sink, TraceSink)


# ─────────────────────────────────────────────────────────────────────────────
# LoggerSink
# ─────────────────────────────────────────────────────────────────────────────


class TestLoggerSink:
    def test_writes_to_logger(self, caplog: pytest.LogCaptureFixture) -> None:
        caplog.set_level(logging.INFO, logger="eidr.client.trace")
        sink = LoggerSink()
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)
        assert any("GET https://x/y" in record.getMessage() for record in caplog.records)

    def test_custom_logger_used(self, caplog: pytest.LogCaptureFixture) -> None:
        caplog.set_level(logging.WARNING, logger="custom.logger")
        custom = logging.getLogger("custom.logger")
        sink = LoggerSink(logger=custom, level=logging.WARNING)
        rec = make_trace_record(
            method="POST",
            url="https://x/y",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)
        assert any("POST https://x/y" in record.getMessage() for record in caplog.records)


# ─────────────────────────────────────────────────────────────────────────────
# FileSink
# ─────────────────────────────────────────────────────────────────────────────


class TestFileSink:
    def test_writes_to_file(self, tmp_path: Path) -> None:
        path = tmp_path / "trace.log"
        sink = FileSink(path)
        rec = make_trace_record(
            method="GET",
            url="https://x/y",
            request_headers={"A": "1"},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body="<Ok/>",
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)
        sink.close()
        content = path.read_text()
        assert "GET https://x/y" in content
        assert "<Ok/>" in content

    def test_multiple_writes_append(self, tmp_path: Path) -> None:
        path = tmp_path / "trace.log"
        sink = FileSink(path)
        for i in range(3):
            rec = make_trace_record(
                method="GET",
                url=f"https://x/{i}",
                request_headers={},
                request_body=None,
                response_status=200,
                response_headers=None,
                response_body=None,
                start_time=0.0,
                exception=None,
                attempt=0,
            )
            sink.write(rec)
        sink.close()
        content = path.read_text()
        assert content.count("GET https://x/") == 3

    def test_close_is_idempotent(self, tmp_path: Path) -> None:
        sink = FileSink(tmp_path / "trace.log")
        sink.close()
        sink.close()  # no-op

    def test_write_after_close_silently_noops(self, tmp_path: Path) -> None:
        path = tmp_path / "trace.log"
        sink = FileSink(path)
        sink.close()
        rec = make_trace_record(
            method="GET",
            url="x",
            request_headers={},
            request_body=None,
            response_status=200,
            response_headers=None,
            response_body=None,
            start_time=0.0,
            exception=None,
            attempt=0,
        )
        sink.write(rec)  # Should not raise


# ─────────────────────────────────────────────────────────────────────────────
# resolve_tracing_arg
# ─────────────────────────────────────────────────────────────────────────────


class TestResolveTracingArg:
    def test_none_returns_none(self) -> None:
        assert resolve_tracing_arg(None) is None

    def test_false_returns_none(self) -> None:
        assert resolve_tracing_arg(False) is None

    def test_true_returns_logger_sink(self) -> None:
        result = resolve_tracing_arg(True)
        assert isinstance(result, LoggerSink)

    def test_sink_instance_passed_through(self) -> None:
        sink = ListSink()
        assert resolve_tracing_arg(sink) is sink

    def test_invalid_type_raises(self) -> None:
        with pytest.raises(TypeError, match="tracing must be"):
            resolve_tracing_arg("not a sink")  # type: ignore[arg-type]

    def test_invalid_type_int_raises(self) -> None:
        with pytest.raises(TypeError, match="tracing must be"):
            resolve_tracing_arg(42)  # type: ignore[arg-type]


# ─────────────────────────────────────────────────────────────────────────────
# End-to-end through Client
# ─────────────────────────────────────────────────────────────────────────────


class TestClientTracing:
    def test_successful_get_captures_one_record(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<FullMetadata{NS}>"
                    "<BaseObjectData>"
                    "<ID>10.5240/foo</ID>"
                    "<StructuralType>Abstraction</StructuralType>"
                    "<Mode>AudioVisual</Mode>"
                    "<ReferentType>Movie</ReferentType>"
                    "<ResourceName>X</ResourceName>"
                    "<OriginalLanguage>en</OriginalLanguage>"
                    "<Status>valid</Status>"
                    "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
                    "</BaseObjectData>"
                    "</FullMetadata>"
                ),
            )

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.resolve("10.5240/foo")
        assert len(sink.records) == 1
        rec = sink.records[0]
        assert rec.method == "GET"
        assert rec.response_status == 200
        assert rec.exception is None

    def test_authorization_redacted_in_trace(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<FullMetadata/>")

        sink = ListSink()
        try:
            with make_client(handler, tracing=sink) as client:
                client.resolve("10.5240/foo")
        except Exception:
            pass  # resolve might fail parsing, doesn't matter for this test
        # Find the Authorization header in the captured trace
        rec = sink.records[0]
        auth_values = [v for n, v in rec.request_headers if n.lower() == "authorization"]
        assert len(auth_values) == 1
        assert auth_values[0] == _REDACTED
        # Make sure the raw password shadow isn't anywhere in the trace
        full_text = rec.format_plain()
        assert "Eidr 10.5238/testuser" not in full_text

    def test_non_auth_headers_preserved_in_trace(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<FullMetadata/>")

        sink = ListSink()
        try:
            with make_client(handler, tracing=sink) as client:
                client.resolve("10.5240/foo")
        except Exception:
            pass
        rec = sink.records[0]
        header_dict = dict(rec.request_headers)
        assert header_dict.get("EIDR-Version") == "2.7.1"
        assert header_dict.get("Accept") == "text/xml"

    def test_retry_captures_multiple_records(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] < 2:
                return httpx.Response(503, text="<Busy/>")
            return httpx.Response(200, text="<FullMetadata/>")

        sink = ListSink()
        config = TransportConfig(
            max_retries=2,
            retry_backoff_base=0.001,
            retry_backoff_max=0.01,
            httpx_transport=httpx.MockTransport(handler),
        )
        client = Client(REGISTRY, CREDS, transport_config=config, tracing=sink)
        try:
            client.resolve("10.5240/foo")
        except Exception:
            pass
        finally:
            client.close()
        # Should have captured both the 503 attempt and the 200 retry
        assert len(sink.records) == 2
        assert sink.records[0].response_status == 503
        assert sink.records[0].attempt == 0
        assert sink.records[1].response_status == 200
        assert sink.records[1].attempt == 1

    def test_transport_failure_captures_exception(self) -> None:
        from eidr.errors import EIDRTransportError

        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("cannot connect")

        sink = ListSink()
        with pytest.raises(EIDRTransportError), make_client(handler, tracing=sink) as client:
            client.resolve("10.5240/foo")
        assert len(sink.records) >= 1
        rec = sink.records[0]
        assert rec.exception is not None
        assert "ConnectError" in rec.exception
        assert rec.response_status is None

    def test_tracing_off_by_default(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<FullMetadata/>")

        # No tracing arg — no sink, no overhead
        with make_client(handler) as client:
            assert client._trace_sink is None

    def test_tracing_true_uses_logger_sink(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text="<FullMetadata/>")

        with make_client(handler, tracing=True) as client:
            assert isinstance(client._trace_sink, LoggerSink)

    def test_tracing_failing_sink_does_not_impede_request(self) -> None:
        class BrokenSink:
            def write(self, record: TraceRecord) -> None:
                raise RuntimeError("sink exploded")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    f"<FullMetadata{NS}>"
                    "<BaseObjectData>"
                    "<ID>10.5240/foo</ID>"
                    "<StructuralType>Abstraction</StructuralType>"
                    "<Mode>AudioVisual</Mode>"
                    "<ReferentType>Movie</ReferentType>"
                    "<ResourceName>X</ResourceName>"
                    "<OriginalLanguage>en</OriginalLanguage>"
                    "<Status>valid</Status>"
                    "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
                    "</BaseObjectData>"
                    "</FullMetadata>"
                ),
            )

        # Sink exceptions must not propagate out of the request path.
        with make_client(handler, tracing=BrokenSink()) as client:
            rec = client.resolve("10.5240/foo")
        assert rec is not None


# ─────────────────────────────────────────────────────────────────────────────
# Body-size limits and redaction (M6 review item #5)
# ─────────────────────────────────────────────────────────────────────────────


class TestTraceBodyLimits:
    """Verify the trace body-size and body-redaction knobs."""

    def _large_record_response(self) -> str:
        """A FullMetadata response whose body length exceeds typical limits."""
        # Generate a body around 200 KB so default max_body_chars (100 KB)
        # triggers truncation.
        padding = "<Description>" + ("x" * 210_000) + "</Description>"
        return (
            f"<FullMetadata{NS}>"
            "<BaseObjectData>"
            "<ID>10.5240/foo</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>X</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
            f"{padding}"
            "</BaseObjectData>"
            "</FullMetadata>"
        )

    def test_default_truncates_large_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._large_record_response())

        sink = ListSink()
        with make_client(handler, tracing=sink) as client:
            client.resolve("10.5240/foo")
        rec = sink.records[0]
        assert rec.response_body is not None
        # Default limit is 100_000 chars; truncation marker appended.
        assert "chars truncated]" in rec.response_body
        # The captured body shouldn't be the full 210K+ bytes.
        assert len(rec.response_body) < 120_000

    def test_none_disables_truncation(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._large_record_response())

        sink = ListSink()
        with make_client(handler, tracing=sink, trace_max_body_chars=None) as client:
            client.resolve("10.5240/foo")
        rec = sink.records[0]
        assert rec.response_body is not None
        # Full body captured — no truncation marker.
        assert "chars truncated]" not in rec.response_body
        assert len(rec.response_body) > 200_000

    def test_redact_bodies_replaces_both_directions(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._large_record_response())

        sink = ListSink()
        with make_client(handler, tracing=sink, trace_redact_bodies=True) as client:
            client.resolve("10.5240/foo")
        rec = sink.records[0]
        # Response body replaced with marker; request body None for GET.
        assert rec.response_body is not None
        assert rec.response_body.startswith("[REDACTED ")
        assert "chars]" in rec.response_body
        # Sensitive header redaction still applies regardless.
        auth_values = [v for n, v in rec.request_headers if n.lower() == "authorization"]
        assert len(auth_values) == 1
        assert "REDACTED" in auth_values[0]

    def test_redaction_overrides_truncation(self) -> None:
        # When both are set, redaction wins (the body is replaced entirely,
        # not truncated).
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=self._large_record_response())

        sink = ListSink()
        with make_client(
            handler,
            tracing=sink,
            trace_max_body_chars=100,
            trace_redact_bodies=True,
        ) as client:
            client.resolve("10.5240/foo")
        rec = sink.records[0]
        assert rec.response_body is not None
        assert rec.response_body.startswith("[REDACTED ")
