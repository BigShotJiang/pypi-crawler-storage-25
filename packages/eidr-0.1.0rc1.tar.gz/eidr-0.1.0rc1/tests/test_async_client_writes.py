"""End-to-end write-operation tests for :class:`AsyncClient`.

Parallels ``test_client_writes.py``. Verifies wire shape (URL,
headers, body) and response handling (AsyncToken vs record), plus
the sync-under-load fallback path where an ``immediate=True``
register returns an :class:`AsyncToken` instead of a record.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

import httpx
import pytest

from eidr.client import (
    AsyncClient,
    AsyncToken,
    DedupeMode,
    ListSink,
    RelationshipType,
    TokenStatus,
    TraceRecord,
)
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.content import ContentRecord
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test",
)

READONLY = Registry(
    name="RO",
    url="https://ro.example/EIDR",
    writable=False,
    description="Read-only",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)

NS = 'xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _content_record_xml(*, with_id: bool = True) -> bytes:
    id_elem = "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>" if with_id else ""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<FullMetadata {NS}>"
        "<BaseObjectData>"
        f"{id_elem}"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    ).encode()


def _content_record(**kwargs: object) -> ContentRecord:
    return ContentRecord.from_xml(_content_record_xml(**kwargs))  # type: ignore[arg-type]


def _success_envelope_with_token(token: str = "tok-abc") -> str:
    return (
        f"<Response {NS}>"
        "<Status><Code>0</Code><Type>Success</Type></Status>"
        f"<Token>{token}</Token>"
        "</Response>"
    )


def _success_envelope() -> str:
    return f"<Response {NS}><Status><Code>0</Code><Type>Success</Type></Status></Response>"


def _registered_record_xml() -> str:
    return (
        f"<FullMetadata {NS}>"
        "<BaseObjectData>"
        "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>Test Movie</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        "<Administrators><Registrant>10.5237/FFDA-9947</Registrant></Administrators>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
    tracing: ListSink | None = None,
) -> AsyncClient:
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        async_httpx_transport=httpx.MockTransport(handler),
    )
    return AsyncClient(registry, CREDS, transport_config=config, tracing=tracing)


# ─── register ───────────────────────────────────────────────────────────────


class TestAsyncRegister:
    async def test_posts_to_register_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["immediate"] = request.headers.get("Immediate-Response")
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_record_xml())

        async with make_client(handler) as client:
            result = await client.register(_content_record(), immediate=True)

        assert captured["url"] == "https://test.example/EIDR/register/"
        assert captured["method"] == "POST"
        assert captured["immediate"] == "true"
        body = cast(str, captured["body"])
        assert '<Create type="CreateBasic">' in body
        assert isinstance(result, ContentRecord)

    async def test_async_returns_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.headers.get("Immediate-Response") == "false"
            return httpx.Response(200, text=_success_envelope_with_token())

        async with make_client(handler) as client:
            result = await client.register(_content_record(), immediate=False)

        assert isinstance(result, AsyncToken)
        assert result.value == "tok-abc"
        # Token is bound to this client for future polling.
        assert result._client is client

    async def test_sync_under_load_fallback(self) -> None:
        """Per REST API §2.1.1, an immediate=True call may return a
        token if the registry falls back to async processing under
        load. The AsyncClient must handle this gracefully."""

        def handler(request: httpx.Request) -> httpx.Response:
            # Client asked for immediate=true; registry deflected to async.
            assert request.headers.get("Immediate-Response") == "true"
            return httpx.Response(200, text=_success_envelope_with_token("deflected-tok"))

        async with make_client(handler) as client:
            result = await client.register(_content_record(), immediate=True)

        # We asked for immediate but got a token — caller must handle both
        assert isinstance(result, AsyncToken)
        assert result.value == "deflected-tok"

    async def test_dedupe_mode_appears_in_envelope(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope_with_token())

        async with make_client(handler) as client:
            await client.register(
                _content_record(),
                immediate=False,
                dedupe_mode=DedupeMode.MANUAL,
            )
        assert 'dedupMode="manual"' in cast(str, captured["body"])

    async def test_readonly_registry_refuses(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        from eidr.errors import EIDRReadOnlyRegistryError

        async with make_client(handler, registry=READONLY) as client:
            with pytest.raises(EIDRReadOnlyRegistryError):
                await client.register(_content_record(), immediate=True)


# ─── match ──────────────────────────────────────────────────────────────────


class TestAsyncMatch:
    async def test_posts_to_match_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["immediate"] = request.headers.get("Immediate-Response")
            return httpx.Response(200, text=_registered_record_xml())

        async with make_client(handler) as client:
            await client.match(_content_record())

        assert captured["url"] == "https://test.example/EIDR/match/"
        # Match is always immediate
        assert captured["immediate"] == "true"


# ─── modify ─────────────────────────────────────────────────────────────────


class TestAsyncModify:
    async def test_posts_to_modify_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_registered_record_xml())

        async with make_client(handler) as client:
            await client.modify(_content_record(), immediate=True)

        assert captured["url"] == "https://test.example/EIDR/modify/"
        body = cast(str, captured["body"])
        assert '<Modify type="CreateBasic">' in body
        assert "<ID>10.5240/0000-02ED-1DCE-6AAF-99F7-M</ID>" in body

    async def test_requires_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("Transport should not be called")

        async with make_client(handler) as client:
            with pytest.raises(ValueError, match=r"record\.id"):
                await client.modify(_content_record(with_id=False))


# ─── delete / promote / alias ───────────────────────────────────────────────


class TestAsyncDelete:
    async def test_delete_immediate_returns_none(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            result = await client.delete("10.5240/DOOMED", immediate=True)

        assert "<Delete><ID>10.5240/DOOMED</ID></Delete>" in cast(str, captured["body"])
        assert result is None

    async def test_delete_async_returns_token(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token("del-1"))

        async with make_client(handler) as client:
            tok = await client.delete("10.5240/X", immediate=False)
        assert isinstance(tok, AsyncToken)
        assert tok.value == "del-1"


class TestAsyncPromote:
    async def test_promote_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.promote("10.5240/X", immediate=True)

        assert "<Promote><ID>10.5240/X</ID></Promote>" in cast(str, captured["body"])


class TestAsyncAlias:
    async def test_alias_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.alias("10.5240/SRC", "10.5240/TGT", immediate=True)

        body = cast(str, captured["body"])
        assert "<Alias>" in body
        assert "<ID>10.5240/SRC</ID>" in body
        assert "<TargetID>10.5240/TGT</TargetID>" in body


# ─── relationships ──────────────────────────────────────────────────────────


class TestAsyncRelationships:
    async def test_add_relationship_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        info = "<PromotionInfo><ID>10.5240/TGT</ID></PromotionInfo>"
        async with make_client(handler) as client:
            await client.add_relationship(
                "10.5240/SRC",
                RelationshipType.PROMOTIONAL,
                info,
                immediate=True,
            )

        body = cast(str, captured["body"])
        assert '<AddRelationship type="PromotionalRelationship">' in body
        assert info in body

    async def test_remove_relationship_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        async with make_client(handler) as client:
            await client.remove_relationship(
                "10.5240/SRC",
                RelationshipType.COMPOSITE,
                immediate=True,
            )
        body = cast(str, captured["body"])
        assert '<RemoveRelationship type="CompositeRelationship">' in body

    async def test_replace_relationship_shape(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text=_success_envelope())

        info = "<PackagingInfo><ID>10.5240/P</ID></PackagingInfo>"
        async with make_client(handler) as client:
            await client.replace_relationship(
                "10.5240/SRC",
                RelationshipType.PACKAGING,
                info,
                immediate=True,
            )
        body = cast(str, captured["body"])
        assert '<ReplaceRelationship type="PackagingRelationship">' in body
        assert info in body


# ─── wait_timeout polling ───────────────────────────────────────────────────


class TestAsyncWaitTimeout:
    async def test_wait_returns_token_when_still_pending(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] == 1:
                return httpx.Response(200, text=_success_envelope_with_token("pending-tok"))
            return httpx.Response(
                200,
                text=(
                    f"<Response {NS}>"
                    "<Status><Code>0</Code><Type>Success</Type></Status>"
                    "<RequestStatusResults>"
                    "<OperationStatus>"
                    "<Token>sub-pending</Token>"
                    "<Status><Code>2</Code><Type>pending</Type></Status>"
                    "</OperationStatus>"
                    "</RequestStatusResults>"
                    "</Response>"
                ),
            )

        async with make_client(handler) as client:
            result = await client.register(
                _content_record(),
                immediate=False,
                wait_timeout=0.05,
            )
        assert isinstance(result, AsyncToken)
        assert result.status is TokenStatus.PENDING

    async def test_wait_none_does_not_poll(self) -> None:
        poll_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            if "/status/" in str(request.url):
                poll_count[0] += 1
            return httpx.Response(200, text=_success_envelope_with_token("t"))

        async with make_client(handler) as client:
            await client.register(_content_record(), immediate=False, wait_timeout=None)
        assert poll_count[0] == 0


# ─── tracing captures async writes ──────────────────────────────────────────


class TestAsyncTracing:
    async def test_register_captures_full_request_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_registered_record_xml())

        sink = ListSink()
        async with make_client(handler, tracing=sink) as client:
            await client.register(_content_record(), immediate=True)

        assert len(sink.records) == 1
        rec: TraceRecord = sink.records[0]
        assert rec.method == "POST"
        assert rec.request_body is not None
        assert "--314159" in rec.request_body
        assert '<Create type="CreateBasic">' in rec.request_body

    async def test_authorization_redacted_in_async_trace(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_success_envelope_with_token())

        sink = ListSink()
        async with make_client(handler, tracing=sink) as client:
            await client.register(_content_record(), immediate=False)

        rec = sink.records[0]
        auth_values = [v for n, v in rec.request_headers if n.lower() == "authorization"]
        assert len(auth_values) == 1
        assert "REDACTED" in auth_values[0]
