"""Tests for pre-submission validation on :class:`PartyRecord`
and :class:`ServiceRecord`."""

from __future__ import annotations

import pytest

from eidr.errors import EIDRValidationError
from eidr.models import PartyRecord, ServiceRecord, ValidationReport

PARTY_ID = "10.5237/7791-8534"
SERVICE_ID = "10.5239/7791-8534"
PARENT_SERVICE_ID = "10.5239/8534-7791"

NS = ' xmlns="http://www.eidr.org/schema" xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'


def _wrap_party(inner: str) -> bytes:
    return f"<Party{NS}>{inner}</Party>".encode()


def _wrap_service(inner: str) -> bytes:
    return f"<Service{NS}>{inner}</Service>".encode()


def _valid_party_body(with_id: bool = True) -> str:
    parts = []
    if with_id:
        parts.append(f"<ID>{PARTY_ID}</ID>")
    parts.extend(
        [
            "<PartyName><md:DisplayName>Acme Studios</md:DisplayName></PartyName>",
            "<ContactInfo>"
            "<Name>Jane Doe</Name>"
            "<PrimaryEmail>jane@acme.example</PrimaryEmail>"
            "</ContactInfo>",
            "<Active>true</Active>",
        ]
    )
    return "".join(parts)


def _valid_service_body(with_id: bool = True) -> str:
    parts = []
    if with_id:
        parts.append(f"<ID>{SERVICE_ID}</ID>")
    parts.extend(
        [
            "<ServiceName><md:DisplayName>Netflix</md:DisplayName></ServiceName>",
            "<Active>true</Active>",
        ]
    )
    return "".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# Party validation
# ─────────────────────────────────────────────────────────────────────────────


class TestPartyHappyPath:
    def test_minimal_valid_party_passes(self) -> None:
        rec = PartyRecord.from_xml(_wrap_party(_valid_party_body()))
        report = rec.validate()
        assert isinstance(report, ValidationReport)
        assert not report, f"Unexpected errors: {list(report)}"

    def test_strict_no_op_on_valid(self) -> None:
        rec = PartyRecord.from_xml(_wrap_party(_valid_party_body()))
        rec.validate_strict()  # no raise


class TestPartyRequiredFields:
    def test_missing_party_name(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Party/PartyName" for e in report)

    def test_party_name_missing_display_name(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName></PartyName>"
                "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        # Empty PartyName fires the outer required check, not the inner one
        assert any(e.path.startswith("Party/PartyName") for e in report if e.path)

    def test_missing_contact_info(self) -> None:
        # Per the schema, ContactInfo is required. The library matches
        # the schema. (A future schema revision may relax this, at
        # which point the library will follow suit.)
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Party/ContactInfo" for e in report)

    def test_contact_info_missing_name(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                "<ContactInfo><PrimaryEmail>x@y.z</PrimaryEmail></ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Party/ContactInfo/Name" for e in report)

    def test_contact_info_missing_primary_email(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                "<ContactInfo><Name>Jane</Name></ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Party/ContactInfo/PrimaryEmail" for e in report)

    def test_missing_active(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Party/Active" for e in report)


class TestPartyBooleanValidation:
    def test_non_boolean_active_rejected(self) -> None:
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
                "<Active>yes</Active>"
            )
        )
        report = rec.validate()
        assert any(
            e.code == "record.vocabulary.invalid" and e.path == "Party/Active" for e in report
        )

    def test_all_valid_boolean_literals(self) -> None:
        for literal in ("true", "false", "1", "0"):
            rec = PartyRecord.from_xml(
                _wrap_party(
                    f"<ID>{PARTY_ID}</ID>"
                    "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
                    "<ContactInfo>"
                    "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                    "</ContactInfo>"
                    f"<Active>{literal}</Active>"
                )
            )
            report = rec.validate()
            assert not any(e.path == "Party/Active" for e in report), (
                f"xs:boolean literal {literal!r} should validate"
            )


class TestPartyCardinality:
    def test_alternate_party_name_at_limit_ok(self) -> None:
        alts = "".join(f"<AlternatePartyName>alt{i}</AlternatePartyName>" for i in range(20))
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>" + alts + "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert not any(e.code == "party.cardinality.exceeded" for e in report)

    def test_alternate_party_name_over_limit_rejected(self) -> None:
        alts = "".join(f"<AlternatePartyName>alt{i}</AlternatePartyName>" for i in range(21))
        rec = PartyRecord.from_xml(
            _wrap_party(
                f"<ID>{PARTY_ID}</ID>"
                "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>" + alts + "<ContactInfo>"
                "<Name>x</Name><PrimaryEmail>x@y.z</PrimaryEmail>"
                "</ContactInfo>"
                "<Active>true</Active>"
            )
        )
        report = rec.validate()
        assert any(e.code == "party.cardinality.exceeded" for e in report)


class TestPartyRequireIdFlag:
    def test_id_optional_by_default(self) -> None:
        rec = PartyRecord.from_xml(_wrap_party(_valid_party_body(with_id=False)))
        assert not rec.validate()

    def test_id_required_when_flag_set(self) -> None:
        rec = PartyRecord.from_xml(_wrap_party(_valid_party_body(with_id=False)))
        report = rec.validate(mode="modify")
        assert any(e.path == "Party/ID" for e in report)

    def test_validate_strict_raises(self) -> None:
        rec = PartyRecord.from_xml(_wrap_party(_valid_party_body(with_id=False)))
        with pytest.raises(EIDRValidationError) as exc_info:
            rec.validate_strict(mode="modify")
        assert exc_info.value.errors


# ─────────────────────────────────────────────────────────────────────────────
# Service validation
# ─────────────────────────────────────────────────────────────────────────────


class TestServiceHappyPath:
    def test_minimal_valid_service_passes(self) -> None:
        rec = ServiceRecord.from_xml(_wrap_service(_valid_service_body()))
        assert not rec.validate()


class TestServiceRequiredFields:
    def test_missing_service_name(self) -> None:
        rec = ServiceRecord.from_xml(_wrap_service(f"<ID>{SERVICE_ID}</ID><Active>true</Active>"))
        report = rec.validate()
        assert any(e.path == "Service/ServiceName" for e in report)

    def test_missing_active(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap_service(
                f"<ID>{SERVICE_ID}</ID>"
                "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
            )
        )
        report = rec.validate()
        assert any(e.path == "Service/Active" for e in report)


class TestServiceDeliveryModel:
    def test_valid_delivery_models_ok(self) -> None:
        for model in ("Linear", "VOD", "Other"):
            rec = ServiceRecord.from_xml(
                _wrap_service(_valid_service_body() + f"<DeliveryModel>{model}</DeliveryModel>")
            )
            report = rec.validate()
            assert not any(e.code == "service.vocabulary.invalid" for e in report), (
                f"{model} should validate"
            )

    def test_invalid_delivery_model_rejected(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap_service(_valid_service_body() + "<DeliveryModel>Holographic</DeliveryModel>")
        )
        report = rec.validate()
        assert any(e.code == "service.vocabulary.invalid" for e in report)

    def test_multiple_delivery_models_reports_each(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap_service(
                _valid_service_body()
                + "<DeliveryModel>Linear</DeliveryModel>"
                + "<DeliveryModel>Garbage</DeliveryModel>"
                + "<DeliveryModel>VOD</DeliveryModel>"
            )
        )
        report = rec.validate()
        bad = [e for e in report if e.code == "service.vocabulary.invalid"]
        assert len(bad) == 1  # only the "Garbage" entry
        assert "Garbage" in (bad[0].value or "")


class TestServiceParent:
    def test_valid_parent_ok(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap_service(_valid_service_body() + f"<Parent>{PARENT_SERVICE_ID}</Parent>")
        )
        report = rec.validate()
        assert not any(e.code == "service.parent.invalid" for e in report)

    def test_invalid_parent_rejected(self) -> None:
        rec = ServiceRecord.from_xml(
            _wrap_service(_valid_service_body() + "<Parent>not-an-eidr-id</Parent>")
        )
        report = rec.validate()
        assert any(e.code == "service.parent.invalid" for e in report)


class TestServiceCardinality:
    def test_over_limit_alternate_service_names(self) -> None:
        alts = "".join(f"<AlternateServiceName>alt{i}</AlternateServiceName>" for i in range(11))
        rec = ServiceRecord.from_xml(_wrap_service(_valid_service_body() + alts))
        report = rec.validate()
        assert any(
            e.code == "service.cardinality.exceeded" and e.path == "Service/AlternateServiceName"
            for e in report
        )

    def test_over_limit_delivery_models(self) -> None:
        # DeliveryModel is capped at 4
        dms = "".join("<DeliveryModel>Linear</DeliveryModel>" for _ in range(5))
        rec = ServiceRecord.from_xml(_wrap_service(_valid_service_body() + dms))
        report = rec.validate()
        assert any(
            e.code == "service.cardinality.exceeded" and e.path == "Service/DeliveryModel"
            for e in report
        )


class TestServiceRequireIdFlag:
    def test_id_optional_by_default(self) -> None:
        rec = ServiceRecord.from_xml(_wrap_service(_valid_service_body(with_id=False)))
        assert not rec.validate()

    def test_id_required_when_flag_set(self) -> None:
        rec = ServiceRecord.from_xml(_wrap_service(_valid_service_body(with_id=False)))
        report = rec.validate(mode="modify")
        assert any(e.path == "Service/ID" for e in report)
