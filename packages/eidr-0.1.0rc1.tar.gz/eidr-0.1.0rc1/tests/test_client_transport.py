"""Tests for :mod:`eidr.client._http`.

Uses :class:`httpx.MockTransport` to drive the transport without
actually hitting the network. Each test wires its own mock handler.
"""

from __future__ import annotations

from collections.abc import Callable

import httpx
import pytest

from eidr.client._http import (
    TransportConfig,
    _build_multipart_body,
    _form_field_name,
    _Transport,
)
from eidr.credentials import Credentials
from eidr.errors import (
    EIDRAuthenticationError,
    EIDRHTTPStatusError,
    EIDRReadOnlyRegistryError,
    EIDRTimeoutError,
    EIDRTransportError,
    EIDRUncertainWriteError,
)
from eidr.registries import Registry

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures — registries and credentials for tests
# ─────────────────────────────────────────────────────────────────────────────


REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)

READONLY_REGISTRY = Registry(
    name="TEST_RO",
    url="https://test-ro.example/EIDR",
    writable=False,
    description="Read-only test registry",
)

CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


def make_transport(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    registry: Registry = REGISTRY,
    credentials: Credentials | None = CREDS,
    max_retries: int = 2,
    retry_backoff_base: float = 0.001,  # Minimize test runtime
) -> _Transport:
    """Spin up a _Transport wired to a MockTransport handler."""
    config = TransportConfig(
        max_retries=max_retries,
        retry_backoff_base=retry_backoff_base,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return _Transport(
        registry=registry,
        credentials=credentials,
        config=config,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Multipart framing
# ─────────────────────────────────────────────────────────────────────────────


class TestMultipartBody:
    def test_basic_shape(self) -> None:
        body = _build_multipart_body("batch", "<Request/>")
        text = body.decode("utf-8")
        assert text.startswith("--314159\r\n")
        assert text.endswith("--314159")
        assert "Content-Disposition: form-data; name=batch" in text
        assert "Content-Transfer-Encoding: binary" in text
        assert "<Request/>" in text

    def test_payload_appears_after_blank_line(self) -> None:
        body = _build_multipart_body("query", "<Q/>")
        text = body.decode("utf-8")
        # Blank line separates headers from content
        assert "binary\r\n\r\n<Q/>" in text

    def test_bytes_encoding_is_utf8(self) -> None:
        body = _build_multipart_body("batch", "<X>café</X>")
        # UTF-8 encoded non-ASCII passes through
        assert "café".encode() in body


class TestFormFieldNames:
    def test_register_maps_to_batch(self) -> None:
        assert _form_field_name("/register/") == "batch"
        assert _form_field_name("/register/some-id") == "batch"

    def test_query_maps_to_query(self) -> None:
        assert _form_field_name("/query/") == "query"

    def test_status_maps_to_statusrequest(self) -> None:
        assert _form_field_name("/status/") == "statusrequest"
        assert _form_field_name("/status/abc-123") == "statusrequest"

    def test_party_create_maps_to_party(self) -> None:
        assert _form_field_name("/party/create/") == "party"

    def test_service_query_maps_to_serviceQuery(self) -> None:
        assert _form_field_name("/service/query/") == "serviceQuery"

    def test_unknown_resource_defaults_to_batch(self) -> None:
        assert _form_field_name("/something/weird/") == "batch"

    def test_query_string_stripped_before_lookup(self) -> None:
        assert _form_field_name("/query/?type=full") == "query"


# ─────────────────────────────────────────────────────────────────────────────
# GET — read path
# ─────────────────────────────────────────────────────────────────────────────


class TestGetHappy:
    def test_200_returns_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/EIDR/object/10.5240/foo"
            return httpx.Response(200, text="<FullMetadata/>")

        t = make_transport(handler)
        body = t.get("/object/10.5240/foo")
        assert body == "<FullMetadata/>"
        t.close()

    def test_eidr_version_header_sent(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["eidr_version"] = request.headers.get("EIDR-Version")
            captured["user_agent"] = request.headers.get("User-Agent")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.get("/object/x")
        assert captured["eidr_version"] == "2.7.1"
        assert "eidr-python-sdk" in captured["user_agent"]
        t.close()

    def test_authorization_header_included_when_creds_present(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["auth"] = request.headers.get("Authorization")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.get("/object/x")
        assert captured["auth"] is not None
        assert captured["auth"].startswith("Eidr 10.5238/testuser:10.5237/FFDA-9947:")
        t.close()

    def test_no_authorization_header_when_no_creds(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["auth"] = request.headers.get("Authorization")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler, credentials=None)
        t.get("/object/x")
        assert captured["auth"] is None
        t.close()

    def test_accept_header_is_text_xml(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["accept"] = request.headers.get("Accept")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.get("/object/x")
        assert captured["accept"] == "text/xml"
        t.close()


class TestGetRetry:
    def test_5xx_retried(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] < 3:
                return httpx.Response(503, text="<Busy/>")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        body = t.get("/object/x")
        assert body == "<Ok/>"
        assert attempts[0] == 3
        t.close()

    def test_5xx_exhausted_raises_http_status(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(503, text="<Busy/>")

        t = make_transport(handler, max_retries=1)
        with pytest.raises(EIDRHTTPStatusError) as exc_info:
            t.get("/object/x")
        assert exc_info.value.status_code == 503
        t.close()

    def test_4xx_not_retried(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            return httpx.Response(404, text="<NotFound/>")

        t = make_transport(handler)
        with pytest.raises(EIDRHTTPStatusError) as exc_info:
            t.get("/object/x")
        assert exc_info.value.status_code == 404
        assert attempts[0] == 1  # No retries on 4xx
        t.close()

    def test_401_raises_auth_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="<Auth/>")

        t = make_transport(handler)
        with pytest.raises(EIDRAuthenticationError):
            t.get("/object/x")
        t.close()

    def test_403_raises_auth_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(403, text="<Auth/>")

        t = make_transport(handler)
        with pytest.raises(EIDRAuthenticationError):
            t.get("/object/x")
        t.close()

    def test_connection_error_retried(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] < 2:
                raise httpx.ConnectError("connection refused")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        body = t.get("/object/x")
        assert body == "<Ok/>"
        t.close()

    def test_timeout_retried_then_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("slow")

        t = make_transport(handler, max_retries=1)
        with pytest.raises(EIDRTimeoutError):
            t.get("/object/x")
        t.close()


# ─────────────────────────────────────────────────────────────────────────────
# POST — write path
# ─────────────────────────────────────────────────────────────────────────────


class TestPostHappy:
    def test_200_returns_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.headers["Content-Type"].startswith(
                "multipart/form-data; boundary=314159"
            )
            assert request.headers["Immediate-Response"] == "false"
            return httpx.Response(200, text="<Response><Status><Code>0</Code></Status></Response>")

        t = make_transport(handler)
        body = t.post("/register/", "<Request/>", immediate=False)
        assert "<Code>0</Code>" in body
        t.close()

    def test_immediate_header_true(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["immediate"] = request.headers.get("Immediate-Response")
            return httpx.Response(200, text="<Response><Status><Code>0</Code></Status></Response>")

        t = make_transport(handler)
        t.post("/register/", "<Request/>", immediate=True)
        assert captured["immediate"] == "true"
        t.close()

    def test_multipart_body_content(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = request.content.decode("utf-8")
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.post("/register/", "<Request>X</Request>", immediate=False)
        assert captured["body"].startswith("--314159")
        assert "name=batch" in captured["body"]
        assert "<Request>X</Request>" in captured["body"]
        t.close()

    def test_read_only_registry_refuses_post(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise AssertionError("Transport should not have been called")

        t = make_transport(handler, registry=READONLY_REGISTRY)
        with pytest.raises(EIDRReadOnlyRegistryError) as exc_info:
            t.post("/register/", "<Request/>", immediate=False)
        assert exc_info.value.registry_name == "TEST_RO"
        t.close()


class TestPostUncertainWrite:
    """Once the body is on the wire, we surface uncertainty rather than retry."""

    def test_timeout_during_post_raises_uncertain(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("slow")

        t = make_transport(handler)
        with pytest.raises(EIDRUncertainWriteError) as exc_info:
            t.post("/register/", "<Request/>", immediate=False)
        assert "may or may not have processed" in str(exc_info.value)
        t.close()

    def test_generic_transport_error_raises_uncertain(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadError("broken")

        t = make_transport(handler)
        with pytest.raises(EIDRUncertainWriteError):
            t.post("/register/", "<Request/>", immediate=False)
        t.close()

    def test_connection_error_retried(self) -> None:
        attempts = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            attempts[0] += 1
            if attempts[0] < 2:
                raise httpx.ConnectError("cant connect")
            return httpx.Response(200, text="<Response><Status><Code>0</Code></Status></Response>")

        t = make_transport(handler)
        body = t.post("/register/", "<Request/>", immediate=False)
        assert "<Code>0</Code>" in body
        t.close()

    def test_connect_error_exhausts_to_transport_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("nope")

        t = make_transport(handler, max_retries=1)
        with pytest.raises(EIDRTransportError):
            t.post("/register/", "<Request/>", immediate=False)
        t.close()

    def test_5xx_raises_uncertain_write_no_retry(self) -> None:
        """A 5xx after the body has been transmitted must NOT be
        retried — the registry may have processed the request before
        failing. The transport raises :class:`EIDRUncertainWriteError`
        and lets the caller decide how to reconcile.

        Matches Java SDK semantics: ``Post.java`` flips
        ``safetoretry = false`` the moment body transmission begins.
        """
        from eidr.errors import EIDRUncertainWriteError

        attempts: list[int] = []

        def handler(request: httpx.Request) -> httpx.Response:
            attempts.append(1)
            return httpx.Response(503, text="<Busy/>")

        # Even with max_retries=2 (which would have allowed retries
        # before this fix), there should still be exactly one attempt.
        t = make_transport(handler, max_retries=2)
        with pytest.raises(EIDRUncertainWriteError) as exc_info:
            t.post("/register/", "<Request/>", immediate=False)
        assert "503" in str(exc_info.value)
        assert len(attempts) == 1, (
            f"expected exactly 1 POST attempt (no retry), got {len(attempts)}"
        )
        t.close()


# ─────────────────────────────────────────────────────────────────────────────
# URL construction
# ─────────────────────────────────────────────────────────────────────────────


class TestURLConstruction:
    def test_resource_path_appended_to_base(self) -> None:
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.get("/object/10.5240/abc")
        assert captured["url"] == "https://test.example/EIDR/object/10.5240/abc"
        t.close()

    def test_leading_slash_tolerated(self) -> None:
        """Both '/object/x' and 'object/x' should work."""
        captured = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(str(request.url))
            return httpx.Response(200, text="<Ok/>")

        t = make_transport(handler)
        t.get("/object/x")
        t.get("object/x")
        assert captured[0] == captured[1]
        t.close()
