"""Unit tests for the M10 surface (Java-parity gap closeout).

Covers:

- ``modification_base(asset_id, creation_type=...)`` — the
  Content-side primitive added in M10-C. Verifies URL construction,
  query-parameter encoding of the ``type=Create{CreationType}``
  parameter, and parsing of the registry's response into a typed
  ``ContentRecord``.

The M10-B service-graph reads (``service_parent``,
``service_children`` with ``include_inactive``) live in
``test_client_m9_writes.py`` next to their existing M9 siblings —
they're tightly coupled to the Service test fixtures already there.

The M10-A status-lookup variants will get their own block here
when implemented.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC

import httpx
import pytest

from eidr.client import Client
from eidr.client._http import TransportConfig
from eidr.credentials import Credentials
from eidr.models.enums import CreationType
from eidr.registries import Registry

REGISTRY = Registry(
    name="TEST",
    url="https://test.example/EIDR",
    writable=True,
    description="Test registry",
)
CREDS = Credentials(
    user_id="10.5238/testuser",
    party_id="10.5237/FFDA-9947",
    password="testpw",
)


def make_client(
    handler: Callable[[httpx.Request], httpx.Response],
) -> Client:
    """Build a sync Client with a MockTransport."""
    config = TransportConfig(
        max_retries=0,
        retry_backoff_base=0.001,
        retry_backoff_max=0.01,
        httpx_transport=httpx.MockTransport(handler),
    )
    return Client(REGISTRY, CREDS, transport_config=config)


# A modification-base response body. The live registry returns this
# as a <Response> envelope wrapping the record body alongside <Status>
# (discovered in M10 v1 integration testing). The wrapper element name
# is <BaseObjectData> for Basic-creation-type records.
#
# The SDK handles both this envelope-wrapped shape AND a bare-record
# shape (for forward compatibility, in case the registry's behavior
# changes or different endpoints use different shapes).
GREAT_TRAIN_ROBBERY = "10.5240/7791-8534-2C23-9030-8610-5"


def _modification_base_envelope_response(
    asset_id: str = GREAT_TRAIN_ROBBERY,
) -> str:
    """Envelope-wrapped modification-base response (live registry shape)."""
    return (
        '<Response xmlns="http://www.eidr.org/schema" '
        'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md" '
        'version="2.7.1">'
        "<Status><Code>0</Code><Type>success</Type></Status>"
        "<BaseObjectData>"
        f"<ID>{asset_id}</ID>"
        "<StructuralType>Performance</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ResourceName>Test Title</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        '<AssociatedOrg idType="eidrPartyID" '
        'organizationID="10.5237/FFDA-9947" role="registrant"/>'
        "<ReleaseDate>2026</ReleaseDate>"
        "<CountryOfOrigin>US</CountryOfOrigin>"
        "<Status>valid</Status>"
        "<ReferentType>CreateBasic</ReferentType>"
        "<BasicData>"
        "<MovieInfo><Length>PT1H30M</Length></MovieInfo>"
        "</BasicData>"
        "</BaseObjectData>"
        "</Response>"
    )


def _modification_base_bare_response(
    asset_id: str = GREAT_TRAIN_ROBBERY,
) -> str:
    """Bare-record modification-base response.

    Used to test the SDK's dual-shape handling — if a registry
    variant returns a known record root (e.g. ``<FullMetadata>``)
    bare, the SDK should also accept that.
    """
    return (
        '<FullMetadata xmlns="http://www.eidr.org/schema" '
        'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
        "<BaseObjectData>"
        f"<ID>{asset_id}</ID>"
        "<StructuralType>Performance</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ResourceName>Test Title</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        '<AssociatedOrg idType="eidrPartyID" '
        'organizationID="10.5237/FFDA-9947" role="registrant"/>'
        "<ReleaseDate>2026</ReleaseDate>"
        "<CountryOfOrigin>US</CountryOfOrigin>"
        "<Status>valid</Status>"
        "<ReferentType>CreateBasic</ReferentType>"
        "<BasicData>"
        "<MovieInfo><Length>PT1H30M</Length></MovieInfo>"
        "</BasicData>"
        "</BaseObjectData>"
        "</FullMetadata>"
    )


# Backwards-compat alias used by the older tests.
_content_record_xml = _modification_base_envelope_response


class TestModificationBase:
    """M10-C: ``modification_base(asset_id, creation_type=...)``."""

    def test_gets_modificationbase_endpoint(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, text=_content_record_xml())

        with make_client(handler) as client:
            client.modification_base(
                "10.5240/7791-8534-2C23-9030-8610-5",
                creation_type=CreationType.Basic,
            )

        assert captured["method"] == "GET"
        assert "/object/modificationbase/10.5240/7791-8534-2C23-9030-8610-5" in str(captured["url"])
        # CreationType.Basic → ?type=CreateBasic
        assert "type=CreateBasic" in str(captured["url"])

    def test_creation_type_param_is_create_plus_value(self) -> None:
        """Wire format: ``?type=Create{CreationType.value}``.

        The Java SDK constructs the query parameter as the literal
        string ``Create`` concatenated with the CreationType value
        (so ``CreationType.Series`` → ``CreateSeries``,
        ``CreationType.Episode`` → ``CreateEpisode``, etc.). This
        test pins that contract.
        """
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_record_xml())

        with make_client(handler) as client:
            client.modification_base(
                "10.5240/7791-8534-2C23-9030-8610-5",
                creation_type=CreationType.Series,
            )

        assert "type=CreateSeries" in str(captured["url"])

    def test_returns_typed_contentrecord(self) -> None:
        from eidr.models.content import ContentRecord

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_content_record_xml())

        with make_client(handler) as client:
            result = client.modification_base(
                "10.5240/7791-8534-2C23-9030-8610-5",
                creation_type=CreationType.Basic,
            )

        assert isinstance(result, ContentRecord)

    def test_accepts_eidrid_value_object(self) -> None:
        """The ``coerce_id_to_str`` regression pattern from M9 round 3."""
        from eidr.models.ids import EIDRID

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_content_record_xml())

        eidr_id = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        with make_client(handler) as client:
            client.modification_base(eidr_id, creation_type=CreationType.Basic)  # type: ignore[arg-type]

        assert "/object/modificationbase/10.5240/7791-8534-2C23-9030-8610-5" in str(captured["url"])

    def test_rejects_empty_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="non-empty"):
            client.modification_base("", creation_type=CreationType.Basic)

    def test_propagates_not_found_error(self) -> None:
        """Unknown asset → ``EIDRNotFoundError``, not silent None.

        Distinct from ``service_parent``, which deliberately
        translates not-found to None (root-of-tree case). For
        ``modification_base`` there's no "no modification base"
        case — if the asset doesn't exist, that's an error.
        """
        from eidr.errors import EIDRNotFoundError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>4</Code><Type>not found</Type></Status>"
                    "</Response>"
                ),
            )

        with make_client(handler) as client, pytest.raises(EIDRNotFoundError):
            client.modification_base(
                "10.5240/7791-8534-2C23-9030-8610-5",
                creation_type=CreationType.Basic,
            )

    def test_handles_envelope_wrapped_response(self) -> None:
        """Live registry shape (M10 v1 integration test): the body is
        a ``<Response>`` envelope with ``Code 0 success`` and the record
        as a sibling of ``<Status>``."""
        from eidr.models.content import ContentRecord

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_modification_base_envelope_response())

        with make_client(handler) as client:
            result = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

        assert isinstance(result, ContentRecord)

    def test_handles_bare_record_response(self) -> None:
        """Forward-compat: also accept a bare ``<FullMetadata>``-style
        response, in case a different endpoint variant or registry
        version returns the record directly."""
        from eidr.models.content import ContentRecord

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_modification_base_bare_response())

        with make_client(handler) as client:
            result = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

        assert isinstance(result, ContentRecord)

    def test_envelope_with_no_record_content_raises_protocol_error(self) -> None:
        """Defensive: a Code 0 envelope with only ``<Status>`` (no
        record sibling) is a registry shape change. Surface it as a
        clear ``EIDRProtocolError`` rather than crashing on a
        downstream parser."""
        from eidr.errors import EIDRProtocolError

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                text=(
                    '<Response xmlns="http://www.eidr.org/schema">'
                    "<Status><Code>0</Code><Type>success</Type></Status>"
                    "</Response>"
                ),
            )

        with (
            make_client(handler) as client,
            pytest.raises(EIDRProtocolError, match="no record content"),
        ):
            client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

    def test_modification_base_to_modify_round_trip(self) -> None:
        """Reviewer 1 flagged the workflow risk: the modification-base
        response uses ``<BaseObjectData>`` as the record root, but
        ``modify()`` (specifically ``_record_to_creation_inner``)
        previously only accepted ``<FullMetadata>`` /
        ``<SelfDefinedMetadata>`` / ``<ProvenanceMetadata>`` roots.

        This test pins the v2 fix: a ``modification_base()`` →
        mutate → ``modify()`` workflow now succeeds end-to-end.
        The modify body is built without errors and contains the
        expected ``<Modify type="CreateBasic">`` structure with the
        ``<BaseObjectData>`` properly wrapped in ``<Basic>``.
        """
        from eidr.client._operations import build_modify
        from eidr.models.enums import CreationType

        # Step 1: fetch a modification-base record (envelope shape).
        def base_handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_modification_base_envelope_response())

        with make_client(base_handler) as client:
            base = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

        # Step 2: serialize for modify (would happen inside modify()).
        record_xml = base.to_xml()
        assert record_xml.lstrip().startswith(b"<?xml") or b"<BaseObjectData" in record_xml

        # Step 3: build the modify inner XML. This is the path that
        # previously raised "Expected root <FullMetadata>...".
        inner = build_modify(
            record_xml,
            GREAT_TRAIN_ROBBERY,
            CreationType.Basic,
        )
        # Verify the resulting modify fragment has the expected structure.
        assert '<Modify type="CreateBasic">' in inner
        assert f"<ID>{GREAT_TRAIN_ROBBERY}</ID>" in inner
        assert "<Basic" in inner
        assert "<BaseObjectData>" in inner
        # Per the schema rule (creationFullInfo / creationSelfDefinedInfo
        # do not include <ID>), the inner BaseObjectData must NOT contain
        # the <ID> element — the registry assigns IDs on Create and the
        # outer <Modify><ID> carries it for Modify.
        assert f"<BaseObjectData><ID>{GREAT_TRAIN_ROBBERY}" not in inner, (
            "Inner <BaseObjectData> should have <ID> stripped"
        )

    def test_modification_base_non_basic_round_trip(self) -> None:
        """M11-C: modification base for non-Basic creation types.

        Non-Basic creation types (Series, Episode, etc.) include an
        ``<ExtraObjectMetadata>`` element alongside ``<BaseObjectData>``
        in the record body. The registry's modification-base envelope
        likely returns these as siblings of ``<Status>``; the SDK
        synthesizes a ``<FullMetadata>`` wrapper so they round-trip
        through the codec layer correctly.
        """
        from eidr.client._operations import build_modify
        from eidr.models.enums import CreationType

        series_envelope = (
            '<Response xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<Status><Code>0</Code><Type>success</Type></Status>"
            "<BaseObjectData>"
            f"<ID>{GREAT_TRAIN_ROBBERY}</ID>"
            "<StructuralType>AbstractionParent</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ResourceName>Test Series</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            '<AssociatedOrg idType="eidrPartyID" '
            'organizationID="10.5237/FFDA-9947" role="registrant"/>'
            "<ReleaseDate>2026</ReleaseDate>"
            "<CountryOfOrigin>US</CountryOfOrigin>"
            "<Status>valid</Status>"
            "<ReferentType>CreateSeries</ReferentType>"
            "</BaseObjectData>"
            "<ExtraObjectMetadata>"
            "<SeriesInfo><EndDate>2030</EndDate></SeriesInfo>"
            "</ExtraObjectMetadata>"
            "</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=series_envelope)

        with make_client(handler) as client:
            base = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Series)

        # Synthesized FullMetadata wrapper exposes the ID via the
        # standard accessor.
        assert str(base.id) == GREAT_TRAIN_ROBBERY

        # Round-trip through build_modify produces a well-formed
        # <Modify type="CreateSeries"> with both children present.
        inner = build_modify(base.to_xml(), GREAT_TRAIN_ROBBERY, CreationType.Series)
        assert '<Modify type="CreateSeries">' in inner
        assert "<Series" in inner
        assert "<BaseObjectData>" in inner
        assert "<ExtraObjectMetadata>" in inner
        assert "<SeriesInfo>" in inner

    def test_modification_base_handles_live_registry_byte_shape(self) -> None:
        """0.1.0b3 regression: the **actual byte shape** the live
        registry returns, captured from the M12 live integration trace.

        Two surprises from the live data:

        1. The registry wraps ``<BaseObjectData>`` in a creation-type
           element (``<Basic>``) — not a bare ``<BaseObjectData>``::

               <Response>
                 <Status>...</Status>
                 <Basic>
                   <BaseObjectData>...</BaseObjectData>
                 </Basic>
               </Response>

        2. The registry **omits ``<ID>``** from ``<BaseObjectData>`` —
           the asset ID is in the request URL, not the response body.

        Both are addressed in 0.1.0b3:
        - :func:`_extract_first_non_status_child` unwraps the
          creation-type wrapper.
        - :meth:`Client.modification_base` injects ``asset_id`` into
          ``record.base["ID"]`` when missing.
        """
        # Trimmed wire shape from the live trace (full version is
        # 7.6KB). Same envelope structure, abridged metadata.
        live_byte_shape = (
            b'<?xml version="1.0" encoding="UTF-8"?>'
            b'<Response xmlns="http://www.eidr.org/schema" '
            b'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md" '
            b'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            b'version="2.7.1">'
            b"<Status><Code>0</Code><Type>success</Type></Status>"
            b"<Basic>"
            b"<BaseObjectData>"
            b"<StructuralType>Abstraction</StructuralType>"
            b"<Mode>Visual</Mode>"
            b"<ReferentType>Short</ReferentType>"
            b'<ResourceName lang="en">The Great Train Robbery</ResourceName>'
            b'<OriginalLanguage mode="Visual" type="normal">en</OriginalLanguage>'
            b"<ReleaseDate>1903-12-01</ReleaseDate>"
            b"<CountryOfOrigin>US</CountryOfOrigin>"
            b"<Status>valid</Status>"
            b"<Administrators><Registrant>10.5237/2908-C010</Registrant></Administrators>"
            b"</BaseObjectData>"
            b"</Basic>"
            b"</Response>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content=live_byte_shape)

        with make_client(handler) as client:
            base = client.modification_base(GREAT_TRAIN_ROBBERY, creation_type=CreationType.Basic)

        # Body had no <ID>; SDK injects from the asset_id parameter.
        assert str(base.id) == GREAT_TRAIN_ROBBERY, (
            "modification_base must inject asset_id into the record "
            "since the registry's response body omits <ID>."
        )
        assert base.resource_name == "The Great Train Robbery"
        assert base.country_of_origin == ["US"]
        assert base.original_languages == ["en"]
        assert base.creation_type == CreationType.Basic

    def test_modification_base_auto_infers_basic(self) -> None:
        """``modification_base_auto`` resolves first to infer creation type."""
        from eidr.models.enums import CreationType

        # Bare-record body for the resolve() step (not envelope-wrapped).
        basic_resolve_xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<BaseObjectData>"
            f"<ID>{GREAT_TRAIN_ROBBERY}</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ResourceName>Test Movie</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            '<AssociatedOrg idType="eidrPartyID" '
            'organizationID="10.5237/FFDA-9947" role="registrant"/>'
            "<ReleaseDate>2026</ReleaseDate>"
            "<CountryOfOrigin>US</CountryOfOrigin>"
            "<Status>valid</Status>"
            "<ReferentType>Movie</ReferentType>"
            "</BaseObjectData>"
            "</FullMetadata>"
        )

        # First request: resolve. Second: modification base.
        request_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            request_count[0] += 1
            url = str(request.url)
            if request_count[0] == 1:
                # resolve() — return a Basic-typed record (no SeriesInfo etc.)
                assert "/object/" in url
                assert "modificationbase" not in url
                return httpx.Response(200, text=basic_resolve_xml)
            # modification_base() — confirm it's the Basic variant.
            assert "/object/modificationbase/" in url
            assert "type=CreateBasic" in url
            return httpx.Response(200, text=_modification_base_envelope_response())

        with make_client(handler) as client:
            base = client.modification_base_auto(GREAT_TRAIN_ROBBERY)

        assert request_count[0] == 2
        assert str(base.id) == GREAT_TRAIN_ROBBERY
        # Round-trips through modify with the inferred type.
        from eidr.client._operations import build_modify

        inner = build_modify(base.to_xml(), GREAT_TRAIN_ROBBERY, CreationType.Basic)
        assert '<Modify type="CreateBasic">' in inner

    def test_modification_base_auto_infers_series(self) -> None:
        """For a Series record, the helper resolves and infers Series."""

        # Series record has SeriesInfo in ExtraObjectMetadata.
        series_resolve_xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema" '
            'xmlns:md="http://www.movielabs.com/schema/md/v2.8/md">'
            "<BaseObjectData>"
            f"<ID>{GREAT_TRAIN_ROBBERY}</ID>"
            "<StructuralType>AbstractionParent</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ResourceName>Test Series</ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            '<AssociatedOrg idType="eidrPartyID" '
            'organizationID="10.5237/FFDA-9947" role="registrant"/>'
            "<ReleaseDate>2026</ReleaseDate>"
            "<CountryOfOrigin>US</CountryOfOrigin>"
            "<Status>valid</Status>"
            "<ReferentType>Series</ReferentType>"
            "</BaseObjectData>"
            "<ExtraObjectMetadata>"
            "<SeriesInfo><EndDate>2030</EndDate></SeriesInfo>"
            "</ExtraObjectMetadata>"
            "</FullMetadata>"
        )
        request_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            request_count[0] += 1
            url = str(request.url)
            if request_count[0] == 1:
                return httpx.Response(200, text=series_resolve_xml)
            # Should request type=CreateSeries since the resolved record is a Series.
            assert "type=CreateSeries" in url
            return httpx.Response(200, text=series_resolve_xml)

        with make_client(handler) as client:
            client.modification_base_auto(GREAT_TRAIN_ROBBERY)

        assert request_count[0] == 2

    def test_modification_base_auto_rejects_alias(self) -> None:
        """Alias records should not be passed to modify; helper rejects them
        with a clear error rather than silently producing a wrong-shape body.
        """
        from eidr.errors import EIDRClientError

        alias_xml = (
            '<FullMetadata xmlns="http://www.eidr.org/schema">'
            "<BaseObjectData>"
            f"<ID>{GREAT_TRAIN_ROBBERY}</ID>"
            "<StructuralType>Performance</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ResourceName>Aliased</ResourceName>"
            "<ReferentType>Movie</ReferentType>"
            '<AssociatedOrg idType="eidrPartyID" '
            'organizationID="10.5237/FFDA-9947" role="registrant"/>'
            "<ReleaseDate>2026</ReleaseDate>"
            "<CountryOfOrigin>US</CountryOfOrigin>"
            "<Status>valid</Status>"
            "</BaseObjectData>"
            "<AliasContinuation>"
            f"<LastAliased>{GREAT_TRAIN_ROBBERY}</LastAliased>"
            "<TargetOfLastAliased>10.5240/AAAA-BBBB-CCCC-DDDD-EEEE-F</TargetOfLastAliased>"
            "</AliasContinuation>"
            "</FullMetadata>"
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=alias_xml)

        with (
            make_client(handler) as client,
            pytest.raises(EIDRClientError, match="Alias"),
        ):
            client.modification_base_auto(GREAT_TRAIN_ROBBERY)


# ─── M10-A: status-lookup variants ─────────────────────────────────────────


def _statusrequest_part_of(request: httpx.Request) -> str:
    """Helper: extract the form-field-wrapped XML payload from a multipart POST."""
    text = request.content.decode("utf-8")
    # The body is multipart/form-data with a single part named
    # 'statusrequest'. Extract the inner XML.
    if "name=statusrequest" not in text:
        raise AssertionError(f"expected name=statusrequest in body, got: {text[:200]!r}")
    # Find the blank line after the part headers, then the XML up to the next boundary.
    parts = text.split("\r\n\r\n", 1)
    if len(parts) != 2:
        # Some MockTransport bodies use \n\n instead of \r\n\r\n.
        parts = text.split("\n\n", 1)
    if len(parts) != 2:
        raise AssertionError(f"could not split multipart body: {text[:200]!r}")
    body_after_headers = parts[1]
    # Trim trailing boundary
    boundary_marker = "\n--"
    boundary_idx = body_after_headers.rfind(boundary_marker)
    if boundary_idx != -1:
        body_after_headers = body_after_headers[:boundary_idx]
    return body_after_headers.strip()


def _empty_statusrequest_response() -> str:
    """A registry response carrying zero status entries (Code 0 / no rows)."""
    return (
        '<Response xmlns="http://www.eidr.org/schema">'
        "<Status><Code>0</Code><Type>success</Type></Status>"
        "</Response>"
    )


class TestStatusLookupByUser:
    """M10-A: ``status_lookup_by_user``."""

    def test_posts_to_status_endpoint_with_userid_in_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user("10.5238/richardkroon")

        assert captured["method"] == "POST"
        assert "/status/" in str(captured["url"])
        body = str(captured["body"])
        assert "<UserID>10.5238/richardkroon</UserID>" in body
        assert "<PageNumber>1</PageNumber>" in body
        assert "<PageSize>20</PageSize>" in body
        # No Status / After / From / To filters by default.
        assert "<Status>" not in body  # only the StatusRequest tag, no filter
        assert "<After>" not in body
        assert "<From>" not in body
        assert "<To>" not in body

    def test_uses_userid_element_not_user(self) -> None:
        """Special case in Java's posttag logic: ``user`` → ``UserID``."""
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user("10.5238/richardkroon")

        body = str(captured["body"])
        assert "<UserID>" in body
        # Not the unqualified <User> form
        assert "<User>" not in body

    def test_status_filter_appears_in_body(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user("10.5238/richardkroon", status="completed")

        body = str(captured["body"])
        assert "<Status>completed</Status>" in body

    def test_after_alone_emits_after_element(self) -> None:
        from datetime import datetime

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user(
                "10.5238/richardkroon",
                after=datetime(2026, 4, 1, tzinfo=UTC),
            )

        body = str(captured["body"])
        assert "<After>2026-04-01T00:00:00+00:00</After>" in body
        assert "<From>" not in body
        assert "<To>" not in body

    def test_after_and_before_emit_from_to_pair(self) -> None:
        from datetime import datetime

        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user(
                "10.5238/richardkroon",
                after=datetime(2026, 4, 1, tzinfo=UTC),
                before=datetime(2026, 4, 27, tzinfo=UTC),
            )

        body = str(captured["body"])
        assert "<From>2026-04-01T00:00:00+00:00</From>" in body
        assert "<To>2026-04-27T00:00:00+00:00</To>" in body
        # Mutually exclusive with the <After> form.
        assert "<After>" not in body

    def test_pagination_params_passed_through(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_user("10.5238/richardkroon", page_number=3, page_size=50)

        body = str(captured["body"])
        assert "<PageNumber>3</PageNumber>" in body
        assert "<PageSize>50</PageSize>" in body

    def test_rejects_empty_user_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="non-empty"):
            client.status_lookup_by_user("")

    def test_rejects_invalid_page_number(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="page_number"):
            client.status_lookup_by_user("10.5238/u", page_number=0)

    def test_rejects_invalid_page_size(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover
            raise AssertionError("transport should not be called")

        with make_client(handler) as client, pytest.raises(ValueError, match="page_size"):
            client.status_lookup_by_user("10.5238/u", page_size=0)


class TestStatusLookupByRegistrant:
    """M10-A: ``status_lookup_by_registrant``."""

    def test_posts_with_registrant_element(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_by_registrant("10.5237/FFDA-9947")

        assert "/status/" in str(captured["url"])
        body = str(captured["body"])
        assert "<Registrant>10.5237/FFDA-9947</Registrant>" in body
        # No UserID element
        assert "<UserID>" not in body


class TestStatusLookupSuperparty:
    """M10-A: ``status_lookup_superparty`` (no tag element in body)."""

    def test_posts_without_tag_element(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup_superparty()

        assert "/status/" in str(captured["url"])
        body = str(captured["body"])
        # No tag elements — the registry uses auth credentials' Superparty
        # status to authorize the wider lookup.
        assert "<UserID>" not in body
        assert "<Registrant>" not in body
        assert "<Token>" not in body
        # But page elements are still required.
        assert "<PageNumber>1</PageNumber>" in body
        assert "<PageSize>20</PageSize>" in body


class TestStatusLookupReadOnlyRegistry:
    """M10-A regression test (Reviewer 1): status lookups must not be gated by
    the writability check.

    Status lookups are read operations that happen to use POST (matching
    Java's ``workaround=true`` path). Earlier versions of the SDK passed
    these through the default ``requires_writable=True`` codepath, which
    would have raised ``EIDRReadOnlyRegistryError`` against the public
    RESOLVE registry — incorrect for a read operation.
    """

    def test_by_user_works_against_read_only_registry(self) -> None:
        from eidr.registries import Registry

        ro_registry = Registry(
            name="RO",
            url="https://ro.example/EIDR",
            writable=False,
            description="Read-only test registry",
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_statusrequest_response())

        config = TransportConfig(
            max_retries=0,
            retry_backoff_base=0.001,
            retry_backoff_max=0.01,
            httpx_transport=httpx.MockTransport(handler),
        )
        # Should not raise EIDRReadOnlyRegistryError.
        with Client(ro_registry, CREDS, transport_config=config) as client:
            client.status_lookup_by_user("10.5238/u")

    def test_by_registrant_works_against_read_only_registry(self) -> None:
        from eidr.registries import Registry

        ro_registry = Registry(
            name="RO",
            url="https://ro.example/EIDR",
            writable=False,
            description="Read-only test registry",
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_statusrequest_response())

        config = TransportConfig(
            max_retries=0,
            retry_backoff_base=0.001,
            retry_backoff_max=0.01,
            httpx_transport=httpx.MockTransport(handler),
        )
        with Client(ro_registry, CREDS, transport_config=config) as client:
            client.status_lookup_by_registrant("10.5237/AAAA-BBBB")

    def test_superparty_works_against_read_only_registry(self) -> None:
        from eidr.registries import Registry

        ro_registry = Registry(
            name="RO",
            url="https://ro.example/EIDR",
            writable=False,
            description="Read-only test registry",
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_statusrequest_response())

        config = TransportConfig(
            max_retries=0,
            retry_backoff_base=0.001,
            retry_backoff_max=0.01,
            httpx_transport=httpx.MockTransport(handler),
        )
        with Client(ro_registry, CREDS, transport_config=config) as client:
            client.status_lookup_superparty()

    def test_paginated_status_lookup_token_works_against_read_only_registry(
        self,
    ) -> None:
        """The paginated ``status_lookup(token, page_number=...)`` POST
        path must not be gated by the writability check either."""
        from eidr.registries import Registry

        ro_registry = Registry(
            name="RO",
            url="https://ro.example/EIDR",
            writable=False,
            description="Read-only test registry",
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, text=_empty_statusrequest_response())

        config = TransportConfig(
            max_retries=0,
            retry_backoff_base=0.001,
            retry_backoff_max=0.01,
            httpx_transport=httpx.MockTransport(handler),
        )
        with Client(ro_registry, CREDS, transport_config=config) as client:
            client.status_lookup("some-token-12345", page_number=1, page_size=5)


class TestStatusLookupPagination:
    """M10 v2 (Reviewer 1): ``status_lookup(token)`` Java-parity gap.

    The Java SDK's ``statusLookupViaToken`` accepts ``pageNumber`` and
    ``pageSize`` parameters. Python's ``status_lookup(token)``
    previously did not. The fix is additive: pagination kwargs are
    optional; without them, the GET path is used (preserving the
    ``Token.poll/wait`` flow). With them, the POST path is used.
    """

    def test_no_pagination_uses_get_path(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup("token-123")

        assert captured["method"] == "GET"
        assert "/status/token-123" in str(captured["url"])

    def test_pagination_switches_to_post_path(self) -> None:
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup("token-123", page_number=2, page_size=50)

        assert captured["method"] == "POST"
        assert str(captured["url"]).rstrip("/").endswith("/status")
        body = str(captured["body"])
        assert "<Token>token-123</Token>" in body
        assert "<PageNumber>2</PageNumber>" in body
        assert "<PageSize>50</PageSize>" in body

    def test_only_page_number_set_uses_post_path(self) -> None:
        """Either kwarg alone activates the POST path."""
        captured: dict[str, object] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["body"] = _statusrequest_part_of(request)
            return httpx.Response(200, text=_empty_statusrequest_response())

        with make_client(handler) as client:
            client.status_lookup("token-123", page_number=3)

        assert captured["method"] == "POST"
        body = str(captured["body"])
        assert "<PageNumber>3</PageNumber>" in body
        # page_size defaults to 20
        assert "<PageSize>20</PageSize>" in body
