"""Tests for ``eidr.credentials``."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from eidr.credentials import (
    ENV_AWS_SECRET,
    ENV_CONFIG_FILE,
    ENV_PARTY,
    ENV_PASSWORD,
    ENV_SOURCE,
    ENV_USER,
    Credentials,
)
from eidr.errors import (
    EIDRClientError,
    EIDRCredentialAmbiguityError,
    EIDRCredentialsNotFoundError,
)


@pytest.fixture
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Clear all EIDR-relevant environment variables for each test."""
    for name in (
        ENV_USER,
        ENV_PARTY,
        ENV_PASSWORD,
        ENV_CONFIG_FILE,
        ENV_AWS_SECRET,
        ENV_SOURCE,
        "EIDR_BASE_URL",
        "EIDR_AWS_REGION",
    ):
        monkeypatch.delenv(name, raising=False)


@pytest.fixture
def _clean_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    """Redirect ``~`` to a fresh temp dir so default file paths miss."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # Also handle Windows USERPROFILE just in case the test runs there
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    # And reset the working directory so ./.secrets.json and ./eidr.xml miss
    monkeypatch.chdir(tmp_path)
    return tmp_path


# Convenience: combine the two so tests don't have to request both
@pytest.fixture
def _isolated_env(_clean_env: None, _clean_home: Path) -> Path:
    return _clean_home


# ─────────────────────────────────────────────────────────────────────────────
# Direct construction
# ─────────────────────────────────────────────────────────────────────────────


class TestDirectConstruction:
    def test_basic_fields(self) -> None:
        c = Credentials(user_id="10.5238/u", party_id="10.5237/AAAA-BBBB", password="secret")
        assert c.user_id == "10.5238/u"
        assert c.party_id == "10.5237/AAAA-BBBB"
        assert c.password == "secret"
        assert c.base_url is None
        assert c.source == "direct"

    def test_password_not_in_repr(self) -> None:
        c = Credentials(user_id="u", party_id="p", password="very-secret-pw")
        assert "very-secret-pw" not in repr(c)
        assert "very-secret-pw" not in str(c)
        assert "<redacted>" in repr(c)

    def test_is_frozen(self) -> None:
        c = Credentials(user_id="u", party_id="p", password="pw")
        with pytest.raises(AttributeError):
            c.password = "new"  # type: ignore[misc]


# ─────────────────────────────────────────────────────────────────────────────
# XML config file
# ─────────────────────────────────────────────────────────────────────────────


class TestFromEidrXml:
    def test_standard_layout(self, tmp_path: Path) -> None:
        xml_path = tmp_path / "eidr.xml"
        xml_path.write_text(
            """<?xml version="1.0"?>
<config>
    <user>10.5238/testuser</user>
    <party>10.5237/AAAA-BBBB</party>
    <password>s3cret</password>
    <url>https://sandbox2.eidr.org/EIDR</url>
</config>
""",
            encoding="utf-8",
        )
        c = Credentials.from_eidr_xml(xml_path)
        assert c.user_id == "10.5238/testuser"
        assert c.party_id == "10.5237/AAAA-BBBB"
        assert c.password == "s3cret"
        assert c.base_url == "https://sandbox2.eidr.org/EIDR"
        assert c.source == "xml"

    def test_alternate_tag_names(self, tmp_path: Path) -> None:
        xml_path = tmp_path / "eidr.xml"
        xml_path.write_text(
            """<?xml version="1.0"?>
<eidr>
    <UserID>10.5238/u</UserID>
    <PartyID>10.5237/AAAA-BBBB</PartyID>
    <Password>pw</Password>
    <RegistryURL>https://example.com</RegistryURL>
</eidr>
""",
            encoding="utf-8",
        )
        c = Credentials.from_eidr_xml(xml_path)
        assert c.user_id == "10.5238/u"
        assert c.base_url == "https://example.com"

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(EIDRClientError, match="not found"):
            Credentials.from_eidr_xml(tmp_path / "does-not-exist.xml")

    def test_malformed_xml_raises(self, tmp_path: Path) -> None:
        xml_path = tmp_path / "bad.xml"
        xml_path.write_text("this is not xml<<<", encoding="utf-8")
        with pytest.raises(EIDRClientError, match="not valid XML"):
            Credentials.from_eidr_xml(xml_path)

    def test_missing_required_field_raises(self, tmp_path: Path) -> None:
        xml_path = tmp_path / "incomplete.xml"
        xml_path.write_text(
            "<c><user>u</user><party>p</party></c>",  # no password
            encoding="utf-8",
        )
        with pytest.raises(EIDRClientError, match="password"):
            Credentials.from_eidr_xml(xml_path)

    def test_expands_tilde(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        xml_path = tmp_path / "my.xml"
        xml_path.write_text(
            "<c><user>u</user><party>p</party><password>pw</password></c>",
            encoding="utf-8",
        )
        c = Credentials.from_eidr_xml("~/my.xml")
        assert c.user_id == "u"


# ─────────────────────────────────────────────────────────────────────────────
# JSON file
# ─────────────────────────────────────────────────────────────────────────────


class TestFromJson:
    def test_uppercase_keys(self, tmp_path: Path) -> None:
        p = tmp_path / "secrets.json"
        p.write_text(
            json.dumps(
                {
                    "USER_ID": "10.5238/u",
                    "PARTY_ID": "10.5237/AAAA-BBBB",
                    "PASSWORD": "pw",
                    "BASE_URL": "https://example.com",
                }
            ),
            encoding="utf-8",
        )
        c = Credentials.from_json(p)
        assert c.user_id == "10.5238/u"
        assert c.source == "json"

    def test_lowercase_keys(self, tmp_path: Path) -> None:
        p = tmp_path / "secrets.json"
        p.write_text(
            json.dumps(
                {
                    "user": "u",
                    "party": "p",
                    "password": "pw",
                }
            ),
            encoding="utf-8",
        )
        c = Credentials.from_json(p)
        assert c.user_id == "u"

    def test_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(EIDRClientError, match="not found"):
            Credentials.from_json(tmp_path / "nope.json")

    def test_not_json_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "bad.json"
        p.write_text("not json", encoding="utf-8")
        with pytest.raises(EIDRClientError, match="not valid JSON"):
            Credentials.from_json(p)

    def test_must_be_object_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "array.json"
        p.write_text("[1, 2, 3]", encoding="utf-8")
        with pytest.raises(EIDRClientError, match="must contain a JSON object"):
            Credentials.from_json(p)

    def test_missing_required_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "incomplete.json"
        p.write_text(json.dumps({"user": "u", "party": "p"}), encoding="utf-8")
        with pytest.raises(EIDRClientError, match="password"):
            Credentials.from_json(p)


# ─────────────────────────────────────────────────────────────────────────────
# Environment variables
# ─────────────────────────────────────────────────────────────────────────────


class TestFromEnv:
    def test_reads_all_env_vars(self, _clean_env: None, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(ENV_USER, "10.5238/u")
        monkeypatch.setenv(ENV_PARTY, "10.5237/AAAA-BBBB")
        monkeypatch.setenv(ENV_PASSWORD, "pw")
        monkeypatch.setenv("EIDR_BASE_URL", "https://example.com")

        c = Credentials.from_env()
        assert c.user_id == "10.5238/u"
        assert c.party_id == "10.5237/AAAA-BBBB"
        assert c.password == "pw"
        assert c.base_url == "https://example.com"
        assert c.source == "env"

    def test_base_url_is_optional(self, _clean_env: None, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv(ENV_USER, "u")
        monkeypatch.setenv(ENV_PARTY, "p")
        monkeypatch.setenv(ENV_PASSWORD, "pw")
        c = Credentials.from_env()
        assert c.base_url is None

    def test_missing_raises(self, _clean_env: None) -> None:
        with pytest.raises(EIDRClientError, match="not set"):
            Credentials.from_env()


# ─────────────────────────────────────────────────────────────────────────────
# load() — default chain
# ─────────────────────────────────────────────────────────────────────────────


class TestLoadChain:
    def test_no_sources_raises_not_found(self, _isolated_env: Path) -> None:
        with pytest.raises(EIDRCredentialsNotFoundError):
            Credentials.load()

    def test_single_source_env_is_selected(
        self, _isolated_env: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv(ENV_USER, "u")
        monkeypatch.setenv(ENV_PARTY, "p")
        monkeypatch.setenv(ENV_PASSWORD, "pw")
        c = Credentials.load()
        assert c.source == "env"

    def test_single_source_json_is_selected(self, _isolated_env: Path) -> None:
        p = _isolated_env / ".secrets.json"
        p.write_text(json.dumps({"user": "u", "party": "p", "password": "pw"}), encoding="utf-8")
        c = Credentials.load()
        assert c.source == "json"

    def test_ambiguous_sources_raises(
        self, _isolated_env: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Set both env and a JSON file
        monkeypatch.setenv(ENV_USER, "u")
        monkeypatch.setenv(ENV_PARTY, "p")
        monkeypatch.setenv(ENV_PASSWORD, "pw")
        (_isolated_env / ".secrets.json").write_text(
            json.dumps({"user": "u2", "party": "p2", "password": "pw2"}),
            encoding="utf-8",
        )
        with pytest.raises(EIDRCredentialAmbiguityError) as excinfo:
            Credentials.load()
        assert "env" in excinfo.value.sources
        assert "json" in excinfo.value.sources

    def test_explicit_source_wins(
        self, _isolated_env: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv(ENV_USER, "u")
        monkeypatch.setenv(ENV_PARTY, "p")
        monkeypatch.setenv(ENV_PASSWORD, "pw")
        (_isolated_env / ".secrets.json").write_text(
            json.dumps({"user": "u2", "party": "p2", "password": "pw2"}),
            encoding="utf-8",
        )
        monkeypatch.setenv(ENV_SOURCE, "env")
        c = Credentials.load()
        assert c.source == "env"
        assert c.user_id == "u"

    def test_invalid_explicit_source_raises(
        self, _isolated_env: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv(ENV_SOURCE, "telepathy")
        with pytest.raises(EIDRClientError, match="not a recognized credential source"):
            Credentials.load()

    def test_explicit_source_but_empty_raises_not_found(
        self, _isolated_env: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv(ENV_SOURCE, "env")
        # env variables NOT set
        with pytest.raises(EIDRCredentialsNotFoundError):
            Credentials.load()
