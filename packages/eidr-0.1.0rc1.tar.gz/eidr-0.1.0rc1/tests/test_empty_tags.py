"""Tests for the empty-tag validation rule and the ``strip_empty_tags`` helper.

The EIDR registry rejects any element with no text, no attributes, and
no children as a schema-validation error. An element that carries only
an attribute (e.g. ``<AlternateID domain="..."/>``) is structurally
valid for submission — the registry may reject it on semantic grounds,
but that's a different layer.

Missing tags are distinct from empty tags: a missing tag causes the
registry to run its inheritance and default-generation rules, which is
fine. Only present-but-empty tags are the schema problem.
"""

from __future__ import annotations

from eidr.codecs._rules import ATTR_PREFIX
from eidr.models import (
    ContentRecord,
    PartyRecord,
    ServiceRecord,
    find_empty_tags,
    strip_empty_tags,
)

CONTENT_ID = "10.5240/7791-8534-2C23-9030-8610-5"
REGISTRANT_ID = "10.5237/7791-8534"
PARTY_ID = "10.5237/7791-8534"
SERVICE_ID = "10.5239/7791-8534"

NS = (
    ' xmlns="http://www.eidr.org/schema"'
    ' xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"'
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
)


def _valid_base() -> str:
    return (
        f"<ID>{CONTENT_ID}</ID>"
        "<StructuralType>Abstraction</StructuralType>"
        "<Mode>AudioVisual</Mode>"
        "<ReferentType>Movie</ReferentType>"
        "<ResourceName>X</ResourceName>"
        "<OriginalLanguage>en</OriginalLanguage>"
        "<Status>valid</Status>"
        f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
    )


def _content_xml(inner_extra: str = "") -> bytes:
    body = f"<FullMetadata{NS}><BaseObjectData>{_valid_base()}</BaseObjectData>"
    if inner_extra:
        body += f"<ExtraObjectMetadata>{inner_extra}</ExtraObjectMetadata>"
    body += "</FullMetadata>"
    return body.encode()


# ─────────────────────────────────────────────────────────────────────────────
# find_empty_tags: detection
# ─────────────────────────────────────────────────────────────────────────────


class TestFindEmptyTags:
    def test_clean_record_reports_nothing(self) -> None:
        rec = ContentRecord.from_xml(_content_xml())
        assert find_empty_tags(rec.data) == []

    def test_empty_series_info_detected(self) -> None:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo></SeriesInfo>"))
        paths = find_empty_tags(rec.data)
        assert any("SeriesInfo" in p for p in paths), f"Expected SeriesInfo in one of {paths}"

    def test_self_closing_tag_detected(self) -> None:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        paths = find_empty_tags(rec.data)
        assert any("SeriesInfo" in p for p in paths)

    def test_whitespace_only_text_detected(self) -> None:
        # ResourceName with only whitespace is empty
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            f"<ID>{CONTENT_ID}</ID>"
            "<StructuralType>Abstraction</StructuralType>"
            "<Mode>AudioVisual</Mode>"
            "<ReferentType>Movie</ReferentType>"
            "<ResourceName>   </ResourceName>"
            "<OriginalLanguage>en</OriginalLanguage>"
            "<Status>valid</Status>"
            f"<Administrators><Registrant>{REGISTRANT_ID}</Registrant></Administrators>"
            "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        paths = find_empty_tags(rec.data)
        assert any("ResourceName" in p for p in paths), paths

    def test_attribute_only_element_is_not_empty(self) -> None:
        # <AlternateID domain="..."/> is structurally valid (has an attribute).
        # The registry will reject it later as missing a value, but that's
        # a different layer — our job is only structural checks.
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + _valid_base()
            + '<AlternateID domain="http://imdb.com"/>'
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        paths = find_empty_tags(rec.data)
        assert not any("AlternateID" in p for p in paths), paths

    def test_nested_empty_child_reported_not_parent(self) -> None:
        # If only a nested child is empty, report the nested path.
        # The parent isn't itself empty because it has a non-None child key.
        rec = ContentRecord.from_xml(
            _content_xml(
                "<EpisodeInfo>"
                "<EpisodeClass>Standard</EpisodeClass>"
                "<SequenceInfo></SequenceInfo>"
                "</EpisodeInfo>"
            )
        )
        paths = find_empty_tags(rec.data)
        assert any("SequenceInfo" in p for p in paths), paths

    def test_multiple_empties_all_reported(self) -> None:
        rec = ContentRecord.from_xml(
            _content_xml("<SeriesInfo></SeriesInfo><PackagingInfo></PackagingInfo>")
        )
        paths = find_empty_tags(rec.data)
        assert len(paths) >= 2
        assert any("SeriesInfo" in p for p in paths)
        assert any("PackagingInfo" in p for p in paths)


# ─────────────────────────────────────────────────────────────────────────────
# strip_empty_tags: recursive removal
# ─────────────────────────────────────────────────────────────────────────────


class TestStripEmptyTags:
    def test_idempotent_on_clean_record(self) -> None:
        rec = ContentRecord.from_xml(_content_xml())
        original = rec.data.copy()
        strip_empty_tags(rec.data)
        assert rec.data == original

    def test_returns_same_dict(self) -> None:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        result = strip_empty_tags(rec.data)
        assert result is rec.data

    def test_empty_leaf_removed(self) -> None:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        strip_empty_tags(rec.data)
        assert find_empty_tags(rec.data) == []
        # The whole ExtraObjectMetadata wrapper should be gone too, since
        # its only child was the empty SeriesInfo
        assert "ExtraObjectMetadata" not in rec.data["FullMetadata"]  # type: ignore[index,call-overload]

    def test_recursive_strip_removes_empty_parent(self) -> None:
        # When a block's only children are themselves empty, the block
        # should also be stripped (recursive up-propagation).
        rec = ContentRecord.from_xml(
            _content_xml(
                "<EpisodeInfo>"
                "<EpisodeClass></EpisodeClass>"  # empty
                "</EpisodeInfo>"
            )
        )
        strip_empty_tags(rec.data)
        assert find_empty_tags(rec.data) == []
        assert "ExtraObjectMetadata" not in rec.data["FullMetadata"]  # type: ignore[index,call-overload]

    def test_preserves_attribute_only_elements(self) -> None:
        # <AlternateID domain="..."/> has an attribute; must not be stripped.
        # (The value-object wrapper can't construct an AlternateID without a
        # value, but that's a separate concern — the codec dict preserves
        # the element so the registry, not the SDK, decides what to do.)
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + _valid_base()
            + '<AlternateID domain="http://imdb.com"/>'
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        strip_empty_tags(rec.data)
        # The raw AlternateID element is preserved in the codec dict
        bod = rec.data["FullMetadata"]["BaseObjectData"]
        assert "AlternateID" in bod, (
            f"Attribute-only element was stripped; BaseObjectData keys: {list(bod.keys())}"
        )
        alt_entry = bod["AlternateID"]
        # Unwrap from list if it's one
        if isinstance(alt_entry, list):
            assert len(alt_entry) == 1
            alt_entry = alt_entry[0]
        assert isinstance(alt_entry, dict)
        assert alt_entry.get(f"{ATTR_PREFIX}domain") == "http://imdb.com"

    def test_preserves_non_empty_siblings(self) -> None:
        rec = ContentRecord.from_xml(
            _content_xml(
                "<SeriesInfo></SeriesInfo>"  # empty
                "<PackagingInfo><PackagingClass>X</PackagingClass></PackagingInfo>"
            )
        )
        strip_empty_tags(rec.data)
        # Empty SeriesInfo gone; PackagingInfo preserved
        extra = rec.data["FullMetadata"]["ExtraObjectMetadata"]  # type: ignore[index,call-overload]
        assert "SeriesInfo" not in extra
        assert "PackagingInfo" in extra

    def test_strip_empty_from_list(self) -> None:
        # A multi-valued field with a mix of non-empty and empty entries
        # should end up with only the non-empty entries.
        xml = (
            f"<FullMetadata{NS}><BaseObjectData>"
            + _valid_base()
            + "<AlternateID>real-value</AlternateID>"
            + "<AlternateID></AlternateID>"
            + "<AlternateID>another-real-value</AlternateID>"
            + "</BaseObjectData></FullMetadata>"
        ).encode()
        rec = ContentRecord.from_xml(xml)
        strip_empty_tags(rec.data)
        alt_ids = rec.alternate_ids
        assert [a.value for a in alt_ids] == ["real-value", "another-real-value"]

    def test_strip_then_validate_round_trip(self) -> None:
        # Full workflow: build programmatically with some accidental empties,
        # strip, validate. Should be clean.
        rec = ContentRecord.from_xml(
            _content_xml(
                "<SeriesInfo><SeriesClass>Program</SeriesClass></SeriesInfo>"
                "<PackagingInfo></PackagingInfo>"  # empty, will strip
            )
        )
        strip_empty_tags(rec.data)
        report = rec.validate()
        # No empty-tag errors should remain
        assert not any(e.code == "content.empty_tag.forbidden" for e in report), (
            f"Found empty-tag errors after strip: {list(report)}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Validator pipeline: empty tags reported as dedicated error code
# ─────────────────────────────────────────────────────────────────────────────


class TestEmptyTagValidationRule:
    def test_content_empty_tag_reported(self) -> None:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        report = rec.validate()
        assert any(e.code == "content.empty_tag.forbidden" for e in report)

    def test_party_empty_tag_reported(self) -> None:
        xml = (
            f"<Party{NS}>"
            f"<ID>{PARTY_ID}</ID>"
            "<PartyName><md:DisplayName>X</md:DisplayName></PartyName>"
            "<ContactInfo>"
            "<Name>ops</Name>"
            "<PrimaryEmail>ops@x.z</PrimaryEmail>"
            "</ContactInfo>"
            "<Active>true</Active>"
            "<PartyAccountName></PartyAccountName>"  # <-- empty
            "</Party>"
        ).encode()
        rec = PartyRecord.from_xml(xml)
        report = rec.validate()
        assert any(e.code == "party.empty_tag.forbidden" for e in report)
        # The specific path should identify the offender
        assert any(
            "PartyAccountName" in (e.path or "")
            for e in report
            if e.code == "party.empty_tag.forbidden"
        )

    def test_service_empty_tag_reported(self) -> None:
        xml = (
            f"<Service{NS}>"
            f"<ID>{SERVICE_ID}</ID>"
            "<ServiceName><md:DisplayName>X</md:DisplayName></ServiceName>"
            "<Active>true</Active>"
            "<Description></Description>"  # <-- empty
            "</Service>"
        ).encode()
        rec = ServiceRecord.from_xml(xml)
        report = rec.validate()
        assert any(e.code == "service.empty_tag.forbidden" for e in report)

    def test_error_message_mentions_strip_helper(self) -> None:
        """Make the error message actionable — direct callers at the fix."""
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        report = rec.validate()
        empty_errors = [e for e in report if e.code == "content.empty_tag.forbidden"]
        assert empty_errors
        assert "strip_empty_tags" in empty_errors[0].message


# ─────────────────────────────────────────────────────────────────────────────
# Interaction of empty-tag and CreationType-consistency rules
# ─────────────────────────────────────────────────────────────────────────────


class TestRuleInteractionOrder:
    """Per the design, order of empty-tag stripping vs CreationType
    consistency checking does not matter — both paths end in a
    legitimate rejection of the same bad record.

    These tests document both outcomes and confirm the resolution is
    deterministic (same record → same errors, every time)."""

    def test_empty_info_block_flagged_with_both_lenses(self) -> None:
        # Submitting <SeriesInfo/> without stripping first:
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        report = rec.validate()
        # Empty-tag rule fires
        assert any(e.code == "content.empty_tag.forbidden" for e in report)

    def test_after_strip_creation_type_consistency_would_fire(self) -> None:
        # If the caller strips the SeriesInfo block first, the record's
        # shape becomes a Basic (no CreationType block). That's perfectly
        # valid — the user just intended no CreationType override, which
        # means the record will resolve as CreationType=Basic on the
        # registry. This is a legitimate outcome.
        rec = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        strip_empty_tags(rec.data)
        report = rec.validate()
        # After stripping, no empty-tag errors remain
        assert not any(e.code == "content.empty_tag.forbidden" for e in report)
        # And no CreationType-consistency errors either (no block == Basic)
        assert not any(e.code.startswith("content.creation_type.") for e in report)
        assert rec.creation_type.value == "Basic"

    def test_validation_is_deterministic(self) -> None:
        # Same record, validated twice, should produce the same report.
        rec1 = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        rec2 = ContentRecord.from_xml(_content_xml("<SeriesInfo/>"))
        codes1 = sorted(e.code for e in rec1.validate())
        codes2 = sorted(e.code for e in rec2.validate())
        assert codes1 == codes2
