"""Tests for :mod:`eidr.codecs` — XML ↔ CodecDict ↔ JSON."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import pytest
from lxml import etree

from eidr.codecs import (
    ATTR_PREFIX,
    EIDR_MULTI_ELEMENTS,
    TEXT_KEY,
    CardinalityHeuristicWarning,
    observed_cardinality,
)
from eidr.codecs import json as json_codec
from eidr.codecs import xml as xml_codec
from eidr.errors import EIDRCodecError

FIXTURES = Path(__file__).parent / "fixtures"
EIDR_NS = "http://www.eidr.org/schema"


# ─────────────────────────────────────────────────────────────────────────────
# Constants and shape
# ─────────────────────────────────────────────────────────────────────────────


class TestModuleConstants:
    def test_attr_prefix_is_underscore(self) -> None:
        # Pinned by the MovieLabs spec; never change without a major version bump.
        assert ATTR_PREFIX == "_"

    def test_text_key_is_value(self) -> None:
        assert TEXT_KEY == "value"

    def test_bundled_multi_elements_is_frozen(self) -> None:
        assert isinstance(EIDR_MULTI_ELEMENTS, frozenset)
        # Sanity-check: a few well-known multi-valued EIDR elements
        for expected in ("AlternateID", "Actor", "Director"):
            assert expected in EIDR_MULTI_ELEMENTS


# ─────────────────────────────────────────────────────────────────────────────
# XML → CodecDict
# ─────────────────────────────────────────────────────────────────────────────


class TestToCodecDict:
    def test_simple_element(self) -> None:
        xml = b"<Root>hello</Root>"
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": "hello"}

    def test_empty_element(self) -> None:
        xml = b"<Root/>"
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": None}

    def test_element_with_attribute_only(self) -> None:
        xml = b'<Root lang="en">hello</Root>'
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": {"_lang": "en", "value": "hello"}}

    def test_element_with_children(self) -> None:
        xml = b"<Root><Name>Alice</Name><Age>30</Age></Root>"
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": {"Name": "Alice", "Age": "30"}}

    def test_repeating_children_become_list(self) -> None:
        xml = b"<Root><Item>a</Item><Item>b</Item></Root>"
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": {"Item": ["a", "b"]}}

    def test_single_child_with_multi_hint_becomes_list(self) -> None:
        # Per MovieLabs spec: maxOccurs > 1 means array even for single occurrence
        xml = b"<Root><Item>only one</Item></Root>"
        cd = xml_codec.to_codec_dict(xml, multi_elements={"Item"}, use_bundled_hints=False)
        assert cd == {"Root": {"Item": ["only one"]}}

    def test_single_child_without_hint_is_scalar(self) -> None:
        xml = b"<Root><Item>one</Item></Root>"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", CardinalityHeuristicWarning)
            cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": {"Item": "one"}}

    def test_warns_when_no_hints(self) -> None:
        xml = b"<Root><Item>one</Item></Root>"
        with pytest.warns(CardinalityHeuristicWarning):
            xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)

    def test_no_warning_with_bundled_hints(self) -> None:
        xml = b"<Root><Item>one</Item></Root>"
        with warnings.catch_warnings():
            warnings.simplefilter("error")  # any warning becomes an error
            # Bundled hints are non-empty, so no warning should fire
            xml_codec.to_codec_dict(xml, use_bundled_hints=True)

    def test_accepts_string_input(self) -> None:
        cd = xml_codec.to_codec_dict(
            "<Root>x</Root>", multi_elements=set(), use_bundled_hints=False
        )
        assert cd == {"Root": "x"}

    def test_accepts_element_input(self) -> None:
        element = etree.fromstring(b"<Root>x</Root>")
        cd = xml_codec.to_codec_dict(element, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": "x"}

    def test_malformed_xml_raises(self) -> None:
        with pytest.raises(EIDRCodecError, match="Failed to parse XML"):
            xml_codec.to_codec_dict(b"<not well-formed")

    def test_namespace_declarations_preserved(self) -> None:
        xml = b'<Root xmlns="http://example.com/ns"><Item>x</Item></Root>'
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        assert cd == {"Root": {"_xmlns": "http://example.com/ns", "Item": "x"}}

    def test_prefixed_attributes_preserved(self) -> None:
        # xsi:type is a common EIDR idiom
        xml = b'<Root xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="Foo">x</Root>'
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        root = cd["Root"]
        assert isinstance(root, dict)
        assert root["_xmlns:xsi"] == "http://www.w3.org/2001/XMLSchema-instance"
        assert root["_xsi:type"] == "Foo"
        assert root["value"] == "x"


# ─────────────────────────────────────────────────────────────────────────────
# CodecDict → XML
# ─────────────────────────────────────────────────────────────────────────────


class TestFromCodecDict:
    def test_simple_roundtrip(self) -> None:
        xml = b"<Root>hello</Root>"
        cd = xml_codec.to_codec_dict(xml, multi_elements=set(), use_bundled_hints=False)
        out = xml_codec.to_xml(cd, xml_declaration=False)
        assert out == b"<Root>hello</Root>"

    def test_empty_element_roundtrip(self) -> None:
        cd = {"Root": None}
        out = xml_codec.to_xml(cd, xml_declaration=False)
        # Empty element may serialize as either <Root/> or <Root></Root>
        assert out in (b"<Root/>", b"<Root></Root>")

    def test_attribute_roundtrip(self) -> None:
        cd = {"Root": {"_lang": "en", "value": "hello"}}
        out = xml_codec.to_xml(cd, xml_declaration=False)
        # Attribute order isn't guaranteed, but both should be present
        assert b'lang="en"' in out
        assert b">hello</Root>" in out

    def test_child_elements_roundtrip(self) -> None:
        cd = {"Root": {"Name": "Alice", "Age": "30"}}
        out = xml_codec.to_xml(cd, xml_declaration=False)
        assert b"<Name>Alice</Name>" in out
        assert b"<Age>30</Age>" in out

    def test_namespace_declaration_preserved_in_output(self) -> None:
        cd = {"Root": {"_xmlns": "http://example.com/ns", "value": "x"}}
        out = xml_codec.to_xml(cd, xml_declaration=False)
        assert b'xmlns="http://example.com/ns"' in out

    def test_list_children_emit_as_separate_elements(self) -> None:
        cd = {"Root": {"Item": ["a", "b", "c"]}}
        out = xml_codec.to_xml(cd, xml_declaration=False)
        assert out.count(b"<Item>") == 3

    def test_rejects_multi_root_dict(self) -> None:
        with pytest.raises(EIDRCodecError, match="exactly one top-level key"):
            xml_codec.from_codec_dict({"A": "1", "B": "2"})

    def test_rejects_attribute_root(self) -> None:
        with pytest.raises(EIDRCodecError, match="looks like an attribute"):
            xml_codec.from_codec_dict({"_attr": "value"})


# ─────────────────────────────────────────────────────────────────────────────
# Canonical XML (signing-ready)
# ─────────────────────────────────────────────────────────────────────────────


class TestCanonicalXML:
    def test_byte_stable(self) -> None:
        cd = {"Root": {"B": "2", "A": "1"}}
        c1 = xml_codec.to_xml_canonical(cd)
        c2 = xml_codec.to_xml_canonical(cd)
        assert c1 == c2

    def test_canonical_differs_from_infoset(self) -> None:
        cd = {"Root": {"_lang": "en", "value": "hello"}}
        canonical = xml_codec.to_xml_canonical(cd)
        infoset = xml_codec.to_xml(cd, xml_declaration=False)
        # Both should contain the core content, but canonical won't have
        # an XML declaration and may differ in other ways.
        assert b"hello" in canonical and b"hello" in infoset

    def test_rejects_unknown_method(self) -> None:
        cd = {"Root": "x"}
        with pytest.raises(EIDRCodecError, match="Unknown canonicalization method"):
            xml_codec.to_xml_canonical(cd, method="not-a-method")


# ─────────────────────────────────────────────────────────────────────────────
# JSON codec
# ─────────────────────────────────────────────────────────────────────────────


class TestJsonCodec:
    def test_to_json_produces_parseable_output(self) -> None:
        cd = {"Root": {"_lang": "en", "value": "hello"}}
        text = json_codec.to_json(cd)
        parsed = json.loads(text)
        assert parsed == cd

    def test_to_json_dict_retain_is_identity(self) -> None:
        cd = {"Root": {"A": "1"}}
        result = json_codec.to_json_dict(cd, wrapper="retain")
        assert result == cd

    def test_to_json_dict_drop_strips_wrapper(self) -> None:
        cd = {"Root": {"A": "1"}}
        result = json_codec.to_json_dict(cd, wrapper="drop")
        assert result == {"A": "1"}

    def test_drop_requires_single_root(self) -> None:
        cd = {"A": "1", "B": "2"}
        with pytest.raises(EIDRCodecError, match="exactly one top-level"):
            json_codec.to_json_dict(cd, wrapper="drop")

    def test_drop_requires_dict_content(self) -> None:
        cd = {"Root": "just-a-string"}
        with pytest.raises(EIDRCodecError, match="requires the top-level value"):
            json_codec.to_json_dict(cd, wrapper="drop")

    def test_rejects_invalid_wrapper(self) -> None:
        cd = {"Root": {"A": "1"}}
        with pytest.raises(EIDRCodecError, match="must be 'retain' or 'drop'"):
            json_codec.to_json_dict(cd, wrapper="keep")  # type: ignore[arg-type]

    def test_from_json_accepts_string(self) -> None:
        cd = json_codec.from_json('{"Root": "x"}')
        assert cd == {"Root": "x"}

    def test_from_json_accepts_bytes(self) -> None:
        cd = json_codec.from_json(b'{"Root": "x"}')
        assert cd == {"Root": "x"}

    def test_from_json_accepts_dict(self) -> None:
        cd = json_codec.from_json({"Root": "x"})
        assert cd == {"Root": "x"}

    def test_from_json_wraps_back_with_wrapper_key(self) -> None:
        cd = json_codec.from_json('{"A": "1"}', wrapper_key="Root")
        assert cd == {"Root": {"A": "1"}}

    def test_from_json_rejects_non_object(self) -> None:
        with pytest.raises(EIDRCodecError, match="must be an object"):
            json_codec.from_json("[1, 2, 3]")

    def test_from_json_rejects_malformed(self) -> None:
        with pytest.raises(EIDRCodecError, match="JSON parse error"):
            json_codec.from_json("{not json}")


class TestCanonicalJson:
    def test_byte_stable(self) -> None:
        cd = {"Root": {"B": "2", "A": "1", "C": {"nested": "v"}}}
        s1 = json_codec.to_canonical_string(cd)
        s2 = json_codec.to_canonical_string(cd)
        assert s1 == s2

    def test_keys_are_sorted(self) -> None:
        cd = {"Root": {"Z": "last", "A": "first", "M": "middle"}}
        s = json_codec.to_canonical_string(cd)
        # "A" appears before "M" appears before "Z"
        assert s.index('"A"') < s.index('"M"') < s.index('"Z"')

    def test_no_extra_whitespace(self) -> None:
        cd = {"Root": {"A": "1"}}
        s = json_codec.to_canonical_string(cd)
        assert " " not in s
        assert "\n" not in s

    def test_preserves_non_ascii(self) -> None:
        cd = {"Root": {"Title": "Amélie"}}
        s = json_codec.to_canonical_string(cd)
        # JCS does NOT escape non-ASCII
        assert "Amélie" in s


# ─────────────────────────────────────────────────────────────────────────────
# observed_cardinality helper
# ─────────────────────────────────────────────────────────────────────────────


class TestObservedCardinality:
    def test_finds_multi_at_top_level(self) -> None:
        cd = {"Root": {"Item": ["a", "b"]}}
        multi = observed_cardinality(cd)
        assert "Item" in multi

    def test_finds_multi_at_nested_level(self) -> None:
        cd = {"Root": {"Wrapper": {"Inner": ["x", "y"]}}}
        multi = observed_cardinality(cd)
        assert "Inner" in multi

    def test_single_item_not_counted(self) -> None:
        cd = {"Root": {"Item": "alone"}}
        multi = observed_cardinality(cd)
        assert "Item" not in multi

    def test_attributes_ignored(self) -> None:
        cd = {"Root": {"_attr1": "a", "_attr2": "b"}}
        multi = observed_cardinality(cd)
        assert multi == set()

    def test_none_input(self) -> None:
        assert observed_cardinality(None) == set()

    def test_strips_namespace_prefix(self) -> None:
        cd = {"Root": {"md:Item": ["a", "b"]}}
        multi = observed_cardinality(cd)
        assert "Item" in multi


# ─────────────────────────────────────────────────────────────────────────────
# JSON → XML via codec
# ─────────────────────────────────────────────────────────────────────────────


class TestJsonToXml:
    def test_converts_json_to_xml(self) -> None:
        xml = json_codec.to_xml('{"Root": "x"}', xml_declaration=False)
        assert xml == b"<Root>x</Root>"

    def test_converts_with_wrapper_key(self) -> None:
        xml = json_codec.to_xml('{"A": "1"}', wrapper_key="Root", xml_declaration=False)
        assert b"<Root>" in xml and b"<A>1</A>" in xml


# ─────────────────────────────────────────────────────────────────────────────
# Round-trip against real EIDR records (the acceptance test)
# ─────────────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    ("filename", "element_name"),
    [
        ("random_full.xml", "FullMetadata"),
        ("random_self.xml", "SelfDefinedMetadata"),
        ("random_prov.xml", "ProvenanceMetadata"),
    ],
)
class TestRealCorpusRoundTrip:
    """The codec must round-trip every real record losslessly at the infoset level.

    For each of ~209 records per file, we:

    1. Extract the XML for one record.
    2. Convert to a CodecDict.
    3. Serialize to JSON text.
    4. Parse the JSON back to a CodecDict.
    5. Serialize to XML bytes.
    6. Re-parse both the original and round-tripped XML and verify they
       have the same element count (a proxy for structural equivalence —
       a fuller check would compare every element's tag path, text, and
       attributes, which we do in a second test below).
    """

    def test_all_records_roundtrip_by_element_count(self, filename: str, element_name: str) -> None:
        tree = etree.parse(str(FIXTURES / filename))
        nodes = tree.findall(f".//{{{EIDR_NS}}}{element_name}")
        assert len(nodes) > 0, f"No {element_name} elements found in {filename}"

        failures: list[tuple[int, str]] = []
        for idx, node in enumerate(nodes):
            xml_bytes = etree.tostring(node)
            try:
                cd = xml_codec.to_codec_dict(xml_bytes)
                jtext = json_codec.to_json(cd)
                cd2 = json_codec.from_json(jtext)
                xml_bytes2 = xml_codec.to_xml(cd2, xml_declaration=False)

                re1 = etree.fromstring(xml_bytes)
                re2 = etree.fromstring(xml_bytes2)
                count1 = sum(1 for _ in re1.iter())
                count2 = sum(1 for _ in re2.iter())
                if count1 != count2:
                    failures.append((idx, f"element count {count1} vs {count2}"))
            except Exception as e:
                failures.append((idx, f"{type(e).__name__}: {e}"))

        assert not failures, (
            f"{len(failures)} of {len(nodes)} records failed round-trip in "
            f"{filename}. First 3: {failures[:3]}"
        )


class TestCorpusDeepEquivalence:
    """Stricter test: verify every element tag path and text matches after round-trip.

    Only runs on the first 20 records of random_full.xml to keep runtime
    bounded; a stricter sweep is available under the ``slow`` marker.
    """

    def test_deep_equivalence_first_20(self) -> None:
        tree = etree.parse(str(FIXTURES / "random_full.xml"))
        nodes = tree.findall(f".//{{{EIDR_NS}}}FullMetadata")[:20]

        for idx, node in enumerate(nodes):
            xml_bytes = etree.tostring(node)

            cd = xml_codec.to_codec_dict(xml_bytes)
            jtext = json_codec.to_json(cd)
            cd2 = json_codec.from_json(jtext)
            xml_bytes2 = xml_codec.to_xml(cd2, xml_declaration=False)

            re1 = etree.fromstring(xml_bytes)
            re2 = etree.fromstring(xml_bytes2)

            # Collect (tag, text_stripped) for every element in document order
            def fingerprint(el: etree._Element) -> list[tuple[str, str]]:
                result = []
                for e in el.iter():
                    if not isinstance(e.tag, str):
                        continue
                    text = (e.text or "").strip() if e.text else ""
                    result.append((e.tag, text))
                return result

            fp1 = fingerprint(re1)
            fp2 = fingerprint(re2)
            assert fp1 == fp2, (
                f"Record {idx}: tag/text fingerprint mismatch.\n"
                f"Diff (first 3): {[x for x in fp1 if x not in fp2][:3]} vs "
                f"{[x for x in fp2 if x not in fp1][:3]}"
            )


class TestCanonicalJsonOnCorpus:
    """Canonical JSON must be byte-stable across independent invocations."""

    def test_canonical_json_byte_stable_on_corpus(self) -> None:
        tree = etree.parse(str(FIXTURES / "random_full.xml"))
        nodes = tree.findall(f".//{{{EIDR_NS}}}FullMetadata")[:30]

        for node in nodes:
            cd = xml_codec.to_codec_dict(etree.tostring(node))
            c1 = json_codec.to_canonical_string(cd)
            c2 = json_codec.to_canonical_string(cd)
            assert c1 == c2


class TestCanonicalXmlOnCorpus:
    """Canonical XML must be byte-stable across independent invocations."""

    def test_canonical_xml_byte_stable_on_corpus(self) -> None:
        tree = etree.parse(str(FIXTURES / "random_full.xml"))
        nodes = tree.findall(f".//{{{EIDR_NS}}}FullMetadata")[:30]

        for node in nodes:
            cd = xml_codec.to_codec_dict(etree.tostring(node))
            c1 = xml_codec.to_xml_canonical(cd)
            c2 = xml_codec.to_xml_canonical(cd)
            assert c1 == c2
