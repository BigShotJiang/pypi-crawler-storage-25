# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Pre-1.0 releases may introduce breaking changes in any version bump.
From 1.0.0 onward, the public API stability policy takes effect.

## [Unreleased]

(no unreleased changes)


## [0.1.0rc1] — 2026-04-27

**First release candidate.** This release closes both rounds of reviewer feedback on `0.1.0b3` (Reviewer 1 had RC blockers covering documentation drift, contract inconsistencies, and ergonomic gaps; Reviewer 2 was already willing to ship and asked for caching + breaking-change visibility). All changes here are reviewer-driven; no new wire surfaces.

**Pipeline state at release:** 1,164 unit tests passing · 25 integration tests deselected by default · ruff clean · ruff format clean · mypy `--strict` clean across 49 source files.

### API stability contract

The public API contract documented in `STABILITY.md` **takes effect at this release**. Earlier beta versions made the breaking changes documented under `[0.1.0b2]` and `[0.1.0b3]`; this release adds two more (active_filter default, service_children typed return). From `0.1.0rc1` onward, breaking changes to anything in the contract require a major-version bump (2.0.0).

### Changed (breaking — last beta-window changes)

- **`active_filter` default changed from `"all"` to `"active"`** across all four query helpers (`find_parties_by_name`, `find_parties_from_catalog`, `find_services_by_name`, `find_services_from_catalog`) and their async mirrors. Now matches Java SDK behavior exactly. Pass `active_filter="all"` explicitly to opt into the previous behavior.

- **`Client.service_children` and `AsyncClient.service_children` now return `ServiceChildrenResults`** rather than `ParsedResponse`. The new wrapper exposes parsed `child_ids: list[str]`, full child Service XML strings via `children: list[str]`, lazy parsed `child_records: list[ServiceRecord]`, plus the underlying `ParsedResponse` as `raw_response`. `__len__`/`__bool__` defined naturally. Callers who relied on `result.status_code == 0` should now check `result.raw_response.status_code == 0`.

### Added

- **Parsed-record accessors on query result wrappers.** `PartyQueryResults.party_records`, `ServiceQueryResults.service_records`, and `ServiceChildrenResults.child_records` parse XML strings to typed records via `functools.cached_property` — first access parses, subsequent accesses return the cached list. Works correctly with frozen dataclasses on Python 3.11+.

- **Top-level exports for public types.** `OperationStatusEntry`, `PartyQueryResults`, `ServiceQueryResults`, `ServiceChildrenResults`, and `TransportConfig` are now in `eidr.__all__` and `eidr.client.__all__`. Previously `TransportConfig` was reachable only via the underscore module `eidr.client._http`, which contradicted the stability contract.

### Fixed

- **`ServiceChildrenResults` extraction tightened** (R1 implementation #3). Previously walked the entire response tree collecting every `<ID>` starting with `10.5239/`, which could over-collect parent IDs, alias targets, or IDs nested inside full `<Service>` bodies. New extraction:
  - prefers known structured containers (`<ServiceChildren>`, `<Children>`, `<ServiceList>`) when present, scanning only their interior;
  - excludes `<ID>` elements that have a `<Service>` ancestor (those belong to full child records, not to the ID-only list);
  - excludes the parent's own `service_id` from the children;
  - deduplicates the IDs.
  Without a live wire trace pinning the exact registry container shape, both paths remain active. `raw_response` is the escape hatch.

- **`Client.service_parent` no longer hides "service ID does not exist" as "service is at root"** (R1 implementation #5). Inspects `EIDRNotFoundError.details`: Details mentioning "parent" → root case (returns `None`); Details mentioning the queried ID → missing case (re-raises). Documented in the docstring's `Raises:` section and flagged in `STABILITY.md`'s "Heuristic-based behavior" section as wording-dependent.

- **`Client.service_query(full=True)` documentation no longer overpromises fallback** (R1 implementation #1). Docstring previously claimed automatic fallback that the code never implemented; now reflects actual behavior (registry rejection propagates as a typed exception).

- **`build_find_parties_by_name` docstring corrected** to describe `includeAlternateNames="..."` as an XSD attribute, not a `<IncludeAlternateNames>` child element. The code emits the correct attribute form (fixed in `0.1.0b3`); only the docstring was stale.

- **`modification_base()` workflow example fixed** to include `creation_type=CreationType.Basic` (or to use `modification_base_auto()` when the type isn't known statically). The required-kwarg signature change shipped in `0.1.0b2` but the docstring example wasn't updated.

- **`_record_to_creation_inner` stale comment removed** (R1 implementation #6). The comment claimed pre-built `<Basic>` / `<Series>` etc. wrappers were accepted as input; the code rejects them.

- **Top-level package docstring no longer points at private modules** (R1). Removed the `~eidr.client._http.TransportConfig` reference in favor of the now-exported `~eidr.TransportConfig`.

### Documentation

- **`README.md` rewritten** for `0.1.0rc1`/M14 (R1 RC blocker #1). Status banner replaced "Pre-1.0 development snapshot" with RC language pointing to `STABILITY.md`. Implementation status section lists all current methods including `iter_query`, `iter_query_ids`, `modification_base_auto`, `change_party_password`. Roadmap narrowed to schema URI resolver expansion (1.1).

- **`src/eidr/__init__.py` body updated to `0.1.0rc1` (M14)** — the previous round had updated the version string but missed the implementation-status block which still said `0.1.0b3 (M13)`.

- **`STABILITY.md` corrected and expanded.** Method names: `register_party` → `create_party`, `register_service` → `create_service`, `change_password` → `change_party_password`. Codec module paths: `eidr.codec.xml_codec`/`json_codec` → `eidr.codecs.xml`/`eidr.codecs.json` with the actual public API names. Added a **Breaking changes by version** section per R2's request, attributing each beta-period breaking change to the correct release. Added a **Heuristic-based behavior** section flagging `service_parent`'s Details-text disambiguation and `ServiceChildrenResults`' defensive extraction.

- **`REVIEW_SCOPE.md` fully rewritten** (R1 RC blocker). The previous file was historical scope notes from M5/M6 (pre-HTTP-client, 489 tests) with a new quick-summary prepended; reviewers reading past the summary saw stale content that contradicted the M14 cover letter. The 97-line replacement is a clean entry point pointing reviewers at `README.md`, `STABILITY.md`, `CHANGELOG.md`, and `M14_COVER_LETTER.md`.

- **PyPI classifier updated** from `Development Status :: 3 - Alpha` to `Development Status :: 4 - Beta`. Beta is the correct classifier for an RC.

- **Parity claim language clarified** to "core public Java SDK parity" with out-of-scope surfaces (batch, user/ACL admin, UserOverride, payload templates, Java test harness) listed explicitly in `README.md`, `STABILITY.md`, and `REVIEW_SCOPE.md`.

### Reviewer 2 acknowledgments

- **`iter_query()` for asset queries** — already shipped in `0.1.0b2`. R2 missed it twice because earlier README/`__init__.py` listed it as roadmap. Documentation now surfaces it prominently.

- **Typed VirtualFields views** — pushed back. The wire format for `<Full>` / `<SelfDefined>` is search-index strings (concatenated keywords for the registry's text-search subsystem), not structured XML. The Typed View pattern that works for Digital metadata doesn't apply.

- **Digital model performance** — already documented in README and STABILITY. The XML round-trip is the documented trade-off; users wanting raw throughput should use `CodecDict` directly.

- **Series modification base verification** — still unverified live. The integration test is gated on `EIDR_TEST_SERIES_ID`. Recommended to set this and run the suite before tagging 1.0 GA.

### Tests added

Ten new tests on top of the 1,154 from `0.1.0b3`:

- `test_party_records_property_parses_to_typed` (sync)
- `test_party_records_empty_for_id_only_response` (sync)
- `test_service_records_property_parses_to_typed` (sync)
- `test_extracts_child_ids_from_id_only_response` (sync)
- `test_extracts_full_child_records_when_provided` (sync, updated to assert correct exclusion)
- `test_empty_for_parent_with_no_children` (sync)
- `test_extraction_excludes_parent_id_if_echoed`
- `test_extraction_deduplicates_child_ids`
- `test_extraction_prefers_structured_container_when_present`
- `test_cached_property_caches_child_records`




## [0.1.0b3] — 2026-04-27

**Wire-shape correctness release.** The 0.1.0b2 live integration run (against sandbox2 with `FileSink` instrumentation) captured wire traces revealing three real bugs in the M11 surfaces — bugs that wouldn't have shown up against the synthesized fixtures used in the unit tests. All three are fixed in 0.1.0b3.

**Pipeline state at release:** 1,154 unit tests passing · 25 integration tests deselected by default · ruff clean · ruff format clean · mypy `--strict` clean across 49 source files.

### Fixed

- **`modification_base` envelope shape** — the registry wraps `<BaseObjectData>` in a creation-type element (`<Basic>`, `<Series>`, `<Episode>`, etc.) inside the `<Response>` envelope; 0.1.0b1/b2 didn't unwrap that. The full live shape is::

      <Response xmlns="..." version="2.7.1">
        <Status><Code>0</Code>...</Status>
        <Basic>                              <!-- this wrapper was missed -->
          <BaseObjectData>...</BaseObjectData>
        </Basic>
      </Response>

  Additionally, the registry **omits `<ID>`** from `<BaseObjectData>` in modification_base responses — the asset ID is in the request URL, not the response body. 0.1.0b3 unwraps the creation-type element via `_extract_first_non_status_child` (which now recognizes all eight `CreationType` wrapper names) and injects `asset_id` into `record.base["ID"]` so the returned record round-trips through `modify()` without the caller having to re-stamp the ID. New regression test `test_modification_base_handles_live_registry_byte_shape` pins the actual byte shape from the M12 wire trace.

- **`includeAlternateNames` is an XSD attribute, not a child element** — per `api.xsd`'s definition of `<FindPartiesByName>`:

      <xs:element name="FindPartiesByName">
        <xs:complexType>
          <xs:complexContent>
            <xs:extension base="eidr:partyQueryType">
              <xs:attribute name="includeAlternateNames" type="xs:boolean" default="false"/>
            </xs:extension>
          </xs:complexContent>
        </xs:complexType>
      </xs:element>

  0.1.0b1/b2 emitted `<IncludeAlternateNames>true</IncludeAlternateNames>` (PascalCase, child element) which the registry rejected with a Code 9 syntax error: `cvc-complex-type.2.4.a: Invalid content was found starting with element 'IncludeAlternateNames'. One of '{...":ContinuationToken}' is expected.` 0.1.0b3 emits it as `includeAlternateNames="true"` attribute on the root element.

- **Services don't have an `includeAlternateNames` parameter at all** — per `service.xsd`'s `serviceQueryType`, the schema doesn't include alternate-name search for services. 0.1.0b1/b2 incorrectly added `IncludeAlternateNames` to the FindServicesByName body; 0.1.0b3 removes it entirely. The `include_alt_names` keyword is removed from `Client.find_services_by_name` and its async mirror — **breaking change in beta**, but the kwarg never worked correctly so no real-world users could be relying on it.

- **`<PartyQueryResults>` and `<ServiceQueryResults>` are top-level document roots, not wrapped in `<Response>`** — per `api.xsd` and `service.xsd`, these elements are declared at the schema's top level. 0.1.0b1/b2 expected them nested inside a `<Response>` envelope and `parse_response` raised `EIDRProtocolError("Unexpected root element")` for the actual live shape. 0.1.0b3 adds them to `_RESOLVE_ROOTS` so they parse as `kind="record"`, and updates `PartyQueryResults.from_response` / `ServiceQueryResults.from_response` to handle the root-as-results-element case.

- **`<AdminResponse>` envelope handling** — `/party/query` and `/service/query` use `<AdminResponse>` (not `<Response>`) for error responses, with status fields directly under the root rather than nested in `<Status>`. 0.1.0b3 adds AdminResponse handling to `parse_response` so error responses on these endpoints map to the appropriate typed exception (e.g., Code 9 `syntax error` → `EIDRValidationError`).

### How these were caught

The 0.1.0b2 live integration run included `FileSink` instrumentation on `TestM10ModificationBase`, `TestM11FindParties::test_find_parties_by_name_movielabs`, and `TestM11ModificationBaseNonBasic::test_modification_base_for_series` (added in 0.1.0b2 as diagnostic capture). The captured traces (`m12_modbase_basic_*.log` and `m12_find_parties_*.log`) showed the actual registry envelope shapes, which differed from the SDK's assumptions in the three ways listed above. Without that wire trace, the bugs would have been visible only as `ContentRecord(id=None, resource_name=None)` and `EIDRProtocolError: Unexpected root element` — diagnostic data far short of what we needed to fix them.

The lesson is that fixture-based unit tests are only as good as the fixtures match real wire data; the M11 surfaces shipped against shapes synthesized from `api.xsd`/`service.xsd` schema reading, but the schema only describes valid shapes — it doesn't tell you which shape variant the registry actually returns for a given endpoint. **Live integration coverage with wire traces is the only way to catch this class of bug**; that's now standard for any new surface added to the SDK before it ships in a `0.1.0` GA candidate.

### Tests added

- `test_modification_base_handles_live_registry_byte_shape` — pins the actual byte shape from `m12_modbase_basic_20260427_151253.log` (creation-type wrapper, `<ID>`-omitted body, multiple xmlns declarations, version="2.7.1" attribute).
- `test_admin_response_error_raises_validation_error` — pins the `<AdminResponse>` Code 9 syntax-error response shape from `m12_find_parties_20260427_151134.log`.
- `test_root_level_party_query_results` — pins the root-level `<PartyQueryResults>` shape (success path for `/party/query`).
- `test_root_level_service_query_results` — same for services.




## [0.1.0b2] — 2026-04-27

**Beta-hardening release** in response to reviewer feedback on `0.1.0b1`. Addresses release-credibility documentation drift (Reviewer 1 #1, #2, #11), replaces raw `ParsedResponse` returns from typed convenience helpers with proper typed wrappers (Reviewer 1 #3, #8), closes API-design gaps (Reviewer 1 #4, #6, #9), and adds the asset-query auto-paging that Reviewer 2 flagged (#1).

**Pipeline state at release:** 1,151 unit tests passing · 25 integration tests deselected by default (15 prior + 10 new for M11 surfaces) · ruff clean · ruff format clean · mypy `--strict` clean across 49 source files.

### Live-test trace from 0.1.0b1 acknowledged

The maintainer's `0.1.0b1` integration run (2026-04-27) showed:
- **Smoke tests: 6/6 passing** (read-only + writes round-trip clean against sandbox2).
- **Integration tests: 10 passing, 4 skipped, 1 FAILING** — `TestM10ModificationBase::test_get_modification_base_for_basic_record` returned `ContentRecord(id=None, resource_name=None)` from the live registry response.

The integration test for `modification_base` was the only failure and didn't capture a wire trace, so the registry's actual response shape in this run is unknown. **`0.1.0b2` adds a `FileSink` to that integration test** so the next live run captures `m12_modbase_basic_<timestamp>.log` for diagnostic capture. Same pattern applied to `find_parties_by_name` and the non-Basic `modification_base_for_series` integration tests — both also capture wire traces now.

`0.1.0b2` also adds `test_modification_base_handles_live_registry_byte_shape` — a regression test pinning the **exact byte shape** the live registry returns (per the smoke wire traces: UTF-8 declaration, pretty-printed XML with newlines, `version="2.7.1"` attribute, doubled `xmlns` declarations). This test passes in `0.1.0b2`, confirming the SDK's M10 v2 envelope handling correctly processes the documented live shape.

If the next live run still surfaces a `ContentRecord(id=None, resource_name=None)` outcome on the modification_base test, the `m12_modbase_basic_*.log` will tell us what's actually different about the registry's response — most likely a shape that differs from the smoke logs (e.g., a registry-side change, or a code path-specific envelope variation). With the trace in hand, the fix is one more iteration.

### Breaking changes

Beta is the right time for these; none are planned for 1.0 → 2.0.

- **`Client.modification_base()` / `AsyncClient.modification_base()`** now require `creation_type` — the `CreationType.Basic` default was a footgun (passing the wrong creation type returns a wrong-shape record body that can parse silently and produce a malformed `modify()` payload). Callers who don't know the type should use the new `modification_base_auto()` (resolves first to infer it).

- **`find_parties_by_name()`, `find_parties_from_catalog()`, `find_services_by_name()`, `find_services_from_catalog()`** now return typed `PartyQueryResults` / `ServiceQueryResults` objects instead of raw `ParsedResponse`. The wrapper exposes `total_matches`, `current_size`, `continuation_token`, `party_ids` / `parties` (or `services`), plus `raw_response` as an escape hatch. Callers who were doing XPath against the returned `ParsedResponse` should switch to the typed fields; callers who genuinely need the underlying envelope can access it via `.raw_response`.

### Added

- **Typed result wrappers** (Reviewer 1 #3, #8). New `eidr.client._results` module with `PartyQueryResults` and `ServiceQueryResults` dataclasses. Wire shape verified against `api.xsd` and `service.xsd` (the canonical fields are `<CurrentSize>`, `<TotalMatches>`, `<ContinuationToken>`, `<PartyID>` * | `<Party>` * for parties; `<Service>` * for services — services don't have an ID-only choice in their schema, which explains why Java's literals map has the service-full path commented out). Both wrappers expose `__len__` and `__bool__`. Exported from `eidr.client`.

- **`Client.modification_base_auto(asset_id)` and async mirror** (Reviewer 1 #6). Resolves the asset first, reads `record.creation_type` (derived from which `<ExtraObjectMetadata>` block is present), then calls `modification_base()` with the inferred type. Refuses Alias records via `record.alias_continuation` check with a clear error message — alias records are not modifiable through the modify operation.

- **`Client.iter_status_by_token(token, *, page_size=20, max_results=None)` and async mirror** (Reviewer 1 #4). Java parity for paginated batch-token status lookups. Yields `OperationStatusEntry` per `<OperationStatus>` element across pages. Uses the POST path internally (M10 v2 added pagination kwargs to `status_lookup(token)`).

- **`Client.iter_query(expression, *, page_size=25, max_results=None)`** and **`Client.iter_query_ids(...)`** plus async mirrors (Reviewer 2 #1). Asset-query auto-paging for paging consistency with `iter_status_*`. The `iter_query` variant yields full `ContentRecord` instances; `iter_query_ids` yields EIDR ID strings (much lighter wire payload). Stops when `QueryResults.has_more_pages` is False or `max_results` is reached.

- **`OperationStatusEntry.resulting_id`** field (Reviewer 1 #9). Extracted from `<ID>` child of `<OperationStatus>`. Populated for completed register/modify operations; `None` for pending operations or operations that don't produce an ID (e.g. delete). Reduces the need to drop down to `entry.element` for the most common access pattern.

- **`STABILITY.md`** — 1.0 API stability contract. Documents the public API surface, internal modules (leading underscore convention), escape hatches, and what 1.0 promises vs doesn't promise (e.g., infoset-equivalent XML round-trip but not byte-identical serialization).

- **`tests/test_examples_smoke.py`** (Reviewer 1 #12). 13 smoke tests verifying each example file parses as valid Python, imports cleanly given the full extras, and that `register_and_modify.py` exits cleanly without `EXAMPLE_ENABLE_WRITES=1`. Also enforces a structural rule that examples have a `main()` entry point and are documented in `examples/README.md`.

- **Live integration coverage stubs** (Reviewer 1 #5, #7, #10). Ten new `@pytest.mark.integration` tests in `tests/test_integration_sandbox.py` covering `find_parties_by_name`, `find_parties_from_catalog`, `find_services_by_name`, `find_services_from_catalog`, `iter_query`, `iter_query_ids`, `modification_base_auto`, non-Basic `modification_base` (gated on `EIDR_TEST_SERIES_ID`), and `iter_status_by_user`. Skip-by-default like the existing integration tests; they need a live sandbox run by the maintainer to verify against current registry behavior.

### Fixed

- **Documentation drift** (Reviewer 1 #1, #2, #11). Rewrote the implementation-status sections of `README.md` and `src/eidr/__init__.py` to accurately reflect M11 — typed query helpers and auto-paging iterators now appear under "Implementation status" rather than under "Not yet implemented." Updated `REVIEW_SCOPE.md`'s inline summary from M9 to M11. README's variance-table reference updated from "M10" to "M11." README's `### Development setup` now uses the full extras list `pip install -e '.[client,digital,aws,dev,docs]'` with explanations of what each extra brings in.

- **Typed Digital performance documented** (Reviewer 2 #2). Added a "Performance note" to the README's Typed Digital section explaining the ~5-15ms-per-call overhead from XML round-tripping and recommending the codec-dict accessors for high-frequency manifestation processing. Cross-referenced from `STABILITY.md`. This characteristic is now documented behavior at 1.0 and won't change without a major-version bump.

### Pushback / not in this release

- **Typed `VirtualFields` per the M8 typed-view pattern** (Reviewer 2 #3). Looking at the actual wire format, `VirtualFields.full` and `VirtualFields.self_defined` are space-separated search-index strings (e.g. `"Edwin S. Porter Edwin Stanton Porter The Great Train Robbery CITWF Genre: Western..."`), not structured XML. The M8 typed-view pattern fits structured payloads (Digital/Manifestation/Series blocks); there's nothing structural to extract from a search-index string. The current `VirtualFields.full -> str` accessor is the correct shape. Documented in this entry to avoid the question recurring.

- **Schema URI resolver expansion** (Reviewer 2 #4). Targeted for 1.1 as Reviewer 2 suggested. Roadmap-only for `0.1.0b2`.

- **Dedicated test party for destructive party-mutation tests** (deferred from M10 v2). Out of SDK-side scope; maintainer call.



(no unreleased changes)


## [0.1.0b1] — 2026-04-27

**First beta.** Feature surface is now stable for the planned 1.0; remaining work between here and 1.0 is polish, downstream-consumer integration, and any issues that surface in real production use.

**Pipeline state at release:** 1,111 unit tests passing · 15 integration tests deselected by default · ruff clean · ruff format clean · mypy `--strict` clean across 48 source files.

### M11 — what landed

Four work units, all additive on top of `0.1.0a3`. No breaking changes.

#### M11-A: Auto-paging iterators for status lookup

New `OperationStatusEntry` typed wrapper (in `eidr.client._response`) exposing the four most commonly accessed fields of a `<OperationStatus>` element: `.token`, `.status_code`, `.status_type`, `.details`, plus `.element` for advanced lxml access via XPath.

Three new sync methods on `Client` and three async mirrors on `AsyncClient`:

- `iter_status_by_user(user_id, *, page_size=20, max_results=None, status=None, after=None, before=None)`
- `iter_status_by_registrant(registrant, *, page_size=20, max_results=None, status=None, after=None, before=None)`
- `iter_status_superparty(*, page_size=20, max_results=None, status=None, after=None, before=None)`

Each yields one `OperationStatusEntry` per `<OperationStatus>` element across pages. Stops when the registry returns a page with fewer entries than `page_size` (the natural last-page signal) or when `max_results` is reached. Removes the page-tracking boilerplate that callers had to write manually with the underlying `status_lookup_by_*` methods.

15 new tests (10 sync + 5 async) in `test_client_m11.py` / `test_async_client_m11.py`.

#### M11-B: Typed query helpers for Party / Service queries

Closes Reviewer 1's "ergonomic parity gap" point and the corresponding Java SDK surface (`findPartiesByName`, `findPartiesFromCatalog`, `findServicesByName`, `findServicesFromCatalog`).

Four new sync methods + four async mirrors:

- `find_parties_by_name(name, *, include_alt_names=True, role_filter=None, active_filter="all", page_number=1, page_size=20, continuation_token=None, full=False)`
- `find_parties_from_catalog(name, *, role_filter=None, active_filter="all", page_number=1, page_size=20, continuation_token=None, full=False)`
- `find_services_by_name(name, *, include_alt_names=True, active_filter="all", page_number=1, page_size=20, continuation_token=None, full=False)`
- `find_services_from_catalog(name, *, active_filter="all", page_number=1, page_size=20, continuation_token=None, full=False)`

Each is a typed convenience wrapper over the existing `party_query()` / `service_query()` escape-hatch methods — the wire-XML body is built internally and dispatched. Mirrors Java's wire shape including the catalog-vs-name distinction, the `IncludeAlternateNames` element, the `RoleFilter` (party only), and the `ContinuationToken` for stateful paging.

`party_query()` and `service_query()` (sync + async) now also accept a `full=False` kwarg that adds `?type=full` to the URL when `True` — Java parity with the `bFull` parameter. Service-side caveat: Java's literals map has the service-full path commented out, suggesting it may not be supported by all registry versions; documented in the docstring.

New builder helpers in `eidr.client._operations`: `build_find_parties_by_name`, `build_find_parties_from_catalog`, `build_find_services_by_name`, `build_find_services_from_catalog`. Each handles XML escaping, namespace declaration, and validation (empty name, bad active_filter, bad page params).

10 new tests in `test_client_m11.py` + 4 in `test_async_client_m11.py`.

#### M11-C: Non-Basic modification base

Reviewer-flagged precision item from M10 v2: the modification-base envelope handling only verified `CreationType.Basic`. Non-Basic creation types (Series, Episode, Edit, Clip, Manifestation, Compilation) include both `<BaseObjectData>` and `<ExtraObjectMetadata>` in the record body — and the registry likely returns these as siblings of `<Status>` inside the `<Response>` envelope.

Extended `_extract_first_non_status_child()` (in `eidr.client._response`) to handle multi-child envelopes: when the envelope has more than one non-`<Status>` child, the helper synthesizes a `<FullMetadata>` wrapper around them (chosen because it's the resolve-output root that `ContentRecord._root_value` already unwraps, and the same shape `_record_to_creation_inner` accepts as a Create source). The single-child case is unchanged.

End-to-end probe verified: a Series-style envelope (`<Response>` wrapping `<BaseObjectData>` + `<ExtraObjectMetadata>`) round-trips through `modification_base()` → `modify()` to produce a well-formed `<Modify type="CreateSeries"><ID>...</ID><Series>...<BaseObjectData/><ExtraObjectMetadata/></Series></Modify>` payload.

Test `test_modification_base_non_basic_round_trip` added to `test_client_m10.py`.

#### M11-D: Examples directory

New `examples/` directory with five end-to-end workflow scripts:

- `resolve_basic.py` — anonymous resolve against the public RESOLVE registry.
- `find_parties.py` — typed `find_parties_by_name` and `find_parties_from_catalog` demonstrations including pagination, role filter, full vs ID-only.
- `status_lookup_iterator.py` — auto-paging `iter_status_by_user` with date filter and `max_results` cap.
- `register_and_modify.py` — full register → modification_base → mutate → modify → delete lifecycle. Gated by `EXAMPLE_ENABLE_WRITES=1` env var.
- `async_concurrent_resolve.py` — bulk-read pattern using `AsyncClient` + `asyncio.gather`.

Plus an `examples/README.md` documenting the recommended reading order, conventions used in the examples, and how to add new ones.

Examples don't ship as part of the importable `eidr` package — they're documentation-by-example for downstream consumers.

### Variance table updates

The Java-parity variance table in `M9_COVER_LETTER.md` flips two more rows to ✅ Equivalent: typed `findPartiesByName/FromCatalog` and typed `findServicesByName/FromCatalog`. Auto-paging is a Python-only ergonomic addition (Java has no equivalent).

### Test-suite trajectory

| Phase | Unit tests |
|---|---|
| 0.1.0a3 close (M10 v2) | 1,080 |
| M11-A auto-paging | 1,095 |
| M11-B typed query helpers | 1,110 |
| M11-C non-Basic modification base | 1,111 |
| **0.1.0b1** | **1,111** |



(no unreleased changes)


## [0.1.0a3] — 2026-04-27

M10 v2 — fix pass on top of `0.1.0a2`. Closes the live-integration-test failure on `modification_base` and resolves the highest-priority items from a three-reviewer pass on `0.1.0a2`. No breaking changes.

**Pipeline state at release:** 1,080 unit tests passing · 15 integration tests deselected by default (opt-in via `pytest -m integration`) · ruff clean · ruff format clean · mypy `--strict` clean across 48 source files.

### Fixed

- **`modification_base()` envelope handling.** The live registry returns the modification-base body as a `<Response>` envelope wrapping a `<BaseObjectData>` record alongside `<Status>`, not as a bare record body — surfaced by the M10 v1 integration test against sandbox2. Added `_extract_first_non_status_child()` helper in `eidr.client._response` that walks the envelope's children and returns the first non-`<Status>` child. `modification_base` now routes through `parse_response` (handling typed exceptions for non-zero status), branches on `kind`, and parses either the bare record (`kind=="record"`) or the envelope-wrapped record (`kind=="envelope"`). Both paths return a typed `ContentRecord`.

- **`modification_base()` → `modify()` round-trip.** The advertised workflow `base = client.modification_base(asset); client.modify(base)` was broken: `_record_to_creation_inner` rejected `<BaseObjectData>` roots (only accepted resolve-style wrappers like `<FullMetadata>`). Extended the helper to accept `<BaseObjectData>` as a valid root for the modification-base shape — wraps it in the creation-type element (`<Basic>` for `CreationType.Basic`, etc.) and strips `<ID>` from the inner `<BaseObjectData>` per the schema rule (`creationFullInfo` / `creationSelfDefinedInfo` exclude `<ID>` because the registry assigns IDs on Create). New regression test pins the round-trip end-to-end.

- **`status_lookup_by_*()` writability gating.** All six methods (sync + async × by_user/by_registrant/superparty) were calling `_transport.post` with the default `requires_writable=True`, which would have raised `EIDRReadOnlyRegistryError` against the public RESOLVE registry — incorrect for read operations. Added `requires_writable=False` to all six call sites, matching the existing pattern in `query`, `graph_traversal`, `party_query`, `service_query`. New regression test class `TestStatusLookupReadOnlyRegistry` confirms.

- **`ContentRecord` wrapper unwrapping for `ProvenanceMetadata` and `InheritedMetadata`.** `_root_value()` only unwrapped `FullMetadata`, `SelfDefinedMetadata`, and `SimpleMetadata` despite the top-level docs claiming uniform support across all five wrapper types. Accessors like `.id` and `.resource_name` would have silently returned wrong/empty results for provenance/inherited resolutions. Now all five wrapper types are unwrapped consistently. New parametrized test class `TestRecordWrapperUnwrapping` covers each.

- **Stale README and `eidr/__init__.py` docs.** "Not yet implemented" sections in both files still listed modification base, status lookup variants, and service-graph reads as deferred — directly contradicting M10. Moved these into a new "Implemented in M10 (0.1.0a2)" callout. Remaining "Not yet implemented" items now accurately reflect the deferred surface (typed query helpers, auto-paging iterators, `status_lookup(token)` pagination — see below — batch operations, user/ACL admin, impersonation).

- **`service_children` docstring.** Pointed callers at `parsed.payload_xml`, an attribute that doesn't exist on `ParsedResponse`. Now correctly references `parsed.raw_body` and `parsed.root` (lxml element).

- **Removed dead `_looks_like_response_envelope()` helper.** Was the source of an earlier `lstrip("<?xml")` character-class bug; the lxml-based `parse_response` now handles classification more robustly (also addressing Reviewer 1's "too textual / fragile for `<eidr:Response>`" critique).

### Added

- **`status_lookup(token, *, page_number=None, page_size=None)`.** Java-parity gap from the M10 v1 review: Java's `statusLookupViaToken(..., pageNumber, pageSize)` supports pagination; Python's didn't. The fix is additive — pagination kwargs are optional. Without them, the existing GET path is used (preserving `Token.poll/wait` backwards compatibility). With either kwarg set, the method dispatches to a POST with a `<Token>` element in the request body, mirroring Java's `workaround=true` path. Three new tests pin the dispatch behavior.

- **`build_status_request()` helper now accepts `token=` kwarg.** The existing `user_id` / `registrant` / `superparty` selector set is extended to a fourth selector — `token`. Mutual-exclusion validation updated. Tag element name is `<Token>` (capitalize first letter, per Java's `posttag` logic).

### Variance table updates (from `M9_COVER_LETTER.md`)

The `status_lookup(token)` pagination row flips from "deferred" to ✅ Equivalent. All other M10 rows already at ✅ remain so.

### Reviewer credits

This fix pass acted on three independent reviews of `0.1.0a2`. Reviewer 1's high-priority items — read-only POST gating, the modification-base shape problem, the modification-base→modify round-trip risk, the stale README/init claims, and the token-pagination parity gap — drove most of the changes here. Reviewer 2 and Reviewer 3 endorsed the M10 design choices and identified longer-term ergonomic improvements (auto-paging iterators, typed query helpers, typed `VirtualFields`) that are flagged as roadmap items but not in scope for this fix pass.



(no unreleased changes)


## [0.1.0a2] — 2026-04-27

Second pre-release. Closes out **Milestone 10** (Java-parity gap closeout) on top of `0.1.0a1` (M9: Service writes, Party writes, virtual fields, Superparty gate). Six rows in the variance table flip from 🟡 Deferred / 🟢 Different by design to ✅ Equivalent.

**Pipeline state at release:** 1,064 unit tests passing · 15 integration tests deselected by default (7 new in M10, 8 from prior milestones; opt-in via `pytest -m integration`) · ruff clean · ruff format clean · mypy `--strict` clean across 48 source files.

**Compatibility:** Python 3.11+. No breaking changes since `0.1.0a1`.

### M10 — what landed

Three feature areas, each a 🟡 Deferred row in the M9 variance table that now flips to ✅ Equivalent.

#### Status lookup variants (M10-A)

Three new methods on `Client` and `AsyncClient`, mirroring `StatusLookup.statusLookupViaUser` / `statusLookupViaRegistrant` / `statusLookupSuperparty` from the Java reference SDK. All three POST to `/status/` with a `<Request><Operation><StatusRequest>...</StatusRequest></Operation></Request>` body (form-field name `statusrequest` per `Literals.lithash`).

- `status_lookup_by_user(user_id, *, page_number=1, page_size=20, status=None, after=None, before=None)` — emits `<UserID>{user_id}</UserID>` (special case: NOT `<User>`).
- `status_lookup_by_registrant(registrant, *, page_number=1, page_size=20, status=None, after=None, before=None)` — emits `<Registrant>{registrant}</Registrant>`.
- `status_lookup_superparty(*, page_number=1, page_size=20, status=None, after=None, before=None)` — no tag element; the registry uses auth credentials' Superparty status to authorize. Not gated by the SDK's Party-write Superparty gate (which is for destructive operations only).

Date-range encoding follows Java's behavior:

- `after` alone → `<After>{after}</After>`
- `after` + `before` → `<From>{after}</From><To>{before}</To>`
- Naïve `datetime` values are interpreted as UTC.

The implementation always uses POST (matching Java's `workaround=true` default) because the GET path corrupts user/party IDs containing `/`, and EIDR IDs always do (`10.5238/richardkroon`, `10.5237/FFDA-9947`).

The existing `status_lookup(token)` for token-based lookup is unchanged — tokens are opaque registry-issued strings without slashes, so the simple GET path remains correct there.

New helper: `eidr.client._operations.build_status_request()` — exported alongside the existing `build_*` operation builders.

#### Modification base (M10-C)

`Client.modification_base(asset_id, *, creation_type=CreationType.Basic)` and the async mirror. Returns a typed `ContentRecord` carrying the registry's pre-filled record body, suitable for use as a starting point in a subsequent `modify()` call. Workflow::

    base = client.modification_base(asset_id)
    # ...mutate base...
    client.modify(base)

GETs `/object/modificationbase/{asset_id}?type=Create{CreationType}`. Mirrors Java's `ModificationBase.getModificationBase`.

The implementation uses a new `_looks_like_response_envelope()` helper (in `eidr.client._shared`) to distinguish bare-record success bodies from `<Response>` error envelopes — a precise startswith check rather than the strict element-name match used by `parse_response`'s `_RESOLVE_ROOTS` (which doesn't enumerate every possible record-root element).

#### Service-graph reads (M10-B)

- `Client.service_parent(service_id) -> ServiceRecord | None` and the async mirror. Returns the parent service if one exists, `None` if the service is at the root of its hierarchy (registry returns `Code 4 not found` which the SDK translates to `None`). Other errors (auth, validation) propagate as their normal typed exceptions. Mirrors Java's `ServiceGraph.getServiceParent`.
- `Client.service_children(service_id, *, include_inactive: bool = False)` — added the previously-missing `include_inactive` kwarg. Wire format: `?all=true` or `?all=false`. Default `False` matches Java's default behavior.

### Test-suite trajectory

| Milestone close | Unit tests |
|---|---|
| M8 (typed Digital) | ~924 |
| M9 (initial drop) | ~974 |
| M9 review-fix pass | ~979 |
| M9 live-test rounds 1-5 | ~1,000 |
| M9 + Superparty gate (v7) → 0.1.0a1 | 1,029 |
| M10-B service-graph reads | 1,039 |
| M10-C modification_base | 1,045 |
| M10-A status lookup variants | 1,056 |
| M10 async parity → **0.1.0a2** | **1,064** |

### Variance-table delta

Six rows flipped to ✅ Equivalent at this release: Lookup-by-user, Lookup-by-registrant, Superparty lookup, Pagination (side effect), Get a record's modification base, Service get-parent, Service get-children's `includeInactive` parameter.

### Live-sandbox verification

Same opt-in integration test pattern as M9:

- `pytest -m integration tests/test_integration_sandbox.py` runs all 15 tests against `sandbox2.eidr.org`.
- `EIDR_TEST_USER_ID`, `EIDR_TEST_PARTY_ID`, `EIDR_TEST_PASSWORD` required.
- Optional: `EIDR_TEST_CHILD_SERVICE_ID`, `EIDR_TEST_PARENT_SERVICE_ID`, `EIDR_TEST_ROOT_SERVICE_ID` for the service-graph round-trips.
- Optional: `EIDR_TEST_SUPERPARTY_AVAILABLE=1` to assert success path on `status_lookup_superparty` (otherwise tests for the `EIDRAuthorizationError` rejection path).

The `modification_base` integration test is the **highest-value** of the M10 additions: the response body shape is unverified by docs, and the test captures whatever the registry returns for The Great Train Robbery so we can confirm `ContentRecord.from_xml` parses it cleanly. If this test surfaces a parsing issue it's the same kind of round-by-round signal that drove the M9 live-test fix passes; expect a possible v2 spin if the live response shape differs from assumptions.



(no unreleased changes)


## [0.1.0a1] — 2026-04-27

First publicly-tagged pre-release of the EIDR Python SDK. Closes out **Milestone 9** (Video Service writes, Party writes, virtual-fields retrieval, Python↔Java SDK variance reference, Party-write Superparty gate) on top of the foundational work in Milestones 1-8 (codecs, ContentRecord/Party/Service models, write-side validation, sync + async clients, typed Digital sub-model, content + party + service operation surface).

**Pipeline state at release:** 1,029 unit tests passing · 8 integration tests deselected by default (3 new in M9, 5 from prior milestones; opt-in via `pytest -m integration`) · ruff clean · ruff format clean · mypy `--strict` clean across 48 source files. Live-sandbox verification across six rounds against `sandbox2.eidr.org`.

**Compatibility:** Python 3.11+. Distribution `eidr` on PyPI. Apache-2.0 licensed. Source repository at <https://github.com/EIDR-ID/eidr-python-sdk>.

### Scope summary (what this release includes)

- **Resolution & query** — Content / Party / Service resolve in 7 flavors (`Full`, `Self`, `Provenance`, `Inherited`, `SimpleMetadata`, `DOIKernel`, `LinkedAlternateIDs`); Content / Party / Service query via XML escape-hatch; alt-ID resolution.
- **Content writes** — `register`, `match`, `modify`, `delete`, `add_relationship` / `remove_relationship` / `replace_relationship`, `promote`, `alias`, `graph_traversal`, dedupe-mode and immediate-vs-async control, full pre-submission validation pipeline.
- **Service writes (M9)** — `create_service`, `modify_service`, `delete_service`, `alias_service`, `set_service_parent`, `service_children`.
- **Party writes (M9)** — `create_party`, `modify_party`, `delete_party`, `alias_party`, `activate_party`, `deactivate_party`, `change_party_password`. Strict-by-default Superparty gate (configurable via `superparty_id` and `enforce_superparty_gate` kwargs).
- **Virtual-fields retrieval (M9)** — `virtual_fields(id)` returning a typed `VirtualFields` value object with `id`, `full`, `self_defined`, `alias` views.
- **Async parity** — every sync method has an async counterpart on `AsyncClient`. Sync and async share the response-parsing layer and operation-builder helpers.
- **Tracing** — pluggable `TraceSink` Protocol with structured trace records (`ListSink`, `FileSink`, custom). Authorization headers and `password=` query parameters are redacted.
- **Typed Digital sub-model (M8)** — `[digital]` extra installs `xsdata-pydantic`-generated Pydantic models for the `<Digital>` block within `ManifestationInfo`. The codec-dict layer remains the source of truth; the typed view is a transient projection.
- **Errors** — typed exception hierarchy (`EIDRError` → `EIDRTransportError` / `EIDRProtocolError` / `EIDRClientError` / `EIDRCodecError`), with named subclasses for authentication, authorization, validation, duplicate, uncertain-write, registry, ID-format, read-only, and SDK policy errors.
- **Variance reference** — exhaustive Python↔Java SDK variance table in `M9_COVER_LETTER.md`, organized in 9 sections covering resolution, status lookup, modification helpers, batch operations, party/service/user admin, query, tracing, configuration, and error model.

### M9 — what landed (rolled up from six rounds of fixes)

The M9 milestone went through one initial drop, one two-reviewer code review-fix pass, and five rounds of live-sandbox-test fix passes. Each round surfaced different aspects of the SDK's behavior under real registry conditions.

#### Service / Party / Virtual-fields surface (initial M9 + review-fix pass)

- **6 Service write methods** + **7 Party write methods** + **1 Virtual-fields method** on `Client` and on `AsyncClient` — 28 new methods total.
- New value objects: `VirtualFields` for the virtual-fields response (no codec round-trip needed; the response is small and self-describing).
- Form-field-name dispatch for the `Operations`-envelope writes (the `service/create` endpoint uses `name=batch` per Java SDK literal-map verification, *not* `name=serviceCreate` as the schema docs imply).
- Write-side authorization caveat documented prominently in inline docstrings and README.
- `_record_to_creation_inner` strips `<ID>` from Create payloads (the only registry-assigned element). Other `selfDefinedFieldsGroup` content — including `<Administrators>` — is user-supplied and required in all contexts.
- POST 5xx responses raise `EIDRUncertainWriteError` immediately rather than auto-retrying (matching Java's `safetoretry=false` semantic — writes can't be retried after the body is on the wire because the registry might already have committed).
- URL query parameters (e.g. `target=`, `password=`) URL-encoded via `params=` kwarg on `_Transport.post()` so passwords containing `&`, `+`, `%`, `=`, or space don't corrupt the request.
- `password=` parameter redacted from any URL captured in a `TraceRecord` so it doesn't leak into trace logs.
- Empty-body POST sends literal zero bytes (matches Java's `preparePayload`-skip path for endpoints like `/party/delete/{id}` that take no body).

#### Live-test rounds 1-5 — registry-shape discoveries

Live-sandbox testing revealed five distinct response shapes the registry uses for write operations, plus two locations where `<Token>` can appear, plus one operation-level error pattern that the request-level status doesn't surface.

The five response shapes now handled:

1. **Bare record root** (`<Service>...</Service>`) — Service resolve-style response.
2. **Envelope-wrapped record** (`<Response><Status/><Service/></Response>`) — alternate Service write response.
3. **Top-level Status with Details** (`<Response><Status><Details>10.5239/...</Details></Status></Response>`) — Service / Party admin write success. The `<Details>` text contains the registry-assigned ID; the SDK follows up with a resolve to return the full record.
4. **OperationResult-wrapped Status with Details** (`<Response><OperationResult><Status><Details>...</Details></Status></OperationResult></Response>`) — Content write success (register / modify) using the `<Operations>` envelope.
5. **OperationStatus with Duplicate** (`<Response><RequestStatusResults><OperationStatus><Duplicate score="..."><ID>...</ID></Duplicate></OperationStatus></RequestStatusResults></Response>`) — Match-found success. The matched record's ID is in `<Duplicate>/<ID>`; the SDK resolves it inline so callers get a `ContentRecord` rather than a `Token` they have to poll.

Token extraction looks in two locations: `<Response>/<Token>` (top-level) and `<Response>/<RequestStatus>/<Token>` (the location used by `match`).

Operation-level errors (`<OperationStatus><Status><Code>4</Code><Type>validation error</Type><Details>...</Details></Status></OperationStatus>` *inside* a request-level `Code 0 success` envelope) are now surfaced via `raise_for_operation_status()` using the same dispatcher that handles request-level errors. The motivating case: `match()` against a record whose `<Administrators><Registrant>` doesn't match the auth party returns "Registrant must match the Party ID" at the operation level, with `Code 0` at the request level.

Other round-1-through-5 fixes:

- **OrgName namespace normalization.** Service and Party records' `<DisplayName>` / `<SortName>` are in the MovieLabs `md:` namespace (`http://www.movielabs.com/schema/md/v2.8/md`), not the EIDR namespace. The SDK rewrites bare `<DisplayName>` to `<md:DisplayName>` automatically and ensures the `xmlns:md` declaration is present. Without this, the registry rejects the payload with a schema validation error.
- **`coerce_id_to_str()` helper.** Methods that take an ID string now accept any value with `__str__` — so `client.delete_service(record.id)` works directly with the `EIDRID` value object that `ServiceRecord.id` returns. Wired into all 13 ID-validation sites in the sync client and 13 in the async client.
- **`parse_response` accepts envelopes with status nested in `<OperationResult>` / `<OperationStatus>`** — previously rejected as protocol violation.
- **Smoke-script robustness.** Cleanup logic now scrapes the trace log for `<Details>10.5239/...</Details>` if the SDK returns an unexpected shape, ensuring no test resource gets stranded even under SDK-side errors. Display logic coerces `EIDRID` to string up front to avoid format-string concat crashes in the success-message path.

#### Party-write Superparty gate (v7)

Per the M9 design discussion: client-side enforcement of the registry-side policy that restricts Party-administration to a single hard-coded "Superparty" (default ID `10.5237/superparty`, a universal constant across all EIDR registries). The registry has no Role mechanism for delegating Party admin authority, so the gate is the cleanest way to give general-purpose SDK callers an early, clear refusal instead of a deferred server-side authorization error.

- **New `EIDRSDKPolicyError` class** — subclass of `EIDRClientError`, distinct from server-side `EIDRAuthorizationError`. Carries `policy="superparty_required"`, `operation`, `configured_value`, `required_value` attributes for programmatic inspection.
- **Two new `Client` / `AsyncClient` kwargs** — `superparty_id: str = "10.5237/superparty"` and `enforce_superparty_gate: bool = True`. Strict by default.
- **Seven gated methods** — `create_party`, `modify_party`, `delete_party`, `alias_party`, `activate_party`, `deactivate_party`, `change_party_password`. Each calls `_check_superparty_gate(operation_name)` as the very first line, before any wire work.
- **Not gated** — `resolve_party`, `party_query`, all Service writes (governed by Party Roles, which the registry handles).
- **Anonymous-client handling** — a client constructed without credentials trips the gate with a tailored "requires Superparty credentials but the client was constructed without credentials" message rather than a confusing `AttributeError`.
- **Live verification** — confirmed against `sandbox2.eidr.org`: invoking `delete_party()` with non-Superparty credentials raises `EIDRSDKPolicyError` immediately with no HTTP request issued.

### Live-sandbox verification record

- **Round 0 (initial drop)** — unit tests only.
- **Round 1** — OrgName namespace bug, `<ID>` not stripped from Create payloads, anonymous virtual_fields test inverted.
- **Round 2** — `<Status><Details>` ID-as-success-payload shape discovered (would have stranded a test service had it not been fixed mid-flight).
- **Round 3** — `OperationResult`-wrapped Status fallback, `coerce_id_to_str` for `EIDRID` callers, smoke `modify_service` `None` expectation relaxed.
- **Round 4** — `<RequestStatus>/<Token>` location discovered, operation-level error surfacing via `raise_for_operation_status`, integration test fixture rewrites Registrant.
- **Round 5** — `<Duplicate>/<ID>` inline resolution for `match` results.
- **v7 (Superparty gate)** — confirmed live: `delete_party()` with non-Superparty creds raises `EIDRSDKPolicyError` with no HTTP traffic.

Six round-trip suites verified end-to-end against `sandbox2.eidr.org`:

- `Authorization: Eidr <user>:<party>:<base64-sha256-pw>` header — accepted, byte-for-byte match with Java reference SDK
- `virtual_fields` authenticated — full round-trip with `id`, `full`, `self_defined` views populated
- `virtual_fields` anonymous — correctly raises `EIDRAuthenticationError` (registry policy)
- `create_service` end-to-end — POST → `<Status><Details>` ID → SDK resolves → returns populated `ServiceRecord`
- `modify_service` end-to-end — POSTs `<Service>` with proper `md:` namespacing, registry returns bare success ack
- `delete_service` — accepts `EIDRID` or `str`, POSTs to `/service/delete/{id}`, registry confirms
- `match` against existing record — POST → registry returns `<Duplicate>` envelope → SDK resolves matched ID inline → returns `ContentRecord`
- Full create → modify → delete round-trip with no stranded test service across any of the six runs

### Test-suite summary at release

| Group | Count | What it covers |
|---|---|---|
| Foundational (M1–M5) | ~600 | Codecs, ContentRecord/Party/Service models, ID parsing, write-side validation, registry catalog |
| HTTP transport + write methods (M6) | ~150 | Sync transport, retry policy, content writes, tracing |
| Async parity (M7) | ~120 | AsyncClient mirror, AsyncToken, async transport |
| Typed Digital (M8) | ~50 | xsdata-pydantic round-trip, MANIFEST consistency |
| M9 wire-shape (Service / Party / Virtual-fields) | ~45 | Endpoint URLs, body wrappers, response handling |
| M9 review-fix and live-test regressions | ~24 | OrgName namespace, `<ID>` strip, response shapes, token locations, operation-level errors, EIDRID coercion, etc. |
| Superparty gate (v7) | 29 | Refusal, pass-through, bypass, custom ID, anonymous, read-not-gated, service-not-gated, async mirror |
| **Total** | **1,029** | All passing, 8 deselected integration tests opt-in |



### Added (M9-fixed-v7) — Party-write Superparty gate

Per the maintainer's spec: client-side enforcement of a registry-side policy that restricts Party-administration operations to a single hard-coded Party (the "Superparty"). Unlike Service writes, the registry has no Role mechanism that lets it delegate this authority — only the Superparty can perform Party admin.

- **New ``EIDRSDKPolicyError`` exception class.** Subclass of ``EIDRClientError``. Distinct from server-side ``EIDRAuthorizationError``: this one is the SDK's "I won't even ask," raised at method entry before any wire work. Carries ``policy``, ``operation``, ``configured_value``, ``required_value`` attributes for programmatic inspection. The ``policy`` attribute is a stable string identifier (``"superparty_required"``) so callers can branch on the kind of gate without parsing messages.

- **Two new ``Client`` / ``AsyncClient`` kwargs.**
   - ``superparty_id: str = "10.5237/superparty"`` — the ID the gate requires. The default is correct for all current EIDR registries (production, sandbox1, sandbox2, sandbox2-mirror) per the maintainer; configurable for hypothetical future rotation or non-standard test deployments.
   - ``enforce_superparty_gate: bool = True`` — strict by default. Setting to ``False`` bypasses the gate; only useful for testing the SDK itself or the unusual case of a caller who is the Superparty under a non-default ID.

- **Seven gated methods.** ``create_party``, ``modify_party``, ``delete_party``, ``alias_party``, ``activate_party``, ``deactivate_party``, ``change_party_password``. Each calls a private ``_check_superparty_gate(operation_name)`` helper at method entry as the very first line. Read operations (``resolve_party``, ``party_query``) are **never** gated. Service writes are not gated either — they're governed by Party Roles, which the registry handles itself.

- **Anonymous client handling.** A client constructed without credentials hits the same gate with a tailored message: "requires Superparty credentials but the client was constructed without credentials" — rather than a confusing ``AttributeError`` or a delayed server-side auth error.

- **Dedicated test module ``tests/test_superparty_gate.py``.** 29 tests across 8 groups: every gated method refuses non-Superparty (parametrized × 7), every gated method passes through with matching creds (×7), every gated method passes through with the gate disabled (×7), custom Superparty ID accepts/rejects correctly, anonymous client refused, ``resolve_party`` not gated, ``create_service`` not gated, AsyncClient mirror exercises both refusal and bypass paths.

- **Existing wire-shape tests opt out of the gate.** ``make_client()`` helpers in ``tests/test_client_m9_writes.py`` and ``tests/test_async_client_m9_writes.py`` now pass ``enforce_superparty_gate=False`` by default — those tests verify the request bytes, not the policy. The 13 affected tests (plus 8 async mirrors) continue to pass unchanged.

### Variance from Java SDK

The Java reference SDK exposes Party admin to any caller and lets the registry reject server-side. The Python SDK gates these operations client-side by default, with a configurable opt-out. This is a deliberate divergence: the Python SDK is intended for general-purpose use including by callers who have no plausible reason to invoke Party admin, and an early, clear refusal is more useful than a deferred auth error. Maintainer-approved per the M9 design discussion.



### Fixed (M9 live-test pass round 5)

Round 4 confirmed ``match()`` works end-to-end against ``sandbox2.eidr.org`` — the trace shows a clean POST → ``Code 0`` request-level success → token + duplicate ID returned in the body. But it also surfaced a *fifth* registry response shape that the round-4 fixes only partially handled.

- **Match-result fast path: surface the duplicate ID inline.** The live registry's ``match`` response for a found-duplicate result includes both a request-level ``<Token>`` and the matched record's ID inline, in ``<OperationStatus>/<Duplicate>/<ID>``::

      <Response>
        <Status><Code>0</Code><Type>success</Type></Status>
        <RequestStatus><Token>...</Token></RequestStatus>
        <RequestStatusResults>
          <CurrentSize>1</CurrentSize>
          <TotalMatches>1</TotalMatches>
          <OperationStatus>
            <Token>...</Token>
            <Status><Code>0</Code><Type>success</Type></Status>
            <Duplicate score="95" lowThreshold="60" highThreshold="90">
              <ID>10.5240/...</ID>
            </Duplicate>
          </OperationStatus>
        </RequestStatusResults>
      </Response>

  Without this fix, the SDK only saw the request-level token and returned that as a deferred ``Token`` — forcing the caller to poll ``status_lookup`` for an answer that's already in the response body. The ID, score, and threshold attributes were all there, just not surfaced.

  Fix: new ``extract_duplicate_id()`` helper in ``eidr.client._response`` checks every ``<OperationStatus>`` for a ``<Duplicate>/<ID>`` element. When found, ``_submit_write`` resolves the ID directly and returns a ``ContentRecord``, bypassing the token-then-poll path. Wired into both sync and async ``_submit_write``. Verified against the live sandbox response captured in the M9 round-4 trace. Regression test in ``tests/test_client_writes.py`` uses the actual sandbox response body shape (with score=95, thresholds 60/90) to lock in the contract.

### Documentation

Updated ``Administrators`` block handling notes (no code change required, but worth recording explicitly): the ``<Administrators>`` block — including ``<Registrant>`` and any metadata-authority entries — is **user-supplied and required for all write contexts** (create, modify, match). The only registry-assigned element is the EIDR ID itself, which is stripped from Create payloads and assigned by the registry on commit. Earlier internal notes that suggested ``<Administrators>`` was registry-assigned were incorrect; the SDK code never made that assumption (``_record_to_creation_inner`` only strips ``<ID>``), so no behavior change. The clarification is now reflected in the docstring for ``_record_to_creation_inner`` and the variance table.

### Verified working against the live sandbox (M9 smoke + integration round 4)

Per the round-4 trace logs:

- ``create_service`` / ``modify_service`` / ``delete_service`` round-trip end-to-end (the round-3 ``coerce_id_to_str`` and round-2 ``<Status><Details>`` fixes now confirmed across multiple runs)
- ``match()`` POSTs a registry-acceptable payload (with ``<Administrators><Registrant>`` set to the auth party), registry returns the ``<Duplicate>``-shaped envelope, SDK surfaces the matched record after the round-5 fix
- All four prior-round fixes (namespace normalization, ID strip on Create, ``<Status><Details>`` extraction, ``<OperationResult>``-wrapped Status fallback, nested-token extraction, operation-level error surfacing, ``EIDRID`` coercion) work correctly together against the live registry



### Fixed (M9 live-test pass round 4)

Round 3 brought ``create_service`` / ``modify_service`` / ``delete_service`` to a fully-working end-to-end state against ``sandbox2.eidr.org`` — the smoke trace logged a clean POST → resolve → POST → POST sequence with all three operations returning ``Code 0 success`` and the test service properly cleaned up. ``match()`` was the only remaining failure, and the per-test trace from the integration suite revealed two distinct issues plus a smoke-script display bug.

- **``<Token>`` lives inside ``<RequestStatus>``, not at top level.** The ``match`` operation's response carries the request-level token at ``<Response>/<RequestStatus>/<Token>`` rather than ``<Response>/<Token>``. The previous ``extract_token`` only looked at the top-level location and returned ``None`` for match responses, so the SDK fell through to its bare-success branch and raised ``EIDRProtocolError`` (round-3 added the ``<OperationResult>``-wrapped Status fallback to ``extract_status_details``, but ``extract_token`` itself wasn't extended). Fix: ``extract_token`` now falls back to ``<RequestStatus>/<Token>`` when no top-level ``<Token>`` is found. Regression test in ``tests/test_client_response.py``.

- **Operation-level errors were swallowed by generic protocol-error handling.** The registry can return ``Code 0 success`` at the request level while reporting an *operation-level* error (e.g. ``Code 4 validation error: Registrant must match the Party ID``). The SDK previously fell through all the inline-record/token/details extraction paths and surfaced a generic ``EIDRProtocolError`` ("registry returned neither a record nor a token"), hiding the actionable diagnostic. Fix: new ``raise_for_operation_status()`` helper in ``eidr.client._response`` checks every ``<OperationStatus>`` (or ``<OperationResult>``) child for a non-zero status code; if found, raises the matching typed exception with full ``Code`` / ``Type`` / ``Details`` context (using the same ``_status_to_exception`` dispatcher that handles request-level errors). Wired into both ``_submit_write`` (sync) and ``async _submit_write``. Regression test in ``tests/test_client_writes.py``.

- **Smoke script's ``record()`` reporter chokes on ``EIDRID``.** The cleanup branch passed ``created_id`` (an ``EIDRID`` value object from ``ServiceRecord.id``) as the ``detail`` argument to a print-format string, which can't ``+``-concatenate a non-string type. The actual delete operation succeeded — only the success message crashed. Fix: ``record()`` now coerces ``detail`` to a string up front via ``str(detail)``.

- **``match()`` integration test fixture rewrites Registrant.** The integration test's ``match()`` flow resolved a foreign-party record (one whose ``<Administrators><Registrant>`` is some other party) and submitted it back unchanged, which the registry correctly rejects ("Registrant must match the Party ID"). Test now rewrites the registrant to the test party's ID before resubmission. The fix from the operation-level-error work above means this would have surfaced as a clear ``EIDRValidationError`` rather than ``EIDRProtocolError``, but the test should still submit a registry-acceptable payload.

### Verified working against the live sandbox (M9 smoke round 3)

The round-3 smoke trace confirmed the following operations work end-to-end against ``sandbox2.eidr.org``:

- ``create_service`` — POST → ``<Status><Details>`` ID → SDK resolves → returns populated ``ServiceRecord`` (verified ID ``10.5239/5C9B-663A``)
- ``modify_service`` — POSTs ``<Service>`` body, registry returns bare ``Code 0 success`` ack, SDK correctly returns ``None``
- ``delete_service`` — accepts ``EIDRID`` value object (round-3 ``coerce_id_to_str`` fix), POSTs to ``/service/delete/{id}``, registry confirms with ``Code 0 success``
- Full create → modify → delete round-trip with no stranded test service



### Fixed (M9 live-test pass round 3)

The maintainer ran the full smoke + integration suites against the live ``sandbox2.eidr.org`` registry after M9-fixed-v3 shipped. **Round 3 result: full ``create_service`` round-trip working end-to-end on the wire** (verified by trace: POST → ``<Status><Details>`` ID → SDK follows up with resolve → registry returns the full Service body → SDK returns a populated ``ServiceRecord``). Three issues surfaced; all three fixed.

- **``parse_response`` rejected envelopes with status nested inside ``<OperationResult>``.** Content writes (``register`` / ``match`` / ``modify``) using the ``<Operations>`` envelope receive responses with the status block nested one level deeper than Service/Party admin writes::

      <Response>
        <OperationResult>
          <Status>
            <Code>0</Code><Type>success</Type>
            <Details>10.5240/...</Details>
          </Status>
        </OperationResult>
      </Response>

  ``parse_response`` was raising ``EIDRProtocolError`` for these because there's no ``<Status>`` at top level. ``match()`` against an existing record manifested the bug. Fix: ``parse_response`` now falls back to ``<OperationResult>/<Status>`` or ``<OperationStatus>/<Status>`` when no top-level ``<Status>`` is present. ``extract_status_details()`` similarly extended to look in both locations. Regression test in ``tests/test_client_writes.py``.

- **``EIDRID`` value objects rejected by ID validation.** After ``client.create_service(record)`` returns a ``ServiceRecord``, the natural caller pattern is ``client.delete_service(new_record.id)`` for cleanup. But ``ServiceRecord.id`` returns an ``EIDRID`` value object, not a string. The previous validation (``if not service_id or not service_id.strip()``) raised ``AttributeError: 'EIDRID' object has no attribute 'strip'``, breaking that pattern and stranding the test service on the smoke run. Fix: new ``coerce_id_to_str()`` helper in ``eidr.client._shared`` accepts any value with ``__str__`` and validates non-emptiness. Wired into all 13 ID-validation sites in the sync client and 13 in the async client. Regression test verifies an ``EIDRID`` argument is accepted by ``delete_service``.

- **Smoke script's ``modify_service`` expectation was too strict.** The live registry's ``modify_service`` response is a bare success ack (``<Status><Code>0</Code></Status>``) with no body to echo. The SDK correctly returns ``None`` for this shape (per ``_submit_admin``'s docstring), but the smoke script treated ``None`` as a failure. Fix: smoke now treats ``None`` from ``modify_service`` as the documented "modified, no body to echo" success path, distinct from any other unexpected return.

### Verified working against the live sandbox (M9 smoke, rounds 1-3)

After three rounds of live-test fixes, all of the following are verified end-to-end against ``sandbox2.eidr.org``:

- ``Authorization: Eidr <user>:<party>:<base64-sha256-pw>`` header (matches Java reference SDK byte-for-byte)
- ``virtual_fields`` with credentials — full round-trip with ``id``, ``full``, ``self_defined`` views populated
- ``virtual_fields`` without credentials — correctly raises ``EIDRAuthenticationError`` (registry policy)
- ``create_service`` — POST → registry assigns ID → SDK resolves → returns populated ``ServiceRecord``
- ``modify_service`` — POSTs ``<Service>`` body with proper ``md:`` namespacing, registry accepts with bare success ack
- ``delete_service`` — accepts both ``str`` and ``EIDRID`` arguments (M9 round-3 fix)
- ``<Status><Details>`` ID-as-success-payload response shape (verified for ``create_service``; ``OperationResult``-wrapped variant inferred from ``match`` failure shape and unit-tested)
- The ``<CreateService>`` envelope wrapper, ``name=batch`` form-field, empty-body POSTs, envelope-wrapped record responses, and all M9 review-fix items from prior rounds



### Fixed (M9 live-test pass round 2)

A second round of live-sandbox runs surfaced one final response shape that the M9 round-1 fix didn't account for — the registry's actual write-success envelope. Diagnosed and fixed.

- **``<Status><Details>`` ID-as-success-payload response shape.** The live ``sandbox2.eidr.org`` registry's standard response to a successful Service/Party write is::

    <Response>
      <Status>
        <Code>0</Code>
        <Type>success</Type>
        <Details>10.5239/52C0-0B32</Details>
      </Status>
    </Response>

  This is neither a bare record root nor an envelope-wrapped record (the two shapes the M9 round-1 fix handled) — it's a third shape with the new record's ID embedded in ``<Status><Details>``. The previous handler returned ``None`` for this shape, which meant ``create_service`` reported "unexpected return" and the smoke script's cleanup logic couldn't find an ID to delete (resulting in a stranded test service in sandbox2 that the maintainer had to clean up manually). The same shape was also blocking ``match()`` against existing records — manifesting after the round-1 ``<ID>``-strip fix as ``EIDRProtocolError: succeeded but the registry returned neither a record nor a token``.

  Fix: new ``extract_status_details()`` helper in ``eidr.client._response``. Both ``_submit_admin`` (Service/Party writes) and ``_submit_write`` (Content register/match/modify) now check for ``<Status><Details>`` after the inline-record and token paths come up empty; if a valid EIDR ID is present, the helper follows up with a ``resolve()`` call and returns the full record. Both sync and async transports.

  Two regression tests added: ``TestCreateService::test_handles_status_details_id_response`` and ``TestMatch::test_match_handles_status_details_id_response``. Both simulate the two-stage POST→GET interaction with a mock transport and verify the returned record has the registry-assigned ID.

- **Smoke script cleanup made robust.** The previous cleanup logic depended on the SDK successfully reporting the created ID — if the SDK returned an unexpected shape (which is exactly what happened in the round-1 live test), the cleanup branch never fired and the registry-side service was stranded. New ``_scrape_created_service_id()`` helper scans the trace log for the most recent ``<Details>10.5239/...</Details>`` from a successful response. Used as a fallback both when ``create_service`` returns an unexpected shape *and* when it raises (in case the registry committed before the exception). The trace log is the right source of truth for "did the registry actually create something" because it captures the exact response wire bytes.



### Fixed (M9 live-test pass)

Three bugs surfaced when the maintainer ran the M9 smoke + integration tests against the real EIDR sandbox. All three were verified against the schema and registry response payloads before fixing.

- **`<DisplayName>` / `<SortName>` namespace bug.** The MovieLabs MD-v2.8 schema requires these elements (inside ``ServiceName`` / ``PartyName``) in the MD namespace (``md:`` prefix). The codec layer faithfully preserves whatever shape was parsed, so a record constructed from XML with bare-namespaced ``<DisplayName>`` round-tripped back as schema-invalid bytes. Live registry rejected with::

    cvc-complex-type.2.4.a: Invalid content was found starting with
    element 'DisplayName'. One of '{...}:DisplayName' is expected.

  Fix: new ``eidr.models._org_name_norm`` module with two helpers — ``normalize_org_name_block()`` rewrites bare keys (``DisplayName`` / ``SortName`` / ``AlternateName``) to their ``md:``-prefixed forms, and ``ensure_md_namespace_declared()`` adds the ``_xmlns:md`` declaration at the root so the XML serializer can emit it. Both wired into ``ServiceRecord.__init__`` and ``PartyRecord.__init__``. **Idempotent**: already-correct inputs pass through unchanged. **Auto-corrects** bare-namespace inputs on parse, so the fix benefits existing callers without any code change. 13 new regression tests in ``tests/test_org_name_normalization.py``.

- **``<ID>`` not stripped from Create/Match payloads.** The Create payload's schema (``creationFullInfo`` / ``creationSelfDefinedInfo`` in ``eidr-base.xsd``) places ``<StructuralType>`` first; ``<ID>`` is not part of the type at all because the registry assigns IDs on Create. The schema's own annotation says it explicitly: *"the groups rather than the resolution types because no ID is present in a creation"*. The previous ``_record_to_creation_inner`` helper just renamed the root element without removing ``<ID>``, so resubmitting a resolved record through ``match()`` produced a body the registry rejected with ``cvc-complex-type.2.4.a: Invalid content was found starting with element 'ID'``. Fix: helper now strips ``<ID>`` from ``<BaseObjectData>`` after the rename. Modify operations are unaffected — the ID lives in the outer ``<Modify>`` envelope, not inside ``<BaseObjectData>``. Existing test updated and a new regression test added.

- **Anonymous virtual-fields test was wrong.** The integration test ``test_virtual_fields_anonymous_resolve_registry`` expected the call to succeed, but per registry policy (confirmed by the maintainer) anonymous access to ``/virtual/object/`` is blocked — only ID resolution remains public, with alternate IDs stripped. Renamed to ``test_virtual_fields_requires_authentication`` and inverted to assert that ``EIDRAuthenticationError`` is raised. Same fix in the smoke script's ``[2/4]`` step.

### Verified working against the live sandbox (M9 smoke)

The live smoke runs against ``sandbox2.eidr.org`` confirmed the following M9 wire shapes are correct:

- ``virtual_fields`` against authenticated SANDBOX2 — full round-trip; response handling correctly extracts ``id``, ``full``, and ``self_defined`` views from a ``<Response><Status/><VirtualFields/></Response>`` envelope.
- The ``Authorization: Eidr <user>:<party>:<base64-sha256-pw>`` header — accepted by the registry; the SDK's ``make_auth_header`` matches the Java reference SDK byte-for-byte.
- The ``<CreateService>`` envelope wrapper — registry parses it correctly (the only failure was the namespace-prefix issue inside ``ServiceName``, fixed above).
- The ``serviceCreate``-form-field revert (M9 review pass) — registry accepts the request as ``name=batch`` (Java SDK default), confirming the form-field-name inference in the original M9 was unnecessary.
- The new envelope-wrapped record-response handling (M9 review pass) — correctly unwrapped a ``<Response><Status/><Service/></Response>`` shape (this is the actual shape the live registry uses for service responses).

### Notes (M9 live-test pass)

- One bug surfaced by the integration tests is **not** M9-specific and existed in earlier milestones. The ``match()`` ``<ID>`` strip fix benefits any caller who resubmits a resolved record — even though Match is a pre-M9 feature, no integration test had previously exercised the resolved-record-resubmit path.
- Live testing against ``sandbox2.eidr.org`` is the canonical wire-shape verification path. Mock unit tests catch most regressions but cannot catch a bug where both the test data and the production code are wrong in the same way (the namespace bug above is exactly that pattern).



### Fixed (M9 review pass)

These changes address feedback from two reviewers on the M9
drop. Both reviewers independently flagged the same
high-priority items, which was a strong signal that the
issues were real.

- **POST 5xx auto-retry removed.** The transport had been
  retrying POSTs on 5xx with a comment claiming "5xx generally
  means the request didn't reach application logic, so retry
  is safe." That assumption was wrong — a 502/503/504 from a
  load balancer can absolutely come *after* the registry
  processed the request, so an auto-retry could duplicate the
  operation. Now matches Java's ``Post.java`` semantics:
  ``safetoretry = false`` the moment the body has been
  transmitted. A 5xx response now raises
  :class:`EIDRUncertainWriteError` immediately with the
  reconciliation guidance from the docstring. (R1, R2)
- **Form-field name ``serviceCreate`` removed.** Java's
  ``conf/Literals.java`` ``lithash`` doesn't register a
  ``/service/create/`` mapping — the endpoint falls through to
  the ``"batch"`` default. M9's initial drop registered
  ``serviceCreate`` as an inference; reviewers correctly
  flagged this as a parity-bug candidate. Reverted. The form-
  field map now matches Java exactly. (R1, R2)
- **Admin response parsing handles both shapes.** Service and
  Party write responses can come back either as a bare record
  root (``<Service>...</Service>``) or wrapped inside the
  standard envelope (``<Response><Status/><Service>...</Service></Response>``).
  The previous ``_submit_admin`` only handled the bare-root
  case and silently returned ``None`` for the envelope shape.
  New :func:`extract_inline_record_xml` helper in
  :mod:`eidr.client._response` handles both shapes; both sync
  and async ``_submit_admin`` use it. Regression tests for
  both clients lock the fix in. (R1, R2)
- **Query parameters URL-encoded properly.** The four URL-
  parameter operations (``alias_service``, ``set_service_parent``,
  ``alias_party``, ``change_party_password``) used f-string
  interpolation (``f"...?password={pw}"``) which would corrupt
  requests if the value contained ``&``, ``+``, ``%``, ``=``,
  or whitespace. The transport's ``post()`` now accepts a
  ``params=`` kwarg (mirror of what ``get()`` already had);
  values are properly percent-encoded by httpx. (R1, R2)
- **URL redaction in trace records.** Sensitive query
  parameters (currently ``password``) are now redacted from
  the ``url`` field of trace records via a new
  :func:`redact_url_query` helper in :mod:`eidr.client._tracing`.
  Previously only headers and bodies were redacted; URLs were
  captured verbatim, so ``password=secret`` would leak to any
  trace sink. Hat tip: both reviewers flagged this. (R1, R2)
- **Empty-body POST sends literal empty body.** URL-only
  operations (``delete_*``, ``alias_*``, ``activate_party``,
  ``deactivate_party``, ``set_service_parent``,
  ``change_party_password``) used to wrap ``""`` in multipart
  boundary lines because the transport always called
  ``_build_multipart_body``. Java's ``Post.java`` skips its
  ``preparePayload`` when ``data == ""`` — the wire body is
  zero bytes, but the Content-Type header still says
  multipart. The Python transport now matches that semantic.
  (R1, R2)
- **Stale ``__init__.py`` and ``REVIEW_SCOPE.md`` updated.**
  The top-level ``__init__.py`` "Not yet implemented" list
  still claimed Video Service writes, virtual fields, and the
  Digital sub-model were not implemented, and that Party
  writes were not planned. ``REVIEW_SCOPE.md`` still described
  the pre-HTTP-client scope. Both updated. The
  ``REVIEW_SCOPE.md`` is now flagged as historical with a
  prominent pointer to the current milestone cover letter.
  (R1)
- **Party-write authorization caveat added** to both the
  inline section comment and the README's Party-writes usage
  example. The caveat: most Party write operations are
  administrative and the registry will refuse them with
  :class:`EIDRAuthorizationError` (HTTP 403) for parties
  without the appropriate role. (R1)

### Notes (R1/R2 items deferred with rationale)

- **Modification base retrieval** (Java's
  ``ModificationBase.getModificationBase``). Both reviewers
  flagged this as higher-priority than other deferred items.
  Now top of M10's queue.
- **Status lookup variants** (via-user, via-registrant,
  superparty). Already documented as deferred; reviewers
  acknowledged.
- **Typed Party / Service query helpers** (Java's
  ``findPartiesByName`` etc.). Already documented as deferred;
  variance table now describes the wire-capability vs
  ergonomic-parity distinction.
- **Match returns ``ContentRecord`` rather than a typed
  ``MatchResult``.** R1 raised this as a semantic mismatch.
  Tracking for a future milestone; would be a breaking change
  to the existing ``match()`` return type.
- **``service_children`` ``includeInactive`` parameter.**
  R1/R2 noted Java has the parameter; Python does not.
  Already documented as deferred to M9.1 with sandbox
  verification.
- **``get_service_parent`` read method.** R2 noted Python only
  writes the parent relationship; Java has both read and
  write. Already documented as deferred.
- **Batch operations.** R1 accepted as defensible; R2
  suggested adding. Decision stands: out of scope. The
  variance table now describes batch support as a real Java
  parity gap rather than just an implementation detail.
- **Typed ``VirtualFields.full_typed()`` accessors** (R2).
  The current implementation returns serialized XML strings
  per fork D1 in the M9 design discussion (deliberate, with
  maintainer sign-off). Tracking as a future ergonomic
  improvement.



### Added (M9 — Video Service writes, Party writes, virtual fields)

- **Video Service write methods** on both :class:`Client` and
  :class:`AsyncClient`: :meth:`create_service`,
  :meth:`modify_service`, :meth:`delete_service`,
  :meth:`alias_service`, :meth:`set_service_parent`,
  :meth:`service_children`. POSTs the bare ``<CreateService>``
  (create) or ``<Service>`` (modify) wrapper element directly
  to ``/service/create/`` or ``/service/modify/``; URL-only
  operations (delete, alias, set_parent) post empty bodies to
  ``/service/{op}/{id}[?target=...]``; ``service_children`` is
  a GET. Wire shapes follow the Java reference SDK
  (``ServiceAdmin.java``).
- **Party write methods** — same shape: :meth:`create_party`,
  :meth:`modify_party`, :meth:`delete_party`,
  :meth:`alias_party`, :meth:`activate_party`,
  :meth:`deactivate_party`, :meth:`change_party_password`.
  **This is a change of direction from earlier milestones**,
  which had documented Party writes as "not planned" per a
  strict reading of REST API §1.1.3 (which lists only
  Resolution and Query as public Party services). The Java
  reference SDK ships full Party admin operations and the
  maintainer wants parity, so M9 ships them parallel to
  Service writes. The new wrapper-element asymmetry
  (``<CreateParty>`` for create, ``<Party>`` for modify) is
  documented in the cover letter and inline in
  :mod:`eidr.client._operations`.
- **Virtual fields retrieval** — :meth:`virtual_fields` on
  both clients, GETs ``/virtual/object/{id}`` and returns a
  new :class:`VirtualFields` value object (frozen dataclass
  with ``id`` / ``full`` / ``self_defined`` / ``alias``
  fields, each carrying serialized record content as an
  optional string). A prior README claim that this endpoint
  was "GET-with-XML-payload" was incorrect — it's a plain
  parameter-less GET, structurally identical to resolve.
- **:class:`VirtualFields` value object** at
  :mod:`eidr.models.virtual`, re-exported from
  :mod:`eidr.models`. Frozen dataclass with
  :meth:`from_codec_dict` constructor handling both scalar
  and list-of-one shapes from the codec layer.

### Changed (M9)

- **Shared-helper consolidation.** Two helpers needed by both
  the sync and async client (``xml_to_record_codec_dict`` for
  parsing inline record bodies from response envelopes, and
  ``embed_party_password`` for splicing a ``<Password>``
  element into a party body for ``create_party``) moved to
  :mod:`eidr.client._shared`. Follows the M7 precedent for
  ``resolve_resource_path``. No public API change.
- **Form-field name** ``/service/create/`` →
  ``serviceCreate`` added to the transport's form-field-name
  map (matches the Java SDK's per-endpoint naming for the few
  routes where the registry expects a specific field name).

### Fixed (M9 — Video Service / virtual fields docstring corrections)

- **Earlier "deferred, not stubbed" comment block** in
  :class:`Client` (and the matching block in :class:`AsyncClient`)
  has been replaced with the actual implementations. The prior
  block claimed Service writes were deferred because their wire
  shape "hadn't been independently verified"; M9 verifies the
  shapes against the Java reference SDK and ships them.
- **README "Not yet implemented" entry** for virtual fields
  retrieval was misleading — claimed it was a "GET with XML
  payload"; it's a plain parameter-less GET. Entry removed
  alongside the M9 implementation.

### Notes (M9 — live testing limitation)

- The development environment Claude was working in is **not
  able to reach EIDR domains** (Anthropic's egress proxy in
  this sandboxed dev environment doesn't have EIDR domains on
  its outbound allowlist; verified via the response header
  ``x-deny-reason: host_not_allowed``). EIDR's actual security
  model is auth-header-based, not IP-based; the SDK's
  ``Authorization: Eidr <UserID>:<PartyID>:<base64(SHA-256(password))>``
  construction matches the Java reference SDK exactly. Net
  effect: live-registry verification of the M9 wire shapes was
  not possible during development. The mock-transport unit
  tests (50 sync+async tests under
  ``tests/test_client_m9_writes.py`` and
  ``tests/test_async_client_m9_writes.py``) lock the wire
  shapes that match the Java reference SDK. Three live
  integration tests in ``tests/test_integration_sandbox.py``
  cover the round-trip:
  - ``TestM9VirtualFields`` — read-only, runs by default
    in the integration lane
  - ``TestM9ServiceRoundTrip`` — opt-in via
    ``EIDR_TEST_SERVICE_WRITES=1`` because state-mutating
  - Party-write integration tests are deliberately omitted
    because the test party is also the auth party — see the
    inline comment for the rationale.
- A standalone test script ``scripts/m9_live_smoke.py`` is
  included for ad-hoc live verification outside the pytest
  harness, with full request/response logging.



### Fixed (M8 review pass)

These changes address feedback from two reviewers on the M8
drop. The reviewers' notes covered different surface areas
(R1 documentation/release-blocker focus, R2 design/performance
focus) and didn't directly conflict. Items deferred carry a
documented rationale.

- **README contradiction resolved.** "Not yet implemented" no
  longer lists the auto-generated Digital sub-model — that's
  M8's headline shipped feature (R1 #1).
- **Stale docstrings corrected** in :class:`ContentRecord` and
  :mod:`eidr.models`. The class docstring for ``ContentRecord``
  used to claim ``validate()`` was a no-op stub planned for M5;
  it now describes the shipped ``validate`` /
  ``validate_strict`` methods plus the ``[digital]`` extra
  pointer to ``ManifestationInfo.digital_typed``.
  ``eidr/models/__init__.py`` no longer claims PartyRecord,
  ServiceRecord, or the typed Digital surface are forthcoming —
  all three ship today (R1 #2).
- **Wrong example in :mod:`eidr.models.digital` module
  docstring** corrected. Was referencing a nonexistent
  ``ContentRecord.technical_info()`` and ``set_technical_info``
  — leftovers from an earlier wire-shape misassumption that
  was corrected later in M8 design but missed by the docstring
  rewrite. Now uses the actual surface:
  ``manifestation.digital_typed()`` and
  ``manifestation.set_digital(...)`` (R1 #3).
- **Wildcard export claim made accurate.** The docstring used
  to imply ``from eidr.models.digital import *`` exposes the
  full 290-class generated tree; ``__all__`` only contained
  curated aliases. Docstring now correctly states wildcard
  imports expose the curated set, with a separate "Internal
  generated module" warning explaining where the full tree
  lives and why it shouldn't be reached into directly (R1 #4).
- **Missing-extra check is comprehensive.** Was checking only
  for :mod:`pydantic`. Renamed to
  :func:`_check_digital_extra_available` and now verifies all
  three runtime deps (``pydantic``, ``xsdata``,
  ``xsdata_pydantic``); the friendly error message names the
  specific missing package. Test parameterized to cover each
  case (R1 #5).
- **Internal/unstable status of ``_digital_generated.py`` is
  now prominent.** Module docstring has a dedicated "Internal
  generated module — DO NOT IMPORT DIRECTLY" section with the
  rationale (mechanical regen output, names not stable across
  versions) and the recommended escalation path (file an
  issue if a missing alias is needed) (R1 #6).
- **Real Manifestation Digital fixture round-trip test.** New
  :class:`TestRealManifestationRoundTrip` class with four tests
  walking the full lifecycle: parse a realistic resolved
  Manifestation XML, read via :meth:`digital_typed`, mutate,
  write via :meth:`set_digital`, serialize the whole record back
  to XML, re-parse. Wire-format guarantee (no ``ns0:`` /
  ``ns1:`` prefix leakage) is locked by explicit assertions on
  both the underlying codec dict and the serialized XML bytes
  (R1 #10).

### Changed (M8 review pass)

- **Namespace prefix normalization in
  :func:`digital_tracks_to_codec_dict`.** xsdata-pydantic's
  serializer auto-generates ``ns0:`` / ``ns1:`` prefixes; the
  resulting codec dict differed from the wire-format dialect
  produced by a fresh :meth:`Client.resolve` (default-namespace
  EIDR + ``md:`` prefix for MovieLabs). New
  ``_normalize_xsdata_prefixes`` helper rewrites
  ``ns0:Foo`` → ``Foo``, ``ns1:Foo`` → ``md:Foo``, and drops
  inline ``_xmlns:nsN`` declarations. Callers inspecting
  ``manifest.digital`` after a ``set_digital()`` now see the
  same dialect as a fresh resolve, eliminating the "two
  shapes" UX papercut (R2 #3).
- **``arbitrary_types_allowed=True`` narrowed.** Previously
  patched on every generated class (290/290). Now patched only
  on classes whose body transitively mentions an xsdata custom
  type (``XmlDuration``, ``XmlDate``, ``XmlDateTime``,
  ``XmlTime``, ``XmlPeriod``, ``QName``) — currently 42/290.
  The other 248 classes keep pydantic's full strict-typing
  benefits. New regression tests verify wrong-type assignment
  is correctly rejected on non-relaxed classes; sanity-check
  tests verify the relaxation is in place where it's needed
  (R1 #7 / R2 #2).

### Added (M8 review pass)

- **Schema provenance manifest.**
  ``src/eidr/schemas/bundled/MANIFEST.json`` records SHA-256
  hashes and byte counts for every bundled XSD plus a
  rolled-up ``manifest_sha256`` summarizing the whole snapshot.
  New :func:`compute_manifest`, :func:`load_manifest`, and
  :func:`manifest_sha256` helpers in
  :mod:`eidr.schemas`. The manifest hash is embedded as a
  comment at the top of :mod:`eidr.models._digital_generated`
  so the generated artifact is mechanically tied to the exact
  schema bytes it was built from. Build tool
  ``tools/write_schema_manifest.py`` regenerates the manifest;
  ``tools/generate_digital.py`` reads it. New
  ``test_generated_module_embeds_correct_hash`` test catches
  drift if XSDs change without regenerating (R1 #9).
- **sdist now includes ``/tools`` and ``/docs``.** Source
  releases are now reproducible — anyone with the sdist can
  regenerate the typed Digital model and audit the
  documentation alongside the source (R1 #8).

### Deferred (with rationale)

- **Memoization of ``digital_typed()``** (R2 #1) — needs
  careful invalidation design. The codec dict is the source of
  truth, so a memoized object would have to clear when the
  dict changes; without a mutation hook on
  ``_BlockView``, that's not safe to add yet. Tracked for a
  future performance milestone.
- **Native dict-to-pydantic mapper** (R2 #4) — the XML
  intermediate adds ~1 short XML parse per
  ``digital_typed()`` call. Negligible compared to a typical
  EIDR network round-trip; a native mapper would be a 10-100x
  speedup for tight-loop bulk processing but adds substantial
  schema-tracking burden. Reviewer 2 explicitly framed this
  as a future performance milestone.
- **SchemaSource URI resolution** (R2 #5) — only matters when
  M9+ adds runtime XSD validation (the current M8
  ``SchemaSource`` Protocol is sufficient for codegen).
  Tracked alongside the M9 runtime-validation work.



### Added (M8 — typed Digital sub-model)

- **Auto-generated typed Digital model** at
  :mod:`eidr.models._digital_generated`. 290 pydantic v2 model
  classes covering the full EIDR namespace (``http://www.eidr.org/schema``)
  and its imports (MovieLabs MD v2.8 ``http://www.movielabs.com/schema/md/v2.8/md``,
  DOI AVS, ISO 3166). Generated by :mod:`xsdata-pydantic` from the
  bundled XSD set; the generated module is checked into the repo
  and ships pre-built in the wheel — end users never run xsdata.
- **Public typed surface** at :mod:`eidr.models.digital` with
  curated short aliases for the headline types:

    * :class:`DigitalTracks` — the contents of a record's
      ``<Digital>`` sub-element (the actual EIDR wire shape;
      ``digitalTracksType`` in the XSD).
    * :class:`Track` — single Track element wrapping one of
      audio/video/subtitle/interactive (``DigitalAssetMetadataType``).
    * :class:`Container` — single Container element
      (``ContainerMetadataType``).
    * Per-asset-data types: :class:`DigitalAssetVideo`,
      :class:`DigitalAssetAudio`, :class:`DigitalAssetSubtitle`,
      :class:`DigitalAssetImage`,
      :class:`DigitalAssetInteractive`,
      :class:`DigitalAssetAncillary`.
    * :class:`DigitalAssetSet` for callers working with raw
      MD-schema content outside the EIDR record path.

  Wildcard import (``from eidr.models.digital import *``)
  exposes the full generated tree under xsdata's PascalCase
  naming (``DigitalAssetAudioDataType``, etc.).

- **Codec-dict ↔ typed bridge** on :class:`ManifestationInfo`:

    * :meth:`digital_typed` — returns a :class:`DigitalTracks`
      view of the Manifestation's ``<Digital>`` sub-block, or
      ``None``. Each call materializes a fresh instance from
      the codec dict; mutations on the returned object don't
      propagate back automatically.
    * :meth:`set_digital` — overwrites the ``<Digital>``
      sub-block from a typed instance. Strict type-check at
      runtime: must be a :class:`DigitalTracks` or ``None``.

  The existing raw-codec-dict :attr:`digital` accessor is kept
  unchanged for backwards compatibility and dedup workflows
  that compare whole-block dicts directly.

- **Schema-source abstraction** at :mod:`eidr.schemas` with three
  exports:

    * :class:`SchemaSource` — Protocol with ``read(name)`` and
      ``list()`` methods. Tests can implement ad-hoc mocks.
    * :class:`BundledSchemaSource` — reads from the in-package
      ``src/eidr/schemas/bundled/`` snapshot via
      :mod:`importlib.resources`.
    * :class:`RemoteSchemaSource` — fetches from
      ``https://www.eidr.org/schema/`` via httpx (requires the
      ``[client]`` extra at use time).
    * :func:`default_schema_source` — returns
      :class:`BundledSchemaSource`. Predictable, offline-friendly,
      deterministic.

  Used by :mod:`tools.generate_digital` at SDK-build time and
  reserved for M9+ runtime XSD validation.

- **Code-generation tooling** at ``tools/generate_digital.py``.
  Maintainer-only; not shipped in the wheel. Runs xsdata against
  the chosen schema source (``--remote`` flag toggles to
  eidr.org), post-processes the output to add
  ``arbitrary_types_allowed=True`` to every ``ConfigDict`` (a
  workaround for a pydantic-v2 / xsdata-pydantic interaction with
  custom :class:`xsdata.models.datatype.XmlDuration` types), and
  writes a single :file:`_digital_generated.py` module with
  ``# ruff: noqa``, ``# mypy: ignore-errors``, ``# fmt: off``
  pragmas so the generated file doesn't fight the gates.

- **``[digital]`` install extra** in ``pyproject.toml``. Pulls
  in :mod:`pydantic` ≥ 2 and :mod:`xsdata-pydantic` ≥ 24. Most
  callers don't need typed access to the Digital sub-tree (they
  treat it as opaque metadata), so the dependency stays opt-in.
  Importing :mod:`eidr.models.digital` without the extra raises
  a clear :class:`ModuleNotFoundError` pointing at the
  remediation.

### Wire-shape findings (M8)

- **Digital lives at ``ManifestationInfo > Digital``, not
  ``record.data["TechnicalInfo"]``.** The ``<Digital>`` element
  is the actual EIDR wire location; ``<TechnicalInfo>`` does not
  exist as a record-level field. Initial M8 design assumed the
  latter and was corrected during scoping. The generated
  ``DigitalAssetSetType`` (with ``audio`` / ``video`` / etc.
  list fields) is a separate MD-schema construct that EIDR does
  not actually wire up at the record level — EIDR uses the
  ``digitalTracksType`` (Track / Container choice) wrapper
  instead.
- **xsdata-pydantic + pydantic v2 require a post-process step.**
  The generator emits ``model_config = ConfigDict(defer_build=True)``
  on each class but does not add ``arbitrary_types_allowed=True``.
  Without the latter, direct construction (rather than
  parser-driven instantiation) raises
  ``PydanticSchemaGenerationError`` on the xsdata custom types
  (:class:`XmlDuration`, etc.). The codegen tool patches this
  with a single string-replace post-process step.
- **Wrapper-element XML serialization needs explicit namespace
  declarations.** When :func:`codec_dict_to_digital_tracks` wraps
  a Digital block dict in a ``<Digital>`` element, it injects
  ``xmlns`` (EIDR) and ``xmlns:md`` (MovieLabs) declarations on
  the wrapper to handle inherited prefix references inside the
  body. Without them, lxml fails ``etree.Element`` construction
  with ``Invalid tag name 'md:Audio'``.



### Fixed (M7 review pass)

These changes address feedback from two reviewers on the initial
M7 drop. The two reviewers' notes overlapped substantially on the
priority items; differences were reconciled in favor of the
stronger fix where they disagreed.

- **Stale documentation corrected.** Module docstrings in
  ``src/eidr/client/_client.py`` and ``src/eidr/client/__init__.py``
  no longer claim AsyncClient is "deferred" or "planned but not yet
  shipped" — they now describe AsyncClient as parallel to Client
  with identical operation surface. Both reviewers flagged this.
- **Async ``Token.result()`` parity with sync.** The sync
  :meth:`Token.result` raises :class:`EIDRProtocolError` on terminal
  failure; the async :meth:`AsyncToken.result` previously did not.
  Now does, with the same error-message shape ("AsyncToken {value!r}
  resolved to FAILURE: {reason}"). The parity contract — equivalent
  method names have equivalent semantics — is locked by a new test
  class ``TestAsyncTokenResultFailureParity``.
- **Relationship XML fragments are parsed and re-serialized,
  not embedded verbatim.** ``_check_info_tag`` (validation only)
  was renamed to ``_validate_and_reserialize_info`` and now returns
  the ``etree.tostring()`` of the parsed root. Both
  :func:`build_add_relationship` and :func:`build_replace_relationship`
  embed the re-serialized fragment instead of the caller's original
  string. Trailing comments before the root, ``<?xml ?>``
  declarations, processing instructions, and other lexical oddities
  in caller-supplied fragments are dropped at validation time
  rather than passed through into the request envelope.
- **Async ``aclose()`` is idempotent.** ``AsyncClient.aclose()``
  and ``_AsyncTransport.aclose()`` previously raised on a second
  call (reviewer flag: "lifecycle methods should be safe to call
  more than once"). Now the second call is a no-op, matching the
  contract on sync :meth:`Client.close`. ``_AsyncTransport`` carries
  a ``_closed`` flag set on first close.

### Changed (M7 review pass)

- **``TransportConfig.httpx_transport`` split into two fields.**
  Previously a single field accepted either a sync or async
  transport via type widening + ``cast()``. Static type checkers
  couldn't catch a sync-only transport accidentally passed to
  :class:`AsyncClient`. The field is now sync-only
  (:class:`httpx.BaseTransport | None`); a new
  :attr:`async_httpx_transport` field carries the async transport
  (:class:`httpx.AsyncBaseTransport | None`). Wrong assignments are
  now static-type errors at the call site under ``mypy --strict``.
  The runtime validators (:func:`_validate_sync_transport`,
  :func:`_validate_async_transport`) are kept as belt-and-suspenders
  for untyped-code paths (dynamic plugin loading, JSON-config-driven
  transports, etc.). All ``cast()`` calls in the transport modules
  removed; ``cast`` import dropped from both ``_http.py`` and
  ``_async_http.py``. Test fixtures using ``MockTransport`` flipped
  to use the appropriate field per client type. **Breaking change**
  for callers relying on the previous union type — fix is
  mechanical (rename ``httpx_transport=`` to ``async_httpx_transport=``
  in async test fixtures).
- **Validation pipeline connected to writes.** :meth:`Client.register`,
  :meth:`Client.match`, :meth:`Client.modify` and their AsyncClient
  counterparts now accept three opt-in keyword flags:
  ``validate: bool = False``, ``normalize: bool = False``,
  ``strip_empty: bool = False``. When any is set, the helper
  :func:`_apply_pre_submission_pipeline` applies the corresponding
  transform in fixed order (normalize → strip_empty → validate)
  to a copy of the record (caller's record is not mutated). Default
  ``False`` for all three avoids silent transformation of caller
  data; reviewers' feedback was unanimous that the SDK should
  surface these capabilities but not invoke them silently. Submission
  mode is wired correctly (``"create"`` for register, ``"modify"``
  for modify, ``None`` for match).
- **Cross-client helpers moved to ``_shared.py``.**
  ``resolve_resource_path`` (formerly ``_resolve_resource_path``,
  duplicated in both client modules) lives in a new
  ``src/eidr/client/_shared.py`` module with a contract docstring
  ("stateless free functions only"). Both clients import it from
  there; no duplicated copies remain.
- **``EIDRUncertainWriteError`` docstring expanded** with the
  recommended reconciliation pattern: resolve the target record
  after the timeout, compare against intended state, decide whether
  to retry, treat-as-success, or escalate. Documents *why* the SDK
  does not auto-retry idempotent writes (``modify`` retry returns
  duplicate-metadata, ``delete`` retry returns not-found,
  ``register`` retry typically duplicates) — auto-retry would
  obscure these distinct success-then-retry outcomes.
- **``match()`` docstring** clarifies that the returned record is
  the registry's dedupe candidate, not the caller's submission;
  ``.id`` is the matched record's ID, not a newly-assigned one.
  Avoids the ``ContentRecord | Token`` return type confusion
  flagged by reviewers without introducing a dedicated
  ``MatchResult`` type.

### Added (M7 review pass)

- **Live-registry integration test lane** at
  ``tests/test_integration_sandbox.py``. Marked
  ``@pytest.mark.integration``; **skipped by default** via
  ``addopts = ["-m", "not integration"]`` in
  ``[tool.pytest.ini_options]``. Five tests covering anonymous
  resolve (against ``RESOLVE``, no creds), authenticated resolve
  (against ``SANDBOX2``), status_lookup with synthetic token
  (verifies error-mapping path), non-destructive Match against a
  resolved record, and ID-only query. Credentials picked up from
  ``EIDR_TEST_USER_ID`` / ``EIDR_TEST_PARTY_ID`` /
  ``EIDR_TEST_PASSWORD`` env vars; tests skip with a clear reason
  if any is missing. Run with ``pytest -m integration``.
- **New unit-test classes** for the items above:
  ``TestAsyncTokenResultFailureParity`` (2 tests),
  ``TestSyncTransportMismatch`` / ``TestAsyncTransportMismatch`` /
  ``TestMockTransportPassesEither`` (7 tests across the new
  ``test_client_transport_validation.py``),
  ``TestAsyncCloseIdempotence`` (3 tests). Test count: 866 → 878.



### Added (M7 — async client)

- :class:`eidr.AsyncClient` — async counterpart to :class:`Client`.
  Every public method is ``async def`` with the same signature as its
  sync sibling: ``resolve``, ``query``, ``graph_traversal``,
  ``party_query``, ``service_query``, ``status_lookup``, ``register``,
  ``match``, ``modify``, ``delete``, ``promote``, ``alias``,
  ``add_relationship``, ``remove_relationship``,
  ``replace_relationship``. Built on :class:`httpx.AsyncClient`;
  used with ``async with``. The envelope builder, operation
  builders, response parser, query-results parser, codec layer,
  and record models are shared verbatim with :class:`Client` — the
  async/sync distinction is isolated to the transport and
  client-façade layers.
- :class:`eidr.AsyncToken` — awaitable handle for in-flight async
  EIDR writes. Same field shape as :class:`Token` (``value``,
  ``status``, ``last_response``, ``_client``), but ``poll()``,
  ``wait()``, ``result()``, and ``operation_result()`` are
  coroutines. Uses :func:`asyncio.sleep` for backoff so the task
  yields to the event loop during waits; cancellation
  (:class:`asyncio.CancelledError`) propagates cleanly with
  last-poll state preserved.
- :meth:`Token.to_async(async_client)` — converts a sync
  :class:`Token` to an :class:`AsyncToken` without re-issuing the
  write. Intended for the sync-under-load fallback case (REST API
  §2.1.1 — a sync Create/Modify deflected to async because dedupe
  couldn't complete within the immediate-response window) when
  running from async code. The reverse conversion is deliberately
  not offered: async→sync implies ``asyncio.run()`` from within
  sync code, which is almost always a mistake elsewhere.
- Top-level re-exports expanded: ``AsyncClient``, ``AsyncToken``,
  ``DedupeMode``, ``GraphTraversalType``, ``RelationshipType``,
  ``OperationResult``, ``QueryResults``, ``TraceRecord``,
  ``TraceSink``, ``LoggerSink``, ``FileSink``, ``ListSink`` are all
  lazily importable from ``eidr``. The underlying ``httpx`` import
  is still deferred — base-SDK users who only need codec workflows
  don't pay for it.

### Changed (M7)

- :class:`Client.register` and :class:`Client.modify` docstrings
  now explicitly document the sync-under-load fallback case (REST
  API §2.1.1): an ``immediate=True`` call can legally return a
  :class:`Token` if the registry deflects to async processing
  under load. Callers must handle both return types. The
  sync-under-load fallback does not apply to :meth:`Client.match`
  per the same reference.
- :class:`TransportConfig.httpx_transport` type widened to
  ``httpx.BaseTransport | httpx.AsyncBaseTransport | None`` so a
  single :class:`TransportConfig` can configure either transport.
  The test suite's usual :class:`httpx.MockTransport` implements
  both protocols, so no caller-side change is needed. Runtime
  usage casts to the appropriate protocol with an explanatory
  comment at each call site.

### Infrastructure (M7)

- Added ``pytest-asyncio>=0.23`` to the ``[dev]`` extra.
  Configured ``asyncio_mode = "auto"`` in
  ``[tool.pytest.ini_options]`` so ``async def test_*`` functions
  run without needing ``@pytest.mark.asyncio`` decorators. Matches
  the convention used by httpx, anyio, and other async-first
  libraries.
- Async test coverage: four new test files totaling 63 tests
  (``test_async_client_resolve.py``, ``test_async_client_writes.py``,
  ``test_async_client_queries.py``, ``test_async_client_token.py``),
  paralleling the sync test structure. Includes coverage for
  cancellation propagation, the sync-under-load fallback path,
  ``Token.to_async`` conversion (value / last_response / status
  preservation and non-destructive semantics), and the
  readonly-registry-allowed-for-queries case. Full suite now 858
  tests.



### Fixed (M6 review pass)

These changes address issues raised in review of the initial M6 drop.
None changes the public surface in a breaking way; in two places the
public surface is *cleaner* than it was (see Changed below).

- **Resolve-response parsing now accepts the actual XML root names.**
  The first M6 drop's ``_RESOLVE_ROOTS`` listed ``SelfDefined`` and
  ``Provenance`` — names that match the ``type=`` URL parameter, not
  the wire-format element names. The registry actually emits
  ``<SelfDefinedMetadata>``, ``<ProvenanceMetadata>``, and
  ``<InheritedMetadata>``. ``client.resolve(..., resolution_type="Self")``
  and provenance/inherited resolves now succeed instead of raising
  ``EIDRProtocolError`` from the response layer. The same root-name
  fix was applied to ``_record_to_creation_inner()`` so Modify and
  Register accept records resolved with non-Full types.
- **Status-code mapping rewritten.** The per-response code-to-exception
  map in ``_response.py`` was replaced with a route through
  :func:`eidr.errors._status_to_exception`, which dispatches on the
  ``<Status><Type>`` string with the integer code as fallback. EIDR's
  REST API Reference Tables 5 and 6 use overlapping integer codes
  with different meanings (e.g., code 5 in Table 5 is "authorization
  error", not "not found"), so type-string dispatch is more correct.
  ``EIDRValidationError.__init__`` was extended to accept the same
  ``code/type/details/response`` kwargs as its parent so the dispatch
  works uniformly. Type-string keyword set extended to recognize
  "bad id error" (Table 5 code 8 → :class:`EIDRNotFoundError`) and
  "syntax error" (Table 5 code 9 → :class:`EIDRValidationError`).
- **``<Status><Details>`` is now extracted.** The registry's
  ``<Details>`` element carries the actionable diagnostic
  (e.g., *"Referent Type must be one of 'TV', 'Movie', 'Short',
  'Web'"*). Previously ignored; now exposed on the raised
  exception's ``details`` attribute and folded into the exception's
  message for triage.
- **Read-only registry guard no longer blocks queries.** The
  transport's ``post()`` previously raised ``EIDRReadOnlyRegistryError``
  on any POST against a read-only registry, which incorrectly blocked
  ``query()``, ``graph_traversal()``, ``party_query()``, and
  ``service_query()`` — operations that semantically read but use
  POST because they carry an XML body. ``post()`` now takes a
  ``requires_writable`` kwarg (default ``True`` for safety); the four
  query methods pass ``False``.
- **Relationship info-XML validation is now a real parse.**
  ``_check_info_tag`` previously did a string prefix check on the
  caller-supplied info XML, which would let malformed XML through
  into the request envelope. It now parses with ``lxml``, verifies
  well-formedness, and checks the root local name and namespace
  (accepts EIDR namespace or no namespace; rejects others).
- **``Client.resolve()`` URL construction uses ``httpx`` ``params=``.**
  Previously query parameters were hand-joined with ``?`` and ``&``
  and interpolated into the path. Now they go through httpx's URL
  encoding so values with reserved characters are escaped correctly.

### Added (M6 review pass)

- **Trace body size limits and redaction.**
  :class:`~eidr.client._http.TransportConfig` gains
  ``trace_max_body_chars`` (default 100,000 — generous, but bounded
  against worst-case bulk responses) and ``trace_redact_bodies``
  (default ``False``; when ``True``, request and response bodies are
  replaced entirely with a ``[REDACTED N chars]`` marker). Headers
  are still redacted regardless. Intended for "safe support bundle"
  workflows where traces are shared with parties who shouldn't see
  unpublished record content.
- :class:`eidr.client.OperationResult` — uniform structured view of
  a write-operation outcome, regardless of whether the registry
  echoed a record (sync register/modify), returned IDs (status
  lookup), or only an envelope (delete/promote/alias). Carries
  ``status``, ``ids``, ``record``, ``sub_tokens``, ``raw_response``,
  plus an ``.id`` convenience property for single-operation cases.
  Constructed via :func:`eidr.client._operation_result.operation_result_from`
  or returned by :meth:`Token.operation_result`.
- :meth:`Token.operation_result(timeout=...)` — polls the token,
  returns an :class:`OperationResult`. On timeout with at least one
  poll completed, returns a ``PENDING`` result (rather than raising)
  so callers can inspect the partial state and resume.

### Changed (M6 review pass)

- :meth:`Client.register` no longer accepts a ``match_only=`` kwarg.
  The shared logic was hoisted into a private ``_create_or_match``;
  :meth:`Client.match` calls it directly. Cleaner public surface;
  no behavior change for callers using either method as documented.
- :class:`eidr.client.QueryResults` carries ``page_number`` and
  ``page_size``, and :attr:`QueryResults.has_more_pages` now computes
  ``page_number * page_size < total_matches`` rather than
  ``current_size < total_matches``. The old heuristic returned
  ``True`` on the last partial page (e.g., page 4 of 25 with
  ``current_size=10`` and ``total_matches=85``); the corrected
  computation returns ``False`` correctly. ``parse_query_results``
  now accepts ``page_number`` and ``page_size`` kwargs;
  :meth:`Client.query` passes them through.
- :class:`EIDRValidationError` constructor signature aligned with
  :class:`EIDRProtocolError` (accepts ``code/type/details/response``
  kwargs). Local validator code that constructed
  ``EIDRValidationError(*args)`` continues to work unchanged.

### Added

#### HTTP client, writes, and queries (M6)

- ``eidr.Client`` — the connected client. Wraps transport, authentication,
  retry policy, and response parsing in a single façade. Supports context
  management (``with Client(...) as c:``) for deterministic cleanup.
  Constructor takes a :class:`~eidr.registries.Registry`, a
  :class:`~eidr.credentials.Credentials`, optional
  :class:`~eidr.client._http.TransportConfig`, and optional tracing
  configuration.

- ``Client.resolve(eidr_id, *, resolution_type="Full", follow_alias=True)``
  — resolves Content, Party, and Video Service IDs. Dispatches to the
  right registry endpoint based on the ID prefix.
  Returns a :class:`~eidr.models.content.ContentRecord`,
  :class:`~eidr.models.party.PartyRecord`, or
  :class:`~eidr.models.service.ServiceRecord`.

- :class:`eidr.Token` + :class:`eidr.TokenStatus` — EIDR async-write
  tokens. ``Token.poll()`` runs one status-lookup round-trip;
  ``Token.wait(timeout=...)`` polls with exponential backoff until the
  token resolves or the deadline is hit. Unknown registry status codes
  are treated as ``PENDING`` (not ``FAILURE``) to avoid false negatives
  when EIDR adds new codes in minor releases. Tokens can be serialized
  via ``.value`` and rebound to a client later for resumable polling.

- ``Client.status_lookup(token)`` — low-level access to the token
  status endpoint; returns the parsed response for callers who want to
  inspect per-operation status details in batch drill-downs.

- **Tracing facility** (M6.1.5) —
  :class:`eidr.TraceSink` protocol with three built-in implementations:
  :class:`eidr.LoggerSink` (default when ``tracing=True``),
  :class:`eidr.FileSink`, :class:`eidr.ListSink`. Every HTTP attempt
  emits a :class:`eidr.TraceRecord` with method, URL, attempt number,
  request/response headers, request/response bodies, and exception (if
  any). Sensitive headers (``Authorization``, ``Proxy-Authorization``,
  ``Cookie``, ``Set-Cookie``) are redacted at capture time,
  case-insensitively. Sink exceptions are swallowed so a broken sink
  never breaks the API call. Tracing is off by default; no overhead
  when unused.

- **Nine write methods** on ``Client``:

  - ``register(record, *, immediate=False, dedupe_mode=None,
    match_only=False, wait_timeout=None)`` — register a new Content
    record. Determines CreationType from the record, builds the
    correct ``<Create type="...">`` wrapper, submits to ``/register/``.
  - ``match(record)`` — convenience shorthand for
    ``register(..., match_only=True)``, which posts to ``/match/``.
  - ``modify(record, *, immediate=False, dedupe_mode=None,
    wait_timeout=None)`` — modify an existing record. Requires
    ``record.id`` to be set.
  - ``delete(eidr_id, *, immediate=False, wait_timeout=None)`` —
    alias-to-tombstone. Returns ``None`` on immediate success.
  - ``promote(eidr_id, *, immediate=False, wait_timeout=None)`` —
    promote an InDev record to Valid status.
  - ``alias(source_id, target_id, *, immediate=False, wait_timeout=None)``
    — alias one record to another.
  - ``add_relationship(source_id, relationship_type, info_xml, *,
    immediate=False, wait_timeout=None)`` — add a lightweight
    relationship.
  - ``remove_relationship(source_id, relationship_type, *, ...)``.
  - ``replace_relationship(source_id, relationship_type, info_xml, *,
    ...)``.

  All nine support ``immediate=True`` (synchronous) or ``immediate=False``
  (returns a :class:`Token`); the async path also accepts
  ``wait_timeout=float`` to poll up to the given deadline and return
  the completed record (or the still-pending token if the deadline
  expires).

- :class:`eidr.DedupeMode` with four values per REST API Reference §2.1.4:
  ``NORMAL``, ``MANUAL``, ``ACCEPT``, ``REVIEW``. ``ACCEPT`` and
  ``REVIEW`` are Superparty-restricted; the registry returns an error
  for any other caller. Applies only to async Create and Modify.

- :class:`eidr.RelationshipType` enum covering the six lightweight
  relationship types: ``COMPOSITE``, ``LANGUAGE``, ``PACKAGING``,
  ``ADJUNCT``, ``PROMOTIONAL``, ``ALTERNATE_CONTENT``. Values match
  the registry wire strings (``CompositeRelationship``, etc.).

- **Four query methods** on ``Client``:

  - ``query(expression, *, page_number=1, page_size=25, id_only=False)``
    — content-registry queries, paginated. Returns a
    :class:`~eidr.client.QueryResults`. Adds ``?type=ID`` to the URL
    for ``id_only=True``.
  - ``graph_traversal(operation, eidr_id, *, referent_type_filter=None,
    structural_type_filter=None, relationship_type_filter=None)`` —
    walks the EIDR graph. Supports all nine traversal operations
    enumerated in :class:`eidr.GraphTraversalType`.
  - ``party_query(query_xml)`` — POSTs a raw query body to
    ``/party/query/`` (no ``<Request><Operation>`` wrapper, per REST
    API Reference §2.3.15).
  - ``service_query(query_xml)`` — same for ``/service/query/``.

- :class:`eidr.client.QueryResults` — frozen dataclass with
  ``current_size``, ``total_matches``, optional ``continuation_token``,
  ``records`` (for full-metadata queries), ``ids`` (for ID-only queries),
  plus a ``has_more_pages`` convenience property.

- :class:`eidr.GraphTraversalType` enum with nine values matching the
  registry wire-format element names: ``FIND_ANCESTORS``,
  ``FIND_DESCENDANTS``, ``GET_DEPENDENTS``, ``GET_SERIES_ANCESTRY``,
  ``GET_LIGHTWEIGHT_RELATIONSHIPS``, ``GET_REMOTEST_ANCESTOR``,
  ``GET_LEAF_DESCENDANTS``, ``GET_PARENT``, ``GET_CHILDREN``.

### Changed

- :meth:`~eidr.models.content.ContentRecord.from_xml` now accepts
  ``<SimpleMetadata>`` records (produced by query results) in addition
  to ``<FullMetadata>`` and ``<SelfDefined>``. The ``.base`` accessor
  falls back to the record's root dict when no ``<BaseObjectData>``
  child is present, so ``.id``, ``.resource_name``, ``.referent_type``,
  etc. work uniformly across all three record shapes. Query-result
  SimpleMetadata records now flow through the same ``ContentRecord``
  API as full-metadata records.

### Deferred (scoped, justified)

- **Video Service writes** (registration, modification) — endpoints
  exist per REST API Reference §2.3.12–§2.3.13 but the wire shape
  hasn't been verified against a live sandbox. Explicit deferral
  comment block in ``_client.py``; to land in a follow-up milestone
  alongside verified sandbox round-trips.
- **Party writes** — the public REST API does not expose Party
  create/modify/delete (REST API Reference §1.1.3 lists only
  Resolution and Query). Party record creation is handled internally
  by EIDR Operations.
- **AsyncClient** — deferred to M7 to keep the sync API stable first.
- **Virtual-fields retrieval** — uncommon, uses GET-with-XML-payload
  which doesn't fit the current transport cleanly.

#### Write-side validation (M5)

- :class:`eidr.models.ValidationReport` and
  :class:`eidr.models.ValidationError` — pre-submission validation
  infrastructure. Reports accumulate errors rather than raising on the
  first, so callers see the full picture in a single pass. Codes are
  dotted and hierarchical (e.g. ``content.required_field.missing``,
  ``content.vocabulary.invalid``, ``service.cardinality.exceeded``);
  each error carries a path, human-readable message, and optional
  offending value.

- ``ContentRecord.validate(*, require_id=False, max_errors=50)`` — no
  longer raises :class:`NotImplementedError`. Now runs a full pass over
  BaseObjectData required fields, controlled-vocabulary checks
  (``ReferentType``, ``Mode``, ``Status``, ``StructuralType``), the
  EIDR-profile credit bounds (≤2 Directors, ≤4 Actors), CreationType
  consistency (at most one mutually-exclusive block),
  CompositeInfo-only-with-Basic-or-Episode, per-CreationType required
  fields (e.g. ``EpisodeInfo`` requires ``Parent``), and the empty-tag
  rule. ``PartyRecord`` and ``ServiceRecord`` gain parallel
  ``validate()`` methods covering their respective rule sets.

- ``validate_strict()`` on all three record classes — raises
  :class:`~eidr.errors.EIDRValidationError` on any error. The raised
  exception carries the full error list on its ``errors`` attribute.

- :func:`eidr.models.strip_empty_tags` — recursively remove empty tags
  from a codec dict in place. The registry rejects any element with no
  text, no attributes, and no children as a schema-validation error,
  so pre-submission stripping is required for records built
  programmatically. Recursive up-propagation: a parent that becomes
  empty after its children are stripped is itself stripped. An element
  with only namespace declarations is considered empty; an element
  with a non-namespace attribute is NOT empty, since the attribute
  carries content.

- :func:`eidr.models.find_empty_tags` — non-mutating reporter that
  returns XPath-like paths of every empty tag. Used by the validators
  (as the ``*.empty_tag.forbidden`` rule) and by callers who want to
  audit a record without mutating it.

- :func:`eidr.models.normalize_whitespace` — pre-submission helper
  that mirrors the registry's own text normalization. Text content
  gets xs:string treatment (leading/trailing strip, collapse runs of
  internal whitespace to a single space); attribute values get
  xs:token treatment (leading/trailing strip only, internal
  whitespace preserved). Intended to compose with
  :func:`strip_empty_tags` — normalize first so that whitespace-only
  fields become empty and can then be stripped.

- ``max_errors`` parameter on :class:`ValidationReport` and all
  :meth:`validate` / :meth:`validate_strict` methods, defaulting to
  ``50``. When the cap is reached, a sentinel error with code
  ``validation.truncated`` is appended. This matters because a
  pathologically broken record (e.g., the wrong format handed to
  ``from_xml``) could otherwise produce thousands of errors; the cap
  keeps output manageable without hiding the first useful ones.
  Callers who want every error can pass a high cap; callers who want
  the registry's own fail-fast behavior can pass ``max_errors=1``.

- New tests covering the full M5 surface: ``test_content_validation.py``
  (33 tests), ``test_party_service_validation.py`` (27 tests),
  ``test_empty_tags.py`` (22 tests), ``test_normalize_and_caps.py``
  (26 tests) — 108 validation-focused tests in total.

### Changed

- :class:`~eidr.errors.EIDRValidationError` now carries an ``errors``
  attribute (a list of :class:`ValidationError`) populated by
  :meth:`ValidationReport.raise_if_errors`. Docstring updated to
  describe both pre-submission (local validator) and post-registry
  rejection contexts.

#### Party and Service record wrappers (M4)

- :class:`eidr.models.party.PartyRecord` — wrapper for EIDR Party-ID
  records. Thin typed façade over the :data:`CodecDict` with the full
  set of Party accessors:

  - ``id``, ``party_name`` (:class:`OrgName`), ``alternate_party_names``
  - ``contact_info`` (:class:`ContactInfo`), ``active``,
    ``party_account_name``, ``allowed_roles``

- :class:`eidr.models.service.ServiceRecord` — wrapper for EIDR
  Service-ID records. Similar shape to ``PartyRecord`` but richer per
  the service schema:

  - ``id``, ``service_name``, ``service_name_is_abbreviation``,
    ``alternate_service_names``, ``alternate_ids``, ``description``
  - ``parent`` (EIDR ID of a parent service, when this is a sub-service
    like HBO Max → HBO), ``other_affiliations``, ``active``
  - ``primary_time_zone``, ``region``, ``primary_audio_language``,
    ``delivery_models``

- :class:`eidr.models.OrgName` — shared value object for the MovieLabs
  ``md:OrgName-type`` shape. Used as ``PartyName``, ``ServiceName``,
  and (already) as the name inside :class:`AssociatedOrg`. Carries
  display name, sort name, alternate names, and the ``organizationID``
  / ``idType`` / ``departmentID`` attributes.

- :class:`eidr.models.ContactInfo` and :class:`eidr.models.Phone` —
  value objects for the MovieLabs ``md:ContactInfo-type``. ``Phone``
  models the single ``Phone`` element with its ``@type`` attribute.

- :func:`eidr.models.parse` — root-element-driven dispatcher that
  returns the appropriate wrapper (:class:`ContentRecord`,
  :class:`PartyRecord`, :class:`ServiceRecord`, or
  :class:`AliasContinuation`) based on the root element of an XML
  document. Useful in code paths that don't know the response shape in
  advance. Also exported at the top level as :func:`eidr.parse`.
  :func:`eidr.models.parse_codec_dict` offers the same dispatch over an
  already-parsed codec dict.

- Tests: ``test_party_record.py`` (18 tests, round-trip + every
  accessor), ``test_service_record.py`` (15 tests, same coverage for
  Service including abbreviation flag and parent hierarchy), and
  ``test_parse_dispatch.py`` (13 tests, every root element including
  all three alias-continuation variants).

### Changed

- **Canonical JSON is now strictly RFC 8785 JCS** via the ``rfc8785``
  library (Trail of Bits, Apache 2.0, pure Python). The previous
  stdlib-``json``-based approximation is removed. ``rfc8785`` is a
  hard runtime dependency — the library is deliberately "one
  canonicalization, one implementation" rather than offering a
  partial-conformance fallback.
- Added :func:`eidr.codecs.json.to_canonical_bytes` returning the
  canonical JSON as ``bytes`` (the form RFC 8785 is defined over and
  the form JAdES/signing tools consume).
- **Canonical XML standardized on W3C Canonical XML 2.0** via lxml's
  native support. The method parameter default changed from
  ``"c14n11"`` to ``"c14n2"``; ``"c14n11"`` is retained as a
  deprecated alias. Documentation no longer describes this as
  approximating C14N 1.1 — the implementation *is* C14N 2.0, the
  recommended successor to 1.1, and the library commits to that.
- :meth:`ContentRecord.validate` now raises
  :class:`NotImplementedError` instead of silently returning ``None``.
  Write-side validation is an M5 milestone; a silent no-op was a
  footgun in the meantime.
- Top-level :mod:`eidr` docstring rewritten to describe only what is
  actually exported. Previous drafts referenced a not-yet-implemented
  ``Client``/``AsyncClient`` and "pydantic-based record types"; those
  references are removed.

### Added

- :class:`eidr.models.AliasContinuation` — value object representing
  an alias-continuation record (a resolved record that points at a
  replacement). Parseable directly from an ``<AliasContinuation>``
  root element (via :meth:`~eidr.models.AliasContinuation.from_xml`)
  or detected on a ``ContentRecord`` via the new
  :attr:`ContentRecord.alias_continuation` accessor. Aliased records
  are explicitly NOT an error condition — callers with auto-follow
  disabled will receive them routinely and should inspect
  ``alias_continuation`` to decide how to proceed.
- ``tests/test_cardinality_contexts.py`` — regression fixtures for
  every known context-ambiguous qualified name, locking in the
  record-level vs transport-level interpretation. Named examples:
  ``ID``, ``Status``, ``ReferentType``, ``StructuralType``, ``Token``,
  ``UserID``, ``Party``, ``Service``, ``Mode``, ``ResourceName``.
  A future schema change or harvester refactor that silently flips
  any of these will fire the tests rather than leaking bad output.

### Dependencies

- **Removed** ``pydantic`` from hard runtime dependencies. Never used
  by the current implementation; was a leftover from an earlier design
  that planned xsdata-pydantic-generated models.
- **Moved** ``httpx`` from hard dep to the ``[client]`` optional extra.
  Reserved for the M6 milestone (HTTP client layer).
- **Added** ``rfc8785>=0.1`` as a hard dep — the canonical JSON
  implementation.
- **Removed** the ``canonical-json`` and ``validation`` optional
  extras. ``canonical-json`` is no longer optional (now part of core);
  ``validation`` was a placeholder with no contents.
- **Added** ``python-stdnum`` to the ``[dev]`` extra to support the
  ISO 7064 Mod 37,36 cross-validation tests (previously declared
  only via ``pytest.importorskip``).

#### Typed model layer (`eidr.models`)

- `ContentRecord` — ergonomic, typed façade over a `CodecDict` for EIDR
  Content-ID records. Preserves the dict as the source of truth so
  round-trips through XML and JSON remain lossless while offering
  ~30 typed accessors for the fields that matter in practice:
  - `id`, `structural_type`, `mode`, `referent_type`, `status`,
    `resource_name`, `release_date`, `country_of_origin`,
    `original_languages`, `version_languages`, `description`,
    `approximate_length`, `registrant`, `metadata_authorities`
  - `alternate_ids`, `alternate_resource_names`, `associated_orgs`,
    `directors`, `actors`
  - `creation_type` — computed from which ExtraObjectMetadata block is
    present; the seven mutually-exclusive CreationType-bearing blocks
    (SeriesInfo, SeasonInfo, EpisodeInfo, EditInfo, ClipInfo,
    ManifestationInfo, CompilationInfo) define the value; CompositeInfo
    and the lightweight-relationship blocks do NOT affect the Basic
    determination.
  - `creation_block` — the typed block view (SeriesInfo, EpisodeInfo,
    etc.) corresponding to `creation_type`; `None` for Basic records.
  - `composite_info` — separate accessor because CompositeInfo can
    co-occur with a Basic *or* an Episode record.
  - `supplemental_content_infos`, `promotion_infos`,
    `alternate_content_infos`, `packaging_infos` — the lightweight
    relationships; always lists (any combination allowed per record).
  - `ManifestationInfo.digital` — raw codec-dict access to the
    DigitalAssetMetadata sub-tree (auto-generated bindings deferred).
- `from_xml()`, `from_json()`, `from_codec_dict()` for construction.
- `to_xml()`, `to_xml_canonical()`, `to_json()`, `to_json_canonical()`
  for output, delegating to the codec layer so all canonicalization
  guarantees apply.
- Value-object types (frozen dataclasses with `from_codec` /
  `to_codec`): `AlternateID`, `AlternateResourceName`, `AssociatedOrg`,
  `Credit`, `Parent`.
- Controlled-vocabulary enums (all `StrEnum`): `CreationType`,
  `ReferentType`, `StructuralType`, `Mode`, `Status`.
- Read-side is permissive — trusts whatever the registry returns.
  Pre-submission validation of CreationType/block consistency, required
  fields, and controlled vocabularies is reserved for a future
  milestone (`ContentRecord.validate()` is currently a no-op stub).

#### Bundled schema artifacts (`eidr.schemas.bundled`)

- All 15 EIDR XSD files bundled under `src/eidr/schemas/bundled/` —
  EIDR schema, MovieLabs MD v2.8, DOI, ISO 3166-A2.
- `conversion_table.json` — machine-readable artifact derived from the
  XML→JSON Conversion Table; 271 paths (139 data-bearing after
  Full/Self-Defined dedup).
- `tools/harvest_cardinality.py` — regenerates the multi-element
  cardinality maps from the bundled XSDs.
- `tools/build_conversion_table.py` — regenerates the Conversion Table
  JSON from the source XLSX.

#### Cardinality data (upgrade)

- Replaced the 18-element corpus-observed heuristic with an
  authoritative XSD-derived map.
- `EIDR_MULTI_QUALIFIED` — frozenset of `(namespace, localname)` tuples
  (147 entries across EIDR, MD v2.8, and DOI namespaces).
- `EIDR_MULTI_LOCAL` — namespace-agnostic fallback (140 distinct
  local names).
- `EIDR_MULTI_ELEMENTS` retained as a backward-compatible alias.
- Harvester distinguishes record-level contexts from transport-wrapper
  contexts (`requestType`, `queryResultsType`, etc.) to avoid falsely
  flagging singleton record fields like `ID` or `Status` as multi.
- XML codec now consults `EIDR_MULTI_QUALIFIED` first via threaded
  Clark-notation tags, so a single `md:Track` element correctly emits
  as a JSON array.

### Fixed

- XML codec no longer applies the default namespace to unprefixed
  attributes. Per XML namespace rules, unprefixed attributes are
  always in no namespace (and most schemas set
  `attributeFormDefault="unqualified"` accordingly). Previously,
  round-trip serialization would rewrite unprefixed attributes like
  `relation="IsSameAs"` into qualified form, introducing spurious
  `ns0:` prefix bindings.

#### Codec layer (`eidr.codecs`)

- `eidr.codecs.xml` — XML ↔ `CodecDict` conversion.
  - `to_codec_dict(source, *, multi_elements=None, use_bundled_hints=True)` —
    parse XML (bytes, text, or lxml Element) into the intermediate dict
    representation. Supports explicit cardinality hints, the bundled
    EIDR hint set, and an observed-cardinality fallback (with
    `CardinalityHeuristicWarning`).
  - `to_xml(codec_dict, ...)` — serialize to XML bytes (infoset-level
    round trip).
  - `to_xml_canonical(codec_dict, method="c14n11")` — byte-stable
    canonical output via W3C C14N 1.1 / C14N2, suitable for
    cryptographic signing (XAdES-B-T).
- `eidr.codecs.json` — JSON ↔ `CodecDict` conversion per the MovieLabs
  MDDF JSON Encoding Best Practice.
  - `to_json_dict(codec_dict, *, wrapper="retain")` and
    `to_json(codec_dict, *, wrapper="retain")` — with explicit
    `wrapper="retain"|"drop"` behavior per the MovieLabs spec.
  - `from_json(json_source, *, wrapper_key=None)` — reverse-direction
    parse, with optional wrapper reconstruction.
  - `to_canonical_string(codec_dict)` — RFC 8785 JCS canonical output
    for JAdES-B-T signing.
  - Convenience `to_xml(...)` / `to_xml_canonical(...)` wrappers for
    direct JSON → XML conversion.
- `eidr.codecs.EIDR_MULTI_ELEMENTS` — bundled frozenset of cardinality
  hints harvested from a 209-record Content-ID sample spanning every
  EIDR referent type.
- `eidr.codecs.CardinalityHeuristicWarning` — emitted when the codec
  falls back to observed-cardinality inference.

#### Foundation modules (prior milestone, included here for completeness)

- `eidr.errors` — full exception hierarchy rooted at `EIDRError`, with
  transport / protocol / client / codec sub-trees and an
  `EIDRUncertainWriteError` for 5xx-after-transmitted writes.
- `eidr.auth` — REST API `Authorization` header construction
  (`Eidr <user>:<party>:Base64(SHA-256(password))`).
- `eidr.registries` — named registry endpoints (PRODUCTION, SANDBOX1,
  SANDBOX2, SANDBOX2_MIRROR, RESOLVE) with `writable` capability flags
  and case-insensitive name lookup.
- `eidr.credentials` — unified credential loader with five sources
  (EIDR XML config file, local JSON, AWS Secrets Manager, environment
  variables, direct construction), hard ambiguity detection, and
  password-redacted `repr`.
- `eidr.models.ids.EIDRID` — typed value object for EIDR identifiers
  with format validation, ISO 7064 Mod 37,36 check-character
  verification, and lossless conversions between canonical, filename,
  URN, DOI URN, DOI proxy, compact binary, and base64url forms.
- `eidr.models._checkchar` — pure-Python ISO 7064 Mod 37,36
  implementation, verified against every worked example in the EIDR
  ID Format spec, the ISAN reference document, and all 229 real
  records in the test corpus; cross-validated against `python-stdnum`.

### Infrastructure

- `pyproject.toml` — PEP 621 metadata, hatchling build backend,
  Python 3.11+ floor (tested on 3.11/3.12/3.13/3.14), optional extras
  for `aws`, `validation`, `canonical-json`, `dev`, `docs`.
- GitHub Actions CI — lint + type-check + matrix test (four Python
  versions × three OS), integration-test job gated on `main`, build
  verification with fresh-venv wheel install.
- GitHub Actions Release — OIDC trusted publishing to PyPI with PEP 740
  Sigstore attestations, GitHub Release creation, TestPyPI dry-run path.
- Sphinx documentation scaffolding (`furo` theme, MyST parser,
  autodoc2 API reference, intersphinx to Python/pydantic/httpx/lxml).
- Read the Docs configuration.
- Apache 2.0 license.
