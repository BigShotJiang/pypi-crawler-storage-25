"""Official Python SDK for the Entertainment Identifier Registry (EIDR).

This is a pre-1.0 development snapshot. The public API may change before
``1.0.0``.

Currently implemented surface
-----------------------------

* :class:`~eidr.models.ids.EIDRID`, :class:`~eidr.models.ids.IDCategory`
  — the value type for EIDR identifiers, with ISO 7064 Mod 37,36
  check-character validation and lossless form conversions.
* :class:`~eidr.credentials.Credentials` — unified credential loader
  with five sources (EIDR XML config, JSON, AWS Secrets Manager,
  environment variables, direct construction) and hard ambiguity
  detection.
* :func:`~eidr.auth.make_auth_header` — REST ``Authorization`` header
  construction (``Eidr <user>:<party>:Base64(SHA-256(password))``).
* :mod:`eidr.registries` — named registry endpoints (Production,
  Sandbox 1, Sandbox 2, Sandbox 2 Mirror, Resolve) with writable flags.
* :mod:`eidr.errors` — exception hierarchy rooted at
  :class:`~eidr.errors.EIDRError`. Registry-side exceptions carry
  structured ``code`` / ``type`` / ``details`` / ``response`` fields.
* :mod:`eidr.codecs` — XML ↔ intermediate dict ↔ JSON conversion per
  the MovieLabs MDDF JSON Encoding Best Practice. Two output paths:
  infoset-level round trip (for normal use) and canonical output
  (RFC 8785 JCS for JSON, W3C Canonical XML 2.0 for XML — for
  signing workflows).
* :mod:`eidr.models` — typed wrappers over the codec dict:
  :class:`~eidr.models.content.ContentRecord` (uniformly handles
  ``FullMetadata``, ``SelfDefinedMetadata``, ``ProvenanceMetadata``,
  ``InheritedMetadata``, and ``SimpleMetadata`` shapes),
  :class:`~eidr.models.party.PartyRecord`, and
  :class:`~eidr.models.service.ServiceRecord`. Pre-submission
  validation per the EIDR submission profile.
  :func:`eidr.parse` is a root-element-driven dispatcher that returns
  the appropriate record type when the caller doesn't know in advance.
* :class:`~eidr.client.Client` — sync HTTP client. Requires the
  ``[client]`` install extra (lazily imported — base-SDK users
  who don't need HTTP won't pull in ``httpx``). Operations:

  * **Reads:** ``resolve``, ``query``, ``graph_traversal``,
    ``party_query``, ``service_query``, ``status_lookup``.
  * **Writes:** ``register``, ``match``, ``modify``, ``delete``,
    ``promote``, ``alias``, ``add_relationship``,
    ``remove_relationship``, ``replace_relationship``. Each supports
    ``immediate=`` (sync), Token-based async, and optional
    ``wait_timeout=`` polling.

* :class:`~eidr.client.AsyncClient` — async counterpart to
  :class:`Client` with identical method signatures (all ``async
  def``). Built on :class:`httpx.AsyncClient`; use with
  ``async with``. Reads and writes both supported; the
  sync-under-load fallback case (REST API §2.1.1 — an
  ``immediate=True`` Create/Modify deflected to async by the
  registry) is handled transparently.

* :class:`~eidr.client.Token` and
  :class:`~eidr.client.AsyncToken` — handles for in-flight async
  writes, differing only in whether poll/wait are coroutines.
  :meth:`Token.to_async` bridges a sync-under-load-fallback Token
  into an async workflow without re-issuing the write; the reverse
  conversion is deliberately not offered.
* :class:`~eidr.client.OperationResult` — uniform structured view
  of a completed (or partially-completed) async write. Returned by
  :meth:`Token.operation_result` and :meth:`AsyncToken.operation_result`
  so caller code that consumes the result doesn't need to distinguish
  sync from async.
* :class:`~eidr.client.QueryResults` — paginated query result
  container with ``records`` / ``ids`` / ``total_matches`` /
  ``page_number`` / ``page_size`` / ``has_more_pages``.
* **Tracing facility** — :class:`~eidr.client.TraceSink` protocol
  with built-in :class:`~eidr.client.LoggerSink`,
  :class:`~eidr.client.FileSink`, and :class:`~eidr.client.ListSink`.
  Sensitive headers redacted at capture time. Body-size limits and
  body-redaction modes via :class:`~eidr.TransportConfig`.

Implementation status
---------------------

As of ``0.1.0rc1`` (M14) the SDK has reached **functional and
ergonomic parity with the Java SDK on the core public
registry-operation surface**. Java-only surfaces (batch operations,
user/ACL admin, UserOverride/impersonation) are listed under "Out
of scope" below. The public API contract documented in
`STABILITY.md` takes effect at this release; remaining work is
release-blocking defect correction, downstream-consumer trial
through the eidr-wikidata migration, and any issues that surface
in real use.

High-level surfaces:

* **Read paths:** :meth:`Client.resolve`,
  :meth:`Client.resolve_party`, :meth:`Client.resolve_service`,
  :meth:`Client.query` (page-by-page),
  :meth:`Client.iter_query`, :meth:`Client.iter_query_ids`
  (auto-paging),
  :meth:`Client.find_parties_by_name`,
  :meth:`Client.find_parties_from_catalog`,
  :meth:`Client.find_services_by_name`,
  :meth:`Client.find_services_from_catalog`,
  :meth:`Client.party_query` and :meth:`Client.service_query`
  (escape hatch), :meth:`Client.graph_traversal`,
  :meth:`Client.service_parent`,
  :meth:`Client.service_children`,
  :meth:`Client.modification_base`,
  :meth:`Client.modification_base_auto`,
  :meth:`Client.iter_status_by_user`,
  :meth:`Client.iter_status_by_registrant`,
  :meth:`Client.iter_status_superparty`,
  :meth:`Client.iter_status_by_token`,
  :meth:`Client.virtual_fields`.
* **Write paths:** :meth:`Client.register`,
  :meth:`Client.modify`, :meth:`Client.delete`,
  :meth:`Client.alias`, :meth:`Client.promote`,
  :meth:`Client.add_relationship`,
  :meth:`Client.replace_relationship`,
  :meth:`Client.remove_relationship`,
  :meth:`Client.create_party`, :meth:`Client.modify_party`,
  :meth:`Client.change_password`,
  :meth:`Client.create_service`, :meth:`Client.modify_service`,
  :meth:`Client.delete_service`.
* **Async:** every method has an exact mirror on
  :class:`AsyncClient`. Auto-paging iterators return
  :class:`AsyncIterator` for use with ``async for``.

Out of scope
------------

* **Batch operations** (``registerBatchFromXML``, etc.) — the
  single-operation API is the public surface; callers wanting
  batches can drop to the codec layer.
* **User admin and ACL admin** (``/user/*``, ``AdminAcl.*``) —
  internal Operations machinery, not for the public SDK.
* **Impersonation / UserOverride** — Superparty-only feature,
  deferred pending a clean public surface design. Targeted
  post-1.0.

Roadmap to 1.0
--------------

* **``iter_query()``** for asset-query auto-paging (paging
  consistency with ``iter_status_*``).
* **Live integration coverage** for M11 query helpers and
  non-Basic modification base; pre-built fixtures await a live
  registry run.
* **Schema validation expansion** — ``SchemaSource`` to a full
  lxml URI resolver. Targeted for 1.1.

See the M9 cover letter for the full Python↔Java SDK variance
table (updated through M10).

Example:
-------
File-based codec workflows::

    >>> from eidr.models import ContentRecord
    >>> rec = ContentRecord.from_xml(open("record.xml", "rb").read())
    >>> rec.resource_name
    'The Great Train Robbery'

Network workflows (requires the ``[client]`` install extra)::

    >>> from eidr import Client, registries, Credentials
    >>> with Client(registries.SANDBOX2, Credentials.load()) as client:  # doctest: +SKIP
    ...     rec = client.resolve("10.5240/7791-8534-2C23-9030-8610-5")
    ...     created = client.register(new_record, immediate=True)
    ...     for r in client.query("/FullMetadata/...").records:
    ...         print(r.id)
"""

from __future__ import annotations

from eidr import errors, registries  # re-exported as sub-modules
from eidr.auth import make_auth_header
from eidr.credentials import Credentials
from eidr.errors import (
    EIDRAnonymousWarning,
    EIDRAuthenticationError,
    EIDRAuthorizationError,
    EIDRClientError,
    EIDRCodecError,
    EIDRCredentialAmbiguityError,
    EIDRCredentialsNotFoundError,
    EIDRDuplicateError,
    EIDRError,
    EIDRHTTPStatusError,
    EIDRIDFormatError,
    EIDRNotFoundError,
    EIDRProtocolError,
    EIDRReadOnlyRegistryError,
    EIDRRegistryError,
    EIDRSDKPolicyError,
    EIDRTimeoutError,
    EIDRTransportError,
    EIDRUncertainWriteError,
    EIDRValidationError,
)
from eidr.models import ContentRecord, PartyRecord, ServiceRecord, parse
from eidr.models.ids import EIDRID, IDCategory

__version__ = "0.1.0rc1"


# Lazy-import the HTTP client so callers who only need file-based
# codec workflows don't pull httpx. PEP 562 __getattr__ fires only
# on access to names not already set in the module namespace, so
# the normal imports above are unaffected.
_LAZY_CLIENT_NAMES = frozenset(
    {
        # Sync
        "Client",
        "Token",
        "TokenStatus",
        # Async (requires [client] extra and an asyncio runtime)
        "AsyncClient",
        "AsyncToken",
        # Value types / enums
        "DedupeMode",
        "GraphTraversalType",
        "RelationshipType",
        # Result types
        "OperationResult",
        "OperationStatusEntry",
        "PartyQueryResults",
        "QueryResults",
        "ServiceChildrenResults",
        "ServiceQueryResults",
        # Tracing
        "TraceRecord",
        "TraceSink",
        "LoggerSink",
        "FileSink",
        "ListSink",
        # Transport configuration
        "TransportConfig",
    }
)


def __getattr__(name: str) -> object:
    if name in _LAZY_CLIENT_NAMES:
        from eidr import client as _client_mod  # local import, not eager

        obj = getattr(_client_mod, name)
        # Cache on the module so future accesses skip __getattr__.
        globals()[name] = obj
        return obj
    raise AttributeError(f"module 'eidr' has no attribute {name!r}")


__all__ = [  # noqa: RUF022 — grouped by theme for readability
    # Version
    "__version__",
    # Public types — IDs
    "EIDRID",
    "IDCategory",
    # Public types — records
    "ContentRecord",
    "PartyRecord",
    "ServiceRecord",
    # Top-level dispatcher
    "parse",
    # HTTP clients — sync (lazy; requires [client] extra)
    "Client",
    "Token",
    "TokenStatus",
    # HTTP clients — async (lazy; requires [client] extra)
    "AsyncClient",
    "AsyncToken",
    # Client value types / enums (lazy)
    "DedupeMode",
    "GraphTraversalType",
    "RelationshipType",
    # Client result types (lazy)
    "OperationResult",
    "OperationStatusEntry",
    "PartyQueryResults",
    "QueryResults",
    "ServiceChildrenResults",
    "ServiceQueryResults",
    # Tracing (lazy)
    "TraceRecord",
    "TraceSink",
    "LoggerSink",
    "FileSink",
    "ListSink",
    # Transport configuration (lazy)
    "TransportConfig",
    # Credentials & auth
    "Credentials",
    "make_auth_header",
    # Sub-packages re-exported
    "errors",
    "registries",
    # Exceptions (re-exported for convenience; also available via eidr.errors)
    "EIDRError",
    "EIDRAnonymousWarning",
    "EIDRAuthenticationError",
    "EIDRAuthorizationError",
    "EIDRClientError",
    "EIDRCodecError",
    "EIDRCredentialAmbiguityError",
    "EIDRCredentialsNotFoundError",
    "EIDRDuplicateError",
    "EIDRHTTPStatusError",
    "EIDRIDFormatError",
    "EIDRNotFoundError",
    "EIDRProtocolError",
    "EIDRReadOnlyRegistryError",
    "EIDRRegistryError",
    "EIDRSDKPolicyError",
    "EIDRTimeoutError",
    "EIDRTransportError",
    "EIDRUncertainWriteError",
    "EIDRValidationError",
]
