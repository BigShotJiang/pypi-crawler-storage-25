"""Pre-submission validation for :class:`ContentRecord`.

The EIDR submission profile
---------------------------

This validator enforces the **EIDR submission profile** — the union
of schema-required fields and EIDR's documented business rules that
can be checked before a record leaves the client. It is not a pure
"structural shape" check; it encodes EIDR-specific policy:

* EIDR-profile credit bounds (≤2 Directors, ≤4 Actors) beyond the
  raw schema's unbounded ``maxOccurs``.
* Unconditional-on-root-records required fields (Basic, Series,
  Compilation), paired with conditional-for-child-records required
  fields (Episode, Season, Edit, Clip, Manifestation) per the
  schema's inheritance model.
* Controlled-vocabulary checks for ``ReferentType``, ``Mode``,
  ``Status``, ``StructuralType``.

Inheritance and system-generation (per `common.xsd`)
----------------------------------------------------

The schema's ``inheritedBaseObjectInfoGroup`` defines which
BaseObjectData fields may be inherited from a parent record. For
some record kinds, additional fields may be filled by the registry's
**system-generation** business rules (Season and Episode
ResourceName, for instance — which are not technically inherited
but are generated at the registry from parent-record context plus
the submitted record's own fields).

From the library's perspective the distinction between inheritance
and system-generation is academic: in both cases the registry *may*
populate the field from outside the submitted record, and the
library lacks the context (parent record in hand, full modeling of
business rules) to predict whether it *will*. The uniform library
rule is:

* **Root records** (Basic, Series, Compilation): every
  required BaseObjectData field must be supplied directly. These
  records have no parent, and system-generation likewise doesn't
  apply to fields on root records (which become the reference point
  for their descendants rather than consumers of inherited data).
* **Child records** (Season, Episode, Edit, Clip, Manifestation):
  any field in ``inheritedBaseObjectInfoGroup`` may be omitted.
  The registry will either fill it from the parent (inheritance)
  or generate it (business rules), or — if it cannot — return a
  validation error to the caller.

Callers who want stricter pre-submission checks than this (e.g.,
"never let me submit a Season without ResourceName") can inspect
the record themselves; the library keeps a uniformly-permissive
policy to avoid false-positive rejections on records the registry
would have accepted.

Fields that are explicitly not inheritable per the schema, and are
therefore required on all record kinds regardless of Creation Type:

* ``ID`` (always unique to the record; handled separately)
* ``Administrators`` (carries the Registrant; unique per record)
* ``AlternateID`` (not inherited; must be set directly)
* ``RegistrantExtra`` (not inherited)
* ``Description`` (not inherited)

``ExtraObjectMetadata`` blocks are never inherited — if a
CreationType-bearing block is present, its required fields must
be supplied directly.

What validation does NOT do
---------------------------

* Does not resolve ID references against the registry (Parent,
  Registrant, MetadataAuthority). Network-dependent checks remain
  the registry's job.
* Does not model the registry's business rules for inheritance,
  system-generated titles, or default values. If a field is in the
  schema's inheritable set and the record is a child kind, we allow
  it to be missing; we do not attempt to predict what the registry
  will populate.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from eidr.models._validation import ValidationReport
from eidr.models.enums import CreationType, Mode, ReferentType, Status, StructuralType

if TYPE_CHECKING:
    from eidr.codecs._rules import CodecDict, CodecValue
    from eidr.models.content import ContentRecord

__all__ = ["validate_content_record"]


# The seven mutually-exclusive CreationType-bearing blocks.
_CREATION_BLOCKS: dict[str, CreationType] = {
    "SeriesInfo": CreationType.Series,
    "SeasonInfo": CreationType.Season,
    "EpisodeInfo": CreationType.Episode,
    "EditInfo": CreationType.Edit,
    "ClipInfo": CreationType.Clip,
    "ManifestationInfo": CreationType.Manifestation,
    "CompilationInfo": CreationType.Compilation,
}

# Root CreationTypes — no parent, no inheritance, must supply every required
# BaseObjectData field directly. Basic is the implicit default (no block).
_ROOT_CREATION_TYPES: frozenset[CreationType] = frozenset(
    {
        CreationType.Basic,
        CreationType.Series,
        CreationType.Compilation,
    }
)

# Child CreationTypes — may inherit schema-inheritable fields from parent.
_CHILD_CREATION_TYPES: frozenset[CreationType] = frozenset(
    {
        CreationType.Season,
        CreationType.Episode,
        CreationType.Edit,
        CreationType.Clip,
        CreationType.Manifestation,
    }
)

# Fields under BaseObjectData that the schema's inheritedBaseObjectInfoGroup
# marks as inheritable. Child records may omit these; root records must
# supply them directly. Source: common.xsd, inheritedBaseObjectInfoGroup.
_INHERITABLE_BASE_FIELDS: frozenset[str] = frozenset(
    {
        "StructuralType",
        "Mode",
        "ReferentType",
        "ResourceName",
        "AlternateResourceName",
        "OriginalLanguage",
        "VersionLanguage",
        "AssociatedOrg",
        "ReleaseDate",
        "CountryOfOrigin",
        "Status",
        "ApproximateLength",
        "Credits",
    }
)

# Required BaseObjectData fields per the EIDR submission profile.
# Everything listed here MUST be present directly on a root record.
# Child records may omit those in _INHERITABLE_BASE_FIELDS.
_BASE_REQUIRED_FIELDS: tuple[str, ...] = (
    "StructuralType",
    "Mode",
    "ReferentType",
    "ResourceName",
    "OriginalLanguage",
    "Status",
    "Administrators",
)

# Per-CreationType schema carve-outs from the inheritable set.
#
# Per common.xsd: "ResourceName and AlternateResourceName are never
# inherited for Seasons or Episodes." For these record kinds the
# registry uses a business-rule **system-generation** path rather
# than inheritance. From the library's perspective, though,
# inheritance and system-generation are indistinguishable: in both
# cases the registry *may* populate the field from outside the
# submitted record, and the library lacks the context (parent record,
# business-rule state) to verify whether it *will*.
#
# The library's rule is therefore uniform for child records: any
# field the schema marks as potentially fillable-from-outside
# (via either mechanism) may be omitted at submission time. If the
# registry can't satisfy the requirement from inheritance or
# business-rule, it returns a validation error — that's on the
# registry, not the library.
#
# AlternateResourceName is always optional at the schema level
# (``minOccurs=0`` in every context), so it's never in the
# required-fields set and no carve-out is needed regardless of
# inheritance semantics.
#
# This dict is retained (empty) as documentation. If the operational
# semantics ever change — e.g., EIDR decides that some fill-in
# mechanism is too unreliable for the library to trust — per-type
# carve-outs can be reintroduced here.
_NON_INHERITABLE_FOR: dict[CreationType, frozenset[str]] = {}

# CreationTypes and the block-level required fields specific to each.
# Reported as paths relative to the block itself (e.g., "SeriesInfo/SeriesClass").
# ExtraObjectMetadata is NEVER inherited — these are always required directly.
_BLOCK_REQUIREMENTS: dict[str, tuple[str, ...]] = {
    "SeriesInfo": ("SeriesClass",),
    "SeasonInfo": ("Parent", "SequenceNumber"),
    "EpisodeInfo": ("Parent",),
    "EditInfo": ("Parent", "EditClass", "EditUse"),
    "ClipInfo": ("Parent",),
    "ManifestationInfo": ("Parent", "ManifestationClass"),
    "CompilationInfo": ("CompilationClass",),
}

# EIDR profile bounds tighter than the raw schema
_MAX_DIRECTORS = 2
_MAX_ACTORS = 4


def _scalar(v: CodecValue) -> str | None:
    """Extract a leaf text value."""
    if v is None:
        return None
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        text = v.get("value")
        return text if isinstance(text, str) else None
    if isinstance(v, list) and len(v) == 1:
        return _scalar(v[0])
    return None


def _is_structurally_present(container: CodecDict | None, key: str) -> bool:
    """True iff ``container`` has ``key`` bound to a non-``None`` value.

    Attribute-only elements (dicts with only attribute keys, like
    ``<AssociatedOrg organizationID="..."/>``) qualify as present
    here — the registry may apply business rules to populate their
    content from the attribute, so requiring a text payload would
    reject records that are valid on the wire.

    Use for checks of the form "is this element *there at all*?" —
    parent containers, references that may be populated by business
    rules, and similar.
    """
    if container is None or not isinstance(container, dict):
        return False
    val = container.get(key)
    if val is None:
        return False
    return not (isinstance(val, (list, dict, str)) and len(val) == 0)


def _has_meaningful_content(container: CodecDict | None, key: str) -> bool:
    """True iff ``container``'s ``key`` has real text/child content.

    More strict than :func:`_is_structurally_present`: an element
    with only attributes (and no text, no children) does NOT count
    as having meaningful content. Use for leaf-like required fields
    where the registry expects an actual value (``ResourceName``,
    ``ID``, ``Registrant``), not a reference-by-attribute.
    """
    if container is None or not isinstance(container, dict):
        return False
    val = container.get(key)
    if val is None:
        return False
    if isinstance(val, str):
        return bool(val)
    if isinstance(val, list):
        return any(_value_has_content(item) for item in val)
    if isinstance(val, dict):
        return _value_has_content(val)
    return True  # type: ignore[unreachable]  # pragma: no cover


def _value_has_content(value: CodecValue) -> bool:
    """Does a value carry text or child elements (as opposed to only attributes)?"""
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value)
    if isinstance(value, list):
        return any(_value_has_content(v) for v in value)
    if isinstance(value, dict):
        # A dict has content iff any non-attribute key is present with non-None
        from eidr.codecs._rules import ATTR_PREFIX

        for k, v in value.items():
            if k.startswith(ATTR_PREFIX):
                continue
            if k == "value":
                if isinstance(v, str) and v:
                    return True
                continue
            # A child element whose value is truthy
            if v is not None:
                if isinstance(v, (list, dict, str)):
                    if len(v) > 0:
                        return True
                else:
                    return True  # type: ignore[unreachable]  # pragma: no cover
        return False
    return True  # type: ignore[unreachable]  # pragma: no cover


def _determine_creation_type(extra: CodecValue) -> CreationType:
    """Determine the record's CreationType from its ExtraObjectMetadata blocks.

    If no CreationType-bearing block is present, the record is Basic.
    If exactly one is present, the record's CreationType matches. If
    multiple are present, we return Basic here — the multi-block
    error is reported separately by
    :func:`_check_creation_type_consistency`.
    """
    if not isinstance(extra, dict):
        return CreationType.Basic
    present = [name for name in _CREATION_BLOCKS if name in extra]
    if len(present) == 1:
        return _CREATION_BLOCKS[present[0]]
    return CreationType.Basic


def validate_content_record(
    record: ContentRecord,
    *,
    mode: Literal["create", "modify"] | None = None,
    max_errors: int = 50,
) -> ValidationReport:
    """Run pre-submission validation over a ContentRecord.

    Applies the EIDR submission profile: schema-required fields
    conditional on CreationType (inheritable fields may be omitted
    on child records, modulo the Season/Episode carve-out for
    ResourceName), controlled-vocabulary checks, EIDR-profile
    credit caps, CreationType-block consistency, CompositeInfo
    placement, and the empty-tag rule.

    Args:
        record: The record to validate.
        mode: Submission mode. ``"create"`` — ID must NOT be
            present (the registry assigns it). ``"modify"`` — ID
            MUST be present and well-formed. ``None`` (default) —
            only validate ID format if present; don't enforce
            presence or absence.
        max_errors: Cap on collected errors.

    Returns:
        A :class:`ValidationReport`. Empty iff the record passes all
        checks. Non-empty reports are iterable and carry one
        :class:`ValidationError` per finding, bounded at
        ``max_errors``.
    """
    report = ValidationReport(max_errors=max_errors)
    root = record._root
    base = root.get("BaseObjectData") if isinstance(root, dict) else None
    extra = root.get("ExtraObjectMetadata") if isinstance(root, dict) else None

    if not isinstance(base, dict):
        report.add(
            code="content.required_field.missing",
            message="BaseObjectData is required",
            path="BaseObjectData",
        )
        return report

    creation_type = _determine_creation_type(extra)

    _check_id(base, report, mode=mode)
    _check_base_required_fields(base, creation_type, report)
    _check_controlled_vocabularies(base, report)
    _check_credits_bounds(base, report)
    _check_creation_type_consistency(extra, report)
    _check_block_required_fields(extra, report)
    _check_composite_info_placement(extra, report)
    _check_empty_tags(record, report)

    return report


def _check_id(
    base: CodecDict,
    report: ValidationReport,
    *,
    mode: Literal["create", "modify"] | None,
) -> None:
    """ID-mode check for Content.

    ``"create"`` — ID must be absent (registry assigns it).
    ``"modify"`` — ID required, must parse.
    ``None`` — validate format only when present.
    """
    raw = _scalar(base.get("ID"))
    id_present = raw is not None and raw != ""

    if mode == "create" and id_present:
        report.add(
            code="content.id.unexpected",
            message=(
                "ID must NOT be present on Content create payloads; the registry assigns the ID."
            ),
            path="BaseObjectData/ID",
            value=raw,
        )
        return

    if mode == "modify" and not id_present:
        report.add(
            code="content.required_field.missing",
            message="ID is required on Content modify payloads",
            path="BaseObjectData/ID",
        )
        return

    if not id_present:
        return

    from eidr.errors import EIDRIDFormatError
    from eidr.models.ids import EIDRID

    try:
        EIDRID.parse(raw or "")
    except EIDRIDFormatError as exc:
        report.add(
            code="content.id.invalid",
            message=f"ID is not a valid EIDR identifier: {exc}",
            path="BaseObjectData/ID",
            value=raw,
        )


def _check_base_required_fields(
    base: CodecDict, creation_type: CreationType, report: ValidationReport
) -> None:
    """Enforce BaseObjectData required-field rules per the EIDR submission profile.

    Root records (Basic, Series, Compilation) must supply every
    required field directly. Child records (Season, Episode, Edit,
    Clip, Manifestation) may omit fields that the schema marks as
    inheritable via ``inheritedBaseObjectInfoGroup``, with per-
    CreationType carve-outs: ``ResourceName`` and ``AlternateResourceName``
    are never inherited for Seasons or Episodes, per the schema.
    """
    is_root = creation_type in _ROOT_CREATION_TYPES
    non_inheritable_overrides = _NON_INHERITABLE_FOR.get(creation_type, frozenset())

    for name in _BASE_REQUIRED_FIELDS:
        # Can this field be inherited for this CreationType?
        can_inherit = (
            not is_root
            and name in _INHERITABLE_BASE_FIELDS
            and name not in non_inheritable_overrides
        )
        if can_inherit:
            continue
        # The registry needs a real value here; attribute-only shells
        # are not meaningful content for these leaf fields.
        # Exception: Administrators is a container whose required
        # substructure (Registrant) is checked separately below.
        presence_check = (
            _is_structurally_present if name == "Administrators" else _has_meaningful_content
        )
        if not presence_check(base, name):
            report.add(
                code="content.required_field.missing",
                message=f"{name} is required",
                path=f"BaseObjectData/{name}",
            )

    # Administrators/Registrant is a leaf reference — must resolve to a
    # real EIDR Party ID, not just an attribute hull. However, Registrant
    # itself is never inherited (Administrators isn't in the inheritable
    # group), so this check applies uniformly to root and child records.
    admin = base.get("Administrators")
    if isinstance(admin, dict) and not _has_meaningful_content(admin, "Registrant"):
        report.add(
            code="content.required_field.missing",
            message="Administrators/Registrant is required",
            path="BaseObjectData/Administrators/Registrant",
        )


def _check_controlled_vocabularies(base: CodecDict, report: ValidationReport) -> None:
    """ReferentType, Mode, Status, StructuralType must be in their enums."""
    for field_name, enum_cls in (
        ("ReferentType", ReferentType),
        ("Mode", Mode),
        ("Status", Status),
        ("StructuralType", StructuralType),
    ):
        raw = _scalar(base.get(field_name))
        if raw is None:
            continue  # Missing is a separate error, reported elsewhere
        try:
            enum_cls(raw)
        except ValueError:
            valid = [m.value for m in enum_cls]
            report.add(
                code="content.vocabulary.invalid",
                message=(f"{field_name}={raw!r} is not one of {', '.join(valid)}"),
                path=f"BaseObjectData/{field_name}",
                value=raw,
            )


def _check_credits_bounds(base: CodecDict, report: ValidationReport) -> None:
    """EIDR profile: ≤2 Directors, ≤4 Actors."""
    credits = base.get("Credits")
    if not isinstance(credits, dict):
        return

    for role, cap, code in (
        ("Director", _MAX_DIRECTORS, "content.credits.too_many_directors"),
        ("Actor", _MAX_ACTORS, "content.credits.too_many_actors"),
    ):
        entries = credits.get(role)
        if entries is None:
            continue
        count = len(entries) if isinstance(entries, list) else 1
        if count > cap:
            report.add(
                code=code,
                message=(
                    f"EIDR profile allows at most {cap} "
                    f"{role}{'s' if cap != 1 else ''} per record; got {count}"
                ),
                path=f"BaseObjectData/Credits/{role}",
                value=count,
            )


def _check_creation_type_consistency(extra: CodecValue, report: ValidationReport) -> None:
    """At most one CreationType-bearing block may be present."""
    if not isinstance(extra, dict):
        return  # No ExtraObjectMetadata at all → implicitly Basic; fine
    present = [name for name in _CREATION_BLOCKS if name in extra]
    if len(present) > 1:
        report.add(
            code="content.creation_type.multiple_blocks",
            message=(
                "At most one CreationType-bearing block may appear per "
                f"record; found {', '.join(present)}"
            ),
            path="ExtraObjectMetadata",
            value=present,
        )


def _check_block_required_fields(extra: CodecValue, report: ValidationReport) -> None:
    """Each CreationType-bearing block has its own required fields.

    Empty blocks (e.g., ``<SeriesInfo/>``) are not special-cased here
    — they are caught by the dedicated empty-tag check, which reports
    them as schema-violating regardless of what their required fields
    would have been.
    """
    if not isinstance(extra, dict):
        return
    for block_name, required in _BLOCK_REQUIREMENTS.items():
        block = extra.get(block_name)
        if not isinstance(block, dict):
            continue
        for req in required:
            if not _is_structurally_present(block, req):
                report.add(
                    code="content.required_field.missing",
                    message=f"{block_name}/{req} is required",
                    path=f"ExtraObjectMetadata/{block_name}/{req}",
                )


def _check_composite_info_placement(extra: CodecValue, report: ValidationReport) -> None:
    """CompositeInfo may only co-occur with a Basic or Episode record."""
    if not isinstance(extra, dict):
        return
    if "CompositeInfo" not in extra:
        return
    # Find which CreationType block (if any) is present
    creation_blocks_present = [name for name in _CREATION_BLOCKS if name in extra]
    if not creation_blocks_present:
        return  # Basic — CompositeInfo is allowed
    if creation_blocks_present == ["EpisodeInfo"]:
        return  # Episode + CompositeInfo is allowed
    report.add(
        code="content.composite_info.misplaced",
        message=(
            "CompositeInfo may only appear on Basic or Episode records; "
            f"found alongside {', '.join(creation_blocks_present)}"
        ),
        path="ExtraObjectMetadata/CompositeInfo",
    )


def _check_empty_tags(record: ContentRecord, report: ValidationReport) -> None:
    """The registry rejects any empty tag outright.

    An element with no text, no attributes, and no children is a
    schema-validation error. Users who built records programmatically
    should call :func:`~eidr.models.strip_empty_tags` before
    submission to remove them.
    """
    from eidr.models._empty_tags import find_empty_tags

    paths = find_empty_tags(record._data)
    for path in paths:
        report.add(
            code="content.empty_tag.forbidden",
            message=(
                "Empty tags are not permitted in EIDR submissions; "
                "remove this element or supply content. "
                "Consider calling strip_empty_tags() before validation."
            ),
            path=path,
        )
