"""Empty-tag helpers for pre-submission record manipulation.

The EIDR registry rejects empty tags outright — an element with no
text, no attributes, and no children is a schema validation error,
regardless of whether that element was required. The canonical
behavior for a caller building a record is therefore:

1. Omit fields you don't have values for. A missing tag is fine; the
   registry will fill it via inheritance or business rules (system-
   generated titles, default flags, etc.) before validating.
2. Never emit a present-but-empty tag. If you accumulate a field
   optionally and end up with no value, remove the tag entirely.

This module provides two tools:

* :func:`strip_empty_tags` — recursively removes empty tags from a
  codec dict in place. Intended as a pre-submission normalization
  step. Recursive: stripping a child may leave the parent empty,
  which is then also stripped.
* :func:`find_empty_tags` — reports the XPath-like paths of every
  empty tag in a codec dict. Used by the validators to produce
  actionable error messages when the caller has submitted a record
  they should have stripped first.

An element is considered empty when:

* Its content is ``None`` (from ``<X/>`` or ``<X></X>``), *or*
* Its content is a string that is empty or whitespace-only, *or*
* Its content is an empty list, *or*
* Its content is a dict that contains no real data — i.e., after
  namespace-declaration keys (``_xmlns``, ``_xmlns:...``) are
  ignored, no non-empty children remain and no attribute keys are
  present. A dict with only attribute keys (``_lang``, ``_type``,
  etc.) is NOT empty — the attribute carries content.

Namespace declarations (``_xmlns`` and ``_xmlns:<prefix>`` keys) are
preserved as-is on any non-empty element; they are not themselves
content that keeps an element alive.
"""

from __future__ import annotations

from typing import Any

from eidr.codecs._rules import ATTR_PREFIX, TEXT_KEY, CodecDict, CodecValue

__all__ = ["EMPTY_TAG_SENTINEL", "find_empty_tags", "strip_empty_tags"]


# Sentinel returned internally from _strip_one to signal "this element
# was empty and should be removed from its parent."
class _Empty:
    pass


EMPTY_TAG_SENTINEL = _Empty()


def _is_namespace_key(key: str) -> bool:
    """True for ``_xmlns`` and ``_xmlns:<prefix>`` keys (namespace decls)."""
    return key == f"{ATTR_PREFIX}xmlns" or key.startswith(f"{ATTR_PREFIX}xmlns:")


def _is_attr_key(key: str) -> bool:
    """True for any attribute key (``_<name>``) including namespace decls."""
    return key.startswith(ATTR_PREFIX)


def _is_empty_scalar(value: Any) -> bool:
    """A string is empty if it is blank or whitespace-only."""
    return isinstance(value, str) and not value.strip()


def strip_empty_tags(codec_dict: CodecDict) -> CodecDict:
    """Recursively strip empty tags from a codec dict, in place.

    Returns the same dict for call-chaining convenience. Use before
    submitting a record you built programmatically — once stripped,
    the remaining tags are guaranteed to have real content.

    "Empty" is defined as: no text, no non-namespace attributes, and
    no non-empty children (after recursive stripping). Whitespace-only
    text is treated as empty. Namespace declarations alone do not
    count as content.

    Args:
        codec_dict: The codec dict to modify. Modified in place.

    Returns:
        The same codec dict.
    """
    _strip_dict(codec_dict)
    return codec_dict


def _strip_dict(d: CodecDict) -> None:
    """Strip empty children from a dict in place."""
    # Iterate over a list of keys since we may delete during iteration
    for key in list(d.keys()):
        if _is_attr_key(key):
            continue  # Attributes are preserved — handled by parent emptiness check
        if key == TEXT_KEY:
            # Text content: remove iff empty/whitespace
            if _is_empty_scalar(d[key]):
                del d[key]
            continue
        value = d[key]
        stripped = _strip_value(value)
        if stripped is EMPTY_TAG_SENTINEL:
            del d[key]
        else:
            d[key] = stripped


def _strip_value(value: CodecValue) -> Any:
    """Strip an element value. Returns :data:`EMPTY_TAG_SENTINEL` iff empty."""
    if value is None:
        return EMPTY_TAG_SENTINEL

    if isinstance(value, str):
        if _is_empty_scalar(value):
            return EMPTY_TAG_SENTINEL
        return value

    if isinstance(value, list):
        # Strip each item; drop items that become empty
        new_list = []
        for item in value:
            stripped = _strip_value(item)
            if stripped is not EMPTY_TAG_SENTINEL:
                new_list.append(stripped)
        if not new_list:
            return EMPTY_TAG_SENTINEL
        return new_list

    if isinstance(value, dict):
        _strip_dict(value)
        # After stripping, is the dict effectively empty?
        if _dict_is_empty(value):
            return EMPTY_TAG_SENTINEL
        return value

    # Per the CodecValue type, None | str | list | dict covers every
    # case; if we reach here the value was of an unexpected type, and
    # returning it unchanged is the safest fallback.
    return value  # type: ignore[unreachable]  # pragma: no cover


def _dict_is_empty(d: CodecDict) -> bool:
    """A dict is empty if it has no content-bearing keys.

    Namespace-declaration keys (``_xmlns``, ``_xmlns:...``) are
    ignored. Ordinary attributes keep a dict alive (the element
    carries attribute content). Children must be non-empty after
    their own recursive strip pass.
    """
    for key, value in d.items():
        if _is_namespace_key(key):
            continue
        if _is_attr_key(key):
            # Non-namespace attribute — carries content
            return False
        if key == TEXT_KEY:
            if not _is_empty_scalar(value):
                return False
            continue
        # Child element — it's already been recursively stripped, so
        # any value present here is non-empty by construction.
        # (strip_value would have returned EMPTY_TAG_SENTINEL and the
        # parent would have deleted it.)
        return False
    return True


def find_empty_tags(codec_dict: CodecDict, *, path: str = "") -> list[str]:
    """Return a list of XPath-like paths for every empty tag.

    Used by validators to report offending locations. Does NOT modify
    the input. Paths use local element names separated by ``/`` with
    list indices in brackets, e.g. ``"BaseObjectData/AlternateID[2]"``.

    Args:
        codec_dict: The codec dict to inspect.
        path: The path prefix for recursive calls; callers should
            usually leave as default.

    Returns:
        A list of XPath-like paths; empty iff the record has no
        empty tags.
    """
    results: list[str] = []
    _walk_empty_dict(codec_dict, path, results)
    return results


def _walk_empty_dict(d: CodecDict, path: str, results: list[str]) -> None:
    for key, value in d.items():
        if _is_attr_key(key) or key == TEXT_KEY:
            continue
        child_path = f"{path}/{key}" if path else key
        _walk_empty_value(value, child_path, results)


def _walk_empty_value(value: CodecValue, path: str, results: list[str]) -> None:
    if value is None:
        results.append(path)
        return
    if isinstance(value, str):
        if _is_empty_scalar(value):
            results.append(path)
        return
    if isinstance(value, list):
        for i, item in enumerate(value):
            _walk_empty_value(item, f"{path}[{i}]", results)
        return
    if isinstance(value, dict):
        # Check whether this dict is effectively empty
        if _dict_effectively_empty_for_walk(value):
            results.append(path)
            return
        _walk_empty_dict(value, path, results)


def _dict_effectively_empty_for_walk(d: CodecDict) -> bool:
    """Non-mutating variant of :func:`_dict_is_empty`.

    Used by :func:`find_empty_tags`, which walks without mutating.
    A dict is empty if it has no non-namespace attribute, no
    non-empty text, and no children (or only empty children — but
    those will themselves be reported separately at their own paths,
    so the parent is empty iff it has no non-empty *direct* content).
    """
    for key, value in d.items():
        if _is_namespace_key(key):
            continue
        if _is_attr_key(key):
            return False
        if key == TEXT_KEY:
            if not _is_empty_scalar(value):
                return False
            continue
        # Children present — walk them. If they're all empty, we still
        # consider this dict non-empty at this level because the
        # children will be reported individually. The registry would
        # reject those children before getting to the parent, so we
        # report them rather than masking them with a parent complaint.
        return False
    return True
