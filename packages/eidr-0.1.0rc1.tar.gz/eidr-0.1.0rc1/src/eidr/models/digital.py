"""Typed pydantic models for the EIDR Digital sub-tree.

The Digital sub-tree describes technical characteristics of digital
encodings — video codec, frame rate, color primaries, audio
channel layout, subtitle tracks, and so on. The XSD has roughly
40+ types nested 4–6 levels deep with extensive enum vocabularies.

This module re-exports the auto-generated typed model from
:mod:`eidr.models._digital_generated` under more discoverable
names. The generated module is the source of truth and is
checked into the SDK by maintainers; end users never run the
generator. To regenerate after a schema update, see
``tools/generate_digital.py``.

Why opt-in via the ``[digital]`` extra
--------------------------------------

Most callers don't need typed access to a Manifestation's
Digital sub-tree — they treat it as opaque metadata to pass
through. The generated tree pulls in :mod:`pydantic` (and via
xsdata-pydantic, a small extra runtime), which the base SDK
doesn't otherwise need. Putting the typed surface behind
``[digital]`` keeps the codec-only path dependency-light.

Importing this module without the required dependencies installed
produces a clear :class:`ModuleNotFoundError` with a remediation
message, not a confusing failure deep inside the generated code.

Usage
-----

::

    from eidr import Client, registries
    from eidr.models.digital import (
        DigitalTracks, Track, DigitalAssetAudio,
    )

    with Client(registries.SANDBOX2, creds) as client:
        record = client.resolve('10.5240/...some-manifestation-ID...')

    manifest = record.creation_block  # a ManifestationInfo
    typed = manifest.digital_typed()  # → DigitalTracks | None
    if typed is not None:
        for entry in typed.track_or_container:
            if isinstance(entry, Track) and isinstance(
                entry.choice, DigitalAssetAudio
            ):
                print(entry.choice.language.value, entry.choice.type_value)

To write back, build a typed :class:`DigitalTracks` and call
:meth:`ManifestationInfo.set_digital`. The pattern is "build typed
view, mutate, set back" — the codec dict on
``manifestation.digital`` remains the source of truth, and
``digital_typed()`` materializes a fresh instance on each call.

Wildcard import
---------------

``from eidr.models.digital import *`` exposes only the curated
short aliases listed in :data:`__all__` (``DigitalTracks``,
``Track``, ``Container``, and the per-asset-data types).

Internal generated module — DO NOT IMPORT DIRECTLY
--------------------------------------------------

The full 290-class generated tree lives at
:mod:`eidr.models._digital_generated`. **That module is internal
and unstable.** Class names, field names, and module structure
can change in any SDK release without notice — they are
regenerated mechanically from the bundled XSD by
``tools/generate_digital.py``, and the generator's output style
follows whatever xsdata happens to produce.

The supported public API is the curated set of names re-exported
from this module (:mod:`eidr.models.digital`). If you need a
type that isn't aliased here, file an issue — that's a signal we
should add it to the curated set, not that you should reach into
the generated module.
"""

from __future__ import annotations


def _check_digital_extra_available() -> None:
    """Raise a friendly error if the ``[digital]`` extra wasn't installed.

    Checks every runtime dependency the typed Digital surface
    needs: :mod:`pydantic`, :mod:`xsdata`, and
    :mod:`xsdata_pydantic`. Without all three, downstream imports
    of the generated module — or its xsdata-pydantic field
    helpers — raise less-friendly errors deep inside the
    generated code. Catching the missing dependency at this
    module's import time produces one clear error pointing at
    the remediation.
    """
    missing: list[str] = []
    for dep_name in ("pydantic", "xsdata", "xsdata_pydantic"):
        try:
            __import__(dep_name)
        except ModuleNotFoundError:
            missing.append(dep_name)

    if missing:
        joined = ", ".join(missing)
        raise ModuleNotFoundError(
            f"eidr.models.digital requires the [digital] install "
            f"extra (missing: {joined}). Install with "
            f"`pip install 'eidr[digital]'` to use the typed "
            f"Digital sub-model."
        )


_check_digital_extra_available()

# Re-export the full generated tree. The names match the XSD type
# names with PascalCase suffix ``Type`` preserved (xsdata's
# convention) — e.g., ``DigitalAssetVideoDataType``. We also
# expose shorter aliases for the most-used types.
from eidr.models import _digital_generated as _gen  # noqa: E402
from eidr.models._digital_generated import *  # noqa: F403, E402

# Curated short aliases for the headline types. The full xsdata
# names are preserved alongside; aliases are convenience only,
# not a separate API surface.
#
# The EIDR record's wire shape places digital metadata inside
# ``ManifestationInfo > Digital``, where the ``<Digital>`` element
# carries zero or more ``<Track>`` and ``<Container>`` children.
# That ``<Digital>`` element's type is :class:`DigitalTracksType`
# (formerly named ``digitalTracksType`` in the schema). Each
# ``<Track>`` is a :class:`DigitalAssetMetadataType` choice
# wrapping exactly one of audio/video/subtitle/interactive; each
# ``<Container>`` is a :class:`ContainerMetadataType`.
#
# The other ``DigitalAsset*`` types in the MD schema
# (:class:`DigitalAssetSetType`, :class:`DigitalAssetVideoDataType`,
# etc.) are reusable building blocks that the EIDR record schema
# composes via the Track choice — they're available on this
# module too, but :class:`DigitalTracks` is the type a caller
# round-tripping a record's Digital block actually instantiates.
DigitalTracks = _gen.DigitalTracksType
"""The contents of a record's ``<Digital>`` sub-element under
``ManifestationInfo``. A flat collection of Track and Container
choices, accessed via the ``track_or_container`` field. Top-level
type for :meth:`ManifestationInfo.digital_typed`."""

Track = _gen.DigitalAssetMetadataType
"""A single ``<Track>`` element inside ``<Digital>`` — a choice of
exactly one of audio / video / subtitle / interactive."""

Container = _gen.ContainerMetadataType
"""A single ``<Container>`` element inside ``<Digital>`` —
groups related tracks under a packaging-level metadata wrapper."""

# Per-asset-data types — the typed bodies of the choices inside Track.
DigitalAssetVideo = _gen.DigitalAssetVideoDataType
"""Video-asset data: encoding, picture characteristics, watermarks."""

DigitalAssetAudio = _gen.DigitalAssetAudioDataType
"""Audio-asset data: encoding, language, MCA labels, loudness."""

DigitalAssetSubtitle = _gen.DigitalAssetSubtitleDataType
"""Subtitle-asset data: format, language, encoding."""

DigitalAssetImage = _gen.DigitalAssetImageDataType
"""Image-asset data: still images attached to a record."""

DigitalAssetInteractive = _gen.DigitalAssetInteractiveDataType
"""Interactive-asset data: HTML5/scripted experiences."""

DigitalAssetAncillary = _gen.DigitalAssetAncillaryDataType
"""Ancillary-asset data: closed captions, descriptive audio,
timed metadata not covered by the audio/video/subtitle types."""

# Multi-asset collection wrapper from the MD schema. Not directly
# wired into the EIDR record's ``<Digital>`` element (EIDR uses
# the Track/Container choice instead) but exposed here for callers
# working with raw MD-schema content outside the EIDR record path.
DigitalAssetSet = _gen.DigitalAssetSetType
"""MD-schema container for a collection of digital assets
(audio / video / subtitle / image / interactive / ancillary lists).
Not used by the EIDR record schema directly — see
:class:`DigitalTracks` for the EIDR-record digital wrapper."""


# Public names exported when callers do ``from eidr.models.digital import *``.
__all__ = [
    "Container",
    "DigitalAssetAncillary",
    "DigitalAssetAudio",
    "DigitalAssetImage",
    "DigitalAssetInteractive",
    "DigitalAssetSet",
    "DigitalAssetSubtitle",
    "DigitalAssetVideo",
    "DigitalTracks",
    "Track",
]
