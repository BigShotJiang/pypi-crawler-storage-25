"""Enums for the EIDR Content schema discriminator fields.

These are string enums carrying the controlled vocabularies used in
EIDR Content records. Using enums (rather than bare strings) gives:

* IDE autocomplete and typo protection
* Iteration over allowed values
* Clear documentation of the controlled vocabulary

All enums are :class:`str` subclasses, so they compare equal to their
string values and serialize transparently. ``CreationType.Basic == "Basic"``
is ``True``.

When a record carries a value not in the controlled vocabulary, the
codec preserves the raw string. The wrapper layer accepts both enum
members and raw strings on the way in.
"""

from __future__ import annotations

from enum import StrEnum

__all__ = [
    "CreationType",
    "Mode",
    "ReferentType",
    "Status",
    "StructuralType",
]


class CreationType(StrEnum):
    """The type of EIDR Content record.

    CreationTypes are mutually exclusive — a record has exactly one. The
    CreationType has a one-to-one correspondence with the presence of a
    matching ``ExtraObjectMetadata`` block (e.g., ``Series`` ↔ ``SeriesInfo``).

    ``Basic`` indicates no CreationType-specific block is present.

    ``Alias`` is used for records that point to another record (i.e., have
    a non-null ``target_id``); these are lightweight pointer records, not
    primary content records.
    """

    Basic = "Basic"
    Series = "Series"
    Season = "Season"
    Episode = "Episode"
    Edit = "Edit"
    Clip = "Clip"
    Manifestation = "Manifestation"
    Compilation = "Compilation"
    Alias = "Alias"


class ReferentType(StrEnum):
    """The kind of audiovisual work a Content record describes.

    Distinct from :class:`CreationType` (which describes the structural
    role) — ReferentType describes what the work *is* (Movie, TV episode,
    short, etc.). A record's ReferentType and CreationType are largely
    independent: a Movie can be a Basic, an Edit, a Manifestation, etc.
    """

    Movie = "Movie"
    TV = "TV"
    Web = "Web"
    Short = "Short"
    Series = "Series"
    Season = "Season"
    Compilation = "Compilation"
    Supplemental = "Supplemental"


class StructuralType(StrEnum):
    """How the record fits into the EIDR work-edit-manifestation hierarchy."""

    Abstraction = "Abstraction"
    """The conceptual work — the highest level (e.g., the movie idea)."""

    Performance = "Performance"
    """A specific Edit derived from the Abstraction (e.g., theatrical cut)."""

    Digital = "Digital"
    """A specific Manifestation — concrete digital encoding."""

    Restricted = "Restricted"
    """A record with restricted-access fields."""


class Mode(StrEnum):
    """The sensory mode of the audiovisual work."""

    AudioVisual = "AudioVisual"
    Audio = "Audio"
    Visual = "Visual"


class Status(StrEnum):
    """Lifecycle status of an EIDR record."""

    valid = "valid"
    invalid = "invalid"
    tombstoned = "tombstoned"
