"""Auto-generated EIDR/MovieLabs metadata model — DO NOT EDIT BY HAND.

Regenerated from the bundled EIDR XSD (`md-v28-eidr.xsd` and
imports) by ``tools/generate_digital.py``. To update, edit the
source schemas under ``src/eidr/schemas/bundled/`` and rerun
the generator. Hand-edits will be lost on next regen.

Despite the module name, the generated tree covers the entire
MovieLabs MD-v2.8 (EIDR profile) schema, not just the Digital
subtree. The Digital types are the headline use case for the
typed surface — see :mod:`eidr.models.digital` for the
developer-facing import — but the rest of the MD types are
available here too for callers that need them.

This module imports cleanly without any runtime work; it just
defines pydantic v2 model classes. Construction and validation
happen on demand when callers instantiate or assign to fields.
"""

# Schema manifest SHA-256: ce142e74cb08de16412dcab72dd2b87fb45e0fa01fab31b45070bf8daa180659
# (computed from src/eidr/schemas/bundled/MANIFEST.json at
# generation time; if this differs from the live manifest,
# the bundled XSDs have been edited without regeneration.)

# ruff: noqa
# mypy: ignore-errors
# fmt: off

from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import ForwardRef

from pydantic import BaseModel, ConfigDict
from xsdata.models.datatype import (
    XmlDate,
    XmlDateTime,
    XmlDuration,
    XmlPeriod,
    XmlTime,
)
from xsdata_pydantic.fields import field


class AgentRole(Enum):
    """
    Allowed values for roles played by a party as an agent of a Creation.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar ACTOR: A Performer of spoken (and sometimes silent) dramatic
        roles.
    :cvar AUTHOR: A Creator of a lexical work (words).
    :cvar COMPOSER: A Creator of a musical work.
    :cvar CORPORATE_CREATOR: An Organization credited as a Creator of a
        Creation.
    :cvar CREATOR: A creator of a Creation. This is a generic value
        which may be used when a more appropriate specific role (such as
        author or composer) is not available.
    :cvar DIRECTOR: A person responsible for the direction of Performers
        and other creative elements of a Creation.
    :cvar PUBLISHER: A Party making a Creation available to the public.
    """

    ACTOR = "Actor"
    AUTHOR = "Author"
    COMPOSER = "Composer"
    CORPORATE_CREATOR = "CorporateCreator"
    CREATOR = "Creator"
    DIRECTOR = "Director"
    PUBLISHER = "Publisher"


class AssociatedPartyRole(Enum):
    """
    Allowed values for a role associated with a party.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar AUTHOR: A party known as a creator of lexical works (words).
    :cvar BOOK_PUBLISHER: A party known for publishing books.
    :cvar COMPOSER: A party known as a creator of musical works.
    :cvar CORPORATE_CREATOR: An organization known for being credited as
        a creator of creations.
    :cvar CREATOR: A party known as a creator of creations. This is a
        generic value which may be used when a more appropriate specific
        role (such as author or composer) is not available.
    :cvar DIGITAL_SERVICE_PROVIDER: A party known for providing digital
        content through the internet, a telecom network or other means
        of carrier-less delivery.
    :cvar JOURNAL_PUBLISHER: A party known for publishing journals.
    :cvar VIDEO_SERVICE_PROVIDER: A party known for providing scheduled
        or on-demand video services (for example, audiovisual content
        delivered through tv, satellite, cable or internet media).
    """

    AUTHOR = "Author"
    BOOK_PUBLISHER = "BookPublisher"
    COMPOSER = "Composer"
    CORPORATE_CREATOR = "CorporateCreator"
    CREATOR = "Creator"
    DIGITAL_SERVICE_PROVIDER = "DigitalServiceProvider"
    JOURNAL_PUBLISHER = "JournalPublisher"
    VIDEO_SERVICE_PROVIDER = "VideoServiceProvider"


class Character(Enum):
    """
    Allowed values for the types of character in which the content of a
    referentCreation may be expressed.

    The values in this element are drawn from the RDA/ONIX Framework for
    Resource Categorization.

    :cvar IMAGE: Content expressed in line, shape, mass and/or other
        visually-realized forms.
    :cvar LANGUAGE: Content expressed in human or machine-readable
        language.
    :cvar MUSIC: Content expressed in musical notes.
    :cvar OTHER: Content expressed in a form other than language, music,
        or image. 'Other' includes other forms of communicating
        phenomena, qualities, etc., perceived directly through the human
        senses (for example, natural or machine-generated sounds,
        aromas, textures as well as those that cannot be perceived
        directly through the human senses (for example, electromagnetic
        waves).
    :cvar RESTRICTED: A Creation identified within a restricted DOI
        Application Profile for which kernel metadata values are not
        generally available.
    """

    IMAGE = "Image"
    LANGUAGE = "Language"
    MUSIC = "Music"
    OTHER = "Other"
    RESTRICTED = "Restricted"


class CreationIdentifierType1(Enum):
    """
    Allowed values for types of creationIdentifier.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar AD_ID: An Ad-ID, a 12-character identifier used by the
        advertising industry for identifying advertising assets,
        described at www.ad-id.org.
    :cvar AMG: An All Media Guide Identifier, an identifier for entities
        (artists, music, etc.) in the AMG database now maintained by
        Rovi.
    :cvar BASELINE: A Baseline Identifier, a 7-digit identifier for
        audiovisual works.
    :cvar C_IDF: A Content ID Forum Identifier (version 2.0 rev 1.1),
        specified at http://www.npo-ba.org/cid/cIDfSpecV2R11E.pdf.
    :cvar CRID: A Content Reference Identifier, an URI for content
        created by the TV-Anytime forum and described in RFC 4078.
    :cvar DOI: A DOI Name issued under the authority of the
        International DOI Foundation.
    :cvar EAN13: An International Article Number (formerly European
        Article Number), a 13-digit identifier for products.
    :cvar EDITION_NUMBER: An Identifier of a Creation which denotes its
        edition.
    :cvar EIDR_CONTENT_ID: An EIDR ID which identifies a Creation.
    :cvar GRID: A Global Release Identifier, an 18-character identifier
        for releases of music over electronic networks as defined by
        IFPI.
    :cvar IMDB_ID: An Internet Movie Database (IMDb) Movie ID, a 7-digit
        identifier for AudiovisualWorks issued by the IMDb.
    :cvar ISAN: An International Standard Audiovisual Number, the ISO
        Standard Identifier for AudiovisualWorks as defined in ISO
        15706.
    :cvar ISBN10: An International Standard Book Number, the ISO
        Standard Identifier for books as defined in ISO 2108, in its
        10-digit form. The isbn10 is now deprecated but is included in
        this schema for legacy purposes.
    :cvar ISBN13: An International Standard Book Number, the ISO
        Standard Identifier for books as defined in ISO 2108, in its
        13-digit form.
    :cvar ISRC: An International Standard Recording Code, the ISO
        Standard Identifier for SoundRecordings as defined in ISO 3901.
    :cvar ISSN: An International Standard Serial Number, the ISO
        Standard Identifier for published Serials as defined in ISO
        3297.
    :cvar ISTC: An International Standard Text Code, the ISO Standard
        Identifier for textual works as defined in ISO 21047.
    :cvar ISWC: An International Standard Musical Work Code, the ISO
        Standard Identifier for musical works as defined in ISO 15707.
    :cvar IVA: An Internet Video Archive Identifier, a 7-digit
        identifier for trailers, defined by the Internet Video Archive.
    :cvar MUZE: A MUZE Identifier, an 8-character identifier for music
        songs in the MUZE database now maintained by Rovi.
    :cvar PII: A Publisher Item Identifier, a 17-character identifier
        based on ISSN and ISBN that is used commonly by publishers for
        journal articles.
    :cvar PROPRIETARY_IDENTIFIER: An Identifier from a scheme which is
        proprietary to a particular party.
    :cvar SMPTE_UMID: A Unique Material Identifier, a 32-byte identifier
        for audiovisual Creations as defined in  SMPTE 330M-2004.
    :cvar TRIB: A Tribune Media Services Unique ID, a 14-character
        identifier for audiovisual works.
    :cvar TVG: A TV Guide Identifier, a 6-digit identifier for televised
        audiovisual works.
    :cvar UPC: A Universal Product Code, a 12-digit identifier for
        products.
    :cvar URI: A Uniform Resource Identifier, an identifier for
        WebResources as defined in IETF's RFC 3986.
    :cvar URN: A Uniform Resource Name, an identifier for WebResources
        as defined in IETF's RFC 2141.
    :cvar UUID: A Universally Unique Identifier, an identifier with 32
        hexadecimal digits for [Resources] described in  ITU-T Rec.
        X.667 and IETF RFC 4122.
    """

    AD_ID = "Ad-ID"
    AMG = "AMG"
    BASELINE = "Baseline"
    C_IDF = "cIDF"
    CRID = "CRID"
    DOI = "DOI"
    EAN13 = "EAN13"
    EDITION_NUMBER = "EditionNumber"
    EIDR_CONTENT_ID = "EidrContentID"
    GRID = "GRid"
    IMDB_ID = "IMDbID"
    ISAN = "ISAN"
    ISBN10 = "ISBN10"
    ISBN13 = "ISBN13"
    ISRC = "ISRC"
    ISSN = "ISSN"
    ISTC = "ISTC"
    ISWC = "ISWC"
    IVA = "IVA"
    MUZE = "MUZE"
    PII = "PII"
    PROPRIETARY_IDENTIFIER = "ProprietaryIdentifier"
    SMPTE_UMID = "SMPTE-UMID"
    TRIB = "TRIB"
    TVG = "TVG"
    UPC = "UPC"
    URI = "URI"
    URN = "URN"
    UUID = "UUID"


class CreationNameType(Enum):
    """
    Allowed Values for types of creationName.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar ABBREVIATED_TITLE: A Title which is a shortened form of
        another Title.
    :cvar DISTINCTIVE_TITLE: The Title by which a Creation is normally
        known.
    :cvar FORMER_TITLE: A Title by which a Creation was once known.
    :cvar NAME: A Name of a Creation.
    :cvar TITLE: A Title of a Creation.
    :cvar TRANSLATED_TITLE: A Title which is a translation of another
        Title.
    """

    ABBREVIATED_TITLE = "AbbreviatedTitle"
    DISTINCTIVE_TITLE = "DistinctiveTitle"
    FORMER_TITLE = "FormerTitle"
    NAME = "Name"
    TITLE = "Title"
    TRANSLATED_TITLE = "TranslatedTitle"


class CreationStructuralType(Enum):
    """
    Allowed values for a structuralType of a Creation.

    :cvar ABSTRACTION: A Creation which exists as a concept and is
        recognised only through one more more physical, digital or
        spatio-temporal Manifestations. An abstraction (sometimes known
        as a 'work' or 'abstract work') represents the content of a
        creation, regardless of the carrier or media in which it is
        expressed. For example, the play 'Hamlet' is an abstraction
        which has been expressed in many performances, printed books,
        films, broadcasts and more recently in digital media.
    :cvar DIGITAL: A Creation which is expressed in digital form. A
        digital creation is entirely made of digital bits and so may be
        perceived only through a computer or other intermediary device.
        For example, an audio CD is not itself a digital creation but a
        physical one, but it contains several digital creations (the
        individual tracks).
    :cvar PERFORMANCE: A Creation which is expressed in a transient
        form. A performance describes a 'spatio-temporal' creation, such
        as a speech, a play or the playing of a piece of music. It may
        be recorded for reproduction, but the creation itself is only
        perceivable in transient form.
    :cvar PHYSICAL: A Creation which is expressed in physical form.
    :cvar RESTRICTED: A Creation identified within a restricted DOI
        Application Profile for which kernel metadata values are not
        generally available.
    """

    ABSTRACTION = "Abstraction"
    DIGITAL = "Digital"
    PERFORMANCE = "Performance"
    PHYSICAL = "Physical"
    RESTRICTED = "Restricted"


class CreationToCreationLinkRole(Enum):
    """
    Allowed values for roles played by a Creation in relation to another
    Creation.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar ALTERNATE_CONTENT: A SupplementalResource in an AudioVisual
        Creation which is synchronized to the original Creation (for
        example, an alternate audio track or camera angle).
    :cvar CHAPTER: A Chapter of the linked Creation (that is, a formal
        subdivision of lexical Creation).
    :cvar CLIP: A short excerpt of a longer Audio or AudioVisual
        Creation, often made for promotional or preview purposes but
        which may also be made available commercially.
    :cvar CUE_SHEET: A Cue Sheet for the linked Creation (that is, a
        metadata file identifying Creations (typically music) which are
        included in a TVProgramme, CD, DVD or other Audio or AudioVisual
        Creation).
    :cvar DERIVATION: A Creation made, in whole or part, from the linked
        Creation. Derivation is the most general term to cover all forms
        of adaptation, versioning, performing, fixing and abstracting of
        one Creation from another, and can be used when the specific
        type of derived relationship is undefined or unclear.
    :cvar EDIT: A recorded Performance of a Film or other AudioVisual
        Creation. A Creation playing the role of Edit always has the
        structuralType of 'Performance'.
    :cvar EDITION: A published version of a textual or visual Creation
        in which some of the original form and/or content has been re-
        ordered, changed or omitted.
    :cvar EPISODE: An Episode of a linked Creation (that is, a Part of a
        Series broadcast as a single complete programme).
    :cvar FIXATION: A persistent Manifestation of the linked Creation.
        Fixations include all types of digital files or physical
        carriers on or in which content is fixed by digital or analogue
        methods.
    :cvar IS_SAME_AS: A Creation that is the same as the linked
        Creation.
    :cvar PART: A Creation that is part of (that is, wholly contained
        within) the linked Creation (for example, an illustration within
        a book, a volume of an encyclopaedia). This is a generic value
        which may be used when a more appropriate specific part role
        (such as chapter) is not available.
    :cvar PERFORMANCE: A Performance of the linked Creation (for
        example, a recorded performance of a musical work).
    :cvar PROMOTIONAL_RESOURCE: A Creation which promotes the use of the
        linked Creation.
    :cvar SEASON: A Season of the linked Series.
    :cvar SHARES_CONTENT: A Creation that shares some content with the
        linked Creation (for example, two books which have common
        Chapters, or a TV show that contains an excerpt of a Film).
    :cvar SUPPLEMENTAL_RESOURCE: A Creation which accompanies the linked
        Creation (this includes, for example, all kinds of preface or
        epilogue in a textual Creation, or trailers or outtakes in an
        Audiovisual Creation).
    :cvar TAKES_CONTENT: A Creation that contains content coming from
        one or more places in the linked Creation (for example, a text
        which contains some paragraphs from a pre-existing text). The
        content may or may not be identified as a distinct Part.
    :cvar TRANSLATION: A Translation of the linked Creation (that is,
        whose words are expressed in a different language from its
        Source).
    :cvar UNDEFINED: A Creation with a relationship with the linked
        Creation which is unknown or not covered by the available
        options.
    :cvar VERSION: A Version of the linked Creation (that is, a version
        which updates and replaces the previous version).
    """

    ALTERNATE_CONTENT = "AlternateContent"
    CHAPTER = "Chapter"
    CLIP = "Clip"
    CUE_SHEET = "CueSheet"
    DERIVATION = "Derivation"
    EDIT = "Edit"
    EDITION = "Edition"
    EPISODE = "Episode"
    FIXATION = "Fixation"
    IS_SAME_AS = "IsSameAs"
    PART = "Part"
    PERFORMANCE = "Performance"
    PROMOTIONAL_RESOURCE = "PromotionalResource"
    SEASON = "Season"
    SHARES_CONTENT = "SharesContent"
    SUPPLEMENTAL_RESOURCE = "SupplementalResource"
    TAKES_CONTENT = "TakesContent"
    TRANSLATION = "Translation"
    UNDEFINED = "Undefined"
    VERSION = "Version"


class CreationType(Enum):
    """
    Allowed Values for types of Creation.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar ARTICLE: A non-fictional text in prose form (typically between
        a few paragraphs and a few pages in length) included with others
        in a Publication to provide information and/or opinion.
    :cvar BLOG: A blog (weblog) on a website.
    :cvar BLOG_ENTRY: An entry in a Blog.
    :cvar BOOK: A non serial Creation, capable of being expressed in
        printed form with multiple bound pages and covers, published
        with a distinct Title and not as part of another Publication
        unless it is set of similar Resources. A DOI applied at this
        level may refer to a Book which appears in physical, digital and
        audio forms.
    :cvar BOOK_CHAPTER: A Chapter of a Book.
    :cvar BOOK_SERIES: A Series of Books.
    :cvar CHAPTER: A formal subdivision of a lexical Creation.
    :cvar CLINICAL_TRIAL_PROTOCOL: A chronological Report on a series of
        events which is a part of a clinical trial.
    :cvar CLIP: A short excerpt of a longer Audio or AudioVisual
        Creation, often made for promotional or preview purposes but
        which may also be made available commercially.
    :cvar CONFERENCE_PROCEEDINGS: A Publication consisting of
        contributions presented at a conference.
    :cvar CONFERENCE_PROCEEDINGS_SERIES: A Series of
        ConferenceProceedings.
    :cvar COURSE_PACK: A collection of journal articles, BookChapters
        and/or other components making up reading materials for an
        academic course.
    :cvar CRYSTAL_STRUCTURE: A Dataset describing the structure of a
        crystal.
    :cvar CUE_SHEET: A metadata file identifying Creations (typically
        music) which are included in a TVProgramme, CD, DVD or other
        Audio or AudioVisual Creation.
    :cvar DATASET: A Set of numeric and related data (typically
        associated with scientific research).
    :cvar DICTIONARY_ENTRY: An entry in a dictionary.
    :cvar EBOOK: A Book published in downloadable digital form.
    :cvar ENCYCLOPAEDIA_ENTRY: An entry in an encyclopaedia.
    :cvar FIGURE: An image, table or other graphical feature which is an
        integral part of a lexical work.
    :cvar FILM: An AudioVisual Creation, normally of at least 40 minutes
        duration, first played in a movie theatre (in the US) or a
        cinema (in most of the rest of the world), or released directly
        to video.
    :cvar INTERACTIVE_RESOURCE: A Visual Creation not intended to be
        viewed in linear fashion (for example, DVD menus, interactive TV
        overlays, customized players).
    :cvar JOURNAL: A Periodical principally consisting of Articles
        contributed by expert authors, with a specific theme, subject
        area and target audience, normally of a scholarly, scientific
        and/or technical nature.
    :cvar JOURNAL_ARTICLE: An Article in a Journal.
    :cvar JOURNAL_ISSUE: A collection of Articles published together in
        one or more fixations representing a single issue of a Journal.
        Typically a journal issue will be identified with a specific
        date of publication.
    :cvar JOURNAL_VOLUME: A numbered Set of JournalIssues, normally
        representing the issues published in a specific period such as a
        calendar year.
    :cvar LEARNING_OBJECT: A Resource for use in teaching and learning.
    :cvar MEDICAL_CASE_REPORT: A Report on a medical case.
    :cvar MOVING_IMAGE: A moving Image.
    :cvar PERIODICAL: A Serial whose issues normally are published at
        regular intervals.
    :cvar PRINTED_BOOK: A Book published in printed form.
    :cvar REPORT: A lexical Creation containing statements about
        event(s) or state(s) in the past or present.
    :cvar REPORT_CHAPTER: A Chapter of a Report.
    :cvar REPORT_SERIES: A Series of Reports.
    :cvar RESTRICTED: A Creation identified within a restricted DOI
        Application Profile for which kernel metadata values are not
        generally available.
    :cvar SEASON: A sub-grouping of an Audio or AudioVisual Series.
    :cvar SERIAL: A Creation whose parts are published sequentially in
        time.
    :cvar SERIAL_ISSUE: A collection of Articles published together in
        one or more fixations representing a single issue of a Serial.
        Typically a serial issue will be identified with a specific date
        of publication.
    :cvar SERIES: A Set of related Creations published sequentially,
        typically under some common Name.
    :cvar SHORT_FILM: A complete AudioVisual Creation (that is, not a
        Clip or Excerpt), of no more than 40 minutes duration, that was
        not made for television.
    :cvar STANDARD: A formal standard adopted by ISO or another
        recognized standards body.
    :cvar STANDARD_SERIES: A Series of Standards.
    :cvar STILL_IMAGE: A still Image.
    :cvar SUPPLEMENTAL_RESOURCE: A Creation which accompanies another
        Creation (this includes, for example, all kinds of preface or
        epilogue in a textual Creation, or trailers or outtakes in an
        Audiovisual Creation).
    :cvar THESIS: A lexical Creation written for the attainment of a
        degree or award from an academic institution.
    :cvar TV_PROGRAMME: An AudioVisual Creation made for, or first
        broadcast on, television.
    :cvar WEB_RESOURCE: A Creation made for, or first published on, the
        World Wide Web.
    :cvar WEBSITE: A website.
    """

    ARTICLE = "Article"
    BLOG = "Blog"
    BLOG_ENTRY = "BlogEntry"
    BOOK = "Book"
    BOOK_CHAPTER = "BookChapter"
    BOOK_SERIES = "BookSeries"
    CHAPTER = "Chapter"
    CLINICAL_TRIAL_PROTOCOL = "ClinicalTrialProtocol"
    CLIP = "Clip"
    CONFERENCE_PROCEEDINGS = "ConferenceProceedings"
    CONFERENCE_PROCEEDINGS_SERIES = "ConferenceProceedingsSeries"
    COURSE_PACK = "CoursePack"
    CRYSTAL_STRUCTURE = "CrystalStructure"
    CUE_SHEET = "CueSheet"
    DATASET = "Dataset"
    DICTIONARY_ENTRY = "DictionaryEntry"
    EBOOK = "Ebook"
    ENCYCLOPAEDIA_ENTRY = "EncyclopaediaEntry"
    FIGURE = "Figure"
    FILM = "Film"
    INTERACTIVE_RESOURCE = "InteractiveResource"
    JOURNAL = "Journal"
    JOURNAL_ARTICLE = "JournalArticle"
    JOURNAL_ISSUE = "JournalIssue"
    JOURNAL_VOLUME = "JournalVolume"
    LEARNING_OBJECT = "LearningObject"
    MEDICAL_CASE_REPORT = "MedicalCaseReport"
    MOVING_IMAGE = "MovingImage"
    PERIODICAL = "Periodical"
    PRINTED_BOOK = "PrintedBook"
    REPORT = "Report"
    REPORT_CHAPTER = "ReportChapter"
    REPORT_SERIES = "ReportSeries"
    RESTRICTED = "Restricted"
    SEASON = "Season"
    SERIAL = "Serial"
    SERIAL_ISSUE = "SerialIssue"
    SERIES = "Series"
    SHORT_FILM = "ShortFilm"
    STANDARD = "Standard"
    STANDARD_SERIES = "StandardSeries"
    STILL_IMAGE = "StillImage"
    SUPPLEMENTAL_RESOURCE = "SupplementalResource"
    THESIS = "Thesis"
    TV_PROGRAMME = "TvProgramme"
    WEB_RESOURCE = "WebResource"
    WEBSITE = "Website"


class Mode(Enum):
    """
    Allowed values for sensory modes with which a Creation is intended to
    be perceived.

    If the creation is an abstraction, this value may be used to refer to
    the mode in which manifestations of the abstraction can be expressed.
    For example, a musical work is abstraction that may be expressed in a
    performance (audio), in notational form (visual) or in braille notation
    (tangible).

    :cvar AUDIO: Of a Creation which is intended to be listened to.
    :cvar OLFACTORY: Of a Creation which is intended to be smelled.
    :cvar RESTRICTED: A Creation identified within a restricted DOI
        Application Profile for which kernel metadata values are not
        generally available.
    :cvar TANGIBLE: Of a Creation which is intended to be touched.
    :cvar TASTEABLE: Of a Creation which is intended to be tasted.
    :cvar VISUAL: Of a Creation which is intended to be looked at.
    """

    AUDIO = "Audio"
    OLFACTORY = "Olfactory"
    RESTRICTED = "Restricted"
    TANGIBLE = "Tangible"
    TASTEABLE = "Tasteable"
    VISUAL = "Visual"


class PartyIdentifierType(Enum):
    """
    Allowed values for types of partyIdentifier.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar DOI: A DOI Name issued under the authority of the
        International DOI Foundation.
    :cvar EIDRPARTY_ID: An EIDR ID which identifies a Party.
    :cvar IPNUMBER: An Interested Party Number, an identifier for
        Parties issued under the governance of CISAC. Formerly known as
        the CAE (Compositeur, Auteur, Editeur) Number.
    :cvar ISNI: An International Standard Name Identifier, the ISO
        Standard Identifier for Parties as defined in ISO 27729.
    :cvar PROPRIETARY_IDENTIFIER: An Identifier from a scheme which is
        proprietary to a particular party.
    """

    DOI = "DOI"
    EIDRPARTY_ID = "EIDRPartyID"
    IPNUMBER = "IPNumber"
    ISNI = "ISNI"
    PROPRIETARY_IDENTIFIER = "ProprietaryIdentifier"


class PartyNameType(Enum):
    """
    Allowed values for types of partyName.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar ABBREVIATED_NAME: A shortened form of a Name (which may be an
        acronym, in whole or in part) by which a party is known.
    :cvar FORMER_NAME: A Name by which a party was previously known.
    :cvar NAME: A Name by which a party is known.
    :cvar PRINCIPAL_NAME: The Name by which a party is principally
        known.
    """

    ABBREVIATED_NAME = "AbbreviatedName"
    FORMER_NAME = "FormerName"
    NAME = "Name"
    PRINCIPAL_NAME = "PrincipalName"


class PartyStructuralType(Enum):
    """
    Allowed values for the primary type of a referent.

    :cvar ANIMAL: A non-human animal. Animals may require identification
        for many reasons: for example, as performers ('Lassie').
    :cvar INDIVIDUAL: An individual human being, real or imaginary, or
        an imaginary Party attributed with characteristics of a human
        being (for example, Homer Simpson, Mickey Mouse). Individuals
        may be real, legendary or imaginary, and do not need to be
        biologically unique. Personas adopted for artistic or other
        purposes may be referenced with DOIs as unique individuals. For
        example, the authors 'Ellis Peters' 'John Redfern' 'Jolyon Carr'
        and 'Peter Benedict' may be identified as a unique parties
        distinct from the person 'Edith Pargeter', for whom they are all
        pen-name pseudonyms. 'Mickey Mouse' may be identified as an
        individual for the purpose of unique identification as a
        performer in a creation, or 'Borat' or 'Hamlet' for the
        identification of a character depicted in a fictional work.
    :cvar ORGANIZATION: A Party which is either a legal person such as a
        corporation or legal partnership (but not a human being); or a
        group of Individuals, or a group of organizations. Organizations
        include all groupings of two or more parties, as well as legally
        defined, non-human parties.
    """

    ANIMAL = "Animal"
    INDIVIDUAL = "Individual"
    ORGANIZATION = "Organization"


class PartyToPartyLinkRole(Enum):
    """
    Allowed values for a role which one party plays in a link to another
    party.

    Where roles have complementary pairs (for example, parent-child or
    member-memberOrganization) only one of these is included in this list,
    and this role should be associated in the linkedParty element with the
    appropriate party.

    :cvar CORPORATE_SUBSIDIARY: An Organization which is a subsidiary of
        another Organization.
    :cvar DIVISION_OR_DEPARTMENT: An Organization which is a division or
        department of another Organization.
    :cvar MARRIAGE_PARTNER: An Individual who is married to another
        Individual.
    :cvar MEMBER: A Party which is a member of an Organization.
    :cvar PARENT: An Individual who is the parent of another Individual.
    :cvar SIBLING: An Individual who is a brother or sister of another
        Individual.
    """

    CORPORATE_SUBSIDIARY = "CorporateSubsidiary"
    DIVISION_OR_DEPARTMENT = "DivisionOrDepartment"
    MARRIAGE_PARTNER = "MarriagePartner"
    MEMBER = "Member"
    PARENT = "Parent"
    SIBLING = "Sibling"


class PrimaryReferentType(Enum):
    """
    Allowed values for the primary type of a referent.

    :cvar CREATION: A Resource made, directly or indirectly, by one or
        more human beings.
    :cvar PARTY: An individual person, animal or organization capable of
        acting, or being perceived to act, as an agent. Parties may be
        real, legendary or imaginary, and do not need to be biologically
        unique. Personas adopted for artistic or other purposes may be
        referenced with DOIs as unique individuals. For example, the
        authors 'Ellis Peters' 'John Redfern' 'Jolyon Carr' and 'Peter
        Benedict' may be identified as a unique parties distinct from
        the person 'Edith Pargeter', for whom they are all pen-name
        pseudonyms. 'Mickey Mouse' may be identified as an individual
        for the purpose of unique identification as a performer in a
        creation, or 'Borat' or 'Hamlet' for the identification of a
        character depicted in a fictional work.
    """

    CREATION = "Creation"
    PARTY = "Party"


class ReturnType(Enum):
    """
    Allowed values for resource types (e.g.

    MIME types).

    :cvar APPLICATION_RDF_XML: application/rdf+xml
    :cvar APPLICATION_XML: application/xml
    :cvar TEXT_HTML: text/html
    :cvar TEXT_XML: text/xml
    """

    APPLICATION_RDF_XML = "application/rdf+xml"
    APPLICATION_XML = "application/xml"
    TEXT_HTML = "text/html"
    TEXT_XML = "text/xml"


class SequenceIdentifierType1(Enum):
    """
    Allowed values for types of sequenceIdentifier.

    This is an open set. Other values may be registered with the IDF by any
    Registration Authority.

    :cvar PAGE_NUMBER: A SequenceIdentifier identifying a page in a
        containing creation, e.g. in a book or in a journal, on which a
        contained creation, e.g. a chapter or an article, starts.
    :cvar PROPRIETARY_IDENTIFIER: An Identifier from a scheme which is
        proprietary to a particular party.
    """

    PAGE_NUMBER = "PageNumber"
    PROPRIETARY_IDENTIFIER = "ProprietaryIdentifier"


class TerritoryCode(Enum):
    """
    Allowed values for Territories not included in the ISO 3166-1 list.

    :cvar AD: Andorra.
    :cvar AE: The United Arab Emirates.
    :cvar AF: Afghanistan.
    :cvar AG: Antigua and Barbuda.
    :cvar AI: Anguilla.
    :cvar AL: Albania.
    :cvar AM: Armenia.
    :cvar AO: Angola.
    :cvar AQ: Antarctica.
    :cvar AR: Argentina.
    :cvar AS: American Samoa.
    :cvar AT: Austria.
    :cvar AU: Australia.
    :cvar AW: Aruba.
    :cvar AX: Aaland Islands.
    :cvar AZ: Azerbaijan.
    :cvar BA: Bosnia and Herzegovina.
    :cvar BB: Barbados.
    :cvar BD: Bangladesh.
    :cvar BE: Belgium.
    :cvar BF: Burkina Faso.
    :cvar BG: Bulgaria.
    :cvar BH: Bahrain.
    :cvar BI: Burundi.
    :cvar BJ: Benin.
    :cvar BL: Saint Barthelemy.
    :cvar BM: Bermuda.
    :cvar BN: Brunei.
    :cvar BO: Bolivia.
    :cvar BQ: Bonaire, Sint Eustatius and Saba.
    :cvar BR: Brazil.
    :cvar BS: The Bahamas.
    :cvar BT: Bhutan.
    :cvar BV: Bouvet Island.
    :cvar BW: Botswana.
    :cvar BY: Belarus.
    :cvar BZ: Belize.
    :cvar CA: Canada.
    :cvar CC: Cocos Islands.
    :cvar CD: The Democratic Republic of the Congo.
    :cvar CF: The Central African Republic.
    :cvar CG: The Congo.
    :cvar CH: Switzerland.
    :cvar CI: Cote d'Ivoire.
    :cvar CK: Cook Islands.
    :cvar CL: Chile.
    :cvar CM: Cameroon.
    :cvar CN: China.
    :cvar CO: Colombia.
    :cvar CR: Costa Rica.
    :cvar CU: Cuba.
    :cvar CW: Curacao.
    :cvar CV: Cape Verde.
    :cvar CX: Christmas Island.
    :cvar CY: Cyprus.
    :cvar CZ: Czechia.
    :cvar DE: Germany.
    :cvar DJ: Djibouti.
    :cvar DK: Denmark.
    :cvar DM: Dominica.
    :cvar DO: The Dominican Republic.
    :cvar DZ: Algeria.
    :cvar EC: Ecuador.
    :cvar EE: Estonia.
    :cvar EG: Egypt.
    :cvar EH: Western Sahara.
    :cvar ER: Eritrea.
    :cvar ES: Spain.
    :cvar ET: Ethiopia.
    :cvar FI: Finland.
    :cvar FJ: Fiji.
    :cvar FK: Falkland Islands.
    :cvar FM: Micronesia.
    :cvar FO: Faroe Islands.
    :cvar FR: France.
    :cvar GA: Gabon.
    :cvar GB: The United Kingdom.
    :cvar GD: Grenada.
    :cvar GE: Georgia.
    :cvar GF: French Guiana.
    :cvar GG: Guernsey.
    :cvar GH: Ghana.
    :cvar GI: Gibraltar.
    :cvar GL: Greenland.
    :cvar GM: The Gambia.
    :cvar GN: Guinea.
    :cvar GP: Guadeloupe.
    :cvar GQ: Equatorial Guinea.
    :cvar GR: Greece.
    :cvar GS: South Georgia and The South Sandwich Islands.
    :cvar GT: Guatemala.
    :cvar GU: Guam.
    :cvar GW: Guinea-Bissau.
    :cvar GY: Guyana.
    :cvar HK: Hong Kong.
    :cvar HM: Heard Island and McDonald Islands.
    :cvar HN: Honduras.
    :cvar HR: Croatia.
    :cvar HT: Haiti.
    :cvar HU: Hungary.
    :cvar ID: Indonesia.
    :cvar IE: Ireland.
    :cvar IL: Israel.
    :cvar IM: Isle of Man.
    :cvar IN: India.
    :cvar IO: The British Indian Ocean Territory.
    :cvar IQ: Iraq.
    :cvar IR: Iran.
    :cvar IS: Iceland.
    :cvar IT: Italy.
    :cvar JE: Jersey.
    :cvar JM: Jamaica.
    :cvar JO: Jordan.
    :cvar JP: Japan.
    :cvar KE: Kenya.
    :cvar KG: Kyrgyzstan.
    :cvar KH: Cambodia.
    :cvar KI: Kiribati.
    :cvar KM: The Comoros.
    :cvar KN: Saint Kitts and Nevis.
    :cvar KP: The Democratic People's Republic of Korea.
    :cvar KR: The Republic of Korea.
    :cvar KW: Kuwait.
    :cvar KY: Cayman Islands.
    :cvar KZ: Kazakhstan.
    :cvar LA: Laos.
    :cvar LB: Lebanon.
    :cvar LC: Saint Lucia.
    :cvar LI: Liechtenstein.
    :cvar LK: Sri Lanka.
    :cvar LR: Liberia.
    :cvar LS: Lesotho.
    :cvar LT: Lithuania.
    :cvar LU: Luxembourg.
    :cvar LV: Latvia.
    :cvar LY: Libya.
    :cvar MA: Morocco.
    :cvar MC: Monaco.
    :cvar MD: Moldova.
    :cvar ME: Montenegro.
    :cvar MF: Saint Martin.
    :cvar MG: Madagascar.
    :cvar MH: The Marshall Islands.
    :cvar MK: North Macedonia.
    :cvar ML: Mali.
    :cvar MM: Myanmar.
    :cvar MN: Mongolia.
    :cvar MO: Macao.
    :cvar MP: Northern Mariana Islands.
    :cvar MQ: Martinique.
    :cvar MR: Mauritania.
    :cvar MS: Montserrat.
    :cvar MT: Malta.
    :cvar MU: Mauritius.
    :cvar MV: Maldives.
    :cvar MW: Malawi.
    :cvar MX: Mexico.
    :cvar MY: Malaysia.
    :cvar MZ: Mozambique.
    :cvar NA: Namibia.
    :cvar NC: New Caledonia.
    :cvar NE: The Niger.
    :cvar NF: Norfolk Island.
    :cvar NG: Nigeria.
    :cvar NI: Nicaragua.
    :cvar NL: The Netherlands.
    :cvar NO: Norway.
    :cvar NP: Nepal.
    :cvar NR: Nauru.
    :cvar NU: Niue.
    :cvar NZ: New Zealand.
    :cvar OM: Oman.
    :cvar PA: Panama.
    :cvar PE: Peru.
    :cvar PF: French Polynesia.
    :cvar PG: Papua New Guinea.
    :cvar PH: The Philippines.
    :cvar PK: Pakistan.
    :cvar PL: Poland.
    :cvar PM: Saint Pierre and Miquelon.
    :cvar PN: Pitcairn.
    :cvar PR: Puerto Rico.
    :cvar PS: Palestine, State of.
    :cvar PT: Portugal.
    :cvar PW: Palau.
    :cvar PY: Paraguay.
    :cvar QA: Qatar.
    :cvar RE: Reunion.
    :cvar RO: Romania.
    :cvar RS: Serbia.
    :cvar RU: Russia.
    :cvar RW: Rwanda.
    :cvar SA: Saudi Arabia.
    :cvar SB: Solomon Islands.
    :cvar SC: Seychelles.
    :cvar SD: The Sudan.
    :cvar SE: Sweden.
    :cvar SG: Singapore.
    :cvar SH: Saint Helena.
    :cvar SI: Slovenia.
    :cvar SJ: Svalbard and Jan Mayen.
    :cvar SK: Slovakia.
    :cvar SL: Sierra Leone.
    :cvar SM: San Marino.
    :cvar SN: Senegal.
    :cvar SO: Somalia.
    :cvar SR: Suriname.
    :cvar SS: South Sudan.
    :cvar ST: Sao Tome and Principe.
    :cvar SV: El Salvador.
    :cvar SX: Sint Maarten.
    :cvar SY: Syria.
    :cvar SZ: Eswatini.
    :cvar TC: Turks and Caicos Islands.
    :cvar TD: Chad.
    :cvar TF: The French Southern Territories.
    :cvar TG: Togo.
    :cvar TH: Thailand.
    :cvar TJ: Tajikistan.
    :cvar TK: Tokelau.
    :cvar TL: Timor-Leste.
    :cvar TM: Turkmenistan.
    :cvar TN: Tunisia.
    :cvar TO: Tonga.
    :cvar TR: Turkey.
    :cvar TT: Trinidad and Tobago.
    :cvar TV: Tuvalu.
    :cvar TW: Taiwan (Province of China).
    :cvar TZ: Tanzania.
    :cvar UA: Ukraine.
    :cvar UG: Uganda.
    :cvar UM: United States Minor Outlying Islands.
    :cvar US: The United States.
    :cvar UY: Uruguay.
    :cvar UZ: Uzbekistan.
    :cvar VA: The Holy See.
    :cvar VC: Saint Vincent and The Grenadines.
    :cvar VE: Venezuela.
    :cvar VG: British Virgin Islands.
    :cvar VI: US Virgin Islands.
    :cvar VN: Viet Nam.
    :cvar VU: Vanuatu.
    :cvar WF: Wallis and Futuna.
    :cvar WS: Samoa.
    :cvar XX: Country unknown.
    :cvar YE: Yemen.
    :cvar YT: Mayotte.
    :cvar ZA: South Africa.
    :cvar ZM: Zambia.
    :cvar ZW: Zimbabwe.
    :cvar ANHH: Netherlands Antilles.
    :cvar CSH: Czechoslovakia.
    :cvar CSHH: Czechoslovakia.
    :cvar DD: German Democratic Republic.
    :cvar DDDE: German Democratic Republic.
    :cvar SCG: Serbia and Montenegro.
    :cvar CSXX: Serbia and Montenegro.
    :cvar SU: USSR.
    :cvar SUHH: USSR.
    :cvar VD: Vietnam, Democratic Republic of.
    :cvar VDVN: Vietnam, Democratic Republic of.
    :cvar YD: Yemen, Democratic (South Yemen).
    :cvar YDYE: Yemen, Democratic (South Yemen).
    :cvar YU: Yugoslavia.
    :cvar YUCS: Yugoslavia.
    :cvar XK: Kosovo.
    """

    AD = "AD"
    AE = "AE"
    AF = "AF"
    AG = "AG"
    AI = "AI"
    AL = "AL"
    AM = "AM"
    AO = "AO"
    AQ = "AQ"
    AR = "AR"
    AS = "AS"
    AT = "AT"
    AU = "AU"
    AW = "AW"
    AX = "AX"
    AZ = "AZ"
    BA = "BA"
    BB = "BB"
    BD = "BD"
    BE = "BE"
    BF = "BF"
    BG = "BG"
    BH = "BH"
    BI = "BI"
    BJ = "BJ"
    BL = "BL"
    BM = "BM"
    BN = "BN"
    BO = "BO"
    BQ = "BQ"
    BR = "BR"
    BS = "BS"
    BT = "BT"
    BV = "BV"
    BW = "BW"
    BY = "BY"
    BZ = "BZ"
    CA = "CA"
    CC = "CC"
    CD = "CD"
    CF = "CF"
    CG = "CG"
    CH = "CH"
    CI = "CI"
    CK = "CK"
    CL = "CL"
    CM = "CM"
    CN = "CN"
    CO = "CO"
    CR = "CR"
    CU = "CU"
    CW = "CW"
    CV = "CV"
    CX = "CX"
    CY = "CY"
    CZ = "CZ"
    DE = "DE"
    DJ = "DJ"
    DK = "DK"
    DM = "DM"
    DO = "DO"
    DZ = "DZ"
    EC = "EC"
    EE = "EE"
    EG = "EG"
    EH = "EH"
    ER = "ER"
    ES = "ES"
    ET = "ET"
    FI = "FI"
    FJ = "FJ"
    FK = "FK"
    FM = "FM"
    FO = "FO"
    FR = "FR"
    GA = "GA"
    GB = "GB"
    GD = "GD"
    GE = "GE"
    GF = "GF"
    GG = "GG"
    GH = "GH"
    GI = "GI"
    GL = "GL"
    GM = "GM"
    GN = "GN"
    GP = "GP"
    GQ = "GQ"
    GR = "GR"
    GS = "GS"
    GT = "GT"
    GU = "GU"
    GW = "GW"
    GY = "GY"
    HK = "HK"
    HM = "HM"
    HN = "HN"
    HR = "HR"
    HT = "HT"
    HU = "HU"
    ID = "ID"
    IE = "IE"
    IL = "IL"
    IM = "IM"
    IN = "IN"
    IO = "IO"
    IQ = "IQ"
    IR = "IR"
    IS = "IS"
    IT = "IT"
    JE = "JE"
    JM = "JM"
    JO = "JO"
    JP = "JP"
    KE = "KE"
    KG = "KG"
    KH = "KH"
    KI = "KI"
    KM = "KM"
    KN = "KN"
    KP = "KP"
    KR = "KR"
    KW = "KW"
    KY = "KY"
    KZ = "KZ"
    LA = "LA"
    LB = "LB"
    LC = "LC"
    LI = "LI"
    LK = "LK"
    LR = "LR"
    LS = "LS"
    LT = "LT"
    LU = "LU"
    LV = "LV"
    LY = "LY"
    MA = "MA"
    MC = "MC"
    MD = "MD"
    ME = "ME"
    MF = "MF"
    MG = "MG"
    MH = "MH"
    MK = "MK"
    ML = "ML"
    MM = "MM"
    MN = "MN"
    MO = "MO"
    MP = "MP"
    MQ = "MQ"
    MR = "MR"
    MS = "MS"
    MT = "MT"
    MU = "MU"
    MV = "MV"
    MW = "MW"
    MX = "MX"
    MY = "MY"
    MZ = "MZ"
    NA = "NA"
    NC = "NC"
    NE = "NE"
    NF = "NF"
    NG = "NG"
    NI = "NI"
    NL = "NL"
    NO = "NO"
    NP = "NP"
    NR = "NR"
    NU = "NU"
    NZ = "NZ"
    OM = "OM"
    PA = "PA"
    PE = "PE"
    PF = "PF"
    PG = "PG"
    PH = "PH"
    PK = "PK"
    PL = "PL"
    PM = "PM"
    PN = "PN"
    PR = "PR"
    PS = "PS"
    PT = "PT"
    PW = "PW"
    PY = "PY"
    QA = "QA"
    RE = "RE"
    RO = "RO"
    RS = "RS"
    RU = "RU"
    RW = "RW"
    SA = "SA"
    SB = "SB"
    SC = "SC"
    SD = "SD"
    SE = "SE"
    SG = "SG"
    SH = "SH"
    SI = "SI"
    SJ = "SJ"
    SK = "SK"
    SL = "SL"
    SM = "SM"
    SN = "SN"
    SO = "SO"
    SR = "SR"
    SS = "SS"
    ST = "ST"
    SV = "SV"
    SX = "SX"
    SY = "SY"
    SZ = "SZ"
    TC = "TC"
    TD = "TD"
    TF = "TF"
    TG = "TG"
    TH = "TH"
    TJ = "TJ"
    TK = "TK"
    TL = "TL"
    TM = "TM"
    TN = "TN"
    TO = "TO"
    TR = "TR"
    TT = "TT"
    TV = "TV"
    TW = "TW"
    TZ = "TZ"
    UA = "UA"
    UG = "UG"
    UM = "UM"
    US = "US"
    UY = "UY"
    UZ = "UZ"
    VA = "VA"
    VC = "VC"
    VE = "VE"
    VG = "VG"
    VI = "VI"
    VN = "VN"
    VU = "VU"
    WF = "WF"
    WS = "WS"
    XX = "XX"
    YE = "YE"
    YT = "YT"
    ZA = "ZA"
    ZM = "ZM"
    ZW = "ZW"
    ANHH = "ANHH"
    CSH = "CSH"
    CSHH = "CSHH"
    DD = "DD"
    DDDE = "DDDE"
    SCG = "SCG"
    CSXX = "CSXX"
    SU = "SU"
    SUHH = "SUHH"
    VD = "VD"
    VDVN = "VDVN"
    YD = "YD"
    YDYE = "YDYE"
    YU = "YU"
    YUCS = "YUCS"
    XK = "XK"


class TimeProximity(Enum):
    """
    Allowed values for the proximity of a declared time to the actual time
    referenced.

    A null value indicates that the date is accurate.

    :cvar AFTER: A time which is after the time stated.
    :cvar BEFORE: A time which is before the time stated.
    :cvar CIRCA: A time which is approximately accurate.
    :cvar NOT_AFTER: A time which is the same as or before the time
        stated.
    :cvar NOT_BEFORE: A time which is the same as or after the time
        stated.
    """

    AFTER = "After"
    BEFORE = "Before"
    CIRCA = "Circa"
    NOT_AFTER = "NotAfter"
    NOT_BEFORE = "NotBefore"


class PartyAccountName(BaseModel):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"[0-9a-zA-Z_# \.\-\(\)]{2,64}",
        },
    )


class Username(BaseModel):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        },
    )


class AdministratorTypeType(Enum):
    """
    See Chapter 7 of the spec for details on these.

    :cvar ASSOCIATED_ORG: Identifies a party that can be listed as an
        AssociatedOrg for an asset.
    :cvar REGISTRANT: Identifies a party that is registering or has
        registered a work
    :cvar METADATA_AUTHORITY: Identifies a party who has asserted that
        they possess complete and correct metadata for the record and
        who has agreed to maintain the record.
    :cvar ENCODING_AGENT: Identifies a partythat can be listed as
        EncodingAgent for a regustered encoding
    :cvar WRITER: Identifies a party that can write to objects, but not
        create, delete, or promote them -- e.g. a clean-up crew
    :cvar READER: Identifies a party that is allowed to see information
        that would otherwise be hidden
    :cvar SERVICE_ADMIN: Identifies a party that is allowed to create,
        modify, delete, or alias video services information
    :cvar ALT_IDWRITER: Identifies a party that is allowed to modify
        AlternateID information on any record
    """

    ASSOCIATED_ORG = "AssociatedOrg"
    REGISTRANT = "Registrant"
    METADATA_AUTHORITY = "MetadataAuthority"
    ENCODING_AGENT = "EncodingAgent"
    WRITER = "Writer"
    READER = "Reader"
    SERVICE_ADMIN = "ServiceAdmin"
    ALT_IDWRITER = "AltIDWriter"


class AlternateContentClassType(Enum):
    ALTERNATE_SCENE = "Alternate Scene"
    CAMERA_ANGLE = "Camera Angle"
    CENSORED = "Censored"
    COMMENTARY_DIRECTOR = "Commentary (Director)"
    COMMENTARY_OTHER = "Commentary (Other)"
    DESCRIPTIVE_AUDIO = "Descriptive Audio"
    PARENTAL_CONTROL = "Parental Control"
    SING_ALONG = "Sing Along"
    TRIVIA_TRACK = "Trivia Track"
    OTHER = "Other"


class AlternateIdrelationType(Enum):
    CONTAINS_ALL_OF = "ContainsAllOf"
    CONTAINS_PART_OF = "ContainsPartOf"
    DEPICTS_EVENT = "DepictsEvent"
    DEPRECATED = "Deprecated"
    DUPLICATE = "Duplicate"
    HAS_CUE_SHEET = "HasCueSheet"
    HAS_SOUND_RECORDING = "HasSoundRecording"
    IS_DERIVED_FROM = "IsDerivedFrom"
    IS_ENTIRELY_CONTAINED_BY = "IsEntirelyContainedBy"
    IS_PARTIALLY_CONTAINED_BY = "IsPartiallyContainedBy"
    IS_SAME_AS = "IsSameAs"
    IS_SOURCE_OF = "IsSourceOf"
    OTHER = "Other"


class BaseAssetDoitype(BaseModel):
    class Meta:
        name = "baseAssetDOIType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")


class ComponentsModeType(Enum):
    """
    These are a superset of an object's possible mode types; they cover
    individual components and combinations of components. "Other" covers
    combinations not otherwise described.
    """

    AUDIO = "Audio"
    VISUAL = "Visual"
    AUDIO_VISUAL = "AudioVisual"
    OTHER = "Other"
    INTERACTIVE_MATERIAL = "InteractiveMaterial"
    ALL = "All"


class CompositeClassType(Enum):
    MASHUP = "Mashup"
    OMNIBUS = "Omnibus"
    EXCERPT = "Excerpt"
    INCLUSION = "Inclusion"
    OTHER = "Other"


class DescriptionType(BaseModel):
    class Meta:
        name = "descriptionType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 128,
        },
    )
    lang: str = field(
        metadata={
            "type": "Attribute",
        }
    )


class DoiModeRestricted(Enum):
    """
    :cvar AUDIO: Of a Creation which is intended to be listened to.
    :cvar VISUAL: Of a Creation which is intended to be looked at.
    """

    AUDIO = "Audio"
    VISUAL = "Visual"


class EditClassType(Enum):
    """
    These are intended to enumerate the primary, distinguishing
    characteristics of the Edit.
    """

    ALTERNATE_ENDING = "Alternate Ending"
    ANNIVERSARY = "Anniversary"
    CENSORED = "Censored"
    COLORIZED = "Colorized"
    CONTENT_BREAK = "Content Break"
    CREATIVE = "Creative"
    CREDITS = "Credits"
    DIALOG = "Dialog"
    DIRECTOR_S_CUT = "Director's Cut"
    DUBBING_CREDITS = "Dubbing Credits"
    EXIT = "Exit"
    EXTENDED = "Extended"
    INTERACTIVE_PLATFORM = "Interactive Platform"
    INTERMISSION = "Intermission"
    LOGOS = "Logos"
    MUSIC = "Music"
    ORIGINAL = "Original"
    OVERTURE = "Overture"
    PRODUCT_PLACEMENT = "Product Placement"
    PROMOTIONAL = "Promotional"
    RECAP = "Recap"
    REGIONALIZED = "Regionalized"
    RERELEASED = "Rereleased"
    RESTORED_AUDIO = "Restored Audio"
    RESTORED_PICTURE = "Restored Picture"
    RESTORED = "Restored"
    SANITIZED_AUDIO = "Sanitized Audio"
    SANITIZED_PICTURE = "Sanitized Picture"
    SANITIZED = "Sanitized"
    SHORTENED = "Shortened"
    SOUND_EFFECTS = "Sound Effects"
    SPLIT = "Split"
    SUBSTITUTIONS = "Substitutions"
    SYNDICATION = "Syndication"
    TEXTLESS = "Textless"
    THREE_D = "Three-D"
    UNRATED = "Unrated"
    OTHER = "Other"


class EditUseType(Enum):
    """
    These are intended to capture the original, primary, intended use for
    the Edit.

    In many cases, the actual uses will be different, e.g., iTunes using
    the Theatrical cut.
    """

    AIRLINE = "Airline"
    BROADCAST = "Broadcast"
    HOME_VIDEO = "Home Video"
    HOSPITALITY = "Hospitality"
    MULTIUSE = "Multiuse"
    PRESERVATION_MASTER = "Preservation Master"
    STREAMING = "Streaming"
    THEATRICAL = "Theatrical"
    WEB = "Web"
    UNKNOWN = "Unknown"


class EpisodeClassType(Enum):
    MAIN = "Main"
    PILOT = "Pilot"
    STANDALONE = "Standalone"
    SPECIAL = "Special"
    OMNIBUS = "Omnibus"
    RECUT = "Recut"
    SEGMENT = "Segment"


class FilmTracksType(BaseModel):
    class Meta:
        name = "filmTracksType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class LanguageTrackTypeType(Enum):
    COMMENTARY = "commentary"
    DIALOGCENTRIC = "dialogcentric"
    NARRATION = "narration"
    PRIMARY = "primary"
    SILENT = "silent"
    SILENT_OMITTED = "silent-omitted"
    OTHER = "other"
    EASYREADER = "easyreader"
    FORCED = "forced"
    LARGE = "large"
    NOFORCED = "noforced"
    NORMAL = "normal"
    SDH = "SDH"
    SINGALONG = "singalong"


class LanguagesType(BaseModel):
    class Meta:
        name = "languagesType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    language: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
        },
    )


class LinkedAlternateIdurltype(BaseModel):
    class Meta:
        name = "linkedAlternateIDURLType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    type_value: None | str = field(
        default=None,
        metadata={
            "name": "type",
            "type": "Attribute",
        },
    )


class ManifestationClassType(Enum):
    ADAPTATION_SET = "Adaptation Set"
    BLU_RAY = "Blu-ray"
    BROADCAST_PACKAGE = "Broadcast Package"
    CMP = "CMP"
    CPL = "CPL"
    DVD = "DVD"
    EST = "EST"
    GAME_MACHINE = "Game Machine"
    HD = "HD"
    IMF = "IMF"
    MASTER = "Master"
    MEZZANINE = "Mezzanine"
    MOBILE = "Mobile"
    PRESENTATION = "Presentation"
    PROXY = "Proxy"
    REPRESENTATION = "Representation"
    SD = "SD"
    SCREENER = "Screener"
    UHD = "UHD"
    VOD = "VOD"
    VERSION_LANGUAGE = "Version Language"
    WEB = "Web"
    OTHER = "Other"


class MetadataAuthorityType(BaseModel):
    class Meta:
        name = "metadataAuthorityType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        },
    )


class ModeType(Enum):
    """
    use DOI types where possible; use Other for InteractiveMaterial;
    AudioVisual is included for compatibility with DOI 2004 modes.
    """

    AUDIO = "Audio"
    VISUAL = "Visual"
    AUDIO_VISUAL = "AudioVisual"
    OTHER = "Other"


class PackagingClassType(Enum):
    DVD = "DVD"
    BD = "BD"
    HD = "HD"
    SD = "SD"
    STREAMING = "Streaming"
    STREAMING_WEB = "Streaming (Web)"
    STREAMING_MOBILE = "Streaming (Mobile)"
    DOWNLOAD_WEB = "Download (Web)"
    DOWNLOAD_MOBILE = "Download (Mobile)"
    VOD = "VOD"
    BROADCAST = "Broadcast"
    DIGITAL_CINEMA = "Digital Cinema"
    OTHER = "Other"


class PartyAliasContinuationType(BaseModel):
    class Meta:
        name = "partyAliasContinuationType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    last_aliased: str = field(
        metadata={
            "name": "LastAliased",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        }
    )
    target_of_last_aliased: str = field(
        metadata={
            "name": "TargetOfLastAliased",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        }
    )


class PromotionClassType(Enum):
    BROADCAST_AD = "Broadcast Ad"
    DVD_TRAILER = "DVD Trailer"
    EPK = "EPK"
    INFOMERCIAL = "Infomercial"
    MOBILE = "Mobile"
    PREVIEW = "Preview"
    RADIO_SPOT = "Radio Spot"
    SIZZLE_REEL = "Sizzle Reel"
    TEASER = "Teaser"
    THEATRICAL_TRAILER = "Theatrical Trailer"
    UGC_SITE = "UGC Site"
    WEB = "Web"
    OTHER = "Other"


class ReferentType(Enum):
    """
    :cvar SERIES: Use for an item that consists of separate pieces. The
        pieces can be ordered or unordered.
    :cvar PODCAST: A variant of Series with distinct de-duplication
        behavior.
    :cvar SEASON: Convolutedly defined, this is a container for items
        that belong together and are released separately over a defined
        period of time. (Defined by example, this is a season of a TV
        series.) The items can be ordered or unordered
    :cvar TV: Use for anything that was first aired on any form of TV
        (broadcast, cable, satellite.)
    :cvar MOVIE: Use for a work that was first seen in a theatrical
        setting
    :cvar SHORT: Use for shorter works. Ideally, a TV show should not be
        described with this, but ads, outtakes, bonus content, and
        theatrical shorts can be.
    :cvar WEB: Use for work that was first presented on the web
    :cvar COMPILATION: Used for an item that contains mutiple entire
        other objects. See CompilationClassType for examples.
    :cvar INTERACTIVE_MATERIAL: Use for interactive material, such as
        DVD menus or on-line games. ‘abstract’ could be used for
        interactive material that is the conceptual basis for different
        implementations.
    :cvar SUPPLEMENTAL: Use for trailers, value-added material, and
        other promotional material, which are otherwise cannot be made
        children of assets.
    """

    SERIES = "Series"
    PODCAST = "Podcast"
    SEASON = "Season"
    TV = "TV"
    MOVIE = "Movie"
    SHORT = "Short"
    WEB = "Web"
    COMPILATION = "Compilation"
    INTERACTIVE_MATERIAL = "Interactive Material"
    SUPPLEMENTAL = "Supplemental"


class RegistrantType(BaseModel):
    class Meta:
        name = "registrantType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        },
    )


class RelationshipType(Enum):
    IS_SEASON_OF = "isSeasonOf"
    IS_EPISODE_OF = "isEpisodeOf"
    IS_EDIT_OF = "isEditOf"
    IS_MANIFESTATION_OF = "isManifestationOf"
    IS_CLIP_OF = "isClipOf"
    IS_COMPOSITE_OF = "isCompositeOf"
    IS_COMPILATION_OF = "isCompilationOf"
    IS_PACKAGING_OF = "isPackagingOf"
    IS_PROMOTION_FOR = "isPromotionFor"
    IS_SUPPLEMENT_TO = "isSupplementTo"
    IS_ALTERNATE_CONTENT_FOR = "isAlternateContentFor"


class ResolutionTypeType(Enum):
    DOIKERNEL = "DOIKernel"
    FULL = "Full"
    SELF_DEFINED = "SelfDefined"
    SIMPLE = "Simple"
    PROVENANCE = "Provenance"
    INHERITED = "Inherited"


class SeasonClassType(Enum):
    ADJUNCT = "Adjunct"
    ENHANCED = "Enhanced"
    LIMITED_SERIES = "LimitedSeries"
    MAIN = "Main"
    MINI_SERIES = "Mini-series"
    PRO_FORMA = "Pro Forma"
    RECUT = "Recut"


class SeriesClassType(Enum):
    EPISODIC = "Episodic"
    ANTHOLOGY = "Anthology"
    LIMITED_SERIES = "LimitedSeries"
    MINI_SERIES = "Mini-series"


class StatusType(Enum):
    VALID = "valid"
    IN_DEVELOPMENT = "in development"
    ALIAS = "alias"


class SupplementalContentClassType(Enum):
    B_ROLL = "B-roll"
    BEHIND_THE_SCENES = "Behind the scenes"
    DELETED_SCENE = "Deleted Scene"
    FEATURETTE = "Featurette"
    INTERACTIVITY = "Interactivity"
    INTERVIEW = "Interview"
    MAKING_OF = "Making Of"
    MUSIC_VIDEO = "Music Video"
    MUSIC = "Music"
    OUTTAKE = "Outtake"
    SCREEN_TEST = "Screen Test"
    SELECTED_CLIPS = "Selected Clips"
    OTHER = "Other"


class TapeTracksType(BaseModel):
    class Meta:
        name = "tapeTracksType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class TitleClassType(Enum):
    """
    XXX update this list.... release: title as released abbreviated: Prince
    Caspian for The Chronicles of Narnia: Prince Caspian working: working
    title acronym: SATC for Sex and the City fan-based: what fans call it
    internal: any internal or code name series numeric: episodes are
    identified by number, not name or original broadcast date series date:
    episodes are identified by original broadcast date, not name or number
    regional: regional title that may be in the samelanguage as the
    original broadcast: if a broadcast release has a different name
    broadcast: the title if it was different when broadcast for the first
    time, e.g. for a movie shown on TV AKA: also known as FKA: formerly
    known as transliterated: the title rendered in a script other than the
    original (e.g. various romanization schemes) other:
    """

    RELEASE = "release"
    ABBREVIATED = "abbreviated"
    WORKING = "working"
    ACRONYM = "acronym"
    FAN_BASED = "fan-based"
    INTERNAL = "internal"
    SERIES_NUMERIC = "series numeric"
    SERIES_DATE = "series date"
    REGIONAL = "regional"
    BROADCAST = "broadcast"
    AKA = "AKA"
    FKA = "FKA"
    TRANSLITERATED = "transliterated"
    OTHER = "other"


class UsageDetailsType(BaseModel):
    class Meta:
        name = "usageDetailsType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 128,
        },
    )
    domain: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 4,
            "max_length": 256,
            "pattern": r"[\S]+[.][\S]+",
        }
    )


class AbbreviatedMetadataInfoTypeDisplayIndicators(Enum):
    CC = "CC"
    F = "F"
    P = "P"
    DD = "DD"
    SAP = "SAP"
    DVS = "DVS"


class BasicMetadataParentTypeRelationshipType(Enum):
    ISCLIPOF = "isclipof"
    ISEPISODEOF = "isepisodeof"
    ISSEASONOF = "isseasonof"
    ISPIECEOF = "ispieceof"
    ISPARTOF = "ispartof"
    ISDERIVEDFROM = "isderivedfrom"
    ISCOMPOSITEOF = "iscompositeof"
    ISSUPPLEMENTTO = "issupplementto"
    ISPROMOTIONFOR = "ispromotionfor"


class ColorTypeType(Enum):
    COLOR = "color"
    BANDW = "bandw"
    COLORIZED = "colorized"
    COMPOSITE = "composite"
    UNKNOWN = "unknown"


class ContactInfoType(BaseModel):
    class Meta:
        name = "ContactInfo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    name: str = field(
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    primary_email: str = field(
        metadata={
            "name": "PrimaryEmail",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    alternate_email: list[str] = field(
        default_factory=list,
        metadata={
            "name": "AlternateEmail",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    address: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Address",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    phone: list[ContactInfoType.Phone] = field(
        default_factory=list,
        metadata={
            "name": "Phone",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Phone(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        type_value: None | str = field(
            default=None,
            metadata={
                "name": "type",
                "type": "Attribute",
            },
        )


class ContentIdentifierType(BaseModel):
    class Meta:
        name = "ContentIdentifier-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    namespace: str = field(
        metadata={
            "name": "Namespace",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    identifier: str = field(
        metadata={
            "name": "Identifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    location: None | str = field(
        default=None,
        metadata={
            "name": "Location",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    scope: None | ContentIdentifierType.Scope = field(
        default=None,
        metadata={
            "name": "Scope",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Scope(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        subscope: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRelatedToEventType(BaseModel):
    """
    :ivar type_value: Battle, Crime, etc.
    :ivar sub_type:
    :ivar date:
    :ivar duration:
    :ivar description:
    :ivar primary:
    :ivar fictional:
    """

    class Meta:
        name = "ContentRelatedToEvent-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    type_value: None | str = field(
        default=None,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sub_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "SubType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    date: None | ContentRelatedToEventType.Date = field(
        default=None,
        metadata={
            "name": "Date",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    duration: None | ContentRelatedToEventType.Duration = field(
        default=None,
        metadata={
            "name": "Duration",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRelatedToEventType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Date(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlPeriod | XmlDate | XmlDateTime = field()
        approximate: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Duration(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlDuration = field()
        approximate: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRelatedToPeriodType(BaseModel):
    class Meta:
        name = "ContentRelatedToPeriod-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    date: ContentRelatedToPeriodType.Date = field(
        metadata={
            "name": "Date",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    duration: None | ContentRelatedToPeriodType.Duration = field(
        default=None,
        metadata={
            "name": "Duration",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRelatedToPeriodType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Date(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlPeriod | XmlDate | XmlDateTime = field()
        approximate: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Duration(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlDuration = field()
        approximate: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRelatedToRelationshipType(BaseModel):
    """
    :ivar type_value: Reenactment, Fictionalization, Parody, etc.
    :ivar sub_type:
    :ivar description:
    """

    class Meta:
        name = "ContentRelatedToRelationship-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: str = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    sub_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "SubType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRelatedToRelationshipType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class CoordinateEarthType(BaseModel):
    class Meta:
        name = "CoordinateEarth-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    latitude: None | float = field(
        default=None,
        metadata={
            "name": "Latitude",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    longitude: None | float = field(
        default=None,
        metadata={
            "name": "Longitude",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    elevation_meters: None | float = field(
        default=None,
        metadata={
            "name": "ElevationMeters",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class CoordinateOtherType(BaseModel):
    class Meta:
        name = "CoordinateOther-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    coordinate: list[CoordinateOtherType.Coordinate] = field(
        default_factory=list,
        metadata={
            "name": "Coordinate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    system: str = field(
        metadata={
            "type": "Attribute",
        }
    )

    class Coordinate(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        label: str = field(
            metadata={
                "type": "Attribute",
            }
        )


class DateTimeRangeType(BaseModel):
    class Meta:
        name = "DateTimeRange-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    start: XmlDateTime = field(
        metadata={
            "name": "Start",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    end: XmlDateTime = field(
        metadata={
            "name": "End",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class DigitalAssetAudioAmbisonicsType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioAmbisonics-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: None | str = field(
        default=None,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    order: int = field(
        metadata={
            "name": "Order",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    veritical_order: None | int = field(
        default=None,
        metadata={
            "name": "VeriticalOrder",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    normalization: str = field(
        metadata={
            "name": "Normalization",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class DigitalAssetAudioLanguageType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioLanguage-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    dubbed: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class DigitalAssetAudioLoudnessType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioLoudness-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    level: None | Decimal = field(
        default=None,
        metadata={
            "name": "Level",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    deviation: None | Decimal = field(
        default=None,
        metadata={
            "name": "Deviation",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    leq_m: None | Decimal = field(
        default=None,
        metadata={
            "name": "LeqM",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    compliance: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Compliance",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetAudioMcalabelType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioMCALabel-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    content_kind: None | str = field(
        default=None,
        metadata={
            "name": "ContentKind",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    element_kind: None | str = field(
        default=None,
        metadata={
            "name": "ElementKind",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetChromaticityType(BaseModel):
    class Meta:
        name = "DigitalAssetChromaticity-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    chromaticity_ciex: Decimal = field(
        metadata={
            "name": "ChromaticityCIEx",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    chromaticity_ciey: Decimal = field(
        metadata={
            "name": "ChromaticityCIEy",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class DigitalAssetColorEncodingType(BaseModel):
    class Meta:
        name = "DigitalAssetColorEncoding-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    primaries: str = field(
        metadata={
            "name": "Primaries",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    transfer_function: str = field(
        metadata={
            "name": "TransferFunction",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    color_differencing: str = field(
        metadata={
            "name": "ColorDifferencing",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class DigitalAssetExternalTrackReferenceType(BaseModel):
    class Meta:
        name = "DigitalAssetExternalTrackReference-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
        },
    )
    namespace: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    location: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "trackReference",
            "type": "Attribute",
            "max_length": 128,
        },
    )


class DigitalAssetVideoPicture360InitialType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPicture360Initial-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    heading_degrees: Decimal = field(
        metadata={
            "name": "HeadingDegrees",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_inclusive": Decimal("0"),
            "max_inclusive": Decimal("360"),
        }
    )
    pitch_degrees: Decimal = field(
        metadata={
            "name": "PitchDegrees",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_inclusive": Decimal("-90"),
            "max_inclusive": Decimal("90"),
        }
    )
    roll_degress: Decimal = field(
        metadata={
            "name": "RollDegress",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_inclusive": Decimal("-180"),
            "max_inclusive": Decimal("180"),
        }
    )


class DigitalAssetVideoPictureHdrplaybackInfoType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPictureHDRPlaybackInfo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    sdrdownconversion: None | str = field(
        default=None,
        metadata={
            "name": "SDRDownconversion",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    other_element: list[object] = field(
        default_factory=list,
        metadata={
            "type": "Wildcard",
            "namespace": "##other",
        },
    )


class DigitalAssetVideoPictureLightLevelType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPictureLightLevel-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    content_max: list[DigitalAssetVideoPictureLightLevelType.ContentMax] = (
        field(
            default_factory=list,
            metadata={
                "name": "ContentMax",
                "type": "Element",
                "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            },
        )
    )
    frame_average_max: list[
        DigitalAssetVideoPictureLightLevelType.FrameAverageMax
    ] = field(
        default_factory=list,
        metadata={
            "name": "FrameAverageMax",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class ContentMax(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: int = field()
        interpretation: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class FrameAverageMax(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: int = field()
        interpretation: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetWatermarkType(BaseModel):
    """
    enforce max length on xs:string fields.
    """

    class Meta:
        name = "DigitalAssetWatermark-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    vendor: str = field(
        metadata={
            "name": "Vendor",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_length": 2,
            "max_length": 128,
            "pattern": r".*[^\s].*",
        }
    )
    product_and_version_id: str = field(
        metadata={
            "name": "ProductAndVersionID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        }
    )
    data: str = field(
        metadata={
            "name": "Data",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 256,
        }
    )
    guaranteed_absent: None | bool = field(
        default=None,
        metadata={
            "name": "guaranteedAbsent",
            "type": "Attribute",
        },
    )


class EidrurnType(BaseModel):
    class Meta:
        name = "EIDRURN-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    scope: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class GenderType(BaseModel):
    class Meta:
        name = "Gender-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    transgender: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    specific_gender: None | str = field(
        default=None,
        metadata={
            "name": "specificGender",
            "type": "Attribute",
        },
    )


class MadeForRegionType(Enum):
    """
    :cvar DOMESTIC:
    :cvar INTERNATIONAL:
    :cvar VALUE_001: World
    :cvar VALUE_002: Africa
    :cvar VALUE_003: North America
    :cvar VALUE_005: South America
    :cvar VALUE_009: Oceania
    :cvar VALUE_011: Western Africa
    :cvar VALUE_013: Central America
    :cvar VALUE_014: Eastern Africa
    :cvar VALUE_015: Northern Africa
    :cvar VALUE_017: Middle Africa
    :cvar VALUE_018: Southern Africa
    :cvar VALUE_019: Americas
    :cvar VALUE_021: Northern America
    :cvar VALUE_029: Caribbean
    :cvar VALUE_030: Eastern Asia
    :cvar VALUE_034: Southern Asia
    :cvar VALUE_035: South-Eastern Asia
    :cvar VALUE_039: Southern Europe
    :cvar VALUE_053: Australia and New Zealand
    :cvar VALUE_054: Melanesia
    :cvar VALUE_057: Micronesia
    :cvar VALUE_061: Polynesia
    :cvar VALUE_142: Asia
    :cvar VALUE_143: Central Asia
    :cvar VALUE_145: Western Asia
    :cvar VALUE_150: Europe
    :cvar VALUE_151: Eastern Europe
    :cvar VALUE_154: Northern Europe
    :cvar VALUE_155: Western Europe
    :cvar VALUE_419: Latin America and the Caribbean
    :cvar AD: Andorra.
    :cvar AE: The United Arab Emirates.
    :cvar AF: Afghanistan.
    :cvar AG: Antigua and Barbuda.
    :cvar AI: Anguilla.
    :cvar AL: Albania.
    :cvar AM: Armenia.
    :cvar AO: Angola.
    :cvar AQ: Antarctica.
    :cvar AR: Argentina.
    :cvar AS: American Samoa.
    :cvar AT: Austria.
    :cvar AU: Australia.
    :cvar AW: Aruba.
    :cvar AX: Aaland Islands.
    :cvar AZ: Azerbaijan.
    :cvar BA: Bosnia and Herzegovina.
    :cvar BB: Barbados.
    :cvar BD: Bangladesh.
    :cvar BE: Belgium.
    :cvar BF: Burkina Faso.
    :cvar BG: Bulgaria.
    :cvar BH: Bahrain.
    :cvar BI: Burundi.
    :cvar BJ: Benin.
    :cvar BL: Saint Barthelemy.
    :cvar BM: Bermuda.
    :cvar BN: Brunei.
    :cvar BO: Bolivia.
    :cvar BQ: Bonaire, Sint Eustatius and Saba.
    :cvar BR: Brazil.
    :cvar BS: The Bahamas.
    :cvar BT: Bhutan.
    :cvar BV: Bouvet Island.
    :cvar BW: Botswana.
    :cvar BY: Belarus.
    :cvar BZ: Belize.
    :cvar CA: Canada.
    :cvar CC: Cocos Islands.
    :cvar CD: The Democratic Republic of the Congo.
    :cvar CF: The Central African Republic.
    :cvar CG: The Congo.
    :cvar CH: Switzerland.
    :cvar CI: Cote d'Ivoire.
    :cvar CK: Cook Islands.
    :cvar CL: Chile.
    :cvar CM: Cameroon.
    :cvar CN: China.
    :cvar CO: Colombia.
    :cvar CR: Costa Rica.
    :cvar CU: Cuba.
    :cvar CW: Curacao.
    :cvar CV: Cape Verde.
    :cvar CX: Christmas Island.
    :cvar CY: Cyprus.
    :cvar CZ: Czechia.
    :cvar DE: Germany.
    :cvar DJ: Djibouti.
    :cvar DK: Denmark.
    :cvar DM: Dominica.
    :cvar DO: The Dominican Republic.
    :cvar DZ: Algeria.
    :cvar EC: Ecuador.
    :cvar EE: Estonia.
    :cvar EG: Egypt.
    :cvar EH: Western Sahara.
    :cvar ER: Eritrea.
    :cvar ES: Spain.
    :cvar ET: Ethiopia.
    :cvar FI: Finland.
    :cvar FJ: Fiji.
    :cvar FK: Falkland Islands.
    :cvar FM: Micronesia.
    :cvar FO: Faroe Islands.
    :cvar FR: France.
    :cvar GA: Gabon.
    :cvar GB: The United Kingdom.
    :cvar GD: Grenada.
    :cvar GE: Georgia.
    :cvar GF: French Guiana.
    :cvar GG: Guernsey.
    :cvar GH: Ghana.
    :cvar GI: Gibraltar.
    :cvar GL: Greenland.
    :cvar GM: The Gambia.
    :cvar GN: Guinea.
    :cvar GP: Guadeloupe.
    :cvar GQ: Equatorial Guinea.
    :cvar GR: Greece.
    :cvar GS: South Georgia and The South Sandwich Islands.
    :cvar GT: Guatemala.
    :cvar GU: Guam.
    :cvar GW: Guinea-Bissau.
    :cvar GY: Guyana.
    :cvar HK: Hong Kong.
    :cvar HM: Heard Island and McDonald Islands.
    :cvar HN: Honduras.
    :cvar HR: Croatia.
    :cvar HT: Haiti.
    :cvar HU: Hungary.
    :cvar ID: Indonesia.
    :cvar IE: Ireland.
    :cvar IL: Israel.
    :cvar IM: Isle of Man.
    :cvar IN: India.
    :cvar IO: The British Indian Ocean Territory.
    :cvar IQ: Iraq.
    :cvar IR: Iran.
    :cvar IS: Iceland.
    :cvar IT: Italy.
    :cvar JE: Jersey.
    :cvar JM: Jamaica.
    :cvar JO: Jordan.
    :cvar JP: Japan.
    :cvar KE: Kenya.
    :cvar KG: Kyrgyzstan.
    :cvar KH: Cambodia.
    :cvar KI: Kiribati.
    :cvar KM: The Comoros.
    :cvar KN: Saint Kitts and Nevis.
    :cvar KP: The Democratic People's Republic of Korea.
    :cvar KR: The Republic of Korea.
    :cvar KW: Kuwait.
    :cvar KY: Cayman Islands.
    :cvar KZ: Kazakhstan.
    :cvar LA: Laos.
    :cvar LB: Lebanon.
    :cvar LC: Saint Lucia.
    :cvar LI: Liechtenstein.
    :cvar LK: Sri Lanka.
    :cvar LR: Liberia.
    :cvar LS: Lesotho.
    :cvar LT: Lithuania.
    :cvar LU: Luxembourg.
    :cvar LV: Latvia.
    :cvar LY: Libya.
    :cvar MA: Morocco.
    :cvar MC: Monaco.
    :cvar MD: Moldova.
    :cvar ME: Montenegro.
    :cvar MF: Saint Martin.
    :cvar MG: Madagascar.
    :cvar MH: The Marshall Islands.
    :cvar MK: North Macedonia.
    :cvar ML: Mali.
    :cvar MM: Myanmar.
    :cvar MN: Mongolia.
    :cvar MO: Macao.
    :cvar MP: Northern Mariana Islands.
    :cvar MQ: Martinique.
    :cvar MR: Mauritania.
    :cvar MS: Montserrat.
    :cvar MT: Malta.
    :cvar MU: Mauritius.
    :cvar MV: Maldives.
    :cvar MW: Malawi.
    :cvar MX: Mexico.
    :cvar MY: Malaysia.
    :cvar MZ: Mozambique.
    :cvar NA: Namibia.
    :cvar NC: New Caledonia.
    :cvar NE: The Niger.
    :cvar NF: Norfolk Island.
    :cvar NG: Nigeria.
    :cvar NI: Nicaragua.
    :cvar NL: The Netherlands.
    :cvar NO: Norway.
    :cvar NP: Nepal.
    :cvar NR: Nauru.
    :cvar NU: Niue.
    :cvar NZ: New Zealand.
    :cvar OM: Oman.
    :cvar PA: Panama.
    :cvar PE: Peru.
    :cvar PF: French Polynesia.
    :cvar PG: Papua New Guinea.
    :cvar PH: The Philippines.
    :cvar PK: Pakistan.
    :cvar PL: Poland.
    :cvar PM: Saint Pierre and Miquelon.
    :cvar PN: Pitcairn.
    :cvar PR: Puerto Rico.
    :cvar PS: Palestine, State of.
    :cvar PT: Portugal.
    :cvar PW: Palau.
    :cvar PY: Paraguay.
    :cvar QA: Qatar.
    :cvar RE: Reunion.
    :cvar RO: Romania.
    :cvar RS: Serbia.
    :cvar RU: Russia.
    :cvar RW: Rwanda.
    :cvar SA: Saudi Arabia.
    :cvar SB: Solomon Islands.
    :cvar SC: Seychelles.
    :cvar SD: The Sudan.
    :cvar SE: Sweden.
    :cvar SG: Singapore.
    :cvar SH: Saint Helena.
    :cvar SI: Slovenia.
    :cvar SJ: Svalbard and Jan Mayen.
    :cvar SK: Slovakia.
    :cvar SL: Sierra Leone.
    :cvar SM: San Marino.
    :cvar SN: Senegal.
    :cvar SO: Somalia.
    :cvar SR: Suriname.
    :cvar SS: South Sudan.
    :cvar ST: Sao Tome and Principe.
    :cvar SV: El Salvador.
    :cvar SX: Sint Maarten.
    :cvar SY: Syria.
    :cvar SZ: Eswatini.
    :cvar TC: Turks and Caicos Islands.
    :cvar TD: Chad.
    :cvar TF: The French Southern Territories.
    :cvar TG: Togo.
    :cvar TH: Thailand.
    :cvar TJ: Tajikistan.
    :cvar TK: Tokelau.
    :cvar TL: Timor-Leste.
    :cvar TM: Turkmenistan.
    :cvar TN: Tunisia.
    :cvar TO: Tonga.
    :cvar TR: Turkey.
    :cvar TT: Trinidad and Tobago.
    :cvar TV: Tuvalu.
    :cvar TW: Taiwan (Province of China).
    :cvar TZ: Tanzania.
    :cvar UA: Ukraine.
    :cvar UG: Uganda.
    :cvar UM: United States Minor Outlying Islands.
    :cvar US: The United States.
    :cvar UY: Uruguay.
    :cvar UZ: Uzbekistan.
    :cvar VA: The Holy See.
    :cvar VC: Saint Vincent and The Grenadines.
    :cvar VE: Venezuela.
    :cvar VG: British Virgin Islands.
    :cvar VI: US Virgin Islands.
    :cvar VN: Viet Nam.
    :cvar VU: Vanuatu.
    :cvar WF: Wallis and Futuna.
    :cvar WS: Samoa.
    :cvar XX: Country unknown.
    :cvar YE: Yemen.
    :cvar YT: Mayotte.
    :cvar ZA: South Africa.
    :cvar ZM: Zambia.
    :cvar ZW: Zimbabwe.
    :cvar ANHH: Netherlands Antilles.
    :cvar CSH: Czechoslovakia.
    :cvar CSHH: Czechoslovakia.
    :cvar DD: German Democratic Republic.
    :cvar DDDE: German Democratic Republic.
    :cvar SCG: Serbia and Montenegro.
    :cvar CSXX: Serbia and Montenegro.
    :cvar SU: USSR.
    :cvar SUHH: USSR.
    :cvar VD: Vietnam, Democratic Republic of.
    :cvar VDVN: Vietnam, Democratic Republic of.
    :cvar YD: Yemen, Democratic (South Yemen).
    :cvar YDYE: Yemen, Democratic (South Yemen).
    :cvar YU: Yugoslavia.
    :cvar YUCS: Yugoslavia.
    :cvar XK: Kosovo.
    """

    DOMESTIC = "Domestic"
    INTERNATIONAL = "International"
    VALUE_001 = "001"
    VALUE_002 = "002"
    VALUE_003 = "003"
    VALUE_005 = "005"
    VALUE_009 = "009"
    VALUE_011 = "011"
    VALUE_013 = "013"
    VALUE_014 = "014"
    VALUE_015 = "015"
    VALUE_017 = "017"
    VALUE_018 = "018"
    VALUE_019 = "019"
    VALUE_021 = "021"
    VALUE_029 = "029"
    VALUE_030 = "030"
    VALUE_034 = "034"
    VALUE_035 = "035"
    VALUE_039 = "039"
    VALUE_053 = "053"
    VALUE_054 = "054"
    VALUE_057 = "057"
    VALUE_061 = "061"
    VALUE_142 = "142"
    VALUE_143 = "143"
    VALUE_145 = "145"
    VALUE_150 = "150"
    VALUE_151 = "151"
    VALUE_154 = "154"
    VALUE_155 = "155"
    VALUE_419 = "419"
    AD = "AD"
    AE = "AE"
    AF = "AF"
    AG = "AG"
    AI = "AI"
    AL = "AL"
    AM = "AM"
    AO = "AO"
    AQ = "AQ"
    AR = "AR"
    AS = "AS"
    AT = "AT"
    AU = "AU"
    AW = "AW"
    AX = "AX"
    AZ = "AZ"
    BA = "BA"
    BB = "BB"
    BD = "BD"
    BE = "BE"
    BF = "BF"
    BG = "BG"
    BH = "BH"
    BI = "BI"
    BJ = "BJ"
    BL = "BL"
    BM = "BM"
    BN = "BN"
    BO = "BO"
    BQ = "BQ"
    BR = "BR"
    BS = "BS"
    BT = "BT"
    BV = "BV"
    BW = "BW"
    BY = "BY"
    BZ = "BZ"
    CA = "CA"
    CC = "CC"
    CD = "CD"
    CF = "CF"
    CG = "CG"
    CH = "CH"
    CI = "CI"
    CK = "CK"
    CL = "CL"
    CM = "CM"
    CN = "CN"
    CO = "CO"
    CR = "CR"
    CU = "CU"
    CW = "CW"
    CV = "CV"
    CX = "CX"
    CY = "CY"
    CZ = "CZ"
    DE = "DE"
    DJ = "DJ"
    DK = "DK"
    DM = "DM"
    DO = "DO"
    DZ = "DZ"
    EC = "EC"
    EE = "EE"
    EG = "EG"
    EH = "EH"
    ER = "ER"
    ES = "ES"
    ET = "ET"
    FI = "FI"
    FJ = "FJ"
    FK = "FK"
    FM = "FM"
    FO = "FO"
    FR = "FR"
    GA = "GA"
    GB = "GB"
    GD = "GD"
    GE = "GE"
    GF = "GF"
    GG = "GG"
    GH = "GH"
    GI = "GI"
    GL = "GL"
    GM = "GM"
    GN = "GN"
    GP = "GP"
    GQ = "GQ"
    GR = "GR"
    GS = "GS"
    GT = "GT"
    GU = "GU"
    GW = "GW"
    GY = "GY"
    HK = "HK"
    HM = "HM"
    HN = "HN"
    HR = "HR"
    HT = "HT"
    HU = "HU"
    ID = "ID"
    IE = "IE"
    IL = "IL"
    IM = "IM"
    IN = "IN"
    IO = "IO"
    IQ = "IQ"
    IR = "IR"
    IS = "IS"
    IT = "IT"
    JE = "JE"
    JM = "JM"
    JO = "JO"
    JP = "JP"
    KE = "KE"
    KG = "KG"
    KH = "KH"
    KI = "KI"
    KM = "KM"
    KN = "KN"
    KP = "KP"
    KR = "KR"
    KW = "KW"
    KY = "KY"
    KZ = "KZ"
    LA = "LA"
    LB = "LB"
    LC = "LC"
    LI = "LI"
    LK = "LK"
    LR = "LR"
    LS = "LS"
    LT = "LT"
    LU = "LU"
    LV = "LV"
    LY = "LY"
    MA = "MA"
    MC = "MC"
    MD = "MD"
    ME = "ME"
    MF = "MF"
    MG = "MG"
    MH = "MH"
    MK = "MK"
    ML = "ML"
    MM = "MM"
    MN = "MN"
    MO = "MO"
    MP = "MP"
    MQ = "MQ"
    MR = "MR"
    MS = "MS"
    MT = "MT"
    MU = "MU"
    MV = "MV"
    MW = "MW"
    MX = "MX"
    MY = "MY"
    MZ = "MZ"
    NA = "NA"
    NC = "NC"
    NE = "NE"
    NF = "NF"
    NG = "NG"
    NI = "NI"
    NL = "NL"
    NO = "NO"
    NP = "NP"
    NR = "NR"
    NU = "NU"
    NZ = "NZ"
    OM = "OM"
    PA = "PA"
    PE = "PE"
    PF = "PF"
    PG = "PG"
    PH = "PH"
    PK = "PK"
    PL = "PL"
    PM = "PM"
    PN = "PN"
    PR = "PR"
    PS = "PS"
    PT = "PT"
    PW = "PW"
    PY = "PY"
    QA = "QA"
    RE = "RE"
    RO = "RO"
    RS = "RS"
    RU = "RU"
    RW = "RW"
    SA = "SA"
    SB = "SB"
    SC = "SC"
    SD = "SD"
    SE = "SE"
    SG = "SG"
    SH = "SH"
    SI = "SI"
    SJ = "SJ"
    SK = "SK"
    SL = "SL"
    SM = "SM"
    SN = "SN"
    SO = "SO"
    SR = "SR"
    SS = "SS"
    ST = "ST"
    SV = "SV"
    SX = "SX"
    SY = "SY"
    SZ = "SZ"
    TC = "TC"
    TD = "TD"
    TF = "TF"
    TG = "TG"
    TH = "TH"
    TJ = "TJ"
    TK = "TK"
    TL = "TL"
    TM = "TM"
    TN = "TN"
    TO = "TO"
    TR = "TR"
    TT = "TT"
    TV = "TV"
    TW = "TW"
    TZ = "TZ"
    UA = "UA"
    UG = "UG"
    UM = "UM"
    US = "US"
    UY = "UY"
    UZ = "UZ"
    VA = "VA"
    VC = "VC"
    VE = "VE"
    VG = "VG"
    VI = "VI"
    VN = "VN"
    VU = "VU"
    WF = "WF"
    WS = "WS"
    XX = "XX"
    YE = "YE"
    YT = "YT"
    ZA = "ZA"
    ZM = "ZM"
    ZW = "ZW"
    ANHH = "ANHH"
    CSH = "CSH"
    CSHH = "CSHH"
    DD = "DD"
    DDDE = "DDDE"
    SCG = "SCG"
    CSXX = "CSXX"
    SU = "SU"
    SUHH = "SUHH"
    VD = "VD"
    VDVN = "VDVN"
    YD = "YD"
    YDYE = "YDYE"
    YU = "YU"
    YUCS = "YUCS"
    XK = "XK"


class MoneyType(BaseModel):
    class Meta:
        name = "Money-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: Decimal = field()
    currency: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class NvpairType(BaseModel):
    class Meta:
        name = "NVPair-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    name: str = field(
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    value: str = field(
        metadata={
            "name": "Value",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class PersonIdentifierType(BaseModel):
    class Meta:
        name = "PersonIdentifier-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    identifier: str = field(
        metadata={
            "name": "Identifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    namespace: str = field(
        metadata={
            "name": "Namespace",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    reference_location: None | str = field(
        default=None,
        metadata={
            "name": "ReferenceLocation",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    scope: None | PersonIdentifierType.Scope = field(
        default=None,
        metadata={
            "name": "Scope",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Scope(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        subscope: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class StringAndLanguageType(BaseModel):
    class Meta:
        name = "StringAndLanguage-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    language: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class ComplexSequenceInfoAlternateNumber(BaseModel):
    """
    domain attribute is required for AlternateNumber.
    """

    class Meta:
        name = "complex-SequenceInfo-AlternateNumber"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 8,
            "pattern": r"[0-9a-zA-Z]+([:/\-.,][0-9a-zA-Z]+)*",
        },
    )
    domain: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 4,
            "max_length": 256,
            "pattern": r"[\S]+[.][\S]+",
        }
    )


class ComplexSequenceInfoDistributionNumber(BaseModel):
    class Meta:
        name = "complex-SequenceInfo-DistributionNumber"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 8,
            "pattern": r"0|[1-9][0-9a-zA-Z]*([:/\-.,][0-9a-zA-Z]+)?",
        },
    )
    domain: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 4,
            "max_length": 256,
            "pattern": r"[\S]+[.][\S]+",
        },
    )


class ComplexSequenceInfoHouseSequence(BaseModel):
    class Meta:
        name = "complex-SequenceInfo-HouseSequence"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 8,
            "pattern": r"[0-9a-zA-Z:/\-.,]+",
        },
    )
    domain: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 4,
            "max_length": 256,
            "pattern": r"[\S]+[.][\S]+",
        },
    )


class StringAssociatedOrgRole(Enum):
    PRODUCER = "producer"
    DISTRIBUTOR = "distributor"
    BROADCASTER = "broadcaster"
    EDITOR = "editor"
    ENCODER = "encoder"
    OTHER = "other"


class StringAudioEncChannelMapping(Enum):
    VALUE_5_1_MATRIX = "5.1 Matrix"
    VALUE_6_1_MATRIX = "6.1 Matrix"
    CENTER_SURROUND = "Center surround"
    CENTER = "Center"
    DUAL_MONO = "dual mono"
    IMAX_6_0 = "IMAX 6.0"
    IMAX_6_1 = "IMAX 6.1"
    IMAX_12_0 = "IMAX 12.0"
    IMAX_12_1 = "IMAX 12.1"
    L_C_R_LS_RS_LFE = "L,C,R,LS,RS,LFE"
    L_R_C_LFE_LS_RS = "L,R,C,LFE,LS,RS"
    LFE_2 = "LFE 2"
    LFE_SCREEN = "LFE screen"
    LEFT_CENTER = "Left center"
    LEFT_SURROUND_DIRECT = "Left surround direct"
    LEFT_SURROUND = "Left surround"
    LEFT_TOP_FRONT_SURROUND = "Left Top Front Surround"
    LEFT_TOP_REAR_SURROUND = "Left Top Rear Surround"
    LEFT_WIDE = "Left wide"
    LEFT = "Left"
    REAR_SURROUND_LEFT = "Rear surround left"
    REAR_SURROUND_RIGHT = "Rear surround right"
    RIGHT_CENTER = "Right center"
    RIGHT_SURROUND_DIRECT = "Right surround direct"
    RIGHT_SURROUND = "Right surround"
    RIGHT_TOP_FRONT_SURROUND = "Right Top Front Surround"
    RIGHT_TOP_REAR_SURROUND = "Right Top Rear Surround"
    RIGHT_WIDE = "Right wide"
    RIGHT = "Right"
    STEREO = "stereo"
    SURROUND = "surround"
    TOP_CENTER_SURROUND = "Top center surround"
    VERTICAL_HEIGHT_FRONT = "Vertical height front"


class StringAudioEncCodec(Enum):
    AAC = "AAC"
    AAC_LC = "AAC-LC"
    AAC_LC_MPS = "AAC-LC+MPS"
    AAC_SLS = "AAC-SLS"
    AC_3 = "AC-3"
    AC_4 = "AC-4"
    ADMBWF = "ADMBWF"
    AIFF = "AIFF"
    ALAC = "ALAC"
    AMR = "AMR"
    BWF = "BWF"
    BWF_RF64 = "BWF-RF64"
    DAMF = "DAMF"
    DOLBY_ATMOS_ADMBWF = "DOLBY-ATMOS-ADMBWF"
    DOLBY_DDPLUS_ATMOS = "DOLBY-DDPLUS-ATMOS"
    DOLBY_TRUEHD = "DOLBY-TRUEHD"
    DSD = "DSD"
    DST = "DST"
    DTS = "DTS"
    DTS_ES = "DTS-ES"
    DTS_EXPRESS = "DTS-EXPRESS"
    DTS_HRA = "DTS-HRA"
    DTS_96_24 = "DTS-96/24"
    DTS_MA = "DTS-MA"
    DTS_X = "DTS-X"
    DTS_X_ADMBWF = "DTS-X-ADMBWF"
    E_AC_3 = "E-AC-3"
    FLAC = "FLAC"
    HE_AACV2 = "HE-AACv2"
    IAB = "IAB"
    LPAC = "LPAC"
    LTAC = "LTAC"
    MP3 = "MP3"
    MPEG1 = "MPEG1"
    MPEG_4_ALS = "MPEG-4-ALS"
    MPEG_H = "MPEG-H"
    MLP = "MLP"
    PCM = "PCM"
    QCELP = "QCELP"
    REAL_AUDIO_LOSSLESS = "RealAudio-Lossless"
    VORBIS = "Vorbis"
    WAV = "WAV"
    WMA = "WMA"
    WM9_LOSSLESS = "WM9-Lossless"
    OTHER = "Other"


class StringAudioEncVbr(Enum):
    VBR = "VBR"
    CONSTRAINED_VBR = "Constrained VBR"
    VALUE_2_PASS_VBR = "2-pass VBR"


class StringAudioType(Enum):
    COMMENTARY = "commentary"
    DIALOGCENTRIC = "dialogcentric"
    NARRATION = "narration"
    PRIMARY = "primary"
    SILENT = "silent"
    SILENT_OMITTED = "silent-omitted"
    OTHER = "other"


class StringCardsetType(Enum):
    ANTI_PIRACY = "AntiPiracy"
    DISTRIBUTION_LOGO = "DistributionLogo"
    DUBBING_CREDIT = "DubbingCredit"
    EDIT_NOTICE = "EditNotice"
    HEALTH = "Health"
    INTERMISSION = "Intermission"
    RATING = "Rating"
    OTHER = "Other"


class StringCardsetListType(Enum):
    THEATRICAL = "Theatrical"
    BROADCAST = "Broadcast"
    HOSPITALITY = "Hospitality"
    RENTAL = "Rental"
    EST = "EST"


class StringCompilationCompilationClass(Enum):
    BLU_RAY = "Blu-ray"
    DIGITAL_CINEMA = "Digital Cinema"
    DISTRIBUTION_BUNDLE = "Distribution Bundle"
    DVD = "DVD"
    EST = "EST"
    FRANCHISE = "Franchise"
    HOME_ENTERTAINMENT = "Home Entertainment"
    SYNDICATION = "Syndication"
    SERIES = "Series"
    SEASON = "Season"
    VOLUME = "Volume"
    OTHER = "Other"


class StringCompilationEntryClass(Enum):
    EPISODE = "Episode"
    INSTALLMENT = "Installment"
    PART = "Part"
    SEASON = "Season"
    SUPPLEMENTAL = "Supplemental"


class StringContainerType(Enum):
    VALUE_3_GP = "3GP"
    VALUE_3_GP2 = "3GP2"
    AC3 = "AC3"
    AIFF = "AIFF"
    ASF = "ASF"
    AVI = "AVI"
    ATMOS = "atmos"
    CFF = "CFF"
    DAMF = "DAMF"
    DIVX = "DIVX"
    DTS = "DTS"
    FLV = "FLV"
    HCT = "HCT"
    IMF = "IMF"
    ISO = "ISO"
    JPEG = "JPEG"
    M4_V = "M4V"
    MJ2 = "MJ2"
    MKV = "MKV"
    MP4 = "MP4"
    MPEG_2_PS = "MPEG-2 (PS)"
    MPEG_2_TS = "MPEG-2 (TS)"
    MXF = "MXF"
    OGG = "Ogg"
    PNG = "PNG"
    QUICKTIME_MOV = "Quicktime (MOV)"
    RIFF = "RIFF"
    RM = "RM"
    SWF = "SWF"
    TIFF = "TIFF"
    VOB = "VOB"
    WAV = "WAV"
    WMV = "WMV"
    XMF = "XMF"
    ZIP = "ZIP"
    OTHER = "Other"


class StringHashMethod(Enum):
    C4 = "C4"
    CRC16 = "CRC16"
    CRC32 = "CRC32"
    CRC64 = "CRC64"
    MD2 = "MD2"
    MD4 = "MD4"
    MD5 = "MD5"
    SHA_0 = "SHA-0"
    SHA_1 = "SHA-1"
    SHA_2 = "SHA-2"
    SHA_3 = "SHA-3"


class StringInteractiveEncRuntimeEnvironment(Enum):
    ANDROID = "Android"
    BD_J = "BD-J"
    BRIGHT_SCRIPT = "BrightScript"
    CMX = "CMX"
    DEFAULT = "Default"
    FLASH = "Flash"
    HTML5 = "HTML5"
    I_OS = "iOS"
    LINUX = "Linux"
    MHEG = "MHEG"
    MAC_OS = "MacOS"
    TV_OS = "tvOS"
    WINDOWS = "Windows"
    OTHER = "Other"


class StringInteractiveFormatType(Enum):
    TEXT = "Text"
    EXECUTABLE = "Executable"
    METADATA = "Metadata"


class StringInteractiveType(Enum):
    VALUE_360 = "360"
    AR = "AR"
    COMIC = "Comic"
    COMMERCE = "Commerce"
    IMAGE = "Image"
    INTERACTIVITY = "Interactivity"
    LIVE = "Live"
    LOCATION = "Location"
    MR = "MR"
    MENU = "Menu"
    MIXED_MEDIA = "Mixed-Media"
    OVERLAY_GAME = "Overlay Game"
    SKINS = "Skins"
    STANDALONE_GAME = "Standalone Game"
    VR = "VR"
    OTHER = "Other"


class StringOrgNameIdType(Enum):
    EIDRPARTY_ID = "EIDRPartyID"
    ISNI = "ISNI"


class StringSubtitleFormat(Enum):
    TEXT = "Text"
    IMAGE = "Image"
    COMBINED = "Combined"


class StringSubtitleFormatType(Enum):
    VALUE_3_GPP = "3GPP"
    BLU_RAY = "Blu-ray"
    CAP = "CAP"
    CFF_TT = "CFF-TT"
    DCI = "DCI"
    DVB = "DVB"
    DVD = "DVD"
    DXFP = "DXFP"
    IMSC1 = "IMSC1"
    ITT = "ITT"
    SCC = "SCC"
    SMPTE_2052_1_TIMED_TEXT = "SMPTE 2052-1 Timed Text"
    SRT = "SRT"
    STL = "STL"
    TTML = "TTML"
    WEB_VTT = "WebVTT"


class StringSubtitleType(Enum):
    COMMENTARY = "commentary"
    EASYREADER = "easyreader"
    FORCED = "forced"
    LARGE = "large"
    NOFORCED = "noforced"
    NORMAL = "normal"
    SDH = "SDH"
    SINGALONG = "singalong"
    OTHER = "other"


class StringUnM49(Enum):
    """
    :cvar VALUE_001: World
    :cvar VALUE_002: Africa
    :cvar VALUE_003: North America
    :cvar VALUE_005: South America
    :cvar VALUE_009: Oceania
    :cvar VALUE_011: Western Africa
    :cvar VALUE_013: Central America
    :cvar VALUE_014: Eastern Africa
    :cvar VALUE_015: Northern Africa
    :cvar VALUE_017: Middle Africa
    :cvar VALUE_018: Southern Africa
    :cvar VALUE_019: Americas
    :cvar VALUE_021: Northern America
    :cvar VALUE_029: Caribbean
    :cvar VALUE_030: Eastern Asia
    :cvar VALUE_034: Southern Asia
    :cvar VALUE_035: South-Eastern Asia
    :cvar VALUE_039: Southern Europe
    :cvar VALUE_053: Australia and New Zealand
    :cvar VALUE_054: Melanesia
    :cvar VALUE_057: Micronesia
    :cvar VALUE_061: Polynesia
    :cvar VALUE_142: Asia
    :cvar VALUE_143: Central Asia
    :cvar VALUE_145: Western Asia
    :cvar VALUE_150: Europe
    :cvar VALUE_151: Eastern Europe
    :cvar VALUE_154: Northern Europe
    :cvar VALUE_155: Western Europe
    :cvar VALUE_419: Latin America and the Caribbean
    """

    VALUE_001 = "001"
    VALUE_002 = "002"
    VALUE_003 = "003"
    VALUE_005 = "005"
    VALUE_009 = "009"
    VALUE_011 = "011"
    VALUE_013 = "013"
    VALUE_014 = "014"
    VALUE_015 = "015"
    VALUE_017 = "017"
    VALUE_018 = "018"
    VALUE_019 = "019"
    VALUE_021 = "021"
    VALUE_029 = "029"
    VALUE_030 = "030"
    VALUE_034 = "034"
    VALUE_035 = "035"
    VALUE_039 = "039"
    VALUE_053 = "053"
    VALUE_054 = "054"
    VALUE_057 = "057"
    VALUE_061 = "061"
    VALUE_142 = "142"
    VALUE_143 = "143"
    VALUE_145 = "145"
    VALUE_150 = "150"
    VALUE_151 = "151"
    VALUE_154 = "154"
    VALUE_155 = "155"
    VALUE_419 = "419"


class StringVideoEncCodec(Enum):
    AVI_UNCOMPRESSED = "AVI Uncompressed"
    CINE_FORM_HD = "CineForm HD"
    DIVX = "DIVX"
    DV = "DV"
    H_264 = "H.264"
    H_264_DOLBY_VISION = "H.264-DolbyVision"
    H_265 = "H.265"
    H_265_DOLBY_VISION = "H.265-DolbyVision"
    JPEG2000 = "JPEG2000"
    MOBICLIP = "MOBICLIP"
    MPEG1 = "MPEG1"
    MPEG2 = "MPEG2"
    ON2 = "On2"
    PHOTOJPEG = "PHOTOJPEG"
    PRORES = "PRORES"
    PRORES422 = "PRORES422"
    PRORES4444 = "PRORES4444"
    PRORESHQ = "PRORESHQ"
    PRORESXQ = "PRORESXQ"
    QT_UNCOMPRESSED = "QT Uncompressed"
    REAL = "REAL"
    SVQ = "SVQ"
    SPARK = "Spark"
    VC_2 = "VC-2"
    VC_3 = "VC-3"
    VC_5 = "VC-5"
    VC_6 = "VC-6"
    VC1 = "VC1"
    VP6 = "VP6"
    VP7 = "VP7"
    VP8 = "VP8"
    VP9 = "VP9"
    WMV = "WMV"
    WMV7 = "WMV7"
    WMV8 = "WMV8"
    WMV9 = "WMV9"
    XVID = "XVID"
    OTHER = "OTHER"


class StringVideoEncMlevel(Enum):
    LL = "LL"
    ML = "ML"
    H_14 = "H-14"
    HL = "HL"
    VALUE_1 = "1"
    VALUE_1B = "1b"
    VALUE_1_1 = "1.1"
    VALUE_1_2 = "1.2"
    VALUE_1_3 = "1.3"
    VALUE_2 = "2"
    VALUE_2_1 = "2.1"
    VALUE_2_2 = "2.2"
    VALUE_3 = "3"
    VALUE_3_1 = "3.1"
    VALUE_3_2 = "3.2"
    VALUE_4 = "4"
    VALUE_4_1 = "4.1"
    VALUE_4_2 = "4.2"
    VALUE_5 = "5"
    VALUE_5_1 = "5.1"
    VALUE_5_2 = "5.2"


class StringVideoEncMprofile(Enum):
    SP = "SP"
    MP = "MP"
    SNR = "SNR"
    SPATIAL = "Spatial"
    HP = "HP"
    VALUE_422 = "422"
    MVP = "MVP"
    BP = "BP"
    CBP = "CBP"
    XP = "XP"
    HI_P = "HiP"
    CHI_P = "CHiP"
    PHI_P = "PHiP"
    HI10_P = "Hi10P"
    HI422_P = "Hi422P"
    HI444_P = "Hi444P"
    HI444_PP = "Hi444PP"
    HI10_IP = "Hi10IP"
    HI422_IP = "Hi422IP"
    HI444_IP = "Hi444IP"
    C444_IP = "C444IP"
    SBP = "SBP"
    SCBP = "SCBP"
    SHP = "SHP"
    SHIP = "SHIP"
    SCHP = "SCHP"
    STEREO_HP = "StereoHP"
    MULTIVIEW_HP = "MultiviewHP"


class StringVideoEncVbr(Enum):
    VBR = "VBR"
    CONSTRAINED_VBR = "Constrained VBR"
    VALUE_2_PASS_VBR = "2-pass VBR"


class StringVideoPicColorSampling(Enum):
    VALUE_4_1_1 = "4:1:1"
    VALUE_4_2_0 = "4:2:0"
    VALUE_4_2_2 = "4:2:2"
    VALUE_4_4_4 = "4:4:4"


class StringVideoPicColorimetry(Enum):
    VALUE_601 = "601"
    VALUE_709 = "709"
    VALUE_2020 = "2020"
    P3 = "P3"
    XV_YCC709 = "xvYCC709"


class StringVideoPicFrameRateMultiplier(Enum):
    VALUE_1000_1001 = "1000/1001"


class StringVideoPicFrameRateTimecode(Enum):
    DROP = "Drop"
    EBU = "EBU"
    OTHER = "Other"


class StringVideoPicPixelAspect(Enum):
    NTSC = "NTSC"
    PAL = "PAL"
    SQUARE = "square"
    OTHER = "other"


class StringVideoPicProgressiveScanOrder(Enum):
    BFF = "BFF"
    TFF = "TFF"
    PPF = "PPF"


class StringVideoPicType3D(Enum):
    VALUE_2_D_PLUS_DEPTH = "2D-plus-depth"
    ANAGLYPH = "anaglyph"
    CHROMATEK = "Chromatek"
    FRAME_PACKED = "frame-packed"
    IMAX = "IMAX"
    INTERFERENCE_FILTER = "interference-filter"
    LINE_INTERLEAVED = "line-interleaved"
    MASTER_IMAGE = "MasterImage"
    MULTISCOPIC = "multiscopic"
    MVC = "MVC"
    OVER_UNDER = "over-under"
    PULFRICH = "Pulfrich"
    QUINCUNX = "quincunx"
    REAL_D = "RealD"
    SENSIO = "Sensio"
    SIDE_BY_SIDE = "side-by-side"
    XPAN_D = "XpanD"


class StringVideoPictureFormat(Enum):
    VALUE_360 = "360"
    FULL = "Full"
    LETTERBOX = "Letterbox"
    PAN_AND_SCAN = "Pan and Scan"
    PILLARBOX = "Pillarbox"
    STRETCH = "Stretch"
    OTHER = "Other"


class StringVideoSubLangType(Enum):
    COMMENTARY = "commentary"
    EASYREADER = "easyreader"
    FORCED = "forced"
    LARGE = "large"
    NOFORCED = "noforced"
    NORMAL = "normal"
    SDH = "SDH"
    SINGALONG = "singalong"
    OTHER = "other"


class StringVideoType(Enum):
    ANGLE = "angle"
    ENHANCEMENT = "enhancement"
    OVERLAY = "overlay"
    PRIMARY = "primary"
    OTHER = "other"


class CreationIdentifierType2(BaseModel):
    """
    A complex element describing the type of an identifier used to identify
    a creation.

    :ivar value:
    :ivar user_defined_type: The type of the creationIdentifier if the
        creationIdentifierType is 'ProprietaryIdentifier'.
    :ivar valid_namespace: The namespace of the creationIdentifier if
        the creationIdentifierType is 'ProprietaryIdentifier'.
    :ivar governing_party: The name or identifier of the party
        ultimately responsible for issuing the creationIdentifier if the
        creationIdentifierType is 'ProprietaryIdentifier'.
    """

    class Meta:
        name = "creationIdentifierType"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: CreationIdentifierType1 = field()
    user_defined_type: None | str = field(
        default=None,
        metadata={
            "name": "userDefinedType",
            "type": "Attribute",
        },
    )
    valid_namespace: None | str = field(
        default=None,
        metadata={
            "name": "validNamespace",
            "type": "Attribute",
        },
    )
    governing_party: None | str = field(
        default=None,
        metadata={
            "name": "governingParty",
            "type": "Attribute",
        },
    )


class CreationName(BaseModel):
    """
    A complex element describing a name or title by which a creation is
    known.

    The distinction between 'name' and 'title' is a matter of convention:
    published creations such as books, serials, CDs, DVDs or broadcast
    programmes normally have 'titles', but other creations such as websites
    or datasets more commonly have 'names'. There is no functional
    difference.

    :ivar value: The text string representing the value of the
        creationName.
    :ivar subname_value: A text string representing a subname or
        subtitle which accompanies the creationName. This is not an
        alternative name for the creation which may be used
        independently, but a name or subtitle which supports the main
        creationName. For example, the book titled 'Knowledge
        Representation' by John F. Sowa has the subtitle 'Logical,
        Philosophical and Computational Foundations'.
    :ivar type_value: The type of the creationName.
    :ivar primary_language: The primary language in which the
        creationName is expressed.
    """

    class Meta:
        name = "creationName"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    subname_value: None | str = field(
        default=None,
        metadata={
            "name": "subnameValue",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    type_value: CreationNameType = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    primary_language: None | str = field(
        default=None,
        metadata={
            "name": "primaryLanguage",
            "type": "Attribute",
        },
    )


class Date(BaseModel):
    """
    A complex element describing a date.

    :ivar value: The value of the date (for example, '1967').
    :ivar proximity: The proximity of the declared date to the actual
        date (for example, 'circa', 'not before'). A null value
        indicates that the date is accurate.
    """

    class Meta:
        name = "date"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    value: XmlDate = field(
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    proximity: None | TimeProximity = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class PartyIdentifier(BaseModel):
    """
    A complex element describing an identifier used to identify a party.

    :ivar value: A text string representing the value of the
        partyIdentifier (for example, '987654321').
    :ivar type_value: The type of the partyIdentifier.
    """

    class Meta:
        name = "partyIdentifier"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    type_value: PartyIdentifierType = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )


class PartyName(BaseModel):
    """
    A complex element describing a name by which a party is known.

    :ivar value: A text string representing the value of the partyName
        (for example, 'John Smith', 'ABC Publishing, Inc').
    :ivar type_value: The type of the partyName.
    """

    class Meta:
        name = "partyName"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    type_value: PartyNameType = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )


class SequenceIdentifierType2(BaseModel):
    """
    A complex element describing the type of an identifier used to identify
    the order of a relationship between two entities.

    :ivar value:
    :ivar user_defined_type: The type of the sequenceIdentifier if the
        sequenceIdentifierType is 'ProprietaryIdentifier'.
    :ivar valid_namespace: The namespace of the sequenceIdentifier if
        the sequenceIdentifierType is 'ProprietaryIdentifier'.
    :ivar governing_party: The name or identifier of the party
        ultimately responsible for issuing the sequenceIdentifier if the
        sequenceIdentifierType is 'ProprietaryIdentifier'.
    """

    class Meta:
        name = "sequenceIdentifierType"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: SequenceIdentifierType1 = field()
    user_defined_type: None | str = field(
        default=None,
        metadata={
            "name": "userDefinedType",
            "type": "Attribute",
        },
    )
    valid_namespace: None | str = field(
        default=None,
        metadata={
            "name": "validNamespace",
            "type": "Attribute",
        },
    )
    governing_party: None | str = field(
        default=None,
        metadata={
            "name": "governingParty",
            "type": "Attribute",
        },
    )


class Uri2(BaseModel):
    """
    A complex element describing an URI used to identify a creation.

    :ivar value:
    :ivar return_type: The type (MIME type or equivalent) of the page
        that is returned by the URI.
    :ivar does_content_negotiation: A flag that identifies the URI that
        does content negotiation (whose returnType acts as the default).
    """

    class Meta:
        name = "uri"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    return_type: None | ReturnType = field(
        default=None,
        metadata={
            "name": "returnType",
            "type": "Attribute",
        },
    )
    does_content_negotiation: None | bool = field(
        default=None,
        metadata={
            "name": "doesContentNegotiation",
            "type": "Attribute",
        },
    )


class AdministratorsInfoType(BaseModel):
    """
    Used in provenanceInfoType, baseObjectInfoType, and
    selfDefinedBaseObjectInfoType.
    """

    class Meta:
        name = "administratorsInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    registrant: RegistrantType = field(
        metadata={
            "name": "Registrant",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    metadata_authority: list[MetadataAuthorityType] = field(
        default_factory=list,
        metadata={
            "name": "MetadataAuthority",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 4,
        },
    )


class AlternateIdtype(BaseModel):
    """
    Since this is abstract, any field using it has to provide one of the
    derived types as an xsi:type attribute, e.g. " <AlternateID xmlns=""
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xs:type="{http://www.eidr.org/schema}DOI">10.123/456</AlternateID> "
    This would be easier (and more controlled) under W3C schema 1.1 using
    conditional type assignment.

    Note: xs: in the example above should be xsi: but some validators don't
    like that unless the namespace is declared, even inside the
    documentation element.
    """

    class Meta:
        name = "alternateIDType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 1024,
        },
    )
    relation: None | AlternateIdrelationType = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class AssetDoitype(BaseAssetDoitype):
    """
    other files use redefine with eidr-base.xsd and redefine assetDOIType
    see assetDOIType.xsd for the canonical forms.
    """

    class Meta:
        name = "assetDOIType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class LanguageType(BaseModel):
    class Meta:
        name = "languageType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    mode: DoiModeRestricted = field(
        metadata={
            "type": "Attribute",
        }
    )
    type_value: None | LanguageTrackTypeType = field(
        default=None,
        metadata={
            "name": "type",
            "type": "Attribute",
        },
    )


class SeriesInfoType(BaseModel):
    """
    Series must supply base object ReferentType, StructuralType,
    OriginalLanguage, and ReleaseDate. baseObjectData.ApproximateLength
    must be 0 (zero) or the typical length of an episode.
    """

    class Meta:
        name = "seriesInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    end_date: None | XmlPeriod | XmlDate = field(
        default=None,
        metadata={
            "name": "EndDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    series_class: None | SeriesClassType = field(
        default=None,
        metadata={
            "name": "SeriesClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    number_required: None | bool = field(
        default=None,
        metadata={
            "name": "NumberRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    date_required: None | bool = field(
        default=None,
        metadata={
            "name": "DateRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    original_title_required: None | bool = field(
        default=None,
        metadata={
            "name": "OriginalTitleRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class TitleType(BaseModel):
    class Meta:
        name = "titleType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "max_length": 256,
        },
    )
    title_class: None | TitleClassType = field(
        default=None,
        metadata={
            "name": "titleClass",
            "type": "Attribute",
        },
    )
    lang: str = field(
        metadata={
            "type": "Attribute",
        }
    )
    system_generated: None | bool = field(
        default=None,
        metadata={
            "name": "systemGenerated",
            "type": "Attribute",
        },
    )


class UserCreationType(BaseModel):
    """
    Used when creating a user, which is the only time the password is
    handed around.
    """

    class Meta:
        name = "userCreationType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    parent_party: str = field(
        metadata={
            "name": "ParentParty",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        }
    )
    contact_info: ContactInfoType = field(
        metadata={
            "name": "ContactInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    active: bool = field(
        metadata={
            "name": "Active",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    username: str = field(
        metadata={
            "name": "Username",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        }
    )
    password: str = field(
        metadata={
            "name": "Password",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_length": 6,
            "max_length": 32,
        }
    )


class UserResolutionType(BaseModel):
    """
    Returned when resolving a user; Used when modifying a user.

    Passwords are modified with a separate call, and not returned when
    resolving.
    """

    class Meta:
        name = "userResolutionType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: str = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5238/[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        }
    )
    parent_party: str = field(
        metadata={
            "name": "ParentParty",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        }
    )
    contact_info: ContactInfoType = field(
        metadata={
            "name": "ContactInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    active: bool = field(
        metadata={
            "name": "Active",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    username: str = field(
        metadata={
            "name": "Username",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        }
    )


class AbbreviatedMetadataInfoType(BaseModel):
    class Meta:
        name = "AbbreviatedMetadataInfo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    title_brief: str = field(
        metadata={
            "name": "TitleBrief",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    art_reference: list[str] = field(
        default_factory=list,
        metadata={
            "name": "ArtReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    summary_short: str = field(
        metadata={
            "name": "SummaryShort",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    display_indicators: list[AbbreviatedMetadataInfoTypeDisplayIndicators] = (
        field(
            default_factory=list,
            metadata={
                "name": "DisplayIndicators",
                "type": "Element",
                "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            },
        )
    )
    language: str = field(
        metadata={
            "type": "Attribute",
        }
    )
    default: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class CompObjClassType(BaseModel):
    class Meta:
        name = "CompObjClass-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: StringCompilationCompilationClass = field()
    has_other_inclusions: None | bool = field(
        default=None,
        metadata={
            "name": "hasOtherInclusions",
            "type": "Attribute",
        },
    )


class CompObjEntryType(BaseModel):
    class Meta:
        name = "CompObjEntry-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    display_name: None | StringAndLanguageType = field(
        default=None,
        metadata={
            "name": "DisplayName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    entry_number: None | str = field(
        default=None,
        metadata={
            "name": "EntryNumber",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 8,
            "pattern": r"0|[1-9][0-9a-zA-Z]*([:,\-.,/][0-9a-zA-Z]+)?",
        },
    )
    entry_class: None | StringCompilationEntryClass = field(
        default=None,
        metadata={
            "name": "EntryClass",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    content_id: str = field(
        metadata={
            "name": "ContentID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
        }
    )


class ContainerTrackMetadataType(BaseModel):
    """
    rather than restricting, validation rules could ignore any non-ID
    tracks.
    """

    class Meta:
        name = "ContainerTrackMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    external_track_reference_or_internal_track_reference: (
        None | DigitalAssetExternalTrackReferenceType | str
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "ExternalTrackReference",
                    "type": DigitalAssetExternalTrackReferenceType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "InternalTrackReference",
                    "type": str,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                    "max_length": 128,
                },
            ),
        },
    )


class ContentRelatedToWorkType(BaseModel):
    class Meta:
        name = "ContentRelatedToWork-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    work_type: None | str = field(
        default=None,
        metadata={
            "name": "WorkType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    content_id: list[str] = field(
        default_factory=list,
        metadata={
            "name": "ContentID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
        },
    )
    other_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "OtherIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRelatedToWorkType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentSequenceInfoType(BaseModel):
    """
    Restrict cardinalities, remove Number Element.
    """

    class Meta:
        name = "ContentSequenceInfo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    distribution_number: None | ComplexSequenceInfoDistributionNumber = field(
        default=None,
        metadata={
            "name": "DistributionNumber",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    house_sequence: None | ComplexSequenceInfoHouseSequence = field(
        default=None,
        metadata={
            "name": "HouseSequence",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    alternate_number: list[ComplexSequenceInfoAlternateNumber] = field(
        default_factory=list,
        metadata={
            "name": "AlternateNumber",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_occurs": 32,
        },
    )


class DigitalAssetAudioEncodingType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioEncoding-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    codec: StringAudioEncCodec = field(
        metadata={
            "name": "Codec",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    codec_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "CodecType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"(mpeg4ra|IANA|rfc4281):.{1,128}",
        },
    )
    bitrate_max: None | int = field(
        default=None,
        metadata={
            "name": "BitrateMax",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    bitrate_average: None | int = field(
        default=None,
        metadata={
            "name": "BitrateAverage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    vbr: None | StringAudioEncVbr = field(
        default=None,
        metadata={
            "name": "VBR",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sample_rate: None | int = field(
        default=None,
        metadata={
            "name": "SampleRate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sample_bit_depth: None | int = field(
        default=None,
        metadata={
            "name": "SampleBitDepth",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    channel_mapping: None | StringAudioEncChannelMapping = field(
        default=None,
        metadata={
            "name": "ChannelMapping",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    watermark: list[DigitalAssetWatermarkType] = field(
        default_factory=list,
        metadata={
            "name": "Watermark",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    actual_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "ActualLength",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetCardsetType(BaseModel):
    """
    EIDR restricts Description to 128 characters.
    """

    class Meta:
        name = "DigitalAssetCardset-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: list[StringCardsetType] = field(
        default_factory=list,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    sequence: None | int = field(
        default=None,
        metadata={
            "name": "Sequence",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetColorVolumeType(BaseModel):
    class Meta:
        name = "DigitalAssetColorVolume-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    primary_rchromaticity: DigitalAssetChromaticityType = field(
        metadata={
            "name": "PrimaryRChromaticity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    primary_gchromaticity: DigitalAssetChromaticityType = field(
        metadata={
            "name": "PrimaryGChromaticity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    primary_bchromaticity: DigitalAssetChromaticityType = field(
        metadata={
            "name": "PrimaryBChromaticity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    white_point_chromaticity: DigitalAssetChromaticityType = field(
        metadata={
            "name": "WhitePointChromaticity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    luminance_min: Decimal = field(
        metadata={
            "name": "LuminanceMin",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    luminance_max: Decimal = field(
        metadata={
            "name": "LuminanceMax",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class DigitalAssetInteractiveBaseDataType(BaseModel):
    class Meta:
        name = "DigitalAssetInteractiveBaseData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: StringInteractiveType = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    format_type: None | StringInteractiveFormatType = field(
        default=None,
        metadata={
            "name": "FormatType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: None | str = field(
        default=None,
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetInteractiveEncodingType(BaseModel):
    class Meta:
        name = "DigitalAssetInteractiveEncoding-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    runtime_environment: StringInteractiveEncRuntimeEnvironment = field(
        metadata={
            "name": "RuntimeEnvironment",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    first_version: None | str = field(
        default=None,
        metadata={
            "name": "FirstVersion",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 64,
        },
    )
    last_version: None | str = field(
        default=None,
        metadata={
            "name": "LastVersion",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 64,
        },
    )


class DigitalAssetSubtitleFormatType(BaseModel):
    class Meta:
        name = "DigitalAssetSubtitleFormat-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: StringSubtitleFormat = field()
    sdimage: None | bool = field(
        default=None,
        metadata={
            "name": "SDImage",
            "type": "Attribute",
        },
    )
    hdimage: None | bool = field(
        default=None,
        metadata={
            "name": "HDImage",
            "type": "Attribute",
        },
    )


class DigitalAssetVideoEncodingType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoEncoding-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    codec: StringVideoEncCodec = field(
        metadata={
            "name": "Codec",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    codec_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "CodecType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"(mpeg4ra|IANA):.{1,128}",
        },
    )
    mpegprofile: None | StringVideoEncMprofile = field(
        default=None,
        metadata={
            "name": "MPEGProfile",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    mpeglevel: None | StringVideoEncMlevel = field(
        default=None,
        metadata={
            "name": "MPEGLevel",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    bitrate_max: None | int = field(
        default=None,
        metadata={
            "name": "BitrateMax",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    bit_rate_average: None | int = field(
        default=None,
        metadata={
            "name": "BitRateAverage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    vbr: None | StringVideoEncVbr = field(
        default=None,
        metadata={
            "name": "VBR",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    watermark: list[DigitalAssetWatermarkType] = field(
        default_factory=list,
        metadata={
            "name": "Watermark",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    actual_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "ActualLength",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetVideoPicture360Type(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPicture360-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    projection: str = field(
        metadata={
            "name": "Projection",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    rendering: None | str = field(
        default=None,
        metadata={
            "name": "Rendering",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    initial_view: None | DigitalAssetVideoPicture360InitialType = field(
        default=None,
        metadata={
            "name": "InitialView",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetVideoPictureFrameRateType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPictureFrameRate-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: int = field()
    multiplier: None | StringVideoPicFrameRateMultiplier = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    timecode: None | StringVideoPicFrameRateTimecode = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class DigitalAssetVideoPictureProgressiveType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPictureProgressive-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: bool = field()
    scan_order: None | StringVideoPicProgressiveScanOrder = field(
        default=None,
        metadata={
            "name": "scanOrder",
            "type": "Attribute",
        },
    )


class DigitalAssetVideoSubtitleLanguageType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoSubtitleLanguage-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(default="")
    closed: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    type_value: None | StringVideoSubLangType = field(
        default=None,
        metadata={
            "name": "type",
            "type": "Attribute",
        },
    )


class HashType(BaseModel):
    class Meta:
        name = "Hash-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        default="",
        metadata={
            "pattern": r"[0-9a-fA-F]+",
        },
    )
    method: None | StringHashMethod = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )


class NvpairMoneyType(BaseModel):
    class Meta:
        name = "NVPairMoney-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    name: str = field(
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    value: MoneyType = field(
        metadata={
            "name": "Value",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class OrgNameType(BaseModel):
    """
    restrict cardinalities, enumerate values for idType attribute.
    """

    class Meta:
        name = "OrgName-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    display_name: None | str = field(
        default=None,
        metadata={
            "name": "DisplayName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 256,
        },
    )
    sort_name: None | str = field(
        default=None,
        metadata={
            "name": "SortName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 256,
        },
    )
    alternate_name: list[str] = field(
        default_factory=list,
        metadata={
            "name": "AlternateName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_occurs": 32,
            "max_length": 256,
        },
    )
    organization_id: None | str = field(
        default=None,
        metadata={
            "name": "organizationID",
            "type": "Attribute",
        },
    )
    id_type: None | StringOrgNameIdType = field(
        default=None,
        metadata={
            "name": "idType",
            "type": "Attribute",
        },
    )


class PersonNameType(BaseModel):
    """
    restrict DisplayName and SortName to single occurrence, no space-only
    strings, no ; or :, minlength of 2.
    """

    class Meta:
        name = "PersonName-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    display_name: StringAndLanguageType = field(
        metadata={
            "name": "DisplayName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    sort_name: None | StringAndLanguageType = field(
        default=None,
        metadata={
            "name": "SortName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    first_given_name: None | str = field(
        default=None,
        metadata={
            "name": "FirstGivenName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    second_given_name: None | str = field(
        default=None,
        metadata={
            "name": "SecondGivenName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    family_name: None | str = field(
        default=None,
        metadata={
            "name": "FamilyName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    suffix: None | str = field(
        default=None,
        metadata={
            "name": "Suffix",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    moniker: None | str = field(
        default=None,
        metadata={
            "name": "Moniker",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class RegionType(BaseModel):
    class Meta:
        name = "Region-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    country_or_country_region: (
        None | RegionType.Country | RegionType.CountryRegion
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "country",
                    "type": ForwardRef("RegionType.Country"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "countryRegion",
                    "type": ForwardRef("RegionType.CountryRegion"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )

    class Country(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(
            default="",
            metadata={
                "pattern": r"[A-Z][A-Z]",
            },
        )

    class CountryRegion(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str | StringUnM49 = field(
            default="",
            metadata={
                "pattern": r"[A-Z][A-Z]-[A-Z0-9]+",
            },
        )


class CreationIdentifier(BaseModel):
    """
    A complex element describing an identifier used to identify a creation.

    An identifier is a type of name of which each instance is unique of its
    type: for example , the ISBN '9780946014491' belongs to only one book.

    :ivar value_or_non_uri_value_or_uri:
    :ivar type_value: The type of the creationIdentifier.
    """

    class Meta:
        name = "creationIdentifier"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value_or_non_uri_value_or_uri: list[
        CreationIdentifier.Value | CreationIdentifier.NonUriValue | Uri2
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "value",
                    "type": ForwardRef("CreationIdentifier.Value"),
                    "namespace": "http://www.doi.org/2010/DOISchema",
                },
                {
                    "name": "nonUriValue",
                    "type": ForwardRef("CreationIdentifier.NonUriValue"),
                    "namespace": "http://www.doi.org/2010/DOISchema",
                },
                {
                    "name": "uri",
                    "type": Uri2,
                    "namespace": "http://www.doi.org/2010/DOISchema",
                },
            ),
        },
    )
    type_value: CreationIdentifierType2 = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )

    class Value(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")

    class NonUriValue(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")


class LinkedParty(BaseModel):
    """
    A complex element describing another party with which the referentParty
    is associated.

    At least one of the elements 'partyName' or 'partyIdentifier' must be
    present, and at least one of the elements 'referentPartyRole' or
    'linkedPartyRole'.

    :ivar name: A name by which the linkedParty is known.
    :ivar identifier: An identifier of the linkedParty.
    :ivar referent_party_role: A role played by the referentParty in
        relation to the linkedParty (for example, the referentParty is a
        corporateSubsidiary of the linkedParty).
    :ivar linked_party_role: A role played by the linkedParty in
        relation to the referentParty (for example, the linkedParty is a
        corporateSubsidiary of the referentParty).
    """

    class Meta:
        name = "linkedParty"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    name: None | PartyName = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    identifier: None | PartyIdentifier = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    referent_party_role: None | PartyToPartyLinkRole = field(
        default=None,
        metadata={
            "name": "referentPartyRole",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    linked_party_role: None | PartyToPartyLinkRole = field(
        default=None,
        metadata={
            "name": "linkedPartyRole",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )


class PrincipalAgent(BaseModel):
    """
    A complex element describing a party principally responsible for the
    creation or publication of a referent.

    Either a 'partyName' or a 'partyIdentifier' element must be present.

    :ivar name: A name by which the principalAgent is known.
    :ivar identifier: An identifier of the principalAgent.
    :ivar role: A role played by the principalAgent.
    """

    class Meta:
        name = "principalAgent"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    name: None | PartyName = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    identifier: None | PartyIdentifier = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    role: None | AgentRole = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )


class SequenceIdentifier(BaseModel):
    """
    A complex element describing an identifier used to identify the order
    of a relationship between two entities.

    :ivar value: A text string representing the value of the
        sequenceIdentifier (for example, '1A').
    :ivar type_value: The type of the sequenceIdentifier.
    """

    class Meta:
        name = "sequenceIdentifier"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    value: str = field(
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    type_value: SequenceIdentifierType2 = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )


class Afi(AlternateIdtype):
    class Meta:
        name = "AFI"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Amg(AlternateIdtype):
    """
    AMG IDs from the V (video) or E (DVD) spaces.

    Can be the letter followed by up to 9 digits Future: may want to
    support othe letter followed by 1-9 digits left-padded to force field
    size to be 10.
    """

    class Meta:
        name = "AMG"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class AdId(AlternateIdtype):
    """
    4 alpha chars -- company code 7 alphanumeric -- generated code optional
    'H' -- for HD version.
    """

    class Meta:
        name = "Ad-ID"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Bfi(AlternateIdtype):
    class Meta:
        name = "BFI"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Baseline(AlternateIdtype):
    """
    This is an ID from the Project ID space, which covers Film, TV, Season,
    Episode, and DVD.

    To use this ID within the Baseline system you may need to look at the
    EIDR ReferentType and/or the Baseline IDs of any ancestors.
    """

    class Meta:
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Crid(AlternateIdtype):
    """
    a CRID is crid://dns name/data (see rfc 4078) 'crid' is
    case-insensitive this regular expression for the domain requires at
    least one . in the domain, and supports 2-4 character top level domains
    the other pieces of the domain are alphanumeric first char,
    alphanumeric or dash in the middle, alphanumeric last char, maximum 63
    characters data: doesn't include ? or # sections yet, and may be too
    restrictive.
    """

    class Meta:
        name = "CRID"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Doi(AlternateIdtype):
    """
    DOI from outside the eidr system.
    """

    class Meta:
        name = "DOI"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Ean(AlternateIdtype):
    class Meta:
        name = "EAN"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Grid(AlternateIdtype):
    """
    GRid is 2 char (identifier scheme), 5 char (issuer code), 10 char
    (release number), 1 char (check character) Letters must be upper case.

    Either all dashes are present, or none are.
    """

    class Meta:
        name = "GRid"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Gtin(AlternateIdtype):
    class Meta:
        name = "GTIN"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Imdb(AlternateIdtype):
    class Meta:
        name = "IMDB"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Isan(AlternateIdtype):
    """
    ISAN in form 4-4-4-4, 4-4-4-4-C (C is a checkdigit), 4-4-4-4-C-4-4-C,
    or 4-4-4-4-4-4 Hex digits and check digits must be upper case All
    occurrences in a string of "-" must be one of dash, space or nothing.

    The 24-digit forms must have both check digits, or neither.
    """

    class Meta:
        name = "ISAN"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Isrc(AlternateIdtype):
    """
    An ISRC is 2-char (non-digit) country code, 3 char (alpha or digit)
    registrant code, 2 digit year of reference, 5 digit designation code,
    with optional separating dashes.

    Letters are upper case. Either all dashes are present, or none are.
    """

    class Meta:
        name = "ISRC"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Istc(AlternateIdtype):
    """
    3 hex digits, 4 digits, 8 hex digits, ISO 7064 MOD16-3 check digit (The
    groups can be separated by nothing, a space, or a hyphen.

    The same separator must be used for the whole ID.).
    """

    class Meta:
        name = "ISTC"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Iva(AlternateIdtype):
    class Meta:
        name = "IVA"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Lumiere(AlternateIdtype):
    class Meta:
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Muze(AlternateIdtype):
    class Meta:
        name = "MUZE"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Proprietary(AlternateIdtype):
    """
    Any value allowed.

    Required attribute for domain of reference, e.g. " <AlternateID
    xmlns="" xmlns:xs="http://www.w3.org/2001/XMLSchema"
    domain="http://www.colossalcave.com"
    xs:type="{http://www.eidr.org/schema}Proprietary">XYZZY</AlternateID>
    ".
    """

    class Meta:
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    domain: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 4,
            "max_length": 256,
            "pattern": r"[\S]+[.][\S]+",
        }
    )


class SmpteUmid(AlternateIdtype):
    class Meta:
        name = "SMPTE-UMID"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class ShortDoi(AlternateIdtype):
    class Meta:
        name = "ShortDOI"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Trib(AlternateIdtype):
    class Meta:
        name = "TRIB"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Tvg(AlternateIdtype):
    class Meta:
        name = "TVG"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Upc(AlternateIdtype):
    """
    UPC is twelve decimal digits.
    """

    class Meta:
        name = "UPC"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Uri1(AlternateIdtype):
    """
    a URI for us is scheme://dns name/data [# query] [#fragment] scheme
    starts with a character, then (char digit + - .)* limited to total of
    12 the regular expression for the domain requires at least one . in the
    domain, and supports 2-4 character top level domains the other pieces
    of the domain are alphanumeric first char, alphanumeric or dash in the
    middle, alphanumeric last char, maximum 63 characters data is
    slash-separated, with an optional trailing slash. legal characters are
    0-9a-zA-Z _ - . ~ ! $ ampersand ' ( ) * + , ; = @ : optional query is
    as data, with the addition of / and ? optional fragment is as query
    data differences from full URI: -- limit on scheme length -- must have
    domain name, can't have userinfo@host:port -- dns names only, not IP
    addresses -- there must be /something after the domain.
    """

    class Meta:
        name = "URI"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Urn(AlternateIdtype):
    class Meta:
        name = "URN"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class Uuid(AlternateIdtype):
    """
    UUID in form 8-4-4-4-12.

    Both upper and lowercase hex digits allowed.
    """

    class Meta:
        name = "UUID"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class AliasContinuationType(BaseModel):
    class Meta:
        name = "aliasContinuationType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    last_aliased: AssetDoitype = field(
        metadata={
            "name": "LastAliased",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    target_of_last_aliased: AssetDoitype = field(
        metadata={
            "name": "TargetOfLastAliased",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class AlternateContentInfoType(BaseModel):
    class Meta:
        name = "alternateContentInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_content_class: AlternateContentClassType = field(
        metadata={
            "name": "AlternateContentClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class AlternateIdsType(BaseModel):
    """
    An asset's AlternateIDs only.
    """

    class Meta:
        name = "alternateIDsType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_id: list[AlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class CIdf(AlternateIdtype):
    class Meta:
        name = "cIDF"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class ClipInfoType(BaseModel):
    """
    A clip can be just an ID, an ID with start and duration, or an ID with
    just duration.
    """

    class Meta:
        name = "clipInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    parent: AssetDoitype = field(
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    components_mode: ComponentsModeType = field(
        metadata={
            "name": "ComponentsMode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    start_or_duration: list[ClipInfoType.Start | ClipInfoType.Duration] = (
        field(
            default_factory=list,
            metadata={
                "type": "Elements",
                "choices": (
                    {
                        "name": "Start",
                        "type": ForwardRef("ClipInfoType.Start"),
                        "namespace": "http://www.eidr.org/schema",
                    },
                    {
                        "name": "Duration",
                        "type": ForwardRef("ClipInfoType.Duration"),
                        "namespace": "http://www.eidr.org/schema",
                    },
                ),
                "max_occurs": 2,
            },
        )
    )

    class Start(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlDuration = field()

    class Duration(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlDuration = field()


class CompositeElementType(BaseModel):
    class Meta:
        name = "compositeElementType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id_or_other_id: None | AssetDoitype | AlternateIdtype = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "ID",
                    "type": AssetDoitype,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "OtherID",
                    "type": AlternateIdtype,
                    "namespace": "http://www.eidr.org/schema",
                },
            ),
        },
    )
    source_start: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "SourceStart",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    source_duration: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "SourceDuration",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    components_mode: None | ComponentsModeType = field(
        default=None,
        metadata={
            "name": "ComponentsMode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    dest_start: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "DestStart",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    dest_duration: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "DestDuration",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_length": 128,
        },
    )


class CreditsType(BaseModel):
    class Meta:
        name = "creditsType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    director: list[PersonNameType] = field(
        default_factory=list,
        metadata={
            "name": "Director",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 2,
        },
    )
    actor: list[PersonNameType] = field(
        default_factory=list,
        metadata={
            "name": "Actor",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 4,
        },
    )


class EditInfoType(BaseModel):
    """
    An edit must provide, rather than inherit, Description,
    ApproximateLength, and ReleaseDate on baseRegistrationData.
    """

    class Meta:
        name = "editInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    parent: AssetDoitype = field(
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    edit_use: EditUseType = field(
        metadata={
            "name": "EditUse",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    edit_class: list[EditClassType] = field(
        default_factory=list,
        metadata={
            "name": "EditClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 8,
        },
    )
    made_for_region: list[MadeForRegionType] = field(
        default_factory=list,
        metadata={
            "name": "MadeForRegion",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 8,
        },
    )
    edit_details: list[UsageDetailsType] = field(
        default_factory=list,
        metadata={
            "name": "EditDetails",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 8,
        },
    )
    color_type: ColorTypeType = field(
        metadata={
            "name": "ColorType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    three_d: bool = field(
        metadata={
            "name": "ThreeD",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class EpisodeInfoType(BaseModel):
    """
    Episode must supply base object, ReferentType, StructuralType,
    ReleaseDate.

    If Episode is a child of a Season, it inherits the Season's TimeSlot.
    baseObjectData.ApproximateLength is used for the length of the episode
    baseObjectData.ResourceName is used to provide an episode title and is
    required, but may be submitted empty or replaced with a
    system-generated name under special circumstances.
    """

    class Meta:
        name = "episodeInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    parent: AssetDoitype = field(
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    sequence_info: None | ContentSequenceInfoType = field(
        default=None,
        metadata={
            "name": "SequenceInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    episode_class: list[EpisodeClassType] = field(
        default_factory=list,
        metadata={
            "name": "EpisodeClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    time_slot: None | XmlTime = field(
        default=None,
        metadata={
            "name": "TimeSlot",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class LinkedAlternateIdtype(BaseModel):
    """
    An AlternateID together with 0 or more URL elements.
    """

    class Meta:
        name = "linkedAlternateIDType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    alternate_id: AlternateIdtype = field(
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    url: list[LinkedAlternateIdurltype] = field(
        default_factory=list,
        metadata={
            "name": "URL",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class PackagingInfoType(BaseModel):
    class Meta:
        name = "packagingInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    packaging_class: PackagingClassType = field(
        metadata={
            "name": "PackagingClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class PartyCreationType(BaseModel):
    """
    Used when creating a party, which is the only time the password is
    handed around.
    """

    class Meta:
        name = "partyCreationType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    party_name: OrgNameType = field(
        metadata={
            "name": "PartyName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_party_name: list[str] = field(
        default_factory=list,
        metadata={
            "name": "AlternatePartyName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 20,
            "max_length": 256,
        },
    )
    contact_info: ContactInfoType = field(
        metadata={
            "name": "ContactInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    active: bool = field(
        metadata={
            "name": "Active",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    party_account_name: None | str = field(
        default=None,
        metadata={
            "name": "PartyAccountName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"[0-9a-zA-Z_# \.\-\(\)]{2,64}",
        },
    )
    allowed_roles: list[AdministratorTypeType] = field(
        default_factory=list,
        metadata={
            "name": "AllowedRoles",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    password: str = field(
        metadata={
            "name": "Password",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_length": 6,
            "max_length": 32,
        }
    )


class PartyResolutionType(BaseModel):
    """
    Returned when resolving a party; Used when modifying a party.

    Passwords are modified with a separate call, and not returned when
    resolving.
    """

    class Meta:
        name = "partyResolutionType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: str = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5237/[0-9a-fA-F]{4}-[0-9a-fA-F]{4}|10\.5237/superparty",
        }
    )
    party_name: OrgNameType = field(
        metadata={
            "name": "PartyName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_party_name: list[str] = field(
        default_factory=list,
        metadata={
            "name": "AlternatePartyName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 20,
            "max_length": 256,
        },
    )
    contact_info: ContactInfoType = field(
        metadata={
            "name": "ContactInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    active: bool = field(
        metadata={
            "name": "Active",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    party_account_name: None | str = field(
        default=None,
        metadata={
            "name": "PartyAccountName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"[0-9a-zA-Z_# \.\-\(\)]{2,64}",
        },
    )
    allowed_roles: list[AdministratorTypeType] = field(
        default_factory=list,
        metadata={
            "name": "AllowedRoles",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class PromotionInfoType(BaseModel):
    class Meta:
        name = "promotionInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    promotion_class: PromotionClassType = field(
        metadata={
            "name": "PromotionClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class ProvenanceInfoType(BaseModel):
    """
    Returned by provenance resolution.
    """

    class Meta:
        name = "provenanceInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    issue_number: int = field(
        metadata={
            "name": "IssueNumber",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    status: StatusType = field(
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    administrators: AdministratorsInfoType = field(
        metadata={
            "name": "Administrators",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    created_by: None | str = field(
        default=None,
        metadata={
            "name": "CreatedBy",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5238/[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        },
    )
    creation_date: XmlDateTime = field(
        metadata={
            "name": "CreationDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    last_modified_by: None | str = field(
        default=None,
        metadata={
            "name": "LastModifiedBy",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "pattern": r"10\.5238/[0-9a-zA-Z_#\.\-\(\)]{3,32}",
        },
    )
    last_modification_date: XmlDateTime = field(
        metadata={
            "name": "LastModificationDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    publication_date: None | XmlDateTime = field(
        default=None,
        metadata={
            "name": "PublicationDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class RelationshipInfoType(AssetDoitype):
    """
    a relationship is described with " <Relationship xmlns=""
    type="{http://www.eidr.org/schema}isSeasonOf">assetDOI</Relationship> "
    isCompositeOf and isCompilation of can occur multiple times in a
    relationship list (see SimpleMetadata), once for each item in the
    composite.

    The lightweight relationships ca occur multiple times. Other
    relationships occur once on any given object.
    """

    class Meta:
        name = "relationshipInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    type_value: RelationshipType = field(
        metadata={
            "name": "type",
            "type": "Attribute",
        }
    )


class SeasonInfoType(BaseModel):
    """
    Season must supply base object ReferentType, StructuralType, and
    ReleaseDate. baseObjectData.ApproximateLength must be 0 (zero) the
    typical length of an episode. baseObjectData.ResourceName is used to
    provide a season title and is required, but may be submitted empty or
    replaced with a system-generated name under special circumstances.
    """

    class Meta:
        name = "seasonInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    parent: AssetDoitype = field(
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    end_date: None | XmlPeriod | XmlDate = field(
        default=None,
        metadata={
            "name": "EndDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    season_class: list[SeasonClassType] = field(
        default_factory=list,
        metadata={
            "name": "SeasonClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    number_required: None | bool = field(
        default=None,
        metadata={
            "name": "NumberRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    date_required: None | bool = field(
        default=None,
        metadata={
            "name": "DateRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    original_title_required: None | bool = field(
        default=None,
        metadata={
            "name": "OriginalTitleRequired",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    sequence_number: None | int = field(
        default=None,
        metadata={
            "name": "SequenceNumber",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class SupplementalContentInfoType(BaseModel):
    class Meta:
        name = "supplementalContentInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    supplemental_content_class: SupplementalContentClassType = field(
        metadata={
            "name": "SupplementalContentClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class VirtualFieldsType(BaseModel):
    class Meta:
        name = "virtualFieldsType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    full: None | str = field(
        default=None,
        metadata={
            "name": "Full",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    self_defined: None | str = field(
        default=None,
        metadata={
            "name": "SelfDefined",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alias: None | str = field(
        default=None,
        metadata={
            "name": "Alias",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class AssociatedOrgType(OrgNameType):
    class Meta:
        name = "AssociatedOrg-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    role: StringAssociatedOrgRole = field(
        metadata={
            "type": "Attribute",
        }
    )


class BasicMetadataParentType(BaseModel):
    class Meta:
        name = "BasicMetadataParent-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    parent_content_id_or_parent: None | str | BasicMetadataType = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "ParentContentID",
                    "type": str,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                    "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
                },
                {
                    "name": "Parent",
                    "type": ForwardRef("BasicMetadataType"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )
    sequence_info: None | ContentSequenceInfoType = field(
        default=None,
        metadata={
            "name": "SequenceInfo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    region_or_excluded_region: list[
        BasicMetadataParentType.Region | BasicMetadataParentType.ExcludedRegion
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Region",
                    "type": ForwardRef("BasicMetadataParentType.Region"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "ExcludedRegion",
                    "type": ForwardRef(
                        "BasicMetadataParentType.ExcludedRegion"
                    ),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )
    relationship_type: None | BasicMetadataParentTypeRelationshipType = field(
        default=None,
        metadata={
            "name": "relationshipType",
            "type": "Attribute",
        },
    )

    class Region(RegionType):
        pass
        model_config = ConfigDict(defer_build=True)

    class ExcludedRegion(RegionType):
        pass
        model_config = ConfigDict(defer_build=True)


class CompObjType(BaseModel):
    class Meta:
        name = "CompObj-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    entry: list[CompObjEntryType] = field(
        default_factory=list,
        metadata={
            "name": "Entry",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    compilation_class: CompObjClassType = field(
        metadata={
            "name": "CompilationClass",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class CompanyCreditsType(BaseModel):
    class Meta:
        name = "CompanyCredits-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    display_string: list[CompanyCreditsType.DisplayString] = field(
        default_factory=list,
        metadata={
            "name": "DisplayString",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    region: list[RegionType] = field(
        default_factory=list,
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    display_sequence: None | int = field(
        default=None,
        metadata={
            "name": "DisplaySequence",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class DisplayString(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRatingDetailType(BaseModel):
    class Meta:
        name = "ContentRatingDetail-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    region: RegionType = field(
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    system: str = field(
        metadata={
            "name": "System",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    value: str = field(
        metadata={
            "name": "Value",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    reason: list[ContentRatingDetailType.Reason] = field(
        default_factory=list,
        metadata={
            "name": "Reason",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    link_to_logo: list[ContentRatingDetailType.LinkToLogo] = field(
        default_factory=list,
        metadata={
            "name": "LinkToLogo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRatingDetailType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Reason(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        value_attribute: None | str = field(
            default=None,
            metadata={
                "name": "value",
                "type": "Attribute",
            },
        )

    class LinkToLogo(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        authoritative: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        origin: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRelatedToPersonType(BaseModel):
    class Meta:
        name = "ContentRelatedToPerson-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    identifier: list[PersonIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "Identifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    name: PersonNameType = field(
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    description: list[ContentRelatedToPersonType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ContentRelatedToPlaceType(BaseModel):
    class Meta:
        name = "ContentRelatedToPlace-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    region: None | RegionType = field(
        default=None,
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    address: None | str = field(
        default=None,
        metadata={
            "name": "Address",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    earth_coordinate: None | CoordinateEarthType = field(
        default=None,
        metadata={
            "name": "EarthCoordinate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    other_coordinate: None | CoordinateOtherType = field(
        default=None,
        metadata={
            "name": "OtherCoordinate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[ContentRelatedToPlaceType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetCardsetListType(BaseModel):
    class Meta:
        name = "DigitalAssetCardsetList-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: list[StringCardsetListType] = field(
        default_factory=list,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    region: list[MadeForRegionType] = field(
        default_factory=list,
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    cardset: list[DigitalAssetCardsetType] = field(
        default_factory=list,
        metadata={
            "name": "Cardset",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )


class DigitalAssetColorTransformMetadataType(BaseModel):
    class Meta:
        name = "DigitalAssetColorTransformMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    color_volume_transform: str = field(
        metadata={
            "name": "ColorVolumeTransform",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    application_identifier: (
        None | DigitalAssetColorTransformMetadataType.ApplicationIdentifier
    ) = field(
        default=None,
        metadata={
            "name": "ApplicationIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    target_system_display: None | DigitalAssetColorVolumeType = field(
        default=None,
        metadata={
            "name": "TargetSystemDisplay",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    do_not_transcode_base: None | bool = field(
        default=None,
        metadata={
            "name": "DoNotTranscodeBase",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class ApplicationIdentifier(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: int = field()
        application_version: None | int = field(
            default=None,
            metadata={
                "name": "applicationVersion",
                "type": "Attribute",
            },
        )


class DigitalAssetVideoPictureType(BaseModel):
    """
    redefine to require AspectRatio.
    """

    class Meta:
        name = "DigitalAssetVideoPicture-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    aspect_ratio: str = field(
        metadata={
            "name": "AspectRatio",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"[0-9]{1,2}:[0-9]|([0-9]\.[0-9][0-9]):[0-9]",
        }
    )
    pixel_aspect: None | StringVideoPicPixelAspect = field(
        default=None,
        metadata={
            "name": "PixelAspect",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    width_pixels: None | int = field(
        default=None,
        metadata={
            "name": "WidthPixels",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    height_pixels: None | int = field(
        default=None,
        metadata={
            "name": "HeightPixels",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    active_width_pixels: None | int = field(
        default=None,
        metadata={
            "name": "ActiveWidthPixels",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    active_height_pixels: None | int = field(
        default=None,
        metadata={
            "name": "ActiveHeightPixels",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    frame_rate: None | DigitalAssetVideoPictureFrameRateType = field(
        default=None,
        metadata={
            "name": "FrameRate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    progressive: None | DigitalAssetVideoPictureProgressiveType = field(
        default=None,
        metadata={
            "name": "Progressive",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    color_subsampling: None | StringVideoPicColorSampling = field(
        default=None,
        metadata={
            "name": "ColorSubsampling",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    colorimetry: None | StringVideoPicColorimetry = field(
        default=None,
        metadata={
            "name": "Colorimetry",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    type3_d: None | StringVideoPicType3D = field(
        default=None,
        metadata={
            "name": "Type3D",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetVideoPictureOriginalType(BaseModel):
    class Meta:
        name = "DigitalAssetVideoPictureOriginal-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    frame_rate: None | DigitalAssetVideoPictureFrameRateType = field(
        default=None,
        metadata={
            "name": "FrameRate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    progressive: None | DigitalAssetVideoPictureProgressiveType = field(
        default=None,
        metadata={
            "name": "Progressive",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class GroupingEntityType(BaseModel):
    class Meta:
        name = "GroupingEntity-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: str = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    group_identity: str = field(
        metadata={
            "name": "GroupIdentity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    display_name: list[GroupingEntityType.DisplayName] = field(
        default_factory=list,
        metadata={
            "name": "DisplayName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    region: None | RegionType = field(
        default=None,
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    alt_group_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "AltGroupIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class DisplayName(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class TermsType(BaseModel):
    class Meta:
        name = "Terms-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    choice: (
        None
        | MoneyType
        | TermsType.Event
        | TermsType.Text
        | bool
        | XmlDuration
        | TermsType.Uri
        | TermsType.Language
        | TermsType.Id
        | ContentIdentifierType
        | TermsType.YearDateTime
        | XmlTime
        | RegionType
        | object
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Money",
                    "type": MoneyType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Event",
                    "type": ForwardRef("TermsType.Event"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Text",
                    "type": ForwardRef("TermsType.Text"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Boolean",
                    "type": bool,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Duration",
                    "type": XmlDuration,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "URI",
                    "type": ForwardRef("TermsType.Uri"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Language",
                    "type": ForwardRef("TermsType.Language"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "ID",
                    "type": ForwardRef("TermsType.Id"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "AltIdentifier",
                    "type": ContentIdentifierType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "YearDateTime",
                    "type": ForwardRef("TermsType.YearDateTime"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Time",
                    "type": XmlTime,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Region",
                    "type": RegionType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "wildcard": True,
                    "type": object,
                    "namespace": "##other",
                },
            ),
        },
    )
    term_name: str = field(
        metadata={
            "name": "termName",
            "type": "Attribute",
        }
    )

    class Event(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlDateTime | XmlDate = field()

    class Text(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")

    class Uri(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")

    class Language(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")

    class Id(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")

    class YearDateTime(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlPeriod | XmlDate | XmlDateTime = field()


class LinkedCreation(BaseModel):
    """
    A complex element describing another creation with which the
    referentCreation is associated.

    At least one of the elements 'creationName' or 'creationIdentifier'
    must be present (the latter being preferably a doiName), and at least
    one of the elements 'referentCreationRole' or 'linkedCreationRole'.

    :ivar name: A name or title by which the linkedCreation is known.
    :ivar identifier: An identifier of the linkedCreation.
    :ivar referent_creation_role: A role played by the referentCreation
        in relation to the linkedCreation (for example, the
        referentCreation is an edition of the linkedCreation).
    :ivar linked_creation_role: A role played by the linkedCreation in
        relation to the referentCreation (for example, the
        linkedCreation is an edition of the referentCreation).
    :ivar referent_creation_sequence_identifier: An identifier of the
        referentCreation, giving the order in which it appears within a
        list of creations linked to the linkedCreation.
    :ivar linked_creation_sequence_identifier: An identifier of the
        linkedCreation, giving the order in which it appears within a
        list of creations linked to the referentCreation.
    """

    class Meta:
        name = "linkedCreation"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    name: list[CreationName] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    identifier: list[CreationIdentifier] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    referent_creation_role: None | CreationToCreationLinkRole = field(
        default=None,
        metadata={
            "name": "referentCreationRole",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    linked_creation_role: None | CreationToCreationLinkRole = field(
        default=None,
        metadata={
            "name": "linkedCreationRole",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    referent_creation_sequence_identifier: list[SequenceIdentifier] = field(
        default_factory=list,
        metadata={
            "name": "referentCreationSequenceIdentifier",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    linked_creation_sequence_identifier: list[SequenceIdentifier] = field(
        default_factory=list,
        metadata={
            "name": "linkedCreationSequenceIdentifier",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )


class ReferentParty(BaseModel):
    """
    A complex element describing the party identified by the doiName to
    which the kernelMetadata applies.

    :ivar name: A name by which the referentParty is known. For Kernel
        Metadata in a restricted Application Profile the string 'No
        information available' should be used, with a partyNameType of
        'name'.
    :ivar identifier: An identifier of the referentParty.
    :ivar structural_type: The primary structuralType of the
        referentParty.
    :ivar associated_role: For parties, the referentType represents a
        role with which the party is commonly associated, not
        necessarily a permanent type.
    :ivar date_of_birth_or_formation: The date of birth (for an
        individual or animal) or formation (for an organization) of the
        referentParty. If an organization was (re)formed on one or more
        occasion, this date should represent the latest date of
        formation.
    :ivar date_of_death_or_dissolution: The date of death (for an
        individual or animal) or dissolution (for an organization) of
        the referentParty. If an organization was dissolved on one or
        more occasion, this date should represent the latest date of
        dissolution.
    :ivar associated_territory: A territory with which the referentParty
        is associated (for example, a territory of birth, nationality or
        residence). As with other elements (dates and referentType) this
        element is included to support the disambiguation of one party
        with another.
    :ivar linked_party: Another party to whom the referentParty is
        linked, with identification of link role (eg member, department,
        corporate subsiduary, child, sibling). This element is included
        in Kernel Metadata as it may be critical for the identification
        of an organization which exists only as part of another
        organization.
    """

    class Meta:
        name = "referentParty"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    name: list[PartyName] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    identifier: list[PartyIdentifier] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    structural_type: PartyStructuralType = field(
        metadata={
            "name": "structuralType",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    associated_role: list[AssociatedPartyRole] = field(
        default_factory=list,
        metadata={
            "name": "associatedRole",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    date_of_birth_or_formation: None | Date = field(
        default=None,
        metadata={
            "name": "dateOfBirthOrFormation",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    date_of_death_or_dissolution: None | Date = field(
        default=None,
        metadata={
            "name": "dateOfDeathOrDissolution",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    associated_territory: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "associatedTerritory",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    linked_party: list[LinkedParty] = field(
        default_factory=list,
        metadata={
            "name": "linkedParty",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )


class BaseObjectInfoType(BaseModel):
    class Meta:
        name = "baseObjectInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    structural_type: CreationStructuralType = field(
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    mode: ModeType = field(
        metadata={
            "name": "Mode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    referent_type: ReferentType = field(
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    resource_name: TitleType = field(
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_resource_name: list[TitleType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 128,
        },
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 16,
        },
    )
    release_date: XmlPeriod | XmlDate = field(
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    country_of_origin: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 32,
        },
    )
    status: StatusType = field(
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    approximate_length: XmlDuration = field(
        metadata={
            "name": "ApproximateLength",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_id: list[AlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    administrators: AdministratorsInfoType = field(
        metadata={
            "name": "Administrators",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    credits: None | CreditsType = field(
        default=None,
        metadata={
            "name": "Credits",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    registrant_extra: None | str = field(
        default=None,
        metadata={
            "name": "RegistrantExtra",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_length": 128,
        },
    )
    description: None | DescriptionType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class CompositeInfoType(BaseModel):
    class Meta:
        name = "compositeInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    composite_class: CompositeClassType = field(
        metadata={
            "name": "CompositeClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    element: list[CompositeElementType] = field(
        default_factory=list,
        metadata={
            "name": "Element",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class CreationFullInfo(BaseModel):
    class Meta:
        name = "creationFullInfo"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    structural_type: CreationStructuralType = field(
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    mode: ModeType = field(
        metadata={
            "name": "Mode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    referent_type: ReferentType = field(
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    resource_name: TitleType = field(
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_resource_name: list[TitleType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 128,
        },
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 16,
        },
    )
    release_date: XmlPeriod | XmlDate = field(
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    country_of_origin: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 32,
        },
    )
    status: StatusType = field(
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    approximate_length: XmlDuration = field(
        metadata={
            "name": "ApproximateLength",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    alternate_id: list[AlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    administrators: AdministratorsInfoType = field(
        metadata={
            "name": "Administrators",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    credits: None | CreditsType = field(
        default=None,
        metadata={
            "name": "Credits",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    registrant_extra: None | str = field(
        default=None,
        metadata={
            "name": "RegistrantExtra",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_length": 128,
        },
    )
    description: None | DescriptionType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class CreationSelfDefinedInfo(BaseModel):
    class Meta:
        name = "creationSelfDefinedInfo"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    structural_type: None | CreationStructuralType = field(
        default=None,
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    mode: None | ModeType = field(
        default=None,
        metadata={
            "name": "Mode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    referent_type: None | ReferentType = field(
        default=None,
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    resource_name: None | TitleType = field(
        default=None,
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_resource_name: list[TitleType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 128,
        },
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 16,
        },
    )
    release_date: None | XmlPeriod | XmlDate = field(
        default=None,
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    country_of_origin: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    status: None | StatusType = field(
        default=None,
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    approximate_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "ApproximateLength",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_id: list[AlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    administrators: AdministratorsInfoType = field(
        metadata={
            "name": "Administrators",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    credits: None | CreditsType = field(
        default=None,
        metadata={
            "name": "Credits",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    registrant_extra: None | str = field(
        default=None,
        metadata={
            "name": "RegistrantExtra",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_length": 128,
        },
    )
    description: None | DescriptionType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class InheritedBaseObjectInfoType(BaseModel):
    """
    ID, Administrators, AlternateIDs, and Description can never be
    inherited.

    ResourceName and AlternateResourceName are never inherited for Seasons
    or Episodes. Everything else can be, but doesn't have to be.
    """

    class Meta:
        name = "inheritedBaseObjectInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    structural_type: None | CreationStructuralType = field(
        default=None,
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    mode: None | ModeType = field(
        default=None,
        metadata={
            "name": "Mode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    referent_type: None | ReferentType = field(
        default=None,
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    resource_name: None | TitleType = field(
        default=None,
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_resource_name: list[TitleType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 128,
        },
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 16,
        },
    )
    release_date: None | XmlPeriod | XmlDate = field(
        default=None,
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    country_of_origin: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    status: None | StatusType = field(
        default=None,
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    approximate_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "ApproximateLength",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    credits: None | CreditsType = field(
        default=None,
        metadata={
            "name": "Credits",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class LinkedAlternateIdsType(BaseModel):
    """
    An asset's AlternateIDs and associated URLs.
    """

    class Meta:
        name = "linkedAlternateIDsType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    linked_alternate_id: list[LinkedAlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "LinkedAlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class RelationshipsInfoType(BaseModel):
    class Meta:
        name = "relationshipsInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    relationship: list[RelationshipInfoType] = field(
        default_factory=list,
        metadata={
            "name": "Relationship",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class SelfDefinedBaseObjectInfoType(BaseModel):
    """
    This is what you get when you do a resolution for self-defined
    metadata.

    ID and Administrators must be defined on every object. AlternateIDs,
    RegistrantExtra are never inherited, but can be optionally provided.
    Everything else can come from self or parent, and hence is optional
    here. VersionLanguages are only those defined on the object, rather
    than constructed from a Manifestation.
    """

    class Meta:
        name = "selfDefinedBaseObjectInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    structural_type: None | CreationStructuralType = field(
        default=None,
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    mode: None | ModeType = field(
        default=None,
        metadata={
            "name": "Mode",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    referent_type: None | ReferentType = field(
        default=None,
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    resource_name: None | TitleType = field(
        default=None,
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_resource_name: list[TitleType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 128,
        },
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 16,
        },
    )
    release_date: None | XmlPeriod | XmlDate = field(
        default=None,
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    country_of_origin: list[TerritoryCode] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 32,
        },
    )
    status: None | StatusType = field(
        default=None,
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    approximate_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "ApproximateLength",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_id: list[AlternateIdtype] = field(
        default_factory=list,
        metadata={
            "name": "AlternateID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    administrators: AdministratorsInfoType = field(
        metadata={
            "name": "Administrators",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    credits: None | CreditsType = field(
        default=None,
        metadata={
            "name": "Credits",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    registrant_extra: None | str = field(
        default=None,
        metadata={
            "name": "RegistrantExtra",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_length": 128,
        },
    )
    description: None | DescriptionType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class SimpleInfoType(BaseModel):
    class Meta:
        name = "simpleInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    id: AssetDoitype = field(
        metadata={
            "name": "ID",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    structural_type: CreationStructuralType = field(
        metadata={
            "name": "StructuralType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    referent_type: ReferentType = field(
        metadata={
            "name": "ReferentType",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    resource_name: TitleType = field(
        metadata={
            "name": "ResourceName",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    original_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 32,
        },
    )
    version_language: list[LanguageType] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 64,
        },
    )
    release_date: XmlPeriod | XmlDate = field(
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    status: StatusType = field(
        metadata={
            "name": "Status",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    relationship: list[RelationshipInfoType] = field(
        default_factory=list,
        metadata={
            "name": "Relationship",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class AudienceType(BaseModel):
    class Meta:
        name = "Audience-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    who: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Who",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    when: list[AudienceType.When] = field(
        default_factory=list,
        metadata={
            "name": "When",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    what: list[AudienceType.What] = field(
        default_factory=list,
        metadata={
            "name": "What",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    identification: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "Identification",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    terms: list[TermsType] = field(
        default_factory=list,
        metadata={
            "name": "Terms",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class When(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")
        start_date: None | XmlPeriod | XmlDate | XmlDateTime = field(
            default=None,
            metadata={
                "name": "startDate",
                "type": "Attribute",
            },
        )
        end_date: None | XmlPeriod | XmlDate | XmlDateTime = field(
            default=None,
            metadata={
                "name": "endDate",
                "type": "Attribute",
            },
        )

    class What(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")
        bonus: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        condition: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class BasicMetadataCharacterType(BaseModel):
    class Meta:
        name = "BasicMetadataCharacter-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    character_name: list[BasicMetadataCharacterType.CharacterName] = field(
        default_factory=list,
        metadata={
            "name": "CharacterName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    character_id: list[PersonIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "CharacterID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    nonfictional: None | BasicMetadataCharacterType.Nonfictional = field(
        default=None,
        metadata={
            "name": "Nonfictional",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    gender: list[GenderType] = field(
        default_factory=list,
        metadata={
            "name": "Gender",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    grouping_entity: list[GroupingEntityType] = field(
        default_factory=list,
        metadata={
            "name": "GroupingEntity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sequence: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class CharacterName(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Nonfictional(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: bool = field()
        appearance: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class CompObjDataType(CompObjType):
    class Meta:
        name = "CompObjData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    display_name: list[CompObjDataType.DisplayName] = field(
        default_factory=list,
        metadata={
            "name": "DisplayName",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    comp_obj_id: None | str = field(
        default=None,
        metadata={
            "name": "CompObjID",
            "type": "Attribute",
        },
    )

    class DisplayName(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class CompatibilityType(BaseModel):
    """
    :ivar spec_version: Version of the specification to which this
        document is authored
    :ivar system:
    :ivar profile:
    :ivar validator_parameter:
    """

    class Meta:
        name = "Compatibility-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    spec_version: str = field(
        metadata={
            "name": "SpecVersion",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    system: list[str] = field(
        default_factory=list,
        metadata={
            "name": "System",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    profile: CompatibilityType.Profile = field(
        metadata={
            "name": "Profile",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    validator_parameter: list[TermsType] = field(
        default_factory=list,
        metadata={
            "name": "ValidatorParameter",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Profile(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        sub_profile: None | str = field(
            default=None,
            metadata={
                "name": "subProfile",
                "type": "Attribute",
            },
        )


class ComplianceType(BaseModel):
    class Meta:
        name = "Compliance-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    category: None | str = field(
        default=None,
        metadata={
            "name": "Category",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    standard: None | str = field(
        default=None,
        metadata={
            "name": "Standard",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    disposition: str = field(
        metadata={
            "name": "Disposition",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    competent_authority: None | AssociatedOrgType = field(
        default=None,
        metadata={
            "name": "CompetentAuthority",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    certificate: None | ComplianceType.Certificate = field(
        default=None,
        metadata={
            "name": "Certificate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    testing_organization: None | AssociatedOrgType = field(
        default=None,
        metadata={
            "name": "TestingOrganization",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    testing_method: None | str = field(
        default=None,
        metadata={
            "name": "TestingMethod",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    comments: None | str = field(
        default=None,
        metadata={
            "name": "Comments",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Certificate(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: bytes = field(
            default=b"",
            metadata={
                "format": "base64",
            },
        )
        mime: None | str = field(
            default=None,
            metadata={
                "name": "MIME",
                "type": "Attribute",
            },
        )


class ContainerSpecificType(BaseModel):
    class Meta:
        name = "ContainerSpecific-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    encoding_agent: None | AssociatedOrgType = field(
        default=None,
        metadata={
            "name": "EncodingAgent",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: None | StringAndLanguageType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class ContentRatingType(BaseModel):
    class Meta:
        name = "ContentRating-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    not_rated_or_rating: list[
        ContentRatingType.NotRated | ContentRatingDetailType
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "NotRated",
                    "type": ForwardRef("ContentRatingType.NotRated"),
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Rating",
                    "type": ContentRatingDetailType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )
    adult_content: None | bool = field(
        default=None,
        metadata={
            "name": "AdultContent",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class NotRated(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: bool = field()
        condition: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class PrivateDataType(BaseModel):
    class Meta:
        name = "PrivateData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    encoding_agent: None | AssociatedOrgType = field(
        default=None,
        metadata={
            "name": "EncodingAgent",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: None | StringAndLanguageType = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    hash: list[HashType] = field(
        default_factory=list,
        metadata={
            "name": "Hash",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_occurs": 8,
        },
    )
    size: None | PrivateDataType.Size = field(
        default=None,
        metadata={
            "name": "Size",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Size(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: int = field()
        pad: None | int = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ReleaseHistoryType(BaseModel):
    class Meta:
        name = "ReleaseHistory-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    release_type: ReleaseHistoryType.ReleaseType = field(
        metadata={
            "name": "ReleaseType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    distr_territory: list[RegionType] = field(
        default_factory=list,
        metadata={
            "name": "DistrTerritory",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    date: ReleaseHistoryType.Date = field(
        metadata={
            "name": "Date",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    release_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "ReleaseOrg",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class ReleaseType(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: str = field(default="")
        wide: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Date(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: XmlPeriod | XmlDate | XmlDateTime = field()
        scheduled: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class ReferentCreation(BaseModel):
    """
    A complex element describing the creation identified by the doiName to
    which the kernelMetadata applies.

    :ivar name: A name or title by which the referentCreation is known.
        For Kernel Metadata in a restricted Application Profile the
        string 'No information available' should be used, with a
        creationNameType of 'name'.
    :ivar identifier: An identifier of the referentCreation.
    :ivar structural_type: The primary structuralType of a
        referentCreation. For creations there are four mutually
        exclusive structuralTypes (physical, digital, performance and
        abstraction) that allow classification according to overall
        form. Where structuralTypes may be contained within one another,
        the referent's structuralType is defined by the overall form.
        For example a CD (physical) may contain files (digital) which
        contain recordings of performances of songs (abstractions), and
        elements of content can be further classified if necessary under
        referentType.
    :ivar mode: A principal sensory mode in which a referentCreation is
        intended to be perceived (audio, visual, tangible, olfactory,
        tasteable, none). Mode identifies only the principal intended
        modes of perception: most physical creations are perceivable
        with all five senses, but some of these perceptions may be
        trivial. For example, a printed book may be touched or smelled,
        but these are normally supplementary or incidental to the visual
        mode for its intended function as a content carrier. For a
        Braille book, however, touch would be a principal mode. One
        creation may be perceived in several modes (audio and visual
        being much the most common combination).
    :ivar character: A fundamental form of communication (language,
        music, image, other) in which the content of a referentCreation
        is expressed.
    :ivar type_value: A class of creation to which the referentCreation
        belongs.
    :ivar principal_agent: A party (either an individual or an
        organization) principally responsible for the creation or
        publication of the referentCreation.
    :ivar linked_creation: Another creation with which the
        referentCreation is associated.
    """

    class Meta:
        name = "referentCreation"
        target_namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True)
    name: list[CreationName] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    identifier: list[CreationIdentifier] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )
    structural_type: CreationStructuralType = field(
        metadata={
            "name": "structuralType",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        }
    )
    mode: list[Mode] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    character: list[Character] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    type_value: list[CreationType] = field(
        default_factory=list,
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    principal_agent: list[PrincipalAgent] = field(
        default_factory=list,
        metadata={
            "name": "principalAgent",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
            "min_occurs": 1,
        },
    )
    linked_creation: list[LinkedCreation] = field(
        default_factory=list,
        metadata={
            "name": "linkedCreation",
            "type": "Element",
            "namespace": "http://www.doi.org/2010/DOISchema",
        },
    )


class SimpleInfo(SimpleInfoType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class AllInheritedInfoType(BaseModel):
    """
    This includes fields that are inherited.

    No data in ExtraObjectMetadata is ever inherited. This is the return
    value for a request to resolve a DOI to its inherited values. See API
    overview for languages and titles. Alternate IDs and RegistrantExtra
    are never inherited.
    """

    class Meta:
        name = "allInheritedInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: InheritedBaseObjectInfoType = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class CreateBasicDataType(BaseModel):
    class Meta:
        name = "createBasicDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationFullInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class CreateClipDataType(BaseModel):
    class Meta:
        name = "createClipDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateClipDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        clip_info: ClipInfoType = field(
            metadata={
                "name": "ClipInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateCompilationDataType(BaseModel):
    """
    A Compilation is a root, and can't inherit from anything.
    """

    class Meta:
        name = "createCompilationDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationFullInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateCompilationDataType.ExtraObjectMetadata = (
        field(
            metadata={
                "name": "ExtraObjectMetadata",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        compilation_info: CompObjType = field(
            metadata={
                "name": "CompilationInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateCompositeDataType(BaseModel):
    class Meta:
        name = "createCompositeDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationFullInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateCompositeDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        composite_info: CompositeInfoType = field(
            metadata={
                "name": "CompositeInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateEditDataType(BaseModel):
    class Meta:
        name = "createEditDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateEditDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        edit_info: EditInfoType = field(
            metadata={
                "name": "EditInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateEpisodeDataType(BaseModel):
    """
    An Episode must be the child of a Series or a Season.
    """

    class Meta:
        name = "createEpisodeDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateEpisodeDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        episode_info: EpisodeInfoType = field(
            metadata={
                "name": "EpisodeInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateInteractiveDataType(BaseModel):
    class Meta:
        name = "createInteractiveDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateInteractiveDataType.ExtraObjectMetadata = (
        field(
            metadata={
                "name": "ExtraObjectMetadata",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        interactive_material_info: DigitalAssetInteractiveBaseDataType = field(
            metadata={
                "name": "InteractiveMaterialInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateSeasonDataType(BaseModel):
    """
    A Season must be the child of a Series.
    """

    class Meta:
        name = "createSeasonDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateSeasonDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        season_info: SeasonInfoType = field(
            metadata={
                "name": "SeasonInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class CreateSeriesDataType(BaseModel):
    """
    A Series is a root, and can't inherit from anything.
    """

    class Meta:
        name = "createSeriesDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationFullInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateSeriesDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        series_info: SeriesInfoType = field(
            metadata={
                "name": "SeriesInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class ModifyBasicDataType(BaseModel):
    class Meta:
        name = "modifyBasicDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )


class ModifyCompositeDataType(BaseModel):
    class Meta:
        name = "modifyCompositeDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: ModifyCompositeDataType.ExtraObjectMetadata = field(
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        composite_info: CompositeInfoType = field(
            metadata={
                "name": "CompositeInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class SeriesAncestryType(BaseModel):
    class Meta:
        name = "seriesAncestryType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    origin: SimpleInfoType = field(
        metadata={
            "name": "Origin",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    episode_basic_data: None | SimpleInfoType = field(
        default=None,
        metadata={
            "name": "EpisodeBasicData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    episode_info: None | EpisodeInfoType = field(
        default=None,
        metadata={
            "name": "EpisodeInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    season_basic_data: None | SimpleInfoType = field(
        default=None,
        metadata={
            "name": "SeasonBasicData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    season_info: None | SeasonInfoType = field(
        default=None,
        metadata={
            "name": "SeasonInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    series_basic_data: None | SimpleInfoType = field(
        default=None,
        metadata={
            "name": "SeriesBasicData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    series_info: None | SeriesInfoType = field(
        default=None,
        metadata={
            "name": "SeriesInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class AbbreviatedMetadataType(BaseModel):
    """
    :ivar update_num:
    :ivar localized_info:
    :ivar rating:
    :ivar alt_identifier:
    :ivar studio: Equivalent to DisplayName
    :ivar content_id:
    """

    class Meta:
        name = "AbbreviatedMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    update_num: None | int = field(
        default=None,
        metadata={
            "name": "UpdateNum",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_inclusive": 1,
        },
    )
    localized_info: list[AbbreviatedMetadataInfoType] = field(
        default_factory=list,
        metadata={
            "name": "LocalizedInfo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    rating: list[ContentRatingType] = field(
        default_factory=list,
        metadata={
            "name": "Rating",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    alt_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "AltIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    studio: str = field(
        metadata={
            "name": "Studio",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    content_id: str = field(
        metadata={
            "name": "ContentID",
            "type": "Attribute",
            "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
        }
    )


class BasicMetadataJobType(BaseModel):
    class Meta:
        name = "BasicMetadataJob-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    job_function: BasicMetadataJobType.JobFunction = field(
        metadata={
            "name": "JobFunction",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    job_display: list[BasicMetadataJobType.JobDisplay] = field(
        default_factory=list,
        metadata={
            "name": "JobDisplay",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    billing_block_order: None | BasicMetadataJobType.BillingBlockOrder = field(
        default=None,
        metadata={
            "name": "BillingBlockOrder",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    character: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Character",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    character_info: list[BasicMetadataCharacterType] = field(
        default_factory=list,
        metadata={
            "name": "CharacterInfo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    guest: None | bool = field(
        default=None,
        metadata={
            "name": "Guest",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class JobFunction(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        scheme: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class JobDisplay(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class BillingBlockOrder(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: int = field()
        top_billed: None | bool = field(
            default=None,
            metadata={
                "name": "topBilled",
                "type": "Attribute",
            },
        )


class ContainerMetadataType(BaseModel):
    class Meta:
        name = "ContainerMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: StringContainerType = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    track: list[ContainerTrackMetadataType] = field(
        default_factory=list,
        metadata={
            "name": "Track",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    hash: list[HashType] = field(
        default_factory=list,
        metadata={
            "name": "Hash",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    size: None | int = field(
        default=None,
        metadata={
            "name": "Size",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    container_reference: None | str = field(
        default=None,
        metadata={
            "name": "ContainerReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    container_specific_metadata: None | ContainerSpecificType = field(
        default=None,
        metadata={
            "name": "ContainerSpecificMetadata",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class ContentRelatedToCharacterType(BasicMetadataCharacterType):
    class Meta:
        name = "ContentRelatedToCharacter-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    description: list[ContentRelatedToCharacterType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    fictional: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetAudioDataType(BaseModel):
    class Meta:
        name = "DigitalAssetAudioData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    type_value: None | StringAudioType = field(
        default=None,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    encoding: None | DigitalAssetAudioEncodingType = field(
        default=None,
        metadata={
            "name": "Encoding",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: DigitalAssetAudioLanguageType = field(
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    channels: None | str = field(
        default=None,
        metadata={
            "name": "Channels",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "pattern": r"[0-9][0-9]?(\.[0-9]([0-9]?))?",
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "TrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetImageDataType(BaseModel):
    class Meta:
        name = "DigitalAssetImageData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    description: list[DigitalAssetImageDataType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    type_value: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sub_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "SubType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    purpose: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Purpose",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    width: int = field(
        metadata={
            "name": "Width",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    height: int = field(
        metadata={
            "name": "Height",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    encoding: str = field(
        metadata={
            "name": "Encoding",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    picture_details: None | DigitalAssetVideoPictureType = field(
        default=None,
        metadata={
            "name": "PictureDetails",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    dynamic_range_profile: (
        None | DigitalAssetImageDataType.DynamicRangeProfile
    ) = field(
        default=None,
        metadata={
            "name": "DynamicRangeProfile",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    color_gamut_profile: None | str = field(
        default=None,
        metadata={
            "name": "ColorGamutProfile",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    compliance: list[ComplianceType] = field(
        default_factory=list,
        metadata={
            "name": "Compliance",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "TrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    track_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "TrackIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class DynamicRangeProfile(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        luminance_min: None | Decimal = field(
            default=None,
            metadata={
                "name": "LuminanceMin",
                "type": "Attribute",
            },
        )
        luminance_max: None | Decimal = field(
            default=None,
            metadata={
                "name": "LuminanceMax",
                "type": "Attribute",
            },
        )


class DigitalAssetInteractiveDataType(BaseModel):
    class Meta:
        name = "DigitalAssetInteractiveData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: StringInteractiveType = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    format_type: None | StringInteractiveFormatType = field(
        default=None,
        metadata={
            "name": "FormatType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: None | str = field(
        default=None,
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    encoding: list[DigitalAssetInteractiveEncodingType] = field(
        default_factory=list,
        metadata={
            "name": "Encoding",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "TrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetSubtitleDataType(BaseModel):
    class Meta:
        name = "DigitalAssetSubtitleData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    format: None | DigitalAssetSubtitleFormatType = field(
        default=None,
        metadata={
            "name": "Format",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    type_value: list[StringSubtitleType] = field(
        default_factory=list,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
            "max_occurs": 8,
        },
    )
    format_type: None | StringSubtitleFormatType = field(
        default=None,
        metadata={
            "name": "FormatType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: str = field(
        metadata={
            "name": "Language",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    cardset_list: list[DigitalAssetCardsetListType] = field(
        default_factory=list,
        metadata={
            "name": "CardsetList",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "TrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class DigitalAssetVideoDataType(BaseModel):
    """
    :ivar description:
    :ivar type_value:
    :ivar encoding:
    :ivar picture:
    :ivar color_type: BW, Color, Colorized, etc.
    :ivar picture_format:
    :ivar subtitle_language:
    :ivar signed_language:
    :ivar cardset_list:
    :ivar track_reference:
    :ivar private:
    """

    class Meta:
        name = "DigitalAssetVideoData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    description: None | str = field(
        default=None,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    type_value: None | StringVideoType = field(
        default=None,
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    encoding: None | DigitalAssetVideoEncodingType = field(
        default=None,
        metadata={
            "name": "Encoding",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    picture: DigitalAssetVideoPictureType = field(
        metadata={
            "name": "Picture",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    color_type: None | ColorTypeType = field(
        default=None,
        metadata={
            "name": "ColorType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    picture_format: None | StringVideoPictureFormat = field(
        default=None,
        metadata={
            "name": "PictureFormat",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    subtitle_language: list[DigitalAssetVideoSubtitleLanguageType] = field(
        default_factory=list,
        metadata={
            "name": "SubtitleLanguage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    signed_language: None | str = field(
        default=None,
        metadata={
            "name": "SignedLanguage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    cardset_list: list[DigitalAssetCardsetListType] = field(
        default_factory=list,
        metadata={
            "name": "CardsetList",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    track_reference: None | str = field(
        default=None,
        metadata={
            "name": "TrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class VersionIntentType(BaseModel):
    class Meta:
        name = "VersionIntent-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    audience: None | AudienceType = field(
        default=None,
        metadata={
            "name": "Audience",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    description: list[VersionIntentType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    edit_use: None | str = field(
        default=None,
        metadata={
            "name": "EditUse",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    edit_class: list[str] = field(
        default_factory=list,
        metadata={
            "name": "EditClass",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    made_for_region: None | RegionType = field(
        default=None,
        metadata={
            "name": "MadeForRegion",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    terms: list[TermsType] = field(
        default_factory=list,
        metadata={
            "name": "Terms",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class KernelMetadata(BaseModel):
    """
    The XML schema for DOI Kernel metadata.

    :ivar referent_doi_name: The specific DOI name allocated to the
        referent.
    :ivar primary_referent_type: The primaryReferentType of the referent
        (Creation or Party).
    :ivar registration_agency_doi_name: The DOI name of the Registration
        Agency responsible for issuing this Declaration.
    :ivar issue_date: The date on which this Declaration was issued.
    :ivar issue_number: The sequence number of this Declaration in the
        series of Kernel Metadata Declarations issued for this DOI name.
        Original issue=1. If a Kernel Metadata Declaration for a
        specific DOI name is re-issued, this number should be
        incremented by one.
    :ivar referent_creation_or_referent_party:
    """

    class Meta:
        name = "kernelMetadata"
        namespace = "http://www.doi.org/2010/DOISchema"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    referent_doi_name: str = field(
        metadata={
            "name": "referentDoiName",
            "type": "Element",
            "pattern": r"10\.[^\./@]+(\.[^\./@]+)*/.+",
        }
    )
    primary_referent_type: PrimaryReferentType = field(
        metadata={
            "name": "primaryReferentType",
            "type": "Element",
        }
    )
    registration_agency_doi_name: str = field(
        metadata={
            "name": "registrationAgencyDoiName",
            "type": "Element",
            "pattern": r"10\.[^\./@]+(\.[^\./@]+)*/.+",
        }
    )
    issue_date: XmlDate = field(
        metadata={
            "name": "issueDate",
            "type": "Element",
        }
    )
    issue_number: int = field(
        metadata={
            "name": "issueNumber",
            "type": "Element",
        }
    )
    referent_creation_or_referent_party: (
        None | ReferentCreation | ReferentParty
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "referentCreation",
                    "type": ReferentCreation,
                },
                {
                    "name": "referentParty",
                    "type": ReferentParty,
                },
            ),
        },
    )


class CreateBasic(CreateBasicDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateClip(CreateClipDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateCompilation(CreateCompilationDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateComposite(CreateCompositeDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateEdit(CreateEditDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateEpisode(CreateEpisodeDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateSeason(CreateSeasonDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class CreateSeries(CreateSeriesDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class ResolvedInheritedGeneral(AllInheritedInfoType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class BasicMetadataPeopleType(BaseModel):
    class Meta:
        name = "BasicMetadataPeople-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    job: list[BasicMetadataJobType] = field(
        default_factory=list,
        metadata={
            "name": "Job",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    name: PersonNameType = field(
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    identifier: list[PersonIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "Identifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    gender: None | GenderType = field(
        default=None,
        metadata={
            "name": "Gender",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class ContainerMetadataWithIdType(ContainerMetadataType):
    class Meta:
        name = "ContainerMetadataWithID-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    container_id: ContentIdentifierType = field(
        metadata={
            "name": "ContainerID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )


class ContentRelatedToType(BaseModel):
    """
    :ivar relationship: Describes how the original people place or
        things are modified.  These can be controleld vocaublary or free
        text.
    :ivar description: Description of the subject of the work.
        Especially important if other elements are insuffiicent.
    :ivar choice:
    :ivar grouping_entity:
    """

    class Meta:
        name = "ContentRelatedTo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    relationship: ContentRelatedToRelationshipType = field(
        metadata={
            "name": "Relationship",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    description: list[ContentRelatedToType.Description] = field(
        default_factory=list,
        metadata={
            "name": "Description",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    choice: list[
        ContentRelatedToWorkType
        | ContentRelatedToCharacterType
        | ContentRelatedToPersonType
        | ContentRelatedToPeriodType
        | ContentRelatedToPlaceType
        | ContentRelatedToEventType
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Work",
                    "type": ContentRelatedToWorkType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Character",
                    "type": ContentRelatedToCharacterType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "PersonOrGroup",
                    "type": ContentRelatedToPersonType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Period",
                    "type": ContentRelatedToPeriodType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Place",
                    "type": ContentRelatedToPlaceType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Event",
                    "type": ContentRelatedToEventType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )
    grouping_entity: list[GroupingEntityType] = field(
        default_factory=list,
        metadata={
            "name": "GroupingEntity",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )

    class Description(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetMetadataType(BaseModel):
    class Meta:
        name = "DigitalAssetMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    choice: (
        None
        | DigitalAssetAudioDataType
        | DigitalAssetVideoDataType
        | DigitalAssetSubtitleDataType
        | DigitalAssetInteractiveDataType
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Audio",
                    "type": DigitalAssetAudioDataType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Video",
                    "type": DigitalAssetVideoDataType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Subtitle",
                    "type": DigitalAssetSubtitleDataType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
                {
                    "name": "Interactive",
                    "type": DigitalAssetInteractiveDataType,
                    "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
                },
            ),
        },
    )


class DigitalTracksType(BaseModel):
    class Meta:
        name = "digitalTracksType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    track_or_container: list[
        DigitalAssetMetadataType | ContainerMetadataType
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Track",
                    "type": DigitalAssetMetadataType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "Container",
                    "type": ContainerMetadataType,
                    "namespace": "http://www.eidr.org/schema",
                },
            ),
        },
    )


class BasicMetadataInfoType(BaseModel):
    class Meta:
        name = "BasicMetadataInfo-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    title_display19: None | str = field(
        default=None,
        metadata={
            "name": "TitleDisplay19",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    title_display60: None | str = field(
        default=None,
        metadata={
            "name": "TitleDisplay60",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    title_display_unlimited: None | str = field(
        default=None,
        metadata={
            "name": "TitleDisplayUnlimited",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    title_sort: None | str = field(
        default=None,
        metadata={
            "name": "TitleSort",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    art_reference: list[BasicMetadataInfoType.ArtReference] = field(
        default_factory=list,
        metadata={
            "name": "ArtReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    summary190: None | BasicMetadataInfoType.Summary190 = field(
        default=None,
        metadata={
            "name": "Summary190",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    summary400: None | BasicMetadataInfoType.Summary400 = field(
        default=None,
        metadata={
            "name": "Summary400",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    summary4000: None | BasicMetadataInfoType.Summary4000 = field(
        default=None,
        metadata={
            "name": "Summary4000",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    display_indicators: list[str] = field(
        default_factory=list,
        metadata={
            "name": "DisplayIndicators",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    genre: list[BasicMetadataInfoType.Genre] = field(
        default_factory=list,
        metadata={
            "name": "Genre",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    keyword: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Keyword",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    version_notes: None | str = field(
        default=None,
        metadata={
            "name": "VersionNotes",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    region: list[RegionType] = field(
        default_factory=list,
        metadata={
            "name": "Region",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    target_audience: list[AudienceType] = field(
        default_factory=list,
        metadata={
            "name": "TargetAudience",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    original_title: None | str = field(
        default=None,
        metadata={
            "name": "OriginalTitle",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    copyright_line: None | str = field(
        default=None,
        metadata={
            "name": "CopyrightLine",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    people_local: list[BasicMetadataPeopleType] = field(
        default_factory=list,
        metadata={
            "name": "PeopleLocal",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    title_alternate: list[BasicMetadataInfoType.TitleAlternate] = field(
        default_factory=list,
        metadata={
            "name": "TitleAlternate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    language: str = field(
        metadata={
            "type": "Attribute",
        }
    )
    default: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    condition: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )

    class ArtReference(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        resolution: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        purpose: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Summary190(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        cast: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Summary400(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        cast: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Summary4000(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        cast: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class Genre(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        source: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        id: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        level: None | int = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )

    class TitleAlternate(BaseModel):
        model_config = ConfigDict(defer_build=True)
        value: str = field(default="")
        type_value: None | str = field(
            default=None,
            metadata={
                "name": "type",
                "type": "Attribute",
            },
        )
        language: None | str = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetAncillaryDataType(BaseModel):
    class Meta:
        name = "DigitalAssetAncillaryData-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    type_value: str = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    sub_type: list[str] = field(
        default_factory=list,
        metadata={
            "name": "SubType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    base_track_id: None | str = field(
        default=None,
        metadata={
            "name": "BaseTrackID",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    base_track_reference: None | str = field(
        default=None,
        metadata={
            "name": "BaseTrackReference",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "max_length": 128,
        },
    )
    base_track_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "BaseTrackIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    track_metadata: None | DigitalAssetMetadataType = field(
        default=None,
        metadata={
            "name": "TrackMetadata",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    combined_metadata: None | DigitalAssetMetadataType = field(
        default=None,
        metadata={
            "name": "CombinedMetadata",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    compliance: list[ComplianceType] = field(
        default_factory=list,
        metadata={
            "name": "Compliance",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    private: None | PrivateDataType = field(
        default=None,
        metadata={
            "name": "Private",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class ManifestationInfoType(BaseModel):
    class Meta:
        name = "manifestationInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    parent: AssetDoitype = field(
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    manifestation_class: list[ManifestationClassType] = field(
        default_factory=list,
        metadata={
            "name": "ManifestationClass",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "min_occurs": 1,
            "max_occurs": 8,
        },
    )
    made_for_region: list[MadeForRegionType] = field(
        default_factory=list,
        metadata={
            "name": "MadeForRegion",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 8,
        },
    )
    manifestation_details: list[UsageDetailsType] = field(
        default_factory=list,
        metadata={
            "name": "ManifestationDetails",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
            "max_occurs": 8,
        },
    )
    digital_or_film_or_tape: (
        None | DigitalTracksType | FilmTracksType | TapeTracksType
    ) = field(
        default=None,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "Digital",
                    "type": DigitalTracksType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "Film",
                    "type": FilmTracksType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "Tape",
                    "type": TapeTracksType,
                    "namespace": "http://www.eidr.org/schema",
                },
            ),
        },
    )


class BasicMetadataType(BaseModel):
    class Meta:
        name = "BasicMetadata-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
    update_num: None | int = field(
        default=None,
        metadata={
            "name": "UpdateNum",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_inclusive": 1,
        },
    )
    localized_info: list[BasicMetadataInfoType] = field(
        default_factory=list,
        metadata={
            "name": "LocalizedInfo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
            "min_occurs": 1,
        },
    )
    run_length: None | XmlDuration = field(
        default=None,
        metadata={
            "name": "RunLength",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    release_year: XmlPeriod = field(
        metadata={
            "name": "ReleaseYear",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    release_date: None | XmlPeriod | XmlDate | XmlDateTime = field(
        default=None,
        metadata={
            "name": "ReleaseDate",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    release_history: list[ReleaseHistoryType] = field(
        default_factory=list,
        metadata={
            "name": "ReleaseHistory",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    work_type: str = field(
        metadata={
            "name": "WorkType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        }
    )
    work_type_detail: list[str] = field(
        default_factory=list,
        metadata={
            "name": "WorkTypeDetail",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    picture_color_type: None | ColorTypeType = field(
        default=None,
        metadata={
            "name": "PictureColorType",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    picture_format: None | str = field(
        default=None,
        metadata={
            "name": "PictureFormat",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    three_d: None | BasicMetadataType.ThreeD = field(
        default=None,
        metadata={
            "name": "ThreeD",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    aspect_ratio: None | str = field(
        default=None,
        metadata={
            "name": "AspectRatio",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    alt_identifier: list[ContentIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "AltIdentifier",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    rating_set: None | ContentRatingType = field(
        default=None,
        metadata={
            "name": "RatingSet",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    people: list[BasicMetadataPeopleType] = field(
        default_factory=list,
        metadata={
            "name": "People",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    country_of_origin: list[RegionType] = field(
        default_factory=list,
        metadata={
            "name": "CountryOfOrigin",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    primary_spoken_language: list[str] = field(
        default_factory=list,
        metadata={
            "name": "PrimarySpokenLanguage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    original_language: list[str] = field(
        default_factory=list,
        metadata={
            "name": "OriginalLanguage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    version_language: list[str] = field(
        default_factory=list,
        metadata={
            "name": "VersionLanguage",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    version_intent: None | VersionIntentType = field(
        default=None,
        metadata={
            "name": "VersionIntent",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    associated_org: list[AssociatedOrgType] = field(
        default_factory=list,
        metadata={
            "name": "AssociatedOrg",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    content_related_to: list[ContentRelatedToType] = field(
        default_factory=list,
        metadata={
            "name": "ContentRelatedTo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    sequence_info: None | ContentSequenceInfoType = field(
        default=None,
        metadata={
            "name": "SequenceInfo",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    parent: list[BasicMetadataParentType] = field(
        default_factory=list,
        metadata={
            "name": "Parent",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    content_id: str = field(
        metadata={
            "name": "ContentID",
            "type": "Attribute",
            "pattern": r"10\.5240/[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-F]{4}-[\dA-Z]|10\.5240/[\dA-F]{20}[\dA-Z]",
        }
    )

    class ThreeD(BaseModel):
        model_config = ConfigDict(defer_build=True, arbitrary_types_allowed=True)
        value: bool = field()
        three60: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )
        multiview: None | bool = field(
            default=None,
            metadata={
                "type": "Attribute",
            },
        )


class DigitalAssetSetType(BaseModel):
    class Meta:
        name = "DigitalAssetSet-type"
        target_namespace = "http://www.movielabs.com/schema/md/v2.8/md"

    model_config = ConfigDict(defer_build=True)
    audio: list[DigitalAssetAudioDataType] = field(
        default_factory=list,
        metadata={
            "name": "Audio",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    video: list[DigitalAssetVideoDataType] = field(
        default_factory=list,
        metadata={
            "name": "Video",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    subtitle: list[DigitalAssetSubtitleDataType] = field(
        default_factory=list,
        metadata={
            "name": "Subtitle",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    image: list[DigitalAssetImageDataType] = field(
        default_factory=list,
        metadata={
            "name": "Image",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    interactive: list[DigitalAssetInteractiveDataType] = field(
        default_factory=list,
        metadata={
            "name": "Interactive",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )
    ancillary: list[DigitalAssetAncillaryDataType] = field(
        default_factory=list,
        metadata={
            "name": "Ancillary",
            "type": "Element",
            "namespace": "http://www.movielabs.com/schema/md/v2.8/md",
        },
    )


class CreateManifestationDataType(BaseModel):
    class Meta:
        name = "createManifestationDataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: CreationSelfDefinedInfo = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: CreateManifestationDataType.ExtraObjectMetadata = (
        field(
            metadata={
                "name": "ExtraObjectMetadata",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )
    )

    class ExtraObjectMetadata(BaseModel):
        model_config = ConfigDict(defer_build=True)
        manifestation_info: ManifestationInfoType = field(
            metadata={
                "name": "ManifestationInfo",
                "type": "Element",
                "namespace": "http://www.eidr.org/schema",
            }
        )


class ExtraObjectMetadataType(BaseModel):
    """
    Metadata for child objects and derived objects.

    This schema enforces the following rules for what extra metadata can be
    present ((0 or 1 of compilation, season, series, interactive material,
    episode, episode+composite, or composite) OR (0 or 1 of
    Edit,Manifestation, or Clip)) AND (0 or more of each of Promotion,
    Supplement, AlternateContent, Packaging).
    """

    class Meta:
        name = "extraObjectMetadataType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    choice: list[
        CompObjType
        | SeasonInfoType
        | SeriesInfoType
        | DigitalAssetInteractiveBaseDataType
        | EpisodeInfoType
        | CompositeInfoType
        | EditInfoType
        | ManifestationInfoType
        | ClipInfoType
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "CompilationInfo",
                    "type": CompObjType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "SeasonInfo",
                    "type": SeasonInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "SeriesInfo",
                    "type": SeriesInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "InteractiveMaterialInfo",
                    "type": DigitalAssetInteractiveBaseDataType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "EpisodeInfo",
                    "type": EpisodeInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "CompositeInfo",
                    "type": CompositeInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "EditInfo",
                    "type": EditInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "ManifestationInfo",
                    "type": ManifestationInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "ClipInfo",
                    "type": ClipInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
            ),
            "max_occurs": 2,
        },
    )
    promotion_info: list[PromotionInfoType] = field(
        default_factory=list,
        metadata={
            "name": "PromotionInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    supplemental_content_info: list[SupplementalContentInfoType] = field(
        default_factory=list,
        metadata={
            "name": "SupplementalContentInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    alternate_content_info: list[AlternateContentInfoType] = field(
        default_factory=list,
        metadata={
            "name": "AlternateContentInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )
    packaging_info: list[PackagingInfoType] = field(
        default_factory=list,
        metadata={
            "name": "PackagingInfo",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class CreateManifestation(CreateManifestationDataType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class AllSelfDefinedInfoType(BaseModel):
    """
    Contains all the fields defined on the object itself.

    This is the return value for a request for resolution of a DOI to its
    'own' information.
    """

    class Meta:
        name = "allSelfDefinedInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: SelfDefinedBaseObjectInfoType = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: None | ExtraObjectMetadataType = field(
        default=None,
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class FullObjectInfoType(BaseModel):
    """
    This contains all the information about the object.

    This is the return value for a request for full resolution of an asset
    DOI. In baseObjectData all mandatory fields are provided (either by
    inheritance or actual presence.) The languages fields are fuly
    realized, based on the inheritance, add, and replace chain from all
    ancestors. ExtraObjectmetadata contains metadata for any described type
    information or relationships or relationships that are present. (See
    extraObjectMetadataType for the legal combinations.).
    """

    class Meta:
        name = "fullObjectInfoType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    base_object_data: BaseObjectInfoType = field(
        metadata={
            "name": "BaseObjectData",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        }
    )
    extra_object_metadata: None | ExtraObjectMetadataType = field(
        default=None,
        metadata={
            "name": "ExtraObjectMetadata",
            "type": "Element",
            "namespace": "http://www.eidr.org/schema",
        },
    )


class ResolvedFullGeneral(FullObjectInfoType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class ResolvedSelfGeneral(AllSelfDefinedInfoType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)


class ResolutionSetType(BaseModel):
    """
    This is used by the SDK and atomic tools to return a set of resolutions
    as a valid piece of XML; the Registry only supports doing resolutions
    one at a time, and all of the results are put in a Resolutions element
    of this type.

    Most of the tools will generate only a single kind of Resolution at a
    time. As of 1.2.1, GraphTool and ResolveTool are the only exceptions to
    this. If the "singleType" attribute is present, it contains the name of
    the single type of resolution contained by <Resolutions xmlns=""/>.
    """

    class Meta:
        name = "resolutionSetType"
        target_namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
    choice: list[
        SimpleInfoType
        | AllSelfDefinedInfoType
        | AllInheritedInfoType
        | FullObjectInfoType
        | ProvenanceInfoType
        | KernelMetadata
    ] = field(
        default_factory=list,
        metadata={
            "type": "Elements",
            "choices": (
                {
                    "name": "SimpleMetadata",
                    "type": SimpleInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "SelfDefinedMetadata",
                    "type": AllSelfDefinedInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "InheritedMetadata",
                    "type": AllInheritedInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "FullMetadata",
                    "type": FullObjectInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "ProvenanceMetadata",
                    "type": ProvenanceInfoType,
                    "namespace": "http://www.eidr.org/schema",
                },
                {
                    "name": "kernelMetadata",
                    "type": KernelMetadata,
                    "namespace": "http://www.eidr.org/schema",
                },
            ),
        },
    )
    single_type: None | ResolutionTypeType = field(
        default=None,
        metadata={
            "name": "singleType",
            "type": "Attribute",
        },
    )


class Resolutions(ResolutionSetType):
    class Meta:
        namespace = "http://www.eidr.org/schema"

    model_config = ConfigDict(defer_build=True)
