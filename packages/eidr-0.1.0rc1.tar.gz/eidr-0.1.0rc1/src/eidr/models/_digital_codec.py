"""Adapter between codec-dict ``Digital`` block and the typed model.

The SDK's source of truth for record content is the
:class:`~eidr.codecs.codec_dict.CodecDict` shape — the
hand-written :class:`~eidr.models.content.ContentRecord` and
friends wrap that dict. M8's typed Digital sub-model
(:mod:`eidr.models.digital`) is a transient view over the same
underlying data: each :meth:`ManifestationInfo.digital_typed`
call materializes a fresh pydantic instance from the dict;
:meth:`ManifestationInfo.set_digital` does the reverse.

This module owns those two conversions. They go through
xsdata-pydantic's own parsers/serializers, so the adapter does
not mirror the schema by hand. Whatever xsdata generated, xsdata
parses; whatever xsdata serializes, xsdata round-trips.

Wire shape recap
----------------

The ``<Digital>`` element appears at
``record.data → ManifestationInfo → Digital``. It belongs to the
EIDR namespace (``http://www.eidr.org/schema``). Its body is a
flat sequence of ``<Track>`` and ``<Container>`` children — the
schema type is ``digitalTracksType`` (generated as
:class:`DigitalTracksType`). Each ``<Track>`` is a
``DigitalAssetMetadata-type`` choice wrapping exactly one of
audio/video/subtitle/interactive; each ``<Container>`` is a
``ContainerMetadata-type``.

Why XML-as-intermediate rather than dict-walking
------------------------------------------------

Two paths are possible:

1. **Direct dict → pydantic.** Walk the codec dict, instantiate
   pydantic models field-by-field. Fast (no XML serialization
   step) but requires hand-coded mapping logic that tracks every
   name transformation xsdata applied (snake_case fields,
   ``Type`` suffixes, choice-element flattening, attribute
   renaming). Drift risk is high.

2. **Dict → XML → pydantic via xsdata parser.** Round-trip
   through the wire format. Slower (one extra XML parse) but the
   SDK's existing XML codec layer already knows how to turn a
   :class:`CodecDict` into XML, and xsdata-pydantic's parser
   already knows how to turn that XML into typed instances. No
   hand-coded mapping; both directions stay in sync with the
   generated module by construction.

We use option 2. The performance cost is one short XML parse per
:meth:`digital_typed` call — measured against the cost of a
typical EIDR network round-trip, this is rounding error.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from eidr.codecs._rules import CodecDict


_EIDR_NAMESPACE = "http://www.eidr.org/schema"


def codec_dict_to_digital_tracks(digital_dict: CodecDict, digital_tracks_class: type[Any]) -> Any:
    """Build a typed :class:`DigitalTracks` from a Digital codec dict.

    Goes through XML as the intermediate form — see the module
    docstring for rationale.

    Args:
        digital_dict: The codec dict at
            ``record.data["ManifestationInfo"]["Digital"]``.
        digital_tracks_class: The :class:`DigitalTracksType` class.
            Passed in rather than imported here to keep this
            adapter free of pydantic imports for callers using
            only the codec layer.

    Returns:
        A :class:`DigitalTracks` instance.
    """
    from eidr.codecs import xml as xml_codec

    # Wrap the Digital dict's contents in a top-level ``<Digital>``
    # element matching the wire shape. Inject the EIDR and MD
    # namespace declarations on the wrapper so any ``md:`` (or
    # ``ns1:`` etc.) prefixes inside the dict — inherited from the
    # parent record's namespace scope — can resolve. Without these
    # declarations, an EIDR-shaped dict with a bare ``md:Audio``
    # key would fail at ``etree.Element`` construction with
    # ``Invalid tag name``.
    wrapper_dict: CodecDict = {
        "Digital": {
            "_xmlns": _EIDR_NAMESPACE,
            "_xmlns:md": "http://www.movielabs.com/schema/md/v2.8/md",
            **digital_dict,
        }
    }
    xml_bytes = xml_codec.to_xml(wrapper_dict, xml_declaration=False)

    parser = _xsdata_parser()
    return parser.from_bytes(xml_bytes, digital_tracks_class)


def digital_tracks_to_codec_dict(digital_tracks: Any) -> CodecDict:
    """Serialize a typed :class:`DigitalTracks` back to a codec dict.

    Inverse of :func:`codec_dict_to_digital_tracks`. xsdata-pydantic
    serializes to XML; the SDK's codec layer parses XML to dict.
    Returns the dict that should be assigned at
    ``record.data["ManifestationInfo"]["Digital"]`` — i.e., the
    body of the ``<Digital>`` element, not the wrapper itself.

    Output is **prefix-normalized** so the resulting dict matches
    the shape produced by a fresh :meth:`Client.resolve` of a
    Manifestation: default namespace for EIDR types (``Track``,
    ``Container``, …), ``md:`` prefix for MovieLabs MD-v2.8 types
    (``md:Audio``, ``md:Video``, …). xsdata's auto-generated
    ``ns0:`` / ``ns1:`` prefixes are not exposed to callers — see
    :func:`_normalize_xsdata_prefixes` for the rationale.
    """
    from eidr.codecs import xml as xml_codec

    serializer = _xsdata_serializer()
    xml_text = serializer.render(digital_tracks)
    xml_bytes = xml_text.encode("utf-8") if isinstance(xml_text, str) else xml_text

    # Parse back into a codec dict. ``to_codec_dict`` returns a
    # dict keyed on the root element (``Digital``); we strip one
    # level so the result drops cleanly into the
    # ``ManifestationInfo[Digital]`` slot.
    parsed = xml_codec.to_codec_dict(xml_bytes)
    if len(parsed) == 1:
        only_key = next(iter(parsed))
        body = parsed[only_key]
        if isinstance(body, dict):
            return _normalize_xsdata_prefixes(body)
    return _normalize_xsdata_prefixes(parsed)


# ─── prefix normalization ──────────────────────────────────────────────────


def _normalize_xsdata_prefixes(obj: CodecDict) -> CodecDict:
    """Rewrite xsdata's ``nsN:`` prefixes to the EIDR-record-resolve style.

    xsdata-pydantic's serializer auto-generates ``ns0:``, ``ns1:``
    prefixes (one per namespace it encounters) and re-declares the
    namespace at the first element that uses each prefix. The codec
    dict produced by parsing that XML preserves these prefixes
    verbatim — fine for round-tripping back through xsdata, but
    inconsistent with the dict shape produced by a fresh
    :meth:`Client.resolve`. After ``set_digital()``, a developer
    inspecting ``manifest.data["…"]["Digital"]`` would see ``ns0:Track``
    where they'd see ``Track`` after a resolve — same data, different
    "dialect."

    Normalization rules (mechanically derived from the EIDR record
    schema):

    * ``ns0:Foo`` → ``Foo`` (EIDR namespace = default at this scope)
    * ``ns1:Foo`` → ``md:Foo`` (MovieLabs MD-v2.8)
    * ``_xmlns:ns0`` and ``_xmlns:ns1`` keys are dropped entirely
      (xsdata redundantly re-declares each namespace at the first
      element using it; the wire shape declares once at the
      wrapper).

    Recurses through nested dicts and lists. Does not modify the
    input — returns a fresh dict.
    """
    out: CodecDict = {}
    for key, value in obj.items():
        # Drop inline ns0/ns1 namespace declarations entirely.
        if key in ("_xmlns:ns0", "_xmlns:ns1"):
            continue

        new_key = _rewrite_prefix(key)
        out[new_key] = _normalize_value(value)
    return out


def _normalize_value(value: Any) -> Any:
    """Recurse the normalizer through dict-or-list values."""
    if isinstance(value, dict):
        return _normalize_xsdata_prefixes(value)
    if isinstance(value, list):
        return [_normalize_value(v) for v in value]
    return value


def _rewrite_prefix(key: str) -> str:
    """Rewrite a single dict-key's prefix per the normalization rules.

    Pure function over strings; no recursion, no allocation beyond
    one short string when a rewrite happens.
    """
    if key.startswith("ns0:"):
        return key[len("ns0:") :]
    if key.startswith("ns1:"):
        return "md:" + key[len("ns1:") :]
    return key


# ─── xsdata machinery, lazily constructed ─────────────────────────────────


def _xsdata_parser() -> Any:
    """Return an xsdata-pydantic XML parser.

    Constructed lazily so the import path of any caller not using
    the typed Digital surface stays clean of pydantic / xsdata.
    """
    from xsdata_pydantic.bindings import XmlParser

    return XmlParser()


def _xsdata_serializer() -> Any:
    """Return an xsdata-pydantic XML serializer.

    Same lazy-construction story as :func:`_xsdata_parser`.
    """
    from xsdata.formats.dataclass.serializers.config import SerializerConfig
    from xsdata_pydantic.bindings import XmlSerializer

    config = SerializerConfig(xml_declaration=False, indent="")
    return XmlSerializer(config=config)
