"""The :class:`PartyRecord` wrapper for EIDR Party-ID records.

EIDR Party records identify organizations (and, rarely, individuals)
that register, produce, distribute, or are otherwise associated with
Content records. They are returned by the Party/Resolve operation and
serve as the identity namespace for :attr:`ContentRecord.registrant`,
:attr:`ContentRecord.metadata_authorities`, and similar cross-references.

Compared with :class:`~eidr.models.content.ContentRecord`, a Party is:

* **Flat** — no inheritance, no Full-vs-Self-vs-Provenance distinction,
  no ``ExtraObjectMetadata`` block.
* **Small** — roughly 10 fields. A single unwrapped DTO.

Wrapped as a typed façade over the same :data:`CodecDict`
representation as Content records, for API consistency.
"""

from __future__ import annotations

from typing import Any

from eidr.codecs import json as _json_codec
from eidr.codecs import xml as _xml_codec
from eidr.codecs._rules import CodecDict, CodecValue
from eidr.errors import EIDRClientError
from eidr.models._org_name_norm import (
    ensure_md_namespace_declared,
    normalize_org_name_block,
)
from eidr.models._validation import ValidationReport
from eidr.models._value_objects import ContactInfo, OrgName
from eidr.models.ids import EIDRID

__all__ = ["PartyRecord"]


def _root_value(data: CodecDict) -> CodecDict:
    """Return the top-level value of a ``<Party>`` wrapper.

    Returns the data unchanged if already unwrapped.
    """
    if not data:
        return {}
    if len(data) == 1:
        only_key = next(iter(data))
        if only_key == "Party":
            inner = data[only_key]
            if isinstance(inner, dict):
                return inner
    return data


def _ensure_list(value: CodecValue) -> list[Any]:
    """Coerce an optional CodecValue to a list."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _scalar_text(value: CodecValue) -> str | None:
    """Leaf-text extraction (handles bare strings, dicts, singleton lists)."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        text = value.get("value")
        return text if isinstance(text, str) else None
    if isinstance(value, list) and len(value) == 1:
        return _scalar_text(value[0])
    return None


class PartyRecord:
    """Wrapper over an EIDR Party-ID record.

    Construct via :meth:`from_xml`, :meth:`from_json`, or
    :meth:`from_codec_dict`. The underlying codec dict remains the
    source of truth and is exposed via :attr:`data`.

    Read accessors are non-validating — the wrapper trusts whatever the
    registry returned.
    """

    __slots__ = ("_data", "_root")

    def __init__(self, data: CodecDict) -> None:
        if not isinstance(data, dict):
            raise EIDRClientError(f"PartyRecord requires a dict, got {type(data).__name__}")
        self._data: CodecDict = data
        self._root: CodecDict = _root_value(data)
        # Normalize ``PartyName/{DisplayName,SortName,AlternateName}``
        # to their ``md:``-prefixed forms. See ServiceRecord.__init__
        # and :mod:`eidr.models._org_name_norm` for the rationale.
        pn = self._root.get("PartyName")
        if pn is not None:
            normalized = normalize_org_name_block(pn)
            if normalized != pn:
                self._root["PartyName"] = normalized
                ensure_md_namespace_declared(self._root)

    # ─── construction ──────────────────────────────────────────────────────

    @classmethod
    def from_codec_dict(cls, data: CodecDict) -> PartyRecord:
        """Wrap an existing codec dict."""
        return cls(data)

    @classmethod
    def from_xml(cls, source: bytes | str) -> PartyRecord:
        """Parse an EIDR Party record from XML bytes or text."""
        cd = _xml_codec.to_codec_dict(source)
        return cls(cd)

    @classmethod
    def from_json(
        cls,
        source: str | bytes | dict[str, Any],
        *,
        wrapper_key: str | None = None,
    ) -> PartyRecord:
        """Parse an EIDR Party record from JSON text, bytes, or dict.

        Args:
            source: JSON input.
            wrapper_key: If the JSON dropped its top-level wrapper (e.g.
                ``"Party"``), supply the wrapper name. Otherwise the
                top-level key in the JSON is used as-is.
        """
        cd = _json_codec.from_json(source, wrapper_key=wrapper_key)
        return cls(cd)

    # ─── output ────────────────────────────────────────────────────────────

    def to_codec_dict(self) -> CodecDict:
        """Return the underlying codec dict (live view)."""
        return self._data

    def to_xml(
        self,
        *,
        pretty_print: bool = False,
        xml_declaration: bool = True,
    ) -> bytes:
        """Serialize to XML bytes (infoset round trip)."""
        return _xml_codec.to_xml(
            self._data,
            pretty_print=pretty_print,
            xml_declaration=xml_declaration,
        )

    def to_xml_canonical(self, *, method: str = "c14n2") -> bytes:
        """Serialize to byte-stable canonical XML (signing-ready)."""
        return _xml_codec.to_xml_canonical(self._data, method=method)

    def to_json(
        self,
        *,
        wrapper: str = "retain",
        indent: int | None = 2,
    ) -> str:
        """Serialize to JSON text per the MovieLabs MDDF rules."""
        return _json_codec.to_json(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
            indent=indent,
        )

    def to_json_canonical(self, *, wrapper: str = "retain") -> str:
        """Serialize to RFC 8785 JCS canonical JSON (signing-ready)."""
        return _json_codec.to_canonical_string(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
        )

    # ─── data access ───────────────────────────────────────────────────────

    @property
    def data(self) -> CodecDict:
        """The underlying codec dict (source of truth)."""
        return self._data

    # ─── Party field accessors ─────────────────────────────────────────────

    @property
    def id(self) -> EIDRID | None:
        """The record's EIDR Party ID, parsed and validated."""
        text = _scalar_text(self._root.get("ID"))
        if not text:
            return None
        try:
            return EIDRID.parse(text)
        except Exception:
            return None

    @property
    def party_name(self) -> OrgName | None:
        """The Party's organization name (``md:OrgName-type``)."""
        return OrgName.from_codec(self._root.get("PartyName"))

    @property
    def alternate_party_names(self) -> list[str]:
        """Alternate party names (up to 20, per schema)."""
        items = _ensure_list(self._root.get("AlternatePartyName"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def contact_info(self) -> ContactInfo | None:
        """The Party's contact record (``ContactInfo``)."""
        return ContactInfo.from_codec(self._root.get("ContactInfo"))

    @property
    def active(self) -> bool | None:
        """Whether the Party is currently active in the registry."""
        raw = _scalar_text(self._root.get("Active"))
        if raw is None:
            return None
        # xs:boolean: "true"/"false"/"1"/"0"
        if raw in ("true", "1"):
            return True
        if raw in ("false", "0"):
            return False
        return None

    @property
    def party_account_name(self) -> str | None:
        """The registry account name used by this Party (e.g. for logins)."""
        return _scalar_text(self._root.get("PartyAccountName"))

    @property
    def allowed_roles(self) -> list[str]:
        """Administrative roles this Party is allowed to play.

        Values come from the registry's administrator-role vocabulary
        (e.g. ``"Registrant"``, ``"MetadataAuthority"``).
        """
        items = _ensure_list(self._root.get("AllowedRoles"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    # ─── validation ────────────────────────────────────────────────────────

    def validate(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> ValidationReport:
        """Run pre-submission validation over this Party record.

        Checks required fields (``PartyName`` with ``md:DisplayName``
        required; ``ContactInfo`` optional but shape-checked when
        present; ``Active`` required), xs:boolean well-formedness,
        the ``AlternatePartyName`` cardinality cap (≤20),
        ``AllowedRoles`` vocabulary, and the empty-tag rule.

        Args:
            mode: Submission mode. ``"create"`` rejects a present ID
                (the registry assigns it). ``"modify"`` requires a
                present ID. ``None`` (default) validates ID format
                only when present. See
                :data:`~eidr.models._validate_party_service.SubmissionMode`.
            max_errors: Cap on collected errors (default ``50``).
        """
        from eidr.models._validate_party_service import validate_party_record

        return validate_party_record(self, mode=mode, max_errors=max_errors)  # type: ignore[arg-type]

    def validate_strict(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> None:
        """Run validation and raise on any error.

        Raises:
            EIDRValidationError: When validation reports any error.
        """
        self.validate(mode=mode, max_errors=max_errors).raise_if_errors()

    # ─── dunder methods ────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PartyRecord):
            return self._data == other._data
        return NotImplemented

    def __hash__(self) -> int:
        return id(self)

    def __repr__(self) -> str:
        pn = self.party_name
        name = pn.display_name if pn else None
        return f"PartyRecord(id={self.id!s}, party_name={name!r})"
