"""The :class:`ServiceRecord` wrapper for EIDR Service-ID records.

EIDR Service records identify distribution services (channels,
streaming platforms, VOD services, etc.) to which :class:`ContentRecord`
instances can be associated. They are returned by the Service/Resolve
operation.

Compared with :class:`~eidr.models.content.ContentRecord`, a Service
record is flat (no inheritance), small (~12 fields), and may reference
a parent Service (for hierarchies like "HBO" → "HBO Max"). Like
:class:`~eidr.models.party.PartyRecord`, it has a single unwrapped DTO
shape and is wrapped as a typed façade over :data:`CodecDict`.
"""

from __future__ import annotations

from typing import Any

from eidr.codecs import json as _json_codec
from eidr.codecs import xml as _xml_codec
from eidr.codecs._rules import ATTR_PREFIX, CodecDict, CodecValue
from eidr.errors import EIDRClientError
from eidr.models._org_name_norm import (
    ensure_md_namespace_declared,
    normalize_org_name_block,
)
from eidr.models._validation import ValidationReport
from eidr.models._value_objects import AlternateID, OrgName
from eidr.models.ids import EIDRID

__all__ = ["ServiceRecord"]


def _root_value(data: CodecDict) -> CodecDict:
    if not data:
        return {}
    if len(data) == 1:
        only_key = next(iter(data))
        if only_key == "Service":
            inner = data[only_key]
            if isinstance(inner, dict):
                return inner
    return data


def _ensure_list(value: CodecValue) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _scalar_text(value: CodecValue) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        text = value.get("value")
        return text if isinstance(text, str) else None
    if isinstance(value, list) and len(value) == 1:
        return _scalar_text(value[0])
    return None


class ServiceRecord:
    """Wrapper over an EIDR Service-ID record."""

    __slots__ = ("_data", "_root")

    def __init__(self, data: CodecDict) -> None:
        if not isinstance(data, dict):
            raise EIDRClientError(f"ServiceRecord requires a dict, got {type(data).__name__}")
        self._data: CodecDict = data
        self._root: CodecDict = _root_value(data)
        # Normalize ``ServiceName/{DisplayName,SortName,AlternateName}``
        # to their ``md:``-prefixed forms. The MovieLabs MD-v2.8 schema
        # requires these in the MD namespace; bare-namespaced inputs
        # are silently corrected on parse so writes back to the
        # registry produce schema-valid bodies. See
        # :mod:`eidr.models._org_name_norm` for the full rationale.
        sn = self._root.get("ServiceName")
        if sn is not None:
            normalized = normalize_org_name_block(sn)
            if normalized != sn:
                # Rewrite happened — also ensure the root declares
                # the md: namespace so the XML serializer can emit
                # ``xmlns:md="…"`` on the root element.
                self._root["ServiceName"] = normalized
                ensure_md_namespace_declared(self._root)

    # ─── construction ──────────────────────────────────────────────────────

    @classmethod
    def from_codec_dict(cls, data: CodecDict) -> ServiceRecord:
        """Wrap an existing codec dict."""
        return cls(data)

    @classmethod
    def from_xml(cls, source: bytes | str) -> ServiceRecord:
        """Parse from XML bytes or text."""
        cd = _xml_codec.to_codec_dict(source)
        return cls(cd)

    @classmethod
    def from_json(
        cls,
        source: str | bytes | dict[str, Any],
        *,
        wrapper_key: str | None = None,
    ) -> ServiceRecord:
        """Parse from JSON text, bytes, or dict.

        Args:
            source: JSON input.
            wrapper_key: If the JSON dropped its top-level wrapper (e.g.
                ``"Service"``), supply the wrapper name. Otherwise the
                top-level key in the JSON is used as-is.
        """
        cd = _json_codec.from_json(source, wrapper_key=wrapper_key)
        return cls(cd)

    # ─── output ────────────────────────────────────────────────────────────

    def to_codec_dict(self) -> CodecDict:
        """Return the underlying codec dict (live view)."""
        return self._data

    def to_xml(
        self,
        *,
        pretty_print: bool = False,
        xml_declaration: bool = True,
    ) -> bytes:
        """Serialize to XML bytes (infoset round trip)."""
        return _xml_codec.to_xml(
            self._data,
            pretty_print=pretty_print,
            xml_declaration=xml_declaration,
        )

    def to_xml_canonical(self, *, method: str = "c14n2") -> bytes:
        """Serialize to byte-stable canonical XML (signing-ready)."""
        return _xml_codec.to_xml_canonical(self._data, method=method)

    def to_json(
        self,
        *,
        wrapper: str = "retain",
        indent: int | None = 2,
    ) -> str:
        """Serialize to JSON text per the MovieLabs MDDF rules."""
        return _json_codec.to_json(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
            indent=indent,
        )

    def to_json_canonical(self, *, wrapper: str = "retain") -> str:
        """Serialize to RFC 8785 JCS canonical JSON (signing-ready)."""
        return _json_codec.to_canonical_string(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
        )

    # ─── data access ───────────────────────────────────────────────────────

    @property
    def data(self) -> CodecDict:
        """The underlying codec dict (source of truth)."""
        return self._data

    # ─── Service field accessors ───────────────────────────────────────────

    @property
    def id(self) -> EIDRID | None:
        """The record's EIDR Service ID."""
        text = _scalar_text(self._root.get("ID"))
        if not text:
            return None
        try:
            return EIDRID.parse(text)
        except Exception:
            return None

    @property
    def service_name(self) -> OrgName | None:
        """The Service's name.

        Uses ``md:OrgName-type`` with an optional ``@abbreviation`` attribute —
        see :attr:`service_name_is_abbreviation`.
        """
        return OrgName.from_codec(self._root.get("ServiceName"))

    @property
    def service_name_is_abbreviation(self) -> bool:
        """Whether :attr:`service_name` is itself an abbreviation.

        Returns ``True`` when the registry marks the name as an
        abbreviation (e.g. ``"NBC"`` rather than
        ``"National Broadcasting Company"``).
        """
        raw = self._root.get("ServiceName")
        if isinstance(raw, dict):
            attr = raw.get(f"{ATTR_PREFIX}abbreviation")
            return attr in ("true", "1")
        return False

    @property
    def alternate_service_names(self) -> list[str]:
        """Alternate service names (up to 10, per schema)."""
        items = _ensure_list(self._root.get("AlternateServiceName"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def alternate_ids(self) -> list[AlternateID]:
        """Foreign identifiers for this service (up to 10, per schema)."""
        items = _ensure_list(self._root.get("AlternateID"))
        out: list[AlternateID] = []
        for it in items:
            obj = AlternateID.from_codec(it)
            if obj is not None:
                out.append(obj)
        return out

    @property
    def description(self) -> str | None:
        """Free-text description (up to 128 characters)."""
        return _scalar_text(self._root.get("Description"))

    @property
    def parent(self) -> EIDRID | None:
        """Parent Service ID when this is a sub-service.

        For example, ``"HBO Max"`` would carry a parent of ``"HBO"``.
        ``None`` when the service has no parent.
        """
        text = _scalar_text(self._root.get("Parent"))
        if not text:
            return None
        try:
            return EIDRID.parse(text)
        except Exception:
            return None

    @property
    def other_affiliations(self) -> list[str]:
        """EIDR Service or Party IDs this service is affiliated with.

        Commonly used for a channel's network owner or other business
        relationships. Up to 10 entries per schema.
        """
        items = _ensure_list(self._root.get("OtherAffiliation"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def active(self) -> bool | None:
        """Whether the Service is currently active."""
        raw = _scalar_text(self._root.get("Active"))
        if raw is None:
            return None
        if raw in ("true", "1"):
            return True
        if raw in ("false", "0"):
            return False
        return None

    @property
    def primary_time_zone(self) -> str | None:
        """The Service's primary scheduling time zone."""
        return _scalar_text(self._root.get("PrimaryTimeZone"))

    @property
    def region(self) -> str | None:
        """The service region (typically a DMA name or code)."""
        return _scalar_text(self._root.get("Region"))

    @property
    def primary_audio_language(self) -> str | None:
        """BCP 47 language code for primary audio (e.g. ``"en"``, ``"en-GB"``)."""
        return _scalar_text(self._root.get("PrimaryAudioLanguage"))

    @property
    def delivery_models(self) -> list[str]:
        """Delivery model(s) — one or more of ``"Linear"``, ``"VOD"``, ``"Other"``."""
        items = _ensure_list(self._root.get("DeliveryModel"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    # ─── validation ────────────────────────────────────────────────────────

    def validate(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> ValidationReport:
        """Run pre-submission validation over this Service record.

        Checks required fields (``ServiceName`` with ``md:DisplayName``;
        ``Active``), xs:boolean well-formedness, schema cardinality
        bounds (AlternateServiceName ≤10, AlternateID ≤10,
        OtherAffiliation ≤10, DeliveryModel ≤4), the DeliveryModel
        controlled vocabulary (Linear/VOD/Other), Parent EIDR ID
        format, and the empty-tag rule.

        Args:
            mode: Submission mode. ``"create"`` rejects a present ID;
                ``"modify"`` requires a present ID; ``None`` (default)
                validates ID format only when present.
            max_errors: Cap on collected errors (default ``50``).
        """
        from eidr.models._validate_party_service import validate_service_record

        return validate_service_record(self, mode=mode, max_errors=max_errors)  # type: ignore[arg-type]

    def validate_strict(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> None:
        """Run validation and raise on any error.

        Raises:
            EIDRValidationError: When validation reports any error.
        """
        self.validate(mode=mode, max_errors=max_errors).raise_if_errors()

    # ─── dunder methods ────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ServiceRecord):
            return self._data == other._data
        return NotImplemented

    def __hash__(self) -> int:
        return id(self)

    def __repr__(self) -> str:
        sn = self.service_name
        name = sn.display_name if sn else None
        return f"ServiceRecord(id={self.id!s}, service_name={name!r})"
