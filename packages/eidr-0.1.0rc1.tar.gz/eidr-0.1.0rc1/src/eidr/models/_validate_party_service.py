"""Pre-submission validation for Party and Service records.

Validates :class:`PartyRecord` and :class:`ServiceRecord` before a
register/modify submission.

Party and Service records are flat — no inheritance, no parent/child
hierarchy, no business-rule field population at submission time.
Every schema-required field must be supplied directly. The validators
here enforce the EIDR submission profile for these record types:

- **Party:** ``PartyName``, ``ContactInfo``, and ``Active`` required
  (per schema). ``ContactInfo`` must carry its own schema-required
  sub-fields (``Name``, ``PrimaryEmail``). ``AllowedRoles`` values are
  validated against the schema's ``administratorTypeType``.
- **Service:** ``ServiceName``, ``Active`` required. ``DeliveryModel``
  values validated against {Linear, VOD, Other}. Cardinality bounds
  enforced per the schema.
- **ID presence** depends on submission mode: ``"create"`` → ID
  must NOT be present (registry assigns it); ``"modify"`` → ID
  MUST be present; ``None`` → validate format if present, otherwise
  don't enforce. See :data:`SubmissionMode`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from eidr.models._validation import ValidationReport

if TYPE_CHECKING:
    from eidr.codecs._rules import CodecDict, CodecValue
    from eidr.models.party import PartyRecord
    from eidr.models.service import ServiceRecord

__all__ = ["SubmissionMode", "validate_party_record", "validate_service_record"]


SubmissionMode = Literal["create", "modify"] | None
"""Submission-mode hint for ID-presence checking.

* ``"create"`` — ID must NOT be present; the registry assigns it.
* ``"modify"`` — ID MUST be present and well-formed.
* ``None`` — only validate ID format when present; don't enforce
  presence or absence. Useful when inspecting a record whose
  submission mode isn't known.
"""


_DELIVERY_MODELS: frozenset[str] = frozenset({"Linear", "VOD", "Other"})

_ALLOWED_ROLES: frozenset[str] = frozenset(
    {
        "AssociatedOrg",
        "Registrant",
        "MetadataAuthority",
        "EncodingAgent",
        "Writer",
        "Reader",
        "ServiceAdmin",
        "AltIDWriter",
    }
)


def _scalar(v: CodecValue) -> str | None:
    if v is None:
        return None
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        text = v.get("value")
        return text if isinstance(text, str) else None
    if isinstance(v, list) and len(v) == 1:
        return _scalar(v[0])
    return None


def _is_structurally_present(container: CodecDict | None, key: str) -> bool:
    """True iff ``container`` has ``key`` bound to a non-empty value."""
    if container is None or not isinstance(container, dict):
        return False
    val = container.get(key)
    if val is None:
        return False
    return not (isinstance(val, (list, dict, str)) and len(val) == 0)


def _has_meaningful_content(container: CodecDict | None, key: str) -> bool:
    """True iff ``container``'s ``key`` has real text/child content."""
    if container is None or not isinstance(container, dict):
        return False
    val = container.get(key)
    if val is None:
        return False
    if isinstance(val, str):
        return bool(val)
    if isinstance(val, list):
        return any(_value_has_content(item) for item in val)
    if isinstance(val, dict):
        return _value_has_content(val)
    return True  # type: ignore[unreachable]  # pragma: no cover


def _value_has_content(value: CodecValue) -> bool:
    """Does a value carry text or child elements (vs. only attributes)?"""
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value)
    if isinstance(value, list):
        return any(_value_has_content(v) for v in value)
    if isinstance(value, dict):
        from eidr.codecs._rules import ATTR_PREFIX

        for k, v in value.items():
            if k.startswith(ATTR_PREFIX):
                continue
            if k == "value":
                if isinstance(v, str) and v:
                    return True
                continue
            if v is not None:
                if isinstance(v, (list, dict, str)):
                    if len(v) > 0:
                        return True
                else:
                    return True  # type: ignore[unreachable]  # pragma: no cover
        return False
    return True  # type: ignore[unreachable]  # pragma: no cover


def _check_boolean(
    container: CodecDict, field_name: str, path: str, report: ValidationReport
) -> None:
    """An xs:boolean field must be true/false/1/0 when present."""
    raw = _scalar(container.get(field_name))
    if raw is None:
        return
    if raw not in ("true", "false", "1", "0"):
        report.add(
            code="record.vocabulary.invalid",
            message=(
                f"{field_name}={raw!r} is not a valid xs:boolean (expected true, false, 1, or 0)"
            ),
            path=path,
            value=raw,
        )


def _check_id_for_mode(
    root: CodecDict,
    report: ValidationReport,
    *,
    record_kind: str,
    mode: SubmissionMode,
) -> None:
    """ID-mode check: create rejects present ID; modify requires it."""
    id_present = _is_structurally_present(root, "ID")
    lower = record_kind.lower()

    if mode == "create" and id_present:
        report.add(
            code=f"{lower}.id.unexpected",
            message=(
                f"ID must NOT be present on {record_kind} create payloads; "
                "the registry assigns the ID."
            ),
            path=f"{record_kind}/ID",
            value=_scalar(root.get("ID")),
        )
        return

    if mode == "modify" and not id_present:
        report.add(
            code=f"{lower}.required_field.missing",
            message=f"ID is required on {record_kind} modify payloads",
            path=f"{record_kind}/ID",
        )
        return

    if not id_present:
        return

    from eidr.errors import EIDRIDFormatError
    from eidr.models.ids import EIDRID

    raw = _scalar(root.get("ID"))
    try:
        EIDRID.parse(raw or "")
    except EIDRIDFormatError as exc:
        report.add(
            code=f"{lower}.id.invalid",
            message=f"ID is not a valid EIDR identifier: {exc}",
            path=f"{record_kind}/ID",
            value=raw,
        )


def _check_empty_tags(codec_dict: CodecDict, report: ValidationReport, *, code_prefix: str) -> None:
    """The registry rejects any empty tag outright."""
    from eidr.models._empty_tags import find_empty_tags

    for path in find_empty_tags(codec_dict):
        report.add(
            code=f"{code_prefix}.empty_tag.forbidden",
            message=(
                "Empty tags are not permitted in EIDR submissions; "
                "remove this element or supply content. "
                "Consider calling strip_empty_tags() before validation."
            ),
            path=path,
        )


def validate_party_record(
    record: PartyRecord,
    *,
    mode: SubmissionMode = None,
    max_errors: int = 50,
) -> ValidationReport:
    """Run pre-submission validation over a PartyRecord.

    Args:
        record: The record to validate.
        mode: Submission mode — ``"create"`` (ID absent), ``"modify"``
            (ID required), or ``None`` (validate format only).
        max_errors: Cap on collected errors.
    """
    report = ValidationReport(max_errors=max_errors)
    root = record._root

    _check_id_for_mode(root, report, record_kind="Party", mode=mode)

    # PartyName — required, must contain md:DisplayName
    if not _is_structurally_present(root, "PartyName"):
        report.add(
            code="party.required_field.missing",
            message="PartyName is required",
            path="Party/PartyName",
        )
    else:
        pn = root.get("PartyName")
        if isinstance(pn, dict) and not _has_meaningful_content(pn, "md:DisplayName"):
            report.add(
                code="party.required_field.missing",
                message="PartyName/md:DisplayName is required",
                path="Party/PartyName/md:DisplayName",
            )

    # ContactInfo — required, with schema-required sub-fields (Name,
    # PrimaryEmail). Despite operational reality that many Parties
    # represent long-defunct organizations with no real contact,
    # the schema requires this and the library matches the schema.
    # (A future schema revision may relax this.)
    if not _is_structurally_present(root, "ContactInfo"):
        report.add(
            code="party.required_field.missing",
            message="ContactInfo is required",
            path="Party/ContactInfo",
        )
    else:
        ci = root.get("ContactInfo")
        if isinstance(ci, dict):
            if not _has_meaningful_content(ci, "Name"):
                report.add(
                    code="party.required_field.missing",
                    message="ContactInfo/Name is required",
                    path="Party/ContactInfo/Name",
                )
            if not _has_meaningful_content(ci, "PrimaryEmail"):
                report.add(
                    code="party.required_field.missing",
                    message="ContactInfo/PrimaryEmail is required",
                    path="Party/ContactInfo/PrimaryEmail",
                )

    # Active — required xs:boolean
    if not _is_structurally_present(root, "Active"):
        report.add(
            code="party.required_field.missing",
            message="Active is required",
            path="Party/Active",
        )
    else:
        _check_boolean(root, "Active", "Party/Active", report)

    # AllowedRoles — controlled vocabulary (administratorTypeType)
    roles = root.get("AllowedRoles")
    if roles is not None:
        role_list = roles if isinstance(roles, list) else [roles]
        for i, entry in enumerate(role_list):
            val = _scalar(entry)
            if val is not None and val not in _ALLOWED_ROLES:
                report.add(
                    code="party.vocabulary.invalid",
                    message=(
                        f"AllowedRoles={val!r} is not one of {', '.join(sorted(_ALLOWED_ROLES))}"
                    ),
                    path=(
                        f"Party/AllowedRoles[{i}]"
                        if isinstance(roles, list)
                        else "Party/AllowedRoles"
                    ),
                    value=val,
                )

    # AlternatePartyName — schema cardinality cap
    alt = root.get("AlternatePartyName")
    if isinstance(alt, list) and len(alt) > 20:
        report.add(
            code="party.cardinality.exceeded",
            message=(f"AlternatePartyName is bounded at 20 entries; got {len(alt)}"),
            path="Party/AlternatePartyName",
            value=len(alt),
        )

    _check_empty_tags(record._data, report, code_prefix="party")

    return report


def validate_service_record(
    record: ServiceRecord,
    *,
    mode: SubmissionMode = None,
    max_errors: int = 50,
) -> ValidationReport:
    """Run pre-submission validation over a ServiceRecord.

    Args:
        record: The record to validate.
        mode: Submission mode — ``"create"`` (ID absent), ``"modify"``
            (ID required), or ``None`` (validate format only).
        max_errors: Cap on collected errors.
    """
    report = ValidationReport(max_errors=max_errors)
    root = record._root

    _check_id_for_mode(root, report, record_kind="Service", mode=mode)

    # ServiceName — required, with md:DisplayName
    if not _is_structurally_present(root, "ServiceName"):
        report.add(
            code="service.required_field.missing",
            message="ServiceName is required",
            path="Service/ServiceName",
        )
    else:
        sn = root.get("ServiceName")
        if isinstance(sn, dict) and not _has_meaningful_content(sn, "md:DisplayName"):
            report.add(
                code="service.required_field.missing",
                message="ServiceName/md:DisplayName is required",
                path="Service/ServiceName/md:DisplayName",
            )

    # Active — required xs:boolean
    if not _is_structurally_present(root, "Active"):
        report.add(
            code="service.required_field.missing",
            message="Active is required",
            path="Service/Active",
        )
    else:
        _check_boolean(root, "Active", "Service/Active", report)

    # DeliveryModel — controlled vocabulary when present
    dms = root.get("DeliveryModel")
    if dms is not None:
        raw_list = dms if isinstance(dms, list) else [dms]
        for i, entry in enumerate(raw_list):
            val = _scalar(entry)
            if val is not None and val not in _DELIVERY_MODELS:
                report.add(
                    code="service.vocabulary.invalid",
                    message=(
                        f"DeliveryModel={val!r} is not one of {', '.join(sorted(_DELIVERY_MODELS))}"
                    ),
                    path=(
                        f"Service/DeliveryModel[{i}]"
                        if isinstance(dms, list)
                        else "Service/DeliveryModel"
                    ),
                    value=val,
                )

    # Cardinality bounds per the schema
    for field_name, cap in (
        ("AlternateServiceName", 10),
        ("AlternateID", 10),
        ("OtherAffiliation", 10),
        ("DeliveryModel", 4),
    ):
        raw_val = root.get(field_name)
        if isinstance(raw_val, list) and len(raw_val) > cap:
            report.add(
                code="service.cardinality.exceeded",
                message=(f"{field_name} is bounded at {cap} entries; got {len(raw_val)}"),
                path=f"Service/{field_name}",
                value=len(raw_val),
            )

    # Parent — when present, must be a valid EIDR ID (syntax only).
    if _is_structurally_present(root, "Parent"):
        from eidr.errors import EIDRIDFormatError
        from eidr.models.ids import EIDRID

        raw = _scalar(root.get("Parent"))
        try:
            EIDRID.parse(raw or "")
        except EIDRIDFormatError as exc:
            report.add(
                code="service.parent.invalid",
                message=f"Parent is not a valid EIDR identifier: {exc}",
                path="Service/Parent",
                value=raw,
            )

    _check_empty_tags(record._data, report, code_prefix="service")

    return report
