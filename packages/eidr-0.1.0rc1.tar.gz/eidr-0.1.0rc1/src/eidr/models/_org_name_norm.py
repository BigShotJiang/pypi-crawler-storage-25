"""Namespace normalization for ``md:OrgName-type`` blocks.

The MovieLabs MD-v2.8 schema requires elements like ``DisplayName``,
``SortName``, and ``AlternateName`` (inside ``ServiceName`` / ``PartyName``)
to be in the MovieLabs MD namespace —
``http://www.movielabs.com/schema/md/v2.8/md`` (prefix ``md:`` by
convention). The codec layer represents this with ``"md:"``-prefixed
keys in the codec dict.

Live registry submission against EIDR's sandbox (M9 review-fix pass)
confirmed that bare ``<DisplayName>`` (in the EIDR namespace, without
the ``md:`` prefix) is rejected with::

    cvc-complex-type.2.4.a: Invalid content was found starting with
    element 'DisplayName'. One of '{"http://www.movielabs.com/schema/
    md/v2.8/md":DisplayName}' is expected.

But the codec layer faithfully preserves whatever shape was parsed —
so XML inputs that happen to declare ``DisplayName`` in the EIDR
namespace produce codec dicts with bare keys, which then serialize
back to the registry-rejected shape on write.

This module provides :func:`normalize_org_name_block` (rewrites the
keys inside a ``ServiceName`` / ``PartyName`` block) and
:func:`ensure_md_namespace_declared` (ensures the root element
declares the ``md:`` prefix, so the XML serializer can emit the
prefixed elements). Both are idempotent — already-correct inputs
pass through unchanged.

Why normalize on parse rather than on serialize? Either layer would
work, but parse-side normalization means the codec dict in memory is
always in the canonical (registry-acceptable) shape — a developer
inspecting ``record.data["ServiceName"]`` after a fresh parse sees
``md:DisplayName``, matching what they'd see after a resolve from the
registry. Round-trips through any serializer (XML, JSON, codec dict)
all produce the right thing.
"""

from __future__ import annotations

from eidr.codecs._rules import ATTR_PREFIX, CodecDict, CodecValue

#: The MovieLabs MD-v2.8 namespace URI.
_MD_NS_URI = "http://www.movielabs.com/schema/md/v2.8/md"

#: The conventional prefix for the MovieLabs MD-v2.8 namespace. Other
#: prefixes are technically valid XML but the EIDR registry's
#: serializations consistently use ``md:``.
_MD_PREFIX = "md"

#: Element names inside ``ServiceName`` / ``PartyName`` blocks that the
#: schema requires in the MovieLabs MD-v2.8 namespace. Keys without
#: the ``md:`` prefix are rewritten; keys already prefixed pass
#: through.
_MD_NAMESPACED_NAME_FIELDS: frozenset[str] = frozenset(
    {
        "DisplayName",
        "SortName",
        "AlternateName",
    }
)


def normalize_org_name_block(value: CodecValue) -> CodecValue:
    """Rewrite bare element names inside a ``ServiceName`` / ``PartyName`` block.

    Walks the value (which may be a dict, a list of dicts, or a
    scalar) and rewrites bare keys (``"DisplayName"``, ``"SortName"``,
    ``"AlternateName"``) to their ``"md:"``-prefixed equivalents.
    Already-prefixed keys are preserved verbatim. Other keys (e.g.,
    XML attributes like ``"@organizationID"``) are preserved.

    Idempotent: calling this on already-normalized input is a no-op.
    """
    if isinstance(value, list):
        return [normalize_org_name_block(item) for item in value]
    if not isinstance(value, dict):
        return value
    out: CodecDict = {}
    for key, val in value.items():
        new_key = f"md:{key}" if key in _MD_NAMESPACED_NAME_FIELDS else key
        # Only recurse on the children of the OrgName block itself —
        # the top level (this dict) is the only level where the
        # rewrite applies. Children (list values etc.) are scalars
        # in this schema, but recursion handles nested-dict values
        # that some encoders use for elements with attributes.
        new_val = normalize_org_name_block(val) if isinstance(val, dict | list) else val
        out[new_key] = new_val
    return out


def ensure_md_namespace_declared(root: CodecDict) -> None:
    """Mutate ``root`` so the codec-dict declares the ``md:`` namespace.

    Adds ``"_xmlns:md" -> "http://www.movielabs.com/schema/md/v2.8/md"``
    at the root level if not already present. This is what the
    codec-to-XML serializer reads to attach the ``xmlns:md="…"``
    declaration to the root element on serialize.

    Idempotent: already-declared roots are unchanged. If the root
    has an ``md`` prefix bound to a different URI (technically
    legal XML but never seen in EIDR data), that pre-existing
    declaration is preserved — we don't overwrite caller intent.
    """
    md_decl_key = f"{ATTR_PREFIX}xmlns:{_MD_PREFIX}"
    if md_decl_key in root:
        return
    # Insert at the start so it's near other xmlns declarations
    # in the serialized output. Order doesn't matter semantically,
    # only stylistically.
    new_root: CodecDict = {md_decl_key: _MD_NS_URI}
    new_root.update(root)
    root.clear()
    root.update(new_root)
