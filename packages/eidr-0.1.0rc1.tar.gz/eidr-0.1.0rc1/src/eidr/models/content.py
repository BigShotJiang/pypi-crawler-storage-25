"""The :class:`ContentRecord` wrapper for EIDR Content-ID records.

:class:`ContentRecord` is a thin, typed façade over the codec's
:data:`~eidr.codecs.CodecDict` representation. The dict remains the
source of truth — every accessor reads from it (and write accessors
modify it), so:

* Round-trips through XML and JSON are guaranteed lossless. The
  wrapper never drops fields it doesn't model.
* You can always escape to ``record.data`` to reach fields the
  ergonomic API doesn't surface (e.g., extension elements, the full
  Manifestation/Digital sub-tree).
* The wrapper imposes **no validation** on read. Records returned
  from the registry are trusted as-is. To validate before submission,
  call :meth:`ContentRecord.validate` (collects errors and returns
  them) or :meth:`validate_strict` (raises on first error). The
  :meth:`Client.register` and :meth:`Client.modify` methods accept
  ``validate=True`` to invoke the validator from the submission
  path; see those methods for the opt-in pre-submission pipeline.

Construction modes
------------------

Two entry points:

* :meth:`from_xml(bytes)` and :meth:`from_json(text)` parse a registry
  response (or a fragment) into a :class:`ContentRecord`.
* :meth:`from_codec_dict(dict)` wraps an existing codec dict — useful
  when chaining with :mod:`eidr.codecs.xml` directly.

All three are read-friendly: missing/optional fields surface as
``None`` or empty lists, never as exceptions.

Output:

* :meth:`to_xml()` and :meth:`to_xml_canonical()` for native XML
* :meth:`to_json()` and :meth:`to_json_canonical()` for MovieLabs JSON
* :meth:`to_codec_dict()` for direct codec interop

These all delegate to :mod:`eidr.codecs`, so the same canonicalization
guarantees apply.

Field model
-----------

The wrapper exposes accessors derived from the EIDR XML→JSON Conversion
Table (139 deduped data-bearing paths after Full↔Self-Defined collapse).
The CreationType-bearing ExtraObjectMetadata blocks (SeriesInfo,
SeasonInfo, EpisodeInfo, EditInfo, ClipInfo, ManifestationInfo,
CompilationInfo) are mutually exclusive per the EIDR data model and
surface as a single :attr:`creation_block` accessor whose type is
discriminated by the record's :attr:`creation_type`. CompositeInfo can
co-occur with a Basic or Episode record; it is a separate
:attr:`composite_info` accessor. Lightweight relationship blocks
(SupplementalContentInfo, PromotionInfo, AlternateContentInfo,
PackagingInfo) appear in any combination and surface as lists.
"""

from __future__ import annotations

from typing import Any

from eidr.codecs import json as _json_codec
from eidr.codecs import xml as _xml_codec
from eidr.codecs._rules import ATTR_PREFIX, CodecDict, CodecValue
from eidr.errors import EIDRClientError
from eidr.models._validation import ValidationReport
from eidr.models._value_objects import (
    AliasContinuation,
    AlternateID,
    AlternateResourceName,
    AssociatedOrg,
    Credit,
    Parent,
)
from eidr.models.enums import CreationType, Mode, ReferentType, Status, StructuralType
from eidr.models.ids import EIDRID

__all__ = ["ContentRecord"]


# ─────────────────────────────────────────────────────────────────────────────
# Helpers for navigating the codec dict shape
# ─────────────────────────────────────────────────────────────────────────────


def _root_value(data: CodecDict) -> CodecDict:
    """Return the top-level value of a Full/Self/Simple/Provenance/Inherited wrapper.

    Accepts either a wrapped dict (``{"FullMetadata": {...}}``) or an
    already-unwrapped dict. Returns the inner dict.

    Recognized wrappers:

    * ``FullMetadata`` — the standard resolved-record envelope.
    * ``SelfDefinedMetadata`` — a self-defined view (a subset of the
      full record).
    * ``SimpleMetadata`` — the flat-schema view used by query results.
      Unlike ``FullMetadata``, ``SimpleMetadata`` doesn't wrap its
      children in ``BaseObjectData``; all fields live at the top
      level. The :attr:`ContentRecord.base` property accounts for
      this by falling back to the root dict when no
      ``BaseObjectData`` key is present.
    * ``ProvenanceMetadata`` — a provenance-only view (administrative
      lineage info). Wraps content the same way ``FullMetadata`` does.
    * ``InheritedMetadata`` — the inherited-from-parent view used for
      Episode / Edit / Clip records. Same wrapper structure as
      ``FullMetadata``.

    The ``BaseObjectData`` wrapper for non-Simple shapes is handled
    in :attr:`ContentRecord.base`.
    """
    if not data:
        return {}
    if len(data) == 1:
        only_key = next(iter(data))
        if only_key in (
            "FullMetadata",
            "SelfDefinedMetadata",
            "SimpleMetadata",
            "ProvenanceMetadata",
            "InheritedMetadata",
        ):
            inner = data[only_key]
            if isinstance(inner, dict):
                return inner
    return data


def _ensure_list(value: CodecValue) -> list[Any]:
    """Coerce an optional CodecValue to a list. ``None`` → ``[]``, scalar → ``[scalar]``."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _scalar_text(value: CodecValue) -> str | None:
    """Extract a leaf text value, supporting all shapes the codec emits.

    Handles scalars, ``{"value": "..."}`` with optional attributes, and
    singleton lists (which the codec emits when the raw schema declares
    an element multi but the EIDR profile constrains it to singleton in
    the current context — e.g., ``md:DisplayName`` inside a Director).
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        text = value.get("value")
        return text if isinstance(text, str) else None
    if isinstance(value, list) and len(value) == 1:
        return _scalar_text(value[0])
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Sub-block accessor classes
#
# Each maps to one of the ExtraObjectMetadata blocks. They are thin views
# onto a sub-dict of ContentRecord.data; mutation flows back to the
# underlying record automatically.
# ─────────────────────────────────────────────────────────────────────────────


class _BlockView:
    """Common base for ExtraObjectMetadata block accessors."""

    __slots__ = ("_d",)

    def __init__(self, d: CodecDict) -> None:
        self._d = d

    @property
    def data(self) -> CodecDict:
        """The raw codec-dict for this block (live view)."""
        return self._d

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._d!r})"


class SeriesInfo(_BlockView):
    """View over a SeriesInfo block (CreationType=Series)."""

    @property
    def series_class(self) -> str | None:
        return _scalar_text(self._d.get("SeriesClass"))

    @property
    def end_date(self) -> str | None:
        return _scalar_text(self._d.get("EndDate"))

    @property
    def date_required(self) -> str | None:
        return _scalar_text(self._d.get("DateRequired"))

    @property
    def number_required(self) -> str | None:
        return _scalar_text(self._d.get("NumberRequired"))

    @property
    def original_title_required(self) -> str | None:
        return _scalar_text(self._d.get("OriginalTitleRequired"))


class SeasonInfo(_BlockView):
    """View over a SeasonInfo block (CreationType=Season)."""

    @property
    def parent(self) -> Parent | None:
        return Parent.from_codec(self._d.get("Parent"))

    @property
    def season_class(self) -> str | None:
        return _scalar_text(self._d.get("SeasonClass"))

    @property
    def sequence_number(self) -> str | None:
        return _scalar_text(self._d.get("SequenceNumber"))

    @property
    def end_date(self) -> str | None:
        return _scalar_text(self._d.get("EndDate"))

    @property
    def date_required(self) -> str | None:
        return _scalar_text(self._d.get("DateRequired"))

    @property
    def number_required(self) -> str | None:
        return _scalar_text(self._d.get("NumberRequired"))

    @property
    def original_title_required(self) -> str | None:
        return _scalar_text(self._d.get("OriginalTitleRequired"))


class EpisodeInfo(_BlockView):
    """View over an EpisodeInfo block (CreationType=Episode)."""

    @property
    def parent(self) -> Parent | None:
        return Parent.from_codec(self._d.get("Parent"))

    @property
    def episode_class(self) -> str | None:
        return _scalar_text(self._d.get("EpisodeClass"))

    @property
    def time_slot(self) -> str | None:
        return _scalar_text(self._d.get("TimeSlot"))

    @property
    def sequence_info(self) -> CodecDict | None:
        """Raw ``md:SequenceInfo`` sub-dict (HouseSequence, AlternateNumber, etc.)."""
        v = self._d.get("SequenceInfo")
        return v if isinstance(v, dict) else None


class EditInfo(_BlockView):
    """View over an EditInfo block (CreationType=Edit)."""

    @property
    def parent(self) -> Parent | None:
        return Parent.from_codec(self._d.get("Parent"))

    @property
    def edit_class(self) -> str | None:
        return _scalar_text(self._d.get("EditClass"))

    @property
    def edit_use(self) -> str | None:
        return _scalar_text(self._d.get("EditUse"))

    @property
    def color_type(self) -> str | None:
        return _scalar_text(self._d.get("ColorType"))

    @property
    def made_for_region(self) -> str | None:
        return _scalar_text(self._d.get("MadeForRegion"))

    @property
    def three_d(self) -> str | None:
        return _scalar_text(self._d.get("ThreeD"))

    @property
    def edit_details(self) -> str | None:
        return _scalar_text(self._d.get("EditDetails"))


class ClipInfo(_BlockView):
    """View over a ClipInfo block (CreationType=Clip)."""

    @property
    def parent(self) -> Parent | None:
        return Parent.from_codec(self._d.get("Parent"))

    @property
    def start(self) -> str | None:
        return _scalar_text(self._d.get("Start"))

    @property
    def duration(self) -> str | None:
        return _scalar_text(self._d.get("Duration"))

    @property
    def components_mode(self) -> str | None:
        return _scalar_text(self._d.get("ComponentsMode"))


class ManifestationInfo(_BlockView):
    """View over a ManifestationInfo block (CreationType=Manifestation).

    The ``Digital`` sub-block carries technical encoding metadata
    (audio/video/subtitle tracks, container packaging, etc.). Two
    accessors are available:

    * :attr:`digital` — the raw codec dict. Always available; no
      additional dependencies. Best for whole-block equality
      comparisons (dedup) and pass-through use cases where the
      caller treats the digital metadata as opaque.
    * :meth:`digital_typed` — a typed pydantic view, requires the
      ``[digital]`` install extra. Best for programmatic
      construction and inspection of specific tracks. Each call
      returns a fresh instance built from the current dict;
      mutations don't propagate back automatically — call
      :meth:`set_digital` to persist.
    """

    @property
    def parent(self) -> Parent | None:
        return Parent.from_codec(self._d.get("Parent"))

    @property
    def manifestation_class(self) -> str | None:
        return _scalar_text(self._d.get("ManifestationClass"))

    @property
    def made_for_region(self) -> str | None:
        return _scalar_text(self._d.get("MadeForRegion"))

    @property
    def manifestation_details(self) -> str | None:
        return _scalar_text(self._d.get("ManifestationDetails"))

    @property
    def digital(self) -> CodecDict | None:
        """The full Digital sub-block as a raw codec-dict.

        Returns ``None`` when the Manifestation has no Digital metadata.
        When present, the contents follow the
        ``digitalTracksType`` schema (a flat list of ``Track`` and
        ``Container`` choices).

        For typed access to the same content, use
        :meth:`digital_typed`. For whole-block equality (the common
        dedup case), compare two ``digital`` dicts directly.
        """
        v = self._d.get("Digital")
        return v if isinstance(v, dict) else None

    def digital_typed(self) -> object | None:
        """Return a typed view of this Manifestation's Digital block.

        Requires the ``[digital]`` install extra. The codec dict on
        :attr:`digital` is the source of truth; this method builds
        a fresh :class:`~eidr.models.digital.DigitalTracks` instance
        from it on each call. Mutations on the returned object do
        *not* propagate back automatically; call :meth:`set_digital`
        with the modified instance to persist.

        Why a transient view rather than a live-bound property:

        1. The codec dict layer is the source of truth for every
           record kind in the SDK. M8 follows the convention.
        2. Holding a long-lived typed object alongside the dict
           creates two representations that can diverge. A transient
           view is functionally immutable — even if pydantic itself
           allows mutation, the changes are discarded unless
           explicitly written back.
        3. Idiomatic Python: ``dataclasses.replace``,
           ``attrs.evolve``, immutable functional updates. The
           pattern is well-understood.

        Returns:
            A :class:`DigitalTracks` instance, or ``None`` if this
            Manifestation has no Digital sub-block. The return type
            is annotated as :class:`object` to keep pydantic out of
            the ``ManifestationInfo`` import path; callers using the
            typed surface narrow with ``isinstance(...)`` or rely
            on the return type via ``cast`` after they've imported
            :class:`DigitalTracks`.

        Raises:
            ModuleNotFoundError: If the ``[digital]`` extra is not
                installed.
        """
        digital = self.digital
        if digital is None:
            return None

        # Lazy imports so the codec-only path stays free of pydantic.
        from eidr.models._digital_codec import codec_dict_to_digital_tracks
        from eidr.models.digital import DigitalTracks

        result: object = codec_dict_to_digital_tracks(digital, DigitalTracks)
        return result

    def set_digital(self, tracks: object | None) -> None:
        """Overwrite this Manifestation's Digital sub-block.

        The inverse of :meth:`digital_typed`. Serializes a
        :class:`~eidr.models.digital.DigitalTracks` instance back
        to a codec dict and replaces the existing ``Digital`` entry
        on the underlying block. Passing ``None`` removes the
        Digital sub-block entirely.

        Note that this method mutates the underlying codec dict —
        the parent :class:`ContentRecord`'s ``data`` is updated in
        place, matching the pattern used elsewhere in the model
        layer for other sub-blocks.

        Args:
            tracks: A :class:`DigitalTracks` instance, or ``None``
                to clear the Digital sub-block. Strict type-check
                at runtime: must be exactly the typed model, not a
                bare dict (callers wanting to write a raw dict can
                assign through ``record.data`` directly).

        Raises:
            ModuleNotFoundError: If the ``[digital]`` extra is not
                installed.
            TypeError: If ``tracks`` is neither ``None`` nor a
                :class:`DigitalTracks`.
        """
        if tracks is None:
            self._d.pop("Digital", None)
            return

        from eidr.models._digital_codec import digital_tracks_to_codec_dict
        from eidr.models.digital import DigitalTracks

        if not isinstance(tracks, DigitalTracks):
            raise TypeError(
                f"set_digital expected DigitalTracks or None, got "
                f"{type(tracks).__name__}. To write a raw codec dict, "
                f"mutate record.data directly."
            )
        self._d["Digital"] = digital_tracks_to_codec_dict(tracks)


class CompilationInfo(_BlockView):
    """View over a CompilationInfo block (CreationType=Compilation)."""

    @property
    def compilation_class(self) -> str | None:
        return _scalar_text(self._d.get("CompilationClass"))

    @property
    def has_other_inclusions(self) -> str | None:
        cc = self._d.get("CompilationClass")
        if isinstance(cc, dict):
            return cc.get(f"{ATTR_PREFIX}hasOtherInclusions")  # type: ignore[return-value]
        return None

    @property
    def entries(self) -> list[CodecDict]:
        """List of ``md:Entry`` elements (each with ContentID, EntryNumber, etc.)."""
        raw = self._d.get("md:Entry")
        if raw is None:
            return []
        if isinstance(raw, list):
            return [e for e in raw if isinstance(e, dict)]
        if isinstance(raw, dict):
            return [raw]
        return []


class CompositeInfo(_BlockView):
    """View over a CompositeInfo block.

    Note: CompositeInfo is special — it can appear on a Basic record OR
    an Episode record (alongside EpisodeInfo). It is therefore not part
    of the mutually exclusive CreationType-bearing block set.
    """

    @property
    def composite_class(self) -> str | None:
        return _scalar_text(self._d.get("CompositeClass"))

    @property
    def elements(self) -> list[CodecDict]:
        """List of composite Element children (each with ID, Description, etc.)."""
        raw = self._d.get("Element")
        if raw is None:
            return []
        if isinstance(raw, list):
            return [e for e in raw if isinstance(e, dict)]
        if isinstance(raw, dict):
            return [raw]
        return []


# Map ExtraObjectMetadata block local names → (CreationType, view class).
# Ordering matters only for documentation purposes.
_CREATION_BLOCK_MAP: dict[str, tuple[CreationType, type[_BlockView]]] = {
    "SeriesInfo": (CreationType.Series, SeriesInfo),
    "SeasonInfo": (CreationType.Season, SeasonInfo),
    "EpisodeInfo": (CreationType.Episode, EpisodeInfo),
    "EditInfo": (CreationType.Edit, EditInfo),
    "ClipInfo": (CreationType.Clip, ClipInfo),
    "ManifestationInfo": (CreationType.Manifestation, ManifestationInfo),
    "CompilationInfo": (CreationType.Compilation, CompilationInfo),
}


# ─────────────────────────────────────────────────────────────────────────────
# ContentRecord
# ─────────────────────────────────────────────────────────────────────────────


class ContentRecord:
    """Wrapper over an EIDR Content-ID record.

    Construct via :meth:`from_xml`, :meth:`from_json`, or
    :meth:`from_codec_dict`. The underlying codec dict remains the
    single source of truth and is exposed via :attr:`data`.

    Read accessors are non-validating: missing optional fields return
    ``None`` (or empty containers); the wrapper trusts whatever the
    registry returned. Pre-submission validation lives in
    :meth:`validate` (collecting) and :meth:`validate_strict`
    (raising). For typed access to the Manifestation Digital
    sub-tree, see :meth:`ManifestationInfo.digital_typed` (requires
    the ``[digital]`` install extra).

    Equality is defined by the underlying codec-dict equality. Two
    records with identical data compare equal regardless of how they
    were constructed.
    """

    __slots__ = ("_data", "_root")

    def __init__(self, data: CodecDict) -> None:
        """Wrap an existing codec dict.

        Most callers will use :meth:`from_xml` / :meth:`from_json` /
        :meth:`from_codec_dict` instead.
        """
        if not isinstance(data, dict):
            raise EIDRClientError(f"ContentRecord requires a dict, got {type(data).__name__}")
        self._data: CodecDict = data
        self._root: CodecDict = _root_value(data)

    # ─── construction ──────────────────────────────────────────────────────

    @classmethod
    def from_codec_dict(cls, data: CodecDict) -> ContentRecord:
        """Wrap an existing codec dict (e.g., from :mod:`eidr.codecs.xml`).

        Accepts either a wrapped form (``{"FullMetadata": {...}}``) or
        an unwrapped one (the inner contents directly).
        """
        return cls(data)

    @classmethod
    def from_xml(cls, source: bytes | str) -> ContentRecord:
        """Parse an EIDR Content record from XML bytes or text."""
        cd = _xml_codec.to_codec_dict(source)
        return cls(cd)

    @classmethod
    def from_json(
        cls,
        source: str | bytes | dict[str, Any],
        *,
        wrapper_key: str | None = None,
    ) -> ContentRecord:
        """Parse an EIDR Content record from JSON.

        Args:
            source: JSON text, bytes, or already-parsed dict (per the
                MovieLabs MDDF JSON Encoding).
            wrapper_key: If the JSON dropped its top-level wrapper
                (e.g., ``"FullMetadata"``), supply the wrapper name to
                reconstruct it. Otherwise, the top-level key in the
                JSON is used as-is.
        """
        cd = _json_codec.from_json(source, wrapper_key=wrapper_key)
        return cls(cd)

    # ─── output ────────────────────────────────────────────────────────────

    def to_codec_dict(self) -> CodecDict:
        """Return the underlying codec dict (live view; mutations propagate)."""
        return self._data

    def to_xml(
        self,
        *,
        pretty_print: bool = False,
        xml_declaration: bool = True,
    ) -> bytes:
        """Serialize to XML bytes (infoset round trip)."""
        return _xml_codec.to_xml(
            self._data,
            pretty_print=pretty_print,
            xml_declaration=xml_declaration,
        )

    def to_xml_canonical(self, *, method: str = "c14n2") -> bytes:
        """Serialize to byte-stable canonical XML (signing-ready)."""
        return _xml_codec.to_xml_canonical(self._data, method=method)

    def to_json(
        self,
        *,
        wrapper: str = "retain",
        indent: int | None = 2,
    ) -> str:
        """Serialize to JSON text per the MovieLabs MDDF rules.

        Args:
            wrapper: ``"retain"`` (default) keeps the top-level wrapper
                key; ``"drop"`` strips it.
            indent: JSON indent level. ``None`` for compact output.
        """
        return _json_codec.to_json(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
            indent=indent,
        )

    def to_json_canonical(self, *, wrapper: str = "retain") -> str:
        """Serialize to RFC 8785 JCS canonical JSON (signing-ready)."""
        return _json_codec.to_canonical_string(
            self._data,
            wrapper=wrapper,  # type: ignore[arg-type]
        )

    # ─── data access ───────────────────────────────────────────────────────

    @property
    def data(self) -> CodecDict:
        """The underlying codec dict (the single source of truth)."""
        return self._data

    @property
    def base(self) -> CodecDict:
        """The ``BaseObjectData`` sub-dict, or the root itself when absent.

        For :class:`FullMetadata` / :class:`SelfDefinedMetadata`
        records, the base-level fields live under
        ``BaseObjectData``. For :class:`SimpleMetadata` records
        (produced by query results), the fields live at the root
        level with no intervening wrapper — this property falls back
        to the root dict in that case so per-field accessors (``id``,
        ``resource_name``, ``referent_type``, etc.) work uniformly
        across record shapes.
        """
        v = self._root.get("BaseObjectData")
        if isinstance(v, dict):
            return v
        return self._root

    @property
    def extra(self) -> CodecDict:
        """The ``ExtraObjectMetadata`` sub-dict, or ``{}`` if absent."""
        v = self._root.get("ExtraObjectMetadata")
        return v if isinstance(v, dict) else {}

    # ─── BaseObjectData accessors ──────────────────────────────────────────

    @property
    def id(self) -> EIDRID | None:
        """The record's EIDR ID, parsed and validated."""
        text = _scalar_text(self.base.get("ID"))
        if not text:
            return None
        try:
            return EIDRID.parse(text)
        except Exception:
            return None

    @property
    def structural_type(self) -> StructuralType | str | None:
        """The record's StructuralType.

        Returns the :class:`StructuralType` enum when the value is in the
        controlled vocabulary; the raw string otherwise.
        """
        s = _scalar_text(self.base.get("StructuralType"))
        if s is None:
            return None
        try:
            return StructuralType(s)
        except ValueError:
            return s

    @property
    def mode(self) -> Mode | str | None:
        """The record's :class:`Mode` (AudioVisual / Audio / Visual), or raw string if unknown."""
        s = _scalar_text(self.base.get("Mode"))
        if s is None:
            return None
        try:
            return Mode(s)
        except ValueError:
            return s

    @property
    def referent_type(self) -> ReferentType | str | None:
        """The record's :class:`ReferentType`, or raw string if not in the controlled vocabulary."""
        s = _scalar_text(self.base.get("ReferentType"))
        if s is None:
            return None
        try:
            return ReferentType(s)
        except ValueError:
            return s

    @property
    def status(self) -> Status | str | None:
        """The record's :class:`Status` (valid / invalid / tombstoned)."""
        s = _scalar_text(self.base.get("Status"))
        if s is None:
            return None
        try:
            return Status(s)
        except ValueError:
            return s

    @property
    def resource_name(self) -> str | None:
        """The record's primary title (``BaseObjectData/ResourceName``)."""
        return _scalar_text(self.base.get("ResourceName"))

    @property
    def resource_name_lang(self) -> str | None:
        """BCP 47 language of the primary title, when set."""
        rn = self.base.get("ResourceName")
        if isinstance(rn, dict):
            return rn.get(f"{ATTR_PREFIX}lang")  # type: ignore[return-value]
        return None

    @property
    def alternate_resource_names(self) -> list[AlternateResourceName]:
        """All ``AlternateResourceName`` entries (always a list, may be empty)."""
        items = _ensure_list(self.base.get("AlternateResourceName"))
        out: list[AlternateResourceName] = []
        for it in items:
            obj = AlternateResourceName.from_codec(it)
            if obj is not None:
                out.append(obj)
        return out

    @property
    def alternate_ids(self) -> list[AlternateID]:
        """All ``AlternateID`` entries (always a list, may be empty).

        Note: anonymous Resolve calls do NOT return Alt IDs. To populate
        this field, the request must be authenticated.
        """
        items = _ensure_list(self.base.get("AlternateID"))
        out: list[AlternateID] = []
        for it in items:
            obj = AlternateID.from_codec(it)
            if obj is not None:
                out.append(obj)
        return out

    @property
    def release_date(self) -> str | None:
        """Release date as an ISO 8601 date string (e.g. ``"YYYY-MM-DD"``)."""
        return _scalar_text(self.base.get("ReleaseDate"))

    @property
    def country_of_origin(self) -> list[str]:
        """ISO 3166-1 alpha-2 country codes (may be empty)."""
        items = _ensure_list(self.base.get("CountryOfOrigin"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def original_languages(self) -> list[str]:
        """BCP 47 language tags of the original production (may be empty)."""
        items = _ensure_list(self.base.get("OriginalLanguage"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def version_languages(self) -> list[str]:
        """BCP 47 language tags for this Edit (dubbed, subtitled, etc.)."""
        items = _ensure_list(self.base.get("VersionLanguage"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def description(self) -> str | None:
        """Free-text description."""
        return _scalar_text(self.base.get("Description"))

    @property
    def approximate_length(self) -> str | None:
        """xs:duration string, e.g., ``"PT1H30M"``."""
        return _scalar_text(self.base.get("ApproximateLength"))

    @property
    def registrant(self) -> str | None:
        """EIDR Party ID of the registrant (``BaseObjectData/Administrators/Registrant``)."""
        admin = self.base.get("Administrators")
        if isinstance(admin, dict):
            return _scalar_text(admin.get("Registrant"))
        return None

    @property
    def metadata_authorities(self) -> list[str]:
        """Party IDs of any MetadataAuthority entries (may be empty)."""
        admin = self.base.get("Administrators")
        if not isinstance(admin, dict):
            return []
        items = _ensure_list(admin.get("MetadataAuthority"))
        return [s for s in (_scalar_text(x) for x in items) if s is not None]

    @property
    def directors(self) -> list[Credit]:
        """All Director credits (always a list, may be empty)."""
        credits = self.base.get("Credits")
        if not isinstance(credits, dict):
            return []
        items = _ensure_list(credits.get("Director"))
        return [c for c in (Credit.from_codec(it) for it in items) if c is not None]

    @property
    def actors(self) -> list[Credit]:
        """All Actor credits (always a list, may be empty)."""
        credits = self.base.get("Credits")
        if not isinstance(credits, dict):
            return []
        items = _ensure_list(credits.get("Actor"))
        return [c for c in (Credit.from_codec(it) for it in items) if c is not None]

    @property
    def associated_orgs(self) -> list[AssociatedOrg]:
        """All AssociatedOrg entries (always a list, may be empty)."""
        items = _ensure_list(self.base.get("AssociatedOrg"))
        return [a for a in (AssociatedOrg.from_codec(it) for it in items) if a is not None]

    # ─── ExtraObjectMetadata: CreationType-bearing block (mutually exclusive) ───

    @property
    def creation_type(self) -> CreationType:
        """The record's CreationType, derived from which ExtraObjectMetadata block is present.

        Returns :attr:`CreationType.Basic` when no CreationType-bearing
        block is present (and no AliasContinuation; aliases are detected
        elsewhere).
        """
        extra = self.extra
        for block_name, (ct, _) in _CREATION_BLOCK_MAP.items():
            if block_name in extra:
                return ct
        return CreationType.Basic

    @property
    def creation_block(self) -> _BlockView | None:
        """The CreationType-specific block, typed (Series/Season/Episode/Edit/etc.).

        Returns ``None`` for Basic records. The concrete return type is
        determined by :attr:`creation_type`. Use :func:`isinstance` if
        you need to dispatch on it::

            if isinstance(record.creation_block, EpisodeInfo):
                print(record.creation_block.parent)
        """
        extra = self.extra
        for block_name, (_, view_cls) in _CREATION_BLOCK_MAP.items():
            block = extra.get(block_name)
            if isinstance(block, dict):
                return view_cls(block)
        return None

    @property
    def composite_info(self) -> CompositeInfo | None:
        """The CompositeInfo block, if present.

        CompositeInfo is special: it can co-occur with a Basic or Episode
        record (and only those), so it is not part of the mutually
        exclusive CreationType-bearing set.
        """
        ci = self.extra.get("CompositeInfo")
        return CompositeInfo(ci) if isinstance(ci, dict) else None

    # ─── ExtraObjectMetadata: lightweight relationships (any combination) ─

    @property
    def supplemental_content_infos(self) -> list[CodecDict]:
        """All SupplementalContentInfo blocks (may be multiple per record)."""
        items = _ensure_list(self.extra.get("SupplementalContentInfo"))
        return [d for d in items if isinstance(d, dict)]

    @property
    def promotion_infos(self) -> list[CodecDict]:
        """All PromotionInfo blocks."""
        items = _ensure_list(self.extra.get("PromotionInfo"))
        return [d for d in items if isinstance(d, dict)]

    @property
    def alternate_content_infos(self) -> list[CodecDict]:
        """All AlternateContentInfo blocks."""
        items = _ensure_list(self.extra.get("AlternateContentInfo"))
        return [d for d in items if isinstance(d, dict)]

    @property
    def packaging_infos(self) -> list[CodecDict]:
        """All PackagingInfo blocks."""
        items = _ensure_list(self.extra.get("PackagingInfo"))
        return [d for d in items if isinstance(d, dict)]

    # ─── alias handling ─────────────────────────────────────────────────────

    @property
    def alias_continuation(self) -> AliasContinuation | None:
        """Return an :class:`AliasContinuation` if this record carries one.

        An ``<AliasContinuation>`` block inside a record is a marker
        that the record is an alias — resolving this ID via the registry
        will redirect to a different live record. Callers that have
        auto-follow-alias turned off will see records with this field
        populated and should either follow the alias themselves (via
        :attr:`AliasContinuation.target_of_last_aliased`) or handle the
        record as a pointer rather than as substantive content.

        Returns ``None`` when the record does not carry alias continuation
        data — the common case.

        Note that an ``<AliasContinuation>`` *root element* (returned by
        the registry when a bare alias is resolved) should be parsed via
        :meth:`AliasContinuation.from_xml` directly, not via this
        accessor. This accessor surfaces alias data attached to a
        regular Full/Self/Provenance metadata envelope.
        """
        # Alias data can appear as a child of the record root or
        # elsewhere in the envelope; we check the root first.
        raw = self._root.get("AliasContinuation")
        if raw is not None:
            return AliasContinuation.from_codec(raw)
        # Also check top-level wrapper (if constructed directly from an
        # AliasContinuation root element)
        if "AliasContinuation" in self._data:
            raw = self._data["AliasContinuation"]
            return AliasContinuation.from_codec(raw)
        return None

    # ─── validation ────────────────────────────────────────────────────────

    def validate(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> ValidationReport:
        """Run pre-submission validation over this record.

        Applies the EIDR submission profile: schema-required fields
        conditional on CreationType (inheritable fields may be
        omitted on child records, modulo the Season/Episode carve-out
        for ResourceName), controlled-vocabulary checks, EIDR-profile
        credit caps, CreationType-block consistency, CompositeInfo
        placement, and the empty-tag rule.

        **Validation is profile-level, not raw-schema-only.** The
        validator enforces the EIDR submission profile — a selected
        subset of schema rules plus EIDR-specific policy — so a
        passing report means "the registry should accept this
        structurally." It does not resolve ID references (Parent,
        Registrant, alias targets) against the registry; those
        remain the registry's job.

        Args:
            mode: Submission mode. ``"create"`` — ID must be absent
                (the registry assigns it). ``"modify"`` — ID must
                be present and well-formed. ``None`` (default) —
                only validate ID format if present; don't enforce
                presence or absence.
            max_errors: Cap on collected errors (default ``50``).
                When reached, a sentinel ``validation.truncated``
                error is appended. Set high to see every error;
                set to ``1`` to mimic the registry's fail-fast
                behavior.

        Returns:
            A :class:`ValidationReport`. Empty iff the record passes
            all checks; otherwise iterable over
            :class:`ValidationError` instances, capped at
            ``max_errors``.
        """
        from eidr.models._validate_content import validate_content_record

        return validate_content_record(self, mode=mode, max_errors=max_errors)  # type: ignore[arg-type]

    def validate_strict(
        self,
        *,
        mode: str | None = None,
        max_errors: int = 50,
    ) -> None:
        """Run validation and raise on any error.

        Convenience wrapper for :meth:`validate`. Raises
        :class:`~eidr.errors.EIDRValidationError` if the report is
        non-empty. The raised exception carries an ``errors``
        attribute with the full list of :class:`ValidationError`
        instances for inspection.

        Args:
            mode: Forwarded to :meth:`validate`.
            max_errors: Forwarded to :meth:`validate`.

        Raises:
            EIDRValidationError: When validation reports any error.
        """
        self.validate(mode=mode, max_errors=max_errors).raise_if_errors()

    # ─── dunder methods ────────────────────────────────────────────────────

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ContentRecord):
            return self._data == other._data
        return NotImplemented

    def __hash__(self) -> int:
        # Codec dicts aren't hashable; fall back to identity.
        return id(self)

    def __repr__(self) -> str:
        eid = self.id
        rn = self.resource_name
        return f"ContentRecord(id={eid!s}, resource_name={rn!r})"
