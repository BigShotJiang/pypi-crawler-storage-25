"""Value-object types used as elements within :class:`ContentRecord`.

These are small, immutable, hand-written dataclasses representing the
sub-structures that appear inside an EIDR Content record:

* :class:`AlternateID` — a foreign identifier
* :class:`AlternateResourceName` — a localized title
* :class:`AssociatedOrg` — an organization linked to the work
* :class:`Credit` — a director/actor credit (with display + sort name)
* :class:`Parent` — a parent reference (used in Series/Season/Episode/Edit)

Each type implements ``from_codec_dict`` and ``to_codec_dict`` to round
through the codec layer. They preserve any unknown / extension keys
verbatim under ``_extra``, so the wrapper layer is non-lossy even
against records that carry data the wrapper doesn't model.
"""

from __future__ import annotations

from dataclasses import dataclass

from eidr.codecs._rules import ATTR_PREFIX, TEXT_KEY, CodecDict, CodecValue

__all__ = [
    "AliasContinuation",
    "AlternateID",
    "AlternateResourceName",
    "AssociatedOrg",
    "ContactInfo",
    "Credit",
    "OrgName",
    "Parent",
    "Phone",
]


def _scalar(v: CodecValue) -> str | None:
    """Coerce a CodecValue to a string (the common case for leaf elements).

    Handles the shapes the codec emits:

    * ``"text"`` → ``"text"``
    * ``{"value": "text", ...}`` → ``"text"`` (text + attributes)
    * ``["text"]`` → ``"text"`` (singleton list, emitted when the raw
      schema declares an element ``maxOccurs > 1`` but EIDR usage
      constrains it to a single value — e.g. ``md:DisplayName``
      inside a Director/Actor credit)
    * ``[{"value": "text", ...}]`` → ``"text"`` (singleton list wrapping
      the attribute/text shape)
    * ``None`` → ``None``
    * Anything else → ``None``

    The function is deliberately permissive: the wrapper layer trusts
    whatever the codec emits and collapses to the EIDR-profile shape
    without complaining about schema-vs-profile discrepancies.
    """
    if v is None:
        return None
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        text = v.get(TEXT_KEY)
        return text if isinstance(text, str) else None
    if isinstance(v, list) and len(v) == 1:
        # Single-element list — recurse to unwrap. The raw codec emits
        # lists whenever the schema says maxOccurs > 1; many EIDR fields
        # are singleton-in-practice inside a given parent context.
        return _scalar(v[0])
    return None


@dataclass(frozen=True, slots=True)
class AlternateID:
    """A foreign identifier attached to an EIDR Content record.

    Maps to ``BaseObjectData/AlternateID`` and its three attributes:
    ``@domain``, ``@relation``, ``@xsi:type``. The text content is the
    identifier value itself.

    Examples:
        >>> alt = AlternateID(value="tt0123456", relation="IsSameAs", type="IMDB")
        >>> alt.value
        'tt0123456'
    """

    value: str
    """The identifier itself."""

    domain: str | None = None
    """The issuing authority's domain (e.g., ``"http://www.imdb.com"``)."""

    relation: str | None = None
    """The relationship between this ID and the EIDR record (e.g., ``"IsSameAs"``)."""

    type: str | None = None
    """The xsi:type discriminator (e.g., ``"IMDB"``, ``"DOI"``, ``"ISAN"``)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> AlternateID | None:
        """Construct from a CodecDict shape ``{"value": …, "_domain": …, …}``."""
        if value is None:
            return None
        # The codec may emit a single altID wrapped in a list depending
        # on multi-hint configuration; accept both shapes.
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if isinstance(value, str):
            return cls(value=value)
        if not isinstance(value, dict):
            return None
        text = value.get(TEXT_KEY)
        if not isinstance(text, str):
            return None
        return cls(
            value=text,
            domain=value.get(f"{ATTR_PREFIX}domain"),  # type: ignore[arg-type]
            relation=value.get(f"{ATTR_PREFIX}relation"),  # type: ignore[arg-type]
            type=value.get(f"{ATTR_PREFIX}type"),  # type: ignore[arg-type]
        )

    def to_codec(self) -> CodecDict:
        """Render back into a CodecDict shape.

        Always emits the dict form (with ``value`` subkey) when any
        attribute is set; otherwise a bare scalar string is fine, but
        we use the dict shape for consistency.
        """
        d: CodecDict = {TEXT_KEY: self.value}
        if self.domain is not None:
            d[f"{ATTR_PREFIX}domain"] = self.domain
        if self.relation is not None:
            d[f"{ATTR_PREFIX}relation"] = self.relation
        if self.type is not None:
            d[f"{ATTR_PREFIX}type"] = self.type
        return d


@dataclass(frozen=True, slots=True)
class AlternateResourceName:
    """A localized or alternate title for the work.

    Maps to ``BaseObjectData/AlternateResourceName`` with its
    ``@lang`` and ``@titleClass`` attributes.
    """

    value: str
    """The alternate title."""

    lang: str | None = None
    """BCP 47 language tag of this title (e.g., ``"en-US"``, ``"ja"``)."""

    title_class: str | None = None
    """The kind of title (``"working"``, ``"original"``, ``"international"`` etc.)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> AlternateResourceName | None:
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if isinstance(value, str):
            return cls(value=value)
        if not isinstance(value, dict):
            return None
        text = value.get(TEXT_KEY)
        if not isinstance(text, str):
            return None
        return cls(
            value=text,
            lang=value.get(f"{ATTR_PREFIX}lang"),  # type: ignore[arg-type]
            title_class=value.get(f"{ATTR_PREFIX}titleClass"),  # type: ignore[arg-type]
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {TEXT_KEY: self.value}
        if self.lang is not None:
            d[f"{ATTR_PREFIX}lang"] = self.lang
        if self.title_class is not None:
            d[f"{ATTR_PREFIX}titleClass"] = self.title_class
        return d


@dataclass(frozen=True, slots=True)
class AssociatedOrg:
    """An organization linked to a Content record (producer, distributor, etc.).

    Maps to ``BaseObjectData/AssociatedOrg`` with three attributes
    (``@idType``, ``@organizationID``, ``@role``) plus child elements
    ``md:DisplayName`` and zero-or-more ``md:AlternateName``.
    """

    display_name: str | None = None
    """Primary name of the organization (``md:DisplayName``)."""

    alternate_names: tuple[str, ...] = ()
    """Additional names (``md:AlternateName`` elements; ordered)."""

    organization_id: str | None = None
    """Identifier of the organization, if any."""

    id_type: str | None = None
    """Type of the organization ID (e.g., ``"eidrParty"``)."""

    role: str | None = None
    """Role this organization plays (``"producer"``, ``"distributor"``, etc.)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> AssociatedOrg | None:
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        # Display name lives under md:DisplayName (prefixed key)
        display = _scalar(value.get("md:DisplayName"))
        # AlternateName may be scalar or list (it's multi)
        alt = value.get("md:AlternateName")
        if alt is None:
            alt_tuple: tuple[str, ...] = ()
        elif isinstance(alt, list):
            alt_tuple = tuple(_scalar(x) or "" for x in alt if _scalar(x) is not None)
        else:
            s = _scalar(alt)
            alt_tuple = (s,) if s else ()
        return cls(
            display_name=display,
            alternate_names=alt_tuple,
            organization_id=value.get(f"{ATTR_PREFIX}organizationID"),  # type: ignore[arg-type]
            id_type=value.get(f"{ATTR_PREFIX}idType"),  # type: ignore[arg-type]
            role=value.get(f"{ATTR_PREFIX}role"),  # type: ignore[arg-type]
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {}
        if self.id_type is not None:
            d[f"{ATTR_PREFIX}idType"] = self.id_type
        if self.organization_id is not None:
            d[f"{ATTR_PREFIX}organizationID"] = self.organization_id
        if self.role is not None:
            d[f"{ATTR_PREFIX}role"] = self.role
        if self.display_name is not None:
            d["md:DisplayName"] = self.display_name
        if self.alternate_names:
            # The MD-namespaced AlternateName is multi per the bundled hints
            d["md:AlternateName"] = list(self.alternate_names)
        return d


@dataclass(frozen=True, slots=True)
class Credit:
    """A cast or crew credit (Director or Actor).

    Maps to ``Credits/Director`` or ``Credits/Actor`` — both share the
    same shape: ``md:DisplayName`` plus optional ``md:SortName``.
    """

    display_name: str
    """Person's display name (e.g., ``"Hayao Miyazaki"``)."""

    sort_name: str | None = None
    """Sort form, when different from display (e.g., ``"Miyazaki, Hayao"``)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> Credit | None:
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        display = _scalar(value.get("md:DisplayName"))
        if not display:
            return None
        return cls(
            display_name=display,
            sort_name=_scalar(value.get("md:SortName")),
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {"md:DisplayName": self.display_name}
        if self.sort_name is not None:
            d["md:SortName"] = self.sort_name
        return d


@dataclass(frozen=True, slots=True)
class OrgName:
    """The MovieLabs ``md:OrgName-type`` — a named organization.

    Carries display name, optional sort form, any number of alternate
    names, and identifying attributes (``organizationID``, ``idType``,
    ``departmentID``).

    Used by :class:`~eidr.models.party.PartyRecord` (as ``PartyName``)
    and :class:`~eidr.models.service.ServiceRecord` (as ``ServiceName``).
    """

    display_name: str
    """Primary name of the organization."""

    sort_name: str | None = None
    """Sort form, when different from display (e.g. ``"BBC, The"``)."""

    alternate_names: tuple[str, ...] = ()
    """Additional names (ordered)."""

    organization_id: str | None = None
    """Identifier of the organization, if any (e.g. ``"urn:dun:123456"``)."""

    department_id: str | None = None
    """Departmental sub-identifier, if any."""

    id_type: str | None = None
    """Type of ``organization_id`` (e.g. ``"DUNS"``, ``"eidrParty"``)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> OrgName | None:
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        display = _scalar(value.get("md:DisplayName")) or _scalar(value.get("DisplayName"))
        if not display:
            return None
        # AlternateName can be scalar or list; normalize to tuple
        alt = value.get("md:AlternateName")
        if alt is None:
            alt = value.get("AlternateName")
        if alt is None:
            alt_tuple: tuple[str, ...] = ()
        elif isinstance(alt, list):
            alt_tuple = tuple(_scalar(x) or "" for x in alt if _scalar(x) is not None)
        else:
            s = _scalar(alt)
            alt_tuple = (s,) if s else ()
        return cls(
            display_name=display,
            sort_name=_scalar(value.get("md:SortName")) or _scalar(value.get("SortName")),
            alternate_names=alt_tuple,
            organization_id=value.get(f"{ATTR_PREFIX}organizationID"),  # type: ignore[arg-type]
            department_id=value.get(f"{ATTR_PREFIX}departmentID"),  # type: ignore[arg-type]
            id_type=value.get(f"{ATTR_PREFIX}idType"),  # type: ignore[arg-type]
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {}
        if self.organization_id is not None:
            d[f"{ATTR_PREFIX}organizationID"] = self.organization_id
        if self.department_id is not None:
            d[f"{ATTR_PREFIX}departmentID"] = self.department_id
        if self.id_type is not None:
            d[f"{ATTR_PREFIX}idType"] = self.id_type
        d["md:DisplayName"] = self.display_name
        if self.sort_name is not None:
            d["md:SortName"] = self.sort_name
        if self.alternate_names:
            d["md:AlternateName"] = list(self.alternate_names)
        return d


@dataclass(frozen=True, slots=True)
class Phone:
    """A phone number with an optional ``@type`` classifier."""

    number: str
    """The phone number as a string (no format enforced)."""

    type: str | None = None
    """Kind of number (e.g. ``"office"``, ``"mobile"``)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> Phone | None:
        if value is None:
            return None
        if isinstance(value, str):
            return cls(number=value)
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        text = value.get(TEXT_KEY)
        if not isinstance(text, str):
            return None
        return cls(
            number=text,
            type=value.get(f"{ATTR_PREFIX}type"),  # type: ignore[arg-type]
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {TEXT_KEY: self.number}
        if self.type is not None:
            d[f"{ATTR_PREFIX}type"] = self.type
        return d


@dataclass(frozen=True, slots=True)
class ContactInfo:
    """The MovieLabs ``md:ContactInfo-type`` — a contact record.

    Attached to a :class:`~eidr.models.party.PartyRecord`. Required
    fields are ``name`` and ``primary_email``. The remaining fields
    are optional and may be empty.
    """

    name: str
    """Contact person or desk name."""

    primary_email: str
    """Primary email address."""

    alternate_emails: tuple[str, ...] = ()
    """Additional email addresses."""

    addresses: tuple[str, ...] = ()
    """Postal addresses, free-form strings."""

    phones: tuple[Phone, ...] = ()
    """Phone numbers with optional type tags."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> ContactInfo | None:
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        name = _scalar(value.get("Name"))
        email = _scalar(value.get("PrimaryEmail"))
        if not name or not email:
            return None

        def _to_tuple(raw: CodecValue) -> tuple[str, ...]:
            if raw is None:
                return ()
            if isinstance(raw, list):
                return tuple(s for s in (_scalar(x) for x in raw) if s)
            s = _scalar(raw)
            return (s,) if s else ()

        alt_emails = _to_tuple(value.get("AlternateEmail"))
        addrs = _to_tuple(value.get("Address"))

        # Phones may be scalar, list, or dict-with-attributes
        phones_raw = value.get("Phone")
        if phones_raw is None:
            phones_tuple: tuple[Phone, ...] = ()
        elif isinstance(phones_raw, list):
            phones_tuple = tuple(
                p for p in (Phone.from_codec(x) for x in phones_raw) if p is not None
            )
        else:
            single = Phone.from_codec(phones_raw)
            phones_tuple = (single,) if single else ()

        return cls(
            name=name,
            primary_email=email,
            alternate_emails=alt_emails,
            addresses=addrs,
            phones=phones_tuple,
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {
            "Name": self.name,
            "PrimaryEmail": self.primary_email,
        }
        if self.alternate_emails:
            d["AlternateEmail"] = list(self.alternate_emails)
        if self.addresses:
            d["Address"] = list(self.addresses)
        if self.phones:
            d["Phone"] = [p.to_codec() for p in self.phones]
        return d


@dataclass(frozen=True, slots=True)
class Parent:
    """A parent reference (used in Series/Season/Episode/Edit/Clip/Manifestation).

    Encodes both the parent's EIDR ID and its relationship type.
    """

    id: str
    """The parent's EIDR ID (canonical form)."""

    relationship_type: str | None = None
    """The kind of parent-child relationship (e.g., ``"IsSeasonOf"``)."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> Parent | None:
        if value is None:
            return None
        # Codec may emit a singleton list if the raw schema allows multi
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        # Parent has child elements <ID> and <RelationshipType>
        pid = _scalar(value.get("ID"))
        if not pid:
            return None
        return cls(
            id=pid,
            relationship_type=_scalar(value.get("RelationshipType")),
        )

    def to_codec(self) -> CodecDict:
        d: CodecDict = {"ID": self.id}
        if self.relationship_type is not None:
            d["RelationshipType"] = self.relationship_type
        return d


@dataclass(frozen=True, slots=True)
class AliasContinuation:
    """An alias-continuation record — a pointer to a replacement record.

    EIDR records can be *aliased* to another record when they are
    superseded, merged, or administratively redirected. Resolving an
    aliased record returns an ``<AliasContinuation>`` payload (with
    ``<LastAliased>`` — the ID of the aliased record itself — and
    ``<TargetOfLastAliased>`` — the ID of the replacement) rather than
    regular metadata. This is **not** an error: callers that have
    "follow alias" disabled will routinely receive these records and
    must be prepared to handle them.

    Callers should detect aliases via :meth:`ContentRecord.alias_continuation`
    (when a record carries a continuation alongside its metadata) or
    by parsing an ``<AliasContinuation>`` root element directly with
    :meth:`AliasContinuation.from_xml`.

    Attributes reference EIDR Content IDs in canonical DOI form.
    """

    last_aliased: str
    """The EIDR ID of the now-aliased record (i.e., the ID that was resolved)."""

    target_of_last_aliased: str
    """The EIDR ID of the current replacement — follow this to get the live record."""

    @classmethod
    def from_codec(cls, value: CodecValue) -> AliasContinuation | None:
        """Construct from a codec-dict shape.

        Accepts either the bare inner contents
        ``{"LastAliased": "...", "TargetOfLastAliased": "..."}`` or a
        wrapped form ``{"AliasContinuation": {...}}``.
        """
        if value is None:
            return None
        if isinstance(value, list):
            if len(value) != 1:
                return None
            value = value[0]
        if not isinstance(value, dict):
            return None
        # Accept the wrapped form: {"AliasContinuation": {...}}
        if "AliasContinuation" in value and len(value) == 1:
            inner = value["AliasContinuation"]
            if not isinstance(inner, dict):
                return None
            value = inner
        last = _scalar(value.get("LastAliased"))
        target = _scalar(value.get("TargetOfLastAliased"))
        if last is None or target is None:
            return None
        return cls(last_aliased=last, target_of_last_aliased=target)

    def to_codec(self) -> CodecDict:
        """Render as the inner-contents shape (caller wraps if needed)."""
        return {
            "LastAliased": self.last_aliased,
            "TargetOfLastAliased": self.target_of_last_aliased,
        }

    @classmethod
    def from_xml(cls, source: bytes | str) -> AliasContinuation | None:
        """Parse an ``<AliasContinuation>`` XML document directly.

        Args:
            source: Raw XML bytes or text. The root element must be
                ``<AliasContinuation>`` in the EIDR schema namespace.

        Returns:
            An :class:`AliasContinuation` instance, or ``None`` if the
            input parses but does not contain the expected fields.
        """
        # Local import to avoid a circular codecs↔models dependency at
        # module-import time.
        from eidr.codecs import xml as _xml_codec

        cd = _xml_codec.to_codec_dict(source)
        return cls.from_codec(cd)
