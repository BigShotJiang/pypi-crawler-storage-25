"""Top-level dispatcher for EIDR registry documents.

Parses any EIDR registry document into the appropriate wrapper type.

Registry responses come in several shapes depending on the operation:

* ``<FullMetadata>`` / ``<SelfDefinedMetadata>`` / ``<ProvenanceMetadata>``
  wrappers for Content record resolution — mapped to
  :class:`~eidr.models.content.ContentRecord`.
* ``<Party>`` for a resolved Party record —
  :class:`~eidr.models.party.PartyRecord`.
* ``<Service>`` for a resolved Service record —
  :class:`~eidr.models.service.ServiceRecord`.
* ``<AliasContinuation>`` for an aliased Content record being returned
  without auto-follow — :class:`~eidr.models.AliasContinuation`.
* ``<PartyAliasContinuation>`` / ``<ServiceAliasContinuation>`` —
  :class:`~eidr.models.AliasContinuation` (same shape).

:func:`parse` dispatches on the root element local name. Callers that
want to handle a single known record kind can continue to use the
type-specific ``from_xml`` / ``from_json`` constructors; :func:`parse`
is for code paths that don't know in advance which response they'll see
(for example, a generic "resolve anything" helper in a CLI tool).
"""

from __future__ import annotations

from eidr.codecs import xml as _xml_codec
from eidr.codecs._rules import CodecDict
from eidr.errors import EIDRClientError
from eidr.models._value_objects import AliasContinuation
from eidr.models.content import ContentRecord
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord

__all__ = ["ParsedRecord", "parse", "parse_codec_dict"]


ParsedRecord = ContentRecord | PartyRecord | ServiceRecord | AliasContinuation
"""The possible return types from :func:`parse`."""


# Map root element local-names to the wrapper they produce. When we
# encounter a name not in this map, we fall back to ContentRecord
# (which is permissive enough to hold arbitrary metadata envelopes
# the codec can round-trip).
_CONTENT_ROOTS = frozenset(
    {
        "FullMetadata",
        "SelfDefinedMetadata",
        "ProvenanceMetadata",
        "InheritedMetadata",
        "SimpleMetadata",
    }
)
_PARTY_ROOTS = frozenset({"Party"})
_SERVICE_ROOTS = frozenset({"Service"})
_ALIAS_ROOTS = frozenset(
    {
        "AliasContinuation",
        "PartyAliasContinuation",
        "ServiceAliasContinuation",
    }
)


def parse(source: bytes | str) -> ParsedRecord:
    """Parse an EIDR registry response into the appropriate wrapper.

    Args:
        source: XML bytes or text. The root element is inspected to
            decide which wrapper to return.

    Returns:
        A :class:`~eidr.models.content.ContentRecord`,
        :class:`~eidr.models.party.PartyRecord`,
        :class:`~eidr.models.service.ServiceRecord`, or
        :class:`~eidr.models.AliasContinuation`, depending on the root
        element of the document.

    Raises:
        EIDRClientError: When the root element is not one we recognize
            *and* the input does not look like a Content metadata
            envelope (which would be accepted permissively).
    """
    codec_dict = _xml_codec.to_codec_dict(source)
    return parse_codec_dict(codec_dict)


def parse_codec_dict(codec_dict: CodecDict) -> ParsedRecord:
    """Dispatch an already-parsed codec dict to the appropriate wrapper.

    Useful when the codec dict was produced by another path (e.g.
    :func:`eidr.codecs.json.from_json`) and you want the same
    root-element-driven dispatch as :func:`parse`.
    """
    if not isinstance(codec_dict, dict) or not codec_dict:
        raise EIDRClientError(
            f"parse() requires a non-empty codec dict; got {type(codec_dict).__name__}"
        )

    # The codec dict may carry namespace declarations as sibling keys
    # (e.g. ``_xmlns``). Skip them when looking for the root.
    candidates = [k for k in codec_dict if not k.startswith("_")]
    if len(candidates) != 1:
        raise EIDRClientError(
            "parse() expected a single root element; found "
            f"{len(candidates)}: {candidates!r}. "
            "If you have a bulk response envelope, iterate its child "
            "elements and parse each individually."
        )

    root_name = candidates[0]

    if root_name in _ALIAS_ROOTS:
        # Unwrap whatever the outer element is (AliasContinuation,
        # PartyAliasContinuation, ServiceAliasContinuation) — the inner
        # shape is the same regardless, and AliasContinuation.from_codec
        # only recognizes the shared inner layout.
        inner = codec_dict[root_name]
        if not isinstance(inner, dict):
            raise EIDRClientError(
                f"Document root is <{root_name}> but its contents are not a structured record."
            )
        alias = AliasContinuation.from_codec(inner)
        if alias is None:
            raise EIDRClientError(
                f"Document root is <{root_name}> but the contents did not "
                "match the expected alias-continuation shape "
                "(LastAliased + TargetOfLastAliased)."
            )
        return alias

    if root_name in _PARTY_ROOTS:
        return PartyRecord(codec_dict)

    if root_name in _SERVICE_ROOTS:
        return ServiceRecord(codec_dict)

    if root_name in _CONTENT_ROOTS:
        return ContentRecord(codec_dict)

    # Unrecognized root. Content records are the dominant response kind,
    # so we default there but flag the caller about the ambiguity.
    raise EIDRClientError(
        f"Unrecognized root element <{root_name}>. "
        f"Known roots: Content ({sorted(_CONTENT_ROOTS)}), "
        f"Party ({sorted(_PARTY_ROOTS)}), "
        f"Service ({sorted(_SERVICE_ROOTS)}), "
        f"Alias ({sorted(_ALIAS_ROOTS)}). "
        "Use the type-specific constructor (e.g. ContentRecord.from_xml) "
        "to parse this payload explicitly."
    )
