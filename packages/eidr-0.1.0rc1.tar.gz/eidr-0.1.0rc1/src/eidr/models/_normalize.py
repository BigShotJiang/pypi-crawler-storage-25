"""Whitespace normalization for pre-submission record cleanup.

The EIDR registry normalizes text content on its side — leading and
trailing whitespace is stripped, and runs of internal whitespace are
collapsed to a single space. Records returned from the registry are
already normalized. Applying the same normalization client-side before
submission has two benefits:

* The registry doesn't have to spend cycles doing it for you (it
  still verifies, but finds nothing to fix).
* What you submit matches what comes back on resolve, which avoids
  confusing bug reports of the form "my title has different spaces
  than I submitted."

This module provides :func:`normalize_whitespace`, which walks a codec
dict and applies the normalization in place. It is designed to
compose cleanly with :func:`~eidr.models.strip_empty_tags`: run
normalization first, then strip, so that fields that become empty
after whitespace collapse (e.g. ``"   "``) are removed as empty tags.

Rules
-----

**Text content** (leaf string values and the ``value`` key of text-with-
attribute dicts):

* Leading and trailing whitespace is stripped.
* Runs of two or more whitespace characters (spaces, tabs, newlines)
  are collapsed to a single space.

**Attribute values** follow XSD ``xs:token`` semantics:

* Leading and trailing whitespace is stripped.
* Runs of internal whitespace are collapsed to a single space.

Note that for text content we also collapse, so text and attribute
normalization are in fact identical at the moment — but they have
separate functions because their contracts differ (text is xs:string
which strictly requires strip-and-collapse; attributes are xs:token
which permits-and-recommends it). If the registry ever changes its
attribute handling, this split lets us adjust one without the other.

Usage
-----

    >>> from eidr.models import normalize_whitespace, strip_empty_tags
    >>> normalize_whitespace(record.data)   # collapse text whitespace
    >>> strip_empty_tags(record.data)        # remove any now-empty tags
    >>> report = record.validate()            # should be clean of both
"""

from __future__ import annotations

import re

from eidr.codecs._rules import ATTR_PREFIX, TEXT_KEY, CodecDict, CodecValue

__all__ = ["normalize_whitespace"]


# Matches runs of two or more whitespace characters (any kind).
_WHITESPACE_RUN = re.compile(r"\s+")


def normalize_whitespace(codec_dict: CodecDict) -> CodecDict:
    """Normalize whitespace in text content and attribute values, in place.

    Text content has leading/trailing whitespace stripped and runs of
    internal whitespace collapsed to a single space. Attribute values
    have leading/trailing whitespace stripped only (``xs:token``
    behavior); internal whitespace in attributes is preserved.

    Returns the same dict for call-chaining convenience.

    Args:
        codec_dict: The codec dict to modify. Modified in place.

    Returns:
        The same codec dict.
    """
    _normalize_dict(codec_dict)
    return codec_dict


def _normalize_text(s: str) -> str:
    """Strip + collapse internal whitespace runs to a single space."""
    return _WHITESPACE_RUN.sub(" ", s).strip()


def _normalize_attr(s: str) -> str:
    """xs:token: strip leading/trailing whitespace, collapse internal runs."""
    return _WHITESPACE_RUN.sub(" ", s).strip()


def _normalize_dict(d: CodecDict) -> None:
    """Walk a dict, normalizing every text node and attribute value in place."""
    for key in list(d.keys()):
        value = d[key]
        if key == TEXT_KEY:
            if isinstance(value, str):
                d[key] = _normalize_text(value)
            continue
        if key.startswith(ATTR_PREFIX):
            # Attribute — xs:token semantics
            if isinstance(value, str):
                d[key] = _normalize_attr(value)
            continue
        # Child element: recurse
        d[key] = _normalize_value(value)


def _normalize_value(value: CodecValue) -> CodecValue:
    """Normalize an element's value (text, list, or dict)."""
    if value is None:
        return None
    if isinstance(value, str):
        return _normalize_text(value)
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        _normalize_dict(value)
        return value
    # CodecValue = None | str | list | dict is exhaustive; this line only
    # runs if the type spec is ever broken, and silently passing the
    # value through is the safest behavior.
    return value  # type: ignore[unreachable]  # pragma: no cover
