"""The :class:`VirtualFields` response object.

Wraps a :class:`<VirtualFields>` response element from the
``/virtual/object/{ID}`` endpoint. The endpoint returns a record's
content rendered in one or more "views" — Full, SelfDefined, Alias —
each of which is a serialized representation of the same underlying
record. The serializations are returned as opaque strings; callers
decide how to interpret them (typically by parsing through
:meth:`ContentRecord.from_xml` if they need the typed surface).

Wire shape (``virtualFieldsType``, defined in ``common.xsd``)::

    <VirtualFields>
      <ID>10.5240/...</ID>
      <Full>... serialized record content ...</Full>
      <SelfDefined>... serialized record content ...</SelfDefined>
      <Alias>... serialized record content ...</Alias>
    </VirtualFields>

The ID is always present. Any subset of Full / SelfDefined / Alias
may be present, depending on what views the registry computed for
that record.
"""

from __future__ import annotations

from dataclasses import dataclass

from eidr.codecs._rules import CodecDict


@dataclass(frozen=True)
class VirtualFields:
    """Response from ``Client.virtual_fields(asset_id)``.

    Represents one record's virtual-fields rendering. Construct via
    :meth:`from_codec_dict` (typically called internally by
    :class:`Client`); not normally instantiated by application code.

    Attributes:
        id: The record's EIDR ID — always present, mirrors the
            input asset ID.
        full: The full serialized record (XML form), or ``None`` if
            not provided.
        self_defined: The self-defined view (a record body
            describing only the fields the record itself sets, no
            inherited values), or ``None``.
        alias: The alias-resolution view (the chain of aliases this
            record participates in, if any), or ``None``.

    Each present field is a string. The SDK does not parse the
    contained XML automatically — callers parse to a typed record
    only if they need it::

        vf = client.virtual_fields("10.5240/...")
        if vf.full is not None:
            full_record = ContentRecord.from_xml(vf.full.encode("utf-8"))
    """

    id: str
    full: str | None = None
    self_defined: str | None = None
    alias: str | None = None

    @classmethod
    def from_codec_dict(cls, data: CodecDict) -> VirtualFields:
        """Build from the codec-dict form of a ``<VirtualFields>`` element.

        Tolerates the ID being either a bare string or wrapped in
        a list-of-one-string (codec layer normalization).
        """
        return cls(
            id=_scalar(data.get("ID")),
            full=_scalar_or_none(data.get("Full")),
            self_defined=_scalar_or_none(data.get("SelfDefined")),
            alias=_scalar_or_none(data.get("Alias")),
        )


def _scalar(value: object) -> str:
    """Extract a scalar string from a codec-dict cell.

    The codec layer wraps repeatable elements in lists; for
    single-occurrence elements it varies by parser hint. We accept
    both shapes for robustness.
    """
    if isinstance(value, list):
        if not value:
            raise ValueError("Expected non-empty list value")
        value = value[0]
    if isinstance(value, str):
        return value
    raise ValueError(f"Expected scalar string, got {type(value).__name__}")


def _scalar_or_none(value: object) -> str | None:
    """Like :func:`_scalar` but returns ``None`` for absent / empty values."""
    if value is None:
        return None
    if isinstance(value, list) and not value:
        return None
    return _scalar(value)
