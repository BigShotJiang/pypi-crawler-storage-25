"""Validation error types for pre-submission record checking.

The validation layer is used to check records **before** submitting
them to the registry via register/modify operations. It does NOT run
on records parsed from registry responses — those are trusted as-is
(the registry is the source of truth for what a valid record looks
like). See :meth:`ContentRecord.validate` and its siblings.

Design
------

Validation returns a :class:`ValidationReport` rather than raising on
the first error. Callers who want fail-fast behavior can use
:meth:`ValidationReport.raise_if_errors` or call
:meth:`Record.validate_strict`, which raises
:class:`~eidr.errors.EIDRValidationError` on any error.

Each :class:`ValidationError` carries:

* a machine-readable ``code`` for programmatic triage
  (e.g., ``"content.creation_type.block_mismatch"``)
* a human-readable ``message``
* a ``path`` into the record where the problem lives
  (e.g., ``"BaseObjectData/ReferentType"``), or ``None`` for
  whole-record issues
* an optional ``value`` showing what was found (redacted for
  sensitive fields — never applicable at this layer, but the field is
  kept optional for future-proofing)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

__all__ = ["ValidationError", "ValidationReport"]


@dataclass(frozen=True, slots=True)
class ValidationError:
    """A single validation failure."""

    code: str
    """Machine-readable error code.

    Codes are dotted, hierarchical, lowercase. Examples:

    * ``"content.creation_type.block_mismatch"``
    * ``"content.required_field.missing"``
    * ``"content.vocabulary.invalid"``
    * ``"content.credits.too_many_directors"``
    * ``"party.required_field.missing"``
    * ``"service.vocabulary.invalid"``
    """

    message: str
    """Human-readable description of the problem."""

    path: str | None = None
    """XPath-style location of the problem within the record.

    Uses local names (no namespace prefixes) for readability:
    ``"BaseObjectData/Credits/Director[0]/md:DisplayName"``.
    """

    value: Any = None
    """The offending value, if relevant. Used for messages like
    ``"Mode='MovieTheater' is not one of AudioVisual, Audio, Visual"``."""


@dataclass(slots=True)
class ValidationReport:
    """The outcome of a validation pass.

    Behaves like a list of :class:`ValidationError` — iterable, sized,
    truthy iff non-empty. Use :meth:`raise_if_errors` for fail-fast
    behavior, or :attr:`errors` to inspect the list directly.

    Validation stops collecting errors once the report reaches
    :attr:`max_errors` entries *total* (including the truncation
    sentinel). A cap of 50 yields at most 49 real errors plus one
    ``validation.truncated`` sentinel when more would have fit. This
    matters because the registry itself fails on the first error —
    a caller trying to fix a record with 400 wrong fields would
    otherwise have to decode 400 errors before finding the one
    they care about. ``50`` is a reasonable default: enough to
    cover a realistically broken record, not so many that
    pathological input locks up output.

    ``max_errors`` must be ≥ 1 (lower values are rejected at
    construction time — a cap of 0 would produce a report
    containing only the truncation sentinel, which is not useful).
    A cap of 1 gives the same fail-fast shape as the registry:
    the first real error, no sentinel.

    Example::

        report = record.validate()
        if report:
            for err in report:
                print(f"{err.code}: {err.message} at {err.path}")
        report.raise_if_errors()  # no-op if empty, else raises
    """

    errors: list[ValidationError] = field(default_factory=list)
    max_errors: int = 50
    truncated: bool = False

    def __post_init__(self) -> None:
        if self.max_errors < 1:
            raise ValueError(
                f"max_errors must be >= 1 (got {self.max_errors}); "
                "a cap of 0 or negative produces a report with only "
                "the truncation sentinel, which is not useful."
            )

    def add(
        self,
        code: str,
        message: str,
        *,
        path: str | None = None,
        value: Any = None,
    ) -> None:
        """Append a new error to the report, respecting :attr:`max_errors`.

        The semantics: the report will contain at most
        :attr:`max_errors` entries total. Special cases:

        * ``max_errors == 1`` — fail-fast mode. The first error is
          recorded; subsequent adds are dropped. No sentinel.
        * ``max_errors > 1`` — the last slot is reserved for the
          ``validation.truncated`` sentinel if more errors would
          have fit. So ``max_errors == 50`` gives at most 49 real
          errors plus one sentinel.
        """
        if self.truncated:
            return

        # Fail-fast mode: record the first error, stop.
        if self.max_errors == 1:
            if not self.errors:
                self.errors.append(
                    ValidationError(code=code, message=message, path=path, value=value)
                )
            self.truncated = True
            return

        # Cap mode: reserve the last slot for the truncation sentinel.
        # When len(errors) == max_errors - 1, adding one more would
        # reach the cap; instead, we add the sentinel and stop.
        if len(self.errors) + 1 >= self.max_errors:
            self.errors.append(
                ValidationError(
                    code="validation.truncated",
                    message=(
                        f"Reached max_errors={self.max_errors}; additional "
                        "errors suppressed. Fix the top-of-list problems "
                        "and re-validate, or pass a higher max_errors."
                    ),
                )
            )
            self.truncated = True
            return
        self.errors.append(ValidationError(code=code, message=message, path=path, value=value))

    def extend(self, other: ValidationReport) -> None:
        """Merge another report's errors into this one, honoring max_errors."""
        for err in other.errors:
            if self.truncated:
                return
            if self.max_errors == 1:
                if not self.errors:
                    self.errors.append(err)
                self.truncated = True
                return
            if len(self.errors) + 1 >= self.max_errors:
                self.errors.append(
                    ValidationError(
                        code="validation.truncated",
                        message=(
                            f"Reached max_errors={self.max_errors}; additional errors suppressed."
                        ),
                    )
                )
                self.truncated = True
                return
            self.errors.append(err)

    def raise_if_errors(self) -> None:
        """Raise :class:`~eidr.errors.EIDRValidationError` iff non-empty.

        The exception's ``errors`` attribute carries the full list,
        so callers can inspect after catching.
        """
        if self.errors:
            # Local import to avoid a circular dependency with the
            # errors module.
            from eidr.errors import EIDRValidationError

            n = len(self.errors)
            first = self.errors[0]
            summary = (
                f"{n} validation error{'s' if n != 1 else ''}; "
                f"first: [{first.code}] {first.message}"
                + (f" at {first.path}" if first.path else "")
            )
            exc = EIDRValidationError(summary)
            exc.errors = list(self.errors)
            raise exc

    # Collection protocol so the report behaves like a list
    def __bool__(self) -> bool:
        return bool(self.errors)

    def __len__(self) -> int:
        return len(self.errors)

    def __iter__(self):  # type: ignore[no-untyped-def]
        return iter(self.errors)

    def __getitem__(self, index: int) -> ValidationError:
        return self.errors[index]

    def __repr__(self) -> str:
        return f"ValidationReport({len(self.errors)} error(s))"
