"""The :class:`EIDRID` value type.

Parse, validate, and convert between representations of EIDR identifiers
per the *EIDR ID Format* specification (v1.51).

Summary of EIDR ID structure
----------------------------

An EIDR ID is a DOI of the form::

    10.<sub-prefix>/<suffix>

where the ``sub-prefix`` categorizes the ID:

==========  ==========  ================================================
Sub-prefix  Category    Description
==========  ==========  ================================================
``5240``    Content     Audiovisual works and related assets
``5237``    Party       Organizations (used in Content and Service records)
``5239``    Service     Audiovisual content delivery services / channels
``5238``    User        Client accounts (used by access control)
==========  ==========  ================================================

Content ID suffix format: ``XXXX-XXXX-XXXX-XXXX-XXXX-C``
    Five groups of 4 hexadecimal digits plus a Mod 37,36 check character.

Party / Service / User ID suffix format: ``XXXX-XXXX``
    Two groups of 4 hexadecimal digits.

This module supports:

* Strict format validation on construction.
* Case-insensitive equality; normalization to uppercase canonical form.
* Detection of sub-prefix category.
* Lossless conversion to/from alternate representations: canonical-no-hyphens,
  filename form (hyphens only), URN (``urn:eidr:``), DOI URN (``urn:doi:``),
  DOI proxy URL, compact-binary (12 bytes), and base64url of compact-binary.

.. note::

   Content ID check-character validation (ISO 7064 Mod 37,36) is enabled by
   default. It can be disabled per-call via ``verify_check=False`` on
   :meth:`EIDRID.parse` when working with potentially-malformed inputs that
   still need to be routed (e.g., during data-cleanup pipelines). The
   registry performs check-character validation on every submission, so it
   is always the authoritative arbiter.
"""

from __future__ import annotations

import base64
import re
from dataclasses import dataclass
from enum import Enum
from typing import ClassVar, Final

from eidr.errors import EIDRIDFormatError
from eidr.models._checkchar import (
    compute_check_char,
)
from eidr.models._checkchar import (
    verify_check_char as _verify_check_char,
)

__all__ = ["EIDRID", "IDCategory"]


class IDCategory(Enum):
    """The four EIDR ID categories, keyed by sub-prefix."""

    CONTENT = "5240"
    PARTY = "5237"
    SERVICE = "5239"
    USER = "5238"

    @classmethod
    def from_subprefix(cls, subprefix: str) -> IDCategory:
        """Return the category for a sub-prefix string.

        Raises:
            ValueError: If the sub-prefix is not recognized.
        """
        for member in cls:
            if member.value == subprefix:
                return member
        raise ValueError(f"Unknown EIDR sub-prefix: {subprefix!r}")


# Content ID suffix: 5 × 4 hex digits + 1 check char
# ASCII hex only (EIDR spec character set)
_CONTENT_SUFFIX_PATTERN: Final = re.compile(
    r"^([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-Z])$"
)

# Party/Service/User ID suffix: 2 × 4 hex digits (no check char per EIDR spec §3.1.1)
_SHORT_SUFFIX_PATTERN: Final = re.compile(r"^([0-9A-F]{4})-([0-9A-F]{4})$")

# User ID sub-prefix also permits a free-form identifier rather than hex pattern
# (e.g., "10.5238/username"). The EIDR ID Format spec constrains the character
# set to [A-Za-z0-9._-] but does not mandate a hyphen-quad shape.
# See "Character Set" section in EIDR ID Format v1.51.
_USER_SUFFIX_PATTERN: Final = re.compile(r"^[A-Za-z0-9._\-]{1,64}$")

# Prefix is always "10." followed by a 4-digit sub-prefix.
_PREFIX_PATTERN: Final = re.compile(r"^10\.(\d{4})/(.+)$")


@dataclass(frozen=True)
class EIDRID:
    """A parsed, validated EIDR identifier.

    :class:`EIDRID` is an immutable value object. Construct via the class
    directly or via the :meth:`parse` / :meth:`from_any` / :meth:`from_urn`
    / :meth:`from_base64url` class methods, which also accept alternate
    representations.

    Equality and hashing are case-insensitive (two IDs that differ only in
    case compare equal and hash to the same value).

    Attributes:
        prefix: The DOI prefix, always ``"10.<subprefix>"``.
        suffix: The canonical-form suffix (uppercase, hyphens preserved).
        category: The :class:`IDCategory` indicated by the sub-prefix.

    Example:
        >>> eid = EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5")
        >>> eid.category
        <IDCategory.CONTENT: '5240'>
        >>> str(eid)
        '10.5240/7791-8534-2C23-9030-8610-5'
        >>> eid.to_filename()
        '10-5240-7791-8534-2C23-9030-8610-5'
        >>> eid == EIDRID.parse("10.5240/7791-8534-2c23-9030-8610-5")  # case-insens.
        True
    """

    prefix: str
    suffix: str
    category: IDCategory

    #: Sub-prefixes that use the Content ID suffix shape (with check char).
    _CONTENT_CATEGORIES: ClassVar[frozenset[IDCategory]] = frozenset({IDCategory.CONTENT})

    def __post_init__(self) -> None:
        # Runtime guard for the (intentionally permissive) constructor:
        # callers can use EIDRID(prefix, suffix, category) directly, but we
        # still validate the final shape and (for Content IDs) the check char.
        object.__setattr__(self, "prefix", self.prefix.strip())
        object.__setattr__(self, "suffix", self.suffix.strip().upper())
        # Validate that prefix matches the category.
        expected_prefix = f"10.{self.category.value}"
        if self.prefix != expected_prefix:
            raise EIDRIDFormatError(
                f"Prefix {self.prefix!r} does not match category "
                f"{self.category.name} (expected {expected_prefix!r})",
                value=self.canonical(),
            )
        # Validate suffix shape per category.
        self._validate_suffix(self.suffix, self.category)
        # Validate Content ID check character. Direct constructor always verifies;
        # use EIDRID.parse(value, verify_check=False) to accept unverified IDs.
        if self.category is IDCategory.CONTENT:
            self._verify_check_char_or_raise()

    # ─── construction from various representations ────────────────────────

    @classmethod
    def parse(cls, value: str, *, verify_check: bool = True) -> EIDRID:
        """Parse an EIDR ID in canonical DOI form.

        Accepts the canonical form ``10.<subprefix>/<suffix>``, in either
        case. Whitespace is stripped.

        Args:
            value: The ID string.
            verify_check: When True (default), Content IDs must have a valid
                ISO 7064 Mod 37,36 check character. When False, any character
                in the check position is accepted. This opt-out is useful
                when processing potentially-malformed data in cleanup
                pipelines — but note that the registry will always validate
                check characters on submission.

        Returns:
            A validated :class:`EIDRID` instance.

        Raises:
            EIDRIDFormatError: If the string is not a valid EIDR ID, or if
                ``verify_check=True`` and the Content ID check character is
                incorrect.
        """
        if not isinstance(value, str):
            raise EIDRIDFormatError(
                f"EIDR ID must be a string, got {type(value).__name__}",
                value=None,
            )
        stripped = value.strip()
        if not stripped:
            raise EIDRIDFormatError("EIDR ID is empty", value=value)

        match = _PREFIX_PATTERN.match(stripped)
        if match is None:
            raise EIDRIDFormatError(
                f"EIDR ID {value!r} does not match canonical DOI form '10.<subprefix>/<suffix>'",
                value=value,
            )
        subprefix, suffix = match.group(1), match.group(2)

        try:
            category = IDCategory.from_subprefix(subprefix)
        except ValueError as exc:
            raise EIDRIDFormatError(
                f"EIDR ID {value!r} has unknown sub-prefix {subprefix!r}",
                value=value,
            ) from exc

        # Normalize suffix case: upper for hex, preserve case for user IDs.
        normalized_suffix = suffix.upper() if category is not IDCategory.USER else suffix
        cls._validate_suffix(normalized_suffix, category)

        instance = cls.__new__(cls)
        # Bypass __post_init__ so we can control check-char verification.
        object.__setattr__(instance, "prefix", f"10.{subprefix}")
        object.__setattr__(instance, "suffix", normalized_suffix)
        object.__setattr__(instance, "category", category)
        if verify_check and category is IDCategory.CONTENT:
            instance._verify_check_char_or_raise()
        return instance

    @classmethod
    def from_any(cls, value: str) -> EIDRID:
        """Parse an EIDR ID from any recognized representation.

        Tries the following formats, in order:

        1. Canonical DOI form (``10.5240/...``)
        2. Canonical form without hyphens
        3. Filename form (``10-5240-...``)
        4. EIDR-F filename form (``EIDR-F-...``) — Content IDs only
        5. URN form (``urn:eidr:10.5240:...``)
        6. DOI URN form (``urn:doi:10.5240:...``)
        7. DOI proxy URL (``https://doi.org/10.5240/...``) — accepts any
           recognized DOI proxy (``doi.org``, ``dx.doi.org``) and any scheme.
        8. Base64URL of compact binary (exactly 16 characters).

        Args:
            value: The ID string in any supported representation.

        Returns:
            A validated :class:`EIDRID` instance.

        Raises:
            EIDRIDFormatError: If no recognized form matches.
        """
        if not isinstance(value, str):
            raise EIDRIDFormatError(
                f"EIDR ID must be a string, got {type(value).__name__}",
                value=None,
            )
        s = value.strip()
        if not s:
            raise EIDRIDFormatError("EIDR ID is empty", value=value)

        # 1. Canonical form (fast path).
        if s.startswith("10.") and "/" in s:
            return cls.parse(s)

        # 7. DOI proxy URL — strip the proxy prefix and recurse.
        lower = s.lower()
        for proxy in (
            "https://doi.org/",
            "http://doi.org/",
            "https://dx.doi.org/",
            "http://dx.doi.org/",
            "doi.org/",
            "dx.doi.org/",
        ):
            if lower.startswith(proxy):
                # Preserve case of the suffix by slicing the original, not the lowercased copy.
                remainder = s[len(proxy) :]
                # The proxy accepts URN forms too; recurse to handle them.
                return cls.from_any(remainder)

        # 5. URN form: urn:eidr:10.5240:suffix
        if lower.startswith("urn:eidr:"):
            body = s[len("urn:eidr:") :]
            # Expected form: 10.NNNN:<suffix>  (colon, not slash)
            if ":" in body:
                pfx_part, suf_part = body.split(":", 1)
                return cls.parse(f"{pfx_part}/{suf_part}")

        # 6. DOI URN form: urn:doi:10.NNNN:suffix
        if lower.startswith("urn:doi:"):
            body = s[len("urn:doi:") :]
            if ":" in body:
                pfx_part, suf_part = body.split(":", 1)
                return cls.parse(f"{pfx_part}/{suf_part}")

        # 3./4. Filename forms (Content IDs have a -5240- segment).
        if s.upper().startswith("EIDR-F-"):
            # EIDR-F implies 10.5240 prefix per EIDR ID Format v1.51 §4.2.1
            suf = s[len("EIDR-F-") :].upper()
            return cls.parse(f"10.5240/{suf}")

        # 3. Generic filename form: 10-NNNN-<suffix-with-hyphens>
        # (both separators became hyphens). Be lenient on case.
        filename_match = re.match(r"^10-(\d{4})-(.+)$", s, flags=re.IGNORECASE)
        if filename_match:
            subprefix = filename_match.group(1)
            suf = filename_match.group(2)
            return cls.parse(f"10.{subprefix}/{suf}")

        # 2. Canonical with hyphens removed:  10.5240/NNNN...
        # (We don't attempt to recover this without an explicit opt-in — it
        # is syntactically indistinguishable from a malformed canonical
        # when the slash is present but hyphens are not, and we don't want
        # to paper over user errors silently.)

        # 8. Base64URL of compact binary (16 chars, no padding for 96-bit).
        if len(s) == 16 and re.match(r"^[A-Za-z0-9_\-]+$", s):
            try:
                return cls.from_base64url(s)
            except EIDRIDFormatError:
                pass

        raise EIDRIDFormatError(
            f"Could not parse EIDR ID from {value!r} (no recognized form matched)",
            value=value,
        )

    @classmethod
    def from_urn(cls, value: str) -> EIDRID:
        """Parse an EIDR ID from its URN representation.

        Accepts both ``urn:eidr:10.NNNN:suffix`` (RFC 7972) and the
        DOI URN form ``urn:doi:10.NNNN:suffix``.

        Raises:
            EIDRIDFormatError: If ``value`` is not a supported URN.
        """
        lower = value.strip().lower()
        if not (lower.startswith("urn:eidr:") or lower.startswith("urn:doi:")):
            raise EIDRIDFormatError(
                f"Not an EIDR URN: {value!r}. Expected 'urn:eidr:...' or 'urn:doi:...'",
                value=value,
            )
        return cls.from_any(value)

    @classmethod
    def from_base64url(cls, value: str) -> EIDRID:
        """Parse an EIDR ID from its base64url-of-compact-binary representation.

        The compact binary form is always 12 bytes (96 bits); its base64url
        encoding is always exactly 16 characters with no padding.

        For Content IDs, this form is **lossless**: the check character is
        not part of the compact binary representation, but it is
        recomputed on reconstruction (the check character is a deterministic
        function of the suffix, so no information is actually lost).

        Args:
            value: A 16-character base64url string.

        Returns:
            A validated :class:`EIDRID` instance.

        Raises:
            EIDRIDFormatError: If the input is not a valid base64url-96-bit string.
        """
        s = value.strip()
        if len(s) != 16:
            raise EIDRIDFormatError(
                f"Compact-binary base64url must be exactly 16 characters, got {len(s)}",
                value=value,
            )
        # base64url to bytes (12 bytes)
        try:
            raw = base64.urlsafe_b64decode(s + "==")  # pad defensively
        except (ValueError, base64.binascii.Error) as exc:  # type: ignore[attr-defined]
            raise EIDRIDFormatError(f"Invalid base64url input: {value!r}", value=value) from exc
        if len(raw) != 12:
            raise EIDRIDFormatError(
                f"Compact-binary input must decode to 12 bytes, got {len(raw)}",
                value=value,
            )

        # First 16 bits: sub-prefix as integer
        subprefix_int = (raw[0] << 8) | raw[1]
        subprefix = str(subprefix_int)
        try:
            category = IDCategory.from_subprefix(subprefix)
        except ValueError as exc:
            raise EIDRIDFormatError(
                f"Compact-binary sub-prefix {subprefix!r} is not a recognized EIDR sub-prefix",
                value=value,
            ) from exc

        if category is IDCategory.CONTENT:
            # 80 bits of suffix; compute check char deterministically.
            suffix_hex = raw[2:].hex().upper()  # 20 hex digits
            check = compute_check_char(suffix_hex)
            formatted = (
                f"{suffix_hex[0:4]}-{suffix_hex[4:8]}-{suffix_hex[8:12]}-"
                f"{suffix_hex[12:16]}-{suffix_hex[16:20]}-{check}"
            )
            return cls(
                prefix=f"10.{subprefix}",
                suffix=formatted,
                category=category,
            )

        # Party/Service: next 32 bits are the 8-hex-digit suffix; remaining 48
        # bits are zero-padding. See EIDR ID Format v1.51 §3.1.1.
        suffix_bytes = raw[2:6]
        hex_suffix = suffix_bytes.hex().upper()
        formatted = f"{hex_suffix[:4]}-{hex_suffix[4:]}"
        return cls(
            prefix=f"10.{subprefix}",
            suffix=formatted,
            category=category,
        )

    # ─── output / conversion ──────────────────────────────────────────────

    def canonical(self) -> str:
        """Return the canonical DOI form: ``10.<subprefix>/<suffix>``."""
        return f"{self.prefix}/{self.suffix}"

    def canonical_no_hyphens(self) -> str:
        """Return the canonical form with hyphens removed from the suffix."""
        return f"{self.prefix}/{self.suffix.replace('-', '')}"

    def to_filename(self) -> str:
        """Return the filename form: ``10-NNNN-...`` (slash and dot replaced with hyphens).

        Per EIDR ID Format v1.51 §3.7.1.
        """
        return self.canonical().replace("/", "-").replace(".", "-")

    def to_urn(self) -> str:
        """Return the RFC 7972 URN form: ``urn:eidr:10.NNNN:suffix``.

        Officially defined only for Content IDs, but syntactically valid for
        any EIDR ID.
        """
        return f"urn:eidr:{self.prefix}:{self.suffix}"

    def to_doi_urn(self) -> str:
        """Return the DOI URN form: ``urn:doi:10.NNNN:suffix``."""
        return f"urn:doi:{self.prefix}:{self.suffix}"

    def to_proxy_url(self, scheme: str = "https") -> str:
        """Return the DOI proxy URL: ``https://doi.org/10.NNNN/suffix``.

        Args:
            scheme: ``"https"`` (preferred per EIDR ID Format v1.51) or ``"http"``.
        """
        if scheme not in ("https", "http"):
            raise ValueError(f"scheme must be 'https' or 'http', got {scheme!r}")
        return f"{scheme}://doi.org/{self.canonical()}"

    def to_compact_binary(self) -> bytes:
        """Return the 12-byte compact-binary representation.

        For Content IDs, the output is the 16-bit sub-prefix followed by
        the 80-bit suffix (hex digits of the 5 quads, check character omitted).

        For Party/Service/User IDs, the output is the 16-bit sub-prefix,
        the 32-bit suffix (8 hex digits), and 48 bits of zero padding.

        Returns:
            A 12-byte ``bytes`` object.

        Raises:
            NotImplementedError: For User IDs whose suffix is not a
                hex-quad pattern (these cannot be represented in compact binary).
        """
        subprefix_int = int(self.category.value)
        prefix_bytes = subprefix_int.to_bytes(2, byteorder="big")

        hex_only = self.suffix.replace("-", "")

        if self.category is IDCategory.CONTENT:
            # 20 hex digits = 80 bits = 10 bytes; drop check char (last char).
            suffix_hex = hex_only[:-1]
            if len(suffix_hex) != 20:
                raise EIDRIDFormatError(
                    f"Content ID suffix {self.suffix!r} does not have 20 hex digits "
                    f"before the check character",
                    value=self.canonical(),
                )
            return prefix_bytes + bytes.fromhex(suffix_hex)

        if self.category in (IDCategory.PARTY, IDCategory.SERVICE):
            # 8 hex digits = 32 bits = 4 bytes; pad to 10 bytes with zeros.
            if len(hex_only) != 8:
                raise EIDRIDFormatError(
                    f"{self.category.name} ID suffix {self.suffix!r} does not have 8 hex digits",
                    value=self.canonical(),
                )
            return prefix_bytes + bytes.fromhex(hex_only) + bytes(6)

        # User
        raise NotImplementedError(
            "Compact-binary form is not defined for User IDs with non-hex suffixes."
        )

    def to_base64url(self) -> str:
        """Return the base64url encoding of the compact-binary form.

        Always exactly 16 characters (96 bits input, no padding emitted).
        """
        raw = self.to_compact_binary()
        return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")

    # ─── dunder methods ───────────────────────────────────────────────────

    def __str__(self) -> str:
        return self.canonical()

    def __eq__(self, other: object) -> bool:
        # Case-insensitive equality per EIDR ID Format v1.51 §2.2.
        if isinstance(other, EIDRID):
            return (
                self.prefix.lower() == other.prefix.lower()
                and self.suffix.lower() == other.suffix.lower()
            )
        if isinstance(other, str):
            try:
                return self == EIDRID.parse(other)
            except EIDRIDFormatError:
                return False
        return NotImplemented

    def __hash__(self) -> int:
        return hash((self.prefix.lower(), self.suffix.lower()))

    # ─── category convenience ─────────────────────────────────────────────

    @property
    def is_content(self) -> bool:
        """True if this is a Content ID (sub-prefix 5240)."""
        return self.category is IDCategory.CONTENT

    @property
    def is_party(self) -> bool:
        """True if this is a Party ID (sub-prefix 5237)."""
        return self.category is IDCategory.PARTY

    @property
    def is_service(self) -> bool:
        """True if this is a Service ID (sub-prefix 5239)."""
        return self.category is IDCategory.SERVICE

    @property
    def is_user(self) -> bool:
        """True if this is a User ID (sub-prefix 5238)."""
        return self.category is IDCategory.USER

    # ─── internal validation ──────────────────────────────────────────────

    @staticmethod
    def _validate_suffix(suffix: str, category: IDCategory) -> None:
        """Validate that ``suffix`` conforms to the shape required by ``category``.

        Raises :class:`EIDRIDFormatError` on any mismatch.
        """
        if category is IDCategory.CONTENT:
            if not _CONTENT_SUFFIX_PATTERN.match(suffix):
                raise EIDRIDFormatError(
                    f"Content ID suffix {suffix!r} does not match "
                    f"'XXXX-XXXX-XXXX-XXXX-XXXX-C' pattern",
                    value=f"10.5240/{suffix}",
                )
        elif category in (IDCategory.PARTY, IDCategory.SERVICE):
            if not _SHORT_SUFFIX_PATTERN.match(suffix):
                raise EIDRIDFormatError(
                    f"{category.name} ID suffix {suffix!r} does not match 'XXXX-XXXX' pattern",
                    value=f"10.{category.value}/{suffix}",
                )
        elif category is IDCategory.USER:
            # User IDs may be either hex-quad (like Party/Service) or a
            # more general identifier per the EIDR character-set rules.
            if _SHORT_SUFFIX_PATTERN.match(suffix):
                return
            if not _USER_SUFFIX_PATTERN.match(suffix):
                raise EIDRIDFormatError(
                    f"User ID suffix {suffix!r} contains characters outside "
                    f"the EIDR ID character set (A-Za-z0-9._-)",
                    value=f"10.5238/{suffix}",
                )

    # ─── check-character support ──────────────────────────────────────────

    def verify_check_char(self) -> bool:
        """Return True if this Content ID's check character is valid.

        For Party, Service, and User IDs (which have no check character),
        always returns ``True``.

        Example:
            >>> EIDRID.parse("10.5240/7791-8534-2C23-9030-8610-5").verify_check_char()
            True
            >>> EIDRID.parse(
            ...     "10.5240/7791-8534-2C23-9030-8610-X",
            ...     verify_check=False,
            ... ).verify_check_char()
            False
        """
        if self.category is not IDCategory.CONTENT:
            return True
        hex_only = self.suffix.replace("-", "")
        return _verify_check_char(hex_only[:-1], hex_only[-1])

    def _verify_check_char_or_raise(self) -> None:
        """Validate the Content ID check character, raising on mismatch.

        No-op for non-Content categories. Internal helper used by
        ``__post_init__`` and :meth:`parse` (when ``verify_check=True``).
        """
        if self.category is not IDCategory.CONTENT:
            return
        hex_only = self.suffix.replace("-", "")
        suffix_hex = hex_only[:-1]
        actual_check = hex_only[-1]
        expected_check = compute_check_char(suffix_hex)
        if expected_check != actual_check:
            raise EIDRIDFormatError(
                f"Content ID check character is invalid: {self.canonical()!r} "
                f"has check {actual_check!r} but should be {expected_check!r}",
                value=self.canonical(),
            )
