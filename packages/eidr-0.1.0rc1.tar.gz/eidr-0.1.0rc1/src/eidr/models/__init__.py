"""Public model layer for the EIDR SDK.

Currently exported:

* :class:`~eidr.models.ids.EIDRID` and :class:`~eidr.models.ids.IDCategory`
  — the value type for EIDR identifiers.
* :class:`~eidr.models.content.ContentRecord` — typed wrapper for
  Content-ID records (Movie, Series, Episode, Edit, Manifestation, etc.).
* CreationType-specific block view classes:
  :class:`~eidr.models.content.SeriesInfo`,
  :class:`~eidr.models.content.SeasonInfo`,
  :class:`~eidr.models.content.EpisodeInfo`,
  :class:`~eidr.models.content.EditInfo`,
  :class:`~eidr.models.content.ClipInfo`,
  :class:`~eidr.models.content.ManifestationInfo`,
  :class:`~eidr.models.content.CompilationInfo`,
  :class:`~eidr.models.content.CompositeInfo`.
* Value objects: :class:`~eidr.models._value_objects.AlternateID`,
  :class:`~eidr.models._value_objects.AlternateResourceName`,
  :class:`~eidr.models._value_objects.AssociatedOrg`,
  :class:`~eidr.models._value_objects.Credit`,
  :class:`~eidr.models._value_objects.Parent`.
* Enums: :class:`~eidr.models.enums.CreationType`,
  :class:`~eidr.models.enums.ReferentType`,
  :class:`~eidr.models.enums.StructuralType`,
  :class:`~eidr.models.enums.Mode`,
  :class:`~eidr.models.enums.Status`.

Also exposed:

* :class:`~eidr.models.party.PartyRecord` and
  :class:`~eidr.models.service.ServiceRecord` — typed wrappers for
  Party and Service (Video Service) records.
* :func:`~eidr.models._normalize.normalize_whitespace` and
  :func:`~eidr.models._empty_tags.strip_empty_tags` — pre-submission
  cleanup helpers.
* The :class:`~eidr.models.content.ContentRecord.validate` /
  :meth:`~eidr.models.content.ContentRecord.validate_strict`
  pipeline.
* The auto-generated typed Digital sub-model at
  :mod:`eidr.models.digital`, accessed via
  :meth:`ManifestationInfo.digital_typed` and
  :meth:`ManifestationInfo.set_digital`. Requires the
  ``[digital]`` install extra.
"""

from __future__ import annotations

from eidr.models._empty_tags import find_empty_tags, strip_empty_tags
from eidr.models._normalize import normalize_whitespace
from eidr.models._parse import ParsedRecord, parse, parse_codec_dict
from eidr.models._validation import ValidationError, ValidationReport
from eidr.models._value_objects import (
    AliasContinuation,
    AlternateID,
    AlternateResourceName,
    AssociatedOrg,
    ContactInfo,
    Credit,
    OrgName,
    Parent,
    Phone,
)
from eidr.models.content import (
    ClipInfo,
    CompilationInfo,
    CompositeInfo,
    ContentRecord,
    EditInfo,
    EpisodeInfo,
    ManifestationInfo,
    SeasonInfo,
    SeriesInfo,
)
from eidr.models.enums import (
    CreationType,
    Mode,
    ReferentType,
    Status,
    StructuralType,
)
from eidr.models.ids import EIDRID, IDCategory
from eidr.models.party import PartyRecord
from eidr.models.service import ServiceRecord
from eidr.models.virtual import VirtualFields

__all__ = [  # noqa: RUF022 — grouped by theme, not alphabetically, for readability
    # IDs
    "EIDRID",
    "IDCategory",
    # Records
    "ContentRecord",
    "PartyRecord",
    "ServiceRecord",
    "VirtualFields",
    # Dispatcher
    "parse",
    "parse_codec_dict",
    "ParsedRecord",
    # CreationType-specific block views
    "SeriesInfo",
    "SeasonInfo",
    "EpisodeInfo",
    "EditInfo",
    "ClipInfo",
    "ManifestationInfo",
    "CompilationInfo",
    "CompositeInfo",
    # Value objects
    "AliasContinuation",
    "AlternateID",
    "AlternateResourceName",
    "AssociatedOrg",
    "ContactInfo",
    "Credit",
    "OrgName",
    "Parent",
    "Phone",
    # Enums
    "CreationType",
    "ReferentType",
    "StructuralType",
    "Mode",
    "Status",
    # Validation
    "ValidationError",
    "ValidationReport",
    # Empty-tag and whitespace utilities
    "find_empty_tags",
    "normalize_whitespace",
    "strip_empty_tags",
]
