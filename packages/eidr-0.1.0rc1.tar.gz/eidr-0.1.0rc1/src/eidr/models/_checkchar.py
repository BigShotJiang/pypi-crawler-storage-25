"""ISO 7064 Mod 37,36 check-character computation for EIDR Content IDs.

Implements the hybrid recursive procedure defined by ISO 7064 for
alphanumeric check characters over a 20-hex-digit EIDR Content ID suffix.
The same algorithm is used by ISAN (over 16 hex digits), which published
a concrete worked example; see the `ISAN Check Characters Calculation`
document (v2.0, February 2007) for the step-by-step procedure.

EIDR Content ID applies this algorithm to the 20 hex digits of the suffix
(five groups of four, hyphens removed) to produce the 21st check character.
The prefix and the ``/`` separator are **not** included in the computation.

Algorithm (from the ISAN doc, unchanged for EIDR):

1. Start with a carry of 36.
2. For each hex digit (value 0–15), left to right:
   a. Add the digit value to the carry → Intermediate Sum (IS).
   b. If IS ≥ 36, subtract 36 → Adjusted Intermediate Sum (AIS).
   c. If AIS = 0 after the subtraction, use 36.
   d. Multiply AIS by 2 → Product.
   e. If Product ≥ 37, subtract 37 → Adjusted Product (AP).
   f. Carry AP forward.
3. After the final digit:
   - If AP = 1, the check value is 0.
   - Otherwise, the check value is (37 − AP).
4. Map the check value 0–35 to the character alphabet ``0-9A-Z``.

The algorithm has been verified against every worked example in the
EIDR ID Format specification (v1.51) and against a 229-ID sample of real
records pulled from the EIDR Sandbox 2 registry.
"""

from __future__ import annotations

from typing import Final

__all__ = [
    "CHECK_CHAR_ALPHABET",
    "compute_check_char",
    "verify_check_char",
]


#: The 36-character alphabet used for check-character values 0–35.
CHECK_CHAR_ALPHABET: Final = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def _hex_value(ch: str) -> int:
    """Return the integer value (0–15) of a single hex digit.

    Accepts upper or lower case. Raises :class:`ValueError` for non-hex input.
    """
    return int(ch, 16)


def compute_check_char(suffix_hex: str) -> str:
    """Compute the Mod 37,36 check character for an EIDR Content ID suffix.

    Args:
        suffix_hex: The 20 hex digits of the suffix, without hyphens and
            without a check character. Case-insensitive.

    Returns:
        A single character from :data:`CHECK_CHAR_ALPHABET`.

    Raises:
        ValueError: If ``suffix_hex`` is not exactly 20 hex digits.

    Example:
        >>> compute_check_char("779185342C2390308610")
        '5'
        >>> compute_check_char("F85AE100B0685B8FB1C8")
        'T'
    """
    if len(suffix_hex) != 20:
        raise ValueError(
            f"EIDR Content ID suffix must be exactly 20 hex digits, got {len(suffix_hex)}"
        )
    # Validate all characters are hex up-front so errors are clean.
    try:
        int(suffix_hex, 16)
    except ValueError as exc:
        raise ValueError(f"Suffix contains non-hex characters: {suffix_hex!r}") from exc

    carry = 36  # Initial seed per ISO 7064 hybrid Mod 37,36.
    for ch in suffix_hex:
        digit = _hex_value(ch)
        # Step 1: intermediate sum
        intermediate = carry + digit
        # Step 2: adjust; if result is 0, use 36
        ais = intermediate - 36 if intermediate >= 36 else intermediate
        if ais == 0:
            ais = 36
        # Step 3/4: multiply by 2, adjust product
        product = ais * 2
        carry = product - 37 if product >= 37 else product

    # Final: if carry is 1, check value is 0; else 37 - carry.
    check_value = 0 if carry == 1 else 37 - carry
    return CHECK_CHAR_ALPHABET[check_value]


def verify_check_char(suffix_hex: str, check_char: str) -> bool:
    """Verify that ``check_char`` is the correct check character for ``suffix_hex``.

    Comparison is case-insensitive.

    Args:
        suffix_hex: The 20 hex digits of the suffix.
        check_char: The 1-character check char to validate.

    Returns:
        ``True`` if the check char is correct, ``False`` otherwise.

    Example:
        >>> verify_check_char("779185342C2390308610", "5")
        True
        >>> verify_check_char("779185342C2390308610", "X")
        False
    """
    try:
        expected = compute_check_char(suffix_hex)
    except ValueError:
        return False
    return expected.upper() == check_char.upper()
