"""Exception hierarchy for the EIDR SDK.

All exceptions raised by this SDK inherit from :class:`EIDRError`, which
allows callers to catch any SDK-originated failure with a single ``except``.

The hierarchy is organized by failure domain:

.. code-block:: text

    EIDRError                             # root of all SDK errors
    |
    +-- EIDRTransportError                # network/HTTP transport-level
    |   +-- EIDRTimeoutError              # read/connect/total timeout
    |   +-- EIDRHTTPStatusError           # non-success HTTP status
    |
    +-- EIDRProtocolError                 # registry returned non-zero Status.Code
    |   +-- EIDRAuthenticationError       # bad credentials
    |   +-- EIDRAuthorizationError        # valid creds, forbidden operation
    |   +-- EIDRNotFoundError             # object not in registry
    |   +-- EIDRValidationError           # registry-side schema/rule violation
    |   +-- EIDRDuplicateError            # dedup conflict on register/modify
    |   +-- EIDRUncertainWriteError       # 5xx on a write; write status unknown
    |   +-- EIDRRegistryError             # catch-all with code/type/details
    |
    +-- EIDRClientError                   # caller / local misuse
    |   +-- EIDRIDFormatError             # malformed EIDR ID
    |   +-- EIDRReadOnlyRegistryError     # write attempted on a read-only registry
    |   +-- EIDRSDKPolicyError            # SDK refused per a client-side policy gate
    |   +-- EIDRCredentialsNotFoundError  # no credentials could be located
    |   +-- EIDRCredentialAmbiguityError  # multiple credential sources present
    |
    +-- EIDRCodecError                    # XML/JSON serialization failure

The SDK also defines :class:`EIDRAnonymousWarning`, a :class:`UserWarning`
subclass emitted once per anonymous client when Alt-ID-bearing responses
are requested.

Design notes
------------
* ``EIDRTransportError`` means "we couldn't reach the registry or got a bad
  HTTP response shape." ``EIDRProtocolError`` means "the registry responded
  normally, but the response carries a non-zero ``Status/Code``."
* ``EIDRUncertainWriteError`` is raised when a write operation (register,
  modify, delete, add/remove/replace relationship, promote, alias) receives
  a transport-level failure *after* the request was sent. The caller cannot
  assume the write did or did not take effect and should re-check state
  before retrying. This exists because the SDK will **not** automatically
  retry writes.
"""

from __future__ import annotations

from typing import Any

# ─────────────────────────────────────────────────────────────────────────────
# Root
# ─────────────────────────────────────────────────────────────────────────────


class EIDRError(Exception):
    """Base class for all exceptions raised by the EIDR SDK.

    Catch this to handle any SDK-originated failure uniformly. Most callers,
    however, should catch the more specific subclasses that correspond to
    their error-handling strategy (e.g., retry-safe errors vs fatal ones).
    """


# ─────────────────────────────────────────────────────────────────────────────
# Transport layer — HTTP / network failures
# ─────────────────────────────────────────────────────────────────────────────


class EIDRTransportError(EIDRError):
    """A network- or HTTP-level failure occurred when talking to the registry.

    Subclassed for more specific failure modes. Generic transport failures
    (connection reset, DNS failure, TLS handshake) raise this class directly.

    Attributes:
        url: The URL being requested when the failure occurred, if known.
    """

    def __init__(self, message: str, *, url: str | None = None) -> None:
        super().__init__(message)
        self.url = url


class EIDRTimeoutError(EIDRTransportError):
    """A timeout occurred while communicating with the registry.

    Distinguished from generic transport errors because timeouts on
    idempotent reads are generally safe to retry, while timeouts on writes
    leave the server state in an unknown condition
    (see :class:`EIDRUncertainWriteError`).
    """


class EIDRHTTPStatusError(EIDRTransportError):
    """The registry returned an HTTP status code outside the success range.

    Most registry errors arrive as HTTP 200 with a non-zero
    ``<Status><Code>`` element in the XML body — those are raised as
    :class:`EIDRProtocolError` subclasses. This exception is raised when
    the HTTP layer itself fails (4xx/5xx without a parseable EIDR response).

    Attributes:
        status_code: The HTTP status code returned.
        body: The raw response body (may be empty or non-XML).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        url: str | None = None,
        body: str | bytes | None = None,
    ) -> None:
        super().__init__(message, url=url)
        self.status_code = status_code
        self.body = body


# ─────────────────────────────────────────────────────────────────────────────
# Protocol layer — registry responded but with a non-zero status
# ─────────────────────────────────────────────────────────────────────────────


class EIDRProtocolError(EIDRError):
    """The registry responded successfully at the HTTP layer but reported an error.

    Every instance carries the ``Status/Code``, ``Status/Type``, and
    ``Status/Details`` fields from the EIDR response envelope, plus the
    raw response text for diagnostic logging.

    Attributes:
        code: The ``<Status><Code>`` value, as an integer.
        type: The ``<Status><Type>`` value, when present.
        details: The ``<Status><Details>`` value, when present.
        response: The raw response text. Retained for debugging.
    """

    def __init__(
        self,
        message: str,
        *,
        code: int | str | None = None,
        type: str | None = None,
        details: str | None = None,
        response: str | None = None,
    ) -> None:
        super().__init__(message)
        # Normalize code to int when possible; keep original string otherwise
        if isinstance(code, str):
            try:
                self.code: int | str | None = int(code)
            except ValueError:
                self.code = code
        else:
            self.code = code
        self.type = type
        self.details = details
        self.response = response

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.code is not None:
            parts.append(f"code={self.code}")
        if self.type:
            parts.append(f"type={self.type}")
        if self.details:
            parts.append(f"details={self.details!r}")
        return " | ".join(parts)


class EIDRAuthenticationError(EIDRProtocolError):
    """The registry rejected the supplied credentials."""


class EIDRAuthorizationError(EIDRProtocolError):
    """The caller is authenticated but not permitted to perform the operation."""


class EIDRNotFoundError(EIDRProtocolError):
    """The requested object does not exist in the registry."""


class EIDRValidationError(EIDRProtocolError):
    """A record failed validation.

    Raised in two contexts:

    * **Pre-submission** — when a caller runs
      :meth:`ContentRecord.validate_strict` (or Party/Service variants)
      and the local validator finds problems. The exception's
      :attr:`errors` attribute is the list of
      :class:`~eidr.models.ValidationError` instances produced by the
      validator.
    * **Post-registry** — when the registry itself rejects a
      submission. In this case :attr:`errors` may be empty (the
      registry's rejection may arrive as a single textual reason).

    Attributes:
        errors: List of validation-error records, when produced by the
            local validator. Empty for registry-originated rejections.
    """

    errors: list[object]
    """Detailed error list, populated by the local validator.

    Typed as ``object`` here to avoid a circular dependency with the
    validation module; callers should treat it as a list of
    :class:`eidr.models.ValidationError` instances.
    """

    def __init__(
        self,
        message: str = "",
        *,
        code: int | str | None = None,
        type: str | None = None,
        details: str | None = None,
        response: str | None = None,
    ) -> None:
        # Full EIDRProtocolError passthrough so registry-originated
        # validation errors carry the same structured context as other
        # EIDRProtocolError subclasses. Locally-produced validation
        # errors (from the pre-submission validator) use only the
        # message argument.
        super().__init__(message, code=code, type=type, details=details, response=response)
        self.errors = []


class EIDRDuplicateError(EIDRProtocolError):
    """Deduplication conflict — the object would duplicate an existing record."""


class EIDRUncertainWriteError(EIDRProtocolError):
    """A write operation's outcome is unknown.

    Raised when a write (register, modify, delete, add/remove/replace
    relationship, promote, alias) receives a 5xx response or times
    out *after* the request was transmitted. The caller must not
    assume the write did or did not take effect; re-check state
    (e.g., via :meth:`Client.resolve`) before retrying.

    The SDK does **not** automatically retry writes, even for
    operations that are idempotent against the target record
    (modify, delete). The conservative default is justified because
    retries can return distinct outcomes on the second attempt:

    * A ``modify`` that succeeded on attempt 1 will, on retry, get
      back a duplicate-metadata error (since the new metadata is
      now the current state).
    * A ``delete`` that succeeded on attempt 1 will, on retry, get
      back a not-found error (the record is now an alias to the
      tombstone).
    * A ``register`` that succeeded on attempt 1 will, on retry,
      typically generate a duplicate registration that requires
      manual deduplication.

    Auto-retry would silently turn these success-then-retry cases
    into errors. The recommended reconciliation pattern is to
    resolve the target record (or query for the intended new state),
    compare against what the caller intended, and decide:

    .. code-block:: python

        try:
            client.modify(record, immediate=True)
        except EIDRUncertainWriteError:
            # The modify may or may not have applied. Check.
            current = client.resolve(record.id)
            if current_matches_intended_state(current, record):
                # Already applied — treat as success.
                pass
            else:
                # Not applied (or partially) — retry the modify.
                client.modify(record, immediate=True)

    For delete, the equivalent check is ``isinstance(resolve(...),
    AliasRecord)`` — a successful delete leaves an alias to the
    tombstone.

    For register, the only reliable reconciliation is a query for
    distinguishing identifiers (AlternateIDs the caller assigned,
    a unique ResourceName/ReleaseDate combination) to detect a
    record that succeeded on attempt 1.
    """


class EIDRRegistryError(EIDRProtocolError):
    """Catch-all for registry-reported errors that don't map to a more specific class.

    Inspect ``.code`` and ``.type`` to determine the specific condition.
    """


# ─────────────────────────────────────────────────────────────────────────────
# Client layer — local caller mistakes
# ─────────────────────────────────────────────────────────────────────────────


class EIDRClientError(EIDRError):
    """The SDK caller provided invalid input or made a usage error.

    Raised before any network call is attempted, when possible.
    """


class EIDRIDFormatError(EIDRClientError):
    """An EIDR ID failed syntactic validation.

    Raised by :class:`~eidr.models.ids.EIDRID` when construction fails.
    See the EIDR ID Format specification (v1.51) for canonical syntax rules.

    Attributes:
        value: The string that failed validation.
    """

    def __init__(self, message: str, *, value: str | None = None) -> None:
        super().__init__(message)
        self.value = value


class EIDRReadOnlyRegistryError(EIDRClientError):
    """A write operation was attempted against a read-only registry.

    Some EIDR endpoints (e.g., ``resolve.eidr.org``) serve read traffic only.
    The SDK checks registry capabilities before dispatching writes and
    raises this error locally, without round-tripping to the server.

    Attributes:
        registry_name: Name of the offending registry (e.g., ``"RESOLVE"``).
        operation: The write operation that was attempted.
    """

    def __init__(
        self,
        message: str,
        *,
        registry_name: str | None = None,
        operation: str | None = None,
    ) -> None:
        super().__init__(message)
        self.registry_name = registry_name
        self.operation = operation


class EIDRSDKPolicyError(EIDRClientError):
    """The SDK refused an operation based on a client-side policy gate.

    Distinct from :class:`EIDRAuthorizationError`, which is the
    server's "I refuse" — this one is the SDK's "I won't even ask".
    Raised at method entry, before any wire work, when the
    configured caller's identity (or other client-side context) does
    not satisfy a policy the SDK enforces locally.

    The motivating case is the Party-write Superparty gate: the
    EIDR registry hard-codes a single Party (the "Superparty") as
    the only one allowed to perform Party administrative
    operations (create / modify / delete / alias / activate /
    deactivate / change-password). There is no Role mechanism for
    Party administration the way there is for content writes, so
    the registry cannot delegate this authority. A general-purpose
    SDK caller has no plausible reason to invoke these operations
    and would receive a server-side ``EIDRAuthorizationError`` if
    they did. The SDK refuses earlier, with a clearer message and
    a typed exception that distinguishes "configuration mismatch"
    from "registry rejected the request".

    Other client-side policies may use this same exception type in
    the future. The ``policy`` attribute identifies which policy
    fired so callers can branch on it without parsing messages.

    Attributes:
        policy: A short identifier for the policy that refused the
            operation (e.g., ``"superparty_required"``).
        operation: The SDK method name that was refused
            (e.g., ``"create_party"``).
        configured_value: The configured value that didn't satisfy
            the policy (e.g., the caller's Party ID), if relevant.
        required_value: The value the policy requires, if relevant.
    """

    def __init__(
        self,
        message: str,
        *,
        policy: str,
        operation: str | None = None,
        configured_value: str | None = None,
        required_value: str | None = None,
    ) -> None:
        super().__init__(message)
        self.policy = policy
        self.operation = operation
        self.configured_value = configured_value
        self.required_value = required_value


class EIDRCredentialsNotFoundError(EIDRClientError):
    """No credentials could be located from any configured source.

    Raised by :meth:`eidr.Credentials.load` when the default precedence
    chain finds nothing usable. Non-Resolve operations require credentials;
    Resolve can run anonymously (with no Alt IDs).
    """


class EIDRCredentialAmbiguityError(EIDRClientError):
    """Multiple credential sources were found; resolution is ambiguous.

    Set ``EIDR_CREDENTIALS_SOURCE`` to pick one, or call an explicit
    loader (``Credentials.from_json``, ``Credentials.from_aws_secret``, etc.)
    to make the intent unambiguous.

    Attributes:
        sources: The credential source names that were found.
    """

    def __init__(self, message: str, *, sources: list[str] | None = None) -> None:
        super().__init__(message)
        self.sources: list[str] = sources or []


# ─────────────────────────────────────────────────────────────────────────────
# Codec layer — XML/JSON (de)serialization
# ─────────────────────────────────────────────────────────────────────────────


class EIDRCodecError(EIDRError):
    """XML or JSON (de)serialization failed.

    Subclasses may be added in the future for specific codec failure modes
    (e.g., XSD validation failures) without breaking this public type.

    Attributes:
        format: Either ``"xml"`` or ``"json"``.
        original: The wrapped underlying exception, if any.
    """

    def __init__(
        self,
        message: str,
        *,
        format: str | None = None,
        original: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.format = format
        self.original: BaseException | None = original


# ─────────────────────────────────────────────────────────────────────────────
# Warnings (not exceptions — emitted via warnings.warn)
# ─────────────────────────────────────────────────────────────────────────────


class EIDRAnonymousWarning(UserWarning):
    """Warning emitted when an anonymous client performs a resolve operation.

    Anonymous resolves succeed but the registry does not return Alt IDs.
    Emitted once per :class:`eidr.Client` instance to avoid noise.
    """


def _status_to_exception(code: int | str | None, **kwargs: Any) -> EIDRProtocolError:
    """Map an EIDR Status/Code value to the appropriate exception subclass.

    Internal helper used by the transport layer to raise the most specific
    exception for a registry-reported error.

    The precise code-to-class mapping is driven by the EIDR REST API
    Reference's Status.Type vocabulary; codes are grouped by class of
    failure. This mapping is intentionally coarse at the SDK level —
    callers who need byte-perfect status codes can always inspect
    ``.code`` and ``.type`` on the raised exception.

    Args:
        code: The ``<Status><Code>`` integer from the registry response.
        **kwargs: Passed through to the chosen exception's constructor.

    Returns:
        A constructed exception instance (not yet raised). Callers raise.
    """
    # Coerce to int when possible for range-based dispatch below.
    try:
        code_int = int(code) if code is not None else None
    except (TypeError, ValueError):
        code_int = None

    status_type = kwargs.get("type", "") or ""
    type_lower = status_type.lower()

    # Type-name heuristics take precedence over code ranges; the registry
    # uses descriptive Type strings. The keyword sets cover the vocabulary
    # observed in EIDR REST API Reference Tables 5 and 6 — "authentication
    # error", "authorization error", "bad id error", "validation error",
    # "syntax error", "duplicate", etc.
    if "authentic" in type_lower:
        cls: type[EIDRProtocolError] = EIDRAuthenticationError
    elif "authoriz" in type_lower or "forbid" in type_lower or "permission" in type_lower:
        cls = EIDRAuthorizationError
    elif (
        "notfound" in type_lower
        or "not_found" in type_lower
        or "not found" in type_lower
        or "bad id" in type_lower  # REST API Reference Table 5, code 8
        or "badid" in type_lower
    ):
        cls = EIDRNotFoundError
    elif "duplicate" in type_lower or "dedup" in type_lower:
        cls = EIDRDuplicateError
    elif (
        "valid" in type_lower
        or "schema" in type_lower
        or "syntax" in type_lower  # REST API Reference Table 5, code 9
        or "malformed" in type_lower
        or (code_int is not None and 400 <= code_int < 500)
    ):
        cls = EIDRValidationError
    else:
        cls = EIDRRegistryError

    message = kwargs.pop("message", None) or f"Registry returned error (code={code})"
    return cls(message, code=code, **kwargs)
