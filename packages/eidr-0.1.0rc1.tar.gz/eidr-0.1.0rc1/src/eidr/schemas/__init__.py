"""EIDR XML schema bundling and resolution.

The SDK ships a snapshot of the EIDR XSD set under
:mod:`eidr.schemas.bundled` (the ``bundled/`` data subdirectory).
The :class:`SchemaSource` abstraction lets callers — and SDK
internals — choose between this offline snapshot and the live
schema published at https://www.eidr.org/schema/.

Defaults and rationale
----------------------

* The SDK's own code that needs to consult schema (e.g., XSD
  validation in M9+) defaults to :class:`BundledSchemaSource`. The
  bundled XSDs are the version the SDK was built against; they
  match the generated typed models exactly. Using bundled schema
  by default means an SDK release behaves identically across
  environments regardless of what's currently published online.

* :class:`RemoteSchemaSource` exists for callers who want to verify
  against the latest published schema. Typical use: in-house tools
  that follow the current EIDR XSD even when it has changed since
  the SDK was built. Network access required at use time.

* Code generation (the M8 ``tools/generate_digital.py`` script)
  uses :class:`BundledSchemaSource` by default. A future SDK
  release rebuilds the generated models from a fresh checkout
  of the schema, runs the test suite, and ships the regenerated
  code as part of the release artifact — end users never run the
  generator at install time.

The two implementations share a small interface
(:meth:`SchemaSource.read`, :meth:`SchemaSource.list`) so any
callers (current or future) can be parameterized on the source
without caring which kind they got.
"""

from __future__ import annotations

from eidr.schemas._manifest import (
    MANIFEST_FILENAME,
    MANIFEST_FORMAT_VERSION,
    compute_manifest,
    load_manifest,
    manifest_sha256,
)
from eidr.schemas._source import (
    BundledSchemaSource,
    RemoteSchemaSource,
    SchemaSource,
    default_schema_source,
)

__all__ = [
    "MANIFEST_FILENAME",
    "MANIFEST_FORMAT_VERSION",
    "BundledSchemaSource",
    "RemoteSchemaSource",
    "SchemaSource",
    "compute_manifest",
    "default_schema_source",
    "load_manifest",
    "manifest_sha256",
]
