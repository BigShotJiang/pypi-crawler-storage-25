"""Implementation of :class:`SchemaSource` and its two concrete forms.

Why a Protocol rather than ABC: the methods are simple
"return bytes for this filename" and "list available filenames" —
no shared machinery worth inheriting. A Protocol makes it trivial
for tests to substitute fake sources (e.g., a dict-backed source
that holds canned XSD fragments) without inheriting from anything
in the SDK.

Why default to bundled: see the module docstring on
:mod:`eidr.schemas`. Repeating here in the module that actually
implements the logic so a contributor reading the impl gets the
rationale without a cross-module hop:

1. **Determinism.** A given SDK version was built against a
   specific XSD snapshot. Generated typed models, validators,
   and integration tests all reflect that snapshot. Defaulting
   to bundled means an SDK release behaves identically regardless
   of what's currently published online.
2. **Offline-friendliness.** Codec-only workflows have no network
   dependency today and shouldn't acquire one accidentally. A
   user running the SDK behind a corporate proxy or in an
   air-gapped CI environment shouldn't have to configure schema
   access just to run unit tests.
3. **Network is opt-in.** Callers who explicitly want the live
   schema (e.g., to verify against post-release XSD updates)
   construct :class:`RemoteSchemaSource` themselves.
"""

from __future__ import annotations

import importlib.resources as resources
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from collections.abc import Iterable


_BUNDLED_PACKAGE = "eidr.schemas.bundled"

# The published location for EIDR's XSD snapshots. Each filename
# at this base resolves to a downloadable XSD; the bundled
# snapshot mirrors this directory structure so a remote-source
# fetch and a bundled-source read return identical bytes when
# the SDK and registry are in sync.
DEFAULT_REMOTE_BASE = "https://www.eidr.org/schema/"


@runtime_checkable
class SchemaSource(Protocol):
    """Reads XSD content by filename.

    Concrete implementations: :class:`BundledSchemaSource` reads
    from the SDK's in-package snapshot, :class:`RemoteSchemaSource`
    fetches over HTTPS. Tests can supply ad-hoc mock sources by
    implementing this protocol.
    """

    def read(self, name: str) -> bytes:
        """Return the bytes of the named schema file.

        Args:
            name: Bare filename, e.g., ``"md-v2_8.xsd"``. No path
                separators; subdirectory layouts are an
                implementation detail of the source.

        Returns:
            The XSD content as bytes (UTF-8-encoded, but treat as
            opaque bytes for fidelity).

        Raises:
            FileNotFoundError: If the named file is not available
                from this source.
            OSError: For transport errors when fetching remotely
                (subclass-specific — :class:`RemoteSchemaSource`
                may raise more specific :class:`httpx` errors).
        """

    def list(self) -> Iterable[str]:
        """Return the names of all schema files this source can supply.

        For :class:`BundledSchemaSource` this is a fixed snapshot;
        for :class:`RemoteSchemaSource` this returns a curated
        manifest of EIDR-published files (the remote endpoint
        does not expose a directory listing).
        """


class BundledSchemaSource:
    """Read XSD content from the SDK's in-package snapshot.

    Files live under :mod:`eidr.schemas.bundled` (the
    ``src/eidr/schemas/bundled/`` data directory). Access uses
    :mod:`importlib.resources` so the source works correctly
    whether the package is installed normally, run from a wheel
    or zipapp, or imported from a source checkout.
    """

    def read(self, name: str) -> bytes:
        if "/" in name or "\\" in name:
            raise ValueError(f"Schema name must be a bare filename, got {name!r}")
        try:
            return (resources.files(_BUNDLED_PACKAGE) / name).read_bytes()
        except FileNotFoundError as exc:
            raise FileNotFoundError(
                f"No bundled schema named {name!r} in {_BUNDLED_PACKAGE!r}. "
                f"Available: {sorted(self.list())}"
            ) from exc

    def list(self) -> Iterable[str]:
        # Filter to .xsd files only — the bundled directory also
        # contains non-XSD support files (e.g. conversion tables).
        for entry in resources.files(_BUNDLED_PACKAGE).iterdir():
            name = entry.name
            if name.endswith(".xsd"):
                yield name


class RemoteSchemaSource:
    """Fetch XSD content from the live EIDR schema endpoint.

    Network access is required at use time. Each :meth:`read` call
    issues a GET; results are not cached internally — callers who
    want caching should layer it themselves (e.g., wrap this
    source in a small dict-backed memoizer).

    Why no built-in cache: caching is a policy decision (cache
    forever? cache for the process lifetime? respect HTTP cache
    headers?). The SDK shouldn't pick a policy. Callers who care
    will know which they want.
    """

    def __init__(self, base_url: str = DEFAULT_REMOTE_BASE) -> None:
        if not base_url.endswith("/"):
            base_url = base_url + "/"
        self._base_url = base_url

    @property
    def base_url(self) -> str:
        return self._base_url

    def read(self, name: str) -> bytes:
        if "/" in name or "\\" in name:
            raise ValueError(f"Schema name must be a bare filename, got {name!r}")
        # Local import: keep httpx out of the import path of any
        # caller using BundledSchemaSource only. Same approach the
        # rest of the SDK uses for the [client] extra.
        try:
            import httpx
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "RemoteSchemaSource requires httpx. Install with "
                "`pip install 'eidr[client]'` (or any extra that "
                "pulls in httpx)."
            ) from exc

        url = self._base_url + name
        response = httpx.get(url, timeout=30.0)
        response.raise_for_status()
        return response.content

    def list(self) -> Iterable[str]:
        # The EIDR schema endpoint does not expose a directory
        # listing, so we return a curated manifest matching what
        # the bundled source ships. Keeping this list in sync with
        # the bundled snapshot is a contributor responsibility at
        # SDK-release time.
        return (
            "api-common.xsd",
            "api.xsd",
            "assetDOIType.xsd",
            "bulk.xsd",
            "common-redef.xsd",
            "common.xsd",
            "dedup.xsd",
            "doi.xsd",
            "doiavs.xsd",
            "eidr-base.xsd",
            "iso3166a2.xsd",
            "md-redef.xsd",
            "md-v28-eidr.xsd",
            "md-v2_8.xsd",
            "service.xsd",
        )


def default_schema_source() -> SchemaSource:
    """Return the source used when none is specified.

    Currently always :class:`BundledSchemaSource`. A future
    environment variable (``EIDR_SCHEMA_SOURCE=remote``) could
    flip the default for runtime validation use cases without
    requiring callers to change code; not implemented yet because
    no current SDK feature reads schema at runtime. M9+ work that
    needs runtime XSD validation will revisit.
    """
    return BundledSchemaSource()
