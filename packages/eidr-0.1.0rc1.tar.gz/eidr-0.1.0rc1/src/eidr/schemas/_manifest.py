"""Provenance manifest for the bundled XSD snapshot.

Each SDK release ships a fixed snapshot of the EIDR XSD set under
:mod:`eidr.schemas.bundled`. The :class:`SchemaManifest` records
the SHA-256 hash of each file in that snapshot at SDK-build time,
so generated artifacts (e.g., :mod:`eidr.models._digital_generated`)
can be mechanically tied to the exact schema bytes they were built
from.

Why this matters
----------------

The generated typed model lives at ``src/eidr/models/_digital_generated.py``
and gets regenerated when the XSDs change. Without provenance,
the only way to know whether the generated code matches the
current bundled schemas is to re-run the generator and diff the
output. The manifest gives a one-line answer:

* The build-time tool (:mod:`tools.generate_digital`) writes the
  current manifest's overall SHA-256 into the generated module's
  header comment.
* The :func:`compute_manifest` function in this module computes
  the same value at runtime against the currently-bundled XSDs.
* If the two differ, someone has either edited the XSDs without
  regenerating, or hand-edited the generated module without
  updating the input schemas.

A future ``check_provenance()`` smoke test (out of scope for M8)
can compare the comment-embedded hash against the live one.

Format
------

The manifest is a JSON file at
``src/eidr/schemas/bundled/MANIFEST.json``::

    {
        "format_version": 1,
        "files": {
            "common.xsd":       {"sha256": "abc123...", "bytes": 12345},
            "md-v2_8.xsd":      {"sha256": "def456...", "bytes": 80144},
            ...
        },
        "manifest_sha256": "..."
    }

``manifest_sha256`` is the hash of the canonicalized
``files`` object — sorted keys, no extra whitespace — making it a
single value that summarizes the whole snapshot. That's what the
generator embeds in the generated module.
"""

from __future__ import annotations

import hashlib
import json
from typing import TYPE_CHECKING

from eidr.schemas._source import BundledSchemaSource

if TYPE_CHECKING:
    from eidr.schemas._source import SchemaSource


MANIFEST_FILENAME = "MANIFEST.json"
MANIFEST_FORMAT_VERSION = 1


def _hash_file_entries(source: SchemaSource) -> dict[str, dict[str, int | str]]:
    """Return a dict mapping each XSD filename to its hash and size.

    Walks the source's ``list()`` output. Order doesn't matter for
    correctness — the manifest_sha256 step canonicalizes via
    sorted keys — but stable iteration order makes the diff
    readable when files change.
    """
    entries: dict[str, dict[str, int | str]] = {}
    for name in sorted(source.list()):
        data = source.read(name)
        entries[name] = {
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
        }
    return entries


def compute_manifest(source: SchemaSource | None = None) -> dict[str, object]:
    """Compute a fresh manifest from the given (or default) schema source.

    Args:
        source: Source to inspect. Defaults to
            :class:`BundledSchemaSource`.

    Returns:
        The manifest dict (suitable for ``json.dumps``).
    """
    if source is None:
        source = BundledSchemaSource()
    files = _hash_file_entries(source)
    canonical = json.dumps(files, sort_keys=True, separators=(",", ":"))
    manifest_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return {
        "format_version": MANIFEST_FORMAT_VERSION,
        "files": files,
        "manifest_sha256": manifest_hash,
    }


def load_manifest(source: SchemaSource | None = None) -> dict[str, object] | None:
    """Read the on-disk manifest from the schema source.

    Returns ``None`` if the manifest file is absent — a fresh
    checkout before the build tool has run, for instance.
    """
    if source is None:
        source = BundledSchemaSource()
    try:
        data = source.read(MANIFEST_FILENAME)
    except (FileNotFoundError, ValueError):
        # ValueError covers the bare-filename guardrail in
        # BundledSchemaSource — should never trigger here, but
        # belt-and-suspenders.
        return None
    parsed: dict[str, object] = json.loads(data.decode("utf-8"))
    return parsed


def manifest_sha256(source: SchemaSource | None = None) -> str:
    """Return just the rolled-up hash of the current schema set.

    Convenience for callers (and tests) that only care about the
    one-line summary value, not the per-file detail.
    """
    return str(compute_manifest(source)["manifest_sha256"])
