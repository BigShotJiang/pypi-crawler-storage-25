"""XML/JSON codec layer — file-based mode for the EIDR SDK.

This package implements the rules for converting between EIDR-native XML
and the MovieLabs MDDF JSON Encoding. It operates on a simple Python
structure ("codec dict") that mirrors the XML infoset without importing any
EIDR-specific schema knowledge — the typed model layer in :mod:`eidr.models`
composes on top of this.

Two codecs, one data shape
--------------------------

The codec's intermediate representation is a recursively-nested Python
``dict`` matching the MovieLabs JSON encoding rules:

* Element tag names are preserved as dict keys.
* Attributes are prefixed with ``_`` (e.g. ``_lang``).
* XML namespace declarations are preserved as ``_xmlns:<prefix>``.
* Element text content with *no* attributes is stored as the scalar value.
* Element text content with attributes is stored under the ``value`` subkey.
* Repeatable elements are stored as lists; see cardinality rules below.

Round-trip guarantees
---------------------

Two distinct output contracts, per the :ref:`review <review_canonicalization>`:

* :func:`xml.to_xml` / :func:`json.to_xml` — **infoset-level** round trip.
  Preserves element order, text content, attributes, and namespace
  declarations, but does *not* guarantee byte-for-byte identity across
  re-serialization (whitespace, attribute order, empty-element form may
  differ between round trips).
* :func:`xml.to_xml_canonical` / :func:`json.to_canonical_string` —
  **byte-stable canonical** output. Uses W3C C14N 1.1 for XML and RFC 8785
  JCS for JSON. Required for signature workflows (XAdES-B-T, JAdES-B-T).

Normal user code uses the infoset-level path. Only call the canonical
variants when preparing a document for cryptographic signing or when
comparing documents for equality across implementations.

Cardinality handling
--------------------

The MovieLabs spec requires elements with ``maxOccurs > 1`` in the XSD to
always be emitted as JSON arrays, even when only one is present. Because
this codec is schema-agnostic, cardinality comes from one of three sources:

1. **Explicit map** (preferred): pass ``multi_elements=<set>`` of fully
   qualified element names (e.g. ``"{http://www.eidr.org/schema}AltID"``)
   or local names.
2. **Bundled EIDR map**: :data:`eidr.codecs.EIDR_MULTI_ELEMENTS` contains
   the set of known-multi element names for EIDR schemas. This is used
   automatically when no explicit map is supplied and the document is
   detected as EIDR-namespaced.
3. **Observed cardinality** (fallback): if neither of the above applies,
   elements that appear ≥2 times at the same level are arrays;
   singletons are scalars. **This does not fully conform to the
   MovieLabs spec** — elements that are *optional-repeatable* and happen
   to appear only once in a given document will be emitted as scalars.
   Emits a :class:`~eidr.codecs.CardinalityHeuristicWarning` to flag this.

Public entry points
-------------------

* :mod:`eidr.codecs.xml` — XML ↔ codec-dict
* :mod:`eidr.codecs.json` — codec-dict ↔ JSON string / JSON dict
* :mod:`eidr.codecs.rules` — low-level helpers if you need them
"""

from __future__ import annotations

from eidr.codecs._rules import (
    ATTR_PREFIX,
    TEXT_KEY,
    CardinalityHeuristicWarning,
    CardinalityMap,
    CodecDict,
    CodecValue,
    observed_cardinality,
)
from eidr.codecs._schema_hints import (
    EIDR_MULTI_ELEMENTS,
    EIDR_MULTI_LOCAL,
    EIDR_MULTI_QUALIFIED,
)

__all__ = [
    "ATTR_PREFIX",
    "EIDR_MULTI_ELEMENTS",
    "EIDR_MULTI_LOCAL",
    "EIDR_MULTI_QUALIFIED",
    "TEXT_KEY",
    "CardinalityHeuristicWarning",
    "CardinalityMap",
    "CodecDict",
    "CodecValue",
    "observed_cardinality",
]
