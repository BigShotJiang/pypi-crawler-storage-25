"""Shared rules, types, and helpers for the XML ↔ JSON codec.

This module defines:

* The intermediate data shape (``CodecValue``, ``CodecDict``).
* The MovieLabs prefix/key constants (``_`` for attributes, ``value`` for
  text alongside attributes).
* The :class:`CardinalityMap` type for schema-aware cardinality hints.
* The observed-cardinality fallback used when no map is available.
* The :class:`CardinalityHeuristicWarning` that flags fallback use.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, Union

__all__ = [
    "ATTR_PREFIX",
    "TEXT_KEY",
    "CardinalityHeuristicWarning",
    "CardinalityMap",
    "CodecDict",
    "CodecValue",
    "is_multi",
    "normalize_multi_elements",
    "observed_cardinality",
]


#: Prefix used to mark XML attributes as dict keys. MovieLabs MDDF spec §2.
ATTR_PREFIX = "_"

#: Key used to hold element text content when attributes are also present.
#: MovieLabs MDDF spec §2.
TEXT_KEY = "value"


# ─────────────────────────────────────────────────────────────────────────────
# Type aliases
# ─────────────────────────────────────────────────────────────────────────────

# The codec's intermediate representation. A CodecDict maps element/attribute
# names to either a scalar string (simple element or attribute value), a
# nested dict (complex element with attributes or children), or a list of
# dicts/strings (repeating element).
#
# Using Any for the value side keeps the type usable without a Python 3.12+
# TypeAlias, while still documenting intent.
CodecValue = Union[str, "CodecDict", list[Any], None]
"""One slot in a :data:`CodecDict`: a string, nested dict, list, or ``None``.

``None`` is only used for genuinely empty elements that have no attributes,
text, or children — rare in EIDR/MovieLabs documents. It is preserved
through round-trips.
"""

CodecDict = dict[str, CodecValue]
"""The recursive dict structure used by the codec.

Keys are strings. Attribute keys start with :data:`ATTR_PREFIX` (``_``).
Element text content, when mixed with attributes, appears under
:data:`TEXT_KEY` (``value``). Repeatable elements appear as lists.

This matches the MovieLabs MDDF JSON Encoding Best Practice output format
exactly; serializing a ``CodecDict`` with the standard library ``json``
module produces spec-conformant JSON.
"""

#: A set of element names that the codec should always treat as multi-valued.
#:
#: Entries may be either:
#:
#: * Qualified names in Clark notation, e.g. ``"{http://www.eidr.org/schema}AltID"``
#: * Bare local names (namespace-agnostic), e.g. ``"AltID"``
#:
#: Qualified names take precedence over bare local names at lookup time.
CardinalityMap = frozenset[str]


# ─────────────────────────────────────────────────────────────────────────────
# Warnings
# ─────────────────────────────────────────────────────────────────────────────


class CardinalityHeuristicWarning(UserWarning):
    """Emitted when the codec falls back to observed-cardinality heuristics.

    This indicates that neither an explicit cardinality map nor the bundled
    EIDR map was used, and the codec is inferring array-ness from the
    document itself. The result is valid JSON but may not conform to the
    MovieLabs MDDF JSON Encoding for elements that are
    optional-repeatable-but-only-appear-once in this document.

    To silence the warning, either:

    * supply ``multi_elements=`` explicitly to the codec call, or
    * suppress via ``warnings.filterwarnings("ignore",
      category=CardinalityHeuristicWarning)``.
    """


# ─────────────────────────────────────────────────────────────────────────────
# Normalization / lookup
# ─────────────────────────────────────────────────────────────────────────────


def normalize_multi_elements(
    names: Iterable[str] | None,
) -> frozenset[str]:
    """Coerce a user-supplied multi-element hint into a normalized frozenset.

    Accepts any iterable of element names (qualified or local) and returns
    a frozen set for efficient lookup. Passing ``None`` returns an empty
    set.
    """
    if not names:
        return frozenset()
    return frozenset(names)


def is_multi(
    qualified: str,
    local: str,
    *,
    multi_elements: frozenset[str] | set[str],
    multi_qualified: frozenset[tuple[str, str]] | None = None,
) -> bool:
    """Return True if the element is declared (or hinted) multi-valued.

    Lookup order:

    1. If ``multi_qualified`` is supplied and ``qualified`` is in Clark
       notation, check ``(ns, local)`` against the tuple set. This is the
       authoritative path when XSD-derived data is available.
    2. Check ``qualified`` (Clark notation or bare name) against
       ``multi_elements``.
    3. Check ``local`` against ``multi_elements``.

    Args:
        qualified: Fully qualified element name in Clark notation
            (``"{ns}local"``), or a bare name when no namespace applies.
        local: The local part of the element name.
        multi_elements: The namespace-agnostic cardinality set (user hints
            merged with bundled local names).
        multi_qualified: Optional authoritative ``(namespace, localname)``
            set. When supplied, it takes precedence over the local-name set.

    Returns:
        ``True`` if the element should be emitted as a JSON array.
    """
    if multi_qualified and qualified.startswith("{"):
        end = qualified.find("}")
        if end != -1:
            ns = qualified[1:end]
            if (ns, local) in multi_qualified:
                return True
    if qualified in multi_elements:
        return True
    return local in multi_elements


# ─────────────────────────────────────────────────────────────────────────────
# Observed-cardinality fallback
# ─────────────────────────────────────────────────────────────────────────────


def observed_cardinality(
    structure: Mapping[str, Any] | None,
) -> set[str]:
    """Return element names that appear ≥2 times *at the same parent* anywhere in ``structure``.

    This is the fallback used when no cardinality map is supplied.  The
    output is a set of local names (namespace-stripped) suitable for use
    as a ``multi_elements`` hint with the codec.

    The scan is defensive: non-dict children are ignored, circular
    references are not detected (callers are assumed to pass an acyclic
    structure), and attribute keys (``_``-prefixed) are skipped.

    Args:
        structure: Any nested dict/list structure rooted at a single
            element dict, or a parsed XML element converted to one.

    Returns:
        Set of local element names observed as multi at *any* parent in
        the tree. A union across all levels — e.g. if ``AltID`` appears
        twice as a child of one element and once as a child of another,
        it is still included.
    """
    seen_multi: set[str] = set()
    if structure is None:
        return seen_multi
    _walk_for_multi(structure, seen_multi)
    return seen_multi


def _walk_for_multi(node: Any, seen_multi: set[str]) -> None:
    """Recursive helper for :func:`observed_cardinality`."""
    if isinstance(node, dict):
        # At this level, a key whose value is a list of 2+ items represents a
        # multi-valued element. Record its name (after stripping any namespace).
        for key, value in node.items():
            if key.startswith(ATTR_PREFIX) or key == TEXT_KEY:
                continue
            if isinstance(value, list) and len(value) >= 2:
                seen_multi.add(_strip_namespace(key))
            # Recurse regardless so nested levels are scanned.
            _walk_for_multi(value, seen_multi)
    elif isinstance(node, list):
        for item in node:
            _walk_for_multi(item, seen_multi)
    # strings and None are leaves; no recursion.


def _strip_namespace(tag: str) -> str:
    """Return the local part of ``tag`` (Clark notation or bare name)."""
    if tag.startswith("{"):
        # {namespace}localname
        end = tag.find("}")
        if end != -1:
            return tag[end + 1 :]
    # Also handle prefix:localname
    if ":" in tag and not tag.startswith(ATTR_PREFIX):
        return tag.split(":", 1)[1]
    return tag
