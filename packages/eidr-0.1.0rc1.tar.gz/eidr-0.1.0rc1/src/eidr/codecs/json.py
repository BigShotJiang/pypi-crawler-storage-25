"""JSON ↔ codec-dict (and therefore ↔ XML) conversion.

The codec's intermediate :data:`CodecDict` structure matches the MovieLabs
MDDF JSON Encoding Best Practice output format exactly, so:

* ``json.dumps(codec_dict)`` produces spec-conformant MovieLabs JSON.
* ``json.loads(json_text)`` produces a :data:`CodecDict` that can be
  serialized back to XML via :func:`eidr.codecs.xml.to_xml`.

The top-level wrapper (e.g., ``"FullMetadata"``) is retained by default,
which is the recommended form for standalone JSON documents. Callers
embedding JSON fragments in an API response where the context is
understood should pass ``wrapper="drop"``, per
:ref:`the review's point 5 <review_wrapper>`.

Two output contracts:

* :func:`to_json` — human-readable JSON for normal use. Indentation and
  key ordering follow the source dict's insertion order.
* :func:`to_canonical_string` — byte-stable JSON via RFC 8785 JCS
  (JSON Canonicalization Scheme). Required for JAdES-B-T signing.

RFC 8785 JCS produces deterministic output: keys lexically sorted at
every level, no unnecessary whitespace, strict Unicode handling. Two
documents with the same data produce identical bytes regardless of how
they were constructed.
"""

from __future__ import annotations

import json as _stdlib_json
from typing import Any, Literal

import rfc8785 as _rfc8785

# Codec XML module is used for the full JSON ↔ XML path.
from eidr.codecs import xml as _xml_codec
from eidr.codecs._rules import CodecDict
from eidr.errors import EIDRCodecError

__all__ = [
    "from_json",
    "to_canonical_bytes",
    "to_canonical_string",
    "to_codec_dict",
    "to_json",
    "to_json_dict",
    "to_xml",
    "to_xml_canonical",
]


WrapperMode = Literal["retain", "drop"]
"""Choice for how the top-level element wrapper is handled.

* ``"retain"`` (default): keep the top-level element name as the outermost
  JSON object key. Produces a self-describing document with a single root
  key. Use for standalone JSON documents (e.g. stored as assets, written
  to disk, embedded in a signed payload).
* ``"drop"``: strip the top-level wrapper so the JSON object's top-level
  keys are the root element's children. Use when the JSON is embedded in
  an API response where the root type is implied by the response context.
"""


# ─────────────────────────────────────────────────────────────────────────────
# XML → JSON direction
# ─────────────────────────────────────────────────────────────────────────────


def to_codec_dict(json_source: str | bytes | dict[str, Any]) -> CodecDict:
    """Parse JSON (text or dict) into a :data:`CodecDict`.

    Accepts either a JSON text form (str or bytes) or an already-parsed
    Python dict (as would come from ``json.loads``).

    Args:
        json_source: A JSON string, UTF-8 encoded JSON bytes, or a Python
            dict matching the MovieLabs encoding.

    Returns:
        A :data:`CodecDict`. The structure is *not* validated against any
        schema — it is assumed to follow the MovieLabs conventions.

    Raises:
        EIDRCodecError: If text input cannot be parsed as JSON, or the
            resulting value is not a dict.
    """
    if isinstance(json_source, dict):
        return json_source  # already a dict; we trust the shape
    if isinstance(json_source, bytes):
        try:
            json_source = json_source.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise EIDRCodecError(
                f"JSON bytes are not valid UTF-8: {exc}",
                format="json",
                original=exc,
            ) from exc
    try:
        loaded = _stdlib_json.loads(json_source)
    except _stdlib_json.JSONDecodeError as exc:
        raise EIDRCodecError(f"JSON parse error: {exc}", format="json", original=exc) from exc
    if not isinstance(loaded, dict):
        raise EIDRCodecError(
            f"Top-level JSON value must be an object, got {type(loaded).__name__}",
            format="json",
        )
    return loaded


def from_json(
    json_source: str | bytes | dict[str, Any],
    *,
    wrapper_key: str | None = None,
) -> CodecDict:
    """Parse JSON and restore a wrapper if the input dropped one.

    When JSON was produced with ``wrapper="drop"``, the caller must supply
    the wrapper_key when reading it back in order to reconstruct a
    well-formed document.

    Args:
        json_source: A JSON string, bytes, or parsed dict.
        wrapper_key: If given, wrap the input under this key. This is the
            complement of :func:`to_json` with ``wrapper="drop"``.

    Returns:
        A :data:`CodecDict`.
    """
    parsed = to_codec_dict(json_source)
    if wrapper_key is None:
        return parsed
    return {wrapper_key: parsed}


# ─────────────────────────────────────────────────────────────────────────────
# CodecDict → JSON direction
# ─────────────────────────────────────────────────────────────────────────────


def to_json_dict(
    codec_dict: CodecDict,
    *,
    wrapper: WrapperMode = "retain",
) -> CodecDict:
    """Produce the Python dict suitable for ``json.dumps``.

    This is a no-op for ``wrapper="retain"`` — the codec-dict is already
    in the right shape. For ``wrapper="drop"``, the single top-level key
    is removed.

    Args:
        codec_dict: A codec-dict, typically from
            :func:`eidr.codecs.xml.to_codec_dict` or :func:`to_codec_dict`.
        wrapper: ``"retain"`` (default) keeps the top-level element name;
            ``"drop"`` removes it and returns the contents.

    Returns:
        A dict ready for ``json.dumps``.

    Raises:
        EIDRCodecError: If ``wrapper="drop"`` is used and ``codec_dict``
            does not have exactly one top-level key.
    """
    if wrapper == "retain":
        return codec_dict
    if wrapper != "drop":
        raise EIDRCodecError(
            f"wrapper must be 'retain' or 'drop', got {wrapper!r}",
            format="json",
        )

    if len(codec_dict) != 1:
        raise EIDRCodecError(
            f"wrapper='drop' requires exactly one top-level key; "
            f"got {len(codec_dict)}: {list(codec_dict.keys())}",
            format="json",
        )
    inner = next(iter(codec_dict.values()))
    if not isinstance(inner, dict):
        raise EIDRCodecError(
            f"wrapper='drop' requires the top-level value to be a dict "
            f"(the wrapped element's contents); got {type(inner).__name__}",
            format="json",
        )
    return inner


def to_json(
    codec_dict: CodecDict,
    *,
    wrapper: WrapperMode = "retain",
    indent: int | None = 2,
    ensure_ascii: bool = False,
) -> str:
    """Serialize a :data:`CodecDict` to JSON text (non-canonical, pretty by default).

    Args:
        codec_dict: A codec-dict.
        wrapper: ``"retain"`` (default) or ``"drop"`` — see :data:`WrapperMode`.
        indent: JSON indent level. ``None`` for compact output, default ``2``.
        ensure_ascii: When True, escape non-ASCII characters. Default False
            (preserves UTF-8 content — BCP 47 language tags, international
            titles, etc. — in readable form).

    Returns:
        A JSON text string.
    """
    py_dict = to_json_dict(codec_dict, wrapper=wrapper)
    return _stdlib_json.dumps(
        py_dict,
        indent=indent,
        ensure_ascii=ensure_ascii,
        # Preserve insertion order (Python dicts) rather than re-sorting;
        # canonical mode sorts via to_canonical_string below.
        sort_keys=False,
    )


def to_canonical_string(
    codec_dict: CodecDict,
    *,
    wrapper: WrapperMode = "retain",
) -> str:
    """Serialize a :data:`CodecDict` to RFC 8785 JCS canonical JSON.

    Produces byte-stable, spec-conforming output suitable for
    cryptographic signing (JAdES-B-T per the ADS Technical Architecture
    §16.3) and for content-addressed dedup hashing.

    Implementation: delegates to the ``rfc8785`` package (Trail of Bits'
    pure-Python RFC 8785 implementation). The library is deliberately
    "one canonicalization, one implementation" — there is no stdlib
    fallback, so output is always guaranteed to match any other
    conforming JCS implementation byte-for-byte.

    Guarantees from RFC 8785:

    * Object keys are in Unicode code-point (lexical) order at every nesting level.
    * No extraneous whitespace.
    * Numbers serialized per the RFC 8259 / ECMA-262 algorithm (shortest
      round-trippable form).
    * UTF-8 output, no BOM.

    Args:
        codec_dict: A codec-dict.
        wrapper: ``"retain"`` (default) or ``"drop"`` — see :data:`WrapperMode`.

    Returns:
        The canonicalized JSON text.
    """
    py_dict = to_json_dict(codec_dict, wrapper=wrapper)
    # rfc8785.dumps returns bytes (RFC 8785 is defined over UTF-8 bytes).
    # We decode to a str for API consistency with :func:`to_json`; the
    # bytes form is recoverable via ``result.encode("utf-8")`` and is
    # byte-identical.
    return _rfc8785.dumps(py_dict).decode("utf-8")


def to_canonical_bytes(
    codec_dict: CodecDict,
    *,
    wrapper: WrapperMode = "retain",
) -> bytes:
    """Serialize a :data:`CodecDict` to RFC 8785 JCS bytes.

    Identical to :func:`to_canonical_string` but returns the canonical
    UTF-8 byte sequence directly, which is the form defined by
    RFC 8785 and the form consumed by signature/digest computation.
    Prefer this variant when feeding JAdES or other signing tools.

    Args:
        codec_dict: A codec-dict.
        wrapper: ``"retain"`` (default) or ``"drop"`` — see :data:`WrapperMode`.

    Returns:
        The canonical JSON as UTF-8 bytes.
    """
    py_dict = to_json_dict(codec_dict, wrapper=wrapper)
    result: bytes = _rfc8785.dumps(py_dict)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Convenience: JSON → XML directly
# ─────────────────────────────────────────────────────────────────────────────


def to_xml(
    json_source: str | bytes | dict[str, Any],
    *,
    wrapper_key: str | None = None,
    pretty_print: bool = False,
    xml_declaration: bool = True,
) -> bytes:
    """Convert JSON directly to XML bytes (infoset-level).

    Convenience wrapper for :func:`from_json` → :func:`eidr.codecs.xml.to_xml`.

    Args:
        json_source: The JSON to convert.
        wrapper_key: If the JSON dropped its top-level wrapper, supply the
            wrapper element name here.
        pretty_print: See :func:`eidr.codecs.xml.to_xml`.
        xml_declaration: See :func:`eidr.codecs.xml.to_xml`.

    Returns:
        XML bytes.
    """
    codec_dict = from_json(json_source, wrapper_key=wrapper_key)
    return _xml_codec.to_xml(
        codec_dict,
        pretty_print=pretty_print,
        xml_declaration=xml_declaration,
    )


def to_xml_canonical(
    json_source: str | bytes | dict[str, Any],
    *,
    wrapper_key: str | None = None,
    method: str = "c14n2",
) -> bytes:
    """Convert JSON directly to canonical XML bytes.

    Convenience wrapper for :func:`from_json` →
    :func:`eidr.codecs.xml.to_xml_canonical`.
    """
    codec_dict = from_json(json_source, wrapper_key=wrapper_key)
    return _xml_codec.to_xml_canonical(codec_dict, method=method)
