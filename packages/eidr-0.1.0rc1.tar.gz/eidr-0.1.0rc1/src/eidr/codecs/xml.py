"""XML ↔ codec-dict conversion.

This module converts between an XML document (as bytes, string, or
``lxml.etree._Element``) and the codec's intermediate :data:`CodecDict`
representation. Two output paths are provided:

* :func:`to_xml` — **infoset-level** round trip. Suitable for normal use.
  Preserves element order, text, attributes, and namespace declarations,
  but is not guaranteed to be byte-for-byte stable across re-serializations.
* :func:`to_xml_canonical` — **byte-stable** canonical output via W3C
  Canonical XML 1.1 (C14N 1.1). Required for signature workflows
  (XAdES-B-T per the ADS Technical Architecture).

Both output paths start from the same :data:`CodecDict` input, so callers
can build a dict once and serialize to either form.
"""

from __future__ import annotations

import io
import warnings
from collections.abc import Iterable

from lxml import etree

from eidr.codecs._rules import (
    ATTR_PREFIX,
    TEXT_KEY,
    CardinalityHeuristicWarning,
    CodecDict,
    CodecValue,
    is_multi,
    normalize_multi_elements,
)
from eidr.codecs._schema_hints import EIDR_MULTI_ELEMENTS, EIDR_MULTI_QUALIFIED
from eidr.errors import EIDRCodecError

__all__ = [
    "from_codec_dict",
    "parse_xml",
    "to_codec_dict",
    "to_xml",
    "to_xml_canonical",
]


# ─────────────────────────────────────────────────────────────────────────────
# Parse XML → CodecDict
# ─────────────────────────────────────────────────────────────────────────────


def parse_xml(source: bytes | str | etree._Element) -> etree._Element:
    """Parse ``source`` to an lxml Element, accepting any common shape.

    Accepts raw XML bytes, an XML string, or an existing lxml element.
    Reuse this helper to keep input-handling consistent across the codec.

    Args:
        source: XML document bytes, XML text, or an already-parsed element.

    Returns:
        The root :class:`lxml.etree._Element`.

    Raises:
        EIDRCodecError: If the input cannot be parsed as XML.
    """
    if isinstance(source, etree._Element):
        return source
    try:
        if isinstance(source, str):
            # lxml's parsers want bytes; encode defensively.
            source = source.encode("utf-8")
        return etree.fromstring(source)
    except etree.XMLSyntaxError as exc:
        raise EIDRCodecError(
            f"Failed to parse XML input: {exc}", format="xml", original=exc
        ) from exc


def to_codec_dict(
    source: bytes | str | etree._Element,
    *,
    multi_elements: Iterable[str] | None = None,
    use_bundled_hints: bool = True,
) -> CodecDict:
    """Convert an EIDR/MovieLabs XML document to a :data:`CodecDict`.

    The root element becomes a single top-level key. If cardinality
    hints are available, elements declared as multi are always placed
    in a list — even when only one occurs. See the
    :mod:`eidr.codecs` module docstring for details on the three
    cardinality sources.

    Args:
        source: The XML document to convert.
        multi_elements: Optional set of element names (qualified or bare
            local) that should always be treated as multi-valued. Union'd
            with the bundled EIDR set when ``use_bundled_hints`` is True.
        use_bundled_hints: When True (default), the bundled
            :data:`~eidr.codecs.EIDR_MULTI_ELEMENTS` set is merged into
            the multi-element map. Pass False to use *only* your explicit
            set.

    Returns:
        A :data:`CodecDict` with a single top-level entry keyed by the
        root element's tag name.

    Warns:
        CardinalityHeuristicWarning: When neither explicit hints nor
            the bundled set yield any multi-element names and the
            codec falls back to observed-cardinality heuristics.
    """
    root = parse_xml(source)

    multi: set[str] = set(normalize_multi_elements(multi_elements))
    if use_bundled_hints:
        multi |= EIDR_MULTI_ELEMENTS

    if not multi:
        # No hints at all; we cannot pre-compute observed cardinality without
        # already walking the tree, so we fall through with an empty map and
        # every multi-valued group is detected in line (see _element_to_dict,
        # which always collects children as lists first and collapses to
        # scalars where the map says singleton).
        warnings.warn(
            "No cardinality hints supplied to to_codec_dict(). "
            "Single-occurrence repeatable elements will be emitted as scalars, "
            "which may not conform to MovieLabs JSON Encoding rules. "
            "Supply multi_elements= explicitly to enforce spec-compliant "
            "output.",
            CardinalityHeuristicWarning,
            stacklevel=2,
        )

    return {_tag_for_key(root): _element_to_value(root, multi)}


def _element_to_value(
    element: etree._Element,
    multi: set[str],
) -> CodecValue:
    """Convert a single element to its :data:`CodecValue` representation.

    Rules (from the MovieLabs MDDF JSON Encoding Best Practice):

    * Element with no attributes and no children and text → scalar string.
    * Element with no attributes and no children and no text → None.
    * Element with attributes and text but no children → dict with
      ``_attr`` keys and ``value`` key.
    * Element with children → dict with child elements as keys, attributes
      as ``_attr`` keys, and text (if present) under ``value``.
    * Children with the same name collapse to a list unless single — and
      then to a list anyway if the name is in ``multi``.
    """
    locally_declared = _locally_declared_namespaces(element)
    has_attrs = len(element.attrib) > 0 or len(locally_declared) > 0
    has_children = len(element) > 0
    text = (element.text or "").strip() if element.text else ""

    # Leaf element with only text (no attributes, no children)
    if not has_attrs and not has_children:
        return text if text else None

    # Mixed or complex: build a dict
    result: CodecDict = {}

    # Namespace declarations appear as _xmlns or _xmlns:<prefix>.
    for prefix, uri in locally_declared:
        if prefix is None:
            result[f"{ATTR_PREFIX}xmlns"] = uri
        else:
            result[f"{ATTR_PREFIX}xmlns:{prefix}"] = uri

    # Regular attributes; preserve namespace via Clark notation
    for name, value in element.attrib.items():
        if name.startswith("{"):
            # {ns}localname → _ns:localname, reconstructed if we know prefix
            qname = etree.QName(name)
            prefix = _prefix_for_namespace(element, qname.namespace)
            if prefix:
                result[f"{ATTR_PREFIX}{prefix}:{qname.localname}"] = value
            else:
                # Emit in Clark notation under the attr prefix; rare case
                result[f"{ATTR_PREFIX}{qname.localname}"] = value
        else:
            result[f"{ATTR_PREFIX}{name}"] = value

    # Text content (only meaningful when attributes present or children absent)
    if text and not has_children:
        result[TEXT_KEY] = text
    elif text and has_children:
        # Mixed content (text + children). EIDR and MEC are not mixed-content
        # vocabularies, so this is noteworthy but we preserve it.
        result[TEXT_KEY] = text

    # Children
    if has_children:
        # Group by the Clark-notation tag (preserves namespace info for
        # authoritative cardinality lookup) but remember the display key
        # (prefixed form, for human-friendly JSON keys).
        grouped: dict[str, list[CodecValue]] = {}
        display_key: dict[str, str] = {}
        clark_key: dict[str, str] = {}
        for child in element:
            if not isinstance(child.tag, str):
                # Skip comments, processing instructions
                continue
            clark = child.tag  # Clark notation: {ns}local or bare local
            key = _tag_for_key(child)  # display form: prefix:local or local
            grouped.setdefault(key, []).append(_element_to_value(child, multi))
            display_key[key] = key
            clark_key[key] = clark

        for key, values in grouped.items():
            clark = clark_key[key]
            local = _strip_namespace(clark)
            # Emit as list if there are 2+ occurrences OR the name is in
            # the multi-map. Otherwise scalar.
            if len(values) >= 2 or is_multi(
                clark, local, multi_elements=multi, multi_qualified=EIDR_MULTI_QUALIFIED
            ):
                result[key] = values
            else:
                result[key] = values[0]

    return result if result else None


# ─────────────────────────────────────────────────────────────────────────────
# Serialize CodecDict → XML
# ─────────────────────────────────────────────────────────────────────────────


def from_codec_dict(codec_dict: CodecDict) -> etree._Element:
    """Build an lxml element tree from a :data:`CodecDict`.

    The dict must have exactly one top-level key (the root element).
    Attribute entries (``_``-prefixed) and the ``value`` key are handled
    per the MovieLabs rules.

    Args:
        codec_dict: A codec-dict produced by :func:`to_codec_dict` or
            constructed by hand.

    Returns:
        The root :class:`lxml.etree._Element`.

    Raises:
        EIDRCodecError: If the dict structure is invalid (e.g. multiple
            root keys, or an attribute-only root).
    """
    if not isinstance(codec_dict, dict) or len(codec_dict) != 1:
        raise EIDRCodecError(
            "from_codec_dict requires a dict with exactly one top-level key "
            "(the root element name).",
            format="xml",
        )
    root_key, root_value = next(iter(codec_dict.items()))
    if root_key.startswith(ATTR_PREFIX):
        raise EIDRCodecError(
            f"Root-level key {root_key!r} looks like an attribute entry, not an element.",
            format="xml",
        )
    return _build_element(root_key, root_value, nsmap={})


def _build_element(
    tag: str,
    value: CodecValue,
    nsmap: dict[str | None, str],
) -> etree._Element:
    """Construct a single element, threading namespace declarations through."""
    # Gather locally declared namespaces so we can build nsmap before
    # creating the element (lxml freezes nsmap at element creation time).
    local_nsmap: dict[str | None, str] = {}
    if isinstance(value, dict):
        for key in value:
            if key.startswith(f"{ATTR_PREFIX}xmlns:"):
                prefix = key[len(f"{ATTR_PREFIX}xmlns:") :]
                ns_uri = value[key]
                if isinstance(ns_uri, str):
                    local_nsmap[prefix] = ns_uri
            elif key == f"{ATTR_PREFIX}xmlns":
                ns_uri = value[key]
                if isinstance(ns_uri, str):
                    local_nsmap[None] = ns_uri

    # Merge parent nsmap (inherited) with local declarations. Local wins.
    merged = {**nsmap, **local_nsmap}

    # Convert a prefixed tag "prefix:localname" or Clark-notation "{ns}local"
    # into the correct Clark notation for lxml.
    clark_tag = _to_clark_element(tag, merged)

    element = etree.Element(clark_tag, nsmap=merged)

    if value is None:
        return element

    if isinstance(value, str):
        element.text = value
        return element

    if not isinstance(value, dict):
        raise EIDRCodecError(
            f"Unexpected value type for element {tag!r}: {type(value).__name__}",
            format="xml",
        )

    # Populate attributes and children
    for key, child_value in value.items():
        if key.startswith(f"{ATTR_PREFIX}xmlns"):
            # Namespace decls already applied via nsmap above
            continue
        if key.startswith(ATTR_PREFIX):
            attr_name = key[len(ATTR_PREFIX) :]
            # Attributes never inherit the default namespace, only prefixes
            clark_attr = _to_clark_attr(attr_name, merged)
            if not isinstance(child_value, str):
                raise EIDRCodecError(
                    f"Attribute {key!r} value must be a string, got {type(child_value).__name__}",
                    format="xml",
                )
            element.set(clark_attr, child_value)
        elif key == TEXT_KEY:
            if isinstance(child_value, str):
                element.text = child_value
        else:
            # Child element(s)
            if isinstance(child_value, list):
                for item in child_value:
                    element.append(_build_element(key, item, merged))
            else:
                element.append(_build_element(key, child_value, merged))

    return element


# ─────────────────────────────────────────────────────────────────────────────
# Public serialization: infoset-level and canonical
# ─────────────────────────────────────────────────────────────────────────────


def to_xml(
    codec_dict: CodecDict,
    *,
    pretty_print: bool = False,
    xml_declaration: bool = True,
    encoding: str = "utf-8",
) -> bytes:
    """Serialize a :data:`CodecDict` to XML bytes (infoset-level).

    This is the normal-use output path. Preserves element order, text,
    attributes, and namespace declarations. **Not byte-stable across
    parse/serialize round trips** — whitespace, attribute ordering, and
    empty-element form may vary. For byte-stable output (signing),
    use :func:`to_xml_canonical`.

    Args:
        codec_dict: A codec-dict, typically from :func:`to_codec_dict`.
        pretty_print: When True, indent the output for readability.
            Default False.
        xml_declaration: When True (default), include ``<?xml version=...?>``.
        encoding: Output encoding. Default utf-8.

    Returns:
        XML bytes.
    """
    element = from_codec_dict(codec_dict)
    result = etree.tostring(
        element,
        pretty_print=pretty_print,
        xml_declaration=xml_declaration,
        encoding=encoding,
    )
    # lxml's type stubs are optional; ignore_missing_imports returns Any here.
    assert isinstance(result, bytes)
    return result


def to_xml_canonical(
    codec_dict: CodecDict,
    *,
    method: str = "c14n2",
    with_comments: bool = False,
) -> bytes:
    """Serialize a :data:`CodecDict` to byte-stable canonical XML.

    Produces deterministic output suitable for cryptographic signing
    (XAdES-B-T and related workflows) and content-addressed hashing.

    Available canonicalization methods:

    * ``"c14n2"`` (default): W3C `Canonical XML 2.0
      <https://www.w3.org/TR/xml-c14n2/>`_. Recommended for new
      workflows — this is the method lxml implements natively and the
      method used for all byte-stability guarantees in this library's
      test suite.
    * ``"c14n"``: the original `Canonical XML 1.0
      <https://www.w3.org/TR/xml-c14n/>`_ via ``lxml.etree.ElementTree.write_c14n``.
    * ``"c14n_exclusive"``: `Exclusive Canonical XML
      <https://www.w3.org/TR/xml-exc-c14n/>`_.
    * ``"c14n11"``: alias for ``"c14n2"``. Accepted for backwards
      compatibility with earlier docs; prefer ``"c14n2"`` in new code.

    Note: C14N 2.0 is the evolution of C14N 1.1 recommended by the W3C
    XML Core Working Group. For most signing workflows either is
    acceptable, but because lxml implements 2.0 natively and offers no
    distinct 1.1 mode, this library standardizes on 2.0 and does not
    attempt to approximate 1.1.

    Args:
        codec_dict: A codec-dict, typically from :func:`to_codec_dict`.
        method: One of ``"c14n2"`` (default), ``"c14n"``,
            ``"c14n_exclusive"``, or the deprecated alias ``"c14n11"``.
        with_comments: When True, preserve XML comments in the canonical
            output. Default False (they're stripped per XAdES conventions).

    Returns:
        Canonical XML bytes (always UTF-8, no BOM, no XML declaration).

    Raises:
        EIDRCodecError: If ``method`` is not one of the supported
            canonicalization algorithms.
    """
    element = from_codec_dict(codec_dict)
    buffer = io.BytesIO()

    # Accept "c14n11" as a legacy alias for "c14n2".
    if method == "c14n11":
        method = "c14n2"

    if method == "c14n":
        # Canonical XML 1.0
        tree = etree.ElementTree(element)
        tree.write_c14n(buffer, exclusive=False, with_comments=with_comments)
        return buffer.getvalue()

    if method == "c14n_exclusive":
        # Exclusive Canonical XML
        tree = etree.ElementTree(element)
        tree.write_c14n(buffer, exclusive=True, with_comments=with_comments)
        return buffer.getvalue()

    if method == "c14n2":
        # Canonical XML 2.0 (lxml's native implementation).
        result = etree.tostring(element, method="c14n2", with_comments=with_comments)
        assert isinstance(result, bytes)
        return result

    raise EIDRCodecError(
        f"Unknown canonicalization method: {method!r}. "
        "Valid options: 'c14n2' (default), 'c14n', 'c14n_exclusive', "
        "or 'c14n11' (deprecated alias for 'c14n2').",
        format="xml",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _tag_for_key(element: etree._Element) -> str:
    """Return a dict key for ``element`` — prefixed form if possible.

    Preference order:
    1. ``prefix:localname`` if the element's namespace has a known prefix.
    2. ``localname`` if the element is in the default (no-prefix) namespace.
    3. Clark notation ``{ns}localname`` if no prefix is known.

    This keeps keys human-friendly in JSON output (``manifest:MediaManifest``
    rather than ``{http://...}MediaManifest``) while remaining lossless
    through round trips.
    """
    tag = element.tag
    if not isinstance(tag, str):
        # Comments, PIs — shouldn't reach here but guard anyway.
        return str(tag)
    if not tag.startswith("{"):
        return tag
    qname = etree.QName(tag)
    prefix = _prefix_for_namespace(element, qname.namespace)
    if prefix:
        return f"{prefix}:{qname.localname}"
    if prefix == "":
        # Default namespace — emit bare local name.
        return str(qname.localname)
    # Fall back to Clark notation; callers will see unprefixed notation.
    return tag


def _prefix_for_namespace(element: etree._Element, namespace: str | None) -> str | None:
    """Return the prefix bound to ``namespace`` in ``element``'s scope.

    Returns ``""`` for the default (unprefixed) namespace, a prefix string
    for prefixed namespaces, or ``None`` if the namespace is unbound.
    """
    if namespace is None:
        return ""
    for prefix, ns_uri in element.nsmap.items():
        if ns_uri == namespace:
            return prefix if prefix is not None else ""
    return None


def _locally_declared_namespaces(
    element: etree._Element,
) -> list[tuple[str | None, str]]:
    """Return namespace (prefix, uri) pairs declared on this element, not inherited."""
    parent = element.getparent()
    if parent is None:
        # Root: all nsmap entries count as locally declared.
        return list(element.nsmap.items())
    # Child: only entries not present in parent's nsmap count as local.
    parent_map = parent.nsmap
    return [(p, u) for p, u in element.nsmap.items() if parent_map.get(p) != u]


def _strip_namespace(tag: str) -> str:
    """Return the local part of ``tag`` (Clark notation or prefix:local)."""
    if tag.startswith("{"):
        end = tag.find("}")
        if end != -1:
            return tag[end + 1 :]
    if ":" in tag:
        return tag.split(":", 1)[1]
    return tag


def _to_clark_element(name: str, nsmap: dict[str | None, str]) -> str:
    """Convert an element name (prefix:local, local, or Clark) to Clark notation.

    Elements inherit the default namespace when unprefixed.
    """
    if name.startswith("{"):
        return name
    if ":" in name:
        prefix, local = name.split(":", 1)
        ns = nsmap.get(prefix)
        if ns:
            return f"{{{ns}}}{local}"
        return name  # unresolved prefix; lxml will reject invalid forms
    # No prefix: use default namespace if available
    default_ns = nsmap.get(None)
    if default_ns:
        return f"{{{default_ns}}}{name}"
    return name


def _to_clark_attr(name: str, nsmap: dict[str | None, str]) -> str:
    """Convert an attribute name to Clark notation.

    Per XML namespace rules, unprefixed attributes are always in **no**
    namespace — they do not inherit the element's default namespace.
    This is also why most schemas set ``attributeFormDefault="unqualified"``.
    """
    if name.startswith("{"):
        return name
    if ":" in name:
        prefix, local = name.split(":", 1)
        ns = nsmap.get(prefix)
        if ns:
            return f"{{{ns}}}{local}"
        return name
    # Unprefixed attribute: no namespace, ever.
    return name


# Backward-compatible alias — keeps the single-name import elsewhere working.
_to_clark = _to_clark_element
