"""Named EIDR registry endpoints.

EIDR operates multiple registry instances for different purposes:

* **Production** (``registry1.eidr.org``) — the authoritative registry,
  read/write, used for live data.
* **Sandbox 1** / **Sandbox 2** (``sandbox1.eidr.org``, ``sandbox2.eidr.org``) —
  read/write test registries. Most integration testing takes place in Sandbox 2.
* **Sandbox 2 Mirror** (``sandbox2-mirror.eidr.org``) — read-only mirror
  of Sandbox 2, used to exercise mirror-specific code paths.
* **Resolve** (``resolve.eidr.org``) — read-only production mirror optimized
  for high-volume resolution traffic.

Usage:
    >>> from eidr import Client, registries
    >>> client = Client(registry=registries.SANDBOX2)
    >>> client = Client(registry="sandbox2")          # by name (case-insensitive)
    >>> client = Client(registry="https://custom.example.com/EIDR")  # raw URL

The :class:`Client` constructor accepts any of:

* a :class:`Registry` instance,
* a string matching one of the named constants (case-insensitive),
* a raw URL string (for custom/private registries).

When a raw URL is supplied, the client assumes read/write capability. To
declare a custom read-only endpoint, construct a :class:`Registry` directly
with ``writable=False``.
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "ALL_REGISTRIES",
    "PRODUCTION",
    "RESOLVE",
    "SANDBOX1",
    "SANDBOX2",
    "SANDBOX2_MIRROR",
    "Registry",
    "by_name",
]


@dataclass(frozen=True)
class Registry:
    """A named EIDR registry endpoint with capability metadata.

    Registries are immutable value objects. The canonical instances are
    exposed as module-level constants (:data:`PRODUCTION`, :data:`SANDBOX2`,
    etc.); construct your own only for custom endpoints not in the
    standard list.

    Attributes:
        name: Short uppercase identifier (e.g., ``"SANDBOX2"``).
        url: Base URL including the path to the ``/EIDR`` root.
        writable: ``True`` if write operations (register, modify, delete,
            etc.) are supported. Read-only registries will reject writes
            locally before attempting a round trip.
        description: Human-readable description of the registry's role.
    """

    name: str
    url: str
    writable: bool
    description: str

    def __str__(self) -> str:
        return f"{self.name} ({self.url})"


# ─────────────────────────────────────────────────────────────────────────────
# Canonical named registries
# ─────────────────────────────────────────────────────────────────────────────

PRODUCTION = Registry(
    name="PRODUCTION",
    url="https://registry1.eidr.org:443/EIDR",
    writable=True,
    description="Production registry (registry1.eidr.org). Authoritative live data.",
)
"""The production EIDR registry. Read/write."""

SANDBOX1 = Registry(
    name="SANDBOX1",
    url="https://sandbox1.eidr.org:443/EIDR",
    writable=True,
    description="Sandbox 1 test registry. Read/write.",
)
"""Sandbox 1 test registry. Read/write."""

SANDBOX2 = Registry(
    name="SANDBOX2",
    url="https://sandbox2.eidr.org:443/EIDR",
    writable=True,
    description="Sandbox 2 test registry. Read/write. Most integration tests run here.",
)
"""Sandbox 2 test registry. Read/write. Preferred target for integration tests."""

SANDBOX2_MIRROR = Registry(
    name="SANDBOX2_MIRROR",
    url="https://sandbox2-mirror.eidr.org:443/EIDR",
    writable=False,
    description="Read-only mirror of Sandbox 2. Exercises mirror-specific code paths.",
)
"""Read-only mirror of Sandbox 2."""

RESOLVE = Registry(
    name="RESOLVE",
    url="https://resolve.eidr.org:443/EIDR",
    writable=False,
    description="Read-only production mirror optimized for high-volume resolution traffic.",
)
"""Read-only production mirror optimized for resolution (resolve.eidr.org)."""


# ─────────────────────────────────────────────────────────────────────────────
# Registry lookup
# ─────────────────────────────────────────────────────────────────────────────

ALL_REGISTRIES: tuple[Registry, ...] = (
    PRODUCTION,
    SANDBOX1,
    SANDBOX2,
    SANDBOX2_MIRROR,
    RESOLVE,
)
"""All named registries, in documentation order."""

# Build a case-insensitive name lookup. Accept both canonical names
# ("SANDBOX2") and the common shortened forms ("sandbox2", "prod").
_NAME_LOOKUP: dict[str, Registry] = {}
for _reg in ALL_REGISTRIES:
    _NAME_LOOKUP[_reg.name.lower()] = _reg
_NAME_LOOKUP["prod"] = PRODUCTION
_NAME_LOOKUP["production"] = PRODUCTION
_NAME_LOOKUP["sandbox"] = SANDBOX2  # unqualified "sandbox" means Sandbox 2
_NAME_LOOKUP["sb1"] = SANDBOX1
_NAME_LOOKUP["sb2"] = SANDBOX2
del _reg


def by_name(name: str) -> Registry:
    """Look up a registry by short name, case-insensitive.

    Accepted names include the canonical ``PRODUCTION``, ``SANDBOX1``,
    ``SANDBOX2``, ``SANDBOX2_MIRROR``, ``RESOLVE``, plus common shorthands
    (``prod``, ``sandbox`` → Sandbox 2, ``sb1``, ``sb2``).

    Args:
        name: A registry name; case and leading/trailing whitespace are ignored.

    Returns:
        The matching :class:`Registry` instance.

    Raises:
        KeyError: If ``name`` does not match any known registry.

    Example:
        >>> by_name("sandbox2").writable
        True
        >>> by_name("resolve").writable
        False
    """
    key = name.strip().lower()
    try:
        return _NAME_LOOKUP[key]
    except KeyError:
        valid = ", ".join(sorted({r.name for r in ALL_REGISTRIES}))
        raise KeyError(f"Unknown EIDR registry name: {name!r}. Known names: {valid}") from None
