"""HTTP client layer for the EIDR REST API.

This subpackage provides the sync :class:`Client` for talking to an EIDR
registry over HTTPS. It requires the ``httpx`` package, which is declared
in the ``[client]`` install extra and not pulled by the base SDK. Code
that only uses the codec and model layers (XML↔CodecDict, ContentRecord,
validation) will never import this subpackage.

Usage::

    from eidr import Client, registries, Credentials

    with Client(registries.SANDBOX2, Credentials.from_env()) as client:
        record = client.resolve("10.5240/7791-8534-2C23-9030-8610-5")
        print(record.title)

An async sibling (``AsyncClient``) is also available. Both clients
expose the same operation surface (``resolve``, ``register``,
``match``, ``modify``, ``delete``, ``promote``, ``alias``,
``add_relationship`` / ``remove_relationship`` /
``replace_relationship``, ``query``, ``graph_traversal``,
``party_query``, ``service_query``, ``status_lookup``); the only
difference is that every :class:`AsyncClient` method is
``async def`` and is used with ``async with`` and ``await``.
See :class:`AsyncClient` for the async-specific details. Tokens
from sync writes (:class:`Token`) and async writes
(:class:`AsyncToken`) are likewise parallel; :meth:`Token.to_async`
bridges a sync token into an async workflow for the
sync-under-load fallback case (REST API §2.1.1).

Importing the subpackage eagerly checks that ``httpx`` is installed and
raises :class:`ModuleNotFoundError` with a clear remediation message if
it isn't, rather than deferring to a confusing failure deep inside the
transport layer at first use.
"""

from __future__ import annotations

try:
    import httpx as _httpx  # noqa: F401
except ImportError as exc:  # pragma: no cover — exercised by install-extras tests
    raise ModuleNotFoundError(
        "The 'httpx' package is required for eidr.client. "
        "Install it via the [client] extra: pip install 'eidr[client]'"
    ) from exc

from eidr.client._async_client import AsyncClient
from eidr.client._async_token import AsyncToken
from eidr.client._client import Client
from eidr.client._envelope import DedupeMode
from eidr.client._http import TransportConfig
from eidr.client._operation_result import OperationResult
from eidr.client._operations import GraphTraversalType, RelationshipType
from eidr.client._query_results import QueryResults
from eidr.client._response import OperationStatusEntry
from eidr.client._results import (
    PartyQueryResults,
    ServiceChildrenResults,
    ServiceQueryResults,
)
from eidr.client._token import Token, TokenStatus
from eidr.client._tracing import (
    FileSink,
    ListSink,
    LoggerSink,
    TraceRecord,
    TraceSink,
)

__all__ = [
    "AsyncClient",
    "AsyncToken",
    "Client",
    "DedupeMode",
    "FileSink",
    "GraphTraversalType",
    "ListSink",
    "LoggerSink",
    "OperationResult",
    "OperationStatusEntry",
    "PartyQueryResults",
    "QueryResults",
    "RelationshipType",
    "ServiceChildrenResults",
    "ServiceQueryResults",
    "Token",
    "TokenStatus",
    "TraceRecord",
    "TraceSink",
    "TransportConfig",
]
