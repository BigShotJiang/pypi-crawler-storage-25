"""Structured view of a completed (or partially-completed) write operation.

EIDR's write protocol returns a ``<Response><Status>...</Status>...``
envelope whose body shape varies by operation:

* A successful synchronous register/modify echoes the registered
  record back inline (``<FullMetadata>...``).
* A successful synchronous delete/promote/alias returns a bare success
  envelope (no body).
* An async write returns a top-level ``<Token>`` the caller polls; the
  status response carries one or more ``<OperationStatus>`` children,
  each with its own status, optional sub-token, and (on success)
  ``<ID>``.
* A multi-operation batch returns a top-level token whose status
  response contains one ``<OperationStatus>`` per sub-operation.

Callers don't always want to thread through these shape variations
themselves. :class:`OperationResult` captures all of them in one
shape: status + ID(s) + optional inline record + sub-token list +
the raw :class:`ParsedResponse` for callers who still want to walk
the envelope.

This is the recommended return type for callers that want to handle
register/modify/etc. uniformly without branching on whether they
got a record, a token, or ``None``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from eidr.client._response import ParsedResponse, iter_sub_tokens
from eidr.client._token import TokenStatus

if TYPE_CHECKING:
    from eidr.models.content import ContentRecord


__all__ = ["OperationResult", "operation_result_from"]


_EIDR_NS = {"eidr": "http://www.eidr.org/schema"}


@dataclass(frozen=True, slots=True)
class OperationResult:
    """Uniform structured view of a write-operation outcome.

    Attributes:
        status: The :class:`TokenStatus` summarizing the operation
            outcome. ``SUCCESS`` for a fully-completed write,
            ``PENDING`` for an in-progress async write, ``FAILURE``
            for one that resolved to an error.
        ids: EIDR IDs the registry assigned or affected. Single-element
            for register/modify; possibly empty for delete/promote/
            alias; multi-element for multi-operation batches.
        record: The full :class:`ContentRecord` the registry echoed
            back, when present. ``None`` for envelope-only responses
            (delete/promote/alias) and for status-lookup responses
            (which return per-operation status, not records).
        sub_tokens: Per-operation tokens for batch writes. Each can be
            polled independently if the caller needs per-operation
            granularity. Empty for single-operation writes.
        raw_response: The underlying :class:`ParsedResponse`. Always
            populated; callers that need to walk the envelope directly
            (e.g., for operation-specific status fields not surfaced
            here) can do so.

    Construction is via :func:`operation_result_from`, not
    :class:`OperationResult.__init__` directly. The factory handles
    the various response-shape conventions and applies the right
    extraction.
    """

    status: TokenStatus
    raw_response: ParsedResponse
    ids: list[str] = field(default_factory=list)
    record: ContentRecord | None = None
    sub_tokens: list[str] = field(default_factory=list)

    @property
    def id(self) -> str | None:
        """The first ID from :attr:`ids`, or ``None`` if the list is empty.

        Convenience for the common single-operation case where the
        caller wants the assigned EIDR ID without indexing into a
        list.
        """
        return self.ids[0] if self.ids else None


def operation_result_from(
    parsed: ParsedResponse,
    *,
    record: ContentRecord | None = None,
    status: TokenStatus = TokenStatus.SUCCESS,
) -> OperationResult:
    """Build an :class:`OperationResult` from a parsed response envelope.

    Args:
        parsed: The :class:`ParsedResponse` returned by the operation
            (immediate response) or by the final status-lookup poll
            (async response).
        record: Inline record returned by the registry, when the
            operation produced one. For a sync register, this is the
            parsed ``<FullMetadata>`` body; for an async register
            polled to completion, the registry's status response
            carries IDs but not records, so this stays ``None``.
        status: The :class:`TokenStatus` outcome. Defaults to
            ``SUCCESS`` because callers that produce envelope-only
            success responses are the typical caller of this factory.
    """
    ids = _extract_ids(parsed)
    sub = iter_sub_tokens(parsed)
    return OperationResult(
        status=status,
        raw_response=parsed,
        ids=ids,
        record=record,
        sub_tokens=sub,
    )


def _extract_ids(parsed: ParsedResponse) -> list[str]:
    """Pull EIDR IDs from a response envelope.

    Looks in (in order):

    1. ``<Response>/<RequestStatusResults>/<OperationStatus>/<ID>``
       elements — for register/modify status responses.
    2. ``<Response>/<ID>`` — top-level IDs returned by some
       single-operation immediate responses.

    Returns an empty list when no IDs are present (typical for
    delete/promote/alias responses, which carry no body).
    """
    ids: list[str] = []
    # Per-operation IDs (status-lookup style).
    for op in parsed.operation_status_elements():
        id_elem = op.find("eidr:ID", _EIDR_NS)
        if id_elem is not None and id_elem.text:
            ids.append(str(id_elem.text).strip())
    # Top-level ID, if any. Some immediate responses carry the new
    # EIDR ID at <Response><ID>.
    top_id = parsed.root.find("eidr:ID", _EIDR_NS)
    if top_id is not None and top_id.text:
        ids.append(str(top_id.text).strip())
    return ids
