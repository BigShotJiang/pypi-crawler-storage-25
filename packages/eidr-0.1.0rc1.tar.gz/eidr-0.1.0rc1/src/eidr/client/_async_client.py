"""Async connected client for the EIDR REST API.

Mirror of :class:`eidr.client._client.Client`, built on top of
:class:`httpx.AsyncClient`. Every public method that :class:`Client`
exposes synchronously has an ``async def`` counterpart here, with
the same signature and semantics. The machinery under the transport
— envelope builder, operation builders, response parser, query
result parser, codec layer, record models — is shared verbatim
between the two clients.

Design notes
------------

**Separate class, not sync/async polymorphism.** Python can't type
"this method is sync or async depending on the instance," and
method-prefix naming (``aregister``, ``aresolve``) would make
every call site ugly. Two parallel classes let callers import the
one they want and use normal method names. The two classes share
modules, not instances — an :class:`AsyncClient` does not contain a
:class:`Client` and vice versa.

**Tokens are also separate.** :class:`Token` polls sync;
:class:`AsyncToken` polls async. A sync token produced by a
sync-under-load fallback (EIDR REST API §2.1.1) can be converted
to an :class:`AsyncToken` via :meth:`Token.to_async` for callers
who want to ``await`` it from an async workflow. The reverse
conversion is deliberately not offered.

**Tracing stays sync.** The :class:`TraceSink` protocol is
synchronous because all built-in sinks (logger, file, list) are
in-process and don't block. An ``AsyncTraceSink`` protocol for
network-backed sinks could be added later; it's not in scope for
this milestone.

**Context-manager lifecycle.** Always use ``async with`` —
``httpx.AsyncClient`` holds a connection pool that must be closed
with ``await client.aclose()``. Forgetting to close leaks file
descriptors and can log a warning on interpreter shutdown.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime
from types import TracebackType
from typing import TYPE_CHECKING, cast

from eidr.client._async_http import _AsyncTransport
from eidr.client._async_token import AsyncToken
from eidr.client._envelope import DedupeMode, build_request_envelope
from eidr.client._http import TransportConfig
from eidr.client._operations import (
    GraphTraversalType,
    RelationshipType,
    build_add_relationship,
    build_alias,
    build_create,
    build_create_party_body,
    build_create_service_body,
    build_delete,
    build_find_parties_by_name,
    build_find_parties_from_catalog,
    build_find_services_by_name,
    build_find_services_from_catalog,
    build_graph_traversal,
    build_modify,
    build_modify_party_body,
    build_modify_service_body,
    build_promote,
    build_query,
    build_remove_relationship,
    build_replace_relationship,
    build_status_request,
)
from eidr.client._query_results import QueryResults, parse_query_results
from eidr.client._response import (
    OperationStatusEntry,
    ParsedResponse,
    _extract_first_non_status_child,
    extract_duplicate_id,
    extract_inline_record_xml,
    extract_record_xml,
    extract_status_details,
    extract_token,
    parse_response,
    raise_for_operation_status,
)
from eidr.client._results import (
    PartyQueryResults,
    ServiceChildrenResults,
    ServiceQueryResults,
)
from eidr.client._shared import (
    DEFAULT_SUPERPARTY_ID,
    check_superparty_gate,
    coerce_id_to_str,
    embed_party_password,
    resolve_resource_path,
    xml_to_record_codec_dict,
)
from eidr.client._token import TokenStatus
from eidr.client._tracing import TraceSink, resolve_tracing_arg
from eidr.models import parse as parse_record
from eidr.models.enums import CreationType

if TYPE_CHECKING:
    from eidr.credentials import Credentials
    from eidr.models.content import ContentRecord
    from eidr.models.party import PartyRecord
    from eidr.models.service import ServiceRecord
    from eidr.models.virtual import VirtualFields
    from eidr.registries import Registry


__all__ = ["AsyncClient"]


class AsyncClient:
    """Async connected client for an EIDR registry.

    Mirror of :class:`~eidr.client.Client` with identical semantics
    and signatures, differing only in coroutine-ness. See
    :class:`Client` for design rationale, wire-protocol notes, and
    the full list of operations. This docstring covers only the
    async-specific aspects.

    Usage pattern::

        async with AsyncClient(
            registries.SANDBOX2,
            Credentials.load(),
        ) as client:
            record = await client.resolve("10.5240/...")
            token = await client.register(new_record, immediate=False)
            result = await token.operation_result(timeout=120)

    The ``async with`` is required (not just recommended): the
    underlying :class:`httpx.AsyncClient`'s connection pool holds
    file descriptors that must be released via ``aclose``.

    **Read operations:** :meth:`resolve`, :meth:`query`,
    :meth:`graph_traversal`, :meth:`party_query`, :meth:`service_query`,
    :meth:`status_lookup`.

    **Write operations:** :meth:`register`, :meth:`match`,
    :meth:`modify`, :meth:`delete`, :meth:`promote`, :meth:`alias`,
    :meth:`add_relationship`, :meth:`remove_relationship`,
    :meth:`replace_relationship`.

    All methods are ``async def`` and must be awaited.
    """

    __slots__ = (
        "_credentials",
        "_enforce_superparty_gate",
        "_registry",
        "_superparty_id",
        "_trace_sink",
        "_transport",
    )

    def __init__(
        self,
        registry: Registry,
        credentials: Credentials | None = None,
        *,
        transport_config: TransportConfig | None = None,
        tracing: TraceSink | bool | None = None,
        superparty_id: str = DEFAULT_SUPERPARTY_ID,
        enforce_superparty_gate: bool = True,
    ) -> None:
        """Initialize an asynchronous EIDR client.

        See :class:`eidr.client.Client.__init__` for the
        ``superparty_id`` and ``enforce_superparty_gate`` kwargs;
        the AsyncClient uses the same gate semantics.
        """
        self._registry = registry
        self._credentials = credentials
        self._superparty_id = superparty_id
        self._enforce_superparty_gate = enforce_superparty_gate
        self._trace_sink = resolve_tracing_arg(tracing)
        self._transport = _AsyncTransport(
            registry=registry,
            credentials=credentials,
            config=transport_config,
            trace_sink=self._trace_sink,
        )

    # ─── lifecycle ──────────────────────────────────────────────────────

    async def aclose(self) -> None:
        """Close the underlying HTTP connection pool.

        Idempotent — safe to call more than once. The first call
        closes the pool; subsequent calls are no-ops. The
        ``async with`` protocol guarantees exactly-once close; this
        method is also safe for callers who prefer explicit
        ``try``/``finally`` or teardown helpers that may double-close.
        Matches the idempotence contract on :meth:`Client.close`.
        """
        await self._transport.aclose()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    @property
    def registry(self) -> Registry:
        """The :class:`~eidr.registries.Registry` this client is bound to."""
        return self._registry

    def _check_superparty_gate(self, operation: str) -> None:
        """Async mirror of :meth:`Client._check_superparty_gate`.

        Note this is a *sync* method even on the async client — the
        gate check is purely client-side (a string comparison plus
        an optional raise) with no I/O, so making it ``async``
        would just force callers to ``await`` for no benefit.
        """
        if not self._enforce_superparty_gate:
            return
        if self._credentials is None:
            from eidr.errors import EIDRSDKPolicyError

            raise EIDRSDKPolicyError(
                f"{operation}() requires Superparty credentials but the "
                f"client was constructed without credentials. Provide "
                f"credentials whose Party ID matches the configured "
                f"Superparty ID ({self._superparty_id!r}), or pass "
                f"enforce_superparty_gate=False to disable the gate.",
                policy="superparty_required",
                operation=operation,
                configured_value=None,
                required_value=self._superparty_id,
            )
        check_superparty_gate(
            enforce=True,
            superparty_id=self._superparty_id,
            caller_party_id=self._credentials.party_id,
            operation=operation,
        )

    # ─── read operations ────────────────────────────────────────────────

    async def resolve(
        self,
        eidr_id: str,
        *,
        resolution_type: str = "Full",
        follow_alias: bool = True,
    ) -> ContentRecord | PartyRecord | ServiceRecord:
        """Resolve an EIDR ID to its registered record.

        Async mirror of :meth:`Client.resolve`. Dispatches to the
        right endpoint based on the ID prefix:

        * ``10.5240/...`` → ``/object/{id}`` (Content)
        * ``10.5237/...`` → ``/party/resolve/{id}``
        * ``10.5239/...`` → ``/service/resolve/{id}``

        Args:
            eidr_id: The EIDR ID to resolve.
            resolution_type: One of ``"Full"`` (default),
                ``"Self"``, ``"Provenance"``, ``"Inherited"``,
                ``"Simple"``, ``"DOIKernel"``, or
                ``"LinkedAlternateIDs"``. Appended as ``?type=``.
            follow_alias: When ``False``, the registry does not
                chase alias pointers and the returned record may
                itself be an alias. Appended as ``?followAlias=false``.

        Returns:
            A :class:`ContentRecord`, :class:`PartyRecord`, or
            :class:`ServiceRecord` depending on the ID prefix.
        """
        resource_path = resolve_resource_path(eidr_id)
        params: dict[str, str] = {}
        if resolution_type != "Full":
            params["type"] = resolution_type
        if not follow_alias:
            params["followAlias"] = "false"

        body = await self._transport.get(resource_path, params=params or None)
        parsed = parse_response(body, operation=f"resolve {eidr_id}")
        if parsed.kind != "record":
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"Expected a record response from resolve {eidr_id}, "
                f"got envelope kind={parsed.kind!r} "
                f"(status_code={parsed.status_code}, status_type="
                f"{parsed.status_type!r})."
            )
        record_xml = extract_record_xml(parsed)
        record = parse_record(record_xml)
        return record  # type: ignore[return-value]

    async def status_lookup(
        self,
        token: str,
        *,
        page_number: int | None = None,
        page_size: int | None = None,
    ) -> ParsedResponse:
        """Fetch the current status of an async operation token.

        Async mirror of :meth:`Client.status_lookup`. Used internally
        by :class:`AsyncToken.poll`; also available as a low-level
        entry point for callers inspecting a token directly.
        Pagination kwargs switch to the POST path (Java parity with
        ``statusLookupViaToken(..., pageNumber, pageSize)``).

        Args:
            token: The registry-issued token string.
            page_number: Optional 1-indexed page number; switches
                to the POST path.
            page_size: Optional page size; switches to the POST path.

        Returns:
            The :class:`ParsedResponse` envelope carrying the current
            status and any per-operation status children.
        """
        if not token or not isinstance(token, str):
            raise ValueError(f"token must be a non-empty string, got {token!r}")

        if page_number is None and page_size is None:
            resource_path = f"/status/{token}"
            body = await self._transport.get(resource_path)
            return parse_response(body, operation=f"status_lookup {token}")

        body_xml = build_status_request(
            token=token,
            page_number=page_number if page_number is not None else 1,
            page_size=page_size if page_size is not None else 20,
        )
        body = await self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup {token}")

    async def status_lookup_by_user(
        self,
        user_id: str,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """List recent operations submitted by a user. See :meth:`Client.status_lookup_by_user`."""
        user_id = coerce_id_to_str(user_id, param_name="user_id")
        body_xml = build_status_request(
            user_id=user_id,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = await self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup_by_user {user_id}")

    async def status_lookup_by_registrant(
        self,
        registrant: str,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """List ops by registrant. See :meth:`Client.status_lookup_by_registrant`."""
        registrant = coerce_id_to_str(registrant, param_name="registrant")
        body_xml = build_status_request(
            registrant=registrant,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = await self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup_by_registrant {registrant}")

    async def status_lookup_superparty(
        self,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """Superparty-only status lookup. See :meth:`Client.status_lookup_superparty`."""
        body_xml = build_status_request(
            superparty=True,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = await self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation="status_lookup_superparty")

    async def iter_status_by_user(
        self,
        user_id: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> AsyncIterator[OperationStatusEntry]:
        """Async iterator over status-lookup entries for a user.

        See :meth:`Client.iter_status_by_user` for argument semantics.
        Same contract; async-iteration variant for use with
        ``async for``.
        """
        yielded = 0
        page_number = 1
        while True:
            response = await self.status_lookup_by_user(
                user_id,
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    async def iter_status_by_registrant(
        self,
        registrant: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> AsyncIterator[OperationStatusEntry]:
        """Async iterator over status-lookup entries for a registrant.

        See :meth:`Client.iter_status_by_registrant` for semantics.
        """
        yielded = 0
        page_number = 1
        while True:
            response = await self.status_lookup_by_registrant(
                registrant,
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    async def iter_status_superparty(
        self,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> AsyncIterator[OperationStatusEntry]:
        """Async iterator (Superparty-only) over recent operations.

        See :meth:`Client.iter_status_superparty` for semantics.
        """
        yielded = 0
        page_number = 1
        while True:
            response = await self.status_lookup_superparty(
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    async def iter_status_by_token(
        self,
        token: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
    ) -> AsyncIterator[OperationStatusEntry]:
        """Async iterator over operation-status entries for a token.

        See :meth:`Client.iter_status_by_token` for argument
        semantics. Same contract; async-iteration variant for use
        with ``async for``.
        """
        if not token or not isinstance(token, str):
            raise ValueError(f"token must be a non-empty string, got {token!r}")

        yielded = 0
        page_number = 1
        while True:
            response = await self.status_lookup(
                token,
                page_number=page_number,
                page_size=page_size,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    async def modification_base(
        self,
        asset_id: str,
        *,
        creation_type: CreationType,
    ) -> ContentRecord:
        """Fetch a modification-base record. See :meth:`Client.modification_base`."""
        from eidr.errors import EIDRProtocolError
        from eidr.models.content import ContentRecord

        asset_id = coerce_id_to_str(asset_id, param_name="asset_id")
        type_param = f"Create{creation_type.value}"
        body = await self._transport.get(
            f"/object/modificationbase/{asset_id}",
            params={"type": type_param},
        )
        parsed = parse_response(body, operation=f"modification_base {asset_id}")
        if parsed.kind == "record":
            return ContentRecord.from_xml(body)
        record_xml = _extract_first_non_status_child(parsed.root)
        if record_xml is None:
            raise EIDRProtocolError(
                f"modification_base returned a Code 0 envelope with "
                f"no record content (status_code={parsed.status_code}, "
                f"status_type={parsed.status_type!r}). The registry "
                f"is expected to return either a bare record body "
                f"or an envelope wrapping the record alongside Status."
            )
        record = ContentRecord.from_xml(record_xml)
        # See Client.modification_base for why we inject the ID.
        if record.base.get("ID") is None:
            record.base["ID"] = asset_id
        return record

    # ─── write operations ───────────────────────────────────────────────

    async def register(
        self,
        record: ContentRecord,
        *,
        immediate: bool = False,
        dedupe_mode: DedupeMode | None = None,
        wait_timeout: float | None = None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> AsyncToken | ContentRecord:
        """Register a new Content record.

        Async mirror of :meth:`Client.register`. Same sync-under-load
        fallback applies (REST API §2.1.1): an ``immediate=True``
        call may return an :class:`AsyncToken` if the registry
        defers to async processing under load.

        See :meth:`Client.register` for full semantics including the
        opt-in pre-submission pipeline (``validate`` / ``normalize`` /
        ``strip_empty``).
        """
        return await self._create_or_match(
            record,
            resource_path="/register/",
            op_name="register",
            immediate=immediate,
            dedupe_mode=dedupe_mode,
            wait_timeout=wait_timeout,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode="create",
        )

    async def match(
        self,
        record: ContentRecord,
        *,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> ContentRecord | AsyncToken:
        """Dry-run dedupe check against a Content record.

        Async mirror of :meth:`Client.match`. Always immediate; the
        sync-under-load fallback does not apply to Match per EIDR
        REST API. The returned record is the registry's dedupe
        candidate, not the caller's submission — see
        :meth:`Client.match` for the full distinction.
        """
        return await self._create_or_match(
            record,
            resource_path="/match/",
            op_name="match",
            immediate=True,
            dedupe_mode=None,
            wait_timeout=None,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode=None,
        )

    async def _create_or_match(
        self,
        record: ContentRecord,
        *,
        resource_path: str,
        op_name: str,
        immediate: bool,
        dedupe_mode: DedupeMode | None,
        wait_timeout: float | None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
        submission_mode: str | None = None,
    ) -> AsyncToken | ContentRecord:
        """Shared submit path for :meth:`register` and :meth:`match`.

        Applies the optional pre-submission pipeline by delegating
        to :func:`eidr.client._client._apply_pre_submission_pipeline` —
        the function is shared between sync and async clients (the
        pipeline itself doesn't do any I/O).
        """
        from eidr.client._client import _apply_pre_submission_pipeline

        record = _apply_pre_submission_pipeline(
            record,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode=submission_mode,
        )
        creation_type = record.creation_type
        record_xml = record.to_xml(xml_declaration=False)
        inner = build_create(record_xml, creation_type)

        result = await self._submit_write(
            resource_path=resource_path,
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=[dedupe_mode] if dedupe_mode is not None else None,
            wait_timeout=wait_timeout,
            operation_desc=f"{op_name} Content",
        )
        if result is None:
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"{op_name} succeeded but the registry returned "
                f"neither a record nor a token. Consider enabling "
                f"tracing to inspect the response."
            )
        return result

    async def modification_base_auto(self, asset_id: str) -> ContentRecord:
        """Async mirror of :meth:`Client.modification_base_auto`."""
        from eidr.errors import EIDRClientError
        from eidr.models.content import ContentRecord

        record = await self.resolve(asset_id)
        if not isinstance(record, ContentRecord):
            raise EIDRClientError(
                f"{asset_id} resolved to a {type(record).__name__}, not a "
                "ContentRecord. modification_base_auto only supports content "
                "records (Party and Service records have separate workflows)."
            )
        if record.alias_continuation is not None:
            raise EIDRClientError(
                f"{asset_id} is an Alias record (carries <AliasContinuation>); "
                "alias records are not modifiable. Aliases are handled by "
                "the Alias operation, not Modify."
            )
        return await self.modification_base(asset_id, creation_type=record.creation_type)

    async def modify(
        self,
        record: ContentRecord,
        *,
        immediate: bool = False,
        dedupe_mode: DedupeMode | None = None,
        wait_timeout: float | None = None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> AsyncToken | ContentRecord:
        """Modify an existing Content record.

        Async mirror of :meth:`Client.modify`. Requires
        ``record.id``. Same sync-under-load fallback as
        :meth:`register`. Same opt-in pre-submission pipeline.
        """
        from eidr.client._client import _apply_pre_submission_pipeline

        eidr_id = record.id
        if eidr_id is None:
            raise ValueError(
                "modify() requires record.id to be set; Modify operations "
                "cannot target an unidentified record."
            )
        record = _apply_pre_submission_pipeline(
            record,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode="modify",
        )
        creation_type = record.creation_type
        record_xml = record.to_xml(xml_declaration=False)
        inner = build_modify(record_xml, str(eidr_id), creation_type)
        result = await self._submit_write(
            resource_path="/modify/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=[dedupe_mode] if dedupe_mode is not None else None,
            wait_timeout=wait_timeout,
            operation_desc=f"modify {eidr_id}",
        )
        if result is None:
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"modify {eidr_id} succeeded but the registry returned "
                f"neither a record nor a token. Enable tracing for details."
            )
        return result

    async def delete(
        self,
        eidr_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Delete (alias-to-tombstone) a Content record.

        Async mirror of :meth:`Client.delete`. Returns ``None`` on
        immediate success (no body to echo), or an :class:`AsyncToken`
        for async polling.
        """
        inner = build_delete(eidr_id)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"delete {eidr_id}",
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    async def promote(
        self,
        eidr_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Promote an InDev record to Valid status.

        Async mirror of :meth:`Client.promote`.
        """
        inner = build_promote(eidr_id)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"promote {eidr_id}",
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    async def alias(
        self,
        source_id: str,
        target_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Alias one record to another.

        Async mirror of :meth:`Client.alias`.
        """
        inner = build_alias(source_id, target_id)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"alias {source_id} -> {target_id}",
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    async def add_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        info_xml: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Add a lightweight relationship to a record.

        Async mirror of :meth:`Client.add_relationship`.
        """
        inner = build_add_relationship(source_id, relationship_type, info_xml)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=(f"add_relationship {relationship_type.value} on {source_id}"),
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    async def remove_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Remove all lightweight relationships of a given type.

        Async mirror of :meth:`Client.remove_relationship`.
        """
        inner = build_remove_relationship(source_id, relationship_type)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=(f"remove_relationship {relationship_type.value} on {source_id}"),
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    async def replace_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        info_xml: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> AsyncToken | None:
        """Atomically replace all relationships of a given type.

        Async mirror of :meth:`Client.replace_relationship`.
        """
        inner = build_replace_relationship(source_id, relationship_type, info_xml)
        result = await self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=(f"replace_relationship {relationship_type.value} on {source_id}"),
        )
        if isinstance(result, AsyncToken):
            return result
        return None

    # ─── query operations ───────────────────────────────────────────────

    async def query(
        self,
        expression: str,
        *,
        page_number: int = 1,
        page_size: int = 25,
        id_only: bool = False,
    ) -> QueryResults:
        """Run a content-registry query.

        Async mirror of :meth:`Client.query`. Returns a
        :class:`QueryResults` carrying the same pagination metadata
        and records as its sync counterpart.
        """
        inner = build_query(expression, page_number=page_number, page_size=page_size)
        envelope = build_request_envelope([inner])
        resource_path = "/query/?type=ID" if id_only else "/query/"
        body = await self._transport.post(
            resource_path, envelope, immediate=True, requires_writable=False
        )
        parsed = parse_response(body, operation="query")
        return parse_query_results(parsed, page_number=page_number, page_size=page_size)

    async def iter_query(
        self,
        expression: str,
        *,
        page_size: int = 25,
        max_results: int | None = None,
    ) -> AsyncIterator[ContentRecord]:
        """Async iterator over full-metadata query results.

        See :meth:`Client.iter_query` for argument semantics.
        """
        yielded = 0
        page_number = 1
        while True:
            results = await self.query(
                expression,
                page_number=page_number,
                page_size=page_size,
                id_only=False,
            )
            if not results.records:
                return
            for record in results.records:
                yield record
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if not results.has_more_pages:
                return
            page_number += 1

    async def iter_query_ids(
        self,
        expression: str,
        *,
        page_size: int = 25,
        max_results: int | None = None,
    ) -> AsyncIterator[str]:
        """Async iterator over ID-only query results.

        See :meth:`Client.iter_query_ids` for argument semantics.
        """
        yielded = 0
        page_number = 1
        while True:
            results = await self.query(
                expression,
                page_number=page_number,
                page_size=page_size,
                id_only=True,
            )
            if not results.ids:
                return
            for id_str in results.ids:
                yield id_str
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if not results.has_more_pages:
                return
            page_number += 1

    async def graph_traversal(
        self,
        operation: GraphTraversalType,
        eidr_id: str,
        *,
        referent_type_filter: str | None = None,
        structural_type_filter: str | None = None,
        relationship_type_filter: str | None = None,
    ) -> QueryResults:
        """Walk the EIDR graph relative to a given record.

        Async mirror of :meth:`Client.graph_traversal`.
        """
        inner = build_graph_traversal(
            operation,
            eidr_id,
            referent_type_filter=referent_type_filter,
            structural_type_filter=structural_type_filter,
            relationship_type_filter=relationship_type_filter,
        )
        envelope = build_request_envelope([inner])
        body = await self._transport.post(
            "/object/graph/", envelope, immediate=True, requires_writable=False
        )
        parsed = parse_response(body, operation=f"graph_traversal {operation.value} {eidr_id}")
        return parse_query_results(parsed)

    async def party_query(
        self,
        query_xml: str,
        *,
        full: bool = False,
    ) -> ParsedResponse:
        """Query the Party registry. See :meth:`Client.party_query`."""
        if not query_xml or not query_xml.strip():
            raise ValueError("query_xml must not be empty")
        params = {"type": "full"} if full else None
        body = await self._transport.post(
            "/party/query/",
            query_xml,
            immediate=True,
            requires_writable=False,
            params=params,
        )
        return parse_response(body, operation="party_query")

    async def service_query(
        self,
        query_xml: str,
        *,
        full: bool = False,
    ) -> ParsedResponse:
        """Query the Video Service registry. See :meth:`Client.service_query`."""
        if not query_xml or not query_xml.strip():
            raise ValueError("query_xml must not be empty")
        params = {"type": "full"} if full else None
        body = await self._transport.post(
            "/service/query/",
            query_xml,
            immediate=True,
            requires_writable=False,
            params=params,
        )
        return parse_response(body, operation="service_query")

    # ─── Typed query helpers (M11-B) ─────────────────────────────────────

    async def find_parties_by_name(
        self,
        party_name: str,
        *,
        include_alt_names: bool = True,
        role_filter: str | None = None,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> PartyQueryResults:
        """Find Parties matching a name. See :meth:`Client.find_parties_by_name`."""
        body_xml = build_find_parties_by_name(
            party_name=party_name,
            include_alt_names=include_alt_names,
            role_filter=role_filter,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = await self.party_query(body_xml, full=full)
        return PartyQueryResults.from_response(response)

    async def find_parties_from_catalog(
        self,
        party_name: str,
        *,
        role_filter: str | None = None,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> PartyQueryResults:
        """Find catalog Parties. See :meth:`Client.find_parties_from_catalog`."""
        body_xml = build_find_parties_from_catalog(
            party_name=party_name,
            role_filter=role_filter,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = await self.party_query(body_xml, full=full)
        return PartyQueryResults.from_response(response)

    async def find_services_by_name(
        self,
        service_name: str,
        *,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> ServiceQueryResults:
        """Find Services by name. See :meth:`Client.find_services_by_name`."""
        body_xml = build_find_services_by_name(
            service_name=service_name,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = await self.service_query(body_xml, full=full)
        return ServiceQueryResults.from_response(response)

    async def find_services_from_catalog(
        self,
        service_name: str,
        *,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> ServiceQueryResults:
        """Find catalog Services. See :meth:`Client.find_services_from_catalog`."""
        body_xml = build_find_services_from_catalog(
            service_name=service_name,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = await self.service_query(body_xml, full=full)
        return ServiceQueryResults.from_response(response)

    # ─── Party / Video Service write operations ─────────────────────────
    #
    # Async mirror of :class:`Client`'s Party/Service writes — see
    # the sync class for full design notes and the wire-shape
    # rationale (asymmetric Create/Modify wrapper element names,
    # bare-element body without ``<Operations>`` envelope).

    async def create_service(
        self,
        record: ServiceRecord,
        *,
        wait_timeout: float | None = None,
    ) -> ServiceRecord | AsyncToken | None:
        """Create a new Video Service record. See :meth:`Client.create_service`."""
        body_xml = build_create_service_body(record.to_xml())
        return cast(
            "ServiceRecord | AsyncToken | None",
            await self._submit_admin(
                resource_path="/service/create/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"create_service {record.id or '<new>'}",
                record_kind="service",
            ),
        )

    async def modify_service(
        self,
        record: ServiceRecord,
        *,
        wait_timeout: float | None = None,
    ) -> ServiceRecord | AsyncToken | None:
        """Modify a Video Service record. See :meth:`Client.modify_service`."""
        if not record.id:
            raise ValueError(
                "modify_service requires record.id to be set; "
                "the registry needs to know which service to modify."
            )
        body_xml = build_modify_service_body(record.to_xml())
        return cast(
            "ServiceRecord | AsyncToken | None",
            await self._submit_admin(
                resource_path="/service/modify/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"modify_service {record.id}",
                record_kind="service",
            ),
        )

    async def delete_service(self, service_id: str) -> None:
        """Delete a Video Service. See :meth:`Client.delete_service`."""
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        await self._transport.post(f"/service/delete/{service_id}", "", immediate=True)

    async def alias_service(self, source_id: str, target_id: str) -> None:
        """Alias a service to another. See :meth:`Client.alias_service`."""
        source_id = coerce_id_to_str(source_id, param_name="source_id")
        target_id = coerce_id_to_str(target_id, param_name="target_id")
        await self._transport.post(
            f"/service/alias/{source_id}",
            "",
            immediate=True,
            params={"target": target_id},
        )

    async def set_service_parent(self, service_id: str, parent_id: str) -> None:
        """Set a service's parent. See :meth:`Client.set_service_parent`."""
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        parent_id = coerce_id_to_str(parent_id, param_name="parent_id")
        await self._transport.post(
            f"/service/parent/{service_id}",
            "",
            immediate=True,
            params={"parent": parent_id},
        )

    async def service_children(
        self,
        service_id: str,
        *,
        include_inactive: bool = False,
    ) -> ServiceChildrenResults:
        """List a service's children. See :meth:`Client.service_children`."""
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        body = await self._transport.get(
            f"/service/children/{service_id}",
            params={"all": "true" if include_inactive else "false"},
        )
        parsed = parse_response(body, operation=f"service_children {service_id}")
        return ServiceChildrenResults.from_response(parsed, service_id=service_id)

    async def service_parent(self, service_id: str) -> ServiceRecord | None:
        """Return a service's parent, or ``None``. See :meth:`Client.service_parent`."""
        from eidr.errors import EIDRNotFoundError
        from eidr.models.service import ServiceRecord

        service_id = coerce_id_to_str(service_id, param_name="service_id")
        body = await self._transport.get(f"/service/parent/{service_id}")
        try:
            parsed = parse_response(body, operation=f"service_parent {service_id}")
        except EIDRNotFoundError as exc:
            # See Client.service_parent for the disambiguation logic.
            details = (getattr(exc, "details", None) or "").lower()
            if "parent" in details or details == "":
                return None
            if service_id.lower() in details:
                raise
            raise
        if parsed.kind == "record":
            return ServiceRecord.from_xml(body)
        return None

    async def create_party(
        self,
        record: PartyRecord,
        password: str,
        *,
        wait_timeout: float | None = None,
    ) -> PartyRecord | AsyncToken | None:
        """Create a Party. See :meth:`Client.create_party`."""
        self._check_superparty_gate("create_party")
        if not password:
            raise ValueError("password must be non-empty")
        body_xml = embed_party_password(record.to_xml(), password)
        body_xml = build_create_party_body(body_xml)
        return cast(
            "PartyRecord | AsyncToken | None",
            await self._submit_admin(
                resource_path="/party/create/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"create_party {record.id or '<new>'}",
                record_kind="party",
            ),
        )

    async def modify_party(
        self,
        record: PartyRecord,
        *,
        wait_timeout: float | None = None,
    ) -> PartyRecord | AsyncToken | None:
        """Modify a Party. See :meth:`Client.modify_party`."""
        self._check_superparty_gate("modify_party")
        if not record.id:
            raise ValueError(
                "modify_party requires record.id to be set; "
                "the registry needs to know which party to modify."
            )
        body_xml = build_modify_party_body(record.to_xml())
        return cast(
            "PartyRecord | AsyncToken | None",
            await self._submit_admin(
                resource_path="/party/modify/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"modify_party {record.id}",
                record_kind="party",
            ),
        )

    async def delete_party(self, party_id: str) -> None:
        """Delete a Party. See :meth:`Client.delete_party`."""
        self._check_superparty_gate("delete_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        await self._transport.post(f"/party/delete/{party_id}", "", immediate=True)

    async def alias_party(self, source_id: str, target_id: str) -> None:
        """Alias a party. See :meth:`Client.alias_party`."""
        self._check_superparty_gate("alias_party")
        source_id = coerce_id_to_str(source_id, param_name="source_id")
        target_id = coerce_id_to_str(target_id, param_name="target_id")
        await self._transport.post(
            f"/party/alias/{source_id}",
            "",
            immediate=True,
            params={"target": target_id},
        )

    async def activate_party(self, party_id: str) -> None:
        """Activate a Party. See :meth:`Client.activate_party`."""
        self._check_superparty_gate("activate_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        await self._transport.post(f"/party/activate/{party_id}", "", immediate=True)

    async def deactivate_party(self, party_id: str) -> None:
        """Deactivate a Party. See :meth:`Client.deactivate_party`."""
        self._check_superparty_gate("deactivate_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        await self._transport.post(f"/party/deactivate/{party_id}", "", immediate=True)

    async def change_party_password(self, party_id: str, new_password: str) -> None:
        """Change a Party password. See :meth:`Client.change_party_password`."""
        self._check_superparty_gate("change_party_password")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        if not new_password:
            raise ValueError("new_password must be non-empty")
        await self._transport.post(
            f"/party/password/{party_id}",
            "",
            immediate=True,
            params={"password": new_password},
        )

    # ─── Virtual fields retrieval ───────────────────────────────────────

    async def virtual_fields(self, asset_id: str) -> VirtualFields:
        """Retrieve a record's virtual fields. See :meth:`Client.virtual_fields`."""
        asset_id = coerce_id_to_str(asset_id, param_name="asset_id")
        body = await self._transport.get(
            f"/virtual/object/{asset_id}",
        )
        from eidr.codecs import xml as xml_codec
        from eidr.errors import EIDRProtocolError
        from eidr.models.virtual import VirtualFields

        parsed = parse_response(body, operation=f"virtual_fields {asset_id}")
        if not parsed.raw_body:
            raise EIDRProtocolError(f"virtual_fields {asset_id}: response had no XML body")
        codec = xml_codec.to_codec_dict(parsed.raw_body.encode("utf-8"))
        response_body = next(iter(codec.values())) if codec else {}
        vf_dict = response_body.get("VirtualFields") if isinstance(response_body, dict) else None
        if isinstance(vf_dict, list):
            vf_dict = vf_dict[0] if vf_dict else None
        if not isinstance(vf_dict, dict):
            raise EIDRProtocolError(
                f"virtual_fields {asset_id}: response did not contain a <VirtualFields> element"
            )
        return VirtualFields.from_codec_dict(vf_dict)

    # ─── internal: party / service admin submit helper ──────────────────

    async def _submit_admin(
        self,
        *,
        resource_path: str,
        body_xml: str,
        wait_timeout: float | None,
        operation_desc: str,
        record_kind: str,
    ) -> ServiceRecord | PartyRecord | AsyncToken | None:
        """Async mirror of :meth:`Client._submit_admin`."""
        body = await self._transport.post(resource_path, body_xml, immediate=True)
        parsed = parse_response(body, operation=operation_desc)

        # Look for an inline record body in either response shape
        # (bare root or envelope-wrapped). See sync _submit_admin
        # for the full rationale.
        expected_root = "Service" if record_kind == "service" else "Party"
        record_xml = extract_inline_record_xml(parsed, expected_root)
        if record_xml is not None:
            if record_kind == "service":
                from eidr.models.service import ServiceRecord

                return ServiceRecord.from_codec_dict(xml_to_record_codec_dict(record_xml))
            from eidr.models.party import PartyRecord

            return PartyRecord.from_codec_dict(xml_to_record_codec_dict(record_xml))

        # ID-in-Details success shape — see sync _submit_admin for
        # the rationale and the live-sandbox verification.
        new_id = extract_status_details(parsed)
        if new_id is not None and new_id.startswith("10."):
            from eidr.models.party import PartyRecord
            from eidr.models.service import ServiceRecord

            resolved = await self.resolve(new_id)
            if record_kind == "service" and isinstance(resolved, ServiceRecord):
                return resolved
            if record_kind == "party" and isinstance(resolved, PartyRecord):
                return resolved
            if record_kind == "service":
                return ServiceRecord.from_codec_dict({"Service": {"ID": new_id}})
            return PartyRecord.from_codec_dict({"Party": {"ID": new_id}})

        token_value = extract_token(parsed)
        if token_value is None:
            return None

        tok = AsyncToken(value=token_value, _client=self)
        tok.last_response = parsed

        if wait_timeout is None:
            return tok

        await tok.wait(timeout=wait_timeout)
        return tok

    # ─── internal: submit, optionally poll ──────────────────────────────

    async def _submit_write(
        self,
        *,
        resource_path: str,
        operations_xml: list[str],
        immediate: bool,
        dedupe_modes: list[DedupeMode | None] | None,
        wait_timeout: float | None,
        operation_desc: str,
    ) -> AsyncToken | ContentRecord | None:
        """Common write-submit path shared by all write methods.

        Async mirror of :meth:`Client._submit_write`. Same return
        conventions: :class:`ContentRecord` for inline record
        results, :class:`AsyncToken` for pending/async, ``None``
        for bare success envelopes (delete/promote/alias-class).
        """
        envelope = build_request_envelope(operations_xml, dedupe_modes=dedupe_modes)
        body = await self._transport.post(
            resource_path,
            envelope,
            immediate=immediate,
        )
        parsed = parse_response(body, operation=operation_desc)

        if parsed.kind == "record":
            return parse_record(extract_record_xml(parsed))  # type: ignore[return-value]

        # Operation-level error check — see sync _submit_write.
        raise_for_operation_status(parsed, operation=operation_desc)

        # Match-result fast path — see sync _submit_write for the
        # full rationale and the verified live-sandbox response shape.
        duplicate_id = extract_duplicate_id(parsed)
        if duplicate_id is not None and duplicate_id.startswith("10."):
            from eidr.models.content import ContentRecord

            resolved = await self.resolve(duplicate_id)
            if isinstance(resolved, ContentRecord):
                return resolved

        token_value = extract_token(parsed)
        if token_value is not None:
            tok = AsyncToken(value=token_value, _client=self)
            tok.last_response = parsed

            if wait_timeout is None:
                return tok

            from eidr.errors import EIDRTimeoutError

            try:
                status = await tok.wait(timeout=wait_timeout)
            except EIDRTimeoutError:
                return tok

            if status is TokenStatus.SUCCESS:
                final = tok.last_response
                if final is not None and final.kind == "record":
                    return parse_record(extract_record_xml(final))  # type: ignore[return-value]
            return tok

        # ID-in-Details success shape — see sync _submit_write for
        # the rationale and the live-sandbox verification.
        new_id = extract_status_details(parsed)
        if new_id is not None and new_id.startswith("10."):
            from eidr.models.content import ContentRecord

            resolved = await self.resolve(new_id)
            if isinstance(resolved, ContentRecord):
                return resolved

        return None


# ─── helpers ────────────────────────────────────────────────────────────
#
# Shared client-internal helpers (e.g., :func:`resolve_resource_path`)
# live in :mod:`eidr.client._shared`. This module imports them above
# and uses them directly.
