"""Query-response parsing for the EIDR REST API.

Query and graph-traversal endpoints return a ``<Response>`` envelope
whose body contains a ``<QueryResults>`` element with pagination
metadata and zero or more ``<SimpleMetadata>`` or ``<ID>`` children
(depending on whether the query requested full-metadata or ID-only
output).

This module provides :class:`QueryResults`, a frozen dataclass that
captures the pagination state plus the parsed records or ID strings.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from eidr.client._response import ParsedResponse
from eidr.errors import EIDRProtocolError

if TYPE_CHECKING:
    from eidr.models.content import ContentRecord


__all__ = ["QueryResults", "parse_query_results"]


#: EIDR namespace URI; used for all XPath lookups against response bodies.
_EIDR_NS = {"eidr": "http://www.eidr.org/schema"}


@dataclass(frozen=True, slots=True)
class QueryResults:
    """Results of a query or graph-traversal call.

    Attributes:
        current_size: Number of result items on this page.
        total_matches: Total number of results across all pages for
            this query. Compare against ``page_number * page_size``
            to decide whether more pages remain.
        page_number: 1-indexed page number this result set
            represents. ``None`` for graph-traversal results, which
            don't paginate.
        page_size: Records-per-page requested. ``None`` for graph
            traversal.
        continuation_token: When present, an opaque token that the
            registry returned to continue a result set too large for
            normal pagination. Currently not used by this SDK but
            captured for callers who want to talk to the registry
            directly.
        records: For full-metadata queries, the
            :class:`~eidr.models.content.ContentRecord` instances
            parsed from the ``<SimpleMetadata>`` children. Empty for
            ID-only queries.
        ids: For ID-only queries (``?type=ID``), the EIDR ID strings
            parsed from the ``<ID>`` children. Empty for full-metadata
            queries.

    A given :class:`QueryResults` will populate either :attr:`records`
    or :attr:`ids` but not both — the registry returns one or the
    other based on the query flavor. Callers generally know which
    they asked for and can index accordingly.
    """

    current_size: int
    total_matches: int
    page_number: int | None = None
    page_size: int | None = None
    continuation_token: str | None = None
    records: list[ContentRecord] = field(default_factory=list)
    ids: list[str] = field(default_factory=list)

    @property
    def has_more_pages(self) -> bool:
        """``True`` when cumulative items fetched so far < ``total_matches``.

        Uses ``page_number * page_size`` as the cumulative count —
        accurate on the last page (when ``current_size`` can be less
        than ``page_size``) unlike a ``current_size < total_matches``
        comparison.

        Returns ``False`` when pagination context isn't available
        (graph-traversal results) — callers who need a more nuanced
        answer there can compute it from :attr:`total_matches`
        directly.
        """
        if self.page_number is None or self.page_size is None:
            return False
        cumulative = self.page_number * self.page_size
        return cumulative < self.total_matches


def parse_query_results(
    parsed: ParsedResponse,
    *,
    page_number: int | None = None,
    page_size: int | None = None,
) -> QueryResults:
    """Extract a :class:`QueryResults` from a parsed response envelope.

    Expects ``parsed`` to be an envelope (``kind == "envelope"``)
    with a ``<QueryResults>`` child element. Raises
    :class:`EIDRProtocolError` if that shape isn't present —
    failures and empty result sets are distinguished (an empty
    result set has ``<QueryResults>`` with ``<CurrentSize>0``).

    Args:
        parsed: A :class:`~eidr.client._response.ParsedResponse`
            from a ``query``/``graph_traversal``/``party_query``/
            ``service_query`` call.
        page_number: The 1-indexed page the caller requested. Stored
            on the result so :attr:`QueryResults.has_more_pages` can
            compute correctly on the last page. Omit for
            graph-traversal responses.
        page_size: Records-per-page the caller requested. Omit for
            graph-traversal responses.

    Returns:
        The populated :class:`QueryResults`.

    Raises:
        EIDRProtocolError: When the envelope doesn't contain a
            ``<QueryResults>`` element — an unexpected response shape.
    """
    # Import here to avoid a circular-import trap (eidr.models →
    # eidr.codecs → eidr.errors which doesn't pull client, so fine,
    # but we also need ContentRecord only when there's at least one
    # SimpleMetadata child; importing eagerly is also fine but keeps
    # the module free of model dependencies at import time).
    from eidr.models.content import ContentRecord

    qr = parsed.root.find("eidr:QueryResults", _EIDR_NS)
    if qr is None:
        raise EIDRProtocolError(
            "Expected a <QueryResults> element in the response envelope, "
            "but none was found. This may indicate the endpoint returned "
            "a non-query response shape; enable tracing to inspect the "
            "raw body."
        )

    current_size = _int_child(qr, "CurrentSize", default=0)
    total_matches = _int_child(qr, "TotalMatches", default=0)

    cont_token_elem = qr.find("eidr:ContinuationToken", _EIDR_NS)
    continuation_token = (
        cont_token_elem.text.strip()
        if cont_token_elem is not None and cont_token_elem.text
        else None
    )

    records: list[ContentRecord] = []
    ids: list[str] = []

    # Walk children in document order. Queries return EITHER
    # SimpleMetadata or ID elements, not both, so these two loops
    # produce disjoint outputs.
    for child in qr:
        from lxml import etree as _etree

        local = _etree.QName(child).localname
        if local == "SimpleMetadata":
            # SimpleMetadata has the same shape as a resolved SimpleMetadata
            # record; it parses through the usual ContentRecord path.
            xml_bytes = _etree.tostring(child, encoding="UTF-8")
            assert isinstance(xml_bytes, bytes)
            records.append(ContentRecord.from_xml(xml_bytes))
        elif local == "ID":
            if child.text:
                ids.append(str(child.text).strip())

    return QueryResults(
        current_size=current_size,
        total_matches=total_matches,
        page_number=page_number,
        page_size=page_size,
        continuation_token=continuation_token,
        records=records,
        ids=ids,
    )


def _int_child(parent: object, local_name: str, *, default: int) -> int:
    """Parse an integer-text child element, returning ``default`` on anything unexpected."""
    from lxml import etree as _etree

    # parent is an lxml element, but typing it precisely here would
    # require an lxml stubs import; use a structural check instead.
    if not isinstance(parent, _etree._Element):
        return default
    elem = parent.find(f"eidr:{local_name}", _EIDR_NS)
    if elem is None or not elem.text:
        return default
    try:
        return int(elem.text.strip())
    except ValueError:
        return default
