"""HTTP transport layer for the EIDR client.

Thin wrapper around :class:`httpx.Client` with EIDR-specific behaviors:

* **Multipart body framing.** EIDR POSTs use ``multipart/form-data`` with
  a fixed boundary (``314159``) and a single form field whose name varies
  by resource. Matches Java SDK's ``Post.preparePayload`` exactly.
* **EIDR sync/async flag.** The ``Immediate-Response`` HTTP header
  controls registry-side synchronous vs. async processing (not to be
  confused with Python's ``async/await``, which is a programming model
  distinction at the call site; the EIDR flag is an HTTP-level request
  parameter).
* **Retry semantics.** Automatic retry with exponential backoff for
  idempotent reads (GET). Writes (POST) are retried only for connection
  failures BEFORE the body is transmitted; once bytes have gone to the
  wire we raise :class:`EIDRUncertainWriteError` and let the caller
  decide what to do, because the registry may or may not have processed
  the request.
* **HTTP 200 always.** The registry returns 200 for virtually all
  application-level responses — success, failure, validation errors,
  auth errors, everything. The real status is inside the XML body.
  This layer returns the raw response text and the caller-supplied
  parser (see :mod:`eidr.client._response`) extracts the outcome.
* **Non-200 still means transport failure.** Gateway errors, timeouts,
  protocol-level malformations, etc. are mapped to the appropriate
  :class:`EIDRError` subclass.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

import httpx

from eidr.auth import make_auth_header
from eidr.client._tracing import TraceSink, make_trace_record
from eidr.errors import (
    EIDRAuthenticationError,
    EIDRHTTPStatusError,
    EIDRReadOnlyRegistryError,
    EIDRTimeoutError,
    EIDRTransportError,
    EIDRUncertainWriteError,
)

if TYPE_CHECKING:
    from eidr.credentials import Credentials
    from eidr.registries import Registry


_logger = logging.getLogger("eidr.client")

#: EIDR's fixed multipart boundary. Yes, really fixed — both the Java
#: SDK and the registry itself are hard-coded to this value.
_MULTIPART_BOUNDARY = "314159"

#: The EIDR API version this client self-identifies as. Sent as the
#: ``EIDR-Version`` header on every request. Matches what the Java
#: SDK declares.
_EIDR_API_VERSION = "2.7.1"

#: Multipart form-field name per resource URL-path. Mirrors the Java
#: SDK's ``Literals.getFileHeader(resource)`` map. Most resources use
#: ``"batch"``; a handful have specialized names.
_FORM_FIELD_NAME: dict[str, str] = {
    # Mirror of Java SDK's ``conf/Literals.java::lithash``. Only the
    # endpoints Java explicitly registers appear here; everything
    # else falls through to the ``"batch"`` default. We've
    # deliberately resisted adding inferred entries (e.g., a
    # ``"serviceCreate"`` for ``/service/create/``) — until verified
    # against a live registry, parity with Java is the safest
    # default. See the M9 reviewer feedback that flagged the
    # earlier inference as a parity-bug candidate.
    "/register/": "batch",
    "/modify/": "batch",
    "/match/": "batch",
    "/query/": "query",
    "/object/graph/": "graphrequest",
    "/status/": "statusrequest",
    "/party/query/": "partyQuery",
    "/party/create/": "party",
    "/party/modify/": "party",
    "/service/query/": "serviceQuery",
    "/service/delete/": "serviceDelete",
    "/service/modify/": "serviceModify",
    "/user/create/": "user",
}


def _form_field_name(resource_path: str) -> str:
    """Return the multipart form-field name for a resource path.

    Falls back to ``"batch"`` for unknown resources (matches the Java
    SDK's default).
    """
    # Strip trailing ID (for resources like "/object/{id}") and query
    # string before lookup.
    base = resource_path.split("?", 1)[0]
    if base in _FORM_FIELD_NAME:
        return _FORM_FIELD_NAME[base]
    # Try progressively shorter prefixes — ``/register/{id}`` → ``/register/``
    parts = base.rstrip("/").split("/")
    while parts:
        candidate = "/".join(parts) + "/"
        if candidate in _FORM_FIELD_NAME:
            return _FORM_FIELD_NAME[candidate]
        parts.pop()
    return "batch"


@dataclass(frozen=True, slots=True)
class TransportConfig:
    """Tunables for :class:`_Transport`.

    Defaults are conservative: 2 retries (3 total attempts) for reads
    with 1s/2s/4s backoff; 30-second read timeout; no proxy. Tracing
    knobs default to capturing full bodies up to a generous limit —
    see ``trace_max_body_chars`` and ``trace_redact_bodies`` if
    producing traces for external distribution.
    """

    connect_timeout: float = 10.0
    read_timeout: float = 30.0
    max_retries: int = 2  # Total attempts = max_retries + 1
    retry_backoff_base: float = 1.0  # First retry waits base; each subsequent doubles
    retry_backoff_max: float = 16.0
    verify_tls: bool = True
    httpx_transport: httpx.BaseTransport | None = None
    """Test hook: inject a custom **sync** httpx transport.

    Used by :class:`~eidr.client._http._Transport` (the sync
    transport powering :class:`~eidr.client.Client`). Must implement
    the sync :class:`httpx.BaseTransport` protocol. When ``None``
    (default), the sync client uses its normal network transport.

    For :class:`~eidr.client.AsyncClient`, set
    :attr:`async_httpx_transport` instead. A single
    :class:`httpx.MockTransport` instance can be assigned to both
    fields when sharing a mock between sync and async tests, since
    ``MockTransport`` inherits from both protocols."""

    async_httpx_transport: httpx.AsyncBaseTransport | None = None
    """Test hook: inject a custom **async** httpx transport.

    Used by :class:`~eidr.client._async_http._AsyncTransport` (the
    async transport powering :class:`~eidr.client.AsyncClient`).
    Must implement the async :class:`httpx.AsyncBaseTransport`
    protocol. When ``None`` (default), the async client uses its
    normal network transport.

    Splitting sync and async transports into separate fields gives
    ``mypy --strict`` enough information to flag a misconfiguration
    at type-check time rather than at runtime: passing a sync-only
    transport to :class:`AsyncClient` (or vice versa) is a static
    type error now, not a runtime ``TypeError`` produced by the
    transport's validator."""

    trace_max_body_chars: int | None = 100_000
    """Truncate request/response bodies in trace records to this many
    characters. ``None`` disables truncation. Default 100,000 is large
    enough for any single EIDR record but bounds the worst case (e.g.,
    an unexpectedly large bulk response). Ignored when
    ``trace_redact_bodies`` is ``True``."""

    trace_redact_bodies: bool = False
    """When ``True``, replace request/response bodies in trace records
    with a ``[REDACTED N chars]`` marker. Headers and status are still
    captured normally. Intended for "safe support bundle" mode when
    sharing traces with parties who should not see unpublished record
    content."""


def _build_multipart_body(form_field_name: str, xml_payload: str) -> bytes:
    """Construct the EIDR-shaped multipart/form-data body.

    Mirrors Java's ``PayloadTemplates.PAYLOAD_HEADER_FOOTER`` exactly:
    two boundary lines sandwiching one form part whose name matches
    the resource URL and whose content is the XML payload.
    """
    lines = [
        f"--{_MULTIPART_BOUNDARY}",
        f"Content-Disposition: form-data; name={form_field_name}",
        "Content-Transfer-Encoding: binary",
        "",
        xml_payload,
        f"--{_MULTIPART_BOUNDARY}",
    ]
    return "\r\n".join(lines).encode("utf-8")


class _Transport:
    """Sync HTTP transport for the EIDR REST API.

    Wraps an :class:`httpx.Client`. One Transport per :class:`Client`
    instance; both share lifecycle (close on exit).

    When a :class:`TraceSink` is provided, every HTTP round-trip —
    including retries and failures — emits a :class:`TraceRecord` to
    the sink. This is the support-diagnostics path: without a complete
    trace of what went over the wire, many user-reported issues are
    effectively impossible to debug remotely.
    """

    def __init__(
        self,
        registry: Registry,
        credentials: Credentials | None,
        config: TransportConfig | None = None,
        *,
        trace_sink: TraceSink | None = None,
    ) -> None:
        self._registry = registry
        self._credentials = credentials
        self._config = config or TransportConfig()
        self._trace_sink = trace_sink

        # Validate the injected transport (if any) is sync-compatible
        # before constructing httpx.Client. Belt-and-suspenders: the
        # field's declared type is sync-only, so static type checkers
        # already prevent the wrong assignment at the call site.
        _validate_sync_transport(self._config.httpx_transport)

        self._httpx = httpx.Client(
            timeout=httpx.Timeout(
                connect=self._config.connect_timeout,
                read=self._config.read_timeout,
                write=self._config.read_timeout,
                pool=self._config.connect_timeout,
            ),
            verify=self._config.verify_tls,
            transport=self._config.httpx_transport,
        )

    def close(self) -> None:
        self._httpx.close()

    def _emit_trace(
        self,
        *,
        method: str,
        url: str,
        request_headers: dict[str, str],
        request_body: str | bytes | None,
        response: httpx.Response | None,
        start_time: float,
        exception: BaseException | None,
        attempt: int,
    ) -> None:
        """Record one round-trip to the trace sink, if any.

        Called from both the GET and POST paths, once per attempt.
        Silently no-ops when ``_trace_sink`` is ``None``. Never raises
        — a broken sink must not impede the request path.
        """
        if self._trace_sink is None:
            return
        try:
            response_status = response.status_code if response is not None else None
            response_headers = dict(response.headers) if response is not None else None
            response_body = response.text if response is not None else None
            record = make_trace_record(
                method=method,
                url=url,
                request_headers=request_headers,
                request_body=request_body,
                response_status=response_status,
                response_headers=response_headers,
                response_body=response_body,
                start_time=start_time,
                exception=exception,
                attempt=attempt,
                max_body_chars=self._config.trace_max_body_chars,
                redact_bodies=self._config.trace_redact_bodies,
            )
            self._trace_sink.write(record)
        except Exception:
            pass

    # ─── request shape ──────────────────────────────────────────────────

    def _base_headers(self) -> dict[str, str]:
        """Headers common to all requests — auth and SDK identification."""
        headers = {
            "EIDR-Version": _EIDR_API_VERSION,
            "User-Agent": f"eidr-python-sdk/{_EIDR_API_VERSION}",
        }
        if self._credentials is not None:
            headers["Authorization"] = make_auth_header(
                user_id=self._credentials.user_id,
                party_id=self._credentials.party_id,
                password=self._credentials.password,
            )
        return headers

    def _full_url(self, resource_path: str) -> str:
        """Combine the registry base URL with a resource path."""
        base = self._registry.url.rstrip("/")
        # Resource paths in the Java SDK start with ``/``; tolerate
        # either form on our side.
        path = resource_path if resource_path.startswith("/") else "/" + resource_path
        return base + path

    # ─── read path (GET) ────────────────────────────────────────────────

    def get(
        self,
        resource_path: str,
        *,
        params: dict[str, str] | None = None,
    ) -> str:
        """Issue a GET request and return the response body as text.

        Retries idempotent failures (connection resets, 5xx) with
        exponential backoff up to :attr:`TransportConfig.max_retries`.
        Non-idempotent errors (4xx) are mapped immediately without
        retry. Every attempt — success, failure, or retry — emits one
        :class:`TraceRecord` to the configured sink.

        Args:
            resource_path: URL path component appended to the registry
                base URL.
            params: Optional query-string parameters. Passed to
                ``httpx.get(params=...)`` so values are URL-encoded
                correctly. Use this rather than embedding ``?key=value``
                in ``resource_path`` — the latter doesn't escape values
                that contain reserved characters.
        """
        url = self._full_url(resource_path)
        headers = self._base_headers()
        headers["Accept"] = "text/xml"

        last_exc: Exception | None = None
        for attempt in range(self._config.max_retries + 1):
            start_time = time.monotonic()
            try:
                response = self._httpx.get(url, headers=headers, params=params)
            except httpx.TimeoutException as exc:
                self._emit_trace(
                    method="GET",
                    url=url,
                    request_headers=headers,
                    request_body=None,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug("GET %s timeout (attempt %d)", url, attempt + 1)
                if attempt < self._config.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise EIDRTimeoutError(
                    f"Timed out after {attempt + 1} attempts: GET {url}"
                ) from exc
            except httpx.TransportError as exc:
                self._emit_trace(
                    method="GET",
                    url=url,
                    request_headers=headers,
                    request_body=None,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug("GET %s transport error (attempt %d): %s", url, attempt + 1, exc)
                if attempt < self._config.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise EIDRTransportError(
                    f"Transport error after {attempt + 1} attempts: GET {url}: {exc}"
                ) from exc

            # Got a response — emit trace before any further branching.
            self._emit_trace(
                method="GET",
                url=url,
                request_headers=headers,
                request_body=None,
                response=response,
                start_time=start_time,
                exception=None,
                attempt=attempt,
            )

            if response.status_code == 200:
                return response.text

            # Non-200: map to typed exception. 5xx is retryable; 4xx is not.
            if 500 <= response.status_code < 600 and attempt < self._config.max_retries:
                _logger.debug(
                    "GET %s returned %d (attempt %d); retrying",
                    url,
                    response.status_code,
                    attempt + 1,
                )
                self._sleep_backoff(attempt)
                continue
            self._raise_for_status(response, method="GET", url=url)

        # Should be unreachable — loop either returns or raises.
        raise EIDRTransportError(f"Exhausted retries: GET {url} — last error: {last_exc}")

    # ─── write path (POST) ──────────────────────────────────────────────

    def post(
        self,
        resource_path: str,
        xml_payload: str,
        *,
        immediate: bool,
        requires_writable: bool = True,
        params: dict[str, str] | None = None,
    ) -> str:
        """Issue a POST request with an EIDR-shaped multipart body.

        Pre-send connection failures are retried like GETs. Once the
        request body is on the wire, failures become
        :class:`EIDRUncertainWriteError` — the registry may or may not
        have processed the request, and the caller needs to decide how
        to reconcile (usually by querying for the resulting token or
        resource).

        Args:
            resource_path: URL path component appended to the registry
                base URL. e.g. ``"/register/"``, ``"/status/"``.
            xml_payload: The ``<Request>...</Request>`` XML body to
                wrap in the multipart envelope.
            immediate: Value of the ``Immediate-Response`` header,
                controlling the registry's sync/async behavior.
            requires_writable: When ``True`` (default), the call is
                refused against a read-only registry. Query-style
                POSTs (content query, graph traversal, party query,
                service query) pass ``False`` because they are
                semantic reads that happen to use the POST method.
            params: Optional query-string parameters. Use this rather
                than embedding ``?key=value`` in ``resource_path`` —
                the latter doesn't escape values that contain reserved
                characters and bypasses the trace's URL-redaction for
                sensitive parameter names like ``password``.

        Raises:
            EIDRReadOnlyRegistryError: When ``requires_writable`` is
                ``True`` and the registry is read-only.
            EIDRUncertainWriteError: When a transport error occurred
                after the body was transmitted.
            EIDRAuthenticationError, EIDRHTTPStatusError, etc.: For
                other HTTP-level failures.
        """
        if requires_writable and not self._registry.writable:
            raise EIDRReadOnlyRegistryError(
                f"Registry {self._registry.name!r} is read-only; POST to {resource_path} refused.",
                registry_name=self._registry.name,
                operation=resource_path,
            )

        url = self._full_url(resource_path)
        # Empty payload → send literal empty body (no multipart
        # wrapper). This matches Java's Post.java semantics: when
        # ``data == ""``, Java skips its ``preparePayload`` call and
        # transmits zero bytes (even though Content-Type still says
        # multipart). The URL-only operations (delete, alias,
        # activate, deactivate, set-parent, change-password) all
        # take their parameters in path/query and don't carry a
        # payload. Wrapping their empty body in multipart boundaries
        # is a wire-shape divergence from Java reported by M9
        # reviewers.
        if not xml_payload or not xml_payload.strip():
            body: bytes = b""
        else:
            body = _build_multipart_body(_form_field_name(resource_path), xml_payload)

        # The URL we capture in traces should match what would
        # actually be sent on the wire — i.e., include any query
        # parameters. We pre-compute it once here and use it as
        # the ``trace_url`` argument across all _emit_trace calls
        # in this request. Sensitive query values (e.g. password)
        # are redacted by the trace builder via redact_url_query.
        if params:
            from urllib.parse import urlencode

            trace_url = url + ("&" if "?" in url else "?") + urlencode(params)
        else:
            trace_url = url

        headers = self._base_headers()
        headers["Content-Type"] = f"multipart/form-data; boundary={_MULTIPART_BOUNDARY}"
        headers["Content-Length"] = str(len(body))
        headers["Immediate-Response"] = "true" if immediate else "false"

        last_exc: Exception | None = None
        for attempt in range(self._config.max_retries + 1):
            start_time = time.monotonic()
            try:
                response = self._httpx.post(url, headers=headers, content=body, params=params)
            except httpx.ConnectError as exc:
                # Connection failed before we sent anything — safe to retry.
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug("POST %s connect error (attempt %d): %s", url, attempt + 1, exc)
                if attempt < self._config.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise EIDRTransportError(
                    f"Could not connect after {attempt + 1} attempts: POST {url}: {exc}"
                ) from exc
            except httpx.TimeoutException as exc:
                # Timeout during write-or-read. Mid-send or after-send
                # failure: we don't know if the registry saw the request.
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                raise EIDRUncertainWriteError(
                    f"Timeout during POST {url}; the registry may or may "
                    f"not have processed the request. Check the registry "
                    f"state before retrying."
                ) from exc
            except httpx.TransportError as exc:
                # Generic transport failure. Could be mid-send (uncertain)
                # or pre-send (retryable). httpx doesn't distinguish, so
                # we assume mid-send to be safe — aborting an in-flight
                # write and retrying is worse than surfacing uncertainty.
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                raise EIDRUncertainWriteError(
                    f"Transport error during POST {url}; the registry "
                    f"may or may not have processed the request: {exc}"
                ) from exc

            # Got a response — emit trace before any further branching.
            self._emit_trace(
                method="POST",
                url=trace_url,
                request_headers=headers,
                request_body=body,
                response=response,
                start_time=start_time,
                exception=None,
                attempt=attempt,
            )

            if response.status_code == 200:
                return response.text

            # No POST 5xx auto-retry. Once the request body has been
            # transmitted (which happened above this branch for any
            # response we're now handling), a 5xx may indicate the
            # registry processed the request before failing — auto-
            # retrying could duplicate the operation. Java's
            # ``Post.java`` flips ``safetoretry = false`` the moment
            # body transmission begins; we adopt the same semantics.
            #
            # If the caller wants reconciliation guidance for "I got
            # a 5xx but don't know if the write took", the
            # :class:`EIDRUncertainWriteError` raised below is the
            # designated signal.
            if 500 <= response.status_code < 600:
                raise EIDRUncertainWriteError(
                    f"POST {url} returned {response.status_code}; "
                    f"the registry may or may not have processed "
                    f"the write. Body snippet: "
                    f"{(response.text or '')[:300]!r}"
                )
            self._raise_for_status(response, method="POST", url=url)

        raise EIDRTransportError(f"Exhausted retries: POST {url} — last error: {last_exc}")

    # ─── error mapping & backoff ────────────────────────────────────────

    @staticmethod
    def _raise_for_status(response: httpx.Response, *, method: str, url: str) -> None:
        """Map a non-200 response to the right :class:`EIDRError` subclass."""
        code = response.status_code
        body_snippet = (response.text or "")[:500]

        if code in (401, 403):
            raise EIDRAuthenticationError(
                f"{method} {url} returned HTTP {code}. "
                f"Check credentials and party role. Body: {body_snippet!r}"
            )
        raise EIDRHTTPStatusError(
            f"{method} {url} returned HTTP {code}. Body: {body_snippet!r}",
            status_code=code,
        )

    def _sleep_backoff(self, attempt: int) -> None:
        """Exponential backoff with a cap. ``attempt`` is 0-indexed."""
        delay = min(
            self._config.retry_backoff_base * (2**attempt),
            self._config.retry_backoff_max,
        )
        time.sleep(delay)


def _validate_sync_transport(
    transport: httpx.BaseTransport | None,
) -> None:
    """Reject an async-only transport passed to a sync client.

    The :attr:`TransportConfig.httpx_transport` field is typed
    sync-only, so static type checkers catch wrong assignments at
    the call site. This runtime check is belt-and-suspenders for
    callers using untyped code (e.g., loading a transport
    dynamically from a plugin) — it raises a precise
    :class:`TypeError` rather than failing deep inside httpx on
    first request.

    ``httpx.MockTransport`` and ``None`` both pass.
    """
    if transport is None:
        return
    if not isinstance(transport, httpx.BaseTransport):
        raise TypeError(
            f"Client was passed a transport of type "
            f"{type(transport).__name__!r}, which does not implement "
            f"httpx.BaseTransport. If this transport is async-only, "
            f"set TransportConfig.async_httpx_transport instead and "
            f"use AsyncClient. (MockTransport works for both.)"
        )


def _validate_async_transport(
    transport: httpx.AsyncBaseTransport | None,
) -> None:
    """Reject a sync-only transport passed to an async client.

    Mirror of :func:`_validate_sync_transport`. The
    :attr:`TransportConfig.async_httpx_transport` field is typed
    async-only, so static type checkers already catch wrong
    assignments at the call site. This runtime check is the
    belt-and-suspenders backstop for untyped code paths.
    """
    if transport is None:
        return
    if not isinstance(transport, httpx.AsyncBaseTransport):
        raise TypeError(
            f"AsyncClient was passed a transport of type "
            f"{type(transport).__name__!r}, which does not implement "
            f"httpx.AsyncBaseTransport. If this transport is sync-only, "
            f"set TransportConfig.httpx_transport instead and use Client. "
            f"(MockTransport works for both.)"
        )
