"""Typed result wrappers for Party / Service query responses.

The :meth:`Client.find_parties_by_name` / `find_parties_from_catalog` /
`find_services_by_name` / `find_services_from_catalog` helpers return
these typed wrappers rather than raw :class:`ParsedResponse`. They
expose the wire-level fields of a ``<PartyQueryResults>`` /
``<ServiceQueryResults>`` envelope without forcing callers to know
the XML structure.

For the underlying escape-hatch :meth:`Client.party_query` /
:meth:`Client.service_query` (which take raw XML query bodies),
:class:`ParsedResponse` is still the return type — those methods
exist precisely for callers who want to inspect the envelope
themselves.

Wire shapes (from ``api.xsd`` and ``service.xsd``):

.. code-block:: xml

    <PartyQueryResults>
      <CurrentSize>...</CurrentSize>
      <TotalMatches>...</TotalMatches>
      <ContinuationToken>...</ContinuationToken>  <!-- optional -->
      <!-- choice: -->
      <PartyID>10.5237/...</PartyID>*
      <!-- or: -->
      <Party>...</Party>*
    </PartyQueryResults>

    <ServiceQueryResults>
      <CurrentSize>...</CurrentSize>
      <TotalMatches>...</TotalMatches>
      <ContinuationToken>...</ContinuationToken>  <!-- optional -->
      <Service>...</Service>*
    </ServiceQueryResults>

Note that ``PageNumber`` and ``PageSize`` appear in the *request*
body but **not** in the response — the registry doesn't echo them
back. ``CurrentSize`` is the number of records in *this page*;
``TotalMatches`` is the count across all pages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import cached_property
from typing import TYPE_CHECKING

from lxml import etree

from eidr.client._response import ParsedResponse

if TYPE_CHECKING:
    from eidr.models.party import PartyRecord
    from eidr.models.service import ServiceRecord

_EIDR_NS = "http://www.eidr.org/schema"
_NS = {"eidr": _EIDR_NS}


def _scalar_text(el: etree._Element | None) -> str | None:
    if el is None or el.text is None:
        return None
    text = el.text.strip()
    return text or None


def _scalar_int(el: etree._Element | None) -> int | None:
    text = _scalar_text(el)
    if text is None:
        return None
    try:
        return int(text)
    except ValueError:
        return None


@dataclass(frozen=True)
class PartyQueryResults:
    """Typed view of a ``<PartyQueryResults>`` envelope.

    Returned by :meth:`Client.find_parties_by_name`,
    :meth:`Client.find_parties_from_catalog`, and their async
    mirrors.

    Field semantics:

    - :attr:`current_size` — number of records in *this page*.
      ``None`` if the registry omitted the field (uncommon).
    - :attr:`total_matches` — count across all pages, useful for
      paging UIs that show "page 2 of 17" style indicators.
    - :attr:`continuation_token` — opaque token for stateful
      paging. Pass back to the next call as ``continuation_token=``.
      ``None`` when not provided by the registry.
    - :attr:`party_ids` — list of Party DOIs, populated when the
      caller did **not** request ``full=True`` (the default).
      Always a list, possibly empty.
    - :attr:`parties` — list of full Party record XML strings,
      populated when the caller requested ``full=True``. Each
      string is a serialized ``<Party>`` element body. The
      :attr:`party_records` property below provides a parsed
      :class:`~eidr.models.PartyRecord` view of these without
      callers having to call ``PartyRecord.from_xml()`` themselves.
      Always a list, possibly empty.
    - :attr:`raw_response` — the underlying :class:`ParsedResponse`,
      retained as an escape hatch for advanced inspection (custom
      XPath, registry-specific extensions, etc.).

    The :attr:`party_records` accessor parses the XML strings on
    each call (no internal caching). For high-frequency iteration,
    bind the result once: ``records = result.party_records``.
    """

    current_size: int | None
    total_matches: int | None
    continuation_token: str | None
    party_ids: list[str] = field(default_factory=list)
    parties: list[str] = field(default_factory=list)
    raw_response: ParsedResponse | None = None

    @cached_property
    def party_records(self) -> list[PartyRecord]:
        """Parse :attr:`parties` XML strings into typed Party records.

        Returns an empty list when ``full=True`` wasn't requested
        (in which case the registry sends ID-only results in
        :attr:`party_ids`). For ID-only results, callers can call
        :meth:`Client.resolve_party` on each entry of
        :attr:`party_ids` to get full records.

        Cached per instance via :class:`functools.cached_property`:
        the first access parses the XML, subsequent accesses return
        the cached list.
        """
        from eidr.models.party import PartyRecord

        return [PartyRecord.from_xml(xml) for xml in self.parties]

    @classmethod
    def from_response(cls, response: ParsedResponse) -> PartyQueryResults:
        """Parse a :class:`ParsedResponse` into a :class:`PartyQueryResults`."""
        # Per api.xsd, the registry returns ``<PartyQueryResults>`` as
        # the document root for successful queries (kind="record" in
        # parse_response). Handle both that shape and the legacy
        # nested-in-Response shape defensively.
        root_local = etree.QName(response.root).localname
        if root_local == "PartyQueryResults":
            results_el: etree._Element | None = response.root
        else:
            results_el = response.root.find(".//eidr:PartyQueryResults", _NS)
        if results_el is None:
            return cls(
                current_size=None,
                total_matches=None,
                continuation_token=None,
                raw_response=response,
            )

        party_ids: list[str] = []
        for el in results_el.findall("eidr:PartyID", _NS):
            text = _scalar_text(el)
            if text is not None:
                party_ids.append(text)

        parties: list[str] = []
        for el in results_el.findall("eidr:Party", _NS):
            xml_bytes = etree.tostring(el, encoding="unicode")
            assert isinstance(xml_bytes, str)
            parties.append(xml_bytes)

        return cls(
            current_size=_scalar_int(results_el.find("eidr:CurrentSize", _NS)),
            total_matches=_scalar_int(results_el.find("eidr:TotalMatches", _NS)),
            continuation_token=_scalar_text(results_el.find("eidr:ContinuationToken", _NS)),
            party_ids=party_ids,
            parties=parties,
            raw_response=response,
        )

    def __len__(self) -> int:
        """Number of result records on *this page*.

        Uses ``current_size`` if reported by the registry; otherwise
        falls back to ``len(party_ids) + len(parties)``.
        """
        if self.current_size is not None:
            return self.current_size
        return len(self.party_ids) + len(self.parties)

    def __bool__(self) -> bool:
        """Truthy when this page has any records."""
        return len(self) > 0


@dataclass(frozen=True)
class ServiceQueryResults:
    """Typed view of a ``<ServiceQueryResults>`` envelope.

    Returned by :meth:`Client.find_services_by_name`,
    :meth:`Client.find_services_from_catalog`, and their async
    mirrors.

    Field semantics mirror :class:`PartyQueryResults`. Note that
    Service queries always return full records (the schema's
    ``<Service>`` choice is the only option — no ID-only path),
    so :attr:`services` is the populated field and there's no
    parallel ``service_ids``.

    The :attr:`service_records` property below provides a parsed
    :class:`~eidr.models.ServiceRecord` view of :attr:`services`
    without callers having to call ``ServiceRecord.from_xml()``
    themselves.
    """

    current_size: int | None
    total_matches: int | None
    continuation_token: str | None
    services: list[str] = field(default_factory=list)
    raw_response: ParsedResponse | None = None

    @cached_property
    def service_records(self) -> list[ServiceRecord]:
        """Parse :attr:`services` XML strings into typed Service records.

        Cached per instance via :class:`functools.cached_property`:
        the first access parses the XML, subsequent accesses return
        the cached list.
        """
        from eidr.models.service import ServiceRecord

        return [ServiceRecord.from_xml(xml) for xml in self.services]

    @classmethod
    def from_response(cls, response: ParsedResponse) -> ServiceQueryResults:
        """Parse a :class:`ParsedResponse` into a :class:`ServiceQueryResults`."""
        # Per service.xsd, the registry returns ``<ServiceQueryResults>``
        # as the document root for successful queries.
        root_local = etree.QName(response.root).localname
        if root_local == "ServiceQueryResults":
            results_el: etree._Element | None = response.root
        else:
            results_el = response.root.find(".//eidr:ServiceQueryResults", _NS)
        if results_el is None:
            return cls(
                current_size=None,
                total_matches=None,
                continuation_token=None,
                raw_response=response,
            )

        services: list[str] = []
        for el in results_el.findall("eidr:Service", _NS):
            xml_bytes = etree.tostring(el, encoding="unicode")
            assert isinstance(xml_bytes, str)
            services.append(xml_bytes)

        return cls(
            current_size=_scalar_int(results_el.find("eidr:CurrentSize", _NS)),
            total_matches=_scalar_int(results_el.find("eidr:TotalMatches", _NS)),
            continuation_token=_scalar_text(results_el.find("eidr:ContinuationToken", _NS)),
            services=services,
            raw_response=response,
        )

    def __len__(self) -> int:
        """Number of result records on *this page*."""
        if self.current_size is not None:
            return self.current_size
        return len(self.services)

    def __bool__(self) -> bool:
        return len(self) > 0


@dataclass(frozen=True)
class ServiceChildrenResults:
    """Typed view of a ``service_children`` response.

    Returned by :meth:`Client.service_children` and its async mirror.
    The registry returns the immediate children of a parent Service
    in a single response (no paging at this endpoint); this wrapper
    extracts them in a Pythonic form rather than leaving callers to
    inspect the underlying ``ParsedResponse``.

    Field semantics:

    - :attr:`service_id` — the parent Service ID that was queried.
      Echoed back from the request so callers can correlate
      results across multiple concurrent calls.
    - :attr:`child_ids` — extracted child Service DOIs as strings.
      Always populated (or empty if the parent has no children).
    - :attr:`children` — list of full child Service record XML
      strings (one ``<Service>`` body per child), populated when
      the registry returns full child records. Empty when the
      registry returns ID-only children. The :attr:`child_records`
      property below provides a parsed
      :class:`~eidr.models.ServiceRecord` view of these.
    - :attr:`raw_response` — the underlying :class:`ParsedResponse`,
      retained as an escape hatch for advanced inspection.

    Note that the registry's response shape for ``/service/children/``
    isn't pinned by the published XSD as tightly as the query-result
    shapes are; this wrapper extracts ``<ID>`` elements (for ID-only
    responses) and ``<Service>`` elements (for full responses) from
    anywhere in the envelope, defensively. If the live response
    shape evolves, ``raw_response`` is the escape hatch.
    """

    service_id: str
    child_ids: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    raw_response: ParsedResponse | None = None

    @classmethod
    def from_response(cls, response: ParsedResponse, *, service_id: str) -> ServiceChildrenResults:
        """Parse a :class:`ParsedResponse` into a :class:`ServiceChildrenResults`.

        Extraction strategy:

        1. Look for a known children-container element first
           (``<ServiceChildren>``, ``<Children>``, ``<ServiceList>``)
           and extract only from inside it if found.
        2. Otherwise fall back to a broader scan of the response
           root, but:

           - exclude ``<ID>`` elements that are descendants of any
             ``<Service>`` element (those are parts of full child
             records, not separate ID-only child entries);
           - exclude the parent's own ``service_id`` from the
             child-IDs list;
           - deduplicate the IDs.

        Without a live wire trace pinning the exact container shape
        for ``/service/children/`` we keep both paths active. If
        the registry's response evolves, ``raw_response`` is the
        escape hatch.

        Args:
            response: Parsed registry response from
                :meth:`Client.service_children`.
            service_id: The parent Service ID that was queried,
                echoed into :attr:`service_id` for correlation
                and used to exclude the parent's own ID from the
                children list.
        """
        # Try known structured containers first.
        container: etree._Element | None = None
        for container_name in ("ServiceChildren", "Children", "ServiceList"):
            found = response.root.find(f".//eidr:{container_name}", _NS)
            if found is not None:
                container = found
                break

        scan_root = container if container is not None else response.root

        # Extract child IDs (ID-only path) and full Service bodies.
        # Descendant <ID> elements inside a <Service> body belong
        # to that record, not to the ID-only list — exclude them
        # by walking ancestors at extraction time. (lxml element
        # proxies are recreated on the fly, so id()-based tracking
        # of pre-collected elements isn't reliable; ancestor-walk
        # is.)
        seen_ids: set[str] = set()
        child_ids: list[str] = []
        children: list[str] = []
        parent_id_normalized = service_id.lower()

        for el in scan_root.iter():
            local_name = etree.QName(el).localname
            if local_name == "ID":
                # Skip <ID> elements that have a <Service> ancestor.
                if any(
                    etree.QName(ancestor).localname == "Service" for ancestor in el.iterancestors()
                ):
                    continue
                text = _scalar_text(el)
                if not text or not text.startswith("10.5239/"):
                    continue
                # Skip the parent's own ID — defensive in case the
                # registry echoes it.
                if text.lower() == parent_id_normalized:
                    continue
                # Deduplicate.
                if text in seen_ids:
                    continue
                seen_ids.add(text)
                child_ids.append(text)
            elif local_name == "Service":
                xml_str = etree.tostring(el, encoding="unicode")
                assert isinstance(xml_str, str)
                children.append(xml_str)

        return cls(
            service_id=service_id,
            child_ids=child_ids,
            children=children,
            raw_response=response,
        )

    @cached_property
    def child_records(self) -> list[ServiceRecord]:
        """Parse :attr:`children` XML strings into typed ServiceRecord instances.

        Empty for ID-only responses (in which case use
        :attr:`child_ids` and :meth:`Client.resolve_service` per ID).

        Cached per instance via :class:`functools.cached_property`:
        the first access parses the XML, subsequent accesses return
        the cached list.
        """
        from eidr.models.service import ServiceRecord

        return [ServiceRecord.from_xml(xml) for xml in self.children]

    def __len__(self) -> int:
        """Total children — the union of child_ids and children.

        Both are populated only if the registry mixes shapes; in
        practice it's one or the other, so this matches whichever
        is populated.
        """
        return max(len(self.child_ids), len(self.children))

    def __bool__(self) -> bool:
        """Truthy when this parent has any children."""
        return len(self) > 0


__all__ = [
    "PartyQueryResults",
    "ServiceChildrenResults",
    "ServiceQueryResults",
]
