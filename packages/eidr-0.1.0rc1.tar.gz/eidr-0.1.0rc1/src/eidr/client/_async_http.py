"""Async HTTP transport for the EIDR REST API.

Mirror of :class:`eidr.client._http._Transport`, using
:class:`httpx.AsyncClient` for non-blocking I/O. The EIDR-specific
behaviors are identical — same multipart framing with boundary
``314159``, same ``Immediate-Response`` header semantics, same
retry policy for idempotent reads, same "uncertain write" treatment
of post-send failures, same tracing hook calling the same
:func:`~eidr.client._tracing.make_trace_record` factory.

Why a separate class rather than an internal async method on
:class:`_Transport`?

* :class:`httpx.Client` and :class:`httpx.AsyncClient` are distinct
  classes with distinct lifetimes. The async client requires
  ``await client.aclose()``, which can't happen in a sync ``close()``.
  Muxing both in one transport would require two httpx clients and
  complicate the ownership model.
* The method signatures have to differ (``async def`` vs ``def``),
  so there's no sync/async polymorphism worth preserving.
* Keeping the two classes parallel lets the sync path stay genuinely
  sync (no coroutine overhead for sync callers).

Nothing below the transport needs to know sync from async. The
envelope builder, operation builders, response parser, query-results
parser, codec layer, and record models are all shared verbatim
between :class:`Client` and :class:`AsyncClient`.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import httpx

from eidr.auth import make_auth_header
from eidr.client._http import (
    _EIDR_API_VERSION,
    _MULTIPART_BOUNDARY,
    TransportConfig,
    _build_multipart_body,
    _form_field_name,
    _validate_async_transport,
)
from eidr.client._tracing import TraceSink, make_trace_record
from eidr.errors import (
    EIDRAuthenticationError,
    EIDRHTTPStatusError,
    EIDRReadOnlyRegistryError,
    EIDRTimeoutError,
    EIDRTransportError,
    EIDRUncertainWriteError,
)

if TYPE_CHECKING:
    from eidr.credentials import Credentials
    from eidr.registries import Registry


_logger = logging.getLogger(__name__)


class _AsyncTransport:
    """Async HTTP transport for the EIDR REST API.

    Wraps an :class:`httpx.AsyncClient`. One transport per
    :class:`AsyncClient` instance; both share lifecycle
    (``aclose`` on exit). Constructed and torn down through the
    enclosing :class:`AsyncClient` — not intended for direct use.

    Trace emission matches the sync transport exactly: every round
    trip (success, failure, retry) produces one
    :class:`~eidr.client._tracing.TraceRecord`, with the same body
    redaction and size-limit knobs from
    :class:`~eidr.client._http.TransportConfig`. Sink writes are
    sync (the :class:`~eidr.client._tracing.TraceSink` protocol is
    synchronous); an async trace sink protocol could be added in a
    future milestone if someone needs to ship traces over the
    network, but in-process sinks (logger, file, list) are fine as
    sync calls inside an async task.
    """

    def __init__(
        self,
        registry: Registry,
        credentials: Credentials | None,
        config: TransportConfig | None = None,
        *,
        trace_sink: TraceSink | None = None,
    ) -> None:
        self._registry = registry
        self._credentials = credentials
        self._config = config or TransportConfig()
        self._trace_sink = trace_sink
        self._closed = False

        # Validate the injected transport (if any) is async-compatible.
        # Belt-and-suspenders: the field's declared type is async-only
        # so static type checkers already catch wrong assignments.
        _validate_async_transport(self._config.async_httpx_transport)

        self._httpx = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=self._config.connect_timeout,
                read=self._config.read_timeout,
                write=self._config.read_timeout,
                pool=self._config.connect_timeout,
            ),
            verify=self._config.verify_tls,
            transport=self._config.async_httpx_transport,
        )

    async def aclose(self) -> None:
        """Close the underlying :class:`httpx.AsyncClient`.

        Idempotent — calling more than once is a no-op after the
        first, matching :meth:`Client.close`. Double-close is a
        realistic scenario (an ``async with`` block that also
        explicitly calls ``aclose()``, a teardown helper that
        closes a client the owner has already closed, etc.) and
        forcing callers to be careful about it for no safety benefit
        would be user-hostile.
        """
        if self._closed:
            return
        await self._httpx.aclose()
        self._closed = True

    # ─── trace emission ─────────────────────────────────────────────────

    def _emit_trace(
        self,
        *,
        method: str,
        url: str,
        request_headers: dict[str, str],
        request_body: str | bytes | None,
        response: httpx.Response | None,
        start_time: float,
        exception: BaseException | None,
        attempt: int,
    ) -> None:
        """Record one round-trip to the trace sink, if any.

        Silently no-ops when ``_trace_sink`` is ``None``. Never raises —
        a broken sink must not impede the request path. Sink writes
        are synchronous; the :class:`TraceSink` protocol doesn't
        distinguish sync from async because in-process sinks are the
        expected case.
        """
        if self._trace_sink is None:
            return
        try:
            response_status = response.status_code if response is not None else None
            response_headers = dict(response.headers) if response is not None else None
            response_body = response.text if response is not None else None
            record = make_trace_record(
                method=method,
                url=url,
                request_headers=request_headers,
                request_body=request_body,
                response_status=response_status,
                response_headers=response_headers,
                response_body=response_body,
                start_time=start_time,
                exception=exception,
                attempt=attempt,
                max_body_chars=self._config.trace_max_body_chars,
                redact_bodies=self._config.trace_redact_bodies,
            )
            self._trace_sink.write(record)
        except Exception:
            pass

    # ─── request shape ──────────────────────────────────────────────────

    def _base_headers(self) -> dict[str, str]:
        """Headers common to all requests — auth and SDK identification."""
        headers = {
            "EIDR-Version": _EIDR_API_VERSION,
            "User-Agent": f"eidr-python-sdk/{_EIDR_API_VERSION}",
        }
        if self._credentials is not None:
            headers["Authorization"] = make_auth_header(
                user_id=self._credentials.user_id,
                party_id=self._credentials.party_id,
                password=self._credentials.password,
            )
        return headers

    def _full_url(self, resource_path: str) -> str:
        """Combine the registry base URL with a resource path."""
        base = self._registry.url.rstrip("/")
        path = resource_path if resource_path.startswith("/") else "/" + resource_path
        return base + path

    # ─── read path (GET) ────────────────────────────────────────────────

    async def get(
        self,
        resource_path: str,
        *,
        params: dict[str, str] | None = None,
    ) -> str:
        """Issue a GET request and return the response body as text.

        Async mirror of :meth:`~eidr.client._http._Transport.get`.
        Same retry policy (exponential backoff, idempotent-retry for
        5xx, no-retry for 4xx), same trace emission per attempt.

        Args:
            resource_path: URL path appended to the registry base.
            params: Optional query-string parameters, URL-encoded
                via httpx's ``params=`` kwarg.
        """
        import time

        url = self._full_url(resource_path)
        headers = self._base_headers()
        headers["Accept"] = "text/xml"

        last_exc: Exception | None = None
        for attempt in range(self._config.max_retries + 1):
            start_time = time.monotonic()
            try:
                response = await self._httpx.get(url, headers=headers, params=params)
            except httpx.TimeoutException as exc:
                self._emit_trace(
                    method="GET",
                    url=url,
                    request_headers=headers,
                    request_body=None,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug("GET %s timeout (attempt %d)", url, attempt + 1)
                if attempt < self._config.max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise EIDRTimeoutError(
                    f"Timed out after {attempt + 1} attempts: GET {url}"
                ) from exc
            except httpx.TransportError as exc:
                self._emit_trace(
                    method="GET",
                    url=url,
                    request_headers=headers,
                    request_body=None,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug(
                    "GET %s transport error (attempt %d): %s",
                    url,
                    attempt + 1,
                    exc,
                )
                if attempt < self._config.max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise EIDRTransportError(
                    f"Transport error after {attempt + 1} attempts: GET {url}: {exc}"
                ) from exc

            self._emit_trace(
                method="GET",
                url=url,
                request_headers=headers,
                request_body=None,
                response=response,
                start_time=start_time,
                exception=None,
                attempt=attempt,
            )

            if response.status_code == 200:
                return response.text

            if 500 <= response.status_code < 600 and attempt < self._config.max_retries:
                _logger.debug(
                    "GET %s returned %d (attempt %d); retrying",
                    url,
                    response.status_code,
                    attempt + 1,
                )
                await self._sleep_backoff(attempt)
                continue
            self._raise_for_status(response, method="GET", url=url)

        raise EIDRTransportError(f"Exhausted retries: GET {url} — last error: {last_exc}")

    # ─── write path (POST) ──────────────────────────────────────────────

    async def post(
        self,
        resource_path: str,
        xml_payload: str,
        *,
        immediate: bool,
        requires_writable: bool = True,
        params: dict[str, str] | None = None,
    ) -> str:
        """Issue a POST request with an EIDR-shaped multipart body.

        Async mirror of :meth:`~eidr.client._http._Transport.post`.
        Same "uncertain write" treatment of post-send transport
        failures — once bytes have left, we don't retry, we raise
        :class:`EIDRUncertainWriteError` and let the caller reconcile.

        Args:
            resource_path: URL path (e.g., ``"/register/"``).
            xml_payload: The ``<Request>...</Request>`` body.
            immediate: ``Immediate-Response`` header value.
            requires_writable: Refuse against a read-only registry
                (default ``True``). Query methods pass ``False``.
            params: Optional query-string parameters. See
                :meth:`~eidr.client._http._Transport.post` for the
                full rationale (URL-encoding + trace redaction).
        """
        import time

        if requires_writable and not self._registry.writable:
            raise EIDRReadOnlyRegistryError(
                f"Registry {self._registry.name!r} is read-only; POST to {resource_path} refused.",
                registry_name=self._registry.name,
                operation=resource_path,
            )

        url = self._full_url(resource_path)
        # See sync _Transport.post for the empty-body rationale.
        if not xml_payload or not xml_payload.strip():
            body: bytes = b""
        else:
            body = _build_multipart_body(_form_field_name(resource_path), xml_payload)

        headers = self._base_headers()
        headers["Content-Type"] = f"multipart/form-data; boundary={_MULTIPART_BOUNDARY}"
        headers["Content-Length"] = str(len(body))
        headers["Immediate-Response"] = "true" if immediate else "false"

        # See sync _Transport.post for the trace_url rationale.
        if params:
            from urllib.parse import urlencode

            trace_url = url + ("&" if "?" in url else "?") + urlencode(params)
        else:
            trace_url = url

        last_exc: Exception | None = None
        for attempt in range(self._config.max_retries + 1):
            start_time = time.monotonic()
            try:
                response = await self._httpx.post(url, headers=headers, content=body, params=params)
            except httpx.ConnectError as exc:
                # Pre-send failure — safe to retry.
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                last_exc = exc
                _logger.debug(
                    "POST %s connect error (attempt %d): %s",
                    url,
                    attempt + 1,
                    exc,
                )
                if attempt < self._config.max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise EIDRTransportError(
                    f"Could not connect after {attempt + 1} attempts: POST {url}: {exc}"
                ) from exc
            except httpx.TimeoutException as exc:
                # Mid-send/after-send — uncertain. Do not retry.
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                raise EIDRUncertainWriteError(
                    f"Timeout during POST {url}; the registry may or may "
                    f"not have processed the request. Check the registry "
                    f"state before retrying."
                ) from exc
            except httpx.TransportError as exc:
                self._emit_trace(
                    method="POST",
                    url=trace_url,
                    request_headers=headers,
                    request_body=body,
                    response=None,
                    start_time=start_time,
                    exception=exc,
                    attempt=attempt,
                )
                raise EIDRUncertainWriteError(
                    f"Transport error during POST {url}; the registry "
                    f"may or may not have processed the request: {exc}"
                ) from exc

            self._emit_trace(
                method="POST",
                url=trace_url,
                request_headers=headers,
                request_body=body,
                response=response,
                start_time=start_time,
                exception=None,
                attempt=attempt,
            )

            if response.status_code == 200:
                return response.text

            # No POST 5xx auto-retry. See the sync transport for the
            # full rationale: once the body has been transmitted,
            # auto-retrying on 5xx may duplicate the operation.
            # Java's ``Post.java`` flips ``safetoretry = false``
            # at the same point.
            if 500 <= response.status_code < 600:
                raise EIDRUncertainWriteError(
                    f"POST {url} returned {response.status_code}; "
                    f"the registry may or may not have processed "
                    f"the write. Body snippet: "
                    f"{(response.text or '')[:300]!r}"
                )
            self._raise_for_status(response, method="POST", url=url)

        raise EIDRTransportError(f"Exhausted retries: POST {url} — last error: {last_exc}")

    # ─── error mapping & backoff ────────────────────────────────────────

    @staticmethod
    def _raise_for_status(response: httpx.Response, *, method: str, url: str) -> None:
        """Map a non-200 response to the right :class:`EIDRError` subclass."""
        code = response.status_code
        body_snippet = (response.text or "")[:500]

        if code in (401, 403):
            raise EIDRAuthenticationError(
                f"{method} {url} returned HTTP {code}. "
                f"Check credentials and party role. Body: {body_snippet!r}"
            )
        raise EIDRHTTPStatusError(
            f"{method} {url} returned HTTP {code}. Body: {body_snippet!r}",
            status_code=code,
        )

    async def _sleep_backoff(self, attempt: int) -> None:
        """Exponential backoff via :func:`asyncio.sleep`.

        Uses ``asyncio.sleep`` rather than ``time.sleep`` so the task
        yields to the event loop during the backoff window — other
        coroutines keep making progress while we wait. ``attempt`` is
        0-indexed.
        """
        delay = min(
            self._config.retry_backoff_base * (2**attempt),
            self._config.retry_backoff_max,
        )
        await asyncio.sleep(delay)
