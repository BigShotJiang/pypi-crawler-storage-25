"""Parse an EIDR registry HTTP 200 response body.

The EIDR registry returns HTTP 200 for virtually every application-level
response — success, auth failure, validation rejection, not-found,
everything. The actual outcome is inside the XML body. This module
walks the XML, determines which kind of response it is, and either
returns a parsed record/token or raises the appropriate exception.

Response shapes we handle here
------------------------------

1. **Resolution success** — root is one of the record envelopes:
   ``<FullMetadata>``, ``<SelfDefinedMetadata>``,
   ``<ProvenanceMetadata>``, or ``<AliasContinuation>`` (for
   over-deep alias chains). Caller decides how to hand this to the
   codec layer.

2. **Response envelope** — root is ``<Response>`` with a ``<Status>``
   child carrying ``<Code>`` (integer) and ``<Type>`` (string). Body
   varies by operation: registration responses carry a ``<Token>``, a
   returned ID, or duplicate records; query responses carry result
   lists; status-lookup responses carry ``<RequestStatusResults>``.

3. **Plain-text or malformed** — shouldn't happen against a real
   registry but does against misconfigured endpoints. We raise
   :class:`EIDRProtocolError` with the raw body excerpt.

Status-code to exception mapping
--------------------------------

Code values are from the EIDR Registry User's Guide. Zero is success;
positive integers indicate specific conditions. We map the well-known
ones to typed exceptions and fall back to :class:`EIDRRegistryError`
for the rest, preserving the raw code and type strings on the
exception for inspection.
"""

from __future__ import annotations

from dataclasses import dataclass

from lxml import etree

from eidr.errors import (
    EIDRProtocolError,
)

__all__ = [
    "OperationStatusEntry",
    "ParsedResponse",
    "extract_duplicate_id",
    "extract_inline_record_xml",
    "extract_record_xml",
    "extract_status_details",
    "extract_token",
    "iter_sub_tokens",
    "parse_response",
    "raise_for_operation_status",
]


#: EIDR XML namespace for registry response bodies.
_EIDR_NS = "http://www.eidr.org/schema"
_NS = {"eidr": _EIDR_NS}

#: Element names (local) that indicate a resolution-response body.
#: Covers Content (FullMetadata et al), Party (Party), and Service
#: (Service) resolution responses — plus over-deep alias continuations.
#:
#: The names here are the **actual element local-names** that the
#: registry emits on the wire — ``SelfDefinedMetadata`` and
#: ``ProvenanceMetadata``, not ``SelfDefined``/``Provenance`` (which
#: are the ``type=`` query parameter values on the resolve URL, a
#: different thing). Matches the root set in :mod:`eidr.models._parse`.
_RESOLVE_ROOTS: frozenset[str] = frozenset(
    {
        # Content
        "FullMetadata",
        "SelfDefinedMetadata",
        "ProvenanceMetadata",
        "InheritedMetadata",
        "SimpleMetadata",
        "DOIKernel",
        "LinkedAlternateIDs",
        # Party / Service
        "Party",
        "Service",
        # Party / Service query results — top-level roots per
        # api.xsd / service.xsd, not wrapped in <Response>.
        "PartyQueryResults",
        "ServiceQueryResults",
        # Alias continuations (for chains >5 levels deep)
        "AliasContinuation",
    }
)


#: Status-code → exception-class mapping. Source: EIDR Registry User's
#: Guide, "Status Codes" section. Values are integers as they appear
#: The response-envelope error dispatch lives in
#: :func:`eidr.errors._status_to_exception`, which prefers matching on
#: the ``<Status><Type>`` string over the code integer. This matches
#: how the EIDR REST API Reference documents the status vocabulary:
#: codes are hierarchical and overlap between namespaces (top-level
#: Request status Table 5 vs. per-Operation status Table 6), but the
#: Type strings are unambiguous.


@dataclass(frozen=True, slots=True)
class ParsedResponse:
    """Structured result of parsing a 200-OK EIDR response body.

    Attributes:
        kind: ``"record"`` if the body is a resolution-style response
            (FullMetadata, SelfDefined, etc.); ``"envelope"`` if it's
            the ``<Response>`` envelope used for registration, status,
            query, and other non-resolve operations.
        root: The parsed lxml element (not detached from its tree).
            For ``kind == "record"`` this is the record root directly;
            for ``kind == "envelope"`` this is the ``<Response>``
            element itself.
        status_code: For envelope responses, the integer from
            ``<Status><Code>``. ``None`` for record responses.
        status_type: For envelope responses, the string from
            ``<Status><Type>``. ``None`` for record responses.
        raw_body: The full response body text, retained for debugging
            and error-reporting.
    """

    kind: str
    root: etree._Element
    status_code: int | None
    status_type: str | None
    raw_body: str

    def operation_status_elements(self) -> list[etree._Element]:
        """Return any ``<OperationStatus>`` children of this envelope.

        For batch responses, each submitted operation produces one
        ``<OperationStatus>`` element with its own sub-token and outcome.
        Single-operation requests typically have exactly one.

        Returns an empty list for record responses and for envelopes
        without operation children.
        """
        if self.kind != "envelope":
            return []
        # <Response>/<RequestStatusResults>/<OperationStatus>* is the
        # status-lookup shape; <Response>/<OperationResult>* is the
        # registration-style shape. Return whichever is present.
        candidates: list[etree._Element] = []
        for path in (
            ".//eidr:OperationStatus",
            ".//eidr:OperationResult",
        ):
            candidates.extend(self.root.xpath(path, namespaces=_NS))
        return candidates


def parse_response(body: str, *, operation: str) -> ParsedResponse:
    """Parse an EIDR HTTP-200 response body.

    Args:
        body: The raw response text returned by the HTTP layer.
        operation: A short description of what operation produced
            this response (e.g., ``"resolve 10.5240/..."``), used in
            error messages.

    Returns:
        A :class:`ParsedResponse` on success.

    Raises:
        EIDRProtocolError: When the body is empty, non-XML, or in an
            otherwise unexpected shape.
        EIDRAuthenticationError, EIDRAuthorizationError,
        EIDRNotFoundError, EIDRValidationError, EIDRDuplicateError,
        EIDRRegistryError: When the envelope's ``<Status><Code>`` is
            non-zero.
    """
    if not body or not body.strip():
        raise EIDRProtocolError(
            f"Empty response body from {operation}. "
            "The registry returns HTTP 200 with a body even on error; "
            "an empty body indicates a transport-level issue."
        )

    try:
        root = etree.fromstring(body.encode("utf-8") if isinstance(body, str) else body)
    except etree.XMLSyntaxError as exc:
        snippet = body[:200]
        raise EIDRProtocolError(
            f"Malformed XML in response to {operation}: {exc}. Body starts: {snippet!r}"
        ) from exc

    local_name = etree.QName(root).localname

    # Case 1: record response (resolution-style)
    if local_name in _RESOLVE_ROOTS:
        return ParsedResponse(
            kind="record",
            root=root,
            status_code=None,
            status_type=None,
            raw_body=body,
        )

    # Case 2: envelope response
    if local_name == "Response":
        status_elem = root.find("eidr:Status", _NS)
        if status_elem is None:
            # No top-level <Status>. Some Content-write responses
            # carry the status nested inside <OperationResult> /
            # <OperationStatus> instead. Fall back to the first one
            # we find. If still nothing, *then* it's a protocol
            # violation.
            for path in (
                ".//eidr:OperationResult/eidr:Status",
                ".//eidr:OperationStatus/eidr:Status",
            ):
                nested = root.xpath(path, namespaces=_NS)
                if nested:
                    status_elem = nested[0]
                    break
        if status_elem is None:
            raise EIDRProtocolError(
                f"Response envelope from {operation} lacks <Status> child. "
                f"Body starts: {body[:200]!r}"
            )
        code_elem = status_elem.find("eidr:Code", _NS)
        type_elem = status_elem.find("eidr:Type", _NS)
        details_elem = status_elem.find("eidr:Details", _NS)
        code_str = (code_elem.text or "").strip() if code_elem is not None else ""
        type_str = (type_elem.text or "").strip() if type_elem is not None else ""
        details_str = (details_elem.text or "").strip() if details_elem is not None else ""
        try:
            code = int(code_str)
        except ValueError as exc:
            raise EIDRProtocolError(
                f"Response from {operation} has non-integer status code {code_str!r}: {exc}"
            ) from exc

        if code == 0:
            # Success — return the envelope for the caller to extract.
            return ParsedResponse(
                kind="envelope",
                root=root,
                status_code=0,
                status_type=type_str or "Success",
                raw_body=body,
            )

        # Non-zero code → exception.
        _raise_for_status_code(
            code=code,
            type_str=type_str,
            details=details_str,
            operation=operation,
            body=body,
        )

    # Case 2b: AdminResponse envelope. Used by /party/query and
    # /service/query for error responses (success returns
    # <PartyQueryResults> / <ServiceQueryResults> directly as the root
    # — handled in Case 1). Status fields appear directly under
    # <AdminResponse>, not nested in <Status>::
    #
    #     <AdminResponse>
    #       <Code>9</Code>
    #       <Type>syntax error</Type>
    #       <Details>...</Details>
    #     </AdminResponse>
    if local_name == "AdminResponse":
        code_elem = root.find("eidr:Code", _NS)
        type_elem = root.find("eidr:Type", _NS)
        details_elem = root.find("eidr:Details", _NS)
        code_str = (code_elem.text or "").strip() if code_elem is not None else ""
        type_str = (type_elem.text or "").strip() if type_elem is not None else ""
        details_str = (details_elem.text or "").strip() if details_elem is not None else ""
        try:
            code = int(code_str)
        except ValueError as exc:
            raise EIDRProtocolError(
                f"AdminResponse from {operation} has non-integer code {code_str!r}: {exc}"
            ) from exc
        # AdminResponse is only emitted on errors; treat code == 0 as
        # a protocol violation defensively (we've never seen one).
        if code == 0:
            raise EIDRProtocolError(
                f"AdminResponse from {operation} returned Code 0 — unexpected. "
                f"Body starts: {body[:200]!r}"
            )
        _raise_for_status_code(
            code=code,
            type_str=type_str,
            details=details_str,
            operation=operation,
            body=body,
        )

    # Case 3: neither — unexpected root.
    raise EIDRProtocolError(
        f"Unexpected root element {local_name!r} in response to "
        f"{operation}. Expected one of {sorted(_RESOLVE_ROOTS)} or 'Response'."
    )


def _raise_for_status_code(
    *,
    code: int,
    type_str: str,
    details: str,
    operation: str,
    body: str,
) -> None:
    """Raise the typed exception for a non-zero status code.

    Dispatches via :func:`eidr.errors._status_to_exception`, which
    matches on the ``<Status><Type>`` string first and falls back to
    the code. This is more correct than integer-only matching: EIDR's
    REST API code values (e.g., REST API Reference Table 5) and
    Operation Status code values (Table 6) overlap numerically but
    mean different things, while the Type strings
    (``"authorization error"``, ``"validation error"``, etc.) are
    unambiguous.
    """
    from eidr.errors import _status_to_exception

    # Include the registry's Details text in the exception message
    # when present — these are often the only actionable diagnostic
    # (e.g., "Referent Type must be one of 'TV', 'Movie', 'Short',
    # 'Web'").
    detail_tail = f" details={details!r}" if details else ""
    message = f"Registry rejected {operation}: code={code} type={type_str!r}{detail_tail}."
    exc = _status_to_exception(code, type=type_str, details=details, message=message)
    # _status_to_exception may or may not use the message kwarg depending
    # on the subclass signature; ensure a useful str() either way.
    if not exc.args:
        exc.args = (message,)
    _attach_context(exc, code=code, type_str=type_str, details=details, body=body)
    raise exc


def _attach_context(
    exc: BaseException,
    *,
    code: int,
    type_str: str,
    details: str,
    body: str,
) -> None:
    """Attach registry-status context to an exception for inspection."""
    import contextlib

    # Not all exception subclasses declare these as slots; attach as
    # regular attributes where possible, silently skip where not.
    # The ``details`` field matches the structured context documented
    # in the EIDRError hierarchy and is especially useful to EIDR
    # Operations when diagnosing a support ticket.
    for name, value in (
        ("code", code),
        ("type", type_str),
        ("details", details),
        ("body", body),
    ):
        with contextlib.suppress(AttributeError, TypeError):
            setattr(exc, name, value)


def extract_record_xml(parsed: ParsedResponse) -> bytes:
    """Serialize a ``kind == "record"`` parsed response back to XML bytes.

    Useful when the caller wants to hand the record to :func:`eidr.parse`
    or :meth:`ContentRecord.from_xml` — those take bytes rather than a
    pre-parsed element.

    Raises:
        ValueError: If called on a non-record parsed response.
    """
    if parsed.kind != "record":
        raise ValueError(
            f"extract_record_xml() expects a record response; got kind={parsed.kind!r}"
        )
    result = etree.tostring(parsed.root, xml_declaration=True, encoding="UTF-8")
    # lxml types the return as bytes | str depending on encoding; we
    # pass bytes-returning encoding so the cast is safe.
    assert isinstance(result, bytes)
    return result


def _extract_first_non_status_child(envelope_root: etree._Element) -> bytes | None:
    """Extract the record body from a ``<Response>`` envelope.

    Used by endpoints (notably ``modification_base``) where the
    registry wraps the record body inside a ``<Response>`` envelope
    alongside ``<Status>``, and the SDK doesn't know the record
    root element name in advance.

    Three cases, handled in order:

    1. **Creation-type wrapper.** When the single non-Status child
       is a known CreationType element (``<Basic>``, ``<Series>``,
       ``<Episode>``, ``<Season>``, ``<Edit>``, ``<Clip>``,
       ``<Manifestation>``, ``<Compilation>``), unwrap it. This is
       the modification-base shape: ``<Response><Status/><Basic>
       <BaseObjectData/></Basic></Response>`` for Basic, or
       ``<Response><Status/><Series><BaseObjectData/>
       <ExtraObjectMetadata/></Series></Response>`` for non-Basic.
       The unwrap exposes the inner ``<BaseObjectData>`` (single
       child) or synthesizes ``<FullMetadata>`` around the inner
       siblings (multi-child non-Basic case) so that
       :class:`ContentRecord` parses the result with populated
       ``id`` and ``resource_name``.

    2. **Single non-creation-type child.** Returns its serialized
       XML directly. Covers resolve-style envelopes where the
       wrapper is already a known record root
       (``<FullMetadata>``, ``<SelfDefinedMetadata>``, etc.).

    3. **Multiple non-Status children at the envelope level.**
       Synthesizes a ``<FullMetadata>`` wrapper around them.
       Defensive fallback for unexpected shapes.

    Returns ``None`` if no non-Status children are present (a
    Code-0 envelope with empty content — would indicate a registry
    shape change).
    """
    non_status_children = [
        child for child in envelope_root if etree.QName(child).localname != "Status"
    ]
    if not non_status_children:
        return None

    # Case 1: single creation-type wrapper. Unwrap it.
    if len(non_status_children) == 1:
        child = non_status_children[0]
        local_name = etree.QName(child).localname
        if local_name in _CREATION_TYPE_WRAPPERS:
            inner = list(child)
            if len(inner) == 1:
                # <Basic><BaseObjectData/></Basic> → return the
                # BaseObjectData directly.
                result = etree.tostring(inner[0], xml_declaration=True, encoding="UTF-8")
                assert isinstance(result, bytes)
                return result
            # <Series><BaseObjectData/><ExtraObjectMetadata/></Series>
            # → synthesize <FullMetadata> wrapping the inner siblings.
            ns = etree.QName(child).namespace
            wrapper_tag = f"{{{ns}}}FullMetadata" if ns else "FullMetadata"
            wrapper = etree.Element(wrapper_tag, nsmap=child.nsmap)
            for inner_child in inner:
                wrapper.append(inner_child)
            result = etree.tostring(wrapper, xml_declaration=True, encoding="UTF-8")
            assert isinstance(result, bytes)
            return result

        # Case 2: single non-creation-type child. Return as-is.
        result = etree.tostring(child, xml_declaration=True, encoding="UTF-8")
        assert isinstance(result, bytes)
        return result

    # Case 3: multiple children at envelope level — defensive fallback.
    ns = etree.QName(envelope_root).namespace
    wrapper_tag = f"{{{ns}}}FullMetadata" if ns else "FullMetadata"
    wrapper = etree.Element(wrapper_tag, nsmap=envelope_root.nsmap)
    for child in non_status_children:
        wrapper.append(child)
    result = etree.tostring(wrapper, xml_declaration=True, encoding="UTF-8")
    assert isinstance(result, bytes)
    return result


# CreationType wrapper element names that the registry uses to wrap
# record bodies in modification_base responses. Each maps 1:1 with
# CreationType enum values; kept as a frozenset (not derived at import
# time from the enum) to avoid an import cycle with eidr.models.enums.
_CREATION_TYPE_WRAPPERS = frozenset(
    {
        "Basic",
        "Series",
        "Season",
        "Episode",
        "Edit",
        "Clip",
        "Manifestation",
        "Compilation",
    }
)


def extract_inline_record_xml(parsed: ParsedResponse, root_local_name: str) -> bytes | None:
    """Extract a record body from either a bare-root or envelope-wrapped response.

    Party and Service write operations may return one of two response
    shapes (the registry's choice depends on operation and load):

    1. **Bare record root.** The response document's root is the
       record element itself: ``<Service>...</Service>`` or
       ``<Party>...</Party>``. :func:`parse_response` classifies
       this as ``kind="record"``.

    2. **Envelope-wrapped record.** The response document is the
       standard ``<Response><Status/>...</Response>`` envelope, with
       the record element appearing as a child alongside ``<Status>``::

           <Response>
             <Status><Code>0</Code><Type>Success</Type></Status>
             <Service>...</Service>
           </Response>

       :func:`parse_response` classifies this as ``kind="envelope"``.

    Both shapes carry an inline record. This helper looks for the
    record in either place and returns its serialized XML bytes, or
    ``None`` if no record element is present (e.g., a bare success
    ack with no body).

    Args:
        parsed: The parsed response from :func:`parse_response`.
        root_local_name: The expected record root local name —
            ``"Service"`` for service writes, ``"Party"`` for party
            writes.

    Returns:
        Serialized XML bytes of the record element, or ``None`` if
        no inline record is present in either response shape.
    """
    # Shape 1: bare record root
    if parsed.kind == "record":
        if etree.QName(parsed.root).localname == root_local_name:
            return extract_record_xml(parsed)
        # Different record kind than expected — caller passes a
        # specific root, so a mismatch here is unexpected. Return
        # None and let the caller's null-handling kick in.
        return None

    # Shape 2: envelope-wrapped — look inside Response for the
    # named record element.
    if parsed.kind == "envelope":
        # Try the EIDR-namespaced search first; fall back to the
        # local-name match for namespace-stripped responses.
        record_el = parsed.root.find(f"eidr:{root_local_name}", _NS)
        if record_el is None:
            for child in parsed.root:
                if etree.QName(child).localname == root_local_name:
                    record_el = child
                    break
        if record_el is None:
            return None
        result = etree.tostring(record_el, xml_declaration=True, encoding="UTF-8")
        assert isinstance(result, bytes)
        return result

    return None


def extract_token(parsed: ParsedResponse) -> str | None:
    """Extract the request-level ``<Token>`` from an envelope response, if any.

    The registry returns request-level tokens in two locations
    depending on the operation:

    - **Top-level** ``<Response>/<Token>``: simple async writes
    - **Inside RequestStatus** ``<Response>/<RequestStatus>/<Token>``:
      operations that return per-operation status alongside the
      request-level token. The ``match`` operation uses this shape
      (verified against the live ``sandbox2.eidr.org`` registry,
      M9 live-test pass round 4).

    The caller polls this token via :meth:`Client.status_lookup` to
    get the operation's final result.

    Returns ``None`` for envelopes without a Token (which includes all
    synchronous and query-style responses).
    """
    if parsed.kind != "envelope":
        return None
    # Try top-level first.
    tok = parsed.root.find("eidr:Token", _NS)
    if tok is None:
        # Fall back to the nested RequestStatus location used by
        # match (and possibly other operation classes).
        tok = parsed.root.find("eidr:RequestStatus/eidr:Token", _NS)
    if tok is None:
        return None
    return (tok.text or "").strip() or None


def extract_status_details(parsed: ParsedResponse) -> str | None:
    """Extract ``<Status><Details>`` text from an envelope response.

    For *write* operations, the registry's standard success envelope
    looks like one of two shapes:

    **Top-level Status** (Service / Party admin writes — verified
    M9 live-test pass round 2)::

        <Response>
          <Status>
            <Code>0</Code>
            <Type>success</Type>
            <Details>10.5239/52C0-0B32</Details>
          </Status>
        </Response>

    **OperationStatus / OperationResult-wrapped** (Content writes
    using the ``<Operations>`` envelope — register, modify, match)::

        <Response>
          <OperationResult>
            <Status>
              <Code>0</Code>
              <Type>success</Type>
              <Details>10.5240/...</Details>
            </Status>
          </OperationResult>
        </Response>

    Both shapes carry the affected record's EIDR ID in
    ``<Details>``. This helper checks for either shape (top-level
    first, then inside ``<OperationStatus>`` / ``<OperationResult>``)
    and returns the first ``<Details>`` text found.

    This is distinct from:

    - Inline record responses (handled by :func:`extract_record_xml`
      / :func:`extract_inline_record_xml`)
    - Async token responses (handled by :func:`extract_token`)
    - Bare success acknowledgements with no body (delete, alias,
      activate, deactivate — ``<Details>`` may be empty or absent)

    Returns:
        The ``<Details>`` text if present and non-empty, else
        ``None``. Calling on a ``kind="record"`` response always
        returns ``None``.
    """
    if parsed.kind != "envelope":
        return None

    # Try top-level <Status><Details> first (Service/Party shape).
    status = parsed.root.find("eidr:Status", _NS)
    if status is not None:
        details = status.find("eidr:Details", _NS)
        if details is not None:
            text = (details.text or "").strip()
            if text:
                return text

    # Fall back to <OperationResult><Status><Details> or
    # <OperationStatus><Status><Details> (Content-write shape).
    for op in parsed.operation_status_elements():
        op_status = op.find("eidr:Status", _NS)
        if op_status is not None:
            details = op_status.find("eidr:Details", _NS)
            if details is not None:
                text = (details.text or "").strip()
                if text:
                    return text

    return None


def extract_duplicate_id(parsed: ParsedResponse) -> str | None:
    """Extract the matched record's EIDR ID from a ``<Duplicate>`` element.

    The ``match`` operation reports a duplicate-match result inline
    in the response envelope::

        <Response>
          <Status><Code>0</Code><Type>success</Type></Status>
          <RequestStatus><Token>...</Token></RequestStatus>
          <RequestStatusResults>
            <CurrentSize>1</CurrentSize>
            <TotalMatches>1</TotalMatches>
            <OperationStatus>
              <Token>...</Token>
              <Status><Code>0</Code><Type>success</Type></Status>
              <Duplicate score="95" lowThreshold="60" highThreshold="90">
                <ID>10.5240/...</ID>
              </Duplicate>
            </OperationStatus>
          </RequestStatusResults>
        </Response>

    The matched record's ID is in ``<Duplicate>/<ID>``. Without this
    helper, the SDK would only see the request-level ``<Token>`` and
    return that as a deferred-result Token, forcing the caller to
    poll ``status_lookup`` for an answer that's already in the
    response body.

    Verified against the live ``sandbox2.eidr.org`` registry's
    ``match`` response shape (M9 live-test pass round 5).

    Returns the duplicate ID text if a ``<Duplicate>`` element with
    a non-empty ``<ID>`` is present, else ``None``.
    """
    if parsed.kind != "envelope":
        return None
    for op in parsed.operation_status_elements():
        dup = op.find("eidr:Duplicate", _NS)
        if dup is None:
            continue
        id_el = dup.find("eidr:ID", _NS)
        if id_el is None:
            continue
        text = (id_el.text or "").strip()
        if text:
            return text
    return None


@dataclass(frozen=True)
class OperationStatusEntry:
    """Typed view of a single ``<OperationStatus>`` element.

    Each status-lookup response (and each batch-write response)
    contains zero or more ``<OperationStatus>`` children, one per
    operation reported. Each child looks roughly like::

        <OperationStatus>
          <Status>
            <Code>0</Code>
            <Type>success</Type>
            <Details>10.5240/...</Details>
          </Status>
          <Token>1777250952014000067</Token>
          <ID>10.5240/...</ID>  <!-- resulting EIDR ID, when applicable -->
          ... (operation-specific extras)
        </OperationStatus>

    Exposes the most commonly accessed fields:

    - :attr:`token` — per-operation token (pending or completed
      operations).
    - :attr:`status_code` — integer status code from
      ``<Status><Code>``.
    - :attr:`status_type` — string status type from
      ``<Status><Type>``.
    - :attr:`details` — textual ``<Status><Details>`` body. For
      completed register operations, the registry often surfaces
      the resulting EIDR ID here (in addition to the dedicated
      ``<ID>`` element).
    - :attr:`resulting_id` — the resulting EIDR ID from a top-level
      ``<ID>`` child, when present. For completed register/modify
      operations this is the registry-assigned ID. ``None`` for
      pending operations or operations that don't produce an ID
      (e.g. delete).
    - :attr:`element` — the underlying lxml element, an escape
      hatch for advanced access (XPath, custom field extraction
      for less common ``<OperationStatus>`` extras like timestamps).

    Treat the field set as best-effort: the registry sometimes
    returns extra elements, and not all fields are populated in
    every response.
    """

    token: str | None
    status_code: int | None
    status_type: str | None
    details: str | None
    resulting_id: str | None
    element: etree._Element

    @classmethod
    def from_element(cls, op: etree._Element) -> OperationStatusEntry:
        """Wrap a single ``<OperationStatus>`` element into a typed entry."""
        token_el = op.find("eidr:Token", _NS)
        token = token_el.text.strip() if token_el is not None and token_el.text else None

        status_el = op.find("eidr:Status", _NS)
        status_code: int | None = None
        status_type: str | None = None
        details: str | None = None
        if status_el is not None:
            code_el = status_el.find("eidr:Code", _NS)
            if code_el is not None and code_el.text:
                try:
                    status_code = int(code_el.text.strip())
                except ValueError:
                    status_code = None
            type_el = status_el.find("eidr:Type", _NS)
            if type_el is not None and type_el.text:
                status_type = type_el.text.strip()
            details_el = status_el.find("eidr:Details", _NS)
            if details_el is not None and details_el.text:
                details = details_el.text.strip()

        # Resulting EIDR ID — for completed register/modify operations
        # the registry returns the assigned ID as a top-level <ID>
        # child of <OperationStatus>. Pending and delete operations
        # have no ID.
        id_el = op.find("eidr:ID", _NS)
        resulting_id = id_el.text.strip() if id_el is not None and id_el.text else None

        return cls(
            token=token,
            status_code=status_code,
            status_type=status_type,
            details=details,
            resulting_id=resulting_id,
            element=op,
        )


def iter_sub_tokens(parsed: ParsedResponse) -> list[str]:
    """Extract operation-level sub-tokens from a batch envelope response.

    Each ``<OperationStatus>`` child may carry its own ``<Token>``
    (for pending sub-operations) or its own ``<ID>`` (for completed
    ones). This helper returns the token strings; use
    :attr:`ParsedResponse.operation_status_elements` for full access.
    """
    tokens: list[str] = []
    for op in parsed.operation_status_elements():
        tok = op.find("eidr:Token", _NS)
        if tok is not None and tok.text:
            tokens.append(tok.text.strip())
    return tokens


def raise_for_operation_status(parsed: ParsedResponse, *, operation: str) -> None:
    """Raise a typed exception for any operation-level error in the response.

    A successful ``<Operations>``-envelope write returns
    ``Code 0 success`` at the request level (``<Response><Status>``)
    *and* at the operation level
    (``<Response><RequestStatusResults><OperationStatus><Status>``).
    But the registry can also return ``Code 0 success`` at the
    request level while reporting an *operation-level* error
    (e.g. ``Code 4 validation error: Registrant must match the
    Party ID``). Without this helper, ``parse_response`` would
    classify the response as a generic success envelope and the
    actionable diagnostic would be lost.

    This helper inspects all ``<OperationStatus>`` children and
    raises the first non-zero one with its full ``Code`` / ``Type``
    / ``Details`` context attached. The exception type is selected
    by :func:`_status_to_exception` based on the operation-level
    ``<Type>`` string — same dispatch used for request-level
    errors.

    Verified against the live ``sandbox2.eidr.org`` registry's
    ``match`` response shape (M9 live-test pass round 4).

    Returns silently if no operation-level error is present.
    """
    for op in parsed.operation_status_elements():
        op_status = op.find("eidr:Status", _NS)
        if op_status is None:
            continue
        code_elem = op_status.find("eidr:Code", _NS)
        type_elem = op_status.find("eidr:Type", _NS)
        details_elem = op_status.find("eidr:Details", _NS)
        if code_elem is None:
            continue
        code_str = (code_elem.text or "").strip()
        try:
            code = int(code_str)
        except ValueError:
            continue
        if code == 0:
            continue
        type_str = (type_elem.text or "").strip() if type_elem is not None else ""
        details_str = (details_elem.text or "").strip() if details_elem is not None else ""
        # Reuse the request-level error dispatcher so callers see
        # the same exception types regardless of whether the error
        # was reported at request or operation level.
        _raise_for_status_code(
            code=code,
            type_str=type_str,
            details=details_str,
            operation=operation,
            body=parsed.raw_body,
        )
