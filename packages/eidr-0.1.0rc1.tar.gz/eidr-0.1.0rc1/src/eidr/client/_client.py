"""Sync HTTP client for the EIDR REST API.

:class:`Client` is the main entry point for SDK users who want to
talk to an EIDR registry. It wraps the transport and response layers
and exposes per-operation methods for each registry service.

Design notes
------------

* **One class, many methods.** The Java SDK uses class-per-operation
  (Registration, Resolution, Query, ...) for inheritance reasons;
  Python is happier with methods on a single client. Method names
  mirror the Java class names in lowercase-with-underscores style.

* **EIDR sync/async is a parameter, not a class distinction.** Every
  write method takes ``immediate: bool``. See :mod:`eidr.client._token`
  for how async operations return a Token that callers poll.

* **Python sync/async is a class distinction.** The sync
  :class:`Client` in this module and the async
  :class:`~eidr.client.AsyncClient` share the same public API
  shape; see :class:`AsyncClient` for the async counterpart. The
  sync/async split is confined to the transport and client-façade
  layers — everything below (envelope builder, operation builders,
  response parser, query-results parser, OperationResult, codec
  layer, record models) is shared verbatim.

* **Resource management.** :class:`Client` supports the context-manager
  protocol; prefer ``with Client(...) as client:`` over manual
  :meth:`close`. The underlying ``httpx.Client`` holds a connection
  pool that leaks sockets if not closed.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import datetime
from types import TracebackType
from typing import TYPE_CHECKING, cast

from eidr.client._envelope import DedupeMode, build_request_envelope
from eidr.client._http import TransportConfig, _Transport
from eidr.client._operations import (
    GraphTraversalType,
    RelationshipType,
    build_add_relationship,
    build_alias,
    build_create,
    build_create_party_body,
    build_create_service_body,
    build_delete,
    build_find_parties_by_name,
    build_find_parties_from_catalog,
    build_find_services_by_name,
    build_find_services_from_catalog,
    build_graph_traversal,
    build_modify,
    build_modify_party_body,
    build_modify_service_body,
    build_promote,
    build_query,
    build_remove_relationship,
    build_replace_relationship,
    build_status_request,
)
from eidr.client._query_results import QueryResults, parse_query_results
from eidr.client._response import (
    OperationStatusEntry,
    ParsedResponse,
    _extract_first_non_status_child,
    extract_duplicate_id,
    extract_inline_record_xml,
    extract_record_xml,
    extract_status_details,
    extract_token,
    parse_response,
    raise_for_operation_status,
)
from eidr.client._results import (
    PartyQueryResults,
    ServiceChildrenResults,
    ServiceQueryResults,
)
from eidr.client._shared import (
    DEFAULT_SUPERPARTY_ID,
    check_superparty_gate,
    coerce_id_to_str,
    embed_party_password,
    resolve_resource_path,
    xml_to_record_codec_dict,
)
from eidr.client._token import Token, TokenStatus
from eidr.client._tracing import TraceSink, resolve_tracing_arg
from eidr.models import parse as parse_record
from eidr.models.enums import CreationType

if TYPE_CHECKING:
    from eidr.credentials import Credentials
    from eidr.models.content import ContentRecord
    from eidr.models.party import PartyRecord
    from eidr.models.service import ServiceRecord
    from eidr.models.virtual import VirtualFields
    from eidr.registries import Registry


__all__ = ["Client"]


class Client:
    """Sync HTTP client for the EIDR REST API.

    Talks to a single :class:`~eidr.registries.Registry`. Create one
    per thread; the underlying ``httpx.Client`` is not thread-safe for
    concurrent use (use one Client per thread, or serialize access).

    Args:
        registry: The :class:`~eidr.registries.Registry` endpoint to
            talk to (e.g., :data:`eidr.registries.PRODUCTION` or
            :data:`~eidr.registries.SANDBOX2`).
        credentials: Optional :class:`~eidr.credentials.Credentials`.
            When absent, only anonymous reads against read-only
            endpoints will succeed; writes will be refused locally.
        transport_config: Low-level transport tuning (timeouts,
            retries, TLS verification). Defaults are conservative.
        tracing: Enable request/response tracing. When set, every
            HTTP round-trip — including retries and failures —
            emits a :class:`~eidr.client.TraceRecord` to the
            configured sink.

            * ``None`` / ``False`` (default): no tracing.
            * ``True``: log to the default logger
              (``"eidr.client.trace"``) at INFO level.
            * A :class:`~eidr.client.TraceSink` instance (e.g.,
              :class:`~eidr.client.FileSink`,
              :class:`~eidr.client.ListSink`, or a custom sink):
              records are delivered there.

            Tracing is the primary support-diagnostic path: when
            users report issues against a live registry, a trace of
            the full HTTP conversation is usually required to
            diagnose root cause. Credential values in request
            headers (``Authorization`` etc.) are redacted at
            capture time before reaching any sink.

    Example::

        from eidr import Client, Credentials, registries
        from eidr.client import FileSink

        creds = Credentials.from_env()
        with Client(
            registries.SANDBOX2, creds,
            tracing=FileSink("/tmp/eidr-trace.log"),
        ) as client:
            record = client.resolve("10.5240/7791-8534-2C23-9030-8610-5")
            print(record.title)
    """

    __slots__ = (
        "_credentials",
        "_enforce_superparty_gate",
        "_registry",
        "_superparty_id",
        "_trace_sink",
        "_transport",
    )

    def __init__(
        self,
        registry: Registry,
        credentials: Credentials | None = None,
        *,
        transport_config: TransportConfig | None = None,
        tracing: TraceSink | bool | None = None,
        superparty_id: str = DEFAULT_SUPERPARTY_ID,
        enforce_superparty_gate: bool = True,
    ) -> None:
        """Initialize a synchronous EIDR client.

        Args:
            registry: The :class:`Registry` to talk to (sandbox /
                production / etc.).
            credentials: Optional :class:`Credentials` for
                authenticated operations. Required for any write
                operation; resolve / query can run anonymously
                (with the loss of Alt-ID-bearing fields).
            transport_config: Optional HTTP transport tuning.
            tracing: Optional :class:`TraceSink` for capturing
                request/response wire bytes.
            superparty_id: The Party ID that the
                Party-administration gate will require. Defaults to
                :data:`DEFAULT_SUPERPARTY_ID` (``"10.5237/superparty"``,
                a universal constant across all EIDR registries).
                Override only if the registry's Superparty ID
                changes (e.g., a hypothetical future rotation) or
                if running against a non-standard test deployment.
            enforce_superparty_gate: If true (the default), the
                seven Party-administration methods (``create_party``,
                ``modify_party``, ``delete_party``, ``alias_party``,
                ``activate_party``, ``deactivate_party``,
                ``change_party_password``) check that the configured
                credentials' Party ID matches ``superparty_id``
                before doing any wire work; mismatches raise
                :class:`~eidr.errors.EIDRSDKPolicyError`. Read
                operations (``resolve_party``, ``party_query``)
                are never gated. Set to ``False`` only when
                testing the SDK itself or in the unusual case
                where the caller is the Superparty under a
                non-default ID.
        """
        self._registry = registry
        self._credentials = credentials
        self._superparty_id = superparty_id
        self._enforce_superparty_gate = enforce_superparty_gate
        self._trace_sink = resolve_tracing_arg(tracing)
        self._transport = _Transport(
            registry=registry,
            credentials=credentials,
            config=transport_config,
            trace_sink=self._trace_sink,
        )

    # ─── lifecycle ──────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP connection pool.

        Safe to call more than once; subsequent calls are no-ops.
        Prefer the context-manager protocol (``with Client(...) as c:``)
        which calls this automatically.
        """
        self._transport.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    @property
    def registry(self) -> Registry:
        """The :class:`~eidr.registries.Registry` this client is bound to."""
        return self._registry

    def _check_superparty_gate(self, operation: str) -> None:
        """Internal helper: invoke the Party-write Superparty gate.

        Called at the entry point of each gated Party-administration
        method, before any wire work. If the gate is disabled
        (``enforce_superparty_gate=False`` at construction) this is
        a fast no-op. If the gate is enabled and the configured
        credentials' Party ID matches the configured Superparty ID
        this is also a no-op. Otherwise raises
        :class:`~eidr.errors.EIDRSDKPolicyError`.

        The gate requires credentials to be present. If credentials
        are absent (anonymous client), the seven gated operations
        would fail server-side with auth error anyway; we surface
        a clearer client-side error here.
        """
        if not self._enforce_superparty_gate:
            return
        if self._credentials is None:
            from eidr.errors import EIDRSDKPolicyError

            raise EIDRSDKPolicyError(
                f"{operation}() requires Superparty credentials but the "
                f"client was constructed without credentials. Provide "
                f"credentials whose Party ID matches the configured "
                f"Superparty ID ({self._superparty_id!r}), or pass "
                f"enforce_superparty_gate=False to disable the gate.",
                policy="superparty_required",
                operation=operation,
                configured_value=None,
                required_value=self._superparty_id,
            )
        check_superparty_gate(
            enforce=True,
            superparty_id=self._superparty_id,
            caller_party_id=self._credentials.party_id,
            operation=operation,
        )

    # ─── read operations ────────────────────────────────────────────────

    def resolve(
        self,
        eidr_id: str,
        *,
        resolution_type: str = "Full",
        follow_alias: bool = True,
    ) -> ContentRecord | PartyRecord | ServiceRecord:
        """Resolve an EIDR ID to its current record.

        Performs a single GET against the registry's ``/object/{id}``
        endpoint (or the Party/Service equivalent, selected by ID
        prefix). Idempotent reads are retried on transport failures
        per :class:`~eidr.client._http.TransportConfig`.

        Args:
            eidr_id: The EIDR ID to resolve. Supports Content
                (``10.5240/...``), Party (``10.5237/...``), and
                Service (``10.5239/...``) IDs.
            resolution_type: One of ``"Full"``, ``"Self"``,
                ``"Provenance"``, ``"Inherited"``, ``"SimpleMetadata"``,
                ``"DOIKernel"``, or ``"LinkedAlternateIDs"``. Controls
                which view of the record the registry returns. Defaults
                to ``"Full"``, which includes inherited values.
            follow_alias: If ``True`` (default), the registry follows
                alias chains transparently and returns the final
                destination record. If ``False``, the registry returns
                the raw alias entry itself. Chains deeper than 5 levels
                return an :class:`~eidr.models.AliasContinuation`
                regardless.

        Returns:
            A :class:`ContentRecord`, :class:`PartyRecord`, or
            :class:`ServiceRecord` depending on the ID prefix.

        Raises:
            EIDRNotFoundError: The ID does not exist in the registry.
            EIDRAuthenticationError: Credentials missing or invalid
                (for protected records).
            EIDRTransportError: Network-level failure after retries.
        """
        # Resource path uses the ID verbatim (registry URLs preserve
        # the DOI separator). We don't validate the ID locally — the
        # registry produces a clearer not-found error than any
        # client-side check, and accepting unknown ID formats lets
        # callers explore the registry without fighting the SDK.
        resource_path = resolve_resource_path(eidr_id)
        params: dict[str, str] = {}
        if resolution_type != "Full":
            params["type"] = resolution_type
        if not follow_alias:
            params["followAlias"] = "false"

        body = self._transport.get(resource_path, params=params or None)
        parsed = parse_response(body, operation=f"resolve {eidr_id}")
        if parsed.kind != "record":
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"Expected a record response from resolve {eidr_id}, "
                f"got envelope kind={parsed.kind!r} "
                f"(status_code={parsed.status_code}, status_type="
                f"{parsed.status_type!r})."
            )
        record_xml = extract_record_xml(parsed)
        record = parse_record(record_xml)
        return record  # type: ignore[return-value]

    def status_lookup(
        self,
        token: str,
        *,
        page_number: int | None = None,
        page_size: int | None = None,
    ) -> ParsedResponse:
        """Look up the status of a pending async operation.

        This is a low-level primitive used by :class:`Token.poll` and
        :class:`Token.wait`; most callers should work with
        :class:`Token` directly rather than calling this. The method
        returns the parsed response envelope so callers can inspect
        per-operation status details.

        Two wire paths:

        - **No pagination** (default — both ``page_number`` and
          ``page_size`` left as ``None``): GETs ``/status/{token}``.
          This is the path used by ``Token.poll/wait`` for typical
          single-token poll loops.
        - **Paginated** (either ``page_number`` or ``page_size``
          set): POSTs to ``/status/`` with a ``<Token>`` element in
          the request body. Mirrors the Java SDK's
          ``statusLookupViaToken(..., pageNumber, pageSize)`` and is
          useful for batch-token responses where the registry
          returns many sub-operations across multiple pages.

        Args:
            token: The token string returned by a previous async
                write operation.
            page_number: Page number (1-indexed). If set, the method
                uses the paginated POST path. Default ``None``
                (use simple GET).
            page_size: Page size. If set, the method uses the
                paginated POST path. Default ``None``.

        Returns:
            The parsed response envelope. The envelope's
            ``operation_status_elements()`` iterate over per-operation
            sub-results; :func:`iter_sub_tokens` extracts any
            sub-tokens for batch drill-down.

        Raises:
            EIDRNotFoundError: The token is unknown to the registry
                (too old, wrong registry, or never issued).
            EIDRTransportError: Network failure after retries.
        """
        if not token or not isinstance(token, str):
            raise ValueError(f"token must be a non-empty string, got {token!r}")

        # No pagination: simple GET, preserves Token.poll/wait
        # backwards compatibility.
        if page_number is None and page_size is None:
            resource_path = f"/status/{token}"
            body = self._transport.get(resource_path)
            return parse_response(body, operation=f"status_lookup {token}")

        # Paginated: POST path. Java parity for
        # statusLookupViaToken(..., pageNumber, pageSize).
        body_xml = build_status_request(
            token=token,
            page_number=page_number if page_number is not None else 1,
            page_size=page_size if page_size is not None else 20,
        )
        body = self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup {token}")

    def status_lookup_by_user(
        self,
        user_id: str,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """List recent operations submitted by a specific user.

        POSTs ``<Request><Operation><StatusRequest>...</StatusRequest></Operation></Request>``
        to ``/status/`` with the user ID in a ``<UserID>`` element.
        Mirrors Java's ``StatusLookup.statusLookupViaUser``.

        Note: the Java SDK has a registry-bug workaround that
        forces all per-tag lookups through the POST path (rather
        than ``GET /status/user/{user_id}``) because the GET path
        corrupts user IDs that contain ``/`` — and EIDR user IDs
        always do (e.g. ``10.5238/richardkroon``). The Python SDK
        matches that behavior unconditionally.

        Args:
            user_id: User ID (e.g. ``10.5238/richardkroon``).
            page_number: Page number (1-indexed). Default 1.
            page_size: Page size. Default 20.
            status: Optional status filter (e.g. ``"completed"``).
            after: Optional start of date range. Used alone for
                "operations after this datetime"; paired with
                ``before`` for an explicit range. Naïve datetimes
                are interpreted as UTC.
            before: Optional end of date range. Must be paired
                with ``after``.

        Returns:
            The parsed response envelope. Iterate
            ``parsed.operation_status_elements()`` to walk the
            per-operation results.
        """
        user_id = coerce_id_to_str(user_id, param_name="user_id")
        body_xml = build_status_request(
            user_id=user_id,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup_by_user {user_id}")

    def status_lookup_by_registrant(
        self,
        registrant: str,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """List recent operations submitted by a specific registrant party.

        POSTs to ``/status/`` with the party ID in a
        ``<Registrant>`` element. Mirrors
        ``StatusLookup.statusLookupViaRegistrant``. Same
        always-POST workaround as :meth:`status_lookup_by_user`.

        Args:
            registrant: Party ID (e.g. ``10.5237/FFDA-9947``).
            page_number: Page number (1-indexed). Default 1.
            page_size: Page size. Default 20.
            status: Optional status filter (e.g. ``"completed"``).
            after: Optional start of date range. See
                :meth:`status_lookup_by_user`.
            before: Optional end of date range. Must be paired with
                ``after``.

        Returns:
            The parsed response envelope.
        """
        registrant = coerce_id_to_str(registrant, param_name="registrant")
        body_xml = build_status_request(
            registrant=registrant,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation=f"status_lookup_by_registrant {registrant}")

    def status_lookup_superparty(
        self,
        *,
        page_number: int = 1,
        page_size: int = 20,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> ParsedResponse:
        """List recent operations across all child parties (Superparty-only).

        POSTs to ``/status/`` with no tag element — the registry
        uses the auth credentials' Superparty status to authorize
        the wider lookup. Non-Superparty callers will receive an
        ``EIDRAuthorizationError`` from the registry. Mirrors
        ``StatusLookup.statusLookupSuperparty``.

        Note: this method is **not** gated by the SDK's Superparty
        gate (see :class:`Client.__init__`'s
        ``enforce_superparty_gate`` kwarg). The gate is for
        *destructive* Party-administration operations; status
        lookups are read-only and the registry handles the
        authorization. Callers who use this method without
        Superparty credentials will see a server-side
        ``EIDRAuthorizationError`` rather than a client-side
        ``EIDRSDKPolicyError``.

        Args:
            page_number: Page number (1-indexed). Default 1.
            page_size: Page size. Default 20.
            status: Optional status filter.
            after: Optional start of date range. See
                :meth:`status_lookup_by_user`.
            before: Optional end of date range.

        Returns:
            The parsed response envelope.
        """
        body_xml = build_status_request(
            superparty=True,
            page_number=page_number,
            page_size=page_size,
            status=status,
            after=after,
            before=before,
        )
        body = self._transport.post(
            "/status/",
            body_xml,
            immediate=True,
            requires_writable=False,
        )
        return parse_response(body, operation="status_lookup_superparty")

    def iter_status_by_user(
        self,
        user_id: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> Iterator[OperationStatusEntry]:
        """Iterate status-lookup entries for a user, auto-paging across pages.

        Yields one :class:`OperationStatusEntry` per ``<OperationStatus>``
        element across all pages, stopping when the registry returns a
        page with fewer than ``page_size`` entries (the
        last-page signal) or when ``max_results`` is reached.

        Removes the page-tracking boilerplate from the caller. The
        underlying wire path is the same POST to ``/status/`` used by
        :meth:`status_lookup_by_user`; this method just loops.

        Args:
            user_id: User ID to list operations for.
            page_size: Page size for each underlying call. Default 20.
                Larger values reduce the number of round-trips but
                increase the per-call response size.
            max_results: Optional cap on the total number of entries
                yielded across all pages. ``None`` (default) means
                unlimited — recommended for known-bounded queries
                (date range, status filter); set explicitly for
                queries against very active users to avoid surprise
                pagination cost.
            status: Optional status filter; passed through to each
                underlying call.
            after: Optional date filter; passed through.
            before: Optional date filter; passed through.

        Yields:
            One :class:`OperationStatusEntry` per operation, in
            registry order.

        Example::

            for entry in client.iter_status_by_user(
                "10.5238/richardkroon",
                status="completed",
                max_results=200,
            ):
                print(entry.token, entry.status_type, entry.details)
        """
        yielded = 0
        page_number = 1
        while True:
            response = self.status_lookup_by_user(
                user_id,
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    def iter_status_by_registrant(
        self,
        registrant: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> Iterator[OperationStatusEntry]:
        """Iterate status-lookup entries for a registrant, auto-paging.

        See :meth:`iter_status_by_user` for argument semantics. Same
        contract, scoped to a registrant party rather than a user.
        """
        yielded = 0
        page_number = 1
        while True:
            response = self.status_lookup_by_registrant(
                registrant,
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    def iter_status_superparty(
        self,
        *,
        page_size: int = 20,
        max_results: int | None = None,
        status: str | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
    ) -> Iterator[OperationStatusEntry]:
        """Superparty-only iterator over recent operations across all parties.

        See :meth:`iter_status_by_user` for argument semantics.
        Requires Superparty credentials; non-Superparty callers will
        receive ``EIDRAuthorizationError`` on the first underlying
        call (the iterator yields nothing in that case — the
        exception propagates).
        """
        yielded = 0
        page_number = 1
        while True:
            response = self.status_lookup_superparty(
                page_number=page_number,
                page_size=page_size,
                status=status,
                after=after,
                before=before,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    def iter_status_by_token(
        self,
        token: str,
        *,
        page_size: int = 20,
        max_results: int | None = None,
    ) -> Iterator[OperationStatusEntry]:
        """Iterate operation-status entries for a single token, auto-paging.

        Useful for batch-token responses where the registry returns
        many sub-operation status entries across multiple pages. The
        underlying wire path is :meth:`status_lookup` with the
        paginated POST mode (M10 v2 added pagination kwargs to
        ``status_lookup(token)``); this method just loops.

        For single-token poll loops (``Token.poll`` / ``Token.wait``),
        you don't need this — those already issue one GET per poll
        iteration. Use this method when you have a token whose
        underlying response carries many ``<OperationStatus>``
        children and you want to walk them all without managing
        pagination yourself.

        Args:
            token: The token string returned by a previous async
                write operation.
            page_size: Page size for each underlying call. Default 20.
            max_results: Optional cap on the total number of entries
                yielded across all pages. ``None`` (default) means
                unlimited.

        Yields:
            One :class:`OperationStatusEntry` per ``<OperationStatus>``
            element, in registry order.

        Example::

            for entry in client.iter_status_by_token(batch_token):
                if entry.status_code == 0:
                    print(f"Sub-op completed: {entry.resulting_id or entry.token}")
                else:
                    print(f"Sub-op failed: {entry.status_type} — {entry.details}")
        """
        if not token or not isinstance(token, str):
            raise ValueError(f"token must be a non-empty string, got {token!r}")

        yielded = 0
        page_number = 1
        while True:
            response = self.status_lookup(
                token,
                page_number=page_number,
                page_size=page_size,
            )
            ops = response.operation_status_elements()
            if not ops:
                return
            for op in ops:
                yield OperationStatusEntry.from_element(op)
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if len(ops) < page_size:
                return
            page_number += 1

    def modification_base(
        self,
        asset_id: str,
        *,
        creation_type: CreationType,
    ) -> ContentRecord:
        """Fetch a modification-base record for a Content asset.

        GETs ``/object/modificationbase/{asset_id}?type=Create{CreationType}``.

        Returns a :class:`ContentRecord` carrying the registry's
        pre-filled record body suitable for use as a starting point
        in a subsequent :meth:`modify` call. Workflow::

            base = client.modification_base(
                asset_id, creation_type=CreationType.Basic
            )
            # ...mutate base in place via codec dict...
            client.modify(base)

        If you don't know the asset's creation type at call time,
        use :meth:`modification_base_auto` (which does a
        :meth:`resolve` first to infer it):

        .. code-block:: python

            base = client.modification_base_auto(asset_id)
            # ...mutate...
            client.modify(base)

        Mirrors the Java SDK's ``ModificationBase.getModificationBase``.

        The registry returns the modification-base body in a
        ``<Response>`` envelope wrapping a ``<BaseObjectData>``
        record (Basic creation type). The SDK transparently handles
        both the envelope-wrapped shape and the bare-record shape;
        the returned :class:`ContentRecord` round-trips cleanly
        through :meth:`modify` regardless of which wrapper the
        registry used.

        Args:
            asset_id: The Content ID (``10.5240/...``) to fetch.
            creation_type: The :class:`CreationType` of the record
                (Basic / Series / Season / Episode / Edit / Clip /
                Manifestation / Compilation). **Required** —
                previously defaulted to ``CreationType.Basic``,
                but the default was a footgun: passing the wrong
                creation type returns a wrong-shape record body
                that may parse silently and produce a malformed
                :meth:`modify` payload. The caller must know which
                creation type they're modifying. Use
                :meth:`modification_base_auto` if the creation
                type is not known up front.

        Returns:
            A :class:`ContentRecord` parsed from the registry's
            response body.

        Raises:
            EIDRNotFoundError: The asset doesn't exist.
            EIDRValidationError: The ``creation_type`` doesn't match
                the asset's actual creation type.
            EIDRAuthenticationError / EIDRAuthorizationError: As usual.
            EIDRProtocolError: The response is a Code-0 envelope
                with no record content (would indicate a registry
                shape change).
        """
        from eidr.errors import EIDRProtocolError
        from eidr.models.content import ContentRecord

        asset_id = coerce_id_to_str(asset_id, param_name="asset_id")
        type_param = f"Create{creation_type.value}"
        body = self._transport.get(
            f"/object/modificationbase/{asset_id}",
            params={"type": type_param},
        )

        # The registry has two possible response shapes here, both
        # of which we must handle:
        #
        # 1. Bare record body (e.g. <BaseObjectData>, <FullMetadata>).
        #    parse_response classifies this as kind="record".
        #
        # 2. <Response> envelope with the record nested inside
        #    alongside <Status> (this is what the M10 v1 live test
        #    actually surfaced — Code 0 with the record as a
        #    sibling of <Status>). parse_response classifies this
        #    as kind="envelope" and raises typed exceptions for
        #    any non-zero status.
        parsed = parse_response(body, operation=f"modification_base {asset_id}")

        if parsed.kind == "record":
            return ContentRecord.from_xml(body)

        # kind == "envelope" with Code 0. Find the first non-Status
        # child element — that's the record body.
        record_xml = _extract_first_non_status_child(parsed.root)
        if record_xml is None:
            raise EIDRProtocolError(
                f"modification_base returned a Code 0 envelope with "
                f"no record content (status_code={parsed.status_code}, "
                f"status_type={parsed.status_type!r}). The registry "
                f"is expected to return either a bare record body "
                f"or an envelope wrapping the record alongside Status."
            )
        record = ContentRecord.from_xml(record_xml)

        # The registry's modification_base response intentionally
        # omits the <ID> element from <BaseObjectData> — the asset ID
        # is in the request URL, not the response body. Inject it so
        # the returned record round-trips through modify() without
        # the caller having to re-stamp it.
        if record.base.get("ID") is None:
            record.base["ID"] = asset_id
        return record

    # ─── write operations ───────────────────────────────────────────────

    def register(
        self,
        record: ContentRecord,
        *,
        immediate: bool = False,
        dedupe_mode: DedupeMode | None = None,
        wait_timeout: float | None = None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> Token | ContentRecord:
        """Register a new Content record.

        Submits a Create operation. The registry runs deduplication;
        if the record is clearly unique, registration succeeds and an
        ID is assigned. If deduplication identifies a potential
        match, the operation is held for manual review (unless the
        caller has set ``dedupe_mode`` to override).

        **Pre-submission pipeline (opt-in).** Three keyword flags
        control optional pre-submission processing of the record
        before the XML is built:

        * ``normalize`` → :func:`eidr.models.normalize_whitespace`
          normalizes leading/trailing/interior whitespace in text
          content per the EIDR submission profile.
        * ``strip_empty`` → :func:`eidr.models.strip_empty_tags`
          removes elements whose content is empty after
          normalization (the registry rejects empty elements).
        * ``validate`` → :meth:`ContentRecord.validate_strict` runs
          the full submission-profile validator and raises
          :class:`~eidr.errors.EIDRValidationError` on any error.

        All three default to ``False`` to avoid silent mutation of
        caller data. The recommended pipeline for most callers is::

            client.register(
                record,
                immediate=True,
                normalize=True,
                strip_empty=True,
                validate=True,
            )

        Callers who want finer control should apply
        :func:`eidr.models.normalize_whitespace`,
        :func:`eidr.models.strip_empty_tags`, and
        :meth:`ContentRecord.validate` themselves before calling
        this method and leave all three flags at ``False``.

        Args:
            record: The :class:`ContentRecord` to register. Its
                CreationType determines the Create type
                (``CreateBasic``, ``CreateSeries``, etc.).
            immediate: When ``True``, the registry processes
                synchronously and returns the final outcome in the
                response. Required for single-record registrations
                that need an inline result. Incompatible with
                non-``NORMAL`` ``dedupe_mode`` — the registry will
                reject that combination.
            dedupe_mode: De-duplication handling. ``None`` (default)
                → ``normal`` dedupe. :attr:`DedupeMode.MANUAL` forces
                manual review; :attr:`DedupeMode.ACCEPT` /
                :attr:`DedupeMode.REVIEW` accept or force review and
                are Superparty-restricted. All override modes are
                incompatible with ``immediate=True``.
            wait_timeout: When non-``None`` on an async
                (``immediate=False``) registration, poll the returned
                token for up to ``wait_timeout`` seconds and return
                the completed :class:`ContentRecord` if it resolves
                in that window. If the token is still pending when
                the timeout expires, return the :class:`Token` for
                later polling. Callers who want purely async
                behavior pass ``None`` (or omit).
            validate: When ``True``, run
                :meth:`ContentRecord.validate_strict` against the
                record (in ``"create"`` mode) before submission.
                Raises :class:`~eidr.errors.EIDRValidationError` on
                any error. Default ``False``. See the
                "Pre-submission pipeline" section above.
            normalize: When ``True``, apply
                :func:`eidr.models.normalize_whitespace` to the
                record before submission. Default ``False``.
            strip_empty: When ``True``, apply
                :func:`eidr.models.strip_empty_tags` to remove
                empty elements (which the registry rejects).
                Default ``False``.

        Returns:
            * For ``immediate=True``: **usually** the
              :class:`ContentRecord` the registry registered, with
              the newly-assigned ID populated. **However**, per EIDR
              REST API §2.1.1, when the registry is under load and
              cannot complete dedupe within the immediate-response
              window, it will fall back to async processing and
              return a :class:`Token` instead. Callers invoking
              ``immediate=True`` must therefore handle both return
              types — either check ``isinstance(result, Token)`` or
              call :meth:`Token.operation_result` unconditionally
              via a small helper. The sync-under-load case does not
              affect :meth:`match`; Match always resolves
              synchronously or returns an error.
            * For ``immediate=False`` with ``wait_timeout=None``: a
              :class:`Token` the caller polls.
            * For ``immediate=False`` with a numeric ``wait_timeout``:
              either a :class:`ContentRecord` (if polling resolved
              before the timeout) or a :class:`Token` (if still
              pending).

        Raises:
            EIDRDuplicateError: When dedupe identified a duplicate
                and the operation wasn't forced through.
            EIDRValidationError: When the registry rejected the
                record's structure or content.
            EIDRReadOnlyRegistryError: When targeting a read-only
                registry.
        """
        return self._create_or_match(
            record,
            resource_path="/register/",
            op_name="register",
            immediate=immediate,
            dedupe_mode=dedupe_mode,
            wait_timeout=wait_timeout,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode="create",
        )

    def match(
        self,
        record: ContentRecord,
        *,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> ContentRecord | Token:
        """Dry-run dedupe check against a Content record.

        POSTs to ``/match/``. The registry evaluates the record
        against existing entries as if it were a registration but
        does not commit; the response reflects the dedupe outcome
        (typically the closest matching record).

        Match is always immediate — the Java SDK's Match operation
        implicitly uses immediate mode, and EIDR Operations confirms
        non-immediate Match is unsupported.

        Args:
            record: The :class:`ContentRecord` to test. No ID needs
                to be set.
            validate: Run :meth:`ContentRecord.validate_strict` before
                submission. See :meth:`register` for rationale;
                same opt-in default.
            normalize: Apply :func:`eidr.models.normalize_whitespace`
                before submission.
            strip_empty: Apply :func:`eidr.models.strip_empty_tags`
                before submission.

        Returns:
            The registry's dedupe response, typically a
            :class:`ContentRecord` representing the closest match.
            **The returned record is not the caller's submission** —
            it's whatever existing record the registry deemed the
            closest dedupe candidate. Callers that want to treat a
            match result like a resolved record should be careful
            about that distinction; the :attr:`ContentRecord.id`
            field on a match response is the matched record's ID,
            not the caller's proposed ID (the match operation never
            assigns an ID).

            A :class:`Token` is returned only in the unusual case
            that the registry defers the match (rare but possible on
            a busy sandbox); Match does not participate in the
            sync-under-load fallback the way Create/Modify do.
        """
        return self._create_or_match(
            record,
            resource_path="/match/",
            op_name="match",
            immediate=True,  # Match is always immediate
            dedupe_mode=None,  # dedupe_mode doesn't apply to Match
            wait_timeout=None,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode=None,  # Match doesn't enforce ID presence/absence
        )

    def _create_or_match(
        self,
        record: ContentRecord,
        *,
        resource_path: str,
        op_name: str,
        immediate: bool,
        dedupe_mode: DedupeMode | None,
        wait_timeout: float | None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
        submission_mode: str | None = None,
    ) -> Token | ContentRecord:
        """Shared submit path for :meth:`register` and :meth:`match`.

        Both operations build the same :samp:`<Create type="...">`
        inner XML; they only differ in which endpoint receives it.

        Applies the optional pre-submission pipeline
        (``normalize`` → ``strip_empty`` → ``validate``) to a copy
        of the record when any flag is set. The order matters:
        normalization first (so trimmed whitespace doesn't leave
        whitespace-only elements), then empty-tag stripping (now
        that normalization revealed which tags are really empty),
        then validation (over the cleaned version the registry
        will actually see).
        """
        record = _apply_pre_submission_pipeline(
            record,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode=submission_mode,
        )
        creation_type = record.creation_type
        record_xml = record.to_xml(xml_declaration=False)
        inner = build_create(record_xml, creation_type)

        result = self._submit_write(
            resource_path=resource_path,
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=[dedupe_mode] if dedupe_mode is not None else None,
            wait_timeout=wait_timeout,
            operation_desc=f"{op_name} Content",
        )
        if result is None:
            # Create/Match without an inline record or a token is an
            # unexpected registry response — bare success envelopes
            # should only appear for delete/promote/alias-class writes.
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"{op_name} succeeded but the registry returned "
                f"neither a record nor a token. This is unexpected; "
                f"consider enabling tracing to see the exact response."
            )
        return result

    def modification_base_auto(self, asset_id: str) -> ContentRecord:
        """Resolve first to infer ``creation_type``, then fetch the modification base.

        Convenience wrapper. Workflow::

            base = client.modification_base_auto(asset_id)
            # ...mutate base in place via codec dict...
            client.modify(base)

        For callers who already know the creation type, prefer the
        single-round-trip :meth:`modification_base` instead — this
        helper does an extra resolve to infer it.

        Resolves the asset, reads its :attr:`ContentRecord.creation_type`
        (derived from which ``ExtraObjectMetadata`` block is present),
        then calls :meth:`modification_base` with the inferred type.

        Args:
            asset_id: The Content ID (``10.5240/...``) to fetch.

        Returns:
            A :class:`ContentRecord` parsed from the modification-base
            response. The returned record's effective creation type
            matches the resolved record's.

        Raises:
            EIDRNotFoundError: The asset doesn't exist.
            EIDRClientError: The resolved record carries an
                ``<AliasContinuation>`` (alias records are not
                modifiable — aliases are handled by the Alias
                operation, not Modify).
        """
        from eidr.errors import EIDRClientError
        from eidr.models.content import ContentRecord

        record = self.resolve(asset_id)
        if not isinstance(record, ContentRecord):
            raise EIDRClientError(
                f"{asset_id} resolved to a {type(record).__name__}, not a "
                "ContentRecord. modification_base_auto only supports content "
                "records (Party and Service records have separate workflows)."
            )
        if record.alias_continuation is not None:
            raise EIDRClientError(
                f"{asset_id} is an Alias record (carries <AliasContinuation>); "
                "alias records are not modifiable. Aliases are handled by "
                "the Alias operation, not Modify."
            )
        return self.modification_base(asset_id, creation_type=record.creation_type)

    def modify(
        self,
        record: ContentRecord,
        *,
        immediate: bool = False,
        dedupe_mode: DedupeMode | None = None,
        wait_timeout: float | None = None,
        validate: bool = False,
        normalize: bool = False,
        strip_empty: bool = False,
    ) -> Token | ContentRecord:
        """Modify an existing Content record.

        The record must carry its EIDR ID (set on the record's
        :attr:`~ContentRecord.id` field) — Modify operations require
        the ID to target the existing record. The registry applies
        the change and may re-run dedupe depending on which fields
        were touched.

        Args:
            record: The :class:`ContentRecord` with the intended
                modifications. Must have an ID.
            immediate: See :meth:`register`.
            dedupe_mode: See :meth:`register`.
            wait_timeout: See :meth:`register`.
            validate: See :meth:`register`. Same opt-in semantics;
                validation runs in ``"modify"`` mode (ID-must-be-present).
            normalize: See :meth:`register`.
            strip_empty: See :meth:`register`.

        Returns:
            Either a :class:`ContentRecord` (immediate or polled to
            completion) or a :class:`Token` (still pending, or —
            per EIDR REST API §2.1.1 — returned from an
            ``immediate=True`` call when the registry falls back to
            async processing under load). Callers invoking
            ``immediate=True`` should handle both return types as
            documented on :meth:`register`.

        Raises:
            ValueError: When the record has no ID set.
            EIDRValidationError: When the local validator (if
                ``validate=True``) or the registry rejected the
                modification.
        """
        eidr_id = record.id
        if eidr_id is None:
            raise ValueError(
                "modify() requires record.id to be set; Modify operations "
                "cannot target an unidentified record."
            )
        record = _apply_pre_submission_pipeline(
            record,
            validate=validate,
            normalize=normalize,
            strip_empty=strip_empty,
            submission_mode="modify",
        )
        creation_type = record.creation_type
        record_xml = record.to_xml(xml_declaration=False)
        inner = build_modify(record_xml, str(eidr_id), creation_type)
        result = self._submit_write(
            resource_path="/modify/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=[dedupe_mode] if dedupe_mode is not None else None,
            wait_timeout=wait_timeout,
            operation_desc=f"modify {eidr_id}",
        )
        if result is None:
            from eidr.errors import EIDRProtocolError

            raise EIDRProtocolError(
                f"modify {eidr_id} succeeded but the registry returned "
                f"neither a record nor a token. Enable tracing for details."
            )
        return result

    def delete(
        self,
        eidr_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Delete (alias-to-tombstone) a Content record.

        The registry doesn't physically remove records — Delete is
        implemented as an alias to the EIDR tombstone record
        (``10.5240/0000-0000-0000-0000-0000-X``). The record's ID
        continues to resolve but the resolution follows the alias
        chain to the tombstone.

        Args:
            eidr_id: The ID of the record to delete.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on successful immediate completion; otherwise a
            :class:`Token` for polling.
        """
        inner = build_delete(eidr_id)
        result = self._submit_write(
            resource_path="/register/",  # Delete uses the register endpoint
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"delete {eidr_id}",
        )
        # Delete doesn't return a record — normalize to None on success
        if isinstance(result, Token):
            return result
        return None

    def promote(
        self,
        eidr_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Promote an InDev record to Valid status.

        Promote triggers deduplication review on a record that was
        registered with ``Status=InDev``. If dedupe passes, the
        record becomes active; if dedupe finds a match, the
        operation is held for manual review.

        Args:
            eidr_id: The ID of the record to promote.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on immediate success; otherwise a :class:`Token`.
        """
        inner = build_promote(eidr_id)
        result = self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"promote {eidr_id}",
        )
        if isinstance(result, Token):
            return result
        return None

    def alias(
        self,
        source_id: str,
        target_id: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Alias one record to another.

        Aliasing makes ``source_id`` resolve to the record
        identified by ``target_id``. Alias chains can be followed
        transparently during resolution (see the ``follow_alias``
        parameter on :meth:`resolve`).

        Args:
            source_id: The record that will become the alias.
            target_id: The record that the alias will point to.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on immediate success; otherwise a :class:`Token`.
        """
        inner = build_alias(source_id, target_id)
        result = self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"alias {source_id} -> {target_id}",
        )
        if isinstance(result, Token):
            return result
        return None

    def add_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        info_xml: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Add a lightweight relationship to a record.

        Only the six lightweight relationship types (Composite,
        Language, Packaging, Adjunct, Promotional, AlternateContent)
        can be managed through this operation. Structural
        relationships (IsSeasonOf, IsEpisodeOf) are determined by
        the record's CreationType and modified via
        :meth:`register`/:meth:`modify`.

        Args:
            source_id: The EIDR ID of the record to which the
                relationship is being added.
            relationship_type: One of the six lightweight types.
            info_xml: Pre-formed XML for the relationship info
                element (e.g., ``<PromotionInfo>...</PromotionInfo>``
                for :attr:`RelationshipType.PROMOTIONAL`). The caller
                is responsible for constructing this; the codec
                layer produces it naturally from the corresponding
                ContentRecord fields if needed.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on immediate success; otherwise a :class:`Token`.
        """
        inner = build_add_relationship(source_id, relationship_type, info_xml)
        result = self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"add_relationship {relationship_type.value} on {source_id}",
        )
        if isinstance(result, Token):
            return result
        return None

    def remove_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Remove all lightweight relationships of a given type.

        Removes every relationship of the given type attached to
        the source record. For selective removal, use
        :meth:`replace_relationship` with a narrower info payload.

        Args:
            source_id: The record whose relationships to remove.
            relationship_type: The relationship type to remove.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on immediate success; otherwise a :class:`Token`.
        """
        inner = build_remove_relationship(source_id, relationship_type)
        result = self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"remove_relationship {relationship_type.value} on {source_id}",
        )
        if isinstance(result, Token):
            return result
        return None

    def replace_relationship(
        self,
        source_id: str,
        relationship_type: RelationshipType,
        info_xml: str,
        *,
        immediate: bool = False,
        wait_timeout: float | None = None,
    ) -> Token | None:
        """Atomically replace all relationships of a given type.

        Removes existing relationships of the given type and adds
        the one provided, as a single atomic operation. For
        relationships that can exist multiply, this replaces the
        entire set.

        Args:
            source_id: The record whose relationships to replace.
            relationship_type: The relationship type.
            info_xml: The replacement info element.
            immediate: See :meth:`register`.
            wait_timeout: See :meth:`register`.

        Returns:
            ``None`` on immediate success; otherwise a :class:`Token`.
        """
        inner = build_replace_relationship(source_id, relationship_type, info_xml)
        result = self._submit_write(
            resource_path="/register/",
            operations_xml=[inner],
            immediate=immediate,
            dedupe_modes=None,
            wait_timeout=wait_timeout,
            operation_desc=f"replace_relationship {relationship_type.value} on {source_id}",
        )
        if isinstance(result, Token):
            return result
        return None

    # ─── query operations ───────────────────────────────────────────────

    def query(
        self,
        expression: str,
        *,
        page_number: int = 1,
        page_size: int = 25,
        id_only: bool = False,
    ) -> QueryResults:
        """Run a content-registry query.

        POSTs to ``/query/`` (or ``/query/?type=ID`` for
        ``id_only=True``). The registry paginates responses; use
        :attr:`QueryResults.has_more_pages` or compare
        :attr:`~QueryResults.total_matches` against the cumulative
        item count to decide whether to request another page.

        Args:
            expression: EIDR query expression. See the EIDR Registry
                Technical Overview for the grammar; common forms
                include XPath-style field navigation plus operators
                ``=``, ``HAS``, ``EXISTS``, and parenthesised boolean
                combinators (e.g.,
                ``"/FullMetadata/BaseObjectData/ReferentType IS Movie"``).
            page_number: 1-indexed page number.
            page_size: Records per page. The registry enforces an
                upper limit; exceeding it returns a
                ``result too long`` status code.
            id_only: When ``True``, fetch only EIDR IDs rather than
                full SimpleMetadata. Faster and lighter for callers
                that just need the ID list. Returns IDs in
                :attr:`QueryResults.ids`.

        Returns:
            A :class:`QueryResults` with pagination metadata and
            either :attr:`~QueryResults.records` (full-metadata) or
            :attr:`~QueryResults.ids` (ID-only) populated.

        Raises:
            EIDRValidationError: For malformed query expressions.
            EIDRAuthenticationError / EIDRAuthorizationError: If the
                caller isn't authorized to query.
        """
        inner = build_query(
            expression,
            page_number=page_number,
            page_size=page_size,
        )
        envelope = build_request_envelope([inner])
        resource_path = "/query/?type=ID" if id_only else "/query/"
        body = self._transport.post(
            resource_path, envelope, immediate=True, requires_writable=False
        )
        parsed = parse_response(body, operation="query")
        return parse_query_results(parsed, page_number=page_number, page_size=page_size)

    def iter_query(
        self,
        expression: str,
        *,
        page_size: int = 25,
        max_results: int | None = None,
    ) -> Iterator[ContentRecord]:
        """Iterate full-metadata query results, auto-paging.

        R2#1 (0.1.0b2): ergonomic parity with the status-lookup
        iterators. Removes the page-tracking boilerplate from
        callers walking long query result sets.

        Yields one :class:`ContentRecord` per match across all
        pages. Stops when the underlying :meth:`query` reports no
        more pages (via :attr:`QueryResults.has_more_pages`) or
        when ``max_results`` is reached.

        For ID-only iteration, use :meth:`iter_query_ids` (yields
        strings, much lighter wire payload).

        Args:
            expression: EIDR query expression. See :meth:`query`.
            page_size: Records per underlying call. Default 25.
                Larger values reduce the number of round-trips but
                increase per-call response size.
            max_results: Optional cap on the total number of records
                yielded across all pages. ``None`` (default) means
                unlimited — recommended for known-bounded queries
                only; set explicitly for broad queries.

        Yields:
            One :class:`ContentRecord` per match, in registry order.

        Example::

            for record in client.iter_query(
                "/FullMetadata/BaseObjectData/ReferentType IS Movie",
                max_results=500,
            ):
                print(record.id, record.resource_name)
        """
        yielded = 0
        page_number = 1
        while True:
            results = self.query(
                expression,
                page_number=page_number,
                page_size=page_size,
                id_only=False,
            )
            if not results.records:
                return
            for record in results.records:
                yield record
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if not results.has_more_pages:
                return
            page_number += 1

    def iter_query_ids(
        self,
        expression: str,
        *,
        page_size: int = 25,
        max_results: int | None = None,
    ) -> Iterator[str]:
        """Iterate ID-only query results, auto-paging.

        Like :meth:`iter_query` but yields EIDR ID strings instead
        of full :class:`ContentRecord` instances. Significantly
        faster and lighter for bulk-ID workflows (e.g., walking a
        large result set to feed a downstream batch process).

        Args:
            expression: EIDR query expression. See :meth:`query`.
            page_size: Records per underlying call. Default 25.
            max_results: Optional cap on the total number of IDs
                yielded across all pages.

        Yields:
            EIDR ID strings.
        """
        yielded = 0
        page_number = 1
        while True:
            results = self.query(
                expression,
                page_number=page_number,
                page_size=page_size,
                id_only=True,
            )
            if not results.ids:
                return
            for id_str in results.ids:
                yield id_str
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return
            if not results.has_more_pages:
                return
            page_number += 1

    def graph_traversal(
        self,
        operation: GraphTraversalType,
        eidr_id: str,
        *,
        referent_type_filter: str | None = None,
        structural_type_filter: str | None = None,
        relationship_type_filter: str | None = None,
    ) -> QueryResults:
        """Walk the EIDR graph relative to a given record.

        POSTs to ``/object/graph/``. Supports the nine traversal
        operations enumerated in :class:`GraphTraversalType`: full
        ancestor/descendant walks with optional filters, single-hop
        parent/child lookups, and specialized series/leaf queries.

        Args:
            operation: Which traversal to invoke (see
                :class:`GraphTraversalType`).
            eidr_id: The EIDR ID anchoring the traversal.
            referent_type_filter: Optional filter on the target
                records' ``ReferentType`` (``Movie``, ``TV``, etc.).
                Only meaningful for ancestor/descendant variants.
            structural_type_filter: Optional filter on
                ``StructuralType`` (``Abstraction``, ``Performance``,
                ``Digital``, ``Interactive``).
            relationship_type_filter: Optional filter on the
                structural relationship (``IsSeasonOf``, etc.).

        Returns:
            A :class:`QueryResults` whose
            :attr:`~QueryResults.records` list is the sequence of
            matching records. For simple operations like
            ``GET_PARENT`` the list has at most one element; for
            ``FIND_DESCENDANTS`` on a series it can be quite large.

        Raises:
            EIDRNotFoundError: The anchor ID doesn't exist.
            EIDRValidationError: For unsupported filter values.
        """
        inner = build_graph_traversal(
            operation,
            eidr_id,
            referent_type_filter=referent_type_filter,
            structural_type_filter=structural_type_filter,
            relationship_type_filter=relationship_type_filter,
        )
        envelope = build_request_envelope([inner])
        body = self._transport.post(
            "/object/graph/", envelope, immediate=True, requires_writable=False
        )
        parsed = parse_response(body, operation=f"graph_traversal {operation.value} {eidr_id}")
        return parse_query_results(parsed)

    def party_query(
        self,
        query_xml: str,
        *,
        full: bool = False,
    ) -> ParsedResponse:
        """Query the Party registry with a caller-supplied query body.

        Unlike the content ``query`` service, the Party query
        endpoint takes the query element **directly** as the POST
        body (no ``<Request><Operation>`` wrapper, per the EIDR 2.6
        REST API Reference §2.3.15). Typical bodies are
        ``<FindPartiesByName>`` or ``<FindPartiesFromCatalog>``; the
        full grammar is documented in ``party-query.xsd``.

        This iteration exposes the low-level escape-hatch API — the
        caller builds the query XML and receives the parsed response
        envelope. The typed convenience helpers
        :meth:`find_parties_by_name` and
        :meth:`find_parties_from_catalog` build on top of this
        method.

        Args:
            query_xml: The complete ``<FindPartiesByName>`` (or
                similar) XML body, well-formed and with the EIDR
                namespace declared.
            full: If ``True``, request full Party records in the
                response (``?type=full`` query parameter). If
                ``False`` (default), return ID-only matches.
                Mirrors Java's ``bFull`` parameter.

        Returns:
            The :class:`ParsedResponse` envelope. Callers can extract
            per-party results from
            :attr:`ParsedResponse.root` via namespace-qualified XPath
            against the registry's party-query response schema.

        Raises:
            EIDRAuthenticationError / EIDRAuthorizationError: If the
                caller isn't authorized for the Party service.
        """
        if not query_xml or not query_xml.strip():
            raise ValueError("query_xml must not be empty")
        params = {"type": "full"} if full else None
        body = self._transport.post(
            "/party/query/",
            query_xml,
            immediate=True,
            requires_writable=False,
            params=params,
        )
        return parse_response(body, operation="party_query")

    def service_query(
        self,
        query_xml: str,
        *,
        full: bool = False,
    ) -> ParsedResponse:
        """Query the Video Service registry with a caller-supplied query body.

        Same escape-hatch pattern as :meth:`party_query`: the caller
        provides the full XML body and receives the parsed envelope.
        POSTs to ``/service/query/`` per the EIDR 2.6 REST API
        Reference.

        Args:
            query_xml: The complete query-element XML body.
            full: If ``True``, request full Service records via the
                ``?type=full`` query parameter. **Note:** the Java
                reference SDK's literals map has the service-side
                full path commented out, suggesting it may not be
                supported by all registry versions. If the registry
                rejects ``?type=full``, the rejection propagates as
                a typed exception (typically
                :class:`EIDRValidationError` for ``Code 9 syntax
                error``) — there's no automatic fallback. Live
                integration verifies that ``find_services_from_catalog``
                without ``full=True`` works against sandbox2; the
                ``full=True`` path is best-effort.

        Returns:
            The :class:`ParsedResponse` envelope.
        """
        if not query_xml or not query_xml.strip():
            raise ValueError("query_xml must not be empty")
        params = {"type": "full"} if full else None
        body = self._transport.post(
            "/service/query/",
            query_xml,
            immediate=True,
            requires_writable=False,
            params=params,
        )
        return parse_response(body, operation="service_query")

    # ─── Typed query helpers (M11-B) ─────────────────────────────────────

    def find_parties_by_name(
        self,
        party_name: str,
        *,
        include_alt_names: bool = True,
        role_filter: str | None = None,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> PartyQueryResults:
        """Find Parties matching a name string.

        Typed convenience wrapper over :meth:`party_query`. Builds a
        ``<FindPartiesByName>`` body with the given parameters and
        posts it. Mirrors Java's
        ``PartyQuery.findPartiesByName(request, includeAltNames, bFull)``.

        Args:
            party_name: Name (or substring) to match.
            include_alt_names: If true, also match alternate names.
                Default true.
            role_filter: Optional role filter (e.g. ``"registrant"``,
                ``"editor"``).
            active_filter: ``"active"``, ``"inactive"``, or ``"all"``.
                Default ``"active"`` to match Java SDK behavior. Pass
                ``"all"`` to include both active and inactive records.
            page_number: 1-indexed page number. Default 1.
            page_size: Page size. Default 20.
            continuation_token: Optional continuation token for
                stateful paging across very large result sets.
            full: If true, request full Party records in the
                response. Default false (ID-only).

        Returns:
            A :class:`PartyQueryResults` exposing
            :attr:`~PartyQueryResults.total_matches`,
            :attr:`~PartyQueryResults.party_ids` (when ``full=False``),
            :attr:`~PartyQueryResults.parties` (when ``full=True``),
            and :attr:`~PartyQueryResults.continuation_token` for
            paging. The underlying :class:`ParsedResponse` is
            available via :attr:`~PartyQueryResults.raw_response`.
        """
        body_xml = build_find_parties_by_name(
            party_name=party_name,
            include_alt_names=include_alt_names,
            role_filter=role_filter,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = self.party_query(body_xml, full=full)
        return PartyQueryResults.from_response(response)

    def find_parties_from_catalog(
        self,
        party_name: str,
        *,
        role_filter: str | None = None,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> PartyQueryResults:
        """Find Parties in EIDR's curated catalog matching a name.

        Searches against EIDR's curated catalog rather than the open
        party namespace. Useful for finding well-known organizations
        (studios, distributors) by canonical name. Mirrors Java's
        ``PartyQuery.findPartiesFromCatalog``.

        Same parameters as :meth:`find_parties_by_name` except no
        ``include_alt_names`` (the catalog already normalizes
        alternate names).

        Returns:
            A :class:`PartyQueryResults`.
        """
        body_xml = build_find_parties_from_catalog(
            party_name=party_name,
            role_filter=role_filter,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = self.party_query(body_xml, full=full)
        return PartyQueryResults.from_response(response)

    def find_services_by_name(
        self,
        service_name: str,
        *,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> ServiceQueryResults:
        """Find Video Services matching a name string.

        Mirrors Java's ``ServiceQuery.findServicesByName``. No
        ``role_filter`` (services don't have roles) and no
        ``include_alt_names`` (services don't have alternate-name
        search per ``service.xsd``'s ``serviceQueryType``).

        Returns:
            A :class:`ServiceQueryResults`.
        """
        body_xml = build_find_services_by_name(
            service_name=service_name,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = self.service_query(body_xml, full=full)
        return ServiceQueryResults.from_response(response)

    def find_services_from_catalog(
        self,
        service_name: str,
        *,
        active_filter: str = "active",
        page_number: int = 1,
        page_size: int = 20,
        continuation_token: str | None = None,
        full: bool = False,
    ) -> ServiceQueryResults:
        """Find Video Services in EIDR's curated catalog matching a name.

        Mirrors Java's ``ServiceQuery.findServicesFromCatalog``.

        Returns:
            A :class:`ServiceQueryResults`.
        """
        body_xml = build_find_services_from_catalog(
            service_name=service_name,
            active_filter=active_filter,
            page_number=page_number,
            page_size=page_size,
            continuation_token=continuation_token,
        )
        response = self.service_query(body_xml, full=full)
        return ServiceQueryResults.from_response(response)

    # ─── Party / Video Service write operations ─────────────────────────
    #
    # Wire-shape note: Unlike Content writes (which wrap each
    # operation in ``<Operation><Create>...</Create></Operation>``
    # inside a ``<Request>`` envelope), Party and Service writes
    # POST the bare wrapper element (``<CreateParty>``, ``<Party>``,
    # ``<CreateService>``, ``<Service>``) directly as the request
    # body. Reference: Java SDK ``PartyAdmin.java`` and
    # ``ServiceAdmin.java``. The envelope builders for these live in
    # :mod:`eidr.client._operations`.
    #
    # Earlier milestone notes said Party writes were not planned —
    # that was based on a strict reading of REST API §1.1.3 which
    # listed only Resolution and Query as public Party services.
    # The Java reference SDK ships full Party admin operations, and
    # in practice these endpoints are exposed for parties that hold
    # appropriate credentials. Shipping them parallel to Service
    # writes per maintainer direction.
    #
    # Authorization caveat: All Party write operations
    # (``create_party``, ``modify_party``, ``delete_party``,
    # ``alias_party``, ``activate_party``, ``deactivate_party``,
    # ``change_party_password``) and most Service write
    # operations are administrative. The registry decides per-
    # call whether the caller's party + role + credentials
    # authorize the operation. A failure surfaces as
    # :class:`~eidr.errors.EIDRAuthorizationError` (HTTP 403 with
    # registry-side ``AccessDenied`` / ``RoleNotAuthorized``
    # status). Callers should not assume these methods will
    # always succeed for any authenticated party — Operations-
    # role-only operations like ``activate_party`` will refuse
    # for ordinary registrants.

    def create_service(
        self,
        record: ServiceRecord,
        *,
        wait_timeout: float | None = None,
    ) -> ServiceRecord | Token | None:
        """Create a new Video Service record.

        POSTs the service body wrapped in ``<CreateService>`` to
        ``/service/create/``. The registry assigns an ID
        (``10.5239/...``) and returns the created service inline.

        The registry may, under load, return a :class:`Token` instead
        of an inline record (the operation deferred to async). The
        SDK handles both shapes; callers pattern-match on the return
        type the same way as for :meth:`register`.

        Args:
            record: A :class:`ServiceRecord` carrying the service
                body. Per the schema (``serviceCreationType``), the
                body's ``<ID>`` element should be omitted — the
                registry assigns the ID. ``ServiceName`` and
                ``Active`` are required; everything else is optional.
            wait_timeout: If a :class:`Token` is returned and this
                is non-``None``, poll up to this many seconds before
                returning. See :meth:`register` for details.

        Returns:
            * :class:`ServiceRecord`: created service body echoed
              back inline.
            * :class:`Token`: registry deferred; caller polls (or
              this is auto-polled if ``wait_timeout`` is set).
            * ``None``: registry acknowledged success without
              echoing a body or token (rare for create).
        """
        body_xml = build_create_service_body(record.to_xml())
        return cast(
            "ServiceRecord | Token | None",
            self._submit_admin(
                resource_path="/service/create/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"create_service {record.id or '<new>'}",
                record_kind="service",
            ),
        )

    def modify_service(
        self,
        record: ServiceRecord,
        *,
        wait_timeout: float | None = None,
    ) -> ServiceRecord | Token | None:
        """Modify an existing Video Service record.

        POSTs the service body wrapped in ``<Service>`` to
        ``/service/modify/``. The body must include the service's
        ``<ID>`` (otherwise the registry has nothing to target).

        Args:
            record: A :class:`ServiceRecord` with the current full
                state of the service. Per the wire contract, modify
                replaces the entire record content — partial updates
                are not supported at the registry level.
            wait_timeout: See :meth:`create_service`.

        Returns:
            Same shape as :meth:`create_service`.
        """
        if not record.id:
            raise ValueError(
                "modify_service requires record.id to be set; "
                "the registry needs to know which service to modify."
            )
        body_xml = build_modify_service_body(record.to_xml())
        return cast(
            "ServiceRecord | Token | None",
            self._submit_admin(
                resource_path="/service/modify/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"modify_service {record.id}",
                record_kind="service",
            ),
        )

    def delete_service(self, service_id: str) -> None:
        """Delete a Video Service record.

        POSTs (with empty body) to ``/service/delete/{service_id}``.
        Like content delete, the registry doesn't physically remove
        the record — it aliases the ID to a tombstone.

        Args:
            service_id: The service ID to delete (``10.5239/...``).
        """
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        self._transport.post(
            f"/service/delete/{service_id}",
            "",
            immediate=True,
        )

    def alias_service(self, source_id: str, target_id: str) -> None:
        """Alias one service ID to another.

        POSTs (with empty body) to
        ``/service/alias/{source_id}?target={target_id}``. After
        the operation, ``source_id`` resolves to the same service as
        ``target_id``.
        """
        source_id = coerce_id_to_str(source_id, param_name="source_id")
        target_id = coerce_id_to_str(target_id, param_name="target_id")
        self._transport.post(
            f"/service/alias/{source_id}",
            "",
            immediate=True,
            params={"target": target_id},
        )

    def set_service_parent(self, service_id: str, parent_id: str) -> None:
        """Set or change a Video Service's parent.

        POSTs (with empty body) to
        ``/service/parent/{service_id}?parent={parent_id}``.
        """
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        parent_id = coerce_id_to_str(parent_id, param_name="parent_id")
        self._transport.post(
            f"/service/parent/{service_id}",
            "",
            immediate=True,
            params={"parent": parent_id},
        )

    def service_children(
        self,
        service_id: str,
        *,
        include_inactive: bool = False,
    ) -> ServiceChildrenResults:
        """List the immediate children of a Video Service.

        GETs ``/service/children/{service_id}?all={true|false}``.
        Returns a typed :class:`ServiceChildrenResults` exposing
        the children as a list of IDs and (when the registry returns
        full bodies) a list of XML strings parseable into
        :class:`~eidr.models.service.ServiceRecord` instances. The
        underlying :class:`ParsedResponse` is retained as an escape
        hatch via :attr:`ServiceChildrenResults.raw_response`.

        Not paginated at the registry level — the response contains
        all children at once. For most service hierarchies this is
        a small list (a few to a few dozen). Service trees with
        thousands of children would produce large responses; the
        SDK does not page.

        Args:
            service_id: The Service ID whose children to list.
            include_inactive: If true, include children whose
                ``Active`` flag is false. Default is false (active
                children only). Mirrors the Java SDK's
                ``includeInactive`` parameter on
                ``ServiceGraph.getServiceChildren``.

        Returns:
            A :class:`ServiceChildrenResults` with the parent
            ``service_id`` echoed back, plus
            :attr:`~ServiceChildrenResults.child_ids` and/or
            :attr:`~ServiceChildrenResults.children` populated
            depending on the registry's response shape.
        """
        service_id = coerce_id_to_str(service_id, param_name="service_id")
        body = self._transport.get(
            f"/service/children/{service_id}",
            params={"all": "true" if include_inactive else "false"},
        )
        parsed = parse_response(body, operation=f"service_children {service_id}")
        return ServiceChildrenResults.from_response(parsed, service_id=service_id)

    def service_parent(self, service_id: str) -> ServiceRecord | None:
        """Return the parent of a Video Service, or ``None`` if at the root.

        GETs ``/service/parent/{service_id}``. The registry returns
        the parent's full Service body if one exists. If the service
        has no parent, the registry returns a ``Code 4 not found``
        envelope whose ``<Details>`` text refers to the parent (e.g.
        ``"No parent service"``); this method translates that to
        ``None``.

        If the *queried* service ID itself doesn't exist, the
        registry also returns ``Code 4 not found``, but with
        ``<Details>`` referring to the queried ID. This method
        re-raises :class:`EIDRNotFoundError` in that case so the
        caller can distinguish "service exists, no parent" from
        "service doesn't exist".

        Other registry errors (auth, validation, etc.) propagate as
        their normal typed exceptions.

        Mirrors the Java SDK's ``ServiceGraph.getServiceParent``.
        Counterpart to :meth:`set_service_parent`.

        Args:
            service_id: The Service ID whose parent to fetch.

        Returns:
            A :class:`~eidr.models.service.ServiceRecord` for the
            parent service, or ``None`` if the service is at the
            root of its hierarchy.

        Raises:
            EIDRNotFoundError: If the queried ``service_id`` itself
                doesn't exist in the registry. (Distinct from "the
                service exists but has no parent", which returns
                ``None``.)
        """
        from eidr.errors import EIDRNotFoundError
        from eidr.models.service import ServiceRecord

        service_id = coerce_id_to_str(service_id, param_name="service_id")
        body = self._transport.get(f"/service/parent/{service_id}")

        # The registry can respond in two shapes here:
        #   1. A bare <Service> body — the parent's full record.
        #   2. A <Response> envelope — typically Code 4 not-found
        #      either when the service is at the root, or when the
        #      queried service ID itself doesn't exist.
        # parse_response classifies into "record" / "envelope" and
        # raises typed exceptions for any non-zero status.
        try:
            parsed = parse_response(body, operation=f"service_parent {service_id}")
        except EIDRNotFoundError as exc:
            # Disambiguate "service is at root" from "service doesn't
            # exist" via the <Details> text. The "no parent" case
            # mentions parent; the "not found" case mentions the
            # queried ID. If unsure, re-raise — the caller can decide
            # how to handle the ambiguity.
            details = (getattr(exc, "details", None) or "").lower()
            if "parent" in details or details == "":
                # "No parent service" / similar → genuine root case.
                # Empty details we treat conservatively as root —
                # the registry's typical "ID not found" responses do
                # populate Details with the queried ID.
                return None
            if service_id.lower() in details:
                # Details mentions the queried ID — service itself
                # doesn't exist. Surface to caller.
                raise
            # Ambiguous Details — re-raise so the caller can inspect
            # the exception and decide. Better to surface than to
            # silently swallow.
            raise

        if parsed.kind == "record":
            return ServiceRecord.from_xml(body)

        # Envelope with Code 0 — unusual for /service/parent/, but if
        # it happens (e.g. registry returns "no parent" with Code 0
        # and an empty payload rather than Code 4), treat it as None.
        return None

    def create_party(
        self,
        record: PartyRecord,
        password: str,
        *,
        wait_timeout: float | None = None,
    ) -> PartyRecord | Token | None:
        """Create a new Party record.

        POSTs the party body (with embedded password) wrapped in
        ``<CreateParty>`` to ``/party/create/``. The registry
        assigns an ID (``10.5237/XXXX-XXXX``) and returns the
        created party inline.

        The password is bundled into the request body per the
        schema's ``partyCreationType`` — this is the only operation
        in the SDK where a password traverses the wire (other than
        :meth:`change_party_password`). Treat the password argument
        as a sensitive value: avoid logging, prefer environment-
        variable injection over hardcoding.

        Args:
            record: A :class:`PartyRecord` carrying the party body.
                Like service create, the ID should be unset — the
                registry assigns it. The body's ``<Password>``
                element, if present, is overwritten by the
                ``password`` argument.
            password: The new party's password. Required.
            wait_timeout: See :meth:`create_service`.

        Returns:
            Same shape as :meth:`create_service`, but with
            :class:`PartyRecord` instead of :class:`ServiceRecord`.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate is enforced
                (the default) and the configured caller's Party ID
                does not match the configured Superparty ID. See
                :meth:`__init__` for the
                ``enforce_superparty_gate`` and ``superparty_id``
                kwargs.
        """
        self._check_superparty_gate("create_party")
        if not password:
            raise ValueError("password must be non-empty")
        body_xml = embed_party_password(record.to_xml(), password)
        body_xml = build_create_party_body(body_xml)
        return cast(
            "PartyRecord | Token | None",
            self._submit_admin(
                resource_path="/party/create/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"create_party {record.id or '<new>'}",
                record_kind="party",
            ),
        )

    def modify_party(
        self,
        record: PartyRecord,
        *,
        wait_timeout: float | None = None,
    ) -> PartyRecord | Token | None:
        """Modify an existing Party record.

        POSTs the party body wrapped in ``<Party>`` to
        ``/party/modify/``. Per the schema, modify uses
        ``partyResolutionType`` (NOT ``partyCreationType``) — no
        password element appears in the body. Use
        :meth:`change_party_password` to update a password.

        Args:
            record: A :class:`PartyRecord` with the current full
                state of the party. Modification replaces the entire
                record content — partial updates are not supported
                at the registry level.
            wait_timeout: See :meth:`create_service`.

        Returns:
            Same shape as :meth:`create_service`.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("modify_party")
        if not record.id:
            raise ValueError(
                "modify_party requires record.id to be set; "
                "the registry needs to know which party to modify."
            )
        body_xml = build_modify_party_body(record.to_xml())
        return cast(
            "PartyRecord | Token | None",
            self._submit_admin(
                resource_path="/party/modify/",
                body_xml=body_xml,
                wait_timeout=wait_timeout,
                operation_desc=f"modify_party {record.id}",
                record_kind="party",
            ),
        )

    def delete_party(self, party_id: str) -> None:
        """Delete a Party record (alias to tombstone).

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("delete_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        self._transport.post(
            f"/party/delete/{party_id}",
            "",
            immediate=True,
        )

    def alias_party(self, source_id: str, target_id: str) -> None:
        """Alias one party ID to another.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("alias_party")
        source_id = coerce_id_to_str(source_id, param_name="source_id")
        target_id = coerce_id_to_str(target_id, param_name="target_id")
        self._transport.post(
            f"/party/alias/{source_id}",
            "",
            immediate=True,
            params={"target": target_id},
        )

    def activate_party(self, party_id: str) -> None:
        """Mark a Party as active.

        POSTs (empty body) to ``/party/activate/{party_id}``.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("activate_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        self._transport.post(
            f"/party/activate/{party_id}",
            "",
            immediate=True,
        )

    def deactivate_party(self, party_id: str) -> None:
        """Mark a Party as inactive.

        POSTs (empty body) to ``/party/deactivate/{party_id}``.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("deactivate_party")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        self._transport.post(
            f"/party/deactivate/{party_id}",
            "",
            immediate=True,
        )

    def change_party_password(self, party_id: str, new_password: str) -> None:
        """Change a Party's password.

        POSTs (empty body) to
        ``/party/password/{party_id}?password={new_password}``.

        Like :meth:`create_party`, this is one of the rare operations
        where a password traverses the wire. The password sits in
        the URL query string; the SDK URL-encodes the value
        (so a password containing ``&``, ``+``, ``%``, ``=``, or a
        space won't corrupt the request) and **redacts the
        ``password=`` parameter from any trace records** so the
        password doesn't appear in trace logs.

        Raises:
            EIDRSDKPolicyError: If the Superparty gate refuses
                the operation. See :meth:`create_party`.
        """
        self._check_superparty_gate("change_party_password")
        party_id = coerce_id_to_str(party_id, param_name="party_id")
        if not new_password:
            raise ValueError("new_password must be non-empty")
        self._transport.post(
            f"/party/password/{party_id}",
            "",
            immediate=True,
            params={"password": new_password},
        )

    # ─── Virtual fields retrieval ───────────────────────────────────────

    def virtual_fields(self, asset_id: str) -> VirtualFields:
        """Retrieve a record's virtual fields.

        GETs ``/virtual/object/{asset_id}``. Returns the
        :class:`VirtualFields` value object with the record's
        rendered views (``full``, ``self_defined``, ``alias``) — any
        subset may be present depending on what the registry
        computed for the record.

        Args:
            asset_id: The EIDR asset ID (``10.5240/...``).

        Returns:
            A :class:`VirtualFields` instance.
        """
        asset_id = coerce_id_to_str(asset_id, param_name="asset_id")
        body = self._transport.get(
            f"/virtual/object/{asset_id}",
        )
        # Parse the response envelope, extract the VirtualFields element.
        from eidr.codecs import xml as xml_codec
        from eidr.errors import EIDRProtocolError
        from eidr.models.virtual import VirtualFields

        parsed = parse_response(body, operation=f"virtual_fields {asset_id}")

        # Find the <VirtualFields> child of the response payload.
        # The response envelope places VirtualFields directly as a
        # child of <Response> alongside <Status>.
        if not parsed.raw_body:
            raise EIDRProtocolError(f"virtual_fields {asset_id}: response had no XML body")
        codec = xml_codec.to_codec_dict(parsed.raw_body.encode("utf-8"))
        # Walk into Response → VirtualFields
        response_body = next(iter(codec.values())) if codec else {}
        vf_dict = response_body.get("VirtualFields") if isinstance(response_body, dict) else None
        if isinstance(vf_dict, list):
            vf_dict = vf_dict[0] if vf_dict else None
        if not isinstance(vf_dict, dict):
            raise EIDRProtocolError(
                f"virtual_fields {asset_id}: response did not contain a <VirtualFields> element"
            )
        return VirtualFields.from_codec_dict(vf_dict)

    # ─── internal: party / service admin submit helper ──────────────────

    def _submit_admin(
        self,
        *,
        resource_path: str,
        body_xml: str,
        wait_timeout: float | None,
        operation_desc: str,
        record_kind: str,
    ) -> ServiceRecord | PartyRecord | Token | None:
        """Submit a Party/Service admin write and parse the response.

        Companion to :meth:`_submit_write` (which handles Content
        writes and their ``<Operations>`` envelope). This helper
        posts the body directly, parses the response, and dispatches
        on whether a record body, token, or bare ack came back.

        ``record_kind`` is ``"party"`` or ``"service"`` and selects
        which model class to instantiate when an inline record body
        is returned.
        """
        body = self._transport.post(
            resource_path,
            body_xml,
            immediate=True,
        )
        parsed = parse_response(body, operation=operation_desc)

        # Look for an inline record body in either response shape:
        # bare record root, or envelope-wrapped record. The registry
        # may return either depending on operation and load.
        expected_root = "Service" if record_kind == "service" else "Party"
        record_xml = extract_inline_record_xml(parsed, expected_root)
        if record_xml is not None:
            if record_kind == "service":
                from eidr.models.service import ServiceRecord

                return ServiceRecord.from_codec_dict(xml_to_record_codec_dict(record_xml))
            from eidr.models.party import PartyRecord

            return PartyRecord.from_codec_dict(xml_to_record_codec_dict(record_xml))

        # No inline record — check for the registry's ID-in-Details
        # success shape. Verified against the live sandbox during the
        # M9 live-test pass: a successful create_service returns::
        #
        #   <Response><Status>
        #     <Code>0</Code><Type>success</Type>
        #     <Details>10.5239/52C0-0B32</Details>
        #   </Status></Response>
        #
        # The new record's ID is in <Details>. We resolve that ID
        # and return the full record. Resolving avoids returning
        # a partial stub that would surprise callers with empty
        # fields like ServiceName.
        new_id = extract_status_details(parsed)
        if new_id is not None and new_id.startswith("10."):
            from eidr.models.party import PartyRecord
            from eidr.models.service import ServiceRecord

            resolved = self.resolve(new_id)
            if record_kind == "service" and isinstance(resolved, ServiceRecord):
                return resolved
            if record_kind == "party" and isinstance(resolved, PartyRecord):
                return resolved
            # Resolve returned an unexpected type (could be a
            # ContentRecord if the ID prefix lands wrong) — fall
            # through to a stub. The registry already confirmed
            # the operation succeeded, so the caller deserves a
            # usable return value, even if minimal.
            if record_kind == "service":
                return ServiceRecord.from_codec_dict({"Service": {"ID": new_id}})
            return PartyRecord.from_codec_dict({"Party": {"ID": new_id}})

        # No inline record, no <Details> ID — look for a Token
        # (deferred async path).
        token_value = extract_token(parsed)
        if token_value is None:
            return None

        tok = Token(value=token_value, _client=self)
        tok.last_response = parsed

        if wait_timeout is None:
            return tok

        # Caller asked us to poll. Reuse the same logic as
        # _submit_write — we don't have a typed read for
        # party/service tokens, so we just wait for terminal status
        # and return the token.
        tok.wait(timeout=wait_timeout)
        return tok

    # ─── internal: submit, optionally poll ──────────────────────────────

    def _submit_write(
        self,
        *,
        resource_path: str,
        operations_xml: list[str],
        immediate: bool,
        dedupe_modes: list[DedupeMode | None] | None,
        wait_timeout: float | None,
        operation_desc: str,
    ) -> Token | ContentRecord | None:
        """Common write-submit path shared by register/modify/delete/etc.

        Builds the request envelope, POSTs it, parses the response,
        and (for async operations with a ``wait_timeout``) polls the
        returned token up to the given timeout.

        Return values are operation-dependent; callers pattern-match
        what they got:

        * :class:`ContentRecord`: The registry returned a record body
          inline (typical for ``immediate=True`` register/modify where
          the registered/modified record is echoed back).
        * :class:`Token`: The registry returned a token the caller
          should poll. Returned for ``immediate=False`` registrations
          (unless ``wait_timeout`` polling resolved to a record) and
          for ``wait_timeout`` exhaustion (still-pending case).
        * ``None``: The registry returned a success envelope without
          a token or inline record. Typical for
          ``immediate=True`` ``delete``/``promote``/``alias``/
          relationship operations, where the write has no natural
          body to echo.

        On transport failure, any of the usual :class:`EIDRError`
        subclasses may raise.
        """
        envelope = build_request_envelope(operations_xml, dedupe_modes=dedupe_modes)
        body = self._transport.post(
            resource_path,
            envelope,
            immediate=immediate,
        )
        parsed = parse_response(body, operation=operation_desc)

        # Immediate success with an inline record result?
        if parsed.kind == "record":
            return parse_record(extract_record_xml(parsed))  # type: ignore[return-value]

        # Operation-level error check. The registry can return
        # ``Code 0 success`` at the request level while reporting an
        # operation-level failure (e.g. ``Code 4 validation error:
        # Registrant must match the Party ID`` from match against a
        # record whose <Administrators> point to a different party).
        # Without this check, we'd fall through the inline-record /
        # token / details paths and surface a generic
        # EIDRProtocolError, hiding the actionable diagnostic.
        raise_for_operation_status(parsed, operation=operation_desc)

        # Match-result fast path: when the registry's match operation
        # finds a duplicate above the high-threshold, the response
        # carries the matched record's ID inline in
        # <OperationStatus>/<Duplicate>/<ID> *and* a request-level
        # token at <RequestStatus>/<Token>. The token would let the
        # caller poll status_lookup for a deferred result, but the
        # answer is already in the body — resolving the ID directly
        # is much friendlier than returning a Token the caller has
        # to poll. Verified against the live sandbox2 registry (M9
        # round 5): a match against The Great Train Robbery
        # returned::
        #
        #   <OperationStatus>
        #     <Token>...</Token>
        #     <Status><Code>0</Code><Type>success</Type></Status>
        #     <Duplicate score="95" lowThreshold="60"
        #                highThreshold="90">
        #       <ID>10.5240/...</ID>
        #     </Duplicate>
        #   </OperationStatus>
        #
        # Score interpretation: > highThreshold means "definite
        # match"; < lowThreshold means "no match"; in between is the
        # ambiguous range. We surface the ID regardless of score —
        # callers who need the score can inspect parsed.raw_body
        # via the Token.last_response field if they want.
        duplicate_id = extract_duplicate_id(parsed)
        if duplicate_id is not None and duplicate_id.startswith("10."):
            from eidr.models.content import ContentRecord

            resolved = self.resolve(duplicate_id)
            if isinstance(resolved, ContentRecord):
                return resolved
            # Fall through if resolve didn't return a ContentRecord
            # (e.g. the ID was for a Service or Party — shouldn't
            # happen for a Content match but we guard anyway).

        # Envelope response — look for a Token (async path).
        token_value = extract_token(parsed)
        if token_value is not None:
            tok = Token(value=token_value, _client=self)
            tok.last_response = parsed

            if wait_timeout is None:
                return tok

            # Caller wants us to poll. Wait up to wait_timeout; if it
            # resolves to SUCCESS with a record body, surface the
            # record; otherwise return the Token (either resolved to a
            # non-record outcome, or still pending).
            from eidr.errors import EIDRTimeoutError

            try:
                status = tok.wait(timeout=wait_timeout)
            except EIDRTimeoutError:
                return tok

            if status is TokenStatus.SUCCESS:
                final = tok.last_response
                if final is not None and final.kind == "record":
                    return parse_record(extract_record_xml(final))  # type: ignore[return-value]
            return tok

        # No token — check for the registry's ID-in-Details success
        # shape. Verified against the live sandbox (M9 live-test
        # pass): a successful write returns::
        #
        #   <Response><Status>
        #     <Code>0</Code><Type>success</Type>
        #     <Details>10.5240/...</Details>
        #   </Status></Response>
        #
        # The affected record's ID is in <Details>. For Content
        # writes (register/modify/match), we resolve that ID and
        # return the full record. Avoids returning None from match()
        # against a record the registry already has, which used to
        # raise EIDRProtocolError.
        new_id = extract_status_details(parsed)
        if new_id is not None and new_id.startswith("10."):
            from eidr.models.content import ContentRecord

            resolved = self.resolve(new_id)
            if isinstance(resolved, ContentRecord):
                return resolved
            # Resolve returned something unexpected (Token, None) —
            # fall through to the bare-ack handling below.

        # No token, no inline record, no <Details> ID. Bare success
        # acknowledgement — common for delete/promote/alias and
        # relationship operations where the write has no body to
        # echo back.
        return None


# ─── helpers ────────────────────────────────────────────────────────────


def _apply_pre_submission_pipeline(
    record: ContentRecord,
    *,
    validate: bool,
    normalize: bool,
    strip_empty: bool,
    submission_mode: str | None,
) -> ContentRecord:
    """Apply optional pre-submission steps to a ContentRecord.

    Order is fixed: normalize → strip_empty → validate. Each step
    runs only if its flag is ``True``. The original record is not
    mutated; a new :class:`ContentRecord` is constructed from the
    transformed codec dict when any step runs.

    Args:
        record: Caller-supplied record.
        validate: When ``True``, run :meth:`ContentRecord.validate_strict`
            after any normalization/stripping. Raises
            :class:`~eidr.errors.EIDRValidationError` on any error.
        normalize: When ``True``, apply
            :func:`eidr.models.normalize_whitespace` to the record's
            codec dict.
        strip_empty: When ``True``, apply
            :func:`eidr.models.strip_empty_tags` to remove
            empty elements (which the registry rejects).
        submission_mode: Forwarded to ``validate_strict``.
            ``"create"`` enforces ID-must-be-absent, ``"modify"``
            enforces ID-must-be-present, ``None`` only validates ID
            format if present.

    Returns:
        The transformed record (or the original if no flags are set).
    """
    if not (validate or normalize or strip_empty):
        return record

    # Apply transforms only when needed; avoid building a new record
    # for the validate-only path.
    if normalize or strip_empty:
        from eidr.models import normalize_whitespace, strip_empty_tags
        from eidr.models.content import ContentRecord as _ContentRecord

        data = record.data
        if normalize:
            data = normalize_whitespace(data)
        if strip_empty:
            data = strip_empty_tags(data)
        record = _ContentRecord.from_codec_dict(data)

    if validate:
        record.validate_strict(mode=submission_mode)

    return record
