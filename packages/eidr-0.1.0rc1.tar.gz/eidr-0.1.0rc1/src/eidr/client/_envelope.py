"""Request envelope builder for EIDR write operations.

Every EIDR write (Create, Modify, Delete, Alias, Promote,
Add/Remove/ReplaceRelationship) shares the same XML envelope shape:

.. code-block:: xml

    <Request xmlns="http://www.eidr.org/schema"
             xmlns:md="http://www.movielabs.com/schema/md/v2.8/md"
             xmlns:doi="http://doi.org/doi_handbook/XML_Schema"
             xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
      <Operation dedupMode="...">
        <Create type="CreateBasic">
          ...record XML...
        </Create>
      </Operation>
    </Request>

The envelope is shared; the inner operation element varies. This
module supplies one small function, :func:`build_request_envelope`,
that wraps a list of pre-built operation elements in the proper
outer :samp:`<Request>` with optional tokens and per-operation
de-dupe modes.

Even a single-operation call is framed as a "batch of one" in the
EIDR protocol — the Java SDK does this too. Multi-operation batches
(a single request with several operations) are supported for
throughput-sensitive use cases; callers usually won't need them.
"""

from __future__ import annotations

from enum import StrEnum

__all__ = [
    "DedupeMode",
    "build_request_envelope",
]


#: XML namespace URIs used in EIDR write requests.
_EIDR_NS = "http://www.eidr.org/schema"
_MD_NS = "http://www.movielabs.com/schema/md/v2.8/md"
_DOI_NS = "http://doi.org/doi_handbook/XML_Schema"
_XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"

_NAMESPACE_ATTRS = (
    f'xmlns="{_EIDR_NS}" xmlns:md="{_MD_NS}" xmlns:doi="{_DOI_NS}" xmlns:xsi="{_XSI_NS}"'
)


class DedupeMode(StrEnum):
    """De-duplication handling mode for a write operation.

    Sent as the ``dedupMode`` attribute on each ``<Operation>`` element
    in a Register or Modify request. Values are the strings the EIDR
    registry expects on the wire.

    Per the EIDR 2.6 REST API Reference §2.1.4:

    * :attr:`NORMAL` — default. If no ``dedupMode`` attribute is
      present, normal mode applies. Records requiring manual review to
      resolve are referred to EIDR Operations; the caller polls the
      returned token for the final outcome.
    * :attr:`MANUAL` — force manual review, even if the automated
      review process identified an existing duplicate ID. Most often
      used when the caller disagrees with the automated
      de-duplication response and believes the submission is unique.
    * :attr:`ACCEPT` — **Restricted to the Superparty.** Any other
      caller will receive an error from the registry. Accepts the
      record regardless of the dedupe outcome.
    * :attr:`REVIEW` — **Restricted to the Superparty.** Any other
      caller will receive an error from the registry.

    Applies only to ``immediate=False`` (asynchronous) Create and
    Modify operations. Setting it for an ``immediate=True`` request
    causes a registry error — the library does not pre-check this,
    but the registry's error message is clearer than any local check.
    """

    NORMAL = "normal"
    MANUAL = "manual"
    ACCEPT = "accept"
    REVIEW = "review"


def build_request_envelope(
    operations_xml: list[str],
    *,
    request_user_token: str | None = None,
    operation_user_tokens: list[str | None] | None = None,
    dedupe_modes: list[DedupeMode | None] | None = None,
) -> str:
    """Wrap one or more operation-XML strings in the EIDR ``<Request>`` envelope.

    Args:
        operations_xml: List of fully-formed inner XML strings for
            each operation. Each string should be valid operation
            content (e.g.,
            ``'<Create type="CreateBasic"><Basic>...</Basic></Create>'``
            for a register, ``'<Modify>...</Modify>'`` for a modify,
            ``'<Delete><ID>...</ID></Delete>'`` for a delete). This
            function does NOT validate the inner structure.
        request_user_token: Optional caller-supplied token applied at
            the request level (appears as an attribute on
            ``<Request>``). Useful for correlating responses with
            caller-side tracking systems.
        operation_user_tokens: Optional per-operation caller tokens,
            one per operation. When provided, must be the same length
            as ``operations_xml``. Each entry may itself be ``None``
            to skip the token for that specific operation.
        dedupe_modes: Optional per-operation dedupe-mode values, same
            length as ``operations_xml``. Each entry may be ``None``
            to omit the attribute (implicit default of NORMAL).

    Returns:
        The complete ``<Request>...</Request>`` XML as a string, with
        no XML declaration or BOM. The transport layer adds the
        declaration and wraps the result in the multipart envelope.

    Raises:
        ValueError: When ``operations_xml`` is empty, or when the
            optional per-operation lists have a different length than
            ``operations_xml``.
    """
    if not operations_xml:
        raise ValueError("At least one operation is required; got empty list.")

    n = len(operations_xml)
    if operation_user_tokens is not None and len(operation_user_tokens) != n:
        raise ValueError(
            f"operation_user_tokens must have the same length as operations_xml "
            f"({n}); got {len(operation_user_tokens)}."
        )
    if dedupe_modes is not None and len(dedupe_modes) != n:
        raise ValueError(
            f"dedupe_modes must have the same length as operations_xml "
            f"({n}); got {len(dedupe_modes)}."
        )

    request_token_attr = ""
    if request_user_token:
        request_token_attr = f' userToken="{_escape_attr(request_user_token)}"'

    parts = [f"<Request {_NAMESPACE_ATTRS}{request_token_attr}>"]
    for i, op_xml in enumerate(operations_xml):
        attrs = ""
        if operation_user_tokens and operation_user_tokens[i]:
            attrs += f' userToken="{_escape_attr(operation_user_tokens[i] or "")}"'
        if dedupe_modes and dedupe_modes[i] is not None:
            dm = dedupe_modes[i]
            assert dm is not None  # narrowed by the check above
            attrs += f' dedupMode="{dm.value}"'
        parts.append(f"<Operation{attrs}>{op_xml}</Operation>")
    parts.append("</Request>")

    return "".join(parts)


def _escape_attr(s: str) -> str:
    """Escape an attribute value for inclusion in XML.

    Handles the five named entities required by XML 1.0 §2.4.
    Caller tokens are typically short alphanumeric strings, so this
    rarely does anything — but we apply it anyway for robustness
    against surprising input.
    """
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )
