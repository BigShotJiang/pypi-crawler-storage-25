"""Request/response tracing for the EIDR HTTP client.

In practice, diagnosing user-reported problems against a live registry
requires a full record of what went over the wire. The EIDR support
path depends on operators being able to reconstruct the exact
request-response conversation — without that, most issues are
impossible to debug remotely.

This module provides a first-class tracing facility: :class:`Client`
takes a ``tracing`` parameter that, when enabled, captures every
HTTP round-trip — method, URL, all request and response headers, full
request and response bodies, timing, and any exception raised. Traces
are delivered to a :class:`TraceSink`; built-in sinks log to the
standard logging module, write to a file, or accumulate in a list.
Callers can implement their own sink for structured capture
(e.g., emit to a tracing backend or structured-event pipeline).

Sensitive values (the ``Authorization`` header's credential triplet)
are redacted at capture time, not display time, so they never reach
memory or disk even in the :class:`ListSink`. The password has
already been one-way hashed by the auth layer, but the full header
value also encodes user and party IDs and should not be exposed in
shared support artifacts.

Example::

    from eidr import Client, registries
    from eidr.client import ListSink

    sink = ListSink()
    with Client(registries.SANDBOX2, creds, tracing=sink) as client:
        client.resolve("10.5240/...")

    # sink.records now holds one TraceRecord per round-trip
    for rec in sink.records:
        print(rec.method, rec.url, rec.response_status)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Protocol, runtime_checkable

__all__ = [
    "FileSink",
    "ListSink",
    "LoggerSink",
    "TraceRecord",
    "TraceSink",
    "redact_headers",
    "redact_url_query",
]


#: Header names whose values contain credentials and must be redacted
#: before any trace is published. Comparison is case-insensitive.
_SENSITIVE_HEADER_NAMES: frozenset[str] = frozenset(
    {
        "authorization",
        "proxy-authorization",
        "cookie",
        "set-cookie",
    }
)

#: Query-string parameter names whose values are credentials and must
#: be redacted in trace ``url`` fields. Comparison is case-insensitive.
#:
#: ``password`` covers :meth:`Client.change_party_password` (URL-only
#: password parameter — Java SDK shape). Other sensitive params can
#: be added here as new endpoints land.
_SENSITIVE_QUERY_PARAMS: frozenset[str] = frozenset(
    {
        "password",
    }
)

#: Placeholder emitted in place of a redacted value.
_REDACTED = "<REDACTED>"


def redact_url_query(url: str) -> str:
    """Return ``url`` with sensitive query-string values redacted.

    The path, scheme, host, and port are preserved verbatim;
    only matching query-parameter values are replaced with
    :data:`_REDACTED`. Comparison is case-insensitive.

    Designed for use in trace records — both as URL appearing in a
    ``TraceRecord.url`` field and as the human-readable URL in
    sink output. Does NOT handle credentials embedded in the path
    portion of the URL (the SDK doesn't do that anywhere).
    """
    from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

    parts = urlsplit(url)
    if not parts.query:
        return url
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    redacted_pairs = [
        (k, _REDACTED if k.lower() in _SENSITIVE_QUERY_PARAMS else v) for k, v in pairs
    ]
    return urlunsplit(
        (
            parts.scheme,
            parts.netloc,
            parts.path,
            urlencode(redacted_pairs),
            parts.fragment,
        )
    )


@dataclass(frozen=True, slots=True)
class TraceRecord:
    """One HTTP round-trip's worth of trace information.

    All string fields are captured eagerly at request time — this is a
    point-in-time snapshot, safe to serialize, compare, and persist.
    Sensitive header values are already redacted when the record is
    constructed; callers don't need to re-filter before display.

    Attributes:
        method: The HTTP method (``"GET"`` / ``"POST"``).
        url: The full request URL, including any query string.
        request_headers: Request headers as a list of ``(name, value)``
            tuples, preserving order. Sensitive values are already
            redacted.
        request_body: The full request body as text, or ``None`` for
            GETs. Bodies are captured verbatim including any multipart
            framing — that's what support needs to see.
        response_status: HTTP response status code, or ``None`` if
            the request raised before a response was received.
        response_headers: Response headers as a list of ``(name, value)``
            tuples, or an empty list on transport failure. Redacted.
        response_body: The full response body as text, or ``None`` if
            no response was received.
        duration_seconds: Wall-clock time from request start to
            response completion (or exception).
        exception: Repr-style string of any exception raised during
            the round-trip, or ``None`` for successful (2xx / 4xx / 5xx)
            completions.
        attempt: Zero-indexed retry attempt number. ``0`` is the first
            attempt; subsequent attempts increment.
    """

    method: str
    url: str
    request_headers: list[tuple[str, str]]
    request_body: str | None
    response_status: int | None
    response_headers: list[tuple[str, str]]
    response_body: str | None
    duration_seconds: float
    exception: str | None
    attempt: int

    def format_plain(self) -> str:
        """Render the record as a human-readable plain-text block.

        Roughly RFC 7230 style — a good default for log lines or
        support-attachment files. The format is deliberately stable;
        tooling can parse it if needed.
        """
        lines = [
            f"=== {self.method} {self.url} (attempt {self.attempt + 1}) ===",
            "--- Request Headers ---",
        ]
        lines.extend(f"{k}: {v}" for k, v in self.request_headers)
        if self.request_body is not None:
            lines.append("--- Request Body ---")
            lines.append(self.request_body)
        status_label = (
            str(self.response_status) if self.response_status is not None else "NO RESPONSE"
        )
        lines.append(f"--- Response ({status_label}) ---")
        if self.response_headers:
            lines.extend(f"{k}: {v}" for k, v in self.response_headers)
        if self.response_body is not None:
            lines.append("--- Response Body ---")
            lines.append(self.response_body)
        if self.exception is not None:
            lines.append(f"--- Exception: {self.exception}")
        lines.append(f"--- Duration: {self.duration_seconds:.3f}s")
        lines.append("")
        return "\n".join(lines)


@runtime_checkable
class TraceSink(Protocol):
    """Protocol for objects that receive :class:`TraceRecord` instances.

    Any object with a ``write(record)`` method can act as a sink. The
    built-in sinks (:class:`LoggerSink`, :class:`FileSink`,
    :class:`ListSink`) cover common cases; custom sinks can structure
    traces however the caller wants (e.g., route to OpenTelemetry,
    emit JSON-per-line to a stream, or forward to a SaaS observability
    backend).
    """

    def write(self, record: TraceRecord) -> None:
        """Receive a single trace record.

        Implementations must not raise; trace writes run inside the
        HTTP path and should never impede the request. If the sink
        cannot accept the record (disk full, network failure, etc.),
        it should log the failure and swallow it.
        """
        ...


class LoggerSink:
    """Trace sink that writes to a :mod:`logging` logger.

    Each trace record becomes one log entry at the configured level,
    formatted via :meth:`TraceRecord.format_plain`. The default logger
    name is ``eidr.client.trace`` — add a handler on that name to
    capture traces.

    Args:
        logger: Logger instance to use. Defaults to
            ``logging.getLogger("eidr.client.trace")``.
        level: Log level for trace records. Defaults to
            :data:`logging.INFO`.
    """

    __slots__ = ("_level", "_logger")

    def __init__(
        self,
        logger: logging.Logger | None = None,
        level: int = logging.INFO,
    ) -> None:
        self._logger = logger or logging.getLogger("eidr.client.trace")
        self._level = level

    def write(self, record: TraceRecord) -> None:
        import contextlib

        # If logging itself fails, there's nowhere else to report it.
        # Swallow silently so the actual HTTP call isn't affected.
        with contextlib.suppress(Exception):
            self._logger.log(self._level, "%s", record.format_plain())


class FileSink:
    """Trace sink that appends to a file (one record per block).

    The file is opened on construction and held open until
    :meth:`close` (or the sink is garbage-collected). Each record is
    written atomically — no interleaving even if multiple threads
    share the sink, thanks to the underlying file write being a
    single syscall for small writes.

    Args:
        path: File path to write to. Opened in append-text mode.
        encoding: File encoding. Defaults to UTF-8.

    Example::

        sink = FileSink("/tmp/eidr-trace.log")
        client = Client(..., tracing=sink)
        # ... use the client ...
        sink.close()  # or rely on __del__
    """

    __slots__ = ("_file", "_path")

    def __init__(
        self,
        path: str | Path,
        *,
        encoding: str = "utf-8",
    ) -> None:
        self._path = Path(path)
        self._file: IO[str] | None = self._path.open("a", encoding=encoding)

    def write(self, record: TraceRecord) -> None:
        import contextlib

        if self._file is None:
            return
        try:
            self._file.write(record.format_plain())
            self._file.write("\n")
            self._file.flush()
        except Exception:
            # File became unwritable. Try to close cleanly so future
            # writes no-op rather than raising repeatedly.
            with contextlib.suppress(Exception):
                self._file.close()
            self._file = None

    def close(self) -> None:
        """Close the underlying file. Idempotent."""
        if self._file is not None:
            try:
                self._file.close()
            finally:
                self._file = None

    def __del__(self) -> None:
        self.close()


class ListSink:
    """Trace sink that accumulates records in memory.

    Primarily useful for tests (assert on captured traces) and for
    in-process diagnostics where the caller wants programmatic access
    to trace records rather than a file. Not suitable for
    long-running clients with high traffic — the list grows
    unbounded.

    Attribute:
        records: The list of captured :class:`TraceRecord` instances,
            in the order they were written.
    """

    __slots__ = ("records",)

    def __init__(self) -> None:
        self.records: list[TraceRecord] = []

    def write(self, record: TraceRecord) -> None:
        self.records.append(record)

    def clear(self) -> None:
        """Drop all captured records."""
        self.records.clear()


# ─── helpers ────────────────────────────────────────────────────────────────


def redact_headers(headers: dict[str, str]) -> list[tuple[str, str]]:
    """Return a redacted, ordered list of ``(name, value)`` header tuples.

    Case-insensitive: a header whose lowercased name appears in
    :data:`_SENSITIVE_HEADER_NAMES` has its value replaced with
    ``<REDACTED>``. Header order from the input mapping is preserved.
    """
    result: list[tuple[str, str]] = []
    for name, value in headers.items():
        if name.lower() in _SENSITIVE_HEADER_NAMES:
            result.append((name, _REDACTED))
        else:
            result.append((name, value))
    return result


def resolve_tracing_arg(arg: TraceSink | bool | None) -> TraceSink | None:
    """Normalize the ``tracing=`` constructor argument to a sink or None.

    * ``None`` / ``False`` → no tracing (return ``None``).
    * ``True`` → default :class:`LoggerSink` at INFO level.
    * A :class:`TraceSink` instance → passed through.

    Anything else raises :class:`TypeError` with a clear message.
    """
    if arg is None or arg is False:
        return None
    if arg is True:
        return LoggerSink()
    if isinstance(arg, TraceSink):
        return arg
    raise TypeError(
        f"tracing must be a TraceSink, bool, or None; got {type(arg).__name__}. "
        f"Use tracing=True for the default logger sink, tracing=FileSink(path) "
        f"for a file, or a custom TraceSink implementation."
    )


def make_trace_record(
    *,
    method: str,
    url: str,
    request_headers: dict[str, str],
    request_body: str | bytes | None,
    response_status: int | None,
    response_headers: dict[str, str] | None,
    response_body: str | bytes | None,
    start_time: float,
    exception: BaseException | None,
    attempt: int,
    max_body_chars: int | None = 100_000,
    redact_bodies: bool = False,
) -> TraceRecord:
    """Construct a :class:`TraceRecord`, applying redaction and normalization.

    Typically called from the transport layer after each round-trip.
    Handles the conversion between the various types the transport
    might have (bytes for outgoing bodies, httpx's case-insensitive
    response headers, optional response).

    Args:
        method: HTTP method used.
        url: Request URL.
        request_headers: Outgoing request headers (pre-redaction).
        request_body: Outgoing body (str or bytes), or ``None``.
        response_status: HTTP status code, or ``None`` on transport
            failure before a response arrived.
        response_headers: Incoming response headers.
        response_body: Incoming body.
        start_time: Monotonic timestamp when the attempt began.
        exception: Exception raised during the attempt, if any.
        attempt: Retry-attempt index (1-indexed).
        max_body_chars: Truncate captured bodies to at most this many
            characters; longer bodies are replaced by a prefix plus a
            ``...[N chars truncated]`` marker. ``None`` disables
            truncation. Default 100_000 (~100 KB) — large enough to
            capture a normal EIDR record but bounded against a worst
            case of e.g. bulk operation responses.
        redact_bodies: When ``True``, request/response bodies are
            replaced entirely with a ``[REDACTED N chars]`` marker.
            Headers and status still capture normally. Use for
            "safe support bundle" mode where callers want to ship a
            trace without unreleased record content in it.
    """
    duration = time.monotonic() - start_time
    req_headers_redacted = redact_headers(request_headers)
    resp_headers_redacted = redact_headers(response_headers) if response_headers else []

    req_body_str = _body_to_text(request_body)
    resp_body_str = _body_to_text(response_body)

    if redact_bodies:
        req_body_str = _redact_body_marker(req_body_str)
        resp_body_str = _redact_body_marker(resp_body_str)
    elif max_body_chars is not None:
        req_body_str = _truncate_body(req_body_str, max_body_chars)
        resp_body_str = _truncate_body(resp_body_str, max_body_chars)

    exc_str: str | None = None
    if exception is not None:
        exc_str = f"{type(exception).__name__}: {exception}"

    return TraceRecord(
        method=method,
        url=redact_url_query(url),
        request_headers=req_headers_redacted,
        request_body=req_body_str,
        response_status=response_status,
        response_headers=resp_headers_redacted,
        response_body=resp_body_str,
        duration_seconds=duration,
        exception=exc_str,
        attempt=attempt,
    )


def _truncate_body(body: str | None, max_chars: int) -> str | None:
    """Truncate ``body`` to ``max_chars`` with a marker suffix."""
    if body is None or len(body) <= max_chars:
        return body
    truncated = len(body) - max_chars
    return f"{body[:max_chars]}\n...[{truncated} chars truncated]"


def _redact_body_marker(body: str | None) -> str | None:
    """Replace ``body`` entirely with a placeholder marker."""
    if body is None:
        return None
    return f"[REDACTED {len(body)} chars]"


def _body_to_text(body: str | bytes | None) -> str | None:
    """Coerce a body value to text, decoding bytes as UTF-8 (or hex-escape)."""
    if body is None:
        return None
    if isinstance(body, str):
        return body
    try:
        return body.decode("utf-8")
    except UnicodeDecodeError:
        # Non-UTF-8 bytes: fall back to repr-style escape so the trace
        # is still readable even for binary content.
        return repr(body)
