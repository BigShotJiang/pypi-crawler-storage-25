"""Async counterpart to :class:`eidr.client.Token`.

An :class:`AsyncToken` is a handle to an in-flight async EIDR write
operation that the registry is processing. It carries the registry's
opaque token string and — when bound to an :class:`AsyncClient` — can
be polled via ``await`` until the operation resolves.

Why a separate class rather than a method-polymorphic ``Token``?

* Methods with different coroutine-ness (``def poll`` vs
  ``async def poll``) can't coexist on one class; Python's type
  system can't model "this method is sync or async depending on the
  instance." A single class with both method sets would require
  prefix-naming (``apoll``, ``await apoll()``) which obscures the
  async-ness of the call site.
* :class:`AsyncToken` is bound to an :class:`AsyncClient`; :class:`Token`
  is bound to a :class:`Client`. Mixing them (``Token.poll()`` with
  an :class:`AsyncClient`) would either require runtime type-mismatch
  handling or would silently succeed with confusing semantics.
* The sync-under-load fallback (REST API §2.1.1 — a sync Create or
  Modify deflected to async because dedupe is slow) produces a sync
  :class:`Token`. For callers running in an async context who want
  to ``await`` that token, :meth:`Token.to_async` bridges the gap
  explicitly. The reverse direction (:class:`AsyncToken` → sync
  :class:`Token`) is deliberately *not* offered because it would
  imply running ``asyncio.run()`` from sync code, which is almost
  always a mistake elsewhere.

The :class:`TokenStatus` enum is shared with :class:`Token` — the
semantics of "pending / success / failure" don't depend on the
polling model.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from eidr.client._token import TokenStatus, _status_from_response
from eidr.errors import EIDRProtocolError, EIDRTimeoutError

if TYPE_CHECKING:
    from eidr.client._async_client import AsyncClient
    from eidr.client._operation_result import OperationResult
    from eidr.client._response import ParsedResponse


__all__ = ["AsyncToken"]


@dataclass
class AsyncToken:
    """Async handle to an in-flight EIDR write operation.

    Created by :meth:`AsyncClient.register` / :meth:`AsyncClient.modify`
    (and friends) when the request is submitted with ``immediate=False``,
    or constructed directly by callers resuming a previously-issued
    token, or returned from :meth:`Token.to_async` to bridge the
    sync-under-load fallback into an async workflow.

    Attributes:
        value: The registry-issued token string.
        status: Last known :class:`TokenStatus`. Starts as
            :attr:`TokenStatus.PENDING` until :meth:`poll` or
            :meth:`wait` updates it.
        last_response: The most recent :class:`ParsedResponse` from a
            status-lookup call, or ``None`` if the token has never
            been polled.

    Example::

        token = await client.register(record, immediate=False)
        # ...later in the same task:
        result = await token.operation_result(timeout=300)
        if result.status is TokenStatus.SUCCESS:
            print("Registered:", result.id)

    Resuming across processes::

        # Persist:
        token = await client.register(record, immediate=False)
        db.save("pending", token.value)

        # Later, possibly in a different process:
        async with AsyncClient(...) as new_client:
            tok = AsyncToken(value=db.load("pending"))
            tok.attach(new_client)
            result = await tok.operation_result(timeout=300)
    """

    value: str
    """The registry-issued token string."""

    _client: AsyncClient | None = field(default=None, repr=False)
    """Reference to the issuing AsyncClient. Required for polling;
    may be ``None`` if the Token was constructed standalone."""

    status: TokenStatus = TokenStatus.PENDING
    """Last known status. Updated by :meth:`poll` and :meth:`wait`."""

    last_response: ParsedResponse | None = field(default=None, repr=False)
    """Most recent response envelope from a status-lookup call."""

    def __post_init__(self) -> None:
        if not self.value or not isinstance(self.value, str):
            raise ValueError(f"AsyncToken value must be a non-empty string, got {self.value!r}")

    # ─── polling ────────────────────────────────────────────────────────

    async def poll(self) -> TokenStatus:
        """Do one status-lookup call, update cached state, return status.

        Fast and non-blocking (one round-trip). Use :meth:`wait` to
        poll repeatedly with backoff.

        Raises:
            EIDRProtocolError: If this token has no associated
                :class:`AsyncClient` (e.g., constructed standalone
                without calling :meth:`attach`).
        """
        if self._client is None:
            raise EIDRProtocolError(
                f"AsyncToken {self.value!r} has no associated AsyncClient; "
                f"call AsyncToken.attach(client) before polling, or construct "
                f"the token via AsyncClient.register()/modify() rather than "
                f"directly."
            )
        response = await self._client.status_lookup(self.value)
        self.last_response = response
        self.status = _status_from_response(response)
        return self.status

    async def wait(
        self,
        *,
        timeout: float,
        initial_delay: float = 0.5,
        max_delay: float = 30.0,
        backoff_factor: float = 1.5,
    ) -> TokenStatus:
        """Poll repeatedly until the token resolves or ``timeout`` elapses.

        Async mirror of :meth:`Token.wait`. Same backoff policy (0.5s
        initial, 1.5× multiplier, 30s cap by default), but uses
        :func:`asyncio.sleep` so the task yields to the event loop
        during the backoff window — other coroutines keep running
        while we wait.

        Cancellation (:class:`asyncio.CancelledError`) propagates
        cleanly: the token's :attr:`status` and :attr:`last_response`
        reflect the last completed poll, and the caller can retry
        later without losing that state.

        Args:
            timeout: Maximum seconds to wait before giving up. A
                value of ``0`` performs exactly one poll.
            initial_delay: Seconds before the first retry after an
                initial PENDING result.
            max_delay: Cap on per-iteration sleep.
            backoff_factor: Multiplier applied to the delay between
                iterations.

        Returns:
            The final :attr:`TokenStatus` (SUCCESS or FAILURE).

        Raises:
            EIDRTimeoutError: If the token is still pending when the
                timeout elapses. The token's :attr:`status` remains
                ``PENDING`` and can be polled again later.
            asyncio.CancelledError: If the surrounding task is
                cancelled during a sleep. Not converted — the caller's
                cancellation intent should not be swallowed.

        Example::

            try:
                status = await token.wait(timeout=60)
            except EIDRTimeoutError:
                # Save the token string somewhere and poll later.
                persist(token.value)
        """
        if timeout < 0:
            raise ValueError(f"timeout must be >= 0, got {timeout}")

        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout

        # First poll is unconditional (handles the common "already
        # done" case without any sleep).
        status = await self.poll()
        if status is not TokenStatus.PENDING:
            return status

        if timeout == 0:
            raise EIDRTimeoutError(
                f"AsyncToken {self.value!r} is still pending and "
                f"timeout=0; caller asked for a single poll only."
            )

        delay = initial_delay
        while loop.time() < deadline:
            remaining = deadline - loop.time()
            await asyncio.sleep(min(delay, remaining))
            if loop.time() >= deadline:
                break
            status = await self.poll()
            if status is not TokenStatus.PENDING:
                return status
            delay = min(delay * backoff_factor, max_delay)

        raise EIDRTimeoutError(
            f"AsyncToken {self.value!r} still pending after {timeout}s; "
            f"save token.value and poll again later."
        )

    async def operation_result(self, *, timeout: float | None = None) -> OperationResult:
        """Block until resolved, return a structured :class:`OperationResult`.

        Async counterpart to :meth:`Token.operation_result`. Returns
        the same :class:`OperationResult` shape — status, ids,
        record, sub-tokens, raw response — so caller code that
        consumes the result doesn't need to distinguish sync from
        async.

        On a still-pending token whose timeout expires, the result's
        status is ``PENDING`` and the caller can inspect
        :attr:`OperationResult.sub_tokens` for any per-operation
        tokens that have completed independently. Only when the
        token has never been polled at all (because the deadline was
        too short for even one round-trip, or the token has no
        client attached) does this method re-raise the underlying
        exception.

        Args:
            timeout: Polling deadline in seconds. ``None`` waits
                indefinitely (use cautiously; prefer a concrete cap
                in production).

        Returns:
            An :class:`OperationResult` carrying status, IDs,
            sub-tokens, and the raw response.
        """
        from eidr.client._operation_result import operation_result_from

        # ``None`` → effectively infinite, mirroring :meth:`result`.
        effective_timeout = 10_000_000.0 if timeout is None else timeout
        try:
            status = await self.wait(timeout=effective_timeout)
        except EIDRTimeoutError:
            if self.last_response is None:
                raise
            return operation_result_from(self.last_response, status=TokenStatus.PENDING)
        assert self.last_response is not None
        return operation_result_from(self.last_response, status=status)

    async def result(self, *, timeout: float | None = None) -> ParsedResponse:
        """Block until resolved, return the response; raise on failure.

        Exact async counterpart of :meth:`Token.result`. Convenience
        wrapper for :meth:`wait` when the caller wants "either
        succeed or throw." Prefer :meth:`operation_result` for most
        use cases — the structured :class:`OperationResult` is
        friendlier than the raw envelope.

        Args:
            timeout: Polling deadline in seconds. ``None`` waits
                indefinitely.

        Returns:
            The :class:`ParsedResponse` from the final (successful)
            status-lookup call.

        Raises:
            EIDRProtocolError: If the token resolved to FAILURE.
            EIDRTimeoutError: If ``timeout`` elapsed without resolution.
        """
        effective_timeout = 10_000_000.0 if timeout is None else timeout
        status = await self.wait(timeout=effective_timeout)

        if status is TokenStatus.SUCCESS:
            assert self.last_response is not None
            return self.last_response

        # FAILURE — extract reason from the last response if we can,
        # matching :meth:`Token.result` exactly.
        assert self.last_response is not None
        reason = self.last_response.status_type or f"code={self.last_response.status_code}"
        raise EIDRProtocolError(f"AsyncToken {self.value!r} resolved to FAILURE: {reason}")

    def result_id(self) -> str | None:
        """Extract the first assigned EIDR ID from :attr:`last_response`.

        Synchronous because it only inspects already-fetched data.
        Returns ``None`` if the token hasn't been polled, hasn't
        resolved, or the response doesn't contain an ID (e.g., for
        delete/promote/alias which don't produce IDs).
        """
        if self.last_response is None:
            return None
        ns = {"eidr": "http://www.eidr.org/schema"}
        for op in self.last_response.operation_status_elements():
            id_elem = op.find("eidr:ID", ns)
            if id_elem is not None and id_elem.text:
                return str(id_elem.text).strip()
        top_id = self.last_response.root.find("eidr:ID", ns)
        if top_id is not None and top_id.text:
            return str(top_id.text).strip()
        return None

    def attach(self, client: AsyncClient) -> None:
        """Attach an :class:`AsyncClient` to a detached token.

        Symmetric with :meth:`Token.attach`. Useful when resuming
        polling on a token that was serialized (only its ``value``
        preserved) and later reconstructed::

            # In one task:
            token = await client.register(record, immediate=False, wait_timeout=0)
            saved = token.value

            # Later, possibly in a new process:
            token = AsyncToken(value=saved)
            token.attach(new_client)
            await token.wait(timeout=60)
        """
        self._client = client
