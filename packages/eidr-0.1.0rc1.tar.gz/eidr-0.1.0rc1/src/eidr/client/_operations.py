"""Inner operation-XML builders for EIDR write operations.

Each EIDR write operation has its own inner-XML shape that gets
wrapped in the outer ``<Request>/<Operation>`` envelope (see
:mod:`eidr.client._envelope`). This module produces those inner
fragments.

Operation shapes
----------------

* **Create** (Register / Match):

  .. code-block:: xml

     <Create type="CreateBasic">
       <Basic>
         <BaseObjectData>...</BaseObjectData>
       </Basic>
     </Create>

  The ``type`` attribute is ``Create`` + the CreationType value
  (``CreateBasic``, ``CreateSeries``, etc.); the inner element name
  matches the CreationType (``<Basic>``, ``<Series>``, ``<Season>``,
  etc.). Per the EIDR schemas (``api.xsd``, ``createType``;
  ``eidr-base.xsd``, ``createBasicDataType`` / ``createSeriesDataType``
  / etc.), the inner element wraps ``<BaseObjectData>`` and, for
  non-Basic records, ``<ExtraObjectMetadata>`` — the same structure
  that appears inside ``<FullMetadata>`` in a resolve response. So
  converting a resolve-shaped record to create-shaped XML is just a
  rename of the outer element (``FullMetadata`` → ``Basic`` /
  ``Series`` / etc.).

* **Modify:**

  .. code-block:: xml

     <Modify type="CreateBasic">
       <ID>10.5240/...</ID>
       <Basic>
         <BaseObjectData>...</BaseObjectData>
       </Basic>
     </Modify>

  Same pattern as Create, with a leading ``<ID>`` identifying the
  record to modify.

* **Delete / Promote:**

  .. code-block:: xml

     <Delete><ID>10.5240/...</ID></Delete>
     <Promote><ID>10.5240/...</ID></Promote>

* **Alias:**

  .. code-block:: xml

     <Alias>
       <ID>10.5240/...source...</ID>
       <TargetID>10.5240/...target...</TargetID>
     </Alias>

* **AddRelationship / RemoveRelationship / ReplaceRelationship:**

  .. code-block:: xml

     <AddRelationship type="PromotionalRelationship">
       <ID>10.5240/...source...</ID>
       <PromotionInfo>...</PromotionInfo>
     </AddRelationship>

  ``type`` is the relationship type (one of six lightweight
  relationships). The inner info element's name depends on the
  relationship type.

The builders in this module work at the XML-string level rather than
via a structured AST. The payloads are small, the output is
straightforward to read, and the approach avoids a second XML tree
traversal for operations where the record object is already the
source of truth.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from eidr.errors import EIDRClientError
from eidr.models.enums import CreationType

__all__ = [
    "GraphTraversalType",
    "RelationshipType",
    "build_add_relationship",
    "build_alias",
    "build_create",
    "build_delete",
    "build_graph_traversal",
    "build_modify",
    "build_promote",
    "build_query",
    "build_remove_relationship",
    "build_replace_relationship",
]


class GraphTraversalType(StrEnum):
    """Sub-operations supported by the graph-traversal endpoint.

    Per ``api.xsd``, a graph-traversal ``<Operation>`` contains one of
    the nine elements below. Values are the XML element names the
    registry expects on the wire. Each has its own required/optional
    children (filters, pagination, etc.); the Python wrapper exposes
    a simple per-operation shape via ``Client.graph_traversal()``.

    * :attr:`FIND_ANCESTORS` / :attr:`FIND_DESCENDANTS`: Recursive
      ancestor/descendant lookup, filterable by referent type,
      structural type, and/or relationship type.
    * :attr:`GET_PARENT` / :attr:`GET_CHILDREN`: Single-hop lookup.
    * :attr:`GET_DEPENDENTS`: Records whose existence depends on
      the target (e.g., episodes of a season).
    * :attr:`GET_SERIES_ANCESTRY`: Walk the Series → Season →
      Episode chain for a given record.
    * :attr:`GET_REMOTEST_ANCESTOR`: The root of an object's
      inheritance chain.
    * :attr:`GET_LEAF_DESCENDANTS`: The leaves of a subtree.
    * :attr:`GET_LIGHTWEIGHT_RELATIONSHIPS`: Non-structural
      relationships attached to the target.
    """

    FIND_ANCESTORS = "FindAncestors"
    FIND_DESCENDANTS = "FindDescendants"
    GET_DEPENDENTS = "GetDependents"
    GET_SERIES_ANCESTRY = "GetSeriesAncestry"
    GET_LIGHTWEIGHT_RELATIONSHIPS = "GetLightweightRelationships"
    GET_REMOTEST_ANCESTOR = "GetRemotestAncestor"
    GET_LEAF_DESCENDANTS = "GetLeafDescendants"
    GET_PARENT = "GetParent"
    GET_CHILDREN = "GetChildren"


class RelationshipType(StrEnum):
    """Lightweight-relationship types supported by Add/Remove/Replace-Relationship.

    Structural relationships (``IsSeasonOf``, ``IsEpisodeOf``, etc.)
    are NOT managed through these operations — they're determined by
    the record's CreationType and modified via Create/Modify. Only
    the six lightweight types below can be added, removed, or
    replaced independently.

    Values are the strings the registry expects as the ``type``
    attribute on ``<AddRelationship>`` / ``<RemoveRelationship>`` /
    ``<ReplaceRelationship>``.
    """

    COMPOSITE = "CompositeRelationship"
    LANGUAGE = "LanguageRelationship"
    PACKAGING = "PackagingRelationship"
    ADJUNCT = "AdjunctRelationship"
    PROMOTIONAL = "PromotionalRelationship"
    ALTERNATE_CONTENT = "AlternateContentRelationship"


#: Map from :class:`RelationshipType` to the expected inner info-element
#: name (the XML tag that holds the relationship's data).
_INFO_TAG_FOR_TYPE: dict[RelationshipType, str] = {
    RelationshipType.COMPOSITE: "CompositeInfo",
    RelationshipType.LANGUAGE: "LanguageConstructionInfo",
    RelationshipType.PACKAGING: "PackagingInfo",
    RelationshipType.ADJUNCT: "AdjunctContentInfo",
    RelationshipType.PROMOTIONAL: "PromotionInfo",
    RelationshipType.ALTERNATE_CONTENT: "AlternateContentInfo",
}


# ─── record-to-fragment helpers ─────────────────────────────────────────────


def _record_to_creation_inner(
    record_xml: bytes | str,
    creation_type: CreationType,
) -> str:
    """Rename a record's outer element to the Create inner element name.

    Per ``api.xsd``/``eidr-base.xsd``, the content of ``<Basic>``,
    ``<Series>``, etc. in a Create payload is the same structure as
    the content of ``<FullMetadata>`` in a resolve response: it
    wraps ``<BaseObjectData>`` and, for non-Basic records,
    ``<ExtraObjectMetadata>``. So the conversion is a simple outer-
    element rename.

    Accepts record XML with a ``<FullMetadata>``,
    ``<SelfDefinedMetadata>``, or ``<ProvenanceMetadata>`` root.
    Match operations may produce self-defined bodies; provenance is
    accepted for completeness though unusual as a Create/Modify
    source.

    Strips ``<ID>`` from any inner ``<BaseObjectData>``: the
    Create payload's schema (``creationFullInfo`` /
    ``creationSelfDefinedInfo``) does not include ``<ID>`` because
    the registry assigns the ID on Create. The schema annotation
    is explicit: *"the groups rather than the resolution types
    because no ID is present in a creation"*. Resubmitting a
    resolved record without stripping the ID was rejected by the
    sandbox in the M9 review pass with::

        cvc-complex-type.2.4.a: Invalid content was found starting
        with element 'ID'. One of '{...}:StructuralType' is expected.
    """
    from lxml import etree

    if creation_type == CreationType.Alias:
        raise EIDRClientError(
            "Cannot build a Create operation for a CreationType.Alias "
            "record — aliases use the Alias operation, not Create."
        )

    if isinstance(record_xml, str):
        record_xml = record_xml.encode("utf-8")
    try:
        root = etree.fromstring(record_xml)
    except etree.XMLSyntaxError as exc:
        raise EIDRClientError(f"Record XML is not well-formed: {exc}") from exc

    root_local = etree.QName(root).localname

    # Three accepted root shapes:
    #
    # - <FullMetadata> / <SelfDefinedMetadata> / <ProvenanceMetadata>:
    #   resolve-style envelopes. Strip the outer wrapper and use
    #   the inner content (BaseObjectData [+ ExtraObjectMetadata]).
    #
    # - <BaseObjectData>: the modification-base shape returned by
    #   /object/modificationbase/ after _extract_first_non_status_child
    #   unwraps the registry's <Basic>/<Series>/etc. wrapper. For
    #   Basic creation type this is the entire record content; we
    #   just wrap it in the creation-type element. For non-Basic,
    #   the synthesized <FullMetadata> path through M11-C handles
    #   <ExtraObjectMetadata> as a sibling — that path takes the
    #   <FullMetadata> branch above, not this branch.
    #
    # Pre-built <Basic>/<Series>/etc. inner-creation forms are NOT
    # accepted as input — passing one would trip the "unexpected
    # root" check below. If a caller somehow has a creation-inner
    # body in hand, they should send it directly via the wire-level
    # build_register / build_modify entry points, bypassing this
    # helper. (No real-world user paths do this; the M11-C non-Basic
    # round-trip uses the synthesized FullMetadata.)
    if root_local == "BaseObjectData":
        # Wrap in the creation-type element.
        inner_tag = creation_type.value
        ns = etree.QName(root).namespace
        tag = f"{{{ns}}}{inner_tag}" if ns else inner_tag
        new_root = etree.Element(tag, nsmap=root.nsmap)
        # Move the BaseObjectData wholesale into the inner element.
        new_root.append(root)
        # Strip <ID> from <BaseObjectData> per the schema rule
        # (creationFullInfo / creationSelfDefinedInfo do not include <ID>).
        id_tag = f"{{{ns}}}ID" if ns else "ID"
        id_el = root.find(id_tag)
        if id_el is not None:
            root.remove(id_el)
        result = etree.tostring(new_root, encoding="unicode")
        assert isinstance(result, str)
        return result

    if root_local not in (
        "FullMetadata",
        "SelfDefinedMetadata",
        "ProvenanceMetadata",
    ):
        raise EIDRClientError(
            f"Expected record XML to have root <FullMetadata>, "
            f"<SelfDefinedMetadata>, <ProvenanceMetadata>, or "
            f"<BaseObjectData>; got <{root_local}>. Pass the output "
            f"of ContentRecord.to_xml() (from resolve) or "
            f"Client.modification_base()."
        )

    # The wire-format inner element's name is the CreationType value
    # (Basic / Series / Season / Episode / Edit / Clip / Manifestation /
    # Compilation). We keep the same namespace as the source root.
    inner_tag = creation_type.value

    ns = etree.QName(root).namespace
    tag = f"{{{ns}}}{inner_tag}" if ns else inner_tag
    new_root = etree.Element(tag, attrib=dict(root.attrib), nsmap=root.nsmap)
    # Move children. lxml's assignment semantics reparent them.
    for child in list(root):
        new_root.append(child)

    # Strip <ID> from <BaseObjectData> — see the docstring above for
    # the schema rationale.
    base_obj_tag = f"{{{ns}}}BaseObjectData" if ns else "BaseObjectData"
    id_tag = f"{{{ns}}}ID" if ns else "ID"
    base_obj = new_root.find(base_obj_tag)
    if base_obj is not None:
        id_el = base_obj.find(id_tag)
        if id_el is not None:
            base_obj.remove(id_el)

    result = etree.tostring(new_root, encoding="unicode")
    # lxml's types for tostring are bytes|str based on encoding; unicode
    # yields str but the type stub returns Any.
    assert isinstance(result, str)
    return result


def _creation_type_attr(creation_type: CreationType) -> str:
    """Return the ``type`` attribute value for a Create/Modify envelope."""
    return f"Create{creation_type.value}"


# ─── operation builders ─────────────────────────────────────────────────────


def build_create(
    record_xml: bytes | str,
    creation_type: CreationType,
) -> str:
    """Build the inner XML for a Create (Register / Match) operation.

    Args:
        record_xml: Full record XML (as returned by
            :meth:`ContentRecord.to_xml`). The outer ``<FullMetadata>``
            (or ``<SelfDefinedMetadata>``) element is renamed to the
            CreationType-specific wire-format name (``<Basic>``,
            ``<Series>``, etc.); all children are preserved.
        creation_type: The record's CreationType, determining both
            the ``type`` attribute value and the inner element name.

    Returns:
        The ``<Create type="...">...</Create>`` fragment as a string.

    Raises:
        EIDRClientError: If ``creation_type`` is
            :attr:`CreationType.Alias` or if ``record_xml`` doesn't
            parse or lacks the expected outer root element.
    """
    inner_xml = _record_to_creation_inner(record_xml, creation_type)
    return f'<Create type="{_creation_type_attr(creation_type)}">{inner_xml}</Create>'


def build_modify(
    record_xml: bytes | str,
    eidr_id: str,
    creation_type: CreationType,
) -> str:
    """Build the inner XML for a Modify operation.

    Args:
        record_xml: Full record XML of the modified record.
        eidr_id: The EIDR ID of the record being modified. Required;
            Modify operations can't rely on the ID being embedded in
            the record body alone.
        creation_type: The record's CreationType.

    Returns:
        The ``<Modify type="...">...</Modify>`` fragment.
    """
    inner_xml = _record_to_creation_inner(record_xml, creation_type)
    eidr_id_escaped = _escape_text(eidr_id)
    type_attr = _creation_type_attr(creation_type)
    return f'<Modify type="{type_attr}"><ID>{eidr_id_escaped}</ID>{inner_xml}</Modify>'


def build_delete(eidr_id: str) -> str:
    """Build the inner XML for a Delete operation."""
    return f"<Delete><ID>{_escape_text(eidr_id)}</ID></Delete>"


def build_promote(eidr_id: str) -> str:
    """Build the inner XML for a Promote operation.

    Promotes a record from ``InDev`` status to ``valid``, triggering
    deduplication review. The operation takes only the ID — the rest
    of the semantics live registry-side.
    """
    return f"<Promote><ID>{_escape_text(eidr_id)}</ID></Promote>"


def build_alias(source_id: str, target_id: str) -> str:
    """Build the inner XML for an Alias operation.

    Args:
        source_id: The EIDR ID of the record being aliased (will
            become the alias).
        target_id: The EIDR ID of the record that ``source_id`` will
            alias to (will become the target/destination).

    Returns:
        The ``<Alias>...</Alias>`` fragment.
    """
    return (
        f"<Alias>"
        f"<ID>{_escape_text(source_id)}</ID>"
        f"<TargetID>{_escape_text(target_id)}</TargetID>"
        f"</Alias>"
    )


def build_add_relationship(
    source_id: str,
    relationship_type: RelationshipType,
    info_xml: str,
) -> str:
    """Build the inner XML for an AddRelationship operation.

    Args:
        source_id: The EIDR ID of the record to which the relationship
            is being added.
        relationship_type: One of the six lightweight relationship
            types (see :class:`RelationshipType`).
        info_xml: Pre-formed XML for the relationship info element.
            Must match the expected info-element name for the
            relationship type (e.g., ``<PromotionInfo>...</PromotionInfo>``
            for :attr:`RelationshipType.PROMOTIONAL`). The caller is
            responsible for building this fragment correctly.

    Returns:
        The ``<AddRelationship type="...">...</AddRelationship>`` fragment.

    Raises:
        EIDRClientError: If ``info_xml`` is malformed, has the wrong
            root element for the given relationship type, or is in
            an unexpected namespace. The caller's fragment is parsed
            and re-serialized before being embedded in the envelope
            — trailing content, XML declarations, or stray
            processing instructions in the caller's string are
            dropped, not passed through.
    """
    reserialized = _validate_and_reserialize_info(relationship_type, info_xml)
    return (
        f'<AddRelationship type="{relationship_type.value}">'
        f"<ID>{_escape_text(source_id)}</ID>"
        f"{reserialized}"
        f"</AddRelationship>"
    )


def build_remove_relationship(
    source_id: str,
    relationship_type: RelationshipType,
) -> str:
    """Build the inner XML for a RemoveRelationship operation.

    Removes all relationships of the given type from the source
    record. RemoveRelationship doesn't target a specific relationship
    — it removes every lightweight relationship of the given type
    attached to the record. If selective removal is needed, use
    :func:`build_replace_relationship` instead.

    Args:
        source_id: The EIDR ID of the record from which to remove
            relationships.
        relationship_type: The relationship type to remove.

    Returns:
        The ``<RemoveRelationship type="...">...</RemoveRelationship>``
        fragment.
    """
    return (
        f'<RemoveRelationship type="{relationship_type.value}">'
        f"<ID>{_escape_text(source_id)}</ID>"
        f"</RemoveRelationship>"
    )


def build_replace_relationship(
    source_id: str,
    relationship_type: RelationshipType,
    info_xml: str,
) -> str:
    """Build the inner XML for a ReplaceRelationship operation.

    Atomically removes all existing relationships of the given type
    and adds the one provided. For relationships that can exist
    multiply (e.g., multiple Packaging relationships), this replaces
    the entire set.

    Args:
        source_id: The EIDR ID of the source record.
        relationship_type: The relationship type to replace.
        info_xml: Pre-formed XML for the replacement info element.

    Returns:
        The ``<ReplaceRelationship type="...">...</ReplaceRelationship>``
        fragment.

    Raises:
        EIDRClientError: See :func:`build_add_relationship` for the
            validation contract — the caller's fragment is parsed
            and re-serialized; trailing content is dropped.
    """
    reserialized = _validate_and_reserialize_info(relationship_type, info_xml)
    return (
        f'<ReplaceRelationship type="{relationship_type.value}">'
        f"<ID>{_escape_text(source_id)}</ID>"
        f"{reserialized}"
        f"</ReplaceRelationship>"
    )


# ─── helpers ────────────────────────────────────────────────────────────────


def _validate_and_reserialize_info(relationship_type: RelationshipType, info_xml: str) -> str:
    """Parse, validate, and re-serialize the relationship info fragment.

    Returns the re-serialized fragment rather than returning ``None``
    and trusting the caller to embed the original. That matters:
    callers can pass XML that is well-formed *as a fragment* but has
    trailing content, declarations, comments, or processing
    instructions after the root element. A naive "parse to validate,
    then concatenate the original string" pattern lets that trailing
    content slip into the request envelope unchecked. Re-serializing
    the parsed root element produces exactly one XML element with no
    surprises.

    Checks:

    1. The fragment is well-formed XML.
    2. The root element's local name matches the expected info name
       for the given relationship type (e.g., ``<PromotionInfo>`` for
       :attr:`RelationshipType.PROMOTIONAL`).
    3. The root is in the EIDR namespace or no namespace (both are
       accepted; the registry is lenient on namespace prefixes).

    Args:
        relationship_type: The expected relationship type.
        info_xml: Caller-supplied XML fragment.

    Returns:
        The re-serialized fragment — bytes decoded to UTF-8, no XML
        declaration, no trailing whitespace. Safe to embed verbatim
        in a request envelope.

    Raises:
        EIDRClientError: If the fragment is malformed, has a
            mismatched root element, or is in an unexpected namespace.
    """
    from lxml import etree

    expected = _INFO_TAG_FOR_TYPE[relationship_type]

    if not info_xml or not info_xml.strip():
        raise EIDRClientError(
            f"info_xml for {relationship_type.name} is empty; expected <{expected}> element."
        )

    try:
        root = etree.fromstring(info_xml.encode("utf-8") if isinstance(info_xml, str) else info_xml)
    except etree.XMLSyntaxError as exc:
        raise EIDRClientError(
            f"info_xml for {relationship_type.name} is not well-formed XML: "
            f"{exc}. Fragment start: {info_xml[:120]!r}"
        ) from exc

    qname = etree.QName(root)
    actual_local = qname.localname
    actual_ns = qname.namespace

    if actual_local != expected:
        raise EIDRClientError(
            f"info_xml for {relationship_type.name} has root "
            f"<{actual_local}>; expected <{expected}>. Ensure the "
            f"relationship_type matches the info element type."
        )

    # Namespace check: accept no-namespace or the EIDR namespace.
    # Other namespaces are almost certainly a mistake.
    if actual_ns is not None and actual_ns != "http://www.eidr.org/schema":
        raise EIDRClientError(
            f"info_xml for {relationship_type.name} is in namespace "
            f"{actual_ns!r}; expected the EIDR namespace "
            f"'http://www.eidr.org/schema' or no namespace."
        )

    # Re-serialize ONLY the validated root element (no XML
    # declaration; no trailing content from the caller's original
    # string). ``etree.tostring`` on an element-tree Element emits
    # just that element's serialization.
    reserialized: bytes = etree.tostring(root, encoding="UTF-8", xml_declaration=False)
    decoded: str = reserialized.decode("utf-8")
    return decoded


def _escape_text(s: str) -> str:
    """Escape text content for inclusion in XML (& and < only; > is optional)."""
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ─── query / graph-traversal builders ───────────────────────────────────────


def build_query(
    expression: str,
    *,
    page_number: int = 1,
    page_size: int = 25,
) -> str:
    """Build the inner XML for a content-registry query operation.

    Wire shape (from ``api.xsd`` ``queryType``):

    .. code-block:: xml

        <Query>
          <Expression>/FullMetadata/BaseObjectData/Status valid</Expression>
          <PageNumber>1</PageNumber>
          <PageSize>25</PageSize>
        </Query>

    Args:
        expression: EIDR query expression. The registry's query
            grammar is documented in the EIDR Registry Technical
            Overview (section "Query Expressions"); common forms use
            XPath-style field navigation plus operators like ``=``,
            ``HAS``, ``EXISTS``, and parenthesised boolean combinators.
            The caller supplies the expression text verbatim; this
            function only XML-escapes it so embedded ``&`` / ``<``
            characters survive the round-trip. Parentheses used for
            grouping are preserved.
        page_number: 1-indexed page number for paginated result sets.
        page_size: Records per page. Registry-side maximum is
            enforced (see EIDR docs for the current value); exceeding
            it produces a ``result too long`` status code.

    Returns:
        The ``<Query>...</Query>`` inner fragment.

    Raises:
        ValueError: For non-positive ``page_number`` or ``page_size``.
    """
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")
    expr_escaped = _escape_text(expression)
    return (
        "<Query>"
        f"<Expression>{expr_escaped}</Expression>"
        f"<PageNumber>{page_number}</PageNumber>"
        f"<PageSize>{page_size}</PageSize>"
        "</Query>"
    )


def build_graph_traversal(
    operation: GraphTraversalType,
    eidr_id: str,
    *,
    referent_type_filter: str | None = None,
    structural_type_filter: str | None = None,
    relationship_type_filter: str | None = None,
) -> str:
    """Build the inner XML for a graph-traversal operation.

    Wire shape (from ``api.xsd``):

    .. code-block:: xml

        <FindAncestors>
          <ID>10.5240/...</ID>
          <ReferentTypeFilter>Movie</ReferentTypeFilter>
          <StructuralTypeFilter>Performance</StructuralTypeFilter>
          <RelationshipTypeFilter>IsPackagingOf</RelationshipTypeFilter>
        </FindAncestors>

    The filter elements are omitted when ``None``. Element order
    matches the schema's ``<sequence>`` definition. Filters apply to
    the ancestor/descendant variants; the simpler operations
    (``GetParent``, ``GetChildren``, ``GetRemotestAncestor``, etc.)
    accept ``<ID>`` only and ignore any filters the registry
    receives, so passing a filter for an operation that doesn't use
    it is harmless but wasteful.

    Args:
        operation: Which graph-traversal variant to invoke.
        eidr_id: The EIDR ID anchoring the traversal.
        referent_type_filter: Optional filter on the records' referent
            type (``Movie``, ``TV``, ``Short``, ``Web``,
            ``Manifestation``, etc.).
        structural_type_filter: Optional filter on structural type
            (``Abstraction``, ``Performance``, ``Digital``,
            ``Interactive``).
        relationship_type_filter: Optional filter on the structural
            relationship connecting records (``IsSeasonOf``,
            ``IsEpisodeOf``, ``IsManifestationOf``, etc.).

    Returns:
        The ``<FindAncestors>...</FindAncestors>`` (or similar) inner
        fragment.
    """
    tag = operation.value
    parts = [f"<{tag}>", f"<ID>{_escape_text(eidr_id)}</ID>"]
    if referent_type_filter is not None:
        parts.append(
            f"<ReferentTypeFilter>{_escape_text(referent_type_filter)}</ReferentTypeFilter>"
        )
    if structural_type_filter is not None:
        parts.append(
            f"<StructuralTypeFilter>{_escape_text(structural_type_filter)}</StructuralTypeFilter>"
        )
    if relationship_type_filter is not None:
        parts.append(
            f"<RelationshipTypeFilter>{_escape_text(relationship_type_filter)}</RelationshipTypeFilter>"
        )
    parts.append(f"</{tag}>")
    return "".join(parts)


# ─── Party / Service / Virtual-fields envelopes ─────────────────────────────
#
# Wire-shape note: Party and Service write operations use a wholly
# different envelope from Content writes. Where a Content write
# wraps one or more ``<Operation><Create>...</Create></Operation>``
# entries inside a ``<Request xmlns="...">``, a Party or Service
# write posts the bare wrapper element (``<CreateParty>``, ``<Party>``,
# ``<CreateService>``, ``<Service>``) directly as the request body.
# No outer ``<Request>``, no ``<Operation>``, no batching — these
# endpoints accept a single payload at a time.
#
# Reference: Java SDK ``src/org/eidr/sdk/party/PartyAdmin.java``
# and ``src/org/eidr/sdk/service/ServiceAdmin.java``. The Java
# implementation is the canonical wire-format reference for
# operations not yet sandbox-verified by this SDK.


def build_create_party_body(party_xml: bytes | str) -> str:
    """Wrap a party body in the ``<CreateParty>`` element.

    The body must conform to ``partyCreationType`` (``common.xsd``).
    The :class:`PartyRecord.to_xml` output uses ``<Party>`` as its
    root; this helper renames that root to ``<CreateParty>`` and
    adds the EIDR namespace declaration if absent.

    Args:
        party_xml: Party body XML, either a ``<Party>`` element
            (typical from :meth:`PartyRecord.to_xml`) or already a
            ``<CreateParty>`` element (passed through unchanged).

    Returns:
        The serialized XML payload, ready to POST to
        ``/party/create/`` as the entire request body.
    """
    return _rename_root(party_xml, "CreateParty", _ALLOWED_PARTY_ROOTS)


def build_modify_party_body(party_xml: bytes | str) -> str:
    """Wrap a party body for modification.

    Modification posts use the ``<Party>`` root element directly
    (carrying ``partyResolutionType``, NOT ``partyCreationType`` —
    modifications never include a password). The
    :meth:`PartyRecord.to_xml` output already uses ``<Party>``, so
    this helper is mostly an identity wrapper that asserts the
    expected root and returns the bytes unchanged.

    The asymmetry between create (``<CreateParty>``) and modify
    (``<Party>``) wrappers matches the Java reference SDK — the
    EIDR registry expects exactly these element names at these
    paths. See ``PartyAdmin.modifyPartyFromObj`` in the Java SDK.
    """
    return _rename_root(party_xml, "Party", _ALLOWED_PARTY_ROOTS)


def build_create_service_body(service_xml: bytes | str) -> str:
    """Wrap a service body in the ``<CreateService>`` element.

    The body must conform to ``serviceCreationType``
    (``service.xsd``). Like ``build_create_party_body``, this
    renames the :meth:`ServiceRecord.to_xml` output's root to
    match the wire-format wrapper the registry expects at
    ``/service/create/``.
    """
    return _rename_root(service_xml, "CreateService", _ALLOWED_SERVICE_ROOTS)


def build_modify_service_body(service_xml: bytes | str) -> str:
    """Wrap a service body for modification.

    POSTs to ``/service/modify/`` use ``<Service>`` as the root,
    carrying ``serviceResolutionType``. Symmetry with the Party
    asymmetry described in :func:`build_modify_party_body`.
    """
    return _rename_root(service_xml, "Service", _ALLOWED_SERVICE_ROOTS)


_ALLOWED_PARTY_ROOTS = ("Party", "CreateParty")
_ALLOWED_SERVICE_ROOTS = ("Service", "CreateService")


def _rename_root(
    body_xml: bytes | str,
    target_root: str,
    allowed_existing_roots: tuple[str, ...],
) -> str:
    """Rename the root element of a record body to ``target_root``.

    Used by the four party/service body builders above. Validates
    that the input root is one of the expected names — catches
    the common "passed a ContentRecord by mistake" case at the
    builder boundary instead of at submission time.

    The original namespace and attribute set are preserved;
    children are reparented to the new root element. If the
    input root is already the target name, the body is returned
    unchanged (after a parse-and-reserialize round-trip for
    well-formedness validation).
    """
    from lxml import etree

    if isinstance(body_xml, str):
        body_xml = body_xml.encode("utf-8")
    try:
        root = etree.fromstring(body_xml)
    except etree.XMLSyntaxError as exc:
        raise EIDRClientError(f"Body XML is not well-formed: {exc}") from exc

    root_local = etree.QName(root).localname
    if root_local not in allowed_existing_roots:
        allowed_disp = " / ".join(f"<{n}>" for n in allowed_existing_roots)
        raise EIDRClientError(
            f"Expected body XML root to be one of {allowed_disp}; "
            f"got <{root_local}>. Did you pass the wrong record type?"
        )

    if root_local == target_root:
        # Already in the desired shape; round-trip via tostring for
        # consistent encoding output.
        result_bytes = etree.tostring(root, encoding="unicode")
        assert isinstance(result_bytes, str)
        return result_bytes

    ns = etree.QName(root).namespace
    tag = f"{{{ns}}}{target_root}" if ns else target_root
    new_root = etree.Element(tag, attrib=dict(root.attrib), nsmap=root.nsmap)
    for child in list(root):
        new_root.append(child)

    result = etree.tostring(new_root, encoding="unicode")
    assert isinstance(result, str)
    return result


# ── Status-lookup request builder ────────────────────────────────────────────


def build_status_request(
    *,
    token: str | None = None,
    user_id: str | None = None,
    registrant: str | None = None,
    superparty: bool = False,
    status: str | None = None,
    after: datetime | None = None,
    before: datetime | None = None,
    page_number: int = 1,
    page_size: int = 20,
) -> str:
    """Build the ``<Request>`` body for a status-lookup POST.

    Produces a ``<Request><Operation><StatusRequest>...</StatusRequest></Operation></Request>``
    body. Mirrors the Java SDK's ``StatusLookup.statusLookup`` private
    helper, used by ``statusLookupViaToken``, ``statusLookupViaUser``,
    ``statusLookupViaRegistrant``, and ``statusLookupSuperparty``.
    The returned XML is suitable for posting to ``/status/`` with
    multipart form-field name ``statusrequest``.

    Tag-element-name rules (from Java's ``posttag`` logic):

    - ``token`` → ``<Token>`` (capitalize first letter)
    - ``user_id`` → ``<UserID>`` (special case, NOT ``<User>``)
    - ``registrant`` → ``<Registrant>`` (capitalize first letter)
    - ``superparty=True`` → no inner element (just StatusRequest
      wrapping the page parameters and any filters)

    Date filtering rules:

    - ``after`` alone → ``<After>{after}</After>``
    - ``after`` + ``before`` → ``<From>{after}</From><To>{before}</To>``
    - Neither → no date elements

    Args:
        token: Operation token returned by a previous async write.
            If set, emits ``<Token>...</Token>``.
        user_id: User ID (e.g. ``10.5238/richardkroon``). If set,
            emits ``<UserID>...</UserID>``.
        registrant: Party ID (e.g. ``10.5237/FFDA-9947``). If set,
            emits ``<Registrant>...</Registrant>``.
        superparty: If true, omits the tag element entirely (the
            registry uses the auth credentials' Superparty status
            to authorize the wider lookup).
        status: Optional status filter — emitted as
            ``<Status>{status}</Status>`` if set.
        after: Optional start of date range. Used alone for an
            "after this date" filter; paired with ``before`` for a
            range.
        before: Optional end of date range. Must be paired with
            ``after`` (a ``before`` without ``after`` is ignored,
            matching Java).
        page_number: Page number (1-indexed). Required.
        page_size: Page size. Required.

    Raises:
        ValueError: If exactly one of ``token`` / ``user_id`` /
            ``registrant`` / ``superparty=True`` is not specified,
            or if ``page_number`` / ``page_size`` are non-positive.
    """
    selectors_set = sum(
        [
            token is not None,
            user_id is not None,
            registrant is not None,
            bool(superparty),
        ]
    )
    if selectors_set != 1:
        raise ValueError(
            "build_status_request requires exactly one of "
            "token / user_id / registrant / superparty=True; got "
            f"token={token!r}, user_id={user_id!r}, "
            f"registrant={registrant!r}, superparty={superparty}"
        )
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")

    parts: list[str] = []
    parts.append(
        '<Request xmlns="http://www.eidr.org/schema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
    )
    parts.append("<Operation><StatusRequest>")
    if token is not None:
        parts.append(f"<Token>{_xml_escape(token.strip())}</Token>")
    elif user_id is not None:
        parts.append(f"<UserID>{_xml_escape(user_id.strip())}</UserID>")
    elif registrant is not None:
        parts.append(f"<Registrant>{_xml_escape(registrant.strip())}</Registrant>")
    # superparty: no tag element

    if status is not None:
        parts.append(f"<Status>{_xml_escape(status)}</Status>")

    if after is not None:
        if before is None:
            parts.append(f"<After>{_format_dt(after)}</After>")
        else:
            parts.append(f"<From>{_format_dt(after)}</From>")
            parts.append(f"<To>{_format_dt(before)}</To>")

    parts.append(f"<PageNumber>{page_number}</PageNumber>")
    parts.append(f"<PageSize>{page_size}</PageSize>")
    parts.append("</StatusRequest></Operation></Request>")
    return "".join(parts)


def _xml_escape(text: str) -> str:
    """Minimal XML text escape — &, <, > only."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _format_dt(dt: datetime) -> str:
    """Format a datetime as XML Schema ``dateTime``.

    Matches Java's ``XMLGregorianCalendar.normalize().toString()``
    output: ISO 8601 with microseconds and a timezone offset.
    A naïve datetime (no tzinfo) is treated as UTC.
    """
    if dt.tzinfo is None:
        # Naïve → treat as UTC. Java's normalize() produces a
        # 'Z'-suffixed UTC time when the zone is unspecified.
        return dt.isoformat() + "Z"
    # tzinfo present → isoformat handles the offset (e.g. +00:00 or Z-equivalent)
    return dt.isoformat()


# ── Party / Service query builders ───────────────────────────────────────────


def build_find_parties_by_name(
    *,
    party_name: str,
    include_alt_names: bool = True,
    role_filter: str | None = None,
    active_filter: str = "active",
    page_number: int = 1,
    page_size: int = 20,
    continuation_token: str | None = None,
) -> str:
    """Build a ``<FindPartiesByName>`` XML body.

    Mirrors Java's ``PartyQuery.findPartiesByName`` wire shape. The
    body is suitable for posting to ``/party/query/`` via
    :meth:`Client.party_query`.

    Args:
        party_name: The name (or substring) to match. Required.
        include_alt_names: If true, match alternate names as well as
            display names. Default true (the Java SDK's typical
            usage). Wire format: ``includeAlternateNames="true"`` as
            an XSD attribute on the root ``<FindPartiesByName>``
            element (per ``api.xsd``; the 0.1.0b3 wire-shape fix
            corrected this from the earlier child-element form
            that the registry rejected).
        role_filter: Optional role filter (e.g. ``"registrant"``,
            ``"editor"``). If set, emits ``<RoleFilter>`` element.
        active_filter: ``"active"``, ``"inactive"``, or ``"all"``.
            Default ``"active"`` to match Java SDK behavior (Java
            ``PartyQuery``/``ServiceQuery`` default to ``active`` when
            unset). Pass ``"all"`` to include both active and inactive
            records.
        page_number: 1-indexed page number. Default 1.
        page_size: Page size. Default 20.
        continuation_token: Optional continuation token for stateful
            paging across very large result sets. Mutually exclusive
            with ``page_number`` semantically (the registry uses one
            or the other depending on result-set size).

    Returns:
        Well-formed ``<FindPartiesByName>`` XML string with the EIDR
        namespace declared.
    """
    if not party_name or not party_name.strip():
        raise ValueError("party_name must not be empty")
    if active_filter not in ("active", "inactive", "all"):
        raise ValueError(
            f"active_filter must be 'active', 'inactive', or 'all'; got {active_filter!r}"
        )
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")

    # Per api.xsd: ``includeAlternateNames`` is an XML *attribute* on
    # <FindPartiesByName> (lowercase camelCase), not a child element.
    # 0.1.0b1/b2 emitted it as a child element which the registry
    # rejected with a Code 9 syntax error.
    parts: list[str] = []
    parts.append(
        '<FindPartiesByName xmlns="http://www.eidr.org/schema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        f'includeAlternateNames="{"true" if include_alt_names else "false"}">'
    )
    parts.append(f"<PartyName>{_xml_escape(party_name)}</PartyName>")
    if role_filter is not None:
        parts.append(f"<RoleFilter>{_xml_escape(role_filter)}</RoleFilter>")
    parts.append(f"<ActiveFilter>{active_filter}</ActiveFilter>")
    parts.append(f"<PageNumber>{page_number}</PageNumber>")
    parts.append(f"<PageSize>{page_size}</PageSize>")
    if continuation_token is not None:
        parts.append(f"<ContinuationToken>{_xml_escape(continuation_token)}</ContinuationToken>")
    parts.append("</FindPartiesByName>")
    return "".join(parts)


def build_find_parties_from_catalog(
    *,
    party_name: str,
    role_filter: str | None = None,
    active_filter: str = "active",
    page_number: int = 1,
    page_size: int = 20,
    continuation_token: str | None = None,
) -> str:
    """Build a ``<FindPartiesFromCatalog>`` XML body.

    Mirrors Java's ``PartyQuery.findPartiesFromCatalog``. The catalog
    variant searches against EIDR's curated party catalog rather than
    the open party namespace; useful for finding well-known
    organizations (studios, distributors) by canonical name.

    Same fields as :func:`build_find_parties_by_name` except no
    ``include_alt_names`` (the catalog already normalizes alternate
    names).
    """
    if not party_name or not party_name.strip():
        raise ValueError("party_name must not be empty")
    if active_filter not in ("active", "inactive", "all"):
        raise ValueError(
            f"active_filter must be 'active', 'inactive', or 'all'; got {active_filter!r}"
        )
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")

    parts: list[str] = []
    parts.append(
        '<FindPartiesFromCatalog xmlns="http://www.eidr.org/schema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
    )
    parts.append(f"<PartyName>{_xml_escape(party_name)}</PartyName>")
    if role_filter is not None:
        parts.append(f"<RoleFilter>{_xml_escape(role_filter)}</RoleFilter>")
    parts.append(f"<ActiveFilter>{active_filter}</ActiveFilter>")
    parts.append(f"<PageNumber>{page_number}</PageNumber>")
    parts.append(f"<PageSize>{page_size}</PageSize>")
    if continuation_token is not None:
        parts.append(f"<ContinuationToken>{_xml_escape(continuation_token)}</ContinuationToken>")
    parts.append("</FindPartiesFromCatalog>")
    return "".join(parts)


def build_find_services_by_name(
    *,
    service_name: str,
    active_filter: str = "active",
    page_number: int = 1,
    page_size: int = 20,
    continuation_token: str | None = None,
) -> str:
    """Build a ``<FindServicesByName>`` XML body.

    Mirrors Java's ``ServiceQuery.findServicesByName``. Per
    ``service.xsd``'s ``serviceQueryType``, services don't have a
    role filter or an include-alternate-names attribute (alternate
    names aren't a concept for services), so this is a leaner shape
    than the parties variant.
    """
    if not service_name or not service_name.strip():
        raise ValueError("service_name must not be empty")
    if active_filter not in ("active", "inactive", "all"):
        raise ValueError(
            f"active_filter must be 'active', 'inactive', or 'all'; got {active_filter!r}"
        )
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")

    parts: list[str] = []
    parts.append(
        '<FindServicesByName xmlns="http://www.eidr.org/schema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
    )
    parts.append(f"<ServiceName>{_xml_escape(service_name)}</ServiceName>")
    parts.append(f"<ActiveFilter>{active_filter}</ActiveFilter>")
    parts.append(f"<PageNumber>{page_number}</PageNumber>")
    parts.append(f"<PageSize>{page_size}</PageSize>")
    if continuation_token is not None:
        parts.append(f"<ContinuationToken>{_xml_escape(continuation_token)}</ContinuationToken>")
    parts.append("</FindServicesByName>")
    return "".join(parts)


def build_find_services_from_catalog(
    *,
    service_name: str,
    active_filter: str = "active",
    page_number: int = 1,
    page_size: int = 20,
    continuation_token: str | None = None,
) -> str:
    """Build a ``<FindServicesFromCatalog>`` XML body.

    Mirrors Java's ``ServiceQuery.findServicesFromCatalog``.
    """
    if not service_name or not service_name.strip():
        raise ValueError("service_name must not be empty")
    if active_filter not in ("active", "inactive", "all"):
        raise ValueError(
            f"active_filter must be 'active', 'inactive', or 'all'; got {active_filter!r}"
        )
    if page_number < 1:
        raise ValueError(f"page_number must be >= 1, got {page_number}")
    if page_size < 1:
        raise ValueError(f"page_size must be >= 1, got {page_size}")

    parts: list[str] = []
    parts.append(
        '<FindServicesFromCatalog xmlns="http://www.eidr.org/schema" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
    )
    parts.append(f"<ServiceName>{_xml_escape(service_name)}</ServiceName>")
    parts.append(f"<ActiveFilter>{active_filter}</ActiveFilter>")
    parts.append(f"<PageNumber>{page_number}</PageNumber>")
    parts.append(f"<PageSize>{page_size}</PageSize>")
    if continuation_token is not None:
        parts.append(f"<ContinuationToken>{_xml_escape(continuation_token)}</ContinuationToken>")
    parts.append("</FindServicesFromCatalog>")
    return "".join(parts)
