"""Helpers shared between the sync and async client modules.

Functions in here have no I/O dependencies and are usable from
either :class:`~eidr.client.Client` or :class:`~eidr.client.AsyncClient`.
Kept in a separate module rather than imported from one client into
the other to avoid circular-import risk and to make the
"this is purely shared utility code" intent explicit.

If anything here grows runtime state (caches, registry lookups,
etc.), it should likely move back into a client module — the
contract here is "stateless free functions only."
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from eidr.codecs._rules import CodecDict


def coerce_id_to_str(value: object, *, param_name: str) -> str:
    """Coerce an ID-like value to a non-empty string.

    Accepts plain strings and any value with a ``__str__`` (e.g.
    :class:`~eidr.models.ids.EIDRID` value objects, which is what
    ``ServiceRecord.id`` / ``PartyRecord.id`` / ``ContentRecord.id``
    return).

    Discovered as a smoke-script bug during M9 live-test pass round
    2: callers naturally chain ``client.delete_service(record.id)``
    after a ``create_service`` call, but ``record.id`` is an
    :class:`EIDRID`, not a string. The previous validation
    (``if not service_id or not service_id.strip()``) raised
    ``AttributeError: 'EIDRID' object has no attribute 'strip'``,
    breaking the natural usage pattern.

    Raises:
        ValueError: If the value is ``None``, empty after stripping,
            or otherwise unusable.
    """
    if value is None:
        raise ValueError(f"{param_name} must be non-empty")
    text = str(value).strip()
    if not text:
        raise ValueError(f"{param_name} must be non-empty")
    return text


def resolve_resource_path(eidr_id: str) -> str:
    """Return the resolve-endpoint URL path for an EIDR ID.

    Uses the ID's prefix to distinguish Content / Party / Service:

    * ``10.5240/...`` → ``/object/{id}`` (Content)
    * ``10.5237/...`` → ``/party/resolve/{id}``
    * ``10.5239/...`` → ``/service/resolve/{id}``

    If the prefix is unrecognized we default to Content; the registry
    will return a not-found error for truly invalid IDs.

    Underscore-prefixed module but a plain (non-prefixed) function
    name: callers are sibling client modules, not the public API.
    The function is not exported from :mod:`eidr.client`.
    """
    stripped = eidr_id.strip()
    if stripped.startswith("10.5237/"):
        return f"/party/resolve/{stripped}"
    if stripped.startswith("10.5239/"):
        return f"/service/resolve/{stripped}"
    # Default to Content (10.5240/... and unrecognized prefixes).
    return f"/object/{stripped}"


def xml_to_record_codec_dict(xml_bytes: bytes) -> CodecDict:
    """Parse XML and strip the one-key root wrapper for record constructors.

    Used by Party/Service write-path response handling: the server
    returns a record body wrapped in its root element (``<Service>``
    or ``<Party>``), but the record wrapper's ``from_codec_dict``
    constructor expects the root's *body*, not the root itself. So
    we parse, find the single top-level key, and return its value.

    If the parsed result doesn't have the expected single-root
    shape (an unexpected envelope shape from the registry, for
    instance), we return the parsed result as-is and let the
    record wrapper raise its own error — the codec layer doesn't
    have enough context to give a better message.
    """
    from eidr.codecs import xml as xml_codec

    parsed = xml_codec.to_codec_dict(xml_bytes)
    if isinstance(parsed, dict) and len(parsed) == 1:
        only_value = next(iter(parsed.values()))
        if isinstance(only_value, dict):
            return only_value
    return parsed


def embed_party_password(party_xml: bytes | str, password: str) -> str:
    """Inject a ``<Password>`` element into a party body for create.

    The schema's ``partyCreationType`` requires ``<Password>`` as
    the last child of the party body. :meth:`PartyRecord.to_xml`
    produces a body suitable for resolution (no password); for
    create operations we splice in a ``<Password>`` element before
    serializing.

    The schema's ``simplePasswordType`` constrains valid characters
    at the registry side; we don't validate here. lxml handles
    XML-escaping for the password value.

    Idempotent against already-embedded passwords: if the input
    already has a ``<Password>`` child, it's replaced.
    """
    from lxml import etree

    if isinstance(party_xml, str):
        party_xml = party_xml.encode("utf-8")
    root = etree.fromstring(party_xml)
    ns = etree.QName(root).namespace
    password_tag = f"{{{ns}}}Password" if ns else "Password"

    for existing in root.findall(password_tag):
        root.remove(existing)

    pwd_el = etree.SubElement(root, password_tag)
    pwd_el.text = password

    result = etree.tostring(root, encoding="unicode")
    assert isinstance(result, str)
    return result


# ── Party-write Superparty gate ─────────────────────────────────────────────


#: Default Superparty ID — the EIDR registry hard-codes a single Party as
#: the only one allowed to perform Party-administration operations
#: (create / modify / delete / alias / activate / deactivate /
#: change-password). This ID is a universal constant across all EIDR
#: registries (production, sandbox1, sandbox2, sandbox2-mirror) per the
#: maintainer; the SDK exposes it as a configurable :class:`~eidr.Client`
#: kwarg in case future rotation is needed.
DEFAULT_SUPERPARTY_ID = "10.5237/superparty"

#: Operation names — used in :class:`EIDRSDKPolicyError` messages and as
#: keys in unit tests. Mirrors the ``Client`` method names so that
#: ``policy_error.operation == "create_party"`` is greppable.
SUPERPARTY_GATED_OPERATIONS: frozenset[str] = frozenset(
    {
        "create_party",
        "modify_party",
        "delete_party",
        "alias_party",
        "activate_party",
        "deactivate_party",
        "change_party_password",
    }
)


def check_superparty_gate(
    *,
    enforce: bool,
    superparty_id: str,
    caller_party_id: str,
    operation: str,
) -> None:
    """Raise :class:`~eidr.errors.EIDRSDKPolicyError` if the gate refuses.

    The Party-write Superparty gate is the SDK's client-side
    enforcement of a registry-side policy: only the Party whose ID
    matches the registry's hard-coded "Superparty" is permitted to
    execute Party-administration operations. The registry rejects
    other callers server-side; the SDK refuses earlier with a
    clearer message.

    The gate is *strict by default* (``enforce=True``). Callers can
    disable it by setting ``enforce_superparty_gate=False`` on their
    :class:`Client` / :class:`AsyncClient`, but the resulting
    requests will still be rejected by the registry — disabling is
    only useful for testing the SDK itself or for the unusual case
    of a caller who is the Superparty under a different ID than
    the SDK's default.

    Args:
        enforce: If ``False``, this function is a no-op.
        superparty_id: The Party ID the gate requires the caller to
            match (typically :data:`DEFAULT_SUPERPARTY_ID`).
        caller_party_id: The Party ID configured on the SDK client
            (from ``creds.party_id``).
        operation: The SDK method name being invoked
            (e.g., ``"create_party"``). Surfaced in the error
            message and as the ``operation`` attribute of the
            raised exception.

    Raises:
        EIDRSDKPolicyError: If ``enforce`` is true and
            ``caller_party_id != superparty_id``. The exception
            carries ``policy="superparty_required"`` plus the
            configured / required values for callers that want to
            inspect them programmatically.
    """
    if not enforce:
        return
    if caller_party_id == superparty_id:
        return
    from eidr.errors import EIDRSDKPolicyError

    raise EIDRSDKPolicyError(
        f"{operation}() requires Superparty credentials. "
        f"The configured Party ID ({caller_party_id!r}) does not "
        f"match the configured Superparty ID ({superparty_id!r}). "
        f"Party-administration operations are restricted by the "
        f"EIDR registry to a single hard-coded Party; general-"
        f"purpose callers should not invoke them. To override "
        f"the gate (e.g., for testing the SDK itself), pass "
        f"enforce_superparty_gate=False to the Client constructor.",
        policy="superparty_required",
        operation=operation,
        configured_value=caller_party_id,
        required_value=superparty_id,
    )
