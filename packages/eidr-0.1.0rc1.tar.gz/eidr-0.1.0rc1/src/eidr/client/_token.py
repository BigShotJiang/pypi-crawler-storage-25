"""Token type for async EIDR operations.

An EIDR async write (Register, Modify, Delete, etc. submitted with
``immediate=False``) returns a token instead of a final result. The
caller polls the token via a status-lookup endpoint until the
operation's outcome is known. Most operations resolve within seconds,
but cases requiring manual registry review can remain pending for
days.

This module provides the :class:`Token` class, which wraps a token
string together with a reference to the issuing :class:`Client` and
exposes polling/waiting helpers. Callers can also construct a Token
directly from a string (e.g., to resume polling after the process
that issued the original write has exited).

The Java SDK and its command-line tools do not bundle polling
helpers — callers write their own loops. This is a Python-side
convenience that keeps the common case (quick dedupe resolution,
return result inline) ergonomic, while still letting the caller
drop back to explicit polling for the pending-for-days case.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

from eidr.errors import EIDRProtocolError, EIDRTimeoutError

if TYPE_CHECKING:
    from eidr.client._async_client import AsyncClient
    from eidr.client._async_token import AsyncToken
    from eidr.client._client import Client
    from eidr.client._operation_result import OperationResult
    from eidr.client._response import ParsedResponse


__all__ = ["Token", "TokenStatus"]


class TokenStatus(StrEnum):
    """The resolved state of a :class:`Token`.

    Values are strings so they can be compared to literals in calling
    code without an explicit enum import.
    """

    PENDING = "pending"
    """The operation has not yet completed. Poll again later."""

    SUCCESS = "success"
    """The operation completed successfully. See
    :attr:`Token.last_response` for the result envelope and
    :meth:`Token.result` to extract a typed result."""

    FAILURE = "failure"
    """The registry rejected or failed the operation. See
    :attr:`Token.last_response` for error details."""


# EIDR status-lookup response codes, per the EIDR Registry User's Guide.
# The codes here match what appears inside ``<OperationStatus><Status>
# <Code>N</Code>``, NOT the top-level envelope <Status><Code>.
#
# These are distinct from _CODE_TO_EXCEPTION in _response.py — that one
# maps the top-level envelope status (e.g., "the entire request was
# rejected because you weren't authenticated"); THIS one maps per-
# operation status (e.g., "this particular sub-operation is still
# awaiting dedupe review"). A request can succeed at the envelope
# level and still have every sub-operation pending.
_PENDING_CODES: frozenset[int] = frozenset(
    {
        # Code values that indicate the operation is still in flight.
        # Common ones: 100 (in dedupe), 101 (manual review), etc.
        # The authoritative list is Registry-side; we treat "anything
        # that isn't explicitly success or failure" as pending rather
        # than maintaining a complete enumeration that might drift.
    }
)


@dataclass(slots=True)
class Token:
    """Handle to an async EIDR operation.

    Created by :meth:`Client.register` / :meth:`Client.modify` (and
    friends) when the request is submitted with ``immediate=False``,
    or constructed directly by callers resuming a previously-issued
    token.

    Attributes:
        value: The token string returned by the registry.
        status: Last known :class:`TokenStatus`. Starts as
            :attr:`TokenStatus.PENDING` until :meth:`poll` or
            :meth:`wait` updates it.
        last_response: The most recent :class:`ParsedResponse` from a
            status-lookup call, or ``None`` if the token has never
            been polled.

    Example::

        token = client.register(record, immediate=False, wait_timeout=0)
        # ...later, possibly in a different process:
        token.wait(timeout=300)
        if token.status is TokenStatus.SUCCESS:
            result_id = token.result_id()
    """

    value: str
    """The registry-issued token string."""

    _client: Client | None = field(default=None, repr=False)
    """Reference to the issuing Client. Required for polling; may be
    ``None`` if the Token was constructed standalone."""

    status: TokenStatus = TokenStatus.PENDING
    """Last known status. Updated by :meth:`poll` and :meth:`wait`."""

    last_response: ParsedResponse | None = field(default=None, repr=False)
    """Most recent response envelope from a status-lookup call."""

    def __post_init__(self) -> None:
        if not self.value or not isinstance(self.value, str):
            raise ValueError(f"Token value must be a non-empty string, got {self.value!r}")

    # ─── polling ────────────────────────────────────────────────────────

    def poll(self) -> TokenStatus:
        """Do one status-lookup call, update cached state, return status.

        Fast and non-blocking (one round-trip). Use :meth:`wait` to
        poll repeatedly with backoff.

        Raises:
            EIDRProtocolError: If this Token has no associated Client
                (e.g., constructed standalone without calling
                :meth:`Token.attach`).
        """
        if self._client is None:
            raise EIDRProtocolError(
                f"Token {self.value!r} has no associated Client; call "
                f"Token.attach(client) before polling, or construct "
                f"the Token via Client.register()/modify() rather than "
                f"directly."
            )
        response = self._client.status_lookup(self.value)
        self.last_response = response
        self.status = _status_from_response(response)
        return self.status

    def wait(
        self,
        *,
        timeout: float,
        initial_delay: float = 0.5,
        max_delay: float = 30.0,
        backoff_factor: float = 1.5,
    ) -> TokenStatus:
        """Poll repeatedly until the token resolves or ``timeout`` elapses.

        Uses exponential backoff starting at ``initial_delay`` seconds,
        multiplying by ``backoff_factor`` each iteration, capped at
        ``max_delay``. The defaults (0.5s, 1.5×, 30s cap) hit a decent
        balance between "probably ready within a few seconds" and
        "might take a while" without hammering the registry.

        Each iteration performs one :meth:`poll`. The method returns
        the first resolved status (``SUCCESS`` or ``FAILURE``) or
        raises :class:`EIDRTimeoutError` if still ``PENDING`` when
        ``timeout`` expires.

        Args:
            timeout: Maximum seconds to wait before giving up. A
                value of ``0`` performs exactly one poll.
            initial_delay: Seconds before the first retry after an
                initial PENDING result.
            max_delay: Cap on per-iteration sleep, to prevent the
                exponential from running away on long waits.
            backoff_factor: Multiplier applied to the delay between
                iterations.

        Returns:
            The final :attr:`TokenStatus` (SUCCESS or FAILURE).

        Raises:
            EIDRTimeoutError: If the token is still pending when the
                timeout elapses. The Token's :attr:`status` remains
                ``PENDING`` and can be polled again later.

        Example::

            try:
                status = token.wait(timeout=60)
            except EIDRTimeoutError:
                # Save the token string somewhere and poll later.
                persist(token.value)
        """
        if timeout < 0:
            raise ValueError(f"timeout must be >= 0, got {timeout}")

        deadline = time.monotonic() + timeout

        # First poll is unconditional (handles the common "already
        # done" case without any sleep).
        status = self.poll()
        if status is not TokenStatus.PENDING:
            return status

        if timeout == 0:
            raise EIDRTimeoutError(
                f"Token {self.value!r} is still pending and "
                f"timeout=0; caller asked for a single poll only."
            )

        delay = initial_delay
        while time.monotonic() < deadline:
            # Don't sleep past the deadline.
            remaining = deadline - time.monotonic()
            time.sleep(min(delay, remaining))
            if time.monotonic() >= deadline:
                break
            status = self.poll()
            if status is not TokenStatus.PENDING:
                return status
            delay = min(delay * backoff_factor, max_delay)

        raise EIDRTimeoutError(
            f"Token {self.value!r} still pending after {timeout}s; "
            f"save token.value and poll again later."
        )

    def operation_result(self, *, timeout: float | None = None) -> OperationResult:
        """Block until resolved, return a structured :class:`OperationResult`.

        Convenience wrapper for :meth:`wait` that returns a uniform
        :class:`OperationResult` regardless of whether the underlying
        operation echoed a record, returned an ID, or only an
        envelope. For most callers this is more useful than
        :meth:`result` (which returns the raw envelope) or
        :meth:`result_id` (which returns only the first ID).

        On a still-pending token whose timeout expires, the
        :class:`OperationResult`'s status is ``PENDING`` and the
        caller can check :attr:`OperationResult.sub_tokens` for any
        per-operation tokens that have completed independently.

        Args:
            timeout: Polling deadline in seconds. ``None`` waits
                indefinitely (use cautiously).

        Returns:
            An :class:`OperationResult` carrying status, IDs,
            sub-tokens, and the raw response.

        Raises:
            EIDRTimeoutError: If ``timeout`` elapsed without
                resolution.
        """
        from eidr.client._operation_result import operation_result_from

        # ``None`` → effectively infinite, mirroring :meth:`result`.
        effective_timeout = 10_000_000.0 if timeout is None else timeout
        try:
            status = self.wait(timeout=effective_timeout)
        except EIDRTimeoutError:
            # Timed out; return a PENDING result with whatever the
            # last poll captured. Reuse the same factory so sub-tokens
            # and IDs are extracted consistently with the resolved
            # path.
            if self.last_response is None:
                # Never polled at all — give the caller something
                # they can introspect rather than re-raising.
                raise
            return operation_result_from(self.last_response, status=TokenStatus.PENDING)
        assert self.last_response is not None
        return operation_result_from(self.last_response, status=status)

    def result(self, *, timeout: float | None = None) -> ParsedResponse:
        """Block until resolved, return the response; raise on failure.

        Convenience wrapper for :meth:`wait` when the caller wants
        "either succeed or throw." If ``timeout`` is ``None``, waits
        indefinitely.

        Returns:
            The :class:`ParsedResponse` from the final (successful)
            status-lookup call.

        Raises:
            EIDRProtocolError: If the token resolved to FAILURE.
            EIDRTimeoutError: If ``timeout`` elapsed without resolution.
        """
        # ``None`` → effectively infinite: use a very large number rather
        # than an actual loop, so Ctrl-C still works.
        effective_timeout = 10_000_000.0 if timeout is None else timeout
        status = self.wait(timeout=effective_timeout)

        if status is TokenStatus.SUCCESS:
            assert self.last_response is not None
            return self.last_response

        # FAILURE — extract reason from the last response if we can.
        assert self.last_response is not None
        reason = self.last_response.status_type or f"code={self.last_response.status_code}"
        raise EIDRProtocolError(f"Token {self.value!r} resolved to FAILURE: {reason}")

    def result_id(self) -> str | None:
        """Return the registered/modified EIDR ID, if the token carries one.

        For a successful Register or Match operation, the
        :class:`ParsedResponse` envelope typically contains an ``<ID>``
        element with the newly-assigned EIDR ID. This helper extracts
        it.

        Returns ``None`` if:

        * The token has not been polled yet.
        * The token has not resolved to SUCCESS.
        * The response envelope doesn't contain an ``<ID>`` at the
          expected location (e.g., for Match-only requests, which
          return dedupe scores rather than an assigned ID).
        """
        if self.last_response is None or self.status is not TokenStatus.SUCCESS:
            return None
        ns = {"eidr": "http://www.eidr.org/schema"}
        for op in self.last_response.operation_status_elements():
            id_elem = op.find("eidr:ID", ns)
            if id_elem is not None and id_elem.text:
                return str(id_elem.text).strip()
        # Fallback: top-level <ID> (some response shapes put it there).
        top_id = self.last_response.root.find("eidr:ID", ns)
        if top_id is not None and top_id.text:
            return str(top_id.text).strip()
        return None

    def attach(self, client: Client) -> None:
        """Attach a Client to a previously-detached Token.

        Useful when resuming polling on a Token that was serialized
        (only its ``value`` preserved) and later reconstructed::

            # In one process:
            token = client.register(record, immediate=False, wait_timeout=0)
            saved = token.value
            # Later, in another process:
            token = Token(value=saved)
            token.attach(new_client)
            token.wait(timeout=60)
        """
        self._client = client

    def to_async(self, async_client: AsyncClient) -> AsyncToken:
        """Convert this sync :class:`Token` to an :class:`AsyncToken`.

        Specifically addresses the sync-under-load fallback case: when
        a caller invokes :meth:`Client.register` or :meth:`Client.modify`
        with ``immediate=True`` and the registry returns a
        :class:`Token` instead of a record (because dedupe couldn't
        complete within the immediate-response window, per REST API
        §2.1.1), the caller may want to poll that token asynchronously
        from an existing async workflow. This method converts the
        sync handle to an awaitable one without re-issuing the write.

        The conversion is **one-way** — there is no
        :meth:`AsyncToken.to_sync`. Async-to-sync conversion would
        imply running ``asyncio.run()`` inside something that's
        already sync, which is almost always a mistake elsewhere in
        the caller's code.

        The returned :class:`AsyncToken` carries the same ``value``
        and ``last_response`` as this token, and ``status`` (so any
        completed poll result is preserved). The new token is bound
        to ``async_client``; the original sync token remains usable
        independently, though typically the caller drops the
        reference at conversion time.

        Args:
            async_client: The :class:`AsyncClient` that will own the
                new token's polling lifecycle.

        Returns:
            A new :class:`AsyncToken` bound to ``async_client``.
        """
        from eidr.client._async_token import AsyncToken

        return AsyncToken(
            value=self.value,
            _client=async_client,
            status=self.status,
            last_response=self.last_response,
        )


def _status_from_response(response: ParsedResponse) -> TokenStatus:
    """Classify a status-lookup response into a :class:`TokenStatus`.

    Reads the ``<OperationStatus><Status><Code>`` under
    ``<RequestStatusResults>``. Code 0 means success; anything else
    is either pending (awaiting dedupe/review) or failure, decided by
    whether a terminal-failure signal appears in the response.

    This is intentionally forgiving: codes we don't recognize are
    treated as PENDING rather than FAILURE, because silently treating
    a novel pending-state code as a failure would be much worse than
    the reverse (the caller just polls again).
    """
    # An envelope without operation statuses — take top-level code
    # verbatim. 0 = success, anything else = failure.
    ops = response.operation_status_elements()
    if not ops:
        if response.status_code == 0:
            return TokenStatus.SUCCESS
        return TokenStatus.FAILURE

    # Aggregate across operations. A batch is SUCCESS only if every
    # op succeeded; PENDING if any op is pending; FAILURE otherwise.
    ns = {"eidr": "http://www.eidr.org/schema"}
    any_pending = False
    any_failed = False
    for op in ops:
        status_elem = op.find("eidr:Status", ns)
        if status_elem is None:
            any_pending = True
            continue
        code_elem = status_elem.find("eidr:Code", ns)
        if code_elem is None or not code_elem.text:
            any_pending = True
            continue
        try:
            code = int(code_elem.text.strip())
        except ValueError:
            any_pending = True
            continue
        if code == 0:
            continue
        # Non-zero: distinguish pending from failure. If the operation
        # still carries a Token (sub-operation token), it's pending;
        # if it has an ID or a final error, it's failed. The registry
        # semantics here are documented in the User's Guide.
        if op.find("eidr:Token", ns) is not None:
            any_pending = True
        else:
            any_failed = True

    if any_failed:
        return TokenStatus.FAILURE
    if any_pending:
        return TokenStatus.PENDING
    return TokenStatus.SUCCESS
