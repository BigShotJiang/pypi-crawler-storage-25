"""EIDR REST API authorization header construction.

The EIDR REST API uses a stateless ``Authorization`` header of the form::

    Authorization: Eidr <UserID>:<PartyID>:Base64(SHA-256(password))

The password is never transmitted; only a SHA-256 digest (base64-encoded) is sent.
The resulting token is deterministic: the same inputs always produce the same
token, which is safe to cache for the lifetime of a process.

Security guidance:
  * The password shadow is not a one-time token. **Treat it as a long-lived
    credential.** Do not log, persist, or transmit it outside of the
    ``Authorization`` header of an HTTPS request.
  * The SDK never logs the constructed header. If you capture HTTP traffic
    for debugging, redact ``Authorization`` values yourself.
"""

from __future__ import annotations

import base64
import hashlib

__all__ = ["make_auth_header", "password_shadow"]


def password_shadow(password: str) -> str:
    """Compute the base64-encoded SHA-256 digest of a password.

    This is the scheme used by the EIDR REST API for the password portion
    of the ``Authorization`` header. The SHA-256 digest of the UTF-8-encoded
    password is base64-encoded using the standard alphabet with no line
    breaks.

    Args:
        password: The user's plaintext password.

    Returns:
        A 44-character ASCII string (base64 encoding of a 32-byte digest).

    Example:
        >>> password_shadow("hunter2")  # doctest: +SKIP
        'f52fbd32b2b3b86ff88ef6c490628285f482af15ddcb29541f94bcf526a3f6c7'
    """
    digest = hashlib.sha256(password.encode("utf-8")).digest()
    return base64.b64encode(digest).decode("ascii")


def make_auth_header(user_id: str, party_id: str, password: str) -> str:
    """Build the value of the ``Authorization`` header for EIDR REST API calls.

    The format is::

        Eidr <UserID>:<PartyID>:<password_shadow>

    where ``password_shadow`` is the base64-encoded SHA-256 digest of the
    UTF-8-encoded password. The resulting string is suitable for direct use
    as an HTTP ``Authorization`` header value.

    Args:
        user_id: The EIDR User ID (e.g., ``"10.5238/username"``).
        party_id: The EIDR Party ID (e.g., ``"10.5237/XXXX-XXXX"``).
        password: The user's plaintext password.

    Returns:
        The complete ``Authorization`` header value, starting with ``"Eidr "``.

    Example:
        >>> h = make_auth_header("10.5238/user", "10.5237/AAAA-BBBB", "pw")
        >>> h.startswith("Eidr 10.5238/user:10.5237/AAAA-BBBB:")
        True
    """
    return f"Eidr {user_id}:{party_id}:{password_shadow(password)}"
