"""EIDR credential loading.

Credentials can come from one of five sources, listed in decreasing order of
explicitness:

1. **Direct construction**: ``Credentials(user_id=..., party_id=..., password=...)``
2. **Explicit file path — EIDR XML config**: ``Credentials.from_eidr_xml(path)``.
   This is the format used by the EIDR command-line tools; it lives by default
   in ``~/.eidr`` on many installations.
3. **Explicit file path — JSON**: ``Credentials.from_json(path)``. Schema: a
   JSON object with keys ``USER_ID``, ``PARTY_ID``, ``PASSWORD``, and optional
   ``BASE_URL``.
4. **AWS Secrets Manager**: ``Credentials.from_aws_secret(name, region=...)``.
   Requires the ``aws`` extra (``pip install 'eidr[aws]'``).
5. **Environment variables**: ``Credentials.from_env()``.
   Reads ``EIDR_USER_ID``, ``EIDR_PARTY_ID``, ``EIDR_PASSWORD``,
   and optionally ``EIDR_BASE_URL``.

For most programs, :meth:`Credentials.load` runs the full default precedence
chain and returns the first usable result, raising
:class:`~eidr.errors.EIDRCredentialAmbiguityError` if multiple sources are
found and no disambiguation has been made via the ``EIDR_CREDENTIALS_SOURCE``
environment variable.

Security
--------
* :class:`Credentials` overrides ``__repr__``/``__str__`` to never print the
  password.
* The password is stored as a plain string; the SDK does not attempt memory
  scrubbing (CPython's string interning makes this unreliable). Callers who
  require stricter handling should use a short-lived credential store and
  destroy their :class:`Credentials` objects promptly after use.
"""

from __future__ import annotations

import json
import logging
import os
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from eidr.errors import (
    EIDRClientError,
    EIDRCredentialAmbiguityError,
    EIDRCredentialsNotFoundError,
)

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)


__all__ = ["Credentials"]


# Environment variables recognized by the loader.
ENV_USER = "EIDR_USER_ID"
ENV_PARTY = "EIDR_PARTY_ID"
ENV_PASSWORD = "EIDR_PASSWORD"
ENV_BASE_URL = "EIDR_BASE_URL"
ENV_CONFIG_FILE = "EIDR_CONFIG_FILE"
ENV_AWS_SECRET = "EIDR_AWS_SECRET"
ENV_AWS_REGION = "EIDR_AWS_REGION"
ENV_SOURCE = "EIDR_CREDENTIALS_SOURCE"

# Precedence order for the default chain. When multiple sources yield
# credentials, the first match wins *only* if EIDR_CREDENTIALS_SOURCE
# explicitly selects it; otherwise an ambiguity error is raised.
_DEFAULT_CHAIN: tuple[str, ...] = ("env", "xml", "json", "aws")

# Default locations searched for config/JSON files when not specified explicitly.
_DEFAULT_XML_PATHS: tuple[Path, ...] = (
    Path.home() / ".eidr" / "eidr.xml",
    Path.home() / ".eidr.xml",
    Path("eidr.xml"),
)
_DEFAULT_JSON_PATHS: tuple[Path, ...] = (
    Path.home() / ".eidr" / "secrets.json",
    Path(".secrets.json"),
)
_DEFAULT_AWS_SECRET_NAME = "EIDR_Credentials"
_DEFAULT_AWS_REGION = "us-west-2"


@dataclass(frozen=True)
class Credentials:
    """EIDR REST API credentials.

    This is an immutable value object. To change a credential, construct
    a new :class:`Credentials` instance.

    Attributes:
        user_id: The EIDR User ID (e.g., ``"10.5238/username"``).
        party_id: The EIDR Party ID (e.g., ``"10.5237/XXXX-XXXX"``).
        password: The user's plaintext password. Not printed by ``__repr__``.
        base_url: Optional base URL. When present, overrides any registry
            passed to :class:`~eidr.Client` unless the registry is given
            explicitly. This is a convenience for multi-environment configs
            that ship credentials and endpoint together.
        source: Diagnostic marker identifying which loader produced this
            instance (``"xml"``, ``"json"``, ``"aws"``, ``"env"``, ``"direct"``).
            Informational only.
    """

    user_id: str
    party_id: str
    password: str = field(repr=False)  # never appear in repr()
    base_url: str | None = None
    source: str = "direct"

    def __repr__(self) -> str:
        return (
            f"Credentials(user_id={self.user_id!r}, party_id={self.party_id!r}, "
            f"password=<redacted>, base_url={self.base_url!r}, source={self.source!r})"
        )

    def __str__(self) -> str:
        return f"Credentials(user_id={self.user_id}, party_id={self.party_id}, password=<redacted>)"

    # ─── construction from sources ────────────────────────────────────────

    @classmethod
    def from_eidr_xml(cls, path: str | os.PathLike[str]) -> Credentials:
        """Load credentials from a standard EIDR XML config file.

        The file is parsed namespace-agnostically; recognized element local
        names include (all case-insensitive):

        * **User ID**: ``User``, ``UserID``, ``User_Id``
        * **Party ID**: ``Party``, ``PartyID``, ``Party_Id``
        * **Password**: ``Password``, ``Passwd``
        * **Base URL**: ``URL``, ``RegistryURL``, ``Registry_URL``, ``Registry``

        Args:
            path: Path to the XML config file.

        Returns:
            A :class:`Credentials` instance with ``source="xml"``.

        Raises:
            EIDRClientError: If the file cannot be read or parsed, or if
                required fields are missing.

        Example:
            >>> creds = Credentials.from_eidr_xml("~/.eidr/eidr.xml")  # doctest: +SKIP
        """
        resolved = _expand(path)
        if not resolved.exists():
            raise EIDRClientError(f"EIDR XML config file not found: {resolved}")

        try:
            tree = ET.parse(resolved)
        except ET.ParseError as exc:
            raise EIDRClientError(f"EIDR XML config file is not valid XML: {resolved}") from exc

        root = tree.getroot()
        fields_map = {
            "user_id": ("user", "userid", "user_id"),
            "party_id": ("party", "partyid", "party_id"),
            "password": ("password", "passwd"),
            "base_url": ("url", "registryurl", "registry_url", "registry"),
        }
        extracted: dict[str, str] = {}
        for field_name, candidates in fields_map.items():
            value = _find_first_text(root, candidates)
            if value is not None:
                extracted[field_name] = value

        _require(extracted, ("user_id", "party_id", "password"), source=f"XML file {resolved}")
        return cls(
            user_id=extracted["user_id"],
            party_id=extracted["party_id"],
            password=extracted["password"],
            base_url=extracted.get("base_url"),
            source="xml",
        )

    @classmethod
    def from_json(cls, path: str | os.PathLike[str]) -> Credentials:
        """Load credentials from a local JSON file.

        The file must contain a single JSON object. Keys are read with
        case-insensitive matching against the following aliases:

        * **User ID**: ``USER_ID``, ``user_id``, ``user``
        * **Party ID**: ``PARTY_ID``, ``party_id``, ``party``
        * **Password**: ``PASSWORD``, ``password``
        * **Base URL**: ``BASE_URL``, ``URL``, ``REGISTRY_URL``

        Args:
            path: Path to the JSON file.

        Returns:
            A :class:`Credentials` instance with ``source="json"``.

        Raises:
            EIDRClientError: If the file cannot be read or parsed, or if
                required fields are missing.
        """
        resolved = _expand(path)
        if not resolved.exists():
            raise EIDRClientError(f"EIDR JSON credentials file not found: {resolved}")

        try:
            data = json.loads(resolved.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise EIDRClientError(
                f"EIDR JSON credentials file is not valid JSON: {resolved}"
            ) from exc

        if not isinstance(data, dict):
            raise EIDRClientError(
                f"EIDR JSON credentials file must contain a JSON object: {resolved}"
            )

        # Normalize keys to lowercase for case-insensitive matching.
        norm = {k.lower(): v for k, v in data.items()}

        def _get(*keys: str) -> str | None:
            for k in keys:
                if norm.get(k):
                    return str(norm[k])
            return None

        user_id = _get("user_id", "user")
        party_id = _get("party_id", "party")
        password = _get("password")
        base_url = _get("base_url", "url", "registry_url")

        missing = [
            label
            for label, value in (
                ("user_id", user_id),
                ("party_id", party_id),
                ("password", password),
            )
            if not value
        ]
        if missing:
            raise EIDRClientError(
                f"JSON credentials file {resolved} missing required field(s): {', '.join(missing)}"
            )
        # Narrow types after the missing-field check.
        assert user_id is not None
        assert party_id is not None
        assert password is not None
        return cls(
            user_id=user_id,
            party_id=party_id,
            password=password,
            base_url=base_url,
            source="json",
        )

    @classmethod
    def from_aws_secret(
        cls,
        name: str | None = None,
        region: str | None = None,
    ) -> Credentials:
        """Load credentials from AWS Secrets Manager.

        Requires the ``aws`` extra::

            pip install 'eidr[aws]'

        The secret value is expected to be a JSON object with the same key
        conventions as :meth:`from_json`.

        Args:
            name: Secret name. Defaults to ``EIDR_AWS_SECRET`` environment
                variable, or ``"EIDR_Credentials"`` if unset.
            region: AWS region. Defaults to ``EIDR_AWS_REGION`` environment
                variable, or ``"us-west-2"`` if unset.

        Returns:
            A :class:`Credentials` instance with ``source="aws"``.

        Raises:
            EIDRClientError: If ``boto3`` is not installed, or if the secret
                cannot be retrieved or parsed.
        """
        try:
            import boto3
            from botocore.exceptions import (
                BotoCoreError,
                ClientError,
                NoCredentialsError,
            )
        except ImportError as exc:
            raise EIDRClientError(
                "AWS credential source requires the 'aws' extra: pip install 'eidr[aws]'"
            ) from exc

        secret_name = name or os.environ.get(ENV_AWS_SECRET, _DEFAULT_AWS_SECRET_NAME)
        secret_region = region or os.environ.get(ENV_AWS_REGION, _DEFAULT_AWS_REGION)

        try:
            client = boto3.client("secretsmanager", region_name=secret_region)
            response = client.get_secret_value(SecretId=secret_name)
        except (NoCredentialsError, ClientError, BotoCoreError) as exc:
            raise EIDRClientError(
                f"Unable to retrieve AWS secret {secret_name!r} in {secret_region}: {exc}"
            ) from exc

        secret_string = response.get("SecretString")
        if not secret_string:
            raise EIDRClientError(
                f"AWS secret {secret_name!r} has no SecretString (only SecretBinary)"
            )

        try:
            data = json.loads(secret_string)
        except json.JSONDecodeError as exc:
            raise EIDRClientError(f"AWS secret {secret_name!r} is not valid JSON") from exc

        norm = {k.lower(): v for k, v in data.items()}

        def _get(*keys: str) -> str | None:
            for k in keys:
                if norm.get(k):
                    return str(norm[k])
            return None

        user_id = _get("user_id", "user")
        party_id = _get("party_id", "party")
        password = _get("password")
        base_url = _get("base_url", "url", "registry_url")

        missing = [
            label
            for label, value in (
                ("user_id", user_id),
                ("party_id", party_id),
                ("password", password),
            )
            if not value
        ]
        if missing:
            raise EIDRClientError(
                f"AWS secret {secret_name!r} missing required field(s): {', '.join(missing)}"
            )
        assert user_id is not None and party_id is not None and password is not None
        return cls(
            user_id=user_id,
            party_id=party_id,
            password=password,
            base_url=base_url,
            source="aws",
        )

    @classmethod
    def from_env(cls) -> Credentials:
        """Load credentials from environment variables.

        Reads ``EIDR_USER_ID``, ``EIDR_PARTY_ID``, ``EIDR_PASSWORD``, and
        optionally ``EIDR_BASE_URL``.

        Returns:
            A :class:`Credentials` instance with ``source="env"``.

        Raises:
            EIDRClientError: If any of the required environment variables
                is unset or empty.
        """
        user_id = os.environ.get(ENV_USER)
        party_id = os.environ.get(ENV_PARTY)
        password = os.environ.get(ENV_PASSWORD)
        base_url = os.environ.get(ENV_BASE_URL)

        missing = [
            name
            for name, value in (
                (ENV_USER, user_id),
                (ENV_PARTY, party_id),
                (ENV_PASSWORD, password),
            )
            if not value
        ]
        if missing:
            raise EIDRClientError(f"Environment variable(s) not set: {', '.join(missing)}")
        assert user_id is not None and party_id is not None and password is not None
        return cls(
            user_id=user_id,
            party_id=party_id,
            password=password,
            base_url=base_url,
            source="env",
        )

    # ─── unified loader with explicit precedence ──────────────────────────

    @classmethod
    def load(cls) -> Credentials:
        """Load credentials using the default precedence chain.

        The chain inspects the following sources, in order:

        1. Environment variables (``EIDR_USER_ID``, etc.)
        2. Standard EIDR XML config file (``EIDR_CONFIG_FILE``, then
           default search paths: ``~/.eidr/eidr.xml``, ``~/.eidr.xml``,
           ``./eidr.xml``)
        3. Local JSON file (default search: ``~/.eidr/secrets.json``,
           ``./.secrets.json``)
        4. AWS Secrets Manager (if ``boto3`` is importable)

        **No silent fallback.** If more than one source is available,
        :class:`~eidr.errors.EIDRCredentialAmbiguityError` is raised and
        the caller must either:

        * Set ``EIDR_CREDENTIALS_SOURCE`` to one of ``env``, ``xml``,
          ``json``, or ``aws`` to explicitly select a source, or
        * Call the specific loader (``from_env``, ``from_eidr_xml``, ...)
          directly with explicit arguments.

        Returns:
            A :class:`Credentials` instance.

        Raises:
            EIDRCredentialsNotFoundError: If no source yielded credentials.
            EIDRCredentialAmbiguityError: If multiple sources are available
                and none was selected via ``EIDR_CREDENTIALS_SOURCE``.
        """
        explicit = os.environ.get(ENV_SOURCE, "").strip().lower()
        if explicit:
            if explicit not in _DEFAULT_CHAIN:
                raise EIDRClientError(
                    f"{ENV_SOURCE}={explicit!r} is not a recognized credential source. "
                    f"Valid values: {', '.join(_DEFAULT_CHAIN)}"
                )
            creds = _try_source(explicit)
            if creds is None:
                raise EIDRCredentialsNotFoundError(
                    f"{ENV_SOURCE}={explicit!r} was set but source yielded no credentials."
                )
            log.info("Credentials loaded from source %r (explicitly selected).", explicit)
            return creds

        # No explicit selection — probe every source and require exactly one hit.
        hits: list[Credentials] = []
        for source in _DEFAULT_CHAIN:
            creds = _try_source(source)
            if creds is not None:
                hits.append(creds)

        if not hits:
            raise EIDRCredentialsNotFoundError(
                "No credentials found. Tried: environment variables, EIDR XML config, "
                "local JSON, AWS Secrets Manager. Set one of EIDR_USER_ID / "
                "EIDR_CONFIG_FILE / EIDR_AWS_SECRET, or call Credentials.from_* directly."
            )

        if len(hits) > 1:
            source_names = [c.source for c in hits]
            raise EIDRCredentialAmbiguityError(
                f"Multiple credential sources are available ({', '.join(source_names)}). "
                f"Set {ENV_SOURCE} to one of {', '.join(source_names)}, or call "
                f"Credentials.from_* directly to disambiguate.",
                sources=source_names,
            )

        creds = hits[0]
        log.info("Credentials loaded from source %r.", creds.source)
        return creds


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _expand(path: str | os.PathLike[str]) -> Path:
    """Expand ``~`` and environment variables in a path."""
    return Path(os.path.expandvars(os.path.expanduser(os.fspath(path))))


def _clean_tag(tag: str) -> str:
    """Strip XML namespace prefix from an element tag and lowercase the result."""
    if "}" in tag:
        tag = tag.split("}", 1)[1]
    return tag.strip().lower()


def _find_first_text(root: ET.Element, candidates: tuple[str, ...]) -> str | None:
    """Find the first element (any depth) whose local tag matches a candidate.

    Returns the stripped text content, or None if no match or empty text.
    """
    wanted = {c.lower() for c in candidates}
    for elem in root.iter():
        if _clean_tag(elem.tag) in wanted:
            text = (elem.text or "").strip()
            if text:
                return text
    return None


def _require(extracted: dict[str, str], required: tuple[str, ...], *, source: str) -> None:
    """Raise EIDRClientError if any required key is missing from ``extracted``."""
    missing = [k for k in required if not extracted.get(k)]
    if missing:
        raise EIDRClientError(f"{source} is missing required field(s): {', '.join(missing)}")


def _try_source(source: str) -> Credentials | None:
    """Attempt to load credentials from the named source, returning None on failure.

    Used by the default chain to probe sources without raising. Individual
    loader errors (e.g., malformed files) are re-raised; only "source not
    configured" cases return None.
    """
    if source == "env":
        if not os.environ.get(ENV_USER):
            return None
        return Credentials.from_env()

    if source == "xml":
        override = os.environ.get(ENV_CONFIG_FILE)
        if override:
            return Credentials.from_eidr_xml(override)
        for candidate in _DEFAULT_XML_PATHS:
            if _expand(candidate).exists():
                return Credentials.from_eidr_xml(candidate)
        return None

    if source == "json":
        for candidate in _DEFAULT_JSON_PATHS:
            if _expand(candidate).exists():
                return Credentials.from_json(candidate)
        return None

    if source == "aws":
        # Only attempt AWS if the caller explicitly configured a secret name
        # via env var. We don't probe AWS blindly; that would require boto3
        # to be installed and might generate unwanted AWS API calls.
        if not os.environ.get(ENV_AWS_SECRET):
            return None
        try:
            import boto3  # noqa: F401
        except ImportError:
            return None
        return Credentials.from_aws_secret()

    raise ValueError(f"Unknown credential source: {source!r}")
