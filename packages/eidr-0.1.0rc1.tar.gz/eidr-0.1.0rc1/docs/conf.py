"""Sphinx configuration for the EIDR Python SDK documentation."""

from __future__ import annotations

import sys
from importlib.metadata import version as _pkg_version
from pathlib import Path

# Make the src layout importable for autodoc.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

# ─── Project metadata ──────────────────────────────────────────────────────

project = "eidr"
author = "Entertainment Identifier Registry"
# Keep the year range open-ended in source; Sphinx will render "2026".
copyright = "2026, Entertainment Identifier Registry"  # noqa: A001

try:
    release = _pkg_version("eidr")
except Exception:  # package not installed yet during local builds
    release = "0.1.0.dev0"
version = ".".join(release.split(".")[:2])

# ─── Extensions ────────────────────────────────────────────────────────────

extensions = [
    "myst_parser",                 # Markdown + MyST directives
    "sphinx.ext.autodoc",          # Pull docstrings
    "sphinx.ext.napoleon",         # Google / NumPy docstring styles
    "sphinx.ext.viewcode",         # Link to source
    "sphinx.ext.intersphinx",      # Cross-link to Python / pydantic / httpx
    "autodoc2",                    # Richer auto-API docs
    "sphinx_copybutton",           # Copy-to-clipboard on code blocks
]

# ─── General ───────────────────────────────────────────────────────────────

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}
master_doc = "index"
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

# ─── MyST settings ─────────────────────────────────────────────────────────

myst_enable_extensions = [
    "colon_fence",
    "deflist",
    "fieldlist",
    "linkify",
    "smartquotes",
    "tasklist",
]
myst_heading_anchors = 3

# ─── autodoc / autodoc2 ────────────────────────────────────────────────────

autodoc_default_options = {
    "members": True,
    "member-order": "bysource",
    "show-inheritance": True,
    "undoc-members": False,
}
autodoc_typehints = "description"
autodoc_typehints_format = "short"
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_include_init_with_doc = False
napoleon_use_admonition_for_examples = True

# autodoc2 produces the rendered API reference tree under docs/apidocs/.
autodoc2_packages = [
    {
        "path": "../src/eidr",
        "auto_mode": True,
    },
]
autodoc2_render_plugin = "myst"
autodoc2_hidden_objects = ["dunder", "private"]
autodoc2_module_all_regexes = [r"^eidr(\..*)?$"]  # use __all__ where defined

# ─── Intersphinx ───────────────────────────────────────────────────────────

intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "pydantic": ("https://docs.pydantic.dev/latest", None),
    "httpx": ("https://www.python-httpx.org", None),
    "lxml": ("https://lxml.de", None),
}

# ─── HTML output ───────────────────────────────────────────────────────────

html_theme = "furo"
html_title = f"eidr {release}"
html_theme_options = {
    "sidebar_hide_name": False,
    "navigation_with_keys": True,
    "source_repository": "https://github.com/EIDR-ID/eidr-python-sdk",
    "source_branch": "main",
    "source_directory": "docs/",
    "footer_icons": [
        {
            "name": "GitHub",
            "url": "https://github.com/EIDR-ID/eidr-python-sdk",
            "html": "",
            "class": "fa-brands fa-solid fa-github fa-2x",
        },
    ],
}
html_static_path = ["_static"]
