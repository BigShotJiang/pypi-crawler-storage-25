# Contributing

Detailed contribution guidelines will be published when the project is moved
to the public EIDR-ID GitHub organization. Until then, contact EIDR at
<support@eidr.org>.

## Development setup

```bash
git clone https://github.com/EIDR-ID/eidr-python-sdk.git
cd eidr-python-sdk
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -e '.[dev,aws,canonical-json,docs]'
```

## Running tests

```bash
pytest                          # fast unit + codec tests
pytest -m integration           # tests hitting the live sandbox (requires creds)
pytest --cov=eidr --cov-report=html
```

## Building the docs

```bash
cd docs
sphinx-build -b html . _build/html
```

## Coding standards

- **Style:** [Ruff](https://docs.astral.sh/ruff/) (replaces black, isort, flake8).
- **Types:** `mypy --strict` against Python 3.11 (the supported floor).
- **Docstrings:** Google style.
- **Commits:** conventional-commit style preferred (`feat:`, `fix:`, `docs:`, etc.).
- **Testing:** every public function carries at least one unit test; codec
  changes carry a round-trip test on the corpus.

## Releasing

Maintainers only. Releases are published to PyPI via OIDC trusted publishing
from a tag matching `v*` on `main`. See `.github/workflows/release.yml`.
