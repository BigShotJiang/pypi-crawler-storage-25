# Getting started

This guide walks through the shortest path from a fresh `pip install`
to a useful interaction with the EIDR registry. It covers installing
the library, authenticating, and making your first resolve and write
calls. See the full guide index for deeper coverage of each topic.

## Install

```bash
pip install 'eidr[client]'      # codec, records, IDs, plus HTTP client
```

The base `eidr` package installs the codec and record layers only
(no network dependency). The `[client]` extra pulls in `httpx` for
the sync and async HTTP clients.

## Anonymous resolve (no credentials)

The EIDR Resolve endpoint is publicly accessible — you can resolve
any Content, Party, or Service ID against `registries.RESOLVE`
without credentials. The one caveat: anonymous resolves do not
return `AlternateID` records in the response.

```python
from eidr import Client, registries

with Client(registries.RESOLVE) as client:
    record = client.resolve("10.5240/7791-8534-2C23-9030-8610-5")
    print(record.resource_name)
    # "The Great Train Robbery"
    print(record.referent_type)
    # "Movie"
```

Any writable registry (`SANDBOX1`, `SANDBOX2`, `PRODUCTION`) requires
credentials; anonymous calls against them fail with
`EIDRAuthenticationError`.

## Authenticated access

For writes and for Alt-ID-inclusive resolves, supply credentials.

```python
from eidr import Client, Credentials, registries

# Load from the first configured source (env / EIDR XML config / local JSON / AWS)
creds = Credentials.load()

# Or load from an explicit source:
creds = Credentials.from_eidr_xml("~/.eidr/eidr.xml")
creds = Credentials.from_json(".secrets.json")
creds = Credentials.from_env()
creds = Credentials.from_aws_secret("EIDR_Credentials", region="us-west-2")

with Client(registries.SANDBOX2, creds) as client:
    ...
```

See [Credentials](credentials.md) for the full precedence chain and
disambiguation rules.

## Register a record

```python
from eidr.models.content import ContentRecord

record = ContentRecord.from_xml(open("my-record.xml", "rb").read())

with Client(registries.SANDBOX2, creds) as client:
    # Synchronous: returns the registered record with assigned ID.
    # (May also return a Token if the registry defers under load —
    # handle both.)
    result = client.register(record, immediate=True)
    if isinstance(result, ContentRecord):
        print("Assigned:", result.id)
    else:  # Token
        done = result.operation_result(timeout=120)
        print("Assigned after polling:", done.id)
```

See [Registering](registering.md) for async registrations, dedupe
modes, and the sync-under-load fallback.

## Query

```python
with Client(registries.SANDBOX2, creds) as client:
    results = client.query(
        "/FullMetadata/BaseObjectData/ReferentType IS Movie",
        page_number=1,
        page_size=50,
    )
    for record in results.records:
        print(record.id, record.resource_name)

    if results.has_more_pages:
        next_page = client.query(
            "/FullMetadata/BaseObjectData/ReferentType IS Movie",
            page_number=2,
            page_size=50,
        )
```

`query()` returns a `QueryResults` object carrying the parsed
records, the total match count, and pagination metadata. Pagination
is explicit — you control which page to fetch.

## Async (asyncio) workflow

For programs using `asyncio`, `AsyncClient` mirrors `Client`'s API.
Every method is `async def`; returned `Token`s are `AsyncToken`s
with awaitable `poll` / `wait` / `operation_result`.

```python
import asyncio
from eidr import AsyncClient, Credentials, registries

async def main():
    async with AsyncClient(registries.SANDBOX2, Credentials.load()) as client:
        record = await client.resolve("10.5240/...")
        token = await client.register(new_record, immediate=False)
        result = await token.operation_result(timeout=120)
        print(result.status.name, result.id)

asyncio.run(main())
```

See [Bulk operations](bulk-operations.md) for async token polling
and batch workflows.

## File-based mode (no network)

When you only need XML↔JSON conversion, use the codec layer directly:

```python
from eidr.codecs import xml, json

# XML bytes → JSON dict (MovieLabs encoding)
d = xml.to_json_dict(xml_bytes)

# JSON dict → XML bytes (canonical form for signing)
xml_bytes = json.to_xml_canonical(d, method="c14n2")
```

See [XML ↔ JSON codec](xml-json-codec.md) for the full contract.

## Next steps

- [Credentials](credentials.md) — source precedence, AWS setup, disambiguation
- [Error handling](error-handling.md) — the exception hierarchy and when to retry
- [Bulk operations](bulk-operations.md) — async/bulk registration and token polling
