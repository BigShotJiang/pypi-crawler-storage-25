# License

This project is licensed under the Apache License, Version 2.0.

```{include} ../LICENSE
:code: text
```
