# eidr — Python SDK

`eidr` is the official Python SDK for the
[Entertainment Identifier Registry](https://eidr.org).
It provides a typed, ergonomic interface to EIDR's Content, Party, and Service
ID registries, with full support for both the native XML API and the JSON API
Proxy.

```{warning}
**Pre-1.0 development.** The public API is subject to change until `1.0.0`.
Lock your dependency to a specific minor version until the project reaches
`1.0.0`.
```

## At a glance

- **Full REST coverage** — Resolve, Query, GraphTraversal, Register,
  Match, Modify, Delete, Promote, Alias, AddRelationship /
  RemoveRelationship / ReplaceRelationship, StatusLookup, plus
  raw-payload Party and Service queries.
- **Two operating modes** — file-based (codec only) for pipelines and
  CLIs; object-based (typed models) for rich programmatic use.
- **XML and JSON codecs** — one object model, two codecs, following
  the MovieLabs MDDF JSON Encoding Best Practice.
- **Sync and async** — `Client` and `AsyncClient` mirror the same
  method surface; `Token` and `AsyncToken` likewise.
- **Typed end-to-end** — `mypy --strict` clean, PEP 561 `py.typed`.

## Installation

```bash
pip install eidr                   # codec + records + IDs (no network)
```

Optional extras:

```bash
pip install 'eidr[client]'         # HTTP client (sync + async), httpx
pip install 'eidr[aws]'            # AWS Secrets Manager credential source
pip install 'eidr[digital]'        # typed pydantic models for the Digital sub-tree
pip install 'eidr[client,aws]'     # both
```

## Contents

```{toctree}
:maxdepth: 2
:caption: User Guide

guide/getting-started
guide/credentials
guide/resolving
guide/querying
guide/registering
guide/modifying
guide/bulk-operations
guide/xml-json-codec
guide/error-handling
```

```{toctree}
:maxdepth: 2
:caption: Reference

apidocs/index
changelog
```

```{toctree}
:maxdepth: 1
:caption: Project

contributing
license
```

## Relationship to other EIDR tools

- [`eidr-cli`](https://pypi.org/project/eidr-cli/) — separate package;
  command-line tools built on this library. Each tool also serves as a worked
  example of best-practice library use.
- [EIDR Java SDK](https://github.com/EIDR-ID/eidr-java-sdk) — the long-standing
  reference SDK. This Python library implements the same API surface with
  Python-native ergonomics.

## Indices

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
