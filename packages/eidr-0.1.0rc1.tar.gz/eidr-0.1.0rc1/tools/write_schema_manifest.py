#!/usr/bin/env python3
"""Write the bundled-schema provenance manifest.

Run by maintainers when bundled XSDs change. Computes a SHA-256
hash for each XSD in ``src/eidr/schemas/bundled/`` and writes the
manifest to ``MANIFEST.json`` in the same directory. End users
do not run this — the manifest is checked into the repo and
shipped pre-built.

After running this, the maintainer is expected to:

1. Inspect the diff in ``src/eidr/schemas/bundled/MANIFEST.json``
2. Run ``python tools/generate_digital.py`` to regenerate the
   typed Digital model with the updated manifest hash embedded
3. Run ``ruff check --fix && ruff format && mypy && pytest``
4. Commit both files together, with a message naming the schema
   changes ("regen schemas: bumped md-v2_8.xsd to v2.8.1")
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from eidr.schemas._manifest import (  # noqa: E402
    MANIFEST_FILENAME,
    compute_manifest,
)
from eidr.schemas._source import BundledSchemaSource  # noqa: E402


def main() -> None:
    bundled_dir = SRC / "eidr" / "schemas" / "bundled"
    target = bundled_dir / MANIFEST_FILENAME

    source = BundledSchemaSource()
    manifest = compute_manifest(source)

    # Pretty-print so the on-disk file diffs cleanly when XSDs
    # change. The internal manifest_sha256 is computed against
    # a canonical (compact) form, so the on-disk pretty-printing
    # has no effect on the hash itself.
    target.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    sys.stdout.write(
        f"[write_schema_manifest] wrote {target}\n"
        f"[write_schema_manifest] manifest_sha256: "
        f"{manifest['manifest_sha256']}\n"
        f"[write_schema_manifest] tracked: {len(manifest['files'])} files\n"  # type: ignore[arg-type]
    )


if __name__ == "__main__":
    main()
