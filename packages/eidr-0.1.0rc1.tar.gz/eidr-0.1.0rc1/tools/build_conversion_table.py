#!/usr/bin/env python3
"""Build the bundled Conversion Table JSON from the source XLSX.

The MovieLabs/EIDR XML→JSON Conversion Table is the authoritative list
of data-bearing fields in the EIDR Content-ID schema. This tool reads
the XLSX (which lives outside the repository) and emits a
machine-readable JSON artifact under
``src/eidr/schemas/bundled/conversion_table.json`` that downstream
consumers (typed-model layer, CLI documentation, OpenAPI generator) can
load without needing ``openpyxl``.

Usage:
    python tools/build_conversion_table.py path/to/XML_to_JSON-ConversionTable.xlsx

The output is deterministic (sorted, stable key order) so regeneration
produces minimal diffs.

Output schema (JSON):

    {
      "version": "<xlsx source filename or identifier>",
      "generated_from": "<xlsx filename>",
      "row_count": <int>,
      "paths": [
        {
          "xml_path": "/FullMetadata/BaseObjectData/ResourceName",
          "xml_path_dedup": "/BaseObjectData/ResourceName",   # Full/Self collapsed
          "json_key": "value",
          "database_location": "...",
          "notes": "...",
          "is_attribute": false,
          "is_namespace_decl": false,
          "star_level": 1,
          "star_schema": "ResourceName",
          "bmr_stand_alone_works": "R",
          "bmr_episodics": "R",
          "bmr_edits": "R",
          "bmr_clips": "R",
          "bmr_manifestations": "R",
          "bmr_notes": null,
          "review_comparison_type": "exact",
          "review_comparison_options": null
        },
        ...
      ]
    }
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

try:
    from openpyxl import load_workbook
except ImportError:
    print(
        "openpyxl is required: pip install openpyxl",
        file=sys.stderr,
    )
    raise


# Column layout, 1-indexed (matches the observed layout of the v1 XLSX).
COLS = {
    "xml_level": 1,
    "xml_name": 2,
    "json_key": 3,
    "database_location": 4,
    "json_key_notes": 5,
    "star_level": 6,
    "star_schema": 7,
    "star_schema_notes": 8,
    "bmr_stand_alone_works": 9,
    "bmr_episodics": 10,
    "bmr_edits": 11,
    "bmr_clips": 12,
    "bmr_manifestations": 13,
    "bmr_notes": 14,
    # column 15 is blank in the sample
    "review_comparison_type": 16,
    "review_comparison_options": 17,
}


def _strip_root(xml_path: str) -> str:
    """Strip /FullMetadata or /SelfDefinedMetadata prefix so duplicates collapse."""
    for pfx in ("/FullMetadata", "/SelfDefinedMetadata"):
        if xml_path.startswith(pfx):
            return xml_path[len(pfx):] or "/"
    return xml_path


def build_conversion_table(xlsx_path: Path) -> dict[str, Any]:
    wb = load_workbook(str(xlsx_path), data_only=True)
    ws = wb[wb.sheetnames[0]]

    paths: list[dict[str, Any]] = []
    seen_rows = 0

    for row_idx in range(2, ws.max_row + 1):
        xml_name = ws.cell(row=row_idx, column=COLS["xml_name"]).value
        if not xml_name:
            continue
        seen_rows += 1

        entry = {
            "xml_path": xml_name,
            "xml_path_dedup": _strip_root(xml_name),
            "json_key": ws.cell(row=row_idx, column=COLS["json_key"]).value,
            "database_location": ws.cell(row=row_idx, column=COLS["database_location"]).value,
            "notes": ws.cell(row=row_idx, column=COLS["json_key_notes"]).value,
            "is_attribute": "@" in xml_name,
            "is_namespace_decl": "@xmlns" in xml_name,
            "star_level": ws.cell(row=row_idx, column=COLS["star_level"]).value,
            "star_schema": ws.cell(row=row_idx, column=COLS["star_schema"]).value,
            "star_schema_notes": ws.cell(row=row_idx, column=COLS["star_schema_notes"]).value,
            "bmr_stand_alone_works": ws.cell(row=row_idx, column=COLS["bmr_stand_alone_works"]).value,
            "bmr_episodics": ws.cell(row=row_idx, column=COLS["bmr_episodics"]).value,
            "bmr_edits": ws.cell(row=row_idx, column=COLS["bmr_edits"]).value,
            "bmr_clips": ws.cell(row=row_idx, column=COLS["bmr_clips"]).value,
            "bmr_manifestations": ws.cell(row=row_idx, column=COLS["bmr_manifestations"]).value,
            "bmr_notes": ws.cell(row=row_idx, column=COLS["bmr_notes"]).value,
            "review_comparison_type": ws.cell(row=row_idx, column=COLS["review_comparison_type"]).value,
            "review_comparison_options": ws.cell(row=row_idx, column=COLS["review_comparison_options"]).value,
        }
        paths.append(entry)

    # Sort by xml_path for deterministic output
    paths.sort(key=lambda p: p["xml_path"])

    return {
        "generated_from": xlsx_path.name,
        "row_count": seen_rows,
        "paths": paths,
    }


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <path-to-XML_to_JSON-ConversionTable.xlsx>",
              file=sys.stderr)
        return 2

    xlsx_path = Path(sys.argv[1])
    if not xlsx_path.exists():
        print(f"File not found: {xlsx_path}", file=sys.stderr)
        return 1

    repo_root = Path(__file__).resolve().parent.parent
    out_path = repo_root / "src" / "eidr" / "schemas" / "bundled" / "conversion_table.json"

    table = build_conversion_table(xlsx_path)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(table, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )
    print(f"Wrote {out_path}: {table['row_count']} rows ({len(table['paths'])} paths)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
