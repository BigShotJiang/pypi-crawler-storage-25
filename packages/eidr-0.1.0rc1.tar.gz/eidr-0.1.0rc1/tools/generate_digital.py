#!/usr/bin/env python3
"""Regenerate the typed Digital sub-model from the bundled XSD.

Run by SDK maintainers when the bundled schema changes. End users
do **not** run this — the generated module
(``src/eidr/models/_digital_generated.py``) is checked into the
repo and shipped with releases. Generation at install time would
add an avoidable build dependency and break offline installs.

Usage::

    python tools/generate_digital.py            # bundled schema (default)
    python tools/generate_digital.py --remote   # live schema from eidr.org

The generator points :mod:`xsdata` at the chosen schema source,
restricts output to the Digital-related type subtree (filtered by
type-name pattern), and writes a single Python module under
``src/eidr/models/``. After running, the maintainer is expected
to:

1. ``ruff check src tests --fix && ruff format src tests``
2. ``mypy src/eidr``
3. ``pytest`` (full suite)
4. Inspect the generated module diff in git
5. Commit the regenerated file with a message naming the schema
   source ("regen Digital from bundled md-v28-eidr.xsd @ {hash}")

The script is deterministic given the same input schema; running
it twice in a row should produce a byte-identical generated file.
If a future ``xsdata`` version introduces output differences, the
maintainer regenerates against that version and commits the new
output as part of the version bump.

Why ``xsdata-pydantic`` over plain ``xsdata``: pydantic v2 gives
us validation on construction and field-level constraint
enforcement (``Field(..., max_length=N)`` derived from XSD
restrictions), which is what we want for the typed-model surface.
The plain ``xsdata`` output is dataclasses-based with no
validation; we'd need a parallel validator layer.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# Import the SchemaSource abstraction directly from src/ — this
# script runs at SDK-development time, not as an installed entry
# point, so importing from the source tree by path is correct.
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from eidr.schemas import BundledSchemaSource, RemoteSchemaSource, SchemaSource  # noqa: E402


# Schemas to feed xsdata. Order matters for cross-references —
# ``md-v28-eidr.xsd`` imports ``doiavs.xsd``; including both
# satisfies the import. Other schemas in the bundle (api.xsd,
# bulk.xsd, dedup.xsd, service.xsd) are out of scope for the
# Digital sub-model and excluded.
DIGITAL_SCHEMA_FILES = (
    # The EIDR-namespace schemas. ``common.xsd`` imports
    # ``md-v28-eidr.xsd`` and ``doiavs.xsd`` so all transitively-
    # used types come along. We include them all explicitly here
    # so the staging directory has every file xsdata might
    # request, and so the generator's behavior doesn't depend on
    # xsdata's import-resolution order.
    "doi.xsd",
    "doiavs.xsd",
    "iso3166a2.xsd",
    "md-v28-eidr.xsd",
    "common.xsd",
)

# Where the generated module lands. Single file rather than a
# package: simpler for callers to import, and the generated tree
# is small enough not to need splitting.
OUTPUT_PATH = SRC / "eidr" / "models" / "_digital_generated.py"


def stage_schemas(source: SchemaSource, target_dir: Path) -> None:
    """Materialize the schemas this generator needs into ``target_dir``.

    xsdata reads from a filesystem path. For both bundled and
    remote sources we copy/fetch into a temp dir so xsdata sees
    the same shape regardless of source. This also gives us a
    natural diff anchor: if a schema changed since last generation,
    ``git diff`` against a temp-staged copy makes the change
    visible.
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    for name in DIGITAL_SCHEMA_FILES:
        data = source.read(name)
        (target_dir / name).write_bytes(data)


def run_xsdata(staged_dir: Path, output_module: Path) -> None:
    """Invoke ``xsdata`` to generate pydantic models.

    We shell out to the ``xsdata`` CLI rather than using the Python
    API because the CLI has a more stable interface across versions
    and produces a cleaner output module path. xsdata writes a
    single ``<package>.py`` file alongside its working directory
    when ``--structure-style single-package`` is used; we capture
    that file and copy it into the SDK source tree.
    """
    with tempfile.TemporaryDirectory() as tmp_pkg_dir:
        cmd = [
            sys.executable,
            "-m",
            "xsdata",
            "generate",
            "--output",
            "pydantic",
            "--package",
            "_digital_pkg",
            "--structure-style",
            "single-package",
            "--compound-fields",
            str(staged_dir / "common.xsd"),
        ]
        result = subprocess.run(
            cmd,
            cwd=Path(tmp_pkg_dir),
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            sys.stderr.write(
                f"xsdata failed (exit {result.returncode}):\n"
                f"stdout:\n{result.stdout}\n"
                f"stderr:\n{result.stderr}\n"
            )
            raise SystemExit(2)

        # xsdata writes the package as a flat ``<name>.py`` file in
        # the working directory. Find it.
        candidates = list(Path(tmp_pkg_dir).glob("*.py"))
        # Drop xsdata's __init__.py companion if present
        candidates = [
            p
            for p in candidates
            if p.name != "__init__.py"
        ]
        if not candidates:
            sys.stderr.write(
                f"xsdata produced no output module in {tmp_pkg_dir}.\n"
                f"stdout:\n{result.stdout}\n"
            )
            raise SystemExit(2)
        if len(candidates) > 1:
            sys.stderr.write(
                f"xsdata produced multiple output modules: {candidates}; "
                f"expected exactly one with --structure-style "
                f"single-package.\n"
            )
            raise SystemExit(2)

        generated = candidates[0]
        body = generated.read_text()

        # xsdata-pydantic's generator emits
        # ``model_config = ConfigDict(defer_build=True)`` on each
        # generated class. With pydantic v2 schema generation, that
        # alone is not enough — the xsdata custom types
        # (:class:`XmlDuration`, etc.) aren't recognized by pydantic,
        # and constructing instances directly (rather than via
        # xsdata-pydantic's parser) raises a schema-generation
        # error on those classes. We need
        # ``arbitrary_types_allowed=True`` on the affected classes
        # too. xsdata-pydantic's runtime compat layer sets that at
        # the mixin level when their parser builds a model, but
        # direct instantiation skips that path.
        #
        # We narrow the patch: only classes that transitively
        # mention one of the xsdata custom type names in their
        # body get the ``arbitrary_types_allowed=True`` config.
        # This keeps pydantic's strict typing intact for the bulk
        # of the model tree (Reviewer 2 / R1 #7 / R2 #2 — narrow
        # the broad relaxation to what actually needs it).
        body = _narrow_arbitrary_types_allowed(body)

        # Embed the schema manifest hash so the generated artifact
        # is mechanically tied to the exact XSD bytes it was built
        # from. If the bundled XSDs change without a regen, a
        # provenance check can catch the drift.
        from eidr.schemas._manifest import (  # noqa: PLC0415
            manifest_sha256,
        )
        from eidr.schemas._source import (  # noqa: PLC0415
            BundledSchemaSource,
        )

        schema_hash = manifest_sha256(BundledSchemaSource())

        header = (
            '"""Auto-generated EIDR/MovieLabs metadata model — DO NOT EDIT BY HAND.\n\n'
            "Regenerated from the bundled EIDR XSD (`md-v28-eidr.xsd` and\n"
            "imports) by ``tools/generate_digital.py``. To update, edit the\n"
            "source schemas under ``src/eidr/schemas/bundled/`` and rerun\n"
            "the generator. Hand-edits will be lost on next regen.\n\n"
            "Despite the module name, the generated tree covers the entire\n"
            "MovieLabs MD-v2.8 (EIDR profile) schema, not just the Digital\n"
            "subtree. The Digital types are the headline use case for the\n"
            "typed surface — see :mod:`eidr.models.digital` for the\n"
            "developer-facing import — but the rest of the MD types are\n"
            "available here too for callers that need them.\n\n"
            "This module imports cleanly without any runtime work; it just\n"
            "defines pydantic v2 model classes. Construction and validation\n"
            "happen on demand when callers instantiate or assign to fields.\n"
            '"""\n\n'
            f"# Schema manifest SHA-256: {schema_hash}\n"
            "# (computed from src/eidr/schemas/bundled/MANIFEST.json at\n"
            "# generation time; if this differs from the live manifest,\n"
            "# the bundled XSDs have been edited without regeneration.)\n\n"
            "# ruff: noqa\n"
            "# mypy: ignore-errors\n"
            "# fmt: off\n\n"
        )
        output_module.parent.mkdir(parents=True, exist_ok=True)
        output_module.write_text(header + body)


_XSDATA_CUSTOM_TYPES = (
    "XmlDuration",
    "XmlDate",
    "XmlDateTime",
    "XmlTime",
    "XmlPeriod",
    "QName",
)
"""xsdata-pydantic custom types that pydantic v2 doesn't have
built-in validators for. A class whose body mentions any of these
names needs ``arbitrary_types_allowed=True`` for direct
construction (without going through xsdata's parser) to succeed.
"""


def _narrow_arbitrary_types_allowed(body: str) -> str:
    """Patch ``arbitrary_types_allowed=True`` only on classes that need it.

    Walks the generated module text class-by-class. For each
    ``class Foo(BaseModel):`` block, scans the body for any of
    the xsdata custom type names. If found, the class's
    ``ConfigDict(defer_build=True)`` becomes
    ``ConfigDict(defer_build=True, arbitrary_types_allowed=True)``;
    otherwise it stays untouched.

    The implementation is deliberately string-based, not AST-based:
    the generator's output style is stable enough that splitting
    on ``\\nclass `` is reliable, and avoiding an AST round-trip
    keeps this script dependency-free beyond what xsdata already
    needs.
    """
    # Split on the canonical class boundary. The first chunk is
    # the module prologue (imports, header comment); subsequent
    # chunks each begin with the class name.
    chunks = body.split("\nclass ")
    if len(chunks) < 2:
        # Generator produced no classes — let the caller's sanity
        # check fail with a clearer message.
        return body

    # Reassemble, patching each class chunk
    out_chunks = [chunks[0]]
    for chunk in chunks[1:]:
        if any(name in chunk for name in _XSDATA_CUSTOM_TYPES):
            chunk = chunk.replace(
                "ConfigDict(defer_build=True)",
                "ConfigDict(defer_build=True, arbitrary_types_allowed=True)",
            )
        out_chunks.append(chunk)
    return "\nclass ".join(out_chunks)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--remote",
        action="store_true",
        help="Fetch from https://www.eidr.org/schema/ instead of "
        "the bundled snapshot. Requires the [client] extra.",
    )
    parser.add_argument(
        "--remote-base",
        default=None,
        help="Override the remote base URL (implies --remote).",
    )
    args = parser.parse_args()

    source: SchemaSource
    if args.remote or args.remote_base:
        source = (
            RemoteSchemaSource(args.remote_base)
            if args.remote_base
            else RemoteSchemaSource()
        )
        sys.stdout.write(
            f"[generate_digital] using RemoteSchemaSource "
            f"({source.base_url if isinstance(source, RemoteSchemaSource) else 'remote'})\n"
        )
    else:
        source = BundledSchemaSource()
        sys.stdout.write("[generate_digital] using BundledSchemaSource\n")

    with tempfile.TemporaryDirectory() as staging:
        staged = Path(staging) / "schemas"
        stage_schemas(source, staged)
        sys.stdout.write(
            f"[generate_digital] staged {len(DIGITAL_SCHEMA_FILES)} "
            f"schema file(s) to {staged}\n"
        )

        run_xsdata(staged, OUTPUT_PATH)
        sys.stdout.write(f"[generate_digital] wrote {OUTPUT_PATH}\n")
        sys.stdout.write(
            f"[generate_digital] now run: ruff check --fix, ruff format, "
            f"mypy, pytest\n"
        )

    # Best-effort sanity: did we actually produce a file with
    # any types?
    text = OUTPUT_PATH.read_text()
    type_count = text.count("class ")
    if type_count < 5:
        sys.stderr.write(
            f"[generate_digital] WARNING: only {type_count} class(es) "
            f"emitted; xsdata may have ignored the schema. Inspect "
            f"the output file before committing.\n"
        )


if __name__ == "__main__":
    main()
