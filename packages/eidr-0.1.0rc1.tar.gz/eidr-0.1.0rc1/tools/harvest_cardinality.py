#!/usr/bin/env python3
"""Harvest cardinality hints from the bundled EIDR XSDs.

Scans every ``.xsd`` file under ``src/eidr/schemas/bundled/`` and derives
the set of element declarations that are effectively multi-valued. An
element is considered multi-valued if:

* its own ``maxOccurs`` is greater than 1, *or*
* it appears inside an ``xs:choice``, ``xs:sequence``, or ``xs:all`` group
  whose ``maxOccurs`` is greater than 1.

The tool writes two artifacts under ``src/eidr/codecs/``:

* ``_multi_qualified.py`` — the authoritative map keyed by ``(namespace,
  localname)``. This is the canonical cardinality source.
* ``_multi_local.py`` — a namespace-agnostic local-name fallback used
  when a caller cannot provide qualified names.

Run this tool when the bundled XSDs change. The output is
deterministic (sorted) so diffs on regeneration are meaningful.

Usage:
    python tools/harvest_cardinality.py

The output files are committed to the repository. Users do not need to
run this tool themselves — the pre-generated cardinality data ships
with the package.
"""

from __future__ import annotations

import sys
from collections import defaultdict
from pathlib import Path

from lxml import etree

XS = "http://www.w3.org/2001/XMLSchema"

# Conventional prefix → namespace URI. Used only for generating readable
# comments in the output files; not functionally important.
NS_COMMENT_PREFIX = {
    "http://www.eidr.org/schema": "eidr",
    "http://www.movielabs.com/schema/md/v2.8/md": "md",
    "http://www.doi.org/2010/DOISchema": "doi",
    "http://www.doi.org/2010/DOISchemaAVS": "doiavs",
    "http://www.doi.org/2010/iso3166a2": "iso3166",
}


# Response-level wrappers that are singleton inside a single record but
# appear multiple times when a registry response bundles many records.
# Technically not XSD-multi, but we include them for practical reasons
# (bulk query / resolve responses regularly contain 100+ of these).
RESPONSE_LEVEL_WRAPPERS = [
    ("http://www.eidr.org/schema", "FullMetadata"),
    ("http://www.eidr.org/schema", "SelfDefinedMetadata"),
    ("http://www.eidr.org/schema", "ProvenanceMetadata"),
]


def is_effectively_multi(element_decl: etree._Element) -> bool:
    """An element is multi if its maxOccurs, or an ancestor group's, is > 1."""
    mo = element_decl.get("maxOccurs", "1")
    if mo == "unbounded" or (mo.isdigit() and int(mo) > 1):
        return True

    # Walk up through nested xs:choice / xs:sequence / xs:all groups.
    parent = element_decl.getparent()
    while parent is not None and isinstance(parent.tag, str):
        ptag = parent.tag
        if ptag in (f"{{{XS}}}choice", f"{{{XS}}}sequence", f"{{{XS}}}all"):
            pmo = parent.get("maxOccurs", "1")
            if pmo == "unbounded" or (pmo.isdigit() and int(pmo) > 1):
                return True
            parent = parent.getparent()
        else:
            break
    return False


def resolve_ref(ref: str, xsd_root: etree._Element, tns: str) -> tuple[str, str]:
    """Resolve an element ref QName to (namespace, localname)."""
    if ":" in ref:
        prefix, local = ref.split(":", 1)
        ns = xsd_root.nsmap.get(prefix, tns)
        return ns, local
    return tns, ref


# Container types that represent transport/response wrappers, not record content.
# When evaluating whether an element is "really" multi at the record level, we
# ignore observations inside these wrappers — an element being singleton in a
# query container is not evidence that it is singleton in the actual record
# (e.g., `ID` is singleton inside `BaseObjectData` but multi inside
# `queryResultsType`; we want the BaseObjectData interpretation).
TRANSPORT_CONTEXT_TYPES: frozenset[str] = frozenset({
    "requestType",
    "responseType",
    "messageType",
    "queryResultsType",
    "resolutionSetType",
    "operationStatusType",
    "operationType",
    "tokenCancellationRequestType",
    "requestStatusType",
    "userDOIListType",
    "partyQueryResultsType",
    "serviceQueryResultsType",
    "addRelationshipType",
    "removeRelationshipType",
    "replaceRelationshipType",
    "modifyType",
    "deleteType",
    "aliasType",
    "promoteType",
    "findAncestorsType",
    "findDescendantsType",
    "getDependantsType",
    "getSeriesAncestryType",
    "getLightweightRelationshipsType",
    "getRemotestAncestorType",
    "getLeafDescendantsType",
    "getParentType",
    "getChildrenType",
    "queryType",
    "duplicateType",
    "reportQueryType",
})


def harvest(xsd_dir: Path) -> dict[str, set[str]]:
    """Scan XSDs under ``xsd_dir``. Return mapping namespace → set of local names.

    An element is recorded as multi if it is declared multi in any
    *record-level* context — that is, any complexType **outside** the
    transport-wrapper set (see :data:`TRANSPORT_CONTEXT_TYPES`).

    The same name can be multi in record contexts and singleton in
    transport contexts (e.g., ``AlternateID`` is multi inside
    ``BaseObjectData`` but singleton inside ``linkedAlternateIDType``,
    which represents one specific alternate ID being linked). The
    record-level interpretation wins because that's the semantics
    callers actually want when parsing a record.

    Names that are multi *only* in transport contexts (e.g., ``ID``
    in ``queryResultsType``) are excluded — at the record level
    they are singleton.
    """
    # Per-name list of (containing_complexType_name, is_multi) observations
    contexts: dict[tuple[str, str], list[tuple[str | None, bool]]] = defaultdict(list)

    xsd_files = sorted(xsd_dir.glob("*.xsd"))
    if not xsd_files:
        raise SystemExit(f"No .xsd files found under {xsd_dir}")

    for xsd_path in xsd_files:
        tree = etree.parse(str(xsd_path))
        root = tree.getroot()
        tns = root.get("targetNamespace", "")

        for el in root.iter(f"{{{XS}}}element"):
            multi = is_effectively_multi(el)
            name = el.get("name")
            ref = el.get("ref")

            if name:
                ns, local = tns, name
            elif ref:
                ns, local = resolve_ref(ref, root, tns)
            else:
                continue

            ct_name = _enclosing_complex_type_name(el)
            contexts[(ns, local)].append((ct_name, multi))

    # An element is multi iff it is multi in any record-level (non-transport)
    # context. Transport-only multi observations are ignored.
    by_ns: dict[str, set[str]] = defaultdict(set)
    for (ns, local), occs in contexts.items():
        record_level_multi = any(
            m for ct, m in occs if ct not in TRANSPORT_CONTEXT_TYPES
        )
        if record_level_multi:
            by_ns[ns].add(local)

    # Reinstate the response-level wrappers explicitly — they're singleton
    # in record contexts but appear multiple times when bundled into bulk
    # responses.
    for ns, local in RESPONSE_LEVEL_WRAPPERS:
        by_ns[ns].add(local)

    return dict(by_ns)


def _enclosing_complex_type_name(el: etree._Element) -> str | None:
    """Return the name of the nearest ancestor xs:complexType, or ``None``."""
    parent = el.getparent()
    while parent is not None and isinstance(parent.tag, str):
        if parent.tag == f"{{{XS}}}complexType":
            return parent.get("name") or "(anon)"
        parent = parent.getparent()
    return None


def write_qualified_module(out_path: Path, by_ns: dict[str, set[str]]) -> None:
    """Write the authoritative qualified-name map as a Python module."""
    header = f'''"""Authoritative cardinality map, harvested from the bundled EIDR XSDs.

Keys are ``(namespace, localname)`` tuples. Every entry is an element
that is declared multi-valued in the XSD (either directly via
``maxOccurs > 1`` or transitively via a parent choice/sequence/all group
whose ``maxOccurs > 1``) or is a response-level wrapper that regularly
appears multiple times in bulk responses.

This file is regenerated by :mod:`tools.harvest_cardinality`. Do not
edit by hand.

Source schemas bundled under ``src/eidr/schemas/bundled/`` at generation
time; regenerate whenever those XSDs are updated.
"""

from __future__ import annotations

EIDR_MULTI_QUALIFIED: frozenset[tuple[str, str]] = frozenset({{
'''

    lines = [header]
    # Emit sorted by namespace, then localname.
    for ns in sorted(by_ns):
        locals_sorted = sorted(by_ns[ns])
        prefix_comment = NS_COMMENT_PREFIX.get(ns, "?")
        lines.append(f"    # {prefix_comment}: {ns}\n")
        for local in locals_sorted:
            lines.append(f"    ({ns!r}, {local!r}),\n")
    lines.append("})\n")

    out_path.write_text("".join(lines), encoding="utf-8")
    total = sum(len(v) for v in by_ns.values())
    print(f"  wrote {out_path}: {total} qualified entries across {len(by_ns)} namespaces")


def write_local_module(out_path: Path, by_ns: dict[str, set[str]]) -> None:
    """Write the namespace-agnostic local-name fallback as a Python module."""
    all_locals: set[str] = set()
    for names in by_ns.values():
        all_locals.update(names)

    header = '''"""Namespace-agnostic multi-element local names.

Used as a fallback when the codec cannot match qualified names (e.g.
when processing XML fragments with unusual or missing namespace
declarations). Derived from :data:`EIDR_MULTI_QUALIFIED` by collapsing
across namespaces.

Some local names (e.g. ``Identifier``, ``Type``, ``URL``, ``name``)
appear in multiple namespaces. Using the qualified map is always
preferable when possible.

This file is regenerated by :mod:`tools.harvest_cardinality`. Do not
edit by hand.
"""

from __future__ import annotations

EIDR_MULTI_LOCAL: frozenset[str] = frozenset({
'''

    lines = [header]
    for local in sorted(all_locals):
        lines.append(f"    {local!r},\n")
    lines.append("})\n")

    out_path.write_text("".join(lines), encoding="utf-8")
    print(f"  wrote {out_path}: {len(all_locals)} distinct local names")


def main() -> int:
    repo_root = Path(__file__).resolve().parent.parent
    xsd_dir = repo_root / "src" / "eidr" / "schemas" / "bundled"
    codec_dir = repo_root / "src" / "eidr" / "codecs"

    if not xsd_dir.exists():
        print(f"XSD directory not found: {xsd_dir}", file=sys.stderr)
        return 1

    print(f"Harvesting cardinality from {xsd_dir}...")
    by_ns = harvest(xsd_dir)

    write_qualified_module(codec_dir / "_multi_qualified.py", by_ns)
    write_local_module(codec_dir / "_multi_local.py", by_ns)
    print("done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
