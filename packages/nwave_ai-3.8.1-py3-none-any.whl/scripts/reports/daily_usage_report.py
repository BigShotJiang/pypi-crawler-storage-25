"""Daily nWave usage report — searches GitHub for attribution commits and posts to Slack.

Runs as GitHub Actions cron job (6:57 UTC daily) or manually.
Requires: GH_TOKEN (GitHub), SLACK_ADOPTION_WEBHOOK_URL (Slack incoming webhook
scoped to the #nwave_adoption_report channel).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone


INTERNAL_ORGS = {"nWave-ai", "Alcor-Academy"}
INTERNAL_USERS = {"11PJ11", "conso"}
# Dedicated webhook for #nwave_adoption_report. Falls back to the legacy
# SLACK_WEBHOOK_URL for local runs that still use the old secret.
SLACK_WEBHOOK_URL = os.environ.get("SLACK_ADOPTION_WEBHOOK_URL") or os.environ.get(
    "SLACK_WEBHOOK_URL", ""
)

# Known user context — enriched manually as we learn about adopters.
# Key: GitHub login. Values: type label for the report.
KNOWN_USERS: dict[str, str] = {
    "SDiamante13": "External (dotfiles — stable adopter)",
    "pmvanev": "External (SBIR — US gov research)",
    "christianBorrello": "External",
    "andlaf-ak": "External",
    "11PJ11": "Internal (Ale)",
    "conso": "Internal (Marco)",
}

# Known repo context — enriched manually.
KNOWN_REPOS: dict[str, str] = {
    "SDiamante13/dotfiles": "Personal dotfiles (nWave as daily tool)",
    "pmvanev/sbir-plugin-cc": "SBIR plugin for Claude Code",
    "christianBorrello/the-augmented-craftsman": "AI-augmented development",
    "SagitterSpa/SagitterHub": "Corporate repo (Sagitter Spa)",
    "andlaf-ak/claude-code-agents": "Claude Code agent collection",
    "Alcor-Academy/nwave-landing": "nWave landing page",
    "nWave-ai/nwave-dev": "nWave framework (internal)",
}


def search_attribution_commits(hours: int = 24) -> list[dict]:
    """Search GitHub for commits with nWave attribution trailer in the last N hours.

    Uses server-side --author-date filter so the result budget is not consumed
    by older commits before client-side filtering.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")
    result = subprocess.run(
        [
            "gh",
            "search",
            "commits",
            "Co-Authored-By: nWave",
            f"--author-date=>={cutoff_str}",
            "--sort=author-date",
            "--order=desc",
            "--limit",
            "200",
            "--json",
            "repository,author,commit,sha",
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        print(f"GitHub search failed: {result.stderr}", file=sys.stderr)
        return []

    return json.loads(result.stdout) if result.stdout.strip() else []


def is_external_user(login: str) -> bool:
    """Check if a user is external (not internal org member or known internal)."""
    return login not in INTERNAL_USERS


def is_external_repo(repo_full_name: str) -> bool:
    """Check if a repo belongs to an external org."""
    org = repo_full_name.split("/", maxsplit=1)[0] if "/" in repo_full_name else ""
    return org not in INTERNAL_ORGS


def filter_external(commits: list[dict]) -> list[dict]:
    """Filter out internal org commits."""
    return [
        c
        for c in commits
        if is_external_repo(c.get("repository", {}).get("fullName", ""))
    ]


def get_cumulative_data() -> tuple[dict[str, set[str]], set[str]]:
    """Get all-time user -> repos mapping and all external repos.

    Returns (user_repos, all_repos) where user_repos maps login -> set of repo names.

    Uses --limit 500 to surface the long tail of adopters that gets buried
    under high-volume repos at lower limits. (--limit 1000 triggers a gh CLI
    query escaping bug; 500 is the practical safe ceiling.)
    External repo discovery is decoupled from author identity: an external
    repo is counted as an adopter even when the commit author is internal
    (e.g., during coaching sessions).
    """
    result = subprocess.run(
        [
            "gh",
            "search",
            "commits",
            "Co-Authored-By: nWave",
            "--sort=author-date",
            "--order=desc",
            "--limit",
            "500",
            "--json",
            "repository,author",
        ],
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        return {}, set()

    commits = json.loads(result.stdout) if result.stdout.strip() else []
    user_repos: dict[str, set[str]] = {}
    all_repos: set[str] = set()
    for c in commits:
        repo = c.get("repository", {}).get("fullName", "")
        author = c.get("author", {}).get("login", "")
        if not repo:
            continue
        if is_external_repo(repo):
            all_repos.add(repo)
            if author and is_external_user(author):
                user_repos.setdefault(author, set()).add(repo)
    return user_repos, all_repos


def _user_type(login: str) -> str:
    """Get the type label for a user."""
    return KNOWN_USERS.get(login, "External")


def _repo_description(repo: str) -> str:
    """Get a short description for a repo."""
    return KNOWN_REPOS.get(repo, "")


def format_report(
    recent_external: list[dict],
    user_repos: dict[str, set[str]],
    all_repos: set[str],
) -> str:
    """Format the Slack message with user/repo table."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    lines = [f":bar_chart: *nWave Daily Usage Report — {today}*", ""]

    # Recent activity section
    if recent_external:
        lines.append(
            f":new: *New external activity (last 24h): {len(recent_external)} commits*"
        )
        for c in recent_external:
            repo = c.get("repository", {}).get("fullName", "")
            author = c.get("author", {}).get("login", "unknown")
            msg = c.get("commit", {}).get("message", "").split("\n")[0][:60]
            lines.append(f"  `@{author}` in `{repo}` — _{msg}_")
    else:
        lines.append("No new external nWave commits in the last 24 hours.")

    lines.append("")

    # Cumulative adopters table
    ext_users = len(user_repos)
    ext_repos = len(all_repos)
    lines.append(
        f":chart_with_upwards_trend: *Cumulative adopters*: "
        f"{ext_users} external users, {ext_repos} external repos"
    )
    lines.append("")

    if user_repos:
        lines.append("```")
        # Header
        lines.append(f"{'User':<20} {'Repo':<42} {'Type'}")
        lines.append(f"{'-' * 20} {'-' * 42} {'-' * 30}")

        # Sort by user, then repo
        for user in sorted(user_repos):
            repos = sorted(user_repos[user])
            user_type = _user_type(user)
            for i, repo in enumerate(repos):
                desc = _repo_description(repo)
                label = f"{user_type} ({desc})" if desc else user_type
                # Truncate label to fit
                label = label[:30]
                display_user = user if i == 0 else ""
                lines.append(f"{display_user:<20} {repo:<42} {label}")
        lines.append("```")

    # Drift detection: surface repos discovered but missing from KNOWN_REPOS
    unlabelled = sorted(all_repos - set(KNOWN_REPOS.keys()))
    if unlabelled:
        lines.append("")
        lines.append(
            f":label: *New unlabelled repos discovered ({len(unlabelled)})* "
            "— please add to KNOWN_REPOS in daily_usage_report.py:"
        )
        for repo in unlabelled:
            lines.append(f"  - `{repo}`")

    lines.append("")
    lines.append(
        "_Note: GitHub commit search indexes the default branch only and may lag "
        "by a few hours. Repos pushing to feature branches will appear after merge._"
    )
    lines.append("_Generated by Claude Code on behalf of the nWave team._")

    return "\n".join(lines)


def post_to_slack(message: str) -> bool:
    """Post message to Slack via incoming webhook."""
    if not SLACK_WEBHOOK_URL:
        print(
            "SLACK_ADOPTION_WEBHOOK_URL not set — printing to stdout instead",
            file=sys.stderr,
        )
        print(message)
        return False

    import requests

    resp = requests.post(
        SLACK_WEBHOOK_URL,
        json={"text": message},
        timeout=10,
    )
    if resp.status_code != 200:
        print(f"Slack post failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return False

    print("Report posted to Slack")
    return True


def main() -> None:
    """Generate and post daily usage report."""
    print("Searching GitHub for nWave attribution commits...")

    recent = search_attribution_commits(hours=24)
    recent_external = filter_external(recent)
    user_repos, all_repos = get_cumulative_data()

    print(f"Found {len(recent)} recent commits ({len(recent_external)} external)")
    print(
        f"Cumulative: {len(user_repos)} external users, {len(all_repos)} external repos"
    )

    report = format_report(recent_external, user_repos, all_repos)
    post_to_slack(report)


if __name__ == "__main__":
    main()
