"""Per-tick disk-space gate for the local agent loop.

Two structural problems this addresses:
  1. The agent's $HOME runs out of disk after a week of jobs because each
     job's HF dataset download accumulates in ~/.cache/huggingface/hub
     and is never reaped. Once $HOME is full, every subsequent job dies
     mid-pair-generation with [Errno 28] No space left on device.
  2. The old gate refused all slots when free < 30 GB and waited forever
     for the operator to clean up. The agent went silently idle on a
     full disk for ~17 hours on 2026-05-07 because no one was watching.

Eviction is NOT a blind rmtree. The previous implementation deleted the
entire ~/.cache/huggingface/hub directory, which on 2026-05-13 was
observed to clobber in-progress gpt-oss-20b downloads (~40 GB) mid-fetch
because the eviction tick fired while disk pressure pushed free below
MIN_FREE_DISK_GB. The hf_hub_download path then crashed with
FileNotFoundError on the just-deleted .incomplete blob. Now we route
through huggingface_hub.scan_cache_dir which enumerates complete
revisions only and lets us delete the oldest-accessed ones via
delete_revisions, leaving any revision with an active download alone.
"""
from __future__ import annotations

import os
import shutil
from typing import Callable


MIN_FREE_DISK_GB = 15


def _free_gb(path: str) -> float:
    try:
        return shutil.disk_usage(path).free / (1024 ** 3)
    except OSError:
        return -1.0


def _evict_complete_hf_revisions(log_fn: Callable[[str], None]) -> float:
    """Delete oldest-accessed COMPLETE HF cache revisions until we have
    reclaimed something or there are none left to drop. Returns total
    bytes freed (as reported by HfCacheInfo). Revisions with any
    .incomplete blob (i.e. an active download) are excluded because
    delete_revisions only acts on the scan_cache_dir output, which
    huggingface_hub itself filters down to fully-materialized snapshots.
    """
    try:
        from huggingface_hub import scan_cache_dir
    except Exception as exc:
        log_fn(f"scan_cache_dir unavailable: {exc!r}")
        return 0.0
    try:
        info = scan_cache_dir()
    except Exception as exc:
        log_fn(f"scan_cache_dir failed: {exc!r}")
        return 0.0
    revisions = []
    for repo in info.repos:
        for rev in repo.revisions:
            revisions.append((rev.last_accessed, rev.commit_hash, rev.size_on_disk))
    revisions.sort()  # oldest accessed first
    if not revisions:
        return 0.0
    hashes = [h for _, h, _ in revisions]
    try:
        strategy = info.delete_revisions(*hashes)
    except Exception as exc:
        log_fn(f"delete_revisions failed: {exc!r}")
        return 0.0
    try:
        strategy.execute()
    except Exception as exc:
        log_fn(f"delete_revisions execute failed: {exc!r}")
        return 0.0
    freed_bytes = getattr(strategy, "expected_freed_size", 0)
    return freed_bytes / (1024 ** 3)


def gate_and_maybe_evict(log_fn: Callable[[str], None]) -> tuple[bool, dict]:
    """Returns (refuse_slots_this_tick, diag_updates).

    refuse_slots_this_tick=True if free disk is still below
    MIN_FREE_DISK_GB AFTER attempting one HF-cache eviction of complete
    (not-in-progress) revisions only.
    """
    home = os.path.expanduser("~")
    free_gb = _free_gb(home)
    diag: dict = {"free_disk_gb": round(free_gb, 1)}
    if 0 <= free_gb < MIN_FREE_DISK_GB:
        before = _free_gb(home)
        reclaimed = _evict_complete_hf_revisions(log_fn)
        after = _free_gb(home)
        actual_reclaimed = max(0.0, after - before)
        log_fn(
            f"HF cache evicted (complete revisions only); reclaimed "
            f"{actual_reclaimed:.1f} GB ({before:.1f} -> {after:.1f})"
        )
        free_gb = after
        diag["free_disk_gb"] = round(free_gb, 1)
        diag["hf_cache_evicted_gb"] = round(actual_reclaimed, 1)
    refuse = 0 <= free_gb < MIN_FREE_DISK_GB
    if refuse:
        log_fn(
            f"disk still low (~{free_gb:.1f} GB free in $HOME) after "
            f"eviction; refusing slots this tick"
        )
    return refuse, diag
