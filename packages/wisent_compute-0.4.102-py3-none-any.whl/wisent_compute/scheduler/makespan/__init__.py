"""Makespan-minimizing job-to-agent matcher.

Replaces the VRAM-balancing _assign_jobs_to_agents body that lived in
coordinator.py. The user's spec is: 'the queue should optimize for the
fastest possible completion.' The previous code used gpu_mem_gb as the
backlog proxy, which is a memory constraint, not a runtime estimate. A
6 GB job that does many forward passes can outrun a 26 GB job that does
few; treating VRAM as time produced a fleet-balancer, not a makespan
optimizer.

What this module does each coordinator tick:
  1. Build a (model, task) -> mean_runtime_seconds map from the
     completed/ blobs. TTL-cached at module scope for 600s; the catalog
     of (model, task) pairs is small (<= a few hundred) so the cost is
     amortized across many ticks.
  2. List live agents from capacity/<consumer_id>.json (HEARTBEAT_TTL_S
     = 180s window; mirror of the previous coordinator).
  3. Seed each live agent's active_slots with its currently-running
     jobs (running/ blobs whose instance_ref hostname matches the
     agent), so the matcher accounts for in-flight work.
  4. Sort queued jobs by (-priority, -estimated_runtime) (LPT in time).
  5. For each queued job, for every eligible agent, simulate the
     earliest VRAM-feasible start time and the resulting finish time;
     pick the agent that finishes the job earliest; add a slot at
     (finish, vram) to that agent's projection.
  6. Write assigned_to back to the queue blob.

assigned_to enforcement still lives in providers/local/helpers/_job_eligible
so the agent side is unchanged from 0.4.100.

VRAM-concurrency model on each agent: an agent of total_vram_gb can run
any subset of jobs whose summed gpu_mem_gb <= total_vram_gb in parallel.
A new job (need_vram) starts at the earliest t where freed VRAM by
that point covers need_vram, i.e., the earliest end_time at which the
cumulative-freed budget reaches need_vram. This is the standard
multi-machine variable-VRAM single-resource scheduling approximation;
it ignores per-job CPU and disk contention, which empirically have not
been the bottleneck on this fleet.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import time as _time
from typing import Callable, Optional

from ..._catalog.gpu_sku import GPU_SIZING  # noqa: F401 (used implicitly through eligibility downstream)
from ...queue.storage import JobStorage


HEARTBEAT_TTL_S = 180
HISTORY_TTL_S = 600
DEFAULT_RUNTIME_S = 1800
COMPLETED_SAMPLE_CAP = 4000  # don't scan every completed/ blob each refresh

_MODEL_RE = re.compile(r"--model\s+(\S+)")
_TASK_RE = re.compile(r"--task\s+(\S+)")
_INSTANCE_HOST_RE = re.compile(r"^[^@]+@(.+)$")

_history_cache: dict[tuple[str, str], float] = {}
_history_cache_built_at: float = 0.0


def _extract_model_task(command: str) -> tuple[str, str]:
    m = _MODEL_RE.search(command or "")
    t = _TASK_RE.search(command or "")
    model = m.group(1).strip("'\"") if m else ""
    task = t.group(1).strip("'\"") if t else ""
    return model, task


def _build_history(store: JobStorage, log_fn: Callable[[str], None]) -> dict[tuple[str, str], float]:
    """Mean runtime in seconds per (model, task), from completed/ blobs.

    Reads at most COMPLETED_SAMPLE_CAP blobs ordered by GCS-default
    iteration (alphabetical job_id, which is random hex — effectively a
    uniform sample). Skips jobs without started_at/completed_at.
    """
    bucket = getattr(store, "_sdk_bucket", None)
    if bucket is None:
        return {}
    by_key: dict[tuple[str, str], list[float]] = {}
    scanned = 0
    for blob in bucket.list_blobs(prefix="completed/"):
        if scanned >= COMPLETED_SAMPLE_CAP:
            break
        scanned += 1
        try:
            doc = json.loads(blob.download_as_text())
        except Exception:
            continue
        st = doc.get("started_at")
        ct = doc.get("completed_at")
        if not st or not ct:
            continue
        try:
            elapsed = (
                dt.datetime.fromisoformat(ct.replace("Z", "+00:00"))
                - dt.datetime.fromisoformat(st.replace("Z", "+00:00"))
            ).total_seconds()
        except Exception:
            continue
        if elapsed <= 0:
            continue
        model, task = _extract_model_task(doc.get("command") or "")
        if not model or not task:
            continue
        by_key.setdefault((model, task), []).append(elapsed)
    out = {k: sum(v) / len(v) for k, v in by_key.items() if v}
    log_fn(f"makespan: history rebuilt from {scanned} completed/ blobs, {len(out)} (model,task) keys")
    return out


def _history(store: JobStorage, log_fn: Callable[[str], None]) -> dict[tuple[str, str], float]:
    global _history_cache, _history_cache_built_at
    if _time.time() - _history_cache_built_at > HISTORY_TTL_S or not _history_cache:
        _history_cache = _build_history(store, log_fn)
        _history_cache_built_at = _time.time()
    return _history_cache


def _estimate_runtime(job, history: dict[tuple[str, str], float]) -> float:
    """Per-job runtime estimate in seconds. Order: explicit field on the
    job, then exact (model, task) history mean, then per-model average,
    then global average, then DEFAULT_RUNTIME_S."""
    explicit = getattr(job, "runtime_seconds_estimate", 0) or 0
    if explicit > 0:
        return float(explicit)
    model, task = _extract_model_task(getattr(job, "command", "") or "")
    if model and task and (model, task) in history:
        return history[(model, task)]
    if model:
        same_model = [v for (m, _t), v in history.items() if m == model]
        if same_model:
            return sum(same_model) / len(same_model)
    if history:
        all_vals = list(history.values())
        return sum(all_vals) / len(all_vals)
    return float(DEFAULT_RUNTIME_S)


def _live_agents(store: JobStorage, now: dt.datetime) -> dict[str, dict]:
    bucket = getattr(store, "_sdk_bucket", None)
    if bucket is None:
        return {}
    agents: dict[str, dict] = {}
    for blob in bucket.list_blobs(prefix="capacity/"):
        try:
            doc = json.loads(blob.download_as_text())
        except Exception:
            continue
        cid = doc.get("consumer_id") or ""
        pub = doc.get("published_at") or ""
        try:
            age = (now - dt.datetime.fromisoformat(pub.replace("Z", "+00:00"))).total_seconds()
        except Exception:
            continue
        if age > HEARTBEAT_TTL_S:
            continue
        agents[cid] = {
            "total_vram_gb": int(doc.get("total_vram_gb") or 0),
            "active_slots": [],  # list of (finish_offset_seconds, vram_gb)
        }
    return agents


def _seed_running_jobs(store: JobStorage, agents: dict[str, dict],
                       now: dt.datetime, history: dict) -> None:
    """For each running/ blob, locate the executing agent (by hostname
    in instance_ref) and add an active_slot covering its remaining
    runtime. Without this, a freshly-claimed long job looks invisible
    and the matcher would pile more work onto an already-loaded agent.
    """
    bucket = getattr(store, "_sdk_bucket", None)
    if bucket is None:
        return
    # Map every live agent's hostname to its consumer_id.
    host_to_cid: dict[str, str] = {}
    for cid in agents:
        # consumer_id format is "<kind>-<hostname>"; the hostname is
        # everything after the first '-'. Capacity-broadcast keys use
        # the same convention (see queue/capacity.py: publish_capacity
        # writes "consumer_id": f"{kind}-{hostname}").
        parts = cid.split("-", 1)
        if len(parts) == 2:
            host_to_cid[parts[1]] = cid
    for blob in bucket.list_blobs(prefix="running/"):
        try:
            doc = json.loads(blob.download_as_text())
        except Exception:
            continue
        iref = doc.get("instance_ref") or ""
        m = _INSTANCE_HOST_RE.match(iref)
        if not m:
            continue
        host = m.group(1)
        cid = host_to_cid.get(host)
        if cid is None:
            continue
        st = doc.get("started_at") or ""
        try:
            elapsed = (now - dt.datetime.fromisoformat(st.replace("Z", "+00:00"))).total_seconds()
        except Exception:
            elapsed = 0.0
        # Build a Job-like shim so _estimate_runtime works on raw dict.
        class _Shim:
            command = doc.get("command", "")
            runtime_seconds_estimate = doc.get("runtime_seconds_estimate", 0)
        est = _estimate_runtime(_Shim(), history)
        remaining = max(0.0, est - max(0.0, elapsed))
        vram = int(doc.get("gpu_mem_gb") or 0)
        agents[cid]["active_slots"].append((remaining, vram))


def _earliest_start(slots: list, new_vram: int, total_vram: int) -> float:
    """Earliest start time (seconds from now) at which new_vram GB
    becomes free on an agent with the given total VRAM and active slots
    [(finish_offset_seconds, vram_gb), ...]."""
    used_now = sum(v for _, v in slots)
    available_now = total_vram - used_now
    if available_now >= new_vram:
        return 0.0
    by_end = sorted(slots, key=lambda s: s[0])
    freed = available_now
    for end_time, vram in by_end:
        freed += vram
        if freed >= new_vram:
            return float(end_time)
    return float(by_end[-1][0]) if by_end else 0.0


def _assign_one(job, agents: dict[str, dict], runtime: float, vram: int) -> Optional[str]:
    """Pick the eligible agent that finishes this job earliest; update
    its active_slots in place. Returns the chosen consumer_id, or None
    if no agent has enough total VRAM to host the job."""
    best_cid: Optional[str] = None
    best_finish: Optional[float] = None
    for cid, info in agents.items():
        if info["total_vram_gb"] < vram:
            continue
        start = _earliest_start(info["active_slots"], vram, info["total_vram_gb"])
        finish = start + runtime
        if best_finish is None or finish < best_finish:
            best_finish = finish
            best_cid = cid
    if best_cid is None or best_finish is None:
        return None
    agents[best_cid]["active_slots"].append((best_finish, vram))
    return best_cid


def assign_jobs(store: JobStorage, log_fn: Optional[Callable[[str], None]] = None) -> int:
    """One pass of makespan-minimizing assignment. Returns the number of
    queue blobs whose assigned_to changed this tick."""
    if log_fn is None:
        log_fn = lambda _msg: None  # noqa: E731
    now = dt.datetime.now(dt.timezone.utc)
    history = _history(store, log_fn)
    agents = _live_agents(store, now)
    if not agents:
        return 0
    _seed_running_jobs(store, agents, now, history)
    queued = list(store.list_jobs("queue"))
    enriched = [
        (-int(getattr(j, "priority", 0) or 0),
         -_estimate_runtime(j, history),
         j)
        for j in queued
    ]
    enriched.sort(key=lambda t: (t[0], t[1]))
    rewritten = 0
    for _p, _r, job in enriched:
        vram = int(getattr(job, "gpu_mem_gb", 0) or 0)
        runtime = _estimate_runtime(job, history)
        chosen = _assign_one(job, agents, runtime, vram)
        if chosen is None:
            continue
        if getattr(job, "assigned_to", "") == chosen:
            continue
        try:
            job.assigned_to = chosen
            store.write_job("queue", job)
            rewritten += 1
        except Exception as exc:
            log_fn(f"makespan: write_job failed for {getattr(job, 'job_id', '?')}: {exc!r}")
    return rewritten
