"""FastMCP server entry point and CLI."""

from __future__ import annotations

import argparse
import sys

import ytmusicapi
from mcp.server.fastmcp import FastMCP

from . import __version__
from .tools import register_all


def build_app() -> FastMCP:
    app = FastMCP("yt-music-mcp")
    register_all(app)
    return app


def _cmd_run(_args: argparse.Namespace) -> int:
    app = build_app()
    app.run()
    return 0


def _cmd_setup_auth(args: argparse.Namespace) -> int:
    """Interactive browser-header auth.

    Prompts for request headers copied from music.youtube.com's DevTools,
    then either writes ``browser.json`` or prints the JSON to stdout so
    the user can paste it into ``YTMUSIC_BROWSER_AUTH_JSON``.
    """
    print(
        "Paste the request headers copied from music.youtube.com "
        "(DevTools > Network > any POST to /youtubei/...), then Ctrl-D "
        "(Ctrl-Z + Enter on Windows).",
        file=sys.stderr,
    )
    if args.stdout:
        # setup() with no filepath returns the JSON string without writing.
        headers_json = ytmusicapi.setup()
        print(headers_json)
        print(
            "\nPaste the JSON above into your MCP client config as "
            "YTMUSIC_BROWSER_AUTH_JSON.",
            file=sys.stderr,
        )
    else:
        ytmusicapi.setup(filepath=args.out)
        print(f"Wrote {args.out}", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yt-music-mcp",
        description="MCP server for YouTube Music.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.set_defaults(func=_cmd_run)
    sub = parser.add_subparsers(dest="command")

    run = sub.add_parser("run", help="Run the MCP server over stdio (default).")
    run.set_defaults(func=_cmd_run)

    setup = sub.add_parser(
        "setup-auth",
        help="Interactive helper to capture YouTube Music auth headers.",
    )
    setup.add_argument(
        "--out",
        default="browser.json",
        help="Path to write the auth file (default: ./browser.json). "
        "Ignored when --stdout is set.",
    )
    setup.add_argument(
        "--stdout",
        action="store_true",
        help="Print the auth JSON to stdout instead of writing a file. "
        "Copy the output into YTMUSIC_BROWSER_AUTH_JSON in your MCP config.",
    )
    setup.set_defaults(func=_cmd_setup_auth)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
