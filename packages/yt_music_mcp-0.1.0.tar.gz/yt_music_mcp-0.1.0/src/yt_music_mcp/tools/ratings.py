"""Rating, subscription, and history-mutation tools.

All of these modify the user's account state and require authentication.
"""

from __future__ import annotations

from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from ..client import get_client


Rating = Literal["LIKE", "DISLIKE", "INDIFFERENT"]


def register(app: FastMCP) -> None:
    @app.tool()
    def rate_song(video_id: str, rating: Rating = "INDIFFERENT") -> dict[str, Any] | None:
        """Like, dislike, or clear the rating on a song. **Mutates.** Requires auth."""
        return get_client().rate_song(video_id, rating)

    @app.tool()
    def rate_playlist(playlist_id: str, rating: Rating = "INDIFFERENT") -> dict[str, Any]:
        """Like, dislike, or clear the rating on a playlist. **Mutates.** Requires auth."""
        return get_client().rate_playlist(playlist_id, rating)

    @app.tool()
    def subscribe_artists(channel_ids: list[str]) -> dict[str, Any]:
        """Subscribe to one or more artists. **Mutates.** Requires auth."""
        return get_client().subscribe_artists(channel_ids)

    @app.tool()
    def unsubscribe_artists(channel_ids: list[str]) -> dict[str, Any]:
        """Unsubscribe from one or more artists. **Mutates.** Requires auth."""
        return get_client().unsubscribe_artists(channel_ids)

    @app.tool()
    def add_history_item(song: dict[str, Any]) -> dict[str, Any]:
        """Record a play in the user's history. Pass a song dict from ``get_song``.
        **Mutates.** Requires auth.
        """
        return get_client().add_history_item(song)

    @app.tool()
    def remove_history_items(feedback_tokens: list[str]) -> dict[str, Any]:
        """Remove items from history by their feedback tokens (from ``get_history``).
        **Mutates.** Requires auth.
        """
        return get_client().remove_history_items(feedback_tokens)

    @app.tool()
    def edit_song_library_status(feedback_tokens: list[str]) -> dict[str, Any]:
        """Toggle songs' library status (add/remove from library).

        Pass feedback tokens from ``get_album`` or ``get_song``. **Mutates.** Requires auth.
        """
        return get_client().edit_song_library_status(feedback_tokens)
