"""Search tools."""

from __future__ import annotations

from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from ..client import get_client


SearchFilter = Literal[
    "songs",
    "videos",
    "albums",
    "artists",
    "playlists",
    "community_playlists",
    "featured_playlists",
    "uploads",
]

SearchScope = Literal["library", "uploads"]


def register(app: FastMCP) -> None:
    @app.tool()
    def search(
        query: str,
        filter: SearchFilter | None = None,
        scope: SearchScope | None = None,
        limit: int = 20,
        ignore_spelling: bool = False,
    ) -> list[dict[str, Any]]:
        """Search YouTube Music.

        Args:
            query: The search query.
            filter: Restrict results to one category (songs, albums, artists, ...).
            scope: "library" or "uploads" to search within the user's own content
                (requires authentication).
            limit: Minimum number of results to return (actual count may be higher).
            ignore_spelling: If True, disables spelling suggestions.
        """
        return get_client().search(
            query,
            filter=filter,
            scope=scope,
            limit=limit,
            ignore_spelling=ignore_spelling,
        )

    @app.tool()
    def get_search_suggestions(query: str) -> list[str]:
        """Return autocomplete suggestions for a partial search query."""
        return get_client().get_search_suggestions(query)
