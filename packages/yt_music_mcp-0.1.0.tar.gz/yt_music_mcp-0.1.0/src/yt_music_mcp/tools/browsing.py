"""Browsing tools: artists, albums, songs, lyrics, users, watch playlists."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from ..client import get_client


def register(app: FastMCP) -> None:
    @app.tool()
    def get_artist(channel_id: str) -> dict[str, Any]:
        """Get artist details: name, description, top songs, albums, singles, videos.

        Args:
            channel_id: YouTube Music channel ID (often starts with "UC").
        """
        return get_client().get_artist(channel_id)

    @app.tool()
    def get_artist_albums(
        channel_id: str,
        params: str,
        limit: int | None = 100,
        order: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get the full list of an artist's albums/singles.

        The ``params`` token comes from ``get_artist()`` under
        ``albums.params`` or ``singles.params``.

        Args:
            channel_id: Artist channel ID.
            params: Params token from get_artist output.
            limit: Max number of albums to return.
            order: Sort order — "Recency", "Popularity", or "Alphabetical order".
        """
        return get_client().get_artist_albums(channel_id, params, limit=limit, order=order)

    @app.tool()
    def get_album(browse_id: str) -> dict[str, Any]:
        """Get album details and track list. ``browse_id`` typically starts with "MPRE"."""
        return get_client().get_album(browse_id)

    @app.tool()
    def get_album_browse_id(audio_playlist_id: str) -> str | None:
        """Convert an OLAK5uy_... album playlist ID to its MPRE browse ID."""
        return get_client().get_album_browse_id(audio_playlist_id)

    @app.tool()
    def get_song(video_id: str) -> dict[str, Any]:
        """Get metadata for a single song/video by its videoId."""
        return get_client().get_song(video_id)

    @app.tool()
    def get_song_related(browse_id: str) -> list[dict[str, Any]]:
        """Get related content for a song. ``browse_id`` comes from ``get_watch_playlist``."""
        return get_client().get_song_related(browse_id)

    @app.tool()
    def get_lyrics(browse_id: str, timestamps: bool = False) -> dict[str, Any] | None:
        """Get lyrics for a song.

        Args:
            browse_id: Lyrics browse ID from ``get_watch_playlist(video_id).lyrics``.
            timestamps: If True and available, returns timed lyrics.
        """
        result = get_client().get_lyrics(browse_id, timestamps=timestamps)
        if result is None:
            return None
        # Lyrics / TimedLyrics are dataclasses; fall back to dict if already a mapping.
        if hasattr(result, "__dict__"):
            return dict(result.__dict__)
        return result  # type: ignore[return-value]

    @app.tool()
    def get_watch_playlist(
        video_id: str | None = None,
        playlist_id: str | None = None,
        limit: int = 25,
        radio: bool = False,
        shuffle: bool = False,
    ) -> dict[str, Any]:
        """Get a watch queue (up-next list) seeded from a video or playlist.

        Supply either ``video_id`` or ``playlist_id``. Returns tracks plus a
        ``lyrics`` browse ID to feed into ``get_lyrics``.
        """
        return get_client().get_watch_playlist(
            videoId=video_id,
            playlistId=playlist_id,
            limit=limit,
            radio=radio,
            shuffle=shuffle,
        )

    @app.tool()
    def get_user(channel_id: str) -> dict[str, Any]:
        """Get a user/channel's profile page."""
        return get_client().get_user(channel_id)

    @app.tool()
    def get_user_playlists(channel_id: str, params: str) -> list[dict[str, Any]]:
        """Get all playlists for a user. ``params`` comes from ``get_user()``."""
        return get_client().get_user_playlists(channel_id, params)

    @app.tool()
    def get_user_videos(channel_id: str, params: str) -> list[dict[str, Any]]:
        """Get all videos for a user. ``params`` comes from ``get_user()``."""
        return get_client().get_user_videos(channel_id, params)
