"""Tool modules registered on the FastMCP app.

Each submodule exposes a ``register(app)`` that adds its tools to the server.
"""

from mcp.server.fastmcp import FastMCP

from . import browsing, explore, library, playlists, ratings, search


def register_all(app: FastMCP) -> None:
    """Register every tool module on the given FastMCP app."""
    search.register(app)
    browsing.register(app)
    explore.register(app)
    library.register(app)
    playlists.register(app)
    ratings.register(app)


__all__ = ["register_all"]
