"""Playlist read & mutation tools.

Mutations (create, edit, delete, add/remove items) are always enabled.
These permanently change the user's YouTube Music library — use deliberately.
"""

from __future__ import annotations

from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from ..client import get_client


Privacy = Literal["PRIVATE", "PUBLIC", "UNLISTED"]


def register(app: FastMCP) -> None:
    @app.tool()
    def get_playlist(
        playlist_id: str,
        limit: int | None = 100,
        related: bool = False,
        suggestions_limit: int = 0,
    ) -> dict[str, Any]:
        """Get a playlist's metadata and tracks.

        Args:
            playlist_id: Playlist ID (often starts with "PL" or "RD").
            limit: Max number of tracks to return (None for all).
            related: If True, include related playlists (requires auth).
            suggestions_limit: Number of track suggestions to include (requires auth).
        """
        return get_client().get_playlist(
            playlist_id,
            limit=limit,
            related=related,
            suggestions_limit=suggestions_limit,
        )

    @app.tool()
    def create_playlist(
        title: str,
        description: str = "",
        privacy_status: Privacy = "PRIVATE",
        video_ids: list[str] | None = None,
        source_playlist: str | None = None,
    ) -> str | dict[str, Any]:
        """Create a new playlist. **Mutates the user's library.** Requires auth.

        Args:
            title: Playlist title.
            description: Playlist description.
            privacy_status: "PRIVATE", "PUBLIC", or "UNLISTED".
            video_ids: Initial list of video IDs to add.
            source_playlist: If set, copy tracks from this playlist ID.

        Returns:
            The new playlist's ID (on success).
        """
        return get_client().create_playlist(
            title,
            description,
            privacy_status=privacy_status,
            video_ids=video_ids,
            source_playlist=source_playlist,
        )

    @app.tool()
    def edit_playlist(
        playlist_id: str,
        title: str | None = None,
        description: str | None = None,
        privacy_status: Privacy | None = None,
        move_item: str | tuple[str, str] | None = None,
        add_playlist_id: str | None = None,
        add_to_top: bool | None = None,
    ) -> str | dict[str, Any]:
        """Edit a playlist's metadata or reorder tracks. **Mutates.** Requires auth.

        Args:
            playlist_id: Playlist to edit.
            title: New title.
            description: New description.
            privacy_status: New privacy.
            move_item: Either a setVideoId to move, or a (setVideoId, toPreceding) tuple.
            add_playlist_id: Append all tracks from this playlist.
            add_to_top: If True (with add_playlist_id), add to the top.
        """
        return get_client().edit_playlist(
            playlist_id,
            title=title,
            description=description,
            privacyStatus=privacy_status,
            moveItem=move_item,
            addPlaylistId=add_playlist_id,
            addToTop=add_to_top,
        )

    @app.tool()
    def delete_playlist(playlist_id: str) -> str | dict[str, Any]:
        """Permanently delete a playlist. **Destructive.** Requires auth."""
        return get_client().delete_playlist(playlist_id)

    @app.tool()
    def add_playlist_items(
        playlist_id: str,
        video_ids: list[str] | None = None,
        source_playlist: str | None = None,
        duplicates: bool = False,
    ) -> str | dict[str, Any]:
        """Add tracks to a playlist. **Mutates.** Requires auth.

        Args:
            playlist_id: Target playlist.
            video_ids: Videos to add.
            source_playlist: Alternatively, copy tracks from this playlist.
            duplicates: If True, allow adding tracks already present.
        """
        return get_client().add_playlist_items(
            playlist_id,
            videoIds=video_ids,
            source_playlist=source_playlist,
            duplicates=duplicates,
        )

    @app.tool()
    def remove_playlist_items(
        playlist_id: str,
        videos: list[dict[str, Any]],
    ) -> str | dict[str, Any]:
        """Remove tracks from a playlist. **Mutates.** Requires auth.

        Args:
            playlist_id: Target playlist.
            videos: List of track dicts — each must contain ``videoId`` and
                ``setVideoId`` as returned by ``get_playlist``.
        """
        return get_client().remove_playlist_items(playlist_id, videos)
