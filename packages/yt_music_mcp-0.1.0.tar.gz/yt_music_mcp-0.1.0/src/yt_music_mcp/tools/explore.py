"""Explore tools: home feed, charts, moods."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from ..client import get_client


def register(app: FastMCP) -> None:
    @app.tool()
    def get_home(limit: int = 3) -> list[dict[str, Any]]:
        """Get the YouTube Music home feed (mixes, recommended playlists, etc.)."""
        return get_client().get_home(limit=limit)

    @app.tool()
    def get_charts(country: str = "ZZ") -> dict[str, Any]:
        """Get top charts.

        Args:
            country: ISO 3166-1 alpha-2 code, or "ZZ" for global.
        """
        return get_client().get_charts(country=country)

    @app.tool()
    def get_mood_categories() -> dict[str, Any]:
        """List mood & genre categories. Use a category's ``params`` with get_mood_playlists."""
        return get_client().get_mood_categories()

    @app.tool()
    def get_mood_playlists(params: str) -> list[dict[str, Any]]:
        """Get playlists for a mood/genre category (params token from get_mood_categories)."""
        return get_client().get_mood_playlists(params)

    @app.tool()
    def get_explore() -> dict[str, Any]:
        """Get the Explore page: new albums, trending, etc."""
        return get_client().get_explore()
