"""Library read tools. All require authentication."""

from __future__ import annotations

from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from ..client import get_client


LibraryOrder = Literal["a_to_z", "z_to_a", "recently_added"]


def register(app: FastMCP) -> None:
    @app.tool()
    def get_library_playlists(limit: int | None = 25) -> list[dict[str, Any]]:
        """Get playlists the user has created or saved. Requires auth."""
        return get_client().get_library_playlists(limit=limit)

    @app.tool()
    def get_library_songs(
        limit: int = 25,
        order: LibraryOrder | None = None,
    ) -> list[dict[str, Any]]:
        """Get songs in the user's library. Requires auth."""
        return get_client().get_library_songs(limit=limit, order=order)

    @app.tool()
    def get_library_albums(
        limit: int = 25,
        order: LibraryOrder | None = None,
    ) -> list[dict[str, Any]]:
        """Get albums in the user's library. Requires auth."""
        return get_client().get_library_albums(limit=limit, order=order)

    @app.tool()
    def get_library_artists(
        limit: int = 25,
        order: LibraryOrder | None = None,
    ) -> list[dict[str, Any]]:
        """Get artists with songs in the user's library. Requires auth."""
        return get_client().get_library_artists(limit=limit, order=order)

    @app.tool()
    def get_library_subscriptions(
        limit: int = 25,
        order: LibraryOrder | None = None,
    ) -> list[dict[str, Any]]:
        """Get artists the user has subscribed to. Requires auth."""
        return get_client().get_library_subscriptions(limit=limit, order=order)

    @app.tool()
    def get_liked_songs(limit: int = 100) -> dict[str, Any]:
        """Get the user's liked songs playlist. Requires auth."""
        return get_client().get_liked_songs(limit=limit)

    @app.tool()
    def get_history() -> list[dict[str, Any]]:
        """Get the user's recent play history. Requires auth."""
        return get_client().get_history()

    @app.tool()
    def get_account_info() -> dict[str, Any]:
        """Get the authenticated account's display name, channel handle, and photo."""
        return get_client().get_account_info()
