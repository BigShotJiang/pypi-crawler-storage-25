"""Lazy singleton wrapping the ytmusicapi YTMusic client.

Auth resolution order:

1. ``YTMUSIC_BROWSER_AUTH_JSON`` — the full auth JSON as a string. Useful when
   you want to keep credentials inline in a Claude/Cursor config and avoid a
   file on disk.
2. ``YTMUSIC_BROWSER_AUTH`` — a path to a ``browser.json`` produced by
   ``yt-music-mcp setup-auth``.
3. Neither set — runs unauthenticated; search and browsing still work, but
   library/playlist tools will raise at call time.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from ytmusicapi import YTMusic


AUTH_ENV_PATH = "YTMUSIC_BROWSER_AUTH"
AUTH_ENV_JSON = "YTMUSIC_BROWSER_AUTH_JSON"


@lru_cache(maxsize=1)
def get_client() -> YTMusic:
    """Return a cached YTMusic instance, built from the configured auth."""
    inline_json = os.environ.get(AUTH_ENV_JSON)
    if inline_json:
        return YTMusic(inline_json)

    auth_path = os.environ.get(AUTH_ENV_PATH)
    if not auth_path:
        return YTMusic()

    try:
        return YTMusic(str(Path(auth_path).expanduser()))
    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"{AUTH_ENV_PATH}={auth_path!r} does not point to a readable file. "
            "Run `yt-music-mcp setup-auth` to generate browser.json, or set "
            f"{AUTH_ENV_JSON} to the JSON contents directly."
        ) from e
