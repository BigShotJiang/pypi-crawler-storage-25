"""MCP server exposing YouTube Music via ytmusicapi."""

__version__ = "0.1.0"
