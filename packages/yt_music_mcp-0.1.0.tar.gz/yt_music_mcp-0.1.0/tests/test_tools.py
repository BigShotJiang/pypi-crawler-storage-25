"""Smoke tests for tool registration.

These tests avoid FastMCP internals and only check that:
  * the server builds without error
  * every tool module registers at least the expected number of tools
  * invoking the underlying ytmusicapi client from a tool module forwards args

Real behaviour of each tool is covered indirectly: we mock the ytmusicapi
client and then invoke the tool modules' registration on a real FastMCP
instance. If the import or registration signatures drift, these tests fail.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest
from mcp.server.fastmcp import FastMCP

from yt_music_mcp import client as client_mod
from yt_music_mcp.server import build_app
from yt_music_mcp.tools import (
    browsing,
    explore,
    library,
    playlists,
    ratings,
    search,
)


@pytest.fixture
def fake_ytmusic(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    fake = MagicMock(name="YTMusic")
    client_mod.get_client.cache_clear()
    for mod in (client_mod, search, browsing, explore, library, playlists, ratings):
        monkeypatch.setattr(mod, "get_client", lambda: fake)
    return fake


def test_build_app_succeeds(fake_ytmusic: MagicMock) -> None:
    app = build_app()
    assert app.name == "yt-music-mcp"


@pytest.mark.parametrize(
    "module,min_tools",
    [
        (search, 2),
        (browsing, 10),
        (explore, 5),
        (library, 8),
        (playlists, 6),
        (ratings, 7),
    ],
)
def test_module_registers_tools(
    fake_ytmusic: MagicMock, module, min_tools: int
) -> None:
    app = FastMCP("test")
    module.register(app)
    tools = asyncio.run(app.list_tools())
    assert len(tools) >= min_tools
