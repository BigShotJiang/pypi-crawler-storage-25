# SWEbench Benchmark

SWE-bench evaluates AI coding agents on real-world GitHub issues from popular Python repositories.

## How it works

Each instance contains:
- A **problem statement** (GitHub issue text)
- A **repository** checked out at the commit just before the fix
- **Test directives** that should pass after the agent's fix is applied

## Container contract

- `$PROBLEM_STATEMENT` — the GitHub issue text
- `$WORKING_DIR` — repo checked out at the pre-fix commit (`/repo`)
- `$OUTPUT_DIR` — agent writes `patch.diff` here (`/output`)
- `$METADATA_FILE` — JSON with `repo`, `base_commit`, `gold_patch_path`, `test_directives`
- `$INSTANCE_ID` — unique instance identifier

## Scoring

The agent's patch is applied with `git apply`. The test directives are run with pytest. If all tests pass, `resolved: true`.

## Building images

```bash
python benchmarks/swebench/prepare_metadata.py
python scripts/build_images.py --benchmark swebench
```
