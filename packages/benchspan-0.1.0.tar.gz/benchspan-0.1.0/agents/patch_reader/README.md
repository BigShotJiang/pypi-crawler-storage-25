# Patch Reader Agent

Cheating agent that reads the gold patch from benchmark metadata and applies it directly.

Expected result: ~95-100% resolve rate. Use this to verify that scoring is working correctly end-to-end.
