#!/bin/bash
# BenchSpan agent: Claude Code
# Env: ANTHROPIC_API_KEY, BENCHSPAN_MODEL (optional), BENCHSPAN_MAX_TURNS (optional)

set -uo pipefail

# ── Install system deps if missing (curl, xz-utils needed for Node.js tarball) ──
(which curl >/dev/null 2>&1 && which xz >/dev/null 2>&1) || \
  (apt-get update -qq && apt-get install -y -qq curl xz-utils) >/dev/null 2>&1 || true

# ── Install Node.js (binary tarball — fast) ──
curl -fsSL https://nodejs.org/dist/v22.14.0/node-v22.14.0-linux-x64.tar.xz \
  | tar -xJ -C /usr/local --strip-components=1

# ── Install Claude Code (install noise to stderr, keep stdout clean) ──
/usr/local/bin/npm install -g @anthropic-ai/claude-code 2>&1 | tail -5 >&2

# ── Create non-root user (claude refuses --dangerously-skip-permissions as root) ──
useradd -m -s /bin/bash benchspan 2>/dev/null || true
chown -R benchspan:benchspan "$OUTPUT_DIR" 2>/dev/null || true
chmod -R 777 "$WORKING_DIR" 2>/dev/null || true

# ── Configurable via env vars (set on BenchSpan dashboard or --env file) ──
export BENCHSPAN_MODEL="${BENCHSPAN_MODEL:-claude-haiku-4-5-20251001}"
export BENCHSPAN_MAX_TURNS="${BENCHSPAN_MAX_TURNS:-30}"

# ── Write a run script to avoid quoting hell with su -c ──
cat > /tmp/run_claude.sh << 'RUNEOF'
#!/bin/bash
cd "$WORKING_DIR"
export HOME=/home/benchspan
/usr/local/bin/claude -p "$PROBLEM_STATEMENT" \
  --bare \
  --dangerously-skip-permissions \
  --model "$BENCHSPAN_MODEL" \
  --output-format stream-json \
  --verbose \
  --max-turns "$BENCHSPAN_MAX_TURNS" \
  2>"$OUTPUT_DIR/agent_stderr.log" | tee "$OUTPUT_DIR/claude_output.jsonl"
RUNEOF
chmod +x /tmp/run_claude.sh

# ── Run as non-root ──
su benchspan -p -c "bash /tmp/run_claude.sh"

# ── Extract telemetry from stream-json ──
python3 -c "
import json, os

messages = []
result = None
with open('$OUTPUT_DIR/claude_output.jsonl') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get('type') == 'result':
            result = obj
        elif obj.get('type') == 'assistant':
            messages.append(obj)

steps = []
step_num = 0
for msg in messages:
    for block in msg.get('message', {}).get('content', []):
        if block.get('type') == 'tool_use':
            step_num += 1
            steps.append({
                'step': step_num,
                'type': 'tool_call',
                'tool': block.get('name', ''),
                'input': block.get('input', {}),
            })

usage = result.get('usage', {}) if result else {}
traj = {
    'schema_version': '1.0',
    'instance_id': '$INSTANCE_ID',
    'model': os.environ.get('BENCHSPAN_MODEL', 'claude-haiku-4-5-20251001'),
    'total_tokens': (usage.get('input_tokens', 0) or 0) + (usage.get('output_tokens', 0) or 0),
    'prompt_tokens': usage.get('input_tokens', 0) or 0,
    'completion_tokens': usage.get('output_tokens', 0) or 0,
    'total_latency_ms': result.get('duration_ms', 0) if result else 0,
    'cache_read_tokens': usage.get('cache_read_input_tokens', 0) or 0,
    'cache_write_tokens': usage.get('cache_creation_input_tokens', 0) or 0,
    'steps': steps,
}
json.dump(traj, open('$OUTPUT_DIR/trajectory.json', 'w'), indent=2)
" 2>/dev/null
