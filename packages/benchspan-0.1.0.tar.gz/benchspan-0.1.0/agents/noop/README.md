# No-Op Agent

Does nothing. Writes an empty trajectory. Expected result: 0% resolve rate.

Use this to verify that the benchmark plumbing works end-to-end.
