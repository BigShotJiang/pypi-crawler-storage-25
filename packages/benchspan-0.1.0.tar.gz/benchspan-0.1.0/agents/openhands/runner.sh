#!/bin/bash
# BenchSpan agent: OpenHands
# Env: LLM_API_KEY, LLM_MODEL, BENCHSPAN_MAX_TURNS (optional)

set -uo pipefail

# ── Install system deps ──
(which curl >/dev/null 2>&1 && which git >/dev/null 2>&1) || \
  (apt-get update -qq && apt-get install -y -qq curl git) >/dev/null 2>&1 || true

# ── Install OpenHands ──
curl -fsSL https://install.openhands.dev/install.sh | sh >/dev/null 2>&1
export PATH="$HOME/.local/bin:$PATH"

# ── Point OpenHands at the benchmark working directory ──
export OPENHANDS_WORK_DIR="$WORKING_DIR"

# ── Run in headless mode ──
cd "$WORKING_DIR"
openhands \
  --headless \
  --override-with-envs \
  -t "$PROBLEM_STATEMENT" \
  2>"$OUTPUT_DIR/agent_stderr.log" | tee "$OUTPUT_DIR/openhands_output.log"
