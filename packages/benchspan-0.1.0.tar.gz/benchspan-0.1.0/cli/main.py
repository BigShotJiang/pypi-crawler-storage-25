"""BenchSpan CLI — run agentic benchmarks end-to-end."""

from __future__ import annotations

import warnings
warnings.filterwarnings("ignore")

import json
import os
import time
from io import BytesIO
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.live import Live
from rich.table import Table

app = typer.Typer(
    help="BenchSpan — run agentic benchmarks end-to-end.",
    invoke_without_command=True,
    no_args_is_help=True,
    add_completion=False,
)
runs_app = typer.Typer(help="Inspect past benchmark runs.", no_args_is_help=True)
app.add_typer(runs_app, name="runs")
benchmarks_app = typer.Typer(help="List and manage benchmarks.", no_args_is_help=True)
app.add_typer(benchmarks_app, name="benchmarks")

console = Console()

BACKEND_HELP = "Backend mode: 'prod' (remote API, default) or 'local' (Docker on this machine)"

# Built-in agents directory (shipped with the CLI)
# Built-in agents: check package dir first (pip install), then dev dir (editable install)
_PACKAGE_AGENTS_DIR = Path(__file__).resolve().parent / "agents"
_DEV_AGENTS_DIR = Path(__file__).resolve().parent.parent / "agents"
_BUILTIN_AGENTS_DIR = _PACKAGE_AGENTS_DIR if _PACKAGE_AGENTS_DIR.exists() else _DEV_AGENTS_DIR


def _parse_agent_env_vars(runner_sh: Path) -> tuple[list[str], list[str]]:
    """Parse required and optional env vars from runner.sh '# Env:' line.

    Returns (required, optional) lists.
    """
    required, optional = [], []
    for line in runner_sh.read_text().splitlines():
        if line.startswith("# Env:"):
            for part in line.split(":", 1)[1].split(","):
                part = part.strip()
                if not part:
                    continue
                if "(optional)" in part:
                    optional.append(part.replace("(optional)", "").strip())
                else:
                    required.append(part)
            break
    return required, optional


def _check_required_env_vars(agent_path: Path, backend: str) -> None:
    """Error if required env vars for a built-in agent are not set on the dashboard.

    Only checks for prod backend (customers). Local backend skips since
    env vars are passed directly via the shell.
    """
    if backend == "local":
        return

    runner_sh = agent_path / "runner.sh"
    required, _ = _parse_agent_env_vars(runner_sh)
    if not required:
        return

    try:
        from cli.api_client import list_secret_names, get_token
        if not get_token():
            return  # not logged in, skip check
        dashboard_names = set(list_secret_names())
    except Exception:
        return  # can't reach API, skip silently

    missing = [v for v in required if v not in dashboard_names]
    if missing:
        console.print(
            f"[red]Error:[/red] agent requires env var(s) not found on your BenchSpan dashboard: "
            f"[bold]{', '.join(missing)}[/bold]"
        )
        console.print(
            "  Set them at [cyan]https://benchspan.com/dashboard/settings/profile[/cyan] before running."
        )
        raise typer.Exit(1)


def _resolve_agent(agent: str) -> Path | None:
    """Resolve an agent name or path to a directory containing runner.sh.

    Checks in order:
    1. If it's a path to a directory with runner.sh, use it directly
    2. If it matches a built-in agent name, use the bundled agent
    3. Otherwise, error
    """
    # Try as a path first
    agent_path = Path(agent).resolve()
    if (agent_path / "runner.sh").exists():
        return agent_path

    # Try as a built-in agent name
    builtin_path = _BUILTIN_AGENTS_DIR / agent
    if builtin_path.exists() and (builtin_path / "runner.sh").exists():
        return builtin_path

    # Nothing found — show helpful error
    if Path(agent).exists():
        console.print(f"[red]Error:[/red] {agent_path}/runner.sh not found")
    else:
        available = sorted(
            d.name for d in _BUILTIN_AGENTS_DIR.iterdir()
            if d.is_dir() and (d / "runner.sh").exists()
        ) if _BUILTIN_AGENTS_DIR.exists() else []
        console.print(f"[red]Error:[/red] '{agent}' is not a path or built-in agent name")
        if available:
            console.print(f"Available built-in agents: {', '.join(available)}")
    return None


@app.command()
def login(
    email: Optional[str] = typer.Option(None, help="Email for direct login (skip browser)"),
    password: Optional[str] = typer.Option(None, help="Password for direct login"),
    api_url: Optional[str] = typer.Option(None, help="Override API URL"),
) -> None:
    """Login to BenchSpan. Opens browser by default, or use --email/--password."""
    from cli.api_client import login as browser_login, login_with_credentials, _load_config, _save_config

    if api_url:
        config = _load_config()
        config["api_url"] = api_url
        _save_config(config)

    if email and password:
        login_with_credentials(email, password)
    else:
        browser_login()


@app.command()
def logout() -> None:
    """Clear saved credentials."""
    from cli.api_client import CONFIG_FILE
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        console.print("Logged out.")
    else:
        console.print("Not logged in.")


@app.command()
def whoami() -> None:
    """Show current login status."""
    from cli.api_client import _load_config
    config = _load_config()
    if config.get("token"):
        console.print(f"Logged in as [cyan]{config.get('email', 'unknown')}[/cyan]")
        console.print(f"API: {config.get('api_url', 'default')}")
    else:
        console.print("Not logged in. Run: benchspan login")


@app.command()
def run(
    benchmark: str = typer.Option(
        ...,
        help="Benchmark selector: 'swebench', 'swebench.django__django-11099', "
             "'swebench.django', 'swebench.id1,swebench.id2'",
    ),
    agent: str = typer.Option(..., help="Built-in agent name (e.g. 'claude-code') or path to agent directory"),
    instances: Optional[int] = typer.Option(None, help="Max number of instances to run"),
    tag: Optional[str] = typer.Option(None, help="Label stored with the run for filtering"),
    output: str = typer.Option("./runs", help="Where to write run artifacts", hidden=True),
    parallelism: int = typer.Option(5, help="Max concurrent containers (max 10)"),
    backend: str = typer.Option("prod", hidden=True),
    allow_solutions: bool = typer.Option(False, hidden=True),
) -> None:
    """Run a benchmark with the given agent."""
    if parallelism > 10:
        console.print(f"[red]Error:[/red] parallelism cannot exceed 10 (got {parallelism})")
        raise typer.Exit(1)

    if allow_solutions:
        os.environ["BENCHKIT_ALLOW_SOLUTIONS"] = "1"

    agent_path = _resolve_agent(agent)
    if agent_path is None:
        raise typer.Exit(1)

    _check_required_env_vars(agent_path, backend)

    if backend == "local":
        _run_local(benchmark, agent_path, instances, tag, output, parallelism)
    else:
        _run_prod(benchmark, agent_path, instances, tag, parallelism)


def _run_local(benchmark, agent_path, instances, tag, output, parallelism):
    """Run benchmark locally using Docker on this machine."""
    try:
        import asyncio
        from orchestrator.instance_selection import parse_benchmark_selector
        from orchestrator.runner import execute_run
    except ImportError:
        console.print("[red]Local mode is not available in this installation.[/red]")
        console.print("Use [cyan]benchspan run[/cyan] without --backend local to run via the BenchSpan API.")
        raise typer.Exit(1)

    try:
        benchmark_name, instance_ids, max_instances = parse_benchmark_selector(
            benchmark, max_instances=instances
        )
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    output_path = Path(output).resolve()
    output_path.mkdir(parents=True, exist_ok=True)

    run_id = f"run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"

    result = asyncio.run(
        execute_run(
            benchmark=benchmark_name,
            agent_path=agent_path,
            run_id=run_id,
            tag=tag,
            output_dir=output_path,
            max_instances=max_instances,
            instance_ids=instance_ids,
            parallelism=parallelism,
        )
    )

    _print_summary(result)


def _run_prod(benchmark, agent_path, instances, tag, parallelism):
    """Submit benchmark run to remote BenchSpan API."""
    from cli.api_client import create_agent_tar, submit_run

    # Show agent tar size before submitting
    tar_buf = create_agent_tar(agent_path)
    tar_size = len(tar_buf.read())
    tar_buf.seek(0)
    if tar_size > 1024 * 1024:
        size_str = f"{tar_size / 1024 / 1024:.1f} MB"
    else:
        size_str = f"{tar_size / 1024:.0f} KB"
    console.print(f"Agent package: [cyan]{size_str}[/cyan]")

    tags = [tag] if tag else []

    console.print(f"[bold]Submitting run...[/bold]")
    result = submit_run(benchmark, agent_path, instances, tags, parallelism)
    run_id = result["run_id"]

    console.print(f"  Run ID:    [cyan]{run_id}[/cyan]")
    console.print(f"  Benchmark: {result['benchmark']} ({result['instances_total']} instances)")
    console.print()

    _watch_run(run_id)


def _watch_run(run_id: str):
    """Poll and display progress for a run. Handles Ctrl+C gracefully."""
    from cli.api_client import poll_status, get_run

    try:
        with Live(_make_status_table({}, 0), console=console, refresh_per_second=1) as live:
            while True:
                time.sleep(3)
                status = poll_status(run_id)

                if not status:
                    continue  # transient error, retry next poll

                live.update(_make_status_table(status, status.get("instances_total", 0)))

                if status.get("status") in ("complete", "failed", "cancelled"):
                    break

    except KeyboardInterrupt:
        console.print()
        console.print(f"[yellow]Run continues in background.[/yellow]")
        console.print(f"  Resume:  benchspan runs watch [cyan]{run_id}[/cyan]")
        console.print(f"  Cancel:  benchspan runs cancel [cyan]{run_id}[/cyan]")
        return

    # Fetch final results
    run_data = get_run(run_id)
    _print_prod_summary(run_data)


def _retry_prod(run_id, agent_path, parallelism):
    """Retry failed instances from a previous run via the API."""
    from cli.api_client import get_run, get_failed_instances, submit_run, poll_status

    # Get the original run to find the benchmark
    run_data = get_run(run_id)
    if not run_data:
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)

    benchmark = run_data["benchmark"]

    # Get failed instance IDs
    failed_ids = get_failed_instances(run_id)
    if not failed_ids:
        console.print("[yellow]No failed instances to retry.[/yellow]")
        raise typer.Exit(0)

    console.print(f"[bold]Retrying {len(failed_ids)} failed instances from {run_id[:12]}...[/bold]")

    # Submit new run targeting just the failed instances
    result = submit_run(
        benchmark=benchmark,
        agent_path=agent_path,
        tags=[f"retry:{run_id[:12]}"],
        parallelism=parallelism,
        instance_ids=failed_ids,
    )
    new_run_id = result["run_id"]

    console.print(f"  Run ID:    [cyan]{new_run_id}[/cyan]")
    console.print(f"  Benchmark: {result['benchmark']} ({result['instances_total']} instances)")
    console.print()

    # Poll for progress
    with Live(_make_status_table({}, result["instances_total"]), console=console, refresh_per_second=1) as live:
        while True:
            time.sleep(3)
            status = poll_status(new_run_id)
            live.update(_make_status_table(status, status["instances_total"]))
            if status["status"] in ("complete", "failed"):
                break

    run_data = get_run(new_run_id)
    _print_prod_summary(run_data)


def _make_status_table(status: dict, total: int) -> Table:
    complete = status.get("instances_complete", 0)
    failed = status.get("instances_failed", 0)
    running = status.get("instances_running", 0)
    queued = status.get("instances_queued", 0)

    tbl = Table.grid(padding=(0, 2))
    parts = [
        f"[bold]{complete + failed}[/bold]/{total} done",
        f"[green]{complete} passed[/green]",
        f"[red]{failed} failed[/red]",
    ]
    if running > 0:
        parts.append(f"[yellow]{running} running[/yellow]")
    if queued > 0:
        parts.append(f"[dim]{queued} queued[/dim]")
    tbl.add_row(*parts)
    return tbl


@app.command()
def retry(
    run_id: str = typer.Argument(..., help="Run ID to retry"),
    agent: str = typer.Option(..., help="Path to agent directory"),
    failed: bool = typer.Option(True, help="Retry failed instances"),
    errored: bool = typer.Option(True, help="Retry errored instances"),
    output: str = typer.Option("./runs", help="Runs directory"),
    parallelism: int = typer.Option(5, help="Max concurrent containers (max 10)"),
    backend: str = typer.Option("prod", hidden=True),
) -> None:
    """Retry failed/errored instances from a previous run."""
    agent_path = _resolve_agent(agent)
    if agent_path is None:
        raise typer.Exit(1)

    if backend == "prod":
        _retry_prod(run_id, agent_path, parallelism)
        return

    import asyncio
    from orchestrator.runner import execute_run

    output_path = Path(output).resolve()
    manifest_path = output_path / run_id / "manifest.json"
    if not manifest_path.exists():
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)

    with open(manifest_path) as f:
        old_manifest = json.load(f)

    retry_ids = []
    run_dir = output_path / run_id
    for instance_dir in run_dir.iterdir():
        if not instance_dir.is_dir():
            continue
        score_path = instance_dir / "score.json"
        error_path = instance_dir / "error.json"
        if not score_path.exists():
            continue

        with open(score_path) as f:
            score = json.load(f)

        has_error = error_path.exists()
        resolved = score.get("resolved", False)

        if resolved:
            continue
        if has_error and errored:
            retry_ids.append(instance_dir.name)
        elif not has_error and failed:
            retry_ids.append(instance_dir.name)

    if not retry_ids:
        console.print("[yellow]No instances to retry.[/yellow]")
        raise typer.Exit(0)

    console.print(f"Retrying {len(retry_ids)} instances from {run_id}")

    new_run_id = f"run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"

    result = asyncio.run(
        execute_run(
            benchmark=old_manifest["benchmark"],
            agent_path=agent_path,
            run_id=new_run_id,
            tag=f"retry:{run_id}",
            output_dir=output_path,
            max_instances=None,
            instance_ids=retry_ids,
            parallelism=parallelism,
        )
    )

    _print_summary(result)


@app.command()
def agents() -> None:
    """List available built-in agents."""
    if not _BUILTIN_AGENTS_DIR.exists():
        console.print("[yellow]No built-in agents directory found.[/yellow]")
        raise typer.Exit(0)

    table = Table(title="Built-in Agents")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Env Vars")

    for agent_dir in sorted(_BUILTIN_AGENTS_DIR.iterdir()):
        if not agent_dir.is_dir() or not (agent_dir / "runner.sh").exists():
            continue
        desc = ""
        env_vars = ""
        for line in (agent_dir / "runner.sh").read_text().splitlines():
            if line.startswith("# Benchspan agent:") or line.startswith("# BenchSpan agent:"):
                desc = line.split(":", 1)[1].strip()
            elif line.startswith("# Env:"):
                env_vars = line.split(":", 1)[1].strip()
        table.add_row(agent_dir.name, desc, env_vars)

    console.print(table)
    console.print("\nUse with: benchspan run --benchmark <name> --agent <agent-name>")


@app.command()
def init(
    path: str = typer.Argument(..., help="Directory to create for the agent"),
) -> None:
    """Scaffold a new agent with a template runner.sh."""
    agent_dir = Path(path)
    if agent_dir.exists():
        console.print(f"[red]Error:[/red] {agent_dir} already exists")
        raise typer.Exit(1)

    agent_dir.mkdir(parents=True)

    runner_sh = agent_dir / "runner.sh"
    runner_sh.write_text(
        '#!/bin/bash\n'
        '# BenchSpan agent runner\n'
        '#\n'
        '# Available environment variables:\n'
        '#   $PROBLEM_STATEMENT  — what to solve (natural language)\n'
        '#   $WORKING_DIR        — where to do your work\n'
        '#   $OUTPUT_DIR         — where to write outputs\n'
        '#   $METADATA_FILE      — path to JSON with benchmark-specific data\n'
        '#   $INSTANCE_ID        — unique instance identifier\n'
        '#\n'
        '# Your agent should:\n'
        '#   1. Read $PROBLEM_STATEMENT\n'
        '#   2. Work in $WORKING_DIR\n'
        '#   3. Write outputs to $OUTPUT_DIR\n'
        '#   4. Optionally write $OUTPUT_DIR/trajectory.json for telemetry\n'
        '\n'
        'cd "$WORKING_DIR"\n'
        '\n'
        '# --- Replace this with your agent invocation ---\n'
        'echo "Problem: $PROBLEM_STATEMENT"\n'
        'echo "TODO: invoke your agent here"\n'
    )
    runner_sh.chmod(0o755)

    console.print(f"[green]Created agent at {agent_dir}[/green]")
    console.print(f"\nEdit {runner_sh} to invoke your agent, then run:")
    console.print(f"  benchspan run --benchmark swebench.django --agent {agent_dir} --instances 5")


@app.command()
def instances(
    benchmark: str = typer.Argument(..., help="Benchmark name (e.g. 'swebench')"),
) -> None:
    """List available instances and subsets for a benchmark."""
    from orchestrator.instance_selection import load_all_instance_ids, load_subsets

    all_ids = load_all_instance_ids(benchmark)
    if not all_ids:
        console.print(f"[red]No instances found for '{benchmark}'[/red]")
        raise typer.Exit(1)

    subsets = load_subsets(benchmark)

    console.print(f"[bold]{benchmark}[/bold]: {len(all_ids)} total instances\n")

    if subsets:
        table = Table(title="Named Subsets")
        table.add_column("Subset", style="cyan")
        table.add_column("Instances", justify="right")
        table.add_column("Selector", style="dim")
        for name in sorted(subsets, key=lambda k: -len(subsets[k])):
            table.add_row(name, str(len(subsets[name])), f"{benchmark}.{name}")
        console.print(table)

    console.print(f"\n[bold]Usage examples:[/bold]")
    console.print(f"  benchspan run --benchmark {benchmark} --agent ./my-agent")
    console.print(f"  benchspan run --benchmark {benchmark} --agent ./my-agent --instances 10")
    if subsets:
        first_subset = sorted(subsets, key=lambda k: -len(subsets[k]))[0]
        console.print(f"  benchspan run --benchmark {benchmark}.{first_subset} --agent ./my-agent")
    if all_ids:
        first_id = sorted(all_ids)[0]
        console.print(f"  benchspan run --benchmark {benchmark}.{first_id} --agent ./my-agent")


@app.command(hidden=True)
def dashboard(
    port: int = typer.Option(3456, help="Port to serve on"),
    output: str = typer.Option("./runs", help="Runs directory to visualize"),
) -> None:
    """Launch the BenchSpan dashboard UI."""
    import os
    import subprocess

    dashboard_dir = Path(__file__).parent.parent / "dashboard"
    if not (dashboard_dir / "package.json").exists():
        console.print(f"[red]Dashboard not found at {dashboard_dir}[/red]")
        raise typer.Exit(1)

    runs_dir = Path(output).resolve()
    env = {**os.environ, "RUNS_DIR": str(runs_dir)}

    console.print(f"[bold]Starting BenchSpan dashboard[/bold]")
    console.print(f"  Runs: {runs_dir}")
    console.print(f"  URL:  http://localhost:{port}")
    console.print()

    try:
        subprocess.run(
            ["npx", "next", "dev", "--port", str(port)],
            cwd=str(dashboard_dir),
            env=env,
        )
    except KeyboardInterrupt:
        console.print("\nDashboard stopped.")


# --- Runs subcommands ---


@runs_app.command("list")
def runs_list(
    output: str = typer.Option("./runs", help="Runs directory (local mode)"),
    backend: str = typer.Option("prod", hidden=True),
    benchmark: Optional[str] = typer.Option(None, help="Filter by benchmark"),
    tag: Optional[str] = typer.Option(None, help="Filter by tag"),
    all: bool = typer.Option(False, "--all", "-a", help="Show all team runs (default: your runs only)"),
    limit: int = typer.Option(50, help="Max number of runs to show"),
) -> None:
    """Show past runs (yours by default, --all for team)."""
    if backend == "prod":
        _runs_list_prod(benchmark, tag, mine=not all, limit=limit)
    else:
        _runs_list_local(output)


def _runs_list_prod(benchmark, tag, mine=True, limit=50):
    from cli.api_client import list_runs

    runs = list_runs(benchmark=benchmark, tag=tag, mine=mine, limit=limit)
    if not runs:
        label = "your" if mine else "any"
        console.print(f"[yellow]No runs found. Run [bold]benchspan run[/bold] to submit {label} first benchmark.[/yellow]")
        return

    title = "My Runs" if mine else "All Runs"
    table = Table(title=title)
    table.add_column("Run ID", style="cyan", no_wrap=True)
    table.add_column("Benchmark")
    table.add_column("Tags")
    table.add_column("Status")
    table.add_column("Resolved", justify="right")
    table.add_column("Rate", justify="right")
    table.add_column("Created")

    for r in runs:
        s = r.get("summary") or {}
        total = s.get("instances_total", 0)
        resolved = s.get("resolved", 0)
        rate = s.get("resolve_rate", 0)
        tags = ", ".join(r.get("tags", []))
        status_style = {"complete": "green", "running": "yellow", "failed": "red", "cancelled": "red"}.get(r["status"], "dim")

        table.add_row(
            r["run_id"],
            r["benchmark"],
            tags,
            f"[{status_style}]{r['status']}[/{status_style}]",
            f"{resolved}/{total}" if total else "-",
            f"{rate:.1%}" if total else "-",
            r.get("created_at", "")[:19],
        )

    console.print(table)


def _runs_list_local(output):
    runs_dir = Path(output).resolve()
    if not runs_dir.exists():
        console.print("[yellow]No runs found.[/yellow]")
        return

    manifests = []
    for manifest_path in sorted(runs_dir.glob("*/manifest.json")):
        with open(manifest_path) as f:
            manifests.append(json.load(f))

    if not manifests:
        console.print("[yellow]No runs found.[/yellow]")
        return

    table = Table(title="Benchmark Runs")
    table.add_column("Run ID", style="cyan")
    table.add_column("Benchmark")
    table.add_column("Agent")
    table.add_column("Tag")
    table.add_column("Instances")
    table.add_column("Resolved", justify="right")
    table.add_column("Rate", justify="right")
    table.add_column("Timestamp")

    for m in manifests:
        s = m.get("summary", {})
        table.add_row(
            m["run_id"],
            m["benchmark"],
            m["agent"],
            m.get("tag", ""),
            str(m["instances_total"]),
            f"{s.get('resolved', 0)}/{m['instances_completed']}",
            f"{s.get('resolve_rate', 0):.1%}",
            m.get("timestamp", ""),
        )

    console.print(table)


@runs_app.command("show")
def runs_show(
    run_id: str = typer.Argument(..., help="Run ID to inspect"),
    output: str = typer.Option("./runs", help="Runs directory (local mode)"),
    backend: str = typer.Option("prod", hidden=True),
) -> None:
    """Show scores and telemetry for a run."""
    if backend == "prod":
        _runs_show_prod(run_id)
    else:
        _runs_show_local(run_id, output)


def _runs_show_prod(run_id):
    from cli.api_client import get_run

    data = get_run(run_id)
    _print_prod_summary(data)

    console.print("\n[bold]Per-instance results:[/bold]")
    table = Table()
    table.add_column("Instance ID", style="cyan")
    table.add_column("Resolved", justify="center")
    table.add_column("Score", justify="right")
    table.add_column("Error")

    for inst in data.get("instances", []):
        score = inst.get("score_json") or {}
        table.add_row(
            inst["instance_id"],
            "[green]Yes[/green]" if score.get("resolved") else "[red]No[/red]",
            f"{score.get('score', 0):.1f}",
            (inst.get("error_message") or "")[:60],
        )

    console.print(table)


def _runs_show_local(run_id, output):
    manifest_path = Path(output).resolve() / run_id / "manifest.json"
    if not manifest_path.exists():
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)

    with open(manifest_path) as f:
        manifest = json.load(f)

    manifest["run_dir"] = str(manifest_path.parent)
    _print_summary(manifest)

    console.print("\n[bold]Per-instance results:[/bold]")
    table = Table()
    table.add_column("Instance ID", style="cyan")
    table.add_column("Resolved", justify="center")
    table.add_column("Score", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("Latency", justify="right")

    run_dir = manifest_path.parent
    for instance_dir in sorted(run_dir.iterdir()):
        score_path = instance_dir / "score.json"
        if not score_path.exists():
            continue
        with open(score_path) as f:
            score = json.load(f)

        tokens = ""
        latency = ""
        traj_path = instance_dir / "trajectory.json"
        if traj_path.exists():
            with open(traj_path) as f:
                traj = json.load(f)
            tokens = str(traj.get("total_tokens", ""))
            lat_ms = traj.get("total_latency_ms")
            if lat_ms is not None:
                latency = f"{lat_ms / 1000:.1f}s"

        table.add_row(
            score.get("instance_id", instance_dir.name),
            "[green]Yes[/green]" if score.get("resolved") else "[red]No[/red]",
            f"{score.get('score', 0):.1f}",
            tokens,
            latency,
        )

    console.print(table)


@runs_app.command("compare")
def runs_compare(
    run_a: str = typer.Argument(..., help="First run ID"),
    run_b: str = typer.Argument(..., help="Second run ID"),
    output: str = typer.Option("./runs", help="Runs directory (local mode)"),
    backend: str = typer.Option("prod", hidden=True),
) -> None:
    """Diff two runs side by side."""
    if backend == "prod":
        _runs_compare_prod(run_a, run_b)
    else:
        _runs_compare_local(run_a, run_b, output)


def _runs_compare_prod(run_a, run_b):
    from cli.api_client import compare_runs

    data = compare_runs(run_a, run_b)
    ra = data["run_a"]
    rb = data["run_b"]
    sa = ra.get("summary") or {}
    sb = rb.get("summary") or {}

    table = Table(title="Run Comparison")
    table.add_column("Metric")
    table.add_column(run_a[:12], justify="right", style="cyan")
    table.add_column(run_b[:12], justify="right", style="magenta")
    table.add_column("Delta", justify="right")

    def _row(label, key, fmt=".1f", pct=False):
        va = sa.get(key)
        vb = sb.get(key)
        sa_str = f"{va:{fmt}}" if va is not None else "-"
        sb_str = f"{vb:{fmt}}" if vb is not None else "-"
        if pct:
            sa_str = f"{va:.1%}" if va is not None else "-"
            sb_str = f"{vb:.1%}" if vb is not None else "-"
        delta = ""
        if va is not None and vb is not None:
            d = vb - va
            sign = "+" if d > 0 else ""
            delta = f"{sign}{d:.1%}" if pct else f"{sign}{d:{fmt}}"
        table.add_row(label, sa_str, sb_str, delta)

    table.add_row("Benchmark", ra["benchmark"], rb["benchmark"], "")
    _row("Resolved", "resolved", ".0f")
    _row("Resolve Rate", "resolve_rate", pct=True)
    _row("Avg Score", "avg_score", ".2f")

    console.print(table)


def _runs_compare_local(run_a, run_b, output):
    runs_dir = Path(output).resolve()

    def _load_manifest(rid):
        p = runs_dir / rid / "manifest.json"
        if not p.exists():
            console.print(f"[red]Run not found:[/red] {rid}")
            raise typer.Exit(1)
        with open(p) as f:
            return json.load(f)

    ma = _load_manifest(run_a)
    mb = _load_manifest(run_b)
    sa = ma.get("summary", {})
    sb = mb.get("summary", {})

    table = Table(title="Run Comparison")
    table.add_column("Metric")
    table.add_column(run_a, justify="right", style="cyan")
    table.add_column(run_b, justify="right", style="magenta")
    table.add_column("Delta", justify="right")

    def _row(label, key, fmt=".1f", pct=False):
        va = sa.get(key)
        vb = sb.get(key)
        sa_str = f"{va:{fmt}}" if va is not None else "-"
        sb_str = f"{vb:{fmt}}" if vb is not None else "-"
        if pct:
            sa_str = f"{va:.1%}" if va is not None else "-"
            sb_str = f"{vb:.1%}" if vb is not None else "-"
        delta = ""
        if va is not None and vb is not None:
            d = vb - va
            sign = "+" if d > 0 else ""
            delta = f"{sign}{d:.1%}" if pct else f"{sign}{d:{fmt}}"
        table.add_row(label, sa_str, sb_str, delta)

    table.add_row("Benchmark", ma["benchmark"], mb["benchmark"], "")
    table.add_row("Agent", ma["agent"], mb["agent"], "")
    table.add_row("Instances", str(ma["instances_total"]), str(mb["instances_total"]), "")
    _row("Resolved", "resolved", ".0f")
    _row("Resolve Rate", "resolve_rate", ".1%", pct=True)
    _row("Avg Tokens", "avg_tokens", ",.0f")
    _row("Avg Latency (ms)", "avg_latency_ms", ",.0f")
    _row("Avg Tool Calls", "avg_tool_calls", ".1f")
    _row("Cache Hit Rate", "cache_hit_rate", ".0%", pct=True)

    console.print(table)

    # Per-instance diff
    console.print("\n[bold]Per-instance diff:[/bold]")

    def _load_scores(rid):
        scores = {}
        rd = runs_dir / rid
        for d in rd.iterdir():
            sp = d / "score.json"
            if sp.exists():
                with open(sp) as f:
                    s = json.load(f)
                scores[s.get("instance_id", d.name)] = s
        return scores

    scores_a = _load_scores(run_a)
    scores_b = _load_scores(run_b)
    all_ids = sorted(set(scores_a) | set(scores_b))

    diff_table = Table()
    diff_table.add_column("Instance ID", style="cyan")
    diff_table.add_column(f"{run_a}", justify="center")
    diff_table.add_column(f"{run_b}", justify="center")
    diff_table.add_column("Change", justify="center")

    for iid in all_ids:
        ra = scores_a.get(iid, {}).get("resolved")
        rb = scores_b.get(iid, {}).get("resolved")
        ra_str = "[green]Pass[/green]" if ra else ("[red]Fail[/red]" if ra is not None else "-")
        rb_str = "[green]Pass[/green]" if rb else ("[red]Fail[/red]" if rb is not None else "-")
        if ra is not None and rb is not None:
            if ra == rb:
                change = "[dim]=[/dim]"
            elif rb and not ra:
                change = "[green]+[/green]"
            else:
                change = "[red]-[/red]"
        else:
            change = "[yellow]?[/yellow]"
        diff_table.add_row(iid, ra_str, rb_str, change)

    console.print(diff_table)


# --- Output helpers ---


def _print_prod_summary(data: dict) -> None:
    summary = data.get("summary") or {}
    console.print()
    console.print(f"[bold]Run ID:[/bold]      {data['run_id']}")
    console.print(f"[bold]Benchmark:[/bold]   {data['benchmark']}")
    console.print(f"[bold]Status:[/bold]      {data['status']}")
    if data.get("tags"):
        console.print(f"[bold]Tags:[/bold]        {', '.join(data['tags'])}")
    console.print()

    if summary:
        total = summary.get("instances_total", 0)
        resolved = summary.get("resolved", 0)
        rate = summary.get("resolve_rate", 0)
        console.print("[bold]Results:[/bold]")
        console.print(f"  Resolved:   [green]{resolved}[/green]/{total}  ({rate:.1%})")
        if summary.get("avg_score") is not None:
            console.print(f"  Avg score:  {summary['avg_score']:.2f}")


def _print_summary(manifest: dict) -> None:
    summary = manifest.get("summary", {})
    console.print()
    console.print(f"[bold]Run ID:[/bold]      {manifest['run_id']}")
    console.print(f"[bold]Benchmark:[/bold]   {manifest['benchmark']} ({manifest['instances_total']} instances)")
    console.print(f"[bold]Agent:[/bold]       {manifest['agent']}")
    if manifest.get("tag"):
        console.print(f"[bold]Tag:[/bold]         {manifest['tag']}")
    console.print()
    console.print("[bold]Results:[/bold]")

    total = manifest["instances_total"]
    resolved = summary.get("resolved", 0)
    errored = manifest.get("instances_errored", manifest.get("instances_failed", 0))
    failed = total - resolved - errored
    rate = summary.get("resolve_rate", 0)
    console.print(f"  Resolved:       [green]{resolved}[/green]/{total}  ({rate:.1%})")
    if failed > 0:
        console.print(f"  Failed:         [red]{failed}[/red]/{total}")
    if errored > 0:
        console.print(f"  Errors:         [yellow]{errored}[/yellow]/{total}")

    if summary.get("avg_tokens") is not None:
        console.print(f"  Avg tokens:     {summary['avg_tokens']:,.0f}")
    if summary.get("avg_latency_ms") is not None:
        console.print(f"  Avg latency:    {summary['avg_latency_ms'] / 1000:.1f}s")
    if summary.get("avg_tool_calls") is not None:
        console.print(f"  Avg tool calls: {summary['avg_tool_calls']:.1f}")
    if summary.get("cache_hit_rate") is not None:
        console.print(f"  Cache hit rate: {summary['cache_hit_rate']:.0%}")

    elapsed = manifest.get("elapsed_sec")
    if elapsed is not None:
        mins, secs = divmod(int(elapsed), 60)
        console.print(f"  Duration:       {mins}m {secs:02d}s")

    run_dir = manifest.get("run_dir", "")
    console.print(f"\nArtifacts written to: {run_dir}")


@runs_app.command("watch")
def runs_watch(
    run_id: str = typer.Argument(..., help="Run ID to watch"),
) -> None:
    """Attach to a running (or completed) run and show progress."""
    from cli.api_client import get_run

    # Check the run exists
    run_data = get_run(run_id)
    if not run_data:
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)

    console.print(f"  Run ID:    [cyan]{run_id}[/cyan]")
    console.print(f"  Benchmark: {run_data.get('benchmark', '?')}")
    console.print()

    if run_data.get("status") in ("complete", "failed", "cancelled"):
        console.print(f"[dim]Run already {run_data['status']}.[/dim]")
        _print_prod_summary(run_data)
        return

    _watch_run(run_id)


@runs_app.command("cancel")
def runs_cancel(
    run_id: str = typer.Argument(..., help="Run ID to cancel"),
) -> None:
    """Cancel a running benchmark run."""
    from cli.api_client import _api

    resp = _api("POST", f"/runs/{run_id}/cancel")

    if resp.status_code == 200:
        data = resp.json()
        console.print(f"[green]Run cancelled.[/green] {data.get('instances_cancelled', 0)} queued instances cancelled.")
        console.print(f"Running instances will finish naturally.")
    elif resp.status_code == 400:
        console.print(f"[yellow]{resp.json().get('error', 'Run is not running')}[/yellow]")
    elif resp.status_code == 404:
        console.print(f"[red]Run not found:[/red] {run_id}")
    else:
        console.print(f"[red]Error:[/red] {resp.text}")


@runs_app.command("download")
def runs_download(
    run_id: str = typer.Argument(..., help="Run ID to download logs for"),
    failed: bool = typer.Option(False, "--failed", "-f", help="Download only failed (unresolved) instances"),
    errored: bool = typer.Option(False, "--errored", "-e", help="Download only errored instances"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i", help="Download a specific instance by ID"),
    output: str = typer.Option(".", "--output", "-o", help="Directory to save the download"),
) -> None:
    """Download logs and artifacts from a run.

    Examples:
      benchspan runs download <run_id>                    # all instances
      benchspan runs download <run_id> --failed           # only unresolved
      benchspan runs download <run_id> --errored          # only errored
      benchspan runs download <run_id> -i django-11099    # specific instance
    """
    import zipfile

    from cli.api_client import download_run

    # Determine filter
    if instance:
        # For single instance, download all and extract just that one
        filter_type = "all"
    elif errored:
        filter_type = "errored"
    elif failed:
        filter_type = "failed"
    else:
        filter_type = "all"

    label = instance or filter_type
    console.print(f"Downloading [cyan]{label}[/cyan] from run {run_id[:12]}...")

    data = download_run(run_id, filter_type)
    if not data:
        console.print("[red]Download failed.[/red] Run may not exist or have no matching instances.")
        raise typer.Exit(1)

    output_dir = Path(output).resolve()
    short_id = run_id[:8]

    if instance:
        # Extract only the specific instance from the zip
        zf = zipfile.ZipFile(BytesIO(data))
        matching = [n for n in zf.namelist() if n.startswith(f"{instance}/")]
        if not matching:
            console.print(f"[red]Instance '{instance}' not found in run.[/red]")
            raise typer.Exit(1)

        extract_dir = output_dir / f"run_{short_id}" / instance
        extract_dir.mkdir(parents=True, exist_ok=True)
        for name in matching:
            # Strip the instance_id prefix for cleaner paths
            rel = name[len(f"{instance}/"):]
            if not rel:
                continue
            dest = extract_dir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(name))

        console.print(f"[green]Downloaded {len(matching)} files[/green]")
        console.print(f"  {extract_dir}")
    else:
        # Save the whole zip
        zip_name = f"run_{short_id}_{filter_type}.zip"
        zip_path = output_dir / zip_name
        zip_path.write_bytes(data)

        # Also extract it
        extract_dir = output_dir / f"run_{short_id}"
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(BytesIO(data)) as zf:
            zf.extractall(extract_dir)
            file_count = len(zf.namelist())

        console.print(f"[green]Downloaded {file_count} files[/green]")
        console.print(f"  zip: {zip_path}")
        console.print(f"  dir: {extract_dir}")


@benchmarks_app.command("list")
def benchmarks_list() -> None:
    """List all available benchmarks (public + private)."""
    from cli.api_client import list_benchmarks

    benchmarks = list_benchmarks()
    if not benchmarks:
        console.print("[yellow]No benchmarks found.[/yellow]")
        return

    table = Table(title="Benchmarks")
    table.add_column("Name", style="cyan")
    table.add_column("Type")
    table.add_column("Instances", justify="right")
    table.add_column("Version")
    table.add_column("Description")

    for bm in sorted(benchmarks, key=lambda b: (b.get("type", ""), b["name"])):
        type_style = "dim" if bm.get("type") == "public" else "green"
        table.add_row(
            bm["name"],
            f"[{type_style}]{bm.get('type', 'public')}[/{type_style}]",
            str(bm.get("instances", 0)),
            bm.get("version", ""),
            bm.get("description", "") or "",
        )

    console.print(table)


@benchmarks_app.command("instances")
def benchmarks_instances(
    name: str = typer.Argument(..., help="Benchmark name"),
) -> None:
    """List instances for a benchmark."""
    from cli.api_client import get_benchmark_instances

    data = get_benchmark_instances(name)
    if "error" in data:
        console.print(f"[red]{data['error']}[/red]")
        raise typer.Exit(1)

    instances = data.get("instances", [])
    bm_type = data.get("type", "public")

    console.print(f"[bold]{name}[/bold] ({bm_type}) — {len(instances)} instances\n")

    table = Table()
    table.add_column("Instance ID", style="cyan")
    table.add_column("Timeout", justify="right")

    for inst in instances:
        table.add_row(
            inst["instance_id"],
            f"{inst.get('timeout', '—')}s" if inst.get("timeout") else "—",
        )

    console.print(table)


if __name__ == "__main__":
    app()
