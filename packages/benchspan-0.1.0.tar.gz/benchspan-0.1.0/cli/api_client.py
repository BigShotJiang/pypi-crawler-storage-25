"""BenchSpan API client — used by CLI in prod (remote) mode."""

from __future__ import annotations

import json
import tarfile
import time
import webbrowser
from io import BytesIO
from pathlib import Path

import requests
from rich.console import Console

console = Console()

CONFIG_DIR = Path.home() / ".benchspan"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_API_URL = "https://api.benchspan.com"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def _save_config(config: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_api_url() -> str:
    return _load_config().get("api_url", DEFAULT_API_URL)


def get_token() -> str | None:
    return _load_config().get("token")


def require_token() -> str:
    token = get_token()
    if not token:
        console.print("[red]Not logged in.[/red] Run: benchspan login")
        raise SystemExit(1)
    return token


def _headers(token: str | None = None) -> dict:
    t = token or require_token()
    return {"Authorization": f"Bearer {t}"}


def _api(method: str, path: str, token: str | None = None, **kwargs) -> requests.Response:
    url = f"{get_api_url()}{path}"
    resp = requests.request(method, url, headers=_headers(token), **kwargs)
    if resp.status_code == 401:
        console.print("[red]Session expired.[/red] Run: benchspan login")
        raise SystemExit(1)
    return resp


# --- Auth ---


def login() -> None:
    """Browser-based login flow with localhost callback, polling fallback."""
    import http.server
    import socketserver
    import threading
    import urllib.parse

    api_url = get_api_url()
    result = {}

    # Start local HTTP server to receive the callback
    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)

            if parsed.path == "/callback" and "token" in params:
                result["token"] = params["token"][0]
                result["email"] = params.get("email", [""])[0]
                result["user_id"] = params.get("user_id", [""])[0]
                result["company_id"] = params.get("company_id", [""])[0]

                # Serve success page
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""<!DOCTYPE html><html><body style="background:#0a0a0a;color:#e5e5e5;
                    font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh">
                    <div style="text-align:center"><h1 style="color:#4ade80">Logged in</h1>
                    <p style="color:#737373">You can close this tab.</p></div></body></html>""")
            else:
                self.send_response(400)
                self.end_headers()

        def log_message(self, format, *args):
            pass  # Suppress server logs

    # Try localhost callback first
    try:
        server = socketserver.TCPServer(("127.0.0.1", 0), CallbackHandler)
        port = server.server_address[1]

        server_thread = threading.Thread(target=server.handle_request, daemon=True)
        server_thread.start()

        # Create CLI auth session
        resp = requests.post(f"{api_url}/auth/cli/start", json={"callback_port": port})
        if resp.status_code != 201:
            console.print(f"[red]Failed to start login:[/red] {resp.text}")
            raise SystemExit(1)

        code = resp.json()["code"]

        # Open browser to login page
        auth_url = f"{api_url}/auth/cli/login?code={code}&port={port}"
        console.print(f"Opening browser to login...")
        console.print(f"If it doesn't open, visit: [cyan]{auth_url}[/cyan]")
        webbrowser.open(auth_url)

        # Wait for callback (with polling fallback)
        console.print("Waiting for login...", end="")
        for _ in range(100):  # 5 min timeout
            time.sleep(3)
            console.print(".", end="")

            # Check if localhost callback received the token
            if result.get("token"):
                break

            # Polling fallback — check if approved via another path
            poll = requests.get(f"{api_url}/auth/cli/poll", params={"code": code})
            if poll.status_code == 200 and poll.json().get("status") == "approved":
                poll_data = poll.json()
                result["token"] = poll_data["token"]
                result["email"] = poll_data.get("email", "")
                result["user_id"] = poll_data.get("user_id", "")
                result["company_id"] = poll_data.get("company_id", "")
                break
            elif poll.status_code == 410:
                console.print()
                console.print("[red]Login expired. Try again.[/red]")
                server.server_close()
                raise SystemExit(1)

        server.server_close()

    except OSError:
        # Localhost server failed — pure polling mode
        resp = requests.post(f"{api_url}/auth/cli/start", json={"callback_port": 1})
        if resp.status_code != 201:
            console.print(f"[red]Failed to start login:[/red] {resp.text}")
            raise SystemExit(1)

        code = resp.json()["code"]
        auth_url = f"{api_url}/auth/cli/login?code={code}"
        console.print(f"Visit this URL to login: [cyan]{auth_url}[/cyan]")

        console.print("Waiting for login...", end="")
        for _ in range(100):
            time.sleep(3)
            console.print(".", end="")
            poll = requests.get(f"{api_url}/auth/cli/poll", params={"code": code})
            if poll.status_code == 200 and poll.json().get("status") == "approved":
                poll_data = poll.json()
                result["token"] = poll_data["token"]
                result["email"] = poll_data.get("email", "")
                result["user_id"] = poll_data.get("user_id", "")
                result["company_id"] = poll_data.get("company_id", "")
                break
            elif poll.status_code == 410:
                console.print()
                console.print("[red]Login expired. Try again.[/red]")
                raise SystemExit(1)

    if not result.get("token"):
        console.print()
        console.print("[red]Login timed out.[/red]")
        raise SystemExit(1)

    # Save credentials
    config = _load_config()
    config["token"] = result["token"]
    config["email"] = result["email"]
    config["user_id"] = result["user_id"]
    config["company_id"] = result["company_id"]
    config["api_url"] = api_url
    _save_config(config)

    console.print()
    console.print(f"[green]Logged in as {result['email']}[/green]")


def login_with_credentials(email: str, password: str) -> None:
    """Direct email/password login (alternative to browser flow)."""
    api_url = get_api_url()
    resp = requests.post(f"{api_url}/auth/login", json={"email": email, "password": password})

    if resp.status_code != 200:
        console.print(f"[red]Login failed:[/red] {resp.json().get('error', 'unknown error')}")
        raise SystemExit(1)

    data = resp.json()
    config = _load_config()
    config["token"] = data["token"]
    config["user_id"] = data["user_id"]
    config["company_id"] = data["company_id"]
    config["api_url"] = api_url
    _save_config(config)

    console.print(f"[green]Logged in.[/green]")


# --- Runs ---


def list_secret_names() -> list[str]:
    """List secret names configured on the dashboard (never values)."""
    try:
        resp = _api("GET", "/secrets")
        if resp.status_code == 200:
            return [s["name"] for s in resp.json().get("secrets", [])]
    except Exception:
        pass
    return []


def _load_ignore_patterns(agent_path: Path) -> list[str]:
    """Load ignore patterns from .benchspanignore file."""
    ignore_file = agent_path / ".benchspanignore"
    if not ignore_file.exists():
        return []
    patterns = []
    for line in ignore_file.read_text().splitlines():
        line = line.strip().rstrip("/")
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns


def _should_ignore(path: Path, agent_path: Path, patterns: list[str]) -> bool:
    """Check if a file should be ignored based on .benchspanignore patterns."""
    import fnmatch
    rel = str(path.relative_to(agent_path))
    for pattern in patterns:
        # Match against filename or relative path
        if fnmatch.fnmatch(path.name, pattern):
            return True
        if fnmatch.fnmatch(rel, pattern):
            return True
        # Match directory names anywhere in path
        for part in path.relative_to(agent_path).parts:
            if fnmatch.fnmatch(part, pattern):
                return True
    return False


def create_agent_tar(agent_path: Path) -> BytesIO:
    """Create a tar.gz of the agent directory with runner/ prefix.

    Respects .benchspanignore for excluding files/directories.
    Always excludes: .git, __pycache__, node_modules, .venv, *.pyc
    """
    default_ignores = [".git", "__pycache__", "node_modules", ".venv", "*.pyc", ".benchspanignore"]
    user_ignores = _load_ignore_patterns(agent_path)
    all_patterns = default_ignores + user_ignores

    buf = BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for item in agent_path.rglob("*"):
            if item.is_file() and not _should_ignore(item, agent_path, all_patterns):
                arcname = f"runner/{item.relative_to(agent_path)}"
                tar.add(str(item), arcname=arcname)
    buf.seek(0)
    return buf


def submit_run(
    benchmark: str,
    agent_path: Path,
    instances: int | None = None,
    tags: list[str] | None = None,
    parallelism: int = 10,
    instance_ids: list[str] | None = None,
) -> dict:
    """Submit a benchmark run to the API."""
    agent_tar = create_agent_tar(agent_path)

    files = {"agent": ("agent.tar.gz", agent_tar, "application/gzip")}
    data = {"benchmark": benchmark, "parallelism": str(parallelism)}
    if instances:
        data["instances"] = str(instances)
    if tags:
        data["tags"] = json.dumps(tags)
    if instance_ids:
        data["instance_ids"] = json.dumps(instance_ids)

    resp = _api("POST", "/runs", files=files, data=data)
    if resp.status_code != 201:
        console.print(f"[red]Failed to submit run:[/red] {resp.text}")
        raise SystemExit(1)

    return resp.json()


def get_failed_instances(run_id: str) -> list[str]:
    """Get instance IDs that failed or didn't resolve in a run."""
    resp = _api("GET", f"/runs/{run_id}/instances?limit=200")
    data = resp.json()
    failed = []
    for inst in data.get("instances", []):
        # Include: status=failed, or status=complete but not resolved
        if inst.get("status") == "failed":
            failed.append(inst["instance_id"])
        elif inst.get("status") == "complete":
            score = inst.get("score_json") or {}
            if not score.get("resolved"):
                failed.append(inst["instance_id"])
    return failed


def poll_status(run_id: str) -> dict:
    """Get run status counts."""
    try:
        resp = _api("GET", f"/runs/{run_id}/status")
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return {}


def get_run(run_id: str) -> dict:
    """Get full run details."""
    resp = _api("GET", f"/runs/{run_id}")
    return resp.json()


def list_runs(limit: int = 50, benchmark: str | None = None, tag: str | None = None, mine: bool = True) -> list[dict]:
    """List runs."""
    params = {"limit": limit}
    if benchmark:
        params["benchmark"] = benchmark
    if tag:
        params["tag"] = tag
    if mine:
        params["mine"] = "true"
    resp = _api("GET", "/runs", params=params)
    return resp.json().get("runs", [])


def list_benchmarks() -> list[dict]:
    """List all benchmarks (public + private)."""
    resp = _api("GET", "/benchmarks")
    return resp.json().get("benchmarks", [])


def get_benchmark_instances(name: str) -> list[dict]:
    """List instances for a benchmark."""
    resp = _api("GET", f"/benchmarks/{name}/instances")
    return resp.json()


def compare_runs(run_a: str, run_b: str) -> dict:
    """Compare two runs."""
    resp = _api("GET", "/runs/compare", params={"a": run_a, "b": run_b})
    return resp.json()


def download_run(run_id: str, filter_type: str = "all") -> bytes | None:
    """Download run artifacts as a zip. Returns raw bytes or None on error."""
    resp = _api("GET", f"/runs/{run_id}/download", params={"filter": filter_type})
    if resp.status_code == 200:
        return resp.content
    return None
