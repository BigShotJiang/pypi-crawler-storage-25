use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use minacalc_rs::{Calc, RoxCalcExt};
use std::path::PathBuf;
use std::collections::HashMap;

// 修正1: 警告を出さないように #[derive(Clone)] を削除
#[pyclass]
pub struct RateScores {
    #[pyo3(get)] pub overall: f64,
    #[pyo3(get)] pub stream: f64,
    #[pyo3(get)] pub jumpstream: f64,
    #[pyo3(get)] pub handstream: f64,
    #[pyo3(get)] pub stamina: f64,
    #[pyo3(get)] pub jackspeed: f64,
    #[pyo3(get)] pub chordjack: f64,
    #[pyo3(get)] pub technical: f64,
}

#[pyfunction]
pub fn calculate(input: String) -> PyResult<HashMap<String, RateScores>> {
    let calc = Calc::new().map_err(|_| {
        PyRuntimeError::new_err("Calcの初期化に失敗しました")
    })?;

    let path = PathBuf::from(&input);

    let msd_results = calc.calculate_all_rates_from_file(&path, true).map_err(|_| {
        PyRuntimeError::new_err("ファイルからのレート計算に失敗しました")
    })?;

    let mut result_map = HashMap::new();

    let rates = ["0.7", "1.0", "1.5", "2.0"];
    let rate_indices = [0, 3, 8, 13];

    for (rate_str, &index) in rates.iter().zip(rate_indices.iter()) {
        if index < msd_results.msds.len() {
            let scores = &msd_results.msds[index];

            let rate_scores = RateScores {
                overall: scores.overall as f64,
                stream: scores.stream as f64,
                jumpstream: scores.jumpstream as f64,
                handstream: scores.handstream as f64,
                stamina: scores.stamina as f64,
                jackspeed: scores.jackspeed as f64,
                chordjack: scores.chordjack as f64,
                technical: scores.technical as f64,
            };

            result_map.insert(rate_str.to_string(), rate_scores);
        }
    }

    Ok(result_map)
}

// 修正2: PyO3の最新API (Bound) の書き方に変更
#[pymodule]
fn mames_rate_api_lib(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(calculate, m)?)?;
    m.add_class::<RateScores>()?;
    Ok(())
}