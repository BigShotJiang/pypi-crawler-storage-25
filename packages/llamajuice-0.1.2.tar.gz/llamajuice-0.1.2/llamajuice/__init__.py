"""llamajuice — Squeeze every last drop from your NVIDIA GPU."""

__version__ = "0.1.2"
