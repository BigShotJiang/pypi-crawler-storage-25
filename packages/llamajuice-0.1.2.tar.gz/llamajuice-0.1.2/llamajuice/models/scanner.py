"""Scan for locally available GGUF models from LM Studio and Ollama."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class LocalModel:
    name: str
    path: Path | None  # None for Ollama API-discovered models
    size_gb: float
    source: str  # "lmstudio", "ollama", "local"

    def __str__(self) -> str:
        return f"{self.name} ({self.size_gb} GB, {self.source})"


def _scan_lmstudio() -> list[LocalModel]:
    """Scan LM Studio model directory for .gguf files."""
    models_dir = Path.home() / ".lmstudio" / "models"
    if not models_dir.exists():
        return []

    models = []
    for gguf in models_dir.rglob("*.gguf"):
        # Skip mmproj (vision projection) files
        if "mmproj" in gguf.name.lower():
            continue
        size_gb = round(gguf.stat().st_size / (1024**3), 1)
        if size_gb < 0.5:  # skip tiny files like embeddings
            continue
        models.append(LocalModel(
            name=gguf.stem,
            path=gguf,
            size_gb=size_gb,
            source="lmstudio",
        ))
    return models


def _scan_ollama() -> list[LocalModel]:
    """Scan Ollama blob directory for GGUF models.

    Ollama stores models as blobs with a manifest that maps model names
    to SHA256 digests. The actual GGUF files are in blobs/sha256-{hash}.
    """
    ollama_dir = Path.home() / ".ollama"
    manifests_dir = ollama_dir / "models" / "manifests" / "registry.ollama.ai"
    blobs_dir = ollama_dir / "models" / "blobs"

    if not manifests_dir.exists() or not blobs_dir.exists():
        return []

    models = []
    for manifest_file in manifests_dir.rglob("manifest"):
        # Path structure: manifests/registry.ollama.ai/library/{model}/{tag}/manifest
        parts = manifest_file.relative_to(manifests_dir).parts
        if len(parts) < 3:
            continue
        # parts like: ('library', 'qwen3', '8b', 'manifest') or ('library', 'qwen3', 'latest', 'manifest')
        model_name = "/".join(parts[1:-1])  # e.g. "qwen3/8b"

        try:
            manifest = json.loads(manifest_file.read_text())
        except (json.JSONDecodeError, OSError):
            continue

        # Find the model layer (mediaType contains "model")
        for layer in manifest.get("layers", []):
            media_type = layer.get("mediaType", "")
            if "model" not in media_type:
                continue

            digest = layer.get("digest", "")
            if not digest.startswith("sha256:"):
                continue

            blob_name = digest.replace(":", "-")
            blob_path = blobs_dir / blob_name
            if not blob_path.exists():
                continue

            size_gb = round(blob_path.stat().st_size / (1024**3), 1)
            if size_gb < 0.5:
                continue

            models.append(LocalModel(
                name=model_name,
                path=blob_path,
                size_gb=size_gb,
                source="ollama",
            ))
    return models


def _scan_ollama_api() -> list[LocalModel]:
    """Query the Ollama API for available models (if Ollama is running)."""
    try:
        import httpx
        resp = httpx.get("http://localhost:11434/api/tags", timeout=3)
        if resp.status_code != 200:
            return []
        data = resp.json()
    except Exception:
        return []

    models = []
    for m in data.get("models", []):
        name = m.get("name", "")
        size_gb = round(m.get("size", 0) / (1024**3), 1)
        if size_gb < 0.1:
            continue
        models.append(LocalModel(
            name=name,
            path=None,
            size_gb=size_gb,
            source="ollama",
        ))
    return models


def scan_local_models() -> list[LocalModel]:
    """Scan all known locations for GGUF models and query Ollama API."""
    models = []
    models.extend(_scan_lmstudio())
    models.extend(_scan_ollama())     # blob-based scan
    models.extend(_scan_ollama_api()) # API-based scan (catches models blob scan misses)

    # Deduplicate by name (case-insensitive) — prefer entries with a path
    seen_names: dict[str, LocalModel] = {}
    for m in models:
        key = m.name.lower().replace(":", "-").replace("/", "-")
        if key not in seen_names or (m.path is not None and seen_names[key].path is None):
            seen_names[key] = m

    return sorted(seen_names.values(), key=lambda m: m.name.lower())
