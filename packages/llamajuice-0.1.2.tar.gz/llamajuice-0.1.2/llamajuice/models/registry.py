"""Model recommendations by VRAM tier and use case.

This is reference data only - Juice does not download models.
Users download their own GGUFs from HuggingFace and point Juice at them.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ModelRec:
    name: str
    repo_id: str
    quant: str
    size_gb: float
    min_vram_gb: float
    description: str


# Tested recommendations - models we've verified work well with Juice
CATALOGUE: list[ModelRec] = [
    ModelRec(
        name="Qwen2.5-7B-Instruct",
        repo_id="Qwen/Qwen2.5-7B-Instruct-GGUF",
        quant="Q4_K_M",
        size_gb=4.7,
        min_vram_gb=6.0,
        description="All-round 7B - reasoning, tool calls, multilingual",
    ),
    ModelRec(
        name="Qwen2.5-Coder-7B-Instruct",
        repo_id="Qwen/Qwen2.5-Coder-7B-Instruct-GGUF",
        quant="Q4_K_M",
        size_gb=4.7,
        min_vram_gb=6.0,
        description="Code - FIM, completion, refactoring",
    ),
    ModelRec(
        name="Qwen3-8B",
        repo_id="Qwen/Qwen3-8B-GGUF",
        quant="Q4_K_M",
        size_gb=5.0,
        min_vram_gb=6.0,
        description="Latest Qwen - thinking mode with <think> traces",
    ),
    ModelRec(
        name="Mistral-7B-Instruct-v0.3",
        repo_id="MistralAI/Mistral-7B-Instruct-v0.3-GGUF",
        quant="Q4_K_M",
        size_gb=4.4,
        min_vram_gb=6.0,
        description="Fast and reliable baseline",
    ),
    ModelRec(
        name="Llama-3.1-8B-Instruct",
        repo_id="bartowski/Meta-Llama-3.1-8B-Instruct-GGUF",
        quant="Q4_K_M",
        size_gb=4.9,
        min_vram_gb=6.0,
        description="Strong English, good tool use",
    ),
    ModelRec(
        name="Phi-3.5-mini-instruct",
        repo_id="bartowski/Phi-3.5-mini-instruct-GGUF",
        quant="Q4_K_M",
        size_gb=2.2,
        min_vram_gb=4.0,
        description="Tiny but capable - fits on 4 GB GPUs",
    ),
    ModelRec(
        name="Gemma-2-9B-Instruct",
        repo_id="bartowski/gemma-2-9b-it-GGUF",
        quant="Q4_K_M",
        size_gb=5.4,
        min_vram_gb=7.0,
        description="Google 9B - strong reasoning",
    ),
]


def list_models_for_vram(vram_gb: float) -> list[ModelRec]:
    """Return recommended models that fit in the given VRAM."""
    return [m for m in CATALOGUE if m.min_vram_gb <= vram_gb]
