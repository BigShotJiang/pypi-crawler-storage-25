"""Combo proxy — single endpoint, multi-model routing.

Sits in front of Ollama (or any OpenAI-compatible backend) and routes
requests to the optimal model based on task complexity.

To the caller it looks like one smart model. Under the hood it's two
models cooperating: fast 1.5B for simple tasks, capable 7B for complex ones.
"""

from __future__ import annotations

import json
import time

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

from llamajuice.core.router import ComboConfig, TaskType, classify_request

app = FastAPI(title="juice combo", docs_url=None, redoc_url=None)

# Set at startup by the CLI
_config: ComboConfig | None = None
_client: httpx.AsyncClient | None = None

# Stats
_stats = {
    "requests": 0,
    "routed_fast": 0,
    "routed_main": 0,
}


def configure(config: ComboConfig) -> None:
    global _config, _client
    _config = config
    _client = httpx.AsyncClient(timeout=120)


def preload_models() -> dict:
    """Pre-load both models into Ollama with full GPU offload.

    Uses num_gpu=99 to force all layers onto GPU and keep_alive=-1
    to pin them in memory indefinitely. Returns status dict.
    """
    ollama_base = _config.backend_url.replace("/v1", "")
    results = {}

    for label, model in [("fast", _config.fast_model), ("main", _config.main_model)]:
        try:
            resp = httpx.post(
                f"{ollama_base}/api/generate",
                json={
                    "model": model,
                    "prompt": "",
                    "keep_alive": -1,
                    "options": {"num_gpu": 99},
                },
                timeout=120,
            )
            results[label] = {"model": model, "status": "loaded"}
        except Exception as e:
            results[label] = {"model": model, "status": "failed", "error": str(e)}

    return results


@app.get("/health")
async def health():
    return {"status": "ok", "mode": "combo"}


@app.get("/v1/models")
async def list_models():
    return {
        "data": [
            {"id": "juice-combo", "object": "model"},
            {"id": _config.fast_model, "object": "model"},
            {"id": _config.main_model, "object": "model"},
        ]
    }


@app.get("/juice/stats")
async def stats():
    return _stats


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()

    messages = body.get("messages", [])
    has_tools = bool(body.get("tools"))
    stream = body.get("stream", False)

    # Classify and route
    task = classify_request(messages, has_tools=has_tools, config=_config)

    if task == TaskType.SIMPLE:
        target_model = _config.fast_model
        _stats["routed_fast"] += 1
    else:
        target_model = _config.main_model
        _stats["routed_main"] += 1

    _stats["requests"] += 1

    # Log to usage tracker
    try:
        from llamajuice.core.usage import log_request
        log_request(model=target_model, task_type=task.value)
    except Exception:
        pass  # usage tracking is best-effort

    # Override the model in the request
    body["model"] = target_model

    # Add routing header so callers can see which model was used
    extra_headers = {"X-Juice-Model": target_model, "X-Juice-Task": task.value}

    if stream:
        return StreamingResponse(
            _proxy_stream(body, extra_headers),
            media_type="text/event-stream",
            headers=extra_headers,
        )
    else:
        resp = await _client.post(
            f"{_config.backend_url}/chat/completions",
            json=body,
        )
        data = resp.json()

        # Inject routing info into the response
        data["juice_routing"] = {
            "model_used": target_model,
            "task_type": task.value,
        }

        return JSONResponse(content=data, headers=extra_headers)


async def _proxy_stream(body: dict, headers: dict):
    """Stream proxy — forwards SSE chunks from backend."""
    async with _client.stream(
        "POST",
        f"{_config.backend_url}/chat/completions",
        json=body,
    ) as resp:
        async for line in resp.aiter_lines():
            yield f"{line}\n"
    yield "\n"
