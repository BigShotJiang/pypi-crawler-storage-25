"""GPU detection and utilisation verification via nvidia-smi."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass


@dataclass
class GPUInfo:
    index: int
    name: str
    vram_total_mb: int
    vram_used_mb: int
    utilisation_pct: int
    driver_version: str
    cuda_version: str

    @property
    def vram_total_gb(self) -> float:
        return round(self.vram_total_mb / 1024, 1)

    @property
    def vram_used_gb(self) -> float:
        return round(self.vram_used_mb / 1024, 1)

    @property
    def vram_free_mb(self) -> int:
        return self.vram_total_mb - self.vram_used_mb

    @property
    def vram_pct(self) -> int:
        if self.vram_total_mb == 0:
            return 0
        return round(self.vram_used_mb / self.vram_total_mb * 100)

    def vram_bar(self, width: int = 20) -> str:
        filled = round(self.vram_pct / 100 * width)
        return "#" * filled + "-" * (width - filled)


class GPUError(Exception):
    """Raised when GPU detection or verification fails."""


def _run_smi(args: list[str]) -> str:
    try:
        result = subprocess.run(
            ["nvidia-smi", *args],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError:
        raise GPUError(
            "nvidia-smi not found. Is the NVIDIA driver installed and on PATH?"
        )
    except subprocess.TimeoutExpired:
        raise GPUError("nvidia-smi timed out.")

    if result.returncode != 0:
        raise GPUError(f"nvidia-smi failed: {result.stderr.strip()}")
    return result.stdout


def detect_gpus() -> list[GPUInfo]:
    """Detect all NVIDIA GPUs via nvidia-smi."""
    # Get driver and CUDA version from main output
    header = _run_smi([])
    driver_match = re.search(r"Driver Version:\s+([\d.]+)", header)
    cuda_match = re.search(r"CUDA Version:\s+([\d.]+)", header)
    driver_version = driver_match.group(1) if driver_match else "unknown"
    cuda_version = cuda_match.group(1) if cuda_match else "unknown"

    # Query per-GPU details
    csv = _run_smi([
        "--query-gpu=index,name,memory.total,memory.used,utilization.gpu",
        "--format=csv,noheader,nounits",
    ])

    gpus = []
    for line in csv.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 5:
            continue
        gpus.append(GPUInfo(
            index=int(parts[0]),
            name=parts[1],
            vram_total_mb=int(float(parts[2])),
            vram_used_mb=int(float(parts[3])),
            utilisation_pct=int(float(parts[4])),
            driver_version=driver_version,
            cuda_version=cuda_version,
        ))

    if not gpus:
        raise GPUError("No NVIDIA GPUs detected.")
    return gpus


def detect_gpu(index: int = 0) -> GPUInfo:
    """Detect a single GPU by index (default: first GPU)."""
    gpus = detect_gpus()
    for gpu in gpus:
        if gpu.index == index:
            return gpu
    raise GPUError(f"GPU index {index} not found. Available: {[g.index for g in gpus]}")


def assert_gpu_utilised(gpu: GPUInfo | None = None, min_vram_pct: int = 70) -> GPUInfo:
    """Check that the GPU has significant VRAM usage (model is loaded on GPU).

    Re-queries nvidia-smi for fresh data if gpu is None.
    Raises GPUError if VRAM usage is below threshold.
    """
    if gpu is None:
        gpu = detect_gpu()
    else:
        # Re-query for fresh numbers
        gpu = detect_gpu(gpu.index)

    if gpu.vram_pct < min_vram_pct:
        raise GPUError(
            f"GPU offload verification failed. "
            f"VRAM usage is {gpu.vram_pct}% ({gpu.vram_used_gb}/{gpu.vram_total_gb} GB). "
            f"Expected at least {min_vram_pct}%. "
            f"The model may be running on CPU."
        )
    return gpu
