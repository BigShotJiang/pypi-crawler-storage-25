"""Multi-model router — route requests to the optimal model by task.

The router classifies incoming requests and sends them to either:
  - A fast, small model (1.5B) for simple tasks: greetings, classification, short answers
  - A capable, large model (7B) for complex tasks: reasoning, tool calls, code, analysis

To the caller it looks like a single OpenAI-compatible endpoint.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class TaskType(Enum):
    SIMPLE = "simple"    # route to small model
    COMPLEX = "complex"  # route to large model


@dataclass
class ComboConfig:
    """Configuration for a combo model pair."""
    fast_model: str        # e.g. "qwen2.5:1.5b"
    main_model: str        # e.g. "qwen2.5:7b"
    backend_url: str       # e.g. "http://localhost:11434/v1"
    proxy_port: int = 8080

    # Routing thresholds
    max_simple_tokens: int = 50      # messages shorter than this → maybe simple
    tool_always_main: bool = True    # tool calls always go to main model


# Patterns that indicate a simple task (fast model is fine)
SIMPLE_PATTERNS = [
    r"^(hi|hello|hey|thanks|thank you|ok|okay|yes|no|sure|got it)\b",
    r"^what (is|are) (the )?(time|date|day)\b",
    r"^(translate|convert)\b.{0,50}$",
    r"^(yes|no|true|false|correct|wrong)\b.{0,20}$",
]

# Patterns that indicate a complex task (needs main model)
COMPLEX_PATTERNS = [
    r"\b(explain|analyze|analyse|compare|evaluate|design|implement|refactor)\b",
    r"\b(write|create|build|generate) (a |an |the )?(function|class|script|program|code)\b",
    r"\b(why|how) (does|do|did|would|should|could|can)\b.*\?",
    r"\b(step by step|in detail|thoroughly)\b",
    r"\b(debug|fix|error|exception|traceback)\b",
    r"\bthink\b.*\b(through|about|carefully)\b",
]

_simple_re = [re.compile(p, re.IGNORECASE) for p in SIMPLE_PATTERNS]
_complex_re = [re.compile(p, re.IGNORECASE) for p in COMPLEX_PATTERNS]


def classify_request(
    messages: list[dict],
    has_tools: bool = False,
    config: ComboConfig | None = None,
) -> TaskType:
    """Classify a chat completion request as simple or complex.

    Rules (in priority order):
    1. Tool calls present → COMPLEX (always)
    2. Matches complex pattern → COMPLEX
    3. Matches simple pattern → SIMPLE
    4. Last message > max_simple_tokens chars → COMPLEX
    5. Multiple turns (>4 messages) → COMPLEX
    6. Default → SIMPLE (bias toward speed)
    """
    max_simple = config.max_simple_tokens if config else 50

    # Rule 1: tools always go to main model
    if has_tools:
        return TaskType.COMPLEX

    if not messages:
        return TaskType.SIMPLE

    last_msg = messages[-1].get("content", "") or ""

    # Rule 2: multi-turn conversations need context → complex
    if len(messages) > 4:
        return TaskType.COMPLEX

    # Rule 3: complex patterns
    for pattern in _complex_re:
        if pattern.search(last_msg):
            return TaskType.COMPLEX

    # Rule 4: simple patterns
    for pattern in _simple_re:
        if pattern.search(last_msg):
            return TaskType.SIMPLE

    # Rule 5: long messages are probably complex
    if len(last_msg) > max_simple * 4:  # ~200 chars
        return TaskType.COMPLEX

    # Rule 6: default to simple (bias toward speed)
    return TaskType.SIMPLE
