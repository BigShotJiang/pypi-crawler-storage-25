"""juice fix-gpu — set CUDA_VISIBLE_DEVICES and restart Ollama.

The RTX 50-series (Blackwell) needs CUDA_VISIBLE_DEVICES=0 or Ollama
reports 0 VRAM. Setting the env var via setx only affects new terminals —
Ollama is already running as a background process with the old environment.

This module:
1. Sets CUDA_VISIBLE_DEVICES=0 in the Windows registry (permanent)
2. Sets it in the current process (immediate)
3. Kills the running Ollama process
4. Relaunches Ollama with the env var inherited
5. Verifies GPU is detected by loading a model and checking VRAM
"""

from __future__ import annotations

import os
import subprocess
import sys
import time


class FixGPUError(Exception):
    pass


def _is_ollama_running() -> bool:
    """Check if ollama.exe is running."""
    if sys.platform == "win32":
        result = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq ollama.exe"],
            capture_output=True, text=True, timeout=10,
        )
        return "ollama.exe" in result.stdout
    else:
        result = subprocess.run(
            ["pgrep", "-x", "ollama"],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0


def _kill_ollama() -> None:
    """Kill the Ollama process."""
    if sys.platform == "win32":
        subprocess.run(
            ["taskkill", "/F", "/IM", "ollama.exe"],
            capture_output=True, timeout=10,
        )
        # Also kill ollama_llama_server.exe (the child process)
        subprocess.run(
            ["taskkill", "/F", "/IM", "ollama_llama_server.exe"],
            capture_output=True, timeout=10,
        )
    else:
        subprocess.run(["pkill", "-f", "ollama"], capture_output=True, timeout=10)

    # Wait for it to die
    for _ in range(20):
        if not _is_ollama_running():
            return
        time.sleep(0.5)

    raise FixGPUError("Could not kill Ollama process after 10 seconds.")


def _set_env_permanent(name: str, value: str) -> None:
    """Set an environment variable permanently via registry (Windows) or bashrc (Linux)."""
    if sys.platform == "win32":
        result = subprocess.run(
            ["setx", name, value],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            raise FixGPUError(f"setx failed: {result.stderr.strip()}")
    else:
        bashrc = os.path.expanduser("~/.bashrc")
        line = f'export {name}="{value}"'
        # Check if already set
        try:
            with open(bashrc) as f:
                if line in f.read():
                    return
        except FileNotFoundError:
            pass
        with open(bashrc, "a") as f:
            f.write(f"\n{line}\n")


def _launch_ollama() -> subprocess.Popen:
    """Launch Ollama with CUDA_VISIBLE_DEVICES in the environment."""
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"

    if sys.platform == "win32":
        # Launch detached on Windows so it survives our exit
        proc = subprocess.Popen(
            ["ollama", "serve"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW,
        )
    else:
        proc = subprocess.Popen(
            ["ollama", "serve"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    return proc


def _wait_for_ollama(timeout: float = 60) -> None:
    """Wait for Ollama API to become available."""
    import httpx

    start = time.monotonic()
    while time.monotonic() - start < timeout:
        try:
            resp = httpx.get("http://localhost:11434/api/tags", timeout=2)
            if resp.status_code == 200:
                return
        except (httpx.ConnectError, httpx.TimeoutException):
            pass
        time.sleep(0.5)

    raise FixGPUError(f"Ollama did not start within {timeout}s.")


def _verify_gpu_after_fix() -> dict:
    """Load a model briefly and check if VRAM is being used."""
    import httpx

    # Ask Ollama to load whatever model it has
    try:
        resp = httpx.get("http://localhost:11434/api/tags", timeout=5)
        models = resp.json().get("models", [])
        if not models:
            return {"verified": False, "reason": "No models in Ollama to test with."}

        model_name = models[0]["name"]

        # Generate empty to trigger model load
        httpx.post(
            "http://localhost:11434/api/generate",
            json={"model": model_name, "prompt": "", "keep_alive": "5m"},
            timeout=120,
        )

        # Check VRAM
        from llamajuice.core.gpu import detect_gpu
        gpu = detect_gpu()

        if gpu.vram_pct > 10:
            return {
                "verified": True,
                "model": model_name,
                "vram_used_gb": gpu.vram_used_gb,
                "vram_total_gb": gpu.vram_total_gb,
                "vram_pct": gpu.vram_pct,
            }
        else:
            return {
                "verified": False,
                "reason": f"VRAM still at {gpu.vram_pct}% after loading {model_name}. GPU may not be detected.",
                "vram_pct": gpu.vram_pct,
            }

    except Exception as e:
        return {"verified": False, "reason": str(e)}


def fix_gpu() -> dict:
    """Full GPU fix cycle. Returns a dict with results of each step."""
    results = {
        "steps": [],
        "success": False,
    }

    # Step 1: Set env var permanently
    try:
        _set_env_permanent("CUDA_VISIBLE_DEVICES", "0")
        os.environ["CUDA_VISIBLE_DEVICES"] = "0"
        results["steps"].append({"step": "Set CUDA_VISIBLE_DEVICES=0", "status": "OK"})
    except Exception as e:
        results["steps"].append({"step": "Set CUDA_VISIBLE_DEVICES=0", "status": "FAIL", "error": str(e)})
        return results

    # Step 2: Kill Ollama
    was_running = _is_ollama_running()
    if was_running:
        try:
            _kill_ollama()
            results["steps"].append({"step": "Stop Ollama", "status": "OK"})
        except Exception as e:
            results["steps"].append({"step": "Stop Ollama", "status": "FAIL", "error": str(e)})
            return results
    else:
        results["steps"].append({"step": "Stop Ollama", "status": "OK", "note": "was not running"})

    # Step 3: Relaunch Ollama
    try:
        _launch_ollama()
        _wait_for_ollama()
        results["steps"].append({"step": "Start Ollama", "status": "OK"})
    except Exception as e:
        results["steps"].append({"step": "Start Ollama", "status": "FAIL", "error": str(e)})
        return results

    # Step 4: Verify GPU
    verification = _verify_gpu_after_fix()
    if verification.get("verified"):
        results["steps"].append({
            "step": "Verify GPU",
            "status": "OK",
            "vram": f"{verification['vram_used_gb']}/{verification['vram_total_gb']} GB ({verification['vram_pct']}%)",
            "model": verification.get("model"),
        })
        results["success"] = True
    else:
        results["steps"].append({
            "step": "Verify GPU",
            "status": "FAIL",
            "error": verification.get("reason", "Unknown"),
        })

    return results
