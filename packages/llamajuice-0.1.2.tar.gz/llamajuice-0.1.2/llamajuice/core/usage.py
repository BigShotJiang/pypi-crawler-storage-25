"""Usage tracker — log requests and learn usage patterns.

Stores every request timestamp + model + response time in SQLite.
Analyzes patterns to recommend adaptive keep_alive values.

Data lives in ~/.llamajuice/usage.db
"""

from __future__ import annotations

import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

USAGE_DB = Path.home() / ".llamajuice" / "usage.db"


def _get_db() -> sqlite3.Connection:
    """Get or create the usage database."""
    USAGE_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(USAGE_DB))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL NOT NULL,
            model TEXT NOT NULL,
            task_type TEXT,
            response_time_ms REAL,
            tokens_generated INTEGER,
            hour_of_day INTEGER,
            day_of_week INTEGER
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_requests_model_time
        ON requests(model, timestamp)
    """)
    conn.commit()
    return conn


def log_request(
    model: str,
    task_type: str = "unknown",
    response_time_ms: float = 0,
    tokens_generated: int = 0,
) -> None:
    """Log a single request to the usage database."""
    now = datetime.now()
    conn = _get_db()
    conn.execute(
        """INSERT INTO requests
           (timestamp, model, task_type, response_time_ms, tokens_generated,
            hour_of_day, day_of_week)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            time.time(),
            model,
            task_type,
            response_time_ms,
            tokens_generated,
            now.hour,
            now.weekday(),  # 0=Monday
        ),
    )
    conn.commit()
    conn.close()


@dataclass
class ModelUsageStats:
    model: str
    total_requests: int
    avg_gap_minutes: float       # average time between requests
    p95_gap_minutes: float       # 95th percentile gap
    peak_hours: list[int]        # hours with most usage
    avg_response_ms: float
    last_used: float             # timestamp
    requests_last_hour: int
    requests_last_24h: int


def get_usage_stats(model: str, days: int = 7) -> ModelUsageStats | None:
    """Get usage statistics for a model over the last N days."""
    conn = _get_db()
    cutoff = time.time() - (days * 86400)

    rows = conn.execute(
        """SELECT timestamp, response_time_ms, hour_of_day
           FROM requests
           WHERE model = ? AND timestamp > ?
           ORDER BY timestamp""",
        (model, cutoff),
    ).fetchall()
    conn.close()

    if len(rows) < 2:
        return None

    timestamps = [r[0] for r in rows]
    response_times = [r[1] for r in rows if r[1] > 0]
    hours = [r[2] for r in rows]

    # Calculate gaps between consecutive requests
    gaps = []
    for i in range(1, len(timestamps)):
        gap_min = (timestamps[i] - timestamps[i - 1]) / 60
        gaps.append(gap_min)

    gaps.sort()
    avg_gap = sum(gaps) / len(gaps)
    p95_idx = int(len(gaps) * 0.95)
    p95_gap = gaps[p95_idx] if p95_idx < len(gaps) else gaps[-1]

    # Peak hours
    hour_counts = defaultdict(int)
    for h in hours:
        hour_counts[h] += 1
    peak_hours = sorted(hour_counts, key=hour_counts.get, reverse=True)[:3]

    # Recent activity
    now = time.time()
    last_hour = sum(1 for t in timestamps if now - t < 3600)
    last_24h = sum(1 for t in timestamps if now - t < 86400)

    return ModelUsageStats(
        model=model,
        total_requests=len(rows),
        avg_gap_minutes=round(avg_gap, 1),
        p95_gap_minutes=round(p95_gap, 1),
        peak_hours=peak_hours,
        avg_response_ms=round(sum(response_times) / len(response_times), 1) if response_times else 0,
        last_used=timestamps[-1],
        requests_last_hour=last_hour,
        requests_last_24h=last_24h,
    )


def recommend_keep_alive(model: str, role: str = "primary") -> str:
    """Recommend a keep_alive value based on actual usage patterns.

    Logic:
    - If avg gap < 5 min: user is actively using it → pin it (-1)
    - If avg gap < 30 min: frequent use → keep warm (30m)
    - If avg gap < 2 hours: occasional use → moderate TTL (10m)
    - If avg gap > 2 hours or no data: on-demand (5m)

    For router/small models: always pin (they're cheap).
    For STT/TTS: always on-demand (they're expensive and intermittent).
    """
    # Small models are always cheap to keep loaded
    if role == "router":
        return "-1"

    # STT/TTS are always on-demand regardless of usage
    if role in ("stt", "tts"):
        return "90s"

    stats = get_usage_stats(model)

    if stats is None:
        # No usage data yet — use conservative defaults
        if role == "primary":
            return "10m"
        return "5m"

    # Active right now? Pin it.
    if stats.requests_last_hour > 5:
        return "-1"

    # Adapt based on average gap
    if stats.avg_gap_minutes < 5:
        return "-1"      # very active — keep loaded
    elif stats.avg_gap_minutes < 15:
        return "30m"     # frequent — long warm period
    elif stats.avg_gap_minutes < 60:
        return "15m"     # moderate — medium warm
    elif stats.avg_gap_minutes < 120:
        return "10m"     # occasional
    else:
        return "5m"      # rare — short TTL


def get_all_model_stats(days: int = 7) -> list[ModelUsageStats]:
    """Get usage stats for all tracked models."""
    conn = _get_db()
    models = conn.execute(
        "SELECT DISTINCT model FROM requests WHERE timestamp > ?",
        (time.time() - days * 86400,),
    ).fetchall()
    conn.close()

    stats = []
    for (model,) in models:
        s = get_usage_stats(model, days)
        if s:
            stats.append(s)

    return sorted(stats, key=lambda s: s.total_requests, reverse=True)
