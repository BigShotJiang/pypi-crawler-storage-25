"""Server flag presets based on VRAM tier."""

from __future__ import annotations

from dataclasses import dataclass, field

from llamajuice.core.gpu import GPUInfo


@dataclass
class ServerFlags:
    ngl: int = 99
    ctx_size: int = 8192
    flash_attn: bool = True
    batch_size: int = 512
    threads: int = 0  # 0 = let llama-server auto-detect
    parallel: int = 1
    extra: list[str] = field(default_factory=list)

    def to_args(self) -> list[str]:
        args = [
            "--n-gpu-layers", str(self.ngl),
            "--ctx-size", str(self.ctx_size),
            "--batch-size", str(self.batch_size),
            "--parallel", str(self.parallel),
            "--flash-attn", "on" if self.flash_attn else "off",
        ]
        if self.threads > 0:
            args.extend(["--threads", str(self.threads)])
        args.extend(self.extra)
        return args


PRESETS: dict[str, ServerFlags] = {
    "8gb": ServerFlags(
        ngl=99,
        ctx_size=8192,
        batch_size=512,
        parallel=1,
    ),
    "12gb": ServerFlags(
        ngl=99,
        ctx_size=16384,
        batch_size=512,
        parallel=1,
    ),
    "16gb": ServerFlags(
        ngl=99,
        ctx_size=32768,
        batch_size=1024,
        parallel=2,
    ),
    "24gb": ServerFlags(
        ngl=99,
        ctx_size=65536,
        batch_size=2048,
        parallel=4,
    ),
    "code": ServerFlags(
        ngl=99,
        ctx_size=4096,
        batch_size=512,
        parallel=4,
    ),
}


def select_preset(gpu: GPUInfo) -> tuple[str, ServerFlags]:
    """Auto-select the best preset for the given GPU's VRAM."""
    vram = gpu.vram_total_gb
    if vram > 20:
        name = "24gb"
    elif vram > 14:
        name = "16gb"
    elif vram > 10:
        name = "12gb"
    else:
        name = "8gb"
    return name, PRESETS[name]
