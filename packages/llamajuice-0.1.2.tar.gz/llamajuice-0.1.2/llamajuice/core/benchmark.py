"""juice bench — benchmark local LLM performance on YOUR hardware.

Measures what actually matters for agent workloads:
  - tok/s: raw generation speed
  - TTFT: time to first token (responsiveness)
  - VRAM: actual GPU memory usage during generation
  - Tool calls: does the model produce valid tool call JSON?
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

import httpx

from llamajuice.core.gpu import GPUInfo, detect_gpu

# Standard benchmark prompts — same across all runs for comparability
BENCH_PROMPT = (
    "Explain how a hash table works internally. "
    "Cover collision resolution, load factors, and amortized O(1) complexity. "
    "Be concise but technical."
)

TOOL_CALL_PROMPT = "What is the weather in London right now?"

TOOL_DEFINITION = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather for a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name"},
                },
                "required": ["city"],
            },
        },
    }
]


@dataclass
class BenchResult:
    server_name: str
    base_url: str
    model: str
    tok_per_sec: float
    ttft_ms: float
    prompt_tokens: int
    completion_tokens: int
    vram_used_gb: float
    vram_total_gb: float
    vram_pct: int
    tool_call_pass: bool | None  # None = not tested
    tool_call_error: str | None = None
    runs: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "server": self.server_name,
            "base_url": self.base_url,
            "model": self.model,
            "tok_per_sec": round(self.tok_per_sec, 1),
            "ttft_ms": round(self.ttft_ms),
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "vram_used_gb": self.vram_used_gb,
            "vram_total_gb": self.vram_total_gb,
            "vram_pct": self.vram_pct,
            "tool_call_pass": self.tool_call_pass,
            "tool_call_error": self.tool_call_error,
            "runs": self.runs,
        }


def _detect_model(base_url: str) -> str | None:
    """Try to detect the loaded model name from the server."""
    try:
        resp = httpx.get(f"{base_url}/models", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            models = data.get("data", [])
            if models:
                return models[0].get("id", "unknown")
    except Exception:
        pass
    return None


def _run_generation(base_url: str, model: str, max_tokens: int = 200) -> dict:
    """Run a single generation benchmark and return timing data."""
    start = time.perf_counter()
    first_token_time = None

    # Use streaming to measure TTFT
    tokens_received = 0
    full_content = ""

    with httpx.stream(
        "POST",
        f"{base_url}/chat/completions",
        json={
            "model": model,
            "messages": [{"role": "user", "content": BENCH_PROMPT}],
            "max_tokens": max_tokens,
            "stream": True,
        },
        timeout=120,
    ) as resp:
        resp.raise_for_status()
        for line in resp.iter_lines():
            if not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                break
            try:
                chunk = json.loads(data_str)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content", "")
                if content and first_token_time is None:
                    first_token_time = time.perf_counter()
                if content:
                    tokens_received += 1
                    full_content += content
            except json.JSONDecodeError:
                continue

    end = time.perf_counter()
    elapsed = end - start
    ttft = (first_token_time - start) if first_token_time else elapsed

    # Get accurate token count from a non-streaming call for the same content length
    # (streaming doesn't always give us usage stats)
    tok_per_sec = tokens_received / elapsed if elapsed > 0 else 0

    return {
        "elapsed_s": round(elapsed, 2),
        "ttft_ms": round(ttft * 1000),
        "tokens": tokens_received,
        "tok_per_sec": round(tok_per_sec, 1),
    }


def _run_tool_call_test(base_url: str, model: str) -> tuple[bool, str | None]:
    """Test if the model produces valid tool call JSON."""
    try:
        resp = httpx.post(
            f"{base_url}/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "user", "content": TOOL_CALL_PROMPT}],
                "tools": TOOL_DEFINITION,
                "tool_choice": "auto",
                "max_tokens": 200,
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()

        choice = data.get("choices", [{}])[0]
        message = choice.get("message", {})
        tool_calls = message.get("tool_calls", [])

        if not tool_calls:
            return False, "No tool calls returned"

        tc = tool_calls[0]
        fn = tc.get("function", {})
        name = fn.get("name", "")
        args_str = fn.get("arguments", "")

        if name != "get_weather":
            return False, f"Wrong function name: {name}"

        try:
            args = json.loads(args_str)
        except json.JSONDecodeError:
            return False, f"Invalid JSON args: {args_str}"

        if "city" not in args:
            return False, f"Missing 'city' in args: {args}"

        return True, None

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 400:
            return False, "Server returned 400 (tools may not be supported)"
        return False, str(e)
    except Exception as e:
        return False, str(e)


def bench_server(
    base_url: str,
    server_name: str = "server",
    model: str | None = None,
    runs: int = 3,
    test_tools: bool = True,
) -> BenchResult:
    """Run benchmark against an OpenAI-compatible server.

    Args:
        base_url: e.g. "http://localhost:8080/v1"
        server_name: label for output
        model: model name (auto-detected if None)
        runs: number of generation runs (first discarded as warmup)
        test_tools: whether to test tool calling
    """
    if model is None:
        model = _detect_model(base_url) or "default"

    # Warmup + benchmark runs
    all_runs = []
    for i in range(runs):
        result = _run_generation(base_url, model)
        result["run"] = i + 1
        result["warmup"] = i == 0
        all_runs.append(result)

    # Average over non-warmup runs
    bench_runs = [r for r in all_runs if not r["warmup"]]
    avg_tps = sum(r["tok_per_sec"] for r in bench_runs) / len(bench_runs)
    avg_ttft = sum(r["ttft_ms"] for r in bench_runs) / len(bench_runs)
    total_prompt = bench_runs[0].get("prompt_tokens", 0)
    total_completion = sum(r["tokens"] for r in bench_runs) // len(bench_runs)

    # VRAM snapshot
    try:
        gpu = detect_gpu()
        vram_used = gpu.vram_used_gb
        vram_total = gpu.vram_total_gb
        vram_pct = gpu.vram_pct
    except Exception:
        vram_used = 0
        vram_total = 0
        vram_pct = 0

    # Tool call test
    tool_pass = None
    tool_error = None
    if test_tools:
        tool_pass, tool_error = _run_tool_call_test(base_url, model)

    return BenchResult(
        server_name=server_name,
        base_url=base_url,
        model=model,
        tok_per_sec=avg_tps,
        ttft_ms=avg_ttft,
        prompt_tokens=total_prompt,
        completion_tokens=total_completion,
        vram_used_gb=vram_used,
        vram_total_gb=vram_total,
        vram_pct=vram_pct,
        tool_call_pass=tool_pass,
        tool_call_error=tool_error,
        runs=all_runs,
    )


def detect_and_bench_competitors() -> list[BenchResult]:
    """Detect running servers and benchmark them all."""
    servers = [
        ("llamajuice", "http://localhost:8080/v1", "/health"),
        ("Ollama", "http://localhost:11434/v1", "http://localhost:11434/api/tags"),
        ("LM Studio", "http://localhost:1234/v1", "http://localhost:1234/v1/models"),
    ]

    results = []
    for name, base_url, health_url in servers:
        try:
            # Check if server is running
            check_url = health_url if health_url.startswith("http") else f"{base_url.rsplit('/v1')[0]}{health_url}"
            resp = httpx.get(check_url, timeout=3)
            if resp.status_code != 200:
                continue
        except (httpx.ConnectError, httpx.TimeoutException):
            continue

        # Check if a model is loaded
        model = _detect_model(base_url)
        if not model:
            continue

        try:
            result = bench_server(base_url, server_name=name, model=model)
            results.append(result)
        except Exception:
            continue

    return results


def format_shareable(results: list[BenchResult], gpu: GPUInfo | None = None) -> str:
    """Format results as a shareable one-liner for Reddit/Discord."""
    parts = []
    for r in results:
        tool_str = "tools:pass" if r.tool_call_pass else "tools:FAIL"
        if r.tool_call_pass is None:
            tool_str = "tools:n/a"
        parts.append(
            f"{r.server_name}: {r.tok_per_sec:.0f} tok/s / "
            f"{r.ttft_ms:.0f}ms TTFT / "
            f"{r.vram_pct}% GPU / {tool_str}"
        )

    gpu_str = f" on {gpu.name}" if gpu else ""
    return f"{' -- '.join(parts)}{gpu_str}"
