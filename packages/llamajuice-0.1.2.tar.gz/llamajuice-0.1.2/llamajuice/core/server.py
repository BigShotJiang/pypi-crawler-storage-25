"""GPUServer — launch llama-server with verified GPU offload."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import httpx

from llamajuice.core.gpu import GPUError, GPUInfo, assert_gpu_utilised, detect_gpu
from llamajuice.core.presets import PRESETS, ServerFlags, select_preset

LLAMAJUICE_HOME = Path.home() / ".llamajuice"
BIN_DIR = LLAMAJUICE_HOME / "bin"

# Pinned llama-server version — bump this to upgrade the binary
LLAMA_SERVER_VERSION = "b8604"


def _find_binary() -> Path:
    """Locate the llama-server binary."""
    if sys.platform == "win32":
        name = "llama-server.exe"
    else:
        name = "llama-server"

    path = BIN_DIR / name
    if path.exists():
        return path

    raise GPUError(
        f"llama-server binary not found at {path}. "
        f"Run 'juice setup' or 'python -m llamajuice.scripts.download_server' to download it."
    )


class GPUServer:
    """Launch and manage a llama-server process with GPU verification."""

    def __init__(
        self,
        model_path: str | Path,
        port: int = 8080,
        preset: str | None = None,
        flags: ServerFlags | None = None,
        gpu_index: int = 0,
        verify_gpu: bool = True,
    ):
        self.model_path = Path(model_path)
        self.port = port
        self.gpu_index = gpu_index
        self.verify_gpu = verify_gpu
        self._process: subprocess.Popen | None = None

        # Detect GPU and resolve preset
        self.gpu = detect_gpu(gpu_index)
        if flags is not None:
            self.flags = flags
            self.preset_name = "custom"
        elif preset and preset in PRESETS:
            self.preset_name = preset
            self.flags = PRESETS[preset]
        else:
            self.preset_name, self.flags = select_preset(self.gpu)

    @property
    def base_url(self) -> str:
        return f"http://localhost:{self.port}/v1"

    @property
    def health_url(self) -> str:
        return f"http://localhost:{self.port}/health"

    def _build_command(self) -> list[str]:
        binary = _find_binary()
        cmd = [
            str(binary),
            "--model", str(self.model_path),
            "--port", str(self.port),
            *self.flags.to_args(),
        ]
        return cmd

    def _wait_for_health(self, timeout: float = 120) -> None:
        """Poll /health until the server is ready."""
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            try:
                resp = httpx.get(self.health_url, timeout=2)
                if resp.status_code == 200:
                    return
            except httpx.ConnectError:
                pass
            except httpx.TimeoutException:
                pass
            time.sleep(0.5)
        raise GPUError(f"Server failed to become healthy within {timeout}s.")

    def launch_background(self, verbose: bool = False) -> subprocess.Popen:
        """Launch llama-server and return immediately after health check."""
        cmd = self._build_command()

        if verbose:
            stdout = None
            stderr = None
        else:
            stdout = subprocess.DEVNULL
            stderr = subprocess.PIPE

        # On Windows, ensure CUDA DLLs in BIN_DIR are found by the binary
        env = os.environ.copy()
        if sys.platform == "win32":
            env["PATH"] = str(BIN_DIR) + os.pathsep + env.get("PATH", "")

        self._process = subprocess.Popen(
            cmd,
            stdout=stdout,
            stderr=stderr,
            env=env,
        )

        try:
            self._wait_for_health()
        except GPUError:
            self.stop()
            raise

        if self.verify_gpu:
            try:
                self.gpu = assert_gpu_utilised(self.gpu)
            except GPUError:
                self.stop()
                raise

        return self._process

    def launch(self, verbose: bool = False) -> None:
        """Launch llama-server and block until Ctrl+C."""
        self.launch_background(verbose=verbose)

        def _shutdown(signum, frame):
            self.stop()
            sys.exit(0)

        signal.signal(signal.SIGINT, _shutdown)
        signal.signal(signal.SIGTERM, _shutdown)

        try:
            self._process.wait()
        except KeyboardInterrupt:
            self.stop()

    def stop(self) -> None:
        """Stop the llama-server process."""
        if self._process is None:
            return
        try:
            self._process.terminate()
            self._process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self._process.kill()
            self._process.wait()
        self._process = None

    @staticmethod
    def detect() -> GPUServer | None:
        """Detect a running llamajuice server on the default port."""
        try:
            resp = httpx.get("http://localhost:8080/health", timeout=2)
            if resp.status_code == 200:
                # Server is running but we don't know its config
                return None  # TODO: return a connected GPUServer instance
        except (httpx.ConnectError, httpx.TimeoutException):
            pass
        return None
