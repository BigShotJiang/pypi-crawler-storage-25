"""
llamajuice Reddit Scanner — Find posts where developers are struggling with
local LLM GPU issues, model performance, or tool calling reliability.
Generates helpful replies (not spam — lead with value, link naturally).

Reuses pattern from BlindKey reddit-scan.py.

Usage:
    python scripts/reddit-scan.py [--limit 30]

Requires:
    REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET in environment or .env
"""

import os
import re
import json
import requests
from datetime import datetime
from pathlib import Path
from typing import List, Dict

# Try loading creds from .env or BlindKey's Unleashed .env
for env_path in [
    Path(__file__).parent.parent / ".env",
    Path(__file__).parent.parent.parent / "Unleashed" / ".env",
]:
    if env_path.exists():
        try:
            from dotenv import load_dotenv
            load_dotenv(env_path)
        except ImportError:
            pass
        break

REDDIT_CLIENT_ID = os.getenv("REDDIT_CLIENT_ID", "")
REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET", "")
REDDIT_USER_AGENT = os.getenv("REDDIT_USER_AGENT", "LlamaJuiceScanner/1.0")

# Subreddits where local LLM devs hang out
TARGET_SUBREDDITS = [
    "LocalLLaMA",
    "ollama",
    "LMStudio",
    "selfhosted",
    "MachineLearning",
    "ClaudeAI",
    "ChatGPT",
    "LanguageTechnology",
    "nvidia",
    "buildapc",
]

# Keywords that signal someone struggling with local LLM GPU issues
KEYWORDS = [
    # GPU detection / offload failures
    r"gpu.*not.*detect",
    r"gpu.*not.*used",
    r"gpu.*offload.*fail",
    r"cpu.*fallback",
    r"running.*on.*cpu",
    r"vram.*not.*used",
    r"vram.*0",
    r"gpu.*utiliz.*low",
    r"nvidia-smi.*0.*MiB",
    r"cuda.*not.*found",
    r"cuda.*visible.*devices",
    # Ollama-specific
    r"ollama.*slow",
    r"ollama.*cpu",
    r"ollama.*gpu.*not",
    r"ollama.*performance",
    r"ollama.*tok.*s",
    r"ollama.*speed",
    # LM Studio
    r"lm.?studio.*gpu",
    r"lm.?studio.*offload",
    r"lm.?studio.*slow",
    # RTX 50-series specific
    r"rtx.*50[5-9]0",
    r"blackwell.*ollama",
    r"blackwell.*gpu",
    r"5050.*gpu",
    r"5060.*gpu",
    r"5070.*gpu",
    # Tool calling issues
    r"tool.*call.*broken",
    r"tool.*call.*fail",
    r"function.*call.*broken",
    r"json.*malform",
    r"structured.*output.*fail",
    # Performance / optimization
    r"local.*llm.*slow",
    r"tok.*per.*sec",
    r"token.*speed",
    r"inference.*speed",
    r"model.*too.*slow",
    r"how.*fast.*should",
    # Multi-model / routing
    r"multiple.*model",
    r"model.*routing",
    r"small.*model.*fast",
    r"switch.*between.*model",
]

OUTPUT_DIR = Path(__file__).parent.parent / "data"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def fetch_posts(subreddit: str, limit: int = 30, sort: str = "new") -> List[Dict]:
    """Fetch posts using PRAW or public JSON API fallback."""
    posts = []

    if REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET:
        try:
            import praw
            reddit = praw.Reddit(
                client_id=REDDIT_CLIENT_ID,
                client_secret=REDDIT_CLIENT_SECRET,
                user_agent=REDDIT_USER_AGENT
            )
            sub = reddit.subreddit(subreddit)
            submissions = sub.new(limit=limit) if sort == "new" else sub.hot(limit=limit)

            for s in submissions:
                posts.append({
                    "id": s.id,
                    "title": s.title,
                    "selftext": s.selftext[:3000] if s.selftext else "",
                    "score": s.score,
                    "num_comments": s.num_comments,
                    "created_utc": s.created_utc,
                    "url": f"https://reddit.com{s.permalink}",
                    "author": str(s.author) if s.author else "[deleted]",
                    "subreddit": subreddit,
                })
            return posts
        except Exception as e:
            print(f"  PRAW failed for r/{subreddit}: {e}")

    # Fallback: public JSON API
    try:
        url = f"https://www.reddit.com/r/{subreddit}/{sort}.json?limit={limit}"
        headers = {"User-Agent": REDDIT_USER_AGENT}
        resp = requests.get(url, headers=headers, timeout=15)

        if resp.status_code == 200:
            data = resp.json()
            for child in data.get("data", {}).get("children", []):
                p = child.get("data", {})
                posts.append({
                    "id": p.get("id"),
                    "title": p.get("title", ""),
                    "selftext": p.get("selftext", "")[:3000],
                    "score": p.get("score", 0),
                    "num_comments": p.get("num_comments", 0),
                    "created_utc": p.get("created_utc", 0),
                    "url": f"https://reddit.com{p.get('permalink', '')}",
                    "author": p.get("author", "[deleted]"),
                    "subreddit": subreddit,
                })
        elif resp.status_code == 403:
            print(f"  r/{subreddit}: private or quarantined (403)")
        else:
            print(f"  r/{subreddit}: HTTP {resp.status_code}")

    except Exception as e:
        print(f"  JSON API failed for r/{subreddit}: {e}")

    return posts


def score_relevance(post: Dict) -> float:
    """Score a post's relevance to llamajuice's value prop (0-100)."""
    text = (post["title"] + " " + post["selftext"]).lower()
    score = 0.0

    for pattern in KEYWORDS:
        matches = len(re.findall(pattern, text, re.IGNORECASE))
        if matches:
            score += 10 * matches

    # Boost for engagement
    if post["score"] > 50:
        score += 10
    if post["score"] > 200:
        score += 10
    if post["num_comments"] > 20:
        score += 10
    if post["num_comments"] > 50:
        score += 15

    # Boost for recency
    age_days = (datetime.now().timestamp() - post["created_utc"]) / 86400
    if age_days < 1:
        score += 20
    elif age_days < 3:
        score += 10
    elif age_days < 7:
        score += 5

    return min(score, 100)


def generate_reply(post: Dict) -> str:
    """Generate a helpful reply based on the post content. Lead with value."""
    text = (post["title"] + " " + post["selftext"]).lower()

    # GPU not detected / CPU fallback
    if re.search(r"gpu.*not.*detect|cpu.*fallback|running.*on.*cpu|vram.*not.*used|vram.*0|gpu.*offload.*fail", text, re.IGNORECASE):
        return (
            "Had this exact issue on an RTX 5050 — spent 3 hours before finding that "
            "CUDA_VISIBLE_DEVICES=0 was needed. On the 50-series, Ollama can report 0 VRAM "
            "without it.\n\n"
            "I ended up building a diagnostic tool that catches this and 15 other common "
            "setup issues in one command:\n\n"
            "  pip install llamajuice && juice doctor\n\n"
            "It checks GPU detection, CUDA env vars, which models support tool calling, "
            "Whisper dependencies, etc. Every warning includes the fix command.\n\n"
            "https://github.com/michaelkenealy/llamajuice"
        )

    # RTX 50-series specific
    if re.search(r"rtx.*50[5-9]0|blackwell|5050|5060|5070", text, re.IGNORECASE):
        return (
            "The 50-series needs CUDA_VISIBLE_DEVICES=0 set or Ollama reports 0 VRAM. "
            "This bit me for hours.\n\n"
            "Quick check: run `nvidia-smi` — if it shows your GPU but Ollama doesn't use it, "
            "run `setx CUDA_VISIBLE_DEVICES 0` (Windows) and restart your terminal.\n\n"
            "I built `juice doctor` to catch this automatically along with ~15 other "
            "common local LLM issues:\n\n"
            "  pip install llamajuice && juice doctor\n\n"
            "https://github.com/michaelkenealy/llamajuice"
        )

    # Ollama slow / performance
    if re.search(r"ollama.*slow|ollama.*speed|ollama.*tok|ollama.*performance|local.*llm.*slow|tok.*per.*sec|inference.*speed", text, re.IGNORECASE):
        return (
            "First thing to check: is it actually running on GPU? Run nvidia-smi while "
            "generating — if VRAM usage is low, your model is partially or fully on CPU.\n\n"
            "Common causes: CUDA_VISIBLE_DEVICES not set (especially 50-series), model "
            "too large for VRAM (silently falls back), or flash attention not enabled.\n\n"
            "I built a tool that diagnoses all of this:\n\n"
            "  pip install llamajuice && juice doctor\n\n"
            "Also has `juice bench` to measure actual tok/s and compare. "
            "https://github.com/michaelkenealy/llamajuice"
        )

    # Tool calling issues
    if re.search(r"tool.*call|function.*call|json.*malform|structured.*output", text, re.IGNORECASE):
        return (
            "Tool calling reliability varies a lot by model. Qwen2.5 and Llama 3.1 are "
            "solid, but Gemma, base Llama 3, and Phi don't support it at all.\n\n"
            "`juice doctor` checks which of your installed models actually support tool "
            "calling and warns you about the ones that don't. Also has `juice bench` which "
            "tests tool call round-trips on your hardware.\n\n"
            "  pip install llamajuice && juice doctor\n\n"
            "https://github.com/michaelkenealy/llamajuice"
        )

    # Multi-model / routing
    if re.search(r"multiple.*model|model.*routing|small.*model.*fast|switch.*between.*model", text, re.IGNORECASE):
        return (
            "This is what I'm doing with `juice combo` — a proxy that sits in front of "
            "Ollama and routes simple requests (greetings, yes/no) to a fast 1.5B model "
            "and complex requests (reasoning, tool calls) to a 7B. One endpoint, two models.\n\n"
            "On my 8GB RTX, the 1.5B responds almost instantly while the 7B handles the "
            "hard stuff. Your app just points at localhost:8080/v1.\n\n"
            "  pip install llamajuice && juice combo\n\n"
            "https://github.com/michaelkenealy/llamajuice"
        )

    # Generic performance / setup
    return (
        "If you're hitting GPU/performance issues with local LLMs, I built a diagnostic "
        "tool that catches the common problems:\n\n"
        "  pip install llamajuice && juice doctor\n\n"
        "Checks GPU detection, CUDA env vars, model tool-calling support, VRAM usage, "
        "Whisper dependencies — every warning includes the fix command. "
        "Also has benchmarking and multi-model routing.\n\n"
        "https://github.com/michaelkenealy/llamajuice"
    )


def main():
    import argparse
    parser = argparse.ArgumentParser(description="llamajuice Reddit Scanner")
    parser.add_argument("--limit", type=int, default=30, help="Posts per subreddit")
    args = parser.parse_args()

    print("=" * 60)
    print("llamajuice Reddit Scanner")
    print("=" * 60)

    all_posts = []

    for sub in TARGET_SUBREDDITS:
        print(f"\nScanning r/{sub}...")
        for sort in ["new", "hot"]:
            posts = fetch_posts(sub, limit=args.limit, sort=sort)
            all_posts.extend(posts)

    # Deduplicate by post ID
    seen_ids = set()
    unique_posts = []
    for p in all_posts:
        if p["id"] not in seen_ids:
            seen_ids.add(p["id"])
            unique_posts.append(p)

    print(f"\nFetched {len(unique_posts)} unique posts across {len(TARGET_SUBREDDITS)} subreddits")

    # Score and rank
    scored = []
    for post in unique_posts:
        relevance = score_relevance(post)
        if relevance > 0:
            post["relevance_score"] = relevance
            post["suggested_reply"] = generate_reply(post)
            scored.append(post)

    scored.sort(key=lambda x: x["relevance_score"], reverse=True)
    top_10 = scored[:10]

    # Display results
    print(f"\nFound {len(scored)} relevant posts. Top 10:\n")
    print("=" * 60)

    for i, post in enumerate(top_10, 1):
        age_days = (datetime.now().timestamp() - post["created_utc"]) / 86400
        age_str = f"{age_days:.0f}d ago" if age_days >= 1 else f"{age_days * 24:.0f}h ago"

        print(f"\n{'-' * 60}")
        print(f"#{i} | Score: {post['relevance_score']:.0f} | r/{post['subreddit']} | {age_str}")
        print(f"   {post['score']} upvotes | {post['num_comments']} comments")
        print(f"   {post['title'][:100]}")
        print(f"   {post['url']}")
        print(f"\n   SUGGESTED REPLY:")
        for line in post["suggested_reply"].split("\n"):
            print(f"   {line}")

    # Save to file
    output = {
        "scanned_at": datetime.now().isoformat(),
        "subreddits": TARGET_SUBREDDITS,
        "total_fetched": len(unique_posts),
        "relevant_found": len(scored),
        "top_posts": [
            {
                "rank": i + 1,
                "title": p["title"],
                "url": p["url"],
                "subreddit": p["subreddit"],
                "score": p["score"],
                "num_comments": p["num_comments"],
                "relevance_score": p["relevance_score"],
                "suggested_reply": p["suggested_reply"],
            }
            for i, p in enumerate(top_10)
        ],
    }

    out_file = OUTPUT_DIR / "reddit-llamajuice-scan.json"
    with open(out_file, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\n{'=' * 60}")
    print(f"Results saved to {out_file}")


if __name__ == "__main__":
    main()
