"""Download the correct pre-built llama-server binary for this platform."""

from __future__ import annotations

import re
import stat
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

import httpx
from tqdm import tqdm

from llamajuice.core.server import BIN_DIR, LLAMA_SERVER_VERSION

# llama.cpp GitHub releases
RELEASE_BASE = "https://github.com/ggml-org/llama.cpp/releases/download"


def _detect_cuda_tier() -> str | None:
    """Detect which CUDA build to use from nvidia-smi driver version.

    Driver >= 550 supports CUDA 12.4 builds.
    Older drivers get CPU fallback (no CUDA 12.1 builds available anymore).
    """
    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        match = re.search(r"Driver Version:\s+([\d.]+)", result.stdout)
        if not match:
            return None

        driver = int(match.group(1).split(".")[0])
        if driver >= 550:
            return "cuda-12.4"
        else:
            return None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _get_asset_info() -> tuple[str, str, str]:
    """Return (asset_filename, binary_name_inside, archive_type) for this platform.

    Naming convention (as of b8604):
      Windows CUDA:  llama-{ver}-bin-win-cuda-12.4-x64.zip
      Windows CPU:   llama-{ver}-bin-win-cpu-x64.zip
      Linux:         llama-{ver}-bin-ubuntu-x64.tar.gz  (no CUDA suffix on Linux)
    """
    cuda = _detect_cuda_tier()
    ver = LLAMA_SERVER_VERSION

    if sys.platform == "win32":
        binary_name = "llama-server.exe"
        if cuda:
            asset = f"llama-{ver}-bin-win-{cuda}-x64.zip"
        else:
            print("WARNING: No compatible CUDA detected. Downloading CPU build.")
            print("         Performance will be severely limited.")
            asset = f"llama-{ver}-bin-win-cpu-x64.zip"
        return asset, binary_name, "zip"
    else:
        binary_name = "llama-server"
        if not cuda:
            print("WARNING: No compatible CUDA detected. Downloading CPU build.")
            print("         Performance will be severely limited.")
        # Linux builds don't have CUDA suffix -- CUDA support is via separate cudart package
        asset = f"llama-{ver}-bin-ubuntu-x64.tar.gz"
        return asset, binary_name, "tar.gz"


def _download_cudart_windows() -> None:
    """Download the CUDA runtime DLLs needed on Windows."""
    cuda = _detect_cuda_tier()
    if not cuda:
        return

    asset = f"cudart-llama-bin-win-{cuda}-x64.zip"
    url = f"{RELEASE_BASE}/{LLAMA_SERVER_VERSION}/{asset}"

    print(f"  Downloading CUDA runtime ({asset})...")

    zip_path = BIN_DIR / asset
    try:
        with httpx.stream("GET", url, follow_redirects=True, timeout=30) as resp:
            resp.raise_for_status()
            with open(zip_path, "wb") as f:
                for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                    f.write(chunk)

        with zipfile.ZipFile(zip_path) as zf:
            for name in zf.namelist():
                if name.endswith(".dll"):
                    data = zf.read(name)
                    # Extract just the filename, not nested paths
                    dll_name = Path(name).name
                    (BIN_DIR / dll_name).write_bytes(data)

        zip_path.unlink()
    except Exception as e:
        print(f"  Warning: could not download CUDA runtime: {e}")
        if zip_path.exists():
            zip_path.unlink()


def download_server(force: bool = False) -> Path:
    """Download llama-server binary. Returns path to the binary."""
    if sys.platform == "win32":
        dest = BIN_DIR / "llama-server.exe"
    else:
        dest = BIN_DIR / "llama-server"

    if dest.exists() and not force:
        print(f"llama-server already exists at {dest}")
        return dest

    BIN_DIR.mkdir(parents=True, exist_ok=True)
    asset, binary_name, archive_type = _get_asset_info()
    url = f"{RELEASE_BASE}/{LLAMA_SERVER_VERSION}/{asset}"

    print(f"Downloading llama-server {LLAMA_SERVER_VERSION}...")
    print(f"  Asset: {asset}")

    archive_path = BIN_DIR / asset

    with httpx.stream("GET", url, follow_redirects=True, timeout=30) as resp:
        resp.raise_for_status()
        total = int(resp.headers.get("content-length", 0))

        with open(archive_path, "wb") as f, tqdm(
            total=total,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
            desc="llama-server",
            ascii=True,
        ) as bar:
            for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                f.write(chunk)
                bar.update(len(chunk))

    # Extract all files from the archive into BIN_DIR
    if archive_type == "zip":
        with zipfile.ZipFile(archive_path) as zf:
            found_binary = False
            for name in zf.namelist():
                # Skip directories
                if name.endswith("/"):
                    continue
                filename = Path(name).name
                if not filename:
                    continue
                # Extract all .exe and .dll files (Windows) or executables and .so files (Linux)
                if filename.endswith((".exe", ".dll", ".so")) or filename == binary_name:
                    data = zf.read(name)
                    (BIN_DIR / filename).write_bytes(data)
                    if filename == binary_name:
                        found_binary = True
            if not found_binary:
                raise FileNotFoundError(
                    f"Could not find {binary_name} in {asset}. "
                    f"Contents: {zf.namelist()[:20]}"
                )
    else:
        with tarfile.open(archive_path, "r:gz") as tf:
            found_binary = False
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                filename = Path(member.name).name
                if not filename:
                    continue
                if filename.endswith((".so",)) or filename == binary_name:
                    extracted = tf.extractfile(member)
                    if extracted:
                        (BIN_DIR / filename).write_bytes(extracted.read())
                        if filename == binary_name:
                            found_binary = True
            if not found_binary:
                raise FileNotFoundError(
                    f"Could not find {binary_name} in {asset}. "
                    f"Contents: {[m.name for m in tf.getmembers()[:20]]}"
                )

    # Make executable on Linux
    if sys.platform != "win32":
        dest.chmod(dest.stat().st_mode | stat.S_IEXEC)

    # Clean up archive
    archive_path.unlink()

    # On Windows, also grab CUDA runtime DLLs
    if sys.platform == "win32":
        _download_cudart_windows()

    print(f"  Installed to {dest}")
    return dest


if __name__ == "__main__":
    download_server(force="--force" in sys.argv)
