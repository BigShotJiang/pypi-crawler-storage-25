# Juice Roadmap

> Born from real pain: 4 days of GPU detection failures, model incompatibilities, context overflows, and streaming bugs while building an AI agent (Juggler) on an RTX 5050 8GB laptop.

Every developer running local LLMs for agents hits the same wall. Juice is the "it just works" layer between your app and the model runtime.

---

## What Exists Today (v0.1)

| Command | Status | What it does |
|---------|--------|-------------|
| `juice status` | Working | Detects GPU, VRAM, driver, running servers (Ollama, LM Studio) |
| `juice models` | Working | Scans LM Studio + Ollama for your locally installed GGUFs |
| `juice setup` | Working | Downloads llama-server binary with correct CUDA build (all DLLs) |
| `juice serve <model>` | Working | Fuzzy-matches local models, launches llama-server with full GPU offload, verifies health |
| `juice recommend` | Working | Suggests tested models for your VRAM tier with HuggingFace links |

Architecture: Juice doesn't download or manage models. It finds what you already have (LM Studio, Ollama) and serves it with optimal GPU flags. Tested on RTX 5050 8GB with Phi-4-mini, DeepSeek-R1-Qwen3-8B, and others.

---

## Phase 1: Doctor & Diagnostics (highest value, lowest effort)

### `juice doctor`
One command that catches every issue we spent days debugging.

```
$ juice doctor
GPU:     RTX 5050 8GB                          OK
CUDA:    12.8                                  OK
Driver:  572.97                                OK
Ollama:  running, GPU detected                 OK
         CUDA_VISIBLE_DEVICES=0 set            OK
         gemma3:4b loaded                      WARN — no tool calling support
         qwen2.5:7b available                  OK — supports tool calling
Model:   qwen2.5:7b fits in 8GB               OK (4.7GB model + 1.5GB KV cache)
Context: 8192 tokens                           OK (system prompt ~3K + 6 turns fits)
Tools:   10 tools defined, model supports fn   OK
Whisper: faster-whisper installed              OK
         cuBLAS DLL found                      OK
         ffmpeg found                          OK
```

Checks to implement:
- [ ] GPU detection + VRAM available
- [ ] CUDA_VISIBLE_DEVICES set (critical for RTX 50-series)
- [ ] Ollama/LM Studio/llama-server running
- [ ] Active model supports tool calling (query Ollama API with a test tool)
- [ ] Model fits in VRAM (model size + estimated KV cache for target context)
- [ ] Context length won't overflow (estimate system prompt + tool definitions + N turns)
- [ ] Whisper dependencies (faster-whisper, cuBLAS DLLs on PATH, ffmpeg)
- [ ] Print actionable fix for every failure

**Why this is #1 priority:** Every other feature assumes the stack is healthy. Doctor is the foundation.

---

### `juice compat <model>`
Answer: "Will this model work for my agent?"

```
$ juice compat qwen2.5:7b
  Tool calling:     YES (verified against Ollama)
  VRAM fit:         YES (4.7GB model + 1.5GB KV @ 8192 ctx = 6.2GB < 8.0GB)
  Available on:     Ollama (qwen2.5:7b), HuggingFace GGUF
  Streaming tools:  FRAGILE — recommend non-streaming for agents
  Thinking tags:    No
  Recommended for:  Agent tool calling, structured JSON output

$ juice compat gemma3:4b
  Tool calling:     NO (not supported on Ollama)
  Suggestion:       Use qwen2.5:7b or qwen2.5:1.5b instead

$ juice compat llama3
  Tool calling:     NO
  Suggestion:       Use llama3.1:8b (adds tool support) or qwen2.5:7b
```

Data source: maintain a local registry of model capabilities (tool calling, thinking tags, context limits, known issues). Update via `juice update-registry`.

---

## Phase 2: Environment & Configuration

### `juice env --for <project>`
Auto-generate `.env` for a project based on detected hardware + running servers.

```
$ juice env --for juggler
Scanning project... found server.py (FastAPI + LLM calls)
Detected: Ollama on :11434
Best tool-calling model (8GB): qwen2.5:7b (4.7GB)
Best intent model: qwen2.5:1.5b (1GB)
Whisper: faster-whisper available, cuBLAS OK

Writing .env:
  LLM_URL=http://localhost:11434
  LLM_MODEL=qwen2.5:7b
  INTENT_MODEL=qwen2.5:1.5b
  LLM_CONTEXT_LENGTH=8192
  CUDA_VISIBLE_DEVICES=0
  WHISPER_MODEL=medium
  FFMPEG_PATH=C:\Users\...\ffmpeg.exe
```

Project detection rules:
- Look for `.env`, `server.py`, `requirements.txt` to infer what the project needs
- Match against known patterns (Ollama URL, OpenAI-compatible URL, Whisper imports)
- Suggest optimal model for the use case (tool calling vs code vs chat)

### `juice fix-gpu`
Automated fix for the RTX 50-series GPU detection issue.

```
$ juice fix-gpu
Detected: RTX 5050 (Blackwell/sm_120 architecture)
Known issue: Ollama may report 0 VRAM on this GPU
Applying fix: CUDA_VISIBLE_DEVICES=0
  Set for current session       OK
  Set permanently (setx)        OK
  Restarting Ollama...          OK
  Verifying GPU detection...    8151MiB VRAM detected  OK
```

Also handles:
- Driver version too old for CUDA build
- Multiple GPUs (pick the right one)
- WSL2 GPU passthrough issues

---

## Phase 3: Benchmarking & Model Selection

### `juice bench <model>`
Quick performance test on YOUR hardware with YOUR use case.

```
$ juice bench qwen2.5:7b
Loading model...                    6.2s (first load)
Prompt processing (1K tokens):      342 tok/s (GPU)
Generation speed:                   28.4 tok/s
Tool calling test:                  PASS (correctly called add_task)
JSON output test:                   PASS (valid structured output)
Context overflow test (8192):       PASS
VRAM peak:                          6.1GB / 8.0GB
Estimated headroom:                 1.9GB (enough for Whisper medium)

Verdict: RECOMMENDED for agent workloads on your GPU
```

### `juice recommend --for <use-case>`
```
$ juice recommend --for agent-tool-calling --vram 8
Based on your RTX 5050 (8GB):

  #1  qwen2.5:7b        4.7GB  28 tok/s  Best tool calling accuracy
  #2  qwen2.5:1.5b      1.0GB  85 tok/s  Fast intent parser (pair with #1)
  #3  granite3.1:8b      4.9GB  24 tok/s  IBM tool-calling specialist

  Avoid: gemma3:4b (no tool support), llama3 (no tool support)

  Suggested combo: qwen2.5:7b (main) + qwen2.5:1.5b (intent) = 5.7GB peak
```

---

## Phase 4: Bridge Mode (Ollama wrapper)

### `juice serve --with-ollama`
Don't replace Ollama — wrap it. Juice ensures everything is correct before Ollama handles the request.

```
$ juice serve --with-ollama --model qwen2.5:7b --ctx 8192
  Checking Ollama...              running on :11434
  Checking GPU...                 RTX 5050, 8GB, CUDA_VISIBLE_DEVICES=0
  Pulling model if needed...      qwen2.5:7b already available
  Loading with context 8192...    OK (VRAM: 6.1GB used)
  Tool calling verified...        OK

  Ready. Your app connects to Ollama as normal (localhost:11434)
  Juice is monitoring: GPU health, model loaded, context limits
```

This is the "set and forget" mode — Juice runs alongside Ollama, monitors health, auto-restarts if needed, and logs issues.

---

## Phase 5: Model Download Fixes

### Fix sharded GGUF downloads
Current `juice serve` fails because HuggingFace splits large GGUFs into shards (e.g. `model-00001-of-00002.gguf`).

- [ ] Detect sharded models in HuggingFace API response
- [ ] Download all shards and let llama-server handle multi-file loading
- [ ] Or prefer single-file quantizations from community repos (e.g. `bartowski/`, `TheBloke/`)
- [ ] Add Ollama as a download backend (simpler, handles sharding automatically)

### Smart model resolution
```
$ juice serve qwen2.5-7b
  Checking local cache...          not found
  Checking Ollama...               qwen2.5:7b available, pulling...
  Loaded from Ollama               OK
```

Use Ollama's model library as primary source (reliable, single command), fall back to HuggingFace GGUF only for models not in Ollama's registry.

---

## Friction Log (from Juggler build, March 2026)

These are the actual problems hit during 4 days of development. Each one is a `juice doctor` check.

| Day | Problem | Time wasted | Juice fix |
|-----|---------|-------------|-----------|
| 1 | Ollama didn't detect RTX 5050 GPU, VRAM 0 | 3 hours | `juice fix-gpu` |
| 1 | llama3 doesn't support tool calling | 2 hours | `juice compat llama3` → "No tools" |
| 1 | gemma3:4b doesn't support tool calling | 1 hour | `juice compat gemma3:4b` → "No tools" |
| 2 | LM Studio server defaults to CPU, not GPU | 2 hours | `juice doctor` → "GPU offload not set" |
| 2 | LM Studio defaults context to 4096, overflow | 1 hour | `juice doctor` → "Context too small" |
| 2 | phi-4-mini-reasoning is a math model, wrong for EA | 1 hour | `juice compat phi-4-mini` → "Not for agents" |
| 3 | cuBLAS DLL not found for Whisper | 1 hour | `juice doctor` → "cuBLAS not on PATH" |
| 3 | ffmpeg missing for Telegram voice notes | 30 min | `juice doctor` → "ffmpeg not found" |
| 3 | Streaming SSE parsing fragile across models | 3 hours | `juice compat` → "Streaming tools fragile" |
| 4 | Multiple bot instances (409 Telegram conflict) | 30 min | Outside Juice scope |
| 4 | Model switching loads to CPU not GPU | 1 hour | `juice serve --with-ollama` manages this |

**Total time wasted on issues Juice would catch: ~16 hours**

---

## Target Users

1. **Solo devs building local AI agents** — like Juggler. They know Python, they have a GPU, but they don't want to debug CUDA driver issues for a week.
2. **Teams evaluating local LLMs** — "which model actually works for tool calling on our hardware?" `juice bench` answers this in 60 seconds.
3. **Projects with `.env` configuration** — any FastAPI/Flask/Node app that talks to a local LLM. `juice env` auto-configures it.

## Non-Goals (for now)

- Not a model training tool
- Not a cloud deployment tool
- Not a chat UI (use OpenWebUI, LM Studio, or build your own)
- Not a replacement for Ollama — a complement that makes it reliable
