use tempfile::TempDir;

use laurus::Engine;
use laurus::lexical::TermQuery;
use laurus::lexical::TextOption;
use laurus::storage::file::FileStorageConfig;
use laurus::storage::{StorageConfig, StorageFactory};
use laurus::vector::FlatOption;
use laurus::{DataValue, Document};
use laurus::{FieldOption, LexicalSearchQuery, Schema};

#[tokio::test(flavor = "multi_thread")]
async fn test_wal_recovery_uncommitted() -> laurus::Result<()> {
    // 1. Setup Storage
    let temp_dir = TempDir::new().unwrap();
    let storage_config = StorageConfig::File(FileStorageConfig::new(temp_dir.path()));
    let storage = StorageFactory::create(storage_config)?;

    // 2. Configure Config
    let vector_opt = FlatOption::default();
    let lexical_opt = TextOption::default();

    let config = Schema::builder()
        .add_field("title", FieldOption::Text(lexical_opt))
        .add_field("embedding", FieldOption::Flat(vector_opt))
        .build();

    // 3. Round 1: Index but DO NOT commit
    {
        let engine = Engine::new(storage.clone(), config.clone()).await?;

        // Initial state
        let query = Box::new(TermQuery::new("title", "rust"));
        let search_request = laurus::SearchRequestBuilder::new()
            .lexical_query(LexicalSearchQuery::Obj(query))
            .build();
        let search_results = engine.search(search_request).await?;
        assert_eq!(search_results.len(), 0);

        let doc1 = Document::builder()
            .add_field("title", DataValue::Text("Rust Programming".into()))
            .add_field("embedding", DataValue::Vector(vec![0.1; 128]))
            .build();

        engine.put_document("doc1", doc1).await?;

        // Drop engine WITHOUT commit
    }

    // 4. Round 2: Recover from WAL
    {
        // Re-open engine on SAME storage
        let engine = Engine::new(storage.clone(), config.clone()).await?;

        // Commit to ensure flushed to searchable index
        engine.commit().await?;

        // Should have recovered doc1 from WAL and now committed
        let query = Box::new(TermQuery::new("title", "rust"));
        let search_request = laurus::SearchRequestBuilder::new()
            .lexical_query(LexicalSearchQuery::Obj(query))
            .build();
        let search_results = engine.search(search_request).await?;
        assert_eq!(
            search_results.len(),
            1,
            "Document should be recovered from WAL"
        );
    }

    Ok(())
}
