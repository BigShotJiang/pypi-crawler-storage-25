"""Version information for gac package."""

__version__ = "3.32.3"
