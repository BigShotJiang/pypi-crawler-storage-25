"""agent-lsp: MCP server for language intelligence."""

__version__ = "0.8.1"
