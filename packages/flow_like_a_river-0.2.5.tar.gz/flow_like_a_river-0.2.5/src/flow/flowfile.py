"""Flow YAML parsing, rendering, and validation."""

from __future__ import annotations

import argparse
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .common import (
    DEFAULT_FAST,
    DEFAULT_MODE,
    DEFAULT_THINKING,
    PLACEHOLDER_RE,
    RESERVED_STATE_NAMES,
    VALID_MODES,
    VALID_THINKING,
    canonical_cli_name,
    expand_path,
    parse_wait_seconds,
)


@dataclass(frozen=True)
class ArgSpec:
    name: str
    help: str = ""
    default: str | None = None


@dataclass(frozen=True)
class TransitionSpec:
    target: str
    condition: str | None = None
    wait: str | None = None


@dataclass(frozen=True)
class StateSpec:
    name: str
    start: bool = False
    end: bool = False
    prompt: str = ""
    wait: str | None = None
    mode: str | None = None
    thinking: str | None = None
    fast: bool | None = None
    transitions: tuple[TransitionSpec, ...] = ()


@dataclass(frozen=True)
class FlowSpec:
    name: str
    description: str | None
    version: int
    path: str | None
    mode: str | None
    thinking: str | None
    fast: bool | None
    args: dict[str, ArgSpec]
    states: dict[str, StateSpec]
    source_path: str
    placeholders: tuple[str, ...] = field(default_factory=tuple)

    @property
    def start_states(self) -> list[str]:
        return [state.name for state in self.states.values() if state.start]

    @property
    def end_states(self) -> list[str]:
        return [state.name for state in self.states.values() if state.end]


@dataclass(frozen=True)
class ValidationResult:
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.errors


@dataclass(frozen=True)
class CatalogEntry:
    name: str
    description: str | None
    path: str
    args: dict[str, str]
    end_states: tuple[str, ...]


@dataclass(frozen=True)
class CatalogBrokenEntry:
    path: str
    error: str


@dataclass(frozen=True)
class CatalogResult:
    flows: tuple[CatalogEntry, ...]
    broken: tuple[CatalogBrokenEntry, ...] = ()


def load_flow(path: str | Path) -> FlowSpec:
    source = Path(path).expanduser().resolve()
    data = yaml.safe_load(source.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("flow file must contain a mapping at the top level")
    flow_block = data.get("flow")
    if not isinstance(flow_block, dict):
        raise ValueError("flow file must contain a top-level 'flow' mapping")

    states: dict[str, StateSpec] = {}
    for name, raw in data.items():
        if name == "flow":
            continue
        if not isinstance(raw, dict):
            raise ValueError(f"state '{name}' must be a mapping")
        states[name] = _parse_state(name, raw)

    args = _parse_args(flow_block.get("args") or {})
    placeholders = tuple(sorted(_discover_placeholders(data)))
    version = flow_block.get("version", 1)
    if not isinstance(version, int):
        raise ValueError("flow.version must be an integer when provided")
    name = flow_block.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("flow.name must be a non-empty string")
    description = flow_block.get("description")
    if description is not None and not isinstance(description, str):
        raise ValueError("flow.description must be a string when provided")
    path_value = flow_block.get("path")
    if path_value is not None and not isinstance(path_value, str):
        raise ValueError("flow.path must be a string when provided")
    mode = flow_block.get("mode")
    if mode is not None and mode not in VALID_MODES:
        raise ValueError(f"invalid flow mode '{mode}'")
    thinking = flow_block.get("thinking")
    if thinking is not None and thinking not in VALID_THINKING:
        raise ValueError(f"invalid flow thinking '{thinking}'")
    fast = flow_block.get("fast")
    if fast is not None and not isinstance(fast, bool):
        raise ValueError("flow.fast must be a boolean when provided")

    return FlowSpec(
        name=name.strip(),
        description=description.strip() if isinstance(description, str) and description.strip() else None,
        version=version,
        path=path_value,
        mode=mode,
        thinking=thinking,
        fast=fast,
        args=args,
        states=states,
        source_path=str(source),
        placeholders=placeholders,
    )


def validate_flow(flow: FlowSpec) -> ValidationResult:
    errors: list[str] = []
    warnings: list[str] = []

    if flow.version != 1:
        warnings.append(f"flow.version is {flow.version}; V1 runtime expects version 1")

    if not flow.states:
        errors.append("flow must define at least one state")

    if not flow.start_states:
        errors.append("flow must define at least one start state")

    missing_args = sorted(set(flow.placeholders) - set(flow.args))
    for name in missing_args:
        errors.append(f"placeholder '{{{{{name}}}}}' is used but not declared in flow.args")

    referenced = set()
    for state in flow.states.values():
        if state.name in RESERVED_STATE_NAMES:
            errors.append(f"state '{state.name}' uses a reserved name")
        if state.end and state.transitions:
            errors.append(f"end state '{state.name}' cannot define transitions")
        if not state.end and not state.transitions:
            errors.append(
                f"state '{state.name}' must define at least one transition or set 'end: true' for clarity"
            )
        _validate_wait_literal(state.wait, f"state '{state.name}'", errors)
        unconditional_seen = 0
        for index, transition in enumerate(state.transitions):
            if transition.target not in flow.states:
                errors.append(
                    f"state '{state.name}' transition {index + 1} targets unknown state '{transition.target}'"
                )
            _validate_wait_literal(
                transition.wait,
                f"state '{state.name}' transition {index + 1}",
                errors,
            )
            referenced.add(transition.target)
            if not transition.condition:
                unconditional_seen += 1
                if index != len(state.transitions) - 1:
                    errors.append(
                        f"state '{state.name}' has an unconditional transition before the end of the list"
                    )
        if unconditional_seen > 1:
            errors.append(f"state '{state.name}' defines more than one unconditional transition")
        if state.mode is not None and state.mode not in VALID_MODES:
            errors.append(f"state '{state.name}' has invalid mode '{state.mode}'")
        if state.thinking is not None and state.thinking not in VALID_THINKING:
            errors.append(f"state '{state.name}' has invalid thinking '{state.thinking}'")
        if state.fast is not None and not isinstance(state.fast, bool):
            errors.append(f"state '{state.name}' has invalid fast '{state.fast}'")

    unused_args = sorted(set(flow.args) - set(flow.placeholders))
    for name in unused_args:
        warnings.append(f"flow arg '{name}' is defined but not referenced by any placeholder")

    for name in flow.placeholders:
        if name == "path":
            warnings.append("placeholder '{{path}}' is not special; use top-level flow.path instead")

    reachable = _reachable_states(flow)
    for state_name in flow.states:
        if state_name not in reachable:
            warnings.append(f"state '{state_name}' is unreachable from any start state")

    return ValidationResult(tuple(errors), tuple(warnings))


def render_flow(flow: FlowSpec, values: dict[str, str], cwd_override: str | None = None) -> FlowSpec:
    args = {
        name: ArgSpec(
            spec.name,
            spec.help,
            _render_string(spec.default, values) if isinstance(spec.default, str) else spec.default,
        )
        for name, spec in flow.args.items()
    }
    rendered_states = {
        name: StateSpec(
            name=state.name,
            start=state.start,
            end=state.end,
            prompt=_render_string(state.prompt, values),
            wait=_render_wait_string(state.wait, values),
            mode=state.mode,
            thinking=state.thinking,
            fast=state.fast,
            transitions=tuple(
                TransitionSpec(
                    target=transition.target,
                    condition=_render_string(transition.condition, values) if transition.condition else None,
                    wait=_render_wait_string(transition.wait, values),
                )
                for transition in state.transitions
            ),
        )
        for name, state in flow.states.items()
    }
    rendered_path = cwd_override or (_render_string(flow.path, values) if flow.path else None)
    if rendered_path:
        rendered_path = expand_path(rendered_path)
    return FlowSpec(
        name=_render_string(flow.name, values),
        description=_render_string(flow.description, values) if flow.description else None,
        version=flow.version,
        path=rendered_path,
        mode=flow.mode or DEFAULT_MODE,
        thinking=flow.thinking or DEFAULT_THINKING,
        fast=flow.fast if flow.fast is not None else DEFAULT_FAST,
        args=args,
        states=rendered_states,
        source_path=flow.source_path,
        placeholders=flow.placeholders,
    )


def parse_start_arguments(flow: FlowSpec, state_token: str | None, argv: list[str]) -> tuple[str, dict[str, str], str]:
    selected_state, remainder = _resolve_state_token(flow, state_token, argv)
    parser = argparse.ArgumentParser(
        prog="flow start",
        description=flow.description,
        add_help=False,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    arg_names = sorted(set(flow.placeholders) | set(flow.args))
    default_values = {
        name: str(spec.default)
        for name, spec in flow.args.items()
        if spec.default is not None
    }
    for name in arg_names:
        spec = flow.args.get(name, ArgSpec(name))
        flag = f"--{canonical_cli_name(name)}"
        kwargs: dict[str, Any] = {"dest": name, "help": spec.help or argparse.SUPPRESS, "default": argparse.SUPPRESS}
        if spec.default is not None:
            kwargs["default"] = str(spec.default)
        parser.add_argument(flag, **kwargs)

    path_default = None
    if flow.path:
        try:
            path_default = _render_string(flow.path, default_values)
        except ValueError:
            path_default = flow.path
    parser.add_argument(
        "--path",
        dest="__path__",
        default=path_default if path_default is not None else argparse.SUPPRESS,
        metavar="PATH",
        help="override working directory for new agents",
    )
    parser.add_argument("--help", action="help")

    parsed = parser.parse_args(remainder)
    missing = object()
    values: dict[str, str] = {}
    for name in arg_names:
        value = getattr(parsed, name, missing)
        if value is missing:
            raise ValueError(f"missing required argument '--{canonical_cli_name(name)}' for placeholder '{{{{{name}}}}}'")
        values[name] = str(value)

    path_value = getattr(parsed, "__path__", missing)
    if path_value is missing and flow.path:
        path_value = _render_string(flow.path, values)
    if path_value is missing:
        path_value = str(Path.cwd())
    return selected_state, values, expand_path(path_value)


def catalog_search_paths(cwd: str | Path | None = None) -> tuple[Path, ...]:
    base = Path(cwd or Path.cwd()).expanduser().resolve()
    raw = os.environ.get("FLOW_PATH", "").strip()
    items = raw.split(os.pathsep) if raw else ["~/flows", "~/.flow/flows", "./flows"]
    resolved: list[Path] = []
    seen: set[Path] = set()
    for item in items:
        text = str(item).strip()
        if not text:
            continue
        path = Path(text).expanduser()
        if not path.is_absolute():
            path = (base / path).resolve()
        else:
            path = path.resolve()
        if path in seen:
            continue
        seen.add(path)
        resolved.append(path)
    return tuple(resolved)


def discover_catalog(paths: list[str | Path] | None = None) -> CatalogResult:
    search_paths = [Path(item).expanduser().resolve() for item in (paths or catalog_search_paths())]
    flows: list[CatalogEntry] = []
    broken: list[CatalogBrokenEntry] = []
    seen_names: dict[str, str] = {}
    seen_paths: set[Path] = set()

    for root in search_paths:
        for candidate in _catalog_candidates(root):
            if candidate in seen_paths:
                continue
            seen_paths.add(candidate)
            try:
                flow = load_flow(candidate)
            except Exception as exc:
                broken.append(CatalogBrokenEntry(path=str(candidate), error=str(exc)))
                continue
            validation = validate_flow(flow)
            if validation.errors:
                broken.append(CatalogBrokenEntry(path=str(candidate), error="; ".join(validation.errors)))
                continue
            if flow.name in seen_names:
                broken.append(
                    CatalogBrokenEntry(
                        path=str(candidate),
                        error=f"duplicate flow name '{flow.name}' shadowed by {seen_names[flow.name]}",
                    )
                )
                continue
            seen_names[flow.name] = str(candidate)
            flows.append(
                CatalogEntry(
                    name=flow.name,
                    description=flow.description,
                    path=str(candidate),
                    args={name: spec.help for name, spec in flow.args.items()},
                    end_states=tuple(flow.end_states),
                )
            )

    return CatalogResult(flows=tuple(flows), broken=tuple(broken))


def flow_to_dict(flow: FlowSpec) -> dict[str, Any]:
    return {
        "name": flow.name,
        "description": flow.description,
        "version": flow.version,
        "path": flow.path,
        "mode": flow.mode,
        "thinking": flow.thinking,
        "fast": flow.fast,
        "args": {
            name: {"name": spec.name, "help": spec.help, "default": spec.default}
            for name, spec in flow.args.items()
        },
        "states": {
            name: {
                "name": state.name,
                "start": state.start,
                "end": state.end,
                "prompt": state.prompt,
                "wait": state.wait,
                "mode": state.mode,
                "thinking": state.thinking,
                "fast": state.fast,
                "transitions": [
                    {"target": transition.target, "condition": transition.condition, "wait": transition.wait}
                    for transition in state.transitions
                ],
            }
            for name, state in flow.states.items()
        },
        "source_path": flow.source_path,
        "placeholders": list(flow.placeholders),
    }


def flow_from_dict(payload: dict[str, Any]) -> FlowSpec:
    return FlowSpec(
        name=str(payload["name"]),
        description=None if payload.get("description") is None else str(payload.get("description")),
        version=int(payload["version"]),
        path=payload.get("path"),
        mode=_normalize_stored_mode(payload.get("mode")),
        thinking=payload.get("thinking"),
        fast=_normalize_stored_fast(payload.get("fast")),
        args={
            name: ArgSpec(
                name=str(spec.get("name") or name),
                help=str(spec.get("help") or ""),
                default=None if spec.get("default") is None else str(spec.get("default")),
            )
            for name, spec in dict(payload.get("args") or {}).items()
        },
        states={
            name: StateSpec(
                name=str(state.get("name") or name),
                start=bool(state.get("start")),
                end=bool(state.get("end")),
                prompt=str(state.get("prompt") or ""),
                wait=None if state.get("wait") is None else str(state.get("wait")),
                mode=_normalize_stored_mode(state.get("mode")),
                thinking=state.get("thinking"),
                fast=_normalize_stored_fast(state.get("fast")),
                transitions=tuple(
                    TransitionSpec(
                        target=str(item["target"]),
                        condition=None if item.get("condition") is None else str(item.get("condition")),
                        wait=None if item.get("wait") is None else str(item.get("wait")),
                    )
                    for item in list(state.get("transitions") or [])
                ),
            )
            for name, state in dict(payload.get("states") or {}).items()
        },
        source_path=str(payload.get("source_path") or ""),
        placeholders=tuple(str(item) for item in list(payload.get("placeholders") or [])),
    )


def _resolve_state_token(flow: FlowSpec, state_token: str | None, argv: list[str]) -> tuple[str, list[str]]:
    start_states = flow.start_states
    if state_token and not state_token.startswith("-"):
        if state_token not in start_states:
            raise ValueError(
                f"'{state_token}' is not a start state; expected one of: {', '.join(sorted(start_states))}"
            )
        return state_token, argv
    if len(start_states) == 1:
        return start_states[0], [state_token, *argv] if state_token else list(argv)
    raise ValueError(f"multiple start states defined; choose one of: {', '.join(sorted(start_states))}")


def _parse_args(raw: dict[str, Any]) -> dict[str, ArgSpec]:
    if not isinstance(raw, dict):
        raise ValueError("flow.args must be a mapping")
    args: dict[str, ArgSpec] = {}
    for name, spec in raw.items():
        if isinstance(spec, dict):
            help_text = spec.get("help") or ""
            default = spec.get("default")
        else:
            help_text = ""
            default = spec
        if default is not None and not isinstance(default, (str, int, float, bool)):
            raise ValueError(f"flow arg '{name}' default must be a scalar")
        args[name] = ArgSpec(name=name, help=str(help_text), default=None if default is None else str(default))
    return args


def _parse_state(name: str, raw: dict[str, Any]) -> StateSpec:
    transitions_raw = raw.get("transitions") or []
    if not isinstance(transitions_raw, list):
        raise ValueError(f"state '{name}' transitions must be a list")
    transitions: list[TransitionSpec] = []
    for item in transitions_raw:
        if not isinstance(item, dict):
            raise ValueError(f"state '{name}' transitions must contain mappings")
        target = item.get("go")
        if not isinstance(target, str) or not target.strip():
            raise ValueError(f"state '{name}' has a transition without a valid 'go' target")
        condition = item.get("if")
        if condition is not None and not isinstance(condition, str):
            raise ValueError(f"state '{name}' transition to '{target}' has a non-string 'if' condition")
        wait = item.get("wait")
        if wait is not None and not isinstance(wait, str):
            raise ValueError(f"state '{name}' transition to '{target}' has a non-string 'wait' value")
        transitions.append(
            TransitionSpec(
                target=target.strip(),
                condition=condition.strip() if isinstance(condition, str) and condition.strip() else None,
                wait=wait.strip() if isinstance(wait, str) and wait.strip() else None,
            )
        )
    prompt = raw.get("prompt") or ""
    if prompt is None:
        prompt = ""
    if not isinstance(prompt, str):
        raise ValueError(f"state '{name}' prompt must be a string")
    wait = raw.get("wait")
    if wait is not None and not isinstance(wait, str):
        raise ValueError(f"state '{name}' wait must be a string like '10m'")
    mode = raw.get("mode")
    thinking = raw.get("thinking")
    fast = raw.get("fast")
    return StateSpec(
        name=name,
        start=bool(raw.get("start")),
        end=bool(raw.get("end")),
        prompt=prompt,
        wait=wait.strip() if isinstance(wait, str) and wait.strip() else None,
        mode=mode,
        thinking=thinking,
        fast=fast,
        transitions=tuple(transitions),
    )


def _discover_placeholders(value: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(value, str):
        found.update(PLACEHOLDER_RE.findall(value))
    elif isinstance(value, dict):
        for item in value.values():
            found.update(_discover_placeholders(item))
    elif isinstance(value, list):
        for item in value:
            found.update(_discover_placeholders(item))
    return found


def _render_string(value: str | None, values: dict[str, str]) -> str:
    if not value:
        return ""

    def replace(match: Any) -> str:
        key = match.group(1)
        if key not in values:
            raise ValueError(f"missing value for placeholder '{{{{{key}}}}}'")
        return str(values[key])

    return PLACEHOLDER_RE.sub(replace, value)


def _render_wait_string(value: str | None, values: dict[str, str]) -> str | None:
    if value is None:
        return None
    rendered = _render_string(value, values).strip()
    if not rendered:
        return None
    parse_wait_seconds(rendered)
    return rendered


def _reachable_states(flow: FlowSpec) -> set[str]:
    pending = list(flow.start_states)
    visited: set[str] = set()
    while pending:
        current = pending.pop()
        if current in visited:
            continue
        visited.add(current)
        state = flow.states.get(current)
        if state is None:
            continue
        for transition in state.transitions:
            if transition.target not in flow.states:
                continue
            if transition.target not in visited:
                pending.append(transition.target)
    return visited


def _validate_wait_literal(value: str | None, context: str, errors: list[str]) -> None:
    if value is None:
        return
    if PLACEHOLDER_RE.search(value):
        return
    try:
        parse_wait_seconds(value)
    except ValueError as exc:
        errors.append(f"{context} has invalid wait '{value}': {exc}")


def _normalize_stored_mode(value: Any) -> Any:
    # Legacy snapshots may still contain read-only from before scratchpads existed.
    return "workspace-write" if value == "read-only" else value


def _normalize_stored_fast(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off", ""}:
        return False
    return bool(value)


def _catalog_candidates(root: Path) -> tuple[Path, ...]:
    if not root.exists():
        return ()
    if root.is_file():
        return (root,) if root.suffix.lower() in {".yaml", ".yml"} else ()
    if not root.is_dir():
        return ()
    items = sorted(path.resolve() for path in root.rglob("*.yaml"))
    items.extend(sorted(path.resolve() for path in root.rglob("*.yml")))
    seen: set[Path] = set()
    ordered: list[Path] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return tuple(ordered)
