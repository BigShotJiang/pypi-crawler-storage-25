import json
import os
import stat
import time
import base64
from unittest.mock import AsyncMock, patch, MagicMock

import httpx
import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

from pattern_agent_sdk import AgentSessionToken, PatternSDK, SessionTokenJWKSConfig
from pattern_agent_sdk.sdk import _decode_jwt_payload, _parse_extra_headers


def _make_jwt(payload: dict) -> str:
    header = base64.urlsafe_b64encode(b'{"alg":"HS256"}').rstrip(b"=").decode()
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
    return f"{header}.{body}.fakesig"


class TestDecodeJwtPayload:
    def test_valid_token(self):
        payload = {"sub": "dep-123", "exp": 9999999999}
        token = _make_jwt(payload)
        assert _decode_jwt_payload(token) == payload

    def test_invalid_token(self):
        with pytest.raises(ValueError, match="Invalid JWT format"):
            _decode_jwt_payload("not.a.valid.jwt.token")

    def test_two_parts(self):
        with pytest.raises(ValueError, match="Invalid JWT format"):
            _decode_jwt_payload("only.two")


class TestParseExtraHeaders:
    def test_valid_headers(self):
        raw = base64.b64encode(json.dumps({"X-Forwarded-Client-Cert": "Hash=abc"}).encode()).decode()
        assert _parse_extra_headers(raw) == {"X-Forwarded-Client-Cert": "Hash=abc"}

    def test_empty_or_none(self):
        assert _parse_extra_headers(None) == {}
        assert _parse_extra_headers("") == {}

    def test_malformed_base64(self):
        assert _parse_extra_headers("not-valid-base64!!!") == {}

    def test_non_dict_json(self):
        raw = base64.b64encode(b'["a","b"]').decode()
        assert _parse_extra_headers(raw) == {}

    def test_non_string_values(self):
        raw = base64.b64encode(json.dumps({"key": 123}).encode()).decode()
        assert _parse_extra_headers(raw) == {}


class TestMintTokenHeaders:
    async def test_mint_token_sends_extra_headers(self, respx_mock):
        extra = {"X-Forwarded-Client-Cert": "Hash=abc123"}
        raw = base64.b64encode(json.dumps(extra).encode()).decode()
        sdk = PatternSDK("http://localhost:9999", token_request_headers=raw)

        token = _make_jwt({"sub": "dep-1", "exp": 9999999999})
        route = respx_mock.post("http://localhost:9999/mint-agent-token").mock(
            return_value=httpx.Response(200, json={"token": token})
        )

        await sdk._mint_token()

        assert route.called
        req = route.calls[0].request
        assert req.headers["X-Forwarded-Client-Cert"] == "Hash=abc123"

    async def test_mint_token_no_extra_headers(self, respx_mock):
        sdk = PatternSDK("http://localhost:9999")

        token = _make_jwt({"sub": "dep-1", "exp": 9999999999})
        route = respx_mock.post("http://localhost:9999/mint-agent-token").mock(
            return_value=httpx.Response(200, json={"token": token})
        )

        await sdk._mint_token()

        assert route.called
        req = route.calls[0].request
        assert "X-Forwarded-Client-Cert" not in req.headers


class TestPatternSDKNoEndpoint:
    def test_init_silent_when_no_endpoint(self):
        sdk = PatternSDK()
        assert not sdk._enabled

    async def test_methods_raise_when_disabled(self):
        sdk = PatternSDK()
        with pytest.raises(RuntimeError, match="SDK is disabled"):
            await sdk.config()
        with pytest.raises(RuntimeError, match="SDK is disabled"):
            await sdk.prompt("inference")
        with pytest.raises(RuntimeError, match="SDK is disabled"):
            await sdk.prompts()


class TestConfigCaching:
    async def test_config_cached(self):
        sdk = PatternSDK("http://localhost:9999")
        mock_data = {"key1": "val1", "key2": "val2"}

        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value=mock_data) as mock_req:
            result1 = await sdk.config()
            result2 = await sdk.config()
            result3 = await sdk.config("key1")

        assert result1 == mock_data
        assert result2 == mock_data
        assert result3 == "val1"
        mock_req.assert_awaited_once_with("GET", "/config")

    async def test_config_key_missing_returns_none(self):
        sdk = PatternSDK("http://localhost:9999")
        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value={"a": 1}):
            assert await sdk.config("missing") is None


class TestPromptsCaching:
    async def test_prompt_shares_cache_with_prompts(self):
        sdk = PatternSDK("http://localhost:9999")
        mock_data = {"greeting": "Hello!", "farewell": "Bye!"}

        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value=mock_data) as mock_req:
            single = await sdk.prompt("greeting")
            all_prompts = await sdk.prompts()

        assert single == "Hello!"
        assert all_prompts == mock_data
        mock_req.assert_awaited_once_with("GET", "/prompts")

    async def test_prompt_missing_returns_none(self):
        sdk = PatternSDK("http://localhost:9999")
        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value={}):
            assert await sdk.prompt("nope") is None


class TestTokenPersistence:
    async def test_enable_writes_token_to_disk(self, respx_mock, tmp_path):
        token = _make_jwt({"sub": "dep-1", "exp": 9999999999})
        respx_mock.post("http://localhost:9999/mint-agent-token").mock(
            return_value=httpx.Response(200, json={"token": token})
        )
        sdk = PatternSDK("http://localhost:9999")
        path = str(tmp_path / "token")

        with patch.dict(os.environ, {"__PA_AGENT_SDK_TOKEN_PERSIST_PATH": path}):
            await sdk.enable_token_persistence()

        assert sdk.token_file_path == path
        assert open(path).read() == token
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o600

    async def test_missing_env_var_raises(self):
        sdk = PatternSDK("http://localhost:9999")
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(RuntimeError, match="__PA_AGENT_SDK_TOKEN_PERSIST_PATH is required"):
                await sdk.enable_token_persistence()

    def test_token_file_path_raises_when_not_enabled(self):
        sdk = PatternSDK("http://localhost:9999")
        with pytest.raises(RuntimeError, match="Token persistence has not been enabled"):
            _ = sdk.token_file_path

    async def test_token_refresh_updates_file(self, respx_mock, tmp_path):
        token1 = _make_jwt({"sub": "dep-1", "exp": 9999999999})
        token2 = _make_jwt({"sub": "dep-1", "exp": 9999999999, "v": 2})
        route = respx_mock.post("http://localhost:9999/mint-agent-token")
        route.side_effect = [
            httpx.Response(200, json={"token": token1}),
            httpx.Response(200, json={"token": token2}),
        ]
        sdk = PatternSDK("http://localhost:9999")
        path = str(tmp_path / "token")

        with patch.dict(os.environ, {"__PA_AGENT_SDK_TOKEN_PERSIST_PATH": path}):
            await sdk.enable_token_persistence()

        assert open(path).read() == token1

        sdk._token_exp = 0
        await sdk._ensure_token()

        assert open(path).read() == token2

    async def test_disabled_sdk_raises(self):
        sdk = PatternSDK()
        with pytest.raises(RuntimeError, match="SDK is disabled"):
            await sdk.enable_token_persistence()


def _rsa_key_pair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_pem = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    return private_key, private_pem


def _make_session_jwt(private_pem: bytes, payload: dict, headers: dict | None = None) -> str:
    return pyjwt.encode(payload, private_pem, algorithm="RS256", headers=headers)


class TestSessionTokenConfig:
    async def test_fetches_and_caches(self):
        sdk = PatternSDK("http://localhost:9999")
        config_data = {"jwks_url": "https://example.com/.well-known/jwks.json", "audience": "my-app"}

        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value=config_data) as mock_req:
            result1 = await sdk.session_token_config()
            result2 = await sdk.session_token_config()

        assert result1 == SessionTokenJWKSConfig(jwks_url="https://example.com/.well-known/jwks.json", audience="my-app")
        assert result2 is result1
        mock_req.assert_awaited_once_with("GET", "/session_token_jwks_config")
        assert sdk._jwks_client is not None

    async def test_with_issuer(self):
        sdk = PatternSDK("http://localhost:9999")
        config_data = {
            "jwks_url": "https://example.com/.well-known/jwks.json",
            "audience": "my-app",
            "issuer": "https://auth.example.com",
        }

        with patch.object(sdk, "_request", new_callable=AsyncMock, return_value=config_data):
            result = await sdk.session_token_config()

        assert result.issuer == "https://auth.example.com"


class TestVerifySessionToken:
    def test_raises_without_config(self):
        sdk = PatternSDK("http://localhost:9999")
        with pytest.raises(RuntimeError, match="Session token verification not configured"):
            sdk.verify_session_token("some.jwt.token")

    def test_valid_token(self):
        private_key, private_pem = _rsa_key_pair()
        now = int(time.time())
        payload = {
            "sub": "session-abc",
            "tenant_id": "tenant-1",
            "user_id": "user-42",
            "agents": ["agent-a", "agent-b"],
            "exp": now + 3600,
            "iat": now,
            "aud": "my-app",
        }
        token = _make_session_jwt(private_pem, payload)

        sdk = PatternSDK("http://localhost:9999")
        sdk._session_jwks_config = SessionTokenJWKSConfig(
            jwks_url="https://example.com/.well-known/jwks.json",
            audience="my-app",
        )
        mock_signing_key = MagicMock()
        mock_signing_key.key = private_key.public_key()
        sdk._jwks_client = MagicMock()
        sdk._jwks_client.get_signing_key_from_jwt.return_value = mock_signing_key

        result = sdk.verify_session_token(token)

        assert isinstance(result, AgentSessionToken)
        assert result.session_id == "session-abc"
        assert result.tenant_id == "tenant-1"
        assert result.user_id == "user-42"
        assert result.agents == ["agent-a", "agent-b"]
        assert result.exp == now + 3600
        assert result.iat == now

    def test_expired_token_raises(self):
        private_key, private_pem = _rsa_key_pair()
        now = int(time.time())
        payload = {
            "sub": "session-abc",
            "tenant_id": "tenant-1",
            "user_id": "user-42",
            "agents": [],
            "exp": now - 100,
            "iat": now - 3700,
            "aud": "my-app",
        }
        token = _make_session_jwt(private_pem, payload)

        sdk = PatternSDK("http://localhost:9999")
        sdk._session_jwks_config = SessionTokenJWKSConfig(
            jwks_url="https://example.com/.well-known/jwks.json",
            audience="my-app",
        )
        mock_signing_key = MagicMock()
        mock_signing_key.key = private_key.public_key()
        sdk._jwks_client = MagicMock()
        sdk._jwks_client.get_signing_key_from_jwt.return_value = mock_signing_key

        with pytest.raises(pyjwt.ExpiredSignatureError):
            sdk.verify_session_token(token)

    def test_wrong_audience_raises(self):
        private_key, private_pem = _rsa_key_pair()
        now = int(time.time())
        payload = {
            "sub": "session-abc",
            "tenant_id": "tenant-1",
            "user_id": "user-42",
            "agents": [],
            "exp": now + 3600,
            "iat": now,
            "aud": "wrong-audience",
        }
        token = _make_session_jwt(private_pem, payload)

        sdk = PatternSDK("http://localhost:9999")
        sdk._session_jwks_config = SessionTokenJWKSConfig(
            jwks_url="https://example.com/.well-known/jwks.json",
            audience="my-app",
        )
        mock_signing_key = MagicMock()
        mock_signing_key.key = private_key.public_key()
        sdk._jwks_client = MagicMock()
        sdk._jwks_client.get_signing_key_from_jwt.return_value = mock_signing_key

        with pytest.raises(pyjwt.InvalidAudienceError):
            sdk.verify_session_token(token)
