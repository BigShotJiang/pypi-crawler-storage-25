# pattern_agentic_sdk

SDK for Pattern Agentic agents.

```bash
pip install pattern_agentic_sdk
```

```python
from pattern_agentic_sdk import pa_sdk

config = await pa_sdk.config()
prompt = await pa_sdk.prompt("my-prompt")
```
