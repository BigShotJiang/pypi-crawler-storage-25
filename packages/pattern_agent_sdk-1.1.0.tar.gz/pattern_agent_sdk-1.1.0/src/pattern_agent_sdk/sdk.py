import asyncio
import os
import json
import time
import base64
import logging
import tempfile
from typing import Optional

import httpx
import jwt as pyjwt
from jwt import PyJWKClient
from pydantic import BaseModel
from pattern_agentic_messaging import PASlimApp, PASlimConfig
from pattern_agentic_messaging.session_token import PatternAgentSessionToken

logger = logging.getLogger(__name__)

_SENSITIVE_KEYS = ("password", "secret", "key", "token", "auth", "service_account")


def _safe_describe_config(config: dict, indent: str = "  ") -> str:
    items = {k: v for k, v in config.items() if not k.startswith("__")}
    lines = []
    for k in sorted(items):
        v = items[k]
        if any(s in k.lower() for s in _SENSITIVE_KEYS):
            lines.append(f"{indent}{k}: {'(empty)' if v is None or v == '' else '(redacted)'}")
        else:
            lines.append(f"{indent}{k}: {v}")
    return "\n".join(lines)


def _parse_extra_headers(raw: Optional[str]) -> dict[str, str]:
    if not raw:
        return {}
    try:
        decoded = base64.b64decode(raw)
        headers = json.loads(decoded)
        if isinstance(headers, dict) and all(isinstance(k, str) and isinstance(v, str) for k, v in headers.items()):
            return headers
    except Exception:
        pass
    logger.warning("PatternSDK: __PA_AGENT_SERVICES_TOKEN_REQUEST_HEADERS is malformed, ignoring")
    return {}


def _decode_jwt_payload(token: str) -> dict:  # no sig check: token just received from local sidecar
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")
    payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
    return json.loads(base64.urlsafe_b64decode(payload_b64))


class AgentRuntimeSystemConfig(BaseModel):
    pa_slim_endpoint: str
    pa_slim_name: str
    pa_slim_shared_secret: str
    pa_mcp_json_path: str = ""
    pa_msg_audit_nats_url: Optional[str] = None

    @classmethod
    def from_system_params(cls, params: dict) -> "AgentRuntimeSystemConfig":
        mapped = {}
        for field_name, field_info in cls.model_fields.items():
            key = field_name.upper()
            if key in params:
                val = params[key]
                if field_info.default is None and not val:
                    val = None
                mapped[field_name] = val
        try:
            return cls(**mapped)
        except Exception as e:
            present = {k: ("***" if "secret" in k.lower() else repr(v)[:60]) for k, v in params.items() if k.startswith("PA_")}
            raise RuntimeError(
                f"Agent runtime system config validation failed: {e}\n"
                f"Available PA_* params: {present}"
            ) from e


class SessionTokenJWKSConfig(BaseModel):
    jwks_url: str
    issuer: Optional[str] = None
    audience: str



class PatternSDK:
    def __init__(self, services_endpoint: Optional[str] = None, token_request_headers: Optional[str] = None):
        self._services_endpoint = (services_endpoint or "").rstrip("/")
        self._enabled = bool(self._services_endpoint)
        if not self._enabled:
            logger.info("PatternSDK: no services endpoint configured, SDK disabled")
            return
        self._mint_headers = _parse_extra_headers(token_request_headers)
        self._token: Optional[str] = None
        self._deployment_id: Optional[str] = None
        self._token_exp: float = 0
        self._renew_failed: bool = False
        self._config_cache: Optional[dict] = None
        self._prompts_cache: Optional[dict] = None
        self._persist_token_to_disk: bool = False
        self._token_persist_path: Optional[str] = None
        self._session_jwks_config: Optional[SessionTokenJWKSConfig] = None
        self._jwks_client: Optional[PyJWKClient] = None

    def _require_enabled(self):
        if not self._enabled:
            raise RuntimeError("PatternSDK is disabled: services endpoint not specified")

    @property
    def _endpoint(self) -> str:
        return self._services_endpoint

    async def _mint_token(self) -> str:
        url = f"{self._endpoint}/mint-agent-token"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(url, headers=self._mint_headers or None)
        except httpx.ConnectError as e:
            logger.error(f"PatternSDK: cannot connect to agent services at {url} — is the sidecar running? {e}")
            raise
        except httpx.TimeoutException:
            logger.error(f"PatternSDK: request to {url} timed out")
            raise

        if resp.status_code != 200:
            logger.error(f"PatternSDK: mint-agent-token returned {resp.status_code}: {resp.text}")
            raise RuntimeError(
                f"Error authorizing agent for pattern-agentic services: {resp.status_code} {resp.reason_phrase}"
            )

        try:
            token = resp.json()["token"]
        except (KeyError, json.JSONDecodeError) as e:
            logger.error(f"PatternSDK: mint-agent-token response missing 'token' field: {resp.text}")
            raise RuntimeError("mint-agent-token response missing 'token' field") from e

        payload = _decode_jwt_payload(token)
        self._token = token
        self._deployment_id = payload["sub"]
        self._token_exp = payload.get("exp", 0)
        self._renew_failed = False
        if self._persist_token_to_disk:
            self._write_token_to_disk()
        return token

    async def _ensure_token(self):
        if not self._token or time.time() >= self._token_exp:
            await self._mint_token()

    def _token_is_expired(self) -> bool:
        return time.time() >= self._token_exp

    def _write_token_to_disk(self):
        path = self._token_persist_path
        parent = os.path.dirname(path)
        os.makedirs(parent, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=parent)
        try:
            os.write(fd, self._token.encode())
            os.fchmod(fd, 0o600)
        finally:
            os.close(fd)
        try:
            os.rename(tmp, path)
        except BaseException:
            os.unlink(tmp)
            raise

    async def enable_token_persistence(self):
        self._require_enabled()
        path = os.environ.get("__PA_AGENT_SDK_TOKEN_PERSIST_PATH")
        if not path:
            raise RuntimeError(
                "Invalid configuration, env variable __PA_AGENT_SDK_TOKEN_PERSIST_PATH is required to access the token on disk"
            )
        if os.path.isdir(path):
            path = os.path.join(path, f"agent-{os.getpid()}.jwt")
        self._token_persist_path = path
        self._persist_token_to_disk = True
        await self._ensure_token()
        self._write_token_to_disk()

    @property
    def token_file_path(self) -> str:
        if not self._persist_token_to_disk:
            raise RuntimeError("Token persistence has not been enabled — call enable_token_persistence() first")
        return self._token_persist_path

    async def _authed_request(self, method: str, url: str) -> httpx.Response:
        await self._ensure_token()
        headers = {"Authorization": f"Bearer {self._token}"}

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.request(method, url, headers=headers)
        except httpx.ConnectError as e:
            logger.error(f"PatternSDK: cannot connect to {url}: {e}")
            raise
        except httpx.TimeoutException:
            logger.error(f"PatternSDK: request to {url} timed out")
            raise

        if resp.status_code == 403 and self._token_is_expired() and not self._renew_failed:
            logger.info("PatternSDK: got 403 with expired token, attempting renewal")
            try:
                await self._mint_token()
            except Exception:
                self._renew_failed = True
                logger.error("PatternSDK: token renewal failed after 403, not retrying")
                raise
            headers = {"Authorization": f"Bearer {self._token}"}
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    resp = await client.request(method, url, headers=headers)
            except httpx.ConnectError as e:
                logger.error(f"PatternSDK: cannot connect to {url} on retry: {e}")
                raise
            except httpx.TimeoutException:
                logger.error(f"PatternSDK: retry request to {url} timed out")
                raise

        if resp.status_code == 401:
            logger.error(f"PatternSDK: 401 from {url}: {resp.text}")
            raise PermissionError(f"Unauthorized: {resp.text}")
        if resp.status_code == 403:
            logger.error(f"PatternSDK: 403 from {url}: {resp.text}")
            raise PermissionError(f"Forbidden: {resp.text}")
        if resp.status_code >= 400:
            logger.error(f"PatternSDK: {resp.status_code} from {url}: {resp.text}")
            raise RuntimeError(
                f"Error fetching {url} from pattern-agentic services: {resp.status_code} {resp.reason_phrase}"
            )

        return resp

    async def _request(self, method: str, path: str) -> dict:
        url = f"{self._endpoint}/deployment/{self._deployment_id}{path}"
        resp = await self._authed_request(method, url)
        return resp.json()

    async def _session_request(self, method: str, path: str) -> httpx.Response:
        url = f"{self._endpoint}/session{path}"
        return await self._authed_request(method, url)

    async def session_token_config(self) -> SessionTokenJWKSConfig:
        if self._session_jwks_config:
            return self._session_jwks_config
        self._require_enabled()
        url = f"{self._endpoint}/session-token-config"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
        except httpx.ConnectError as e:
            logger.error(f"PatternSDK: cannot connect to {url}: {e}")
            raise
        except httpx.TimeoutException:
            logger.error(f"PatternSDK: request to {url} timed out")
            raise
        if resp.status_code >= 400:
            logger.error(f"PatternSDK: {resp.status_code} from session-token-config: {resp.text}")
            raise RuntimeError(f"Failed to fetch session token config: {resp.status_code}")
        data = resp.json()
        self._session_jwks_config = SessionTokenJWKSConfig(**data)
        self._jwks_client = PyJWKClient(
            self._session_jwks_config.jwks_url,
            cache_keys=True,
        )
        return self._session_jwks_config

    async def verify_session_token(self, token, *, verify_agent_peers: bool = True) -> PatternAgentSessionToken:
        if isinstance(token, PatternAgentSessionToken):
            raw = token.raw_token
        else:
            raw = token
        if not self._jwks_client or not self._session_jwks_config:
            await self.session_token_config()
        signing_key = self._jwks_client.get_signing_key_from_jwt(raw)
        decode_kwargs = {
            "jwt": raw,
            "key": signing_key.key,
            "algorithms": ["RS256"],
            "audience": self._session_jwks_config.audience,
        }
        if self._session_jwks_config.issuer:
            decode_kwargs["issuer"] = self._session_jwks_config.issuer
        payload = pyjwt.decode(**decode_kwargs)
        verified = PatternAgentSessionToken(
            session_id=payload["sub"],
            tenant_id=payload["tenant_id"],
            user_id=payload["user_id"],
            agents=payload.get("agents", []),
            exp=payload["exp"],
            iat=payload["iat"],
            raw_token=raw,
        )
        if verify_agent_peers:
            if not self._deployment_id:
                raise RuntimeError("Cannot verify agent peers: SDK has no deployment identity (token not yet minted)")
            if self._deployment_id not in verified.agents:
                raise PermissionError(
                    f"Session token does not authorize this agent: "
                    f"deployment={self._deployment_id} not in agents={verified.agents}"
                )
        return verified

    async def _build_agent_app(self, *, verify_sessions: bool = True) -> PASlimApp:
        self._require_enabled()
        await self._ensure_token()
        cfg = await self.config()
        desc = _safe_describe_config(cfg)
        if desc:
            logger.info(f"PatternSDK: runtime config:\n{desc}")
        sys_params = cfg.get("__system_params", {})
        rt = AgentRuntimeSystemConfig.from_system_params(sys_params)
        await self.session_token_config()

        config = PASlimConfig(
            local_name=rt.pa_slim_name,
            endpoint=rt.pa_slim_endpoint,
            auth_secret=rt.pa_slim_shared_secret,
            message_discriminator="type",
            audit_nats_url=rt.pa_msg_audit_nats_url,
        )
        app = PASlimApp(config)
        if verify_sessions:
            app.session_token_verifier = self.verify_session_token
        logger.info(f"PatternSDK: agent configured (deployment={self._deployment_id} slim_name={rt.pa_slim_name} audit={'enabled' if rt.pa_msg_audit_nats_url else 'disabled'})")
        return app

    def agent_app(self, *, verify_sessions: bool = True) -> PASlimApp:
        return asyncio.run(self._build_agent_app(verify_sessions=verify_sessions))

    async def config(self, key: Optional[str] = None):
        self._require_enabled()
        if self._config_cache is None:
            self._config_cache = await self._request("GET", "/config")
        if key is not None:
            return self._config_cache.get(key)
        return self._config_cache

    async def prompt(self, slug: str) -> Optional[str]:
        self._require_enabled()
        if self._prompts_cache is None:
            self._prompts_cache = await self._request("GET", "/prompts")
        return self._prompts_cache.get(slug)

    async def prompts(self) -> dict:
        self._require_enabled()
        if self._prompts_cache is None:
            self._prompts_cache = await self._request("GET", "/prompts")
        return self._prompts_cache

    async def session_peers(self, session_id: str) -> dict:
        self._require_enabled()
        resp = await self._session_request("GET", f"/{session_id}/peers")
        return resp.json()

    async def session_prompt(self, session_id: str) -> Optional[str]:
        self._require_enabled()
        resp = await self._session_request("GET", f"/{session_id}/prompt")
        data = resp.json()
        if data is None:
            return None
        return data.get("content")


pa_sdk = PatternSDK(
    os.environ.get("__PA_AGENT_SERVICES_ENDPOINT"),
    os.environ.get("__PA_AGENT_SERVICES_TOKEN_REQUEST_HEADERS"),
)
