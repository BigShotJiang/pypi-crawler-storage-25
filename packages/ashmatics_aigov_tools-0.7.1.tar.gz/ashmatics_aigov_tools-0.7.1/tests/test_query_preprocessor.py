"""
Tests for Query Preprocessor (ASHKBAPP-68)

Tests the intent classification, entity extraction, and query plan generation
for the intelligent query routing system.

Architecture: Two-Stage Classification with Refinement Oracle
- Stage 1: Lightweight rule-based classification (tested here)
- Stage 2: Refinement Oracle with DeepSeek-R1 (requires integration tests)

Created: 2026-01-26
Updated: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

import pytest

from ashmatics_aigov_tools.services.query_preprocessor import (
    EntityExtractor,
    ExtractedEntities,
    IntentClassifier,
    QueryIntent,
    QueryPlan,
    QueryPreprocessor,
    QueryPreprocessorConfig,
    RetrievalStrategy,
    preprocess_query,
    create_preprocessor,
)


# =============================================================================
# Entity Extractor Tests
# =============================================================================


class TestEntityExtractor:
    """Tests for EntityExtractor."""

    @pytest.fixture
    def extractor(self):
        return EntityExtractor()

    # -------------------------------------------------------------------------
    # Artifact ID Extraction
    # -------------------------------------------------------------------------

    def test_extract_sop_id(self, extractor):
        """Should extract SOP artifact IDs."""
        query = "Show me SOP-PV-01"
        entities = extractor.extract(query)
        assert "SOP-PV-01" in entities.artifact_ids

    def test_extract_work_product_id(self, extractor):
        """Should extract WP artifact IDs."""
        query = "Get the work product WP-MON-02"
        entities = extractor.extract(query)
        assert "WP-MON-02" in entities.artifact_ids

    def test_extract_policy_overview_id(self, extractor):
        """Should extract POL-*-Overview artifact IDs."""
        query = "Fetch POL-RMP-Overview"
        entities = extractor.extract(query)
        assert "POL-RMP-OVERVIEW" in entities.artifact_ids

    def test_extract_process_overview_id(self, extractor):
        """Should extract PROC-*-Overview artifact IDs."""
        query = "I need PROC-MON-Overview"
        entities = extractor.extract(query)
        assert "PROC-MON-OVERVIEW" in entities.artifact_ids

    def test_extract_exemplar_control_id(self, extractor):
        """Should extract EXC-* control IDs."""
        query = "What implements EXC-A4-01?"
        entities = extractor.extract(query)
        assert "EXC-A4-01" in entities.control_ids

    def test_extract_multiple_artifact_ids(self, extractor):
        """Should extract multiple artifact IDs from one query."""
        query = "Compare SOP-PV-01 with SOP-PV-02"
        entities = extractor.extract(query)
        assert "SOP-PV-01" in entities.artifact_ids
        assert "SOP-PV-02" in entities.artifact_ids

    # -------------------------------------------------------------------------
    # Domain Extraction
    # -------------------------------------------------------------------------

    def test_extract_policy_domain_code(self, extractor):
        """Should extract explicit policy domain codes."""
        query = "What is the RMP policy?"
        entities = extractor.extract(query)
        assert "RMP" in entities.policy_domains

    def test_extract_process_domain_code(self, extractor):
        """Should extract explicit process domain codes."""
        query = "Show me the MON domain"
        entities = extractor.extract(query)
        assert "MON" in entities.process_domains

    def test_extract_domain_from_natural_language(self, extractor):
        """Should extract domains from natural language."""
        query = "What is risk management?"
        entities = extractor.extract(query)
        assert "RM" in entities.process_domains

    def test_extract_domain_from_monitoring(self, extractor):
        """Should map 'monitoring' to MON domain."""
        query = "Explain model monitoring"
        entities = extractor.extract(query)
        assert "MON" in entities.process_domains

    def test_extract_domain_from_fairness(self, extractor):
        """Should map 'fairness' to EF domain."""
        query = "How do we handle fairness testing?"
        entities = extractor.extract(query)
        assert "EF" in entities.process_domains

    # -------------------------------------------------------------------------
    # Regulatory Framework Extraction
    # -------------------------------------------------------------------------

    def test_extract_nist_framework(self, extractor):
        """Should extract NIST framework reference."""
        query = "How do we comply with NIST?"
        entities = extractor.extract(query)
        assert "NIST-AI-RMF" in entities.regulatory_frameworks

    def test_extract_nist_full_name(self, extractor):
        """Should extract NIST AI RMF from full name."""
        query = "NIST AI RMF compliance mapping"
        entities = extractor.extract(query)
        assert "NIST-AI-RMF" in entities.regulatory_frameworks

    def test_extract_joint_commission(self, extractor):
        """Should extract Joint Commission framework."""
        query = "Joint Commission requirements for AI"
        entities = extractor.extract(query)
        assert "JC-RUAIH" in entities.regulatory_frameworks

    def test_extract_iso_42001(self, extractor):
        """Should extract ISO 42001 framework."""
        query = "How does this map to ISO 42001?"
        entities = extractor.extract(query)
        assert "ISO-42001" in entities.regulatory_frameworks

    def test_extract_colorado_ai_act(self, extractor):
        """Should extract Colorado AI Act."""
        query = "Colorado AI Act compliance"
        entities = extractor.extract(query)
        assert "CO-AI-ACT" in entities.regulatory_frameworks

    # -------------------------------------------------------------------------
    # Requirement ID Extraction
    # -------------------------------------------------------------------------

    def test_extract_nist_requirement_id(self, extractor):
        """Should extract NIST requirement IDs."""
        query = "What addresses NIST-AI-RMF-GOVERN-1.1?"
        entities = extractor.extract(query)
        assert "NIST-AI-RMF-GOVERN-1.1" in entities.requirement_ids


# =============================================================================
# Intent Classifier Tests
# =============================================================================


class TestIntentClassifier:
    """Tests for IntentClassifier."""

    @pytest.fixture
    def classifier(self):
        return IntentClassifier()

    @pytest.fixture
    def extractor(self):
        return EntityExtractor()

    def _classify(self, classifier, extractor, query):
        """Helper to classify a query."""
        entities = extractor.extract(query)
        intent, confidence, signals = classifier.classify(query, entities)
        return intent, confidence

    # -------------------------------------------------------------------------
    # Domain Explanation Intent
    # -------------------------------------------------------------------------

    def test_domain_explanation_what_is(self, classifier, extractor):
        """'What is X domain?' should classify as DOMAIN_EXPLANATION."""
        intent, _ = self._classify(classifier, extractor, "What is the Risk Management domain?")
        assert intent == QueryIntent.DOMAIN_EXPLANATION

    def test_domain_explanation_explain(self, classifier, extractor):
        """'Explain the X domain' should classify as DOMAIN_EXPLANATION."""
        intent, _ = self._classify(classifier, extractor, "Explain the MON domain")
        assert intent == QueryIntent.DOMAIN_EXPLANATION

    def test_domain_explanation_tell_me_about(self, classifier, extractor):
        """'Tell me about X' should classify as DOMAIN_EXPLANATION."""
        intent, _ = self._classify(classifier, extractor, "Tell me about model monitoring")
        assert intent == QueryIntent.DOMAIN_EXPLANATION

    # -------------------------------------------------------------------------
    # Structural Intent
    # -------------------------------------------------------------------------

    def test_structural_what_implements(self, classifier, extractor):
        """'What implements X?' should classify as STRUCTURAL."""
        intent, _ = self._classify(classifier, extractor, "What SOPs implement EXC-A4-01?")
        assert intent == QueryIntent.STRUCTURAL

    def test_structural_show_hierarchy(self, classifier, extractor):
        """'Show hierarchy' should classify as STRUCTURAL."""
        intent, _ = self._classify(classifier, extractor, "Show me the hierarchy for RMP")
        assert intent == QueryIntent.STRUCTURAL

    def test_structural_what_produces(self, classifier, extractor):
        """'What does X produce?' should classify as STRUCTURAL."""
        intent, _ = self._classify(classifier, extractor, "What work products does MMP-001 produce?")
        assert intent == QueryIntent.STRUCTURAL

    # -------------------------------------------------------------------------
    # Known Item Intent
    # -------------------------------------------------------------------------

    def test_known_item_show_sop(self, classifier, extractor):
        """'Show me SOP-X' should classify as KNOWN_ITEM."""
        intent, _ = self._classify(classifier, extractor, "Show me SOP-PV-01")
        assert intent == QueryIntent.KNOWN_ITEM

    def test_known_item_get_artifact(self, classifier, extractor):
        """'Get POL-X-Overview' should classify as KNOWN_ITEM."""
        intent, _ = self._classify(classifier, extractor, "Get POL-RMP-Overview")
        assert intent == QueryIntent.KNOWN_ITEM

    # -------------------------------------------------------------------------
    # Regulatory Crosswalk Intent
    # -------------------------------------------------------------------------

    def test_regulatory_comply_with(self, classifier, extractor):
        """'How to comply with X?' should classify as REGULATORY_CROSSWALK."""
        intent, _ = self._classify(classifier, extractor, "How do we comply with NIST?")
        assert intent == QueryIntent.REGULATORY_CROSSWALK

    def test_regulatory_crosswalk(self, classifier, extractor):
        """'Crosswalk for X' should classify as REGULATORY_CROSSWALK."""
        intent, _ = self._classify(classifier, extractor, "Get the crosswalk for ISO 42001")
        assert intent == QueryIntent.REGULATORY_CROSSWALK

    # -------------------------------------------------------------------------
    # Comparative Intent
    # -------------------------------------------------------------------------

    def test_comparative_different_from(self, classifier, extractor):
        """'How is X different from Y?' should classify as COMPARATIVE."""
        intent, _ = self._classify(classifier, extractor, "How is ASHCAI different from ISO 42001?")
        assert intent == QueryIntent.COMPARATIVE

    def test_comparative_compare(self, classifier, extractor):
        """'Compare X with Y' should classify as COMPARATIVE."""
        intent, _ = self._classify(classifier, extractor, "Compare risk management with model monitoring")
        assert intent == QueryIntent.COMPARATIVE

    # -------------------------------------------------------------------------
    # List Entities Intent
    # -------------------------------------------------------------------------

    def test_list_policy_domains(self, classifier, extractor):
        """'List policy domains' should classify as LIST_ENTITIES."""
        intent, _ = self._classify(classifier, extractor, "List all policy domains")
        assert intent == QueryIntent.LIST_ENTITIES

    def test_list_process_domains(self, classifier, extractor):
        """'What process domains exist?' should classify as LIST_ENTITIES."""
        intent, _ = self._classify(classifier, extractor, "What process domains are there?")
        assert intent == QueryIntent.LIST_ENTITIES

    # -------------------------------------------------------------------------
    # Topical Intent
    # -------------------------------------------------------------------------

    def test_topical_how_should_i(self, classifier, extractor):
        """'How should I do X?' should classify as TOPICAL."""
        intent, _ = self._classify(classifier, extractor, "How should I approach bias testing?")
        assert intent == QueryIntent.TOPICAL

    def test_topical_best_practices(self, classifier, extractor):
        """'Best practices for X' should classify as TOPICAL."""
        intent, _ = self._classify(classifier, extractor, "Best practices for model monitoring")
        assert intent == QueryIntent.TOPICAL

    # -------------------------------------------------------------------------
    # Gap Analysis Intent
    # -------------------------------------------------------------------------

    def test_gap_analysis_whats_missing(self, classifier, extractor):
        """'What's missing for X?' should classify as GAP_ANALYSIS."""
        intent, _ = self._classify(classifier, extractor, "What's missing for Colorado AI Act compliance?")
        assert intent == QueryIntent.GAP_ANALYSIS


# =============================================================================
# Query Preprocessor Integration Tests
# =============================================================================


class TestQueryPreprocessor:
    """Integration tests for QueryPreprocessor."""

    @pytest.fixture
    def preprocessor(self):
        return QueryPreprocessor()

    def test_domain_explanation_generates_artifact_fetch(self, preprocessor):
        """Domain explanation should generate ARTIFACT_FETCH strategy."""
        plan = preprocessor.process("What is the Risk Management domain?")

        assert plan.intent == QueryIntent.DOMAIN_EXPLANATION
        assert plan.strategy == RetrievalStrategy.ARTIFACT_FETCH
        # Should return BOTH policy and process overviews for holistic explanation
        assert "PROC-RM-Overview" in plan.target_artifacts
        assert "POL-RMP-Overview" in plan.target_artifacts

    def test_domain_explanation_returns_both_policy_and_process(self, preprocessor):
        """Domain explanation should return both policy and process overviews."""
        # When asking about a concept like "model monitoring", user wants to understand
        # both the policy (what we require) and the process (how we do it)
        plan = preprocessor.process("What is model monitoring?")

        assert plan.intent == QueryIntent.DOMAIN_EXPLANATION
        assert "PROC-MON-Overview" in plan.target_artifacts
        assert "POL-MMP-Overview" in plan.target_artifacts

    def test_domain_explanation_explicit_process_domain(self, preprocessor):
        """Explicit process domain code should also fetch related policy."""
        plan = preprocessor.process("What is the MON domain?")

        assert plan.intent == QueryIntent.DOMAIN_EXPLANATION
        assert "PROC-MON-Overview" in plan.target_artifacts
        assert "POL-MMP-Overview" in plan.target_artifacts

    def test_domain_explanation_explicit_policy_domain(self, preprocessor):
        """Explicit policy domain code should also fetch related process."""
        plan = preprocessor.process("Explain the RMP policy")

        assert plan.intent == QueryIntent.DOMAIN_EXPLANATION
        assert "POL-RMP-Overview" in plan.target_artifacts
        assert "PROC-RM-Overview" in plan.target_artifacts

    def test_known_item_generates_keyword_lookup(self, preprocessor):
        """Known item should generate KEYWORD_LOOKUP strategy."""
        plan = preprocessor.process("Show me SOP-PV-01")

        assert plan.intent == QueryIntent.KNOWN_ITEM
        assert plan.strategy == RetrievalStrategy.KEYWORD_LOOKUP
        assert "SOP-PV-01" in plan.target_artifacts

    def test_structural_generates_graph_traversal(self, preprocessor):
        """Structural query should generate GRAPH_TRAVERSAL strategy."""
        plan = preprocessor.process("What SOPs implement EXC-A4-01?")

        assert plan.intent == QueryIntent.STRUCTURAL
        assert plan.strategy == RetrievalStrategy.GRAPH_TRAVERSAL
        assert plan.graph_traversal == "find_control_implementations"

    def test_regulatory_crosswalk_generates_graph_traversal(self, preprocessor):
        """Regulatory crosswalk should generate GRAPH_TRAVERSAL strategy."""
        plan = preprocessor.process("How do we comply with NIST?")

        assert plan.intent == QueryIntent.REGULATORY_CROSSWALK
        assert plan.strategy == RetrievalStrategy.GRAPH_TRAVERSAL

    def test_comparative_generates_multi_source(self, preprocessor):
        """Comparative query should generate MULTI_SOURCE strategy."""
        plan = preprocessor.process("How is ASHCAI different from ISO 42001?")

        assert plan.intent == QueryIntent.COMPARATIVE
        assert plan.strategy == RetrievalStrategy.MULTI_SOURCE
        assert plan.synthesis_required is True

    def test_topical_generates_semantic_search(self, preprocessor):
        """Topical query should generate SEMANTIC_SEARCH strategy."""
        plan = preprocessor.process("Best practices for bias testing")

        assert plan.intent == QueryIntent.TOPICAL
        assert plan.strategy == RetrievalStrategy.SEMANTIC_SEARCH

    def test_list_entities_generates_ontology_listing(self, preprocessor):
        """List entities should generate ONTOLOGY_LISTING strategy."""
        plan = preprocessor.process("List all process domains")

        assert plan.intent == QueryIntent.LIST_ENTITIES
        assert plan.strategy == RetrievalStrategy.ONTOLOGY_LISTING


# =============================================================================
# Convenience Function Tests
# =============================================================================


class TestPreprocessQueryFunction:
    """Tests for preprocess_query convenience function."""

    def test_preprocess_query_returns_plan(self):
        """preprocess_query should return a QueryPlan."""
        plan = preprocess_query("What is risk management?")

        assert isinstance(plan, QueryPlan)
        assert plan.intent is not None
        assert plan.strategy is not None

    def test_preprocess_query_to_dict(self):
        """QueryPlan.to_dict() should return serializable dict."""
        plan = preprocess_query("Show me SOP-PV-01")
        plan_dict = plan.to_dict()

        assert "intent" in plan_dict
        assert "strategy" in plan_dict
        assert "entities" in plan_dict
        assert plan_dict["intent"] == "known_item"


# =============================================================================
# Test Cases from ADR
# =============================================================================


class TestADRTestCases:
    """Test cases from ASHKBAPP-68 ADR."""

    @pytest.fixture
    def preprocessor(self):
        return QueryPreprocessor()

    @pytest.mark.parametrize(
        "query,expected_intent,expected_resource",
        [
            ("What SOPs implement EXC-A4-01?", QueryIntent.STRUCTURAL, "find_control_implementations"),
            ("Show me SOP-MON-02", QueryIntent.KNOWN_ITEM, None),
            ("What's your approach to bias testing?", QueryIntent.TOPICAL, None),
            ("What work products does MMP-001 produce?", QueryIntent.STRUCTURAL, "get_policy_hierarchy"),
        ],
    )
    def test_adr_test_cases(self, preprocessor, query, expected_intent, expected_resource):
        """Test cases from the ADR specification."""
        plan = preprocessor.process(query)

        assert plan.intent == expected_intent
        if expected_resource:
            assert plan.graph_traversal == expected_resource
