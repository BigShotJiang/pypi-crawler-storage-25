"""
Response Synthesizer for Framework Explorer Pipeline

ASHPSTUDIO-184: Framework Explorer Pipeline

Synthesizes coherent responses from retrieval results using GPT-4o.
Combines structured data (crosswalks, hierarchies) with content snippets
to generate informative, well-cited responses.

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import TYPE_CHECKING, Any

from ashmatics_aigov_tools.services.foundry_client import (
    FoundryClient,
    FoundryClientConfig,
)
from ashmatics_aigov_tools.services.pipeline_config import SynthesizerConfig
from ashmatics_aigov_tools.services.pipeline_models import (
    Citation,
    PipelineContext,
    SynthesisResult,
)
from ashmatics_aigov_tools.services.pipeline_prompts import (
    get_prompt,
)

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.mcp_client import KBMCPClient

logger = logging.getLogger(__name__)


# =============================================================================
# RESPONSE SYNTHESIZER
# =============================================================================


class ResponseSynthesizer:
    """
    Synthesizes coherent responses from retrieval results.

    Uses GPT-4o (via Azure AI Foundry) to:
    - Combine structured data (crosswalks, hierarchies) with content
    - Generate narrative explanations
    - Cite sources appropriately
    - Identify ambiguities and gaps in the response

    Can make additional MCP calls when synthesis needs more context.

    Usage:
        synthesizer = ResponseSynthesizer(mcp_client=client)
        result = await synthesizer.synthesize(context)
        print(result.response)
        print(result.citations)
    """

    def __init__(
        self,
        mcp_client: KBMCPClient | None = None,
        config: SynthesizerConfig | None = None,
    ):
        """
        Initialize the synthesizer.

        Args:
            mcp_client: Optional MCP client for augmentation (additional retrieval)
            config: Synthesizer configuration
        """
        self._client = mcp_client
        self._config = config or SynthesizerConfig()
        self._llm_client: FoundryClient | None = None
        self._prompt = get_prompt(self._config.prompt_name)

    def _get_llm_client(self) -> FoundryClient:
        """Get or create the LLM client."""
        if self._llm_client is None:
            # Create config for the specified model
            foundry_config = FoundryClientConfig.from_env()
            foundry_config.model_deployment = self._config.model
            self._llm_client = FoundryClient(foundry_config)
        return self._llm_client

    async def synthesize(
        self,
        context: PipelineContext,
        refinement_hints: list[str] | None = None,
    ) -> SynthesisResult:
        """
        Generate response from retrieval results.

        Args:
            context: Pipeline context with query plan and orchestration result
            refinement_hints: Optional hints from validation failure (retry scenario)

        Returns:
            SynthesisResult with response, confidence, citations
        """
        start_time = time.time()

        # Build synthesis prompt
        user_prompt = self._build_user_prompt(context, refinement_hints)

        # Call LLM
        llm_response = await self._call_llm(user_prompt)

        # Parse structured output
        result = self._parse_response(llm_response)
        result.model_used = self._config.model
        result.prompt_version = self._prompt.frontmatter.version

        # Optionally augment with additional context if confidence is low
        if (
            result.confidence < self._config.min_confidence_for_augmentation
            and self._config.enable_augmentation
            and self._client is not None
        ):
            logger.info(
                f"Synthesis confidence {result.confidence:.2f} below threshold "
                f"{self._config.min_confidence_for_augmentation}, attempting augmentation"
            )
            result = await self._augment_with_additional_context(context, result)

        # Record timing
        result.synthesis_ms = (time.time() - start_time) * 1000

        return result

    def _build_user_prompt(
        self,
        context: PipelineContext,
        refinement_hints: list[str] | None = None,
    ) -> str:
        """Build the user prompt from context."""
        # Extract data from context
        query = context.query
        intent = "unknown"
        entities: dict[str, Any] = {}

        if context.query_plan:
            intent = context.query_plan.intent.value
            plan_entities = context.query_plan.entities
            entities = {
                "artifact_ids": plan_entities.artifact_ids,
                "policy_domains": plan_entities.policy_domains,
                "process_domains": plan_entities.process_domains,
                "regulatory_frameworks": plan_entities.regulatory_frameworks,
                "control_ids": plan_entities.control_ids,
            }

        # Format structured data
        structured_data = "{}"
        content_snippets = "No content retrieved."

        if context.orchestration_result:
            orch = context.orchestration_result

            # Structured data (crosswalks, hierarchies, etc.)
            if orch.structured_data:
                structured_data = json.dumps(orch.structured_data, indent=2, default=str)

            # Content snippets from search results
            if orch.results:
                snippets = []
                for i, result in enumerate(orch.results[:10], 1):  # Limit to top 10
                    snippet = f"[{i}] {result.document_id}"
                    if result.title:
                        snippet += f" - {result.title}"
                    snippet += f"\n{result.content[:500]}..."  # Truncate long content
                    snippets.append(snippet)
                content_snippets = "\n\n".join(snippets)

        # Add refinement section if retrying
        refinement_section = ""
        if refinement_hints:
            refinement_section = (
                "IMPORTANT - Previous attempt had issues. Please address:\n"
                + "\n".join(f"- {hint}" for hint in refinement_hints)
                + "\n\n"
            )

        return self._prompt.user_template.format(
            query=query,
            intent=intent,
            entities=json.dumps(entities),
            structured_data=structured_data,
            content_snippets=content_snippets,
            refinement_section=refinement_section,
        )

    async def _call_llm(self, user_prompt: str) -> dict[str, Any]:
        """Call the LLM and return parsed response."""
        client = self._get_llm_client()

        # Run synchronous client in thread pool
        def _complete():
            return client.complete_json(
                prompt=user_prompt,
                system_prompt=self._prompt.system,
                temperature=self._config.temperature,
                max_tokens=self._config.max_tokens,
            )

        response = await asyncio.to_thread(_complete)

        # Track token usage if available
        if "usage" in response:
            logger.debug(f"Synthesis tokens: {response.get('usage', {})}")

        return response

    def _parse_response(self, llm_response: dict[str, Any]) -> SynthesisResult:
        """Parse LLM response into SynthesisResult."""
        # Handle parse errors from complete_json
        if "error" in llm_response:
            logger.warning(f"LLM response parse error: {llm_response.get('error')}")
            raw = llm_response.get("raw", "")
            return SynthesisResult(
                response=raw if raw else "Failed to generate response.",
                confidence=0.3,
                citations=[],
                ambiguities=["Response parsing failed - raw output returned"],
            )

        # Extract fields
        response_text = llm_response.get("response", "")
        confidence = float(llm_response.get("confidence", 0.5))
        raw_citations = llm_response.get("citations", [])
        ambiguities = llm_response.get("ambiguities", [])

        # Parse citations
        citations = []
        for raw_cite in raw_citations:
            if isinstance(raw_cite, dict):
                citations.append(
                    Citation(
                        artifact_id=raw_cite.get("artifact_id", ""),
                        artifact_type=raw_cite.get("artifact_type"),
                        relevance=raw_cite.get("relevance", ""),
                    )
                )
            elif isinstance(raw_cite, str):
                citations.append(Citation(artifact_id=raw_cite))

        return SynthesisResult(
            response=response_text,
            confidence=confidence,
            citations=citations,
            ambiguities=ambiguities if isinstance(ambiguities, list) else [ambiguities],
        )

    async def _augment_with_additional_context(
        self,
        context: PipelineContext,
        initial_result: SynthesisResult,
    ) -> SynthesisResult:
        """
        Make additional MCP calls to fill gaps in synthesis.

        Scenarios:
        - Ambiguities identified → fetch related content
        - Missing citations → fetch specific artifacts
        - Low confidence on specific topics → targeted search
        """
        if not self._client:
            return initial_result

        augmentation_calls = 0
        additional_content: list[str] = []
        fetched_artifacts: list[str] = []

        try:
            # Strategy 1: Fetch any cited artifacts that we don't have full content for
            for citation in initial_result.citations[:3]:  # Limit to first 3
                if augmentation_calls >= self._config.max_augmentation_calls:
                    break

                try:
                    artifact = await self._client.get_artifact(citation.artifact_id)
                    if artifact and "content" in artifact:
                        additional_content.append(
                            f"[{citation.artifact_id}]: {artifact['content'][:1000]}"
                        )
                        fetched_artifacts.append(citation.artifact_id)
                        augmentation_calls += 1
                except Exception as e:
                    logger.debug(f"Failed to fetch artifact {citation.artifact_id}: {e}")

            # Strategy 2: If still low confidence and have ambiguities, search for them
            if (
                initial_result.confidence < 0.5
                and initial_result.ambiguities
                and augmentation_calls < self._config.max_augmentation_calls
            ):
                for ambiguity in initial_result.ambiguities[:2]:
                    if augmentation_calls >= self._config.max_augmentation_calls:
                        break

                    try:
                        search_results = await self._client.semantic_search(
                            query=ambiguity,
                            top_k=3,
                        )
                        for sr in search_results:
                            additional_content.append(f"[{sr.artifact_id}]: {sr.content[:500]}")
                        augmentation_calls += 1
                    except Exception as e:
                        logger.debug(f"Augmentation search failed: {e}")

            # If we got additional content, re-synthesize
            if additional_content:
                logger.info(
                    f"Re-synthesizing with {len(additional_content)} additional content pieces"
                )

                # Build augmented prompt
                augmented_prompt = self._build_user_prompt(context)
                augmented_prompt += "\n\nADDITIONAL CONTEXT:\n" + "\n\n".join(additional_content)

                # Re-call LLM
                llm_response = await self._call_llm(augmented_prompt)
                augmented_result = self._parse_response(llm_response)

                # Update metadata
                augmented_result.augmentation_calls = augmentation_calls
                augmented_result.augmentation_artifacts = fetched_artifacts
                augmented_result.model_used = self._config.model
                augmented_result.prompt_version = self._prompt.frontmatter.version

                return augmented_result

        except Exception as e:
            logger.warning(f"Augmentation failed: {e}")

        # Return original if augmentation didn't help
        initial_result.augmentation_calls = augmentation_calls
        return initial_result

    def close(self) -> None:
        """Close the LLM client."""
        if self._llm_client:
            self._llm_client.close()
            self._llm_client = None


__all__ = ["ResponseSynthesizer"]
