"""
LLM-based Query Classifier for ASHKBAPP-68 Phase 2

Provides LLM-assisted intent classification using Microsoft's classy-fire library.
This is the Phase 2 implementation that can be plugged into QueryPreprocessor
when rule-based classification has low confidence.

Requires:
    pip install classy-fire openai

Environment Variables (uses existing Azure OpenAI config):
    AZURE_OPENAI_ENDPOINT - Azure OpenAI endpoint
    AZURE_OPENAI_API_KEY - API key for authentication
    AZURE_OPENAI_CHAT_DEPLOYMENT_NAME - Chat model deployment (e.g., "chat")

Created: 2026-01-26
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.query_preprocessor import (
        ExtractedEntities,
        QueryIntent,
    )

logger = logging.getLogger(__name__)


# Intent categories matching QueryIntent enum
INTENT_CATEGORIES = [
    "structural",           # What implements X? Show hierarchy
    "domain_explanation",   # What is X domain? Explain X
    "regulatory_crosswalk", # How to comply with X? Mapping to X
    "comparative",          # Compare X with Y, how differs
    "explanatory",          # Why does X? What is the purpose
    "topical",              # Best practices, how should we
    "known_item",           # Show me SOP-X, get artifact
    "gap_analysis",         # What's missing for X compliance
    "list_entities",        # List all domains, show frameworks
    "compound",             # Multiple intents combined
]


class LLMQueryClassifier:
    """
    LLM-based query intent classifier using classy-fire.

    Uses Microsoft's classy-fire library which maps class names to single tokens
    and constrains LLM outputs for reliable classification.

    Usage:
        classifier = LLMQueryClassifier()
        intent, confidence = classifier.classify("What is Risk Management?")
        # -> ("domain_explanation", 0.95)

        # For compound queries
        intents = classifier.classify_compound(
            "Compare our risk controls to NIST and identify gaps"
        )
        # -> [("comparative", 0.7), ("gap_analysis", 0.8)]
    """

    def __init__(
        self,
        categories: list[str] | None = None,
        use_azure: bool = True,
        deployment_name: str | None = None,
    ):
        """
        Initialize the classifier.

        Args:
            categories: Intent categories to classify into.
                       Defaults to INTENT_CATEGORIES.
            use_azure: Whether to use Azure OpenAI (vs OpenAI directly).
                      Uses existing AZURE_OPENAI_* environment variables.
            deployment_name: Azure OpenAI deployment name. If None, uses
                           AZURE_OPENAI_CHAT_DEPLOYMENT_NAME env var.
        """
        self.categories = categories or INTENT_CATEGORIES
        self.use_azure = use_azure
        self.deployment_name = deployment_name or os.environ.get(
            "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME", "chat"
        )
        self._classifier = None
        self._mcmc_classifier = None

    def _get_classifier(self):
        """Lazy-load the classy-fire classifier."""
        if self._classifier is None:
            try:
                from classy_fire import LLMClassifier
            except ImportError as e:
                raise ImportError(
                    "classy-fire not installed. Run: pip install classy-fire"
                ) from e

            # Configure OpenAI client for classy-fire
            if self.use_azure:
                self._setup_azure_openai()

            self._classifier = LLMClassifier(
                class_names=self.categories,
                deployment_name=self.deployment_name,
            )

        return self._classifier

    def _get_mcmc_classifier(self):
        """Lazy-load the MCMC classifier for probability distributions."""
        if self._mcmc_classifier is None:
            try:
                from classy_fire import MCMCClassifier
            except ImportError as e:
                raise ImportError(
                    "classy-fire not installed. Run: pip install classy-fire"
                ) from e

            if self.use_azure:
                self._setup_azure_openai()

            self._mcmc_classifier = MCMCClassifier(
                class_names=self.categories,
                deployment_name=self.deployment_name,
            )

        return self._mcmc_classifier

    def _setup_azure_openai(self):
        """Configure OpenAI environment for Azure OpenAI."""
        # classy-fire uses openai package directly, so we configure via
        # environment variables using existing AZURE_OPENAI_* settings

        endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        api_key = os.environ.get("AZURE_OPENAI_API_KEY")
        deployment = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME", "chat")

        if endpoint and api_key:
            # Set OpenAI environment variables for Azure compatibility
            # classy-fire will pick these up automatically
            os.environ["OPENAI_API_TYPE"] = "azure"
            os.environ["OPENAI_API_KEY"] = api_key
            os.environ["OPENAI_API_BASE"] = endpoint
            os.environ["OPENAI_API_VERSION"] = os.environ.get(
                "AZURE_OPENAI_API_VERSION", "2024-02-01"
            )
            # Some libraries use AZURE_OPENAI_DEPLOYMENT
            os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment

            logger.debug(f"Configured OpenAI for Azure: {endpoint}, deployment={deployment}")
        else:
            logger.warning(
                "Azure OpenAI not configured. Set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY"
            )

    def classify(self, query: str) -> tuple[str, float]:
        """
        Classify a query into a single intent category.

        Args:
            query: The user's query to classify

        Returns:
            Tuple of (intent_category, confidence)
            - intent_category: One of the categories (e.g., "domain_explanation")
            - confidence: 1.0 for deterministic classification
        """
        classifier = self._get_classifier()
        result = classifier(query)

        # classy-fire LLMClassifier returns (category_name, category_index) tuple
        if isinstance(result, tuple) and len(result) >= 1:
            return result[0], 1.0

        # Handle if it returns just the category string
        if isinstance(result, str):
            return result, 1.0

        # Handle if it returns a dict with probabilities
        if isinstance(result, dict):
            best_category = max(result, key=result.get)
            return best_category, result[best_category]

        return str(result), 1.0

    def classify_with_probabilities(self, query: str) -> dict[str, float]:
        """
        Classify with probability distribution across all categories.

        Uses MCMC sampling for more robust probability estimates.

        Args:
            query: The user's query

        Returns:
            Dict mapping each category to its probability
        """
        mcmc = self._get_mcmc_classifier()
        return mcmc(query)

    def classify_compound(self, query: str) -> list[tuple[str, float]]:
        """
        Identify multiple intents in a compound query.

        Args:
            query: A potentially compound query

        Returns:
            List of (intent, confidence) tuples for detected intents
        """
        probabilities = self.classify_with_probabilities(query)

        # Return intents with probability > 0.3
        threshold = 0.3
        detected = [
            (cat, prob)
            for cat, prob in probabilities.items()
            if prob > threshold
        ]

        # Sort by probability descending
        return sorted(detected, key=lambda x: x[1], reverse=True)


def create_llm_classifier_callback(
    use_azure: bool = True,
) -> Callable[["str", "ExtractedEntities"], tuple["QueryIntent", float]]:
    """
    Factory function to create an LLM classifier callback for QueryPreprocessor.

    This returns a callable that matches the signature expected by
    QueryPreprocessor's llm_classifier parameter.

    Usage:
        from ashmatics_aigov_tools.services.llm_classifier import (
            create_llm_classifier_callback
        )
        from ashmatics_aigov_tools.services.query_preprocessor import QueryPreprocessor

        # Create preprocessor with LLM fallback
        callback = create_llm_classifier_callback()
        preprocessor = QueryPreprocessor(llm_classifier=callback)

        # Now low-confidence queries will use LLM
        plan = preprocessor.process(
            "Compare our approach to NIST and find gaps",
            use_llm_fallback=True
        )

    Args:
        use_azure: Whether to use Azure OpenAI (uses existing AZURE_OPENAI_* env vars)

    Returns:
        Callback function with signature (query, entities) -> (QueryIntent, float)
    """
    # Import here to avoid circular imports
    from ashmatics_aigov_tools.services.query_preprocessor import QueryIntent

    # Map classy-fire category names to QueryIntent enum
    category_to_intent = {
        "structural": QueryIntent.STRUCTURAL,
        "domain_explanation": QueryIntent.DOMAIN_EXPLANATION,
        "regulatory_crosswalk": QueryIntent.REGULATORY_CROSSWALK,
        "comparative": QueryIntent.COMPARATIVE,
        "explanatory": QueryIntent.EXPLANATORY,
        "topical": QueryIntent.TOPICAL,
        "known_item": QueryIntent.KNOWN_ITEM,
        "gap_analysis": QueryIntent.GAP_ANALYSIS,
        "list_entities": QueryIntent.LIST_ENTITIES,
        "compound": QueryIntent.COMPARATIVE,  # Treat compound as comparative
    }

    classifier = LLMQueryClassifier(use_azure=use_azure)

    def callback(query: str, entities: "ExtractedEntities") -> tuple["QueryIntent", float]:
        """
        LLM classifier callback for QueryPreprocessor.

        Args:
            query: User's query
            entities: Pre-extracted entities (can inform classification)

        Returns:
            Tuple of (QueryIntent, confidence)
        """
        try:
            category, confidence = classifier.classify(query)
            intent = category_to_intent.get(category, QueryIntent.UNKNOWN)
            logger.debug(f"LLM classified '{query[:50]}...' as {intent.value} ({confidence:.2f})")
            return intent, confidence
        except Exception as e:
            logger.error(f"LLM classification failed: {e}")
            return QueryIntent.UNKNOWN, 0.0

    return callback


__all__ = [
    "LLMQueryClassifier",
    "INTENT_CATEGORIES",
    "create_llm_classifier_callback",
]
