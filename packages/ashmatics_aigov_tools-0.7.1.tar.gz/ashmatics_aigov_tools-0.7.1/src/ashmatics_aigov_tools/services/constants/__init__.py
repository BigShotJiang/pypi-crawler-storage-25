"""
Constants and Resolution Functions for AI Governance Query Service SDK

This module provides lookup tables and resolution functions for:
- Policy domain codes and natural language names
- Process domain codes and aliases
- Regulatory framework IDs and aliases
- MCP category mappings

Created: 2026-01-25
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations


# =============================================================================
# POLICY DOMAIN DEFINITIONS
# =============================================================================

# Policy domain codes -> IDs (used for MCP API calls)
POLICY_DOMAIN_IDS: dict[str, str] = {
    "SAP": "SAP-001",
    "AGP": "AGP-001",
    "RMP": "RMP-001",
    "HOP": "HOP-001",
    "EFP": "EFP-001",
    "MMP": "MMP-001",
    "LTP": "LTP-001",
    "CMP": "CMP-001",
    "DGP": "DGP-001",
    "SEP": "SEP-001",
    "VAL": "VAL-001",
    "TPP": "TPP-001",
    "XXX": "XXX-001",  # Unknown/placeholder
}

# Policy domain codes -> full names
POLICY_DOMAIN_CODES: dict[str, str] = {
    "SAP": "Security & Access Policy",
    "AGP": "AI Governance Policy",
    "RMP": "Risk Management Policy",
    "HOP": "Human Oversight Policy",
    "EFP": "Ethics & Fairness Policy",
    "MMP": "Model Management Policy",
    "LTP": "Lifecycle & Training Policy",
    "CMP": "Change Management Policy",
    "DGP": "Data Governance Policy",
    "SEP": "Stakeholder Engagement Policy",
    "VAL": "Validation Policy",
    "TPP": "Transparency Policy",
    "XXX": "Unknown Policy",
}

# Natural language aliases -> policy domain codes (for fuzzy resolution)
POLICY_DOMAIN_ALIASES: dict[str, str] = {
    # Risk Management
    "risk management": "RMP",
    "risk": "RMP",
    "risk policy": "RMP",
    "rmp": "RMP",
    # Model Management
    "model management": "MMP",
    "model monitoring": "MMP",
    "model": "MMP",
    "monitoring": "MMP",
    "mmp": "MMP",
    # Human Oversight
    "human oversight": "HOP",
    "oversight": "HOP",
    "human": "HOP",
    "hop": "HOP",
    # Ethics & Fairness
    "equity and fairness": "EFP",
    "ethics and fairness": "EFP",
    "ethics": "EFP",
    "fairness": "EFP",
    "equity": "EFP",
    "efp": "EFP",
    # AI Governance
    "ai governance": "AGP",
    "governance": "AGP",
    "agp": "AGP",
    # Security & Access
    "security and access": "SAP",
    "security": "SAP",
    "access": "SAP",
    "sap": "SAP",
    # Lifecycle & Training
    "lifecycle and training": "LTP",
    "lifecycle": "LTP",
    "training": "LTP",
    "ltp": "LTP",
    # Change Management
    "change management": "CMP",
    "change": "CMP",
    "cmp": "CMP",
    # Data Governance
    "data governance": "DGP",
    "data": "DGP",
    "dgp": "DGP",
    # Stakeholder Engagement
    "stakeholder engagement": "SEP",
    "stakeholder": "SEP",
    "engagement": "SEP",
    "sep": "SEP",
    # Validation
    "validation": "VAL",
    "val": "VAL",
    # Transparency
    "transparency": "TPP",
    "tpp": "TPP",
}


# =============================================================================
# PROCESS DOMAIN DEFINITIONS
# =============================================================================

# Process domain codes -> full names
PROCESS_DOMAIN_NAMES: dict[str, str] = {
    "ORG": "Organization & Strategy Alignment",
    "OVR": "Oversight & Steering",
    "PV": "Problem & Value Quantification",
    "SA": "Solution Architecting & Local Validation",
    "IT": "IT Systems & Data Management",
    "RM": "Risk Management",
    "MON": "Monitoring & Lifecycle Management",
    "HO": "Human Oversight & AI Interaction",
    "EF": "AI Ethics & Fairness Assessment",
    "TR": "AI Transparency & Explainability",
    "UG": "AI Usage Governance & User Compliance",
    "SE": "Stakeholder Engagement",
    "XX": "Unknown",
    "YY": "Miscellaneous",
}

# Natural language aliases -> process domain codes
PROCESS_DOMAIN_ALIASES: dict[str, str] = {
    "organization": "ORG",
    "strategy": "ORG",
    "oversight": "OVR",
    "steering": "OVR",
    "problem": "PV",
    "value": "PV",
    "solution": "SA",
    "architecting": "SA",
    "it systems": "IT",
    "data management": "IT",
    "risk": "RM",
    "monitoring": "MON",
    "lifecycle": "MON",
    "human oversight": "HO",
    "ai interaction": "HO",
    "ethics": "EF",
    "fairness": "EF",
    "transparency": "TR",
    "explainability": "TR",
    "usage": "UG",
    "user compliance": "UG",
    "stakeholder": "SE",
}


# =============================================================================
# REGULATORY FRAMEWORK DEFINITIONS
# =============================================================================

# Regulatory framework IDs -> full names
REGULATORY_FRAMEWORK_NAMES: dict[str, str] = {
    "NIST-AI-RMF": "NIST AI Risk Management Framework",
    "JC-RUAIH": "Joint Commission Requirements for Use of AI in Healthcare",
    "CO-AI-ACT": "Colorado AI Act",
    "ISO-42001": "ISO/IEC 42001 AI Management System",
    "EU-AI-ACT": "EU AI Act",
    "FDA-GMLP": "FDA Good Machine Learning Practices",
}

# Aliases -> framework IDs
REGULATORY_FRAMEWORK_ALIASES: dict[str, str] = {
    # NIST
    "nist": "NIST-AI-RMF",
    "nist ai rmf": "NIST-AI-RMF",
    "nist-ai-rmf": "NIST-AI-RMF",
    "nist ai": "NIST-AI-RMF",
    # Joint Commission
    "joint commission": "JC-RUAIH",
    "jc": "JC-RUAIH",
    "jc-ruaih": "JC-RUAIH",
    "ruaih": "JC-RUAIH",
    # Colorado
    "colorado": "CO-AI-ACT",
    "co ai act": "CO-AI-ACT",
    "co-ai-act": "CO-AI-ACT",
    # ISO
    "iso": "ISO-42001",
    "iso 42001": "ISO-42001",
    "iso-42001": "ISO-42001",
    # EU
    "eu ai act": "EU-AI-ACT",
    "eu-ai-act": "EU-AI-ACT",
    "eu": "EU-AI-ACT",
    # FDA
    "fda": "FDA-GMLP",
    "fda gmlp": "FDA-GMLP",
    "fda-gmlp": "FDA-GMLP",
    "gmlp": "FDA-GMLP",
}


# =============================================================================
# MCP CATEGORY DEFINITIONS
# =============================================================================

# Valid MCP tool categories (as supported by KB MCP server)
VALID_MCP_CATEGORIES: set[str] = {
    "policies",
    "processes",
}

# Category aliases -> normalized category names
# Note: Only 'policies' and 'processes' currently return data from MCP server
CATEGORY_ALIASES: dict[str, str] = {
    "policy": "policies",
    "policies": "policies",
    "process": "processes",
    "processes": "processes",
}


# =============================================================================
# RESOLUTION FUNCTIONS
# =============================================================================


def resolve_policy_domain(input_value: str) -> str | None:
    """
    Resolve a policy domain code or natural language name to its ID.

    Args:
        input_value: Policy domain code (e.g., "RMP") or natural language
                    name (e.g., "risk management")

    Returns:
        Policy domain ID (e.g., "RMP-001") or None if not found

    Examples:
        >>> resolve_policy_domain("RMP")
        'RMP-001'
        >>> resolve_policy_domain("risk management")
        'RMP-001'
        >>> resolve_policy_domain("unknown")
        None
    """
    normalized = input_value.strip().lower()
    upper = input_value.strip().upper()

    # Direct code lookup (e.g., "RMP" -> "RMP-001")
    if upper in POLICY_DOMAIN_IDS:
        return POLICY_DOMAIN_IDS[upper]

    # Alias lookup (e.g., "risk management" -> "RMP" -> "RMP-001")
    if normalized in POLICY_DOMAIN_ALIASES:
        code = POLICY_DOMAIN_ALIASES[normalized]
        return POLICY_DOMAIN_IDS.get(code)

    return None


def resolve_process_domain(input_value: str) -> str | None:
    """
    Resolve a process domain code or natural language name to its code.

    Args:
        input_value: Process domain code (e.g., "PV") or natural language
                    name (e.g., "problem")

    Returns:
        Process domain code (e.g., "PV") or None if not found
    """
    normalized = input_value.strip().lower()
    upper = input_value.strip().upper()

    # Direct code lookup
    if upper in PROCESS_DOMAIN_NAMES:
        return upper

    # Alias lookup
    if normalized in PROCESS_DOMAIN_ALIASES:
        return PROCESS_DOMAIN_ALIASES[normalized]

    return None


def resolve_regulatory_framework(input_value: str) -> str | None:
    """
    Resolve a regulatory framework alias to its canonical ID.

    Args:
        input_value: Framework ID or alias (e.g., "nist", "NIST-AI-RMF")

    Returns:
        Canonical framework ID (e.g., "NIST-AI-RMF") or None if not found

    Examples:
        >>> resolve_regulatory_framework("nist")
        'NIST-AI-RMF'
        >>> resolve_regulatory_framework("joint commission")
        'JC-RUAIH'
    """
    normalized = input_value.strip().lower()
    upper = input_value.strip().upper()

    # Direct ID lookup (exact match)
    if input_value.strip() in REGULATORY_FRAMEWORK_NAMES:
        return input_value.strip()

    # Try uppercase version
    if upper in REGULATORY_FRAMEWORK_NAMES:
        return upper

    # Alias lookup
    if normalized in REGULATORY_FRAMEWORK_ALIASES:
        return REGULATORY_FRAMEWORK_ALIASES[normalized]

    return None


def resolve_mcp_category(input_value: str) -> str | None:
    """
    Resolve an MCP category alias to its canonical name.

    Args:
        input_value: Category name or alias (e.g., "policy", "sops")

    Returns:
        Canonical category name (e.g., "policies", "templates") or None

    Examples:
        >>> resolve_mcp_category("policy")
        'policies'
        >>> resolve_mcp_category("sops")
        'templates'
    """
    normalized = input_value.strip().lower()

    if normalized in CATEGORY_ALIASES:
        return CATEGORY_ALIASES[normalized]

    return None


# =============================================================================
# LISTING FUNCTIONS
# =============================================================================


def get_all_policy_domains() -> list[dict[str, str]]:
    """
    Get all policy domains as a list of dictionaries.

    Returns:
        List of dicts with 'code', 'id', and 'name' keys

    Example:
        >>> domains = get_all_policy_domains()
        >>> domains[0]
        {'code': 'SAP', 'id': 'SAP-001', 'name': 'Security & Access Policy'}
    """
    return [
        {
            "code": code,
            "id": POLICY_DOMAIN_IDS[code],
            "name": name,
        }
        for code, name in POLICY_DOMAIN_CODES.items()
    ]


def get_all_process_domains() -> list[dict[str, str]]:
    """
    Get all process domains as a list of dictionaries.

    Returns:
        List of dicts with 'code' and 'name' keys
    """
    return [
        {
            "code": code,
            "name": name,
        }
        for code, name in PROCESS_DOMAIN_NAMES.items()
    ]


def get_all_regulatory_frameworks() -> list[dict[str, str]]:
    """
    Get all regulatory frameworks as a list of dictionaries.

    Returns:
        List of dicts with 'id' and 'name' keys

    Example:
        >>> frameworks = get_all_regulatory_frameworks()
        >>> frameworks[0]
        {'id': 'NIST-AI-RMF', 'name': 'NIST AI Risk Management Framework'}
    """
    return [
        {
            "id": framework_id,
            "name": name,
        }
        for framework_id, name in REGULATORY_FRAMEWORK_NAMES.items()
    ]


def get_all_mcp_categories() -> list[str]:
    """
    Get all valid MCP categories.

    Returns:
        List of canonical category names
    """
    return sorted(VALID_MCP_CATEGORIES)


__all__ = [
    # Constants
    "POLICY_DOMAIN_IDS",
    "POLICY_DOMAIN_CODES",
    "POLICY_DOMAIN_ALIASES",
    "PROCESS_DOMAIN_NAMES",
    "PROCESS_DOMAIN_ALIASES",
    "REGULATORY_FRAMEWORK_NAMES",
    "REGULATORY_FRAMEWORK_ALIASES",
    "VALID_MCP_CATEGORIES",
    "CATEGORY_ALIASES",
    # Resolution functions
    "resolve_policy_domain",
    "resolve_process_domain",
    "resolve_regulatory_framework",
    "resolve_mcp_category",
    # Listing functions
    "get_all_policy_domains",
    "get_all_process_domains",
    "get_all_regulatory_frameworks",
    "get_all_mcp_categories",
]
