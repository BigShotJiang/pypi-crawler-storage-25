"""
Query Preprocessor for AI Governance Framework SDK

Intelligent query routing layer that analyzes user queries and determines
the optimal retrieval strategy before hitting any backend.

Architecture: Two-Stage Classification with Refinement Oracle
─────────────────────────────────────────────────────────────
Stage 1: Lightweight Classification (rule-based, ~0 cost, <10ms)
    - EntityExtractor: Regex-based entity extraction
    - IntentClassifier: Keyword pattern matching
    - Output: QueryPlan with confidence score

Stage 2: Refinement Oracle (LLM-based, ~$0.001, 2-3s)
    - Only invoked when Stage 1 confidence < threshold
    - Uses DeepSeek-R1 via Azure Foundry
    - Single chat completion (NOT agentic)
    - Purpose: Resolve ambiguous intents, infer implicit entities

Architecture Reference: PLAN-LLM-Query-Preprocessor-Phase2-ASHKBAPP68.md

Created: 2026-01-26
Updated: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


# =============================================================================
# CONFIGURATION
# =============================================================================


@dataclass
class QueryPreprocessorConfig:
    """
    Configuration for query preprocessing with Refinement Oracle.

    Controls cost, latency, and behavior of the two-stage classification.

    Example:
        # Default: LLM enabled with 0.7 threshold
        config = QueryPreprocessorConfig()

        # Cost-zero mode: disable LLM entirely
        config = QueryPreprocessorConfig(enable_refinement_oracle=False)

        # Aggressive LLM use: lower threshold
        config = QueryPreprocessorConfig(refinement_threshold=0.5)
    """

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 1: Lightweight Classification Controls
    # ─────────────────────────────────────────────────────────────────────────

    # Confidence threshold to skip Refinement Oracle (Stage 2)
    # Higher = fewer LLM calls, but may miss ambiguous queries
    # Lower = more LLM calls, better accuracy on edge cases
    refinement_threshold: float = 0.7

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 2: Refinement Oracle Controls
    # ─────────────────────────────────────────────────────────────────────────

    # Master switch for LLM refinement (set False for cost-zero mode)
    enable_refinement_oracle: bool = True

    # Model configuration (falls back to environment variables if None)
    # GPT-4o-mini is recommended for fast, cheap classification (1-2s, ~$0.0002/query)
    # Avoid reasoning models (DeepSeek-R1, o1) - they're overkill for classification
    refinement_model: str = "gpt-4o-mini"
    refinement_endpoint: str | None = None  # Defaults to Azure Foundry OpenAI endpoint
    refinement_api_key: str | None = None   # AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY

    # Request limits (tuned for fast classification models)
    refinement_timeout: float = 10.0        # GPT-4o-mini responds in 1-2s
    refinement_max_tokens: int = 200        # Classification output is small JSON
    refinement_temperature: float = 0.1     # Lower = more deterministic for classification

    # ─────────────────────────────────────────────────────────────────────────
    # Observability
    # ─────────────────────────────────────────────────────────────────────────

    # Log classification decisions for debugging and analysis
    log_classifications: bool = True

    # Track token usage for cost monitoring (requires OpenAI SDK usage info)
    track_token_usage: bool = True

    # ─────────────────────────────────────────────────────────────────────────
    # Safety Controls
    # ─────────────────────────────────────────────────────────────────────────

    # Circuit breaker: disable Refinement Oracle after N consecutive failures
    max_consecutive_failures: int = 3

    # Rate limiting: max LLM calls per minute (0 = unlimited)
    max_refinements_per_minute: int = 0

    def get_endpoint(self) -> str:
        """
        Get refinement endpoint from config or environment.

        Uses Azure Foundry OpenAI-compatible endpoint format:
        https://{resource}.openai.azure.com/openai/v1/

        This endpoint works with the standard OpenAI Python SDK.

        Environment variables (checked in order):
        - AZURE_FOUNDRY_OPENAI_ENDPOINT: Already in OpenAI-compatible format (preferred)
        - Falls back to hardcoded kb-search-parse endpoint
        """
        if self.refinement_endpoint:
            return self.refinement_endpoint

        # Check for explicit OpenAI-compatible Foundry endpoint (preferred)
        endpoint = os.getenv("AZURE_FOUNDRY_OPENAI_ENDPOINT", "")
        if endpoint:
            endpoint = endpoint.rstrip("/")
            if not endpoint.endswith("/"):
                endpoint = f"{endpoint}/"
            return endpoint

        # Default: kb-search-parse OpenAI-compatible endpoint (known working)
        return "https://kb-search-parse.openai.azure.com/openai/v1/"

    def get_api_key(self) -> str | None:
        """Get API key from config or environment."""
        if self.refinement_api_key:
            return self.refinement_api_key
        # Try multiple env var names for flexibility
        return (
            os.getenv("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")
            or os.getenv("AZURE_FOUNDRY_API_KEY")
        )


# =============================================================================
# INTENT CATEGORIES
# =============================================================================


class QueryIntent(str, Enum):
    """
    Query intent categories for routing decisions.

    Maps to different retrieval strategies:
    - STRUCTURAL: Graph traversal (Tier 1)
    - DOMAIN_EXPLANATION: Fetch OverviewSummary artifacts
    - REGULATORY_CROSSWALK: Graph + YAML crosswalks
    - COMPARATIVE: Multi-source fusion
    - EXPLANATORY: Semantic + Graph context
    - TOPICAL: Semantic search
    - KNOWN_ITEM: Direct artifact lookup
    - GAP_ANALYSIS: Graph analysis
    - LIST_ENTITIES: Ontology listing (not document listing)
    - UNKNOWN: Fallback to broad semantic search
    """

    STRUCTURAL = "structural"
    DOMAIN_EXPLANATION = "domain_explanation"
    REGULATORY_CROSSWALK = "regulatory_crosswalk"
    COMPARATIVE = "comparative"
    EXPLANATORY = "explanatory"
    TOPICAL = "topical"
    KNOWN_ITEM = "known_item"
    GAP_ANALYSIS = "gap_analysis"
    LIST_ENTITIES = "list_entities"
    UNKNOWN = "unknown"


class RetrievalStrategy(str, Enum):
    """Primary retrieval strategy for a query."""

    GRAPH_TRAVERSAL = "graph"          # Tier 1: Pre-built NetworkX traversals
    SEMANTIC_SEARCH = "semantic"        # Vector similarity search
    KEYWORD_LOOKUP = "keyword"          # Direct artifact lookup
    MULTI_SOURCE = "multi_source"       # Fusion of multiple sources
    ONTOLOGY_LISTING = "ontology"       # List entities from ontology (not docs)
    ARTIFACT_FETCH = "artifact_fetch"   # Fetch specific OverviewSummary


# =============================================================================
# DATA CLASSES
# =============================================================================


@dataclass
class ExtractedEntities:
    """
    Entities extracted from a query.

    Used for routing decisions and query augmentation.
    """

    # Artifact IDs found in query (e.g., "SOP-PV-01", "POL-RMP-Overview")
    artifact_ids: list[str] = field(default_factory=list)

    # Policy domain codes (e.g., "RMP", "AGP")
    policy_domains: list[str] = field(default_factory=list)

    # Process domain codes (e.g., "PV", "MON", "RM")
    process_domains: list[str] = field(default_factory=list)

    # Regulatory framework IDs (e.g., "NIST-AI-RMF", "JC-RUAIH")
    regulatory_frameworks: list[str] = field(default_factory=list)

    # Control IDs (e.g., "EXC-A4-01")
    control_ids: list[str] = field(default_factory=list)

    # Regulatory requirement IDs (e.g., "NIST-AI-RMF-GOVERN-1.1")
    requirement_ids: list[str] = field(default_factory=list)

    # Raw entity mentions (unresolved natural language)
    raw_mentions: list[str] = field(default_factory=list)

    def has_entities(self) -> bool:
        """Check if any entities were extracted."""
        return bool(
            self.artifact_ids
            or self.policy_domains
            or self.process_domains
            or self.regulatory_frameworks
            or self.control_ids
            or self.requirement_ids
        )

    def get_primary_domain(self) -> str | None:
        """Get the most relevant domain code for the query."""
        if self.process_domains:
            return self.process_domains[0]
        if self.policy_domains:
            return self.policy_domains[0]
        return None


@dataclass
class QueryPlan:
    """
    Execution plan for a query.

    Tells the orchestrator which MCP tools to call and with what parameters.

    The key output fields for MCP routing are:
    - suggested_mcp_tool: The primary MCP tool to call (e.g., "semantic_search_framework")
    - mcp_tool_params: Parameters to pass to that tool

    Valid MCP tool names:
    - "get_artifact" - Fetch specific artifact by ID
    - "semantic_search_framework" - Vector similarity search
    - "get_policy_domain_hierarchy" - Graph traversal for policy tree
    - "find_control_implementations" - Find SOPs implementing a control
    - "get_regulatory_crosswalk" - Regulatory framework mappings
    - "find_evidence_for_requirement" - Evidence for regulatory requirements
    - "get_ashcai_statistics" - Ontology statistics
    - "get_category_content" - List content by category
    """

    # Classified intent
    intent: QueryIntent

    # Primary retrieval strategy
    strategy: RetrievalStrategy

    # Extracted entities
    entities: ExtractedEntities

    # Confidence score (0.0 - 1.0) - lower = may need LLM classification
    confidence: float = 1.0

    # ─────────────────────────────────────────────────────────────────────────
    # MCP Tool Selection (PRIMARY OUTPUT for routing)
    # ─────────────────────────────────────────────────────────────────────────

    # The MCP tool to call - this is the key output for the orchestrator
    suggested_mcp_tool: str | None = None

    # Parameters to pass to the MCP tool
    mcp_tool_params: dict[str, Any] = field(default_factory=dict)

    # For multi-source: additional tools to call in parallel
    additional_mcp_tools: list[dict[str, Any]] = field(default_factory=list)

    # ─────────────────────────────────────────────────────────────────────────
    # Legacy fields (still used by QueryOrchestrator)
    # ─────────────────────────────────────────────────────────────────────────

    # For graph traversals
    graph_traversal: str | None = None  # e.g., "policy_hierarchy", "control_implementations"

    # For artifact fetch
    target_artifacts: list[str] = field(default_factory=list)

    # For semantic search
    search_query: str | None = None
    search_filters: dict[str, Any] = field(default_factory=dict)

    # For multi-source fusion
    sub_plans: list[QueryPlan] = field(default_factory=list)
    synthesis_required: bool = False

    # Execution hints
    top_k: int = 5
    min_score: float = 0.0

    # Debug info
    classification_signals: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for logging/debugging."""
        return {
            "intent": self.intent.value,
            "strategy": self.strategy.value,
            "confidence": self.confidence,
            # MCP tool routing (primary output)
            "suggested_mcp_tool": self.suggested_mcp_tool,
            "mcp_tool_params": self.mcp_tool_params,
            "additional_mcp_tools": self.additional_mcp_tools,
            # Entities
            "entities": {
                "artifact_ids": self.entities.artifact_ids,
                "policy_domains": self.entities.policy_domains,
                "process_domains": self.entities.process_domains,
                "regulatory_frameworks": self.entities.regulatory_frameworks,
                "control_ids": self.entities.control_ids,
            },
            # Legacy fields
            "graph_traversal": self.graph_traversal,
            "target_artifacts": self.target_artifacts,
            "search_query": self.search_query,
            "classification_signals": self.classification_signals,
        }


# =============================================================================
# PATTERN DEFINITIONS
# =============================================================================

# Artifact ID patterns (regex)
ARTIFACT_PATTERNS = {
    # Policy Overview: POL-{CODE}-Overview
    "policy_overview": re.compile(r"\bPOL-([A-Z]{3})-Overview\b", re.IGNORECASE),

    # Process Overview: PROC-{CODE}-Overview
    "process_overview": re.compile(r"\bPROC-([A-Z]{2,3})-Overview\b", re.IGNORECASE),

    # Policy Template: POLT-{CODE}-Template
    "policy_template": re.compile(r"\bPOLT-([A-Z]{3})-Template\b", re.IGNORECASE),

    # SOP: SOP-{CODE}-{NUM}
    "sop": re.compile(r"\bSOP-([A-Z]{2,3})-(\d{2})\b", re.IGNORECASE),

    # Work Product: WP-{CODE}-{NUM}
    "work_product": re.compile(r"\bWP-([A-Z]{2,3})-(\d{2}[a-z]?)\b", re.IGNORECASE),

    # Framework docs: FW-{Name}
    "framework": re.compile(r"\bFW-([A-Za-z]+)\b"),

    # Controls: CTRL-{Name} or EXC-A{N}-{NN}
    "control_artifact": re.compile(r"\bCTRL-([A-Za-z]+)\b"),
    "exemplar_control": re.compile(r"\bEXC-A(\d+)-(\d{2})\b", re.IGNORECASE),

    # Wizard schemas: WIZS-{CODE}
    "wizard_schema": re.compile(r"\bWIZS-([A-Z]{2,3})\b", re.IGNORECASE),

    # Generic artifact ID (prefix-code pattern)
    # Excludes NIST-AI-RMF, ISO-42001, JC-RUAIH patterns (regulatory requirement prefixes)
    # Also excludes AI-RMF (substring of NIST-AI-RMF-GOVERN-1.1)
    "generic": re.compile(r"\b(?!NIST-AI|ISO-42|JC-RU|AI-RMF)([A-Z]{2,5})-([A-Z]{2,3})-([A-Za-z0-9-]+)\b"),
}

# Regulatory requirement ID patterns
REQUIREMENT_PATTERNS = {
    "nist": re.compile(r"\bNIST-AI-RMF-([A-Z]+-\d+(?:\.\d+)?)\b", re.IGNORECASE),
    "jc": re.compile(r"\bJC-RUAIH-(\d+(?:\.\d+)?)\b", re.IGNORECASE),
    "iso": re.compile(r"\bISO-42001-([A-Z]\.\d+(?:\.\d+)?)\b", re.IGNORECASE),
}

# Policy domain codes (3-letter)
POLICY_DOMAIN_CODES = {
    "SAP", "AGP", "RMP", "HOP", "EFP", "MMP",
    "LTP", "CMP", "DGP", "SEP", "VAL", "TPP"
}

# Process domain codes (2-3 letter)
PROCESS_DOMAIN_CODES = {
    "PV", "SA", "MON", "OVR", "ORG", "IT",
    "RM", "HO", "EF", "TR", "UG", "SE"
}

# Regulatory framework aliases -> canonical IDs
REGULATORY_FRAMEWORK_ALIASES: dict[str, str] = {
    # NIST
    "nist": "NIST-AI-RMF",
    "nist ai rmf": "NIST-AI-RMF",
    "nist ai": "NIST-AI-RMF",
    "nist rmf": "NIST-AI-RMF",
    "nist-ai-rmf": "NIST-AI-RMF",
    # Joint Commission
    "joint commission": "JC-RUAIH",
    "jc": "JC-RUAIH",
    "jc-ruaih": "JC-RUAIH",
    "ruaih": "JC-RUAIH",
    # Colorado
    "colorado": "CO-AI-ACT",
    "colorado ai act": "CO-AI-ACT",
    "co ai act": "CO-AI-ACT",
    # ISO
    "iso 42001": "ISO-42001",
    "iso-42001": "ISO-42001",
    "iso42001": "ISO-42001",
    # EU
    "eu ai act": "EU-AI-ACT",
    "eu-ai-act": "EU-AI-ACT",
    # FDA
    "fda gmlp": "FDA-GMLP",
    "fda-gmlp": "FDA-GMLP",
    "gmlp": "FDA-GMLP",
}

# Natural language -> domain code mappings
# Import comprehensive aliases from ashcai_vocabulary module
from ashmatics_aigov_tools.services.ashcai_vocabulary import (
    DOMAIN_ALIASES,
    REFINEMENT_CONTEXT_SECTION,
)

# Process domain -> Policy domain mapping (for holistic domain explanations)
# When user asks "What is X?", we want to show BOTH policy and process overviews
PROCESS_TO_POLICY_MAPPING: dict[str, str] = {
    "RM": "RMP",    # Risk Management
    "MON": "MMP",   # Model Monitoring -> Model Management Policy
    "HO": "HOP",    # Human Oversight
    "EF": "EFP",    # Ethics & Fairness
    "TR": "TPP",    # Transparency
    "PV": "VAL",    # Problem & Value -> Validation Policy
    "SA": "SAP",    # Solution Architecting -> Security & Access Policy
    "OVR": "AGP",   # Oversight -> AI Governance Policy
    "ORG": "AGP",   # Organization -> AI Governance Policy
    "IT": "DGP",    # IT Systems -> Data Governance Policy
    "SE": "SEP",    # Stakeholder Engagement
    "UG": "AGP",    # Usage Governance -> AI Governance Policy
}

# Policy domain -> Process domain mapping (reverse lookup)
POLICY_TO_PROCESS_MAPPING: dict[str, str] = {
    "RMP": "RM",
    "MMP": "MON",
    "HOP": "HO",
    "EFP": "EF",
    "TPP": "TR",
    "VAL": "PV",
    "SAP": "SA",
    "AGP": "OVR",  # AI Governance -> Oversight (primary)
    "DGP": "IT",
    "SEP": "SE",
    "LTP": "MON",  # Lifecycle & Training -> Monitoring
    "CMP": "MON",  # Change Management -> Monitoring (lifecycle)
}


# =============================================================================
# INTENT CLASSIFICATION PATTERNS
# =============================================================================

# Patterns that signal specific intents
INTENT_SIGNALS: dict[QueryIntent, list[re.Pattern]] = {
    QueryIntent.STRUCTURAL: [
        re.compile(r"\bwhat\s+(sops?|work\s*products?|templates?)\s+(implement|produce|require)", re.I),
        re.compile(r"\bshow\s+(me\s+)?(the\s+)?hierarchy", re.I),
        re.compile(r"\bwhat\s+(does|do)\s+\w+\s+produce", re.I),
        re.compile(r"\bwhat\s+work\s*products?\s+(does|do)", re.I),  # "what work products does X produce"
        re.compile(r"\b[A-Z]{2,3}-\d+\s+produce", re.I),  # "MMP-001 produce"
        re.compile(r"\blist\s+(all\s+)?(sops?|work\s*products?|controls?)\s+(for|in|under)", re.I),
        re.compile(r"\bhierarchy\s+(of|under|for)", re.I),
        re.compile(r"\bwhat\s+implements", re.I),
        re.compile(r"\bstructure\s+(of|for)", re.I),
        re.compile(r"\brelationship(s)?\s+between", re.I),
        # ASHKBAPP-185: Catch "work products for X" pattern
        re.compile(r"\bwork\s*products?\s+(for|of|in)\s+", re.I),  # "work products for problem validation"
        re.compile(r"\bsops?\s+(for|of|in)\s+", re.I),  # "SOPs for risk management"
        re.compile(r"\bartifacts?\s+(for|of|in)\s+", re.I),  # "artifacts for PV domain"
        re.compile(r"\btemplates?\s+(for|of|in)\s+", re.I),  # "templates for human oversight"
    ],

    QueryIntent.DOMAIN_EXPLANATION: [
        re.compile(r"\bwhat\s+is\s+(the\s+)?(\w+\s+)?(domain|policy|process)\b", re.I),
        re.compile(r"\bexplain\s+(the\s+)?(\w+\s+)?(domain|policy|process)\b", re.I),
        re.compile(r"\btell\s+me\s+about\s+(the\s+)?(\w+\s+)?(domain|policy|process)\b", re.I),
        re.compile(r"\bdescribe\s+(the\s+)?(\w+\s+)?(domain|policy|process)\b", re.I),
        re.compile(r"\bwhat\s+does\s+(\w+)\s+(domain\s+)?(cover|address|include)", re.I),
        re.compile(r"\boverview\s+of\s+(\w+)", re.I),
        re.compile(r"\bwhat\s+is\s+(risk\s+management|model\s+monitoring|human\s+oversight|ethics|fairness|transparency|validation)\b", re.I),
    ],

    QueryIntent.REGULATORY_CROSSWALK: [
        re.compile(r"\bhow\s+(do\s+we|to)\s+comply\s+with", re.I),
        re.compile(r"\bcompliance\s+(with|for|mapping)", re.I),
        re.compile(r"\bcrosswalk\s+(for|to|with)", re.I),
        re.compile(r"\bmap(ping)?\s+(to|from)\s+\w+\s+(framework|standard|regulation)", re.I),
        re.compile(r"\bwhat\s+addresses\s+\w+\s+(requirement|control)", re.I),
        re.compile(r"\bevidence\s+for\s+\w+", re.I),
        re.compile(r"\b(nist|iso|joint\s*commission|colorado|fda)\b.*\b(mapping|compliance|crosswalk|requirement)", re.I),
    ],

    QueryIntent.COMPARATIVE: [
        re.compile(r"\bhow\s+(is|does)\s+\w+\s+differ(ent)?\s+from", re.I),
        re.compile(r"\bcompare\s+.+\s+(to|with|and|vs)\s+", re.I),  # "compare X with Y"
        re.compile(r"\bcompare\s+\w+", re.I),  # Simple "compare X"
        re.compile(r"\b(difference|comparison)\s+between", re.I),
        re.compile(r"\bvs\.?\b", re.I),
        re.compile(r"\bhow\s+does\s+\w+\s+relate\s+to", re.I),
    ],

    QueryIntent.EXPLANATORY: [
        re.compile(r"\bwhy\s+(does|do|is|are|did)", re.I),
        re.compile(r"\bexplain\s+why", re.I),
        re.compile(r"\bwhat\s+is\s+the\s+purpose\s+of", re.I),
        re.compile(r"\bwhat\s+is\s+the\s+rationale", re.I),
        re.compile(r"\bhow\s+does\s+\w+\s+work", re.I),
    ],

    QueryIntent.KNOWN_ITEM: [
        re.compile(r"\b(show|get|fetch|find|retrieve|display)\s+(me\s+)?SOP-", re.I),
        re.compile(r"\b(show|get|fetch|find|retrieve|display)\s+(me\s+)?WP-", re.I),
        re.compile(r"\b(show|get|fetch|find|retrieve|display)\s+(me\s+)?POL-", re.I),
        re.compile(r"\b(show|get|fetch|find|retrieve|display)\s+(me\s+)?PROC-", re.I),
        re.compile(r"\bopen\s+(the\s+)?[A-Z]{2,5}-", re.I),
    ],

    QueryIntent.GAP_ANALYSIS: [
        re.compile(r"\bwhat('s|\s+is)\s+missing", re.I),  # "what's missing" anywhere
        re.compile(r"\bgap(s)?\s+(analysis|in|for)", re.I),
        re.compile(r"\bcoverage\s+(for|of)", re.I),
        re.compile(r"\bwhat\s+(controls?|requirements?)\s+(are\s+)?(we\s+)?missing", re.I),
        re.compile(r"\bmissing\s+(for|in)\s+.+\s+compliance", re.I),  # "missing for X compliance"
    ],

    QueryIntent.LIST_ENTITIES: [
        re.compile(r"\blist\s+(all\s+)?(the\s+)?(policy|process)\s+domains?\b", re.I),
        re.compile(r"\bwhat\s+(policy|process)\s+domains?\s+(are\s+there|exist|do\s+you\s+have)", re.I),
        re.compile(r"\bshow\s+(me\s+)?(all\s+)?(the\s+)?domains?\b", re.I),
        re.compile(r"\bhow\s+many\s+(policy|process)\s+domains?", re.I),
        re.compile(r"\blist\s+(regulatory\s+)?frameworks?", re.I),
        # Added: "show me all frameworks"
        re.compile(r"\bshow\s+(me\s+)?(all\s+)?(the\s+)?(regulatory\s+)?frameworks?\b", re.I),
        # Added: "list all SOPs" / "list SOPs"
        re.compile(r"\blist\s+(all\s+)?(the\s+)?sops?\b", re.I),
        re.compile(r"\bshow\s+(me\s+)?(all\s+)?(the\s+)?sops?\b", re.I),
    ],

    QueryIntent.TOPICAL: [
        re.compile(r"\bhow\s+(do|should|can)\s+(i|we|you)", re.I),
        re.compile(r"\bbest\s+practice(s)?\s+for", re.I),
        re.compile(r"\bapproach\s+(to|for)", re.I),
        re.compile(r"\bguidance\s+(on|for)", re.I),
        re.compile(r"\brecommendation(s)?\s+for", re.I),
    ],
}


# =============================================================================
# ENTITY EXTRACTOR
# =============================================================================


class EntityExtractor:
    """
    Extracts structured entities from natural language queries.

    Identifies:
    - Artifact IDs (SOP-PV-01, POL-RMP-Overview, etc.)
    - Domain codes (RMP, MON, PV, etc.)
    - Regulatory frameworks (NIST-AI-RMF, etc.)
    - Control IDs (EXC-A4-01, etc.)
    - Requirement IDs (NIST-AI-RMF-GOVERN-1.1, etc.)
    """

    def extract(self, query: str) -> ExtractedEntities:
        """
        Extract all entities from a query.

        Args:
            query: User's natural language query

        Returns:
            ExtractedEntities with all found entities
        """
        entities = ExtractedEntities()
        query_lower = query.lower()

        # Extract artifact IDs
        entities.artifact_ids = self._extract_artifact_ids(query)

        # Extract domain codes (both explicit codes and natural language)
        policy_domains, process_domains = self._extract_domains(query)
        entities.policy_domains = policy_domains
        entities.process_domains = process_domains

        # Extract regulatory frameworks
        entities.regulatory_frameworks = self._extract_frameworks(query_lower)

        # Extract control IDs
        entities.control_ids = self._extract_control_ids(query)

        # Extract requirement IDs
        entities.requirement_ids = self._extract_requirement_ids(query)

        return entities

    def _extract_artifact_ids(self, query: str) -> list[str]:
        """Extract artifact IDs from query."""
        artifact_ids: list[str] = []

        for pattern_name, pattern in ARTIFACT_PATTERNS.items():
            for match in pattern.finditer(query):
                # Normalize to uppercase
                artifact_id = match.group(0).upper()
                if artifact_id not in artifact_ids:
                    artifact_ids.append(artifact_id)

        return artifact_ids

    def _extract_domains(self, query: str) -> tuple[list[str], list[str]]:
        """Extract policy and process domain codes."""
        policy_domains: list[str] = []
        process_domains: list[str] = []
        query_upper = query.upper()
        query_lower = query.lower()

        # Check for explicit domain codes
        for code in POLICY_DOMAIN_CODES:
            # Look for code as standalone word
            if re.search(rf"\b{code}\b", query_upper):
                if code not in policy_domains:
                    policy_domains.append(code)

        for code in PROCESS_DOMAIN_CODES:
            if re.search(rf"\b{code}\b", query_upper):
                if code not in process_domains:
                    process_domains.append(code)

        # Check natural language aliases
        for alias, (code, domain_type) in DOMAIN_ALIASES.items():
            if alias in query_lower:
                if domain_type == "policy" and code not in policy_domains:
                    policy_domains.append(code)
                elif domain_type == "process" and code not in process_domains:
                    process_domains.append(code)

        return policy_domains, process_domains

    def _extract_frameworks(self, query_lower: str) -> list[str]:
        """Extract regulatory framework IDs."""
        frameworks: list[str] = []

        for alias, framework_id in REGULATORY_FRAMEWORK_ALIASES.items():
            if alias in query_lower:
                if framework_id not in frameworks:
                    frameworks.append(framework_id)

        return frameworks

    def _extract_control_ids(self, query: str) -> list[str]:
        """Extract exemplar control IDs."""
        control_ids: list[str] = []

        pattern = ARTIFACT_PATTERNS["exemplar_control"]
        for match in pattern.finditer(query):
            control_id = match.group(0).upper()
            if control_id not in control_ids:
                control_ids.append(control_id)

        return control_ids

    def _extract_requirement_ids(self, query: str) -> list[str]:
        """Extract regulatory requirement IDs."""
        requirement_ids: list[str] = []

        for pattern in REQUIREMENT_PATTERNS.values():
            for match in pattern.finditer(query):
                req_id = match.group(0).upper()
                if req_id not in requirement_ids:
                    requirement_ids.append(req_id)

        return requirement_ids


# =============================================================================
# INTENT CLASSIFIER (Stage 1)
# =============================================================================


class IntentClassifier:
    """
    Rule-based intent classifier for query routing (Stage 1).

    Uses keyword patterns and extracted entities to classify query intent.
    Fast and cost-free, but may have low confidence on ambiguous queries.
    """

    def __init__(
        self,
        llm_classifier: Callable[[str, ExtractedEntities], tuple[QueryIntent, float]] | None = None
    ):
        """
        Initialize the classifier.

        Args:
            llm_classifier: Optional custom LLM classifier callback (for testing).
                           Signature: (query, entities) -> (intent, confidence)
                           Note: Prefer using QueryPreprocessor with config for LLM.
        """
        self._llm_classifier = llm_classifier

    def classify(
        self,
        query: str,
        entities: ExtractedEntities,
        use_llm_fallback: bool = False,
    ) -> tuple[QueryIntent, float, list[str]]:
        """
        Classify query intent.

        Args:
            query: User's query
            entities: Pre-extracted entities
            use_llm_fallback: Whether to use LLM for low-confidence results

        Returns:
            Tuple of (intent, confidence, signals)
            - intent: Classified QueryIntent
            - confidence: 0.0-1.0 confidence score
            - signals: List of matching signal descriptions for debugging
        """
        signals: list[str] = []
        intent_scores: dict[QueryIntent, float] = {intent: 0.0 for intent in QueryIntent}

        # Check for explicit artifact ID -> KNOWN_ITEM
        if entities.artifact_ids:
            intent_scores[QueryIntent.KNOWN_ITEM] += 0.8
            signals.append(f"artifact_ids_found: {entities.artifact_ids}")

        # Check for regulatory frameworks
        if entities.regulatory_frameworks:
            intent_scores[QueryIntent.REGULATORY_CROSSWALK] += 0.4
            signals.append(f"frameworks_found: {entities.regulatory_frameworks}")

        # Check for regulatory requirement IDs (e.g., NIST-AI-RMF-GOVERN-1.1)
        # Strong signal for regulatory_crosswalk - higher than artifact_ids for known_item
        if entities.requirement_ids:
            intent_scores[QueryIntent.REGULATORY_CROSSWALK] += 0.9
            signals.append(f"requirement_ids_found: {entities.requirement_ids}")

        # Check for control IDs -> STRUCTURAL
        if entities.control_ids:
            intent_scores[QueryIntent.STRUCTURAL] += 0.6
            signals.append(f"control_ids_found: {entities.control_ids}")

        # Check pattern signals
        for intent, patterns in INTENT_SIGNALS.items():
            for pattern in patterns:
                if pattern.search(query):
                    intent_scores[intent] += 0.5
                    signals.append(f"pattern_match: {intent.value} <- {pattern.pattern[:50]}")

        # Domain + explanation keywords -> DOMAIN_EXPLANATION
        # But NOT when asking "what is the purpose of" (that's EXPLANATORY intent)
        if (entities.policy_domains or entities.process_domains):
            # Check if query is asking "what is" about the domain
            if re.search(r"\bwhat\s+is\b|\bexplain\b|\bdescribe\b|\btell\s+me\s+about\b", query, re.I):
                # Don't boost if it's a "purpose of" question (explanatory intent)
                if not re.search(r"\bpurpose\s+of\b|\brationale\s+for\b", query, re.I):
                    intent_scores[QueryIntent.DOMAIN_EXPLANATION] += 0.7
                    signals.append("domain_explanation_boost: domain + explanatory keyword")

        # Find highest scoring intent
        best_intent = max(intent_scores, key=intent_scores.get)
        best_score = intent_scores[best_intent]

        # Normalize confidence
        if best_score > 0:
            confidence = min(1.0, best_score)
        else:
            confidence = 0.3  # Low confidence for no matches
            best_intent = QueryIntent.UNKNOWN

        # LLM fallback for low confidence (Phase 2)
        if use_llm_fallback and confidence < 0.5 and self._llm_classifier:
            llm_intent, llm_confidence = self._llm_classifier(query, entities)
            if llm_confidence > confidence:
                best_intent = llm_intent
                confidence = llm_confidence
                signals.append(f"llm_override: {llm_intent.value} ({llm_confidence:.2f})")

        return best_intent, confidence, signals


# =============================================================================
# REFINEMENT ORACLE (Stage 2)
# =============================================================================

# System prompt template for Refinement Oracle (optimized for GPT-4o-mini)
# Uses REFINEMENT_CONTEXT_SECTION from ashcai_vocabulary for domain context
REFINEMENT_SYSTEM_PROMPT = f'''You classify user queries about the Asher Informatics Clinical AI (ASHCAI) Governance Framework. Output ONLY valid JSON.

{REFINEMENT_CONTEXT_SECTION}

INTERPRETATION RULES:
1. ALWAYS interpret queries in the ASHCAI framework context FIRST
2. Match natural language terms to ASHCAI domains (e.g., "problem validation" → PV domain)
3. Only fall back to general AI governance if confidence < 10%
4. When user asks about "work products for X", use structural intent with hierarchy query

INTENT TYPES:
- structural: Relationship/hierarchy queries ("What SOPs implement X?", "What work products for X?", "Show hierarchy")
- domain_explanation: Domain overview queries ("What is Risk Management?", "Explain X domain")
- regulatory_crosswalk: Compliance mapping queries ("How to comply with NIST?", "Map to ISO")
- comparative: Comparison queries ("Compare X with Y", "How differs from")
- explanatory: Why/purpose queries ("Why does X?", "What is the purpose of")
- topical: Best practices/how-to queries ("Best practices for", "How should we")
- known_item: Specific artifact requests ("Show me SOP-PV-01", "Get artifact X")
- gap_analysis: Coverage/gap queries ("What's missing for compliance?", "Gaps in")
- list_entities: Listing queries ("List all domains", "Show frameworks")

MCP TOOLS (suggest the most appropriate):
- get_artifact: Fetch specific artifact by ID
- semantic_search_framework: Vector similarity search for topical/conceptual queries
- get_policy_domain_hierarchy: Graph traversal for policy/process structure AND work products
- find_control_implementations: Find SOPs implementing a control
- get_regulatory_crosswalk: Regulatory framework mappings
- find_evidence_for_requirement: Evidence for regulatory requirements
- get_ashcai_statistics: Ontology statistics and counts

OUTPUT FORMAT (JSON only, no explanation):
{{"intent": "<type>", "confidence": 0.0-1.0, "mcp_tool": "<tool_name>"}}'''

REFINEMENT_USER_TEMPLATE = '''Classify this query: "{query}"

Context from rule-based analysis:
- Initial intent: {initial_intent}
- Initial confidence: {initial_confidence}
- Extracted entities: {entities}'''


class RefinementOracle:
    """
    LLM-based query refinement for ambiguous classifications (Stage 2).

    Uses DeepSeek-R1 via Azure Foundry for single-shot reasoning.
    NOT an agent - just a smart second opinion when rule-based (Stage 1) fails.

    Features:
    - Single chat completion call (predictable cost)
    - Structured JSON output for deterministic parsing
    - Circuit breaker for graceful degradation
    - Token usage tracking

    Usage:
        oracle = RefinementOracle(config)
        intent, confidence, signals, tokens = oracle.refine(
            query="How should we think about bias?",
            initial_intent=QueryIntent.TOPICAL,
            initial_confidence=0.5,
            entities=extracted_entities,
            signals=["pattern_match: topical"],
        )
    """

    def __init__(self, config: QueryPreprocessorConfig):
        """
        Initialize the Refinement Oracle.

        Args:
            config: Configuration with endpoint, API key, and limits.
        """
        self._config = config
        self._client = None  # Lazy initialization

    def _get_client(self):
        """Lazy-initialize OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "OpenAI SDK required for Refinement Oracle. "
                    "Install with: pip install openai"
                )

            api_key = self._config.get_api_key()
            if not api_key:
                raise ValueError(
                    "No API key found. Set AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY "
                    "environment variable or pass refinement_api_key in config."
                )

            self._client = OpenAI(
                base_url=self._config.get_endpoint(),
                api_key=api_key,
            )
        return self._client

    def refine(
        self,
        query: str,
        initial_intent: QueryIntent,
        initial_confidence: float,
        entities: ExtractedEntities,
        signals: list[str],
    ) -> tuple[QueryIntent, float, list[str], int, str | None]:
        """
        Refine a low-confidence classification using LLM reasoning.

        Args:
            query: Original user query
            initial_intent: Stage 1 classification result
            initial_confidence: Stage 1 confidence score
            entities: Extracted entities from Stage 1
            signals: Classification signals from Stage 1

        Returns:
            Tuple of (intent, confidence, signals, tokens_used, suggested_mcp_tool)
        """
        client = self._get_client()

        # Build the refinement prompt with context from Stage 1
        user_message = REFINEMENT_USER_TEMPLATE.format(
            query=query,
            initial_intent=initial_intent.value,
            initial_confidence=f"{initial_confidence:.2f}",
            entities=self._format_entities(entities),
        )

        try:
            response = client.chat.completions.create(
                model=self._config.refinement_model,
                messages=[
                    {"role": "system", "content": REFINEMENT_SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
                temperature=self._config.refinement_temperature,
                max_tokens=self._config.refinement_max_tokens,
                timeout=self._config.refinement_timeout,
            )

            # Extract response content
            # DeepSeek-R1 puts reasoning in `reasoning_content`, answer in `content`
            message = response.choices[0].message
            content = message.content or ""
            
            # Check for reasoning_content (DeepSeek-R1 specific)
            # DeepSeek-R1 puts its thinking in reasoning_content and final answer in content
            # But sometimes content is empty and the answer is buried in reasoning_content
            reasoning_content = getattr(message, 'reasoning_content', None)
            if reasoning_content:
                logger.debug(f"DeepSeek reasoning ({len(reasoning_content)} chars): {reasoning_content[:200]}...")
            
            # If content is empty/whitespace, try to extract JSON from reasoning_content
            if not content.strip() and reasoning_content:
                logger.debug("Content empty, extracting from reasoning_content")
                content = reasoning_content

            # Debug: log raw content for troubleshooting
            logger.debug(f"Raw Refinement Oracle response ({len(content)} chars): {content[:500]}")

            # Track token usage
            tokens_used = 0
            if response.usage:
                tokens_used = response.usage.total_tokens

            # Parse the JSON response
            return self._parse_response(
                content, initial_intent, initial_confidence, signals, tokens_used
            )

        except Exception as e:
            logger.error(f"Refinement Oracle LLM call failed: {e}")
            # Return with None mcp_tool on error
            raise

    def _format_entities(self, entities: ExtractedEntities) -> str:
        """Format entities for prompt."""
        parts = []
        if entities.artifact_ids:
            parts.append(f"artifacts={entities.artifact_ids}")
        if entities.policy_domains:
            parts.append(f"policy_domains={entities.policy_domains}")
        if entities.process_domains:
            parts.append(f"process_domains={entities.process_domains}")
        if entities.regulatory_frameworks:
            parts.append(f"frameworks={entities.regulatory_frameworks}")
        if entities.control_ids:
            parts.append(f"controls={entities.control_ids}")
        return ", ".join(parts) if parts else "none extracted"

    def _extract_from_reasoning(self, text: str, fallback_intent: str) -> dict:
        """
        Extract intent from DeepSeek-R1 reasoning text when JSON output fails.
        
        DeepSeek-R1 often puts classification decisions in reasoning_content
        without producing structured JSON output.
        """
        
        # Valid intent values
        valid_intents = {
            "structural", "domain_explanation", "regulatory_crosswalk",
            "comparative", "explanatory", "topical", "known_item",
            "gap_analysis", "list_entities", "unknown"
        }
        
        text_lower = text.lower()
        
        # Look for explicit intent mentions
        for intent in valid_intents:
            # Patterns: "intent: topical", "classified as topical", "this is topical"
            patterns = [
                rf'intent["\s:]+{intent}',
                rf'classified as["\s]+{intent}',
                rf'this (?:is|falls under|should be)["\s]+{intent}',
                rf'category["\s:]+{intent}',
                rf'"intent":\s*"{intent}"',
            ]
            for pattern in patterns:
                if re.search(pattern, text_lower):
                    logger.debug(f"Extracted intent '{intent}' from reasoning")
                    return {"intent": intent, "confidence": 0.75}
        
        # Look for confidence patterns
        confidence = 0.6  # Default moderate confidence for reasoning extraction
        conf_match = re.search(r'confidence["\s:]+([0-9.]+)', text_lower)
        if conf_match:
            try:
                confidence = float(conf_match.group(1))
            except ValueError:
                # If the confidence value cannot be parsed, keep the default
                logger.debug(
                    "Failed to parse confidence value from reasoning text; "
                    "using default confidence %.2f", confidence
                )
        
        logger.debug(f"Could not extract intent from reasoning, using fallback")
        return {"intent": fallback_intent, "confidence": confidence}

    def _parse_response(
        self,
        content: str,
        fallback_intent: QueryIntent,
        fallback_confidence: float,
        fallback_signals: list[str],
        tokens_used: int,
    ) -> tuple[QueryIntent, float, list[str], int, str | None]:
        """Parse LLM JSON response into classification result."""
        import json
        import re

        original_content = content  # Keep for debug logging
        suggested_mcp_tool: str | None = None

        try:
            # Handle <think> blocks (DeepSeek-R1 format - shouldn't occur with GPT-4o-mini)
            if "<think>" in content:
                content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL)

            # Handle potential markdown code blocks
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                parts = content.split("```")
                if len(parts) >= 2:
                    content = parts[1]

            # Strip whitespace
            content = content.strip()

            # Try direct parse first
            try:
                data = json.loads(content)
            except json.JSONDecodeError:
                # Try to find JSON object with balanced braces
                start_idx = content.find('{')
                if start_idx != -1:
                    brace_count = 0
                    end_idx = start_idx
                    for i, char in enumerate(content[start_idx:], start_idx):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                end_idx = i + 1
                                break
                    json_str = content[start_idx:end_idx]
                    data = json.loads(json_str)
                else:
                    # Fallback: extract intent from text
                    data = self._extract_from_reasoning(content, fallback_intent.value)

            # Extract and validate intent
            intent_str = data.get("intent", fallback_intent.value)
            try:
                intent = QueryIntent(intent_str)
            except ValueError:
                logger.warning(f"Unknown intent from LLM: {intent_str}")
                intent = fallback_intent

            # Extract confidence
            confidence = float(data.get("confidence", fallback_confidence))
            confidence = max(0.0, min(1.0, confidence))  # Clamp to [0, 1]

            # Extract MCP tool suggestion
            suggested_mcp_tool = data.get("mcp_tool") or data.get("suggested_mcp_tool")

            # Build signals
            signals = fallback_signals.copy()
            reasoning = data.get("reasoning", "")
            if reasoning:
                signals.append(f"refinement_oracle: {reasoning}")

            if suggested_mcp_tool:
                signals.append(f"llm_suggested_tool: {suggested_mcp_tool}")

            logger.debug(
                f"Parsed refinement: intent={intent.value}, "
                f"confidence={confidence}, mcp_tool={suggested_mcp_tool}"
            )

            return intent, confidence, signals, tokens_used, suggested_mcp_tool

        except (json.JSONDecodeError, KeyError, TypeError) as e:
            logger.warning(f"Failed to parse Refinement Oracle response: {e}")
            logger.debug(f"Raw response ({len(original_content)} chars): {original_content[:500]}")
            # Return fallback values
            return fallback_intent, fallback_confidence, fallback_signals, tokens_used, None


# =============================================================================
# QUERY PREPROCESSOR
# =============================================================================


class QueryPreprocessor:
    """
    Main query preprocessing orchestrator with two-stage classification.

    Stage 1: Lightweight Classification (fast, rule-based)
    Stage 2: Refinement Oracle (LLM-based, for ambiguous queries)

    The Refinement Oracle is only invoked when Stage 1 confidence is below
    the configured threshold, keeping costs low for common queries.

    Usage:
        # Default config (LLM enabled, threshold=0.7)
        preprocessor = QueryPreprocessor()
        plan = preprocessor.process("What is the Risk Management domain?")

        # Custom config
        config = QueryPreprocessorConfig(refinement_threshold=0.6)
        preprocessor = QueryPreprocessor(config=config)
        plan = preprocessor.process("How should we think about bias?")

        # Cost-zero mode (no LLM)
        config = QueryPreprocessorConfig(enable_refinement_oracle=False)
        preprocessor = QueryPreprocessor(config=config)
    """

    def __init__(
        self,
        config: QueryPreprocessorConfig | None = None,
        llm_classifier: Callable[[str, ExtractedEntities], tuple[QueryIntent, float]] | None = None,
    ):
        """
        Initialize the preprocessor.

        Args:
            config: Configuration for preprocessing behavior. If None, uses defaults.
            llm_classifier: Optional custom LLM classifier callback (for testing/injection).
                          If provided, overrides the built-in Refinement Oracle.
        """
        self._config = config or QueryPreprocessorConfig()
        self._entity_extractor = EntityExtractor()
        self._intent_classifier = IntentClassifier(llm_classifier)
        
        # Refinement Oracle state
        self._refinement_oracle: RefinementOracle | None = None
        self._consecutive_failures = 0
        
        # Stats tracking
        self._total_queries = 0
        self._refinement_invocations = 0
        self._total_tokens_used = 0

    @property
    def config(self) -> QueryPreprocessorConfig:
        """Get current configuration."""
        return self._config

    @property
    def stats(self) -> dict[str, Any]:
        """Get processing statistics."""
        return {
            "total_queries": self._total_queries,
            "refinement_invocations": self._refinement_invocations,
            "refinement_rate": (
                self._refinement_invocations / self._total_queries
                if self._total_queries > 0 else 0.0
            ),
            "total_tokens_used": self._total_tokens_used,
            "avg_tokens_per_refinement": (
                self._total_tokens_used / self._refinement_invocations
                if self._refinement_invocations > 0 else 0
            ),
        }

    def process(
        self,
        query: str,
        use_llm_fallback: bool | None = None,
    ) -> QueryPlan:
        """
        Process a query and generate an execution plan.

        Two-stage classification:
        1. Fast rule-based classification (always runs)
        2. Refinement Oracle (only if confidence < threshold)

        Args:
            query: User's natural language query
            use_llm_fallback: Override config.enable_refinement_oracle for this call.
                            If None, uses config setting.

        Returns:
            QueryPlan with routing decisions
        """
        self._total_queries += 1
        
        # Determine if LLM is enabled for this call
        llm_enabled = (
            use_llm_fallback if use_llm_fallback is not None 
            else self._config.enable_refinement_oracle
        )

        # ─────────────────────────────────────────────────────────────────────
        # Stage 1: Lightweight Classification
        # ─────────────────────────────────────────────────────────────────────
        entities = self._entity_extractor.extract(query)
        logger.debug(f"[Stage 1] Extracted entities: {entities}")

        intent, confidence, signals = self._intent_classifier.classify(
            query, entities, use_llm_fallback=False  # Stage 1 never uses LLM
        )
        logger.debug(f"[Stage 1] Classified: {intent.value} (confidence={confidence:.2f})")

        # ─────────────────────────────────────────────────────────────────────
        # Decision Gate: Is Stage 2 needed?
        # ─────────────────────────────────────────────────────────────────────
        needs_refinement = (
            llm_enabled
            and confidence < self._config.refinement_threshold
            and self._consecutive_failures < self._config.max_consecutive_failures
        )

        # Track LLM-suggested MCP tool (may be set by Stage 2)
        llm_suggested_mcp_tool: str | None = None

        if needs_refinement:
            # ─────────────────────────────────────────────────────────────────
            # Stage 2: Refinement Oracle
            # ─────────────────────────────────────────────────────────────────
            logger.info(
                f"[Stage 2] Invoking Refinement Oracle "
                f"(confidence {confidence:.2f} < threshold {self._config.refinement_threshold})"
            )
            self._refinement_invocations += 1

            (
                refined_intent,
                refined_confidence,
                refined_signals,
                tokens_used,
                llm_suggested_mcp_tool,
            ) = self._invoke_refinement_oracle(query, intent, confidence, entities, signals)

            # Track token usage
            if tokens_used > 0:
                self._total_tokens_used += tokens_used

            # Use refined results if more confident
            if refined_confidence > confidence:
                intent = refined_intent
                confidence = refined_confidence
                signals = refined_signals
                logger.info(
                    f"[Stage 2] Refined to: {intent.value} "
                    f"(confidence={confidence:.2f}, mcp_tool={llm_suggested_mcp_tool})"
                )
            else:
                logger.info(f"[Stage 2] Kept original: {intent.value}")

        # ─────────────────────────────────────────────────────────────────────
        # Generate final plan
        # ─────────────────────────────────────────────────────────────────────
        plan = self._generate_plan(query, intent, entities, confidence, signals)

        # Override MCP tool if LLM suggested one (Stage 2 has context we may not)
        if llm_suggested_mcp_tool and llm_suggested_mcp_tool != plan.suggested_mcp_tool:
            logger.debug(
                f"Overriding MCP tool: {plan.suggested_mcp_tool} -> {llm_suggested_mcp_tool} (LLM suggestion)"
            )
            plan.suggested_mcp_tool = llm_suggested_mcp_tool
            plan.classification_signals.append(f"mcp_tool_override: {llm_suggested_mcp_tool}")

        if self._config.log_classifications:
            logger.info(
                f"Query plan: intent={plan.intent.value}, "
                f"strategy={plan.strategy.value}, "
                f"mcp_tool={plan.suggested_mcp_tool}, "
                f"confidence={plan.confidence:.2f}, "
                f"stage={'1+2' if needs_refinement else '1'}"
            )

        return plan

    def _invoke_refinement_oracle(
        self,
        query: str,
        initial_intent: QueryIntent,
        initial_confidence: float,
        entities: ExtractedEntities,
        signals: list[str],
    ) -> tuple[QueryIntent, float, list[str], int, str | None]:
        """
        Invoke the Refinement Oracle (Stage 2) for low-confidence queries.

        Args:
            query: Original user query
            initial_intent: Stage 1 classification result
            initial_confidence: Stage 1 confidence score
            entities: Extracted entities from Stage 1
            signals: Classification signals from Stage 1

        Returns:
            Tuple of (intent, confidence, signals, tokens_used, suggested_mcp_tool)
            Falls back to initial values on error.
        """
        # Lazy initialization of Refinement Oracle
        if self._refinement_oracle is None:
            self._refinement_oracle = RefinementOracle(self._config)

        try:
            result = self._refinement_oracle.refine(
                query=query,
                initial_intent=initial_intent,
                initial_confidence=initial_confidence,
                entities=entities,
                signals=signals,
            )
            self._consecutive_failures = 0  # Reset on success
            return result
        except Exception as e:
            self._consecutive_failures += 1
            logger.error(f"Refinement Oracle failed: {e}")
            # Graceful degradation: return Stage 1 results
            return initial_intent, initial_confidence, signals, 0, None

    def _generate_plan(
        self,
        query: str,
        intent: QueryIntent,
        entities: ExtractedEntities,
        confidence: float,
        signals: list[str],
    ) -> QueryPlan:
        """Generate execution plan based on classified intent."""

        plan = QueryPlan(
            intent=intent,
            strategy=RetrievalStrategy.SEMANTIC_SEARCH,  # Default
            entities=entities,
            confidence=confidence,
            classification_signals=signals,
            search_query=query,
        )

        # Route based on intent
        if intent == QueryIntent.KNOWN_ITEM:
            plan = self._plan_known_item(plan, query, entities)

        elif intent == QueryIntent.DOMAIN_EXPLANATION:
            plan = self._plan_domain_explanation(plan, query, entities)

        elif intent == QueryIntent.STRUCTURAL:
            plan = self._plan_structural(plan, query, entities)

        elif intent == QueryIntent.REGULATORY_CROSSWALK:
            plan = self._plan_regulatory_crosswalk(plan, query, entities)

        elif intent == QueryIntent.COMPARATIVE:
            plan = self._plan_comparative(plan, query, entities)

        elif intent == QueryIntent.EXPLANATORY:
            plan = self._plan_explanatory(plan, query, entities)

        elif intent == QueryIntent.GAP_ANALYSIS:
            plan = self._plan_gap_analysis(plan, query, entities)

        elif intent == QueryIntent.LIST_ENTITIES:
            plan = self._plan_list_entities(plan, query, entities)

        elif intent == QueryIntent.TOPICAL:
            plan = self._plan_topical(plan, query, entities)

        else:  # UNKNOWN
            plan = self._plan_fallback(plan, query, entities)

        return plan

    def _plan_known_item(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for known item retrieval."""
        plan.strategy = RetrievalStrategy.KEYWORD_LOOKUP
        plan.target_artifacts = entities.artifact_ids

        # MCP tool selection
        if entities.artifact_ids:
            plan.suggested_mcp_tool = "get_artifact"
            plan.mcp_tool_params = {"artifact_id": entities.artifact_ids[0]}

            # If multiple artifacts, add them as additional tools
            for artifact_id in entities.artifact_ids[1:]:
                plan.additional_mcp_tools.append({
                    "tool": "get_artifact",
                    "params": {"artifact_id": artifact_id},
                })

        return plan

    def _plan_domain_explanation(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """
        Plan for domain explanation queries.

        Key insight: When a user asks "What is Risk Management?", they likely
        want to understand BOTH the policy (what we require) and the process
        (how we do it). So we return both POL-RMP-Overview AND PROC-RM-Overview.
        """
        plan.strategy = RetrievalStrategy.ARTIFACT_FETCH

        # Build target artifacts from domains, including related policy/process
        targets: list[str] = []
        seen_codes: set[str] = set()

        # Handle explicit policy domains - add corresponding process too
        for code in entities.policy_domains:
            if code not in seen_codes:
                targets.append(f"POL-{code}-Overview")
                seen_codes.add(f"POL-{code}")

                # Also add corresponding process domain if available
                if code in POLICY_TO_PROCESS_MAPPING:
                    proc_code = POLICY_TO_PROCESS_MAPPING[code]
                    if f"PROC-{proc_code}" not in seen_codes:
                        targets.append(f"PROC-{proc_code}-Overview")
                        seen_codes.add(f"PROC-{proc_code}")

        # Handle explicit process domains - add corresponding policy too
        for code in entities.process_domains:
            if f"PROC-{code}" not in seen_codes:
                targets.append(f"PROC-{code}-Overview")
                seen_codes.add(f"PROC-{code}")

                # Also add corresponding policy domain if available
                if code in PROCESS_TO_POLICY_MAPPING:
                    pol_code = PROCESS_TO_POLICY_MAPPING[code]
                    if f"POL-{pol_code}" not in seen_codes:
                        targets.append(f"POL-{pol_code}-Overview")
                        seen_codes.add(f"POL-{pol_code}")

        # If no specific domain but asking about a concept, try to infer
        if not targets:
            query_lower = query.lower()
            for alias, (code, domain_type) in DOMAIN_ALIASES.items():
                if alias in query_lower:
                    if domain_type == "policy":
                        targets.append(f"POL-{code}-Overview")
                        # Add corresponding process
                        if code in POLICY_TO_PROCESS_MAPPING:
                            proc_code = POLICY_TO_PROCESS_MAPPING[code]
                            targets.append(f"PROC-{proc_code}-Overview")
                    else:
                        targets.append(f"PROC-{code}-Overview")
                        # Add corresponding policy
                        if code in PROCESS_TO_POLICY_MAPPING:
                            pol_code = PROCESS_TO_POLICY_MAPPING[code]
                            targets.append(f"POL-{pol_code}-Overview")
                    break

        plan.target_artifacts = targets

        # MCP tool selection
        if targets:
            plan.suggested_mcp_tool = "get_artifact"
            plan.mcp_tool_params = {"artifact_id": targets[0]}

            # Additional artifacts to fetch in parallel
            for artifact_id in targets[1:]:
                plan.additional_mcp_tools.append({
                    "tool": "get_artifact",
                    "params": {"artifact_id": artifact_id},
                })
        else:
            # Fallback to semantic if no specific domain identified
            plan.strategy = RetrievalStrategy.SEMANTIC_SEARCH
            plan.search_query = query
            plan.suggested_mcp_tool = "semantic_search_framework"
            plan.mcp_tool_params = {"query": query, "top_k": plan.top_k}

        return plan

    def _plan_structural(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for structural/relationship queries."""
        plan.strategy = RetrievalStrategy.GRAPH_TRAVERSAL

        # Determine which traversal and MCP tool to use
        if entities.control_ids:
            plan.graph_traversal = "find_control_implementations"
            plan.suggested_mcp_tool = "find_control_implementations"
            plan.mcp_tool_params = {"control_id": entities.control_ids[0]}

            # Additional controls
            for control_id in entities.control_ids[1:]:
                plan.additional_mcp_tools.append({
                    "tool": "find_control_implementations",
                    "params": {"control_id": control_id},
                })

        elif entities.policy_domains:
            plan.graph_traversal = "get_policy_hierarchy"
            policy_id = f"{entities.policy_domains[0]}-001"
            plan.suggested_mcp_tool = "get_policy_domain_hierarchy"
            plan.mcp_tool_params = {"policy_id": policy_id}

        elif entities.process_domains:
            # ASHKBAPP-185: Enhanced process domain structural queries
            # Map process domain to policy for hierarchy lookup
            proc_code = entities.process_domains[0]
            if proc_code in PROCESS_TO_POLICY_MAPPING:
                policy_code = PROCESS_TO_POLICY_MAPPING[proc_code]
                policy_id = f"{policy_code}-001"
            else:
                policy_id = "AGP-001"  # Default to AI Governance

            plan.graph_traversal = "get_policy_hierarchy"
            plan.suggested_mcp_tool = "get_policy_domain_hierarchy"
            plan.mcp_tool_params = {"policy_id": policy_id}

            # Also fetch the process domain overview for context
            plan.additional_mcp_tools.append({
                "tool": "get_artifact",
                "params": {"artifact_id": f"PROC-{proc_code}-Overview"},
            })

            # Add semantic search for work products in this domain as fallback
            plan.additional_mcp_tools.append({
                "tool": "semantic_search_framework",
                "params": {
                    "query": f"work products {proc_code} domain",
                    "domain": proc_code,
                    "top_k": 10,
                },
            })

        else:
            # Default to AI Governance hierarchy
            plan.graph_traversal = "get_policy_hierarchy"
            plan.suggested_mcp_tool = "get_policy_domain_hierarchy"
            plan.mcp_tool_params = {"policy_id": "AGP-001"}

            # Add semantic search as fallback
            plan.additional_mcp_tools.append({
                "tool": "semantic_search_framework",
                "params": {"query": query, "top_k": 10},
            })

        return plan

    def _plan_regulatory_crosswalk(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for regulatory crosswalk queries."""
        plan.strategy = RetrievalStrategy.GRAPH_TRAVERSAL

        # If specific requirement ID, use evidence lookup
        if entities.requirement_ids:
            plan.graph_traversal = "find_evidence_for_requirement"
            plan.suggested_mcp_tool = "find_evidence_for_requirement"
            plan.mcp_tool_params = {"requirement_id": entities.requirement_ids[0]}

            # Additional requirements
            for req_id in entities.requirement_ids[1:]:
                plan.additional_mcp_tools.append({
                    "tool": "find_evidence_for_requirement",
                    "params": {"requirement_id": req_id},
                })

        elif entities.regulatory_frameworks:
            plan.graph_traversal = "get_regulatory_crosswalk"
            plan.suggested_mcp_tool = "get_regulatory_crosswalk"
            plan.mcp_tool_params = {"framework_id": entities.regulatory_frameworks[0]}

            # Additional frameworks
            for fw_id in entities.regulatory_frameworks[1:]:
                plan.additional_mcp_tools.append({
                    "tool": "get_regulatory_crosswalk",
                    "params": {"framework_id": fw_id},
                })

        else:
            # Default to NIST if no specific framework mentioned
            plan.graph_traversal = "get_regulatory_crosswalk"
            plan.suggested_mcp_tool = "get_regulatory_crosswalk"
            plan.mcp_tool_params = {"framework_id": "NIST-AI-RMF"}

        return plan

    def _plan_comparative(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for comparative queries (multi-source fusion)."""
        plan.strategy = RetrievalStrategy.MULTI_SOURCE
        plan.synthesis_required = True

        # Primary tool: semantic search for conceptual comparison
        plan.suggested_mcp_tool = "semantic_search_framework"
        plan.mcp_tool_params = {"query": query, "top_k": 10}

        # Additional tools based on entities
        if entities.regulatory_frameworks:
            for fw_id in entities.regulatory_frameworks:
                plan.additional_mcp_tools.append({
                    "tool": "get_regulatory_crosswalk",
                    "params": {"framework_id": fw_id},
                })
        elif entities.policy_domains:
            for code in entities.policy_domains:
                plan.additional_mcp_tools.append({
                    "tool": "get_policy_domain_hierarchy",
                    "params": {"policy_id": f"{code}-001"},
                })

        # Create sub-plans for legacy compatibility
        graph_plan = QueryPlan(
            intent=QueryIntent.STRUCTURAL,
            strategy=RetrievalStrategy.GRAPH_TRAVERSAL,
            entities=entities,
            graph_traversal="get_regulatory_crosswalk" if entities.regulatory_frameworks else "get_policy_hierarchy",
        )

        semantic_plan = QueryPlan(
            intent=QueryIntent.TOPICAL,
            strategy=RetrievalStrategy.SEMANTIC_SEARCH,
            entities=entities,
            search_query=query,
        )

        plan.sub_plans = [graph_plan, semantic_plan]
        return plan

    def _plan_explanatory(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for explanatory (why) queries."""
        # Similar to comparative but weighted toward semantic
        plan.strategy = RetrievalStrategy.SEMANTIC_SEARCH
        plan.search_query = query
        plan.top_k = 8  # More context for explanatory

        # MCP tool selection
        plan.suggested_mcp_tool = "semantic_search_framework"
        plan.mcp_tool_params = {
            "query": query,
            "top_k": plan.top_k,
        }

        # Add domain filter if available
        domain = entities.get_primary_domain()
        if domain:
            plan.mcp_tool_params["domain"] = domain

        return plan

    def _plan_gap_analysis(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for gap analysis queries."""
        plan.strategy = RetrievalStrategy.GRAPH_TRAVERSAL
        plan.graph_traversal = "gap_analysis_by_framework"

        # Gap analysis requires regulatory crosswalk as foundation
        if entities.regulatory_frameworks:
            plan.suggested_mcp_tool = "get_regulatory_crosswalk"
            plan.mcp_tool_params = {"framework_id": entities.regulatory_frameworks[0]}
        else:
            # Default to NIST for gap analysis
            plan.suggested_mcp_tool = "get_regulatory_crosswalk"
            plan.mcp_tool_params = {"framework_id": "NIST-AI-RMF"}

        # Note: True gap analysis would need additional processing
        # to compare crosswalk coverage vs. actual implementation
        plan.synthesis_required = True

        return plan

    def _plan_list_entities(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for listing ontology entities (NOT documents)."""
        plan.strategy = RetrievalStrategy.ONTOLOGY_LISTING

        # Determine what to list and which MCP tool to use
        query_lower = query.lower()
        if "policy" in query_lower and "domain" in query_lower:
            plan.graph_traversal = "list_policy_domains"
            plan.suggested_mcp_tool = "get_ashcai_statistics"
            plan.mcp_tool_params = {}
        elif "process" in query_lower and "domain" in query_lower:
            plan.graph_traversal = "list_process_domains"
            plan.suggested_mcp_tool = "get_ashcai_statistics"
            plan.mcp_tool_params = {}
        elif "framework" in query_lower or "regulatory" in query_lower:
            plan.graph_traversal = "list_regulatory_frameworks"
            plan.suggested_mcp_tool = "get_ashcai_statistics"
            plan.mcp_tool_params = {}
        elif "sop" in query_lower:
            plan.graph_traversal = "list_sops"
            plan.suggested_mcp_tool = "get_category_content"
            plan.mcp_tool_params = {"category": "processes", "limit": 50}
        elif "work product" in query_lower or "template" in query_lower:
            plan.graph_traversal = "list_work_products"
            plan.suggested_mcp_tool = "get_category_content"
            plan.mcp_tool_params = {"category": "templates", "limit": 50}
        else:
            plan.graph_traversal = "get_statistics"
            plan.suggested_mcp_tool = "get_ashcai_statistics"
            plan.mcp_tool_params = {}

        return plan

    def _plan_topical(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Plan for topical/conceptual queries."""
        plan.strategy = RetrievalStrategy.SEMANTIC_SEARCH
        plan.search_query = query

        # MCP tool selection
        plan.suggested_mcp_tool = "semantic_search_framework"
        plan.mcp_tool_params = {
            "query": query,
            "top_k": plan.top_k,
            "min_score": 0.7,
        }

        # Add domain filter if available
        domain = entities.get_primary_domain()
        if domain:
            plan.search_filters["domain"] = domain
            plan.mcp_tool_params["domain"] = domain

        return plan

    def _plan_fallback(
        self, plan: QueryPlan, query: str, entities: ExtractedEntities
    ) -> QueryPlan:
        """Fallback plan for unclassified queries."""
        plan.strategy = RetrievalStrategy.SEMANTIC_SEARCH
        plan.search_query = query
        plan.top_k = 10  # Broader search for unclear intent

        # MCP tool: broad semantic search
        plan.suggested_mcp_tool = "semantic_search_framework"
        plan.mcp_tool_params = {
            "query": query,
            "top_k": plan.top_k,
            "min_score": 0.5,  # Lower threshold for fallback
        }

        return plan


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================


def preprocess_query(
    query: str,
    config: QueryPreprocessorConfig | None = None,
) -> QueryPlan:
    """
    Convenience function for one-shot query preprocessing.

    Uses two-stage classification:
    1. Fast rule-based classification (always runs)
    2. Refinement Oracle (only if confidence < threshold and enabled)

    Args:
        query: User's natural language query
        config: Optional configuration. If None, uses defaults with LLM enabled.

    Returns:
        QueryPlan with routing decisions

    Example:
        # Default: LLM enabled
        plan = preprocess_query("What is Risk Management?")

        # Cost-zero mode
        config = QueryPreprocessorConfig(enable_refinement_oracle=False)
        plan = preprocess_query("What is Risk Management?", config=config)
    """
    preprocessor = QueryPreprocessor(config=config)
    return preprocessor.process(query)


def create_preprocessor(
    enable_llm: bool = True,
    threshold: float = 0.7,
) -> QueryPreprocessor:
    """
    Factory function to create a configured QueryPreprocessor.

    Args:
        enable_llm: Whether to enable the Refinement Oracle (Stage 2)
        threshold: Confidence threshold below which to invoke LLM

    Returns:
        Configured QueryPreprocessor instance

    Example:
        # For customer portal (cost-conscious)
        preprocessor = create_preprocessor(enable_llm=True, threshold=0.7)

        # For internal tools (accuracy-focused)
        preprocessor = create_preprocessor(enable_llm=True, threshold=0.5)

        # For testing (no LLM calls)
        preprocessor = create_preprocessor(enable_llm=False)
    """
    config = QueryPreprocessorConfig(
        enable_refinement_oracle=enable_llm,
        refinement_threshold=threshold,
    )
    return QueryPreprocessor(config=config)


__all__ = [
    # Configuration
    "QueryPreprocessorConfig",
    # Enums
    "QueryIntent",
    "RetrievalStrategy",
    # Data classes
    "ExtractedEntities",
    "QueryPlan",
    # Classes
    "EntityExtractor",
    "IntentClassifier",
    "RefinementOracle",
    "QueryPreprocessor",
    # Factory/Convenience Functions
    "preprocess_query",
    "create_preprocessor",
]
