"""
AI Governance Query Service

Framework-agnostic service for querying the AI Governance Framework.
This is the primary SDK entry point for applications consuming the framework.

Created: 2026-01-25
Updated: 2026-01-26 - Added intelligent query preprocessing (ASHKBAPP-68)
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.

Usage:
    from ashmatics_aigov_tools.services import AIGovQueryService, AIGovQueryConfig

    # MCP mode (recommended for production)
    config = AIGovQueryConfig(use_mcp=True, mcp_url="https://kb.ashmatics.com")
    service = AIGovQueryService(config)

    async with service:
        # Smart query with intent classification
        result = await service.smart_query("What is the Risk Management domain?")
        # -> Routes to POL-RMP-Overview, not a list of all RM documents

        # Legacy query (semantic search + LLM synthesis)
        result = await service.query("What SOPs for model monitoring?")
        print(result.answer)

    # Direct mode (for development)
    config = AIGovQueryConfig(use_mcp=False)
    service = AIGovQueryService(config)
    result = await service.query("What is performance validation?")
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from dotenv import load_dotenv

from ashmatics_aigov_tools.services.backends import (
    DirectBackend,
    MCPBackend,
    RetrievalResult,
    SearchBackend,
    SearchResult,
)
from ashmatics_aigov_tools.services.mcp_client import KBMCPClient, MCPClientConfig

if TYPE_CHECKING:
    pass


@dataclass
class AIGovQueryConfig:
    """
    Configuration for AIGovQueryService.

    Supports both MCP mode (recommended) and direct database mode.
    """

    # Backend mode
    use_mcp: bool = True  # True = MCP server, False = direct CosmosDB

    # MCP settings (when use_mcp=True)
    mcp_url: str = "http://localhost:8088"
    mcp_api_key: str | None = None
    mcp_timeout: float = 30.0

    # Direct DB settings (when use_mcp=False)
    mongo_connection_string: str | None = None
    mongo_database: str = "ai_strategy"
    vector_collection: str = "aigov_framework_vectors"

    # LLM settings (for RAG synthesis)
    llm_provider: str = "azure_openai"  # "azure_openai" or "ollama"
    llm_model: str | None = None  # None = use env default
    ollama_endpoint: str = "http://localhost:11434"

    # RAG settings
    top_k: int = 5
    min_score: float = 0.0
    temperature: float = 0.7
    max_tokens: int = 1024
    use_multi_query: bool = False
    num_query_variants: int = 4

    # Optional: custom system prompt for RAG
    system_prompt: str | None = None

    # Query preprocessing settings (ASHKBAPP-68)
    use_smart_routing: bool = True  # Enable intelligent query routing
    use_llm_classification: bool = False  # Phase 2: LLM-assisted classification
    log_query_plans: bool = True  # Log routing decisions for debugging

    @classmethod
    def from_env(cls, use_mcp: bool = True) -> AIGovQueryConfig:
        """
        Create config from environment variables.

        Args:
            use_mcp: Whether to use MCP mode (default True)

        Environment variables:
            MCP_URL: MCP server URL
            MCP_API_KEY: MCP API key
            MONGO_URL: MongoDB connection string (for direct mode)
            AZURE_OPENAI_CHAT_DEPLOYMENT_NAME: Azure OpenAI model
            OLLAMA_MODEL: Ollama model name
        """
        # Load environment files
        _load_env_files()

        return cls(
            use_mcp=use_mcp,
            mcp_url=os.getenv("MCP_URL", "http://localhost:8088"),
            mcp_api_key=os.getenv("MCP_API_KEY"),
            mongo_connection_string=os.getenv("MONGO_URL") or os.getenv("AZ_MONGO_CONNECTION_STRING"),
            llm_model=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
            or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT"),
        )


@dataclass
class QueryResult:
    """Result from a RAG query."""

    question: str
    answer: str
    sources: list[SearchResult]
    intent_category: str | None = None
    complexity: str | None = None
    workflow: list[str] | None = None
    metrics: QueryMetrics | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class QueryMetrics:
    """Metrics from a query execution."""

    num_sources: int = 0
    latency_ms: float = 0.0
    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    estimated_cost: float = 0.0


@dataclass
class StreamChunk:
    """A chunk from a streaming query response."""

    text: str
    is_final: bool = False
    sources: list[SearchResult] | None = None
    metrics: QueryMetrics | None = None


def _load_env_files() -> None:
    """Load environment variables from standard locations."""
    # Try to find project root
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # services -> ashmatics_aigov_tools -> src -> project_root
    project_root = os.path.abspath(os.path.join(current_dir, "../../../.."))

    # Try common env file names
    for env_name in ["ashmatics-tools.env", "ai-strat-src.env", ".env"]:
        env_path = os.path.join(project_root, env_name)
        if os.path.exists(env_path):
            load_dotenv(env_path)
            break


class AIGovQueryService:
    """
    AI Governance Framework Query Service.

    Provides RAG-powered question answering over the Clinical AI
    Governance Framework. Supports both MCP-based retrieval (recommended)
    and direct database access.

    This class is the primary SDK entry point. It's framework-agnostic
    and can be consumed by FastAPI, Flask, Streamlit, or any Python app.

    Usage:
        config = AIGovQueryConfig(use_mcp=True)
        service = AIGovQueryService(config)

        async with service:
            # Smart query with intelligent routing (recommended)
            result = await service.smart_query("What is the Risk Management domain?")
            # -> Fetches POL-RMP-Overview instead of searching all RM docs

            # Full RAG query (legacy)
            result = await service.query("What SOPs for monitoring?")
            print(result.answer)
            for source in result.sources:
                print(f"  - {source.document_id}: {source.score:.3f}")

            # Search only (no LLM)
            results = await service.search("performance validation")

            # Streaming response
            async for chunk in service.stream_query("Explain risk management"):
                print(chunk.text, end="", flush=True)
    """

    def __init__(self, config: AIGovQueryConfig | None = None):
        """
        Initialize the query service.

        Args:
            config: Service configuration. If None, loads from environment.
        """
        _load_env_files()
        self.config = config or AIGovQueryConfig.from_env()

        # Components (lazy initialized)
        self._backend: SearchBackend | None = None
        self._llm = None
        self._embedder = None
        self._rag_strategy = None

        # Query preprocessing (ASHKBAPP-68)
        self._preprocessor = None
        self._orchestrator = None

    async def __aenter__(self) -> AIGovQueryService:
        """Async context manager entry."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()

    async def initialize(self) -> None:
        """
        Initialize service components.

        Called automatically when using 'async with' context manager.
        Can also be called manually for explicit lifecycle control.
        """
        if self._backend is not None:
            return  # Already initialized

        # Create backend based on config
        if self.config.use_mcp:
            mcp_config = MCPClientConfig(
                base_url=self.config.mcp_url,
                api_key=self.config.mcp_api_key,
                timeout=self.config.mcp_timeout,
            )
            mcp_client = KBMCPClient(mcp_config)
            self._backend = MCPBackend(mcp_client)

            # Initialize query preprocessing (ASHKBAPP-68)
            if self.config.use_smart_routing:
                from ashmatics_aigov_tools.services.query_preprocessor import QueryPreprocessor
                from ashmatics_aigov_tools.services.query_orchestrator import QueryOrchestrator

                self._preprocessor = QueryPreprocessor()
                self._orchestrator = QueryOrchestrator(mcp_client)
        else:
            self._backend = DirectBackend(
                connection_string=self.config.mongo_connection_string,
                database_name=self.config.mongo_database,
                collection_name=self.config.vector_collection,
            )

    async def close(self) -> None:
        """
        Clean up service resources.

        Called automatically when exiting 'async with' context manager.
        """
        if self._backend:
            await self._backend.close()
            self._backend = None

        if self._llm:
            # LLM clients may have their own cleanup
            if hasattr(self._llm, "close"):
                await self._llm.close()
            self._llm = None

    @property
    def backend(self) -> SearchBackend:
        """Get the search backend, initializing if needed."""
        if self._backend is None:
            raise RuntimeError(
                "Service not initialized. Use 'async with' or call initialize()."
            )
        return self._backend

    async def health_check(self) -> dict[str, Any]:
        """
        Check service health.

        Returns dict with:
            - backend_healthy: bool
            - backend_type: "mcp" or "direct"
            - llm_available: bool
            - details: backend-specific info
        """
        await self.initialize()

        backend_health = await self.backend.health_check()

        # Check LLM availability
        llm_available = False
        llm_details = {}
        try:
            if self.config.llm_provider == "ollama":
                llm_available = bool(os.getenv("OLLAMA_ENDPOINT") or True)  # Assume local
                llm_details = {"provider": "ollama", "model": self.config.llm_model or "default"}
            else:
                api_key = os.getenv("AZURE_OPENAI_API_KEY")
                endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
                llm_available = bool(api_key and endpoint)
                llm_details = {"provider": "azure_openai", "model": self.config.llm_model}
        except Exception as e:
            llm_details = {"error": str(e)}

        return {
            "healthy": backend_health.get("healthy", False) and llm_available,
            "backend_healthy": backend_health.get("healthy", False),
            "backend_type": "mcp" if self.config.use_mcp else "direct",
            "backend_details": backend_health,
            "llm_available": llm_available,
            "llm_details": llm_details,
        }

    async def search(
        self,
        query: str,
        top_k: int | None = None,
        min_score: float | None = None,
        domain: str | None = None,
        artifact_type: str | None = None,
    ) -> RetrievalResult:
        """
        Search the framework without LLM synthesis.

        Use this for retrieval-only operations where you want
        raw search results without generating an answer.

        Args:
            query: Natural language search query
            top_k: Number of results (default: config.top_k)
            min_score: Minimum similarity score (default: config.min_score)
            domain: Optional domain filter (e.g., "PV", "MMP")
            artifact_type: Optional type filter (e.g., "SOP", "WP")

        Returns:
            RetrievalResult with matched documents and metadata
        """
        await self.initialize()

        return await self.backend.search(
            query=query,
            top_k=top_k or self.config.top_k,
            min_score=min_score if min_score is not None else self.config.min_score,
            domain=domain,
            artifact_type=artifact_type,
        )

    # -------------------------------------------------------------------------
    # Smart Query (ASHKBAPP-68)
    # -------------------------------------------------------------------------

    async def smart_query(
        self,
        question: str,
        include_sources: bool = True,
        synthesize_answer: bool = True,
    ) -> QueryResult:
        """
        Execute an intelligent query with automatic intent classification and routing.

        This is the recommended query method. It:
        1. Classifies query intent (structural, domain_explanation, topical, etc.)
        2. Extracts entities (artifact IDs, domains, frameworks)
        3. Routes to the optimal retrieval strategy
        4. Optionally synthesizes an answer using LLM

        Key difference from query(): This method understands the difference between
        asking "What is Risk Management?" (fetch POL-RMP-Overview) vs
        "List all risk management documents" (list from ontology).

        Args:
            question: Natural language question
            include_sources: Whether to include source documents in result
            synthesize_answer: Whether to generate LLM answer (False = retrieval only)

        Returns:
            QueryResult with answer, sources, and routing metadata

        Examples:
            # Domain explanation -> fetches OverviewSummary
            result = await service.smart_query("What is the Risk Management domain?")
            # -> Fetches POL-RMP-Overview content

            # Structural query -> graph traversal
            result = await service.smart_query("What SOPs implement EXC-A4-01?")
            # -> Uses find_control_implementations

            # Regulatory crosswalk
            result = await service.smart_query("How do we comply with NIST MAP 4.2?")
            # -> Uses get_regulatory_crosswalk

            # Topical -> semantic search
            result = await service.smart_query("Best practices for bias testing")
            # -> Semantic search in EF domain
        """
        import time
        import logging

        logger = logging.getLogger(__name__)

        await self.initialize()
        start_time = time.time()

        # Check if smart routing is available
        if not self._preprocessor or not self._orchestrator:
            logger.warning("Smart routing not available, falling back to standard query")
            return await self.query(question, include_sources=include_sources)

        # Ensure MCP client is connected
        if isinstance(self._backend, MCPBackend):
            await self._backend.connect()

        # Step 1: Preprocess query
        plan = self._preprocessor.process(
            question,
            use_llm_fallback=self.config.use_llm_classification,
        )

        if self.config.log_query_plans:
            logger.info(f"Query plan: {plan.to_dict()}")

        # Step 2: Execute plan via orchestrator
        orchestration_result = await self._orchestrator.execute(plan, question)

        # Step 3: Convert to RetrievalResult
        retrieval = orchestration_result.to_retrieval_result()

        # Step 4: Optionally synthesize answer
        answer = ""
        llm_metrics: dict = {}

        if synthesize_answer and retrieval.results:
            answer, llm_metrics = await self._generate_answer(question, retrieval.results)
        elif retrieval.results:
            # No synthesis - just format the top result
            answer = retrieval.results[0].content

        latency_ms = (time.time() - start_time) * 1000

        metrics = QueryMetrics(
            num_sources=len(retrieval.results),
            latency_ms=latency_ms,
            total_tokens=llm_metrics.get("total_tokens", 0),
            prompt_tokens=llm_metrics.get("prompt_tokens", 0),
            completion_tokens=llm_metrics.get("completion_tokens", 0),
            estimated_cost=llm_metrics.get("estimated_cost", 0.0),
        )

        return QueryResult(
            question=question,
            answer=answer,
            sources=retrieval.results if include_sources else [],
            intent_category=plan.intent.value,
            complexity=retrieval.complexity,
            workflow=retrieval.workflow,
            metrics=metrics,
            metadata={
                "plan": plan.to_dict(),
                "orchestration": {
                    "tools_called": orchestration_result.tools_called,
                    "sources_used": orchestration_result.sources_used,
                },
                **retrieval.metadata,
            },
        )

    async def smart_search(
        self,
        query: str,
        top_k: int | None = None,
    ) -> RetrievalResult:
        """
        Smart search without LLM synthesis.

        Uses intelligent routing but returns raw retrieval results.
        Good for UIs that want to display results directly.

        Args:
            query: Natural language query
            top_k: Number of results (default: config.top_k)

        Returns:
            RetrievalResult with matched documents and routing metadata
        """
        result = await self.smart_query(
            question=query,
            include_sources=True,
            synthesize_answer=False,
        )

        return RetrievalResult(
            query=query,
            results=result.sources,
            intent_category=result.intent_category,
            complexity=result.complexity,
            workflow=result.workflow,
            metadata=result.metadata,
        )

    def preprocess_query(self, query: str) -> dict:
        """
        Analyze a query without executing it.

        Useful for debugging or showing users what the system understood.

        Args:
            query: Natural language query

        Returns:
            Dict with intent, entities, and planned strategy
        """
        if not self._preprocessor:
            from ashmatics_aigov_tools.services.query_preprocessor import QueryPreprocessor
            self._preprocessor = QueryPreprocessor()

        plan = self._preprocessor.process(query)
        return plan.to_dict()

    async def query(
        self,
        question: str,
        top_k: int | None = None,
        include_sources: bool = True,
    ) -> QueryResult:
        """
        Execute a RAG query with LLM synthesis.

        Retrieves relevant documents and generates a synthesized
        answer using the configured LLM.

        Args:
            question: Natural language question
            top_k: Number of sources to retrieve (default: config.top_k)
            include_sources: Whether to include source documents in result

        Returns:
            QueryResult with answer, sources, and metrics
        """
        import time

        await self.initialize()
        start_time = time.time()

        # Retrieve context
        retrieval = await self.backend.search(
            query=question,
            top_k=top_k or self.config.top_k,
        )

        # Generate answer using RAG
        answer, llm_metrics = await self._generate_answer(question, retrieval.results)

        latency_ms = (time.time() - start_time) * 1000

        metrics = QueryMetrics(
            num_sources=len(retrieval.results),
            latency_ms=latency_ms,
            total_tokens=llm_metrics.get("total_tokens", 0),
            prompt_tokens=llm_metrics.get("prompt_tokens", 0),
            completion_tokens=llm_metrics.get("completion_tokens", 0),
            estimated_cost=llm_metrics.get("estimated_cost", 0.0),
        )

        return QueryResult(
            question=question,
            answer=answer,
            sources=retrieval.results if include_sources else [],
            intent_category=retrieval.intent_category,
            complexity=retrieval.complexity,
            workflow=retrieval.workflow,
            metrics=metrics,
            metadata=retrieval.metadata,
        )

    async def stream_query(
        self,
        question: str,
        top_k: int | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """
        Stream a RAG query response.

        Retrieves context and streams the LLM response token by token.
        Useful for real-time UIs that want to show progressive output.

        Args:
            question: Natural language question
            top_k: Number of sources to retrieve

        Yields:
            StreamChunk objects with text, and final chunk with sources/metrics
        """
        import time

        await self.initialize()
        start_time = time.time()

        # Retrieve context first
        retrieval = await self.backend.search(
            query=question,
            top_k=top_k or self.config.top_k,
        )

        # Stream LLM response
        full_answer = ""
        llm_metrics = {}

        async for text, is_done, metrics in self._stream_answer(question, retrieval.results):
            full_answer += text
            if metrics:
                llm_metrics = metrics

            if is_done:
                latency_ms = (time.time() - start_time) * 1000
                final_metrics = QueryMetrics(
                    num_sources=len(retrieval.results),
                    latency_ms=latency_ms,
                    total_tokens=llm_metrics.get("total_tokens", 0),
                    prompt_tokens=llm_metrics.get("prompt_tokens", 0),
                    completion_tokens=llm_metrics.get("completion_tokens", 0),
                    estimated_cost=llm_metrics.get("estimated_cost", 0.0),
                )
                yield StreamChunk(
                    text=text,
                    is_final=True,
                    sources=retrieval.results,
                    metrics=final_metrics,
                )
            else:
                yield StreamChunk(text=text, is_final=False)

    async def get_artifact(self, artifact_id: str) -> dict[str, Any]:
        """
        Fetch a specific artifact by ID.

        Args:
            artifact_id: Artifact slug (e.g., "SOP-PV-01")

        Returns:
            Full artifact document with content and metadata
        """
        await self.initialize()
        return await self.backend.get_artifact(artifact_id)

    # -------------------------------------------------------------------------
    # Graph traversal methods (MCP mode only)
    # -------------------------------------------------------------------------

    async def get_policy_hierarchy(self, policy_id: str):
        """
        Get policy domain hierarchy.

        Only available in MCP mode. In direct mode, raises NotImplementedError.

        Args:
            policy_id: Policy domain ID (e.g., "RMP-001", "MMP-001")

        Returns:
            PolicyHierarchy object with full tree structure and helper methods
        """
        from ashmatics_aigov_tools.services.mcp_client import PolicyHierarchy

        await self.initialize()

        if not self.config.use_mcp:
            raise NotImplementedError("Graph traversals require MCP mode. Set use_mcp=True.")

        if isinstance(self._backend, MCPBackend):
            await self._backend.connect()  # Ensure client is connected
            return await self._backend.client.get_policy_hierarchy(policy_id)
        raise NotImplementedError("Backend does not support graph traversals.")

    async def find_control_implementations(self, control_id: str) -> dict[str, Any]:
        """
        Find SOPs implementing a control.

        Only available in MCP mode.

        Args:
            control_id: Control ID (e.g., "EXC-A4-01")

        Returns:
            Dict with implementing SOPs and related work products
        """
        await self.initialize()

        if not self.config.use_mcp:
            raise NotImplementedError("Graph traversals require MCP mode. Set use_mcp=True.")

        if isinstance(self._backend, MCPBackend):
            await self._backend.connect()  # Ensure client is connected
            result = await self._backend.client.find_control_implementations(control_id)
            return {
                "control_id": result.control_id,
                "control_title": result.control_title,
                "implementing_sops": result.implementing_sops,
                "related_work_products": result.related_work_products,
            }
        raise NotImplementedError("Backend does not support graph traversals.")

    async def get_regulatory_crosswalk(self, framework_id: str):
        """
        Get regulatory framework crosswalk.

        Only available in MCP mode.

        Args:
            framework_id: Framework ID (e.g., "NIST-AI-RMF", "JC-RUAIH")

        Returns:
            RegulatoryMapping object with crosswalk entries and helper methods
        """
        from ashmatics_aigov_tools.services.mcp_client import RegulatoryMapping

        await self.initialize()

        if not self.config.use_mcp:
            raise NotImplementedError("Graph traversals require MCP mode. Set use_mcp=True.")

        if isinstance(self._backend, MCPBackend):
            await self._backend.connect()  # Ensure client is connected
            return await self._backend.client.get_regulatory_crosswalk(framework_id)
        raise NotImplementedError("Backend does not support graph traversals.")

    # -------------------------------------------------------------------------
    # Internal methods
    # -------------------------------------------------------------------------

    def _get_llm(self):
        """Get or create the LLM client."""
        if self._llm is not None:
            return self._llm

        if self.config.llm_provider == "ollama":
            from ashmatics_tools.llm import OllamaClient, OllamaConfig

            model = self.config.llm_model or os.getenv("OLLAMA_MODEL", "llama3.2")
            self._llm = OllamaClient(
                OllamaConfig(
                    endpoint=self.config.ollama_endpoint,
                    model=model,
                    timeout=120.0,
                )
            )
        else:
            from ashmatics_tools.llm import AzureOpenAIClient, AzureOpenAIConfig

            model = (
                self.config.llm_model
                or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
                or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4o")
            )
            self._llm = AzureOpenAIClient(
                AzureOpenAIConfig(
                    deployment_name=model,
                )
            )

        return self._llm

    def _build_prompt(self, question: str, sources: list[SearchResult]) -> tuple[str, str]:
        """Build system and user prompts for RAG."""
        from ashmatics_tools.search.prompts import GOVERNANCE_RAG_SYSTEM_PROMPT

        system_prompt = self.config.system_prompt or GOVERNANCE_RAG_SYSTEM_PROMPT

        # Build context from sources
        context_parts = []
        for i, source in enumerate(sources, 1):
            source_id = source.document_id or f"Source {i}"
            context_parts.append(f"[{source_id}]\n{source.content}\n")

        context = "\n---\n".join(context_parts)

        user_prompt = f"""Context from the AI Governance Framework:

{context}

---

Question: {question}

Please answer based on the context above. Cite specific sources when possible."""

        return system_prompt, user_prompt

    async def _generate_answer(
        self, question: str, sources: list[SearchResult]
    ) -> tuple[str, dict[str, Any]]:
        """Generate an answer using the LLM."""
        from ashmatics_tools.llm.base import LLMMessage

        llm = self._get_llm()
        system_prompt, user_prompt = self._build_prompt(question, sources)

        messages = [
            LLMMessage(role="system", content=system_prompt),
            LLMMessage(role="user", content=user_prompt),
        ]

        async with llm:
            response = await llm.complete_with_messages(
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

        # Extract metrics if available
        metrics = {}
        if hasattr(response, "tokens") and response.tokens:
            tokens = response.tokens
            metrics = {
                "total_tokens": tokens.total_tokens if hasattr(tokens, "total_tokens") else 0,
                "prompt_tokens": tokens.prompt_tokens if hasattr(tokens, "prompt_tokens") else 0,
                "completion_tokens": tokens.completion_tokens if hasattr(tokens, "completion_tokens") else 0,
            }
            # Estimate cost (GPT-4o pricing)
            metrics["estimated_cost"] = (
                metrics["prompt_tokens"] * 0.005 / 1000 + metrics["completion_tokens"] * 0.015 / 1000
            )

        # Extract text from LLMResponse
        answer = response.text if hasattr(response, "text") else str(response)
        return answer, metrics

    async def _stream_answer(
        self, question: str, sources: list[SearchResult]
    ) -> AsyncIterator[tuple[str, bool, dict[str, Any] | None]]:
        """Stream an answer using the LLM."""
        llm = self._get_llm()
        system_prompt, user_prompt = self._build_prompt(question, sources)

        async with llm:
            async for chunk in llm.stream_chat(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            ):
                text = chunk.content if hasattr(chunk, "content") else str(chunk)
                is_done = chunk.is_final if hasattr(chunk, "is_final") else False

                metrics = None
                if is_done and hasattr(chunk, "usage"):
                    metrics = {
                        "total_tokens": chunk.usage.total_tokens,
                        "prompt_tokens": chunk.usage.prompt_tokens,
                        "completion_tokens": chunk.usage.completion_tokens,
                    }

                yield text, is_done, metrics


# Re-export for convenience
__all__ = [
    "AIGovQueryService",
    "AIGovQueryConfig",
    "QueryResult",
    "QueryMetrics",
    "StreamChunk",
    "SearchResult",
    "RetrievalResult",
]
