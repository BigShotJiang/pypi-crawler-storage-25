"""
Search Backend Implementations

Pluggable backends for AIGovQueryService retrieval:
- MCPBackend: Uses KB MCP server (recommended for production)
- DirectBackend: Direct CosmosDB access (for development/debugging)

Created: 2026-01-25
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.mcp_client import KBMCPClient


@dataclass
class SearchResult:
    """A single search result from any backend."""

    document_id: str
    content: str
    score: float
    title: str = ""
    artifact_type: str | None = None
    domain: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievalResult:
    """Result from a retrieval operation."""

    query: str
    results: list[SearchResult]
    intent_category: str | None = None
    complexity: str | None = None
    workflow: list[str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class SearchBackend(Protocol):
    """
    Protocol for search backends.

    Backends provide retrieval capabilities for the AIGovQueryService.
    Different backends can be swapped for different deployment contexts.
    """

    async def search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        domain: str | None = None,
        artifact_type: str | None = None,
    ) -> RetrievalResult:
        """
        Execute a search query.

        Args:
            query: Natural language query
            top_k: Number of results to return
            min_score: Minimum similarity score threshold
            domain: Optional domain filter
            artifact_type: Optional artifact type filter

        Returns:
            RetrievalResult with matched documents
        """
        ...

    async def get_artifact(self, artifact_id: str) -> dict[str, Any]:
        """
        Fetch full artifact content by ID.

        Args:
            artifact_id: Artifact slug

        Returns:
            Full artifact document
        """
        ...

    async def health_check(self) -> dict[str, Any]:
        """
        Check backend health.

        Returns:
            Health status dict
        """
        ...

    async def close(self) -> None:
        """Clean up backend resources."""
        ...


class MCPBackend(SearchBackend):
    """
    MCP-based search backend.

    Uses the KB MCP server for all retrieval operations.
    Recommended for production use - provides smart routing,
    intent classification, and graph traversals.
    """

    def __init__(self, client: KBMCPClient):
        """
        Initialize with an MCP client.

        Args:
            client: Configured KBMCPClient instance
        """
        self._client = client
        self._connected = False

    @property
    def client(self) -> KBMCPClient:
        """Get the MCP client."""
        return self._client

    async def connect(self) -> None:
        """Connect the MCP client if not already connected."""
        if not self._connected:
            await self._client.connect()
            self._connected = True

    async def close(self) -> None:
        """Close the MCP client."""
        if self._connected:
            await self._client.close()
            self._connected = False

    async def search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        domain: str | None = None,
        artifact_type: str | None = None,
    ) -> RetrievalResult:
        """
        Search using MCP agent_query for smart routing.

        Uses agent_query by default for intent-aware search.
        Falls back to semantic_search if domain/type filters specified.
        """
        await self.connect()

        # Use semantic_search for filtered queries, agent_query otherwise
        if domain or artifact_type:
            results = await self._client.semantic_search(
                query=query,
                top_k=top_k,
                min_score=min_score,
                domain=domain,
                artifact_type=artifact_type,
            )
            return RetrievalResult(
                query=query,
                results=[
                    SearchResult(
                        document_id=r.artifact_id,
                        content=r.content,
                        score=r.score,
                        metadata=r.metadata,
                    )
                    for r in results
                ],
            )

        # Use agent_query for smart routing
        agent_result = await self._client.agent_query(
            query=query,
            max_recommendations=top_k,
        )

        # Fetch full content for each recommendation
        results = []
        for rec in agent_result.recommendations:
            if min_score > 0 and rec.relevance_score < min_score:
                continue

            # Optionally fetch full content
            content = ""
            title = rec.title
            try:
                artifact = await self._client.get_artifact(rec.artifact_id)
                # Handle different artifact response structures
                if "content" in artifact:
                    content = artifact["content"]
                elif "sections" in artifact:
                    # Extract content from sections
                    sections = artifact.get("sections", [])
                    content_parts = []
                    for section in sections[:5]:  # Limit to first 5 sections
                        if section.get("content"):
                            content_parts.append(section["content"])
                    content = "\n\n".join(content_parts)
                elif "text" in artifact:
                    content = artifact["text"]

                # Get title from artifact if available
                if artifact.get("title"):
                    title = artifact["title"]
            except Exception:
                # Fallback to reason as content
                content = rec.reason

            results.append(
                SearchResult(
                    document_id=rec.artifact_id,
                    content=content,
                    score=rec.relevance_score,
                    title=title,
                    artifact_type=rec.artifact_type,
                    domain=rec.domain,
                    metadata={"reason": rec.reason, **rec.metadata},
                )
            )

        return RetrievalResult(
            query=query,
            results=results,
            intent_category=agent_result.intent_category,
            complexity=agent_result.estimated_complexity,
            workflow=agent_result.workflow,
            metadata=agent_result.metadata,
        )

    async def get_artifact(self, artifact_id: str) -> dict[str, Any]:
        """Fetch artifact via MCP."""
        await self.connect()
        return await self._client.get_artifact(artifact_id)

    async def health_check(self) -> dict[str, Any]:
        """Check MCP server health."""
        await self.connect()
        return await self._client.health_check()


class DirectBackend(SearchBackend):
    """
    Direct database backend.

    Connects directly to CosmosDB for vector search.
    Use for development, debugging, or when MCP server unavailable.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        database_name: str = "ai_strategy",
        collection_name: str = "aigov_framework_vectors",
    ):
        """
        Initialize direct backend.

        Args:
            connection_string: MongoDB/CosmosDB connection string.
                              If None, reads from MONGO_URL env var.
            database_name: Database name
            collection_name: Collection name for vectors
        """
        self._connection_string = connection_string or os.getenv("MONGO_URL") or os.getenv(
            "AZ_MONGO_CONNECTION_STRING"
        )
        self._database_name = database_name
        self._collection_name = collection_name

        # Lazy-loaded components
        self._vector_store = None
        self._embedder = None

    async def _ensure_initialized(self) -> None:
        """Initialize vector store and embedder if needed."""
        if self._vector_store is not None:
            return

        if not self._connection_string:
            raise ValueError(
                "MongoDB connection string not found. "
                "Set MONGO_URL or AZ_MONGO_CONNECTION_STRING environment variable."
            )

        # Import here to avoid loading heavy dependencies unless needed
        from ashmatics_tools.embedders import EmbeddingConfig, EmbeddingProvider, create_embedder
        from ashmatics_tools.vector_stores import (
            VectorStoreConfig,
            VectorStoreProvider,
            create_vector_store,
        )

        self._vector_store = create_vector_store(
            "cosmosdb",
            VectorStoreConfig(
                provider=VectorStoreProvider.COSMOSDB,
                connection_string=self._connection_string,
                database_name=self._database_name,
                collection_name=self._collection_name,
                dimensions=1536,
            ),
        )

        embedding_model = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "text-embedding-3-small")
        self._embedder = create_embedder(
            "azure",
            EmbeddingConfig(
                provider=EmbeddingProvider.AZURE,
                model=embedding_model,
            ),
        )
        await self._embedder.initialize()

    async def close(self) -> None:
        """Clean up resources."""
        # Vector store and embedder don't need explicit cleanup
        self._vector_store = None
        self._embedder = None

    async def search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        domain: str | None = None,
        artifact_type: str | None = None,
    ) -> RetrievalResult:
        """
        Search using direct vector similarity.

        Args:
            query: Natural language query
            top_k: Number of results
            min_score: Minimum similarity threshold
            domain: Optional domain filter (applied post-search)
            artifact_type: Optional type filter (applied post-search)

        Returns:
            RetrievalResult with matched documents
        """
        await self._ensure_initialized()

        # Embed the query
        query_embedding = await self._embedder.embed_query(query)

        # Build filter if domain or artifact_type specified
        filter_dict = {}
        if domain:
            filter_dict["domain"] = domain
        if artifact_type:
            filter_dict["artifact_type"] = artifact_type

        # Search vector store
        raw_results = await self._vector_store.similarity_search(
            query_embedding=query_embedding,
            top_k=top_k,
            filters=filter_dict if filter_dict else None,
            min_score=min_score if min_score > 0 else None,
        )

        # Convert to SearchResult
        results = []
        for doc in raw_results:
            score = doc.score if hasattr(doc, "score") else 0.0
            metadata = doc.metadata if hasattr(doc, "metadata") else {}
            results.append(
                SearchResult(
                    document_id=doc.document_id if hasattr(doc, "document_id") else "",
                    content=doc.content if hasattr(doc, "content") else "",
                    score=score,
                    title=metadata.get("title", ""),
                    artifact_type=metadata.get("artifact_type"),
                    domain=metadata.get("domain"),
                    metadata=metadata,
                )
            )

        return RetrievalResult(
            query=query,
            results=results,
        )

    async def get_artifact(self, artifact_id: str) -> dict[str, Any]:
        """
        Fetch artifact by ID from the vector collection.

        Note: This returns the vector document, not the full compiled view.
        For full content, query the framework_compiled_views collection.
        """
        await self._ensure_initialized()

        # Query by artifact_id in metadata
        # This is a simplified lookup - full implementation would query compiled views
        results = await self._vector_store.get_by_id(artifact_id)
        if results:
            return results
        return {"artifact_id": artifact_id, "error": "Not found"}

    async def health_check(self) -> dict[str, Any]:
        """Check database connectivity."""
        try:
            await self._ensure_initialized()
            await self._vector_store.health_check()
            count = await self._vector_store.count_documents()
            return {
                "healthy": True,
                "backend": "direct",
                "database": self._database_name,
                "collection": self._collection_name,
                "vector_count": count,
            }
        except Exception as e:
            return {
                "healthy": False,
                "backend": "direct",
                "error": str(e),
            }
