"""
Ashmatics CAI Framework Services

This module provides SDK-style services for querying the AI Governance Framework.
These services are framework-agnostic and can be consumed by any application
(FastAPI, Flask, Streamlit, CLI, etc.).

Created: 2026-01-25
Updated: 2026-01-26 - Added intelligent query preprocessing (ASHKBAPP-68)
Updated: 2026-01-27 - Added Framework Explorer Pipeline (ASHPSTUDIO-184)
Updated: 2026-01-28 - Added ASHCAI vocabulary and domain context (ASHKBAPP-185)
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.

Usage:
    from ashmatics_aigov_tools.services import AIGovQueryService, AIGovQueryConfig

    config = AIGovQueryConfig(use_mcp=True)
    service = AIGovQueryService(config)

    # Smart query with intelligent routing (recommended)
    result = await service.smart_query("What is Risk Management?")
    # -> Routes to POL-RMP-Overview, not a list of all RM documents

    # Legacy query (semantic search + LLM synthesis)
    result = await service.query("What SOPs for model monitoring?")

    # Search only (no LLM synthesis)
    results = await service.search("performance validation", top_k=5)

    # Streaming response
    async for chunk in service.stream_query("Explain risk management"):
        print(chunk.text, end="")

    # Graph traversal (MCP mode only)
    hierarchy = await service.get_policy_hierarchy("RMP-001")
    work_products = hierarchy.get_work_products()

    # Regulatory crosswalk
    crosswalk = await service.get_regulatory_crosswalk("NIST-AI-RMF")

    # Debug: see what the preprocessor understood
    plan = service.preprocess_query("What SOPs implement EXC-A4-01?")
    print(plan)  # {'intent': 'structural', 'strategy': 'graph', ...}
"""

# Core service and result types (SearchResult, RetrievalResult re-exported from backends)
from ashmatics_aigov_tools.services.aigov_query_service import (
    AIGovQueryConfig,
    AIGovQueryService,
    QueryMetrics,
    QueryResult,
    RetrievalResult,
    SearchResult,
    StreamChunk,
)

# Backend implementations
from ashmatics_aigov_tools.services.backends import (
    DirectBackend,
    MCPBackend,
    SearchBackend,
)

# ASHCAI vocabulary and domain context (ASHKBAPP-185)
from ashmatics_aigov_tools.services.ashcai_vocabulary import (
    COMPANY_CONTEXT,
    DOMAIN_ALIASES,
    DOMAIN_VOCABULARY_FULL,
    DOMAIN_VOCABULARY_SHORT,
    FRAMEWORK_STRUCTURE,
    POLICY_DOMAINS,
    PROCESS_DOMAINS,
    REFINEMENT_CONTEXT_SECTION,
    SYSTEM_CONTEXT_SECTION,
    get_all_domain_keywords,
    get_policy_domain_info,
    get_process_domain_info,
    resolve_domain_alias,
)

# Constants and mappings
from ashmatics_aigov_tools.services.constants import (
    CATEGORY_ALIASES,
    POLICY_DOMAIN_ALIASES,
    POLICY_DOMAIN_IDS,
    PROCESS_DOMAIN_ALIASES,
    PROCESS_DOMAIN_NAMES,
    REGULATORY_FRAMEWORK_ALIASES,
    REGULATORY_FRAMEWORK_NAMES,
    VALID_MCP_CATEGORIES,
    get_all_policy_domains,
    get_all_regulatory_frameworks,
    resolve_mcp_category,
    resolve_policy_domain,
    resolve_process_domain,
    resolve_regulatory_framework,
)

# Azure AI Foundry client (ASHKBAPP-68 Phase 2)
from ashmatics_aigov_tools.services.foundry_client import (
    CompletionResponse,
    FoundryClient,
    FoundryClientConfig,
    FoundryModel,
    get_foundry_client,
)
from ashmatics_aigov_tools.services.framework_explorer_pipeline import (
    FrameworkExplorerPipeline,
    explore_framework,
)

# LLM-based query classifier (ASHKBAPP-68 Phase 2)
from ashmatics_aigov_tools.services.llm_classifier import (
    INTENT_CATEGORIES,
    LLMQueryClassifier,
    create_llm_classifier_callback,
)

# MCP client
from ashmatics_aigov_tools.services.mcp_client import (
    ControlImplementation,
    KBMCPClient,
    MCPClientConfig,
    PolicyHierarchy,
    RegulatoryMapping,
)
from ashmatics_aigov_tools.services.pipeline_config import (
    PipelineConfig,
    SynthesizerConfig,
    ValidatorConfig,
)

# Framework Explorer Pipeline (ASHPSTUDIO-184)
from ashmatics_aigov_tools.services.pipeline_models import (
    Citation,
    ConfidenceLevel,
    PipelineContext,
    PipelineResult,
    PipelineStage,
    SynthesisResult,
    ValidationResult,
)
from ashmatics_aigov_tools.services.pipeline_prompts import (
    SYNTHESIS_PROMPT,
    VALIDATION_PROMPT,
    PromptFrontmatter,
    PromptTemplate,
    get_prompt,
    list_prompts,
)
from ashmatics_aigov_tools.services.query_orchestrator import (
    OrchestrationResult,
    QueryOrchestrator,
)

# Query preprocessing (ASHKBAPP-68)
from ashmatics_aigov_tools.services.query_preprocessor import (
    ExtractedEntities,
    QueryIntent,
    QueryPlan,
    QueryPreprocessor,
    RetrievalStrategy,
    preprocess_query,
)
from ashmatics_aigov_tools.services.response_synthesizer import ResponseSynthesizer
from ashmatics_aigov_tools.services.response_validator import ResponseValidator

__all__ = [
    # Core service
    "AIGovQueryService",
    "AIGovQueryConfig",
    # Result types
    "QueryResult",
    "QueryMetrics",
    "SearchResult",
    "RetrievalResult",
    "StreamChunk",
    # Backends
    "SearchBackend",
    "MCPBackend",
    "DirectBackend",
    # MCP client
    "KBMCPClient",
    "MCPClientConfig",
    # MCP result types
    "PolicyHierarchy",
    "RegulatoryMapping",
    "ControlImplementation",
    # Query preprocessing (ASHKBAPP-68)
    "QueryIntent",
    "RetrievalStrategy",
    "ExtractedEntities",
    "QueryPlan",
    "QueryPreprocessor",
    "QueryOrchestrator",
    "OrchestrationResult",
    "preprocess_query",
    # Azure AI Foundry client (ASHKBAPP-68 Phase 2)
    "FoundryClient",
    "FoundryClientConfig",
    "FoundryModel",
    "CompletionResponse",
    "get_foundry_client",
    # LLM classifier (ASHKBAPP-68 Phase 2)
    "LLMQueryClassifier",
    "INTENT_CATEGORIES",
    "create_llm_classifier_callback",
    # ASHCAI vocabulary (ASHKBAPP-185)
    "COMPANY_CONTEXT",
    "FRAMEWORK_STRUCTURE",
    "DOMAIN_VOCABULARY_SHORT",
    "DOMAIN_VOCABULARY_FULL",
    "SYSTEM_CONTEXT_SECTION",
    "REFINEMENT_CONTEXT_SECTION",
    "POLICY_DOMAINS",
    "PROCESS_DOMAINS",
    "DOMAIN_ALIASES",
    "get_policy_domain_info",
    "get_process_domain_info",
    "resolve_domain_alias",
    "get_all_domain_keywords",
    # Constants
    "POLICY_DOMAIN_IDS",
    "POLICY_DOMAIN_ALIASES",
    "PROCESS_DOMAIN_NAMES",
    "PROCESS_DOMAIN_ALIASES",
    "REGULATORY_FRAMEWORK_NAMES",
    "REGULATORY_FRAMEWORK_ALIASES",
    "VALID_MCP_CATEGORIES",
    "CATEGORY_ALIASES",
    # Resolution functions
    "resolve_policy_domain",
    "resolve_process_domain",
    "resolve_regulatory_framework",
    "resolve_mcp_category",
    "get_all_policy_domains",
    "get_all_regulatory_frameworks",
    # Framework Explorer Pipeline (ASHPSTUDIO-184)
    "FrameworkExplorerPipeline",
    "explore_framework",
    # Pipeline models
    "Citation",
    "ConfidenceLevel",
    "PipelineContext",
    "PipelineResult",
    "PipelineStage",
    "SynthesisResult",
    "ValidationResult",
    # Pipeline config
    "PipelineConfig",
    "SynthesizerConfig",
    "ValidatorConfig",
    # Pipeline prompts
    "PromptFrontmatter",
    "PromptTemplate",
    "SYNTHESIS_PROMPT",
    "VALIDATION_PROMPT",
    "get_prompt",
    "list_prompts",
    # Pipeline components
    "ResponseSynthesizer",
    "ResponseValidator",
]
