"""
Response Validator for Framework Explorer Pipeline

ASHPSTUDIO-184: Framework Explorer Pipeline

Validates synthesized responses for quality, accuracy, and relevance.
Uses GPT-4o-mini for fast, cost-effective validation checks.

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

from ashmatics_aigov_tools.services.foundry_client import (
    FoundryClient,
    FoundryClientConfig,
)
from ashmatics_aigov_tools.services.pipeline_config import ValidatorConfig
from ashmatics_aigov_tools.services.pipeline_models import (
    PipelineContext,
    ValidationResult,
)
from ashmatics_aigov_tools.services.pipeline_prompts import (
    get_prompt,
)

logger = logging.getLogger(__name__)


# =============================================================================
# RESPONSE VALIDATOR
# =============================================================================


class ResponseValidator:
    """
    Validates synthesized responses for quality and accuracy.

    Fast LLM check (GPT-4o-mini) that:
    - Verifies response addresses the query intent
    - Checks citation validity
    - Detects obvious errors or hallucinations
    - Calibrates confidence

    Can trigger retry or additional retrieval if issues found.

    Note: Validation is SKIPPED when synthesis confidence >= skip_threshold (default 0.90).
    This can be overridden via config or the force parameter.

    Usage:
        validator = ResponseValidator()
        result = await validator.validate(context)
        if not result.passed:
            # Retry synthesis with result.suggested_refinements
    """

    def __init__(self, config: ValidatorConfig | None = None):
        """
        Initialize the validator.

        Args:
            config: Validator configuration
        """
        self._config = config or ValidatorConfig()
        self._llm_client: FoundryClient | None = None
        self._prompt = get_prompt(self._config.prompt_name)

    def _get_llm_client(self) -> FoundryClient:
        """Get or create the LLM client."""
        if self._llm_client is None:
            # Create config for the fast model
            foundry_config = FoundryClientConfig.from_env()
            foundry_config.model_deployment = self._config.model
            self._llm_client = FoundryClient(foundry_config)
        return self._llm_client

    async def validate(
        self,
        context: PipelineContext,
        force: bool = False,
    ) -> ValidationResult:
        """
        Validate the synthesized response.

        Args:
            context: Full pipeline context including synthesis result
            force: If True, validate even if synthesis confidence >= skip_threshold

        Returns:
            ValidationResult with pass/fail, issues, refinements
        """
        start_time = time.time()

        # Check if we should skip validation
        synthesis = context.synthesis_result
        if not force and synthesis and synthesis.confidence >= self._config.skip_threshold:
            logger.info(
                f"Skipping validation: synthesis confidence {synthesis.confidence:.2f} "
                f">= threshold {self._config.skip_threshold}"
            )
            return ValidationResult.skipped_result(
                reason=f"synthesis_confidence ({synthesis.confidence:.2f}) >= "
                f"threshold ({self._config.skip_threshold})",
                confidence=synthesis.confidence,
            )

        # Check for missing synthesis result
        if not synthesis:
            return ValidationResult(
                passed=False,
                quality_score=0.0,
                issues=["No synthesis result to validate"],
                suggested_refinements=["Run synthesis stage first"],
            )

        # Build validation prompt
        user_prompt = self._build_user_prompt(context)

        # Call LLM
        llm_response = await self._call_llm(user_prompt)

        # Parse result
        result = self._parse_response(llm_response, synthesis.confidence)
        result.model_used = self._config.model
        result.prompt_version = self._prompt.frontmatter.version
        result.validation_ms = (time.time() - start_time) * 1000

        # Apply additional validation rules
        result = self._apply_validation_rules(context, result)

        return result

    def _build_user_prompt(self, context: PipelineContext) -> str:
        """Build the user prompt from context."""
        query = context.query
        intent = "unknown"
        plan_summary = "No query plan available"

        if context.query_plan:
            intent = context.query_plan.intent.value
            plan_summary = (
                f"Intent: {intent}, "
                f"Strategy: {context.query_plan.strategy.value}, "
                f"Tool: {context.query_plan.suggested_mcp_tool or 'N/A'}"
            )

        synthesis = context.synthesis_result
        response = synthesis.response if synthesis else ""
        confidence = synthesis.confidence if synthesis else 0.0
        citations = (
            json.dumps([c.to_dict() for c in synthesis.citations], indent=2) if synthesis else "[]"
        )

        return self._prompt.user_template.format(
            query=query,
            intent=intent,
            plan_summary=plan_summary,
            response=response,
            confidence=confidence,
            citations=citations,
        )

    async def _call_llm(self, user_prompt: str) -> dict[str, Any]:
        """Call the LLM and return parsed response."""
        client = self._get_llm_client()

        # Run synchronous client in thread pool
        def _complete():
            return client.complete_json(
                prompt=user_prompt,
                system_prompt=self._prompt.system,
                temperature=self._config.temperature,
                max_tokens=self._config.max_tokens,
            )

        response = await asyncio.to_thread(_complete)

        # Track token usage if available
        if "usage" in response:
            logger.debug(f"Validation tokens: {response.get('usage', {})}")

        return response

    def _parse_response(
        self,
        llm_response: dict[str, Any],
        synthesis_confidence: float,
    ) -> ValidationResult:
        """Parse LLM response into ValidationResult."""
        # Handle parse errors from complete_json
        if "error" in llm_response:
            logger.warning(f"LLM response parse error: {llm_response.get('error')}")
            # On parse error, default to pass with lower confidence
            return ValidationResult(
                passed=True,
                quality_score=synthesis_confidence * 0.9,  # Slight penalty
                issues=["Validation response parsing failed"],
                suggested_refinements=[],
            )

        # Extract fields
        passed = llm_response.get("passed", True)
        quality_score = float(llm_response.get("quality_score", synthesis_confidence))
        issues = llm_response.get("issues", [])
        suggested_refinements = llm_response.get("suggested_refinements", [])

        # Ensure issues and refinements are lists
        if isinstance(issues, str):
            issues = [issues] if issues else []
        if isinstance(suggested_refinements, str):
            suggested_refinements = [suggested_refinements] if suggested_refinements else []

        return ValidationResult(
            passed=passed,
            quality_score=quality_score,
            issues=issues,
            suggested_refinements=suggested_refinements,
        )

    def _apply_validation_rules(
        self,
        context: PipelineContext,
        result: ValidationResult,
    ) -> ValidationResult:
        """Apply additional validation rules beyond LLM check."""
        issues = list(result.issues)
        refinements = list(result.suggested_refinements)

        synthesis = context.synthesis_result
        if not synthesis:
            return result

        # Rule 1: Require citations if configured
        if self._config.require_citations and not synthesis.citations:
            issues.append("Response has no citations")
            refinements.append("Add citations to support claims")
            # Don't auto-fail, but lower quality score
            result = ValidationResult(
                passed=result.passed,
                quality_score=min(result.quality_score, 0.6),
                issues=issues,
                suggested_refinements=refinements,
                tokens_used=result.tokens_used,
                model_used=result.model_used,
                prompt_version=result.prompt_version,
                validation_ms=result.validation_ms,
            )

        # Rule 2: Quality score threshold
        if result.quality_score < self._config.min_quality_score:
            if result.passed:
                # Override pass if quality too low
                issues.append(
                    f"Quality score {result.quality_score:.2f} below "
                    f"threshold {self._config.min_quality_score}"
                )
                result = ValidationResult(
                    passed=False,
                    quality_score=result.quality_score,
                    issues=issues,
                    suggested_refinements=refinements,
                    tokens_used=result.tokens_used,
                    model_used=result.model_used,
                    prompt_version=result.prompt_version,
                    validation_ms=result.validation_ms,
                )

        # Rule 3: Empty response is always a fail
        if not synthesis.response or len(synthesis.response.strip()) < 50:
            issues.append("Response is empty or too short")
            refinements.append("Generate a more complete response")
            result = ValidationResult(
                passed=False,
                quality_score=0.2,
                issues=issues,
                suggested_refinements=refinements,
                tokens_used=result.tokens_used,
                model_used=result.model_used,
                prompt_version=result.prompt_version,
                validation_ms=result.validation_ms,
            )

        return result

    def close(self) -> None:
        """Close the LLM client."""
        if self._llm_client:
            self._llm_client.close()
            self._llm_client = None


__all__ = ["ResponseValidator"]
