"""
Pipeline Data Models for Framework Explorer

ASHPSTUDIO-184: Framework Explorer Pipeline

Dataclasses for pipeline stage outputs:
- Citation: Reference to a framework artifact
- SynthesisResult: Output from synthesis stage
- ValidationResult: Output from validation stage
- PipelineContext: Execution context flowing through stages
- PipelineResult: Final output to caller

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.query_orchestrator import OrchestrationResult
    from ashmatics_aigov_tools.services.query_preprocessor import QueryPlan


# =============================================================================
# ENUMS
# =============================================================================


class PipelineStage(str, Enum):
    """Pipeline execution stages."""

    QUERY = "query"
    RETRIEVAL = "retrieval"
    SYNTHESIS = "synthesis"
    VALIDATION = "validation"


class ConfidenceLevel(str, Enum):
    """Human-readable confidence levels."""

    HIGH = "high"  # >= 0.90
    MEDIUM = "medium"  # 0.70 - 0.89
    LOW = "low"  # 0.50 - 0.69
    VERY_LOW = "very_low"  # < 0.50

    @classmethod
    def from_score(cls, score: float) -> ConfidenceLevel:
        """Convert numeric score to confidence level."""
        if score >= 0.90:
            return cls.HIGH
        elif score >= 0.70:
            return cls.MEDIUM
        elif score >= 0.50:
            return cls.LOW
        else:
            return cls.VERY_LOW


# =============================================================================
# CITATION
# =============================================================================


@dataclass
class Citation:
    """
    A citation to a framework artifact.

    Used to track which artifacts support claims in synthesized responses.
    Currently artifact-level; designed to support section-level granularity later.
    """

    # Required
    artifact_id: str

    # Optional metadata
    artifact_type: str | None = None  # SOP, Policy, WorkProduct, etc.
    domain: str | None = None  # PV, MON, RM, etc.
    title: str | None = None

    # Citation context
    relevance: str = ""  # Why this was cited
    section: str | None = None  # For future section-level citations

    # Confidence in this citation
    citation_score: float | None = None

    def format_inline(self) -> str:
        """Format as inline citation: (see SOP-PV-01)"""
        return f"(see {self.artifact_id})"

    def format_footnote(self, number: int) -> str:
        """Format as footnote reference: [1]"""
        return f"[{number}]"

    def format_full(self) -> str:
        """Format with full details."""
        parts = [self.artifact_id]
        if self.title:
            parts.append(f'"{self.title}"')
        if self.relevance:
            parts.append(f"- {self.relevance}")
        return " ".join(parts)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "artifact_id": self.artifact_id,
            "artifact_type": self.artifact_type,
            "domain": self.domain,
            "title": self.title,
            "relevance": self.relevance,
            "section": self.section,
            "citation_score": self.citation_score,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Citation:
        """Deserialize from dictionary."""
        return cls(
            artifact_id=data.get("artifact_id", ""),
            artifact_type=data.get("artifact_type"),
            domain=data.get("domain"),
            title=data.get("title"),
            relevance=data.get("relevance", ""),
            section=data.get("section"),
            citation_score=data.get("citation_score"),
        )


# =============================================================================
# SYNTHESIS RESULT
# =============================================================================


@dataclass
class SynthesisResult:
    """
    Output from the synthesis stage.

    Contains the generated response, confidence score, citations,
    and any ambiguities or gaps identified during synthesis.
    """

    # Core output
    response: str  # Markdown-formatted response text
    confidence: float  # 0.0-1.0

    # Citations supporting the response
    citations: list[Citation] = field(default_factory=list)

    # Areas of uncertainty
    ambiguities: list[str] = field(default_factory=list)

    # Metadata
    tokens_used: int = 0
    model_used: str = ""
    prompt_version: str = ""

    # Augmentation tracking (additional MCP calls during synthesis)
    augmentation_calls: int = 0
    augmentation_artifacts: list[str] = field(default_factory=list)

    # Timing
    synthesis_ms: float = 0.0

    @property
    def confidence_level(self) -> ConfidenceLevel:
        """Get human-readable confidence level."""
        return ConfidenceLevel.from_score(self.confidence)

    @property
    def has_citations(self) -> bool:
        """Check if response has citations."""
        return len(self.citations) > 0

    @property
    def has_ambiguities(self) -> bool:
        """Check if synthesis identified ambiguities."""
        return len(self.ambiguities) > 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "response": self.response,
            "confidence": self.confidence,
            "confidence_level": self.confidence_level.value,
            "citations": [c.to_dict() for c in self.citations],
            "ambiguities": self.ambiguities,
            "tokens_used": self.tokens_used,
            "model_used": self.model_used,
            "prompt_version": self.prompt_version,
            "augmentation_calls": self.augmentation_calls,
            "synthesis_ms": self.synthesis_ms,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SynthesisResult:
        """Deserialize from dictionary."""
        return cls(
            response=data.get("response", ""),
            confidence=data.get("confidence", 0.0),
            citations=[Citation.from_dict(c) for c in data.get("citations", [])],
            ambiguities=data.get("ambiguities", []),
            tokens_used=data.get("tokens_used", 0),
            model_used=data.get("model_used", ""),
            prompt_version=data.get("prompt_version", ""),
            augmentation_calls=data.get("augmentation_calls", 0),
            synthesis_ms=data.get("synthesis_ms", 0.0),
        )


# =============================================================================
# VALIDATION RESULT
# =============================================================================


@dataclass
class ValidationResult:
    """
    Output from the validation stage.

    Contains pass/fail status, quality score, issues found,
    and suggested refinements for retry.
    """

    # Core result
    passed: bool
    quality_score: float  # 0.0-1.0

    # Issues found (empty if passed)
    issues: list[str] = field(default_factory=list)

    # How to improve (for retry)
    suggested_refinements: list[str] = field(default_factory=list)

    # Skip tracking
    skipped: bool = False
    skip_reason: str | None = None

    # Metadata
    tokens_used: int = 0
    model_used: str = ""
    prompt_version: str = ""

    # Timing
    validation_ms: float = 0.0

    @property
    def needs_retry(self) -> bool:
        """Check if validation failure warrants retry."""
        return not self.passed and not self.skipped and len(self.suggested_refinements) > 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "passed": self.passed,
            "quality_score": self.quality_score,
            "issues": self.issues,
            "suggested_refinements": self.suggested_refinements,
            "skipped": self.skipped,
            "skip_reason": self.skip_reason,
            "tokens_used": self.tokens_used,
            "model_used": self.model_used,
            "validation_ms": self.validation_ms,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ValidationResult:
        """Deserialize from dictionary."""
        return cls(
            passed=data.get("passed", False),
            quality_score=data.get("quality_score", 0.0),
            issues=data.get("issues", []),
            suggested_refinements=data.get("suggested_refinements", []),
            skipped=data.get("skipped", False),
            skip_reason=data.get("skip_reason"),
            tokens_used=data.get("tokens_used", 0),
            model_used=data.get("model_used", ""),
            validation_ms=data.get("validation_ms", 0.0),
        )

    @classmethod
    def skipped_result(cls, reason: str, confidence: float) -> ValidationResult:
        """Create a result for skipped validation."""
        return cls(
            passed=True,
            quality_score=confidence,
            skipped=True,
            skip_reason=reason,
        )


# =============================================================================
# PIPELINE CONTEXT
# =============================================================================


@dataclass
class PipelineContext:
    """
    Execution context that flows through all pipeline stages.

    Captures outputs from each stage for:
    - Downstream stage consumption (synthesis needs query plan)
    - Validation (validator sees full trace)
    - Observability (logging, debugging, analytics)
    - Caching (identify similar queries)
    """

    # Inputs
    query: str
    session_id: str | None = None
    user_context: dict[str, Any] = field(default_factory=dict)

    # Timestamps
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: datetime | None = None

    # Stage 1: Query Understanding
    query_plan: QueryPlan | None = None
    query_stage_ms: float = 0.0

    # Stage 2: Retrieval
    orchestration_result: OrchestrationResult | None = None
    retrieval_stage_ms: float = 0.0

    # Stage 3: Synthesis
    synthesis_result: SynthesisResult | None = None
    synthesis_stage_ms: float = 0.0

    # Stage 4: Validation
    validation_result: ValidationResult | None = None
    validation_stage_ms: float = 0.0

    # Retries (if validation fails)
    retry_count: int = 0
    max_retries: int = 2
    retry_history: list[dict[str, Any]] = field(default_factory=list)

    # Error tracking
    error: str | None = None
    error_stage: PipelineStage | None = None

    # Current stage (for observability)
    current_stage: PipelineStage | None = None

    @property
    def total_ms(self) -> float:
        """Total execution time across all stages."""
        return (
            self.query_stage_ms
            + self.retrieval_stage_ms
            + self.synthesis_stage_ms
            + self.validation_stage_ms
        )

    @property
    def total_tokens(self) -> int:
        """Total tokens used across all LLM calls."""
        tokens = 0
        if self.synthesis_result:
            tokens += self.synthesis_result.tokens_used
        if self.validation_result:
            tokens += self.validation_result.tokens_used
        return tokens

    @property
    def final_confidence(self) -> float:
        """Get final confidence (from validation or synthesis)."""
        if self.validation_result and not self.validation_result.skipped:
            return self.validation_result.quality_score
        if self.synthesis_result:
            return self.synthesis_result.confidence
        return 0.0

    @property
    def final_response(self) -> str | None:
        """Get final response text."""
        if self.synthesis_result:
            return self.synthesis_result.response
        return None

    def mark_complete(self) -> None:
        """Mark pipeline execution as complete."""
        self.completed_at = datetime.now()
        self.current_stage = None

    def record_retry(self, reason: str, refinements: list[str]) -> None:
        """Record a retry attempt."""
        self.retry_history.append(
            {
                "attempt": self.retry_count,
                "reason": reason,
                "refinements": refinements,
                "timestamp": datetime.now().isoformat(),
            }
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary (for logging/storage)."""
        return {
            "query": self.query,
            "session_id": self.session_id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "stages": {
                "query_ms": self.query_stage_ms,
                "retrieval_ms": self.retrieval_stage_ms,
                "synthesis_ms": self.synthesis_stage_ms,
                "validation_ms": self.validation_stage_ms,
            },
            "total_ms": self.total_ms,
            "total_tokens": self.total_tokens,
            "final_confidence": self.final_confidence,
            "retry_count": self.retry_count,
            "error": self.error,
            "error_stage": self.error_stage.value if self.error_stage else None,
        }


# =============================================================================
# PIPELINE RESULT
# =============================================================================


@dataclass
class PipelineResult:
    """
    Final output from the exploration pipeline.

    This is what gets returned to the caller (CLI, API, etc.).
    """

    # User-facing response
    response: str

    # Confidence level
    confidence: float

    # Supporting information
    citations: list[Citation]

    # Query understanding
    intent: str  # Intent category from query stage
    entities: dict[str, Any] = field(default_factory=dict)

    # Execution trace (for debugging/logging)
    context: PipelineContext | None = None

    # Status
    success: bool = True
    error: str | None = None

    # Timing
    total_ms: float = 0.0

    @property
    def confidence_level(self) -> ConfidenceLevel:
        """Get human-readable confidence level."""
        return ConfidenceLevel.from_score(self.confidence)

    def to_dict(self, include_context: bool = False) -> dict[str, Any]:
        """
        Serialize for API response.

        Args:
            include_context: Include full execution context (verbose)
        """
        result = {
            "response": self.response,
            "confidence": self.confidence,
            "confidence_level": self.confidence_level.value,
            "citations": [c.to_dict() for c in self.citations],
            "intent": self.intent,
            "entities": self.entities,
            "success": self.success,
            "error": self.error,
            "timing_ms": self.total_ms,
        }
        if include_context and self.context:
            result["context"] = self.context.to_dict()
        return result

    def to_markdown(self) -> str:
        """Format as markdown for display."""
        lines = [self.response, ""]

        if self.citations:
            lines.append("---")
            lines.append("**Sources:**")
            for citation in self.citations:
                lines.append(f"- {citation.format_full()}")

        lines.append("")
        lines.append(f"*Confidence: {self.confidence_level.value} ({self.confidence:.0%})*")

        return "\n".join(lines)

    @classmethod
    def error_result(
        cls,
        error: str,
        context: PipelineContext | None = None,
    ) -> PipelineResult:
        """Create an error result."""
        return cls(
            response="",
            confidence=0.0,
            citations=[],
            intent="error",
            context=context,
            success=False,
            error=error,
            total_ms=context.total_ms if context else 0.0,
        )


__all__ = [
    # Enums
    "PipelineStage",
    "ConfidenceLevel",
    # Dataclasses
    "Citation",
    "SynthesisResult",
    "ValidationResult",
    "PipelineContext",
    "PipelineResult",
]
