"""
Framework Explorer Pipeline

ASHPSTUDIO-184: Framework Explorer Pipeline

End-to-end pipeline for AI Governance framework exploration.
Orchestrates: Query → Retrieval → Synthesis → Validation

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Any

from ashmatics_aigov_tools.services.pipeline_config import PipelineConfig
from ashmatics_aigov_tools.services.pipeline_models import (
    PipelineContext,
    PipelineResult,
    PipelineStage,
)
from ashmatics_aigov_tools.services.query_orchestrator import QueryOrchestrator
from ashmatics_aigov_tools.services.query_preprocessor import QueryPreprocessor
from ashmatics_aigov_tools.services.response_synthesizer import ResponseSynthesizer
from ashmatics_aigov_tools.services.response_validator import ResponseValidator

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.mcp_client import KBMCPClient

logger = logging.getLogger(__name__)


# =============================================================================
# FRAMEWORK EXPLORER PIPELINE
# =============================================================================


class FrameworkExplorerPipeline:
    """
    End-to-end pipeline for AI Governance framework exploration.

    ASHPSTUDIO-184: Framework Explorer Pipeline

    Pipeline Stages:
    ================
    1. Query Understanding → query_preprocessor.py (QueryPreprocessor)
    2. Retrieval          → query_orchestrator.py (QueryOrchestrator)
    3. Synthesis          → response_synthesizer.py (ResponseSynthesizer)
    4. Validation         → response_validator.py (ResponseValidator)

    Supporting Files:
    =================
    - pipeline_models.py   → PipelineContext, PipelineResult, Citation, etc.
    - pipeline_config.py   → PipelineConfig, SynthesizerConfig, ValidatorConfig
    - pipeline_prompts.py  → SYNTHESIS_PROMPT, VALIDATION_PROMPT templates
    - mcp_client.py        → KBMCPClient for MCP server communication
    - foundry_client.py    → FoundryClient for LLM calls (GPT-4o, etc.)

    Features:
    =========
    - Configurable stages (can disable validation for speed)
    - Skip validation for high-confidence synthesis (>= 0.90)
    - Retry logic if validation fails (up to 2 retries)
    - Full execution tracing via PipelineContext
    - Extensible for different pipeline patterns

    Usage:
    ======
        async with KBMCPClient(config) as client:
            pipeline = FrameworkExplorerPipeline(client)
            result = await pipeline.explore("What is Risk Management?")
            print(result.response)
            print(result.citations)

    Note: This pipeline is focused on exploration/inquiry use cases.
    Content authoring/wizard flows would use a separate pipeline.
    """

    def __init__(
        self,
        mcp_client: KBMCPClient,
        config: PipelineConfig | None = None,
    ):
        """
        Initialize the pipeline.

        Args:
            mcp_client: Connected KBMCPClient instance
            config: Pipeline configuration
        """
        self._client = mcp_client
        self._config = config or PipelineConfig()

        # Initialize stages
        self._preprocessor = QueryPreprocessor(config=self._config.preprocessor_config)
        self._orchestrator = QueryOrchestrator(mcp_client)
        self._synthesizer = ResponseSynthesizer(
            mcp_client=mcp_client,
            config=self._config.synthesizer_config,
        )
        self._validator = ResponseValidator(config=self._config.validator_config)

    async def explore(
        self,
        query: str,
        user_context: dict[str, Any] | None = None,
        session_id: str | None = None,
        skip_validation: bool | None = None,
    ) -> PipelineResult:
        """
        Execute the full exploration pipeline.

        Args:
            query: User's natural language query
            user_context: Optional context (user role, preferences)
            session_id: Optional session ID for tracing
            skip_validation: Override config.enable_validation for this call.
                           If None, uses config + confidence-based skip logic.

        Returns:
            PipelineResult with response, confidence, citations, trace
        """
        # Initialize context
        context = PipelineContext(
            query=query,
            session_id=session_id,
            user_context=user_context or {},
            max_retries=self._config.max_retries,
        )

        if self._config.log_stages:
            logger.info(f"Pipeline started: query='{query[:50]}...'")

        try:
            # Stage 1: Query Understanding
            context = await self._execute_query_stage(context)

            # Stage 2: Retrieval
            context = await self._execute_retrieval_stage(context)

            # Stage 3: Synthesis
            context = await self._execute_synthesis_stage(context)

            # Stage 4: Validation (unless skipped)
            should_validate = self._should_validate(context, skip_validation)
            if should_validate:
                context = await self._execute_validation_stage(context)
            else:
                if self._config.log_stages:
                    logger.info("Validation stage skipped")

            # Mark complete
            context.mark_complete()

            # Build final result
            return self._build_result(context)

        except Exception as e:
            logger.exception(f"Pipeline error: {e}")
            context.error = str(e)
            context.error_stage = context.current_stage
            context.mark_complete()
            return self._build_error_result(context, e)

    async def _execute_query_stage(self, context: PipelineContext) -> PipelineContext:
        """Execute Stage 1: Query Understanding."""
        context.current_stage = PipelineStage.QUERY
        start_time = time.time()

        if self._config.log_stages:
            logger.info("Stage 1: Query Understanding")

        # Run preprocessor (sync call wrapped for async compatibility)
        plan = await asyncio.to_thread(self._preprocessor.process, context.query)
        context.query_plan = plan
        context.query_stage_ms = (time.time() - start_time) * 1000

        if self._config.log_stages:
            logger.info(
                f"  Intent: {plan.intent.value}, "
                f"Strategy: {plan.strategy.value}, "
                f"Confidence: {plan.confidence:.2f}"
            )

        return context

    async def _execute_retrieval_stage(self, context: PipelineContext) -> PipelineContext:
        """Execute Stage 2: Retrieval."""
        context.current_stage = PipelineStage.RETRIEVAL
        start_time = time.time()

        if self._config.log_stages:
            logger.info("Stage 2: Retrieval")

        if not context.query_plan:
            raise ValueError("Query plan required for retrieval stage")

        # Run orchestrator
        result = await self._orchestrator.execute(context.query_plan, context.query)
        context.orchestration_result = result
        context.retrieval_stage_ms = (time.time() - start_time) * 1000

        if self._config.log_stages:
            logger.info(
                f"  Results: {len(result.results)}, "
                f"Tools: {result.tools_called}, "
                f"Sources: {result.sources_used}"
            )

        return context

    async def _execute_synthesis_stage(self, context: PipelineContext) -> PipelineContext:
        """Execute Stage 3: Synthesis."""
        context.current_stage = PipelineStage.SYNTHESIS
        start_time = time.time()

        if self._config.log_stages:
            logger.info("Stage 3: Synthesis")

        # Run synthesizer
        result = await self._synthesizer.synthesize(context)
        context.synthesis_result = result
        context.synthesis_stage_ms = (time.time() - start_time) * 1000

        if self._config.log_stages:
            logger.info(
                f"  Confidence: {result.confidence:.2f}, "
                f"Citations: {len(result.citations)}, "
                f"Augmentations: {result.augmentation_calls}"
            )

        return context

    async def _execute_validation_stage(self, context: PipelineContext) -> PipelineContext:
        """Execute Stage 4: Validation with retry logic."""
        context.current_stage = PipelineStage.VALIDATION
        start_time = time.time()

        if self._config.log_stages:
            logger.info("Stage 4: Validation")

        # Run validator
        validation = await self._validator.validate(context)
        context.validation_result = validation
        context.validation_stage_ms = (time.time() - start_time) * 1000

        if self._config.log_stages:
            logger.info(
                f"  Passed: {validation.passed}, "
                f"Quality: {validation.quality_score:.2f}, "
                f"Skipped: {validation.skipped}"
            )

        # Retry if validation fails and retries available
        if not validation.passed and not validation.skipped:
            context = await self._handle_validation_retry(context)

        return context

    async def _handle_validation_retry(self, context: PipelineContext) -> PipelineContext:
        """Handle validation failure with retry."""
        validation = context.validation_result
        if not validation:
            return context

        while context.retry_count < context.max_retries and not validation.passed:
            context.retry_count += 1

            if self._config.log_stages:
                logger.info(
                    f"  Retry {context.retry_count}/{context.max_retries}: "
                    f"Issues: {validation.issues}"
                )

            # Record retry
            context.record_retry(
                reason="; ".join(validation.issues),
                refinements=validation.suggested_refinements,
            )

            # Re-synthesize with refinement hints
            refined = await self._synthesizer.synthesize(
                context,
                refinement_hints=validation.suggested_refinements,
            )
            context.synthesis_result = refined

            # Re-validate
            validation = await self._validator.validate(context, force=True)
            context.validation_result = validation

            if self._config.log_stages:
                logger.info(
                    f"  Retry result: Passed={validation.passed}, "
                    f"Quality={validation.quality_score:.2f}"
                )

        return context

    def _should_validate(
        self,
        context: PipelineContext,
        skip_override: bool | None,
    ) -> bool:
        """Determine if validation should run."""
        # Explicit override takes precedence
        if skip_override is not None:
            return not skip_override

        # Config disable
        if not self._config.enable_validation:
            return False

        # High-confidence synthesis skip (default threshold: 0.90)
        synthesis = context.synthesis_result
        if synthesis and synthesis.confidence >= self._config.validation_skip_threshold:
            if self._config.log_stages:
                logger.info(
                    f"  Skipping validation: confidence {synthesis.confidence:.2f} "
                    f">= {self._config.validation_skip_threshold}"
                )
            return False

        return True

    def _build_result(self, context: PipelineContext) -> PipelineResult:
        """Build final pipeline result from context."""
        synthesis = context.synthesis_result
        query_plan = context.query_plan

        if not synthesis:
            return PipelineResult.error_result(
                error="Synthesis stage did not produce a result",
                context=context,
            )

        # Determine final confidence
        validation = context.validation_result
        if validation and not validation.skipped:
            confidence = validation.quality_score
        else:
            confidence = synthesis.confidence

        # Extract entities for result
        entities: dict[str, Any] = {}
        if query_plan:
            plan_entities = query_plan.entities
            entities = {
                "artifact_ids": plan_entities.artifact_ids,
                "policy_domains": plan_entities.policy_domains,
                "process_domains": plan_entities.process_domains,
                "regulatory_frameworks": plan_entities.regulatory_frameworks,
                "control_ids": plan_entities.control_ids,
            }

        return PipelineResult(
            response=synthesis.response,
            confidence=confidence,
            citations=synthesis.citations,
            intent=query_plan.intent.value if query_plan else "unknown",
            entities=entities,
            context=context if self._config.trace_enabled else None,
            success=True,
            total_ms=context.total_ms,
        )

    def _build_error_result(
        self,
        context: PipelineContext,
        error: Exception,
    ) -> PipelineResult:
        """Build error result from exception."""
        return PipelineResult.error_result(
            error=str(error),
            context=context if self._config.trace_enabled else None,
        )

    def close(self) -> None:
        """Close all resources."""
        self._synthesizer.close()
        self._validator.close()

    async def __aenter__(self) -> FrameworkExplorerPipeline:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        self.close()


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================


async def explore_framework(
    query: str,
    mcp_client: KBMCPClient,
    config: PipelineConfig | None = None,
) -> PipelineResult:
    """
    Convenience function for one-off exploration queries.

    Args:
        query: User's natural language query
        mcp_client: Connected MCP client
        config: Optional pipeline config

    Returns:
        PipelineResult
    """
    pipeline = FrameworkExplorerPipeline(mcp_client, config)
    try:
        return await pipeline.explore(query)
    finally:
        pipeline.close()


__all__ = [
    "FrameworkExplorerPipeline",
    "explore_framework",
]
