"""
Pipeline Prompts for Framework Explorer

ASHPSTUDIO-184: Framework Explorer Pipeline

Prompt templates for synthesis and validation stages with metadata
for versioning, comparison, and quality analysis.

Each prompt is a PromptTemplate dataclass with:
- Frontmatter: version, author, description, model, tags
- System prompt: Instructions for the LLM
- User template: Format string for user message

Usage:
    from ashmatics_aigov_tools.services.pipeline_prompts import (
        SYNTHESIS_PROMPT,
        VALIDATION_PROMPT,
    )

    system = SYNTHESIS_PROMPT.system
    user = SYNTHESIS_PROMPT.user_template.format(query=query, intent=intent, ...)

Created: 2026-01-27
Updated: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

# ASHKBAPP-185: Import ASHCAI context for prompt injection
from ashmatics_aigov_tools.services.ashcai_vocabulary import (
    SYSTEM_CONTEXT_SECTION,
)

# =============================================================================
# PROMPT TEMPLATE STRUCTURE
# =============================================================================


@dataclass(frozen=True)
class PromptFrontmatter:
    """
    Metadata for a prompt template (like YAML frontmatter).

    Used for:
    - Version tracking and comparison
    - A/B testing different prompt versions
    - Quality analysis and tuning
    """

    # Identity
    name: str
    version: str  # Semantic versioning: MAJOR.MINOR.PATCH
    description: str

    # Authorship
    author: str = "Asher Informatics"
    created: date = field(default_factory=date.today)
    updated: date = field(default_factory=date.today)

    # Model targeting
    target_model: str = "gpt-4o"  # Model this prompt is optimized for
    fallback_models: tuple[str, ...] = ("gpt-4o-mini", "deepseek-v3")

    # Classification
    stage: str = ""  # "synthesis", "validation", etc.
    tags: tuple[str, ...] = ()

    # Quality tracking
    quality_score: float | None = None  # 0.0-1.0 from evaluation
    evaluation_date: date | None = None
    notes: str = ""


@dataclass(frozen=True)
class PromptTemplate:
    """
    A complete prompt template with frontmatter and content.

    Immutable to prevent accidental modification during runtime.
    """

    # Metadata
    frontmatter: PromptFrontmatter

    # Content
    system: str  # System prompt
    user_template: str  # User message template (use .format() or f-string)

    # Optional examples for few-shot
    examples: tuple[dict[str, str], ...] = ()

    def format_user(self, **kwargs: Any) -> str:
        """Format the user template with provided values."""
        return self.user_template.format(**kwargs)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for logging/storage."""
        return {
            "name": self.frontmatter.name,
            "version": self.frontmatter.version,
            "stage": self.frontmatter.stage,
            "target_model": self.frontmatter.target_model,
            "system_preview": self.system[:200] + "..." if len(self.system) > 200 else self.system,
        }


# =============================================================================
# SYNTHESIS PROMPT
# =============================================================================

SYNTHESIS_PROMPT = PromptTemplate(
    frontmatter=PromptFrontmatter(
        name="synthesis_v1",
        version="1.1.0",
        description="Synthesizes coherent responses from retrieval results for ASHCAI Governance framework queries",
        author="Asher Informatics / Claude",
        created=date(2026, 1, 27),
        updated=date(2026, 1, 28),
        target_model="gpt-4o",
        fallback_models=("deepseek-v3",),
        stage="synthesis",
        tags=("framework-explorer", "response-generation", "citation", "ashcai"),
        notes="ASHKBAPP-185: Added ASHCAI context and domain vocabulary",
    ),
    system=f"""{SYSTEM_CONTEXT_SECTION}

You are synthesizing a response about the Asher Informatics Clinical AI (ASHCAI) Governance Framework.

Your job is to create a clear, informative response that:
1. Directly addresses the user's question in the context of ASHCAI
2. Combines structured data (crosswalks, hierarchies) with explanatory content
3. Cites specific ASHCAI artifacts when making claims
4. Acknowledges gaps or uncertainties
5. Only falls back to general AI governance principles if ASHCAI content is unavailable

OUTPUT FORMAT (JSON only, no explanation outside JSON):
{{
  "response": "Markdown-formatted response text",
  "confidence": 0.0-1.0,
  "citations": [{{"artifact_id": "...", "artifact_type": "...", "relevance": "..."}}],
  "ambiguities": ["List any areas where the answer is uncertain"]
}}

GUIDELINES:
- Be concise but thorough
- Use bullet points and headers for readability
- When citing, use format: (see SOP-PV-01) or (per POL-RMP-Overview)
- Reference the correct domain (e.g., "In the PV (Problem Validation) domain...")
- If data is missing to fully answer, say so explicitly
- Confidence scoring:
  - 0.90+ = Fully answered with strong ASHCAI evidence
  - 0.70-0.89 = Mostly answered, minor gaps
  - 0.50-0.69 = Partially answered, significant gaps
  - <0.50 = Unable to adequately answer with ASHCAI content

CITATION REQUIREMENTS:
- Every factual claim should have a citation to an ASHCAI artifact
- Use artifact IDs exactly as provided in the retrieved data
- Include artifact_type (SOP, Policy, WorkProduct, Process, etc.) when known
- Prefer ASHCAI-specific artifacts over general statements

BRANDING:
- In your response, use "the AshMatics Clinical AI Governance Framework" (not "ASHCAI Framework")
- You may abbreviate to "the AshMatics CAI Framework" or "the CAI Framework" after first mention
- Domain codes (PV, RM, MON, etc.) and artifact IDs should remain as-is""",
    user_template="""Query: "{query}"
Intent: {intent}
Entities: {entities}

Retrieved Structured Data:
{structured_data}

Retrieved Content Snippets:
{content_snippets}

{refinement_section}
Synthesize a response that addresses this query using the retrieved information.""",
)


# =============================================================================
# VALIDATION PROMPT
# =============================================================================

VALIDATION_PROMPT = PromptTemplate(
    frontmatter=PromptFrontmatter(
        name="validation_v1",
        version="1.1.0",
        description="Validates synthesized responses for quality, accuracy, and relevance to ASHCAI",
        author="Asher Informatics / Claude",
        created=date(2026, 1, 27),
        updated=date(2026, 1, 28),
        target_model="gpt-4o-mini",
        fallback_models=(),
        stage="validation",
        tags=("framework-explorer", "quality-check", "guardrail", "ashcai"),
        notes="ASHKBAPP-185: Added ASHCAI context. Uses fast model for cost efficiency.",
    ),
    system=f"""You are a quality reviewer for Asher Informatics Clinical AI (ASHCAI) Governance Framework responses.

CONTEXT: This framework has 12 Policy Domains and 12 Process Domains. Responses should
reference specific ASHCAI artifacts (POL-*, PROC-*, SOP-*, WP-*) rather than generic statements.

Review the response and check:
1. RELEVANCE: Does it address the user's actual question in the ASHCAI context?
2. ACCURACY: Are claims supported by cited ASHCAI sources?
3. COMPLETENESS: Does it answer the full question or only part?
4. CONFIDENCE: Is the stated confidence appropriate given the evidence?
5. SPECIFICITY: Does it use ASHCAI terminology and artifacts, not just generic AI governance?
6. BRANDING: Uses "the AshMatics Clinical AI Governance Framework" (not "ASHCAI Framework")

OUTPUT FORMAT (JSON only):
{{
  "passed": true/false,
  "quality_score": 0.0-1.0,
  "issues": ["List any problems found"],
  "suggested_refinements": ["How to improve if issues found"]
}}

VALIDATION RULES:
- PASS if: Response addresses intent with ASHCAI artifacts, citations support claims, confidence is calibrated
- FAIL if: Wrong intent addressed, unsupported claims, major gaps, hallucinated content, generic answers when ASHCAI content should be available

Be strict but fair. Minor issues (formatting, verbosity) shouldn't fail validation.
Only fail for substantive problems that would mislead the user about ASHCAI.""",
    user_template="""Original Query: "{query}"
Query Intent: {intent}
Query Plan Summary: {plan_summary}

Synthesized Response:
{response}

Stated Confidence: {confidence}
Citations: {citations}

Validate this response.""",
)


# =============================================================================
# PROMPT REGISTRY
# =============================================================================

# All prompts indexed by name for easy lookup
PROMPT_REGISTRY: dict[str, PromptTemplate] = {
    "synthesis_v1": SYNTHESIS_PROMPT,
    "validation_v1": VALIDATION_PROMPT,
}


def get_prompt(name: str) -> PromptTemplate:
    """
    Get a prompt template by name.

    Args:
        name: Prompt name (e.g., "synthesis_v1")

    Returns:
        PromptTemplate instance

    Raises:
        KeyError: If prompt not found
    """
    if name not in PROMPT_REGISTRY:
        available = ", ".join(PROMPT_REGISTRY.keys())
        raise KeyError(f"Prompt '{name}' not found. Available: {available}")
    return PROMPT_REGISTRY[name]


def list_prompts(stage: str | None = None) -> list[str]:
    """
    List available prompts, optionally filtered by stage.

    Args:
        stage: Optional filter (e.g., "synthesis", "validation")

    Returns:
        List of prompt names
    """
    if stage is None:
        return list(PROMPT_REGISTRY.keys())
    return [name for name, prompt in PROMPT_REGISTRY.items() if prompt.frontmatter.stage == stage]


__all__ = [
    # Types
    "PromptFrontmatter",
    "PromptTemplate",
    # Prompts
    "SYNTHESIS_PROMPT",
    "VALIDATION_PROMPT",
    # Registry
    "PROMPT_REGISTRY",
    "get_prompt",
    "list_prompts",
]
