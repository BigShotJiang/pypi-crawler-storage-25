"""
MCP Client for Ashmatics Knowledgebase Server

Async HTTP client for communicating with the KB MCP server.
Supports agent_query, semantic_search, and graph traversal operations.

Created: 2026-01-25
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

import httpx


@dataclass
class MCPClientConfig:
    """Configuration for the KB MCP client."""

    base_url: str = "http://localhost:8088"
    api_key: str | None = None
    timeout: float = 30.0
    # Headers to include in all requests
    extra_headers: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> MCPClientConfig:
        """Create config from environment variables."""
        return cls(
            base_url=os.getenv("MCP_URL", "http://localhost:8088"),
            api_key=os.getenv("MCP_API_KEY"),
            timeout=float(os.getenv("MCP_TIMEOUT", "30.0")),
        )


@dataclass
class SearchRecommendation:
    """A single search recommendation from agent_query."""

    artifact_id: str
    title: str
    relevance_score: float
    reason: str
    artifact_type: str | None = None
    domain: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentQueryResult:
    """Result from agent_query tool."""

    query: str
    intent_category: str
    estimated_complexity: str
    recommendations: list[SearchRecommendation]
    workflow: list[str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SemanticSearchResult:
    """Result from semantic_search tool."""

    artifact_id: str
    content: str
    score: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicyHierarchy:
    """
    Policy domain hierarchy from graph traversal.

    Contains the full tree structure: Policy → Process Domains → Base Practices → SOPs → Work Products
    """

    policy_id: str
    policy_label: str
    process_domains: list[dict[str, Any]]
    total_base_practices: int = 0
    total_sops: int = 0
    total_work_products: int = 0
    traversal_depth: int = 0

    @property
    def title(self) -> str:
        """Alias for policy_label for backward compatibility."""
        return self.policy_label

    def get_all_entities(self, entity_type: str | None = None) -> list[dict[str, Any]]:
        """
        Extract all entities from the hierarchy tree.

        Args:
            entity_type: Optional filter (e.g., "WorkProductTemplate", "SOPTemplate")

        Returns:
            Flat list of all matching entities
        """
        entities: list[dict[str, Any]] = []

        def traverse(node: dict[str, Any]) -> None:
            if entity_type is None or node.get("entity_type") == entity_type:
                entities.append(node)
            for child in node.get("children", []):
                traverse(child)

        for process_domain in self.process_domains:
            traverse(process_domain)

        return entities

    def get_work_products(self) -> list[dict[str, Any]]:
        """Get all work product templates from the hierarchy."""
        return self.get_all_entities("WorkProductTemplate")

    def get_sops(self) -> list[dict[str, Any]]:
        """Get all SOP templates from the hierarchy."""
        return self.get_all_entities("SOPTemplate")

    def get_base_practices(self) -> list[dict[str, Any]]:
        """Get all base practices from the hierarchy."""
        return self.get_all_entities("BasePractice")

    def get_tools(self) -> list[dict[str, Any]]:
        """Get all tools from the hierarchy."""
        return self.get_all_entities("Tool")

    def get_process_domains_list(self) -> list[dict[str, Any]]:
        """Get just the process domains (top level children)."""
        return self.get_all_entities("ProcessDomain")


@dataclass
class ControlImplementation:
    """Control implementation details from graph traversal."""

    control_id: str
    control_title: str
    implementing_sops: list[dict[str, Any]]
    related_work_products: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class RegulatoryMapping:
    """Regulatory crosswalk mapping."""

    framework_id: str
    framework_name: str
    mappings: list[dict[str, Any]]
    total_requirements: int = 0

    def get_requirement(self, requirement_id: str) -> dict[str, Any] | None:
        """Get a specific requirement by ID."""
        for mapping in self.mappings:
            if mapping.get("requirement_id") == requirement_id:
                return mapping
        return None

    def get_mapped_policies(self) -> set[str]:
        """Get all unique policy IDs mapped in this crosswalk."""
        policies: set[str] = set()
        for mapping in self.mappings:
            policies.update(mapping.get("mapped_policies", []))
        return policies

    def get_mapped_controls(self) -> set[str]:
        """Get all unique control IDs mapped in this crosswalk."""
        controls: set[str] = set()
        for mapping in self.mappings:
            controls.update(mapping.get("mapped_controls", []))
        return controls


class MCPError(Exception):
    """Base exception for MCP client errors."""

    pass


class MCPConnectionError(MCPError):
    """Failed to connect to MCP server."""

    pass


class MCPAuthError(MCPError):
    """Authentication failed."""

    pass


class MCPToolError(MCPError):
    """MCP tool execution failed."""

    def __init__(self, message: str, tool_name: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.tool_name = tool_name
        self.details = details or {}


class KBMCPClient:
    """
    Async client for the Ashmatics Knowledgebase MCP server.

    Provides typed methods for calling MCP tools:
    - agent_query: Smart search routing with intent classification
    - semantic_search: Direct vector similarity search
    - get_policy_hierarchy: Graph traversal for policy domains
    - find_control_implementations: Find SOPs implementing controls
    - get_regulatory_crosswalk: Regulatory framework mappings
    - get_statistics: ASHCAI ontology statistics

    Usage:
        config = MCPClientConfig.from_env()
        async with KBMCPClient(config) as client:
            result = await client.agent_query("What SOPs for monitoring?")
            for rec in result.recommendations:
                print(f"{rec.artifact_id}: {rec.reason}")
    """

    def __init__(self, config: MCPClientConfig | None = None):
        """
        Initialize the MCP client.

        Args:
            config: Client configuration. If None, loads from environment.
        """
        self.config = config or MCPClientConfig.from_env()
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> KBMCPClient:
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()

    async def connect(self) -> None:
        """Initialize the HTTP client."""
        headers = dict(self.config.extra_headers)

        # Add authentication header
        if self.config.api_key:
            # Support both API key and Bearer token formats
            if self.config.api_key.startswith("Bearer "):
                headers["Authorization"] = self.config.api_key
            else:
                headers["X-API-Key"] = self.config.api_key

        self._client = httpx.AsyncClient(
            base_url=self.config.base_url,
            headers=headers,
            timeout=httpx.Timeout(self.config.timeout),
        )

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get the HTTP client, raising if not connected."""
        if self._client is None:
            raise MCPConnectionError("Client not connected. Use 'async with' or call connect().")
        return self._client

    async def _call_tool(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """
        Call an MCP tool and parse the response.

        Args:
            tool_name: Name of the MCP tool to call
            arguments: Tool arguments

        Returns:
            Parsed JSON response from the tool

        Raises:
            MCPConnectionError: If connection fails
            MCPAuthError: If authentication fails
            MCPToolError: If tool execution fails
        """
        payload = {
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments,
            },
        }

        try:
            response = await self.client.post("/api/v1/mcp/", json=payload)
        except httpx.ConnectError as e:
            raise MCPConnectionError(f"Failed to connect to MCP server: {e}") from e
        except httpx.TimeoutException as e:
            raise MCPConnectionError(f"MCP request timed out: {e}") from e

        if response.status_code == 401:
            raise MCPAuthError("MCP authentication failed. Check your API key.")
        if response.status_code == 403:
            raise MCPAuthError("MCP authorization denied. Insufficient permissions.")

        if response.status_code >= 400:
            raise MCPToolError(
                f"MCP request failed with status {response.status_code}",
                tool_name=tool_name,
                details={"status_code": response.status_code, "body": response.text},
            )

        data = response.json()

        # MCP response format: {"result": {"content": [{"text": "..."}]}, "error": null}
        if data.get("error"):
            raise MCPToolError(
                data["error"].get("message", "Unknown MCP error"),
                tool_name=tool_name,
                details=data["error"],
            )

        # Extract content from MCP response
        result = data.get("result", {})
        content = result.get("content", [])

        if content and isinstance(content, list):
            # Parse the JSON text from the first content block
            text = content[0].get("text", "{}")
            try:
                import json

                return json.loads(text)
            except json.JSONDecodeError:
                return {"raw_text": text}

        return result

    async def health_check(self) -> dict[str, Any]:
        """
        Check MCP server health.

        Returns:
            Health status dict with version, status, etc.
        """
        try:
            response = await self.client.get("/api/v1/health")
            if response.status_code == 200:
                return {"healthy": True, **response.json()}
            return {"healthy": False, "status_code": response.status_code}
        except Exception as e:
            return {"healthy": False, "error": str(e)}

    async def get_statistics(self) -> dict[str, Any]:
        """
        Get ASHCAI ontology statistics.

        Returns:
            Dict with entity counts and relationship statistics
        """
        return await self._call_tool("get_ashcai_statistics", {})

    async def agent_query(
        self,
        query: str,
        context: dict[str, Any] | None = None,
        max_recommendations: int = 5,
    ) -> AgentQueryResult:
        """
        Call agent_query for smart search routing.

        This is the primary search method - it classifies intent,
        routes to appropriate search strategies, and returns
        ranked recommendations with explanations.

        Args:
            query: User's natural language query
            context: Optional context dict (user role, prior queries, etc.)
            max_recommendations: Maximum number of recommendations to return

        Returns:
            AgentQueryResult with intent, recommendations, and suggested workflow
        """
        arguments = {
            "query": query,
        }
        if context:
            arguments["context"] = context

        result = await self._call_tool("agent_query", arguments)

        # Parse recommendations
        recommendations = []
        for rec in result.get("recommendations", []):
            artifact_id = rec.get("artifact_id", "")
            recommendations.append(
                SearchRecommendation(
                    artifact_id=artifact_id,
                    title=rec.get("title", artifact_id),  # Fallback to artifact_id if no title
                    relevance_score=rec.get("relevance_score", rec.get("score", 0.0)),
                    reason=rec.get("reason", ""),
                    artifact_type=rec.get("artifact_type"),
                    domain=rec.get("domain"),
                    metadata=rec.get("metadata", {}),
                )
            )

        # Extract context analysis if present (KB app nests these)
        context_analysis = result.get("context_analysis", {})

        return AgentQueryResult(
            query=query,
            intent_category=context_analysis.get(
                "intent_category", result.get("intent_category", "unknown")
            ),
            estimated_complexity=context_analysis.get(
                "estimated_complexity", result.get("estimated_complexity", "unknown")
            ),
            recommendations=recommendations,
            workflow=result.get("suggested_workflow", result.get("workflow")),
            metadata=result.get("metadata", {}),
        )

    async def semantic_search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.7,
        domain: str | None = None,
        artifact_prefix: str | None = None,
    ) -> list[SemanticSearchResult]:
        """
        Direct semantic vector search.

        Use this for specific retrieval needs when you want raw
        similarity results without intent classification.

        Args:
            query: Search query
            top_k: Number of results to return
            min_score: Minimum similarity score threshold (default 0.7)
            domain: Optional process domain filter (e.g., "PV", "MON", "RM")
            artifact_prefix: Optional artifact prefix filter (e.g., "SOP-", "WP-", "POL-")

        Returns:
            List of SemanticSearchResult ordered by score
        """
        arguments: dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "min_score": min_score,
        }
        if domain:
            arguments["domain"] = domain
        if artifact_prefix:
            arguments["artifact_prefix"] = artifact_prefix

        result = await self._call_tool("semantic_search_framework", arguments)

        return [
            SemanticSearchResult(
                artifact_id=r.get("artifact_id", ""),
                content=r.get("content", r.get("text", "")),
                score=r.get("score", r.get("similarity_score", r.get("relevance_score", 0.0))),
                metadata=r.get("metadata", {}),
            )
            for r in result.get("results", [])
        ]

    async def get_artifact(self, artifact_id: str) -> dict[str, Any]:
        """
        Fetch full artifact content by ID.

        Args:
            artifact_id: Artifact slug (e.g., "SOP-PV-01", "POL-MMP-Overview")

        Returns:
            Full artifact document with content and metadata
        """
        return await self._call_tool("get_artifact", {"artifact_id": artifact_id})

    async def get_policy_hierarchy(self, policy_id: str) -> PolicyHierarchy:
        """
        Get policy domain hierarchy via graph traversal.

        Returns the full tree structure from a policy domain down through
        process domains, base practices, SOPs, and work products.

        Args:
            policy_id: Policy domain ID (e.g., "RMP-001", "MMP-001")

        Returns:
            PolicyHierarchy with full tree and helper methods for extraction
        """
        result = await self._call_tool("get_policy_domain_hierarchy", {"policy_id": policy_id})

        return PolicyHierarchy(
            policy_id=result.get("policy_id", policy_id),
            policy_label=result.get("policy_label", ""),
            process_domains=result.get("process_domains", []),
            total_base_practices=result.get("total_base_practices", 0),
            total_sops=result.get("total_sops", 0),
            total_work_products=result.get("total_work_products", 0),
            traversal_depth=result.get("traversal_depth", 0),
        )

    async def find_control_implementations(self, control_id: str) -> ControlImplementation:
        """
        Find SOPs and work products implementing a control.

        Args:
            control_id: Exemplar control ID (e.g., "EXC-A4-01", "EXC-A5-02")

        Returns:
            ControlImplementation with implementing SOPs and work products
        """
        result = await self._call_tool("find_control_implementations", {"control_id": control_id})

        return ControlImplementation(
            control_id=result.get("control_id", control_id),
            control_title=result.get("control_title", ""),
            implementing_sops=result.get("implementing_sops", []),
            related_work_products=result.get("related_work_products", []),
        )

    async def find_evidence_for_requirement(self, requirement_id: str) -> dict[str, Any]:
        """
        Find work products that serve as evidence for a regulatory requirement.

        Args:
            requirement_id: Regulatory requirement ID (e.g., "NIST-AI-RMF-GOVERN-1.1")

        Returns:
            Dict with requirement details and mapped evidence (work products)
        """
        return await self._call_tool(
            "find_evidence_for_requirement", {"requirement_id": requirement_id}
        )

    async def get_category_content(
        self,
        category: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """
        Get all content within a specific category.

        Args:
            category: Content category. Valid values:
                      "policies", "processes", "templates", "tools", "forms",
                      "policy_templates", "process_templates"
            limit: Maximum results to return

        Returns:
            List of content items in the category

        Note:
            Use resolve_mcp_category() from constants module to convert
            aliases like "sops" to valid category names.
        """
        result = await self._call_tool(
            "get_category_content",
            {"category": category, "limit": limit},
        )
        return result.get("items", result.get("content", []))

    async def get_regulatory_crosswalk(self, framework_id: str) -> RegulatoryMapping:
        """
        Get regulatory framework crosswalk mapping.

        Args:
            framework_id: Framework identifier. Valid values:
                         "NIST-AI-RMF", "JC-RUAIH", "ONC-HTI1", "CO-AI-ACT", "ACA-1557"

        Returns:
            RegulatoryMapping with framework details and requirement mappings

        Note:
            Use resolve_regulatory_framework() from constants module to convert
            aliases like "nist" or "joint commission" to valid framework IDs.
        """
        result = await self._call_tool("get_regulatory_crosswalk", {"framework_id": framework_id})

        return RegulatoryMapping(
            framework_id=result.get("framework_id", framework_id),
            framework_name=result.get("framework_name", ""),
            mappings=result.get("crosswalk_entries", result.get("mappings", [])),
            total_requirements=result.get("total_requirements", len(result.get("crosswalk_entries", []))),
        )
