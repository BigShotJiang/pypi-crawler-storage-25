"""
Pipeline Configuration for Framework Explorer

ASHPSTUDIO-184: Framework Explorer Pipeline

Configuration dataclasses for pipeline stages:
- SynthesizerConfig: ResponseSynthesizer settings
- ValidatorConfig: ResponseValidator settings
- PipelineConfig: Overall pipeline configuration

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ashmatics_aigov_tools.services.query_preprocessor import QueryPreprocessorConfig


# =============================================================================
# SYNTHESIZER CONFIG
# =============================================================================


@dataclass
class SynthesizerConfig:
    """
    Configuration for ResponseSynthesizer.

    Controls LLM settings, augmentation behavior, and output format.
    """

    # LLM settings - GPT-4o via Azure AI Foundry
    # Can swap to "deepseek-v3" for cost optimization later
    model: str = "gpt-4o"
    temperature: float = 0.3  # Lower for more consistent output
    max_tokens: int = 1500
    timeout: float = 30.0

    # Prompt selection
    prompt_name: str = "synthesis_v1"

    # Augmentation behavior (additional MCP calls during synthesis)
    enable_augmentation: bool = True
    max_augmentation_calls: int = 3
    min_confidence_for_augmentation: float = 0.6  # Augment if confidence < this

    # Output formatting
    include_citations: bool = True
    citation_format: str = "inline"  # "inline" or "footnotes"

    # Retry behavior (within synthesis stage)
    max_parse_retries: int = 2  # Retries if JSON parsing fails

    @classmethod
    def from_env(cls) -> SynthesizerConfig:
        """Create config from environment variables."""
        return cls(
            model=os.getenv("SYNTHESIS_MODEL", "gpt-4o"),
            temperature=float(os.getenv("SYNTHESIS_TEMPERATURE", "0.3")),
            max_tokens=int(os.getenv("SYNTHESIS_MAX_TOKENS", "1500")),
            timeout=float(os.getenv("SYNTHESIS_TIMEOUT", "30.0")),
            enable_augmentation=os.getenv("SYNTHESIS_ENABLE_AUGMENTATION", "true").lower()
            == "true",
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "timeout": self.timeout,
            "prompt_name": self.prompt_name,
            "enable_augmentation": self.enable_augmentation,
            "max_augmentation_calls": self.max_augmentation_calls,
            "min_confidence_for_augmentation": self.min_confidence_for_augmentation,
            "include_citations": self.include_citations,
            "citation_format": self.citation_format,
        }


# =============================================================================
# VALIDATOR CONFIG
# =============================================================================


@dataclass
class ValidatorConfig:
    """
    Configuration for ResponseValidator.

    Controls LLM settings, validation strictness, and skip behavior.
    """

    # LLM settings - GPT-4o-mini for fast, cheap validation
    model: str = "gpt-4o-mini"
    temperature: float = 0.1  # Very deterministic for consistent validation
    max_tokens: int = 500
    timeout: float = 15.0

    # Prompt selection
    prompt_name: str = "validation_v1"

    # Validation strictness
    min_quality_score: float = 0.7  # Below this = fail
    require_citations: bool = True  # Fail if no citations

    # Skip validation for high-confidence synthesis
    skip_threshold: float = 0.90  # Skip if synthesis confidence >= this

    @classmethod
    def from_env(cls) -> ValidatorConfig:
        """Create config from environment variables."""
        return cls(
            model=os.getenv("VALIDATION_MODEL", "gpt-4o-mini"),
            temperature=float(os.getenv("VALIDATION_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("VALIDATION_MAX_TOKENS", "500")),
            timeout=float(os.getenv("VALIDATION_TIMEOUT", "15.0")),
            skip_threshold=float(os.getenv("VALIDATION_SKIP_THRESHOLD", "0.90")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "timeout": self.timeout,
            "prompt_name": self.prompt_name,
            "min_quality_score": self.min_quality_score,
            "require_citations": self.require_citations,
            "skip_threshold": self.skip_threshold,
        }


# =============================================================================
# PIPELINE CONFIG
# =============================================================================


@dataclass
class PipelineConfig:
    """
    Configuration for FrameworkExplorerPipeline.

    Controls overall pipeline behavior, stage configs, and cost limits.
    """

    # Stage configs (use defaults if not provided)
    preprocessor_config: QueryPreprocessorConfig | None = None
    synthesizer_config: SynthesizerConfig | None = None
    validator_config: ValidatorConfig | None = None

    # Pipeline behavior
    enable_validation: bool = True
    validation_skip_threshold: float = 0.90  # Skip if synthesis confidence >= this
    max_retries: int = 2  # Retries before returning partial response

    # Observability
    log_stages: bool = True
    trace_enabled: bool = True
    log_prompts: bool = False  # Log full prompts (verbose, for debugging)

    # Cost controls
    max_total_tokens: int = 5000
    max_total_time_ms: float = 60000  # 60 seconds

    # Caching (response-level)
    enable_cache: bool = False
    cache_ttl_seconds: int = 3600  # 1 hour

    # Feature flags
    enable_augmentation: bool = True  # Allow synthesis to make additional MCP calls

    def __post_init__(self) -> None:
        """Initialize stage configs with defaults if not provided."""
        if self.synthesizer_config is None:
            self.synthesizer_config = SynthesizerConfig()
        if self.validator_config is None:
            self.validator_config = ValidatorConfig()

        # Sync validation skip threshold
        if self.validator_config.skip_threshold != self.validation_skip_threshold:
            self.validator_config = ValidatorConfig(
                model=self.validator_config.model,
                temperature=self.validator_config.temperature,
                max_tokens=self.validator_config.max_tokens,
                timeout=self.validator_config.timeout,
                prompt_name=self.validator_config.prompt_name,
                min_quality_score=self.validator_config.min_quality_score,
                require_citations=self.validator_config.require_citations,
                skip_threshold=self.validation_skip_threshold,
            )

    @classmethod
    def from_env(cls) -> PipelineConfig:
        """Create config from environment variables."""
        return cls(
            synthesizer_config=SynthesizerConfig.from_env(),
            validator_config=ValidatorConfig.from_env(),
            enable_validation=os.getenv("PIPELINE_ENABLE_VALIDATION", "true").lower() == "true",
            validation_skip_threshold=float(
                os.getenv("PIPELINE_VALIDATION_SKIP_THRESHOLD", "0.90")
            ),
            max_retries=int(os.getenv("PIPELINE_MAX_RETRIES", "2")),
            log_stages=os.getenv("PIPELINE_LOG_STAGES", "true").lower() == "true",
            trace_enabled=os.getenv("PIPELINE_TRACE_ENABLED", "true").lower() == "true",
            max_total_tokens=int(os.getenv("PIPELINE_MAX_TOKENS", "5000")),
            max_total_time_ms=float(os.getenv("PIPELINE_MAX_TIME_MS", "60000")),
            enable_cache=os.getenv("PIPELINE_ENABLE_CACHE", "false").lower() == "true",
        )

    @classmethod
    def fast(cls) -> PipelineConfig:
        """
        Create a fast config that skips validation.

        Use for:
        - Development/testing
        - Simple queries (known_item, list_entities)
        - When latency is critical
        """
        return cls(
            enable_validation=False,
            max_retries=0,
            synthesizer_config=SynthesizerConfig(
                enable_augmentation=False,
            ),
        )

    @classmethod
    def thorough(cls) -> PipelineConfig:
        """
        Create a thorough config with strict validation.

        Use for:
        - Complex queries (comparative, gap_analysis)
        - Customer-facing responses
        - When accuracy is critical
        """
        return cls(
            enable_validation=True,
            validation_skip_threshold=1.0,  # Never skip
            max_retries=2,
            synthesizer_config=SynthesizerConfig(
                enable_augmentation=True,
                max_augmentation_calls=5,
            ),
            validator_config=ValidatorConfig(
                min_quality_score=0.8,
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "synthesizer": self.synthesizer_config.to_dict() if self.synthesizer_config else None,
            "validator": self.validator_config.to_dict() if self.validator_config else None,
            "enable_validation": self.enable_validation,
            "validation_skip_threshold": self.validation_skip_threshold,
            "max_retries": self.max_retries,
            "log_stages": self.log_stages,
            "trace_enabled": self.trace_enabled,
            "max_total_tokens": self.max_total_tokens,
            "max_total_time_ms": self.max_total_time_ms,
            "enable_cache": self.enable_cache,
        }


__all__ = [
    "SynthesizerConfig",
    "ValidatorConfig",
    "PipelineConfig",
]
