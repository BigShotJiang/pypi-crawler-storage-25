"""
Azure AI Foundry Client Wrapper

Provides a simplified interface to Azure AI Foundry (via azure-ai-projects SDK)
for chat completions and inference operations.

Requires:
    pip install azure-ai-projects azure-identity openai

Environment Variables:
    AZURE_FOUNDRY_ENDPOINT - Model endpoint (required)
        For OpenAI models (GPT-4, etc.):
            https://{ai-services-account-name}.services.ai.azure.com/api/projects/{project-name}
        For serverless models (DeepSeek, Llama, etc.):
            https://{deployment-name}.{region}.models.ai.azure.com
    AZURE_FOUNDRY_MODEL - Model deployment name (optional, defaults to "gpt-4o")
        Examples: "gpt-4o", "gpt-4o-mini", "DeepSeek-R1"
    AZURE_FOUNDRY_API_KEY - API key for authentication (optional)
        If not set, uses DefaultAzureCredential (az login, managed identity)

Note on Serverless Models:
    Models like DeepSeek-R1 deployed via Azure AI Foundry's "Serverless API"
    have their own endpoint (*.models.ai.azure.com). Get this endpoint from
    the Azure portal under your model deployment's "Endpoint" tab.

Created: 2026-01-26
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class FoundryModel(str, Enum):
    """Available model deployments in Azure AI Foundry."""

    GPT_4O = "gpt-4o"
    GPT_4O_MINI = "gpt-4o-mini"
    DEEPSEEK_R1 = "deepseek-r1"
    DEEPSEEK_V3 = "deepseek-v3"
    # Add more as needed


@dataclass
class CompletionResponse:
    """Response from a completion request."""

    content: str
    model: str
    usage: dict[str, int]
    reasoning: str | None = None  # For reasoning models like DeepSeek-R1
    raw_response: Any = None


@dataclass
class FoundryClientConfig:
    """Configuration for FoundryClient."""

    endpoint: str
    model_deployment: str
    api_version: str = "2025-01-01-preview"

    @classmethod
    def from_env(cls) -> FoundryClientConfig:
        """
        Create config from environment variables.

        Supported endpoint env vars (checked in order):
        - AZURE_FOUNDRY_OPENAI_ENDPOINT: Foundry OpenAI-compatible endpoint (preferred)
        - AZURE_OPENAI_ENDPOINT: Azure OpenAI / Cognitive Services endpoint
        - AZURE_FOUNDRY_ENDPOINT: Azure AI Foundry project endpoint

        Endpoint formats:
        - Foundry OpenAI: https://{resource}.openai.azure.com/openai/v1/
        - Azure OpenAI: https://{resource}.openai.azure.com or
                       https://{resource}.cognitiveservices.azure.com
        - Azure AI Foundry: https://{account}.services.ai.azure.com/api/projects/{project}
        """
        endpoint = (
            os.environ.get("AZURE_FOUNDRY_OPENAI_ENDPOINT")
            or os.environ.get("AZURE_OPENAI_ENDPOINT")
            or os.environ.get("AZURE_FOUNDRY_ENDPOINT")
        )
        model = os.environ.get("AZURE_FOUNDRY_MODEL", "gpt-4o")

        if not endpoint:
            raise ValueError(
                "AZURE_OPENAI_ENDPOINT or AZURE_FOUNDRY_ENDPOINT environment variable is required. "
                "Format: https://{resource}.cognitiveservices.azure.com or "
                "https://{account}.services.ai.azure.com/api/projects/{project}"
            )

        return cls(endpoint=endpoint, model_deployment=model)


class FoundryClient:
    """
    Wrapper around Azure AI Foundry for simplified inference.

    Usage:
        from ashmatics_aigov_tools.services.foundry_client import FoundryClient

        client = FoundryClient.from_env()
        response = client.complete("What is 2+2?")
        print(response.content)

        # With system prompt
        response = client.complete(
            prompt="Classify this: 'What is Risk Management?'",
            system_prompt="You are a query classifier. Output JSON.",
            temperature=0.1,
        )

        # JSON mode
        result = client.complete_json(
            prompt="Classify: 'What SOPs implement EXC-A4-01?'",
            system_prompt="Classify intent as: structural, topical, or explanation",
        )
    """

    def __init__(self, config: FoundryClientConfig | None = None):
        """
        Initialize the Foundry client.

        Args:
            config: Client configuration. If None, loads from environment.
        """
        self.config = config or FoundryClientConfig.from_env()
        self._project_client = None
        self._openai_client = None

    @classmethod
    def from_env(cls, model: FoundryModel | str | None = None) -> FoundryClient:
        """
        Create client from environment variables.

        Args:
            model: Optional model override. If None, uses AZURE_FOUNDRY_MODEL.
        """
        config = FoundryClientConfig.from_env()
        if model:
            config.model_deployment = model.value if isinstance(model, FoundryModel) else model
        return cls(config)

    def _get_project_client(self):
        """Get or create the AIProjectClient (only used with DefaultAzureCredential)."""
        if self._project_client is None:
            try:
                from azure.ai.projects import AIProjectClient
            except ImportError as e:
                raise ImportError(
                    "Required packages not installed. Run: "
                    "pip install azure-ai-projects azure-identity"
                ) from e

            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential()
            logger.debug("Using DefaultAzureCredential for Foundry")

            self._project_client = AIProjectClient(
                endpoint=self.config.endpoint,
                credential=credential,
            )

        return self._project_client

    def _get_openai_client(self):
        """Get or create the authenticated OpenAI client."""
        if self._openai_client is None:
            endpoint = self.config.endpoint.rstrip("/")

            # Determine which API key to use based on endpoint type
            # Foundry endpoints should prefer Foundry keys, Azure OpenAI prefers AZURE_OPENAI keys
            if "/openai/v1" in endpoint or ".models.ai.azure.com" in endpoint:
                # Foundry endpoint - prefer Foundry API keys first
                api_key = (
                    os.environ.get("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")
                    or os.environ.get("AZURE_FOUNDRY_API_KEY")
                    or os.environ.get("AZURE_OPENAI_API_KEY")
                    or os.environ.get("AZURE_OPENAI_KEY")
                )
            else:
                # Azure OpenAI / Cognitive Services - prefer Azure OpenAI keys
                api_key = (
                    os.environ.get("AZURE_OPENAI_KEY")
                    or os.environ.get("AZURE_OPENAI_API_KEY")
                    or os.environ.get("AZURE_FOUNDRY_API_KEY")
                    or os.environ.get("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")
                )

            if api_key:
                try:
                    from openai import AzureOpenAI, OpenAI
                except ImportError as e:
                    raise ImportError(
                        "openai package not installed. Run: pip install openai"
                    ) from e

                # Detect endpoint type and choose appropriate client
                #
                # Pattern 1: Foundry OpenAI-compatible endpoint
                #   Format: https://{resource}.openai.azure.com/openai/v1/
                #   Uses: standard OpenAI client with base_url
                #
                # Pattern 2: Serverless model endpoints
                #   Format: https://{deployment}.{region}.models.ai.azure.com
                #   Uses: standard OpenAI client with base_url
                #
                # Pattern 3: Azure OpenAI / Cognitive Services
                #   Format: https://{resource}.openai.azure.com or
                #          https://{resource}.cognitiveservices.azure.com
                #   Uses: AzureOpenAI client

                if "/openai/v1" in endpoint:
                    # Foundry OpenAI-compatible endpoint - use standard OpenAI client
                    # Endpoint should already include /openai/v1/ path
                    base_url = endpoint if endpoint.endswith("/") else f"{endpoint}/"
                    self._openai_client = OpenAI(
                        api_key=api_key,
                        base_url=base_url,
                    )
                    logger.debug(f"Using OpenAI client for Foundry endpoint: {base_url}")

                elif ".models.ai.azure.com" in endpoint:
                    # Serverless models use standard OpenAI client with custom base_url
                    self._openai_client = OpenAI(
                        api_key=api_key,
                        base_url=f"{endpoint}/v1",
                    )
                    logger.debug(f"Using OpenAI client for serverless model: {endpoint}")

                else:
                    # Azure OpenAI / Cognitive Services - use AzureOpenAI client
                    # Remove /api/projects/{project} suffix if present
                    if "/api/projects/" in endpoint:
                        base_url = endpoint.split("/api/projects/")[0]
                    else:
                        base_url = endpoint

                    self._openai_client = AzureOpenAI(
                        api_key=api_key,
                        api_version=self.config.api_version,
                        azure_endpoint=base_url,
                    )
                    logger.debug(f"Using AzureOpenAI with API key, endpoint: {base_url}")
            else:
                # Use AIProjectClient with DefaultAzureCredential
                project_client = self._get_project_client()
                self._openai_client = project_client.get_openai_client()
                logger.debug("Using OpenAI client from AIProjectClient")

        return self._openai_client

    def complete(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs,
    ) -> CompletionResponse:
        """
        Execute a chat completion.

        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            temperature: Sampling temperature (0.0 = deterministic)
            max_tokens: Maximum tokens in response
            **kwargs: Additional args passed to chat.completions.create

        Returns:
            CompletionResponse with content and metadata
        """
        openai_client = self._get_openai_client()

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        logger.debug(f"Calling {self.config.model_deployment} with {len(messages)} messages")

        response = openai_client.chat.completions.create(
            model=self.config.model_deployment,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )

        content = response.choices[0].message.content or ""

        # Extract reasoning if present (for DeepSeek-R1 and similar)
        reasoning = None
        if hasattr(response.choices[0].message, "reasoning_content"):
            reasoning = response.choices[0].message.reasoning_content

        return CompletionResponse(
            content=content,
            model=response.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            },
            reasoning=reasoning,
            raw_response=response,
        )

    def complete_json(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.1,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Execute a completion expecting JSON output.

        Args:
            prompt: User prompt
            system_prompt: System prompt (should instruct JSON output)
            temperature: Low temperature recommended for structured output
            **kwargs: Additional args

        Returns:
            Parsed JSON dict, or {"error": ..., "raw": ...} on parse failure
        """
        # Add JSON instruction if not in system prompt
        if system_prompt and "json" not in system_prompt.lower():
            system_prompt = system_prompt + "\n\nRespond with valid JSON only."
        elif not system_prompt:
            system_prompt = "Respond with valid JSON only."

        response = self.complete(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            **kwargs,
        )

        # Try to parse JSON
        content = response.content.strip()

        # Handle markdown code blocks
        if content.startswith("```"):
            lines = content.split("\n")
            # Remove first and last lines (```json and ```)
            content = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse JSON: {e}")
            return {"error": str(e), "raw": response.content}

    def close(self):
        """Close the client connections."""
        if self._openai_client:
            self._openai_client.close()
            self._openai_client = None
        if self._project_client:
            self._project_client.close()
            self._project_client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# Convenience function
def get_foundry_client(model: FoundryModel | str | None = None) -> FoundryClient:
    """
    Get a configured Foundry client.

    Args:
        model: Optional model deployment name or FoundryModel enum

    Returns:
        Configured FoundryClient
    """
    return FoundryClient.from_env(model=model)


__all__ = [
    "FoundryClient",
    "FoundryClientConfig",
    "FoundryModel",
    "CompletionResponse",
    "get_foundry_client",
]
