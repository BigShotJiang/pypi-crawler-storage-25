"""
ASHCAI Domain Vocabulary and Framework Context

ASHKBAPP-185: Enhance Domain Recognition & Context

Centralized definitions for the Asher Informatics Clinical AI (ASHCAI) Governance
Framework. This module provides domain vocabulary, aliases, and context for:
- Query preprocessing (entity extraction, intent classification)
- LLM prompts (synthesis, validation, refinement)
- System context for agentic workflows

Framework Hierarchy:
====================
    POLICIES (12 domains)
        └── Define requirements and governance rules
        └── Artifacts: Overview Summary, Policy Template
            │
            ▼
    PROCESSES (12 domains)
        └── Operationalize policies through procedures
        └── Artifacts: Overview Summary, SOPs, Work Products
            │
            ▼
    CONTROLS
        └── Collect evidence that processes are performed
        └── Validate policies are being followed
            │
            ▼
    TOOLS
        └── Software (Asher Informatics or partner) that activates processes
        └── Configured via AI Governance Studio's agentic wizard

Company Context:
================
- Company: Asher Informatics
- Platform: AshMatics
- Studio: AI Governance Studio (realizes the CAI Governance Framework)
- Framework: Clinical AI (CAI) Governance Framework (also: ASHCAI)

Created: 2026-01-28
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

# =============================================================================
# COMPANY & PLATFORM CONTEXT
# =============================================================================

COMPANY_CONTEXT = """
CONTEXT: Asher Informatics Clinical AI Governance Framework
============================================================

You are answering questions about the Asher Informatics Clinical AI (CAI)
Governance Framework, also known internally as "ASHCAI" or simply "CAI".

Company & Platform:
- Company: Asher Informatics (creates AI governance solutions for healthcare)
- Platform: AshMatics (the software platform)
- Studio: AI Governance Studio (the main application for CAI governance)
- Framework: Clinical AI (CAI) Governance Framework

BRANDING GUIDELINES:
- In responses, use "the AshMatics Clinical AI Governance Framework" (full name)
- Acceptable abbreviations after first mention: "the AshMatics CAI Framework" or "the CAI Framework"
- Do NOT use "ASHCAI Framework" in user-facing responses (ASHCAI is internal shorthand only)
- Domain codes (PV, RM, MON) and artifact IDs (SOP-PV-01) remain unchanged

IMPORTANT INTERPRETATION RULES:
1. ALWAYS interpret queries in the context of the ASHCAI framework FIRST
2. Use ASHCAI-specific artifacts, domains, and terminology when available
3. Only fall back to general AI governance principles if:
   - No relevant ASHCAI content is found (confidence < 10%)
   - The user explicitly asks about external frameworks
4. When comparing to external frameworks (NIST, ISO, etc.), always ground
   the comparison in how ASHCAI maps to or differs from them
"""

# =============================================================================
# FRAMEWORK STRUCTURE
# =============================================================================

FRAMEWORK_STRUCTURE = """
ASHCAI FRAMEWORK STRUCTURE
==========================

The framework has a hierarchical structure:

POLICY DOMAINS (12 total)
├── Define governance requirements and rules
├── Each has: Overview Summary + Policy Template
└── Configured by organizations using the AI Governance Studio wizard

    ↓ specifies ↓

PROCESS DOMAINS (12 total)
├── Operationalize policies through standard procedures
├── Each has: Overview Summary + many SOPs + Work Product templates
└── SOPs define step-by-step procedures; Work Products are deliverables

    ↓ implements ↓

CONTROLS
├── Collect evidence that processes are being performed correctly
├── Map to regulatory requirements (NIST, Joint Commission, etc.)
└── Validate that policies are actually being followed

    ↓ activated by ↓

TOOLS
├── Software applications (Asher Informatics or partner tools)
├── Activate and automate process execution
└── Configured via the AI Governance Studio's agentic wizard
"""

# =============================================================================
# POLICY DOMAINS (12)
# =============================================================================

POLICY_DOMAINS = {
    "AGP": {
        "name": "AI Governance Policy",
        "description": "Overarching governance framework for clinical AI systems",
        "artifacts": ["POL-AGP-Overview", "POLT-AGP-Template"],
        "related_process": "OVR",
        "keywords": ["governance", "framework", "oversight", "organization"],
    },
    "RMP": {
        "name": "Risk Management Policy",
        "description": "Requirements for identifying, assessing, and mitigating AI risks",
        "artifacts": ["POL-RMP-Overview", "POLT-RMP-Template"],
        "related_process": "RM",
        "keywords": ["risk", "mitigation", "assessment", "safety"],
    },
    "HOP": {
        "name": "Human Oversight Policy",
        "description": "Requirements for human oversight and control of AI systems",
        "artifacts": ["POL-HOP-Overview", "POLT-HOP-Template"],
        "related_process": "HO",
        "keywords": ["human oversight", "control", "intervention", "supervision"],
    },
    "EFP": {
        "name": "Ethics & Fairness Policy",
        "description": "Requirements for ethical AI and algorithmic fairness",
        "artifacts": ["POL-EFP-Overview", "POLT-EFP-Template"],
        "related_process": "EF",
        "keywords": ["ethics", "fairness", "bias", "equity", "discrimination"],
    },
    "MMP": {
        "name": "Model Monitoring & Management Policy",
        "description": "Requirements for model lifecycle management and monitoring",
        "artifacts": ["POL-MMP-Overview", "POLT-MMP-Template"],
        "related_process": "MON",
        "keywords": ["monitoring", "lifecycle", "drift", "performance", "model management"],
    },
    "TPP": {
        "name": "Transparency Policy",
        "description": "Requirements for AI transparency and explainability",
        "artifacts": ["POL-TPP-Overview", "POLT-TPP-Template"],
        "related_process": "TR",
        "keywords": ["transparency", "explainability", "interpretability", "disclosure"],
    },
    "VAL": {
        "name": "Validation Policy",
        "description": "Requirements for AI system validation before deployment",
        "artifacts": ["POL-VAL-Overview", "POLT-VAL-Template"],
        "related_process": "PV",
        "keywords": ["validation", "verification", "testing", "pre-deployment"],
    },
    "SAP": {
        "name": "Security & Access Policy",
        "description": "Requirements for AI system security and access control",
        "artifacts": ["POL-SAP-Overview", "POLT-SAP-Template"],
        "related_process": "SA",
        "keywords": ["security", "access", "authentication", "authorization"],
    },
    "DGP": {
        "name": "Data Governance Policy",
        "description": "Requirements for data management in AI systems",
        "artifacts": ["POL-DGP-Overview", "POLT-DGP-Template"],
        "related_process": "IT",
        "keywords": ["data governance", "data quality", "data management", "data privacy"],
    },
    "SEP": {
        "name": "Stakeholder Engagement Policy",
        "description": "Requirements for stakeholder communication and engagement",
        "artifacts": ["POL-SEP-Overview", "POLT-SEP-Template"],
        "related_process": "SE",
        "keywords": ["stakeholder", "engagement", "communication", "participation"],
    },
    "LTP": {
        "name": "Lifecycle & Training Policy",
        "description": "Requirements for AI lifecycle management and staff training",
        "artifacts": ["POL-LTP-Overview", "POLT-LTP-Template"],
        "related_process": "TR",
        "keywords": ["lifecycle", "training", "education", "competency"],
    },
    "CMP": {
        "name": "Change Management Policy",
        "description": "Requirements for managing changes to AI systems",
        "artifacts": ["POL-CMP-Overview", "POLT-CMP-Template"],
        "related_process": "MON",
        "keywords": ["change management", "versioning", "updates", "releases"],
    },
}

# =============================================================================
# PROCESS DOMAINS (12)
# =============================================================================

PROCESS_DOMAINS = {
    "PV": {
        "name": "Problem Validation",
        "full_name": "Problem Validation & Use Case Selection",
        "description": "Validates clinical problems and selects appropriate AI use cases before development begins",
        "artifacts": ["PROC-PV-Overview", "SOP-PV-01", "SOP-PV-02", "SOP-PV-03"],
        "work_products": ["WP-PV-01", "WP-PV-02", "WP-PV-03"],
        "related_policy": "VAL",
        "keywords": [
            "problem validation", "use case", "use-case", "use case selection",
            "problem definition", "clinical need", "value proposition",
            "feasibility", "opportunity assessment"
        ],
    },
    "SA": {
        "name": "Solution Architecting",
        "full_name": "Solution Architecting & Technical Design",
        "description": "Designs AI system architecture, technical approach, and integration patterns",
        "artifacts": ["PROC-SA-Overview", "SOP-SA-01", "SOP-SA-02", "SOP-SA-03"],
        "work_products": ["WP-SA-01", "WP-SA-02", "WP-SA-03"],
        "related_policy": "SAP",
        "keywords": [
            "solution architecting", "solution architecture", "technical design",
            "system design", "architecture", "integration", "technical approach"
        ],
    },
    "MON": {
        "name": "Model Monitoring",
        "full_name": "Model Monitoring & Lifecycle Management",
        "description": "Monitors deployed AI models for drift, performance degradation, and safety issues",
        "artifacts": ["PROC-MON-Overview", "SOP-MON-01", "SOP-MON-02", "SOP-MON-03"],
        "work_products": ["WP-MON-01", "WP-MON-02", "WP-MON-03"],
        "related_policy": "MMP",
        "keywords": [
            "model monitoring", "monitoring", "drift detection", "performance monitoring",
            "model lifecycle", "lifecycle management", "model degradation"
        ],
    },
    "RM": {
        "name": "Risk Management",
        "full_name": "Clinical AI Risk Management",
        "description": "Identifies, assesses, mitigates, and tracks risks throughout the AI lifecycle",
        "artifacts": ["PROC-RM-Overview", "SOP-RM-01", "SOP-RM-02", "SOP-RM-03"],
        "work_products": ["WP-RM-01", "WP-RM-02", "WP-RM-03"],
        "related_policy": "RMP",
        "keywords": [
            "risk management", "risk assessment", "risk mitigation", "risk",
            "clinical risk", "ai risk", "hazard", "harm"
        ],
    },
    "HO": {
        "name": "Human Oversight",
        "full_name": "Human Oversight & AI Interaction",
        "description": "Ensures appropriate human oversight, control mechanisms, and intervention capabilities",
        "artifacts": ["PROC-HO-Overview", "SOP-HO-01", "SOP-HO-02", "SOP-HO-03"],
        "work_products": ["WP-HO-01", "WP-HO-02", "WP-HO-03"],
        "related_policy": "HOP",
        "keywords": [
            "human oversight", "human-in-the-loop", "human control", "oversight",
            "intervention", "override", "supervision", "ai interaction"
        ],
    },
    "EF": {
        "name": "Ethics & Fairness",
        "full_name": "Ethics, Fairness & Bias Management",
        "description": "Ensures ethical AI practices, algorithmic fairness, and bias mitigation",
        "artifacts": ["PROC-EF-Overview", "SOP-EF-01", "SOP-EF-02", "SOP-EF-03"],
        "work_products": ["WP-EF-01", "WP-EF-02", "WP-EF-03"],
        "related_policy": "EFP",
        "keywords": [
            "ethics", "fairness", "bias", "equity", "discrimination",
            "algorithmic fairness", "ethical ai", "bias mitigation"
        ],
    },
    "TR": {
        "name": "Transparency",
        "full_name": "Transparency & Explainability",
        "description": "Ensures AI system transparency, explainability, and appropriate disclosure",
        "artifacts": ["PROC-TR-Overview", "SOP-TR-01", "SOP-TR-02", "SOP-TR-03"],
        "work_products": ["WP-TR-01", "WP-TR-02", "WP-TR-03"],
        "related_policy": "TPP",
        "keywords": [
            "transparency", "explainability", "interpretability", "disclosure",
            "explanation", "understandability", "xai", "explainable ai"
        ],
    },
    "OVR": {
        "name": "Oversight",
        "full_name": "Governance Oversight & Organizational Structure",
        "description": "Establishes governance structures, committees, roles, and accountability",
        "artifacts": ["PROC-OVR-Overview", "SOP-OVR-01", "SOP-OVR-02", "SOP-OVR-03"],
        "work_products": ["WP-OVR-01", "WP-OVR-02", "WP-OVR-03"],
        "related_policy": "AGP",
        "keywords": [
            "oversight", "governance", "committee", "accountability",
            "organizational structure", "roles", "responsibilities"
        ],
    },
    "ORG": {
        "name": "Organization",
        "full_name": "Organizational Strategy & Planning",
        "description": "Aligns AI initiatives with organizational strategy and objectives",
        "artifacts": ["PROC-ORG-Overview", "SOP-ORG-01", "SOP-ORG-02", "SOP-ORG-03"],
        "work_products": ["WP-ORG-01", "WP-ORG-02", "WP-ORG-03"],
        "related_policy": "AGP",
        "keywords": [
            "organization", "strategy", "planning", "alignment",
            "objectives", "organizational", "strategic"
        ],
    },
    "IT": {
        "name": "IT Systems",
        "full_name": "IT Systems & Data Management",
        "description": "Manages IT infrastructure, data systems, and technical operations for AI",
        "artifacts": ["PROC-IT-Overview", "SOP-IT-01", "SOP-IT-02", "SOP-IT-03", "SOP-IT-04"],
        "work_products": ["WP-IT-01", "WP-IT-02", "WP-IT-03"],
        "related_policy": "DGP",
        "keywords": [
            "it systems", "data management", "infrastructure", "data",
            "technical operations", "systems", "data governance"
        ],
    },
    "SE": {
        "name": "Stakeholder Engagement",
        "full_name": "Stakeholder Engagement & Communication",
        "description": "Engages stakeholders, manages communication, and ensures participation",
        "artifacts": ["PROC-SE-Overview", "SOP-SE-01", "SOP-SE-02", "SOP-SE-03"],
        "work_products": ["WP-SE-01", "WP-SE-02", "WP-SE-03"],
        "related_policy": "SEP",
        "keywords": [
            "stakeholder engagement", "stakeholder", "communication",
            "participation", "engagement", "stakeholder management"
        ],
    },
    "UG": {
        "name": "Usage Governance",
        "full_name": "Usage Governance & User Compliance",
        "description": "Governs appropriate AI usage and ensures user compliance with policies",
        "artifacts": ["PROC-UG-Overview", "SOP-UG-01", "SOP-UG-02", "SOP-UG-03"],
        "work_products": ["WP-UG-01", "WP-UG-02", "WP-UG-03"],
        "related_policy": "AGP",
        "keywords": [
            "usage governance", "user compliance", "appropriate use",
            "usage", "compliance", "user governance"
        ],
    },
}

# =============================================================================
# NATURAL LANGUAGE ALIASES -> DOMAIN CODES
# =============================================================================

# Comprehensive mapping from natural language phrases to domain codes
# Format: "phrase": (code, domain_type) where domain_type is "policy" or "process"

DOMAIN_ALIASES: dict[str, tuple[str, str]] = {
    # =========================================================================
    # Problem Validation (PV) - Process Domain
    # =========================================================================
    "problem validation": ("PV", "process"),
    "problem-validation": ("PV", "process"),
    "use case": ("PV", "process"),
    "use-case": ("PV", "process"),
    "use case selection": ("PV", "process"),
    "use-case selection": ("PV", "process"),
    "usecase": ("PV", "process"),
    "problem definition": ("PV", "process"),
    "clinical need": ("PV", "process"),
    "value proposition": ("PV", "process"),
    "feasibility assessment": ("PV", "process"),
    "opportunity assessment": ("PV", "process"),
    "pre-deployment validation": ("PV", "process"),
    "validation": ("PV", "process"),

    # =========================================================================
    # Solution Architecting (SA) - Process Domain
    # =========================================================================
    "solution architecting": ("SA", "process"),
    "solution architecture": ("SA", "process"),
    "solution-architecting": ("SA", "process"),
    "technical design": ("SA", "process"),
    "system design": ("SA", "process"),
    "ai architecture": ("SA", "process"),
    "architecture design": ("SA", "process"),
    "integration design": ("SA", "process"),
    "technical approach": ("SA", "process"),
    "architecting": ("SA", "process"),

    # =========================================================================
    # Model Monitoring (MON) - Process Domain
    # =========================================================================
    "model monitoring": ("MON", "process"),
    "model-monitoring": ("MON", "process"),
    "monitoring": ("MON", "process"),
    "drift detection": ("MON", "process"),
    "performance monitoring": ("MON", "process"),
    "model lifecycle": ("MON", "process"),
    "lifecycle management": ("MON", "process"),
    "model drift": ("MON", "process"),
    "model performance": ("MON", "process"),
    "model degradation": ("MON", "process"),

    # =========================================================================
    # Risk Management (RM) - Process Domain
    # =========================================================================
    "risk management": ("RM", "process"),
    "risk-management": ("RM", "process"),
    "risk assessment": ("RM", "process"),
    "risk mitigation": ("RM", "process"),
    "clinical risk": ("RM", "process"),
    "ai risk": ("RM", "process"),
    "risk": ("RM", "process"),
    "hazard analysis": ("RM", "process"),
    "harm prevention": ("RM", "process"),

    # =========================================================================
    # Human Oversight (HO) - Process Domain
    # =========================================================================
    "human oversight": ("HO", "process"),
    "human-oversight": ("HO", "process"),
    "human in the loop": ("HO", "process"),
    "human-in-the-loop": ("HO", "process"),
    "hitl": ("HO", "process"),
    "human control": ("HO", "process"),
    "ai oversight": ("HO", "process"),
    "intervention": ("HO", "process"),
    "override": ("HO", "process"),
    "supervision": ("HO", "process"),
    "ai interaction": ("HO", "process"),

    # =========================================================================
    # Ethics & Fairness (EF) - Process Domain
    # =========================================================================
    "ethics": ("EF", "process"),
    "fairness": ("EF", "process"),
    "ethics and fairness": ("EF", "process"),
    "ethics & fairness": ("EF", "process"),
    "bias": ("EF", "process"),
    "bias mitigation": ("EF", "process"),
    "algorithmic fairness": ("EF", "process"),
    "equity": ("EF", "process"),
    "discrimination": ("EF", "process"),
    "ethical ai": ("EF", "process"),

    # =========================================================================
    # Transparency (TR) - Process Domain
    # =========================================================================
    "transparency": ("TR", "process"),
    "explainability": ("TR", "process"),
    "interpretability": ("TR", "process"),
    "disclosure": ("TR", "process"),
    "explanation": ("TR", "process"),
    "xai": ("TR", "process"),
    "explainable ai": ("TR", "process"),
    "understandability": ("TR", "process"),

    # =========================================================================
    # Oversight / Governance (OVR) - Process Domain
    # =========================================================================
    "governance oversight": ("OVR", "process"),
    "oversight committee": ("OVR", "process"),
    "governance structure": ("OVR", "process"),
    "accountability": ("OVR", "process"),
    "governance": ("OVR", "process"),

    # =========================================================================
    # Organization (ORG) - Process Domain
    # =========================================================================
    "organization": ("ORG", "process"),
    "organizational strategy": ("ORG", "process"),
    "strategy": ("ORG", "process"),
    "strategic planning": ("ORG", "process"),
    "ai strategy": ("ORG", "process"),

    # =========================================================================
    # IT Systems (IT) - Process Domain
    # =========================================================================
    "it systems": ("IT", "process"),
    "data management": ("IT", "process"),
    "infrastructure": ("IT", "process"),
    "technical operations": ("IT", "process"),
    "data governance": ("IT", "process"),
    "data quality": ("IT", "process"),

    # =========================================================================
    # Stakeholder Engagement (SE) - Process Domain
    # =========================================================================
    "stakeholder engagement": ("SE", "process"),
    "stakeholder": ("SE", "process"),
    "stakeholder communication": ("SE", "process"),
    "stakeholder management": ("SE", "process"),
    "engagement": ("SE", "process"),
    "participation": ("SE", "process"),

    # =========================================================================
    # Usage Governance (UG) - Process Domain
    # =========================================================================
    "usage governance": ("UG", "process"),
    "user compliance": ("UG", "process"),
    "appropriate use": ("UG", "process"),
    "usage policy": ("UG", "process"),
    "user governance": ("UG", "process"),

    # =========================================================================
    # POLICY DOMAIN ALIASES
    # =========================================================================

    # AI Governance Policy (AGP)
    "ai governance policy": ("AGP", "policy"),
    "governance policy": ("AGP", "policy"),
    "ai governance": ("AGP", "policy"),

    # Risk Management Policy (RMP)
    "risk management policy": ("RMP", "policy"),
    "risk policy": ("RMP", "policy"),

    # Human Oversight Policy (HOP)
    "human oversight policy": ("HOP", "policy"),
    "oversight policy": ("HOP", "policy"),

    # Ethics & Fairness Policy (EFP)
    "ethics policy": ("EFP", "policy"),
    "fairness policy": ("EFP", "policy"),
    "ethics and fairness policy": ("EFP", "policy"),

    # Model Monitoring Policy (MMP)
    "model monitoring policy": ("MMP", "policy"),
    "monitoring policy": ("MMP", "policy"),
    "model management policy": ("MMP", "policy"),

    # Transparency Policy (TPP)
    "transparency policy": ("TPP", "policy"),
    "explainability policy": ("TPP", "policy"),

    # Validation Policy (VAL)
    "validation policy": ("VAL", "policy"),

    # Security & Access Policy (SAP)
    "security policy": ("SAP", "policy"),
    "access policy": ("SAP", "policy"),
    "security and access policy": ("SAP", "policy"),

    # Data Governance Policy (DGP)
    "data governance policy": ("DGP", "policy"),
    "data policy": ("DGP", "policy"),

    # Stakeholder Engagement Policy (SEP)
    "stakeholder engagement policy": ("SEP", "policy"),
    "stakeholder policy": ("SEP", "policy"),

    # Lifecycle & Training Policy (LTP)
    "lifecycle policy": ("LTP", "policy"),
    "training policy": ("LTP", "policy"),
    "lifecycle and training policy": ("LTP", "policy"),

    # Change Management Policy (CMP)
    "change management policy": ("CMP", "policy"),
    "change policy": ("CMP", "policy"),
}

# =============================================================================
# DOMAIN VOCABULARY FOR PROMPTS
# =============================================================================

DOMAIN_VOCABULARY_SHORT = """
ASHCAI DOMAINS REFERENCE
========================

POLICY DOMAINS (12 total) - Define requirements and rules:
- AGP: AI Governance Policy (overarching governance framework)
- RMP: Risk Management Policy (risk identification and mitigation)
- HOP: Human Oversight Policy (human control of AI systems)
- EFP: Ethics & Fairness Policy (ethical AI and bias prevention)
- MMP: Model Monitoring & Management Policy (model lifecycle)
- TPP: Transparency Policy (explainability and disclosure)
- VAL: Validation Policy (pre-deployment validation)
- SAP: Security & Access Policy (security and access control)
- DGP: Data Governance Policy (data management)
- SEP: Stakeholder Engagement Policy (stakeholder communication)
- LTP: Lifecycle & Training Policy (lifecycle and staff training)
- CMP: Change Management Policy (change control)

PROCESS DOMAINS (12 total) - Operationalize policies:
- PV: Problem Validation (use case selection and problem definition)
- SA: Solution Architecting (technical design and architecture)
- MON: Model Monitoring (drift detection, performance monitoring)
- RM: Risk Management (risk assessment and mitigation)
- HO: Human Oversight (human-in-the-loop, intervention)
- EF: Ethics & Fairness (bias mitigation, algorithmic fairness)
- TR: Transparency (explainability, disclosure)
- OVR: Oversight (governance structure, accountability)
- ORG: Organization (strategy, planning)
- IT: IT Systems (data management, infrastructure)
- SE: Stakeholder Engagement (communication, participation)
- UG: Usage Governance (user compliance, appropriate use)
"""

DOMAIN_VOCABULARY_FULL = f"""
{COMPANY_CONTEXT}

{FRAMEWORK_STRUCTURE}

{DOMAIN_VOCABULARY_SHORT}

ARTIFACT TYPES
==============
- POL-*-Overview: Policy domain overview summary
- POLT-*-Template: Policy template (populated via wizard or manually)
- PROC-*-Overview: Process domain overview summary
- SOP-*-##: Standard Operating Procedure (step-by-step procedures)
- WP-*-##: Work Product template (deliverable templates)
- CTRL-*: Control (evidence collection point)
- FW-*: Framework documentation
- EXC-A#-##: Exemplar Control (sample control implementations)

COMMON QUERY PATTERNS
=====================
- "What are the work products for [domain]?" → Query domain hierarchy
- "What SOPs implement [policy]?" → Structural query
- "How do we comply with [regulation]?" → Regulatory crosswalk
- "Show me [artifact-id]" → Direct artifact lookup
"""

# =============================================================================
# PROMPT SECTIONS FOR INJECTION
# =============================================================================

SYSTEM_CONTEXT_SECTION = f"""
{COMPANY_CONTEXT}

{DOMAIN_VOCABULARY_SHORT}
"""

REFINEMENT_CONTEXT_SECTION = f"""
ASHCAI FRAMEWORK CONTEXT
========================
This is the Asher Informatics Clinical AI (ASHCAI) Governance Framework.
Interpret ALL queries in this context first. Only fall back to general
AI governance if confidence is extremely low (<10%).

DOMAIN CODES:
- Policy Domains: AGP, RMP, HOP, EFP, MMP, TPP, VAL, SAP, DGP, SEP, LTP, CMP
- Process Domains: PV, SA, MON, RM, HO, EF, TR, OVR, ORG, IT, SE, UG

KEY TERM MAPPINGS:
- "problem validation" or "use case" → PV domain
- "solution architecting" → SA domain
- "model monitoring" → MON domain
- "risk management" → RM domain
- "human oversight" → HO domain
- "ethics" or "fairness" or "bias" → EF domain
- "transparency" or "explainability" → TR domain
- "work products for X" → Query domain hierarchy for X
"""


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def get_policy_domain_info(code: str) -> dict | None:
    """Get policy domain information by code."""
    return POLICY_DOMAINS.get(code.upper())


def get_process_domain_info(code: str) -> dict | None:
    """Get process domain information by code."""
    return PROCESS_DOMAINS.get(code.upper())


def resolve_domain_alias(phrase: str) -> tuple[str, str] | None:
    """
    Resolve a natural language phrase to a domain code.

    Returns:
        Tuple of (code, domain_type) or None if not found.
        domain_type is "policy" or "process"
    """
    return DOMAIN_ALIASES.get(phrase.lower())


def get_all_domain_keywords() -> set[str]:
    """Get all keywords that map to domains."""
    keywords = set()
    for domain in POLICY_DOMAINS.values():
        keywords.update(domain.get("keywords", []))
    for domain in PROCESS_DOMAINS.values():
        keywords.update(domain.get("keywords", []))
    return keywords


__all__ = [
    # Context strings
    "COMPANY_CONTEXT",
    "FRAMEWORK_STRUCTURE",
    "DOMAIN_VOCABULARY_SHORT",
    "DOMAIN_VOCABULARY_FULL",
    "SYSTEM_CONTEXT_SECTION",
    "REFINEMENT_CONTEXT_SECTION",
    # Domain definitions
    "POLICY_DOMAINS",
    "PROCESS_DOMAINS",
    "DOMAIN_ALIASES",
    # Helper functions
    "get_policy_domain_info",
    "get_process_domain_info",
    "resolve_domain_alias",
    "get_all_domain_keywords",
]
