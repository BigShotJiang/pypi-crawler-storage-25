"""
Tests for Framework Content utilities
"""
