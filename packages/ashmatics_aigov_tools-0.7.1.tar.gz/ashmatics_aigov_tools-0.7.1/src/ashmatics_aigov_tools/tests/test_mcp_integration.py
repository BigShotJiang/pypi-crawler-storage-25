"""
Integration Tests for AI Governance Framework SDK

These tests hit the actual MCP server to verify:
1. MCP client tool calls work correctly
2. Response structures match expected dataclasses
3. Graph traversals return expected data
4. Constants module resolves names correctly

Run with: uv run pytest tests/test_mcp_integration.py -v

Note: Requires MCP server running at MCP_URL (default: localhost:8088)

Created: 2026-01-25
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

import os
import pytest
import pytest_asyncio
from dotenv import load_dotenv

# Load environment
load_dotenv("ashmatics-tools.env")
load_dotenv("ai-strat-src.env")
load_dotenv(".env")


# Skip all tests if no MCP URL configured
MCP_URL = os.getenv("MCP_URL", "http://localhost:8088")
SKIP_INTEGRATION = os.getenv("SKIP_MCP_INTEGRATION_TESTS", "false").lower() == "true"


# =============================================================================
# Constants Module Tests (no network required)
# =============================================================================

class TestConstants:
    """Test the constants and resolution functions."""

    def test_resolve_policy_domain_by_code(self):
        """Test resolving policy domain by code."""
        from ashmatics_aigov_tools.services.constants import resolve_policy_domain

        assert resolve_policy_domain("RMP") == "RMP-001"
        assert resolve_policy_domain("MMP") == "MMP-001"
        assert resolve_policy_domain("AGP") == "AGP-001"

    def test_resolve_policy_domain_by_name(self):
        """Test resolving policy domain by natural language name."""
        from ashmatics_aigov_tools.services.constants import resolve_policy_domain

        assert resolve_policy_domain("risk management") == "RMP-001"
        assert resolve_policy_domain("model monitoring") == "MMP-001"
        assert resolve_policy_domain("human oversight") == "HOP-001"
        assert resolve_policy_domain("equity and fairness") == "EFP-001"

    def test_resolve_policy_domain_case_insensitive(self):
        """Test that resolution is case insensitive."""
        from ashmatics_aigov_tools.services.constants import resolve_policy_domain

        assert resolve_policy_domain("RISK MANAGEMENT") == "RMP-001"
        assert resolve_policy_domain("Risk Management") == "RMP-001"
        assert resolve_policy_domain("risk management") == "RMP-001"

    def test_resolve_policy_domain_unknown(self):
        """Test that unknown domains return None."""
        from ashmatics_aigov_tools.services.constants import resolve_policy_domain

        assert resolve_policy_domain("unknown domain") is None
        assert resolve_policy_domain("xyz") is None

    def test_resolve_regulatory_framework(self):
        """Test resolving regulatory framework IDs."""
        from ashmatics_aigov_tools.services.constants import resolve_regulatory_framework

        assert resolve_regulatory_framework("nist") == "NIST-AI-RMF"
        assert resolve_regulatory_framework("NIST-AI-RMF") == "NIST-AI-RMF"
        assert resolve_regulatory_framework("joint commission") == "JC-RUAIH"
        assert resolve_regulatory_framework("colorado") == "CO-AI-ACT"

    def test_resolve_mcp_category(self):
        """Test resolving MCP category aliases."""
        from ashmatics_aigov_tools.services.constants import resolve_mcp_category

        assert resolve_mcp_category("policies") == "policies"
        assert resolve_mcp_category("policy") == "policies"
        assert resolve_mcp_category("processes") == "processes"
        assert resolve_mcp_category("process") == "processes"
        assert resolve_mcp_category("invalid") is None

    def test_get_all_policy_domains(self):
        """Test listing all policy domains."""
        from ashmatics_aigov_tools.services.constants import get_all_policy_domains

        domains = get_all_policy_domains()
        assert len(domains) == 13  # 13 policy domains
        codes = {d["code"] for d in domains}
        assert "RMP" in codes
        assert "MMP" in codes
        assert "AGP" in codes

    def test_get_all_regulatory_frameworks(self):
        """Test listing all regulatory frameworks."""
        from ashmatics_aigov_tools.services.constants import get_all_regulatory_frameworks

        frameworks = get_all_regulatory_frameworks()
        assert len(frameworks) >= 4  # At least 4 frameworks
        ids = {f["id"] for f in frameworks}
        assert "NIST-AI-RMF" in ids
        assert "JC-RUAIH" in ids


# =============================================================================
# MCP Client Integration Tests
# =============================================================================

@pytest.mark.skipif(SKIP_INTEGRATION, reason="MCP integration tests disabled")
class TestMCPClient:
    """Integration tests for KBMCPClient."""

    @pytest_asyncio.fixture
    async def client(self):
        """Create a configured MCP client."""
        from ashmatics_aigov_tools.services.mcp_client import KBMCPClient, MCPClientConfig

        config = MCPClientConfig(
            base_url=MCP_URL,
            api_key=os.getenv("MCP_API_KEY"),
            timeout=60.0,
        )
        client = KBMCPClient(config)
        await client.connect()
        yield client
        await client.close()

    @pytest.mark.asyncio
    async def test_health_check(self, client):
        """Test MCP server health check."""
        health = await client.health_check()
        assert health.get("healthy") is True

    @pytest.mark.asyncio
    async def test_get_statistics(self, client):
        """Test fetching ASHCAI ontology statistics."""
        stats = await client.get_statistics()

        # Verify expected counts
        assert stats.get("policy_domains_count", 0) >= 12
        assert stats.get("process_domains_count", 0) >= 12
        assert stats.get("base_practices_count", 0) >= 30
        assert stats.get("sop_templates_count", 0) >= 30
        assert stats.get("regulatory_frameworks_count", 0) >= 4

    @pytest.mark.asyncio
    async def test_get_policy_hierarchy_rmp(self, client):
        """Test fetching Risk Management policy hierarchy."""
        hierarchy = await client.get_policy_hierarchy("RMP-001")

        # Verify structure
        assert hierarchy.policy_id == "RMP-001"
        assert hierarchy.policy_label == "Risk Management"
        assert len(hierarchy.process_domains) > 0

        # Verify we can extract work products
        work_products = hierarchy.get_work_products()
        assert len(work_products) > 0

        # Verify we can extract SOPs
        sops = hierarchy.get_sops()
        assert len(sops) > 0

    @pytest.mark.asyncio
    async def test_get_policy_hierarchy_mmp(self, client):
        """Test fetching Model Management policy hierarchy."""
        hierarchy = await client.get_policy_hierarchy("MMP-001")

        assert hierarchy.policy_id == "MMP-001"
        assert "Model" in hierarchy.policy_label or "Monitoring" in hierarchy.policy_label
        assert hierarchy.total_sops > 0
        assert hierarchy.total_work_products > 0

    @pytest.mark.asyncio
    async def test_get_regulatory_crosswalk_nist(self, client):
        """Test fetching NIST AI RMF crosswalk."""
        crosswalk = await client.get_regulatory_crosswalk("NIST-AI-RMF")

        assert crosswalk.framework_id == "NIST-AI-RMF"
        assert crosswalk.total_requirements > 0
        assert len(crosswalk.mappings) > 0

        # Verify mappings have expected structure
        first_mapping = crosswalk.mappings[0]
        assert "requirement_id" in first_mapping
        assert "mapped_policies" in first_mapping
        assert "mapped_controls" in first_mapping

        # Test helper methods
        policies = crosswalk.get_mapped_policies()
        assert len(policies) > 0

        controls = crosswalk.get_mapped_controls()
        assert len(controls) > 0

    @pytest.mark.asyncio
    async def test_get_regulatory_crosswalk_jc(self, client):
        """Test fetching Joint Commission crosswalk."""
        crosswalk = await client.get_regulatory_crosswalk("JC-RUAIH")

        assert crosswalk.framework_id == "JC-RUAIH"
        assert len(crosswalk.mappings) > 0

    @pytest.mark.asyncio
    async def test_semantic_search(self, client):
        """Test semantic search."""
        results = await client.semantic_search(
            query="model monitoring performance drift",
            top_k=5,
            min_score=0.5,
        )

        # Should return some results
        assert len(results) > 0

        # Results should have expected structure
        for result in results:
            assert result.artifact_id
            # Score may be 0.0 if MCP server doesn't return scores
            assert result.score >= 0.0


# =============================================================================
# AIGovQueryService Integration Tests
# =============================================================================

@pytest.mark.skipif(SKIP_INTEGRATION, reason="MCP integration tests disabled")
class TestAIGovQueryService:
    """Integration tests for the full service."""

    @pytest_asyncio.fixture
    async def service(self):
        """Create a configured query service."""
        from ashmatics_aigov_tools.services import AIGovQueryService, AIGovQueryConfig

        config = AIGovQueryConfig(
            use_mcp=True,
            mcp_url=MCP_URL,
            mcp_api_key=os.getenv("MCP_API_KEY"),
        )
        service = AIGovQueryService(config)
        await service.initialize()
        yield service
        await service.close()

    @pytest.mark.asyncio
    async def test_health_check(self, service):
        """Test service health check."""
        health = await service.health_check()
        assert health.get("backend_healthy") is True
        assert health.get("backend_type") == "mcp"

    @pytest.mark.asyncio
    async def test_search(self, service):
        """Test search without RAG synthesis."""
        result = await service.search("risk management hazard analysis")

        assert result.query == "risk management hazard analysis"
        assert len(result.results) > 0

    @pytest.mark.asyncio
    async def test_get_policy_hierarchy(self, service):
        """Test policy hierarchy via service."""
        from ashmatics_aigov_tools.services.mcp_client import PolicyHierarchy

        hierarchy = await service.get_policy_hierarchy("RMP-001")

        # Should return PolicyHierarchy object
        assert isinstance(hierarchy, PolicyHierarchy)
        assert hierarchy.policy_id == "RMP-001"
        assert len(hierarchy.get_work_products()) > 0

    @pytest.mark.asyncio
    async def test_get_regulatory_crosswalk(self, service):
        """Test regulatory crosswalk via service."""
        from ashmatics_aigov_tools.services.mcp_client import RegulatoryMapping

        crosswalk = await service.get_regulatory_crosswalk("NIST-AI-RMF")

        # Should return RegulatoryMapping object
        assert isinstance(crosswalk, RegulatoryMapping)
        assert crosswalk.framework_id == "NIST-AI-RMF"
        assert len(crosswalk.mappings) > 0


# =============================================================================
# Query Scenarios (verifying specific queries work)
# =============================================================================

@pytest.mark.skipif(SKIP_INTEGRATION, reason="MCP integration tests disabled")
class TestQueryScenarios:
    """Test specific query scenarios to verify routing and results."""

    @pytest_asyncio.fixture
    async def service(self):
        """Create a configured query service."""
        from ashmatics_aigov_tools.services import AIGovQueryService, AIGovQueryConfig

        config = AIGovQueryConfig(
            use_mcp=True,
            mcp_url=MCP_URL,
            mcp_api_key=os.getenv("MCP_API_KEY"),
        )
        service = AIGovQueryService(config)
        await service.initialize()
        yield service
        await service.close()

    @pytest.mark.asyncio
    async def test_query_work_products_for_domain(self, service):
        """
        Test: 'What work products does Risk Management produce?'

        This should be answerable via graph traversal, not semantic search.
        """
        hierarchy = await service.get_policy_hierarchy("RMP-001")
        work_products = hierarchy.get_work_products()

        # Should find RM work products
        wp_ids = {wp.get("entity_id") for wp in work_products}
        assert any("RM" in wp_id for wp_id in wp_ids)

    @pytest.mark.asyncio
    async def test_query_nist_compliance(self, service):
        """
        Test: 'How does ASHCAI address NIST AI RMF GOVERN function?'

        Should return requirements from GOVERN category with mappings.
        """
        crosswalk = await service.get_regulatory_crosswalk("NIST-AI-RMF")

        # Find GOVERN requirements
        govern_reqs = [
            m for m in crosswalk.mappings
            if "GOVERN" in m.get("requirement_id", "")
        ]

        assert len(govern_reqs) > 0
        # Each GOVERN requirement should have mapped policies
        for req in govern_reqs:
            assert len(req.get("mapped_policies", [])) > 0

    @pytest.mark.asyncio
    async def test_query_sops_for_monitoring(self, service):
        """
        Test: 'What SOPs are involved in model monitoring?'

        Should find MON-prefixed SOPs via hierarchy.
        """
        # MMP (Model Management Policy) covers monitoring
        hierarchy = await service.get_policy_hierarchy("MMP-001")
        sops = hierarchy.get_sops()

        # Should find MON SOPs
        sop_ids = {sop.get("entity_id") for sop in sops}
        mon_sops = {s for s in sop_ids if "MON" in s}
        assert len(mon_sops) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
