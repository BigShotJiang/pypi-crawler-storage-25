# Copyright (c) 2025-2026, Asher Informatics PBC
"""
Framework Content management utilities for Ashmatics Knowledge Base.

This module provides tools for uploading and managing the Ashmatics Clinical AI
Governance Framework source content to Azure Container Storage and the Knowledge Base.

Content includes:
- Process domains (JSON definitions, base practices)
- Policy templates and token systems
- Work products and process documentation
- Traceability mappings and ISO 42001 controls
- Process-policy integration bindings
- ASHCAI ontology management and regulatory crosswalks

All content is versioned and tracked for lifecycle management.

CLI Tools:
- cai-framework-manager: Framework content management
- cai-extract-relationships: Extract AI Gov relationships for graph service
- cai-query: RAG-powered Q&A for governance framework
- cai-init-ontology: Initialize ASHCAI ontology in MongoDB
- cai-sync-regulatory: Sync regulatory crosswalks from YAML
"""

__version__ = "0.7.1"
__author__ = "Ashmatics Team"

from .importers.framework_content import FrameworkContentImporter
from .processors.azure_uploader import FrameworkContentUploader
from .processors.content_validator import FrameworkContentValidator
from .processors.regulatory_yaml_parser import (
    RegulatoryFramework,
    RegulatoryRequirement,
    RegulatoryYAMLParser,
    find_yaml_directory,
    parse_all_regulatory_frameworks,
)
from .artifact_slug_mapping import (
    get_artifact_slug,
    generate_artifact_slug,
    validate_slug,
    PREFIXES,
    POLICY_DOMAIN_CODES,
    PROCESS_DOMAIN_CODES,
)

__all__ = [
    "FrameworkContentImporter",
    "FrameworkContentUploader",
    "FrameworkContentValidator",
    # Regulatory YAML Parser
    "RegulatoryYAMLParser",
    "RegulatoryFramework",
    "RegulatoryRequirement",
    "find_yaml_directory",
    "parse_all_regulatory_frameworks",
    # Slug mapping utilities
    "get_artifact_slug",
    "generate_artifact_slug",
    "validate_slug",
    "PREFIXES",
    "POLICY_DOMAIN_CODES",
    "PROCESS_DOMAIN_CODES",
]
