# Copyright 2025 JF Kalafut
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     https://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

content_record = {
                        "framework_version": manifest["framework_version"],
                        "content_category": category,
                        "relative_path": file_info["relative_path"],
                        "blob_path": file_info["blob_path"],
                        "blob_url": file_info["blob_url"],
                        "file_hash": file_info["file_hash"],
                        "file_size": file_info["file_size"],
                        "content_type": file_info["content_type"],
                        "artifact_id": artifact_id,  # KEY: Add artifact_id for cross-database mapping
                        # NEW: Add domain information for enhanced API filtering
                        "domain_type": domain_info["domain_type"],
                        "domain_code": domain_info["domain_code"],
                        "domain_name": domain_info["domain_name"],
                        "control_type": domain_info["control_type"],
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat(),
                    }

domain_info = {
            "domain_type": None,     # "process", "policy", "controls", "governance"
            "domain_code": None,     # 2-letter code for process domains
            "domain_name": None,     # descriptive name for policy domains
            "control_type": None,    # for controls: "base", "iso_mapping", "tools_registry"
        }

"""domain_type: "process", "policy", "controls", "governance"
            domain_code: 2-letter code for process domains, "YY" for policy domains - TODO [ASHPSTUDIO-169]; make a policy domain ENUM, "XX" for unknown/misc.
            domain_name: string following the the domain_code for process domain documents "EF_Ethics_and_Fairness_Assessment", for policy domains the descriptive name following the string "pol",
                         for governance domain_type we have: "master_registry", "framework_document", "configuration"
            control_type: for controls: "base_mapping", "iso_mapping", "tools_registry","general","tools_registry"
"""
domain_info_schema = {
    "schema": {
                "domain_type": {
                    "type": "string",
                    "enum": ["process", "policy", "controls", "governance"],
                    "description": "Type of domain classification"
                },
                "domain_code": {
                    "type": "string", 
                    "description": "2-letter code for process domains, 'YY' for policy domains - TODO [ASHPSTUDIO-169]; make a policy domain ENUM, 'XX' for unknown/misc."
                },
                "domain_name": {
                    "type": "string",
                    "description": "EF_Ethics_and_Fairness_Assessment', for policy domains the descriptive name following the string 'pol', for governance domain_type we have: 'master_registry', 'framework_document', 'configuration'"
                },
                "control_type": {
                    "type": "string",
                    "enum": ["base_mapping", "iso_mapping", "tools_registry", "general"],
                    "description": "For controls domain type"
                }
            }
}


content_patterns = [
                "domains/*.json",
                "policy-logic/*.json",
                "ash-gov-process-model/**/*.md",
                "ash-gov-process-model/**/*.json",
                "process-domain-registry.json",
                # Core framework directories
                "policy-domain/**/*",  # Policy domain content
                "process-domain/**/*",  # Process domain content
                "controls/**/*",  # Controls content
                "ISO-42001-maps/**/*",  # ISO 42001 mapping content
                "tools/**/*",  # Include ALL files in tools directory and subdirectories
                "Makefile",
                "CLAUDE.md",
                # Root-level framework documentation files
                "Framework-Overview-Summary.md",  # Fixed: actual filename
                "Implementation-Reference-Guide.md",
                "Policy-Domain-Architecture.md",
                "Process-Domain-Architecture.md",
                "value-proposition-polproc.md",
                # Additional patterns for completeness
                "reviews-audits/**/*",
                "supporting-framework-docs/**/*",
                "clinical-ai-governance-stakeholder-roles.json",
                "master-registry.json",
            ]