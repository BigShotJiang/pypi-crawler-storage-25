#!/usr/bin/env python3
"""
Copyright 2025 Asher Informatics PBC,

last updated: 2025-09-25 by JF Kalafut
- changes made so that the compilation matches our aigov framework schema and 4-tier categorization system;


Framework Content Importer

Main orchestrator for uploading Ashmatics Clinical AI Governance Framework
content to Azure Container Storage and registering with the Knowledge Base.

Last Updated: 2025-09-21
- refactored to add domain_type, domain_code, domain_name, control_type to each file record

"""

import hashlib
import json
import logging

# Import parent utilities
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

# Governance enums from canonical datamodels (ASHKBAPP-47)
from ashmatics_datamodels.documents import ProcessDomainCode
from ashmatics_tools.utils.import_utils import KBImporter

from ashmatics_aigov_tools.config.content_patterns import (
    filter_file_list,
    get_default_content_patterns,
)
from ashmatics_aigov_tools.processors.azure_uploader import FrameworkContentUploader
from ashmatics_aigov_tools.processors.content_validator import FrameworkContentValidator
from ashmatics_aigov_tools.processors.mongo_compiler import FrameworkContentCompiler
from ashmatics_aigov_tools.artifact_slug_mapping import get_artifact_slug

logger = logging.getLogger(__name__)

# Mapping from ProcessDomainCode to descriptive names
# This provides human-readable names for each process domain code
PROCESS_DOMAIN_NAMES: dict[ProcessDomainCode, str] = {
    ProcessDomainCode.PV: "Problem & Value Quantification",
    ProcessDomainCode.SA: "Solution Architecting & Local Validation",
    ProcessDomainCode.MON: "Monitoring & Lifecycle Management",
    ProcessDomainCode.OVR: "Oversight & Steering",
    ProcessDomainCode.ORG: "Organization & Strategy Alignment",
    ProcessDomainCode.IT: "IT Systems & Data Management",
    ProcessDomainCode.RM: "Clinical AI Risk Management",
    ProcessDomainCode.HO: "Human Oversight & AI Interaction",
    ProcessDomainCode.EF: "AI Ethics & Fairness Assessment",
    ProcessDomainCode.TR: "AI Transparency & Explainability",
    ProcessDomainCode.UG: "AI Usage Governance & User Compliance",
    ProcessDomainCode.XX: "Not Applicable / Unknown",
    ProcessDomainCode.YY: "Other / Miscellaneous",
}


class FrameworkContentImporter:
    """
    Main class for importing framework content to Azure and Knowledge Base.

    Orchestrates:
    1. Content validation
    2. Azure blob upload with versioning
    3. KB path registration -POSTGRESQL!!!
    4. MongoDB compilation (optional)
    5. Version tracking
    """

    def __init__(
        self,
        framework_repo_path: str,
        azure_connection_string: str,
        kb_table_name: str      = "framework_content_registry",
        container_name: str     = "framework-content",
        version: str | None  = None,
        mongo_connection_string: str | None = None,
        mongo_database: str     = "ashmatics_kb",
        mongo_collection: str   = "framework_compiled_views",
        force_adls_gen2: bool | None = None,
        **kb_config,
    ):
        """
        Initialize framework content importer.

        Args:
            framework_repo_path: Path to framework repository
            azure_connection_string: Azure Storage connection string
            kb_table_name: KB table for content registry
            container_name: Azure container name
            version: Framework version (auto-detected if None)
            mongo_connection_string: MongoDB connection string (optional)
            mongo_database: MongoDB database name for compiled views
            mongo_collection: MongoDB collection name for compiled views
            **kb_config: Additional KB importer configuration
        """
        self.framework_path          = Path(framework_repo_path)
        self.kb_table_name           = kb_table_name
        self.version                 = version
        self.mongo_connection_string = mongo_connection_string

        # Initialize components
        self.validator = FrameworkContentValidator(framework_repo_path)
        self.uploader = FrameworkContentUploader(
            azure_connection_string, container_name, version, force_adls_gen2
        )
        self.kb_importer = KBImporter(kb_table_name, **kb_config)

        # Initialize MongoDB compiler if connection string provided
        self.mongo_compiler = None
        if mongo_connection_string:
            self.mongo_compiler = FrameworkContentCompiler(
                mongo_connection_string, mongo_database, mongo_collection
            )

        # Results storage
        self.import_results = {}

        logger.info(
            f"Initialized FrameworkContentImporter for version {self.uploader.version}"
        )

    def import_all(
        self,
        validate_first: bool = True,
        content_patterns: list[str] | None = None,
        dry_run: bool = False,
        hybrid_mode: bool = True,
    ) -> tuple[bool, dict[str, Any]]:
        """
        Complete import process: validate, upload, and register.

        Args:
            validate_first: Whether to validate before upload
            content_patterns: File patterns to include in upload
            dry_run: If True, validate and plan but don't upload
            hybrid_mode: If True, register with both PostgreSQL and MongoDB

        Returns:
            Tuple of (success, detailed_results)
        """
        logger.info("🚀 Starting complete framework content import")

        results = {
            "import_timestamp": datetime.now().isoformat(),
            "framework_version": self.uploader.version,
            "framework_path": str(self.framework_path),
            "dry_run": dry_run,
            "steps": {},
        }

        try:
            # Step 1: Validation
            if validate_first:
                logger.info("📋 Step 1: Validating framework content")
                valid, validation_results       = self.validator.validate_all()
                results["steps"]["validation"]  = validation_results

                if not valid:
                    logger.error("❌ Validation failed - aborting import")
                    results["success"] = False
                    results["error"] = "Framework validation failed"
                    return False, results

                logger.info("✅ Validation passed")

            # Step 2: Azure Upload
            if not dry_run:
                logger.info("☁️ Step 2: Uploading to Azure Container Storage")

                # Ensure container exists
                if not self.uploader.ensure_container_exists():
                    raise Exception("Failed to ensure Azure container exists")

                success_count, fail_count, upload_results = (
                    self.uploader.upload_framework_content(
                        self.framework_path, content_patterns
                    )
                )

                results["steps"]["azure_upload"] = upload_results

                if fail_count > 0:
                    logger.warning(
                        f"⚠️ Some files failed to upload: {fail_count} failures"
                    )

                if success_count == 0:
                    logger.error("❌ No files uploaded successfully")
                    results["success"] = False
                    results["error"] = "Azure upload failed completely"
                    return False, results

                logger.info(
                    f"✅ Azure upload completed: {success_count} files uploaded"
                )

                # Step 3: Create upload manifest - TODO [ASHPSTUDIO-168] add more robust exception handling for edge case catching
                logger.info("📄 Step 3: Creating upload manifest")
                manifest                     = self.uploader.create_upload_manifest()
                results["steps"]["manifest"] = manifest

                # Step 4: Register with Knowledge Base (PostgreSQL)
                logger.info("🗃️ Step 4: Registering with Knowledge Base (PostgreSQL)")
                kb_success, kb_results              = self._register_with_kb(manifest)
                results["steps"]["kb_registration"] = kb_results

                if not kb_success:
                    logger.warning("⚠️ KB registration had issues but upload succeeded")
                    results["partial_success"] = True
                else:
                    logger.info("✅ PostgreSQL registration completed")

                # Step 5: MongoDB Compilation (if hybrid mode enabled)
                if hybrid_mode and self.mongo_compiler:
                    logger.info("🔧 Step 5: Compiling and storing MongoDB views")
                    mongodb_success, mongodb_results = self.compile_and_store_mongo_views(
                        force_refresh=False,
                        verify_azure_content=False,  # Already verified
                    )
                    results["steps"]["mongodb_compilation"] = mongodb_results

                    if mongodb_success:
                        logger.info("✅ MongoDB compilation completed")
                    else:
                        logger.warning("⚠️ MongoDB compilation had issues but upload succeeded")
                        results["partial_success"] = True
                elif hybrid_mode and not self.mongo_compiler:
                    logger.warning("⚠️ Hybrid mode requested but MongoDB compiler not configured")
                elif not hybrid_mode:
                    logger.info("📝 Hybrid mode disabled - skipping MongoDB compilation")

            else:
                logger.info("🔍 Dry run - skipping upload and registration")
                results["steps"]["dry_run_note"] = (
                    "Upload and registration skipped in dry run mode"
                )

            # Final success
            results["success"] = True
            logger.info("🎉 Framework content import completed successfully")

            self.import_results = results
            return True, results

        except Exception as e:
            logger.error(f"💥 Import failed with error: {str(e)}")
            results["success"] = False
            results["error"] = str(e)
            results["exception_type"] = type(e).__name__
            return False, results

    def _register_with_kb(
        self, manifest: dict[str, Any]
    ) -> tuple[bool, dict[str, Any]]:
        """
        Register framework content with Knowledge Base -> updates the postgreSQL


        Args:
            manifest: Upload manifest from Azure uploader

        Returns:
            Tuple of (success, registration_results)
        """
        try:
            # Create KB record for this framework version
            kb_record = {
                "framework_version": manifest["framework_version"],
                "upload_timestamp": manifest["upload_timestamp"],
                "container_name": manifest["container_name"],
                "total_files": manifest["total_files"],
                "content_map": json.dumps(
                    manifest["content_map"]
                ),  # Store as JSON string
                "status": "active",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
            }

            # Add individual content records for searchability
            content_records = []
            for category, files in manifest["content_map"].items():
                for file_info in files:
                    # Generate consistent artifact_id for cross-database mapping
                    artifact_id = self._generate_artifact_id(
                        file_info["relative_path"], category
                    )

                    # Extract domain information for enhanced filtering! TThis was updated 9/21/25 to match our new strategy for naming the aigov framework content JFK
                    domain_info = self._extract_domain_info(Path(file_info["relative_path"]))

                    content_record = {
                        "framework_version": manifest["framework_version"],

                        # Schema-compliant categorization (4-tier system)
                        "content_category": domain_info["content_category"],  # Primary category (Tier 1)
                        "subcategory": domain_info["subcategory"],           # Detailed subcategory (Tier 2)
                        "subcategory_label": domain_info["subcategory_label"], # API-friendly label for filtering
                        "process_domain": domain_info["process_domain"],     # Process domain code (Tier 3)
                        "content_format": domain_info["content_format"],     # File format

                        # File metadata
                        "relative_path": file_info["relative_path"],
                        "blob_path": file_info["blob_path"],
                        "blob_url": file_info["blob_url"],
                        "file_hash": file_info["file_hash"],
                        "file_size": file_info["file_size"],
                        "content_type": file_info["content_type"],
                        "artifact_id": artifact_id,  # KEY: Add artifact_id for cross-database mapping

                        # Domain classification (existing fields - keep these)
                        "domain_type": domain_info["domain_type"],
                        "domain_code": domain_info["domain_code"],
                        "domain_name": domain_info["domain_name"],
                        "control_type": domain_info["control_type"],
                        "is_template": domain_info["is_template"],

                        # Timestamps
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat(),
                    }
                    content_records.append(content_record)

            # Insert main registry record
            main_success, main_message = self.kb_importer.insert_record_graphql(
                kb_record
            )

            # Insert content records using batch approach
            if content_records:
                # Create separate importer for individual content records
                content_table_name = f"{self.kb_table_name}_files"
                content_importer = KBImporter(
                    content_table_name,
                    self.kb_importer.graphql_endpoint,
                    admin_secret=self.kb_importer.admin_secret,
                    verify_ssl=self.kb_importer.verify_ssl,
                )

                success_count, fail_count = content_importer.insert_records_graphql(
                    content_records
                )

                results = {
                    "main_record": {"success": main_success, "message": main_message},
                    "content_records": {
                        "total": len(content_records),
                        "successful": success_count,
                        "failed": fail_count,
                    },
                }

                overall_success = main_success and (fail_count == 0)
                return overall_success, results
            else:
                return main_success, {
                    "main_record": {"success": main_success, "message": main_message},
                    "content_records": {"total": 0, "successful": 0, "failed": 0},
                }

        except Exception as e:
            logger.error(f"Error registering with KB: {str(e)}")
            return False, {"error": str(e)}

    def get_current_version_info(self) -> dict[str, Any] | None:
        """
        Get information about the current framework version.

        Returns:
            Version info dictionary or None if not available
        """
        version = self.validator.get_framework_version()
        if not version:
            return None

        return {
            "version": version,
            "framework_path": str(self.framework_path),
            "detected_timestamp": datetime.now().isoformat(),
        }

    def list_content_files(
        self, content_patterns: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """
        Updated: 2025-09-21 by JF Kalafut

        List all framework content files that would be uploaded based on the files in the source data path passed into the class.

        Args:
            content_patterns: File patterns to include

        Returns:
            List of file information dictionaries
        """
        # Use centralized content patterns configuration
        if content_patterns is None:
            content_patterns = get_default_content_patterns()

        file_list = []
        all_files = []

        for pattern in content_patterns:
            matching_files = list(self.framework_path.glob(pattern))
            all_files.extend(matching_files)

        # Remove duplicates and sort
        all_files = sorted(set(all_files))

        # Filter out excluded system files
        all_files = filter_file_list(all_files)

        for file_path in all_files:
            if not file_path.is_file():
                continue

            try:
                relative_path = file_path.relative_to(self.framework_path)
                category = self._categorize_file(relative_path)
                domain_info = self._extract_domain_info(relative_path)

                file_info = {
                    "relative_path": str(relative_path),
                    "full_path": str(file_path),
                    "size_bytes": file_path.stat().st_size,
                    "modified": datetime.fromtimestamp(
                        file_path.stat().st_mtime
                    ).isoformat(),
                    "file_type": file_path.suffix,

                    # Schema-compliant categorization
                    "category": category,  # Keep legacy field for backward compatibility
                    "content_category": domain_info["content_category"],  # Primary category (Tier 1)
                    "subcategory": domain_info["subcategory"],           # Detailed subcategory (Tier 2)
                    "process_domain": domain_info["process_domain"],     # Process domain code (Tier 3)
                    "content_format": domain_info["content_format"],     # File format

                    # Domain classification (existing fields)
                    "domain_type": domain_info["domain_type"],
                    "domain_code": domain_info["domain_code"],
                    "domain_name": domain_info["domain_name"],
                    "control_type": domain_info["control_type"],
                }
                file_list.append(file_info)
            except Exception as e:
                logger.warning(f"Error processing file {file_path}: {str(e)}")

        return file_list

    def _categorize_file(self, relative_path: Path) -> tuple[Optional[bool], str]:
        """
        NOTE!!!! John Really needs TODO [ASHPSTUDIO-167] Reconcile our AiGov Framework uploader with content


        Categorize files using 4-tier template composition taxonomy:
        1. CAI Governance Level - Framework docs and master files
        2. Policy Domain - Policy templates, overviews, and glue files
        3. Process Domain - SOPs, WPs, Wizard Guides, base docs, working files
        4. Controls - Tool registry and control frameworks
        """
        path_parts = relative_path.parts
        filename   = relative_path.name

        # ========================================
        # SPECIAL CATEGORY: WIZARD GUIDES (Cross-Domain)
        # ========================================
        # Wizard-Design files can be in either process or policy domains
        # but should be categorized as wizard_guides with domain context
        # Include both .md and .json wizard files
        if (('Wizard-Design' in filename or 'WizardDesign' in filename or 'Wizard-Guide' in filename)
            and (filename.endswith('.md') or filename.endswith('.json'))):
            if path_parts[0] == "policy-domain":
                return [True, "wizard_guides_policy_domain"]
            elif path_parts[0] == "ash-gov-process-model":
                return [True, "wizard_guides_process_domain"]
            else:
                return [True, "wizard_guides_misc"]

        # ========================================
        # TIER 1: CAI GOVERNANCE LEVEL
        # ========================================

        # Master registry and framework working files
        if filename in ["master-registry.json", "process-domain-registry.json"]:
            return [True, "cai_governance_master_registry"]

        # Root-level framework documentation (about/descriptions)
        if len(path_parts) == 1 and filename.endswith('.md'):
            if filename in [
                "Framework-Overview-Summary.md",  # Fixed: actual filename
                "value-proposition-polproc.md"
                # Removed: "The AshMatics Clinical AI Governance Framework_generalist.md" - not appropriate for CAI
            ]:
                return [False, "cai_governance_overview"]
            elif filename in ["Implementation-Reference-Guide.md"]:
                return [False, "cai_governance_implementation_guide"]
            elif filename in [
                "Policy-Domain-Architecture.md",
                "Process-Domain-Architecture.md"
            ]:
                return [False, "cai_governance_architecture"]

            else:
                return [False, "cai_governance_misc"]

        # Root-level JSON files (stakeholder roles, etc.)
        elif len(path_parts) == 1 and filename.endswith('.json'):
            return [False, "cai_governance_configuration"]

        # ========================================
        # TIER 2: POLICY DOMAIN ARTIFACTS
        # ========================================

        if path_parts[0] == "policy-domain":
            # Policy overview content for display
            if filename.endswith('-Domain-Overview-Summary.md'):
                return [False, "policy_domain_overview_content"]

            # Policy template primitives (JSON definitions)
            elif filename.endswith('Policy.json'):
                return [True, "policy_domain_template_primitives"]

            # Policy glue files (tokens, bindings)
            elif ('token' in filename.lower() or 'binding' in filename.lower() or
                  filename in ['tokenIndex.json', 'tokenMapByArtifact.json']):
                return [True, "policy_domain_glue_files"]

            # Temporary policy files
            elif filename.startswith('ash-') and filename.endswith('-policy-TEMP.md'):
                return [True, "policy_domain_temp_policies"]

            # Other policy domain content
            else:
                return [False, "policy_domain_misc"]

        # ========================================
        # TIER 3: PROCESS DOMAIN (ash-gov-process-model + process-domain)
        # ========================================

        # Process domain overview materials (from process-domain folder)
        if path_parts[0] == "process-domain":
            if filename.endswith('-Overview-Summary.md'):
                return [False, "process_domain_overview_content"]
            elif filename.endswith('.json'):
                return [False, "process_domain_definitions"]
            else:
                return [False, "process_domain_misc"]

        # Deep content from ash-gov-process-model
        if path_parts[0] == "ash-gov-process-model":
            # Base documents (AshmaticsAIGov-Area-*.md)
            if filename.startswith('AshmaticsAIGov-Area'):
                return [True, "process_domain_base_documents"]

            # Standard Operating Procedures
            elif filename.startswith('SOP-'):
                return [True, "process_domain_sop"]

            # Work Products
            elif filename.startswith('WP-'):
                return [True, "process_domain_work_products"]

            # Wizard Guides (WP files with WizardDesign in the name)
            elif filename.startswith('WP-') and ('Wizard-Design' in filename or 'WizardDesign' in filename):
                return [False, "process_domain_wizard_guides"]

            # Working files - traceability
            elif filename.endswith('traceability.json'):
                return [False, "process_domain_traceability"]

            # Working files - policy binding matrices
            elif 'Policy-Binding-Matrix' in filename:
                return [False, "process_domain_policy_bindings"]

            # Working files - decision logs
            elif (filename.endswith('Decision-Log.md') or '_Log.md' in filename):
                return [True, "process_domain_logs"]

            # Other process documentation
            else:
                return [False, "process_domain_documentation"]

        # ========================================
        # TIER 4: CONTROLS & TOOLS REGISTRY
        # ========================================

        # Controls framework
        if path_parts[0] == "controls":
            return [False, "controls_framework"]

        # ISO mappings
        elif path_parts[0] == "ISO-42001-maps":
            return [False, "controls_iso_mappings"]

        # Tools registry (will become org-specific)
        elif path_parts[0] == "tools":
            if filename.lower() in ["tooling_registry.yaml", "tools_registry.yaml", "registry.yaml"]:
                return [True, "controls_tools_registry"]
            else:
                return [False, "controls_tools_content"]

        # Architecture design materials
        elif path_parts[0] == "architecture-design":
            return [False, "controls_architecture_design"]

        # Reviews and audits
        elif path_parts[0] == "reviews-audits":
            return [True, "controls_reviews_audits"]

        # Supporting framework docs
        elif path_parts[0] == "supporting-framework-docs":
            return [True, "controls_supporting_docs"]

        # Catch-all
        return [False, "framework_misc"]

    def _extract_domain_info(self, relative_path: Path) -> dict[str, str | None]:
        """
        Extract comprehensive domain information from path/filename for all schema tiers.

        Updated 2025-09-25 by JF Kalafut to align with Pydantic schema requirements.

        CRITICAL: This method ensures field consistency between:
        - Azure Blob Storage metadata
        - PostgreSQL framework_content_registry_files table
        - MongoDB compiled content documents
        - Pydantic API schema definitions (ai_gov_framework_schema.py)
        - Strawberry GraphQL types (ai_gov_framework_types.py)

        Returns:
            Dictionary with all required schema fields:

            Schema-compliant categorization (4-tier system):
            - content_category: Primary content category (Tier 1) - maps to PrimaryCategoryType
            - subcategory: Detailed subcategory (Tier 2) - maps to SubcategoryType
            - process_domain: 2-3 letter process domain code (Tier 3) - maps to ProcessDomainCode
            - content_format: File format (markdown, json, yaml, etc.)

            Domain classification (existing fields - preserved for backward compatibility):
            - domain_type: "process", "policy", "controls", "governance" - maps to DomainType
            - domain_code: 2-letter code for process domains, "YY" for policy domains, "XX" for unknown/misc
            - domain_name: Descriptive name (process enum values, policy names, governance types)
            - control_type: For controls: "base_mapping", "iso_mapping", "tools_registry", "general"

            Here is the hierarchy of the categorization:
            domain_type
                -> content_category
                    -> subcategory -> subcategory_label
                -> domain_code
                    -> process_domain (label for WP, SOP, etc.)
        """
        path_parts = relative_path.parts
        filename   = relative_path.name

        # Initialize with all schema fields
        domain_info = {
            # New schema fields (4-tier categorization)
            "content_category": None,    # Primary category (Tier 1) - will be set by _categorize_file
            "subcategory": None,         # Detailed subcategory (Tier 2)
            "subcategory_label": None,   # API-friendly label for filtering
            "process_domain": None,      # Process domain code (Tier 3)
            "content_format": None,      # File format
            "is_template": False,        # Whether the file is a template (e.g., contains placeholders)

            # Existing domain classification fields (keep these)
            "domain_type": None,         # "process", "policy", "controls", "governance"
            "domain_code": None,         # 2-letter code for process domains
            "domain_name": None,         # descriptive name for domains
            "control_type": None,        # for controls: "base_mapping", "iso_mapping", "tools_registry"
        }

        # Determine content format based on file extension
        if filename.endswith('.md'):
            domain_info["content_format"] = "markdown"
        elif filename.endswith('.json'):
            domain_info["content_format"] = "json"
        elif filename.endswith(('.yaml', '.yml')):
            domain_info["content_format"] = "yaml"
        elif filename.endswith('.py'):
            domain_info["content_format"] = "python"
        else:
            domain_info["content_format"] = "other"

        # ========================================
        # SPECIAL HANDLING: WIZARD GUIDES DOMAIN EXTRACTION
        # ========================================
        # Extract domain information for wizard files (both .md and .json)
        if (('Wizard-Design' in filename or 'WizardDesign' in filename or 'Wizard-Guide' in filename)
            and (filename.endswith('.md') or filename.endswith('.json'))):
            if path_parts[0] == "policy-domain":
                domain_info["domain_type"] = "policy"
                # For policy domain wizard files like "policy_domain-Wizard-Guide.md" or "policy_domain-Wizard-Design.json"
                if filename.startswith('policy_domain'):
                    domain_info["domain_code"] = "POL"  # Generic policy domain code
                else:
                    domain_info["domain_code"] = "POL"
            elif path_parts[0] == "ash-gov-process-model":
                domain_info["domain_type"] = "process"
                # Extract from patterns like "PV-Wizard-Design.md" or "PV-WizardDesign.json"
                if '-' in filename:
                    potential_code = filename.split('-')[0]
                    if len(potential_code) <= 3 and potential_code.isupper():
                        domain_info["domain_code"] = potential_code
                    else:
                        domain_info["domain_code"] = "XX"  # Unknown code
                else:
                    domain_info["domain_code"] = "XX"

        # ========================================
        # PROCESS DOMAINS (2 or 3 -letter codes)
        # ========================================
        if len(path_parts) > 1 and path_parts[0] == "ash-gov-process-model":
            #then we are in the Process Reference Model content. This will be the process documents, SOPs, WPS, and will  have subfolders for each of the process domains (eg: RM_02_Risk_Management)
            domain_info["domain_type"] = "process"
            folder_name = path_parts[1]

            # Extract from folder patterns like "EF-09-AI_Ethics_Fairness_Assessment"
            # The folder names use hyphens for CODE-NUM, then underscores for the description
            # Pattern: {CODE}-{NUM}-{Description_With_Underscores}
            if '-' in folder_name:
                # Split by hyphen first to extract the code (e.g., "EF" from "EF-09-AI_Ethics...")
                hyphen_parts = folder_name.split('-')
                potential_code = hyphen_parts[0]
                if len(potential_code) <= 3 and potential_code.isupper():  # Allow 2-3 letter codes
                    domain_info["domain_code"]    = potential_code
                    domain_info["process_domain"] = potential_code
                    # Extract domain name from the description part (after CODE-NUM-)
                    # Join remaining parts and replace underscores with spaces
                    if len(hyphen_parts) > 2:
                        name_part = '-'.join(hyphen_parts[2:])  # e.g., "AI_Ethics_Fairness_Assessment"
                        domain_info["domain_name"] = name_part.replace('_', ' ')

            if filename.startswith(('SOP-', 'WP-')):
                # Extract from patterns like "SOP-OVR-03-Performance-Monitoring-Stakeholder-Communication"
                # or "WP-OVR-02-Governance-Review-Report"
                parts = filename.split('-')
                #we want to extract the whole label SOP-OVR-03 and also save this to the KB table, using the process_domain field, because the domain_code field is already populated with OVR for example
                domain_info["process_domain"] = '-'.join(parts[0:3])

            # Extract from filename patterns in ash-gov-process-model
            #NOTE _ NOT hitting this condition really ever.. unless there is a file that is in the root
            elif filename.startswith(('SOP-', 'WP-', 'AshmaticsAIGov-Area')) or 'traceability' in filename or 'Policy-Binding' in filename:
                # Try to extract from filename patterns
                if filename.startswith(('SOP-', 'WP-')) and len(filename.split('-')) >= 4:
                    # Extract from patterns like "SOP-OVR-03-Performance-Monitoring-Stakeholder-Communication"
                    parts = filename.split('-')
                    potential_code = parts[1]
                    if len(potential_code) <= 3 and potential_code.isupper():
                        domain_info["domain_code"]    = potential_code
                        domain_info["process_domain"] = potential_code
                        #we also want to extract the whole label SOP-OVR-03 and also save this to the KB table, using the process_domain field, because the domain_code field is already populated with OVR for example
                        domain_info["process_domain"] = '-'.join(parts[0:3])  #

                        # Extract domain name from parts after the number (position 3 onwards)
                        if len(parts) > 3:
                            name_parts = parts[3:]
                            # Remove file extension from the last part
                            if name_parts[-1].endswith('.md'):
                                name_parts[-1] = name_parts[-1][:-3]
                            elif name_parts[-1].endswith('.json'):
                                name_parts[-1] = name_parts[-1][:-5]

                            domain_info["domain_name"] = ' '.join(name_parts)



                elif 'AshmaticsAIGov-Area' in filename:
                    # Extract from patterns like "AshmaticsAIGov-Area5-ORG.md"
                    parts = filename.split('-')
                    if len(parts) >= 3:
                        potential_code = parts[-1].replace('.md', '')
                        if len(potential_code) <= 3 and potential_code.isupper():
                            domain_info["domain_code"] = potential_code
                    # this artifact will be what is used as the basis for the process document in the customer's framework, so we consider this as a template. This is opposed to the summary of the process domain that
                    # is used in rendering the CAI to users in the frontend


                elif filename.endswith('traceability.json'):
                    # Extract from patterns like "ORG-traceability.json"
                    potential_code = filename.split('-')[0]
                    if len(potential_code) <= 3 and potential_code.isupper():
                        domain_info["domain_code"] = potential_code
                else:
                    domain_info["domain_code"] = "XX"  # Unknown code


        elif path_parts[0] == "process-domain":
            domain_info["domain_type"] = "process"
            # Extract domain code from filename patterns like "ef-process-domain.json" or "EF-Domain-Overview-Summary.md"
            if filename.endswith('-process-domain.json'):
                potential_code = filename.replace('-process-domain.json', '').upper()
                if len(potential_code) <= 3:
                    domain_info["domain_code"]    = potential_code
                    domain_info["process_domain"] = potential_code
            elif filename.endswith('-Domain-Overview-Summary.md'):
                potential_code = filename.split('-')[0].upper()
                if len(potential_code) <= 3:
                    domain_info["domain_code"]    = potential_code
                    domain_info["process_domain"] = potential_code
            else:
                pass





        # I Don't think we ever hit this condition.. the filename won't be extracted yet
        #  Handle standalone process domain files (not in ash-gov-process-model)
        elif filename.startswith(('SOP-', 'WP-')) and len(filename.split('-')) >= 4:
            # Extract from patterns like "SOP-OVR-03-Performance-Monitoring-Stakeholder-Communication"
            # or "WP-OVR-02-Governance-Review-Report"
            parts = filename.split('-')
            domain_info["domain_type"]    = "process"
            #we also want to extract the whole label SOP-OVR-03 and also save this to the KB table, using the process_domain field, because the domain_code field is already populated with OVR for example
            domain_info["process_domain"] = '-'.join(parts[0:3])  # Full label like SOP-OVR-03


            # Extract domain code (position 1 after SOP/WP)
            potential_code = parts[1]
            if len(potential_code) <= 3 and potential_code.isupper():
                domain_info["domain_code"] = potential_code
                domain_info["process_domain"] = potential_code

                # Extract domain name from parts after the number (position 3 onwards)
                # Skip parts[0] (SOP/WP), parts[1] (domain code), parts[2] (number like "03")
                if len(parts) > 3:
                    # Join remaining parts and replace hyphens with spaces
                    name_parts = parts[3:]
                    # Remove file extension from the last part
                    if name_parts[-1].endswith('.md'):
                        name_parts[-1] = name_parts[-1][:-3]
                    elif name_parts[-1].endswith('.json'):
                        name_parts[-1] = name_parts[-1][:-5]

                    domain_info["domain_name"] = ' '.join(name_parts)
            else:
                domain_info["domain_code"] = "XX"  # Unknown code


        # Populate domain_name for process domains using ProcessDomainCode enum (only if not already set)
        if (domain_info["domain_type"] == "process" and
            domain_info.get("domain_code") and
            not domain_info.get("domain_name")):  # Only if domain_name is not already set
            try:
                # Try to get the domain name from the ProcessDomainCode enum and mapping
                process_domain_code = ProcessDomainCode[domain_info["domain_code"]]
                domain_info["domain_name"] = PROCESS_DOMAIN_NAMES.get(
                    process_domain_code, domain_info["domain_code"]
                )
                # Set process_domain for schema (Tier 3) if not already set
                if not domain_info.get("process_domain"):
                    domain_info["process_domain"] = domain_info["domain_code"]
            except KeyError:
                # If domain code is not found in enum, keep existing domain_name (don't overwrite)
                logger.debug(f"Domain code '{domain_info['domain_code']}' not found in ProcessDomainCode enum - keeping extracted name")

        # ========================================
        # POLICY DOMAINS (descriptive names)
        # ========================================
        elif path_parts[0] == "policy-domain":
            domain_info["domain_type"] = "policy"
            domain_info["domain_code"] = "YY"

            if filename.endswith('-Domain-Overview-Summary.md'):
                domain_name = filename.replace('-Domain-Overview-Summary.md', '')
                domain_info["domain_name"] = domain_name

            elif filename.endswith('Policy.json'):
                domain_name = filename.replace('Policy.json', '')
                domain_info["domain_name"] = domain_name

            elif filename.startswith('ash-') and filename.endswith('-policy-TEMP.md'):
                domain_name = filename.replace('ash-', '').replace('-policy-TEMP.md', '').replace('-', '_')
                domain_info["domain_name"] = domain_name


        # ========================================
        # CONTROLS (organizational frameworks)
        # ========================================
        elif path_parts[0] == "controls":
            domain_info["domain_type"] = "controls"
            if 'iso' in filename.lower() or 'mapping' in filename.lower():
                domain_info["control_type"] = "iso_mapping"

            elif 'exemplar' in filename.lower():
                domain_info["control_type"] = "base_controls"
                #making the is_template True because these base controls should be overwritten in the customer's framework and there will be specific codes and catalogued notes,

            else:
                domain_info["control_type"] = "general"
                #making the is_template False because these are the general controls which are exemplars from ISO42001 Appendix A and should not be overwritten in the customer's framework


        elif path_parts[0] == "ISO-42001-maps":
            domain_info["domain_type"]  = "controls"
            domain_info["control_type"] = "iso_mapping"
            #making the is_template True because these are specific mappings for ISO 42001 for their framework instantiation


        elif path_parts[0] == "tools":
            domain_info["domain_type"]  = "controls"
            domain_info["control_type"] = "tools_registry"
            #making the is_template True because these are specific mappings for tools registry for their framework instantiation


        # ========================================
        # GOVERNANCE (CAI framework level)
        # ========================================
        elif len(path_parts) == 1 and not domain_info.get("domain_type"):  # Root level files, but only if domain_type not already set
            domain_info["domain_type"]  = "governance"


            if filename in ["master-registry.json", "process-domain-registry.json"]:
                domain_info["domain_name"] = "master_registry"
            elif filename.endswith('.md'):
                domain_info["domain_name"] = "framework_documentation"
            elif filename.endswith('.json'):
                domain_info["domain_name"] = "configuration"

        # ========================================
        # POPULATE SCHEMA CATEGORIZATION FIELDS
        # ========================================
        # Get detailed categorization using existing _categorize_file method
        [is_template, categorization]   = self._categorize_file(relative_path)
        domain_info["subcategory"]      = categorization
        domain_info["is_template"]      = is_template
        # Detailed subcategory (Tier 2)

        # Map subcategory to API-friendly label for filtering
        subcategory_to_label = {
            "process_domain_sop": "sop",
            "process_domain_work_products": "work_products",
            "wizard_guides_process": "wizard_guides",
            "wizard_guides_policy": "wizard_guides",
            "cai_governance_templates": "templates",
            "cai_governance_framework_docs": "framework_docs",
            "controls_iso_mapping": "iso_mapping",
            "controls_base_controls": "base_controls",
            "controls_tools_registry": "tools_registry",
            "controls_reviews_audits": "reviews_audits",
            "controls_supporting_docs": "supporting_docs",
            "domain_definitions": "domain_defs",
            "master_registry": "registries",
            "framework_misc": "misc"
        }
        domain_info["subcategory_label"] = subcategory_to_label.get(categorization, "misc")

        # Map subcategory to primary content category (Tier 1) for schema compliance
        if categorization.startswith("cai_governance"):
            domain_info["content_category"] = "cai_governance"
        elif categorization.startswith("policy_domain"):
            domain_info["content_category"] = "policy_domain"
        elif categorization.startswith("process_domain"):
            domain_info["content_category"] = "process_domain"
        elif categorization.startswith("controls_"):
            domain_info["content_category"] = "validation_tools"  # Controls map to validation_tools in schema
        elif categorization.startswith("wizard_guides"):
            # Wizard guides are cross-domain but map to appropriate primary category
            if "policy" in categorization:
                domain_info["content_category"] = "policy_domain"
                domain_info["subcategory_label"] = "wizard_guides"
            elif "process" in categorization:
                domain_info["content_category"] = "process_domain"
                domain_info["subcategory_label"] = "wizard_guides"
            else:
                domain_info["content_category"] = "framework_documentation"
        elif categorization in ["domain_definitions"]:
            domain_info["content_category"] = "domain_definitions"
        elif categorization == "master_registry" or categorization.endswith("_registry"):
            domain_info["content_category"] = "master_registry"
        else:
            # Default to framework_documentation for miscellaneous content
            domain_info["content_category"] = "framework_documentation"

        return domain_info

    def register_existing_content_with_kb(
        self, force_refresh: bool = False, verify_azure_content: bool = True
    ) -> tuple[bool, dict[str, Any]]:
        """
        Register existing Azure framework content with Knowledge Base.

        This method is useful when framework content has already been uploaded to Azure
        but needs to be registered with the KB (e.g., after a deployment or KB schema update).

        Args:
            force_refresh: If True, refresh manifest from Azure even if cached
            verify_azure_content: If True, verify content exists in Azure before registering

        Returns:
            Tuple of (success, registration_results)
        """
        logger.info("🗃️ Starting KB registration for existing Azure content")

        try:
            # Check if Azure container exists and has content
            if verify_azure_content:
                if not self.uploader.container_exists():
                    error_msg = f"Azure container '{self.uploader.container_name}' does not exist"
                    logger.error(error_msg)
                    return False, {"error": error_msg}

                # Get list of blobs in container for this version
                version_prefix = f"v{self.uploader.version}/"
                blobs = self.uploader.list_container_blobs(prefix=version_prefix)

                if not blobs:
                    error_msg = f"No content found in Azure container for version {self.uploader.version}"
                    logger.error(error_msg)
                    return False, {"error": error_msg}

                logger.info(
                    f"Found {len(blobs)} files in Azure container for version {self.uploader.version}"
                )

            # Create or refresh manifest from Azure content
            logger.info("📄 Creating manifest from existing Azure content")
            manifest = self.uploader.create_manifest_from_existing_blobs(
                force_refresh=force_refresh
            )

            if not manifest:
                error_msg = "Failed to create manifest from existing Azure content"
                logger.error(error_msg)
                return False, {"error": error_msg}

            # Register with KB
            logger.info("🗃️ Registering manifest with Knowledge Base")
            kb_success, kb_results = self._register_with_kb(manifest)

            results = {
                "registration_timestamp": datetime.now().isoformat(),
                "framework_version": self.uploader.version,
                "azure_content_verified": verify_azure_content,
                "manifest": manifest,
                "kb_registration": kb_results,
                "success": kb_success,
            }

            if kb_success:
                logger.info("✅ KB registration completed successfully")
            else:
                logger.warning("⚠️ KB registration encountered issues")

            return kb_success, results

        except Exception as e:
            logger.error(f"💥 KB registration failed: {str(e)}")
            return False, {
                "error": str(e),
                "exception_type": type(e).__name__,
                "registration_timestamp": datetime.now().isoformat(),
            }

    def compile_and_store_mongo_views(
        self, force_refresh: bool = False, verify_azure_content: bool = True
    ) -> tuple[bool, dict[str, Any]]:
        """
        Process framework content and store in MongoDB for efficient agent/wizard consumption.

        Updated: 2025-09-21 by JF Kalafut

        This method processes different content types following the hybrid persistence strategy:
        - Markdown files: Compiled into structured JSON views
        - JSON files: Stored natively with standardized metadata (no compilation needed)
        - YAML files: Parsed to JSON and stored with standardized metadata

        Args:
            force_refresh: If True, reprocess even if content already exists
            verify_azure_content: If True, verify content exists in Azure before processing

        Returns:
            Tuple of (success, processing_results)
        """
        logger.info("🔧 Starting MongoDB processing for framework content")

        if not self.mongo_compiler:
            error_msg = (
                "MongoDB compiler not initialized (no connection string provided)"
            )
            logger.error(error_msg)
            return False, {"error": error_msg}

        try:
            # Step 1: Get Azure content manifest
            if verify_azure_content and not self.uploader.container_exists():
                error_msg = f"Azure container '{self.uploader.container_name}' does not exist"
                logger.error(error_msg)
                return False, {"error": error_msg}

            # Create manifest from existing blobs
            logger.info("📄 Getting Azure content manifest")
            manifest = self.uploader.create_manifest_from_existing_blobs(
                force_refresh=force_refresh
            )

            if not manifest:
                error_msg = "Failed to create manifest from existing Azure content"
                logger.error(error_msg)
                return False, {"error": error_msg}

            # Step 2: Connect to MongoDB
            if not self.mongo_compiler.connect():
                error_msg = "Failed to connect to MongoDB"
                logger.error(error_msg)
                return False, {"error": error_msg}

            # Step 3: Download and process content (Markdown, JSON, YAML)
            logger.info("🔧 Processing content for MongoDB storage")
            compiled_views = []
            compilation_errors = []

            for category, files in manifest["content_map"].items():
                for file_info in files:
                    # Skip non-markdown files for compilation
                    if not self._should_compile_file(file_info):
                        continue

                    try:
                        # Download content from Azure
                        content = self._download_blob_content(file_info["blob_path"])
                        if content is None:
                            compilation_errors.append(
                                f"Failed to download: {file_info['relative_path']}"
                            )
                            continue

                        # Create artifact info for compiler (consistent artifact_id generation)
                        artifact_id = self._generate_artifact_id(
                            file_info["relative_path"], category
                        )

                        # Extract domain information for enhanced MongoDB filtering (consistent with PostgreSQL)
                        domain_info = self._extract_domain_info(Path(file_info["relative_path"]))

                        artifact_info = {
                            "artifact_id": artifact_id,
                            "framework_version": manifest["framework_version"],
                            "relative_path": file_info["relative_path"],

                            # Schema-compliant categorization (4-tier system) - matches PostgreSQL
                            "content_category": domain_info["content_category"],  # Primary category (Tier 1)
                            "subcategory": domain_info["subcategory"],           # Detailed subcategory (Tier 2)
                            "subcategory_label": domain_info["subcategory_label"], # API-friendly label for filtering
                            "process_domain": domain_info["process_domain"],     # Process domain code (Tier 3)
                            "content_format": domain_info["content_format"],     # File format

                            # File metadata
                            "blob_path": file_info["blob_path"],
                            "blob_url": file_info["blob_url"],

                            # Domain classification (existing fields - keep these for consistency)
                            "domain_type": domain_info["domain_type"],
                            "domain_code": domain_info["domain_code"],
                            "domain_name": domain_info["domain_name"],
                            "control_type": domain_info["control_type"],
                        }

                        # Route to appropriate storage method based on file type
                        relative_path = file_info['relative_path'].lower()
                        compiled_view = None

                        if relative_path.endswith('.md'):
                            # Compile Markdown content
                            compiled_view = self.mongo_compiler.compile_markdown_content(
                                content, artifact_info
                            )
                        elif relative_path.endswith('.json'):
                            # Store JSON content natively
                            compiled_view = self.mongo_compiler.store_json_content(
                                content, artifact_info
                            )
                        elif relative_path.endswith(('.yaml', '.yml')):
                            # Parse and store YAML content
                            compiled_view = self.mongo_compiler.store_yaml_content(
                                content, artifact_info
                            )

                        if compiled_view:
                            compiled_views.append(compiled_view)
                        else:
                            compilation_errors.append(
                                f"Failed to process: {file_info['relative_path']}"
                            )

                    except Exception as e:
                        error_msg = (
                            f"Error compiling {file_info['relative_path']}: {str(e)}"
                        )
                        logger.error(error_msg)
                        compilation_errors.append(error_msg)

            # Step 4: Store compiled views in MongoDB
            if compiled_views:
                logger.info(
                    f"💾 Storing {len(compiled_views)} compiled views in MongoDB"
                )
                successful_count, failed_count = self.mongo_compiler.batch_store_views(
                    compiled_views
                )

                results = {
                    "compilation_timestamp": datetime.now().isoformat(),
                    "framework_version": self.uploader.version,
                    "total_files_processed": len(manifest["content_map"]),
                    "compiled_views_created": len(compiled_views),
                    "mongodb_storage": {
                        "successful": successful_count,
                        "failed": failed_count,
                    },
                    "compilation_errors": compilation_errors,
                    "success": failed_count == 0 and len(compilation_errors) == 0,
                }

                if successful_count > 0:
                    logger.info(
                        f"✅ MongoDB compilation completed: {successful_count} views stored"
                    )
                    if failed_count > 0:
                        logger.warning(f"⚠️ Some views failed to store: {failed_count}")
                else:
                    logger.error("❌ No views were successfully stored")

                return results["success"], results
            else:
                return False, {
                    "error": "No views were compiled",
                    "compilation_errors": compilation_errors,
                }

        except Exception as e:
            logger.error(f"💥 MongoDB compilation failed: {str(e)}")
            return False, {
                "error": str(e),
                "exception_type": type(e).__name__,
                "compilation_timestamp": datetime.now().isoformat(),
            }
        finally:
            # Always disconnect from MongoDB
            if self.mongo_compiler:
                self.mongo_compiler.disconnect()

    def register_full_hybrid_content(
        self,
        force_refresh: bool = False,
        verify_azure_content: bool = True,
        skip_postgres: bool = False,
        skip_mongodb: bool = False,
    ) -> tuple[bool, dict[str, Any]]:
        """
        Complete hybrid registration: Postgres (relational) + MongoDB (compiled views).

        This implements the full hybrid persistence strategy:
        1. Register base metadata in Postgres via Hasura
        2. Compile and store JSON views in MongoDB for agent consumption

        Args:
            force_refresh: If True, refresh all data even if cached
            verify_azure_content: If True, verify content exists in Azure
            skip_postgres: If True, skip Postgres registration
            skip_mongodb: If True, skip MongoDB compilation

        Returns:
            Tuple of (success, detailed_results)
        """
        logger.info("🚀 Starting full hybrid content registration (Postgres + MongoDB)")

        results = {
            "registration_timestamp": datetime.now().isoformat(),
            "framework_version": self.uploader.version,
            "hybrid_strategy": True,
            "postgres_registration": None,
            "mongodb_compilation": None,
            "overall_success": False,
        }

        postgres_success = True
        mongodb_success = True

        try:
            # Step 1: Postgres Registration (relational metadata)
            if not skip_postgres:
                logger.info("📊 Step 1: Registering base metadata in Postgres")
                postgres_success, postgres_results = (
                    self.register_existing_content_with_kb(
                        force_refresh=force_refresh,
                        verify_azure_content=verify_azure_content,
                    )
                )
                results["postgres_registration"] = postgres_results

                if postgres_success:
                    logger.info("✅ Postgres registration completed")
                else:
                    logger.error("❌ Postgres registration failed")

            # Step 2: MongoDB Compilation (compiled JSON views)
            if not skip_mongodb and self.mongo_compiler:
                logger.info("🔧 Step 2: Compiling JSON views for MongoDB")
                mongodb_success, mongodb_results = self.compile_and_store_mongo_views(
                    force_refresh=force_refresh,
                    verify_azure_content=False,  # Already verified in step 1
                )
                results["mongodb_compilation"] = mongodb_results

                if mongodb_success:
                    logger.info("✅ MongoDB compilation completed")
                else:
                    logger.error("❌ MongoDB compilation failed")
            elif not self.mongo_compiler:
                logger.warning(
                    "⚠️ MongoDB compiler not available - skipping compilation"
                )
                results["mongodb_compilation"] = {
                    "skipped": "No MongoDB connection configured"
                }

            # Determine overall success
            results["overall_success"] = postgres_success and mongodb_success

            if results["overall_success"]:
                logger.info("🎉 Full hybrid registration completed successfully")
            else:
                logger.warning("⚠️ Hybrid registration completed with issues")

            return results["overall_success"], results

        except Exception as e:
            logger.error(f"💥 Hybrid registration failed: {str(e)}")
            results["error"] = str(e)
            results["exception_type"] = type(e).__name__
            return False, results

    def _should_compile_file(self, file_info: dict[str, Any]) -> bool:
        """Determine if a file should be processed for MongoDB storage."""
        relative_path = file_info.get("relative_path", "").lower()

        # Process Markdown files (compilation required)
        if relative_path.endswith(".md"):
            return True

        # Process ALL JSON files (native storage)
        if relative_path.endswith(".json"):
            return True

        # Process YAML files (parse to JSON)
        if relative_path.endswith(".yaml") or relative_path.endswith(".yml"):
            return True

        # Skip binary files, Python scripts, etc.
        skip_extensions = [".py", ".pyc", ".png", ".jpg", ".pdf", ".zip"]
        return not any(relative_path.endswith(ext) for ext in skip_extensions)

    def _generate_artifact_id(self, relative_path: str, content_category: str = None) -> str:
        """
        Generate a human-friendly artifact ID (slug) from relative path.
        Updated 2025-12-19 by JF Kalafut

        Uses the canonical slug mapping from artifact_slug_mapping.py to generate
        consistent, API-friendly identifiers like:
        - POL-AGP-Overview (Policy Overview)
        - SOP-PV-01 (SOP)
        - WP-RM-02 (Work Product)
        - FW-ImplGuide (Framework doc)

        Args:
            relative_path: Path relative to framework repository root
            content_category: Optional category hint (used for fallback)

        Returns:
            Human-friendly slug string for API lookups
        """
        return get_artifact_slug(relative_path, content_category or "")

    def _download_blob_content(self, blob_path: str) -> str | None:
        """Download content from Azure blob."""
        try:
            blob_client = self.uploader.blob_service_client.get_blob_client(
                container=self.uploader.container_name, blob=blob_path
            )

            blob_data = blob_client.download_blob()
            content = blob_data.readall().decode("utf-8")
            return content

        except Exception as e:
            logger.error(f"Failed to download blob {blob_path}: {str(e)}")
            return None

    def validate_artifact_id_mapping(
        self, framework_version: str = None
    ) -> tuple[bool, dict[str, Any]]:
        """
        Validate that artifact_id mapping is consistent between PostgreSQL and MongoDB.

        Args:
            framework_version: Specific version to validate (defaults to current version)

        Returns:
            Tuple of (mapping_is_consistent, validation_results)
        """
        if not framework_version:
            framework_version = self.uploader.version

        logger.info(f"🔍 Validating artifact_id mapping for version {framework_version}")

        validation_results = {
            "framework_version": framework_version,
            "validation_timestamp": datetime.now().isoformat(),
            "postgres_records": 0,
            "mongodb_records": 0,
            "matching_mappings": 0,
            "missing_in_postgres": [],
            "missing_in_mongodb": [],
            "mismatched_paths": [],
            "consistent": False,
        }

        try:
            # Step 1: Get PostgreSQL records with artifact_id
            postgres_artifacts = self._get_postgres_artifact_mappings(framework_version)
            validation_results["postgres_records"] = len(postgres_artifacts)

            # Step 2: Get MongoDB records with artifact_id (if MongoDB compiler available)
            if not self.mongo_compiler:
                logger.warning("MongoDB compiler not available - skipping MongoDB validation")
                validation_results["mongodb_records"] = "not_available"
                validation_results["consistent"] = len(postgres_artifacts) > 0
                return validation_results["consistent"], validation_results

            if not self.mongo_compiler.connect():
                logger.error("Failed to connect to MongoDB for validation")
                validation_results["error"] = "MongoDB connection failed"
                return False, validation_results

            mongodb_artifacts = self._get_mongodb_artifact_mappings(framework_version)
            validation_results["mongodb_records"] = len(mongodb_artifacts)

            # Step 3: Compare mappings
            postgres_paths = set(postgres_artifacts.keys())
            mongodb_paths = set(mongodb_artifacts.keys())

            # Find mismatches
            validation_results["missing_in_postgres"] = list(mongodb_paths - postgres_paths)
            validation_results["missing_in_mongodb"] = list(postgres_paths - mongodb_paths)

            # Check artifact_id consistency for matching paths
            common_paths = postgres_paths & mongodb_paths
            matching_count = 0

            for path in common_paths:
                postgres_artifact_id = postgres_artifacts[path]
                mongodb_artifact_id = mongodb_artifacts[path]

                if postgres_artifact_id == mongodb_artifact_id:
                    matching_count += 1
                else:
                    validation_results["mismatched_paths"].append({
                        "relative_path": path,
                        "postgres_artifact_id": postgres_artifact_id,
                        "mongodb_artifact_id": mongodb_artifact_id,
                    })

            validation_results["matching_mappings"] = matching_count

            # Determine overall consistency
            is_consistent = (
                len(validation_results["missing_in_postgres"]) == 0
                and len(validation_results["missing_in_mongodb"]) == 0
                and len(validation_results["mismatched_paths"]) == 0
                and matching_count > 0
            )

            validation_results["consistent"] = is_consistent

            if is_consistent:
                logger.info(f"✅ Artifact ID mapping is consistent: {matching_count} records validated")
            else:
                logger.warning(
                    f"⚠️ Artifact ID mapping inconsistencies found:\n"
                    f"  - Missing in PostgreSQL: {len(validation_results['missing_in_postgres'])}\n"
                    f"  - Missing in MongoDB: {len(validation_results['missing_in_mongodb'])}\n"
                    f"  - Mismatched artifact_ids: {len(validation_results['mismatched_paths'])}"
                )

            return is_consistent, validation_results

        except Exception as e:
            logger.error(f"💥 Validation failed: {str(e)}")
            validation_results["error"] = str(e)
            validation_results["exception_type"] = type(e).__name__
            return False, validation_results
        finally:
            # Always disconnect from MongoDB
            if self.mongo_compiler:
                self.mongo_compiler.disconnect()

    def _get_postgres_artifact_mappings(self, framework_version: str) -> dict[str, str]:
        """Get artifact_id mappings from PostgreSQL."""
        try:
            # Use GraphQL query to get PostgreSQL records
            query = f'''
            query GetFrameworkFiles {{
                framework_content_registry_files(
                    where: {{framework_version: {{_eq: "{framework_version}"}}, artifact_id: {{_is_null: false}}}}
                ) {{
                    relative_path
                    artifact_id
                }}
            }}
            '''

            success, response = self.kb_importer.execute_graphql_query(query)

            if not success:
                logger.error(f"Failed to query PostgreSQL: {response}")
                return {}

            postgres_mappings = {}
            for record in response.get('data', {}).get('framework_content_registry_files', []):
                postgres_mappings[record['relative_path']] = record['artifact_id']

            return postgres_mappings

        except Exception as e:
            logger.error(f"Error getting PostgreSQL mappings: {str(e)}")
            return {}

    def _get_mongodb_artifact_mappings(self, framework_version: str) -> dict[str, str]:
        """Get artifact_id mappings from MongoDB."""
        try:
            # Query MongoDB for artifact mappings
            cursor = self.mongo_compiler.collection.find(
                {"semver": framework_version},
                {"artifact_id": 1, "relative_path": 1}
            )

            mongodb_mappings = {}
            for doc in cursor:
                artifact_id = doc.get("artifact_id")
                relative_path = doc.get("relative_path")
                if artifact_id and relative_path:
                    mongodb_mappings[relative_path] = artifact_id

            return mongodb_mappings

        except Exception as e:
            logger.error(f"Error getting MongoDB mappings: {str(e)}")
            return {}

    def cleanup_version(self, version: str, dry_run: bool = False) -> dict[str, Any]:
        """
        Delete a specific framework version from all three persistence systems.

        Added Sep 21 2025 by JF Kalafut for version cleanup functionality.

        Args:
            version: Framework version to delete (e.g., "2025.09.21-120000")
            dry_run: If True, show what would be deleted without actually deleting

        Returns:
            Dictionary with cleanup results from all systems
        """
        logger.info(f"{'🔍 DRY RUN: ' if dry_run else '🗑️ '}Cleaning up framework version: {version}")

        results = {
            "version": version,
            "dry_run": dry_run,
            "cleanup_timestamp": datetime.now().isoformat(),
            "azure_cleanup": {},
            "postgresql_cleanup": {},
            "mongodb_cleanup": {},
            "overall_success": False,
            "summary": {}
        }

        try:
            if dry_run:
                # In dry run mode, just discover what would be deleted
                results["azure_cleanup"] = {
                    "version": version,
                    "would_delete_blobs": len(self.uploader.list_container_blobs(prefix=f"v{version}/")),
                    "dry_run": True
                }

                # Check PostgreSQL records
                postgres_versions = self.kb_importer.get_existing_versions()
                results["postgresql_cleanup"] = {
                    "version": version,
                    "version_exists": version in postgres_versions,
                    "dry_run": True
                }

                # Check MongoDB documents
                if self.mongo_compiler:
                    mongo_versions = self.mongo_compiler.get_versions()
                    results["mongodb_cleanup"] = {
                        "version": version,
                        "version_exists": version in mongo_versions,
                        "dry_run": True
                    }

                results["overall_success"] = True
                logger.info(f"🔍 Dry run complete for version {version}")

            else:
                # Actual cleanup - coordinate across all three systems

                # Step 1: Clean up Azure blobs
                logger.info("🗑️ Step 1: Cleaning up Azure blobs")
                results["azure_cleanup"] = self.uploader.delete_version_blobs(version)

                # Step 2: Clean up PostgreSQL records (via Hasura)
                logger.info("🗑️ Step 2: Cleaning up PostgreSQL records")
                results["postgresql_cleanup"] = self.kb_importer.delete_records_by_version(version)

                # Step 3: Clean up MongoDB documents
                logger.info("🗑️ Step 3: Cleaning up MongoDB documents")
                if self.mongo_compiler:
                    results["mongodb_cleanup"] = self.mongo_compiler.delete_version(version)
                else:
                    results["mongodb_cleanup"] = {
                        "version": version,
                        "deleted_documents": 0,
                        "success": True,
                        "note": "MongoDB compiler not available"
                    }

                # Evaluate overall success
                azure_success = results["azure_cleanup"].get("success", False)
                postgres_success = results["postgresql_cleanup"].get("success", False)
                mongo_success = results["mongodb_cleanup"].get("success", False)

                results["overall_success"] = azure_success and postgres_success and mongo_success

                # Create summary
                results["summary"] = {
                    "azure_blobs_deleted": results["azure_cleanup"].get("deleted_blobs", 0),
                    "postgres_files_deleted": results["postgresql_cleanup"].get("files_deleted", 0),
                    "postgres_registry_deleted": results["postgresql_cleanup"].get("registry_deleted", 0),
                    "mongodb_documents_deleted": results["mongodb_cleanup"].get("deleted_documents", 0),
                    "systems_successful": sum([azure_success, postgres_success, mongo_success]),
                    "systems_total": 3
                }

                if results["overall_success"]:
                    logger.info(f"✅ Successfully cleaned up version {version} from all systems")
                else:
                    logger.warning(f"⚠️ Cleanup of version {version} had issues in some systems")

        except Exception as e:
            error_msg = f"Exception during version cleanup: {str(e)}"
            logger.error(error_msg)
            results["error"] = error_msg
            results["overall_success"] = False

        return results

    def discover_versions(self) -> dict[str, list[str]]:
        """
        Discover framework versions across all three persistence systems.

        Added Sep 21 2025 by JF Kalafut for version discovery.

        Returns:
            Dictionary with versions found in each system
        """
        logger.info("🔍 Discovering framework versions across all systems")

        results = {
            "discovery_timestamp": datetime.now().isoformat(),
            "azure_versions": [],
            "postgresql_versions": [],
            "mongodb_versions": [],
            "all_versions": [],
            "orphaned_versions": {},
            "summary": {}
        }

        try:
            # Get versions from each system
            results["azure_versions"] = self.uploader.get_azure_versions()
            results["postgresql_versions"] = self.kb_importer.get_existing_versions()

            if self.mongo_compiler:
                results["mongodb_versions"] = self.mongo_compiler.get_versions()
            else:
                logger.info("MongoDB compiler not available - skipping MongoDB version discovery")

            # Find all unique versions
            all_versions_set = set()
            all_versions_set.update(results["azure_versions"])
            all_versions_set.update(results["postgresql_versions"])
            all_versions_set.update(results["mongodb_versions"])
            results["all_versions"] = sorted(list(all_versions_set), reverse=True)

            # Find orphaned versions (exist in some systems but not others)
            orphaned = {}
            for version in results["all_versions"]:
                missing_systems = []
                if version not in results["azure_versions"]:
                    missing_systems.append("azure")
                if version not in results["postgresql_versions"]:
                    missing_systems.append("postgresql")
                if version not in results["mongodb_versions"]:
                    missing_systems.append("mongodb")

                if missing_systems:
                    orphaned[version] = missing_systems

            results["orphaned_versions"] = orphaned

            # Create summary
            results["summary"] = {
                "total_unique_versions": len(results["all_versions"]),
                "azure_versions_count": len(results["azure_versions"]),
                "postgresql_versions_count": len(results["postgresql_versions"]),
                "mongodb_versions_count": len(results["mongodb_versions"]),
                "orphaned_versions_count": len(orphaned),
                "most_recent_version": results["all_versions"][0] if results["all_versions"] else None
            }

            logger.info(f"📊 Found {len(results['all_versions'])} total versions, {len(orphaned)} orphaned")

        except Exception as e:
            error_msg = f"Exception during version discovery: {str(e)}"
            logger.error(error_msg)
            results["error"] = error_msg

        return results

    def cleanup_older_than(self, days: int, dry_run: bool = False) -> dict[str, Any]:
        """
        Delete framework versions older than specified days.

        Added Sep 21 2025 by JF Kalafut for date-based cleanup.

        Args:
            days: Delete versions older than this many days
            dry_run: If True, show what would be deleted without actually deleting

        Returns:
            Dictionary with cleanup results
        """
        logger.info(f"{'🔍 DRY RUN: ' if dry_run else '🗑️ '}Cleaning up versions older than {days} days")

        from datetime import datetime, timedelta

        results = {
            "days_threshold": days,
            "dry_run": dry_run,
            "cleanup_timestamp": datetime.now().isoformat(),
            "cutoff_date": (datetime.now() - timedelta(days=days)).isoformat(),
            "versions_to_delete": [],
            "versions_to_keep": [],
            "cleanup_results": [],
            "overall_success": False,
            "summary": {}
        }

        try:
            # Discover all versions
            discovery = self.discover_versions()
            all_versions = discovery["all_versions"]

            if not all_versions:
                logger.info("No versions found to clean up")
                results["overall_success"] = True
                return results

            # Parse version timestamps and determine which to delete
            cutoff_date = datetime.now() - timedelta(days=days)

            for version in all_versions:
                try:
                    # Try to parse version as timestamp (e.g., "2025.09.21-120000")
                    if '-' in version and '.' in version:
                        date_part, time_part = version.split('-')
                        year, month, day = date_part.split('.')
                        hour = time_part[:2]
                        minute = time_part[2:4]
                        second = time_part[4:6] if len(time_part) >= 6 else '00'

                        version_date = datetime(
                            int(year), int(month), int(day),
                            int(hour), int(minute), int(second)
                        )

                        if version_date < cutoff_date:
                            results["versions_to_delete"].append(version)
                        else:
                            results["versions_to_keep"].append(version)
                    else:
                        # Can't parse date, keep the version to be safe
                        results["versions_to_keep"].append(version)
                        logger.warning(f"Could not parse date from version {version}, keeping it")

                except Exception as e:
                    # Error parsing date, keep the version to be safe
                    results["versions_to_keep"].append(version)
                    logger.warning(f"Error parsing version {version}: {str(e)}, keeping it")

            logger.info(f"Found {len(results['versions_to_delete'])} versions to delete, {len(results['versions_to_keep'])} to keep")

            if not results["versions_to_delete"]:
                logger.info("No versions older than threshold found")
                results["overall_success"] = True
                return results

            # Delete old versions
            successful_deletions = 0
            for version in results["versions_to_delete"]:
                cleanup_result = self.cleanup_version(version, dry_run=dry_run)
                results["cleanup_results"].append(cleanup_result)

                if cleanup_result.get("overall_success", False):
                    successful_deletions += 1

            results["overall_success"] = successful_deletions == len(results["versions_to_delete"])

            # Create summary
            results["summary"] = {
                "total_versions_found": len(all_versions),
                "versions_to_delete": len(results["versions_to_delete"]),
                "versions_to_keep": len(results["versions_to_keep"]),
                "successful_deletions": successful_deletions,
                "failed_deletions": len(results["versions_to_delete"]) - successful_deletions
            }

            if results["overall_success"]:
                logger.info(f"✅ Successfully cleaned up {successful_deletions} old versions")
            else:
                logger.warning(f"⚠️ Cleaned up {successful_deletions}/{len(results['versions_to_delete'])} old versions")

        except Exception as e:
            error_msg = f"Exception during date-based cleanup: {str(e)}"
            logger.error(error_msg)
            results["error"] = error_msg
            results["overall_success"] = False

        return results

    def keep_latest_versions(self, keep_count: int, dry_run: bool = False) -> dict[str, Any]:
        """
        Keep only the N most recent framework versions, delete the rest.

        Added Sep 21 2025 by JF Kalafut for count-based cleanup.

        Args:
            keep_count: Number of latest versions to keep
            dry_run: If True, show what would be deleted without actually deleting

        Returns:
            Dictionary with cleanup results
        """
        logger.info(f"{'🔍 DRY RUN: ' if dry_run else '🗑️ '}Keeping latest {keep_count} versions")

        results = {
            "keep_count": keep_count,
            "dry_run": dry_run,
            "cleanup_timestamp": datetime.now().isoformat(),
            "versions_to_delete": [],
            "versions_to_keep": [],
            "cleanup_results": [],
            "overall_success": False,
            "summary": {}
        }

        try:
            # Discover all versions
            discovery = self.discover_versions()
            all_versions = discovery["all_versions"]  # Already sorted, most recent first

            if not all_versions:
                logger.info("No versions found")
                results["overall_success"] = True
                return results

            if len(all_versions) <= keep_count:
                logger.info(f"Found {len(all_versions)} versions, all within keep threshold of {keep_count}")
                results["versions_to_keep"] = all_versions
                results["overall_success"] = True
                return results

            # Determine which versions to keep/delete
            results["versions_to_keep"] = all_versions[:keep_count]  # Most recent N
            results["versions_to_delete"] = all_versions[keep_count:]  # Older ones

            logger.info(f"Keeping versions: {results['versions_to_keep']}")
            logger.info(f"Deleting versions: {results['versions_to_delete']}")

            # Delete old versions
            successful_deletions = 0
            for version in results["versions_to_delete"]:
                cleanup_result = self.cleanup_version(version, dry_run=dry_run)
                results["cleanup_results"].append(cleanup_result)

                if cleanup_result.get("overall_success", False):
                    successful_deletions += 1

            results["overall_success"] = successful_deletions == len(results["versions_to_delete"])

            # Create summary
            results["summary"] = {
                "total_versions_found": len(all_versions),
                "versions_to_delete": len(results["versions_to_delete"]),
                "versions_to_keep": len(results["versions_to_keep"]),
                "successful_deletions": successful_deletions,
                "failed_deletions": len(results["versions_to_delete"]) - successful_deletions
            }

            if results["overall_success"]:
                logger.info(f"✅ Successfully cleaned up {successful_deletions} old versions")
            else:
                logger.warning(f"⚠️ Cleaned up {successful_deletions}/{len(results['versions_to_delete'])} old versions")

        except Exception as e:
            error_msg = f"Exception during count-based cleanup: {str(e)}"
            logger.error(error_msg)
            results["error"] = error_msg
            results["overall_success"] = False

        return results
