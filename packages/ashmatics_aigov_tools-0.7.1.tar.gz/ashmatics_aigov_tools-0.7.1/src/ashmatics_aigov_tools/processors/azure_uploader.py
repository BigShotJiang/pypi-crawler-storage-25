#!/usr/bin/env python3
"""
ast updated: 2025-09-25 by JF Kalafut
- changes made so that the compilation matches our aigov framework schema and 4-tier categorization system;


Azure Framework Content Uploader

Uploads Ashmatics Clinical AI Governance Framework content to Azure Container Storage
with versioning and metadata management.
"""

import hashlib
import logging
import mimetypes
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

# CAI framework imports
from ..config.content_patterns import get_default_content_patterns, filter_file_list

# Azure imports (will need to be installed)
try:
    from azure.core.exceptions import AzureError
    from azure.storage.blob import BlobServiceClient, ContentSettings
    from azure.storage.filedatalake import DataLakeServiceClient

    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False
    logging.warning(
        "Azure SDK not available. Install with: pip install azure-storage-blob azure-storage-file-datalake"
    )

logger = logging.getLogger(__name__)


class FrameworkContentUploader:
    """Uploads framework content to Azure Container Storage with versioning."""

    def __init__(
        self,
        connection_string: str,
        container_name: str = "framework-content",
        version: Optional[str] = None,
        force_adls_gen2: Optional[bool] = None,
    ):
        """
        Initialize Azure uploader.

        Args:
            connection_string: Azure Storage connection string
            container_name: Container name for framework content (or filesystem for ADLS Gen2)
            version: Framework version (auto-detected if None)
            force_adls_gen2: Force ADLS Gen2 mode (True) or blob mode (False). If None, auto-detect. 
            NOTE: plan is that we'll use ADLS Gen2, but doesn't need. If we move arway from Azure, we can use blob storage or other.
        """
        if not AZURE_AVAILABLE:
            raise ImportError(
                "Azure SDK required. Install with: pip install azure-storage-blob azure-storage-file-datalake"
            )

        self.connection_string = connection_string
        self.container_name    = container_name
        self.version           = version or self._generate_version()

        # Determine if this is ADLS Gen2 - use manual override or auto-detect
        if force_adls_gen2 is not None:
            self.is_adls_gen2 = force_adls_gen2
            logger.info(f"ADLS Gen2 mode manually set to: {force_adls_gen2}")
        else:
            self.is_adls_gen2 = self._is_adls_gen2_connection(connection_string)
        
        if self.is_adls_gen2:
            # Initialize DataLake client for ADLS Gen2
            self.datalake_service_client = DataLakeServiceClient.from_connection_string(
                connection_string
            )
            # Also initialize blob client for compatibility
            self.blob_service_client = BlobServiceClient.from_connection_string(
                connection_string
            )
            logger.info(f"Detected ADLS Gen2 storage - using DataLake API")
        else:
            # Initialize Blob client for regular blob storage
            self.blob_service_client = BlobServiceClient.from_connection_string(
                connection_string
            )
            self.datalake_service_client = None
            
        self.upload_results = {}

        logger.info(
            f"Initialized Azure uploader for {'filesystem' if self.is_adls_gen2 else 'container'} '{container_name}', version '{self.version}'"
        )

    def _is_adls_gen2_connection(self, connection_string: str) -> bool:
        """
        Detect if this is an ADLS Gen2 connection string by testing DataLake service capabilities.
        
        ADLS Gen2 = Storage account with hierarchical namespace enabled.
        We test this with a lightweight DataLake operation.
        """
        try:
            # Extract account name for logging
            account_name = self._extract_account_name(connection_string)
            logger.info(f"Testing ADLS Gen2 capabilities for account: {account_name}")
            
            # Try to create a DataLake service client and test a minimal operation
            datalake_client = DataLakeServiceClient.from_connection_string(connection_string)
            
            # Test with get_service_properties - this is a lightweight operation
            # that works for ADLS Gen2 but fails for blob-only accounts
            try:
                service_props = datalake_client.get_service_properties()
                logger.info(f"Successfully detected ADLS Gen2 for account {account_name}")
                return True
            except Exception as service_error:
                # Check if the error indicates lack of HNS support
                error_str = str(service_error).lower()
                if any(indicator in error_str for indicator in [
                    'hierarchical namespace', 'not enabled', 'hns', 'dfs endpoint'
                ]):
                    logger.info(f"Account {account_name} does not support ADLS Gen2 (HNS not enabled)")
                else:
                    logger.info(f"ADLS Gen2 test failed for {account_name}: {service_error}")
                return False
                
        except Exception as e:
            logger.warning(f"Error during ADLS Gen2 detection: {str(e)}")
            return False
    
    def _extract_account_name(self, connection_string: str) -> str:
        """Extract storage account name from connection string."""
        try:
            # Connection string format: "DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;"
            parts = connection_string.split(';')
            for part in parts:
                if part.startswith('AccountName='):
                    return part.split('=', 1)[1]
            return ""
        except Exception:
            return ""

    def _generate_version(self) -> str:
        """Generate a version string based on timestamp."""
        return datetime.now().strftime("%Y.%m.%d-%H%M%S")

    def _get_content_type(self, file_path: Path) -> str:
        """Determine MIME type for file."""
        content_type, _ = mimetypes.guess_type(str(file_path))

        # Override for specific file types
        if file_path.suffix == ".json":
            return "application/json"
        elif file_path.suffix == ".md":
            return "text/markdown"
        elif file_path.suffix == ".py":
            return "text/x-python"
        elif file_path.suffix in [".yaml", ".yml"]:
            return "application/x-yaml"

        return content_type or "application/octet-stream"

    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of file content."""
        sha256_hash = hashlib.sha256()
        with file_path.open("rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()

    def _create_blob_path(self, relative_path: str, use_version: bool = True) -> str:
        """Create versioned blob path."""
        if use_version:
            return f"v{self.version}/{relative_path}"
        return relative_path

    def upload_file(
        self,
        local_file_path: Path,
        blob_path: str,
        metadata: Optional[dict[str, str]] = None,
    ) -> tuple[bool, dict[str, Any]]:
        """
        Upload a single file to Azure Blob Storage.

        Args:
            local_file_path: Path to local file
            blob_path: Target blob path in container
            metadata: Optional metadata to attach to blob

        Returns:
            Tuple of (success, upload_info)
        """
        try:
            # Calculate file metadata
            file_hash = self._calculate_file_hash(local_file_path)
            file_size = local_file_path.stat().st_size
            content_type = self._get_content_type(local_file_path)

            # Prepare metadata
            blob_metadata = {
                "framework_version": self.version,
                "upload_timestamp": datetime.now().isoformat(),
                "file_hash": file_hash,
                "file_size": str(file_size),
                "source_file": str(local_file_path),
            }

            if metadata:
                blob_metadata.update(metadata)

            # Create blob client
            blob_client = self.blob_service_client.get_blob_client(
                container=self.container_name, blob=blob_path
            )

            # Upload file
            with local_file_path.open("rb") as data:
                blob_client.upload_blob(
                    data,
                    overwrite=True,
                    content_settings=ContentSettings(content_type=content_type),
                    metadata=blob_metadata,
                )

            upload_info = {
                "blob_path": blob_path,
                "local_path": str(local_file_path),
                "file_size": file_size,
                "file_hash": file_hash,
                "content_type": content_type,
                "metadata": blob_metadata,
                "upload_url": blob_client.url,
            }

            logger.debug(f"✅ Uploaded: {local_file_path} -> {blob_path}")
            return True, upload_info

        except AzureError as e:
            logger.error(f"❌ Azure error uploading {local_file_path}: {str(e)}")
            return False, {"error": str(e), "local_path": str(local_file_path)}
        except Exception as e:
            logger.error(f"❌ Error uploading {local_file_path}: {str(e)}")
            return False, {"error": str(e), "local_path": str(local_file_path)}

    def upload_framework_content(
        self, framework_repo_path: Path, content_patterns: Optional[list[str]] = None
    ) -> tuple[int, int, dict[str, Any]]:
        """
        Upload all framework content to Azure.

        Args:
            framework_repo_path: Path to framework repository
            content_patterns: Glob patterns for files to include

        Returns:
            Tuple of (success_count, failure_count, results)
        """
        logger.info(f"Starting framework content upload from {framework_repo_path}")

        # Use centralized content patterns configuration
        if content_patterns is None:
            content_patterns = get_default_content_patterns()

        results = {
            "version": self.version,
            "container": self.container_name,
            "upload_timestamp": datetime.now().isoformat(),
            "framework_path": str(framework_repo_path),
            "content_patterns": content_patterns,
            "uploaded_files": {},
            "failed_files": {},
            "summary": {
                "total_files": 0,
                "successful_uploads": 0,
                "failed_uploads": 0,
                "total_size_bytes": 0,
            },
        }

        successful_uploads = 0
        failed_uploads     = 0

        # Find all matching files
        all_files = []
        for pattern in content_patterns:
            matching_files = list(framework_repo_path.glob(pattern))
            all_files.extend(matching_files)

        # Remove duplicates and sort
        all_files = sorted(set(all_files))
        
        # Filter out unwanted system files
        all_files = filter_file_list(all_files)
        
        results["summary"]["total_files"] = len(all_files)

        logger.info(f"Found {len(all_files)} files to upload")

        # Upload each file
        for file_path in all_files:
            if not file_path.is_file():
                continue

            # Calculate relative path from framework root
            try:
                relative_path = file_path.relative_to(framework_repo_path)
                blob_path     = self._create_blob_path(str(relative_path))

                # Additional metadata based on file type/location
                file_metadata = self._get_file_metadata(file_path, relative_path)

                success, upload_info = self.upload_file(
                    file_path, blob_path, file_metadata
                )

                if success:
                    successful_uploads += 1
                    results["uploaded_files"][str(relative_path)] = upload_info
                    results["summary"]["total_size_bytes"] += upload_info.get(
                        "file_size", 0
                    )
                else:
                    failed_uploads += 1
                    results["failed_files"][str(relative_path)] = upload_info

            except Exception as e:
                failed_uploads += 1
                logger.error(f"Error processing {file_path}: {str(e)}")
                results["failed_files"][str(file_path)] = {"error": str(e)}

        results["summary"]["successful_uploads"] = successful_uploads
        results["summary"]["failed_uploads"] = failed_uploads

        logger.info(
            f"Upload complete: {successful_uploads} success, {failed_uploads} failed"
        )

        self.upload_results = results
        return successful_uploads, failed_uploads, results

    def _get_file_metadata(
        self, file_path: Path, relative_path: Path
    ) -> dict[str, str]:
        """Generate metadata based on file location and type."""
        metadata = {}

        # Categorize by location using enhanced categorization logic
        path_parts = relative_path.parts
        filename = file_path.name
        
        if path_parts[0] == "domains":
            metadata["content_category"] = "domain_definitions"
            if file_path.suffix == ".json":
                # Extract domain code from filename
                domain_code = file_path.stem.split("-")[0]
                metadata["domain_code"] = domain_code

        # TIER 2: POLICY DOMAIN - Enhanced categorization
        elif path_parts[0] == "policy-domain":
            # Policy overview content for display
            if filename.endswith('-Domain-Overview-Summary.md'):
                metadata["content_category"] = "policy_domain_overview_content"
            # Policy template primitives (JSON definitions)
            elif filename.endswith('Policy.json'):
                metadata["content_category"] = "policy_domain_template_primitives"
            # Policy glue files (tokens, bindings)
            elif ('token' in filename.lower() or 'binding' in filename.lower() or
                  filename in ['tokenIndex.json', 'tokenMapByArtifact.json']):
                metadata["content_category"] = "policy_domain_glue_files"
            # Temporary policy files
            elif filename.startswith('ash-') and filename.endswith('-policy-TEMP.md'):
                metadata["content_category"] = "policy_domain_temp_policies"
            # Other policy domain content
            else:
                metadata["content_category"] = "policy_domain_misc"

        # TIER 3: PROCESS DOMAIN - Enhanced categorization
        elif path_parts[0] == "process-domain":
            if filename.endswith('-Overview-Summary.md'):
                metadata["content_category"] = "process_domain_overview_content"
            elif filename.endswith('.json'):
                metadata["content_category"] = "process_domain_definitions"
            else:
                metadata["content_category"] = "process_domain_misc"

        elif path_parts[0] == "ash-gov-process-model":
            metadata["content_category"] = "process_documentation"
            if len(path_parts) > 1:
                metadata["domain_folder"] = path_parts[1]
        elif file_path.name == "process-domain-registry.json":
            metadata["content_category"] = "master_registry"
        elif path_parts[0] == "tools":
            # Simplified categorization for tools directory to match framework_content.py
            if filename.lower() in ["tooling_registry.yaml", "tools_registry.yaml", "registry.yaml"]:
                metadata["content_category"] = "framework_tool_registry"
            elif filename.endswith('.json') and "registry" in filename.lower():
                metadata["content_category"] = "framework_tool_registry"
            else:
                metadata["content_category"] = "framework_tools"
        elif len(path_parts) == 1 and filename.endswith('.md'):
            # Root-level framework documentation files with enhanced subcategorization
            if filename in ["Framework-Overview-Summary.md"]:  # Fixed: actual filename, removed generalist file
                metadata["content_category"] = "framework_documentation_overview"
            elif filename in ["Implementation-Reference-Guide.md", "value-proposition-polproc.md"]:
                metadata["content_category"] = "framework_documentation_implementation"
            elif filename in ["Policy-Domain-Architecture.md", "Process-Domain-Architecture.md"]:
                metadata["content_category"] = "framework_documentation_architecture"
            else:
                metadata["content_category"] = "framework_documentation"
        else:
            metadata["content_category"] = "framework_documentation"

        # Add file type metadata
        if file_path.suffix == ".json":
            metadata["file_type"] = "json_configuration"
        elif file_path.suffix == ".md":
            metadata["file_type"] = "markdown_documentation"
        elif file_path.suffix == ".py":
            metadata["file_type"] = "python_tool"
        elif file_path.suffix in [".yaml", ".yml"]:
            metadata["file_type"] = "yaml_configuration"

        return metadata

    def create_upload_manifest(self) -> dict[str, Any]:
        """
        last checked Sep 21 2025 by JF Kalafut

        Create manifest of uploaded content for KB registration.

        Returns:
            Manifest dictionary suitable for KB registration
        """
        if not self.upload_results:
            raise ValueError(
                "No upload results available. Run upload_framework_content first."
            )

        manifest = {
            "framework_version": self.version,
            "upload_timestamp": self.upload_results["upload_timestamp"],
            "container_name": self.container_name,
            "total_files": self.upload_results["summary"]["successful_uploads"],
            "total_size_bytes": self.upload_results["summary"]["total_size_bytes"],
            "content_map": {},
        }

        # Organize uploaded files by category, category is the content_category metadata field and need to keep consistent across database access and types!
        for relative_path, upload_info in self.upload_results["uploaded_files"].items():
            category = upload_info["metadata"].get("content_category", "other")

            if category not in manifest["content_map"]:
                manifest["content_map"][category] = []

            manifest["content_map"][category].append(
                {
                    "relative_path": relative_path,
                    "blob_path": upload_info["blob_path"],
                    "blob_url": upload_info["upload_url"],
                    "file_hash": upload_info["file_hash"],
                    "file_size": upload_info["file_size"],
                    "content_type": upload_info["content_type"],
                }
            )

        return manifest

    def ensure_container_exists(self) -> bool:
        """Ensure the container exists, create if not."""
        try:
            container_client = self.blob_service_client.get_container_client(
                self.container_name
            )

            # Check if container exists
            if not container_client.exists():
                logger.info(f"Creating container: {self.container_name}")
                container_client.create_container(
                    metadata={
                        "purpose": "ashmatics_framework_content",
                        "created": datetime.now().isoformat(),
                    }
                )

            return True

        except AzureError as e:
            logger.error(f"Error ensuring container exists: {str(e)}")
            return False

    def container_exists(self) -> bool:
        """Check if the container exists."""
        try:
            container_client = self.blob_service_client.get_container_client(
                self.container_name
            )
            return container_client.exists()
        except AzureError as e:
            logger.error(f"Error checking container existence: {str(e)}")
            return False

    def list_container_blobs(self, prefix: str = None) -> list[dict[str, Any]]:
        """
        List blobs in the container.

        Args:
            prefix: Optional prefix to filter blobs

        Returns:
            List of blob information dictionaries
        """
        try:
            logger.info(f"Listing blobs using {'ADLS Gen2' if self.is_adls_gen2 else 'Blob Storage'} API")

            if self.is_adls_gen2:
                # Use DataLake API for ADLS Gen2
                filesystem_client = self.datalake_service_client.get_file_system_client(
                    self.container_name
                )

                # Check if filesystem exists
                try:
                    filesystem_client.get_file_system_properties()
                except AzureError as e:
                    if "does not exist" in str(e).lower():
                        logger.error(f"ADLS Gen2 filesystem '{self.container_name}' does not exist")
                        return []
                    raise

                blobs = []
                directories_skipped = 0
                paths = filesystem_client.get_paths(path=prefix, recursive=True)

                for path in paths:
                    # Multiple checks for directory detection in ADLS Gen2
                    is_directory = (
                        path.is_directory or
                        path.name.endswith("/") or
                        (hasattr(path, "content_length") and path.content_length == 0 and not path.name.split("/")[-1].count("."))
                    )

                    if is_directory:
                        directories_skipped += 1
                        logger.debug(f"Skipping ADLS Gen2 directory: {path.name}")
                        continue

                    blob_info = {
                        "name": path.name,
                        "size": getattr(path, "content_length", 0),
                        "content_type": getattr(path, "content_type", "unknown"),
                        "last_modified": path.last_modified.isoformat() if path.last_modified else None,
                        "url": f"https://{self.datalake_service_client.account_name}.dfs.core.windows.net/{self.container_name}/{path.name}",
                        "metadata": getattr(path, "metadata", {}) or {},
                    }
                    blobs.append(blob_info)

                logger.info(f"Found {len(blobs)} files, skipped {directories_skipped} directories")
                return blobs
            else:
                # Use Blob API for regular blob storage
                container_client = self.blob_service_client.get_container_client(
                    self.container_name
                )

                blobs = []
                directories_skipped = 0
                blob_list = container_client.list_blobs(name_starts_with=prefix)

                for blob in blob_list:
                    # Skip directories (blobs ending with / or marked as directory)
                    is_directory = (
                        blob.name.endswith("/") or
                        (blob.size == 0 and blob.metadata and blob.metadata.get("hdi_isfolder") == "true")
                    )

                    if is_directory:
                        directories_skipped += 1
                        logger.debug(f"Skipping directory blob: {blob.name}")
                        continue

                    blob_info = {
                        "name": blob.name,
                        "size": blob.size,
                        "content_type": getattr(blob, "content_settings", {}).get(
                            "content_type", "unknown"
                        ),
                        "last_modified": blob.last_modified.isoformat()
                        if blob.last_modified
                        else None,
                        "url": f"https://{self.blob_service_client.account_name}.blob.core.windows.net/{self.container_name}/{blob.name}",
                        "metadata": blob.metadata or {},
                    }
                    blobs.append(blob_info)

                logger.info(f"Found {len(blobs)} files, skipped {directories_skipped} directories")
                return blobs

        except AzureError as e:
            logger.error(f"Error listing {'filesystem' if self.is_adls_gen2 else 'container'} blobs: {str(e)}")
            return []

    def create_manifest_from_existing_blobs(
        self, force_refresh: bool = False, prefix: Optional[str] = None  # noqa: ARG002
    ) -> Optional[dict[str, Any]]:
        """
        Create manifest from existing blobs in Azure container.

        Args:
            force_refresh: Force refresh even if cached manifest exists
            prefix: Optional prefix to filter blobs (defaults to version prefix)

        Returns:
            Manifest dictionary or None if failed
        """
        try:
            # Use version prefix if none specified
            if prefix is None:
                prefix = f"v{self.version}/"

            logger.info(f"Creating manifest from existing blobs with prefix: {prefix}")

            # List all blobs with the prefix (already filters directories)
            blobs = self.list_container_blobs(prefix=prefix)

            if not blobs:
                logger.warning(f"No blobs found with prefix '{prefix}'")
                return None

            # Organize blobs by category
            content_map = {}
            total_size = 0
            file_list = []  # Track file paths for manifest

            for blob in blobs:
                # Remove version prefix to get relative path
                relative_path = blob["name"]
                if relative_path.startswith(prefix):
                    relative_path = relative_path[len(prefix) :]

                # Categorize the file
                category = self._categorize_blob_path(relative_path)

                if category not in content_map:
                    content_map[category] = []

                # Create file info similar to upload manifest
                file_info = {
                    "relative_path": relative_path,
                    "blob_path": blob["name"],
                    "blob_url": blob["url"],
                    "file_size": blob["size"],
                    "content_type": blob["content_type"],
                    "file_hash": blob["metadata"].get("file_hash", "unknown"),
                    "last_modified": blob["last_modified"],
                }

                content_map[category].append(file_info)
                total_size += blob["size"]
                file_list.append(relative_path)

            # Create manifest with files list for compatibility with compare_manifest_to_db.py
            manifest = {
                "framework_version": self.version,
                "container_name": self.container_name,
                "upload_timestamp": datetime.now().isoformat(),
                "source": "existing_azure_content",
                "total_files": len(blobs),
                "total_size_bytes": total_size,
                "content_map": content_map,
                "files": file_list,  # Add for compatibility with comparison script
                "directories": [],   # Already filtered out by list_container_blobs()
                "blob_prefix": prefix,
            }

            logger.info(f"Created manifest for {len(blobs)} existing files")
            return manifest

        except Exception as e:
            logger.error(f"Error creating manifest from existing blobs: {str(e)}")
            return None

    def _categorize_blob_path(self, relative_path: str) -> str:
        """Categorize a blob based on its relative path."""
        path_parts = Path(relative_path).parts
        filename = Path(relative_path).name

        if len(path_parts) == 0:
            return "framework_documentation"

        # TIER 2: POLICY DOMAIN ARTIFACTS
        if path_parts[0] == "policy-domain":
            # Policy overview content for display
            if filename.endswith('-Domain-Overview-Summary.md'):
                return "policy_domain_overview_content"
            # Policy template primitives (JSON definitions)
            elif filename.endswith('Policy.json'):
                return "policy_domain_template_primitives"
            # Policy glue files (tokens, bindings)
            elif ('token' in filename.lower() or 'binding' in filename.lower() or
                  filename in ['tokenIndex.json', 'tokenMapByArtifact.json']):
                return "policy_domain_glue_files"
            # Temporary policy files
            elif filename.startswith('ash-') and filename.endswith('-policy-TEMP.md'):
                return "policy_domain_temp_policies"
            # Other policy domain content
            else:
                return "policy_domain_misc"

        # TIER 3: PROCESS DOMAIN (process-domain folder for overview materials)
        elif path_parts[0] == "process-domain":
            if filename.endswith('-Overview-Summary.md'):
                return "process_domain_overview_content"
            elif filename.endswith('.json'):
                return "process_domain_definitions"
            else:
                return "process_domain_misc"

        # Legacy/existing categorization
        elif path_parts[0] == "domains":
            return "domain_definitions"
        elif path_parts[0] == "policy-logic":
            return "policy_templates"
        elif path_parts[0] == "ash-gov-process-model":
            return "process_documentation"
        elif relative_path == "process-domain-registry.json":
            return "master_registry"
        elif path_parts[0] == "tools":
            # Simplified categorization for tools directory to match framework_content.py
            if filename.lower() in ["tooling_registry.yaml", "tools_registry.yaml", "registry.yaml"]:
                return "framework_tool_registry"
            elif filename.endswith('.json') and "registry" in filename.lower():
                return "framework_tool_registry"
            else:
                return "framework_tools"
        elif len(path_parts) == 1 and filename.endswith('.md'):
            # Root-level framework documentation files
            if filename in ["Framework-Overview-Summary.md"]:  # Fixed: actual filename, removed generalist file
                return "framework_documentation_overview"
            elif filename in ["Implementation-Reference-Guide.md", "value-proposition-polproc.md"]:
                return "framework_documentation_implementation"
            elif filename in ["Policy-Domain-Architecture.md", "Process-Domain-Architecture.md"]:
                return "framework_documentation_architecture"
            else:
                return "framework_documentation"
        else:
            return "framework_documentation"

    def delete_version_blobs(self, version: str) -> dict[str, Any]:
        """
        Delete all blobs for a specific framework version.

        Added Sep 21 2025 by JF Kalafut for version cleanup functionality.

        Args:
            version: Framework version to delete (e.g., "2025.09.21-120000")

        Returns:
            Dictionary with deletion results
        """
        logger.info(f"Deleting Azure blobs for version: {version}")

        results = {
            "version": version,
            "deleted_blobs": 0,
            "failed_blobs": 0,
            "success": False,
            "errors": []
        }

        try:
            # List all blobs with version prefix
            version_prefix = f"v{version}/"
            blobs = self.list_container_blobs(prefix=version_prefix)

            if not blobs:
                logger.info(f"No blobs found for version {version}")
                results["success"] = True
                return results

            logger.info(f"Found {len(blobs)} blobs to delete for version {version}")

            # Delete each blob
            for blob in blobs:
                try:
                    blob_client = self.blob_service_client.get_blob_client(
                        container=self.container_name, blob=blob["name"]
                    )
                    blob_client.delete_blob()
                    results["deleted_blobs"] += 1

                    if results["deleted_blobs"] % 10 == 0:
                        logger.info(f"Deleted {results['deleted_blobs']} blobs...")

                except AzureError as e:
                    error_msg = f"Failed to delete blob {blob['name']}: {str(e)}"
                    results["errors"].append(error_msg)
                    results["failed_blobs"] += 1
                    logger.error(error_msg)

            # Check overall success
            if results["failed_blobs"] == 0:
                results["success"] = True
                logger.info(f"Successfully deleted all {results['deleted_blobs']} blobs for version {version}")
            else:
                logger.warning(f"Deleted {results['deleted_blobs']} blobs, {results['failed_blobs']} failed")

        except Exception as e:
            error_msg = f"Exception during Azure blob deletion for version {version}: {str(e)}"
            results["errors"].append(error_msg)
            logger.error(error_msg)

        return results

    def get_azure_versions(self) -> list[str]:
        """
        Get list of framework versions from Azure blob prefixes.

        Added Sep 21 2025 by JF Kalafut for version discovery.

        Returns:
            List of distinct framework versions found in Azure
        """
        logger.info("Discovering framework versions in Azure blobs")

        try:
            # List all blobs in container
            all_blobs = self.list_container_blobs()

            # Extract versions from blob paths like "v2025.09.21-120000/..."
            versions = set()
            version_pattern = r"^v([^/]+)/"

            for blob in all_blobs:
                match = re.match(version_pattern, blob["name"])
                if match:
                    versions.add(match.group(1))

            sorted_versions = sorted(list(versions), reverse=True)  # Most recent first
            logger.info(f"Found {len(sorted_versions)} framework versions in Azure")
            return sorted_versions

        except Exception as e:
            logger.error(f"Error getting Azure versions: {str(e)}")
            return []

    def delete_blobs_by_filter(self, prefix: str = None, pattern: str = None) -> dict[str, Any]:
        """
        Delete blobs by prefix or pattern.

        Added Sep 21 2025 by JF Kalafut for flexible blob deletion.

        Args:
            prefix: Blob name prefix to filter by
            pattern: Regex pattern to match blob names

        Returns:
            Dictionary with deletion results
        """
        logger.info(f"Deleting Azure blobs with prefix='{prefix}', pattern='{pattern}'")

        results = {
            "prefix": prefix,
            "pattern": pattern,
            "deleted_blobs": 0,
            "failed_blobs": 0,
            "success": False,
            "errors": []
        }

        try:
            # List blobs with optional prefix
            blobs = self.list_container_blobs(prefix=prefix)

            # Apply pattern filter if specified
            if pattern:
                import re
                pattern_re = re.compile(pattern)
                blobs = [blob for blob in blobs if pattern_re.search(blob["name"])]

            if not blobs:
                logger.info(f"No blobs found matching criteria")
                results["success"] = True
                return results

            logger.info(f"Found {len(blobs)} blobs to delete")

            # Delete each matching blob
            for blob in blobs:
                try:
                    blob_client = self.blob_service_client.get_blob_client(
                        container=self.container_name, blob=blob["name"]
                    )
                    blob_client.delete_blob()
                    results["deleted_blobs"] += 1

                    if results["deleted_blobs"] % 10 == 0:
                        logger.info(f"Deleted {results['deleted_blobs']} blobs...")

                except AzureError as e:
                    error_msg = f"Failed to delete blob {blob['name']}: {str(e)}"
                    results["errors"].append(error_msg)
                    results["failed_blobs"] += 1
                    logger.error(error_msg)

            # Check overall success
            if results["failed_blobs"] == 0:
                results["success"] = True
                logger.info(f"Successfully deleted all {results['deleted_blobs']} matching blobs")
            else:
                logger.warning(f"Deleted {results['deleted_blobs']} blobs, {results['failed_blobs']} failed")

        except Exception as e:
            error_msg = f"Exception during Azure blob deletion by filter: {str(e)}"
            results["errors"].append(error_msg)
            logger.error(error_msg)

        return results

    def cleanup_old_versions(self, keep_latest: int = 5) -> dict[str, Any]:
        """
        Delete old framework versions, keeping only the N most recent.

        Added Sep 21 2025 by JF Kalafut for automated cleanup.

        Args:
            keep_latest: Number of latest versions to keep

        Returns:
            Dictionary with cleanup results
        """
        logger.info(f"Cleaning up old Azure versions, keeping latest {keep_latest}")

        results = {
            "keep_latest": keep_latest,
            "versions_found": 0,
            "versions_deleted": 0,
            "versions_kept": 0,
            "total_blobs_deleted": 0,
            "success": False,
            "errors": [],
            "deleted_versions": []
        }

        try:
            # Get all versions
            all_versions = self.get_azure_versions()
            results["versions_found"] = len(all_versions)

            if len(all_versions) <= keep_latest:
                logger.info(f"Found {len(all_versions)} versions, keeping all (threshold: {keep_latest})")
                results["success"] = True
                results["versions_kept"] = len(all_versions)
                return results

            # Determine which versions to delete (oldest ones)
            versions_to_keep = all_versions[:keep_latest]  # Most recent first
            versions_to_delete = all_versions[keep_latest:]

            results["versions_kept"] = len(versions_to_keep)
            logger.info(f"Keeping versions: {versions_to_keep}")
            logger.info(f"Deleting versions: {versions_to_delete}")

            # Delete old versions
            for version in versions_to_delete:
                delete_result = self.delete_version_blobs(version)
                if delete_result["success"]:
                    results["versions_deleted"] += 1
                    results["total_blobs_deleted"] += delete_result["deleted_blobs"]
                    results["deleted_versions"].append(version)
                else:
                    results["errors"].extend(delete_result["errors"])

            # Check overall success
            if results["versions_deleted"] == len(versions_to_delete):
                results["success"] = True
                logger.info(f"Successfully cleaned up {results['versions_deleted']} old versions")
            else:
                logger.warning(f"Cleanup partially successful: {results['versions_deleted']}/{len(versions_to_delete)} versions deleted")

        except Exception as e:
            error_msg = f"Exception during Azure version cleanup: {str(e)}"
            results["errors"].append(error_msg)
            logger.error(error_msg)

        return results
