#!/usr/bin/env python3
"""
Framework Content Validator

Validates the structure and integrity of the Ashmatics Clinical AI Governance Framework
source content before upload to Azure Container Storage.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class FrameworkContentValidator:
    """Validates framework content structure and integrity.

    Updated Sep 21 2025 by JF Kalafut - refactored for new 4-tier categorization system
    """

    def __init__(self, framework_repo_path: str):
        """
        Initialize validator with path to framework repository.

        Args:
            framework_repo_path: Path to the framework repository
        """
        self.framework_path = Path(framework_repo_path)
        self.validation_results = {}

    def validate_all(self) -> tuple[bool, dict[str, Any]]:
        """
        Validate all framework content.

        Returns:
            Tuple of (is_valid, validation_results)
        """
        logger.info("Starting comprehensive framework validation")

        validation_results = {
            "timestamp": datetime.now().isoformat(),
            "framework_path": str(self.framework_path),
            "validations": {},
            "summary": {"total_checks": 0, "passed": 0, "failed": 0, "warnings": 0},
        }

        # Core structure validation
        structure_valid, structure_results = self._validate_structure()
        validation_results["validations"]["structure"] = structure_results

        # Domain files validation
        domains_valid, domains_results = self._validate_domains()
        validation_results["validations"]["domains"] = domains_results

        # Policy logic validation
        policy_valid, policy_results = self._validate_policy_logic()
        validation_results["validations"]["policy_logic"] = policy_results

        # Process model validation
        process_valid, process_results = self._validate_process_model()
        validation_results["validations"]["process_model"] = process_results

        # Registry validation
        registry_valid, registry_results = self._validate_registry()
        validation_results["validations"]["registry"] = registry_results

        # 4-tier categorization validation (added Sep 21 2025 - JF Kalafut)
        tier_valid, tier_results = self._validate_4tier_structure()
        validation_results["validations"]["4tier_categorization"] = tier_results

        # Calculate summary
        all_checks = [
            structure_valid,
            domains_valid,
            policy_valid,
            process_valid,
            registry_valid,
            tier_valid,
        ]
        validation_results["summary"]["total_checks"] = len(all_checks)
        validation_results["summary"]["passed"] = sum(all_checks)
        validation_results["summary"]["failed"] = len(all_checks) - sum(all_checks)

        overall_valid = all(all_checks)
        validation_results["overall_valid"] = overall_valid

        self.validation_results = validation_results

        if overall_valid:
            logger.info("✅ Framework validation passed")
        else:
            logger.error("❌ Framework validation failed")

        return overall_valid, validation_results

    def _validate_structure(self) -> tuple[bool, dict[str, Any]]:
        """Validate core framework structure."""
        logger.info("Validating framework structure")

        required_paths = [
            "process-domain/",
            "policy-domain/",
            "ash-gov-process-model/",
            "process-domain-registry.json",
            "ashmatics-framework-registry.json",  # Updated: was master-registry.json
        ]

        results = {"required_paths": {}, "optional_paths": {}, "issues": []}

        all_valid = True

        for path_str in required_paths:
            path = self.framework_path / path_str
            exists = path.exists()
            results["required_paths"][path_str] = {
                "exists": exists,
                "path": str(path),
                "type": "directory" if path_str.endswith("/") else "file",
            }

            if not exists:
                all_valid = False
                results["issues"].append(f"Missing required path: {path_str}")

        # Check for optional but expected paths
        optional_paths = [
            "tools/",
            "controls/",
            "ISO-42001-maps/",
            "architecture-design/",
            "reviews-audits/",
            "supporting-framework-docs/",
            "Makefile",
            "CLAUDE.md"
        ]
        for path_str in optional_paths:
            path = self.framework_path / path_str
            results["optional_paths"][path_str] = {
                "exists": path.exists(),
                "path": str(path),
            }

        return all_valid, results

    def _validate_domains(self) -> tuple[bool, dict[str, Any]]:
        """Validate domain JSON files."""
        logger.info("Validating domain files")

        domains_path = self.framework_path / "process-domain"
        results = {"domain_files": {}, "issues": []}

        if not domains_path.exists():
            return False, results

        all_valid = True
        # Updated for new 11 process domains - Sep 21 2025 JF Kalafut
        expected_domains = [
            "pv",  # Product Validation
            "sa",  # Safety Assessment
            "mon", # Monitoring
            "ovr", # Oversight
            "org", # Organization
            "it",  # IT Infrastructure
            "rm",  # Risk Management
            "ho",  # Human Oversight
            "ef",  # Ethics & Fairness
            "tr",  # Training
            "ug",  # User Guidance
        ]

        for domain_code in expected_domains:
            domain_file = domains_path / f"{domain_code}-process-domain.json"

            if not domain_file.exists():
                all_valid = False
                results["issues"].append(f"Missing domain file: {domain_file.name}")
                continue

            try:
                with domain_file.open() as f:
                    domain_data = json.load(f)

                # Validate required fields - check nested structure
                domain_results = {
                    "file_path": str(domain_file),
                    "required_fields": {},
                    "base_practices_count": 0,
                    "policy_bindings_count": 0,
                }

                # Check for domain_code (can be in domain_metadata.process_id)
                has_domain_code = "domain_code" in domain_data or (
                    "domain_metadata" in domain_data
                    and "process_id" in domain_data["domain_metadata"]
                )
                domain_results["required_fields"]["domain_code"] = has_domain_code
                if not has_domain_code:
                    all_valid = False
                    results["issues"].append(
                        f"Domain {domain_code}: missing field 'domain_code' or 'domain_metadata.process_id'"
                    )

                # Check for domain_name (can be in domain_metadata.title)
                has_domain_name = "domain_name" in domain_data or (
                    "domain_metadata" in domain_data
                    and "title" in domain_data["domain_metadata"]
                )
                domain_results["required_fields"]["domain_name"] = has_domain_name
                if not has_domain_name:
                    all_valid = False
                    results["issues"].append(
                        f"Domain {domain_code}: missing field 'domain_name' or 'domain_metadata.title'"
                    )

                # Check for other required fields
                other_required_fields = [
                    "base_practices",
                    "policy_integration",
                    "ai_agent_context",
                ]
                for field in other_required_fields:
                    has_field = field in domain_data
                    domain_results["required_fields"][field] = has_field

                    if not has_field:
                        all_valid = False
                        results["issues"].append(
                            f"Domain {domain_code}: missing field '{field}'"
                        )

                # Count practices and bindings
                if "base_practices" in domain_data:
                    domain_results["base_practices_count"] = len(
                        domain_data["base_practices"]
                    )

                if (
                    "policy_integration" in domain_data
                    and "policy_bindings" in domain_data["policy_integration"]
                ):
                    domain_results["policy_bindings_count"] = len(
                        domain_data["policy_integration"]["policy_bindings"]
                    )

                results["domain_files"][domain_code] = domain_results

            except json.JSONDecodeError as e:
                all_valid = False
                results["issues"].append(
                    f"Domain {domain_code}: JSON decode error - {str(e)}"
                )
            except Exception as e:
                all_valid = False
                results["issues"].append(
                    f"Domain {domain_code}: validation error - {str(e)}"
                )

        return all_valid, results

    def _validate_policy_logic(self) -> tuple[bool, dict[str, Any]]:
        """Validate policy domain files."""
        logger.info("Validating policy domain")

        policy_path = self.framework_path / "policy-domain"
        results = {"policy_files": {}, "issues": []}

        if not policy_path.exists():
            return False, results

        all_valid = True
        # Updated for new policy domain structure - Sep 21 2025 JF Kalafut
        # Updated Oct 21 2025 - removed deprecated tokenIndex.json
        required_files = [
            "tokenMapByArtifact.json",
        ]

        # Check for policy template files (*.json)
        policy_templates = list(policy_path.glob("*Policy.json"))
        results["policy_templates_count"] = len(policy_templates)

        # Check for overview summary files (*-Domain-Overview-Summary.md)
        overview_files = list(policy_path.glob("*-Domain-Overview-Summary.md"))
        results["overview_files_count"] = len(overview_files)

        for file_name in required_files:
            file_path = policy_path / file_name

            if not file_path.exists():
                all_valid = False
                results["issues"].append(f"Missing policy file: {file_name}")
                continue

            try:
                with file_path.open() as f:
                    data = json.load(f)

                file_results = {"file_path": str(file_path), "valid_json": True}

                # Specific validations per file
                if file_name == "tokenMapByArtifact.json":
                    file_results["artifact_count"] = (
                        len(data) if isinstance(data, dict) else 0
                    )
                elif file_name == "wizard-guide-policy.json" and "wizardGuide" in data and "wizardSteps" in data["wizardGuide"]:
                    file_results["wizard_steps_count"] = len(
                        data["wizardGuide"]["wizardSteps"]
                    )

                results["policy_files"][file_name] = file_results

            except json.JSONDecodeError as e:
                all_valid = False
                results["issues"].append(
                    f"Policy file {file_name}: JSON decode error - {str(e)}"
                )
            except Exception as e:
                all_valid = False
                results["issues"].append(
                    f"Policy file {file_name}: validation error - {str(e)}"
                )

        return all_valid, results

    def _validate_process_model(self) -> tuple[bool, dict[str, Any]]:
        """Validate process model documentation."""
        logger.info("Validating process model")

        process_path = self.framework_path / "ash-gov-process-model"
        results = {"domain_folders": {}, "overview_files": {}, "issues": []}

        if not process_path.exists():
            return False, results

        all_valid = True
        # Updated for all 11 process domains - Sep 21 2025 JF Kalafut
        expected_domains = ["PV", "SA", "MON", "OVR", "ORG", "IT", "RM", "HO", "EF", "TR", "UG"]

        # Check for domain overview files in process-domain folder
        process_domain_path = self.framework_path / "process-domain"
        for domain in expected_domains:
            overview_file = process_domain_path / f"{domain}-Domain-Overview-Summary.md"
            results["overview_files"][domain] = {
                "exists": overview_file.exists(),
                "file_path": str(overview_file),
            }

            if not overview_file.exists():
                results["issues"].append(
                    f"Missing overview: {domain}-Domain-Overview-Summary.md"
                )

        # Check for domain folders (2-letter codes with full names)
        domain_folders = {
            "PV": "PV_Product_Validation_and_Performance",
            "SA": "SA_Safety_Assessment_and_Risk_Analysis",
            "MON": "MON_Continuous_Monitoring_and_Surveillance",
            "OVR": "OVR_Human_AI_Oversight_and_Decision_Authority",
            "ORG": "ORG_Organization_and_StrategyAlignment",
            "IT": "IT_Infrastructure_and_TechnicalControls",
            "RM": "RM_Risk_Management_and_Mitigation",
            "HO": "HO_Human_Oversight_and_Intervention",
            "EF": "EF_Ethics_and_Fairness",
            "TR": "TR_Training_and_Competency",
            "UG": "UG_User_Guidance_and_Transparency"
        }

        for domain_code, folder_name in domain_folders.items():
            domain_folder = process_path / folder_name
            if domain_folder.exists():
                # Count SOPs, work products, and other content
                sop_files = list(domain_folder.glob("SOP-*.md"))
                wp_files = list(domain_folder.glob("WP-*.md"))
                traceability_file = domain_folder / f"{domain_code}-traceability.json"

                results["domain_folders"][domain_code] = {
                    "exists": True,
                    "folder_name": folder_name,
                    "sop_count": len(sop_files),
                    "work_products_count": len(wp_files),
                    "has_traceability": traceability_file.exists(),
                    "folder_path": str(domain_folder),
                }
            else:
                results["domain_folders"][domain_code] = {
                    "exists": False,
                    "expected_folder_name": folder_name,
                    "folder_path": str(domain_folder),
                }

        return all_valid, results

    def _validate_registry(self) -> tuple[bool, dict[str, Any]]:
        """Validate the master registry file."""
        logger.info("Validating master registry")

        registry_file = self.framework_path / "process-domain-registry.json"
        results = {"registry_file": str(registry_file), "issues": []}

        if not registry_file.exists():
            return False, results

        try:
            with registry_file.open() as f:
                registry_data = json.load(f)

            # Validate structure
            required_sections = [
                "process_domains",
                "policy_domains",
                "iso42001_mappings",
            ]

            for section in required_sections:
                if section not in registry_data:
                    results["issues"].append(f"Missing registry section: {section}")

            # Count domains
            if "process_domains" in registry_data:
                results["process_domains_count"] = len(registry_data["process_domains"])

            # Count policy domains
            if "policy_domains" in registry_data:
                results["policy_domains_count"] = len(registry_data["policy_domains"])

            results["valid_json"] = True

        except json.JSONDecodeError as e:
            results["issues"].append(f"Registry JSON decode error: {str(e)}")
            return False, results
        except Exception as e:
            results["issues"].append(f"Registry validation error: {str(e)}")
            return False, results

        return len(results["issues"]) == 0, results

    def get_framework_version(self) -> Optional[str]:
        """
        Extract framework version from registry or git.

        Returns:
            Version string or None if not found
        """
        # Try to get version from registry
        registry_file = self.framework_path / "process-domain-registry.json"
        if registry_file.exists():
            try:
                with registry_file.open() as f:
                    registry_data = json.load(f)

                if "framework_version" in registry_data:
                    return registry_data["framework_version"]

            except Exception as e:
                logger.warning(f"Could not read version from registry: {e}")

        # Try to get git commit hash as version
        try:
            import subprocess

            result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=self.framework_path,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return f"git-{result.stdout.strip()}"
        except Exception as e:
            logger.warning(f"Could not get git version: {e}")

        # Fallback to timestamp
        return datetime.now().strftime("%Y%m%d-%H%M%S")

    def _validate_4tier_structure(self) -> tuple[bool, dict[str, Any]]:
        """
        Validate the new 4-tier categorization structure.

        Added Sep 21 2025 by JF Kalafut for new categorization system.

        TIER 1: CAI GOVERNANCE LEVEL
        TIER 2: POLICY DOMAIN ARTIFACTS
        TIER 3: PROCESS DOMAIN
        TIER 4: CONTROLS & TOOLS REGISTRY
        """
        logger.info("Validating 4-tier categorization structure")

        results = {
            "tier1_governance": {},
            "tier2_policy_domain": {},
            "tier3_process_domain": {},
            "tier4_controls_tools": {},
            "issues": []
        }

        all_valid = True

        # TIER 1: CAI Governance Level
        tier1_files = [
            "ashmatics-framework-registry.json",  # Updated: was master-registry.json
            "process-domain-registry.json",
            "Framework-Overview-Summary.md",  # Fixed: actual filename (was Framework-Overview.md)
            "Implementation-Reference-Guide.md",
            "Policy-Domain-Architecture.md",
            "Process-Domain-Architecture.md",
        ]

        for file_name in tier1_files:
            file_path = self.framework_path / file_name
            exists = file_path.exists()
            results["tier1_governance"][file_name] = {
                "exists": exists,
                "path": str(file_path)
            }
            if not exists:
                results["issues"].append(f"TIER 1: Missing governance file: {file_name}")

        # TIER 2: Policy Domain Artifacts
        policy_domain_path = self.framework_path / "policy-domain"
        if policy_domain_path.exists():
            overview_files = list(policy_domain_path.glob("*-Domain-Overview-Summary.md"))
            policy_templates = list(policy_domain_path.glob("*Policy.json"))
            temp_policies = list(policy_domain_path.glob("ash-*-policy-TEMP.md"))
            glue_files = list(policy_domain_path.glob("token*.json"))

            results["tier2_policy_domain"] = {
                "policy_domain_exists": True,
                "overview_files_count": len(overview_files),
                "policy_templates_count": len(policy_templates),
                "temp_policies_count": len(temp_policies),
                "glue_files_count": len(glue_files)
            }
        else:
            all_valid = False
            results["issues"].append("TIER 2: Missing policy-domain folder")
            results["tier2_policy_domain"]["policy_domain_exists"] = False

        # TIER 3: Process Domain
        process_domain_path = self.framework_path / "process-domain"
        ash_gov_path = self.framework_path / "ash-gov-process-model"

        if process_domain_path.exists():
            domain_overviews = list(process_domain_path.glob("*-Domain-Overview-Summary.md"))
            domain_definitions = list(process_domain_path.glob("*-process-domain.json"))

            results["tier3_process_domain"]["overview_definitions"] = {
                "process_domain_exists": True,
                "domain_overviews_count": len(domain_overviews),
                "domain_definitions_count": len(domain_definitions)
            }
        else:
            results["issues"].append("TIER 3: Missing process-domain folder")
            results["tier3_process_domain"]["overview_definitions"] = {"process_domain_exists": False}

        if ash_gov_path.exists():
            sop_files = list(ash_gov_path.glob("**/SOP-*.md"))
            wp_files = list(ash_gov_path.glob("**/WP-*.md"))
            base_docs = list(ash_gov_path.glob("**/AshmaticsAIGov-Area*.md"))
            wizard_guides = list(ash_gov_path.glob("**/*Wizard*.md"))
            traceability_files = list(ash_gov_path.glob("**/*traceability.json"))

            results["tier3_process_domain"]["detailed_content"] = {
                "ash_gov_exists": True,
                "sop_files_count": len(sop_files),
                "work_products_count": len(wp_files),
                "base_documents_count": len(base_docs),
                "wizard_guides_count": len(wizard_guides),
                "traceability_files_count": len(traceability_files)
            }
        else:
            results["issues"].append("TIER 3: Missing ash-gov-process-model folder")
            results["tier3_process_domain"]["detailed_content"] = {"ash_gov_exists": False}

        # TIER 4: Controls & Tools Registry
        tier4_paths = [
            ("controls", "controls_framework"),
            ("ISO-42001-maps", "iso_mappings"),
            ("tools", "tools_registry"),
            ("architecture-design", "architecture_design"),
            ("reviews-audits", "reviews_audits"),
            ("supporting-framework-docs", "supporting_docs")
        ]

        for folder_name, category in tier4_paths:
            folder_path = self.framework_path / folder_name
            exists = folder_path.exists()
            results["tier4_controls_tools"][category] = {
                "exists": exists,
                "path": str(folder_path)
            }

            if exists and folder_name == "tools":
                # Special check for tools registry files
                registry_files = list(folder_path.glob("*registry*.yaml")) + list(folder_path.glob("*registry*.yml"))
                results["tier4_controls_tools"][category]["registry_files_count"] = len(registry_files)

        # Overall tier validation
        tier_exists_count = sum([
            any(f["exists"] for f in results["tier1_governance"].values()),
            results["tier2_policy_domain"].get("policy_domain_exists", False),
            results["tier3_process_domain"]["overview_definitions"].get("process_domain_exists", False),
            results["tier3_process_domain"]["detailed_content"].get("ash_gov_exists", False),
            any(f["exists"] for f in results["tier4_controls_tools"].values())
        ])

        results["summary"] = {
            "tiers_present": tier_exists_count,
            "total_tiers": 4,
            "all_tiers_valid": tier_exists_count >= 3  # At least 3 out of 4 tiers should exist
        }

        if tier_exists_count < 3:
            all_valid = False
            results["issues"].append(f"Only {tier_exists_count}/4 tiers have content present")

        return all_valid, results
