#!/usr/bin/env python3
"""
last updated: 2025-09-25 by JF Kalafut
- changes made so that the compilation matches our aigov framework schema and 4-tier categorization system;

MongoDB Framework Content Compiler

Compiles framework Markdown content into JSON views for efficient agent/wizard consumption
and stores them in MongoDB following the hybrid persistence strategy.

UPDATED 2025-09-21 by JF Kalafut:
- Added YAML content support
- Refactored to support our new governance framework content structure and 4-tier categorization system
- Improved error handling and logging




"""

import hashlib
import json
import logging
import re
from datetime import datetime
from typing import Any

# Governance document models from ashmatics-datamodels (ASHKBAPP-47)
from ashmatics_datamodels.documents import (
    # Enums
    ContentFormat,
    # Document types
    ControlsDocument,
    DomainType,
    # Content components
    EmbeddingsMeta,
    FrameworkDocument,
    GovernanceCategory,
    GovernanceCitation,
    GovernanceContent,
    GovernanceContentType,
    GovernanceDocumentBase,
    GovernanceMetadataContent,
    GovernancePlaceholder,
    GovernanceSection,
    GovernanceSubcategory,
    PolicyBinding,
    PolicyDocument,
    ProcessDocument,
    ProcessDomainCode,
    SOPDocument,
    TraceabilityInfo,
    WorkProductDocument,
)
from pydantic import ValidationError

# MongoDB imports (will need to be installed)
try:
    from pymongo import MongoClient
    from pymongo.collection import Collection
    from pymongo.database import Database

    PYMONGO_AVAILABLE = True
except ImportError:
    PYMONGO_AVAILABLE = False
    logging.warning("PyMongo not available. Install with: pip install pymongo")

# Markdown processing imports
try:
    import markdown

    MARKDOWN_AVAILABLE = True
except ImportError:
    MARKDOWN_AVAILABLE = False
    logging.warning(
        "Markdown library not available. Install with: pip install markdown"
    )

logger = logging.getLogger(__name__)

# Constants
MAX_CONTEXT_LENGTH = 200  # Maximum length for context strings in placeholders/bindings


class FrameworkContentCompiler:
    """
    Compiles framework Markdown content into structured JSON views for MongoDB storage.

    CThis class provides a unified interface for converting various content formats
    into structured JSON documents optimized for AI agent consumption. It handles
    content parsing, metadata extraction, policy binding detection, and maintains
    traceability information throughout the compilation process.

    Key Features:
    - Multi-format support: Markdown, YAML, JSON
    - Automated metadata extraction and validation
    - Policy binding detection and cross-referencing
    - Semantic section parsing with placeholder support
    - Batch processing capabilities with error handling
    - MongoDB upsert operations with version control

    Database Schema:
    - Primary keys: artifact_id, semver, relative_path
    - Content categorization: 4-tier system (framework_tools, etc.)
    - Standardized content types: markdown, yaml, json
    - Traceability: source paths, timestamps, compilation metadata

    Args:
        connection_string: MongoDB connection URI
        database_name: Target database name (default: "ashmatics_framework")
        collection_name: Target collection name (default: "compiled_views")
    """

    def __init__(
        self,
        mongo_connection_string: str,
        database_name: str = "ashmatics_kb",
        collection_name: str = "framework_compiled_views",
    ):
        """
        Initialize the MongoDB compiler.

        Args:
            mongo_connection_string: MongoDB connection string (CosmosDB compatible)
            database_name: Database name for compiled views
            collection_name: Collection name for compiled views
        """
        if not PYMONGO_AVAILABLE:
            raise ImportError("PyMongo required. Install with: pip install pymongo")

        if not MARKDOWN_AVAILABLE:
            raise ImportError(
                "Markdown library required. Install with: pip install markdown"
            )

        self.connection_string = mongo_connection_string
        self.database_name = database_name
        self.collection_name = collection_name

        # Initialize MongoDB client
        self.client: MongoClient = None
        self.db: Database = None
        self.collection: Collection = None

        # Initialize Markdown processor
        self.md_processor = markdown.Markdown(
            extensions=["meta", "toc", "codehilite", "tables", "fenced_code"]
        )

        logger.info(
            f"Initialized FrameworkContentCompiler for {database_name}.{collection_name}"
        )

    def connect(self) -> bool:
        """Establish MongoDB connection."""
        try:
            self.client = MongoClient(
                self.connection_string,
                serverSelectionTimeoutMS=30000,  # 30 second timeout
                connectTimeoutMS=30000,
                socketTimeoutMS=30000,
            )

            # Test connection
            self.client.admin.command("ping")

            self.db = self.client[self.database_name]
            self.collection = self.db[self.collection_name]

            logger.info("✅ Connected to MongoDB")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to connect to MongoDB: {str(e)}")
            return False

    def disconnect(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
            logger.info("🔌 Disconnected from MongoDB")

    def compile_markdown_content(
        self, content: str, artifact_info: dict[str, Any]
    ) -> dict[str, Any] | None:
        """
        Compile Markdown content into structured JSON view using Pydantic models.

        Uses governance document models from ashmatics-datamodels for type safety
        and validation. Returns serialized dict for backward compatibility.

        Args:
            content: Raw Markdown content
            artifact_info: Metadata about the artifact (path, category, etc.)

        Returns:
            Compiled JSON view dictionary (serialized from Pydantic model)
        """
        try:
            # Reset markdown processor
            self.md_processor.reset()

            # Process markdown to HTML and extract metadata
            self.md_processor.convert(content)

            # Extract metadata from Markdown
            metadata = getattr(self.md_processor, "Meta", {})

            # Parse content structure
            sections = self._parse_sections(content)
            placeholders = self._extract_placeholders(content)
            policy_bindings = self._extract_policy_bindings(content)
            traceability_data = self._extract_traceability_info(content, artifact_info)
            citations = self._extract_citations(content)

            # Generate content hash for integrity
            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()

            # Build GovernanceMetadataContent (Tier 2) - ASHKBAPP-47
            # Convert string values to enums where applicable
            content_category_str = artifact_info.get("content_category", "")
            subcategory_str = artifact_info.get("subcategory", "")
            content_format_str = artifact_info.get("content_format", "markdown")
            domain_type_str = artifact_info.get("domain_type", "governance")
            process_domain_str = artifact_info.get("process_domain", "")

            # Safe enum conversion with fallbacks and warning logs
            try:
                content_category = GovernanceCategory(content_category_str)
            except ValueError:
                logger.warning(
                    f"Invalid content_category '{content_category_str}', "
                    "falling back to CAI_GOVERNANCE"
                )
                content_category = GovernanceCategory.CAI_GOVERNANCE

            try:
                subcategory = GovernanceSubcategory(subcategory_str)
            except ValueError:
                logger.warning(
                    f"Invalid subcategory '{subcategory_str}', "
                    "falling back to CAI_GOVERNANCE_OVERVIEW"
                )
                subcategory = GovernanceSubcategory.CAI_GOVERNANCE_OVERVIEW

            try:
                content_format = ContentFormat(content_format_str)
            except ValueError:
                logger.warning(
                    f"Invalid content_format '{content_format_str}', "
                    "falling back to MARKDOWN"
                )
                content_format = ContentFormat.MARKDOWN

            try:
                domain_type = DomainType(domain_type_str)
            except ValueError:
                logger.warning(
                    f"Invalid domain_type '{domain_type_str}', "
                    "falling back to GOVERNANCE"
                )
                domain_type = DomainType.GOVERNANCE

            process_domain_code = None
            if process_domain_str:
                try:
                    process_domain_code = ProcessDomainCode(process_domain_str)
                except ValueError:
                    logger.warning(
                        f"Invalid process_domain '{process_domain_str}', "
                        "keeping as None"
                    )

            metadata_content = GovernanceMetadataContent(
                title=self._extract_title(content, metadata, artifact_info),
                artifact_id=artifact_info.get("artifact_id", ""),
                framework_version=artifact_info.get("framework_version", "0.1.0"),
                relative_path=artifact_info.get("relative_path", ""),
                content_category=content_category,
                subcategory=subcategory,
                subcategory_label=artifact_info.get("subcategory_label", ""),
                process_domain_code=process_domain_code,
                content_format=content_format,
                domain_type=domain_type,
                domain_code=artifact_info.get("domain_code", ""),
                domain_name=artifact_info.get("domain_name", ""),
                control_type=artifact_info.get("control_type"),
                content_hash=content_hash,
            )

            # Build GovernanceSection list from parsed sections
            governance_sections = [
                GovernanceSection(
                    level=s.get("level", 1),
                    title=s.get("title", ""),
                    anchor=s.get("anchor", ""),
                    content=s.get("content", ""),
                    subsections=[],  # Flatten for now
                )
                for s in sections
            ]

            # Build GovernancePlaceholder list
            governance_placeholders = [
                GovernancePlaceholder(
                    token=p.get("token", ""),
                    name=p.get("name", ""),
                    required=p.get("required", False),
                    context=p.get("context", "")[:MAX_CONTEXT_LENGTH],
                )
                for p in placeholders
            ]

            # Build PolicyBinding list
            governance_bindings = [
                PolicyBinding(
                    binding_type=b.get("type", "policy"),
                    code=b.get("code", ""),
                    reference=b.get("reference", ""),
                    context=b.get("context", "")[:MAX_CONTEXT_LENGTH],
                )
                for b in policy_bindings
            ]

            # Build TraceabilityInfo
            traceability = TraceabilityInfo(
                process_outputs=traceability_data.get("process_outputs", []),
                contributes_to=traceability_data.get("contributes_to", []),
                depends_on=traceability_data.get("depends_on", []),
                traceability_file=traceability_data.get("traceability_file"),
            )

            # Build GovernanceCitation list
            governance_citations = [
                GovernanceCitation(
                    text=c.get("text", ""),
                    url=c.get("url"),
                    citation_type=c.get("type", "reference"),
                )
                for c in citations
            ]

            # Build EmbeddingsMeta
            embeddings_meta = EmbeddingsMeta(
                needs_embedding=True,
                embedding_model=None,
                embedding_vector=None,
            )

            # Build GovernanceContent (Tier 3)
            governance_content = GovernanceContent(
                governance_sections=governance_sections,
                placeholders=governance_placeholders,
                policy_bindings=governance_bindings,
                traceability=traceability,
                citations=governance_citations,
                normative_refs=self._extract_normative_refs(content),
                outputs_contribute_to=self._extract_outputs(content),
                tokens_required=self._estimate_tokens(content),
                embeddings_meta=embeddings_meta,
                source_metadata=metadata if isinstance(metadata, dict) else {},
                governance_content_type=GovernanceContentType.COMPILED_MARKDOWN,
            )

            # Determine document type and create model
            doc_type = self._determine_document_type(artifact_info)
            document = doc_type(
                metadata_content=metadata_content,
                content=governance_content,
            )

            # Serialize to dict for backward compatibility
            compiled_view = document.model_dump(by_alias=True, exclude_none=True)

            # Add legacy fields for backward compatibility with existing consumers
            # Add legacy fields for backward compatibility, but avoid overwriting existing keys
            legacy_fields = {
                "artifact_id": artifact_info.get("artifact_id"),
                "semver": artifact_info.get("framework_version"),
                "relative_path": artifact_info.get("relative_path"),
                "content_category": content_category_str,
                "subcategory": subcategory_str,
                "process_domain": process_domain_str,
                "content_format": content_format_str,
                "_content_type": "compiled_markdown",
                "_content_hash": content_hash,
            }
            for key, value in legacy_fields.items():
                if key in compiled_view:
                    logger.warning(f"Backward compatibility field '{key}' already exists in compiled_view. Skipping addition to avoid overwrite.")
                    continue
                compiled_view[key] = value

            return compiled_view

        except ValidationError as e:
            relative_path = artifact_info.get("relative_path", "unknown")
            logger.error(
                f"Pydantic validation error compiling markdown content "
                f"for '{relative_path}': {e}"
            )
            return None
        except Exception as e:
            relative_path = artifact_info.get("relative_path", "unknown")
            logger.error(
                f"Error compiling markdown content for '{relative_path}': {e}"
            )
            return None

    def store_json_content(
        self, content: str, artifact_info: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Store JSON content directly in MongoDB with standardized metadata.
        No compilation needed - JSON is MongoDB's native format.

        Args:
            content: Raw JSON content as string
            artifact_info: Metadata about the artifact (path, category, etc.)

        Returns:
            Document with standardized metadata + direct JSON content
        """
        try:
            # Parse JSON content
            json_data = json.loads(content)

            # Generate content hash for integrity
            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()

            # Create document with standardized metadata (underscore prefixed)
            document = {
                # STANDARDIZED METADATA
                "artifact_id": artifact_info.get("artifact_id"),
                "semver": artifact_info.get("framework_version"),
                "relative_path": artifact_info.get("relative_path"),
                "content_category": artifact_info.get("content_category"),
                "subcategory": artifact_info.get("subcategory"),
                "subcategory_label": artifact_info.get("subcategory_label"),
                "process_domain": artifact_info.get("process_domain"),
                "content_format": artifact_info.get("content_format"),
                "_content_type": "json_native",
                "_framework_schema": "v1",
                "_stored_at": datetime.utcnow().isoformat(),
                "_content_hash": content_hash,
                "_source": "framework_content_importer",

                # DOMAIN METADATA (consistent with PostgreSQL schema)
                "domain_type": artifact_info.get("domain_type"),
                "domain_code": artifact_info.get("domain_code"),
                "domain_name": artifact_info.get("domain_name"),
                "control_type": artifact_info.get("control_type"),
            }

            # Add all JSON content directly to document (no wrapper)
            document.update(json_data)

            return document

        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON content: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error storing JSON content: {str(e)}")
            return None

    def store_yaml_content(
        self, content: str, artifact_info: dict[str, Any]
    ) -> dict[str, Any]:
        """
        arse and store YAML content as a compiled JSON view in MongoDB.

    This method handles the complete YAML processing workflow including:
    - YAML parsing with error handling for malformed content
    - Metadata extraction and validation against framework standards
    - Content categorization using the 4-tier system
    - Policy binding detection for governance frameworks
    - Traceability information compilation
    - MongoDB upsert with version control

    The compiled view maintains the original YAML structure while adding
    standardized metadata fields for AI agent consumption.

    Args:
        yaml_content: Raw YAML content string to be processed
        metadata: Source metadata dictionary containing:
            - relative_path: File path relative to framework root
            - artifact_id: Unique identifier for the content artifact
            - semver: Semantic version string
            - last_modified: ISO timestamp of last modification
            - source_hash: Content hash for change detection

    Returns:
        tuple[bool, str]: Success status and result message
            - (True, document_id): Successful storage with MongoDB document ID
            - (True, "updated"): Existing document was updated
            - (True, "no_change"): No changes detected, document unchanged
            - (False, error_msg): Processing or storage failure with error details

    Raises:
        yaml.YAMLError: When YAML content is malformed or invalid
        pymongo.errors.PyMongoError: When MongoDB operations fail

    Example:
        >>> metadata = {
        ...     "relative_path": "tools/policy_framework.yaml",
        ...     "artifact_id": "gov_framework_v2",
        ...     "semver": "2.1.0"
        ... }
        >>> success, result = compiler.store_yaml_content(yaml_str, metadata)
        >>> print(f"Storage result: {result}")
        """
        try:
            # Import YAML library (install with: pip install pyyaml)
            try:
                import yaml
            except ImportError:
                logger.error("PyYAML not available. Install with: pip install pyyaml")
                return None

            # Parse YAML content to JSON
            yaml_data = yaml.safe_load(content)

            # Generate content hash for integrity
            content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()

            # Create document with standardized metadata (underscore prefixed)
            document = {
                # STANDARDIZED METADATA
                "artifact_id": artifact_info.get("artifact_id"),
                "semver": artifact_info.get("framework_version"),
                "relative_path": artifact_info.get("relative_path"),
                "content_category": artifact_info.get("content_category"),
                "subcategory": artifact_info.get("subcategory"),
                "subcategory_label": artifact_info.get("subcategory_label"),
                "process_domain": artifact_info.get("process_domain"),
                "content_format": artifact_info.get("content_format"),
                "_content_type": "yaml_native",
                "_framework_schema": "v1",
                "_stored_at": datetime.utcnow().isoformat(),
                "_content_hash": content_hash,
                "_source": "framework_content_importer",

                # DOMAIN METADATA (consistent with PostgreSQL schema)
                "domain_type": artifact_info.get("domain_type"),
                "domain_code": artifact_info.get("domain_code"),
                "domain_name": artifact_info.get("domain_name"),
                "control_type": artifact_info.get("control_type"),
            }

            # Add all YAML content directly to document (no wrapper)
            if yaml_data:
                # Convert any datetime.date objects to strings for MongoDB compatibility
                yaml_data = self._convert_dates_to_strings(yaml_data)
                document.update(yaml_data)

            return document

        except yaml.YAMLError as e:
            logger.error(f"Error parsing YAML content: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error storing YAML content: {str(e)}")
            return None

    def _parse_sections(self, content: str) -> list[dict[str, Any]]:
        """
        Parse content into structured sections with semantic analysis.

        This method performs intelligent content parsing to extract meaningful
        sections from Markdown or text content. It identifies:
        - Hierarchical heading structures (H1-H6)
        - Content blocks with semantic meaning
        - Cross-references and internal links
        - Code blocks and examples
        - Policy binding declarations
        - Placeholder patterns for dynamic content

        The parsing uses regex patterns optimized for clinical AI governance
        frameworks and maintains section relationships for navigation.

        Args:
            content: Raw content string (Markdown, text, or mixed format)

        Returns:
            dict[str, Any]: Structured sections dictionary with keys:
                - "sections": List of section objects with title, content, level
                - "headings": Hierarchical heading structure
                - "cross_refs": Internal reference mappings
                - "code_blocks": Extracted code examples with language tags
                - "metadata_blocks": YAML frontmatter or embedded metadata
                - "toc": Generated table of contents structure

        Note:
        This method is optimized for framework content and may not handle
        arbitrary Markdown formats. It expects content to follow the
        AshMatics CAI framework conventions.


        """
        sections = []

        # Split content by headers (## or ###)
        header_pattern = r"^(#{1,6})\s+(.+)$"
        lines = content.split("\n")

        current_section = None
        current_content = []

        for line in lines:
            header_match = re.match(header_pattern, line)

            if header_match:
                # Save previous section
                if current_section:
                    current_section["content"] = "\n".join(current_content).strip()
                    sections.append(current_section)

                # Start new section
                level = len(header_match.group(1))
                title = header_match.group(2).strip()

                current_section = {
                    "level": level,
                    "title": title,
                    "anchor": self._generate_anchor(title),
                    "content": "",
                    "subsections": [],
                }
                current_content = []
            else:
                if current_section:
                    current_content.append(line)

        # Add final section
        if current_section:
            current_section["content"] = "\n".join(current_content).strip()
            sections.append(current_section)

        return sections

    def _extract_placeholders(self, content: str) -> list[dict[str, str]]:
        """
        Extract placeholder patterns for dynamic content substitution.

        Identifies placeholder patterns used in framework templates that require
        runtime substitution. Supports multiple placeholder formats commonly
        used in clinical AI governance frameworks:
        - Mustache style: {{variable_name}}
        - Jinja2 style: {{variable_name}} and {% block_name %}
        - Custom framework: ${VARIABLE_NAME}
        - Environment variables: $ENV_VAR and ${ENV_VAR}

        Args:
            content: Source content string to scan for placeholders

        Returns:
            list[str]: Unique placeholder names found in content, normalized
                    to remove syntax markers (e.g., "{{user_id}}" → "user_id")

        Example:
            >>> content = "Welcome {{user_name}} to ${SYSTEM_NAME}"
            >>> placeholders = compiler._extract_placeholders(content)
            >>> print(placeholders)  # ["user_name", "SYSTEM_NAME"]

        """
        placeholders = []

        # Pattern for placeholders: {{PLACEHOLDER_NAME}} or {{{REQUIRED_FIELD}}}
        placeholder_pattern = r"\{\{([^}]+)\}\}"

        matches = re.finditer(placeholder_pattern, content)
        for match in matches:
            placeholder_text = match.group(1).strip()
            placeholders.append(
                {
                    "token": f"{{{{{placeholder_text}}}}}",
                    "name": placeholder_text,
                    "required": placeholder_text.isupper(),
                    "context": self._get_surrounding_context(
                        content, match.start(), match.end()
                    ),
                }
            )

        return placeholders

    def _extract_policy_bindings(self, content: str) -> list[dict[str, Any]]:
        """Extract policy binding references from content."""
        policy_bindings = []

        # Look for policy references (e.g., "Policy PV-01" or "Process EF-09")
        policy_pattern = r"(Policy|Process)\s+([A-Z]{2}-\d{2})"

        matches = re.finditer(policy_pattern, content)
        for match in matches:
            binding_type = match.group(1).lower()
            binding_code = match.group(2)

            policy_bindings.append(
                {
                    "type": binding_type,
                    "code": binding_code,
                    "reference": match.group(0),
                    "context": self._get_surrounding_context(
                        content, match.start(), match.end()
                    ),
                }
            )

        return policy_bindings

    def _extract_traceability_info(
        self, content: str, artifact_info: dict[str, Any]
    ) -> dict[str, Any]:
        """Extract traceability information from content and artifact metadata."""
        traceability = {
            "process_outputs": [],
            "contributes_to": [],
            "depends_on": [],
            "traceability_file": None,
        }

        # Check if this is a traceability JSON file
        if artifact_info.get("relative_path", "").endswith("-traceability.json"):
            try:
                traceability_data = json.loads(content)
                traceability.update(traceability_data)
            except json.JSONDecodeError:
                logger.warning(
                    f"Failed to parse traceability JSON: {artifact_info.get('relative_path')}"
                )

        # Extract "Contributes to Process Output" information
        output_pattern = r"Contributes to Process Output\(s\):\s*(.+)"
        output_matches = re.finditer(output_pattern, content, re.IGNORECASE)

        for match in output_matches:
            outputs = [o.strip() for o in match.group(1).split(",")]
            traceability["contributes_to"].extend(outputs)

        return traceability

    def _extract_citations(self, content: str) -> list[dict[str, str]]:
        """Extract citations and references from content."""
        citations = []

        # Pattern for various citation formats
        citation_patterns = [
            r"\[([^\]]+)\]\(([^)]+)\)",  # Markdown links
            r"https?://[^\s]+",  # Plain URLs
            r"DOI:\s*([^\s]+)",  # DOI references
            r"ISBN:\s*([^\s]+)",  # ISBN references
        ]

        for pattern in citation_patterns:
            matches = re.finditer(pattern, content)
            for match in matches:
                if len(match.groups()) >= 2:
                    # Markdown link format
                    citations.append(
                        {"text": match.group(1), "url": match.group(2), "type": "link"}
                    )
                else:
                    # Other formats
                    citations.append(
                        {
                            "text": match.group(0),
                            "url": match.group(0)
                            if match.group(0).startswith("http")
                            else None,
                            "type": "reference",
                        }
                    )

        return citations

    # DEPRECATED 2025-09-21 by JF Kalafut: Removed _determine_artifact_type()
    # Legacy method replaced by standardized content_category field
    # from 4-tier categorization system

    def _extract_title(self, content: str, metadata: dict, artifact_info: dict) -> str:
        """
        Extract title with filename as primary source for CAI content management consistency.

        Priority order:
        1. Clean filename from relative_path (primary source for CAI system)
        2. Metadata title (if different from filename, use filename)
        3. First # header in content
        4. "Untitled" (last resort)
        """
        # Extract clean filename as primary title source
        relative_path = artifact_info.get("relative_path", "")
        if relative_path:
            filename_title = self._clean_filename_to_title(relative_path)
            if filename_title:
                # Use filename as primary source - this ensures consistency with CAI content management
                return filename_title

        # Check metadata as secondary source
        if metadata and "title" in metadata:
            metadata_title = (
                metadata["title"][0]
                if isinstance(metadata["title"], list)
                else metadata["title"]
            )
            if metadata_title and metadata_title.strip():
                return metadata_title.strip()

        # Extract from first header as tertiary source
        header_match = re.match(r"^#\s+(.+)$", content, re.MULTILINE)
        if header_match:
            return header_match.group(1).strip()

        return "Untitled"

    def _clean_filename_to_title(self, relative_path: str) -> str:
        """
        Convert filename to clean title for CAI content management consistency.

        Examples:
        - "SOP-EF-01-Ethical-Framework-Process.md" → "SOP EF 01 Ethical Framework Process"
        - "WP-RM-02-Risk-Management-Framework.md" → "WP RM 02 Risk Management Framework"
        - "humanOversight-Domain-Overview-Summary.md" → "humanOversight Domain Overview Summary"
        """
        import os

        # Get just the filename without path and extension
        filename = os.path.splitext(os.path.basename(relative_path))[0]

        # Clean up the filename to make it a readable title
        # Replace hyphens and underscores with spaces
        title = filename.replace("-", " ").replace("_", " ")

        # Remove extra whitespace
        title = re.sub(r'\s+', ' ', title).strip()

        # Return empty string if invalid
        if not title or title.isspace():
            return ""

        return title

    def _generate_anchor(self, title: str) -> str:
        """Generate URL anchor from title."""
        return re.sub(r"[^a-zA-Z0-9\-_]", "-", title.lower()).strip("-")

    def _get_surrounding_context(
        self, content: str, start: int, end: int, context_chars: int = 100
    ) -> str:
        """Get surrounding context for a match."""
        context_start = max(0, start - context_chars)
        context_end = min(len(content), end + context_chars)
        return content[context_start:context_end].strip()

    def _estimate_tokens(self, content: str) -> int:
        """Estimate token count for the content."""
        # Simple estimation: ~4 characters per token
        return len(content) // 4

    def _determine_document_type(
        self, artifact_info: dict[str, Any]
    ) -> type[GovernanceDocumentBase]:
        """
        Determine which governance document type to use based on artifact info.

        Uses the subcategory field to select the appropriate Pydantic model class.
        Falls back to FrameworkDocument for unrecognized subcategories.

        Args:
            artifact_info: Metadata about the artifact including subcategory

        Returns:
            The appropriate GovernanceDocumentBase subclass
        """
        # Mapping from normalized subcategory to document type
        subcategory_doc_type_map = {
            "sop": SOPDocument,
            "standard operating procedure": SOPDocument,
            "work_product": WorkProductDocument,
            "work product": WorkProductDocument,
            "wizard": WorkProductDocument,
            "policy": PolicyDocument,
            "process_base": ProcessDocument,
            "process base": ProcessDocument,
            "controls": ControlsDocument,
            "iso": ControlsDocument,
        }

        subcategory = artifact_info.get("subcategory", "")
        normalized_subcategory = subcategory.strip().lower().replace("_", " ")

        # Try direct match
        if normalized_subcategory in subcategory_doc_type_map:
            return subcategory_doc_type_map[normalized_subcategory]

        # Try partial match (for legacy or variant subcategories)
        for key, doc_type in subcategory_doc_type_map.items():
            if key in normalized_subcategory:
                return doc_type

        return FrameworkDocument
    def _extract_outputs(self, content: str) -> list[str]:
        """Extract what this content outputs or contributes to."""
        outputs = []

        # Look for output indicators
        output_patterns = [
            r"outputs?:\s*(.+)",
            r"produces:\s*(.+)",
            r"generates:\s*(.+)",
            r"contributes to:\s*(.+)",
        ]

        for pattern in output_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                items = [item.strip() for item in match.group(1).split(",")]
                outputs.extend(items)

        return outputs

    def _extract_normative_refs(self, content: str) -> list[str]:
        """Extract normative references (standards, regulations, etc.)."""
        refs = []

        # Common normative reference patterns
        ref_patterns = [
            r"ISO\s+\d+",
            r"NIST\s+[\w\-]+",
            r"FDA\s+[\w\-]+",
            r"HIPAA",
            r"GDPR",
            r"SOX",
            r"21\s+CFR\s+\d+",
        ]

        for pattern in ref_patterns:
            matches = re.finditer(pattern, content)
            refs.extend([match.group(0) for match in matches])

        return list(set(refs))  # Remove duplicates

    def store_compiled_view(
        self, compiled_view: dict[str, Any] | GovernanceDocumentBase
    ) -> tuple[bool, str]:
        """
        Store compiled view in MongoDB.

        Accepts either a raw dict or a Pydantic GovernanceDocumentBase model.
        If a model is provided, it will be serialized via model_dump().

        Args:
            compiled_view: Compiled JSON view dictionary or Pydantic model

        Returns:
            Tuple of (success, message/document_id)
        """
        try:
            if self.collection is None and not self.connect():
                return False, "MongoDB connection failed"

            # Serialize Pydantic model if provided, otherwise use dict directly
            if isinstance(compiled_view, GovernanceDocumentBase):
                document_dict = compiled_view.model_dump(by_alias=True, exclude_none=True)
            else:
                document_dict = compiled_view

            # Create index key for upsert
            query_key = {
                "artifact_id": document_dict["artifact_id"],
                "semver": document_dict["semver"],
                "relative_path": document_dict["relative_path"],
            }

            # Upsert the document
            result = self.collection.replace_one(query_key, document_dict, upsert=True)

            if result.upserted_id:
                return True, str(result.upserted_id)
            elif result.modified_count > 0:
                return True, "updated"
            else:
                return True, "no_change"

        except Exception as e:
            logger.error(f"Error storing compiled view: {str(e)}")
            return False, str(e)

    def batch_store_views(
        self, compiled_views: list[dict[str, Any] | GovernanceDocumentBase]
    ) -> tuple[int, int]:
        """
        Store multiple compiled views in batch.

        Accepts a list of dicts or Pydantic GovernanceDocumentBase models.

        Args:
            compiled_views: List of compiled view dictionaries or Pydantic models

        Returns:
            Tuple of (successful_count, failed_count)
        """
        successful = 0
        failed = 0

        for view in compiled_views:
            success, message = self.store_compiled_view(view)
            if success:
                successful += 1
                if successful % 10 == 0:
                    logger.info(f"Stored {successful} compiled views...")
            else:
                failed += 1
                logger.error(
                    f"Failed to store view for {view.get('relative_path', 'unknown')}: {message}"
                )

        return successful, failed

    def get_collection_stats(self) -> dict[str, Any]:
        """Get statistics about the compiled views collection."""
        try:
            if self.collection is None and not self.connect():
                return {"error": "MongoDB connection failed"}

            stats = {
                "total_documents": self.collection.count_documents({}),
                "collection_name": self.collection_name,
                "database_name": self.database_name,
            }

            # Get breakdown by content type (standardized)
            content_type_pipeline = [
                {"$group": {"_id": "$_content_type", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}},
            ]

            content_type_breakdown = list(self.collection.aggregate(content_type_pipeline))
            stats["content_types"] = {
                item["_id"]: item["count"] for item in content_type_breakdown
            }

            # Get breakdown by content category (4-tier system)
            category_pipeline = [
                {"$group": {"_id": "$content_category", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}},
            ]

            category_breakdown = list(self.collection.aggregate(category_pipeline))
            stats["content_categories"] = {
                item["_id"]: item["count"] for item in category_breakdown
            }

            return stats

        except Exception as e:
            logger.error(f"Error getting collection stats: {str(e)}")
            return {"error": str(e)}

    def delete_version(self, version: str) -> dict[str, Any]:
        """
        Delete compiled views by framework version.

        Added Sep 21 2025 by JF Kalafut for version cleanup functionality.

        Args:
            version: Framework version to delete (e.g., "2025.09.21-120000")

        Returns:
            Dictionary with deletion results
        """
        logger.info(f"Deleting MongoDB compiled views for version: {version}")

        try:
            if self.collection is None and not self.connect():
                return {
                    "version": version,
                    "deleted_documents": 0,
                    "success": False,
                    "error": "MongoDB connection failed"
                }

            # Delete all documents with matching framework_version
            result = self.collection.delete_many({"framework_version": version})

            logger.info(f"Deleted {result.deleted_count} MongoDB compiled views for version {version}")

            return {
                "version": version,
                "deleted_documents": result.deleted_count,
                "success": result.acknowledged,
                "acknowledged": result.acknowledged
            }

        except Exception as e:
            error_msg = f"Error deleting MongoDB version {version}: {str(e)}"
            logger.error(error_msg)
            return {
                "version": version,
                "deleted_documents": 0,
                "success": False,
                "error": error_msg
            }

    def get_versions(self) -> list[str]:
        """
        Get distinct framework versions in MongoDB collection.

        Added Sep 21 2025 by JF Kalafut for version discovery.

        Returns:
            List of distinct framework versions, sorted with most recent first
        """
        logger.info("Discovering framework versions in MongoDB")

        try:
            if self.collection is None and not self.connect():
                logger.error("MongoDB connection failed")
                return []
            # Get distinct framework_version values - note: using semver as the version name iterator..
            versions = self.collection.distinct("semver")

            # Filter out None/null values and sort
            valid_versions = [v for v in versions if v is not None]
            sorted_versions = sorted(valid_versions, reverse=True)  # Most recent first

            logger.info(f"Found {len(sorted_versions)} framework versions in MongoDB")
            return sorted_versions

        except Exception as e:
            logger.error(f"Error getting MongoDB versions: {str(e)}")
            return []

    def delete_by_filter(self, filter_conditions: dict[str, Any]) -> dict[str, Any]:
        """
        Delete compiled views by custom filter conditions.

        Added Sep 21 2025 by JF Kalafut for flexible deletion.

        Args:
            filter_conditions: MongoDB filter conditions

        Returns:
            Dictionary with deletion results
        """
        logger.info(f"Deleting MongoDB compiled views with filter: {filter_conditions}")

        try:
            if self.collection is None and not self.connect():
                return {
                    "filter": filter_conditions,
                    "deleted_documents": 0,
                    "success": False,
                    "error": "MongoDB connection failed"
                }

            # Delete documents matching filter
            result = self.collection.delete_many(filter_conditions)

            logger.info(f"Deleted {result.deleted_count} MongoDB compiled views with custom filter")

            return {
                "filter": filter_conditions,
                "deleted_documents": result.deleted_count,
                "success": result.acknowledged,
                "acknowledged": result.acknowledged
            }

        except Exception as e:
            error_msg = f"Error deleting MongoDB documents with filter {filter_conditions}: {str(e)}"
            logger.error(error_msg)
            return {
                "filter": filter_conditions,
                "deleted_documents": 0,
                "success": False,
                "error": error_msg
            }

    def delete_by_category(self, content_category: str, version: str = None) -> dict[str, Any]:
        """
        Delete compiled views by content category, optionally filtered by version.

        Added Sep 21 2025 by JF Kalafut for selective deletion.

        Args:
            content_category: Content category to delete (e.g., "policy_domain_overview_content")
            version: Optional framework version filter

        Returns:
            Dictionary with deletion results
        """
        logger.info(f"Deleting MongoDB compiled views for category: {content_category}, version: {version}")

        try:
            if self.collection is None and not self.connect():
                return {
                    "content_category": content_category,
                    "version": version,
                    "deleted_documents": 0,
                    "success": False,
                    "error": "MongoDB connection failed"
                }

            # Build filter
            filter_conditions = {"content_category": content_category}
            if version:
                filter_conditions["framework_version"] = version

            # Delete documents matching filter
            result = self.collection.delete_many(filter_conditions)

            logger.info(f"Deleted {result.deleted_count} MongoDB compiled views for category {content_category}")

            return {
                "content_category": content_category,
                "version": version,
                "filter": filter_conditions,
                "deleted_documents": result.deleted_count,
                "success": result.acknowledged,
                "acknowledged": result.acknowledged
            }

        except Exception as e:
            error_msg = f"Error deleting MongoDB category {content_category}: {str(e)}"
            logger.error(error_msg)
            return {
                "content_category": content_category,
                "version": version,
                "deleted_documents": 0,
                "success": False,
                "error": error_msg
            }

    def _convert_dates_to_strings(self, data):
        """
        Recursively convert datetime.date objects to ISO format strings for MongoDB compatibility.

        Args:
            data: Any Python object (dict, list, primitive, etc.)

        Returns:
            Object with datetime.date objects converted to strings
        """
        import datetime

        if isinstance(data, datetime.date) and not isinstance(data, datetime.datetime):
            # Convert date to ISO string format
            return data.isoformat()
        elif isinstance(data, dict):
            # Recursively process dictionary values
            return {key: self._convert_dates_to_strings(value) for key, value in data.items()}
        elif isinstance(data, list):
            # Recursively process list items
            return [self._convert_dates_to_strings(item) for item in data]
        else:
            # Return unchanged for other types
            return data
