# Copyright (c) 2026, Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Regulatory YAML Parser for ASHCAI Ontology

Created: 2026-01-19 (ASHPSTUDIO-183)

Parses regulatory crosswalk YAML files (*-logic.yaml) from the
ashmatics-policy-process-builder/wizard-content-schemas/ directory
and transforms them into ASHCAI-compatible structures for ontology population.

Supported Regulatory Frameworks:
- NIST AI RMF (nist-rmf-logic.yaml)
- Joint Commission RUAIH (jc-ruaih-logic.yaml)
- ONC HTI-1 (onc-hti1-logic.yaml)
- Colorado AI Act (colorado-ai-act-logic.yaml)
- ACA Section 1557 (aca-section-1557-logic.yaml)

Each YAML file maps regulatory requirements to:
- Policy domains (e.g., AGP-001, MMP-001)
- Exemplar controls (e.g., EXC-A4-01)
- Process domains and base practices (e.g., MON, RM.BP01)
- Work products (e.g., WP-MON-01-Dashboard)
"""

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


# ============================================================================
# Data Classes for Parsed Regulatory Content
# ============================================================================


@dataclass
class RegulatorySubcategory:
    """A specific subcategory/sub-requirement within a regulatory requirement."""

    id: str
    description: str
    implementation_priority: str = "medium"


@dataclass
class PolicySection:
    """A policy section that addresses regulatory requirements."""

    section: str
    description: str
    token: str | None = None
    addresses: list[str] = field(default_factory=list)


@dataclass
class PolicyMapping:
    """Mapping from a policy to regulatory requirements."""

    policy_id: str
    policy_name: str | None = None
    sections: list[PolicySection] = field(default_factory=list)


@dataclass
class ControlMapping:
    """Mapping from an exemplar control to regulatory requirements."""

    control_id: str
    control_name: str
    iso_control: str | None = None
    addresses: list[str] = field(default_factory=list)


@dataclass
class WorkProductEvidence:
    """A work product that serves as evidence for regulatory requirements."""

    artifact: str
    wp_id: str
    addresses: list[str] = field(default_factory=list)


@dataclass
class ProcessDomainEvidence:
    """Process domain and its work products that evidence requirements."""

    domain: str
    base_practices: list[str] = field(default_factory=list)
    work_products: list[WorkProductEvidence] = field(default_factory=list)


@dataclass
class RegulatoryRequirement:
    """A parsed regulatory requirement with all its crosswalk mappings."""

    requirement_id: str
    framework_id: str  # e.g., "NIST-AI-RMF"
    function: str | None = None  # e.g., "GOVERN", "MAP"
    category: str | None = None  # e.g., "GOVERN-1"
    title: str = ""
    description: str = ""
    subcategories: list[RegulatorySubcategory] = field(default_factory=list)
    primary_policies: list[PolicyMapping] = field(default_factory=list)
    secondary_policies: list[PolicyMapping] = field(default_factory=list)
    exemplar_controls: list[ControlMapping] = field(default_factory=list)
    process_domains: list[ProcessDomainEvidence] = field(default_factory=list)
    raw_data: dict[str, Any] = field(default_factory=dict)


@dataclass
class RegulatoryFramework:
    """A complete parsed regulatory framework with all requirements."""

    framework_id: str  # e.g., "NIST-AI-RMF"
    program_name: str
    program_authority: str
    version: str
    description: str
    target_applicability: str = ""
    requirements: list[RegulatoryRequirement] = field(default_factory=list)
    function_categories: list[dict[str, Any]] = field(default_factory=list)
    source_file: str = ""
    parsed_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    raw_metadata: dict[str, Any] = field(default_factory=dict)


# ============================================================================
# YAML Parser
# ============================================================================


class RegulatoryYAMLParser:
    """
    Parses regulatory crosswalk YAML files into ASHCAI-compatible structures.

    Usage:
        parser = RegulatoryYAMLParser(
            yaml_dir="/path/to/ashmatics-policy-process-builder/wizard-content-schemas"
        )

        # Parse a specific framework
        nist = parser.parse_file("nist-rmf-logic.yaml")

        # Parse all frameworks
        all_frameworks = parser.parse_all()

        # Get crosswalk relationships for ontology population
        relationships = parser.extract_crosswalk_relationships(nist)
    """

    # Known regulatory framework mappings
    FRAMEWORK_MAPPINGS = {
        "nist-rmf-logic.yaml": {
            "framework_id": "NIST-AI-RMF",
            "short_name": "NIST RMF",
        },
        "jc-ruaih-logic.yaml": {
            "framework_id": "JC-RUAIH",
            "short_name": "Joint Commission RUAIH",
        },
        "onc-hti1-logic.yaml": {
            "framework_id": "ONC-HTI1",
            "short_name": "ONC HTI-1",
        },
        "colorado-ai-act-logic.yaml": {
            "framework_id": "CO-AI-ACT",
            "short_name": "Colorado AI Act",
        },
        "aca-section-1557-logic.yaml": {
            "framework_id": "ACA-1557",
            "short_name": "ACA Section 1557",
        },
    }

    def __init__(self, yaml_dir: str | Path):
        """
        Initialize the parser with the YAML directory path.

        Args:
            yaml_dir: Path to the wizard-content-schemas directory
        """
        self.yaml_dir = Path(yaml_dir)
        if not self.yaml_dir.exists():
            raise FileNotFoundError(f"YAML directory not found: {self.yaml_dir}")

        self._parsed_frameworks: dict[str, RegulatoryFramework] = {}
        self._errors: list[str] = []

    def parse_file(self, filename: str) -> RegulatoryFramework:
        """
        Parse a single regulatory YAML file.

        Args:
            filename: Name of the YAML file (e.g., "nist-rmf-logic.yaml")

        Returns:
            RegulatoryFramework with all parsed requirements
        """
        filepath = self.yaml_dir / filename
        if not filepath.exists():
            raise FileNotFoundError(f"YAML file not found: {filepath}")

        logger.info(f"Parsing regulatory YAML: {filename}")

        with open(filepath, encoding="utf-8") as f:
            data = yaml.safe_load(f)

        # Get framework info from mappings or derive from metadata
        framework_info = self.FRAMEWORK_MAPPINGS.get(filename, {})
        metadata = data.get("metadata", {})

        framework_id = framework_info.get("framework_id") or metadata.get(
            "program_name", filename.replace("-logic.yaml", "").upper()
        )

        framework = RegulatoryFramework(
            framework_id=framework_id,
            program_name=metadata.get("program_name", ""),
            program_authority=metadata.get("program_authority", ""),
            version=metadata.get("version", "1.0"),
            description=metadata.get("description", ""),
            target_applicability=metadata.get("target_applicability", ""),
            function_categories=data.get("function_categories", []),
            source_file=str(filepath),
            raw_metadata=metadata,
        )

        # Parse requirements
        raw_requirements = data.get("requirements", [])
        for raw_req in raw_requirements:
            try:
                requirement = self._parse_requirement(raw_req, framework_id)
                framework.requirements.append(requirement)
            except Exception as e:
                error_msg = f"Error parsing requirement {raw_req.get('requirement_id', 'unknown')}: {e}"
                logger.warning(error_msg)
                self._errors.append(error_msg)

        logger.info(
            f"Parsed {len(framework.requirements)} requirements from {filename}"
        )
        self._parsed_frameworks[framework_id] = framework
        return framework

    def parse_all(self) -> list[RegulatoryFramework]:
        """
        Parse all known regulatory YAML files in the directory.

        Returns:
            List of all parsed RegulatoryFramework objects
        """
        frameworks = []
        yaml_files = list(self.yaml_dir.glob("*-logic.yaml"))

        for filepath in yaml_files:
            try:
                framework = self.parse_file(filepath.name)
                frameworks.append(framework)
            except Exception as e:
                error_msg = f"Failed to parse {filepath.name}: {e}"
                logger.error(error_msg)
                self._errors.append(error_msg)

        return frameworks

    def _parse_requirement(
        self, raw: dict[str, Any], framework_id: str
    ) -> RegulatoryRequirement:
        """Parse a single requirement from raw YAML data."""
        requirement = RegulatoryRequirement(
            requirement_id=raw["requirement_id"],
            framework_id=framework_id,
            function=raw.get("function"),
            category=raw.get("category"),
            title=raw.get("title", ""),
            description=raw.get("description", ""),
            raw_data=raw,
        )

        # Parse subcategories
        # Different frameworks use different keys (nist_subcategories, subcategories, etc.)
        subcats_key = None
        for key in ["nist_subcategories", "subcategories", "sub_requirements", "items"]:
            if key in raw:
                subcats_key = key
                break

        if subcats_key and raw[subcats_key]:
            for subcat in raw[subcats_key]:
                requirement.subcategories.append(
                    RegulatorySubcategory(
                        id=subcat.get("id", ""),
                        description=subcat.get("description", ""),
                        implementation_priority=subcat.get(
                            "implementation_priority", "medium"
                        ),
                    )
                )

        # Parse policy mappings
        policy_mapping = raw.get("ashmatics_policy_mapping", {})
        if policy_mapping:
            for policy in policy_mapping.get("primary_policies", []):
                requirement.primary_policies.append(self._parse_policy_mapping(policy))
            for policy in policy_mapping.get("secondary_policies", []):
                requirement.secondary_policies.append(
                    self._parse_policy_mapping(policy)
                )

        # Parse exemplar controls
        for ctrl in raw.get("ashmatics_exemplar_controls", []):
            requirement.exemplar_controls.append(
                ControlMapping(
                    control_id=ctrl.get("control_id", ""),
                    control_name=ctrl.get("control_name", ""),
                    iso_control=ctrl.get("iso_control"),
                    addresses=ctrl.get("addresses", []),
                )
            )

        # Parse process domain evidence
        process_evidence = raw.get("process_domain_evidence", {})
        for domain in process_evidence.get("primary_domains", []):
            pd_evidence = ProcessDomainEvidence(
                domain=domain.get("domain", ""),
                base_practices=domain.get("base_practices", []),
            )
            for wp in domain.get("work_products", []):
                pd_evidence.work_products.append(
                    WorkProductEvidence(
                        artifact=wp.get("artifact", ""),
                        wp_id=wp.get("wp_id", ""),
                        addresses=wp.get("addresses", []),
                    )
                )
            requirement.process_domains.append(pd_evidence)

        return requirement

    def _parse_policy_mapping(self, policy_data: dict[str, Any]) -> PolicyMapping:
        """Parse a policy mapping from raw YAML data."""
        mapping = PolicyMapping(
            policy_id=policy_data.get("policy", ""),
            policy_name=policy_data.get("policy_name"),
        )
        for section_data in policy_data.get("sections", []):
            mapping.sections.append(
                PolicySection(
                    section=section_data.get("section", ""),
                    description=section_data.get("description", ""),
                    token=section_data.get("token"),
                    addresses=section_data.get("addresses", []),
                )
            )
        return mapping

    def extract_crosswalk_relationships(
        self, framework: RegulatoryFramework
    ) -> list[dict[str, Any]]:
        """
        Extract ASHCAI relationship records from a parsed framework.

        Returns a list of relationship dictionaries ready for MongoDB insertion
        using the ASHCAI ontology relationship types.

        Args:
            framework: A parsed RegulatoryFramework

        Returns:
            List of relationship dictionaries with ASHCAI relationship types
        """
        relationships = []
        timestamp = datetime.now(UTC)

        for req in framework.requirements:
            # Create regulatory requirement entity reference
            req_ref = f"{framework.framework_id}-{req.requirement_id}"

            # Extract subcategory relationships
            for subcat in req.subcategories:
                subcat_ref = f"{framework.framework_id}-{subcat.id}"
                relationships.append(
                    {
                        "source_id": req_ref,
                        "source_type": "RegulatoryRequirement",
                        "target_id": subcat_ref,
                        "target_type": "RegulatorySubcategory",
                        "relationship_type": "contains",  # Maps to ASHCAI containsSubcategory
                        "metadata": {
                            "framework_id": framework.framework_id,
                            "description": subcat.description,
                            "priority": subcat.implementation_priority,
                        },
                        "created_at": timestamp,
                    }
                )

            # Policy → Requirement relationships (addressedBy)
            all_policies = req.primary_policies + req.secondary_policies
            for policy in all_policies:
                is_primary = policy in req.primary_policies
                for section in policy.sections:
                    for addressed_req_id in section.addresses:
                        relationships.append(
                            {
                                "source_id": policy.policy_id,
                                "source_type": "PolicyDomain",
                                "target_id": f"{framework.framework_id}-{addressed_req_id}",
                                "target_type": "RegulatoryRequirement",
                                "relationship_type": "addressedBy",  # ASHCAI type
                                "metadata": {
                                    "framework_id": framework.framework_id,
                                    "section": section.section,
                                    "section_description": section.description,
                                    "token": section.token,
                                    "is_primary": is_primary,
                                },
                                "created_at": timestamp,
                            }
                        )

            # Control → Requirement relationships (servesAsEvidenceFor)
            for control in req.exemplar_controls:
                for addressed_req_id in control.addresses:
                    relationships.append(
                        {
                            "source_id": control.control_id,
                            "source_type": "ExemplarControl",
                            "target_id": f"{framework.framework_id}-{addressed_req_id}",
                            "target_type": "RegulatoryRequirement",
                            "relationship_type": "servesAsEvidenceFor",  # ASHCAI type
                            "metadata": {
                                "framework_id": framework.framework_id,
                                "control_name": control.control_name,
                                "iso_control": control.iso_control,
                            },
                            "created_at": timestamp,
                        }
                    )

            # Process Domain → Requirement relationships (operationalizedIn)
            for pd in req.process_domains:
                for bp in pd.base_practices:
                    relationships.append(
                        {
                            "source_id": bp,
                            "source_type": "BasePractice",
                            "target_id": req_ref,
                            "target_type": "RegulatoryRequirement",
                            "relationship_type": "operationalizedIn",  # ASHCAI type
                            "metadata": {
                                "framework_id": framework.framework_id,
                                "process_domain": pd.domain,
                            },
                            "created_at": timestamp,
                        }
                    )

                # Work Product → Requirement relationships (servesAsEvidenceFor)
                for wp in pd.work_products:
                    for addressed_req_id in wp.addresses:
                        relationships.append(
                            {
                                "source_id": wp.wp_id,
                                "source_type": "WorkProductTemplate",
                                "target_id": f"{framework.framework_id}-{addressed_req_id}",
                                "target_type": "RegulatoryRequirement",
                                "relationship_type": "servesAsEvidenceFor",
                                "metadata": {
                                    "framework_id": framework.framework_id,
                                    "artifact_name": wp.artifact,
                                    "process_domain": pd.domain,
                                },
                                "created_at": timestamp,
                            }
                        )

        logger.info(
            f"Extracted {len(relationships)} crosswalk relationships from {framework.framework_id}"
        )
        return relationships

    def get_framework_summary(
        self, framework: RegulatoryFramework
    ) -> dict[str, Any]:
        """
        Get a summary of a parsed framework for reporting.

        Args:
            framework: A parsed RegulatoryFramework

        Returns:
            Dictionary with summary statistics
        """
        total_subcats = sum(len(r.subcategories) for r in framework.requirements)
        total_policies = len(
            {
                p.policy_id
                for r in framework.requirements
                for p in r.primary_policies + r.secondary_policies
            }
        )
        total_controls = len(
            {c.control_id for r in framework.requirements for c in r.exemplar_controls}
        )
        total_domains = len(
            {pd.domain for r in framework.requirements for pd in r.process_domains}
        )

        return {
            "framework_id": framework.framework_id,
            "program_name": framework.program_name,
            "version": framework.version,
            "source_file": framework.source_file,
            "statistics": {
                "requirements": len(framework.requirements),
                "subcategories": total_subcats,
                "functions": len(framework.function_categories),
                "mapped_policies": total_policies,
                "mapped_controls": total_controls,
                "mapped_process_domains": total_domains,
            },
            "parsed_at": framework.parsed_at.isoformat(),
        }

    @property
    def errors(self) -> list[str]:
        """Return any parsing errors encountered."""
        return self._errors.copy()

    @property
    def parsed_frameworks(self) -> dict[str, RegulatoryFramework]:
        """Return all parsed frameworks by ID."""
        return self._parsed_frameworks.copy()


# ============================================================================
# Convenience Functions
# ============================================================================


def find_yaml_directory() -> Path | None:
    """
    Attempt to locate the wizard-content-schemas directory.

    Searches in common relative paths from the current working directory.

    Returns:
        Path to the directory if found, None otherwise
    """
    possible_paths = [
        Path("wizard-content-schemas"),
        Path("../ashmatics-policy-process-builder/wizard-content-schemas"),
        Path("../../ashmatics-policy-process-builder/wizard-content-schemas"),
        Path.home()
        / "GitHub/AsherInformatics/ashmatics-policy-process-builder/wizard-content-schemas",
    ]

    for path in possible_paths:
        if path.exists() and path.is_dir():
            return path

    return None


def parse_all_regulatory_frameworks(
    yaml_dir: str | Path | None = None,
) -> list[RegulatoryFramework]:
    """
    Convenience function to parse all regulatory frameworks.

    Args:
        yaml_dir: Optional path to the YAML directory. If not provided,
                  attempts to auto-detect the location.

    Returns:
        List of parsed RegulatoryFramework objects
    """
    if yaml_dir is None:
        yaml_dir = find_yaml_directory()
        if yaml_dir is None:
            raise FileNotFoundError(
                "Could not locate wizard-content-schemas directory. "
                "Please provide the yaml_dir parameter."
            )

    parser = RegulatoryYAMLParser(yaml_dir)
    return parser.parse_all()
