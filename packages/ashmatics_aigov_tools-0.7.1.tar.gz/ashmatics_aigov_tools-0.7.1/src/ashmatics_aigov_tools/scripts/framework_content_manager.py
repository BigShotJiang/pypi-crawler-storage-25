#!/usr/bin/env python3
# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Ashmatics CAI Governance Framework Content Manager

Last Updated: 2025-12-21 JF Kalafut
v0.2.7 

NOTE: this is replacing the previous script from ashmatics-knowledgebase-tools; our strategy being that this is aigov framework specfic and we should keep it here.


Comprehensive CLI tool for managing Ashmatics Clinical AI Governance Framework
content across Azure Container Storage, PostgreSQL (via Hasura), and MongoDB.

Capabilities:
- Full import: validate → upload to Azure → register with KB (Postgres + MongoDB)
- Register-only: register already-uploaded Azure content with KB
- Validate: check framework content structure without uploading
- List files: show what would be uploaded
- Dry-run: preview operations without executing

Usage:
    # Full import with validation (upload to Azure + register with KB)
    cai-framework-manager --upload --version 0.8.0

    # Register existing Azure content only (no upload)
    cai-framework-manager --register-only --version 0.8.0

    # Dry run to preview what would happen
    cai-framework-manager --upload --version 0.8.0 --dry-run

    # Validate framework content only
    cai-framework-manager --validate-only

    # List files that would be uploaded
    cai-framework-manager --list-files

Updated: 2025-12-19 by JF Kalafut
- Migrated from ashmatics-knowledgebase-tools to ashmatics-aigov-tools
- Uses new artifact_id slug mapping for human-friendly identifiers
- Supports 3-tier MongoDB document schema from ashmatics-datamodels
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from ashmatics_aigov_tools.importers.framework_content import (
    FrameworkContentImporter,
)
from ashmatics_aigov_tools.processors.content_validator import (
    FrameworkContentValidator,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False, log_dir: Path | None = None) -> str:
    """Set up comprehensive logging with file and console handlers.

    Args:
        verbose: Enable verbose/debug logging
        log_dir: Directory for log files (defaults to ./logs)

    Returns:
        Path to the log file created
    """
    # Create logs directory
    if log_dir is None:
        log_dir = Path.cwd() / "logs"
    log_dir.mkdir(exist_ok=True)

    # Generate timestamp-based log filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = log_dir / f"cai_framework_import_{timestamp}.log"

    # Clear any existing handlers to avoid duplicates
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Set logging level
    log_level = logging.DEBUG if verbose else logging.INFO

    # Create formatters
    detailed_formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_formatter = logging.Formatter("%(levelname)s - %(message)s")

    # Create file handler
    file_handler = logging.FileHandler(log_file_path, mode="w", encoding="utf-8")
    file_handler.setLevel(log_level)
    file_handler.setFormatter(detailed_formatter)

    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(console_formatter)

    # Configure root logger
    root_logger.setLevel(log_level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    # Log the start
    logger.info("=== CAI Framework Content Manager Started ===")
    logger.info(f"Log file: {log_file_path}")
    logger.info(f"Timestamp: {datetime.now().isoformat()}")

    return str(log_file_path)


def load_environment_config() -> dict[str, Any]:
    """Load configuration from environment variables.

    Looks for .env files in multiple locations:
    1. Current working directory
    2. Script's parent directories
    3. User's home directory GitHub path
    """
    env_files_loaded = []

    # Potential .env file locations
    potential_paths = [
        Path.cwd() / ".env",
        Path.cwd() / "ashmatics-tools.env",
        Path(__file__).parent.parent.parent.parent / ".env",
        Path(__file__).parent.parent.parent.parent / "ashmatics-tools.env",
        Path.home() / "GitHub/AsherInformatics/ashmatics-aigov-tools/.env",
        Path.home() / "GitHub/AsherInformatics/ashmatics-aigov-tools/ashmatics-tools.env",
    ]

    for env_path in potential_paths:
        if env_path.exists():
            load_dotenv(env_path)
            env_files_loaded.append(str(env_path))

    if env_files_loaded:
        logger.info(f"Loaded environment from: {', '.join(env_files_loaded)}")
    else:
        logger.warning("No .env files found, using environment variables only")

    # Default framework repo path - try multiple locations
    default_framework_path = None
    framework_candidates = [
        Path.cwd(),  # Current directory might be the framework
        Path.home() / "GitHub/AsherInformatics/ashmatics-policy-process-builder",
        Path(__file__).parent.parent.parent.parent.parent / "ashmatics-policy-process-builder",
    ]
    for candidate in framework_candidates:
        if (candidate / "process-domain-registry.json").exists():
            default_framework_path = str(candidate)
            break

    # 2026-01-24: Standardized env var names with backward-compatible fallbacks
    config = {
        "azure_connection_string": os.getenv("AZURE_STORAGE_CONNECTION_STRING"),
        "hasura_endpoint": os.getenv(
            "HASURA_GRAPHQL_ENDPOINT", "https://kb-graphql.ashmatics.com/v1/graphql"
        ),
        "hasura_admin_secret": os.getenv("HASURA_GRAPHQL_ADMIN_SECRET")
        or os.getenv("HASURA_ADMIN_SECRET", "ashmatics_hasura_admin_key"),
        "framework_repo_path": os.getenv("FRAMEWORK_REPO_PATH", default_framework_path),
        "container_name": os.getenv("AZURE_FRAMEWORK_CONTAINER", "framework-content"),
        "kb_table_name": os.getenv("KB_TABLE_NAME", "framework_content_registry"),
        # MongoDB connection: canonical MONGO_URL, fallback to deprecated names
        "mongo_connection_string": os.getenv("MONGO_URL")
        or os.getenv("AZ_MONGO_CONNECTION_STRING")
        or os.getenv("MONGO_CONNECTION_STRING"),
        # Database name: canonical MONGO_DB, fallback to MONGO_DATABASE
        "mongo_database": os.getenv("MONGO_DB") or os.getenv("MONGO_DATABASE", "ashmatics_kb"),
        "mongo_collection": os.getenv("MONGO_COLLECTION", "framework_compiled_views"),
        "force_adls_gen2": os.getenv("FORCE_ADLS_GEN2", "false").lower() == "true",
        "verify_ssl": os.getenv("VERIFY_SSL", "true").lower() == "true",
    }

    return config


def validate_config(config: dict[str, Any], require_azure: bool = True) -> bool:
    """Validate that required configuration is present."""
    errors = []

    if require_azure and not config.get("azure_connection_string"):
        errors.append("AZURE_STORAGE_CONNECTION_STRING - Azure Storage connection string")

    if not config.get("framework_repo_path"):
        errors.append("FRAMEWORK_REPO_PATH - Path to framework repository")
    elif not Path(config["framework_repo_path"]).exists():
        errors.append(f"Framework path does not exist: {config['framework_repo_path']}")
    elif not (Path(config["framework_repo_path"]) / "process-domain-registry.json").exists():
        errors.append(
            f"Invalid framework repo (missing process-domain-registry.json): "
            f"{config['framework_repo_path']}"
        )

    if errors:
        logger.error("Missing or invalid configuration:")
        for error in errors:
            logger.error(f"  - {error}")
        return False

    return True


def main():
    """Main entry point for the CAI Framework Content Manager."""
    parser = argparse.ArgumentParser(
        description="Ashmatics CAI Governance Framework Content Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Full import: validate → upload to Azure → register with KB
    cai-framework-manager --upload --version 0.8.0

    # Register existing Azure content with KB (no upload)
    cai-framework-manager --register-only --version 0.8.0 --hybrid

    # Dry run to see what would happen
    cai-framework-manager --upload --version 0.8.0 --dry-run

    # Validate framework content only
    cai-framework-manager --validate-only

    # List files that would be uploaded
    cai-framework-manager --list-files

    # Hybrid mode with MongoDB compilation
    cai-framework-manager --upload --version 0.8.0 --hybrid
        """,
    )

    # Action flags
    action_group = parser.add_mutually_exclusive_group()
    action_group.add_argument(
        "--upload",
        action="store_true",
        help="Full import: validate, upload to Azure, and register with KB",
    )
    action_group.add_argument(
        "--register-only",
        action="store_true",
        help="Register already-uploaded Azure content with KB (no upload)",
    )
    action_group.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate framework content, do not upload or register",
    )
    action_group.add_argument(
        "--list-files",
        action="store_true",
        help="List all files that would be uploaded",
    )

    # Options
    parser.add_argument(
        "--version",
        type=str,
        default="0.8.0",
        help="Framework version (default: 0.8.0)",
    )
    parser.add_argument(
        "--framework-path",
        type=str,
        help="Path to framework repository (auto-detected if not specified)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview operations without executing",
    )
    parser.add_argument(
        "--hybrid",
        action="store_true",
        help="Enable hybrid persistence (PostgreSQL + MongoDB)",
    )
    parser.add_argument(
        "--skip-postgres",
        action="store_true",
        help="Skip PostgreSQL registration (hybrid mode only)",
    )
    parser.add_argument(
        "--skip-mongodb",
        action="store_true",
        help="Skip MongoDB compilation (hybrid mode only)",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh of Azure manifest even if cached",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="Skip verification of Azure content existence",
    )
    parser.add_argument(
        "--validate-mapping",
        action="store_true",
        help="Validate artifact_id mapping consistency after registration",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging",
    )
    parser.add_argument(
        "--output",
        type=str,
        help="Save detailed results to JSON file",
    )

    args = parser.parse_args()

    # Set up logging
    log_file_path = setup_logging(verbose=args.verbose)
    logger.info(f"Arguments: {vars(args)}")

    # Load configuration
    config = load_environment_config()

    # Override framework path if specified
    if args.framework_path:
        config["framework_repo_path"] = args.framework_path

    # Handle validate-only (doesn't require Azure)
    if args.validate_only:
        if not validate_config(config, require_azure=False):
            return 1

        try:
            validator = FrameworkContentValidator(config["framework_repo_path"])
            valid, results = validator.validate_all()

            print("\n" + "=" * 70)
            print("FRAMEWORK VALIDATION RESULTS")
            print("=" * 70)
            print(f"Result: {'PASSED' if valid else 'FAILED'}")
            print(f"Framework Path: {config['framework_repo_path']}")

            detected_version = validator.get_framework_version()
            print(f"Detected Version: {detected_version}")

            summary = results.get("summary", {})
            print(f"\nTotal checks: {summary.get('total_checks', 0)}")
            print(f"Passed: {summary.get('passed', 0)}")
            print(f"Failed: {summary.get('failed', 0)}")
            print(f"Warnings: {summary.get('warnings', 0)}")

            if args.output:
                with open(args.output, "w") as f:
                    json.dump(results, f, indent=2)
                print(f"\nDetailed results saved to: {args.output}")

            return 0 if valid else 1

        except Exception as e:
            logger.error(f"Validation error: {e}")
            return 1

    # Handle list-files (doesn't require full Azure config)
    if args.list_files:
        if not validate_config(config, require_azure=False):
            return 1

        try:
            importer = FrameworkContentImporter(
                framework_repo_path=config["framework_repo_path"],
                azure_connection_string=config.get("azure_connection_string", "dummy"),
                version=args.version,
            )

            files = importer.list_content_files()

            print("\n" + "=" * 70)
            print("FRAMEWORK CONTENT FILES")
            print("=" * 70)

            by_category: dict[str, list] = {}
            total_size = 0

            for file_info in files:
                category = file_info.get("category", "unknown")
                if category not in by_category:
                    by_category[category] = []
                by_category[category].append(file_info)
                total_size += file_info.get("size_bytes", 0)

            for category, cat_files in sorted(by_category.items()):
                print(f"\n{category.upper().replace('_', ' ')} ({len(cat_files)} files):")
                for f in cat_files[:10]:
                    size_kb = f.get("size_bytes", 0) / 1024
                    print(f"  {f['relative_path']} ({size_kb:.1f} KB)")
                if len(cat_files) > 10:
                    print(f"  ... and {len(cat_files) - 10} more")

            print(f"\nTotal: {len(files)} files, {total_size / 1024:.1f} KB")
            return 0

        except Exception as e:
            logger.error(f"Error listing files: {e}")
            return 1

    # For upload or register-only, we need full config
    if not validate_config(config, require_azure=True):
        return 1

    # Initialize importer
    try:
        logger.info("Initializing Framework Content Importer")

        importer = FrameworkContentImporter(
            framework_repo_path=config["framework_repo_path"],
            azure_connection_string=config["azure_connection_string"],
            kb_table_name=config["kb_table_name"],
            container_name=config["container_name"],
            version=args.version,
            mongo_connection_string=config["mongo_connection_string"],
            mongo_database=config["mongo_database"],
            mongo_collection=config["mongo_collection"],
            graphql_endpoint=config["hasura_endpoint"],
            admin_secret=config["hasura_admin_secret"],
            verify_ssl=config["verify_ssl"],
            force_adls_gen2=config["force_adls_gen2"],
        )

        version_info = importer.get_current_version_info()
        if version_info:
            logger.info(f"Framework version: {version_info['version']}")
            logger.info(f"Framework path: {version_info['framework_path']}")

    except Exception as e:
        logger.error(f"Failed to initialize importer: {e}")
        return 1

    # Handle --upload (full import)
    if args.upload:
        logger.info("Starting FULL IMPORT (validate → upload → register)")

        if args.dry_run:
            logger.info("DRY RUN MODE - No actual changes will be made")

        try:
            success, results = importer.import_all(
                validate_first=True,
                dry_run=args.dry_run,
                hybrid_mode=args.hybrid or bool(config["mongo_connection_string"]),
            )

            _print_import_results(success, results, args)

            if args.output:
                with open(args.output, "w") as f:
                    json.dump(results, f, indent=2, default=str)
                print(f"\nDetailed results saved to: {args.output}")

            return 0 if success else 1

        except Exception as e:
            logger.error(f"Import error: {e}")
            if args.verbose:
                import traceback
                logger.error(traceback.format_exc())
            return 1

    # Handle --register-only
    if args.register_only:
        logger.info("Starting REGISTER-ONLY (existing Azure content)")

        if args.dry_run:
            logger.info("DRY RUN MODE - previewing registration")
            # Just verify Azure content exists
            if importer.uploader.container_exists():
                version_prefix = f"v{importer.uploader.version}/"
                blobs = importer.uploader.list_container_blobs(prefix=version_prefix)
                logger.info(
                    f"Found {len(blobs)} files in Azure for version {importer.uploader.version}"
                )
                for blob in blobs[:5]:
                    logger.info(f"  {blob['name']} ({blob['size']} bytes)")
                if len(blobs) > 5:
                    logger.info(f"  ... and {len(blobs) - 5} more files")
            else:
                logger.error("Azure container does not exist")
                return 1
            return 0

        try:
            if args.hybrid:
                success, results = importer.register_full_hybrid_content(
                    force_refresh=args.force_refresh,
                    verify_azure_content=not args.no_verify,
                    skip_postgres=args.skip_postgres,
                    skip_mongodb=args.skip_mongodb,
                )
            else:
                success, results = importer.register_existing_content_with_kb(
                    force_refresh=args.force_refresh,
                    verify_azure_content=not args.no_verify,
                )

            _print_register_results(success, results, args)

            # Optional mapping validation
            if args.validate_mapping and success:
                _validate_artifact_mapping(importer, results, args)

            if args.output:
                with open(args.output, "w") as f:
                    json.dump(results, f, indent=2, default=str)
                print(f"\nDetailed results saved to: {args.output}")

            return 0 if success else 1

        except Exception as e:
            logger.error(f"Registration error: {e}")
            if args.verbose:
                import traceback
                logger.error(traceback.format_exc())
            return 1

    # No action specified
    parser.print_help()
    print("\nPlease specify an action: --upload, --register-only, --validate-only, or --list-files")
    return 1


def _print_import_results(success: bool, results: dict, args) -> None:
    """Print formatted import results."""
    print("\n" + "=" * 70)
    print("FRAMEWORK CONTENT IMPORT RESULTS")
    print("=" * 70)
    print(f"Result: {'SUCCESS' if success else 'FAILED'}")
    print(f"Version: {results.get('framework_version')}")
    print(f"Framework Path: {results.get('framework_path')}")
    print(f"Timestamp: {results.get('import_timestamp')}")

    if args.dry_run:
        print("Mode: DRY RUN (no actual changes)")

    steps = results.get("steps", {})

    if "validation" in steps:
        val_summary = steps["validation"].get("summary", {})
        print(f"\nValidation: {val_summary.get('passed', 0)}/{val_summary.get('total_checks', 0)} checks passed")

    if "azure_upload" in steps:
        upload_summary = steps["azure_upload"].get("summary", {})
        print(f"Azure Upload: {upload_summary.get('successful_uploads', 0)} files uploaded")
        print(f"  Total size: {upload_summary.get('total_size_bytes', 0) / 1024:.1f} KB")

    if "kb_registration" in steps:
        kb_results = steps["kb_registration"]
        content_stats = kb_results.get("content_records", {})
        print(f"KB Registration: {content_stats.get('successful', 0)} records created")

    if "mongodb_compilation" in steps:
        mongo_results = steps["mongodb_compilation"]
        print(f"MongoDB Compilation: {mongo_results.get('compiled_count', 0)} views compiled")


def _print_register_results(success: bool, results: dict, args) -> None:
    """Print formatted registration results."""
    print("\n" + "=" * 70)
    print("FRAMEWORK CONTENT REGISTRATION RESULTS")
    print("=" * 70)
    print(f"Result: {'SUCCESS' if success else 'FAILED'}")
    print(f"Version: {results.get('framework_version')}")

    if args.hybrid and "hybrid_strategy" in results:
        print("Mode: Hybrid (PostgreSQL + MongoDB)")

        if "postgres_registration" in results:
            pg = results["postgres_registration"]
            if "kb_registration" in pg:
                content = pg["kb_registration"].get("content_records", {})
                print(f"PostgreSQL: {content.get('successful', 0)}/{content.get('total', 0)} files registered")

        if "mongodb_compilation" in results:
            mongo = results["mongodb_compilation"]
            storage = mongo.get("mongodb_storage", {})
            print(f"MongoDB: {storage.get('successful', 0)} views stored")
    elif "kb_registration" in results:
        content = results["kb_registration"].get("content_records", {})
        print(f"KB Registration: {content.get('successful', 0)}/{content.get('total', 0)} files")


def _validate_artifact_mapping(importer, results: dict, args) -> None:
    """Validate artifact_id mapping consistency."""
    logger.info("Starting artifact_id mapping validation...")

    try:
        framework_version = results.get("framework_version", "unknown")
        is_consistent, validation_results = importer.validate_artifact_id_mapping(
            framework_version=framework_version
        )

        if is_consistent:
            logger.info("Artifact ID mapping validation passed!")
            logger.info(f"  Validated {validation_results['matching_mappings']} consistent mappings")
        else:
            logger.warning("Artifact ID mapping validation found inconsistencies")
            if validation_results.get("missing_in_postgres"):
                logger.warning(f"  Missing in PostgreSQL: {len(validation_results['missing_in_postgres'])}")
            if validation_results.get("missing_in_mongodb"):
                logger.warning(f"  Missing in MongoDB: {len(validation_results['missing_in_mongodb'])}")
            if validation_results.get("mismatched_paths"):
                logger.warning(f"  Mismatched artifact_ids: {len(validation_results['mismatched_paths'])}")

    except Exception as e:
        logger.error(f"Validation failed: {e}")


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)
