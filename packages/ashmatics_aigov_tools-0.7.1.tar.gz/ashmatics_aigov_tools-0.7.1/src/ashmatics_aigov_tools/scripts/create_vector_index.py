#!/usr/bin/env python3
"""
Generic CosmosDB/MongoDB Vector Index Manager CLI.

Created 2025-12-22 JF Kalafut
v0.2.7

A standalone CLI utility to create and manage vector search indexes on any
MongoDB collection with embeddings. Uses VectorIndexManager from ashmatics-tools.

Usage:
    # Using environment variable (AZ_MONGO_CONNECTION_STRING)
    uv run python create_vector_index.py --db ai_strategy --collection aigov_framework_vectors

    # Check existing indexes
    uv run python create_vector_index.py --db mydb --collection myvectors --check-only

    # Create with custom settings
    uv run python create_vector_index.py --db mydb --collection myvectors \
        --field embedding --dimensions 1536 --index-type ivf --similarity COS

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
"""

import argparse
import os
import sys

from ashmatics_tools.vector_stores import VectorIndexManager
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table

console = Console()


def get_connection_string() -> str | None:
    """Get MongoDB connection string from environment."""
    for var in [
        "AZ_MONGO_CONNECTION_STRING",
        "MONGO_URI",
        "AZ_MONGO_CONNECTION_STRING",
        "COSMOS_CONNECTION_STRING",
    ]:
        value = os.getenv(var)
        if value:
            return value
    return None


def main():
    parser = argparse.ArgumentParser(
        description="Generic CosmosDB/MongoDB Vector Index Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check stats on a collection
  python create_vector_index.py --db ai_strategy --collection aigov_framework_vectors --check-only

  # Create IVF index with default settings
  python create_vector_index.py --db mydb --collection vectors

  # Create with custom embedding field and dimensions
  python create_vector_index.py --db mydb --collection vectors \\
      --field vector_embedding --dimensions 3072

  # Drop and recreate index
  python create_vector_index.py --db mydb --collection vectors --drop-existing

Environment variables (checked in order):
  AZ_MONGO_CONNECTION_STRING, MONGO_URI, AZ_MONGO_CONNECTION_STRING, COSMOS_CONNECTION_STRING
        """,
    )

    # Connection options
    parser.add_argument("--uri", type=str, default=None, help="MongoDB connection string")
    parser.add_argument("--db", type=str, required=True, help="Database name")
    parser.add_argument("--collection", type=str, required=True, help="Collection name")
    parser.add_argument("--env-file", type=str, default=None, help="Path to .env file")

    # Embedding configuration
    parser.add_argument("--field", type=str, default="embedding", help="Embedding field name")
    parser.add_argument("--dimensions", type=int, default=1536, help="Embedding dimensions")
    parser.add_argument("--index-name", type=str, default="vector_search_index", help="Index name")

    # Index options
    parser.add_argument(
        "--index-type", choices=["ivf", "hnsw"], default="ivf", help="Vector index type"
    )
    parser.add_argument(
        "--similarity", choices=["COS", "L2", "IP"], default="COS", help="Similarity metric"
    )
    parser.add_argument("--drop-existing", action="store_true", help="Drop existing index first")

    # HNSW/IVF tuning
    parser.add_argument("--hnsw-m", type=int, default=16, help="HNSW: max connections per layer")
    parser.add_argument("--hnsw-ef", type=int, default=64, help="HNSW: efConstruction")
    parser.add_argument("--ivf-lists", type=int, default=100, help="IVF: number of clusters")

    # Modes
    parser.add_argument("--check-only", action="store_true", help="Only show stats")
    parser.add_argument("--drop-only", action="store_true", help="Only drop the index")
    parser.add_argument(
        "--with-metadata", action="store_true", help="Also create metadata indexes"
    )

    args = parser.parse_args()

    # Load environment
    if args.env_file:
        load_dotenv(args.env_file)
    else:
        for env_file in ["ashmatics-tools.env", ".env"]:
            if os.path.exists(env_file):
                load_dotenv(env_file)
                break

    # Get connection string
    uri = args.uri or get_connection_string()
    if not uri:
        console.print("[red]Error: No MongoDB connection string found[/red]")
        console.print("[dim]Provide --uri or set AZ_MONGO_CONNECTION_STRING env var[/dim]")
        sys.exit(1)

    console.print("[bold blue]CosmosDB/MongoDB Vector Index Manager[/bold blue]\n")

    # Initialize manager using ashmatics-tools
    manager = VectorIndexManager(
        uri=uri,
        db_name=args.db,
        collection_name=args.collection,
        embedding_field=args.field,
        dimensions=args.dimensions,
        index_name=args.index_name,
    )

    try:
        manager.connect()
        console.print(f"[green]✓[/green] Connected to {args.db}.{args.collection}")

        # Get and display stats
        stats = manager.get_stats()

        table = Table(title="Collection Stats")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Database", args.db)
        table.add_row("Collection", args.collection)
        table.add_row("Documents", f"{stats.document_count:,}")
        table.add_row("Has Embeddings", "Yes" if stats.has_embeddings else "No")
        if stats.actual_dimensions:
            table.add_row("Embedding Dimensions", str(stats.actual_dimensions))

        if stats.has_vector_index:
            table.add_row("Vector Index", stats.index_name or "unknown")
            table.add_row("Index Type", stats.index_type or "unknown")
        else:
            table.add_row("Vector Index", "[yellow]None[/yellow]")

        table.add_row("Total Indexes", str(stats.index_count))

        console.print(table)

        # Dimension mismatch warning
        if stats.actual_dimensions and stats.actual_dimensions != args.dimensions:
            console.print(
                f"\n[yellow]Warning: Actual dimensions ({stats.actual_dimensions}) "
                f"differ from specified ({args.dimensions})[/yellow]"
            )

        if args.check_only:
            console.print("\n[dim]--check-only mode, no changes made[/dim]")
            return

        if args.drop_only:
            manager.drop_vector_index()
            return

        # Create vector index
        manager.create_vector_index(
            index_type=args.index_type,
            similarity=args.similarity,
            force=args.drop_existing,
            hnsw_m=args.hnsw_m,
            hnsw_ef_construction=args.hnsw_ef,
            ivf_num_lists=args.ivf_lists,
        )
        console.print("[green]✅ Vector index created[/green]")

        # Optionally create metadata indexes
        if args.with_metadata:
            console.print("\n[bold]Creating metadata indexes...[/bold]")
            created = manager.create_metadata_indexes()
            console.print(f"  Created {created} metadata indexes")

        # Show final stats
        console.print("\n[bold]Final State:[/bold]")
        final_stats = manager.get_stats()
        if final_stats.has_vector_index:
            console.print(
                f"  Vector index: [green]{final_stats.index_name}[/green] ({final_stats.index_type})"
            )
        else:
            console.print("  Vector index: [yellow]None[/yellow]")

    finally:
        manager.close()


if __name__ == "__main__":
    main()
