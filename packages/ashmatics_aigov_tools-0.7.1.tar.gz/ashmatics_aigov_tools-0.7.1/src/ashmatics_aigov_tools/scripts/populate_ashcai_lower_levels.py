#!/usr/bin/env python3
# Copyright (c) 2026, Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ASHCAI Ontology Lower-Level Populator CLI

Created: 2026-01-21 (ASHKBAPP-XX)

Populates the lower-level ASHCAI ontology entities that are NOT created by
init_ashcai_ontology.py:
    - Base Practices (from process-domain/*.json)
    - SOP Templates (from process-domain/*.json)
    - Work Product Templates (from process-domain/*.json + traceability files)
    - Process Outputs (from process-domain/*.json)
    - Exemplar Controls (from framework registry)
    - Tools (from tooling_registry.yaml)
    - All relationships between these entities

Data Sources:
    - process-domain/{domain}-process-domain.json - Contains base_practices, 
      standard_operating_procedures, and process_outputs with full metadata
    - ash-gov-process-model/{DOMAIN}-*/{DOMAIN}-traceability.json - Contains 
      work product details and composed_from relationships
    - ashmatics-framework-registry.json - Contains exemplar control references
    - ash-gov-process-model/tools/tooling_registry.yaml - Contains tool definitions

Cross-Reference Support:
    SOP and Work Product entities include a `kbApiArtifactId` field that matches
    the KB API's artifact_id convention from artifact_slug_mapping.py. This enables
    MCP tools to fetch actual content via:
        GET /api/v1/aigov_framework/content/{kbApiArtifactId}

Prerequisites:
    - Run init_ashcai_ontology.py first to create Policy/Process domains

Usage:
    # Populate all lower levels (requires init_ashcai_ontology.py to run first)
    cai-populate-lower-levels

    # Dry run to preview
    cai-populate-lower-levels --dry-run

    # Populate specific entity types only
    cai-populate-lower-levels --only base-practices
    cai-populate-lower-levels --only sops
    cai-populate-lower-levels --only work-products
    cai-populate-lower-levels --only process-outputs
    cai-populate-lower-levels --only controls
    cai-populate-lower-levels --only tools
"""

import argparse
import asyncio
import json
import logging
import os
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

console = Console()

# ============================================================================
# KB API Configuration
# ============================================================================

# Default KB API base URL (can be overridden via environment variable)
KB_API_BASE_URL = os.getenv("KB_API_BASE_URL", "https://api.ashmatics.com/api/v1/aigov_framework")


# ============================================================================
# Path Discovery
# ============================================================================


def find_script_repo_root(start_path: Path, marker: str = "pyproject.toml") -> Path | None:
    """
    Find the repository root containing this script by searching upward for a marker file.

    This is used to locate ashmatics-tools.env at the CAI framework repo root.

    Args:
        start_path: Path to start searching from.
        marker: Filename that indicates the repo root (default: pyproject.toml).

    Returns:
        Path to the repo root, or None if not found.
    """
    current = start_path.resolve()
    for parent in [current, *current.parents]:
        if (parent / marker).exists():
            return parent
    return None

def find_repo_root() -> Path | None:
    """Find the ashmatics-policy-process-builder repo root."""
    search_paths = [
        Path(__file__).parent.parent.parent.parent.parent / "ashmatics-policy-process-builder",
        Path.home() / "GitHub" / "AsherInformatics" / "ashmatics-policy-process-builder",
        Path("/projects/AsherInformatics/ashmatics-policy-process-builder"),
        Path("/app/ashmatics-policy-process-builder"),
    ]
    for path in search_paths:
        if path.exists() and (path / "ashmatics-framework-registry.json").exists():
            return path
    return None


# ============================================================================
# ID Normalization Utilities
# ============================================================================

def normalize_wp_id(wp_filename: str) -> str:
    """
    Normalize a work product filename to its canonical short ID.
    
    Examples:
        "WP-RM-01-Hazard-Analysis-Report.md" -> "WP-RM-01"
        "WP-PV-01a-Use-Case-Shortlist.md" -> "WP-PV-01a"
    """
    # Remove .md extension
    wp_name = wp_filename.replace(".md", "")
    
    # Match pattern: WP-{DOMAIN}-{NUM}[a-z]?
    match = re.match(r"^(WP-[A-Z]{2,3}-\d{2}[a-z]?)", wp_name)
    if match:
        return match.group(1)
    
    # Fallback: return the full name without extension
    return wp_name


def normalize_sop_id(sop_id: str) -> str:
    """
    Normalize an SOP ID to canonical format.
    
    Examples:
        "SOP-RM-01" -> "SOP-RM-01"
        "SOP_RM_001" -> "SOP-RM-01"
    """
    # Already in correct format
    if re.match(r"^SOP-[A-Z]{2,3}-\d{2}$", sop_id):
        return sop_id
    
    # Convert underscore format
    match = re.match(r"^SOP_([A-Z]{2,3})_(\d+)$", sop_id)
    if match:
        domain = match.group(1)
        num = int(match.group(2))
        return f"SOP-{domain}-{num:02d}"
    
    return sop_id


def generate_process_output_id(domain: str, output_name: str) -> str:
    """
    Generate a canonical ID for a Process Output.
    
    Examples:
        ("RM", "Risk Management Plan") -> "OUT-RM-RiskManagementPlan"
    """
    # Convert name to PascalCase without spaces
    pascal_name = "".join(word.capitalize() for word in output_name.split())
    return f"OUT-{domain}-{pascal_name}"


def tool_token_to_id(token: str) -> str:
    """
    Convert a tool token URI to a canonical Tool ID.
    
    Examples:
        "tool://risk.matrix" -> "TOOL-risk-matrix"
        "module://hta.he" -> "TOOL-hta-he"
    """
    # Remove protocol prefix
    if token.startswith("tool://"):
        name = token[7:]
    elif token.startswith("module://"):
        name = token[9:]
    else:
        name = token
    
    # Replace dots with dashes for cleaner IDs
    name = name.replace(".", "-")
    return f"TOOL-{name}"


def generate_kb_api_url(artifact_id: str, version: str = "0.8.0") -> str:
    """
    Generate a full KB API URL for an artifact.
    
    Examples:
        ("SOP-RM-01", "0.8.0") -> "https://api.ashmatics.com/api/v1/aigov_framework/content/SOP-RM-01?version=0.8.0"
    """
    return f"{KB_API_BASE_URL}/content/{artifact_id}?version={version}"


# ============================================================================
# Data Extraction Functions
# ============================================================================

def load_process_domain_files(repo_root: Path) -> dict[str, dict]:
    """
    Load all process domain JSON files.
    
    Returns:
        Dict mapping domain code (e.g., "RM") to its full JSON data
    """
    process_domain_dir = repo_root / "process-domain"
    domains = {}
    
    for json_file in process_domain_dir.glob("*-process-domain.json"):
        try:
            with open(json_file) as f:
                data = json.load(f)
            
            # Extract domain code from filename (e.g., "rm-process-domain.json" -> "RM")
            domain_code = json_file.stem.split("-")[0].upper()
            domains[domain_code] = data
            logger.debug(f"Loaded process domain: {domain_code}")
        except Exception as e:
            logger.warning(f"Failed to load {json_file}: {e}")
    
    return domains


def load_traceability_files(repo_root: Path) -> dict[str, dict]:
    """
    Load all traceability JSON files.
    
    Returns:
        Dict mapping domain code to traceability data
    """
    ash_gov_dir = repo_root / "ash-gov-process-model"
    traceability = {}
    
    for trace_file in ash_gov_dir.glob("*/*-traceability.json"):
        try:
            with open(trace_file) as f:
                data = json.load(f)
            
            # Extract domain code from filename
            domain_code = trace_file.stem.split("-")[0].upper()
            traceability[domain_code] = data
            logger.debug(f"Loaded traceability: {domain_code}")
        except Exception as e:
            logger.warning(f"Failed to load {trace_file}: {e}")
    
    return traceability


def load_framework_registry(repo_root: Path) -> dict:
    """Load the main framework registry."""
    registry_path = repo_root / "ashmatics-framework-registry.json"
    with open(registry_path) as f:
        return json.load(f)


def load_tooling_registry(repo_root: Path) -> list[dict]:
    """
    Load the tooling registry YAML file.
    
    Returns:
        List of tool entries from the registry
    """
    registry_path = repo_root / "ash-gov-process-model" / "tools" / "tooling_registry.yaml"
    if not registry_path.exists():
        logger.warning(f"Tooling registry not found at {registry_path}")
        return []
    
    with open(registry_path) as f:
        data = yaml.safe_load(f)
    
    return data.get("entries", [])


def extract_base_practices(process_domains: dict[str, dict]) -> list[dict]:
    """
    Extract all base practices from process domain files.
    
    Returns:
        List of base practice documents ready for MongoDB
    """
    practices = []
    
    for domain_code, domain_data in process_domains.items():
        for bp in domain_data.get("base_practices", []):
            practice_id = bp.get("practice_id", f"{domain_code}.BP{bp.get('order', 1):02d}")
            
            practices.append({
                "_id": practice_id,
                "ontology": "ashcai",
                "entity_type": "BasePractice",
                "semantic_type": "T9204",
                "prefLabel": bp.get("name", practice_id),
                "description": bp.get("description", ""),
                "processDomain": domain_code,
                "sequenceOrder": bp.get("order"),
                "urlPath": bp.get("url_path"),
                "workProducts": bp.get("work_products", []),
                "toolingReferences": bp.get("tooling_references", []),
                "policyTokens": bp.get("policy_tokens", []),
                "status": "active" if bp.get("active", True) else "inactive",
                "version": bp.get("version", "1.0"),
                # Base Practices don't have direct KB API content (they're metadata)
                "kbApiArtifactId": None,
            })
    
    return practices


def extract_sop_templates(process_domains: dict[str, dict]) -> list[dict]:
    """
    Extract all SOP templates from process domain files.
    
    Returns:
        List of SOP template documents ready for MongoDB
    """
    sops = []
    
    for domain_code, domain_data in process_domains.items():
        for sop in domain_data.get("standard_operating_procedures", []):
            sop_id = normalize_sop_id(sop.get("sop_id", ""))
            
            # Parse linked practices (can be "RM.BP01" or "PV.BP01+PV.BP01a")
            linked_practices_raw = sop.get("linked_practices", [])
            linked_practices = []
            for lp in linked_practices_raw:
                if "+" in lp:
                    linked_practices.extend(lp.split("+"))
                else:
                    linked_practices.append(lp)
            
            sops.append({
                "_id": sop_id,
                "ontology": "ashcai",
                "entity_type": "SOPTemplate",
                "semantic_type": "T9205",
                "prefLabel": sop.get("name", sop_id),
                "description": sop.get("description", ""),
                "processDomain": domain_code,
                "basePractices": linked_practices,
                "filePath": sop.get("file_path"),
                "duration": sop.get("duration"),
                "teamSize": sop.get("team_size"),
                "primaryRoles": sop.get("primary_roles", []),
                "inputs": sop.get("inputs", []),
                "outputs": sop.get("outputs", []),  # WP filenames
                "processOutput": sop.get("process_output"),  # Name of composed output
                "dependencies": sop.get("dependencies", {}),
                "status": "active",
                # KB API cross-reference: SOP IDs match exactly!
                "kbApiArtifactId": sop_id,
                "kbApiContentUrl": generate_kb_api_url(sop_id),
            })
    
    return sops


def extract_work_products(
    process_domains: dict[str, dict],
    traceability: dict[str, dict]
) -> list[dict]:
    """
    Extract all work products from process domain and traceability files.
    
    Deduplicates by normalized ID and merges metadata from both sources.
    
    Returns:
        List of work product template documents ready for MongoDB
    """
    wp_map: dict[str, dict] = {}  # Keyed by normalized WP ID
    
    # First pass: Extract from traceability files (more detailed)
    for domain_code, trace_data in traceability.items():
        for wp_key, wp_info in trace_data.get("work_products", {}).items():
            wp_id = normalize_wp_id(wp_key)
            
            if wp_id not in wp_map:
                wp_map[wp_id] = {
                    "_id": wp_id,
                    "ontology": "ashcai",
                    "entity_type": "WorkProductTemplate",
                    "semantic_type": "T9206",
                    "prefLabel": wp_key.replace(".md", "").replace("-", " "),
                    "processDomain": domain_code,
                    "basePractice": wp_info.get("base_practice"),
                    "filePath": wp_info.get("file"),
                    "contributesToOutputs": wp_info.get("contributes_to_outputs", []),
                    "fullSlug": wp_key.replace(".md", ""),
                    "status": "active",
                    # KB API cross-reference: WP IDs match exactly!
                    "kbApiArtifactId": wp_id,
                    "kbApiContentUrl": generate_kb_api_url(wp_id),
                }
            else:
                # Merge additional info
                existing = wp_map[wp_id]
                if wp_info.get("contributes_to_outputs"):
                    existing_outputs = set(existing.get("contributesToOutputs", []))
                    existing_outputs.update(wp_info.get("contributes_to_outputs", []))
                    existing["contributesToOutputs"] = list(existing_outputs)
    
    # Second pass: Cross-reference with base_practices.work_products
    for domain_code, domain_data in process_domains.items():
        for bp in domain_data.get("base_practices", []):
            practice_id = bp.get("practice_id")
            for wp_filename in bp.get("work_products", []):
                wp_id = normalize_wp_id(wp_filename)
                
                if wp_id not in wp_map:
                    wp_map[wp_id] = {
                        "_id": wp_id,
                        "ontology": "ashcai",
                        "entity_type": "WorkProductTemplate",
                        "semantic_type": "T9206",
                        "prefLabel": wp_filename.replace(".md", "").replace("-", " "),
                        "processDomain": domain_code,
                        "basePractice": practice_id,
                        "fullSlug": wp_filename.replace(".md", ""),
                        "status": "active",
                        # KB API cross-reference
                        "kbApiArtifactId": wp_id,
                        "kbApiContentUrl": generate_kb_api_url(wp_id),
                    }
                elif not wp_map[wp_id].get("basePractice"):
                    wp_map[wp_id]["basePractice"] = practice_id
    
    return list(wp_map.values())


def extract_process_outputs(process_domains: dict[str, dict]) -> list[dict]:
    """
    Extract all process outputs from process domain files.
    
    Returns:
        List of process output documents ready for MongoDB
    """
    outputs = []
    
    for domain_code, domain_data in process_domains.items():
        for po in domain_data.get("process_outputs", []):
            output_name = po.get("name", "Unknown")
            output_id = generate_process_output_id(domain_code, output_name)
            
            # Normalize the composed_from WP references
            composed_from = [normalize_wp_id(wp) for wp in po.get("composed_from", [])]
            
            outputs.append({
                "_id": output_id,
                "ontology": "ashcai",
                "entity_type": "ProcessOutput",
                "semantic_type": "T9207",
                "prefLabel": output_name,
                "processDomain": domain_code,
                "composedFrom": composed_from,
                "status": "active",
                # Process Outputs are composed documents, not directly in KB API
                # But we could link to the WP-{DOMAIN}-Outputs file if it exists
                "kbApiArtifactId": f"WP-{domain_code}-OUT-{output_name.replace(' ', '')}",
            })
    
    return outputs


def extract_exemplar_controls(registry: dict) -> list[dict]:
    """
    Extract exemplar controls from the framework registry.
    
    Returns:
        List of exemplar control documents ready for MongoDB
    """
    controls = {}  # Dedupe by control_id
    
    for policy_code, policy_data in registry.get("policyDomains", {}).items():
        for control_id in policy_data.get("exemplarControls", []):
            if control_id not in controls:
                # Parse ISO annex from control ID (e.g., "EXC-A5-01" -> "A.5")
                match = re.match(r"^EXC-A(\d+)-(\d+)$", control_id)
                iso_annex = None
                if match:
                    iso_annex = f"A.{match.group(1)}"
                
                controls[control_id] = {
                    "_id": control_id,
                    "ontology": "ashcai",
                    "entity_type": "ExemplarControl",
                    "semantic_type": "T9208",
                    "prefLabel": control_id,
                    "isoAnnex": iso_annex,
                    "validatesPolicies": [f"{policy_code}-001"],
                    "status": "active",
                    # Controls reference the exemplar controls doc
                    "kbApiArtifactId": "CTRL-ExemplarBase",
                }
            else:
                # Add additional policy to existing control
                policy_id = f"{policy_code}-001"
                if policy_id not in controls[control_id]["validatesPolicies"]:
                    controls[control_id]["validatesPolicies"].append(policy_id)
    
    return list(controls.values())


def extract_tools(tooling_entries: list[dict]) -> list[dict]:
    """
    Extract all tools from the tooling registry.
    
    Returns:
        List of tool documents ready for MongoDB
    """
    tools = []
    
    for entry in tooling_entries:
        token = entry.get("token", "")
        tool_id = tool_token_to_id(token)
        
        # Determine tool type from token prefix
        tool_type = "tool"
        if token.startswith("module://"):
            tool_type = "module"
        
        tools.append({
            "_id": tool_id,
            "ontology": "ashcai",
            "entity_type": "Tool",
            "semantic_type": "T9221",
            "prefLabel": entry.get("label", tool_id),
            "token": token,
            "toolType": tool_type,
            "launchTarget": entry.get("launch_target", "UI"),
            "status": "active",
            # Tools reference the tools registry doc (if we have content for them)
            "kbApiArtifactId": None,  # No direct KB API content for tools yet
        })
    
    return tools


def collect_tool_references(base_practices: list[dict]) -> set[str]:
    """
    Collect all tool references from base practices.
    
    Returns:
        Set of tool tokens referenced across all base practices
    """
    all_tokens = set()
    for bp in base_practices:
        for token in bp.get("toolingReferences", []):
            all_tokens.add(token)
    return all_tokens


# ============================================================================
# Relationship Extraction
# ============================================================================

def extract_relationships(
    base_practices: list[dict],
    sop_templates: list[dict],
    work_products: list[dict],
    process_outputs: list[dict],
    exemplar_controls: list[dict],
    tools: list[dict],
) -> list[dict]:
    """
    Extract all relationships between lower-level entities.
    
    Relationship types created:
        - containsBasePractice: ProcessDomain -> BasePractice
        - realizedBy: BasePractice -> SOPTemplate
        - produces: SOPTemplate -> WorkProductTemplate
        - composedFrom: ProcessOutput -> WorkProductTemplate
        - validatedBy: PolicyDomain -> ExemplarControl
        - requires: BasePractice -> Tool
    """
    relationships = []
    timestamp = datetime.now(UTC).isoformat()
    
    def make_rel(source_id: str, source_type: str, target_id: str, 
                 target_type: str, rel_type: str) -> dict:
        return {
            "ontology": "ashcai",
            "source_id": source_id,
            "source_type": source_type,
            "target_id": target_id,
            "target_type": target_type,
            "relationship_type": rel_type,
            "created_at": timestamp,
            "created_by": "cai-populate-lower-levels",
            "status": "active",
        }
    
    # Build a lookup map for tool tokens -> tool IDs
    tool_id_map = {tool.get("token"): tool["_id"] for tool in tools if tool.get("token")}
    
    # ProcessDomain -> BasePractice (containsBasePractice)
    for bp in base_practices:
        domain = bp.get("processDomain")
        if domain:
            relationships.append(make_rel(
                domain, "ProcessDomain",
                bp["_id"], "BasePractice",
                "containsBasePractice"
            ))
        
        # BasePractice -> Tool (requires)
        for tool_token in bp.get("toolingReferences", []):
            tool_id = tool_id_map.get(tool_token)
            if tool_id:
                relationships.append(make_rel(
                    bp["_id"], "BasePractice",
                    tool_id, "Tool",
                    "requires"
                ))
            else:
                logger.debug(f"Tool token not found in registry: {tool_token}")
    
    # BasePractice -> SOPTemplate (realizedBy)
    for sop in sop_templates:
        for bp_id in sop.get("basePractices", []):
            relationships.append(make_rel(
                bp_id, "BasePractice",
                sop["_id"], "SOPTemplate",
                "realizedBy"
            ))
    
    # SOPTemplate -> WorkProductTemplate (produces)
    for sop in sop_templates:
        for wp_filename in sop.get("outputs", []):
            wp_id = normalize_wp_id(wp_filename)
            relationships.append(make_rel(
                sop["_id"], "SOPTemplate",
                wp_id, "WorkProductTemplate",
                "produces"
            ))
    
    # ProcessOutput -> WorkProductTemplate (composedFrom)
    for po in process_outputs:
        for wp_id in po.get("composedFrom", []):
            relationships.append(make_rel(
                po["_id"], "ProcessOutput",
                wp_id, "WorkProductTemplate",
                "composedFrom"
            ))
    
    # PolicyDomain -> ExemplarControl (validatedBy)
    for ctrl in exemplar_controls:
        for policy_id in ctrl.get("validatesPolicies", []):
            relationships.append(make_rel(
                policy_id, "PolicyDomain",
                ctrl["_id"], "ExemplarControl",
                "validatedBy"
            ))
    
    return relationships


# ============================================================================
# Database Operations
# ============================================================================

class AshcaiLowerLevelPopulator:
    """Populates lower-level ASHCAI ontology entities."""
    
    def __init__(
        self,
        mongodb_uri: str,
        database_name: str,
        repo_root: Path,
        dry_run: bool = False,
        only: str | None = None,
    ):
        self.mongodb_uri = mongodb_uri
        self.database_name = database_name
        self.repo_root = repo_root
        self.dry_run = dry_run
        self.only = only
        self.client = None
        self.db = None
        
        self.stats = {
            "base_practices": 0,
            "sop_templates": 0,
            "work_products": 0,
            "process_outputs": 0,
            "exemplar_controls": 0,
            "tools": 0,
            "relationships": 0,
            "errors": [],
        }
    
    async def connect(self):
        """Establish MongoDB connection."""
        self.client = AsyncIOMotorClient(self.mongodb_uri)
        self.db = self.client[self.database_name]
        await self.client.admin.command("ping")
        logger.info(f"Connected to MongoDB: {self.database_name}")
    
    async def disconnect(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
    
    async def populate(self) -> dict:
        """Run the population process."""
        try:
            await self.connect()
            
            # Load source data
            console.print("[bold]Loading source data...[/bold]")
            process_domains = load_process_domain_files(self.repo_root)
            traceability = load_traceability_files(self.repo_root)
            registry = load_framework_registry(self.repo_root)
            tooling_entries = load_tooling_registry(self.repo_root)
            
            console.print(f"  Loaded {len(process_domains)} process domain files")
            console.print(f"  Loaded {len(traceability)} traceability files")
            console.print(f"  Loaded {len(tooling_entries)} tooling entries")
            
            # Extract entities
            console.print("\n[bold]Extracting entities...[/bold]")
            
            base_practices = extract_base_practices(process_domains)
            console.print(f"  {len(base_practices)} base practices")
            
            sop_templates = extract_sop_templates(process_domains)
            console.print(f"  {len(sop_templates)} SOP templates")
            
            work_products = extract_work_products(process_domains, traceability)
            console.print(f"  {len(work_products)} work products")
            
            process_outputs = extract_process_outputs(process_domains)
            console.print(f"  {len(process_outputs)} process outputs")
            
            exemplar_controls = extract_exemplar_controls(registry)
            console.print(f"  {len(exemplar_controls)} exemplar controls")
            
            tools = extract_tools(tooling_entries)
            console.print(f"  {len(tools)} tools")
            
            # Report on tool reference coverage
            referenced_tokens = collect_tool_references(base_practices)
            registered_tokens = {t.get("token") for t in tools}
            unregistered = referenced_tokens - registered_tokens
            if unregistered:
                console.print(f"  [yellow]Warning: {len(unregistered)} tool tokens referenced but not in registry[/yellow]")
                for token in sorted(unregistered)[:5]:
                    console.print(f"    - {token}")
                if len(unregistered) > 5:
                    console.print(f"    ... and {len(unregistered) - 5} more")
            
            # Extract relationships
            relationships = extract_relationships(
                base_practices, sop_templates, work_products,
                process_outputs, exemplar_controls, tools
            )
            console.print(f"  {len(relationships)} relationships")
            
            # Insert entities
            console.print("\n[bold]Inserting entities...[/bold]")
            
            if not self.only or self.only == "base-practices":
                await self._upsert_entities("ashcai_base_practices", base_practices, "_id")
                self.stats["base_practices"] = len(base_practices)
            
            if not self.only or self.only == "sops":
                await self._upsert_entities("ashcai_sop_templates", sop_templates, "_id")
                self.stats["sop_templates"] = len(sop_templates)
            
            if not self.only or self.only == "work-products":
                await self._upsert_entities("ashcai_work_product_templates", work_products, "_id")
                self.stats["work_products"] = len(work_products)
            
            if not self.only or self.only == "process-outputs":
                # Note: May need to add this collection if not in init script
                await self._upsert_entities("ashcai_process_outputs", process_outputs, "_id")
                self.stats["process_outputs"] = len(process_outputs)
            
            if not self.only or self.only == "controls":
                await self._upsert_entities("ashcai_exemplar_controls", exemplar_controls, "_id")
                self.stats["exemplar_controls"] = len(exemplar_controls)
            
            if not self.only or self.only == "tools":
                await self._upsert_entities("ashcai_tools", tools, "_id")
                self.stats["tools"] = len(tools)
            
            # Insert relationships (always, unless --only specified)
            if not self.only:
                await self._upsert_relationships(relationships)
                self.stats["relationships"] = len(relationships)
            
            return self.stats
            
        finally:
            await self.disconnect()
    
    async def _upsert_entities(self, collection_name: str, entities: list[dict], key_field: str):
        """Upsert a list of entities into a collection."""
        if not entities:
            return
        
        collection = self.db[collection_name]
        timestamp = datetime.now(UTC)
        
        for entity in entities:
            entity["updated_at"] = timestamp
            if "created_at" not in entity:
                entity["created_at"] = timestamp
            
            if self.dry_run:
                logger.debug(f"[DRY RUN] Would upsert {entity[key_field]} to {collection_name}")
            else:
                try:
                    await collection.update_one(
                        {key_field: entity[key_field]},
                        {"$set": entity},
                        upsert=True
                    )
                except Exception as e:
                    logger.warning(f"Failed to upsert {entity[key_field]}: {e}")
                    self.stats["errors"].append(str(e))
        
        action = "[DRY RUN] Would insert" if self.dry_run else "Inserted"
        console.print(f"  {action} {len(entities)} entities to {collection_name}")
    
    async def _upsert_relationships(self, relationships: list[dict]):
        """Upsert relationships into the relationships collection."""
        if not relationships:
            return
        
        collection = self.db["ashcai_relationships"]
        
        for rel in relationships:
            unique_key = {
                "source_id": rel["source_id"],
                "target_id": rel["target_id"],
                "relationship_type": rel["relationship_type"],
            }
            
            if self.dry_run:
                logger.debug(f"[DRY RUN] Would upsert relationship: {rel['source_id']} -> {rel['target_id']}")
            else:
                try:
                    await collection.update_one(
                        unique_key,
                        {"$set": rel},
                        upsert=True
                    )
                except Exception as e:
                    logger.warning(f"Failed to upsert relationship: {e}")
                    self.stats["errors"].append(str(e))
        
        action = "[DRY RUN] Would insert" if self.dry_run else "Inserted"
        console.print(f"  {action} {len(relationships)} relationships")


# ============================================================================
# CLI
# ============================================================================

def display_results(stats: dict, dry_run: bool):
    """Display population results."""
    table = Table(title="ASHCAI Lower-Level Population Results")
    table.add_column("Entity Type", style="cyan")
    table.add_column("Count", style="green")
    
    prefix = "[DRY RUN] " if dry_run else ""
    
    table.add_row(f"{prefix}Base Practices", str(stats["base_practices"]))
    table.add_row(f"{prefix}SOP Templates", str(stats["sop_templates"]))
    table.add_row(f"{prefix}Work Products", str(stats["work_products"]))
    table.add_row(f"{prefix}Process Outputs", str(stats["process_outputs"]))
    table.add_row(f"{prefix}Exemplar Controls", str(stats["exemplar_controls"]))
    table.add_row(f"{prefix}Tools", str(stats["tools"]))
    table.add_row(f"{prefix}Relationships", str(stats["relationships"]))
    
    if stats["errors"]:
        table.add_row("Errors", str(len(stats["errors"])))
    
    console.print(table)
    
    if stats["errors"]:
        console.print("\n[bold red]Errors:[/bold red]")
        for error in stats["errors"][:10]:  # Show first 10
            console.print(f"  - {error}")
        if len(stats["errors"]) > 10:
            console.print(f"  ... and {len(stats['errors']) - 10} more")


async def run_population(args: argparse.Namespace) -> int:
    """Run the population process."""
    # Load environment from script's repo root (where ashmatics-tools.env lives)
    script_repo_root = find_script_repo_root(Path(__file__))
    if script_repo_root:
        env_file = script_repo_root / "ashmatics-tools.env"
        if env_file.exists():
            load_dotenv(env_file)
            logger.info(f"Loaded environment from: {env_file}")
        else:
            load_dotenv()  # Fall back to default .env search
            logger.warning(f"ashmatics-tools.env not found at {script_repo_root}, using default .env search")
    else:
        load_dotenv()
        logger.warning("Could not find script repo root, using default .env search")

    # Find data repo root (ashmatics-policy-process-builder)
    if args.repo_path:
        repo_root = Path(args.repo_path)
    else:
        repo_root = find_repo_root()
    
    if not repo_root or not repo_root.exists():
        console.print("[bold red]Error: Could not find ashmatics-policy-process-builder repo[/bold red]")
        return 1
    
    console.print(f"[bold]ASHCAI Lower-Level Populator[/bold]")
    console.print(f"Repo: {repo_root}")
    console.print(f"KB API Base: {KB_API_BASE_URL}")
    
    # MongoDB connection
    mongodb_uri = args.mongodb_uri or os.getenv("AZ_MONGO_CONNECTION_STRING", "mongodb://localhost:27017")
    database_name = args.database or os.getenv("MONGODB_DATABASE", "ai_strategy")
    
    console.print(f"Database: {database_name}")
    if args.dry_run:
        console.print("[yellow]DRY RUN MODE - No changes will be made[/yellow]")
    if args.only:
        console.print(f"[cyan]Only populating: {args.only}[/cyan]")
    console.print()
    
    # Run population
    populator = AshcaiLowerLevelPopulator(
        mongodb_uri=mongodb_uri,
        database_name=database_name,
        repo_root=repo_root,
        dry_run=args.dry_run,
        only=args.only,
    )
    
    try:
        stats = await populator.populate()
        console.print()
        display_results(stats, args.dry_run)
        
        if stats["errors"]:
            return 1
        return 0
    
    except Exception as e:
        console.print(f"[bold red]Population failed: {e}[/bold red]")
        logger.exception("Population error")
        return 1


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Populate lower-level ASHCAI ontology entities",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "--repo-path",
        help="Path to ashmatics-policy-process-builder repo",
    )
    parser.add_argument(
        "--mongodb-uri",
        help="MongoDB connection URI",
    )
    parser.add_argument(
        "--database",
        help="MongoDB database name",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview without making changes",
    )
    parser.add_argument(
        "--only",
        choices=["base-practices", "sops", "work-products", "process-outputs", "controls", "tools"],
        help="Only populate specific entity type",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging",
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    sys.exit(asyncio.run(run_population(args)))


if __name__ == "__main__":
    main()
