#!/usr/bin/env python3
# Copyright 2025 Asher Informatics PBC
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     https://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Register Existing Framework Content with Knowledge Base

Created 2025-11-20 JF Kalafut


This script registers already-uploaded framework content from Azure Container Storage
with the Ashmatics Knowledge Base via Hasura API.

Usage:
    python register_existing_content.py [--version=2024.12.17-183045] [--dry-run] [--force-refresh]
"""

import argparse
import logging
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from ashmatics_aigov_tools.importers.framework_content import (
    FrameworkContentImporter,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def load_environment_config() -> dict:
    """Load configuration from environment variables."""

    # Load both .env files to get all needed variables
    env_files_loaded = []

    # Get current script directory for finding .env files
    script_dir = Path(__file__).parent

    # Load .env first (for Azure Storage)
    for env_path in [Path.cwd() / ".env", script_dir.parent.parent.parent / ".env"]:
        if env_path.exists():
            load_dotenv(env_path)
            env_files_loaded.append(str(env_path))
            break

    # Then load ashmatics-tools.env (for MongoDB and other configs)
    for env_path in [
        Path.cwd() / "ashmatics-tools.env",
        script_dir.parent.parent.parent / "ashmatics-tools.env",
    ]:
        if env_path.exists():
            load_dotenv(env_path)
            env_files_loaded.append(str(env_path))
            break

    if env_files_loaded:
        logger.info(f"Loading environment from: {', '.join(env_files_loaded)}")
    else:
        logger.warning("No .env files found, using environment variables only")

    # Extract required configuration
    config = {
        "azure_connection_string": os.getenv("AZURE_STORAGE_CONNECTION_STRING"),
        "hasura_endpoint": os.getenv(
            "HASURA_GRAPHQL_ENDPOINT", "https://kb-graphql.ashmatics.com/v1/graphql"
        ),
        "hasura_admin_secret": os.getenv(
            "HASURA_ADMIN_SECRET", "ashmatics_hasura_admin_key"
        ),
        "framework_repo_path": os.getenv(
            "FRAMEWORK_REPO_PATH", str(Path.cwd().parent.parent / "ashmatics-framework")
        ),
        "container_name": os.getenv("AZURE_FRAMEWORK_CONTAINER", "framework-content"),
        "kb_table_name": os.getenv("KB_TABLE_NAME", "framework_content_registry"),
        "mongo_connection_string": os.getenv("AZ_MONGO_CONNECTION_STRING"),
        "mongo_database": os.getenv("MONGO_DATABASE", "ashmatics_kb"),
        "mongo_collection": os.getenv("MONGO_COLLECTION", "framework_compiled_views"),
        "force_adls_gen2": os.getenv("FORCE_ADLS_GEN2", "false").lower() == "true",
    }

    return config


def validate_config(config: dict) -> bool:
    """Validate that required configuration is present."""
    required_keys = ["azure_connection_string"]
    missing_keys = [key for key in required_keys if not config.get(key)]

    if missing_keys:
        logger.error(f"Missing required configuration: {', '.join(missing_keys)}")
        logger.error("Please set the following environment variables:")
        for key in missing_keys:
            if key == "azure_connection_string":
                logger.error(
                    "  AZURE_STORAGE_CONNECTION_STRING - Azure Storage connection string"
                )
        return False

    return True


def main():
    """Main registration function."""
    parser = argparse.ArgumentParser(
        description="Register existing framework content with Knowledge Base"
    )
    parser.add_argument(
        "--version",
        type=str,
        help="Framework version to register (defaults to auto-detected latest)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be registered without actually doing it",
    )
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Force refresh of Azure manifest even if cached",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="Skip verification of Azure content existence",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument(
        "--hybrid",
        action="store_true",
        help="Perform hybrid registration (Postgres + MongoDB)",
    )
    parser.add_argument(
        "--skip-postgres",
        action="store_true",
        help="Skip Postgres registration (hybrid mode only)",
    )
    parser.add_argument(
        "--skip-mongodb",
        action="store_true",
        help="Skip MongoDB compilation (hybrid mode only)",
    )
    parser.add_argument(
        "--validate-mapping",
        action="store_true",
        help="Validate artifact_id mapping consistency after registration",
    )

    args = parser.parse_args()

    # Configure logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    logger.info("🚀 Starting framework content KB registration")

    # Load configuration
    config = load_environment_config()
    if not validate_config(config):
        sys.exit(1)

    try:
        # Initialize importer
        logger.info("📋 Initializing Framework Content Importer")

        if not args.version:
            logger.info("🔍 No version specified, will set to 0.8.0")
            args.version = "0.8.0"  

        importer = FrameworkContentImporter(
            framework_repo_path=config["framework_repo_path"],
            azure_connection_string=config["azure_connection_string"],
            kb_table_name=config["kb_table_name"],
            container_name=config["container_name"],
            version=args.version,
            mongo_connection_string=config["mongo_connection_string"],
            mongo_database=config["mongo_database"],
            mongo_collection=config["mongo_collection"],
            graphql_endpoint=config["hasura_endpoint"],
            admin_secret=config["hasura_admin_secret"],
            verify_ssl=True,
            force_adls_gen2=config["force_adls_gen2"],
        )

        # Show current version info
        version_info = importer.get_current_version_info()
        if version_info:
            logger.info(f"📊 Framework version: {version_info['version']}")
            logger.info(f"📁 Framework path: {version_info['framework_path']}")

        # Dry run mode
        if args.dry_run:
            logger.info("🔍 DRY RUN MODE - No actual registration will occur")

            # Just verify Azure content exists
            if importer.uploader.container_exists():
                version_prefix = f"v{importer.uploader.version}/"
                blobs = importer.uploader.list_container_blobs(prefix=version_prefix)
                logger.info(
                    f"✅ Found {len(blobs)} files in Azure container for version {importer.uploader.version}"
                )

                # Show some examples
                for _i, blob in enumerate(blobs[:5]):
                    logger.info(f"   📄 {blob['name']} ({blob['size']} bytes)")
                if len(blobs) > 5:
                    logger.info(f"   ... and {len(blobs) - 5} more files")
            else:
                logger.error("❌ Azure container does not exist")
                sys.exit(1)

            logger.info(
                "🔍 Dry run completed - use without --dry-run to perform actual registration"
            )
            return

        # Perform registration
        if args.hybrid:
            logger.info("🚀 Performing hybrid registration (Postgres + MongoDB)")

            success, results = importer.register_full_hybrid_content(
                force_refresh=args.force_refresh,
                verify_azure_content=not args.no_verify,
                skip_postgres=args.skip_postgres,
                skip_mongodb=args.skip_mongodb,
            )
        else:
            logger.info(
                "🗃️ Registering existing content with Knowledge Base (Postgres only)"
            )

            success, results = importer.register_existing_content_with_kb(
                force_refresh=args.force_refresh,
                verify_azure_content=not args.no_verify,
            )

        # Show results
        if success:
            logger.info("✅ Registration completed successfully!")

            # Handle hybrid mode results
            if args.hybrid and "hybrid_strategy" in results:
                logger.info("📊 Hybrid Registration Results:")

                # Postgres results
                if (
                    "postgres_registration" in results
                    and results["postgres_registration"]
                ):
                    pg_results = results["postgres_registration"]
                    if "kb_registration" in pg_results:
                        kb_results = pg_results["kb_registration"]

                        if "main_record" in kb_results:
                            main = kb_results["main_record"]
                            logger.info(
                                f"   📊 Postgres main record: {'✅' if main['success'] else '❌'}"
                            )

                        if "content_records" in kb_results:
                            content = kb_results["content_records"]
                            logger.info(
                                f"   📄 Postgres files registered: {content['successful']}/{content['total']}"
                            )
                            if content["failed"] > 0:
                                logger.warning(
                                    f"   ⚠️ Postgres registration failures: {content['failed']} files"
                                )

                # MongoDB results
                if "mongodb_compilation" in results and results["mongodb_compilation"]:
                    mongo_results = results["mongodb_compilation"]
                    if "mongodb_storage" in mongo_results:
                        storage = mongo_results["mongodb_storage"]
                        logger.info(
                            f"   💾 MongoDB views stored: {storage['successful']}/{mongo_results.get('compiled_views_created', 0)}"
                        )
                        if storage["failed"] > 0:
                            logger.warning(
                                f"   ⚠️ MongoDB storage failures: {storage['failed']} views"
                            )

                    if (
                        "compilation_errors" in mongo_results
                        and mongo_results["compilation_errors"]
                    ):
                        logger.warning(
                            f"   ⚠️ Compilation errors: {len(mongo_results['compilation_errors'])}"
                        )

            # Handle standard mode results
            elif "kb_registration" in results:
                kb_results = results["kb_registration"]

                if "main_record" in kb_results:
                    main = kb_results["main_record"]
                    logger.info(
                        f"   📊 Main registry record: {'✅' if main['success'] else '❌'}"
                    )

                if "content_records" in kb_results:
                    content = kb_results["content_records"]
                    logger.info(
                        f"   📄 Content files registered: {content['successful']}/{content['total']}"
                    )
                    if content["failed"] > 0:
                        logger.warning(
                            f"   ⚠️ Failed to register: {content['failed']} files"
                        )

            framework_version = results.get("framework_version", "unknown")
            logger.info(
                f"🎉 Framework version {framework_version} is now registered in Knowledge Base"
            )
            
            # Optional: Validate artifact_id mapping consistency
            if args.validate_mapping:
                logger.info("🔍 Starting artifact_id mapping validation...")
                
                try:
                    is_consistent, validation_results = importer.validate_artifact_id_mapping(
                        framework_version=framework_version
                    )
                    
                    if is_consistent:
                        logger.info("✅ Artifact ID mapping validation passed!")
                        logger.info(f"   📊 Validated {validation_results['matching_mappings']} consistent mappings")
                        logger.info(f"   📄 PostgreSQL records: {validation_results['postgres_records']}")
                        logger.info(f"   💾 MongoDB records: {validation_results['mongodb_records']}")
                    else:
                        logger.warning("⚠️ Artifact ID mapping validation found inconsistencies:")
                        
                        if validation_results.get('missing_in_postgres'):
                            logger.warning(f"   Missing in PostgreSQL: {len(validation_results['missing_in_postgres'])} files")
                            
                        if validation_results.get('missing_in_mongodb'):
                            logger.warning(f"   Missing in MongoDB: {len(validation_results['missing_in_mongodb'])} files")
                            
                        if validation_results.get('mismatched_paths'):
                            logger.warning(f"   Mismatched artifact_ids: {len(validation_results['mismatched_paths'])} files")
                            
                        logger.warning("   Consider re-running registration or manually fixing the mappings")
                        
                except Exception as validation_error:
                    logger.error(f"❌ Validation failed: {str(validation_error)}")
                    if args.verbose:
                        import traceback
                        logger.error(traceback.format_exc())

        else:
            logger.error("❌ Registration failed")
            if "error" in results:
                logger.error(f"   Error: {results['error']}")
            sys.exit(1)

    except KeyboardInterrupt:
        logger.info("\n⏹️ Registration cancelled by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"💥 Registration failed with exception: {str(e)}")
        logger.error(f"   Exception type: {type(e).__name__}")
        if args.verbose:
            import traceback

            logger.error(f"   Traceback:\n{traceback.format_exc()}")
        sys.exit(1)


if __name__ == "__main__":
    main()
