#!/usr/bin/env python3
# Copyright 2026 Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
AI Gov Framework Relationship Extractor

Created: 2026-01-11 JF Kalafut (ASHKBAPP-60)

CLI tool for extracting hierarchical relationships from the AshMatics Clinical AI
Governance Framework content and populating the `aigov_relationships` collection
in MongoDB/CosmosDB.

This tool parses the framework documents to extract:
- Policy → Process Domain activation relationships
- Process → SOP linkages (via linked_process in YAML frontmatter)
- SOP → Work Product output relationships
- ISO 42001 Control → Exemplar → Policy/SOP mapping chains
- Role → SOP responsibility assignments

The extracted relationships are used by the KnowledgeBase's AIGovGraphService
for graph traversals, hierarchy queries, and control traceability.

Usage:
    # Extract and upload relationships (default: framework v0.8.0)
    cai-extract-relationships --version 0.8.0

    # Dry run to preview what would be extracted
    cai-extract-relationships --version 0.8.0 --dry-run

    # Extract specific relationship types only
    cai-extract-relationships --types hierarchy controls

    # Output to JSON file instead of MongoDB
    cai-extract-relationships --output relationships.json

    # Specify custom framework path
    cai-extract-relationships --framework-path ../ashmatics-policy-process-builder
"""

import argparse
import asyncio
import json
import logging
import os
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# ============================================================================
# Relationship Type Definitions (mirror AIGovRelationshipType enum from KB)
# ============================================================================

class AIGovRelationshipType:
    """Relationship types for AI Governance Framework artifacts.

    Note: This mirrors the enum in the Knowledgebase's aigov_relationship_schema.py
    """
    # Hierarchical relationships
    POLICY_ACTIVATES_DOMAIN = "policy_activates_domain"
    POLICY_CONTAINS_PROCESS = "policy_contains_process"
    PROCESS_CONTAINS_SOP = "process_contains_sop"
    SOP_PRODUCES_WORKPRODUCT = "sop_produces_workproduct"
    WORKPRODUCT_EVIDENCES_CONTROL = "workproduct_evidences_control"

    # Control framework mappings
    SOP_IMPLEMENTS_CONTROL = "sop_implements_control"
    MAPS_TO_NIST_RMF = "maps_to_nist_rmf"
    MAPS_TO_ISO42001 = "maps_to_iso42001"
    MAPS_TO_HITRUST = "maps_to_hitrust"
    MAPS_TO_SOC2 = "maps_to_soc2"
    EXEMPLAR_IMPLEMENTS_ISO = "exemplar_implements_iso"

    # Cross-references
    REFERENCES = "references"
    DEPENDS_ON = "depends_on"
    RELATED_TO = "related_to"

    # Role relationships
    OWNED_BY_ROLE = "owned_by_role"
    PERFORMED_BY_ROLE = "performed_by_role"


class AIGovRelationshipSource:
    """Source indicators for how relationships were created."""
    FRAMEWORK_STRUCTURE = "framework_structure"
    YAML_FRONTMATTER = "yaml_frontmatter"
    CONTROL_REGISTRY = "control_registry"
    POLICY_BINDING_MATRIX = "policy_binding_matrix"
    MANUAL = "manual"


# ============================================================================
# Relationship Extraction Classes
# ============================================================================

class RelationshipExtractor:
    """
    Extracts relationships from AI Governance Framework content.

    Parses the hierarchical structure of policies, processes, SOPs, and
    work products to build a comprehensive relationship graph.
    """

    def __init__(self, framework_path: Path, framework_version: str = "0.8.0"):
        """
        Initialize the relationship extractor.

        Args:
            framework_path: Path to the ashmatics-policy-process-builder repo
            framework_version: Version of the framework being processed
        """
        self.framework_path = framework_path
        self.framework_version = framework_version
        self.relationships: list[dict[str, Any]] = []
        self.errors: list[str] = []
        self.stats = {
            "policies_processed": 0,
            "process_domains_processed": 0,
            "sops_processed": 0,
            "work_products_processed": 0,
            "controls_processed": 0,
            "relationships_created": 0,
        }

    def extract_all(self) -> list[dict[str, Any]]:
        """
        Extract all relationships from the framework.

        Returns:
            List of relationship dictionaries ready for MongoDB insertion
        """
        logger.info(f"🔍 Extracting relationships from: {self.framework_path}")
        logger.info(f"📌 Framework version: {self.framework_version}")

        # Extract in dependency order
        self._extract_framework_registry_relationships()
        self._extract_policy_domain_relationships()
        self._extract_process_domain_relationships()
        self._extract_sop_relationships()
        self._extract_control_mappings()

        logger.info(f"✅ Extraction complete: {len(self.relationships)} relationships found")
        self._log_stats()

        return self.relationships

    def _extract_framework_registry_relationships(self):
        """Extract relationships from the master framework registry."""
        registry_path = self.framework_path / "ashmatics-framework-registry.json"

        if not registry_path.exists():
            logger.warning(f"⚠️  Framework registry not found: {registry_path}")
            return

        try:
            with open(registry_path) as f:
                registry = json.load(f)

            # Extract policy domain → process domain activations
            policy_domains = registry.get("policyDomains", {})

            for policy_code, policy_info in policy_domains.items():
                activated_domains = policy_info.get("activatesProcessDomains", [])

                for process_domain in activated_domains:
                    self._add_relationship(
                        source_id=f"POL-{policy_code}",
                        source_type="policy",
                        target_id=f"DOMAIN-{process_domain}",
                        target_type="process_domain",
                        relationship_type=AIGovRelationshipType.POLICY_ACTIVATES_DOMAIN,
                        source=AIGovRelationshipSource.FRAMEWORK_STRUCTURE,
                        metadata={
                            "policy_code": policy_code,
                            "process_domain": process_domain,
                            "tier": policy_info.get("tier"),
                        }
                    )

                # Extract ISO control mappings from registry
                iso_controls = policy_info.get("iso42001Controls", [])
                for control_id in iso_controls:
                    self._add_relationship(
                        source_id=f"POL-{policy_code}",
                        source_type="policy",
                        target_id=f"ISO-{control_id}",
                        target_type="iso_control",
                        relationship_type=AIGovRelationshipType.MAPS_TO_ISO42001,
                        source=AIGovRelationshipSource.FRAMEWORK_STRUCTURE,
                        metadata={"control_id": control_id}
                    )

                self.stats["policies_processed"] += 1

            logger.info(f"📋 Processed framework registry: {len(policy_domains)} policy domains")

        except Exception as e:
            self.errors.append(f"Error processing framework registry: {e}")
            logger.error(f"❌ Error processing framework registry: {e}")

    def _extract_policy_domain_relationships(self):
        """Extract relationships from policy domain documents."""
        policy_dir = self.framework_path / "policy-domain"

        if not policy_dir.exists():
            logger.warning(f"⚠️  Policy domain directory not found: {policy_dir}")
            return

        # Process each policy domain directory
        for domain_dir in policy_dir.iterdir():
            if not domain_dir.is_dir():
                continue

            domain_code = domain_dir.name.upper()

            # Look for policy template files
            for policy_file in domain_dir.glob("ash-*-policy-TEMP.md"):
                self._process_policy_template(policy_file, domain_code)

            # Look for token files for additional metadata
            for token_file in domain_dir.glob("*-policy-tokens.json"):
                self._process_policy_tokens(token_file, domain_code)

    def _process_policy_template(self, policy_file: Path, domain_code: str):
        """Process a policy template file for relationships."""
        try:
            content = policy_file.read_text(encoding="utf-8")
            frontmatter = self._extract_yaml_frontmatter(content)

            if not frontmatter:
                return

            policy_id = f"POL-{domain_code}"

            # Extract linked base practices
            linked_practices = frontmatter.get("linkedBasePractices", [])
            for practice in linked_practices:
                # Practice format: "ORG.BP01"
                if "." in practice:
                    process_domain = practice.split(".")[0]
                    self._add_relationship(
                        source_id=policy_id,
                        source_type="policy",
                        target_id=f"BP-{practice}",
                        target_type="base_practice",
                        relationship_type=AIGovRelationshipType.POLICY_CONTAINS_PROCESS,
                        source=AIGovRelationshipSource.YAML_FRONTMATTER,
                        metadata={
                            "practice_id": practice,
                            "process_domain": process_domain,
                        }
                    )

            # Extract linked SOPs
            linked_sops = frontmatter.get("linkedSOPs", [])
            for sop in linked_sops:
                sop_id = sop.get("sop_id") if isinstance(sop, dict) else sop
                if sop_id:
                    self._add_relationship(
                        source_id=policy_id,
                        source_type="policy",
                        target_id=sop_id,
                        target_type="sop",
                        relationship_type=AIGovRelationshipType.PROCESS_CONTAINS_SOP,
                        source=AIGovRelationshipSource.YAML_FRONTMATTER,
                        metadata=sop if isinstance(sop, dict) else {"sop_id": sop_id}
                    )

        except Exception as e:
            self.errors.append(f"Error processing policy template {policy_file}: {e}")
            logger.warning(f"⚠️  Error processing {policy_file.name}: {e}")

    def _process_policy_tokens(self, token_file: Path, domain_code: str):
        """Process policy token files for additional metadata."""
        try:
            with open(token_file) as f:
                tokens = json.load(f)

            # Extract cross-domain references from tokens
            for token in tokens.get("tokens", []):
                token_name = token.get("token", "")

                # Look for registry/repository path references
                if "RegistryPath" in token_name or "RepositoryPath" in token_name:
                    # Extract referenced domain from token name
                    match = re.match(r"\{\{(\w+)(?:Registry|Repository)Path\}\}", token_name)
                    if match:
                        ref_domain = match.group(1).upper()
                        self._add_relationship(
                            source_id=f"POL-{domain_code}",
                            source_type="policy",
                            target_id=f"DOMAIN-{ref_domain}",
                            target_type="process_domain",
                            relationship_type=AIGovRelationshipType.REFERENCES,
                            source=AIGovRelationshipSource.YAML_FRONTMATTER,
                            metadata={"token": token_name}
                        )

        except Exception as e:
            self.errors.append(f"Error processing token file {token_file}: {e}")

    def _extract_process_domain_relationships(self):
        """Extract relationships from process domain JSON files."""
        process_dir = self.framework_path / "process-domain"

        if not process_dir.exists():
            logger.warning(f"⚠️  Process domain directory not found: {process_dir}")
            return

        for domain_file in process_dir.glob("*-process-domain.json"):
            self._process_domain_json(domain_file)

    def _process_domain_json(self, domain_file: Path):
        """Process a process domain JSON file."""
        try:
            with open(domain_file) as f:
                domain_data = json.load(f)

            domain_metadata = domain_data.get("domain_metadata", {})
            domain_id = domain_metadata.get("process_id", "")

            if not domain_id:
                return

            self.stats["process_domains_processed"] += 1

            # Extract base practices and their work products
            base_practices = domain_data.get("base_practices", [])

            for practice in base_practices:
                practice_id = practice.get("practice_id", "")

                if not practice_id:
                    continue

                # Link domain to base practice
                self._add_relationship(
                    source_id=f"DOMAIN-{domain_id}",
                    source_type="process_domain",
                    target_id=f"BP-{practice_id}",
                    target_type="base_practice",
                    relationship_type=AIGovRelationshipType.POLICY_CONTAINS_PROCESS,
                    source=AIGovRelationshipSource.FRAMEWORK_STRUCTURE,
                    metadata={
                        "practice_name": practice.get("name"),
                        "domain": domain_id,
                    }
                )

                # Link practice to work products
                work_products = practice.get("work_products", [])
                for wp in work_products:
                    wp_id = wp if isinstance(wp, str) else wp.get("id", "")
                    if wp_id:
                        # Extract WP ID from filename if needed
                        wp_match = re.search(r"(WP-[A-Z]+-\d+)", wp_id)
                        if wp_match:
                            wp_id = wp_match.group(1)

                        self._add_relationship(
                            source_id=f"BP-{practice_id}",
                            source_type="base_practice",
                            target_id=wp_id,
                            target_type="work_product",
                            relationship_type=AIGovRelationshipType.SOP_PRODUCES_WORKPRODUCT,
                            source=AIGovRelationshipSource.FRAMEWORK_STRUCTURE,
                            metadata={"work_product_file": wp if isinstance(wp, str) else None}
                        )
                        self.stats["work_products_processed"] += 1

            # Extract process outputs (composed work products)
            process_outputs = domain_data.get("process_outputs", [])
            for output in process_outputs:
                output_name = output.get("name", "")
                composed_from = output.get("composed_from", [])

                for component in composed_from:
                    wp_match = re.search(r"(WP-[A-Z]+-\d+)", component)
                    if wp_match:
                        self._add_relationship(
                            source_id=f"OUTPUT-{domain_id}-{output_name.replace(' ', '_')}",
                            source_type="process_output",
                            target_id=wp_match.group(1),
                            target_type="work_product",
                            relationship_type=AIGovRelationshipType.DEPENDS_ON,
                            source=AIGovRelationshipSource.FRAMEWORK_STRUCTURE,
                            metadata={"output_name": output_name}
                        )

            logger.debug(f"  Processed domain: {domain_id} ({len(base_practices)} practices)")

        except Exception as e:
            self.errors.append(f"Error processing domain file {domain_file}: {e}")
            logger.warning(f"⚠️  Error processing {domain_file.name}: {e}")

    def _extract_sop_relationships(self):
        """Extract relationships from SOP markdown files."""
        sop_base_dir = self.framework_path / "ash-gov-process-model"

        if not sop_base_dir.exists():
            logger.warning(f"⚠️  SOP directory not found: {sop_base_dir}")
            return

        # Find all SOP files recursively
        sop_files = list(sop_base_dir.rglob("SOP-*.md"))
        logger.info(f"📄 Found {len(sop_files)} SOP files in {sop_base_dir}")

        for sop_file in sop_files:
            self._process_sop_file(sop_file)

    def _process_sop_file(self, sop_file: Path):
        """Process an SOP markdown file for relationships."""
        try:
            content = sop_file.read_text(encoding="utf-8")
            frontmatter = self._extract_yaml_frontmatter(content)

            if not frontmatter:
                return

            sop_id = frontmatter.get("sop_id", "")
            if not sop_id:
                # Try to extract from filename
                match = re.search(r"(SOP-[A-Z]+-\d+)", sop_file.name)
                if match:
                    sop_id = match.group(1)
                else:
                    return

            self.stats["sops_processed"] += 1

            # Link SOP to its process/base practice
            linked_process = frontmatter.get("linked_process", "")
            if linked_process:
                self._add_relationship(
                    source_id=f"BP-{linked_process}",
                    source_type="base_practice",
                    target_id=sop_id,
                    target_type="sop",
                    relationship_type=AIGovRelationshipType.PROCESS_CONTAINS_SOP,
                    source=AIGovRelationshipSource.YAML_FRONTMATTER,
                    metadata={"linked_process": linked_process}
                )

            # Extract policy references
            policy_refs = frontmatter.get("policy_refs", [])
            for policy_ref in policy_refs:
                self._add_relationship(
                    source_id=sop_id,
                    source_type="sop",
                    target_id=f"POLICY-REF-{policy_ref}",
                    target_type="policy_reference",
                    relationship_type=AIGovRelationshipType.REFERENCES,
                    source=AIGovRelationshipSource.YAML_FRONTMATTER,
                    metadata={"policy_ref": policy_ref}
                )

            # Extract role relationships
            roles = frontmatter.get("roles", [])
            for role in roles:
                role_token = role.get("role_token", "") if isinstance(role, dict) else role
                if role_token:
                    # Clean up token format
                    role_name = role_token.replace("{{", "").replace("}}", "")
                    self._add_relationship(
                        source_id=sop_id,
                        source_type="sop",
                        target_id=f"ROLE-{role_name}",
                        target_type="role",
                        relationship_type=AIGovRelationshipType.PERFORMED_BY_ROLE,
                        source=AIGovRelationshipSource.YAML_FRONTMATTER,
                        metadata=role if isinstance(role, dict) else {"role_token": role_token}
                    )

            # Extract tool references
            tools = frontmatter.get("tools", [])
            for tool in tools:
                if tool.startswith("tool://"):
                    tool_id = tool.replace("tool://", "")
                    self._add_relationship(
                        source_id=sop_id,
                        source_type="sop",
                        target_id=f"TOOL-{tool_id}",
                        target_type="tool",
                        relationship_type=AIGovRelationshipType.DEPENDS_ON,
                        source=AIGovRelationshipSource.YAML_FRONTMATTER,
                        metadata={"tool_uri": tool}
                    )

            logger.debug(f"  Processed SOP: {sop_id}")

        except Exception as e:
            self.errors.append(f"Error processing SOP file {sop_file}: {e}")
            logger.warning(f"⚠️  Error processing {sop_file.name}: {e}")

    def _extract_control_mappings(self):
        """Extract relationships from control registry files."""
        controls_dir = self.framework_path / "controls"

        if not controls_dir.exists():
            logger.warning(f"⚠️  Controls directory not found: {controls_dir}")
            return

        # Look for control registry files
        for registry_file in controls_dir.glob("*registry*.json"):
            self._process_control_registry(registry_file)

    def _process_control_registry(self, registry_file: Path):
        """Process a control registry file for mappings."""
        try:
            with open(registry_file) as f:
                registry = json.load(f)

            # Handle different registry formats
            exemplar_controls = registry.get("exemplar_controls", [])
            if not exemplar_controls:
                exemplar_controls = registry.get("controls", [])

            for control in exemplar_controls:
                exemplar_id = control.get("exemplar_id", control.get("id", ""))

                if not exemplar_id:
                    continue

                self.stats["controls_processed"] += 1

                # Link exemplar to ISO control
                iso_control = control.get("iso_control", {})
                if isinstance(iso_control, dict):
                    iso_id = iso_control.get("control_id", "")
                else:
                    iso_id = str(iso_control)

                if iso_id:
                    self._add_relationship(
                        source_id=f"EXC-{exemplar_id}",
                        source_type="exemplar_control",
                        target_id=f"ISO-{iso_id}",
                        target_type="iso_control",
                        relationship_type=AIGovRelationshipType.EXEMPLAR_IMPLEMENTS_ISO,
                        source=AIGovRelationshipSource.CONTROL_REGISTRY,
                        metadata={
                            "exemplar_id": exemplar_id,
                            "iso_control_id": iso_id,
                            "control_title": iso_control.get("control_title") if isinstance(iso_control, dict) else None,
                        }
                    )

                # Link to policies
                policy_mappings = control.get("policy_mappings", [])
                for mapping in policy_mappings:
                    policy_id = mapping.get("policy_id", "")
                    if policy_id:
                        self._add_relationship(
                            source_id=f"EXC-{exemplar_id}",
                            source_type="exemplar_control",
                            target_id=f"POL-{policy_id}",
                            target_type="policy",
                            relationship_type=AIGovRelationshipType.SOP_IMPLEMENTS_CONTROL,
                            source=AIGovRelationshipSource.CONTROL_REGISTRY,
                            metadata=mapping
                        )

                # Link to process mappings
                process_mappings = control.get("process_mappings", [])
                for mapping in process_mappings:
                    process_id = mapping.get("process_id", "")
                    sop_ref = mapping.get("sop_reference", "")

                    if process_id:
                        self._add_relationship(
                            source_id=f"EXC-{exemplar_id}",
                            source_type="exemplar_control",
                            target_id=f"BP-{process_id}",
                            target_type="base_practice",
                            relationship_type=AIGovRelationshipType.SOP_IMPLEMENTS_CONTROL,
                            source=AIGovRelationshipSource.CONTROL_REGISTRY,
                            metadata=mapping
                        )

                    if sop_ref:
                        sop_match = re.search(r"(SOP-[A-Z]+-\d+)", sop_ref)
                        if sop_match:
                            self._add_relationship(
                                source_id=f"EXC-{exemplar_id}",
                                source_type="exemplar_control",
                                target_id=sop_match.group(1),
                                target_type="sop",
                                relationship_type=AIGovRelationshipType.SOP_IMPLEMENTS_CONTROL,
                                source=AIGovRelationshipSource.CONTROL_REGISTRY,
                                metadata={"sop_reference": sop_ref}
                            )

                # Link to work products as evidence
                work_products = control.get("work_products", [])
                for wp in work_products:
                    wp_id = wp.get("work_product_id", "") if isinstance(wp, dict) else wp
                    if wp_id:
                        self._add_relationship(
                            source_id=wp_id,
                            source_type="work_product",
                            target_id=f"EXC-{exemplar_id}",
                            target_type="exemplar_control",
                            relationship_type=AIGovRelationshipType.WORKPRODUCT_EVIDENCES_CONTROL,
                            source=AIGovRelationshipSource.CONTROL_REGISTRY,
                            metadata=wp if isinstance(wp, dict) else {"work_product_id": wp_id}
                        )

            logger.info(f"📋 Processed control registry: {registry_file.name} ({len(exemplar_controls)} controls)")

        except Exception as e:
            self.errors.append(f"Error processing control registry {registry_file}: {e}")
            logger.warning(f"⚠️  Error processing {registry_file.name}: {e}")

    def _extract_yaml_frontmatter(self, content: str) -> dict[str, Any] | None:
        """Extract YAML frontmatter from markdown content.

        Handles Jinja2-style template tokens ({{token}}) that conflict with YAML syntax
        by temporarily quoting them before parsing.
        """
        # Match YAML frontmatter between --- markers
        pattern = r"^---\s*\n(.*?)\n---"
        match = re.search(pattern, content, re.DOTALL)

        if not match:
            return None

        yaml_content = match.group(1)

        # Quote template tokens to prevent YAML parsing errors
        # Replace unquoted {{token}} with "{{token}}"
        # But avoid double-quoting already quoted tokens
        yaml_content = re.sub(
            r'(?<!["\'])(\{\{[^}]+\}\})(?!["\'])',
            r'"\1"',
            yaml_content
        )

        try:
            return yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            logger.debug(f"YAML parse error: {e}")
            return None

    def _add_relationship(
        self,
        source_id: str,
        source_type: str,
        target_id: str,
        target_type: str,
        relationship_type: str,
        source: str,
        metadata: dict[str, Any] | None = None,
    ):
        """Add a relationship to the collection."""
        relationship = {
            "source_artifact_id": source_id,
            "source_artifact_type": source_type,
            "target_artifact_id": target_id,
            "target_artifact_type": target_type,
            "relationship_type": relationship_type,
            "source": source,
            "framework_version": self.framework_version,
            "strength": 1.0,  # Default strength for framework-defined relationships
            "confidence": 1.0,  # High confidence for extracted relationships
            "metadata": metadata or {},
            "created_at": datetime.now(UTC).isoformat(),
            "created_by": "relationship_extractor",
            "status": "active",
        }

        self.relationships.append(relationship)
        self.stats["relationships_created"] += 1

    def _log_stats(self):
        """Log extraction statistics."""
        logger.info("=" * 60)
        logger.info("📊 Extraction Statistics:")
        logger.info(f"   Policies processed:        {self.stats['policies_processed']}")
        logger.info(f"   Process domains processed: {self.stats['process_domains_processed']}")
        logger.info(f"   SOPs processed:            {self.stats['sops_processed']}")
        logger.info(f"   Work products processed:   {self.stats['work_products_processed']}")
        logger.info(f"   Controls processed:        {self.stats['controls_processed']}")
        logger.info(f"   Relationships created:     {self.stats['relationships_created']}")

        if self.errors:
            logger.warning(f"   ⚠️  Errors encountered:     {len(self.errors)}")

        logger.info("=" * 60)


# ============================================================================
# MongoDB Upload
# ============================================================================

class RelationshipUploader:
    """Uploads extracted relationships to MongoDB/CosmosDB."""

    COLLECTION_NAME = "aigov_relationships"

    def __init__(self, connection_string: str, database_name: str):
        """
        Initialize the uploader.

        Args:
            connection_string: MongoDB connection string
            database_name: Target database name
        """
        self.connection_string = connection_string
        self.database_name = database_name
        self.client = None
        self.db = None
        self.collection = None

    async def connect(self):
        """Establish database connection."""
        self.client = AsyncIOMotorClient(self.connection_string)
        self.db = self.client[self.database_name]
        self.collection = self.db[self.COLLECTION_NAME]

        # Test connection
        await self.collection.find_one()
        logger.info(f"✅ Connected to MongoDB: {self.database_name}/{self.COLLECTION_NAME}")

    async def ensure_indexes(self):
        """Create necessary indexes for efficient queries."""
        indexes = [
            ("source_artifact_id", 1),
            ("target_artifact_id", 1),
            ("relationship_type", 1),
            ("framework_version", 1),
            [("source_artifact_id", 1), ("target_artifact_id", 1)],
            [("framework_version", 1), ("relationship_type", 1)],
        ]

        for index_spec in indexes:
            if isinstance(index_spec, list):
                await self.collection.create_index(index_spec)
            else:
                await self.collection.create_index([(index_spec[0], index_spec[1])])

        logger.info("✅ Database indexes ensured")

    async def upload(
        self,
        relationships: list[dict[str, Any]],
        clear_existing: bool = True,
        framework_version: str | None = None,
    ) -> dict[str, Any]:
        """
        Upload relationships to MongoDB.

        Args:
            relationships: List of relationship dictionaries
            clear_existing: Whether to clear existing relationships for this version
            framework_version: Version to clear (if clear_existing is True)

        Returns:
            Upload results summary
        """
        results = {
            "inserted": 0,
            "errors": [],
            "cleared": 0,
        }

        if clear_existing and framework_version:
            delete_result = await self.collection.delete_many(
                {"framework_version": framework_version}
            )
            results["cleared"] = delete_result.deleted_count
            logger.info(f"🗑️  Cleared {results['cleared']} existing relationships for v{framework_version}")

        if not relationships:
            logger.warning("⚠️  No relationships to upload")
            return results

        try:
            # Batch insert
            insert_result = await self.collection.insert_many(relationships)
            results["inserted"] = len(insert_result.inserted_ids)
            logger.info(f"✅ Inserted {results['inserted']} relationships")

        except Exception as e:
            results["errors"].append(str(e))
            logger.error(f"❌ Error inserting relationships: {e}")

        return results

    async def close(self):
        """Close database connection."""
        if self.client:
            self.client.close()
            logger.info("🔌 Database connection closed")


# ============================================================================
# CLI Interface
# ============================================================================

def setup_logging(verbose: bool = False, log_dir: Path | None = None) -> str:
    """Set up comprehensive logging with file and console handlers."""
    if log_dir is None:
        log_dir = Path.cwd() / "logs"
    log_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = log_dir / f"aigov_relationship_extract_{timestamp}.log"

    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    log_level = logging.DEBUG if verbose else logging.INFO

    detailed_formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_formatter = logging.Formatter("%(levelname)s - %(message)s")

    file_handler = logging.FileHandler(log_file_path, mode="w", encoding="utf-8")
    file_handler.setLevel(log_level)
    file_handler.setFormatter(detailed_formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(console_formatter)

    root_logger.setLevel(log_level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    logger.info("=== AI Gov Relationship Extractor Started ===")
    logger.info(f"Log file: {log_file_path}")

    return str(log_file_path)


def load_environment_config() -> dict[str, Any]:
    """Load configuration from environment variables."""
    potential_paths = [
        Path.cwd() / ".env",
        Path.cwd() / "ashmatics-tools.env",
        Path.cwd().parent / ".env",
        Path.cwd().parent / "ashmatics-tools.env",
        Path.home() / "GitHub" / "AsherInformatics" / "Ashmatics_Knowledgebase" / "ashmatics-tools.env",
    ]

    for env_path in potential_paths:
        if env_path.exists():
            load_dotenv(env_path)
            logger.info(f"📁 Loaded environment from: {env_path}")
            break

    config = {
        "mongo_connection_string": os.getenv("AZ_MONGO_CONNECTION_STRING", os.getenv("MONGO_URL", "")),
        "mongo_database": os.getenv("MONGO_DATABASE", os.getenv("MONGO_DB", "ashmatics_kb")),
        "framework_path": os.getenv(
            "FRAMEWORK_REPO_PATH",
            str(Path.cwd().parent / "ashmatics-policy-process-builder")
        ),
    }

    return config


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        description="Extract relationships from AI Governance Framework content",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Extract and upload relationships for framework v0.8.0
    cai-extract-relationships --version 0.8.0

    # Dry run to preview extraction
    cai-extract-relationships --version 0.8.0 --dry-run

    # Output to JSON file instead of MongoDB
    cai-extract-relationships --version 0.8.0 --output relationships.json

    # Specify custom framework path
    cai-extract-relationships --framework-path /path/to/framework --version 0.8.0
        """
    )

    parser.add_argument(
        "--version", "-v",
        type=str,
        default="0.8.0",
        help="Framework version being processed (default: 0.8.0)"
    )

    parser.add_argument(
        "--framework-path", "-f",
        type=str,
        help="Path to the framework content repository"
    )

    parser.add_argument(
        "--output", "-o",
        type=str,
        help="Output JSON file path (skip MongoDB upload)"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Extract and display relationships without uploading"
    )

    parser.add_argument(
        "--no-clear",
        action="store_true",
        help="Don't clear existing relationships for this version before upload"
    )

    parser.add_argument(
        "--types",
        nargs="+",
        choices=["hierarchy", "controls", "roles", "all"],
        default=["all"],
        help="Types of relationships to extract (default: all)"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose/debug logging"
    )

    return parser


async def main_async(args: argparse.Namespace, config: dict[str, Any]) -> int:
    """Async main function."""
    # Determine framework path and resolve to absolute
    framework_path = Path(args.framework_path or config["framework_path"]).resolve()

    if not framework_path.exists():
        logger.error(f"❌ Framework path not found: {framework_path}")
        return 1

    logger.info(f"📂 Framework path resolved to: {framework_path}")

    # Extract relationships
    extractor = RelationshipExtractor(framework_path, args.version)
    relationships = extractor.extract_all()

    if not relationships:
        logger.warning("⚠️  No relationships extracted")
        return 1

    # Output to JSON file if specified
    if args.output:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            json.dump(relationships, f, indent=2, default=str)
        logger.info(f"📄 Relationships written to: {output_path}")
        return 0

    # Dry run - just display stats
    if args.dry_run:
        logger.info("🔍 Dry run complete - no changes made")

        # Show sample relationships
        logger.info("\n📋 Sample relationships (first 5):")
        for rel in relationships[:5]:
            logger.info(f"   {rel['source_artifact_id']} --[{rel['relationship_type']}]--> {rel['target_artifact_id']}")

        return 0

    # Upload to MongoDB
    if not config["mongo_connection_string"]:
        logger.error("❌ MongoDB connection string not configured")
        logger.info("   Set AZ_MONGO_CONNECTION_STRING or MONGO_URL environment variable")
        return 1

    uploader = RelationshipUploader(
        config["mongo_connection_string"],
        config["mongo_database"]
    )

    try:
        await uploader.connect()
        await uploader.ensure_indexes()

        results = await uploader.upload(
            relationships,
            clear_existing=not args.no_clear,
            framework_version=args.version
        )

        logger.info("=" * 60)
        logger.info("📊 Upload Results:")
        logger.info(f"   Cleared:  {results['cleared']}")
        logger.info(f"   Inserted: {results['inserted']}")
        if results['errors']:
            logger.warning(f"   Errors:   {len(results['errors'])}")
        logger.info("=" * 60)

    finally:
        await uploader.close()

    return 0


def main():
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()

    # Set up logging
    setup_logging(verbose=args.verbose)

    # Load configuration
    config = load_environment_config()

    # Run async main
    try:
        exit_code = asyncio.run(main_async(args, config))
    except KeyboardInterrupt:
        logger.info("\n⚠️  Operation cancelled by user")
        exit_code = 130
    except Exception as e:
        logger.error(f"❌ Unexpected error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        exit_code = 1

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
