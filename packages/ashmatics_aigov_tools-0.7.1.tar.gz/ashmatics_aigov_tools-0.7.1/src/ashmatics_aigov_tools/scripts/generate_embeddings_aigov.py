#!/usr/bin/env python3
"""
Generate embeddings for Ashmatics AI Governance (aigov) Framework content.

Updated and Created - 2025-12-22 JFK

This script implements a "Structured-First" embedding strategy for the
CAI Governance Framework content stored in MongoDB:
1. Fetches compiled GovernanceDocument objects from MongoDB
2. Iterates through sections, preserving metadata
3. Embeds small sections directly
4. Chunks large sections using DoclingChunker before embedding
5. Stores embedding vectors in a separate collection for vector search

Designed specifically for the aigov framework slug naming conventions
and document structure. For other content types, create a separate script.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
"""

import argparse
import asyncio
import logging
import os
import sys
import warnings

# Suppress CosmosDB compatibility warnings from pymongo/motor (must be before import)
warnings.filterwarnings("ignore", message=".*CosmosDB.*")

from ashmatics_datamodels.documents.governance import GovernanceSection  # noqa: E402
from ashmatics_tools.chunkers.base import ChunkingConfig  # noqa: E402
from ashmatics_tools.chunkers.docling_chunker import DoclingChunker  # noqa: E402
from ashmatics_tools.embedders.base import EmbeddingConfig, EmbeddingProvider  # noqa: E402
from ashmatics_tools.embedders.factory import create_embedder  # noqa: E402
from ashmatics_tools.vector_stores import VectorIndexManager  # noqa: E402
from dotenv import load_dotenv  # noqa: E402
from motor.motor_asyncio import AsyncIOMotorClient  # noqa: E402
from pymongo import UpdateOne  # noqa: E402
from rich.console import Console  # noqa: E402
from rich.progress import (  # noqa: E402
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
)

# Configure logging - suppress noisy HTTP request logs during processing
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("aigov_embedder")

# Suppress noisy loggers
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.getLogger("azure").setLevel(logging.WARNING)
logging.getLogger("ashmatics_tools").setLevel(logging.WARNING)

# Rich console for pretty output
console = Console()

# Constants
MAX_TOKENS_PER_CHUNK = 8000  # Safe limit for text-embedding-3-small (8191 max)
BATCH_SIZE = 50

# Artifact prefix categories based on CAI Framework Slug Registry
# High semantic value - good for RAG/semantic search
SEMANTIC_PREFIXES = [
    "FW-",  # Framework docs (overviews, architecture)
    "POL-",  # Policy overviews
    "PROC-",  # Process overviews
    "AREA-",  # Process area overviews
    "SOP-",  # Standard Operating Procedures
    "CTRL-",  # Controls documentation
    "ISO-",  # ISO mappings
    "WIZ-",  # Wizard designs (narrative content)
    "LOG-",  # Decision logs
]

# Lower semantic value - structured data, templates, glue files
STRUCTURED_PREFIXES = [
    "POLT-",  # Policy templates (token placeholders)
    "POLTOK-",  # Policy tokens (JSON)
    "PROCJ-",  # Process JSON definitions
    "BIND-",  # Policy binding matrices
    "TRACE-",  # Traceability JSON
    "WIZS-",  # Wizard schemas (YAML configs)
    "WP-",  # Work products (large volume, mixed value)
]

# Process domain codes for filtering
PROCESS_DOMAINS = ["PV", "SA", "MON", "OVR", "ORG", "IT", "RM", "HO", "EF", "TR", "UG"]

# Content formats (stored in metadata_content.content_format)
CONTENT_FORMATS = ["md", "markdown", "yaml", "json"]


class FrameworkEmbedder:
    def __init__(self):
        # Load environment variables
        # Try to find the .env files relative to the script location (project root)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up 3 levels: scripts -> ashmatics_aigov_tools -> src -> root
        project_root = os.path.abspath(os.path.join(current_dir, "../../../"))

        # Load MongoDB credentials from ashmatics-tools.env
        mongo_env_path = os.path.join(project_root, "ashmatics-tools.env")
        if os.path.exists(mongo_env_path):
            load_dotenv(mongo_env_path)
            logger.info(f"Loaded MongoDB config from {mongo_env_path}")
        else:
            load_dotenv("ashmatics-tools.env")
            logger.warning(f"Could not find {mongo_env_path}, trying 'ashmatics-tools.env' in cwd")

        # Load Azure OpenAI credentials from .env (standard location)
        azure_env_path = os.path.join(project_root, ".env")
        if os.path.exists(azure_env_path):
            load_dotenv(azure_env_path, override=False)  # Don't override existing vars
            logger.info(f"Loaded Azure config from {azure_env_path}")

        # MongoDB Connection - canonical MONGO_URL with backward-compatible fallbacks
        # 2026-01-24: Standardized env var names
        self.mongo_uri = (
            os.getenv("MONGO_URL")
            or os.getenv("AZ_MONGO_CONNECTION_STRING")
            or os.getenv("MONGO_CONNECTION_STRING")
        )
        if not self.mongo_uri:
            raise ValueError(
                "MongoDB connection string not found. "
                "Set MONGO_URL (preferred), AZ_MONGO_CONNECTION_STRING, or MONGO_CONNECTION_STRING"
            )

        # Database name - canonical MONGO_DB with fallback to MONGO_DATABASE
        self.db_name = os.getenv("MONGO_DB") or os.getenv("MONGO_DATABASE", "ai_strategy")
        self.collection_name = os.getenv("MONGO_COLLECTION", "aigov_framework_content")
        self.framework_version = os.getenv("FRAMEWORK_VERSION", "0.8.0")

        logger.info(f"MongoDB target: {self.db_name}.{self.collection_name}")
        logger.info(f"Framework version: {self.framework_version}")

        # Validate Azure OpenAI credentials
        azure_key = os.getenv("AZURE_OPENAI_API_KEY")
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        if not azure_key or not azure_endpoint:
            raise ValueError(
                "Azure OpenAI credentials not found. Required env vars: "
                "AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT"
            )

        # Initialize clients
        self.client: AsyncIOMotorClient | None = None
        self.db = None
        self.collection = None

        # Vector index manager (for index operations) - from ashmatics-tools
        self.vector_manager: VectorIndexManager | None = None

        # Initialize embedder
        self.embedder = create_embedder(
            provider="azure",
            config=EmbeddingConfig(
                provider=EmbeddingProvider.AZURE,
                model="text-embedding-3-small",
                batch_size=BATCH_SIZE,
            ),
        )

        self.chunker = DoclingChunker(
            config=ChunkingConfig(
                max_tokens=1000,  # Smaller chunks for large sections
                chunk_overlap=100,
                tokenizer_model="sentence-transformers/all-MiniLM-L6-v2",  # Valid HF model
            )
        )

    async def connect(self):
        """Establish MongoDB connection."""
        try:
            self.client = AsyncIOMotorClient(self.mongo_uri)
            self.db = self.client[self.db_name]
            self.collection = self.db[self.collection_name]
            # Test connection
            await self.client.admin.command("ping")
            logger.info(f"✅ Connected to MongoDB: {self.db_name}.{self.collection_name}")

            # Initialize vector manager (uses sync pymongo for index ops)
            self.vector_manager = VectorIndexManager(
                uri=self.mongo_uri,
                db_name=self.db_name,
                collection_name="aigov_framework_vectors",
            )
            self.vector_manager.connect()
        except Exception as e:
            logger.error(f"❌ Failed to connect to MongoDB: {e}")
            raise

    async def process_document(self, doc: dict) -> list[UpdateOne]:
        """
        Process a single document:
        1. Extract metadata
        2. Iterate sections
        3. Generate embeddings
        4. Prepare MongoDB updates
        """
        updates = []
        doc_id = doc.get("_id")
        title = doc.get("metadata_content", {}).get("title", "Untitled")

        logger.info(f"Processing document: {title} ({doc_id})")

        # Extract sections from the 'content' field
        # Correct field name is 'governance_sections' based on GovernanceContent model
        sections_data = doc.get("content", {}).get("governance_sections", [])

        if not sections_data:
            logger.warning(f"  No sections found in {doc_id}")
            return []

        for i, section_data in enumerate(sections_data):
            # Convert to Pydantic model for easier handling
            try:
                section = GovernanceSection(**section_data)
            except Exception as e:
                logger.warning(f"Skipping invalid section in {doc_id}: {e}")
                continue

            # Skip empty sections
            if not section.content.strip():
                continue

            # Check size
            # Simple estimation: 1 token ~= 4 chars
            estimated_tokens = len(section.content) / 4

            chunks_to_embed = []

            if estimated_tokens > MAX_TOKENS_PER_CHUNK:
                logger.info(f"  Chunking large section: {section.title}")
                # Chunk large section
                chunks = await self.chunker.chunk_document(
                    content=section.content, title=section.title, source=str(doc_id)
                )
                chunks_to_embed.extend([c.content for c in chunks])
            else:
                # Use section as-is
                chunks_to_embed.append(section.content)

            # Generate embeddings
            try:
                embeddings = await self.embedder.generate_embeddings_batch(chunks_to_embed)

                if embeddings:
                    # Create vector document
                    # We'll use a separate collection for vectors

                    # Base metadata from the document
                    base_metadata = doc.get("metadata_content", {})

                    # For each chunk (usually just 1, but could be more if split)
                    for chunk_idx, (chunk_content, embedding) in enumerate(
                        zip(chunks_to_embed, embeddings)
                    ):
                        vector_doc = {
                            "artifact_id": base_metadata.get("artifact_id"),
                            "section_index": i,
                            "chunk_index": chunk_idx,
                            "section_title": section.title,
                            "content": chunk_content,
                            "embedding": embedding,
                            "metadata": {
                                **base_metadata,
                                "section_level": section.level,
                                "section_anchor": section.anchor,
                            },
                        }

                        # Create a unique ID for the vector document
                        vector_id = f"{doc_id}_s{i}_c{chunk_idx}"

                        updates.append(
                            UpdateOne({"_id": vector_id}, {"$set": vector_doc}, upsert=True)
                        )

            except Exception as e:
                logger.error(f"  Failed to embed section {section.title}: {e}")

        return updates

    def _matches_filters(
        self,
        artifact_id: str,
        content_format: str | None,
        domain: str | None,
        include_prefixes: list[str] | None,
        exclude_prefixes: list[str] | None,
        format_filter: str | None,
    ) -> bool:
        """Check if document matches the configured filters."""
        if not artifact_id:
            return False

        # Check format filter (md, yaml, json)
        if format_filter:
            # Normalize format names (md == markdown)
            normalized_filter = "markdown" if format_filter == "md" else format_filter
            normalized_format = (content_format or "").lower()
            if normalized_format != normalized_filter:
                return False

        # Check domain filter (e.g., "PV" matches "SOP-PV-01", "POL-PV-Overview")
        if domain:
            # Domain can appear after prefix (SOP-PV-01) or in the middle
            if f"-{domain}-" not in artifact_id and not artifact_id.endswith(f"-{domain}"):
                return False

        # Check include prefixes
        if include_prefixes:
            if not any(artifact_id.startswith(prefix) for prefix in include_prefixes):
                return False

        # Check exclude prefixes
        if exclude_prefixes:
            if any(artifact_id.startswith(prefix) for prefix in exclude_prefixes):
                return False

        return True

    async def run(
        self,
        dry_run: bool = False,
        limit: int | None = None,
        domain: str | None = None,
        include_prefixes: list[str] | None = None,
        exclude_prefixes: list[str] | None = None,
        format_filter: str | None = None,
        concurrency: int = 1,
        create_index: bool = True,
        index_type: str = "ivf",
        rebuild_index: bool = False,
    ):
        """
        Main execution loop.

        Args:
            dry_run: If True, preview documents without generating embeddings
            limit: Maximum number of documents to process (for testing)
            domain: Filter by process domain code (e.g., PV, SA, RM)
            include_prefixes: Only include artifacts with these prefixes
            exclude_prefixes: Exclude artifacts with these prefixes
            format_filter: Only include content of this format (md, yaml, json)
            concurrency: Number of documents to process concurrently (default: 1)
            create_index: If True, create vector index after embedding (default: True)
            index_type: Type of vector index: "ivf" or "hnsw" (default: ivf for CosmosDB compatibility)
            rebuild_index: If True, drop and recreate index even if it exists
        """
        await self.connect()

        # Create/Get vector collection
        vector_collection = self.db["aigov_framework_vectors"]

        # Fetch compiled views for the specified framework version
        version_filter = {"semver": self.framework_version}
        total_docs = await self.collection.count_documents(version_filter)

        # Print configuration
        console.print("\n[bold blue]AIGov Framework Embeddings Generator[/bold blue]")
        console.print(f"  Framework version: [cyan]{self.framework_version}[/cyan]")
        console.print(f"  Source: [cyan]{self.db_name}.{self.collection_name}[/cyan]")
        console.print(f"  Target: [cyan]{self.db_name}.aigov_framework_vectors[/cyan]")
        console.print(f"  Total documents: [cyan]{total_docs}[/cyan]")

        # Log active filters
        if format_filter:
            console.print(f"  Format filter: [yellow]{format_filter}[/yellow]")
        if domain:
            console.print(f"  Domain filter: [yellow]{domain}[/yellow]")
        if include_prefixes:
            console.print(f"  Include prefixes: [yellow]{include_prefixes}[/yellow]")
        if exclude_prefixes:
            console.print(f"  Exclude prefixes: [yellow]{exclude_prefixes}[/yellow]")
        if limit:
            console.print(f"  Limit: [yellow]{limit}[/yellow]")
        if concurrency > 1:
            console.print(f"  Concurrency: [yellow]{concurrency}[/yellow]")

        if dry_run:
            console.print(
                "\n[bold yellow]DRY RUN MODE - No embeddings will be generated[/bold yellow]\n"
            )

        # First pass: collect documents that match filters
        cursor = self.collection.find(version_filter)
        docs_to_process = []
        skipped_count = 0

        console.print("\n[dim]Scanning documents...[/dim]")
        async for doc in cursor:
            artifact_id = doc.get("artifact_id", doc.get("_id"))
            content_format = doc.get("metadata_content", {}).get("content_format")

            if not self._matches_filters(
                artifact_id,
                content_format,
                domain,
                include_prefixes,
                exclude_prefixes,
                format_filter,
            ):
                skipped_count += 1
                continue

            docs_to_process.append(doc)

            if limit and len(docs_to_process) >= limit:
                break

        console.print(
            f"  Found [green]{len(docs_to_process)}[/green] documents to process, "
            f"[dim]{skipped_count} skipped[/dim]\n"
        )

        if not docs_to_process:
            console.print("[yellow]No documents matched the filters.[/yellow]")
            return

        # Process documents with progress bar
        processed_count = 0
        total_vectors = 0
        failed_count = 0

        # Semaphore for concurrency control
        semaphore = asyncio.Semaphore(concurrency)

        async def process_with_semaphore(doc: dict) -> tuple[int, bool]:
            """Process a document with semaphore for concurrency control."""
            async with semaphore:
                if dry_run:
                    sections = doc.get("content", {}).get("governance_sections", [])
                    artifact_id = doc.get("artifact_id", "unknown")
                    return (len(sections), True)

                try:
                    updates = await self.process_document(doc)
                    if updates:
                        result = await vector_collection.bulk_write(updates)
                        return (result.upserted_count + result.modified_count, True)
                    return (0, True)
                except Exception as e:
                    artifact_id = doc.get("artifact_id", "unknown")
                    logger.error(f"Failed to process {artifact_id}: {e}")
                    return (0, False)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TextColumn("[cyan]{task.fields[vectors]}[/cyan] vectors"),
            console=console,
            refresh_per_second=4,  # Reduce flicker
        ) as progress:
            task = progress.add_task(
                "[green]Processing...",
                total=len(docs_to_process),
                vectors=0,
            )

            # Process documents (sequential or concurrent based on setting)
            if concurrency == 1:
                # Sequential processing with progress updates
                for doc in docs_to_process:
                    artifact_id = doc.get("artifact_id", "unknown")
                    progress.update(task, description=f"[green]{artifact_id}")

                    vectors, success = await process_with_semaphore(doc)
                    if success:
                        processed_count += 1
                        total_vectors += vectors
                    else:
                        failed_count += 1

                    progress.update(task, advance=1, vectors=total_vectors)
            else:
                # Concurrent processing
                tasks = [process_with_semaphore(doc) for doc in docs_to_process]
                for coro in asyncio.as_completed(tasks):
                    vectors, success = await coro
                    if success:
                        processed_count += 1
                        total_vectors += vectors
                    else:
                        failed_count += 1
                    progress.update(task, advance=1, vectors=total_vectors)

        # Summary
        console.print()
        console.print("[bold green]✅ Completed![/bold green]")
        console.print(f"  Documents processed: [green]{processed_count}[/green]")
        console.print(f"  Documents skipped: [dim]{skipped_count}[/dim]")
        if failed_count > 0:
            console.print(f"  Documents failed: [red]{failed_count}[/red]")
        if not dry_run:
            console.print(f"  Total vectors: [cyan]{total_vectors}[/cyan]")

            # Get token usage from embedder
            try:
                usage_stats = await self.embedder.get_usage_stats()
                total_tokens = usage_stats.get("total_tokens", 0)
                total_requests = usage_stats.get("total_requests", 0)
                failed_requests = usage_stats.get("failed_requests", 0)

                console.print(f"  API requests: [cyan]{total_requests}[/cyan]")
                console.print(f"  Total tokens: [cyan]{total_tokens:,}[/cyan]")
                if failed_requests > 0:
                    console.print(f"  Failed API requests: [yellow]{failed_requests}[/yellow]")

                # Estimate cost (text-embedding-3-small is $0.02 per 1M tokens)
                estimated_cost = (total_tokens / 1_000_000) * 0.02
                console.print(f"  Estimated cost: [cyan]${estimated_cost:.4f}[/cyan]")
            except Exception:
                pass  # Silently skip if usage stats not available

            # Create/update vector index (only if not dry run and vectors were created)
            if create_index and total_vectors > 0 and self.vector_manager:
                console.print()
                self.vector_manager.create_vector_index(
                    index_type=index_type,
                    force=rebuild_index,
                )
                self.vector_manager.create_metadata_indexes()

                # Show final stats
                stats = self.vector_manager.get_stats()
                console.print("\n[bold]Vector Collection Stats:[/bold]")
                console.print(f"  Total vectors: [cyan]{stats.document_count:,}[/cyan]")
                console.print(
                    f"  Vector index: [cyan]{stats.index_type or 'none'}[/cyan]"
                )

        # Cleanup
        if self.vector_manager:
            self.vector_manager.close()


def main():
    parser = argparse.ArgumentParser(
        description="Generate embeddings for CAI Framework content in MongoDB",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check current vector collection stats
  python generate_embeddings_aigov.py --stats-only

  # Create index on existing vectors (no embedding)
  python generate_embeddings_aigov.py --index-only

  # Semantic Markdown content only (recommended for RAG)
  python generate_embeddings_aigov.py --semantic-only --format md --dry-run

  # All Markdown content with concurrent processing
  python generate_embeddings_aigov.py --format md --concurrency 3

  # Specific process domain (Markdown only)
  python generate_embeddings_aigov.py --domain PV --format md --dry-run

  # Include only specific prefixes
  python generate_embeddings_aigov.py --include FW-,POL-,SOP- --dry-run

  # Exclude work products (too many)
  python generate_embeddings_aigov.py --exclude WP-,TRACE-,BIND-

  # Re-embed specific content (clear old vectors first)
  python generate_embeddings_aigov.py --clear-prefix SOP-PV --include SOP-PV

  # Full reset and re-embed everything
  python generate_embeddings_aigov.py --reset --semantic-only --format md

  # Rebuild index with different type
  python generate_embeddings_aigov.py --index-only --index-type ivf --rebuild-index

Available prefixes: FW-, POL-, POLT-, POLTOK-, PROC-, PROCJ-, AREA-,
                   SOP-, WP-, WIZ-, WIZS-, BIND-, TRACE-, LOG-, CTRL-, ISO-

Process domains: PV, SA, MON, OVR, ORG, IT, RM, HO, EF, TR, UG

Formats: md (Markdown), yaml, json
        """,
    )
    parser.add_argument(
        "--version", default="0.8.0", help="Framework version to process (default: 0.8.0)"
    )
    parser.add_argument("--db", default=None, help="MongoDB database name (default: ai_strategy)")
    parser.add_argument(
        "--collection",
        default=None,
        help="MongoDB collection name (default: aigov_framework_content)",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Preview documents without generating embeddings"
    )
    parser.add_argument(
        "--limit", type=int, default=None, help="Limit number of documents to process (for testing)"
    )

    # Filtering options
    parser.add_argument(
        "--semantic-only",
        action="store_true",
        help="Only embed semantically rich content (FW-, POL-, PROC-, AREA-, SOP-, CTRL-, ISO-, WIZ-, LOG-)",
    )
    parser.add_argument(
        "--domain",
        type=str,
        default=None,
        help="Filter by process domain code (e.g., PV, SA, RM, HO)",
    )
    parser.add_argument(
        "--include",
        type=str,
        default=None,
        help="Comma-separated prefixes to include (e.g., FW-,POL-,SOP-)",
    )
    parser.add_argument(
        "--exclude",
        type=str,
        default=None,
        help="Comma-separated prefixes to exclude (e.g., WP-,TRACE-,BIND-)",
    )
    parser.add_argument(
        "--format",
        type=str,
        default=None,
        choices=["md", "yaml", "json"],
        help="Only process content of this format (md, yaml, json)",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=1,
        help="Number of documents to process concurrently (default: 1). "
        "Higher values may hit rate limits.",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress all log output except errors",
    )

    # Index management options
    parser.add_argument(
        "--no-index",
        action="store_true",
        help="Skip creating vector index after embedding (index created by default)",
    )
    parser.add_argument(
        "--index-type",
        choices=["ivf", "hnsw"],
        default="ivf",
        help="Vector index type: ivf (CosmosDB compatible) or hnsw (faster, requires higher tier). Default: ivf",
    )
    parser.add_argument(
        "--rebuild-index",
        action="store_true",
        help="Drop and recreate vector index even if it exists",
    )

    # Reset/cleanup options
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete ALL vectors and index before processing (use with caution!)",
    )
    parser.add_argument(
        "--clear-prefix",
        type=str,
        default=None,
        help="Delete vectors matching this artifact_id prefix before processing (e.g., SOP-PV)",
    )
    parser.add_argument(
        "--index-only",
        action="store_true",
        help="Only create/rebuild index on existing vectors (no embedding)",
    )
    parser.add_argument(
        "--stats-only",
        action="store_true",
        help="Only show collection statistics (no embedding or indexing)",
    )

    args = parser.parse_args()

    # Validate concurrency (limit to 3 to avoid rate limits)
    if args.concurrency < 1 or args.concurrency > 3:
        console.print("[red]Error: --concurrency must be between 1 and 3[/red]")
        console.print("[dim]Higher values tend to hit Azure OpenAI rate limits[/dim]")
        sys.exit(1)

    # Suppress logs if quiet mode
    if args.quiet:
        logging.getLogger().setLevel(logging.ERROR)

    # Set environment overrides from CLI args
    if args.version:
        os.environ["FRAMEWORK_VERSION"] = args.version
    if args.db:
        os.environ["MONGO_DB"] = args.db
    if args.collection:
        os.environ["MONGO_COLLECTION"] = args.collection

    # Parse prefix filters
    include_prefixes = None
    exclude_prefixes = None

    if args.semantic_only:
        include_prefixes = SEMANTIC_PREFIXES
        logger.info(f"Semantic-only mode: including {include_prefixes}")
    elif args.include:
        include_prefixes = [p.strip() for p in args.include.split(",")]
    if args.exclude:
        exclude_prefixes = [p.strip() for p in args.exclude.split(",")]

    # Handle utility modes (--stats-only, --index-only, --reset, --clear-prefix)
    # These use synchronous VectorIndexManager from ashmatics-tools
    if args.stats_only or args.index_only or args.reset or args.clear_prefix:
        # Load environment for MongoDB connection
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.abspath(os.path.join(current_dir, "../../../"))
        mongo_env_path = os.path.join(project_root, "ashmatics-tools.env")
        if os.path.exists(mongo_env_path):
            load_dotenv(mongo_env_path)
        else:
            load_dotenv("ashmatics-tools.env")

        mongo_uri = os.getenv("AZ_MONGO_CONNECTION_STRING")
        if not mongo_uri:
            console.print("[red]Error: AZ_MONGO_CONNECTION_STRING not found[/red]")
            sys.exit(1)

        db_name = args.db or os.getenv("MONGO_DB", "ai_strategy")
        manager = VectorIndexManager(
            uri=mongo_uri,
            db_name=db_name,
            collection_name="aigov_framework_vectors",
        )
        manager.connect()

        console.print("[bold blue]AIGov Vector Collection Manager[/bold blue]\n")

        if args.stats_only:
            # Just show stats
            stats = manager.get_stats()
            console.print("[bold]Collection Stats:[/bold]")
            console.print(f"  Database: [cyan]{db_name}[/cyan]")
            console.print("  Collection: [cyan]aigov_framework_vectors[/cyan]")
            console.print(f"  Documents: [cyan]{stats.document_count:,}[/cyan]")
            console.print(f"  Vector index: [cyan]{stats.index_type or 'none'}[/cyan]")
            console.print(f"  Total indexes: [cyan]{stats.index_count}[/cyan]")
            manager.close()
            return

        if args.reset:
            # Confirm destructive action
            console.print("[red][bold]⚠️  WARNING: This will delete ALL vectors![/bold][/red]")
            confirm = input("Type 'yes' to confirm: ")
            if confirm.lower() != "yes":
                console.print("[yellow]Aborted.[/yellow]")
                manager.close()
                return
            manager.reset(keep_index=False)

        if args.clear_prefix:
            manager.clear_by_prefix("artifact_id", args.clear_prefix)

        if args.index_only:
            manager.create_vector_index(
                index_type=args.index_type,
                force=args.rebuild_index,
            )
            manager.create_metadata_indexes()

            # Show final stats
            stats = manager.get_stats()
            console.print("\n[bold]Final Stats:[/bold]")
            console.print(f"  Documents: [cyan]{stats.document_count:,}[/cyan]")
            console.print(f"  Vector index: [cyan]{stats.index_type or 'none'}[/cyan]")

        manager.close()
        return

    # Normal embedding mode
    embedder = FrameworkEmbedder()
    asyncio.run(
        embedder.run(
            dry_run=args.dry_run,
            limit=args.limit,
            domain=args.domain,
            include_prefixes=include_prefixes,
            exclude_prefixes=exclude_prefixes,
            format_filter=args.format,
            concurrency=args.concurrency,
            create_index=not args.no_index,
            index_type=args.index_type,
            rebuild_index=args.rebuild_index,
        )
    )


if __name__ == "__main__":
    main()
