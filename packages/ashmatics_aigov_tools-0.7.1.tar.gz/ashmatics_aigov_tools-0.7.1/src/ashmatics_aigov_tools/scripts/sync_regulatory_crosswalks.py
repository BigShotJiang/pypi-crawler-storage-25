#!/usr/bin/env python3
# Copyright (c) 2026, Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Regulatory Crosswalk Synchronization CLI

Created: 2026-01-19 (ASHPSTUDIO-183)

Synchronizes regulatory crosswalk mappings from YAML source files into
the ASHCAI ontology collections in MongoDB.

This CLI tool:
1. Parses regulatory *-logic.yaml files from ashmatics-policy-process-builder
2. Extracts crosswalk relationships (requirements → policies, controls, work products)
3. Upserts regulatory requirements and frameworks into MongoDB
4. Creates/updates relationship records in ashcai_regulatory_crosswalks

Usage:
    # Sync all regulatory frameworks
    cai-sync-regulatory

    # Sync specific frameworks only
    cai-sync-regulatory --frameworks NIST-AI-RMF JC-RUAIH

    # Specify custom YAML source directory
    cai-sync-regulatory --yaml-dir /path/to/wizard-content-schemas

    # Dry run to preview what would be synced
    cai-sync-regulatory --dry-run

    # Force full resync (delete existing crosswalks first)
    cai-sync-regulatory --force
"""

import argparse
import asyncio
import logging
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from ashmatics_aigov_tools.processors.regulatory_yaml_parser import (
    RegulatoryFramework,
    RegulatoryYAMLParser,
    find_yaml_directory,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

console = Console()


# ============================================================================
# Regulatory Crosswalk Synchronizer
# ============================================================================


class RegulatoryCrosswalkSyncer:
    """
    Synchronizes regulatory crosswalks from YAML to MongoDB.

    Handles parsing YAML files, extracting relationships, and upserting
    to the ASHCAI ontology collections.
    """

    def __init__(
        self,
        AZ_MONGO_CONNECTION_STRING: str,
        database_name: str,
        yaml_dir: Path,
        dry_run: bool = False,
        force: bool = False,
    ):
        """
        Initialize the syncer.

        Args:
            AZ_MONGO_CONNECTION_STRING: MongoDB connection URI
            database_name: Target database name
            yaml_dir: Path to the wizard-content-schemas directory
            dry_run: If True, only preview what would be done
            force: If True, delete existing crosswalks before syncing
        """
        self.AZ_MONGO_CONNECTION_STRING = AZ_MONGO_CONNECTION_STRING
        self.database_name = database_name
        self.yaml_dir = yaml_dir
        self.dry_run = dry_run
        self.force = force
        self.client: AsyncIOMotorClient | None = None
        self.db = None
        self.parser = RegulatoryYAMLParser(yaml_dir)
        self.stats = {
            "frameworks_processed": 0,
            "requirements_synced": 0,
            "crosswalks_created": 0,
            "crosswalks_updated": 0,
            "errors": [],
        }

    async def connect(self):
        """Establish MongoDB connection."""
        logger.info(f"Connecting to MongoDB: {self.database_name}")
        self.client = AsyncIOMotorClient(self.AZ_MONGO_CONNECTION_STRING)
        self.db = self.client[self.database_name]
        await self.client.admin.command("ping")
        logger.info("MongoDB connection established")

    async def disconnect(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")

    async def sync_all(
        self, framework_ids: list[str] | None = None
    ) -> dict[str, Any]:
        """
        Sync all or specified regulatory frameworks.

        Args:
            framework_ids: Optional list of framework IDs to sync.
                          If None, syncs all available frameworks.

        Returns:
            Dictionary with sync statistics
        """
        try:
            await self.connect()

            # Parse all YAML files
            frameworks = self.parser.parse_all()

            # Filter if specific frameworks requested
            if framework_ids:
                frameworks = [
                    f for f in frameworks if f.framework_id in framework_ids
                ]
                if not frameworks:
                    logger.warning(
                        f"No frameworks found matching: {framework_ids}"
                    )
                    return self.stats

            # Sync each framework
            for framework in frameworks:
                await self._sync_framework(framework)
                self.stats["frameworks_processed"] += 1

            return self.stats

        finally:
            await self.disconnect()

    async def _sync_framework(self, framework: RegulatoryFramework):
        """Sync a single regulatory framework."""
        logger.info(f"Syncing framework: {framework.framework_id}")

        # Step 1: Upsert framework metadata
        await self._upsert_framework_metadata(framework)

        # Step 2: Upsert regulatory requirements
        await self._upsert_requirements(framework)

        # Step 3: Extract and sync crosswalk relationships
        await self._sync_crosswalks(framework)

    async def _upsert_framework_metadata(self, framework: RegulatoryFramework):
        """Upsert the regulatory framework metadata document."""
        timestamp = datetime.now(UTC)

        framework_doc = {
            "framework_id": framework.framework_id,
            "program_name": framework.program_name,
            "program_authority": framework.program_authority,
            "version": framework.version,
            "description": framework.description,
            "target_applicability": framework.target_applicability,
            "function_categories": framework.function_categories,
            "source_file": framework.source_file,
            "requirements_count": len(framework.requirements),
            "ontology": "ashcai",
            "updated_at": timestamp,
        }

        if self.dry_run:
            logger.info(
                f"[DRY RUN] Would upsert framework: {framework.framework_id}"
            )
            return

        coll = self.db["ashcai_regulatory_frameworks"]
        result = await coll.update_one(
            {"framework_id": framework.framework_id},
            {
                "$set": framework_doc,
                "$setOnInsert": {"created_at": timestamp},
            },
            upsert=True,
        )
        logger.debug(
            f"Framework {framework.framework_id}: "
            f"matched={result.matched_count}, modified={result.modified_count}"
        )

    async def _upsert_requirements(self, framework: RegulatoryFramework):
        """Upsert all regulatory requirements for a framework."""
        timestamp = datetime.now(UTC)
        coll = self.db["ashcai_regulatory_requirements"]

        for req in framework.requirements:
            req_id = f"{framework.framework_id}-{req.requirement_id}"

            # Build subcategories list
            subcategories = [
                {
                    "id": sub.id,
                    "description": sub.description,
                    "implementation_priority": sub.implementation_priority,
                }
                for sub in req.subcategories
            ]

            req_doc = {
                "requirement_id": req_id,
                "framework_id": framework.framework_id,
                "original_id": req.requirement_id,
                "function": req.function,
                "category": req.category,
                "title": req.title,
                "description": req.description,
                "subcategories": subcategories,
                "subcategory_count": len(subcategories),
                "ontology": "ashcai",
                "updated_at": timestamp,
            }

            if self.dry_run:
                logger.debug(f"[DRY RUN] Would upsert requirement: {req_id}")
                self.stats["requirements_synced"] += 1
                continue

            try:
                result = await coll.update_one(
                    {"requirement_id": req_id},
                    {
                        "$set": req_doc,
                        "$setOnInsert": {"created_at": timestamp},
                    },
                    upsert=True,
                )
                self.stats["requirements_synced"] += 1
            except Exception as e:
                error_msg = f"Failed to upsert requirement {req_id}: {e}"
                logger.warning(error_msg)
                self.stats["errors"].append(error_msg)

    async def _sync_crosswalks(self, framework: RegulatoryFramework):
        """Sync crosswalk relationships for a framework."""
        # Extract relationships using the parser
        relationships = self.parser.extract_crosswalk_relationships(framework)

        if self.force and not self.dry_run:
            # Delete existing crosswalks for this framework
            coll = self.db["ashcai_regulatory_crosswalks"]
            result = await coll.delete_many(
                {"metadata.framework_id": framework.framework_id}
            )
            logger.info(
                f"Deleted {result.deleted_count} existing crosswalks for {framework.framework_id}"
            )

        # Upsert each relationship
        coll = self.db["ashcai_regulatory_crosswalks"]
        for rel in relationships:
            if self.dry_run:
                logger.debug(
                    f"[DRY RUN] Would create crosswalk: "
                    f"{rel['source_id']} -> {rel['target_id']}"
                )
                self.stats["crosswalks_created"] += 1
                continue

            try:
                # Create a unique key for the relationship
                filter_key = {
                    "source_id": rel["source_id"],
                    "target_id": rel["target_id"],
                    "relationship_type": rel["relationship_type"],
                    "metadata.framework_id": framework.framework_id,
                }

                result = await coll.update_one(
                    filter_key,
                    {"$set": rel},
                    upsert=True,
                )

                if result.upserted_id:
                    self.stats["crosswalks_created"] += 1
                elif result.modified_count > 0:
                    self.stats["crosswalks_updated"] += 1

            except Exception as e:
                error_msg = (
                    f"Failed to upsert crosswalk {rel['source_id']}->{rel['target_id']}: {e}"
                )
                logger.warning(error_msg)
                self.stats["errors"].append(error_msg)

        logger.info(
            f"Synced {len(relationships)} crosswalks for {framework.framework_id}"
        )


# ============================================================================
# CLI Functions
# ============================================================================


def display_results(stats: dict[str, Any], dry_run: bool):
    """Display sync results in a rich table."""
    table = Table(title="Regulatory Crosswalk Sync Results")

    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    prefix = "[DRY RUN] " if dry_run else ""

    table.add_row(
        f"{prefix}Frameworks Processed", str(stats["frameworks_processed"])
    )
    table.add_row(
        f"{prefix}Requirements Synced", str(stats["requirements_synced"])
    )
    table.add_row(
        f"{prefix}Crosswalks Created", str(stats["crosswalks_created"])
    )
    table.add_row(
        f"{prefix}Crosswalks Updated", str(stats["crosswalks_updated"])
    )

    if stats["errors"]:
        table.add_row("Errors", str(len(stats["errors"])))

    console.print(table)

    if stats["errors"]:
        console.print("\n[bold red]Errors:[/bold red]")
        for error in stats["errors"][:10]:  # Show first 10 errors
            console.print(f"  - {error}")
        if len(stats["errors"]) > 10:
            console.print(f"  ... and {len(stats['errors']) - 10} more errors")


def display_available_frameworks(yaml_dir: Path):
    """Display available frameworks in the YAML directory."""
    parser = RegulatoryYAMLParser(yaml_dir)
    frameworks = parser.parse_all()

    table = Table(title="Available Regulatory Frameworks")
    table.add_column("Framework ID", style="cyan")
    table.add_column("Program Name", style="green")
    table.add_column("Requirements", style="yellow")
    table.add_column("Source File", style="dim")

    for fw in frameworks:
        table.add_row(
            fw.framework_id,
            fw.program_name,
            str(len(fw.requirements)),
            Path(fw.source_file).name,
        )

    console.print(table)


async def run_sync(args: argparse.Namespace) -> int:
    """Run the crosswalk synchronization."""
    load_dotenv()

    # Get MongoDB connection details
    AZ_MONGO_CONNECTION_STRING = args.mongodb_uri or os.getenv(
        "AZ_MONGO_CONNECTION_STRING", "mongodb://localhost:27017"
    )
    database_name = args.database or os.getenv("MONGODB_DATABASE", "ashmatics_kb")

    # Get YAML directory
    yaml_dir = None
    if args.yaml_dir:
        yaml_dir = Path(args.yaml_dir)
    else:
        yaml_dir = find_yaml_directory()

    if yaml_dir is None or not yaml_dir.exists():
        console.print(
            "[bold red]Error: Could not find wizard-content-schemas directory[/bold red]"
        )
        console.print("Please specify --yaml-dir or ensure the directory exists at:")
        console.print("  - ./wizard-content-schemas")
        console.print("  - ../ashmatics-policy-process-builder/wizard-content-schemas")
        return 1

    console.print(f"[bold]Regulatory Crosswalk Sync[/bold]")
    console.print(f"Database: {database_name}")
    console.print(f"YAML Source: {yaml_dir}")
    if args.dry_run:
        console.print("[yellow]DRY RUN MODE - No changes will be made[/yellow]")
    if args.force:
        console.print(
            "[red]FORCE MODE - Existing crosswalks will be deleted before sync[/red]"
        )
    console.print()

    # Show available frameworks if requested
    if args.list:
        display_available_frameworks(yaml_dir)
        return 0

    # Run sync
    syncer = RegulatoryCrosswalkSyncer(
        AZ_MONGO_CONNECTION_STRING=AZ_MONGO_CONNECTION_STRING,
        database_name=database_name,
        yaml_dir=yaml_dir,
        dry_run=args.dry_run,
        force=args.force,
    )

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Syncing regulatory crosswalks...", total=None)

            framework_ids = args.frameworks if args.frameworks else None
            stats = await syncer.sync_all(framework_ids)

            progress.update(task, completed=True)

        display_results(stats, args.dry_run)

        if stats["errors"]:
            return 1
        return 0

    except Exception as e:
        console.print(f"[bold red]Sync failed: {e}[/bold red]")
        logger.exception("Sync error")
        return 1


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Sync regulatory crosswalks from YAML to MongoDB",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Sync all regulatory frameworks
    cai-sync-regulatory

    # List available frameworks
    cai-sync-regulatory --list

    # Sync specific frameworks only
    cai-sync-regulatory --frameworks NIST-AI-RMF JC-RUAIH

    # Dry run to preview
    cai-sync-regulatory --dry-run

    # Force full resync
    cai-sync-regulatory --force

    # Custom YAML directory
    cai-sync-regulatory --yaml-dir /path/to/wizard-content-schemas
        """,
    )

    parser.add_argument(
        "--mongodb-uri",
        help="MongoDB connection URI (default: from AZ_MONGO_CONNECTION_STRING env var)",
    )
    parser.add_argument(
        "--database",
        help="MongoDB database name (default: from MONGODB_DATABASE env var)",
    )
    parser.add_argument(
        "--yaml-dir",
        help="Path to wizard-content-schemas directory",
    )
    parser.add_argument(
        "--frameworks",
        nargs="+",
        help="Specific framework IDs to sync (e.g., NIST-AI-RMF JC-RUAIH)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List available frameworks and exit",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview what would be done without making changes",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Delete existing crosswalks before syncing",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    sys.exit(asyncio.run(run_sync(args)))


if __name__ == "__main__":
    main()
