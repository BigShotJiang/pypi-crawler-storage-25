# Copyright 2026 JF Kalafut
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
End-to-End Test Script for Query Preprocessing Pipeline (ASHKBAPP-68)

Tests the two-stage classification architecture:
- Stage 1: Rule-based classification (fast, free)
- Stage 2: LLM Refinement Oracle (GPT-4o-mini, only for low-confidence queries)

Environment Variables Required:
    AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY - API key for Azure Foundry

Usage:
    # Test Stage 1 only (no LLM calls, free)
    python test_query_pipeline.py --stage1-only

    # Test full pipeline including Stage 2 LLM refinement
    python test_query_pipeline.py

    # Test with specific query
    python test_query_pipeline.py --query "What is Risk Management?"

    # Run with verbose logging
    python test_query_pipeline.py -v
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()
load_dotenv(Path(__file__).parent / ".env")  # Local .env in demo_test folder

from ashmatics_aigov_tools.services.query_preprocessor import (
    QueryPreprocessor,
    QueryPreprocessorConfig,
)


@dataclass
class TestResult:
    """Result from a single test query."""

    query: str
    intent: str
    mcp_tool: str | None
    mcp_params: dict
    confidence: float
    stage_used: str  # "1" or "1+2"
    latency_ms: float
    tokens_used: int
    success: bool
    error: str | None = None


# Test queries covering all intent types
TEST_QUERIES = [
    # Known Item (should route to get_artifact)
    ("Show me SOP-PV-01", "known_item", "get_artifact"),
    ("Get artifact POL-RMP-Overview", "known_item", "get_artifact"),

    # Domain Explanation (should route to get_artifact for overviews)
    ("What is Risk Management?", "domain_explanation", "get_artifact"),
    ("Explain the monitoring domain", "domain_explanation", "get_artifact"),

    # Structural (should route to graph traversals)
    ("What SOPs implement EXC-A4-01?", "structural", "find_control_implementations"),
    ("Show the hierarchy under MMP-001", "structural", "get_policy_domain_hierarchy"),
    ("What work products does SOP-PV-01 produce?", "structural", "get_policy_domain_hierarchy"),

    # Regulatory Crosswalk
    ("How do we comply with NIST AI RMF?", "regulatory_crosswalk", "get_regulatory_crosswalk"),
    ("Map our framework to ISO 42001", "regulatory_crosswalk", "get_regulatory_crosswalk"),
    ("What evidence satisfies NIST-AI-RMF-GOVERN-1.1?", "regulatory_crosswalk", "find_evidence_for_requirement"),

    # List Entities (should route to statistics/category)
    ("List all policy domains", "list_entities", "get_ashcai_statistics"),
    ("Show me all regulatory frameworks", "list_entities", "get_ashcai_statistics"),
    ("List all SOPs", "list_entities", "get_category_content"),

    # Topical (should route to semantic search)
    ("Best practices for bias testing in healthcare AI", "topical", "semantic_search_framework"),
    ("How should we approach fairness assessment?", "topical", "semantic_search_framework"),

    # Comparative (multi-source, synthesis required)
    ("How is ASHCAI different from ISO 42001?", "comparative", "semantic_search_framework"),
    ("Compare our risk management to NIST", "comparative", "semantic_search_framework"),

    # Gap Analysis
    ("What's missing for Colorado AI Act compliance?", "gap_analysis", "get_regulatory_crosswalk"),
    ("Identify gaps in our NIST coverage", "gap_analysis", "get_regulatory_crosswalk"),

    # Explanatory (why questions)
    ("Why does ASHCAI separate MON and MM domains?", "explanatory", "semantic_search_framework"),
    ("What is the purpose of human oversight in AI governance?", "explanatory", "semantic_search_framework"),

    # Ambiguous queries (low confidence, may trigger Stage 2)
    ("help me with AI", "unknown", "semantic_search_framework"),
    ("governance stuff", "unknown", "semantic_search_framework"),
]


def run_test(
    preprocessor: QueryPreprocessor,
    query: str,
    expected_intent: str,
    expected_tool: str,
    use_llm: bool = True,
) -> TestResult:
    """Run a single test query and return results."""
    start_time = time.perf_counter()
    tokens_before = preprocessor.stats["total_tokens_used"]

    try:
        plan = preprocessor.process(query, use_llm_fallback=use_llm)
        latency_ms = (time.perf_counter() - start_time) * 1000
        tokens_used = preprocessor.stats["total_tokens_used"] - tokens_before

        # Determine which stage was used
        stage_used = "1+2" if tokens_used > 0 else "1"

        return TestResult(
            query=query,
            intent=plan.intent.value,
            mcp_tool=plan.suggested_mcp_tool,
            mcp_params=plan.mcp_tool_params,
            confidence=plan.confidence,
            stage_used=stage_used,
            latency_ms=latency_ms,
            tokens_used=tokens_used,
            success=True,
        )
    except Exception as e:
        latency_ms = (time.perf_counter() - start_time) * 1000
        return TestResult(
            query=query,
            intent="error",
            mcp_tool=None,
            mcp_params={},
            confidence=0.0,
            stage_used="error",
            latency_ms=latency_ms,
            tokens_used=0,
            success=False,
            error=str(e),
        )


def print_result(result: TestResult, expected_intent: str, expected_tool: str) -> None:
    """Print a single test result."""
    intent_match = "✓" if result.intent == expected_intent else "✗"
    tool_match = "✓" if result.mcp_tool == expected_tool else "✗"

    print(f"\nQuery: {result.query[:60]}...")
    print(f"  Intent:  {intent_match} {result.intent:<20} (expected: {expected_intent})")
    print(f"  MCP Tool:{tool_match} {result.mcp_tool or 'None':<30} (expected: {expected_tool})")
    print(f"  Params:  {result.mcp_params}")
    print(f"  Confidence: {result.confidence:.2f} | Stage: {result.stage_used} | Latency: {result.latency_ms:.0f}ms | Tokens: {result.tokens_used}")

    if result.error:
        print(f"  ERROR: {result.error}")


def run_all_tests(
    stage1_only: bool = False,
    verbose: bool = False,
    confidence_threshold: float = 0.7,
) -> None:
    """Run all test queries."""
    # Configure logging
    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    # Check for API key if using LLM
    api_key = os.getenv("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")
    if not stage1_only and not api_key:
        print("WARNING: AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY not set.")
        print("         Stage 2 LLM refinement will be disabled.")
        print("         Set the env var or use --stage1-only\n")
        stage1_only = True

    # Create preprocessor with custom config
    config = QueryPreprocessorConfig(
        enable_refinement_oracle=not stage1_only,
        refinement_threshold=confidence_threshold,
        log_classifications=verbose,
    )
    preprocessor = QueryPreprocessor(config=config)

    print("=" * 70)
    print("Query Preprocessing Pipeline Test (ASHKBAPP-68)")
    print("=" * 70)
    print(f"Mode: {'Stage 1 only (rule-based)' if stage1_only else 'Full pipeline (Stage 1 + Stage 2 LLM)'}")
    print(f"Confidence threshold: {confidence_threshold}")
    print(f"Model: {config.refinement_model}")
    print(f"Endpoint: {config.get_endpoint()}")
    print("=" * 70)

    # Run tests
    results: list[TestResult] = []
    intent_correct = 0
    tool_correct = 0
    total_tokens = 0
    total_latency = 0.0
    stage2_invocations = 0

    for query, expected_intent, expected_tool in TEST_QUERIES:
        result = run_test(
            preprocessor,
            query,
            expected_intent,
            expected_tool,
            use_llm=not stage1_only,
        )
        results.append(result)

        if result.success:
            if result.intent == expected_intent:
                intent_correct += 1
            if result.mcp_tool == expected_tool:
                tool_correct += 1
            total_tokens += result.tokens_used
            total_latency += result.latency_ms
            if result.stage_used == "1+2":
                stage2_invocations += 1

        print_result(result, expected_intent, expected_tool)

    # Summary
    total = len(TEST_QUERIES)
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"Intent Accuracy:  {intent_correct}/{total} ({100*intent_correct/total:.1f}%)")
    print(f"MCP Tool Accuracy: {tool_correct}/{total} ({100*tool_correct/total:.1f}%)")
    print(f"Stage 2 Invocations: {stage2_invocations}/{total}")
    print(f"Total Tokens Used: {total_tokens}")
    print(f"Average Latency: {total_latency/total:.0f}ms")
    print(f"Total Latency: {total_latency:.0f}ms")

    # Preprocessor stats
    stats = preprocessor.stats
    print(f"\nPreprocessor Stats:")
    print(f"  Queries Processed: {stats['total_queries']}")
    print(f"  Refinement Invocations: {stats['refinement_invocations']}")
    print(f"  Total Tokens: {stats['total_tokens_used']}")


def run_single_query(
    query: str,
    stage1_only: bool = False,
    verbose: bool = False,
) -> None:
    """Run a single query interactively."""
    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    config = QueryPreprocessorConfig(
        enable_refinement_oracle=not stage1_only,
        log_classifications=True,
    )
    preprocessor = QueryPreprocessor(config=config)

    print(f"\nProcessing: {query}\n")

    start = time.perf_counter()
    plan = preprocessor.process(query, use_llm_fallback=not stage1_only)
    latency = (time.perf_counter() - start) * 1000

    print("\n" + "=" * 50)
    print("QUERY PLAN")
    print("=" * 50)
    print(f"Intent:           {plan.intent.value}")
    print(f"Strategy:         {plan.strategy.value}")
    print(f"Confidence:       {plan.confidence:.2f}")
    print(f"")
    print(f"MCP Tool:         {plan.suggested_mcp_tool}")
    print(f"MCP Params:       {plan.mcp_tool_params}")
    if plan.additional_mcp_tools:
        print(f"Additional Tools: {plan.additional_mcp_tools}")
    print(f"")
    print(f"Latency:          {latency:.0f}ms")
    print(f"Tokens Used:      {preprocessor.stats['total_tokens_used']}")
    print(f"")
    print(f"Signals:          {plan.classification_signals}")


def main():
    parser = argparse.ArgumentParser(
        description="Test the Query Preprocessing Pipeline (ASHKBAPP-68)"
    )
    parser.add_argument(
        "--stage1-only",
        action="store_true",
        help="Only use Stage 1 (rule-based), skip LLM refinement",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )
    parser.add_argument(
        "--query", "-q",
        type=str,
        help="Run a single query instead of the test suite",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.7,
        help="Confidence threshold for Stage 2 (default: 0.7)",
    )

    args = parser.parse_args()

    if args.query:
        run_single_query(args.query, args.stage1_only, args.verbose)
    else:
        run_all_tests(args.stage1_only, args.verbose, args.threshold)


if __name__ == "__main__":
    main()
