#!/usr/bin/env python3
"""
Test Script for Framework Explorer Pipeline

ASHPSTUDIO-184: Framework Explorer Pipeline

Runs the full pipeline against the KB MCP server with sample queries.
Demonstrates all pipeline stages: Query → Retrieval → Synthesis → Validation

Usage:
    # With default queries
    uv run python src/ashmatics_aigov_tools/scripts/demo_test/test_explorer_pipeline.py

    # With custom query
    uv run python src/ashmatics_aigov_tools/scripts/demo_test/test_explorer_pipeline.py \
        --query "What is Risk Management?"

    # Skip validation for faster testing
    uv run python src/ashmatics_aigov_tools/scripts/demo_test/test_explorer_pipeline.py \
        --skip-validation

    # Verbose output with full context
    uv run python src/ashmatics_aigov_tools/scripts/demo_test/test_explorer_pipeline.py \
        --verbose

Environment Variables Required:
    MCP_URL - KB MCP server URL (default: http://localhost:8088)
    AZURE_FOUNDRY_ENDPOINT - Azure AI Foundry endpoint
    AZURE_FOUNDRY_API_KEY - API key (or use az login)

Created: 2026-01-27
Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

# Load environment variables from ashmatics-tools.env
from dotenv import load_dotenv

# Find the repo root and load the env file
_repo_root = Path(__file__).resolve().parents[4]
_env_file = _repo_root / "ashmatics-tools.env"
if _env_file.exists():
    load_dotenv(_env_file)
else:
    # Fallback to .env if present
    load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


# Sample test queries covering different intents
TEST_QUERIES = [
    # Topical / Explanatory
    "What is Risk Management in the ASHCAI framework?",
    # Structural
    "What SOPs implement the Model Monitoring policy?",
    # Regulatory crosswalk
    "How does ASHCAI map to NIST AI RMF requirements?",
    # Gap analysis
    "What controls are we missing for NIST compliance?",
    # Known item
    "Show me SOP-PV-01",
    # Comparative
    "How is ASHCAI different from ISO 42001?",
]


async def test_pipeline(
    query: str,
    skip_validation: bool = False,
    verbose: bool = False,
) -> dict:
    """
    Run a single query through the pipeline.

    Args:
        query: The query to test
        skip_validation: Skip validation stage
        verbose: Print detailed output

    Returns:
        Dict with test results
    """
    from ashmatics_aigov_tools.services import (
        FrameworkExplorerPipeline,
        KBMCPClient,
        MCPClientConfig,
        PipelineConfig,
    )

    # Configure pipeline
    config = PipelineConfig(
        enable_validation=not skip_validation,
        log_stages=verbose,
        trace_enabled=True,
    )

    # Connect to MCP server
    mcp_config = MCPClientConfig.from_env()

    print(f"\n{'=' * 70}")
    print(f"Query: {query}")
    print(f"{'=' * 70}")

    try:
        async with KBMCPClient(mcp_config) as client:
            # Check MCP health first
            health = await client.health_check()
            if not health.get("healthy"):
                print(f"  WARNING: MCP server may not be healthy: {health}")

            # Create and run pipeline
            pipeline = FrameworkExplorerPipeline(client, config)

            start_time = datetime.now()
            result = await pipeline.explore(query, skip_validation=skip_validation)
            elapsed = (datetime.now() - start_time).total_seconds()

            # Print results
            print(f"\nIntent: {result.intent}")
            print(f"Confidence: {result.confidence:.2f} ({result.confidence_level.value})")
            print(f"Success: {result.success}")
            print(f"Time: {elapsed:.2f}s ({result.total_ms:.0f}ms reported)")

            if result.citations:
                print(f"\nCitations ({len(result.citations)}):")
                for cite in result.citations[:5]:
                    print(f"  - {cite.artifact_id}: {cite.relevance[:60]}...")

            print("\nResponse Preview:")
            print("-" * 50)
            # Print first 500 chars of response
            preview = result.response[:500] if result.response else "(empty)"
            print(preview)
            if len(result.response) > 500:
                print(f"... ({len(result.response) - 500} more chars)")
            print("-" * 50)

            if verbose and result.context:
                print("\nPipeline Trace:")
                ctx = result.context
                print(f"  Query stage: {ctx.query_stage_ms:.0f}ms")
                print(f"  Retrieval stage: {ctx.retrieval_stage_ms:.0f}ms")
                print(f"  Synthesis stage: {ctx.synthesis_stage_ms:.0f}ms")
                print(f"  Validation stage: {ctx.validation_stage_ms:.0f}ms")
                print(f"  Total tokens: {ctx.total_tokens}")
                print(f"  Retries: {ctx.retry_count}")

                if ctx.query_plan:
                    print("\n  Query Plan:")
                    print(f"    Intent: {ctx.query_plan.intent.value}")
                    print(f"    Strategy: {ctx.query_plan.strategy.value}")
                    print(f"    MCP Tool: {ctx.query_plan.suggested_mcp_tool}")

                if ctx.validation_result:
                    vr = ctx.validation_result
                    print("\n  Validation:")
                    print(f"    Passed: {vr.passed}")
                    print(f"    Skipped: {vr.skipped}")
                    if vr.issues:
                        print(f"    Issues: {vr.issues}")

            if result.error:
                print(f"\nError: {result.error}")

            return {
                "query": query,
                "success": result.success,
                "confidence": result.confidence,
                "intent": result.intent,
                "citations_count": len(result.citations),
                "response_length": len(result.response),
                "elapsed_seconds": elapsed,
                "error": result.error,
            }

    except Exception as e:
        logger.exception(f"Pipeline failed for query: {query}")
        print(f"\nERROR: {e}")
        return {
            "query": query,
            "success": False,
            "error": str(e),
        }


async def run_test_suite(
    queries: list[str] | None = None,
    skip_validation: bool = False,
    verbose: bool = False,
) -> None:
    """
    Run the full test suite.

    Args:
        queries: List of queries to test (uses defaults if None)
        skip_validation: Skip validation for all queries
        verbose: Verbose output
    """
    queries = queries or TEST_QUERIES

    print("\n" + "=" * 70)
    print("FRAMEWORK EXPLORER PIPELINE - TEST SUITE")
    print("=" * 70)
    print(f"Queries to test: {len(queries)}")
    print(f"Skip validation: {skip_validation}")
    print(f"Verbose: {verbose}")

    results = []
    for query in queries:
        result = await test_pipeline(
            query=query,
            skip_validation=skip_validation,
            verbose=verbose,
        )
        results.append(result)

    # Summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)

    successful = sum(1 for r in results if r.get("success"))
    print(f"Total: {len(results)}")
    print(f"Successful: {successful}")
    print(f"Failed: {len(results) - successful}")

    if results:
        avg_time = sum(r.get("elapsed_seconds", 0) for r in results) / len(results)
        avg_confidence = sum(r.get("confidence", 0) for r in results if r.get("success")) / max(
            successful, 1
        )
        print(f"Avg time: {avg_time:.2f}s")
        print(f"Avg confidence: {avg_confidence:.2f}")

    print("\nResults by query:")
    for r in results:
        status = "OK" if r.get("success") else "FAIL"
        conf = r.get("confidence", 0)
        print(f"  [{status}] {r['query'][:50]}... (conf={conf:.2f})")

    # Return exit code
    if successful < len(results):
        sys.exit(1)


async def test_single_query(
    query: str,
    skip_validation: bool = False,
    verbose: bool = False,
    output_json: bool = False,
) -> None:
    """Test a single query and optionally output JSON."""
    result = await test_pipeline(
        query=query,
        skip_validation=skip_validation,
        verbose=verbose,
    )

    if output_json:
        print("\nJSON Output:")
        print(json.dumps(result, indent=2, default=str))


def main():
    parser = argparse.ArgumentParser(
        description="Test the Framework Explorer Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--query",
        "-q",
        type=str,
        help="Single query to test (runs test suite if not provided)",
    )
    parser.add_argument(
        "--skip-validation",
        "-s",
        action="store_true",
        help="Skip validation stage for faster testing",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Verbose output with full pipeline trace",
    )
    parser.add_argument(
        "--json",
        "-j",
        action="store_true",
        help="Output results as JSON (single query only)",
    )
    parser.add_argument(
        "--all",
        "-a",
        action="store_true",
        help="Run all test queries",
    )

    args = parser.parse_args()

    if args.query:
        # Single query mode
        asyncio.run(
            test_single_query(
                query=args.query,
                skip_validation=args.skip_validation,
                verbose=args.verbose,
                output_json=args.json,
            )
        )
    elif args.all:
        # Full test suite
        asyncio.run(
            run_test_suite(
                skip_validation=args.skip_validation,
                verbose=args.verbose,
            )
        )
    else:
        # Default: run first 2 queries as quick test
        asyncio.run(
            run_test_suite(
                queries=TEST_QUERIES[:2],
                skip_validation=args.skip_validation,
                verbose=args.verbose,
            )
        )


if __name__ == "__main__":
    main()
