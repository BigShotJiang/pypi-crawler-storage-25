# Copyright 2026 JF Kalafut
# Quick test to see DeepSeek-R1 response format when asking for JSON

from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

endpoint = "https://kb-search-parse.openai.azure.com/openai/v1/"
deployment_name = "DeepSeek-R1-0528"
api_key = os.getenv("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")

client = OpenAI(base_url=endpoint, api_key=api_key)

# Test with the same prompt style as Refinement Oracle
system_prompt = '''You are a query classification assistant. 
CRITICAL: You MUST output valid JSON and nothing else. Do not explain, do not add commentary.

Output EXACTLY this format:
{"intent": "<intent>", "confidence": <0.0-1.0>, "reasoning": "<one sentence>"}'''

user_prompt = '''Classify this query: "How should we think about model monitoring?"

Initial classification: topical (0.50 confidence)

Valid intents: known_item, domain_explanation, structural, list_entities, topical, comparative, regulatory_crosswalk, procedural, unknown

OUTPUT JSON ONLY:'''

print("Sending request to DeepSeek-R1...")
print("=" * 60)

response = client.chat.completions.create(
    model=deployment_name,
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ],
    temperature=0.3,
    max_tokens=500,
)

message = response.choices[0].message

print("\n=== CONTENT ===")
print(repr(message.content))
print("\n=== REASONING_CONTENT ===")
reasoning = getattr(message, 'reasoning_content', None)
print(repr(reasoning))
print("\n=== TOKENS ===")
print(f"Total: {response.usage.total_tokens}")
