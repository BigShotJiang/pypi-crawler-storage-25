"""Test DeepSeek-R1 JSON response parsing."""
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

endpoint = "https://kb-search-parse.openai.azure.com/openai/v1/"
deployment_name = "DeepSeek-R1-0528"
api_key = os.getenv("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")

client = OpenAI(base_url=endpoint, api_key=api_key)

# Test with a JSON request like our Refinement Oracle does
completion = client.chat.completions.create(
    model=deployment_name,
    messages=[
        {
            "role": "system",
            "content": 'You are a query classifier. Respond with JSON only: {"intent": "<type>", "confidence": <0.0-1.0>}',
        },
        {
            "role": "user",
            "content": "Classify: How should we think about model monitoring?",
        },
    ],
    temperature=0.3,
    max_tokens=500,
)

msg = completion.choices[0].message
print("=== CONTENT ===")
print(repr(msg.content))
print()
print("=== REASONING_CONTENT ===")
reasoning = getattr(msg, "reasoning_content", None)
if reasoning:
    print(f"Length: {len(reasoning)}")
    print(repr(reasoning[:800]))
else:
    print("None")
