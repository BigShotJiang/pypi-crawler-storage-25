# Copyright 2026 JF Kalafut
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     https://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from openai import OpenAI
from dotenv import load_dotenv
import os

#Hello world script for Azure OpenAI DeepSeek deployment and seeing how works, especially authentication

#there is a .env in this folder with AZ foundrey credentials
load_dotenv()

endpoint = "https://kb-search-parse.openai.azure.com/openai/v1/"
deployment_name = "DeepSeek-R1-0528"
api_key = os.getenv("AZURE_FOUNDRY_KB_SEARCH_PARSE_API_KEY")

client = OpenAI(
    base_url=endpoint,
    api_key=api_key
)

completion = client.chat.completions.create(
    model=deployment_name,
    messages=[
        {
            "role": "user",
            "content": "What is the capital of France?",
        }
    ],
    temperature=0.7,
)

print(completion.choices[0].message)