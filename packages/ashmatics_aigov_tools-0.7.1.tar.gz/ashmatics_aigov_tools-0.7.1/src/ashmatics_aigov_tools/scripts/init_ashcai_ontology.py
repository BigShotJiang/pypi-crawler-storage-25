#!/usr/bin/env python3
# Copyright (c) 2026, Asher Informatics PBC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ASHCAI Ontology Initializer CLI

Created: 2026-01-19 (ASHPSTUDIO-183)
Updated: 2026-01-20 (ASHKBAPP-60) - Load from framework registry JSON

Initializes the ASHCAI (AshMatics Clinical AI Governance) ontology in MongoDB,
creating the base collections and populating reference data from the framework
registry JSON file.

This CLI tool:
1. Creates ASHCAI MongoDB collections with proper indexes
2. Loads policy domains and process domains from framework registry
3. Creates policy→process "specifies" relationships
4. Validates the ontology structure

Usage:
    # Initialize ontology with default settings (auto-discovers registry file)
    cai-init-ontology

    # Initialize with explicit registry file path
    cai-init-ontology --registry-file /path/to/ashmatics-framework-registry.json

    # Initialize with custom MongoDB connection
    cai-init-ontology --mongodb-uri "mongodb://localhost:27017" --database "ashmatics_dev"

    # Dry run to preview what would be created
    cai-init-ontology --dry-run

    # Force re-initialization (drops existing collections)
    cai-init-ontology --force
"""

import argparse
import asyncio
import json
import logging
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from rich.console import Console
from rich.table import Table

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

console = Console()


# ============================================================================
# ASHCAI Collection Definitions
# ============================================================================

ASHCAI_COLLECTIONS = {
    # Core governance entity collections
    "ashcai_policy_domains": {
        "description": "Policy domain definitions (MMP-001, AGP-001, etc.)",
        "indexes": [
            {"keys": [("domain_id", 1)], "unique": True},
            {"keys": [("domain_code", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_process_domains": {
        "description": "Process domain definitions (MON, RM, SA, etc.)",
        "indexes": [
            {"keys": [("domain_code", 1)], "unique": True},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_base_practices": {
        "description": "Base practices within process domains (MON.BP01, etc.)",
        "indexes": [
            {"keys": [("practice_id", 1)], "unique": True},
            {"keys": [("process_domain", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_sop_templates": {
        "description": "SOP template definitions (SOP-MON-01, etc.)",
        "indexes": [
            {"keys": [("sop_id", 1)], "unique": True},
            {"keys": [("process_domain", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_work_product_templates": {
        "description": "Work product template definitions (WP-MON-01-Dashboard, etc.)",
        "indexes": [
            {"keys": [("wp_id", 1)], "unique": True},
            {"keys": [("process_domain", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_exemplar_controls": {
        "description": "Exemplar control definitions (EXC-A4-01, etc.)",
        "indexes": [
            {"keys": [("control_id", 1)], "unique": True},
            {"keys": [("iso_annex", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_process_outputs": {
        "description": "Process output definitions (OUT-RM-RiskManagementPlan, etc.)",
        "indexes": [
            {"keys": [("_id", 1)], "unique": True},
            {"keys": [("processDomain", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_tools": {
        "description": "Tool definitions from tooling registry (TOOL-risk-matrix, etc.)",
        "indexes": [
            {"keys": [("_id", 1)], "unique": True},
            {"keys": [("token", 1)]},
            {"keys": [("toolType", 1)]},
            {"keys": [("status", 1)]},
        ],
    },
    "ashcai_regulatory_requirements": {
        "description": "Regulatory requirement definitions (NIST-MAP-4.2, etc.)",
        "indexes": [
            {"keys": [("requirement_id", 1)], "unique": True},
            {"keys": [("framework_id", 1)]},
            {"keys": [("function", 1)]},
        ],
    },
    "ashcai_regulatory_frameworks": {
        "description": "Regulatory framework metadata (NIST-AI-RMF, JC-RUAIH, etc.)",
        "indexes": [
            {"keys": [("framework_id", 1)], "unique": True},
        ],
    },
    # Relationship collections
    "ashcai_relationships": {
        "description": "All ASHCAI relationships between entities",
        "indexes": [
            {"keys": [("source_id", 1), ("target_id", 1), ("relationship_type", 1)]},
            {"keys": [("source_id", 1)]},
            {"keys": [("target_id", 1)]},
            {"keys": [("relationship_type", 1)]},
            {"keys": [("source_type", 1)]},
            {"keys": [("target_type", 1)]},
        ],
    },
    "ashcai_regulatory_crosswalks": {
        "description": "Regulatory requirement crosswalk mappings",
        "indexes": [
            {"keys": [("framework_id", 1), ("requirement_id", 1)]},
            {"keys": [("source_id", 1)]},
            {"keys": [("target_id", 1)]},
        ],
    },
    # Ontology metadata
    "ashcai_ontology_metadata": {
        "description": "Ontology version and configuration metadata",
        "indexes": [
            {"keys": [("version", 1)], "unique": True},
        ],
    },
}


# ============================================================================
# Registry File Discovery and Loading
# ============================================================================

# Default locations to search for the framework registry
REGISTRY_SEARCH_PATHS = [
    # Relative to this file (when in ashmatics-aigov-tools)
    Path(__file__).parent.parent.parent.parent.parent
    / "ashmatics-policy-process-builder"
    / "ashmatics-framework-registry.json",
    # Common development paths
    Path.home()
    / "GitHub"
    / "AsherInformatics"
    / "ashmatics-policy-process-builder"
    / "ashmatics-framework-registry.json",
    # Docker/container paths
    Path("/app/config/ashmatics-framework-registry.json"),
]


def find_registry_file() -> Path | None:
    """
    Auto-discover the framework registry file.

    Returns:
        Path to the registry file if found, None otherwise.
    """
    for path in REGISTRY_SEARCH_PATHS:
        if path.exists():
            return path
    return None


def load_framework_registry(registry_path: Path) -> dict[str, Any]:
    """
    Load the framework registry JSON file.

    Args:
        registry_path: Path to the ashmatics-framework-registry.json file.

    Returns:
        Parsed registry data.

    Raises:
        FileNotFoundError: If the registry file doesn't exist.
        json.JSONDecodeError: If the file isn't valid JSON.
    """
    if not registry_path.exists():
        raise FileNotFoundError(f"Registry file not found: {registry_path}")

    with open(registry_path) as f:
        registry = json.load(f)

    # Validate required keys
    required_keys = ["policyDomains", "processDomains", "domainRelationships"]
    for key in required_keys:
        if key not in registry:
            raise ValueError(f"Registry file missing required key: {key}")

    return registry


def extract_process_domains(registry: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Extract process domain definitions from the registry.

    Args:
        registry: Loaded framework registry data.

    Returns:
        List of process domain dictionaries ready for MongoDB insertion.
    """
    process_domains = []

    for code, data in registry["processDomains"].items():
        process_domains.append(
            {
                "domain_code": code,
                "label": data.get("name", code),
                "description": data.get("description", ""),
                "area_id": data.get("areaId"),
                "category": data.get("category"),
                "base_practices": data.get("basePractices", []),
                "policy_bindings": data.get("policyBindings", []),
                "upstream_domains": data.get("upstreamDomains", []),
                "downstream_domains": data.get("downstreamDomains", []),
                "sop_count": data.get("sopCount", 0),
                "artifacts": data.get("artifacts", {}),
                "status": "active",
            }
        )

    return process_domains


def extract_policy_domains(registry: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Extract policy domain definitions from the registry.

    Args:
        registry: Loaded framework registry data.

    Returns:
        List of policy domain dictionaries ready for MongoDB insertion.
    """
    policy_domains = []

    for code, data in registry["policyDomains"].items():
        policy_domains.append(
            {
                "domain_id": data.get("artifactId", f"{code}-001"),
                "domain_code": code,
                "label": data.get("name", code),
                "description": data.get("description", ""),
                "tier": data.get("tier"),
                "category": data.get("category"),
                "artifacts": data.get("artifacts", {}),
                "activates_process_domains": data.get("activatesProcessDomains", []),
                "iso42001_controls": data.get("iso42001Controls", []),
                "exemplar_controls": data.get("exemplarControls", []),
                "regulatory_mapping": data.get("regulatoryMapping", {}),
                "folded_concepts": data.get("foldedConcepts", {}),
                "key_tokens": data.get("keyTokens", []),
                "status": data.get("status", "active"),
                "notes": data.get("notes"),
            }
        )

    return policy_domains


def extract_policy_to_process_relationships(
    registry: dict[str, Any],
) -> list[dict[str, Any]]:
    """
    Extract policy-to-process 'specifies' relationships from the registry.

    Args:
        registry: Loaded framework registry data.

    Returns:
        List of relationship dictionaries ready for MongoDB insertion.
    """
    relationships = []
    policy_to_process = registry.get("domainRelationships", {}).get("policyToProcess", {})

    for policy_code, process_codes in policy_to_process.items():
        # Get the artifact ID for the policy (e.g., SAP -> SAP-001)
        policy_data = registry.get("policyDomains", {}).get(policy_code, {})
        policy_id = policy_data.get("artifactId", f"{policy_code}-001")

        for process_code in process_codes:
            relationships.append(
                {
                    "source_id": policy_id,
                    "source_type": "PolicyDomain",
                    "target_id": process_code,
                    "target_type": "ProcessDomain",
                    "relationship_type": "specifies",
                    "strength": 1.0,
                    "confidence": 1.0,
                    "source": "ontology_definition",
                    "created_by": "cai-init-ontology",
                    "description": f"Policy {policy_code} specifies process domain {process_code}",
                    "status": "active",
                    "ontology": "ashcai",
                }
            )

    return relationships


# ============================================================================
# Ontology Initializer
# ============================================================================


class AshcaiOntologyInitializer:
    """
    Initializes the ASHCAI ontology in MongoDB.

    Creates collections, indexes, and populates reference data from the
    framework registry JSON file.
    """

    def __init__(
        self,
        AZ_MONGO_CONNECTION_STRING: str,
        database_name: str,
        registry: dict[str, Any],
        dry_run: bool = False,
        force: bool = False,
    ):
        """
        Initialize the ontology initializer.

        Args:
            AZ_MONGO_CONNECTION_STRING: MongoDB connection URI
            database_name: Target database name
            registry: Loaded framework registry data
            dry_run: If True, only preview what would be done
            force: If True, drop existing collections before creating
        """
        self.AZ_MONGO_CONNECTION_STRING = AZ_MONGO_CONNECTION_STRING
        self.database_name = database_name
        self.registry = registry
        self.dry_run = dry_run
        self.force = force
        self.client: AsyncIOMotorClient | None = None
        self.db = None

        # Extract data from registry
        self.process_domains = extract_process_domains(registry)
        self.policy_domains = extract_policy_domains(registry)
        self.relationships = extract_policy_to_process_relationships(registry)

        self.stats = {
            "collections_created": 0,
            "indexes_created": 0,
            "process_domains_inserted": 0,
            "policy_domains_inserted": 0,
            "relationships_inserted": 0,
            "errors": [],
        }

    async def connect(self):
        """Establish MongoDB connection."""
        logger.info(f"Connecting to MongoDB: {self.database_name}")
        self.client = AsyncIOMotorClient(self.AZ_MONGO_CONNECTION_STRING)
        self.db = self.client[self.database_name]

        # Verify connection
        await self.client.admin.command("ping")
        logger.info("MongoDB connection established")

    async def disconnect(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")

    async def initialize(self) -> dict[str, Any]:
        """
        Run the full initialization process.

        Returns:
            Dictionary with initialization statistics
        """
        try:
            await self.connect()

            # Step 1: Create collections
            await self._create_collections()

            # Step 2: Create indexes
            await self._create_indexes()

            # Step 3: Insert reference data (process and policy domains)
            await self._insert_reference_data()

            # Step 4: Insert policy→process relationships
            await self._insert_relationships()

            # Step 5: Insert ontology metadata
            await self._insert_ontology_metadata()

            return self.stats

        finally:
            await self.disconnect()

    async def _create_collections(self):
        """Create ASHCAI collections if they don't exist."""
        existing = await self.db.list_collection_names()

        for coll_name, coll_info in ASHCAI_COLLECTIONS.items():
            if coll_name in existing:
                if self.force:
                    if not self.dry_run:
                        await self.db.drop_collection(coll_name)
                        logger.info(f"Dropped existing collection: {coll_name}")
                else:
                    logger.info(f"Collection already exists: {coll_name}")
                    continue

            if self.dry_run:
                logger.info(f"[DRY RUN] Would create collection: {coll_name}")
            else:
                await self.db.create_collection(coll_name)
                logger.info(f"Created collection: {coll_name}")

            self.stats["collections_created"] += 1

    async def _create_indexes(self):
        """Create indexes on ASHCAI collections."""
        for coll_name, coll_info in ASHCAI_COLLECTIONS.items():
            collection = self.db[coll_name]

            for idx_config in coll_info.get("indexes", []):
                keys = idx_config["keys"]
                unique = idx_config.get("unique", False)
                index_name = "_".join(f"{k}_{d}" for k, d in keys)

                if self.dry_run:
                    logger.info(
                        f"[DRY RUN] Would create index {index_name} on {coll_name}"
                    )
                else:
                    try:
                        await collection.create_index(keys, unique=unique)
                        logger.debug(f"Created index {index_name} on {coll_name}")
                        self.stats["indexes_created"] += 1
                    except Exception as e:
                        if "already exists" not in str(e).lower():
                            logger.warning(f"Failed to create index: {e}")
                            self.stats["errors"].append(str(e))

    async def _insert_reference_data(self):
        """Insert reference process and policy domains from the registry."""
        timestamp = datetime.now(UTC)

        # Insert process domains
        process_coll = self.db["ashcai_process_domains"]
        for pd in self.process_domains:
            pd_doc = {
                **pd,
                "ontology": "ashcai",
                "created_at": timestamp,
                "updated_at": timestamp,
            }

            if self.dry_run:
                logger.info(
                    f"[DRY RUN] Would insert process domain: {pd['domain_code']}"
                )
                self.stats["process_domains_inserted"] += 1
            else:
                try:
                    # Use upsert to avoid duplicates
                    result = await process_coll.update_one(
                        {"domain_code": pd["domain_code"]},
                        {"$set": pd_doc},
                        upsert=True,
                    )
                    self.stats["process_domains_inserted"] += 1
                    logger.debug(f"Upserted process domain: {pd['domain_code']}")
                except Exception as e:
                    logger.warning(f"Failed to insert process domain {pd['domain_code']}: {e}")
                    self.stats["errors"].append(str(e))

        # Insert policy domains
        policy_coll = self.db["ashcai_policy_domains"]
        for pd in self.policy_domains:
            pd_doc = {
                **pd,
                "ontology": "ashcai",
                "created_at": timestamp,
                "updated_at": timestamp,
            }

            if self.dry_run:
                logger.info(
                    f"[DRY RUN] Would insert policy domain: {pd['domain_id']}"
                )
                self.stats["policy_domains_inserted"] += 1
            else:
                try:
                    await policy_coll.update_one(
                        {"domain_id": pd["domain_id"]},
                        {"$set": pd_doc},
                        upsert=True,
                    )
                    self.stats["policy_domains_inserted"] += 1
                    logger.debug(f"Upserted policy domain: {pd['domain_id']}")
                except Exception as e:
                    logger.warning(f"Failed to insert policy domain {pd['domain_id']}: {e}")
                    self.stats["errors"].append(str(e))

    async def _insert_relationships(self):
        """Insert policy→process 'specifies' relationships."""
        timestamp = datetime.now(UTC)
        rel_coll = self.db["ashcai_relationships"]

        for rel in self.relationships:
            rel_doc = {
                **rel,
                "created_at": timestamp,
                "updated_at": timestamp,
            }

            # Create a unique key for deduplication
            unique_key = {
                "source_id": rel["source_id"],
                "target_id": rel["target_id"],
                "relationship_type": rel["relationship_type"],
            }

            if self.dry_run:
                logger.info(
                    f"[DRY RUN] Would insert relationship: "
                    f"{rel['source_id']} --{rel['relationship_type']}--> {rel['target_id']}"
                )
                self.stats["relationships_inserted"] += 1
            else:
                try:
                    await rel_coll.update_one(
                        unique_key,
                        {"$set": rel_doc},
                        upsert=True,
                    )
                    self.stats["relationships_inserted"] += 1
                    logger.debug(
                        f"Upserted relationship: {rel['source_id']} -> {rel['target_id']}"
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to insert relationship {rel['source_id']} -> {rel['target_id']}: {e}"
                    )
                    self.stats["errors"].append(str(e))

    async def _insert_ontology_metadata(self):
        """Insert ontology version and metadata."""
        timestamp = datetime.now(UTC)

        # Get framework metadata from registry
        framework_meta = self.registry.get("frameworkMetadata", {})

        metadata = {
            "version": "1.0.0",
            "ontology_name": "ASHCAI",
            "full_name": "AshMatics Clinical AI Governance Ontology",
            "description": "Ontology for Clinical AI Governance Framework concepts",
            "namespace_uri": "http://asherinformatics.com/ontology/ashcai/",
            "framework_version": framework_meta.get("version", "unknown"),
            "registry_version": framework_meta.get("registryVersion", "unknown"),
            "created_at": timestamp,
            "updated_at": timestamp,
            "collections": list(ASHCAI_COLLECTIONS.keys()),
            "process_domains_count": len(self.process_domains),
            "policy_domains_count": len(self.policy_domains),
            "relationships_count": len(self.relationships),
        }

        if self.dry_run:
            logger.info("[DRY RUN] Would insert ontology metadata")
        else:
            try:
                meta_coll = self.db["ashcai_ontology_metadata"]
                await meta_coll.update_one(
                    {"version": metadata["version"]},
                    {"$set": metadata},
                    upsert=True,
                )
                logger.info("Inserted ontology metadata")
            except Exception as e:
                logger.warning(f"Failed to insert metadata: {e}")
                self.stats["errors"].append(str(e))


# ============================================================================
# CLI Functions
# ============================================================================


def display_results(stats: dict[str, Any], dry_run: bool):
    """Display initialization results in a rich table."""
    table = Table(title="ASHCAI Ontology Initialization Results")

    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    prefix = "[DRY RUN] " if dry_run else ""

    table.add_row(
        f"{prefix}Collections Created", str(stats["collections_created"])
    )
    table.add_row(f"{prefix}Indexes Created", str(stats["indexes_created"]))
    table.add_row(
        f"{prefix}Process Domains", str(stats["process_domains_inserted"])
    )
    table.add_row(
        f"{prefix}Policy Domains", str(stats["policy_domains_inserted"])
    )
    table.add_row(
        f"{prefix}Relationships", str(stats.get("relationships_inserted", 0))
    )

    if stats["errors"]:
        table.add_row("Errors", str(len(stats["errors"])))

    console.print(table)

    if stats["errors"]:
        console.print("\n[bold red]Errors:[/bold red]")
        for error in stats["errors"]:
            console.print(f"  - {error}")


def find_repo_root(start_path: Path, marker: str = "pyproject.toml") -> Path | None:
    """
    Find the repository root by searching upward for a marker file.

    Args:
        start_path: Path to start searching from.
        marker: Filename that indicates the repo root (default: pyproject.toml).

    Returns:
        Path to the repo root, or None if not found.
    """
    current = start_path.resolve()
    for parent in [current, *current.parents]:
        if (parent / marker).exists():
            return parent
    return None


async def run_initialization(args: argparse.Namespace) -> int:
    """Run the ontology initialization."""
    # Load environment from repo root
    repo_root = find_repo_root(Path(__file__))
    if repo_root:
        env_file = repo_root / "ashmatics-tools.env"
        if env_file.exists():
            load_dotenv(env_file)
        else:
            load_dotenv()  # Fall back to default .env search
    else:
        load_dotenv()

    # Find and load the framework registry
    if args.registry_file:
        registry_path = Path(args.registry_file)
    else:
        registry_path = find_registry_file()

    if not registry_path or not registry_path.exists():
        console.print(
            "[bold red]Error: Framework registry file not found.[/bold red]"
        )
        console.print(
            "Please specify --registry-file or ensure ashmatics-framework-registry.json "
            "is in a discoverable location."
        )
        console.print("\nSearched locations:")
        for path in REGISTRY_SEARCH_PATHS:
            console.print(f"  - {path}")
        return 1

    console.print(f"[bold]ASHCAI Ontology Initializer[/bold]")
    console.print(f"Registry: {registry_path}")

    # Load the registry
    try:
        registry = load_framework_registry(registry_path)
        framework_meta = registry.get("frameworkMetadata", {})
        console.print(
            f"Framework: {framework_meta.get('name', 'Unknown')} "
            f"v{framework_meta.get('version', '?')}"
        )
    except Exception as e:
        console.print(f"[bold red]Failed to load registry: {e}[/bold red]")
        return 1

    # Get MongoDB connection details
    AZ_MONGO_CONNECTION_STRING = args.mongodb_uri or os.getenv(
        "AZ_MONGO_CONNECTION_STRING", "mongodb://localhost:27017"
    )
    database_name = args.database or os.getenv("MONGODB_DATABASE", "ashmatics_kb")

    console.print(f"Database: {database_name}")
    if args.dry_run:
        console.print("[yellow]DRY RUN MODE - No changes will be made[/yellow]")
    if args.force:
        console.print("[red]FORCE MODE - Existing collections will be dropped[/red]")
    console.print()

    # Show what will be loaded
    process_domains = extract_process_domains(registry)
    policy_domains = extract_policy_domains(registry)
    relationships = extract_policy_to_process_relationships(registry)

    console.print(f"Will load: {len(process_domains)} process domains, "
                  f"{len(policy_domains)} policy domains, "
                  f"{len(relationships)} relationships")
    console.print()

    # Run initialization
    initializer = AshcaiOntologyInitializer(
        AZ_MONGO_CONNECTION_STRING=AZ_MONGO_CONNECTION_STRING,
        database_name=database_name,
        registry=registry,
        dry_run=args.dry_run,
        force=args.force,
    )

    try:
        stats = await initializer.initialize()
        display_results(stats, args.dry_run)

        if stats["errors"]:
            return 1
        return 0

    except Exception as e:
        console.print(f"[bold red]Initialization failed: {e}[/bold red]")
        logger.exception("Initialization error")
        return 1


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Initialize ASHCAI ontology in MongoDB from framework registry",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Initialize with auto-discovered registry file
    cai-init-ontology

    # Initialize with explicit registry file
    cai-init-ontology --registry-file /path/to/ashmatics-framework-registry.json

    # Dry run to preview what would be created
    cai-init-ontology --dry-run

    # Force re-initialization (updates existing data)
    cai-init-ontology --force

    # Use custom MongoDB connection
    cai-init-ontology --mongodb-uri "mongodb://localhost:27017" --database "ashmatics_dev"

The registry file is auto-discovered from:
    - Sibling ashmatics-policy-process-builder repo
    - ~/GitHub/AsherInformatics/ashmatics-policy-process-builder/
    - /app/config/ (for Docker deployments)
        """,
    )

    parser.add_argument(
        "--registry-file",
        help="Path to ashmatics-framework-registry.json (auto-discovered if not specified)",
    )
    parser.add_argument(
        "--mongodb-uri",
        help="MongoDB connection URI (default: from AZ_MONGO_CONNECTION_STRING env var)",
    )
    parser.add_argument(
        "--database",
        help="MongoDB database name (default: from MONGODB_DATABASE env var)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview what would be done without making changes",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Drop existing collections before creating",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    sys.exit(asyncio.run(run_initialization(args)))


if __name__ == "__main__":
    main()
