#!/usr/bin/env python3
"""
AI Governance Framework Query Tool - CLI

Command-line interface and REPL for the AI Governance Query Service.
This is a thin wrapper around AIGovQueryService, adding CLI-specific
functionality (argparse, rich display, interactive REPL).

Created: 2025-12-23 JFK
Updated: 2026-01-25 JFK - Refactored to use AIGovQueryService SDK
Updated: 2026-01-25 JFK - Added constants module, fixed hierarchy display

For programmatic use, import the service directly:
    from ashmatics_aigov_tools.services import AIGovQueryService

Usage:
    # Interactive mode (MCP backend, default)
    uv run cai-query

    # Single query
    uv run cai-query --query "What is performance validation?"

    # Direct database mode (bypass MCP)
    uv run cai-query --direct --query "What SOPs for monitoring?"

    # Use Ollama instead of Azure OpenAI
    uv run cai-query --ollama --model llama3.2

    # Graph traversal commands in REPL
    uv run cai-query
    > hierarchy RMP-001
    > hierarchy risk management
    > controls EXC-A4-01
    > crosswalk NIST-AI-RMF
    > crosswalk nist

Copyright (c) 2025-2026 Asher Informatics PBC. All Rights Reserved.
"""

import argparse
import asyncio
import os
import sys
import warnings
from typing import Any

# Suppress CosmosDB compatibility warnings
warnings.filterwarnings("ignore", message=".*CosmosDB.*")

from dotenv import load_dotenv
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table
from rich.tree import Tree

# Import the SDK service
from ashmatics_aigov_tools.services import (
    AIGovQueryConfig,
    AIGovQueryService,
    QueryResult,
    RetrievalResult,
    SearchResult,
)
from ashmatics_aigov_tools.services.constants import (
    resolve_mcp_category,
    resolve_policy_domain,
    resolve_regulatory_framework,
    get_all_policy_domains,
    get_all_regulatory_frameworks,
    VALID_MCP_CATEGORIES,
)
from ashmatics_aigov_tools.services.mcp_client import PolicyHierarchy, RegulatoryMapping

console = Console()


# =============================================================================
# Display Helpers
# =============================================================================


def display_sources(sources: list[SearchResult], title: str = "Retrieved Sources") -> None:
    """Display search results in a formatted table."""
    if not sources:
        console.print("[dim]No sources found.[/dim]")
        return

    table = Table(title=title, show_lines=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Score", style="cyan", width=10)
    table.add_column("Artifact", style="green", width=35)
    table.add_column("Content Preview", style="white", max_width=55)

    for i, source in enumerate(sources, 1):
        # Build source identifier
        source_id = source.document_id[:35] if source.document_id else f"Source {i}"

        # Format score - show [EXPLICIT] for 1.0
        if source.score >= 0.9999:
            score_display = "[EXPLICIT]"
        else:
            score_display = f"{source.score:.4f}"

        # Truncate content for preview
        content = source.content[:180].replace("\n", " ")
        if len(source.content) > 180:
            content += "..."

        table.add_row(str(i), score_display, source_id, content)

    console.print(table)
    console.print()


def display_retrieval_result(result: RetrievalResult) -> None:
    """Display retrieval result with intent and workflow info."""
    # Show intent classification if available (MCP mode)
    if result.intent_category:
        console.print(
            Panel(
                f"Intent: [cyan]{result.intent_category}[/cyan]\n"
                f"Complexity: {result.complexity or 'unknown'}",
                title="Query Analysis",
            )
        )

    # Show search results
    display_sources(result.results)

    # Show suggested workflow if available
    if result.workflow:
        console.print("\n[bold]Suggested Workflow:[/bold]")
        for step in result.workflow:
            console.print(f"  - {step}")
        console.print()


def display_query_result(result: QueryResult) -> None:
    """Display a full RAG query result."""
    # Display answer
    console.print()
    console.print(
        Panel(
            Markdown(result.answer),
            title="[bold green]Answer[/bold green]",
            border_style="green",
        )
    )

    # Display metrics
    if result.metrics:
        console.print(
            f"[dim]Sources: {result.metrics.num_sources} | "
            f"Tokens: {result.metrics.total_tokens} | "
            f"Cost: ${result.metrics.estimated_cost:.4f} | "
            f"Latency: {result.metrics.latency_ms:.0f}ms[/dim]"
        )


def display_hierarchy(hierarchy: PolicyHierarchy) -> None:
    """Display policy hierarchy as a rich tree."""
    tree = Tree(f"[bold blue]{hierarchy.policy_label}[/bold blue] ({hierarchy.policy_id})")

    # Show summary stats
    stats = (
        f"[dim]Base Practices: {hierarchy.total_base_practices} | "
        f"SOPs: {hierarchy.total_sops} | "
        f"Work Products: {hierarchy.total_work_products}[/dim]"
    )
    tree.add(stats)

    # Add process domains
    for pd in hierarchy.process_domains:
        pd_label = pd.get("label", pd.get("entity_id", "Unknown"))
        pd_code = pd.get("entity_id", "")
        pd_branch = tree.add(f"[cyan]{pd_label}[/cyan] ({pd_code})")

        # Add base practices under each process domain
        for bp in pd.get("children", []):
            if bp.get("entity_type") == "BasePractice":
                bp_label = bp.get("label", bp.get("entity_id", ""))
                bp_branch = pd_branch.add(f"[green]{bp_label}[/green]")

                # Add SOPs under each base practice
                for sop in bp.get("children", []):
                    if sop.get("entity_type") == "SOPTemplate":
                        sop_id = sop.get("entity_id", "")
                        sop_label = sop.get("label", sop_id)
                        sop_branch = bp_branch.add(f"[yellow]{sop_id}[/yellow]: {sop_label[:50]}")

                        # Add work products under each SOP
                        for wp in sop.get("children", []):
                            if wp.get("entity_type") == "WorkProductTemplate":
                                wp_id = wp.get("entity_id", "")
                                wp_label = wp.get("label", wp_id)
                                sop_branch.add(f"[magenta]{wp_id}[/magenta]: {wp_label[:40]}")

    console.print(tree)
    console.print()

    # Also show flat lists for easy reference
    work_products = hierarchy.get_work_products()
    if work_products:
        console.print(f"\n[bold]Work Products ({len(work_products)}):[/bold]")
        for wp in work_products[:10]:
            console.print(f"  - [magenta]{wp.get('entity_id')}[/magenta]: {wp.get('label', '')[:60]}")
        if len(work_products) > 10:
            console.print(f"  [dim]... and {len(work_products) - 10} more[/dim]")


def display_hierarchy_dict(hierarchy: dict[str, Any]) -> None:
    """Display policy hierarchy as a tree (dict version for backward compat)."""
    tree = Tree(f"[bold]{hierarchy.get('title', hierarchy.get('policy_id', 'Policy'))}[/bold]")

    # Add parent if exists
    if hierarchy.get("parent"):
        parent = hierarchy["parent"]
        tree.add(f"[dim]Parent:[/dim] {parent.get('title', parent.get('id', 'Unknown'))}")

    # Add children
    children = hierarchy.get("children", [])
    if children:
        children_branch = tree.add("[cyan]Children[/cyan]")
        for child in children:
            children_branch.add(child.get("title", child.get("id", "Unknown")))

    # Add related processes
    processes = hierarchy.get("related_processes", [])
    if processes:
        proc_branch = tree.add("[green]Related Processes[/green]")
        for proc in processes:
            proc_branch.add(proc.get("title", proc.get("id", "Unknown")))

    console.print(tree)
    console.print()


def display_control_implementations(result: dict[str, Any]) -> None:
    """Display control implementation details."""
    console.print(
        Panel(
            f"[bold]{result.get('control_title', result.get('control_id'))}[/bold]",
            title="Control",
        )
    )

    # Implementing SOPs
    sops = result.get("implementing_sops", [])
    if sops:
        console.print("\n[bold cyan]Implementing SOPs:[/bold cyan]")
        for sop in sops:
            console.print(f"  - {sop.get('id', 'Unknown')}: {sop.get('title', '')}")

    # Related work products
    wps = result.get("related_work_products", [])
    if wps:
        console.print("\n[bold green]Related Work Products:[/bold green]")
        for wp in wps:
            console.print(f"  - {wp.get('id', 'Unknown')}: {wp.get('title', '')}")

    console.print()


def display_crosswalk(result: RegulatoryMapping) -> None:
    """Display regulatory crosswalk."""
    console.print(
        Panel(
            f"[bold]{result.framework_name or result.framework_id}[/bold]\n"
            f"[dim]Total Requirements: {result.total_requirements}[/dim]",
            title="Regulatory Framework",
        )
    )

    mappings = result.mappings
    if mappings:
        table = Table(title=f"Crosswalk Entries ({len(mappings)} requirements)")
        table.add_column("Requirement", style="cyan", width=30)
        table.add_column("Policies", style="green", width=20)
        table.add_column("Controls", style="yellow", width=25)

        for mapping in mappings[:15]:  # Limit to 15 rows
            req_id = mapping.get("requirement_id", "")
            req_title = mapping.get("requirement_title", "")
            policies = ", ".join(mapping.get("mapped_policies", [])[:4])
            controls = ", ".join(mapping.get("mapped_controls", [])[:4])

            req_display = f"{req_id}"
            if req_title:
                title_short = req_title[:35] + "..." if len(req_title) > 35 else req_title
                req_display += f"\n[dim]{title_short}[/dim]"

            table.add_row(req_display, policies, controls)

        console.print(table)
        if len(mappings) > 15:
            console.print(f"[dim]... and {len(mappings) - 15} more requirements[/dim]")

    # Show summary
    console.print(f"\n[bold]Coverage Summary:[/bold]")
    console.print(f"  Unique Policies: {len(result.get_mapped_policies())}")
    console.print(f"  Unique Controls: {len(result.get_mapped_controls())}")
    console.print()


def display_crosswalk_dict(result: dict[str, Any]) -> None:
    """Display regulatory crosswalk (dict version for backward compat)."""
    console.print(
        Panel(
            f"[bold]{result.get('framework_name', result.get('framework_id'))}[/bold]",
            title="Regulatory Framework",
        )
    )

    mappings = result.get("mappings", [])
    if mappings:
        table = Table(title=f"Crosswalk Entries ({len(mappings)} requirements)")
        table.add_column("Requirement", style="cyan", width=25)
        table.add_column("Policies", style="green", width=20)
        table.add_column("Controls", style="yellow", width=25)

        for mapping in mappings[:15]:
            req_id = mapping.get("requirement_id", "")
            req_title = mapping.get("requirement_title", "")
            policies = ", ".join(mapping.get("mapped_policies", [])[:4])
            controls = ", ".join(mapping.get("mapped_controls", [])[:4])

            table.add_row(
                f"{req_id}\n[dim]{req_title[:30]}...[/dim]" if len(req_title) > 30 else f"{req_id}\n[dim]{req_title}[/dim]",
                policies,
                controls,
            )

        console.print(table)
        if len(mappings) > 15:
            console.print(f"[dim]... and {len(mappings) - 15} more requirements[/dim]")

    console.print()


# =============================================================================
# REPL
# =============================================================================


async def interactive_repl(service: AIGovQueryService) -> None:
    """Run an interactive REPL for querying the AI Governance Framework."""
    mode = "MCP" if service.config.use_mcp else "Direct"
    provider = "Ollama" if service.config.llm_provider == "ollama" else "Azure OpenAI"
    model = service.config.llm_model or "default"

    console.print(
        Panel.fit(
            "[bold blue]AI Governance Framework Query Tool[/bold blue]\n\n"
            f"Mode: [cyan]{mode}[/cyan]\n"
            f"LLM: [cyan]{provider}[/cyan] ({model})\n\n"
            "Ask questions about the Clinical AI Governance Framework.\n"
            "Type [bold]quit[/bold] or [bold]exit[/bold] to stop.\n"
            "Type [bold]help[/bold] for more commands.",
            title="CAI Governance Query",
        )
    )
    console.print()

    # Check health
    console.print("[dim]Checking connections...[/dim]")

    async with service:
        health = await service.health_check()

        if not health.get("backend_healthy"):
            error = health.get("backend_details", {}).get("error", "Unknown")
            console.print(f"[red]Backend connection failed: {error}[/red]")
            return

        backend_type = health.get("backend_type", "unknown")
        console.print(f"[green]✓[/green] Backend connected ({backend_type})")

        if not health.get("llm_available"):
            provider = health.get("llm_details", {}).get("provider", "unknown")
            console.print(f"[yellow]! {provider} LLM not available[/yellow]")
            console.print("[dim]  Search will work, but no LLM synthesis.[/dim]")
        else:
            provider = health.get("llm_details", {}).get("provider", "unknown")
            model = health.get("llm_details", {}).get("model", "unknown")
            console.print(f"[green]✓[/green] LLM ready ({provider}: {model})")

        console.print()

        # REPL loop
        while True:
            try:
                query = Prompt.ask("\n[bold cyan]Question[/bold cyan]")

                if not query.strip():
                    continue

                query_lower = query.lower().strip()

                # Exit commands
                if query_lower in ("quit", "exit", "q"):
                    console.print("[dim]Goodbye![/dim]")
                    break

                # Help command
                if query_lower == "help":
                    _show_help()
                    continue

                # Stats command
                if query_lower == "stats":
                    health = await service.health_check()
                    details = health.get("backend_details", {})
                    console.print(f"Backend: [cyan]{health.get('backend_type')}[/cyan]")
                    console.print(f"Backend healthy: [cyan]{health.get('backend_healthy')}[/cyan]")
                    if "vector_count" in details:
                        console.print(f"Vectors: [cyan]{details['vector_count']:,}[/cyan]")
                    if "message" in details:
                        console.print(f"Server: [dim]{details['message']}[/dim]")
                    llm = health.get("llm_details", {})
                    if llm:
                        console.print(f"LLM: [cyan]{llm.get('provider', 'unknown')}[/cyan] ({llm.get('model', 'default')})")
                    continue

                # Domains command - list all policy domains
                if query_lower == "domains":
                    console.print("\n[bold]Policy Domains:[/bold]")
                    for domain in get_all_policy_domains():
                        console.print(f"  [cyan]{domain['code']}[/cyan] ({domain['id']}): {domain['name']}")
                    continue

                # Frameworks command - list all regulatory frameworks
                if query_lower == "frameworks":
                    console.print("\n[bold]Regulatory Frameworks:[/bold]")
                    for fw in get_all_regulatory_frameworks():
                        console.print(f"  [cyan]{fw['id']}[/cyan]: {fw['name']}")
                    continue

                # Top K command
                if query_lower.startswith("top "):
                    try:
                        new_k = int(query_lower.split()[1])
                        service.config.top_k = new_k
                        console.print(f"Now retrieving top [cyan]{new_k}[/cyan] sources")
                    except ValueError:
                        console.print("[red]Invalid number. Usage: top 5[/red]")
                    continue

                # Search-only command
                if query_lower.startswith("search "):
                    search_query = query[7:].strip()
                    console.print("[dim]Searching...[/dim]")
                    result = await service.search(search_query)
                    display_retrieval_result(result)
                    continue

                # Smart query command (ASHKBAPP-68)
                if query_lower.startswith("smart "):
                    smart_query = query[6:].strip()
                    console.print("[dim]Smart query with intelligent routing...[/dim]")
                    try:
                        result = await service.smart_query(smart_query)
                        # Show the routing decision
                        plan_info = result.metadata.get("plan", {})
                        console.print(
                            Panel(
                                f"Intent: [cyan]{plan_info.get('intent', 'unknown')}[/cyan]\n"
                                f"Strategy: [yellow]{plan_info.get('strategy', 'unknown')}[/yellow]\n"
                                f"Confidence: {plan_info.get('confidence', 0):.2f}",
                                title="Query Routing",
                            )
                        )
                        display_sources(result.sources)
                        display_query_result(result)
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                    continue

                # Plan command - show routing without executing
                if query_lower.startswith("plan "):
                    plan_query = query[5:].strip()
                    console.print("[dim]Analyzing query...[/dim]")
                    try:
                        plan = service.preprocess_query(plan_query)
                        console.print(
                            Panel(
                                f"[bold]Intent:[/bold] [cyan]{plan.get('intent')}[/cyan]\n"
                                f"[bold]Strategy:[/bold] [yellow]{plan.get('strategy')}[/yellow]\n"
                                f"[bold]Confidence:[/bold] {plan.get('confidence', 0):.2f}\n"
                                f"[bold]Graph Traversal:[/bold] {plan.get('graph_traversal') or 'N/A'}\n"
                                f"[bold]Target Artifacts:[/bold] {', '.join(plan.get('target_artifacts', [])) or 'N/A'}\n"
                                f"[bold]Search Query:[/bold] {plan.get('search_query') or 'N/A'}\n\n"
                                f"[bold]Entities Found:[/bold]\n"
                                f"  Policy Domains: {plan.get('entities', {}).get('policy_domains', [])}\n"
                                f"  Process Domains: {plan.get('entities', {}).get('process_domains', [])}\n"
                                f"  Artifact IDs: {plan.get('entities', {}).get('artifact_ids', [])}\n"
                                f"  Frameworks: {plan.get('entities', {}).get('regulatory_frameworks', [])}\n"
                                f"  Control IDs: {plan.get('entities', {}).get('control_ids', [])}\n\n"
                                f"[bold]Classification Signals:[/bold]\n"
                                + "\n".join(f"  - {s}" for s in plan.get('classification_signals', [])[:5]),
                                title="Query Plan (not executed)",
                            )
                        )
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                    continue

                # Toggle smart routing as default
                if query_lower == "smarton":
                    service.config.use_smart_routing = True
                    console.print("[green]Smart routing enabled as default[/green]")
                    continue

                if query_lower == "smartoff":
                    service.config.use_smart_routing = False
                    console.print("[yellow]Smart routing disabled (using legacy query)[/yellow]")
                    continue

                # List commands (MCP mode)
                if query_lower.startswith("list "):
                    category_input = query_lower.split(maxsplit=1)[1].strip()

                    # Use constants module to resolve category
                    category = resolve_mcp_category(category_input)
                    if category is None:
                        console.print(f"[red]Unknown category: {category_input}[/red]")
                        console.print(f"[dim]Valid categories: {', '.join(VALID_MCP_CATEGORIES)}[/dim]")
                        continue

                    try:
                        if not service.config.use_mcp:
                            console.print("[yellow]List commands require MCP mode.[/yellow]")
                            continue
                        from ashmatics_aigov_tools.services.backends import MCPBackend
                        if isinstance(service._backend, MCPBackend):
                            items = await service._backend.client.get_category_content(category)
                            console.print(f"\n[bold]{category}[/bold] ({len(items)} items):")
                            for item in items[:20]:
                                aid = item.get("artifact_id", item.get("id", "?"))
                                title = item.get("title", item.get("name", ""))
                                console.print(f"  - [cyan]{aid}[/cyan]: {title}")
                            if len(items) > 20:
                                console.print(f"  [dim]... and {len(items) - 20} more[/dim]")
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                    continue

                # Graph traversal: hierarchy
                if query_lower.startswith("hierarchy "):
                    policy_input = query[10:].strip()

                    # Try to resolve natural language to policy ID
                    policy_id = resolve_policy_domain(policy_input)
                    if policy_id is None:
                        # Maybe they gave us a raw ID
                        policy_id = policy_input.upper()
                        if not policy_id.endswith("-001"):
                            policy_id = f"{policy_id}-001"

                    console.print(f"[dim]Fetching hierarchy for {policy_id}...[/dim]")

                    try:
                        result = await service.get_policy_hierarchy(policy_id)
                        display_hierarchy(result)
                    except NotImplementedError as e:
                        console.print(f"[yellow]{e}[/yellow]")
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                        console.print("[dim]Hint: Try 'domains' to see valid policy domain codes[/dim]")
                    continue

                # Graph traversal: controls
                if query_lower.startswith("controls "):
                    control_id = query_lower.split(maxsplit=1)[1].upper()
                    try:
                        result = await service.find_control_implementations(control_id)
                        display_control_implementations(result)
                    except NotImplementedError as e:
                        console.print(f"[yellow]{e}[/yellow]")
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                    continue

                # Graph traversal: crosswalk
                if query_lower.startswith("crosswalk "):
                    framework_input = query[10:].strip()

                    # Try to resolve natural language to framework ID
                    framework_id = resolve_regulatory_framework(framework_input)
                    if framework_id is None:
                        # Maybe they gave us a raw ID
                        framework_id = framework_input.upper()

                    console.print(f"[dim]Fetching crosswalk for {framework_id}...[/dim]")

                    try:
                        result = await service.get_regulatory_crosswalk(framework_id)
                        display_crosswalk(result)
                    except NotImplementedError as e:
                        console.print(f"[yellow]{e}[/yellow]")
                    except Exception as e:
                        console.print(f"[red]Error: {e}[/red]")
                        console.print("[dim]Hint: Try 'frameworks' to see valid framework IDs[/dim]")
                    continue

                # Default: RAG query
                console.print("[dim]Retrieving context and generating answer...[/dim]")
                result = await service.query(query)

                # Display sources
                display_sources(result.sources)

                # Display answer
                display_query_result(result)

            except KeyboardInterrupt:
                console.print("\n[dim]Interrupted. Type 'quit' to exit.[/dim]")
                continue
            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")
                continue


def _show_help() -> None:
    """Show REPL help."""
    console.print(
        Panel(
            "[bold]Commands:[/bold]\n"
            "  [cyan]quit, exit, q[/cyan] - Exit the REPL\n"
            "  [cyan]help[/cyan] - Show this help\n"
            "  [cyan]stats[/cyan] - Show backend statistics\n"
            "  [cyan]domains[/cyan] - List all policy domains\n"
            "  [cyan]frameworks[/cyan] - List all regulatory frameworks\n"
            "  [cyan]top N[/cyan] - Set number of sources to retrieve\n"
            "  [cyan]search <query>[/cyan] - Search without LLM synthesis\n"
            "\n[bold]Smart Query (ASHKBAPP-68):[/bold]\n"
            "  [cyan]smart <query>[/cyan] - Intelligent query routing\n"
            "  [cyan]plan <query>[/cyan] - Show what preprocessor understood\n"
            "  [cyan]smarton/smartoff[/cyan] - Toggle smart routing as default\n"
            "\n[bold]List Commands (MCP mode):[/bold]\n"
            "  [cyan]list policies[/cyan] - List policy domain content\n"
            "  [cyan]list processes[/cyan] - List process domain content\n"
            "\n[bold]Graph Traversals (MCP mode):[/bold]\n"
            "  [cyan]hierarchy RMP-001[/cyan] - Show Risk Management hierarchy\n"
            "  [cyan]hierarchy risk management[/cyan] - Same, using natural language\n"
            "  [cyan]controls EXC-A4-01[/cyan] - Find SOPs implementing a control\n"
            "  [cyan]crosswalk NIST-AI-RMF[/cyan] - Show NIST AI RMF mapping\n"
            "  [cyan]crosswalk nist[/cyan] - Same, using alias\n"
            "\n[bold]Example questions:[/bold]\n"
            "  - What is the purpose of the PV (Performance Validation) process?\n"
            "  - How should organizations handle AI model monitoring?\n"
            "  - What are the key controls for clinical AI governance?\n"
            "  - Explain the Safety Assurance process domain.\n"
            "\n[bold]Smart Query examples:[/bold]\n"
            "  - smart What is Risk Management?  (fetches POL-RMP-Overview)\n"
            "  - smart What SOPs implement EXC-A4-01?  (graph traversal)\n"
            "  - plan How do we comply with NIST?  (shows routing plan)",
            title="Help",
        )
    )


# =============================================================================
# Single Query Mode
# =============================================================================


async def single_query(service: AIGovQueryService, question: str, stream: bool = False) -> None:
    """Execute a single query and display results."""
    async with service:
        if stream:
            console.print("[dim]Retrieving context and streaming answer...[/dim]")
            async for chunk in service.stream_query(question):
                if chunk.text:
                    console.print(chunk.text, end="")

                if chunk.is_final:
                    console.print()  # Newline after streaming
                    if chunk.sources:
                        console.print()
                        display_sources(chunk.sources)
                    if chunk.metrics:
                        console.print(
                            f"[dim]Sources: {chunk.metrics.num_sources} | "
                            f"Tokens: {chunk.metrics.total_tokens} | "
                            f"Latency: {chunk.metrics.latency_ms:.0f}ms[/dim]"
                        )
        else:
            console.print("[dim]Retrieving context and generating answer...[/dim]")
            result = await service.query(question)
            display_sources(result.sources)
            display_query_result(result)


# =============================================================================
# Main Entry Point
# =============================================================================


def main():
    """Main CLI entry point."""
    # Load environment variables early
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(current_dir, "../../.."))

    for env_name in ["ashmatics-tools.env", "ai-strat-src.env", ".env"]:
        env_path = os.path.join(project_root, env_name)
        if os.path.exists(env_path):
            load_dotenv(env_path)
            break

    parser = argparse.ArgumentParser(
        description="AI Governance Framework Query Tool - RAG-powered Q&A",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Interactive mode with MCP backend (default)
  cai-query

  # Single query
  cai-query --query "What is performance validation?"

  # Direct database mode (bypass MCP)
  cai-query --direct --query "What SOPs for monitoring?"

  # Use Ollama instead of Azure OpenAI
  cai-query --ollama --model llama3.2

  # Stream the response
  cai-query --stream --query "What are the key governance controls?"

Environment Variables:
  MCP_URL - KB MCP server URL (default: http://localhost:8088)
  MCP_API_KEY - MCP API key
  MONGO_URL - MongoDB/CosmosDB connection string (for direct mode)
  AZURE_OPENAI_API_KEY - Azure OpenAI API key
  AZURE_OPENAI_ENDPOINT - Azure OpenAI endpoint
  AZURE_OPENAI_CHAT_DEPLOYMENT_NAME - Chat model deployment
        """,
    )

    # Backend mode
    backend_group = parser.add_argument_group("Backend Mode")
    backend_group.add_argument(
        "--mcp",
        action="store_true",
        default=True,
        help="Use KB MCP server for retrieval (default)",
    )
    backend_group.add_argument(
        "--direct",
        action="store_true",
        help="Use direct CosmosDB access (bypass MCP)",
    )
    backend_group.add_argument(
        "--mcp-url",
        type=str,
        default=None,
        help="MCP server URL (default: MCP_URL env or localhost:8088)",
    )
    backend_group.add_argument(
        "--mcp-key",
        type=str,
        default=None,
        help="MCP API key (default: MCP_API_KEY env)",
    )

    # LLM provider options
    provider_group = parser.add_argument_group("LLM Provider")
    provider_group.add_argument(
        "--ollama",
        action="store_true",
        help="Use Ollama instead of Azure OpenAI for LLM",
    )
    provider_group.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model/deployment name (default: gpt-4o for Azure, llama3.2 for Ollama)",
    )
    provider_group.add_argument(
        "--ollama-endpoint",
        type=str,
        default="http://localhost:11434",
        help="Ollama server URL (default: http://localhost:11434)",
    )

    # RAG options
    rag_group = parser.add_argument_group("RAG Options")
    rag_group.add_argument(
        "--top-k",
        type=int,
        default=5,
        help="Number of sources to retrieve (default: 5)",
    )
    rag_group.add_argument(
        "--multi-query",
        action="store_true",
        help="Use multi-query RAG for better retrieval coverage",
    )
    rag_group.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="LLM temperature (default: 0.7)",
    )

    # Query options
    query_group = parser.add_argument_group("Query Options")
    query_group.add_argument(
        "--query",
        "-q",
        type=str,
        default=None,
        help="Single query to execute (if not provided, starts interactive mode)",
    )
    query_group.add_argument(
        "--stream",
        action="store_true",
        help="Stream the response (only for single query mode)",
    )
    query_group.add_argument(
        "--no-context",
        action="store_true",
        help="Don't display retrieved source documents",
    )

    args = parser.parse_args()

    # Determine LLM model
    if args.model:
        model = args.model
    elif args.ollama:
        model = os.getenv("OLLAMA_MODEL", "llama3.2")
    else:
        model = (
            os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
            or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4o")
        )

    # Create configuration
    config = AIGovQueryConfig(
        # Backend
        use_mcp=not args.direct,
        mcp_url=args.mcp_url or os.getenv("MCP_URL", "http://localhost:8088"),
        mcp_api_key=args.mcp_key or os.getenv("MCP_API_KEY"),
        # LLM
        llm_provider="ollama" if args.ollama else "azure_openai",
        llm_model=model,
        ollama_endpoint=args.ollama_endpoint,
        # RAG
        top_k=args.top_k,
        temperature=args.temperature,
        use_multi_query=args.multi_query,
    )

    # Create service
    try:
        service = AIGovQueryService(config)
    except ValueError as e:
        console.print(f"[red]Configuration error: {e}[/red]")
        sys.exit(1)

    # Run query or interactive mode
    async def run():
        try:
            if args.query:
                await single_query(service, args.query, stream=args.stream)
            else:
                await interactive_repl(service)
        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted.[/dim]")

    asyncio.run(run())


if __name__ == "__main__":
    main()
