#!/usr/bin/env python3
"""
Content Patterns Configuration

Centralized definition of content patterns for AshMatics Clinical AI Governance Framework.
This file defines the default file patterns used by both the framework content importer
and Azure uploader to ensure consistency across the codebase.

Created: Sep 25 2025 by JF Kalafut
"""

# Files and patterns to exclude from framework content processing
# These are system files, IDE files, and other non-framework content
EXCLUDED_FILES = {
    # System and IDE files
    "CLAUDE.md",
    ".claude",      # Claude Code configuration directory/file
    "WARP.md",
    ".vscode/",
    ".git/",
    "__pycache__/",
    "*.pyc",
    
    # Workspace and project files
    "*.code-workspace",
    "*.workspace", 
    ".env*",
    "*.LOCAL",
    
    # Build artifacts and temporary files
    "*.log",
    ".DS_Store",
    "Thumbs.db",
    
    # Docker and deployment files (if not part of framework)
    "docker-compose*.yml",
    "Dockerfile*",
    "*.sh",  # Shell scripts unless specifically needed
    
    # Database and cache files
    "__azurite_db_table__.json",
    "AzuriteConfig",
    "uv.lock",
    
    # Test and debug files
    "test_*",
    "debug_*",
    "*_test.py",
    "*_debug.py",
}

# Default content patterns for CAI framework content processing
# These patterns define which files should be included when processing
# or uploading framework content to various destinations (Azure, databases, etc.)
DEFAULT_CONTENT_PATTERNS = [
    # Domain definitions
    "domains/*.json",

    # Policy logic files
    "policy-logic/*.json",

    # Process model documentation
    "ash-gov-process-model/**/*.md",
    "ash-gov-process-model/**/*.json",

    # Registry files
    "process-domain-registry.json",
    "master-registry.json",
    "ashmatics-framework-registry.json",  # Updated registry filename
    "clinical-ai-governance-stakeholder-roles.json",

    # Core framework directories
    "policy-domain/**/*",  # Policy domain content
    "process-domain/**/*",  # Process domain content
    "controls/**/*",  # Controls content
    "ISO-42001-maps/**/*",  # ISO 42001 mapping content
    "tools/**/*",  # Include ALL files in tools directory and subdirectories

    # Wizard content schemas - regulatory logic and wizard configurations
    "wizard-content-schemas/**/*.yaml",  # Wizard config YAML files
    "wizard-content-schemas/**/*.yml",   # Alternative YAML extension
    "wizard-content-schemas/**/*.md",    # Wizard documentation

    # Additional framework directories
    "reviews-audits/**/*",  # Review and audit content
    "supporting-framework-docs/**/*",  # Supporting documentation

    # Build and configuration files
    "Makefile",
    # Note: CLAUDE.md and other system files are excluded - see EXCLUDED_FILES

    # Root-level framework documentation files
    "Framework-Overview-Summary.md",
    "Implementation-Reference-Guide.md",
    "Policy-Domain-Architecture.md",
    "Process-Domain-Architecture.md",
    "value-proposition-polproc.md",
]

def should_exclude_file(file_path: str) -> bool:
    """
    Check if a file should be excluded from framework processing.
    
    Args:
        file_path: Path to the file (relative or absolute)
        
    Returns:
        True if file should be excluded, False otherwise
    """
    import fnmatch
    from pathlib import Path
    
    file_name = Path(file_path).name
    file_path_str = str(file_path)
    
    for exclude_pattern in EXCLUDED_FILES:
        # Direct filename match
        if file_name == exclude_pattern:
            return True
            
        # Pattern match (for wildcards like *.pyc)
        if fnmatch.fnmatch(file_name, exclude_pattern):
            return True
            
        # Path contains pattern (for directories like .vscode/)
        if exclude_pattern in file_path_str:
            return True
            
    return False

def filter_file_list(file_paths: list) -> list:
    """
    Filter a list of file paths to remove excluded files.
    
    Args:
        file_paths: List of file paths to filter
        
    Returns:
        Filtered list with excluded files removed
    """
    return [f for f in file_paths if not should_exclude_file(str(f))]

def get_default_content_patterns() -> list[str]:
    """
    Get the default content patterns for CAI framework processing.
    
    Returns:
        List of glob patterns for framework content files
    """
    return DEFAULT_CONTENT_PATTERNS.copy()

def get_minimal_content_patterns() -> list[str]:
    """
    Get a minimal set of content patterns for basic framework functionality.
    Useful for testing or when only core files are needed.
    
    Returns:
        List of essential glob patterns
    """
    return [
        "domains/*.json",
        "process-domain-registry.json",
        "policy-domain/**/*",
        "process-domain/**/*",
        "controls/**/*",
        "Framework-Overview-Summary.md",
    ]

def get_documentation_patterns() -> list[str]:
    """
    Get patterns that match only documentation files.
    
    Returns:
        List of patterns for documentation files
    """
    return [
        "ash-gov-process-model/**/*.md",
        "policy-domain/**/*.md",
        "process-domain/**/*.md",
        "supporting-framework-docs/**/*.md",
        "Framework-Overview-Summary.md",
        "Implementation-Reference-Guide.md",
        "Policy-Domain-Architecture.md",
        "Process-Domain-Architecture.md",
        "value-proposition-polproc.md",
        "CLAUDE.md",
    ]

def get_configuration_patterns() -> list[str]:
    """
    Get patterns that match only configuration and registry files.
    
    Returns:
        List of patterns for configuration files
    """
    return [
        "domains/*.json",
        "policy-logic/*.json",
        "process-domain-registry.json",
        "master-registry.json",
        "clinical-ai-governance-stakeholder-roles.json",
        "ash-gov-process-model/**/*.json",
        "policy-domain/**/*.json",
        "process-domain/**/*.json",
        "controls/**/*.json",
        "ISO-42001-maps/**/*.json",
        "tools/**/*.json",
        "tools/**/*.yaml",
        "tools/**/*.yml",
    ]