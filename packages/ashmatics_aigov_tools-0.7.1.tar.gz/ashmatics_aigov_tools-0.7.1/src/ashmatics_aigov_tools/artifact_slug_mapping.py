"""
Artifact Slug Mapping for CAI Governance Framework

This module defines the canonical human-friendly artifact_id naming scheme
for all governance framework content. These slugs are used for API lookups
and provide a consistent, developer-friendly way to reference documents.

Naming Convention: PascalCase-Kebab
Pattern: {PREFIX}-{CODE}-{DescriptorPascalCase}

Version: 0.8.0
Created: 2025-12-19
Author: JF Kalafut / Claude Code
"""

import re
from pathlib import Path
from typing import Optional

# =============================================================================
# PREFIX DEFINITIONS
# =============================================================================

# Document type prefixes
PREFIXES = {
    # Framework-level
    "framework": "FW",

    # Policy domain
    "policy_overview": "POL",
    "policy_template": "POLT",
    "policy_tokens": "POLTOK",

    # Process domain
    "process_overview": "PROC",
    "process_domain_json": "PROCJ",
    "process_area": "AREA",

    # Work artifacts
    "sop": "SOP",
    "work_product": "WP",
    "wizard_design": "WIZ",
    "wizard_schema": "WIZS",

    # Governance artifacts
    "decision_log": "LOG",
    "traceability": "TRACE",
    "policy_binding": "BIND",

    # Controls and compliance
    "controls": "CTRL",
    "iso_mapping": "ISO",
}

# Policy domain codes (3-letter)
POLICY_DOMAIN_CODES = {
    "AGP": "AI Governance Policy",
    "CMP": "Change Management Policy",
    "DGP": "Data Governance Policy",
    "EFP": "Ethics & Fairness Policy",
    "HOP": "Human Oversight Policy",
    "LTP": "Lifecycle & Training Policy",
    "MMP": "Model Management Policy",
    "RMP": "Risk Management Policy",
    "SAP": "Security & Access Policy",
    "SEP": "Stakeholder Engagement Policy",
    "TPP": "Transparency Policy",
    "VAL": "Validation Policy",
}

# Process domain codes (2-3 letter)
PROCESS_DOMAIN_CODES = {
    "PV": "Problem & Value Quantification",
    "SA": "Solution Architecting & Local Validation",
    "MON": "Monitoring & Lifecycle Management",
    "OVR": "Oversight & Steering",
    "ORG": "Organization & Strategy Alignment",
    "IT": "IT Systems & Data Management",
    "RM": "Risk Management",
    "HO": "Human Oversight & AI Interaction",
    "EF": "AI Ethics & Fairness Assessment",
    "TR": "AI Transparency & Explainability",
    "UG": "AI Usage Governance & User Compliance",
}

# =============================================================================
# SLUG GENERATION RULES
# =============================================================================

# Mapping patterns: (regex pattern, slug generator function name)
SLUG_PATTERNS = [
    # =========================================================================
    # FRAMEWORK ROOT (FW-*)
    # =========================================================================
    (r"^Framework-Overview-Summary\.md$", "FW-Overview"),
    (r"^Implementation-Reference-Guide\.md$", "FW-ImplGuide"),
    (r"^Policy-Domain-Architecture\.md$", "FW-PolicyArch"),
    (r"^Process-Domain-Architecture\.md$", "FW-ProcessArch"),
    (r"^README\.md$", "FW-Readme"),

    # =========================================================================
    # POLICY DOMAIN (POL-*, POLT-*, POLTOK-*)
    # =========================================================================
    # Policy Overview Summaries: POL-{CODE}-Overview
    (r"^policy-domain/([A-Z]{3})-Domain-Overview-Summary\.md$",
     lambda m: f"POL-{m.group(1)}-Overview"),

    # Policy Templates: POLT-{CODE}-Template
    (r"^policy-domain/ash-([A-Z]{3})-policy-TEMP\.md$",
     lambda m: f"POLT-{m.group(1)}-Template"),

    # Policy Tokens: POLTOK-{CODE}
    (r"^policy-domain/([A-Z]{3})-policy-tokens\.json$",
     lambda m: f"POLTOK-{m.group(1)}"),

    # Policy domain misc files
    (r"^policy-domain/Risk-Based Implementation Strategy\.md$", "POL-RiskBasedStrategy"),
    (r"^policy-domain/Scope of Applicability-AshmaticsGovFramework\.md$", "POL-ScopeApplicability"),
    (r"^policy-domain/governanceTokenManifest\.yaml$", "POL-TokenManifest"),
    (r"^policy-domain/tokenMapByArtifact\.json$", "POL-TokenMap"),
    (r"^policy-domain/policy_domain-Wizard-Design\.json$", "WIZ-PolicyDomain"),

    # =========================================================================
    # PROCESS DOMAIN ROOT (PROC-*, PROCJ-*)
    # =========================================================================
    # Process Domain Overview Summaries: PROC-{CODE}-Overview
    (r"^process-domain/([A-Z]{2,3})-Domain-Overview-Summary\.md$",
     lambda m: f"PROC-{m.group(1)}-Overview"),

    # Process Domain JSON: PROCJ-{CODE}
    (r"^process-domain/([a-z]{2,3})-process-domain\.json$",
     lambda m: f"PROCJ-{m.group(1).upper()}"),

    # Process model overview
    (r"^process-domain/AshMatics-clin-ai-gov-model-Overview-Summary\.md$", "PROC-ModelOverview"),

    # =========================================================================
    # PROCESS MODEL ROOT FILES
    # =========================================================================
    # Reference artifacts at process model root
    (r"^ash-gov-process-model/ReferenceArtifact-[^/]+\.md$", "FW-ImplRoadmapTemplate"),
    (r"^ash-gov-process-model/wip_process_model_dictionary_ashmatics\.json$", "FW-ProcessDictionary"),

    # =========================================================================
    # PROCESS AREAS - SOPs (SOP-{DOMAIN}-{NUM})
    # =========================================================================
    # SOPs already follow the pattern: SOP-{DOMAIN}-{NUM}-Description.md
    (r"^ash-gov-process-model/[^/]+/SOP-([A-Z]{2,3})-(\d{2})-[^/]+\.md$",
     lambda m: f"SOP-{m.group(1)}-{m.group(2)}"),

    # =========================================================================
    # PROCESS AREAS - Work Products (WP-{DOMAIN}-{NUM}[-SUFFIX])
    # =========================================================================
    # Standard WPs: WP-{DOMAIN}-{NUM}-Description.md
    (r"^ash-gov-process-model/[^/]+/WP-([A-Z]{2,3})-(\d{2}[a-z]?)-[^/]+\.md$",
     lambda m: f"WP-{m.group(1)}-{m.group(2)}"),

    # Output WPs: WP-{DOMAIN}-OUT-{Descriptor}
    (r"^ash-gov-process-model/[^/]+/WP-([A-Z]{2,3})-Outputs?-([^/]+)\.md$",
     lambda m: f"WP-{m.group(1)}-OUT-{_to_pascal(m.group(2))}"),

    # Shared WPs
    (r"^ash-gov-process-model/WP-SHARED-([^/]+)\.md$",
     lambda m: f"WP-SHARED-{_to_pascal(m.group(1))}"),

    # =========================================================================
    # PROCESS AREAS - Area Documents (AREA-{DOMAIN}-*)
    # =========================================================================
    # Area overview: AREA-{DOMAIN}-Overview
    (r"^ash-gov-process-model/[^/]+/AshmaticsAIGov-Area\d+-([A-Z]{2,3})\.md$",
     lambda m: f"AREA-{m.group(1)}-Overview"),

    # =========================================================================
    # PROCESS AREAS - Governance Artifacts
    # =========================================================================
    # Wizard Designs: WIZ-{DOMAIN}-Design (handles both WizardDesign and Wizard-Design)
    (r"^ash-gov-process-model/[^/]+/([A-Z]{2,3})-WizardDesign\.md$",
     lambda m: f"WIZ-{m.group(1)}-Design"),
    (r"^ash-gov-process-model/[^/]+/([A-Z]{2,3})-Wizard-Design\.md$",
     lambda m: f"WIZ-{m.group(1)}-Design"),

    # Policy Binding Matrices: BIND-{DOMAIN}
    (r"^ash-gov-process-model/[^/]+/([A-Z]{2,3})-Policy-Binding-Matrix\.md$",
     lambda m: f"BIND-{m.group(1)}"),

    # Traceability JSON: TRACE-{DOMAIN}
    (r"^ash-gov-process-model/[^/]+/([A-Z]{2,3})-traceability\.json$",
     lambda m: f"TRACE-{m.group(1)}"),

    # Decision Logs: LOG-{DOMAIN}
    (r"^ash-gov-process-model/[^/]+/([A-Z]{2,3})-Decision-Log\.md$",
     lambda m: f"LOG-{m.group(1)}"),

    # =========================================================================
    # CONTROLS (CTRL-*)
    # =========================================================================
    (r"^controls/AshMatics Exemplar Controls\.md$", "CTRL-ExemplarBase"),
    (r"^controls/AshMatics Exemplar Controls-mapping_ISO42001\.md$", "CTRL-ExemplarISO"),
    (r"^controls/controls_registry_guide\.md$", "CTRL-RegistryGuide"),
    (r"^controls/controls_registry_schema\.json$", "CTRL-RegistrySchema"),
    (r"^controls/controls_registry_summary\.md$", "CTRL-RegistrySummary"),
    (r"^controls/ashamtics-policies-to-examplarBase-controls\.md$", "CTRL-PolicyMapping"),
    (r"^controls/agentic_workflow_example\.md$", "CTRL-AgenticExample"),

    # =========================================================================
    # ISO MAPPINGS (ISO-*)
    # =========================================================================
    (r"^ISO-42001-maps/ISO-IEC-42001_ReferenceControls-AnnexA2toA10\.md$", "ISO-42001-AnnexA"),
    (r"^ISO-42001-maps/ashmatics-policyDomain-to-ISO42001-Overview-Summary\.md$", "ISO-42001-PolicyMap"),

    # =========================================================================
    # WIZARD SCHEMAS (WIZS-*)
    # =========================================================================
    # Process wizard configs: WIZS-{DOMAIN}
    (r"^wizard-content-schemas/([a-z]{2,3})-wizard-config\.yaml$",
     lambda m: f"WIZS-{m.group(1).upper()}"),

    # Regulatory logic files: WIZS-REG-{Name}
    (r"^wizard-content-schemas/([a-z-]+)-logic\.yaml$",
     lambda m: f"WIZS-REG-{_to_pascal(m.group(1))}"),

    # Other wizard schemas
    (r"^wizard-content-schemas/arch-ai-mapping\.yaml$", "WIZS-ArchAIMapping"),
    (r"^wizard-content-schemas/ashmatics-implementation-tiers-strategy\.md$", "WIZS-ImplTiers"),
    (r"^wizard-content-schemas/decision-tree-wizard-policy_process\.md$", "WIZS-DecisionTree"),

    # =========================================================================
    # REGISTRY FILES
    # =========================================================================
    (r"^ashmatics-framework-registry\.json$", "FW-Registry"),
    (r"^clinical-ai-governance-stakeholder-roles\.json$", "FW-StakeholderRoles"),
    (r"^process-domain-registry\.json$", "FW-ProcessRegistry"),
]


def _to_pascal(text: str) -> str:
    """Convert hyphenated or spaced text to PascalCase."""
    # Remove file extension if present
    text = re.sub(r'\.[a-z]+$', '', text)
    # Split on hyphens, underscores, or spaces
    words = re.split(r'[-_\s]+', text)
    # Capitalize each word
    return ''.join(word.capitalize() for word in words if word)


def _normalize_path(path: str) -> str:
    """Normalize path for pattern matching."""
    # Convert to forward slashes and remove leading ./
    path = path.replace('\\', '/')
    path = re.sub(r'^\./', '', path)
    # Remove any base directory prefixes
    # Match common base paths and remove them
    base_patterns = [
        r'^.*/ashmatics-policy-process-builder/',
        r'^ashmatics-policy-process-builder/',
    ]
    for pattern in base_patterns:
        path = re.sub(pattern, '', path)
    return path


def generate_artifact_slug(relative_path: str) -> Optional[str]:
    """
    Generate a canonical artifact_id slug from a file path.

    Args:
        relative_path: Path relative to the framework repository root

    Returns:
        Human-friendly slug like "SOP-PV-01" or "POL-AGP-Overview",
        or None if no pattern matches

    Examples:
        >>> generate_artifact_slug("policy-domain/AGP-Domain-Overview-Summary.md")
        'POL-AGP-Overview'

        >>> generate_artifact_slug("ash-gov-process-model/PV-01-.../SOP-PV-01-Problem-Discovery.md")
        'SOP-PV-01'

        >>> generate_artifact_slug("wizard-content-schemas/pv-wizard-config.yaml")
        'WIZS-PV'
    """
    normalized = _normalize_path(relative_path)

    for pattern, slug_or_func in SLUG_PATTERNS:
        match = re.match(pattern, normalized)
        if match:
            if callable(slug_or_func):
                return slug_or_func(match)
            else:
                return slug_or_func

    # No pattern matched - return None to indicate manual mapping needed
    return None


def generate_fallback_slug(relative_path: str, content_category: str = "") -> str:
    """
    Generate a fallback slug when no pattern matches.

    Uses the filename with a category prefix, maintaining uniqueness
    but in a less human-friendly format.

    Args:
        relative_path: Path relative to framework repository
        content_category: Optional category hint

    Returns:
        Fallback slug like "MISC-SomeFileName"
    """
    normalized = _normalize_path(relative_path)
    filename = Path(normalized).stem

    # Determine prefix from path or category
    prefix = "MISC"
    if "controls" in normalized.lower():
        prefix = "CTRL"
    elif "policy-domain" in normalized.lower():
        prefix = "POL"
    elif "process-domain" in normalized.lower():
        prefix = "PROC"
    elif "wizard" in normalized.lower():
        prefix = "WIZ"
    elif "ash-gov-process-model" in normalized.lower():
        prefix = "AREA"

    # Convert filename to PascalCase
    slug_name = _to_pascal(filename)

    return f"{prefix}-{slug_name}"


# =============================================================================
# EXPLICIT OVERRIDES
# =============================================================================
# For edge cases that don't fit patterns, add explicit mappings here

EXPLICIT_SLUG_OVERRIDES: dict[str, str] = {
    # Add any edge cases that need manual slugs
    # "path/to/weird-file.md": "CUSTOM-Slug",
}


def get_artifact_slug(relative_path: str, content_category: str = "") -> str:
    """
    Get the canonical artifact_id slug for a file path.

    Checks explicit overrides first, then pattern matching, then fallback.

    Args:
        relative_path: Path relative to framework repository root
        content_category: Optional category for fallback generation

    Returns:
        Human-friendly slug string
    """
    normalized = _normalize_path(relative_path)

    # Check explicit overrides first
    if normalized in EXPLICIT_SLUG_OVERRIDES:
        return EXPLICIT_SLUG_OVERRIDES[normalized]

    # Try pattern matching
    slug = generate_artifact_slug(relative_path)
    if slug:
        return slug

    # Fallback
    return generate_fallback_slug(relative_path, content_category)


# =============================================================================
# VALIDATION AND REPORTING
# =============================================================================

def validate_slug(slug: str) -> tuple[bool, str]:
    """
    Validate that a slug follows the naming convention.

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not slug:
        return False, "Slug is empty"

    # Must start with a known prefix
    known_prefixes = list(PREFIXES.values()) + ["MISC"]
    prefix_match = re.match(r'^([A-Z]+)-', slug)
    if not prefix_match:
        return False, f"Slug must start with a prefix like {known_prefixes[:5]}..."

    prefix = prefix_match.group(1)
    if prefix not in known_prefixes:
        return False, f"Unknown prefix '{prefix}'. Known: {known_prefixes}"

    # Must use only allowed characters (uppercase, digits, hyphens)
    if not re.match(r'^[A-Z][A-Z0-9a-z-]+$', slug):
        return False, "Slug must use PascalCase-Kebab format (e.g., POL-AGP-Overview)"

    return True, ""


if __name__ == "__main__":
    # Test examples
    test_paths = [
        "Framework-Overview-Summary.md",
        "policy-domain/AGP-Domain-Overview-Summary.md",
        "policy-domain/ash-AGP-policy-TEMP.md",
        "process-domain/PV-Domain-Overview-Summary.md",
        "ash-gov-process-model/PV-01-Problem_and_ValueQuantification/SOP-PV-01-Problem-Discovery-UseCase-Identification.md",
        "ash-gov-process-model/PV-01-Problem_and_ValueQuantification/WP-PV-01-Clinical-Needs-Analysis.md",
        "ash-gov-process-model/PV-01-Problem_and_ValueQuantification/PV-WizardDesign.md",
        "wizard-content-schemas/pv-wizard-config.yaml",
        "controls/controls_registry_guide.md",
        "ISO-42001-maps/ISO-IEC-42001_ReferenceControls-AnnexA2toA10.md",
    ]

    print("=" * 60)
    print("Artifact Slug Mapping Test")
    print("=" * 60)

    for path in test_paths:
        slug = get_artifact_slug(path)
        valid, err = validate_slug(slug)
        status = "OK" if valid else f"INVALID: {err}"
        print(f"{path}")
        print(f"  -> {slug} [{status}]")
        print()
