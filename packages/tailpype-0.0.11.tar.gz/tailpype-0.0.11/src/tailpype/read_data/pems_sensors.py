"""
This module provides functionality to read data from the Sensors PEMS (Portable Emission Measurement System).
"""

import glob
import numpy as np
import pandas as pd


def read_sensors_data(path_to_data: str) -> pd.DataFrame:
    """
    Reads and combines Dual-FID data from a given input path.
    :param path_to_data: pathname
    :return: DataFrame containing the combined data
    """

    dual_fid_files = glob.iglob(path_to_data, recursive=True)

    df_dual_fid = pd.DataFrame()
    for file_ in dual_fid_files:
        df_iter = pd.read_csv(filepath_or_buffer=file_, sep=',', skiprows=3, engine='python', encoding='utf-8',
                              header=None)
        idx_drop = df_iter.index[df_iter[0] == 'Summary Information:'][0]
        df_iter = df_iter.iloc[:idx_drop]
        columns = pd.read_csv(filepath_or_buffer=file_, sep=',', header=[0, 1, 2], nrows=1, engine='python',
                              encoding='utf-8').columns
        columns = ['{} - {} [{}]'.format(l0, l1, l2) for l0, l1, l2 in columns] + ['Empty column [-]']
        df_iter.columns = columns
        df_iter['datetime (UTC) [-]'] = \
            df_iter['DATE - sDATE [mm/dd/yyyy]'] + ' ' + df_iter['TIME - sTIME [hh:mm:ss.xxx]']
        df_iter['datetime (UTC) [-]'] = pd.to_datetime(df_iter['datetime (UTC) [-]'], format='%m/%d/%Y %H:%M:%S.%f')
        df_iter['datetime (UTC) [-]'] =\
            df_iter['datetime (UTC) [-]'].dt.tz_localize('Europe/Amsterdam').dt.tz_convert('UTC').dt.round(freq='s')
        # already in 1Hz -> no resampling required

        df_dual_fid = pd.concat([df_dual_fid, df_iter], axis=0).drop_duplicates()
        # drop_duplicates() is needed because some raw data is stored several times in different files

    if len(df_dual_fid) == 0:
        return df_dual_fid

    df_dual_fid = df_dual_fid.replace([np.inf, -np.inf], np.nan).dropna(how='all', axis=1)
    df_dual_fid = df_dual_fid.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_dual_fid.astype({'CH4 Concentration - iFID2_CH4 [ppmC]': float,
                               'THC Concentration - iFID_THC [ppmC]': float})
