"""
This module provides functionality to read data from the HORIBA PEMS (Portable Emission Measurement System).
"""

import glob
import numpy as np
import pandas as pd

from datetime import timedelta, timezone


def read_horiba_data(path_to_data: str) -> pd.DataFrame:
    """
    Reads and combines PEMS data from a given input path and adds a column 'datetime (UTC) [-]'. Furthermore,
    some enrichment takes place.
    :param path_to_data: pathname
    :return: DataFrame containing the combined data
    """

    pems_files = glob.iglob(path_to_data, recursive=True)

    df_pems = pd.DataFrame()
    for file_ in pems_files:
        df_iter = pd.read_csv(filepath_or_buffer=file_, sep=',', header=[0, 1], encoding='utf-8')
        df_iter = df_iter.swaplevel(i=0, j=1, axis=1)
        df_iter.columns = df_iter.columns.map(' '.join)
        df_iter['datetime (UTC) [-]'] = \
            pd.to_datetime(df_iter['Absolute_time [100ns]'], format='%m/%d/%Y %H:%M:%S.%f')
        df_iter = df_iter.resample('1s', on='datetime (UTC) [-]').last()
        # 'last' is used because it works for all dtypes (.agg() is an alternative)
        df_iter = df_iter.reset_index()
        df_iter['datetime (UTC) [-]'] = \
            df_iter['datetime (UTC) [-]'].dt.tz_localize(timezone(timedelta(hours=4))).dt.tz_convert('UTC')

        df_pems = pd.concat([df_pems, df_iter], axis=0).drop_duplicates()
        # drop_duplicates() is needed because some raw data is stored several times in different files

    if len(df_pems) == 0:
        return df_pems

    df_pems['CH4 (calc.) [ppmC]'] = df_pems['GA_THCConc [ppmC]'] / 1.110
    # For the CH4 response factor see the maintenance documents by HORIBA:
    # https://365tno.sharepoint.com/teams/P060.90328/TeamDocuments/Forms/AllItems.aspx?id=%2Fteams%2FP060%2E90328%2FTeamDocuments%2FTeam%2FWork%2F1%2E%20Technische%20middelen%2F21%2E%20PEMS%2FHORIBA%2FOnderhoud%20%26%20kalibratie%2F2025%2FTNO%20Maintenance%202025%2FQC%2FFidRespFactorChkStd%2FFidRespFactorChkStd%5FGROUP1%5FSERIAL6%5F831%2Epdf&parent=%2Fteams%2FP060%2E90328%2FTeamDocuments%2FTeam%2FWork%2F1%2E%20Technische%20middelen%2F21%2E%20PEMS%2FHORIBA%2FOnderhoud%20%26%20kalibratie%2F2025%2FTNO%20Maintenance%202025%2FQC%2FFidRespFactorChkStd

    df_pems = df_pems.replace(np.inf, np.nan).dropna(how='all', axis=1)
    df_pems = df_pems.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_pems


def read_horiba_logger_data(path_to_data: str) -> pd.DataFrame:
    """
    Reads and combines PEMS-Logger data from a given input path.
    :param path_to_data: pathname
    :return: DataFrame containing the combined data
    """

    pems_logger_files = glob.iglob(path_to_data, recursive=True)

    df_pems_logger = pd.DataFrame()
    for file_ in pems_logger_files:
        header_iter = pd.read_csv(filepath_or_buffer=file_, sep=',', index_col=0, skiprows=4, nrows=3, encoding='utf-8')
        start_time =\
            pd.to_datetime(header_iter.loc['StartTime', ' "Value"'], format='%Y-%m-%d %H:%M:%S.%f').replace(microsecond=0)
        dict_iter = pd.read_csv(filepath_or_buffer=file_, sep=',', header=0, skiprows=24, nrows=32, encoding='utf-8')
        dict_iter['Ch No'] = ' "Ch.' +  dict_iter['// "Ch No"'].astype(str) + '"'
        dict_iter['label'] = dict_iter[' "label"'] + ' [' + dict_iter[' "Unit"'] + ']'
        dict_iter = dict_iter.set_index('Ch No')['label'].to_dict()
        df_iter = pd.read_csv(filepath_or_buffer=file_, sep=',', header=0, skiprows=62, encoding='utf-8')
        df_iter = df_iter.rename(mapper=dict_iter, axis=1)
        df_iter['datetime (UTC) [-]'] = \
            start_time + pd.to_timedelta(df_iter[' "Elapsed Time"'], unit='seconds')
        df_iter['datetime (UTC) [-]'] = \
            df_iter['datetime (UTC) [-]'].dt.tz_localize(timezone(timedelta(hours=2))).dt.tz_convert('UTC')
        df_iter = df_iter.resample('1s', on='datetime (UTC) [-]').last()
        df_iter = df_iter.reset_index()
        df_iter = df_iter.ffill(axis=0, limit=None)
        # It is assumed that one file contains one time interval w/o gaps other than caused by resampling.
        # Therefore, no limit is needed.

        df_pems_logger = pd.concat([df_pems_logger, df_iter], axis=0)
    if len(df_pems_logger) == 0:
        return df_pems_logger

    df_pems_logger['CH4 (calc.) [ppmC]'] = df_pems_logger['Tailpipe THC Conc. [ppmC]'] / 1.110
    # CH4 response factor
    # https://365tno.sharepoint.com/teams/P060.90328/TeamDocuments/Forms/AllItems.aspx?id=%2Fteams%2FP060%2E90328%2FTeamDocuments%2FTeam%2FWork%2F1%2E%20Technische%20middelen%2F21%2E%20PEMS%2FHORIBA%2FOnderhoud%20%26%20kalibratie%2F2025%2FTNO%20Maintenance%202025%2FQC%2FFidRespFactorChkStd%2FFidRespFactorChkStd%5FGROUP1%5FSERIAL6%5F831%2Epdf&parent=%2Fteams%2FP060%2E90328%2FTeamDocuments%2FTeam%2FWork%2F1%2E%20Technische%20middelen%2F21%2E%20PEMS%2FHORIBA%2FOnderhoud%20%26%20kalibratie%2F2025%2FTNO%20Maintenance%202025%2FQC%2FFidRespFactorChkStd

    df_pems_logger = df_pems_logger.replace([np.inf, -np.inf], np.nan).dropna(how='all', axis=1)
    df_pems_logger = df_pems_logger.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_pems_logger