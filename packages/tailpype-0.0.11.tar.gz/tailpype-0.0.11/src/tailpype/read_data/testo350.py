"""
This module provides functionality to read data from the Testo 350 emission measurement tool.
"""

import datetime
import glob
import numpy as np
import pandas as pd


# ----------------------------------------------------------------------------------------------------------------------
# constants

columns_dict_testo =\
    {'Datum / Tijd':       'Date / time',
     'sec looptijd':       'sec Runtime',
     '% O₂':               '% O₂',
     '% CO₂ir':            '% CO₂IR',
     'ppm NOx':            'ppm NOx',
     'ppm CO':             'ppm CO',
     'ppm CxHy':           'ppm HC',
     'λ':                  'λ',
     '°C Tr':              '°C FT',
     '°C Tv':              '°C AT',
     'ppm NO':             'ppm NO',
     'ppm NO₂':            'ppm NO₂',
     'l/min Pomp':         'l/min Pump',
     '°C Δt':              '°C Δt',
     'hPa Pabs':           'hPa Pabs',
     'ppm COonv':          'ppm uCO',
     'ppm H₂':             'ppm H₂',
     'kg/h MCO':           'kg/h MCO',
     'kg/h MNOx':          'kg/h MNOx',
     'kg/h MCO2IR':        'kg/h MCO2IR',
     'Verdunningsfactor':  'Dilution factor'}


# ----------------------------------------------------------------------------------------------------------------------

def read_testo_data(path_to_data: str) -> pd.DataFrame:
    """
    Reads and combines Testo 350 data from a given input path and adds a column 'datetime (UTC) [-]'.
    :param path_to_data: pathname
    :return: DataFrame containing the combined data
    """

    testo_files = glob.iglob(path_to_data, recursive=True)

    df_testo = pd.DataFrame()
    for file_ in testo_files:
        df_iter = pd.read_excel(io=file_, decimal='.', header=0)
        df_iter = df_iter.rename(mapper=columns_dict_testo, axis=1)
        # renaming of the columns is needed because the raw data is either in Dutch or English language
        df_iter['datetime (UTC) [-]'] =\
            pd.to_datetime(df_iter['Date / time'], format='%y-%m-%d %H:%M:%S').dt.tz_localize("UTC").dt.round(freq='s')
        # The data is already at 1Hz, no resampling needed.

        df_testo = pd.concat([df_testo, df_iter], axis=0)

        assert len(set(df_testo.columns) ^ set(df_iter.columns)) == 0
        # make sure that all files have the same columns

    if len(df_testo) == 0:
        return df_testo

    df_testo['datetime (UTC) [-]'] = df_testo['datetime (UTC) [-]'] +\
                                     datetime.timedelta(hours=-2, minutes=1, seconds=44)
    # see the ReadMe.txt in the Testo 350 data for the timedelta

    df_testo = df_testo.replace([np.inf, -np.inf], np.nan).dropna(how='all', axis=1)
    df_testo = df_testo.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_testo