"""
This module provides functionality to read data from TNO's Smart Emission Measurement System (SEMS).
"""

import glob
import numpy as np
import pandas as pd


def read_sems_data(path_to_data: str) -> pd.DataFrame:
    """
    Reads and combines SEMS data from a given input path and adds a column 'datetime (UTC) [-]'.
    :param path_to_data: pathname
    :return: DataFrame containing the combined data
    """

    sems_files = glob.iglob(path_to_data, recursive=True)

    df_sems = pd.DataFrame()
    for file_ in sems_files:
        df_iter = pd.read_csv(filepath_or_buffer=file_, delimiter=',', decimal='.', header=[0, 1], engine='python')
        df_iter.columns = df_iter.columns.map(' '.join)
        df_iter['datetime (UTC) [-]'] =\
            pd.to_datetime(df_iter['UTC [-]'], format='%y%m%d%H%M%S').dt.tz_localize("UTC").dt.round(freq='s')
        # Since SEMS data is always at 1Hz it is not resampled to reduce running time of the code.

        df_sems = pd.concat([df_sems, df_iter], axis=0)

        assert len(set(df_sems.columns) ^ set(df_iter.columns)) == 0
        # make sure that all files have the same columns

    if len(df_sems) == 0:
        return df_sems

    df_sems = df_sems.replace([np.inf, -np.inf], np.nan).dropna(how='all', axis=1)
    df_sems = df_sems.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_sems