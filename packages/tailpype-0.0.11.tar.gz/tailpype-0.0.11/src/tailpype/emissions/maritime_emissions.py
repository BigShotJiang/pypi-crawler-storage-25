"""
This module provides functionality for the calculation of emissions from seafaring vessels. Much of it is based on
the NOx Technical Code (NTC) of the IMO, which provides a standardized method for calculating NOx emissions from
marine engines.
"""

