"""
A lot of interesting stuff
"""

def add_one(number):
    return number + 1
