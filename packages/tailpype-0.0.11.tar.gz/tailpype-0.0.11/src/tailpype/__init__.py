"""
A really cool package that does a lot of stuff !
"""


from . import emissions, ftir, read_data

__all__ = ['emissions', 'ftir', 'read_data']
