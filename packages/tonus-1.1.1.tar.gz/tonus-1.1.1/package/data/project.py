from package.data.init import ensure_db_ready, get_conn
from package.entity.project import Project


@ensure_db_ready
def add_project(project: Project):
    sql = "insert into projects(project_name,project_status,fatigue_rate,fatigue_total) values(?,?,?,?)"
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            sql,
            (
                project.project_name,
                project.project_status,
                project.fatigue_rate,
                project.fatigue_total,
            ),
        )

    return cursor.lastrowid

@ensure_db_ready
def delete_project(project: str):
    sql = "delete from projects where project_name = ?"
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            sql,
            (project,),
        )


@ensure_db_ready
def update_project(project: Project):
    project_dict = vars(project)
    update_parts = {k: v for k,v in project_dict.items() if v is not None and k != "id"}
    if not update_parts:
        return None
    update_keys = ",".join([f"{k} = ?" for k in update_parts.keys()])
    sql = "update projects set " + update_keys + " where id = ?"
    params = list(update_parts.values())
    params.append(project.id)

    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(sql, params)
        conn.commit()

@ensure_db_ready
def batch_init_extra(project_ids: list[int]):
    sql = "UPDATE projects SET extra_time = 0, invalid_time = 0, extra_start_time = 0 WHERE id = ?"
    params = [(pid,) for pid in project_ids]
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.executemany(sql, params)
        conn.commit()


@ensure_db_ready
def get_project_id(id: int):
    sql = "select id,project_name,fatigue_rate,fatigue_total,project_status from projects where id = ?"
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            sql,
            (id,),
        )

        return Project(**dict(cursor.fetchone()))


@ensure_db_ready
def get_project_name(project_name):
    sql = "select id,project_name,fatigue_total,fatigue_rate,project_status,extra_time,extra_start_time,invalid_time from projects where project_name = ?"
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            sql,
            (project_name,),
        )
        row = cursor.fetchone()
        if not row:
            return None

        return Project(**dict(row))


@ensure_db_ready
def get_all_projects():
    sql = (
        "select id,project_name,fatigue_total,fatigue_rate,project_status,invalid_time,extra_time,extra_start_time from projects"
    )
    with get_conn() as conn:
        cursor = conn.cursor()
        cursor.execute(
            sql,
        )
        rows = cursor.fetchall()
        if not rows:
            return None

        results = []
        for r in rows:
            results.append(Project(**dict(r)))
        return results
