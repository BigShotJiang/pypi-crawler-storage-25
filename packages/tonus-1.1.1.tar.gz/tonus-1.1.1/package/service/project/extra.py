from datetime import datetime

from package.data.project import update_project, get_project_name
from package.data.init import ensure_db_ready


@ensure_db_ready
def extra_time(project_name, minutes:int, invalid_day:int):
    invalid_time = invalid_day * 24 * 60 * 60 * 60
    extra_start_time = int(datetime.now().timestamp())
    if project_name == "" or project_name is None:
        raise ValueError("Project name cannot be empty")
    project = get_project_name(project_name=project_name)
    project.extra_time = project.extra_time + minutes
    project.invalid_time = invalid_time
    project.extra_start_time = extra_start_time
    update_project(project)
