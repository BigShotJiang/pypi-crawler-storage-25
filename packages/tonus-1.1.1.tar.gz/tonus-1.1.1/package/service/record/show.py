from datetime import datetime
from package.data.project import get_project_name,get_all_projects,batch_init_extra
from package.data.record import (
    get_today_accumulated_fatigue,
)
from rich.console import Console
from rich.table import Table
from rich.progress_bar import ProgressBar
from rich.text import Text
import typer

status_map = {
    0 : ("已暂停", "red"),
    1 : ("进行中", "green"),
    2 : ("已结束", "grey"),
    3 : ("未开始", "yellow")
}

def show(project_name):
    console = Console()
    project = get_project_name(project_name=project_name)

    if not project:
        typer.secho("找不到此项目", fg=typer.colors.RED, err=True)
        return

    cost = int(get_today_accumulated_fatigue(project.id))

    if cost > project.fatigue_total:
        cost = project.fatigue_total

    rest = (project.fatigue_total + project.extra_time) - cost
    total = project.fatigue_total + project.extra_time

    if rest < 0:
        rest = 0

    bar = ProgressBar(
        total=total,
        completed=rest,
        width=40,
        complete_style="yellow",
        finished_style="green",
    )
    status_text, color = status_map.get(project.project_status,("未知","white"))
    status = Text(status_text, style=color)
    grid = Table.grid(padding=1)
    grid.add_row(
        Text(
            f"{project.project_name}: {rest}/{total}:",
            style="bold blue",
        ),
        status,
        bar,
        Text(f"{rest / total:.1%}", style="magenta"),
    )
    console.print(grid)


def list_all():
    p_ids = confirm_extra()
    batch_init_extra(p_ids)
    results = get_today_accumulated_fatigue()
    console = Console()
    if not results:
        typer.secho("没有记录，请确认", fg=typer.colors.RED, err=True)
    grid = Table.grid(padding=1)
    grid.add_column(justify="right")
    grid.add_column(justify="left")
    grid.add_column(justify="right")
    grid = Table.grid(expand=True, padding=(0, 1))
    grid.add_column(no_wrap=True, justify="left")
    grid.add_column(no_wrap=True, justify="right")
    grid.add_column(no_wrap=True, justify="center", width=10)
    grid.add_column(ratio=1)
    grid.add_column(no_wrap=True, justify="right")

    for r in results:
        rest = max(0, int(r["total"] - r["used"]))
        bar = ProgressBar(
            total=r["total"],
            completed=rest,
            width=None, # 宽度自适应
            complete_style="yellow",
            finished_style="green",
        )

        status_text, color = status_map.get(r["status"], ("未知", "white"))
        status = Text(status_text, style=color)
        grid.add_row(
            Text(f"{r['id']} {r['name']}:", style="bold blue"),
            Text(f"{rest}/{r['total']}:", style="bold blue"),
            status,
            bar,
            Text(f"{rest / r['total']:.1%}", style="magenta")
        )
    console.print(grid)


def confirm_extra():
    projects = get_all_projects()
    current_stamp = datetime.now().timestamp()
    filtered_projects = filter(lambda p: int(current_stamp) >= p.invalid_time + p.extra_start_time, projects)
    project_ids = list(map(lambda p: p.id, filtered_projects))
    return project_ids
