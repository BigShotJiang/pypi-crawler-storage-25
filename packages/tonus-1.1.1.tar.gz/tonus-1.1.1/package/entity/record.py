from dataclasses import dataclass
from typing import Optional


@dataclass
class Record:
    id: Optional[int]
    start: int = -1
    stop: int = -1
    duration: int = -1
    task_desc: str = ""
    extra_id: str = ""
    project_id: int = -1
