from dataclasses import dataclass
from typing import Optional


@dataclass
class Project:
    id: Optional[int]
    project_name: Optional[str] = ""
    fatigue_rate: Optional[float] = 1.0
    fatigue_total: Optional[int] = 156
    project_status: Optional[int] = 0,
    extra_time: Optional[int] = 0,
    invalid_time: Optional[int] = 0,
    extra_start_time: Optional[int] = 0,