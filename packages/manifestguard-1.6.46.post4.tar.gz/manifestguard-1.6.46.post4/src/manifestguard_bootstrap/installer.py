from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path

DEFAULT_REPOSITORY = "timejunky/r4it_mgpy_release"
DEFAULT_BRANCH = "release"
DEFAULT_MANIFEST_ROOT = "manifestguard"
DEFAULT_MANIFEST_PATH = "manifestguard/latest/manifest.json"
_MISSING = object()


@dataclass(frozen=True)
class PayloadManifest:
    version: str
    wheel_url: str
    sha256: str
    python_requires: str | None = None
    notes: str | None = None


def _parse_cpython_tag_from_wheel_filename(wheel_name: str) -> tuple[int, int] | None:
    stem = wheel_name[:-4] if wheel_name.endswith(".whl") else wheel_name
    parts = stem.split("-")
    if len(parts) < 5:
        return None
    python_tag = parts[-3]
    if not python_tag.startswith("cp"):
        return None

    digits = python_tag[2:]
    if not digits.isdigit() or len(digits) < 2:
        return None

    major = int(digits[0])
    minor = int(digits[1:])
    return major, minor


def _assert_interpreter_matches_wheel(manifest: PayloadManifest, wheel_name: str, mode: str) -> None:
    required = _parse_cpython_tag_from_wheel_filename(wheel_name)
    if not required:
        return

    current = (sys.version_info.major, sys.version_info.minor)
    if current == required:
        return

    mode_flag = "--user" if mode == "user" else "--venv"
    raise RuntimeError(
        "Protected payload wheel is not compatible with this interpreter.\n"
        f"Current Python: {sys.version_info.major}.{sys.version_info.minor} ({sys.executable})\n"
        f"Required by wheel: {required[0]}.{required[1]} ({wheel_name})\n"
        f"Manifest python_requires: {manifest.python_requires or 'n/a'}\n"
        "To continue, use Python 3.12 and make sure the bootstrap package is installed there:\n"
        "  py -3.12 -m pip install --user --upgrade manifestguard\n"
        f"  py -3.12 -m manifestguard_bootstrap.cli install-protected {mode_flag}\n"
        "Then verify:\n"
        "  py -3.12 -m manifestguard --version\n"
        f"Note: after install-protected, the public bootstrap package is replaced by the protected ManifestGuard payload version {manifest.version}."
    )


def build_version_manifest_path(
    payload_version: str,
    manifest_root: str = DEFAULT_MANIFEST_ROOT,
) -> str:
    normalized_version = payload_version.strip()
    if not normalized_version:
        raise ValueError("payload_version must not be empty.")
    return f"{manifest_root}/{normalized_version}/manifest.json"


def resolve_manifest_path(manifest_path: str, payload_version: str | None = None) -> str:
    if payload_version:
        return build_version_manifest_path(payload_version)
    return manifest_path


def build_raw_manifest_url(
    repository: str = DEFAULT_REPOSITORY,
    branch: str = DEFAULT_BRANCH,
    manifest_path: str = DEFAULT_MANIFEST_PATH,
) -> str:
    return f"https://raw.githubusercontent.com/{repository}/{branch}/{manifest_path}"


def fetch_manifest(url: str, timeout: int = 30) -> PayloadManifest:
    with urllib.request.urlopen(url, timeout=timeout) as response:
        payload = json.load(response)
    return PayloadManifest(
        version=payload["version"],
        wheel_url=payload["wheel_url"],
        sha256=payload["sha256"],
        python_requires=payload.get("python_requires"),
        notes=payload.get("notes"),
    )


def get_installed_manifestguard_version() -> str | None:
    try:
        return importlib.metadata.version("manifestguard")
    except importlib.metadata.PackageNotFoundError:
        return None


def detect_installed_manifestguard_variant() -> str:
    has_payload_module = importlib.util.find_spec("manifestguard") is not None
    has_bootstrap_module = importlib.util.find_spec("manifestguard_bootstrap") is not None

    if has_payload_module:
        return "payload"
    if has_bootstrap_module:
        return "bootstrap-only"
    return "distribution-only"


def compare_versions(left: str, right: str) -> int:
    def normalize_part(part: str) -> tuple[int, int | str]:
        return (0, int(part)) if part.isdigit() else (1, part)

    left_parts = [normalize_part(part) for part in left.split(".")]
    right_parts = [normalize_part(part) for part in right.split(".")]
    max_len = max(len(left_parts), len(right_parts))
    padding = (0, 0)
    left_parts.extend([padding] * (max_len - len(left_parts)))
    right_parts.extend([padding] * (max_len - len(right_parts)))
    if left_parts < right_parts:
        return -1
    if left_parts > right_parts:
        return 1
    return 0


def get_update_status(
    target_version: str,
    installed_version: str | None | object = _MISSING,
) -> dict[str, str | bool | None]:
    if installed_version is _MISSING:
        installed_version = get_installed_manifestguard_version()
    if installed_version is None:
        return {
            "installed_version": None,
            "target_version": target_version,
            "update_available": True,
            "status": "not-installed",
        }

    installed_variant = detect_installed_manifestguard_variant()
    if installed_variant == "bootstrap-only":
        return {
            "installed_version": installed_version,
            "target_version": target_version,
            "update_available": True,
            "status": "bootstrap-only",
        }

    comparison = compare_versions(installed_version, target_version)
    if comparison < 0:
        status = "update-available"
        update_available = True
    elif comparison == 0:
        status = "up-to-date"
        update_available = False
    else:
        status = "ahead-of-target"
        update_available = False

    return {
        "installed_version": installed_version,
        "target_version": target_version,
        "update_available": update_available,
        "status": status,
    }


def detect_install_mode(use_user: bool, use_venv: bool) -> str:
    if use_user and use_venv:
        raise ValueError("Choose either user or venv mode, not both.")
    if use_user:
        return "user"
    if use_venv:
        return "venv"
    if os.environ.get("VIRTUAL_ENV") or sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        return "venv"
    return "user"


def sha256_of_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_file(url: str, destination: Path, timeout: int = 60) -> Path:
    with urllib.request.urlopen(url, timeout=timeout) as response, destination.open("wb") as handle:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            handle.write(chunk)
    return destination


def build_pip_install_command(
    python_executable: str,
    wheel_path: Path,
    mode: str,
    force_reinstall: bool = False,
) -> list[str]:
    command = [python_executable, "-m", "pip", "install", "--upgrade", str(wheel_path)]
    if force_reinstall:
        command.append("--force-reinstall")
    if mode == "user":
        command.append("--user")
    return command


def install_payload(
    manifest: PayloadManifest,
    mode: str,
    python_executable: str | None = None,
    dry_run: bool = False,
) -> list[str]:
    python_executable = python_executable or sys.executable
    installed_version = get_installed_manifestguard_version()
    installed_variant = detect_installed_manifestguard_variant()
    force_reinstall = installed_variant == "bootstrap-only" and installed_version == manifest.version
    with tempfile.TemporaryDirectory(prefix="manifestguard-bootstrap-") as temp_dir:
        wheel_name = Path(manifest.wheel_url).name
        _assert_interpreter_matches_wheel(manifest, wheel_name, mode)
        wheel_path = Path(temp_dir) / wheel_name
        download_file(manifest.wheel_url, wheel_path)
        actual_hash = sha256_of_file(wheel_path)
        if actual_hash.lower() != manifest.sha256.lower():
            raise RuntimeError(
                f"Downloaded wheel hash mismatch. expected={manifest.sha256} actual={actual_hash}"
            )
        command = build_pip_install_command(
            python_executable,
            wheel_path,
            mode,
            force_reinstall=force_reinstall,
        )
        if dry_run:
            return command
        subprocess.run(command, check=True)
        return command
