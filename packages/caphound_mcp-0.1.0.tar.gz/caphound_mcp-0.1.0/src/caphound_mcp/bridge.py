"""
CapHound MCP stdio bridge (Python).

Reads newline-delimited JSON-RPC 2.0 messages from stdin (MCP stdio transport),
forwards each to the CapHound HTTP MCP endpoint with the workspace API key,
writes responses back to stdout. Logs go to stderr (stdout is reserved for protocol).

Config:
    CAPHOUND_API_KEY   — required. Bearer token (warden_live_... / warden_test_...).
    CAPHOUND_API_BASE  — optional. Defaults to https://api.caphound.ai.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any

import httpx

DEFAULT_API_BASE = "https://api.caphound.ai"
USER_AGENT = "caphound-mcp-python/0.1.0"
REQUEST_TIMEOUT_SECONDS = 30.0


def _log(msg: str) -> None:
    sys.stderr.write(f"[caphound-mcp] {msg}\n")
    sys.stderr.flush()


def _write_json(obj: Any) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def _error_response(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": message},
    }


def main() -> int:
    api_key = os.environ.get("CAPHOUND_API_KEY")
    if not api_key:
        _log(
            "CAPHOUND_API_KEY is not set. Add it to the 'env' block of your "
            "MCP client config (e.g. claude_desktop_config.json)."
        )
        return 1

    api_base = os.environ.get("CAPHOUND_API_BASE", DEFAULT_API_BASE).rstrip("/")
    endpoint = f"{api_base}/api/v1/mcp"

    _log(f"ready — forwarding to {endpoint}")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": USER_AGENT,
    }

    with httpx.Client(timeout=REQUEST_TIMEOUT_SECONDS, headers=headers) as client:
        for raw_line in sys.stdin:
            line = raw_line.strip()
            if not line:
                continue

            try:
                req = json.loads(line)
            except json.JSONDecodeError as exc:
                _log(f"parse error: {exc}")
                _write_json(_error_response(None, -32700, "Parse error"))
                continue

            req_id = req.get("id") if isinstance(req, dict) else None

            try:
                resp = client.post(endpoint, content=json.dumps(req))
            except httpx.HTTPError as exc:
                _log(f"transport error: {exc}")
                _write_json(
                    _error_response(req_id, -32603, f"Transport error: {exc}")
                )
                continue

            if resp.status_code == 401:
                _log("401 unauthorized — check your CAPHOUND_API_KEY.")

            text = resp.text
            if not text:
                _write_json(
                    _error_response(
                        req_id, -32603, f"Empty response (HTTP {resp.status_code})"
                    )
                )
                continue

            try:
                parsed = json.loads(text)
                _write_json(parsed)
            except json.JSONDecodeError:
                snippet = text[:200]
                _write_json(
                    _error_response(
                        req_id,
                        -32603,
                        f"Non-JSON response (HTTP {resp.status_code}): {snippet}",
                    )
                )

    return 0


if __name__ == "__main__":
    sys.exit(main())
