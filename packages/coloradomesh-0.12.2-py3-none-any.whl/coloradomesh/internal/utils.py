import secrets
import time
from datetime import datetime, timedelta


def now() -> datetime:
    """
    Get the current date and time as a datetime object.
    :return: The current date and time.
    """
    return datetime.now()


def now_delta(days: int = 0, hours: int = 0, minutes: int = 0) -> datetime:
    """
    Get the current date and time with a specified delta.
    :param days: The number of days to add (or subtract if negative).
    :param hours: The number of hours to add (or subtract if negative).
    :param minutes: The number of minutes to add (or subtract if negative).
    :return: The current date and time with the specified delta applied.
    """
    return datetime.now() + timedelta(days=days, hours=hours, minutes=minutes)


def datetime_within_delta(_datetime: datetime, days: int = 0, hours: int = 0, minutes: int = 0) -> bool:
    """
    Check if a given datetime is within a specified delta from the current time.
    :param _datetime: The datetime to check.
    :param days: The number of days for the delta.
    :param hours: The number of hours for the delta.
    :param minutes: The number of minutes for the delta.
    :return: True if the datetime is within the specified delta from now, False otherwise.
    """
    if not _datetime:
        return False

    now_time = datetime.now()
    delta = timedelta(days=days, hours=hours, minutes=minutes)
    if _datetime > now_time:  # Dealing with positive deltas (future timestamps)
        return _datetime - now_time <= delta
    else:
        return now_time - _datetime <= delta


def timestamp_within_delta(timestamp: int, days: int = 0, hours: int = 0, minutes: int = 0) -> bool:
    """
    Check if a given timestamp is within a specified delta from the current time.
    :param timestamp: The timestamp to check (in seconds since the epoch).
    :param days: The number of days for the delta.
    :param hours: The number of hours for the delta.
    :param minutes: The number of minutes for the delta.
    :return: True if the timestamp is within the specified delta from now, False otherwise.
    """
    if not timestamp:
        return False

    target_time = datetime.fromtimestamp(timestamp)
    return datetime_within_delta(_datetime=target_time, days=days, hours=hours, minutes=minutes)


def delta_datetime_to_now(_datetime: datetime) -> timedelta:
    """
    Calculate the timedelta between a given datetime and the current time.
    :param _datetime: The datetime to compare with the current time.
    :return: The timedelta between the given datetime and now.
    """
    if not _datetime:
        return timedelta(0)

    now_time = now()
    return now_time - _datetime


def iso8601_to_unix_timestamp(iso_str: str) -> int:
    if not iso_str:
        return 0

    try:
        # e.g. 2026-02-18T01:19:00.379Z
        dt = time.strptime(iso_str, "%Y-%m-%dT%H:%M:%S.%fZ")
        return int(time.mktime(dt))
    except Exception as e:
        return 0


def epoch_to_date(epoch_time: int) -> str:
    """Convert epoch timestamp to YYYY-MM-DD format."""
    if not epoch_time:
        return "N/A"

    try:
        # Convert epoch to datetime and format as YYYY-MM-DD
        dt = datetime.fromtimestamp(int(epoch_time))
        return dt.strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return "Invalid date"


def epoch_to_datetime(epoch_time: int) -> str:
    """Convert epoch timestamp to YYYY-MM-DD HH:MM:SS format."""
    if not epoch_time:
        return "N/A"

    try:
        # Convert epoch to datetime and format as YYYY-MM-DD HH:MM:SS
        dt = datetime.fromtimestamp(int(epoch_time))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return "Invalid date"


def generate_password(token_size: int = 8) -> str:
    """Generate a random password."""
    return secrets.token_urlsafe(token_size)
