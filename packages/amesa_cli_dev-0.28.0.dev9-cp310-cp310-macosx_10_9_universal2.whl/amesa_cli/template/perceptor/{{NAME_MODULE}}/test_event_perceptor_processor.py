# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Unit tests for EventPerceptorProcessor with mocked PerceptorComponent.
Tests that the perceptor processor correctly handles input/output and scales on unique ID.
"""

import pytest

from amesa_core.agent.perceptor.perceptor import Perceptor, PerceptorSchema
from amesa_core.agent.perceptor.perceptor_impl import PerceptorImpl
from amesa_core.agent.sensors.sensor import Sensor, SensorSchema
from amesa_core.networking.remote_perceptor.v2.event_perceptor_processor import (
    EventPerceptorProcessor,
)
from amesa_core.networking.event_base import EventMessage


sensor1 = Sensor("counter", "A sensor that provides a counter value.", lambda obs: obs[0])
sensor2 = Sensor("value", "A sensor that provides a value.", lambda obs: obs[1])
sensor1_schema = SensorSchema.from_sensor(sensor1)
sensor2_schema = SensorSchema.from_sensor(sensor2)


class TestPerceptorImpl(PerceptorImpl):
    """Test perceptor implementation for unit tests."""

    def __init__(self):
        self.counter = 0

    async def filtered_sensor_space(self, obs):
        return super().filtered_sensor_space(obs)

    async def compute(self, obs_spec, obs):
        """Compute test perceptor output."""
        counter_value = obs.get("counter", 0) if isinstance(obs, dict) else 0
        return {"test_output": counter_value * 2}


@pytest.fixture
def mock_perceptor_impl():
    """Create a mock perceptor for testing."""
    perceptor = Perceptor(
        "test_perceptor",
        TestPerceptorImpl,
        "A test perceptor for unit tests"
    )
    schema = PerceptorSchema.from_perceptor(perceptor)
    return schema


@pytest.mark.asyncio
async def test_event_perceptor_processor_init(mock_perceptor_impl):
    """Test EventPerceptorProcessor initialization."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Verify initialization
    assert processor._is_initialized is True
    assert len(processor.perceptor_impls) == 1
    assert len(processor.perceptor_components) == 0  # No components created yet


@pytest.mark.asyncio
async def test_event_perceptor_processor_perceive_message(mock_perceptor_impl):
    """Test EventPerceptorProcessor handles perceive messages correctly."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Create a perceive message
    message = EventMessage(
        message_id="test-msg-1",
        timestamp=0,
        correlation_id="test-corr-1",
        unique_id="test-unique-1",
        data={
            "type": "perceive",
            "obs": [5, 0],
        }
    )

    # Process the message
    result = await processor.process_message(message)

    # Verify the result
    assert result is not None
    assert result["type"] == "perceive_response"
    assert "result" in result
    assert result["message_id"] == message.message_id
    assert result["correlation_id"] == message.correlation_id
    for key in ["counter", "value", "test_output"]:
        assert key in result["result"]

    # Verify that a perceptor component was created for the unique_id
    assert len(processor.perceptor_components) == 1
    assert "test-unique-1" in processor.perceptor_components


@pytest.mark.asyncio
async def test_event_perceptor_processor_reset_message(mock_perceptor_impl):
    """Test EventPerceptorProcessor handles reset messages correctly."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # First create a perceptor component by processing a perceive message
    perceive_message = EventMessage(
        message_id="test-msg-1",
        timestamp=0,
        correlation_id="test-corr-1",
        unique_id="test-unique-1",
        data={
            "type": "perceive",
            "obs_spec": None,
            "obs": [5, 0],
        }
    )
    await processor.process_message(perceive_message)

    # Now send a reset message
    reset_message = EventMessage(
        message_id="test-msg-2",
        timestamp=0,
        correlation_id="test-corr-2",
        unique_id="test-unique-1",
        data={
            "type": "reset"
        }
    )

    # Process the reset message
    result = await processor.process_message(reset_message)

    # Verify the result
    assert result is not None
    assert result["type"] == "reset_response"
    assert result["message_id"] == reset_message.message_id
    assert result["correlation_id"] == reset_message.correlation_id
    assert "episode_id" in result
    assert processor._episode_step == 0


@pytest.mark.asyncio
async def test_event_perceptor_processor_unknown_message_type(mock_perceptor_impl):
    """Test EventPerceptorProcessor handles unknown message types correctly."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Create an unknown message type
    message = EventMessage(
        message_id="test-msg-1",
        timestamp=0,
        correlation_id="test-corr-1",
        unique_id="test-unique-1",
        data={
            "type": "unknown_type"
        }
    )

    # Process the message
    result = await processor.process_message(message)

    # Verify the result is an error
    assert result is not None
    assert result["type"] == "error"
    assert "Unknown request type" in result["error"]


@pytest.mark.asyncio
async def test_event_perceptor_processor_scales_on_unique_id(mock_perceptor_impl):
    """
    Test that EventPerceptorProcessor correctly scales on unique ID.
    Each unique ID should get its own isolated perceptor component.
    """
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Process messages with different unique IDs
    unique_ids = ["unique-1", "unique-2", "unique-3"]

    for unique_id in unique_ids:
        message = EventMessage(
            message_id=f"test-msg-{unique_id}",
            timestamp=0,
            correlation_id=f"test-corr-{unique_id}",
            unique_id=unique_id,
            data={
                "type": "perceive",
                "obs_spec": None,
                "obs": [5, 0],
            }
        )

        result = await processor.process_message(message)

        # Verify the result
        assert result is not None
        assert result["type"] == "perceive_response"
        assert "result" in result

    # Verify that separate perceptor components were created for each unique ID
    assert len(processor.perceptor_components) == len(unique_ids)

    for unique_id in unique_ids:
        assert unique_id in processor.perceptor_components
        # Each component should have its own isolated state
        component = processor.perceptor_components[unique_id]
        assert component is not None
        assert component.get_perceptor_count() == 1

    # Verify that components are actually different instances
    component_ids = [id(component) for component in processor.perceptor_components.values()]
    assert len(component_ids) == len(set(component_ids)), "All components should be unique instances"


@pytest.mark.asyncio
async def test_event_perceptor_processor_multiple_unique_ids_isolation(mock_perceptor_impl):
    """
    Test that perceptor components are properly isolated per unique ID.
    Processing messages for one unique ID should not affect others.
    """
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Process first message with unique-id-1
    message_1 = EventMessage(
        message_id="test-msg-1",
        timestamp=0,
        correlation_id="test-corr-1",
        unique_id="unique-id-1",
        data={
            "type": "perceive",
            "obs_spec": None,
            "obs": [5, 0],
        }
    )

    result_1 = await processor.process_message(message_1)
    assert result_1 is not None
    assert result_1["type"] == "perceive_response"

    # Process second message with unique-id-2
    message_2 = EventMessage(
        message_id="test-msg-2",
        timestamp=0,
        correlation_id="test-corr-2",
        unique_id="unique-id-2",
        data={
            "type": "perceive",
            "obs_spec": None,
            "obs": [10, 0]
        }
    )

    result_2 = await processor.process_message(message_2)
    assert result_2 is not None
    assert result_2["type"] == "perceive_response"

    # Verify both components exist and are independent
    assert len(processor.perceptor_components) == 2
    assert "unique-id-1" in processor.perceptor_components
    assert "unique-id-2" in processor.perceptor_components

    component_1 = processor.perceptor_components["unique-id-1"]
    component_2 = processor.perceptor_components["unique-id-2"]

    # Verify components are different instances
    assert component_1 is not component_2
    assert id(component_1) != id(component_2)


@pytest.mark.asyncio
async def test_event_perceptor_processor_get_isolation_info(mock_perceptor_impl):
    """Test that get_perceptor_isolation_info returns correct information."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Process messages with different unique IDs
    unique_ids = ["unique-1", "unique-2"]

    for unique_id in unique_ids:
        message = EventMessage(
            message_id=f"test-msg-{unique_id}",
            timestamp=0,
            correlation_id=f"test-corr-{unique_id}",
            unique_id=unique_id,
            data={
                "type": "perceive",
                "obs_spec": None,
                "obs": [5, 0],
            }
        )
        await processor.process_message(message)

    # Get isolation info
    isolation_info = processor.get_perceptor_isolation_info()

    # Verify isolation info
    assert len(isolation_info) == 2
    assert "unique-1" in isolation_info
    assert "unique-2" in isolation_info

    for unique_id in unique_ids:
        assert "perceptor_count" in isolation_info[unique_id]
        assert "perceptor_names" in isolation_info[unique_id]
        assert isolation_info[unique_id]["perceptor_count"] == 1


@pytest.mark.asyncio
async def test_event_perceptor_processor_missing_obs_error(mock_perceptor_impl):
    """Test that EventPerceptorProcessor handles missing obs parameter correctly."""
    # Create the EventPerceptorProcessor
    processor = EventPerceptorProcessor(
        sensors=[sensor1_schema, sensor2_schema],
        perceptor_impls=[mock_perceptor_impl],
        redis_url="redis://localhost:6379",
        input_topic="test.perceptor.input",
        output_topic="test.perceptor.output",
        consumer_group="test-group",
        consumer_name="test-consumer",
    )

    await processor.init()

    # Create a perceive message without obs
    message = EventMessage(
        message_id="test-msg-1",
        timestamp=0,
        correlation_id="test-corr-1",
        unique_id="test-unique-1",
        data={
            "type": "perceive",
            "obs_spec": None,
            # Missing "obs" parameter
        }
    )

    # Process the message
    result = await processor.process_message(message)

    # Verify the result is an error
    assert result is not None
    assert result["type"] == "error"
    assert "obs is required" in result["error"]
