# hifi_trimmer: changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [[3.1.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v3.1.0)] - [2025-11-06]

### Added

- Add statistics for the total number of reads and bases processed by hifi-trimmer to the summary JSON file.

## [[3.0.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v3.0.0)] - [2025-11-06]

### Added

- Replace the `filter_bam` subcommand with a `trim` command, that takes an input BAM and BED file and writes out a BAM file with trimmed query sequences. It writes to standard output by default - the FASTA output can be recovered by piping into `samtools fasta` or `samtools fastq`.
  - the `--format` option allows direct writing of SAM, BAM or CRAM format
  - Added a `--format-opts` that allows specification of HTSLib flags for formatting: https://www.htslib.org/doc/samtools.html#GLOBAL_COMMAND_OPTIONS

### Changed

- Replaced all underscores in commands with hyphens:
  - `hifi_trimmer` is now `hifi-trimmer`
  - `process_blast` is `process-blast`

## [[2.2.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v2.2.0)] - [2025-11-06]

### Added

- Added the `-p/--preserve-sam-tags` flag to include the RG, BC and QT flags in the output FASTA header from `filter_bam`.

## [[2.1.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v2.1.0)] - [2025-11-06]

### Added

- Added the paths to the BLAST and YAML files to the summary JSON file
- Added the hifi_trimmer version to the summary JSON file

### Fixed
- Move the overall summary entries in the summary JSON file to a sub-dict called "summary"

## [[2.0.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v2.0.0)] - [2025-11-06]

### Fixed
- Refactor code under-the-hood to use classes instead of a more functional approach to improve maintanability
- Fixed issue where reads which are trimmed by different adapters on left and right ends were
double-counted in the final summary section.
- Minor refactoring of the code to make navigating the project easier.

## [[1.2.2](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.2.2)] - [2025-07-09]

### Fixed
- Remove extraneous duckdb dependency

## [[1.2.1](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.2.1)] - [2025-07-09]

### Fixed
- Fixes a bug where reads which should be discarded due to an end adapter are skipped.

## [[1.2.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.2.0)] - [2025-07-09]

### Added
- Adds a `--fastq` option to the `filter_bam` command, which writes the trimmed reads in FASTQ format instead of FASTA

## [[1.1.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.1.0)] - [2025-02-28]

### Added
- `--version` flag
- Default values are included in the `--help` output for options.

### Fixed
- Rare problem encountered where read lengths were over 65,535 - internally, read length and related variables are now typed as UInt32 rather than UInt16.
- Refactored code in the `determine_actions` function to be more readable and to avoid intermittent errors with typing.

## [[1.0.1](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.0.1)] - [2025-02-28]

### Fixed
- Fix rare bug where for some reason the Polars StringCache ends up non-comparable by enabling the global StringCache.
- This reduces performance slightly but it should not be noticable in most cases, unless there are hundreds of millions of rows in the BLAST file.

## [[1.0.0](https://github.com/sanger-tol/hifi-trimmer/releases/tag/v1.0.0)] - [2025-02-27]

Base release of hifi_trimmer.

### Added
- process_blast: Process a BLAST output file and determine which reads to discard or trim, producing a compliant BED file
- filter_bam: Process a BAM file using the BED file to produce a filtered FASTA file
