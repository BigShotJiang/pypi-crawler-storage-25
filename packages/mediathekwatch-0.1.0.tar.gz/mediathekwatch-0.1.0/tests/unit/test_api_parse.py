"""Tests for ARD API teaser parsing edge cases."""

from mediathekwatch.api import ARD


class TestParseTeaserEdgeCases:
    def test_missing_id(self):
        assert ARD._parse_teaser({}) is None

    def test_folge_in_title(self):
        teaser = {
            "id": "x1",
            "title": "Folge 7",
            "links": {"target": {"href": "/video/x1"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_number == 7

    def test_episode_in_title(self):
        teaser = {
            "id": "x2",
            "title": "Episode 12",
            "links": {"target": {"href": "/video/x2"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_number == 12

    def test_parentheses_format(self):
        teaser = {
            "id": "x3",
            "title": "Title (3/10)",
            "links": {"target": {"href": "/video/x3"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_number == 3

    def test_se_ep_format(self):
        teaser = {
            "id": "x4",
            "title": "Something S1/E5",
            "links": {"target": {"href": "/video/x4"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_number == 5

    def test_canonical_url(self):
        teaser = {
            "id": "x5",
            "title": "Episode",
            "links": {"target": {"href": "https://api.ardmediathek.de/page-gateway/pages/wdr/item/x5"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.url == "https://www.ardmediathek.de/video/x5"

    def test_no_links(self):
        teaser = {
            "id": "x6",
            "title": "No Links",
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert "ardmediathek.de" in ep.url

    def test_default_season(self):
        teaser = {
            "id": "x7",
            "title": "Test",
            "links": {"target": {"href": "/video/x7"}},
        }
        ep = ARD._parse_teaser(teaser, default_season=5)
        assert ep is not None
        assert ep.season == 5
