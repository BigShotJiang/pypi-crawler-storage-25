"""Tests for ARTE.tv API integration."""

from unittest.mock import patch

from mediathekwatch.api import ARTE


class TestIsArteUrl:
    def test_arte_url_detected(self):
        assert ARTE.is_arte_url("https://www.arte.tv/de/videos/RC-027434/foo/") is True

    def test_non_arte_url_rejected(self):
        assert ARTE.is_arte_url("https://www.ardmediathek.de/serie/test/...") is False


class TestExtractCollectionId:
    def test_collection_id_from_series_url(self):
        result = ARTE.extract_collection_id("https://www.arte.tv/de/videos/RC-027513/twin-peaks/")
        assert result == "RC-027513"

    def test_collection_id_from_season_url(self):
        result = ARTE.extract_collection_id("https://www.arte.tv/de/videos/RC-027514/twin-peaks-staffel-1/")
        assert result == "RC-027514"

    def test_video_id_from_episode_url(self):
        result = ARTE.extract_collection_id("https://www.arte.tv/de/videos/044639-001-A/twin-peaks-staffel-1-1-8/")
        assert result == "044639-001-A"

    def test_returns_none_for_invalid_url(self):
        result = ARTE.extract_collection_id("https://example.com/not-arte")
        assert result is None


class TestFetchSeriesName:
    def test_fetches_name_from_collection(self):
        with patch("mediathekwatch.api.arte.requests.get") as mock_get:
            mock_get.return_value.json.return_value = {"metadata": {"title": "Twin Peaks"}}
            mock_get.return_value.raise_for_status = lambda: None
            result = ARTE.fetch_series_name("RC-027513")
            assert result == "Twin Peaks"

    def test_returns_none_on_error(self):
        import requests

        with patch("mediathekwatch.api.arte.requests.get", side_effect=requests.RequestException("fail")):
            result = ARTE.fetch_series_name("RC-027513")
            assert result is None


class TestFetchEpisodesFromCollection:
    def test_fetches_from_series_with_seasons(self):
        """Collection with subcollection zones (seasons) returns all episodes."""
        with patch("mediathekwatch.api.arte.requests.get") as mock_get:
            mock_get.return_value.json.return_value = {
                "zones": [
                    {
                        "code": "collection_subcollection_RC-027513_RC-027514",
                        "content": {
                            "data": [
                                {
                                    "programId": "044639-001-A",
                                    "title": "Twin Peaks - Staffel 1 (1/8)",
                                    "subtitle": "Das Geheimnis von Twin Peaks",
                                    "link": {"url": "https://www.arte.tv/de/videos/044639-001-A/"},
                                    "episodeInfo": {"season": 1, "episode": 1},
                                    "duration": 5409,
                                },
                                {
                                    "programId": "044639-002-A",
                                    "title": "Twin Peaks - Staffel 1 (2/8)",
                                    "subtitle": "Spuren ins Nichts",
                                    "link": {"url": "https://www.arte.tv/de/videos/044639-002-A/"},
                                    "episodeInfo": {"season": 1, "episode": 2},
                                    "duration": 2669,
                                },
                            ]
                        },
                    },
                    {
                        "code": "collection_subcollection_RC-027513_RC-027515",
                        "content": {
                            "data": [
                                {
                                    "programId": "044639-009-A",
                                    "title": "Twin Peaks - Staffel 2 (1/22)",
                                    "subtitle": "Zen, oder die Kunst des Reifenschleuderns",
                                    "link": {"url": "https://www.arte.tv/de/videos/044639-009-A/"},
                                    "episodeInfo": {"season": 2, "episode": 1},
                                    "duration": 2800,
                                },
                            ]
                        },
                    },
                ]
            }
            mock_get.return_value.raise_for_status = lambda: None
            eps = ARTE.fetch_episodes_from_collection("RC-027513")
        assert len(eps) == 3
        assert eps[0].episode_id == "044639-001-A"
        assert eps[0].season == 1
        assert eps[0].episode_number == 1
        assert eps[1].episode_id == "044639-002-A"
        assert eps[2].season == 2

    def test_fetches_from_single_season_collection(self):
        """Collection without subcollections has episodes directly in videos zone."""
        with patch("mediathekwatch.api.arte.requests.get") as mock_get:
            mock_get.return_value.json.return_value = {
                "zones": [
                    {
                        "code": "collection_videos_RC-027434",
                        "content": {
                            "data": [
                                {
                                    "programId": "129426-001-A",
                                    "title": "Science Fiction Revolution",
                                    "subtitle": "Die Pioniere",
                                    "link": {"url": "https://www.arte.tv/de/videos/129426-001-A/"},
                                    "episodeInfo": {"season": 1, "episode": 1},
                                    "duration": 3180,
                                },
                            ]
                        },
                    }
                ]
            }
            mock_get.return_value.raise_for_status = lambda: None
            eps = ARTE.fetch_episodes_from_collection("RC-027434")
        assert len(eps) == 1
        assert eps[0].episode_id == "129426-001-A"
        assert eps[0].title == "Science Fiction Revolution - Die Pioniere"

    def test_error_returns_empty(self):
        import requests

        with patch("mediathekwatch.api.arte.requests.get", side_effect=requests.RequestException("fail")):
            eps = ARTE.fetch_episodes_from_collection("RC-027513")
            assert eps == []


class TestParseEmacItem:
    def test_basic_parsing(self):
        item = {
            "programId": "044639-001-A",
            "title": "Twin Peaks - Staffel 1 (1/8)",
            "subtitle": "Das Geheimnis von Twin Peaks",
            "link": {"url": "https://www.arte.tv/de/videos/044639-001-A/"},
            "episodeInfo": {"season": 1, "episode": 1},
            "duration": 5409,
        }
        ep = ARTE._parse_emac_item(item)
        assert ep is not None
        assert ep.episode_id == "044639-001-A"
        assert ep.title == "Twin Peaks - Staffel 1 (1/8) - Das Geheimnis von Twin Peaks"
        assert ep.season == 1
        assert ep.episode_number == 1
        assert ep.duration == 5409

    def test_parsing_without_episode_info(self):
        item = {
            "programId": "129426-001-A",
            "title": "Science Fiction Revolution",
            "duration": 3180,
        }
        ep = ARTE._parse_emac_item(item)
        assert ep is not None
        assert ep.season == 1
        assert ep.episode_number == 0

    def test_parsing_uses_id_fallback(self):
        """When programId is missing, use 'id' field and extract RC part."""
        item = {"id": "129426-001-A_de"}
        ep = ARTE._parse_emac_item(item)
        assert ep is not None
        assert ep.episode_id == "129426-001-A"
