"""Tests for download helper."""

from unittest.mock import patch

from mediathekwatch.download import download_episode


class TestDownloadEpisode:
    def test_success(self, tmp_path):
        output = tmp_path / "test.mkv"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            result = download_episode("https://example.com/video", output, quiet=True)
        assert result is True

    def test_failure(self, tmp_path):
        output = tmp_path / "test.mkv"
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 1
            mock_run.return_value.stderr = "error"
            result = download_episode("https://example.com/video", output, quiet=True)
        assert result is False

    def test_timeout(self, tmp_path):
        import subprocess

        output = tmp_path / "test.mkv"
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("cmd", 3600)):
            result = download_episode("https://example.com/video", output, quiet=True)
        assert result is False

    def test_ytdlp_not_found(self, tmp_path):
        output = tmp_path / "test.mkv"
        with patch("subprocess.run", side_effect=FileNotFoundError()):
            result = download_episode("https://example.com/video", output, quiet=True)
        assert result is False
