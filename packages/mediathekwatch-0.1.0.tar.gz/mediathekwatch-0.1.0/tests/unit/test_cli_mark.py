"""Tests for mark CLI command."""

from argparse import Namespace
from unittest.mock import patch

import pytest

from mediathekwatch.cli import cmd_mark
from mediathekwatch.database import Database


class TestCliMark:
    def test_mark_specific_episode(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(episode_id="ep1", title="Episode 1", season=1, episode_number=1, url="https://a.de")

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]):
            args = Namespace(db=db_path, series=str(sid), season=1, episode=1, target=None)
            cmd_mark(args)

        captured = capsys.readouterr()
        assert "Marked:" in captured.out

        db = Database(db_path)
        assert db.is_episode_downloaded("ep1")
        db.close()

    def test_mark_season(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        eps = [
            Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de"),
            Episode(episode_id="ep2", title="E2", season=1, episode_number=2, url="https://a.de"),
        ]

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=eps):
            args = Namespace(db=db_path, series=str(sid), season=1, episode=None, target=None)
            cmd_mark(args)

        captured = capsys.readouterr()
        assert "Marked 2 episode(s)" in captured.out

    def test_mark_all_episodes(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        eps = [
            Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de"),
            Episode(episode_id="ep2", title="E2", season=2, episode_number=1, url="https://a.de"),
        ]

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=eps):
            args = Namespace(db=db_path, series=str(sid), season=None, episode=None, target=None)
            cmd_mark(args)

        captured = capsys.readouterr()
        assert "Marked 2 episode(s)" in captured.out

    def test_mark_missing_series_by_name(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, series="Missing", season=1, episode=1, target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_mark(args)
        assert excinfo.value.code == 1

    def test_mark_missing_episode(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[]):
            args = Namespace(db=db_path, series=str(sid), season=1, episode=99, target=None)
            with pytest.raises(SystemExit) as excinfo:
                cmd_mark(args)
            assert excinfo.value.code == 1

    def test_mark_fetch_error(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", side_effect=Exception("fail")):
            args = Namespace(db=db_path, series=str(sid), season=1, episode=None, target=None)
            with pytest.raises(SystemExit) as excinfo:
                cmd_mark(args)
            assert excinfo.value.code == 1

    def test_mark_series_not_found_by_id(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, series="999", season=1, episode=1, target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_mark(args)
        assert excinfo.value.code == 1

    def test_mark_no_show_id(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://invalid.url")
        db.close()

        args = Namespace(db=db_path, series=str(sid), season=1, episode=1, target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_mark(args)
        assert excinfo.value.code == 1

    def test_mark_with_target_override(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(episode_id="ep1", title="Episode 1", season=1, episode_number=1, url="https://a.de")
        target = tmp_path / "override"

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]):
            args = Namespace(db=db_path, series=str(sid), season=1, episode=1, target=str(target))
            cmd_mark(args)

        captured = capsys.readouterr()
        assert "Marked:" in captured.out
