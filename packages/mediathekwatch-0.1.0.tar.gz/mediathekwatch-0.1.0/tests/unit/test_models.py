"""Tests for data models."""

from datetime import datetime

from mediathekwatch.models import Episode, Group, Series


class TestEpisode:
    def test_basic(self):
        ep = Episode(
            episode_id="abc123",
            title="Test Episode",
            season=2,
            episode_number=5,
            url="https://example.com",
        )
        assert ep.episode_id == "abc123"
        assert ep.season == 2
        assert ep.episode_number == 5
        assert ep.aired_date is None
        assert ep.duration is None


class TestGroup:
    def test_basic(self):
        g = Group(group_id=2, name="TV Shows", target_folder="/mnt/tv")
        assert g.group_id == 2
        assert g.name == "TV Shows"
        assert g.target_folder == "/mnt/tv"


class TestSeries:
    def test_basic(self):
        s = Series(
            series_id=1,
            name="Test Show",
            mediathek_url="https://example.com",
            added_date=datetime.now(),
        )
        assert s.series_id == 1
        assert s.name == "Test Show"
        assert s.last_checked is None
        assert s.group_id == 1

    def test_with_group_id(self):
        s = Series(
            series_id=1,
            name="Test Show",
            mediathek_url="https://example.com",
            added_date=datetime.now(),
            group_id=3,
        )
        assert s.group_id == 3
