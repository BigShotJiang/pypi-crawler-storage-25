"""Tests for download error paths."""

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from mediathekwatch.download import download_episode


def _make_popen_mock(returncode=0, lines=None):
    """Create a mock subprocess.Popen that supports context manager."""
    stdout_mock = MagicMock()
    stdout_mock.readline.side_effect = lines if lines else ["line\n", ""]

    proc = MagicMock()
    proc.returncode = returncode
    proc.stdout = stdout_mock
    proc.wait.return_value = returncode
    proc.__enter__ = MagicMock(return_value=proc)
    proc.__exit__ = MagicMock(return_value=None)

    return proc


class TestDownloadErrors:
    def test_download_streaming_success(self):
        proc = _make_popen_mock(returncode=0, lines=["line1\n", "line2\n", ""])
        with patch("mediathekwatch.download.subprocess.Popen", return_value=proc):
            result = download_episode("https://example.com", Path("/tmp/test.mkv"), quiet=False)
            assert result is True

    def test_download_streaming_failure(self):
        proc = _make_popen_mock(returncode=1, lines=["error\n", ""])
        with patch("mediathekwatch.download.subprocess.Popen", return_value=proc):
            result = download_episode("https://example.com", Path("/tmp/test.mkv"), quiet=False)
            assert result is False

    def test_download_timeout(self):
        with patch(
            "mediathekwatch.download.subprocess.run",
            side_effect=subprocess.TimeoutExpired("cmd", 30),
        ):
            result = download_episode("https://example.com", Path("/tmp/test.mkv"), quiet=True)
            assert result is False

    def test_download_not_found(self):
        with patch(
            "mediathekwatch.download.subprocess.run",
            side_effect=FileNotFoundError("yt-dlp not found"),
        ):
            result = download_episode("https://example.com", Path("/tmp/test.mkv"), quiet=True)
            assert result is False
