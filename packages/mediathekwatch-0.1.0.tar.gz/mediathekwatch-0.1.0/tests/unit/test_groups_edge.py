"""Tests for group command edge cases."""

from argparse import Namespace

import pytest

from mediathekwatch.cli import cmd_group_delete, cmd_group_list, cmd_group_update, cmd_set_group
from mediathekwatch.database import Database


class TestGroupDeleteEdge:
    def test_delete_group_by_name(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, identifier="TV")
        cmd_group_delete(args)
        captured = capsys.readouterr()
        assert "Deleted" in captured.out

    def test_delete_missing_group_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, identifier="Missing")
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_delete(args)
        assert excinfo.value.code == 1


class TestGroupUpdateEdge:
    def test_update_group_name_duplicate_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_group("TV", "/mnt/tv")
        db.add_group("Movies", "/mnt/movies")
        db.close()

        args = Namespace(db=db_path, identifier="TV", name="Movies", target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_update(args)
        assert excinfo.value.code == 1


class TestGroupListEdge:
    def test_list_groups_only_default(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path)
        cmd_group_list(args)
        captured = capsys.readouterr()
        assert "default" in captured.out


class TestSetGroupEdge:
    def test_set_group_series_by_id_not_found(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://a.de")
        db.close()

        args = Namespace(db=db_path, series="999", group="default")
        with pytest.raises(SystemExit) as excinfo:
            cmd_set_group(args)
        assert excinfo.value.code == 1
