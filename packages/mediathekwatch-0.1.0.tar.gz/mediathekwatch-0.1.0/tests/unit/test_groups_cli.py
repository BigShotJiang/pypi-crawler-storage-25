"""Tests for group CLI commands."""

from argparse import Namespace
from unittest.mock import patch

import pytest

from mediathekwatch.cli import (
    cmd_group_create,
    cmd_group_delete,
    cmd_group_list,
    cmd_group_update,
    cmd_set_group,
)
from mediathekwatch.database import Database


class TestCliGroupCreate:
    def test_create_group(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, name="TV", target="/mnt/tv")
        cmd_group_create(args)
        captured = capsys.readouterr()
        assert "Created group 'TV'" in captured.out

        db = Database(db_path)
        groups = db.list_groups()
        assert len(groups) == 2  # default + TV
        db.close()

    def test_create_duplicate_fails(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, name="TV", target="/mnt/tv2")
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_create(args)
        assert excinfo.value.code == 1


class TestCliGroupUpdate:
    def test_update_name(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, identifier=str(gid), name="Shows", target=None)
        cmd_group_update(args)
        captured = capsys.readouterr()
        assert "Updated" in captured.out

        db = Database(db_path)
        group = db.get_group(gid)
        assert group.name == "Shows"
        db.close()

    def test_update_target(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, identifier="TV", name=None, target="/mnt/shows")
        cmd_group_update(args)

        db = Database(db_path)
        group = db.get_group(gid)
        assert group.target_folder == "/mnt/shows"
        db.close()

    def test_update_nothing_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, identifier=str(gid), name=None, target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_update(args)
        assert excinfo.value.code == 1

    def test_update_missing_group_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, identifier="missing", name="X", target=None)
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_update(args)
        assert excinfo.value.code == 1


class TestCliGroupDelete:
    def test_delete_group(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, identifier=str(gid))
        cmd_group_delete(args)
        captured = capsys.readouterr()
        assert "Deleted group 'TV'" in captured.out

        db = Database(db_path)
        assert db.get_group(gid) is None
        db.close()

    def test_delete_default_group_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, identifier="1")
        with pytest.raises(SystemExit) as excinfo:
            cmd_group_delete(args)
        assert excinfo.value.code == 1


class TestCliGroupList:
    def test_list_groups(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path)
        cmd_group_list(args)
        captured = capsys.readouterr()
        assert "default" in captured.out


class TestCliSetGroup:
    def test_set_group_by_name(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Show", "https://a.de")
        db.close()

        args = Namespace(db=db_path, series="Show", group="TV")
        cmd_set_group(args)
        captured = capsys.readouterr()
        assert "Set series 'Show' to group 'TV'" in captured.out

        db = Database(db_path)
        series = db.get_series(sid)
        assert series.group_id == gid
        db.close()

    def test_set_group_by_id(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Show", "https://a.de")
        db.close()

        args = Namespace(db=db_path, series=str(sid), group=str(gid))
        cmd_set_group(args)
        captured = capsys.readouterr()
        assert "to group 'TV'" in captured.out

    def test_set_group_missing_series_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, series="Missing", group="default")
        with pytest.raises(SystemExit) as excinfo:
            cmd_set_group(args)
        assert excinfo.value.code == 1

    def test_set_group_missing_group_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://a.de")
        db.close()

        args = Namespace(db=db_path, series="Show", group="Missing")
        with pytest.raises(SystemExit) as excinfo:
            cmd_set_group(args)
        assert excinfo.value.code == 1


class TestCliAddWithGroup:
    def test_add_with_group_name(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_group("TV", "/mnt/tv")
        db.close()

        args = Namespace(db=db_path, url="https://a.de", name="Show", group="TV")
        cmd_add(args)

        db = Database(db_path)
        series = db.list_series()
        assert series[0].group_id == 2
        db.close()

    def test_add_with_default_group(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, url="https://a.de", name="Show", group="default")
        cmd_add(args)

        db = Database(db_path)
        series = db.list_series()
        assert series[0].group_id == 1
        db.close()

    def test_add_with_missing_group_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, url="https://a.de", name="Show", group="Missing")
        with pytest.raises(SystemExit) as excinfo:
            cmd_add(args)
        assert excinfo.value.code == 1


class TestCliCheckWithGroups:
    def test_check_rejects_target_with_groups(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_group("TV", "/mnt/tv")
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        args = Namespace(db=db_path, target="/some/path", silent=False)
        with pytest.raises(SystemExit) as excinfo:
            cmd_check(args)
        assert excinfo.value.code == 1

    def test_check_allows_target_without_groups(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[]):
            args = Namespace(db=db_path, target="/some/path", silent=False)
            cmd_check(args)


from mediathekwatch.cli import cmd_add, cmd_check  # noqa: E402
