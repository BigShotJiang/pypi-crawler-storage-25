"""Tests for API error paths and edge cases."""

from unittest.mock import patch

import pytest
import requests

from mediathekwatch.api import ARD, ARTE


class TestFetchSeriesName:
    def test_fetch_series_name_top_level(self):
        with patch("mediathekwatch.api.ard.ARD._fetch_page", return_value={"title": "  Test Show  "}):
            assert ARD.fetch_series_name("show-id") == "Test Show"

    def test_fetch_series_name_links_self(self):
        with patch(
            "mediathekwatch.api.ard.ARD._fetch_page",
            return_value={"links": {"self": {"title": "  Link Show  "}}},
        ):
            assert ARD.fetch_series_name("show-id") == "Link Show"

    def test_fetch_series_name_teaser_show(self):
        with patch(
            "mediathekwatch.api.ard.ARD._fetch_page",
            return_value={"teasers": [{"show": {"title": "  Teaser Show  "}}]},
        ):
            assert ARD.fetch_series_name("show-id") == "Teaser Show"

    def test_fetch_series_name_no_title(self):
        with patch("mediathekwatch.api.ard.ARD._fetch_page", return_value={}):
            assert ARD.fetch_series_name("show-id") is None

    def test_fetch_series_name_error(self):
        with patch("mediathekwatch.api.ard.ARD._fetch_page", side_effect=Exception("fail")):
            assert ARD.fetch_series_name("show-id") is None


class TestFetchPageError:
    def test_fetch_page_raises(self):
        with patch("mediathekwatch.api.ard.requests.get", side_effect=requests.RequestException("fail")):
            with pytest.raises(requests.RequestException):
                ARD._fetch_page("show-id", 1)


class TestFetchEpisodesError:
    def test_fetch_episodes_page_error(self):
        with patch("mediathekwatch.api.ard.ARD._fetch_page", side_effect=requests.RequestException("fail")):
            episodes = ARD.fetch_episodes("show-id")
            assert episodes == []


class TestProcessWidgetTeasers:
    def test_empty_widget_teasers_skipped(self):
        widgets = [{"title": "Staffel 1", "teasers": []}]
        result = ARD._process_widget_teasers(widgets, set(), None)
        assert result == []

    def test_duplicate_episode_skipped(self):

        seen = {"ep1"}
        widgets = [
            {
                "title": "Staffel 1",
                "teasers": [
                    {"id": "ep1", "title": "T1"},
                ],
            }
        ]
        result = ARD._process_widget_teasers(widgets, seen, None)
        assert result == []


class TestParseTeaserError:
    def test_parse_teaser_raises(self):
        with patch("mediathekwatch.api.ard.ARD._extract_title", side_effect=KeyError("boom")):
            result = ARD._parse_teaser({"id": "123"})
            assert result is None


class TestArteFetchCollectionError:
    def test_fetch_episodes_from_collection_error(self):
        with patch("mediathekwatch.api.arte.requests.get", side_effect=Exception("fail")):
            episodes = ARTE.fetch_episodes_from_collection("RC-014034")
            assert episodes == []


class TestArteParseEmacItem:
    def test_parse_emac_item_no_program_id(self):
        result = ARTE._parse_emac_item({})
        assert result is None

    def test_parse_emac_item_dict_duration(self):

        item = {
            "programId": "123",
            "title": "Test",
            "duration": {"seconds": 3600},
        }
        result = ARTE._parse_emac_item(item)
        assert result is not None
        assert result.duration == 3600


class TestArteFetchSingleVideo:
    def test_fetch_single_video_error(self):
        with patch("mediathekwatch.api.arte.requests.get", side_effect=Exception("fail")):
            result = ARTE.fetch_single_video("123456-001-A")
            assert result is None

    def test_fetch_single_video_success(self):

        mock_data = {
            "data": {
                "attributes": {
                    "metadata": {
                        "providerId": "123456-001-A",
                        "title": "Test",
                        "duration": {"seconds": 3600},
                    },
                    "streams": [{"url": "https://video.mp4"}],
                }
            }
        }
        with patch("mediathekwatch.api.arte.requests.get") as mock_get:
            mock_get.return_value.json.return_value = mock_data
            mock_get.return_value.raise_for_status = lambda: None
            result = ARTE.fetch_single_video("123456-001-A")
            assert result is not None
            assert result.title == "Test"


class TestArteParseSingleConfig:
    def test_parse_single_config_error(self):
        result = ARTE._parse_single_config({"data": {"attributes": {"metadata": {"providerId": None}, "streams": []}}}, "de")
        assert result is None

    def test_parse_single_config_no_streams(self):
        mock_data = {
            "data": {
                "attributes": {
                    "metadata": {
                        "providerId": "123456-001-A",
                        "title": "Test",
                    },
                    "streams": [],
                }
            }
        }
        result = ARTE._parse_single_config(mock_data, "de")
        assert result is not None
        assert result.url == ""
