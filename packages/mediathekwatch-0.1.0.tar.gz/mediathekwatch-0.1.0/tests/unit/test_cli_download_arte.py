"""Tests for ARTE download paths in CLI."""

from argparse import Namespace
from unittest.mock import patch

import pytest

from mediathekwatch.cli import cmd_download


class TestCliDownloadArte:
    def test_download_arte_collection(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        target = tmp_path / "output"
        target.mkdir()

        episodes = [Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")]

        with (
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=True),
            patch("mediathekwatch.cli.ARTE.extract_collection_id", return_value="RC-014034"),
            patch("mediathekwatch.cli.ARTE.fetch_series_name", return_value="Karambolage"),
            patch("mediathekwatch.cli.ARTE.fetch_episodes_from_collection", return_value=episodes),
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://arte.tv/de/videos/RC-014034/", target=str(target))
            cmd_download(args)

        captured = capsys.readouterr()
        assert "Downloaded 1" in captured.out

    def test_download_arte_direct_video(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        target = tmp_path / "output"
        target.mkdir()

        episodes = [Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")]

        with (
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=True),
            patch("mediathekwatch.cli.ARTE.extract_collection_id", return_value="123456-001-A"),
            patch("mediathekwatch.cli.ARTE.fetch_series_name", return_value=None),
            patch("mediathekwatch.cli.ARTE.fetch_single_video", return_value=episodes[0]),
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://arte.tv/de/videos/123456-001-A/", target=str(target))
            cmd_download(args)

        captured = capsys.readouterr()
        assert "Downloaded 1" in captured.out

    def test_download_arte_no_collection_id(self, tmp_path):
        target = tmp_path / "output"
        target.mkdir()

        with (
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=True),
            patch("mediathekwatch.cli.ARTE.extract_collection_id", return_value=None),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://arte.tv/de/videos/invalid/", target=str(target))
            with pytest.raises(SystemExit) as excinfo:
                cmd_download(args)
            assert excinfo.value.code == 1

    def test_download_arte_collection_fetch_error(self, tmp_path):
        target = tmp_path / "output"
        target.mkdir()

        with (
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=True),
            patch("mediathekwatch.cli.ARTE.extract_collection_id", return_value="RC-014034"),
            patch("mediathekwatch.cli.ARTE.fetch_series_name", return_value="Karambolage"),
            patch("mediathekwatch.cli.ARTE.fetch_episodes_from_collection", side_effect=Exception("fail")),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://arte.tv/de/videos/RC-014034/", target=str(target))
            with pytest.raises(SystemExit) as excinfo:
                cmd_download(args)
            assert excinfo.value.code == 1

    def test_download_arte_video_fetch_error(self, tmp_path):
        target = tmp_path / "output"
        target.mkdir()

        with (
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=True),
            patch("mediathekwatch.cli.ARTE.extract_collection_id", return_value="123456-001-A"),
            patch("mediathekwatch.cli.ARTE.fetch_series_name", return_value="Name"),
            patch("mediathekwatch.cli.ARTE.fetch_single_video", side_effect=Exception("fail")),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://arte.tv/de/videos/123456-001-A/", target=str(target))
            with pytest.raises(SystemExit) as excinfo:
                cmd_download(args)
            assert excinfo.value.code == 1

    def test_download_no_episodes(self, capsys, tmp_path):
        target = tmp_path / "output"
        target.mkdir()

        with (
            patch("mediathekwatch.cli.ARD.extract_show_id", return_value="show-id"),
            patch("mediathekwatch.cli.ARD.fetch_series_name", return_value="Test"),
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[]),
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=False),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://ard.de/serie/test", target=str(target))
            cmd_download(args)

        captured = capsys.readouterr()
        assert "No episodes found" in captured.out

    def test_download_fail_print(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        target = tmp_path / "output"
        target.mkdir()

        episodes = [Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")]

        with (
            patch("mediathekwatch.cli.ARD.extract_show_id", return_value="show-id"),
            patch("mediathekwatch.cli.ARD.fetch_series_name", return_value="Test"),
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=episodes),
            patch("mediathekwatch.cli.ARTE.is_arte_url", return_value=False),
            patch("mediathekwatch.cli.download_episode", return_value=False),
        ):
            args = Namespace(db=tmp_path / "test.db", url="https://ard.de/serie/test", target=str(target))
            cmd_download(args)

        captured = capsys.readouterr()
        assert "Failed!" in captured.err
