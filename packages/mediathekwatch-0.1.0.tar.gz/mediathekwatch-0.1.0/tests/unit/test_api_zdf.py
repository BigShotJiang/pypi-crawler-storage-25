"""Tests for ZDF Mediathek API client."""

from unittest.mock import MagicMock, patch

from mediathekwatch.api import ZDF


class TestIsZdfUrl:
    def test_zdf_de_url(self):
        assert ZDF.is_zdf_url("https://www.zdf.de/reportagen/funk-collection-funk-12387-106")

    def test_ard_url(self):
        assert not ZDF.is_zdf_url("https://www.ardmediathek.de/serie/feuer-und-flamme")

    def test_arte_url(self):
        assert not ZDF.is_zdf_url("https://www.arte.tv/de/videos/RC-014328")


class TestExtractCanonicalId:
    def test_extracts_from_series_url(self):
        url = "https://www.zdf.de/reportagen/funk-collection-funk-12387-106"
        assert ZDF.extract_canonical_id(url) == "funk-collection-funk-12387-106"

    def test_extracts_from_deep_path(self):
        url = "https://www.zdf.de/serien/die-anstalt/die-anstalt-100"
        assert ZDF.extract_canonical_id(url) == "die-anstalt-100"

    def test_returns_none_for_empty_path(self):
        assert ZDF.extract_canonical_id("https://www.zdf.de/") is None


class TestParseEpisodeNode:
    def test_basic(self):
        node = {
            "id": "funk_video_funk_2182140",
            "title": "Kontrolle von Berliner Polizei - HUNDERTZEHN",
            "subtitle": "",
            "sharingUrl": "https://www.zdf.de/video/reportagen/funk-collection-funk-12387-106/funk-kontrolle-von-berliner-polizei---hundertzehn-102",
            "editorialDate": "2026-05-04T16:00:00.000000+00:00",
            "episodeInfo": {"seasonNumber": 1, "episodeNumber": 40},
        }
        ep = ZDF._parse_episode_node(node)
        assert ep is not None
        assert ep.episode_id == "funk_video_funk_2182140"
        assert ep.title == "Kontrolle von Berliner Polizei - HUNDERTZEHN"
        assert ep.season == 1
        assert ep.episode_number == 40
        assert ep.url == node["sharingUrl"]

    def test_with_subtitle(self):
        node = {
            "id": "vid_1",
            "title": "Der Fall",
            "subtitle": "Ein spannender Fall",
            "sharingUrl": "https://www.zdf.de/video/der-fall-100",
            "episodeInfo": {"seasonNumber": 2, "episodeNumber": 5},
        }
        ep = ZDF._parse_episode_node(node)
        assert ep is not None
        assert ep.title == "Der Fall - Ein spannender Fall"
        assert ep.season == 2
        assert ep.episode_number == 5

    def test_no_episode_info(self):
        node = {
            "id": "vid_2",
            "title": "Sonderfolge",
            "sharingUrl": "https://www.zdf.de/video/sonderfolge-100",
        }
        ep = ZDF._parse_episode_node(node)
        assert ep is not None
        assert ep.season == 1
        assert ep.episode_number == 0

    def test_missing_id_returns_none(self):
        node = {"title": "No ID"}
        assert ZDF._parse_episode_node(node) is None

    def test_empty_subtitle_ignored(self):
        node = {
            "id": "vid_3",
            "title": "Title",
            "subtitle": "",
            "sharingUrl": "https://www.zdf.de/video/title-100",
        }
        ep = ZDF._parse_episode_node(node)
        assert ep is not None
        assert ep.title == "Title"


class TestFetchCollectionOverview:
    @patch("mediathekwatch.api.zdf.requests.get")
    def test_season_based_collection(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "data": {
                    "smartCollectionByCanonical": {
                        "seasons": {
                            "nodes": [
                                {
                                    "episodes": {
                                        "nodes": [
                                            {
                                                "id": "ep1",
                                                "title": "Episode 1",
                                                "sharingUrl": "https://www.zdf.de/video/ep1",
                                                "episodeInfo": {"seasonNumber": 1, "episodeNumber": 1},
                                            }
                                        ],
                                        "pageInfo": {"hasNextPage": False, "endCursor": None},
                                    }
                                }
                            ]
                        }
                    }
                }
            },
            raise_for_status=lambda: None,
        )
        num_seasons, episodes, next_cursor = ZDF._fetch_collection_overview("test-canonical")
        assert num_seasons == 1
        assert len(episodes) == 1
        assert episodes[0].episode_id == "ep1"
        assert next_cursor is None

    @patch("mediathekwatch.api.zdf.requests.get")
    def test_no_seasons(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: {"data": {"smartCollectionByCanonical": None}},
            raise_for_status=lambda: None,
        )
        num_seasons, episodes, next_cursor = ZDF._fetch_collection_overview("test-canonical")
        assert num_seasons == 0
        assert episodes == []
        assert next_cursor is None

    @patch("mediathekwatch.api.zdf.requests.get")
    def test_api_error(self, mock_get):
        mock_get.side_effect = Exception("network error")
        num_seasons, episodes, next_cursor = ZDF._fetch_collection_overview("test-canonical")
        assert num_seasons == 0
        assert episodes == []
        assert next_cursor is None


class TestFetchSeasonEpisodes:
    @patch("mediathekwatch.api.zdf.requests.get")
    def test_fetch_single_page(self, mock_get):
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "data": {
                    "smartCollectionByCanonical": {
                        "seasons": {
                            "nodes": [
                                {
                                    "episodes": {
                                        "nodes": [
                                            {
                                                "id": "ep1",
                                                "title": "Episode 1",
                                                "sharingUrl": "https://www.zdf.de/video/ep1",
                                                "episodeInfo": {"seasonNumber": 1, "episodeNumber": 1},
                                            }
                                        ],
                                        "pageInfo": {"hasNextPage": False, "endCursor": None},
                                    }
                                }
                            ]
                        }
                    }
                }
            },
            raise_for_status=lambda: None,
        )
        episodes, next_cursor = ZDF._fetch_season_episodes("test", 0)
        assert len(episodes) == 1
        assert episodes[0].episode_id == "ep1"
        assert next_cursor is None

    @patch("mediathekwatch.api.zdf.requests.get")
    def test_pagination(self, mock_get):
        responses = [
            {
                "data": {
                    "smartCollectionByCanonical": {
                        "seasons": {
                            "nodes": [
                                {
                                    "episodes": {
                                        "nodes": [
                                            {
                                                "id": "ep1",
                                                "title": "Episode 1",
                                                "sharingUrl": "https://www.zdf.de/video/ep1",
                                                "episodeInfo": {"seasonNumber": 1, "episodeNumber": 1},
                                            }
                                        ],
                                        "pageInfo": {"hasNextPage": True, "endCursor": "cursor1"},
                                    }
                                }
                            ]
                        }
                    }
                }
            },
            {
                "data": {
                    "smartCollectionByCanonical": {
                        "seasons": {
                            "nodes": [
                                {
                                    "episodes": {
                                        "nodes": [
                                            {
                                                "id": "ep2",
                                                "title": "Episode 2",
                                                "sharingUrl": "https://www.zdf.de/video/ep2",
                                                "episodeInfo": {"seasonNumber": 1, "episodeNumber": 2},
                                            }
                                        ],
                                        "pageInfo": {"hasNextPage": False, "endCursor": None},
                                    }
                                }
                            ]
                        }
                    }
                }
            },
        ]
        mock_get.return_value = MagicMock(
            status_code=200,
            json=lambda: responses.pop(0),
            raise_for_status=lambda: None,
        )
        episodes, next_cursor = ZDF._fetch_season_episodes("test", 0)
        assert len(episodes) == 1
        assert episodes[0].episode_id == "ep1"
        assert next_cursor == "cursor1"


class TestFetchEpisodes:
    @patch("mediathekwatch.api.zdf.ZDF._fetch_collection_overview")
    @patch("mediathekwatch.api.zdf.ZDF._fetch_season_episodes")
    def test_fetch_season_based(self, mock_fetch, mock_overview):
        mock_overview.return_value = (
            1,
            [MagicMock(episode_id="ep1"), MagicMock(episode_id="ep2")],
            None,
        )
        episodes = ZDF.fetch_episodes("test-canonical")
        assert len(episodes) == 2
        mock_fetch.assert_not_called()

    @patch("mediathekwatch.api.zdf.ZDF._fetch_collection_overview")
    @patch("mediathekwatch.api.zdf.ZDF._fetch_meta_collection_episodes")
    def test_fetch_meta_collection_fallback(self, mock_meta, mock_overview):
        mock_overview.return_value = (0, [], None)
        mock_meta.return_value = (
            [MagicMock(episode_id="ep1")],
            None,
        )
        episodes = ZDF.fetch_episodes("test-canonical")
        assert len(episodes) == 1
        mock_meta.assert_called_with("test_canonical", None)

    @patch("mediathekwatch.api.zdf.ZDF._fetch_collection_overview")
    @patch("mediathekwatch.api.zdf.ZDF._fetch_season_episodes")
    def test_deduplicates(self, mock_fetch, mock_overview):
        mock_overview.return_value = (1, [MagicMock(episode_id="ep1")], "cursor1")
        mock_fetch.side_effect = [
            ([MagicMock(episode_id="ep1")], None),  # duplicate
        ]
        episodes = ZDF.fetch_episodes("test")
        assert len(episodes) == 1


class TestFetchSeriesName:
    @patch("mediathekwatch.api.zdf.requests.get")
    def test_extracts_title(self, mock_get):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = lambda: None
        mock_response.iter_content = lambda **kwargs: ["<html><head><title>HUNDERTZEHN | ZDF</title></head><body></body></html>"]
        mock_response.close = lambda: None
        mock_get.return_value = mock_response
        assert ZDF.fetch_series_name("funk-collection-funk-12387-106") == "HUNDERTZEHN"

    @patch("mediathekwatch.api.zdf.requests.get")
    def test_cleans_zdfmediathek_suffix(self, mock_get):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = lambda: None
        mock_response.iter_content = lambda **kwargs: ["<html><head><title>Die Anstalt - ZDFmediathek</title></head><body></body></html>"]
        mock_response.close = lambda: None
        mock_get.return_value = mock_response
        assert ZDF.fetch_series_name("die-anstalt") == "Die Anstalt"

    @patch("mediathekwatch.api.zdf.requests.get")
    def test_error_returns_none(self, mock_get):
        mock_get.side_effect = Exception("timeout")
        assert ZDF.fetch_series_name("test") is None
