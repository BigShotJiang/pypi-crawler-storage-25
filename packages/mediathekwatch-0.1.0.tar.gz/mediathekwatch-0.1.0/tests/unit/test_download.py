"""Tests for download utilities."""

from mediathekwatch.download import generate_filename, sanitize_filename


class TestSanitizeFilename:
    def test_basic(self):
        assert sanitize_filename("Hello World") == "Hello World"

    def test_umlauts_preserved(self):
        assert sanitize_filename("Feuer und Flamme") == "Feuer und Flamme"
        assert sanitize_filename("März") == "März"
        assert sanitize_filename("Größe") == "Größe"
        assert sanitize_filename("Über") == "Über"
        assert sanitize_filename("Straße") == "Straße"

    def test_invalid_chars(self):
        assert sanitize_filename("Hello: World") == "Hello World"
        assert sanitize_filename("A/B Test") == "AB Test"


class TestGenerateFilename:
    def test_format(self):
        result = generate_filename("Feuer und Flamme", 11, 5, "Der neue Fall")
        assert result == "Feuer und Flamme - S11E05 - Der neue Fall.mkv"

    def test_padding(self):
        result = generate_filename("Test", 1, 1, "Pilot")
        assert result == "Test - S01E01 - Pilot.mkv"
