"""Tests for CLI check and redownload commands."""

import pytest
from argparse import Namespace
from unittest.mock import patch

from mediathekwatch.cli import cmd_check, cmd_redownload
from mediathekwatch.database import Database


class TestCliCheck:
    def test_check_no_series(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, target=str(tmp_path))
        cmd_check(args)
        captured = capsys.readouterr()
        assert "No series" in captured.out

    def test_check_with_series_no_episodes(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[]):
            args = Namespace(db=db_path, target=str(tmp_path))
            cmd_check(args)

        captured = capsys.readouterr()
        assert "No new episodes" in captured.out

    def test_check_downloads_new(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(
            episode_id="ep1",
            title="Episode 1",
            season=1,
            episode_number=1,
            url="https://example.com",
        )

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]):
            with patch("mediathekwatch.cli.download_episode", return_value=True):
                args = Namespace(db=db_path, target=str(tmp_path))
                cmd_check(args)

        captured = capsys.readouterr()
        assert "New episode" in captured.out


class TestCliRedownload:
    def test_redownload_by_id(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(
            episode_id="ep1",
            title="Episode 1",
            season=1,
            episode_number=1,
            url="https://example.com",
        )

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]):
            with patch("mediathekwatch.cli.download_episode", return_value=True):
                args = Namespace(db=db_path, target=str(tmp_path), series=str(sid), season=1, episode=1)
                cmd_redownload(args)

        captured = capsys.readouterr()
        assert "Download complete" in captured.out

    def test_redownload_by_name(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(
            episode_id="ep1",
            title="Episode 1",
            season=1,
            episode_number=1,
            url="https://example.com",
        )

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]):
            with patch("mediathekwatch.cli.download_episode", return_value=True):
                args = Namespace(db=db_path, target=str(tmp_path), series="Show", season=1, episode=1)
                cmd_redownload(args)

        captured = capsys.readouterr()
        assert "Download complete" in captured.out

    def test_redownload_missing_series_name(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, target=str(tmp_path), series="Missing", season=1, episode=1)

        with pytest.raises(SystemExit) as excinfo:
            cmd_redownload(args)
        assert excinfo.value.code == 1

    def test_redownload_missing_episode(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[]):
            args = Namespace(db=db_path, target=str(tmp_path), series=str(sid), season=99, episode=99)

            with pytest.raises(SystemExit) as excinfo:
                cmd_redownload(args)
            assert excinfo.value.code == 1
