"""Tests for ARD API fetch and pagination."""

from unittest.mock import patch

import pytest

from mediathekwatch.api import ARD


class TestFetchPage:
    def test_success(self):
        with patch("requests.get") as mock_get:
            mock_get.return_value.json.return_value = {"widgets": []}
            mock_get.return_value.raise_for_status = lambda: None
            result = ARD._fetch_page("show123")
        assert result == {"widgets": []}

    def test_error(self):
        import requests

        with patch("requests.get", side_effect=requests.RequestException("fail")):
            with pytest.raises(requests.RequestException):
                ARD._fetch_page("show123")


class TestFetchEpisodes:
    def test_single_page(self):
        with patch.object(ARD, "_fetch_page") as mock_fetch:
            mock_fetch.return_value = {
                "widgets": [
                    {
                        "teasers": [
                            {
                                "id": "ep1",
                                "title": "Episode 1",
                                "links": {"target": {"href": "/video/ep1"}},
                            }
                        ]
                    }
                ],
                "pagination": {"totalElements": 1, "pageNumber": 1, "pageSize": 100},
            }
            eps = ARD.fetch_episodes("show123")
        assert len(eps) == 1
        assert eps[0].episode_id == "ep1"

    def test_pagination(self):
        def side_effect(show_id, page, page_size=100):
            if page == 1:
                return {
                    "widgets": [
                        {
                            "teasers": [
                                {
                                    "id": "ep1",
                                    "title": "E1",
                                    "links": {"target": {"href": "/video/ep1"}},
                                }
                            ]
                        }
                    ],
                    "pagination": {
                        "totalElements": 2,
                        "pageNumber": 1,
                        "pageSize": 1,
                    },
                }
            elif page == 2:
                return {
                    "widgets": [
                        {
                            "teasers": [
                                {
                                    "id": "ep2",
                                    "title": "E2",
                                    "links": {"target": {"href": "/video/ep2"}},
                                }
                            ]
                        }
                    ],
                    "pagination": {
                        "totalElements": 2,
                        "pageNumber": 2,
                        "pageSize": 1,
                    },
                }
            return {"widgets": [], "pagination": {}}

        with patch.object(ARD, "_fetch_page", side_effect=side_effect):
            eps = ARD.fetch_episodes("show123")
        assert len(eps) == 2
        ids = [e.episode_id for e in eps]
        assert "ep1" in ids
        assert "ep2" in ids

    def test_empty_response(self):
        with patch.object(ARD, "_fetch_page") as mock_fetch:
            mock_fetch.return_value = {"widgets": []}
            eps = ARD.fetch_episodes("show123")
        assert eps == []

    def test_duplicate_ids_filtered(self):
        with patch.object(ARD, "_fetch_page") as mock_fetch:
            mock_fetch.return_value = {
                "widgets": [
                    {
                        "teasers": [
                            {
                                "id": "ep1",
                                "title": "E1",
                                "links": {"target": {"href": "/video/ep1"}},
                            },
                            {
                                "id": "ep1",
                                "title": "E1 dup",
                                "links": {"target": {"href": "/video/ep1"}},
                            },
                        ]
                    }
                ],
                "pagination": {"totalElements": 2, "pageNumber": 1, "pageSize": 100},
            }
            eps = ARD.fetch_episodes("show123")
        assert len(eps) == 1

    def test_season_filter(self):
        with patch.object(ARD, "_fetch_page") as mock_fetch:
            mock_fetch.return_value = {
                "widgets": [
                    {
                        "title": "Staffel 5",
                        "teasers": [
                            {
                                "id": "ep1",
                                "title": "E1",
                                "links": {"target": {"href": "/video/ep1"}},
                            }
                        ],
                    }
                ],
                "pagination": {"totalElements": 1, "pageNumber": 1, "pageSize": 100},
            }
            eps = ARD.fetch_episodes("show123", target_season=5)
        assert len(eps) == 1
        assert eps[0].season == 5

    def test_season_filter_no_match(self):
        with patch.object(ARD, "_fetch_page") as mock_fetch:
            mock_fetch.return_value = {
                "widgets": [
                    {
                        "title": "Staffel 3",
                        "teasers": [
                            {
                                "id": "ep1",
                                "title": "E1",
                                "links": {"target": {"href": "/video/ep1"}},
                            }
                        ],
                    }
                ],
                "pagination": {"totalElements": 1, "pageNumber": 1, "pageSize": 100},
            }
            eps = ARD.fetch_episodes("show123", target_season=5)
        assert eps == []

    def test_fetch_error_continues(self):
        import requests

        with patch.object(
            ARD,
            "_fetch_page",
            side_effect=requests.RequestException("fail"),
        ):
            eps = ARD.fetch_episodes("show123")
        assert eps == []
