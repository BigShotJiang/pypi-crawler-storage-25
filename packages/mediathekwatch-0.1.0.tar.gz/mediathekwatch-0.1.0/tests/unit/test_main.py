"""Tests for main entry point."""

from unittest.mock import patch

import pytest

from mediathekwatch.main import main


class TestMain:
    def test_no_args_prints_help(self, capsys):
        with pytest.raises(SystemExit) as excinfo:
            with patch("sys.argv", ["mediathekwatch"]):
                main()
        assert excinfo.value.code == 1
        captured = capsys.readouterr()
        assert "usage" in captured.out

    def test_help(self, capsys):
        with pytest.raises(SystemExit) as excinfo:
            with patch("sys.argv", ["mediathekwatch", "-h"]):
                main()
        assert excinfo.value.code == 0
        captured = capsys.readouterr()
        assert "Monitor ARD Mediathek" in captured.out

    def test_list_command(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        with patch("sys.argv", ["mediathekwatch", "--db", str(db_path), "list"]):
            main()
        captured = capsys.readouterr()
        assert "No series" in captured.out or "ID" in captured.out

    def test_add_command(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        with patch(
            "sys.argv",
            [
                "mediathekwatch",
                "--db",
                str(db_path),
                "add",
                "https://ard.de/serie/test",
                "--name",
                "Test",
            ],
        ):
            main()
        captured = capsys.readouterr()
        assert "Added" in captured.out or "Test" in captured.out

    def test_add_duplicate_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        with patch(
            "sys.argv",
            [
                "mediathekwatch",
                "--db",
                str(db_path),
                "add",
                "https://ard.de/serie/test",
                "--name",
                "Test",
            ],
        ):
            main()

        with pytest.raises(SystemExit) as excinfo:
            with patch(
                "sys.argv",
                [
                    "mediathekwatch",
                    "--db",
                    str(db_path),
                    "add",
                    "https://ard.de/serie/test",
                    "--name",
                    "Test2",
                ],
            ):
                main()
        assert excinfo.value.code == 1

    def test_group_without_subcommand_lists(self, capsys):
        with patch("sys.argv", ["mediathekwatch", "group"]):
            main()
        captured = capsys.readouterr()
        assert "default" in captured.out

    def test_remove_command(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        with patch(
            "sys.argv",
            [
                "mediathekwatch",
                "--db",
                str(db_path),
                "add",
                "https://ard.de/serie/test",
                "--name",
                "Test",
            ],
        ):
            main()

        with patch("sys.argv", ["mediathekwatch", "--db", str(db_path), "remove", "1"]):
            main()
        captured = capsys.readouterr()
        assert "Removed" in captured.out
