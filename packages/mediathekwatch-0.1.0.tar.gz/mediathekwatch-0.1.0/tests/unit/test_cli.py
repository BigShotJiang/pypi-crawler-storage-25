"""Tests for CLI handlers."""

from argparse import Namespace
from unittest.mock import patch

from mediathekwatch.cli import cmd_add, cmd_download, cmd_list, cmd_remove
from mediathekwatch.database import Database


class TestCliAdd:
    def test_add_series(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, url="https://ard.de/serie/test", name="Test Show")
        cmd_add(args)
        db = Database(db_path)
        series = db.list_series()
        assert len(series) == 1
        assert series[0].name == "Test Show"
        db.close()

    def test_add_duplicate_fails(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Test", "https://ard.de/serie/test")
        db.close()
        import sys
        from io import StringIO

        err = StringIO()
        old_err = sys.stderr
        sys.stderr = err
        args = Namespace(db=db_path, url="https://ard.de/serie/test", name="Test 2")
        try:
            cmd_add(args)
            assert False, "Should have exited"
        except SystemExit as e:
            assert e.code == 1
        sys.stderr = old_err

    def test_add_series_auto_name(self, tmp_path):
        """Auto-detect name from API when --name is omitted."""
        db_path = tmp_path / "test.db"
        with (
            patch("mediathekwatch.cli.ARD.extract_show_id") as mock_extract,
            patch("mediathekwatch.cli.ARD.fetch_series_name") as mock_fetch,
        ):
            mock_extract.return_value = "test-show-id"
            mock_fetch.return_value = "Auto Detected Show"
            args = Namespace(db=db_path, url="https://ard.de/serie/test/abc123", name=None)
            cmd_add(args)
        db = Database(db_path)
        series = db.list_series()
        assert len(series) == 1
        assert series[0].name == "Auto Detected Show"
        db.close()

    def test_add_series_auto_name_fails_no_show_id(self, tmp_path):
        """Exit when --name is omitted and show ID cannot be extracted."""
        db_path = tmp_path / "test.db"
        with patch("mediathekwatch.cli.ARD.extract_show_id") as mock_extract:
            mock_extract.return_value = None
            args = Namespace(db=db_path, url="http://invalid.url", name=None)
            import sys
            from io import StringIO

            err = StringIO()
            old_err = sys.stderr
            sys.stderr = err
            try:
                cmd_add(args)
                assert False, "Should have exited"
            except SystemExit as e:
                assert e.code == 1
            sys.stderr = old_err

    def test_add_series_auto_name_fails_no_name(self, tmp_path):
        """Exit when --name is omitted and API returns no name."""
        db_path = tmp_path / "test.db"
        with (
            patch("mediathekwatch.cli.ARD.extract_show_id") as mock_extract,
            patch("mediathekwatch.cli.ARD.fetch_series_name") as mock_fetch,
        ):
            mock_extract.return_value = "show-id"
            mock_fetch.return_value = None
            args = Namespace(db=db_path, url="https://ard.de/serie/test/abc123", name=None)
            import sys
            from io import StringIO

            err = StringIO()
            old_err = sys.stderr
            sys.stderr = err
            try:
                cmd_add(args)
                assert False, "Should have exited"
            except SystemExit as e:
                assert e.code == 1
            sys.stderr = old_err

    def test_add_arte_series_auto_name(self, tmp_path):
        """Auto-detect name from ARTE API when --name is omitted."""
        db_path = tmp_path / "test.db"
        with (
            patch("mediathekwatch.cli.ARTE.extract_collection_id") as mock_extract,
            patch("mediathekwatch.cli.ARTE.fetch_series_name") as mock_fetch,
        ):
            mock_extract.return_value = "RC-014034"
            mock_fetch.return_value = "Karambolage"
            args = Namespace(db=db_path, url="https://www.arte.tv/de/videos/RC-014034/karambolage/", name=None)
            cmd_add(args)
        db = Database(db_path)
        series = db.list_series()
        assert len(series) == 1
        assert series[0].name == "Karambolage"
        db.close()

    def test_add_arte_series_auto_name_fails_no_collection_id(self, tmp_path):
        """Exit when --name is omitted and ARTE collection ID cannot be extracted."""
        db_path = tmp_path / "test.db"
        with patch("mediathekwatch.cli.ARTE.extract_collection_id") as mock_extract:
            mock_extract.return_value = None
            args = Namespace(db=db_path, url="https://www.arte.tv/de/videos/invalid/", name=None)
            import sys
            from io import StringIO

            err = StringIO()
            old_err = sys.stderr
            sys.stderr = err
            try:
                cmd_add(args)
                assert False, "Should have exited"
            except SystemExit as e:
                assert e.code == 1
            sys.stderr = old_err


class TestCliList:
    def test_empty(self, tmp_path, capsys):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path)
        cmd_list(args)
        captured = capsys.readouterr()
        assert "No series" in captured.out

    def test_with_series(self, tmp_path, capsys):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show A", "https://a.de")
        db.close()
        args = Namespace(db=db_path)
        cmd_list(args)
        captured = capsys.readouterr()
        assert "Show A" in captured.out


class TestCliRemove:
    def test_remove_by_id(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://a.de")
        db.close()
        args = Namespace(db=db_path, identifier=str(sid))
        cmd_remove(args)
        db = Database(db_path)
        assert len(db.list_series()) == 0
        db.close()

    def test_remove_by_name(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://a.de")
        db.close()
        args = Namespace(db=db_path, identifier="Show")
        cmd_remove(args)
        db = Database(db_path)
        assert len(db.list_series()) == 0
        db.close()

    def test_remove_missing(self, tmp_path):
        db_path = tmp_path / "test.db"
        import sys
        from io import StringIO

        err = StringIO()
        old_err = sys.stderr
        sys.stderr = err
        args = Namespace(db=db_path, identifier="missing")
        try:
            cmd_remove(args)
            assert False, "Should have exited"
        except SystemExit as e:
            assert e.code == 1
        sys.stderr = old_err


class TestCliDownload:
    def test_download_all_episodes(self, tmp_path):
        """Download all episodes from a URL (no database tracking)."""
        target = tmp_path / "output"
        target.mkdir()
        from mediathekwatch.models import Episode

        episodes = [
            Episode(episode_id="ep1", title="Episode 1", season=1, episode_number=1, url="https://a.de/1"),
            Episode(episode_id="ep2", title="Episode 2", season=1, episode_number=2, url="https://a.de/2"),
        ]

        with (
            patch("mediathekwatch.cli.ARD.extract_show_id") as mock_extract,
            patch("mediathekwatch.cli.ARD.fetch_series_name") as mock_name,
            patch("mediathekwatch.cli.ARD.fetch_episodes") as mock_fetch,
            patch("mediathekwatch.cli.download_episode", return_value=True) as mock_dl,
        ):
            mock_extract.return_value = "show-id-123"
            mock_name.return_value = "Test Series"
            mock_fetch.return_value = episodes

            args = Namespace(db=tmp_path / "test.db", url="https://ard.de/serie/test/abc123", target=str(target))
            cmd_download(args)

        assert mock_dl.call_count == 2

    def test_download_no_show_id(self, tmp_path):
        """Exit when show ID cannot be extracted."""
        target = tmp_path / "output"
        target.mkdir()

        with patch("mediathekwatch.cli.ARD.extract_show_id", return_value=None):
            args = Namespace(db=tmp_path / "test.db", url="http://invalid", target=str(target))
            import sys
            from io import StringIO

            err = StringIO()
            old_err = sys.stderr
            sys.stderr = err
            try:
                cmd_download(args)
                assert False, "Should have exited"
            except SystemExit as e:
                assert e.code == 1
            sys.stderr = old_err

    def test_download_does_not_add_to_db(self, tmp_path):
        """Verify download command does not write to the database."""
        target = tmp_path / "output"
        target.mkdir()

        with (
            patch("mediathekwatch.cli.ARD.extract_show_id") as mock_extract,
            patch("mediathekwatch.cli.ARD.fetch_series_name") as mock_name,
            patch("mediathekwatch.cli.ARD.fetch_episodes") as mock_fetch,
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            mock_extract.return_value = "show-id-123"
            mock_name.return_value = "Test Series"
            mock_fetch.return_value = []

            args = Namespace(db=tmp_path / "test.db", url="https://ard.de/serie/test/abc123", target=str(target))
            cmd_download(args)

        # DB should be empty — no series or episodes recorded
        db = Database(tmp_path / "test.db")
        assert db.list_series() == []
        db.close()
