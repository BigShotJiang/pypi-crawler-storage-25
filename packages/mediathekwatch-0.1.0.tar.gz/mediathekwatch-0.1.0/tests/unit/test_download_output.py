"""Tests for download output path generation."""

from mediathekwatch.download import generate_filename, generate_output_path, sanitize_filename


class TestGenerateOutputPath:
    def test_creates_directories(self, tmp_path):
        result = generate_output_path(tmp_path, "Test Show", 1, 1, "Pilot")
        assert result.parent.exists()
        assert result.parent.name == "S01"
        assert result.name == "Test Show - S01E01 - Pilot.mkv"

    def test_nested_series_folder(self, tmp_path):
        result = generate_output_path(tmp_path, "Feuer und Flamme", 11, 5, "Der neue Fall")
        assert result.parent.parent.name == "Feuer und Flamme"
        assert result.name == "Feuer und Flamme - S11E05 - Der neue Fall.mkv"

    def test_umlauts_preserved(self, tmp_path):
        result = generate_output_path(tmp_path, "Größe", 1, 1, "Über")
        assert "Größe" in str(result)
        assert "Über" in result.name

    def test_long_name_truncated(self, tmp_path):
        long_name = "a" * 150
        result = generate_output_path(tmp_path, long_name, 1, 1, "b" * 150)
        assert len(result.name) < 300


class TestSanitizeFilenameEdgeCases:
    def test_multiple_invalid_chars(self):
        assert sanitize_filename('a<>b:c|d?e*f/g"h\\i') == "abcdefghi"

    def test_truncate(self):
        long = "x" * 200
        result = sanitize_filename(long)
        assert len(result) == 100

    def test_empty(self):
        assert sanitize_filename("") == ""


class TestGenerateFilename:
    def test_large_numbers(self):
        assert generate_filename("Show", 100, 999, "Episode") == "Show - S100E999 - Episode.mkv"
