"""Tests for database layer."""

import pytest

from mediathekwatch.database import Database


class TestDatabase:
    @pytest.fixture
    def db(self, tmp_path):
        db_path = tmp_path / "test.db"
        d = Database(db_path)
        yield d
        d.close()

    def test_add_series(self, db):
        sid = db.add_series("Test Show", "https://example.com/show/123")
        assert sid == 1

    def test_add_duplicate_raises(self, db):
        db.add_series("Test Show", "https://example.com/show/123")
        with pytest.raises(ValueError):
            db.add_series("Test Show 2", "https://example.com/show/123")

    def test_list_series(self, db):
        db.add_series("Show A", "https://a.com")
        db.add_series("Show B", "https://b.com")
        series = db.list_series()
        assert len(series) == 2
        assert series[0].name == "Show A"

    def test_remove_series_by_id(self, db):
        sid = db.add_series("Test", "https://example.com")
        assert db.remove_series(str(sid))
        assert len(db.list_series()) == 0

    def test_remove_series_by_name(self, db):
        db.add_series("Test", "https://example.com")
        assert db.remove_series("Test")
        assert len(db.list_series()) == 0

    def test_mark_episode_downloaded(self, db):
        sid = db.add_series("Test", "https://example.com")
        db.mark_episode_downloaded("ep1", sid, 1, 1, "Pilot", "/tmp/test.mkv")
        assert db.is_episode_downloaded("ep1")
        assert not db.is_episode_downloaded("ep2")

    def test_delete_episode_record(self, db):
        sid = db.add_series("Test", "https://example.com")
        db.mark_episode_downloaded("ep1", sid, 1, 1, "Pilot", "/tmp/test.mkv")
        assert db.delete_episode_record(sid, 1, 1)
        assert not db.is_episode_downloaded("ep1")

    def test_default_group_exists(self, db):
        groups = db.list_groups()
        assert len(groups) == 1
        assert groups[0].name == "default"

    def test_add_group(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        assert gid == 2
        group = db.get_group(gid)
        assert group.name == "TV"
        assert group.target_folder == "/mnt/tv"

    def test_add_group_duplicate_raises(self, db):
        db.add_group("TV", "/mnt/tv")
        with pytest.raises(ValueError):
            db.add_group("TV", "/mnt/tv2")

    def test_update_group(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        db.update_group(gid, name="Shows", target_folder="/mnt/shows")
        group = db.get_group(gid)
        assert group.name == "Shows"
        assert group.target_folder == "/mnt/shows"

    def test_delete_group_moves_series(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Test", "https://example.com", group_id=gid)
        db.delete_group(gid)
        series = db.get_series(sid)
        assert series.group_id == 1
        assert db.get_group(gid) is None

    def test_delete_default_group_raises(self, db):
        with pytest.raises(ValueError):
            db.delete_group(1)

    def test_set_series_group(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Test", "https://example.com")
        assert db.set_series_group(sid, gid)
        series = db.get_series(sid)
        assert series.group_id == gid

    def test_get_series_group_target(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Test", "https://example.com", group_id=gid)
        assert db.get_series_group_target(sid) == "/mnt/tv"

    def test_has_non_default_groups(self, db):
        assert not db.has_non_default_groups()
        db.add_group("TV", "/mnt/tv")
        assert db.has_non_default_groups()

    def test_add_series_with_group(self, db):
        gid = db.add_group("TV", "/mnt/tv")
        sid = db.add_series("Test", "https://example.com", group_id=gid)
        series = db.get_series(sid)
        assert series.group_id == gid
