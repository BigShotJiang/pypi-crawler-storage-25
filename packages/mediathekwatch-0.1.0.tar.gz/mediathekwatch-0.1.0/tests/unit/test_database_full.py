"""More database tests for coverage."""

from mediathekwatch.database import Database


class TestDatabaseCoverage:
    def test_get_series_exists(self, tmp_path):
        db = Database(tmp_path / "test.db")
        sid = db.add_series("Show", "https://example.com")
        s = db.get_series(sid)
        assert s is not None
        assert s.name == "Show"
        db.close()

    def test_get_series_missing(self, tmp_path):
        db = Database(tmp_path / "test.db")
        assert db.get_series(999) is None
        db.close()

    def test_update_last_checked(self, tmp_path):
        db = Database(tmp_path / "test.db")
        sid = db.add_series("Show", "https://example.com")
        assert db.get_series(sid).last_checked is None
        db.update_last_checked(sid)
        assert db.get_series(sid).last_checked is not None
        db.close()

    def test_mark_existing_updates(self, tmp_path):
        db = Database(tmp_path / "test.db")
        sid = db.add_series("Show", "https://example.com")
        db.mark_episode_downloaded("ep1", sid, 1, 1, "Pilot", "/a.mkv")
        db.mark_episode_downloaded("ep1", sid, 1, 1, "Pilot", "/b.mkv")
        assert db.is_episode_downloaded("ep1")
        db.close()

    def test_remove_nonexistent(self, tmp_path):
        db = Database(tmp_path / "test.db")
        assert not db.remove_series("nonexistent")
        assert not db.remove_series("999")
        db.close()
