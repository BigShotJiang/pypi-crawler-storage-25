"""Tests for check CLI edge cases."""

from argparse import Namespace
from unittest.mock import patch

from mediathekwatch.cli import _silenced_output, cmd_check
from mediathekwatch.database import Database


class TestSilencedOutput:
    def test_silenced_output(self):
        import sys

        with _silenced_output():
            print("should not appear", file=sys.stdout)
            print("should not appear", file=sys.stderr)
        # No assertion needed — if it crashes we know it failed


class TestCliCheckFull:
    def test_check_empty_series(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, target=None, silent=False)
        cmd_check(args)
        captured = capsys.readouterr()
        assert "No series" in captured.out

    def test_check_download_fails(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")

        with (
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]),
            patch("mediathekwatch.cli.download_episode", return_value=False),
        ):
            args = Namespace(db=db_path, target=str(tmp_path), silent=False)
            cmd_check(args)

        captured = capsys.readouterr()
        assert "Download failed" in captured.out

    def test_check_silent_mode(self, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")

        with (
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]),
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            args = Namespace(db=db_path, target=str(tmp_path), silent=True)
            cmd_check(args)

    def test_check_no_show_id(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://invalid.url")
        db.close()

        args = Namespace(db=db_path, target=str(tmp_path), silent=False)
        cmd_check(args)

        captured = capsys.readouterr()
        assert "Warning" in captured.out

    def test_check_fetch_error(self, capsys, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", side_effect=Exception("fail")):
            args = Namespace(db=db_path, target=str(tmp_path), silent=False)
            cmd_check(args)

        captured = capsys.readouterr()
        assert "Error fetching" in captured.out
