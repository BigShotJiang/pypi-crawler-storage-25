"""Tests for redownload CLI edge cases."""

from argparse import Namespace
from unittest.mock import patch

import pytest

from mediathekwatch.cli import cmd_redownload
from mediathekwatch.database import Database


class TestCliRedownloadFull:
    def test_redownload_by_name_not_found(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        args = Namespace(db=db_path, target=None, series="Other", season=1, episode=1)
        with pytest.raises(SystemExit) as excinfo:
            cmd_redownload(args)
        assert excinfo.value.code == 1

    def test_redownload_series_id_not_found(self, tmp_path):
        db_path = tmp_path / "test.db"
        args = Namespace(db=db_path, target=None, series="999", season=1, episode=1)
        with pytest.raises(SystemExit) as excinfo:
            cmd_redownload(args)
        assert excinfo.value.code == 1

    def test_redownload_no_show_id(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://invalid.url")
        db.close()

        args = Namespace(db=db_path, target=None, series=str(sid), season=1, episode=1)
        with pytest.raises(SystemExit) as excinfo:
            cmd_redownload(args)
        assert excinfo.value.code == 1

    def test_redownload_fetch_error(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        with patch("mediathekwatch.cli.ARD.fetch_episodes", side_effect=Exception("fail")):
            args = Namespace(db=db_path, target=None, series=str(sid), season=1, episode=1)
            with pytest.raises(SystemExit) as excinfo:
                cmd_redownload(args)
            assert excinfo.value.code == 1

    def test_redownload_delete_record_false(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93")
        db.close()

        mock_ep = Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")

        with (
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]),
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            args = Namespace(db=db_path, target=None, series=str(sid), season=1, episode=1)
            cmd_redownload(args)

        captured = capsys.readouterr()
        assert "not found in database" in captured.out

    def test_redownload_with_group_target(self, capsys, tmp_path):
        from mediathekwatch.models import Episode

        db_path = tmp_path / "test.db"
        db = Database(db_path)
        gid = db.add_group("TV", str(tmp_path / "tv"))
        sid = db.add_series("Show", "https://ard.de/serie/show/Y3JpZDovL3dkci5kZS9zaG93", group_id=gid)
        db.close()

        mock_ep = Episode(episode_id="ep1", title="E1", season=1, episode_number=1, url="https://a.de")

        with (
            patch("mediathekwatch.cli.ARD.fetch_episodes", return_value=[mock_ep]),
            patch("mediathekwatch.cli.download_episode", return_value=True),
        ):
            args = Namespace(db=db_path, target=None, series=str(sid), season=1, episode=1)
            cmd_redownload(args)

        captured = capsys.readouterr()
        assert "Download complete" in captured.out
