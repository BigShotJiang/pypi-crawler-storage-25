"""Shared constants for downloads and filename sanitization."""

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    "Accept": "application/json",
}

# Filename sanitization
INVALID_FILENAME_CHARS = r'[<>:"|?*/\\]'  # chars illegal on Linux/Windows
CONTROL_CHARS = r"[\x00-\x1f]"
WHITESPACE_COLLAPSE = r"\s+"
MAX_FILENAME_LENGTH = 100

# Download
YTDLP_TIMEOUT = 3600
YTDLP_ARGS = [
    "yt-dlp",
    "-t",
    "mkv",
    "--audio-multistreams",
    "--convert-subs",
    "ass",
    "-w",
    "--sub-langs",
    "all",
    "--merge-output-format",
    "mkv",
    "--embed-thumbnail",
    "--embed-subs",
    "--embed-metadata",
    "--embed-info-json",
    "--embed-chapters",
]
