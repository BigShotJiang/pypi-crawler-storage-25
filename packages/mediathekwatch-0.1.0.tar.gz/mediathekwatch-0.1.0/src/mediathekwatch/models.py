"""Data models for ARD Mediathek episodes and series."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Episode:
    """Represents an episode from ARD Mediathek."""

    episode_id: str
    title: str
    season: int
    episode_number: int
    url: str
    aired_date: Optional[str] = None
    duration: Optional[int] = None


@dataclass
class Group:
    """Represents a download target group."""

    group_id: int
    name: str
    target_folder: str


@dataclass
class Series:
    """Represents a monitored series."""

    series_id: int
    name: str
    mediathek_url: str
    added_date: datetime
    last_checked: Optional[datetime] = None
    group_id: int = 1
