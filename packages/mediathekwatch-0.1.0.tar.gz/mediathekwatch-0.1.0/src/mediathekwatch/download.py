"""Download helpers and filename generation."""

import re
import subprocess  # nosec B404
import sys
from pathlib import Path

from mediathekwatch.statics import (
    CONTROL_CHARS,
    INVALID_FILENAME_CHARS,
    MAX_FILENAME_LENGTH,
    WHITESPACE_COLLAPSE,
    YTDLP_ARGS,
    YTDLP_TIMEOUT,
)


def sanitize_filename(name: str) -> str:
    """Sanitize a string for use as a filename.

    Keeps all Unicode letters including umlauts and accented chars (é, è, etc).
    Only removes characters that are invalid on Linux or Windows filesystems.
    """
    # Linux: only / is truly invalid (path separator)
    # Windows: <>|?*/\ are invalid
    # Also strip control characters for safety
    name = re.sub(INVALID_FILENAME_CHARS, "", name)
    name = re.sub(CONTROL_CHARS, "", name)
    name = re.sub(WHITESPACE_COLLAPSE, " ", name)
    name = name.strip()

    if len(name) > MAX_FILENAME_LENGTH:
        name = name[:MAX_FILENAME_LENGTH]

    return name


def generate_filename(series_name: str, season: int, episode_number: int, episode_name: str) -> str:
    """Generate the output filename."""
    series_clean = sanitize_filename(series_name)
    episode_clean = sanitize_filename(episode_name)
    season_str = f"S{season:02d}"
    episode_str = f"E{episode_number:02d}"
    return f"{series_clean} - {season_str}{episode_str} - {episode_clean}.mkv"


def generate_output_path(target_folder: Path, series_name: str, season: int, episode_number: int, episode_name: str) -> Path:
    """Generate the full output path for an episode."""
    series_clean = sanitize_filename(series_name)
    season_str = f"S{season:02d}"
    filename = generate_filename(series_name, season, episode_number, episode_name)
    output_dir = target_folder / series_clean / season_str
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir / filename


def download_episode(url: str, output_path: Path, quiet: bool = False) -> bool:
    """Download an episode using yt-dlp.

    Args:
        url: The URL to download
        output_path: Where to save the file
        quiet: If True, suppress yt-dlp output (for test compatibility)
    """
    cmd = [*YTDLP_ARGS, "-o", str(output_path), url]

    try:
        if quiet:
            # Captured output mode (for tests)
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=YTDLP_TIMEOUT)  # nosec B603
            if result.returncode == 0:
                return True
            else:
                print(f"yt-dlp error: {result.stderr}", file=sys.stderr)
                return False
        else:
            # Real-time streaming mode
            with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as proc:  # nosec B603
                # Stream output in real-time
                while True:
                    line = proc.stdout.readline() if proc.stdout else ""
                    if not line:
                        break
                    print(line, end="")
                proc.wait()
                return proc.returncode == 0
    except subprocess.TimeoutExpired:
        print(f"Download timed out for {url}", file=sys.stderr)
        return False
    except FileNotFoundError:
        print("yt-dlp not found. Please install yt-dlp.", file=sys.stderr)
        return False
