"""Entry point for the ARD Mediathek, ARTE.tv and ZDF Mediathek Monitor CLI."""

import argparse
import sys
from pathlib import Path

from mediathekwatch.cli import (
    cmd_add,
    cmd_check,
    cmd_download,
    cmd_group_create,
    cmd_group_delete,
    cmd_group_list,
    cmd_group_update,
    cmd_list,
    cmd_mark,
    cmd_redownload,
    cmd_remove,
    cmd_set_group,
)

DEFAULT_DB_PATH = Path.home() / ".config" / "mediathekwatch" / "mediathekwatch.db"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Monitor ARD Mediathek, ARTE.tv and ZDF Mediathek series for new episodes and download them.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s add "https://www.ardmediathek.de/serie/feuer-und-flamme/..." --name "Feuer und Flamme"
  %(prog)s add "https://www.zdf.de/reportagen/funk-collection-funk-12387-106" --name "HUNDERTZEHN"
  %(prog)s list
  %(prog)s check --target /mnt/media/TV
  %(prog)s redownload 1 11 5  # Redownload series ID 1, season 11, episode 5
        """,
    )

    parser.add_argument("--db", type=Path, default=DEFAULT_DB_PATH, help=f"Database file path (default: {DEFAULT_DB_PATH})")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    add_parser = subparsers.add_parser("add", help="Add a series to monitor")
    add_parser.add_argument("url", help="ARD Mediathek, ARTE.tv or ZDF Mediathek series URL")
    add_parser.add_argument("--name", help="Series name (auto-fetched if omitted)")
    add_parser.add_argument("--group", default="default", help="Group to assign the series to (default: default)")
    add_parser.set_defaults(func=cmd_add)

    remove_parser = subparsers.add_parser("remove", help="Remove a series from monitoring")
    remove_parser.add_argument("identifier", help="Series ID or name to remove")
    remove_parser.set_defaults(func=cmd_remove)

    list_parser = subparsers.add_parser("list", help="List monitored series")
    list_parser.set_defaults(func=cmd_list)

    check_parser = subparsers.add_parser("check", help="Check for new episodes")
    check_parser.add_argument("--target", default=None, help="Target folder for downloads (default: current directory)")
    check_parser.add_argument("--silent", "-s", action="store_true", help="Suppress all output")
    check_parser.set_defaults(func=cmd_check)

    download_parser = subparsers.add_parser("download", help="Download all episodes from a series URL")
    download_parser.add_argument("url", help="ARD Mediathek, ARTE.tv or ZDF Mediathek series URL")
    download_parser.add_argument("--target", default=".", help="Target folder for downloads (default: current directory)")
    download_parser.set_defaults(func=cmd_download)

    redownload_parser = subparsers.add_parser("redownload", help="Force redownload of an episode")
    redownload_parser.add_argument("series", help="Series ID or name")
    redownload_parser.add_argument("season", type=int, help="Season number")
    redownload_parser.add_argument("episode", type=int, help="Episode number")
    redownload_parser.add_argument("--target", default=None, help="Target folder for downloads (overrides group default)")
    redownload_parser.set_defaults(func=cmd_redownload)

    mark_parser = subparsers.add_parser("mark", help="Mark episodes/seasons as downloaded without downloading")
    mark_parser.add_argument("series", help="Series ID or name")
    mark_parser.add_argument("--season", type=int, help="Mark entire season (optional)")
    mark_parser.add_argument("--episode", type=int, help="Mark specific episode (requires --season)")
    mark_parser.add_argument("--target", default=None, help="Target folder path to record (overrides group default)")
    mark_parser.set_defaults(func=cmd_mark)

    # Group commands
    group_parser = subparsers.add_parser("group", help="Manage download groups")
    group_subparsers = group_parser.add_subparsers(dest="group_command", help="Group subcommands")

    group_create_parser = group_subparsers.add_parser("create", help="Create a new group")
    group_create_parser.add_argument("name", help="Group name")
    group_create_parser.add_argument("--target", required=True, help="Target folder for downloads")
    group_create_parser.set_defaults(func=cmd_group_create)

    group_update_parser = group_subparsers.add_parser("update", help="Update an existing group")
    group_update_parser.add_argument("identifier", help="Group ID or name")
    group_update_parser.add_argument("--name", help="New group name")
    group_update_parser.add_argument("--target", help="New target folder")
    group_update_parser.set_defaults(func=cmd_group_update)

    group_delete_parser = group_subparsers.add_parser("delete", help="Delete a group")
    group_delete_parser.add_argument("identifier", help="Group ID or name")
    group_delete_parser.set_defaults(func=cmd_group_delete)

    group_list_parser = group_subparsers.add_parser("list", help="List all groups")
    group_list_parser.set_defaults(func=cmd_group_list)

    # Set-group command
    set_group_parser = subparsers.add_parser("set-group", help="Set the group for a series")
    set_group_parser.add_argument("series", help="Series ID or name")
    set_group_parser.add_argument("group", help="Group ID or name")
    set_group_parser.set_defaults(func=cmd_set_group)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if not hasattr(args, "func"):
        if args.command == "group":
            cmd_group_list(args)
            return
        group_parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
