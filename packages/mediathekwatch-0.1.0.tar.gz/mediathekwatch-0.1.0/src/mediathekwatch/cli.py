"""CLI command handlers."""

import os
import sys
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Optional

from mediathekwatch.api import ARD, ARTE, ZDF
from mediathekwatch.database import Database
from mediathekwatch.download import download_episode, generate_output_path


def cmd_add(args):
    """Add a series to monitor."""
    db = Database(args.db)
    try:
        name = args.name
        if not name:
            try:
                source, source_id = _classify_url(args.url)
                name = _fetch_series_name_for_source(source, source_id)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
            if not name:
                print("Error: Could not auto-detect series name. Use --name to provide one.", file=sys.stderr)
                sys.exit(1)
            print(f"Auto-detected series name: {name}")
        group_id = 1
        if getattr(args, "group", None):
            group = db.get_group_by_name(args.group)
            if group:
                group_id = group.group_id
            else:
                try:
                    group_id = int(args.group)
                    if not db.get_group(group_id):
                        print(f"Error: Group '{args.group}' not found", file=sys.stderr)
                        sys.exit(1)
                except ValueError:
                    print(f"Error: Group '{args.group}' not found", file=sys.stderr)
                    sys.exit(1)

        series_id = db.add_series(name, args.url, group_id)
        print(f"Added series '{name}' with ID {series_id}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        db.close()


def cmd_remove(args):
    """Remove a series from monitoring."""
    db = Database(args.db)
    try:
        if db.remove_series(args.identifier):
            print(f"Removed series '{args.identifier}'")
        else:
            print(f"Series '{args.identifier}' not found", file=sys.stderr)
            sys.exit(1)
    finally:
        db.close()


def cmd_list(args):
    """List all monitored series."""
    db = Database(args.db)
    try:
        series_list = db.list_series()
        if not series_list:
            print("No series being monitored.")
            return

        groups = {g.group_id: g.name for g in db.list_groups()}
        print(f"{'ID':<5} {'Name':<30} {'Group':<15} {'Last Checked':<20} {'URL'}")
        print("-" * 115)
        for s in series_list:
            last_checked = s.last_checked.strftime("%Y-%m-%d %H:%M") if s.last_checked else "Never"
            name = s.name[:28] + ".." if len(s.name) > 30 else s.name
            group_name = groups.get(s.group_id, "?")
            print(f"{s.series_id:<5} {name:<30} {group_name:<15} {last_checked:<20} {s.mediathek_url}")
    finally:
        db.close()


@contextmanager
def _silenced_output():
    """Context manager that redirects stdout and stderr to /dev/null.

    Uses low-level file descriptor duplication to silence C-extension
    output (e.g. from yt-dlp) that contextlib.redirect_stdout/stderr
    cannot capture. Fragile in multi-threaded contexts.
    """
    devnull = os.open(os.devnull, os.O_WRONLY)
    old_stdout = os.dup(1)
    old_stderr = os.dup(2)
    os.dup2(devnull, 1)
    os.dup2(devnull, 2)
    os.close(devnull)
    try:
        yield
    finally:
        os.dup2(old_stdout, 1)
        os.dup2(old_stderr, 2)
        os.close(old_stdout)
        os.close(old_stderr)


def _classify_url(url: str) -> tuple[str, str]:
    """Classify a URL and extract its source identifier.

    Returns (source, id) where source is one of 'arte', 'zdf', or 'ard'.
    Raises ValueError with a descriptive message if the ID cannot be extracted.
    """
    if ARTE.is_arte_url(url):
        collection_id = ARTE.extract_collection_id(url)
        if not collection_id:
            raise ValueError(f"Could not extract collection ID from ARTE URL: {url}")
        return "arte", collection_id
    elif ZDF.is_zdf_url(url):
        canonical_id = ZDF.extract_canonical_id(url)
        if not canonical_id:
            raise ValueError(f"Could not extract canonical ID from ZDF URL: {url}")
        return "zdf", canonical_id
    else:
        show_id = ARD.extract_show_id(url)
        if not show_id:
            raise ValueError(f"Could not extract show ID from URL: {url}")
        return "ard", show_id


def _fetch_episodes_for_source(source: str, source_id: str, season: Optional[int] = None) -> list:
    """Fetch episodes from a classified source."""
    if source == "arte":
        return ARTE.fetch_episodes_from_collection(source_id)
    elif source == "zdf":
        return ZDF.fetch_episodes(source_id)
    else:
        return ARD.fetch_episodes(source_id, season)


def _fetch_series_name_for_source(source: str, source_id: str) -> Optional[str]:
    """Fetch series name from a classified source."""
    if source == "arte":
        return ARTE.fetch_series_name(source_id)
    elif source == "zdf":
        return ZDF.fetch_series_name(source_id)
    else:
        return ARD.fetch_series_name(source_id)


def _download_new_episodes(episodes, series, target_folder, db, silent):
    """Download episodes that haven't been downloaded yet. Returns count of new episodes."""
    new_episodes = 0
    for episode in episodes:
        if db.is_episode_downloaded(episode.episode_id):
            continue

        if not silent:
            print(f"  New episode found: S{episode.season:02d}E{episode.episode_number:02d} - {episode.title}")

        output_path = generate_output_path(target_folder, series.name, episode.season, episode.episode_number, episode.title)

        if not silent:
            print(f"    Downloading to: {output_path}")

        if download_episode(episode.url, output_path, quiet=silent):
            db.mark_episode_downloaded(episode.episode_id, series.series_id, episode.season, episode.episode_number, episode.title, str(output_path))
            new_episodes += 1
            if not silent:
                print("    Download complete!")
        elif not silent:
            print("    Download failed!")

    return new_episodes


def cmd_check(args):
    """Check for new episodes and download them."""
    silent = getattr(args, "silent", False)
    context = _silenced_output() if silent else nullcontext()

    with context:
        db = Database(args.db)
        non_default_groups = db.has_non_default_groups()
        if non_default_groups and getattr(args, "target", None) is not None:
            print("Error: Cannot use --target when non-default groups are defined. Each group has its own target folder.", file=sys.stderr)
            sys.exit(1)

        try:
            series_list = db.list_series()
            if not series_list:
                if not silent:
                    print("No series being monitored.")
                return

            for series in series_list:
                if non_default_groups:
                    target_folder = Path(db.get_series_group_target(series.series_id))
                else:
                    target_folder = Path(args.target) if getattr(args, "target", None) is not None else Path(".")

                if not silent:
                    print(f"\nChecking series: {series.name}")

                try:
                    source, source_id = _classify_url(series.mediathek_url)
                    episodes = _fetch_episodes_for_source(source, source_id)
                except ValueError as e:
                    if not silent:
                        print(f"  Warning: {e}")
                    continue
                except Exception as e:
                    if not silent:
                        print(f"  Error fetching episodes: {e}")
                    continue

                new_episodes = _download_new_episodes(episodes, series, target_folder, db, silent)
                db.update_last_checked(series.series_id)

                if not silent:
                    if new_episodes == 0:
                        print("  No new episodes found.")
                    else:
                        print(f"  Downloaded {new_episodes} new episode(s).")

        finally:
            db.close()


def cmd_download(args):
    """Download all episodes from a series URL."""
    target_folder = Path(args.target)

    # Determine source and auto-detect series name
    if ARTE.is_arte_url(args.url):
        collection_id = ARTE.extract_collection_id(args.url)
        if not collection_id:
            print(f"Error: Could not extract collection ID from ARTE URL: {args.url}", file=sys.stderr)
            sys.exit(1)

        # Check if this is a direct video URL (not a collection/series URL)
        is_video_url = bool(ARTE.VIDEO_ID_RE.match(collection_id))

        if is_video_url:
            # Direct video URL - fetch just this video
            try:
                video_episode = ARTE.fetch_single_video(collection_id)
            except Exception as e:
                print(f"Error fetching video: {e}", file=sys.stderr)
                sys.exit(1)

            series_name = video_episode.title if video_episode else None
            if not series_name:
                series_name = "ARTE Video"

            print(f"Series: {series_name}")
            print(f"Target: {target_folder}")
            print(f"Detected direct video URL: {collection_id}")

            episodes = [video_episode] if video_episode is not None else []
        else:
            # Collection/series URL - use helper for the rest
            try:
                source, source_id = _classify_url(args.url)
                series_name = _fetch_series_name_for_source(source, source_id)
                if not series_name:
                    print("Error: Could not auto-detect series name from ARTE URL.", file=sys.stderr)
                    sys.exit(1)
                print(f"Series: {series_name}")
                print(f"Target: {target_folder}")
                episodes = _fetch_episodes_for_source(source, source_id)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
            except Exception as e:
                print(f"Error fetching episodes: {e}", file=sys.stderr)
                sys.exit(1)
    else:
        try:
            source, source_id = _classify_url(args.url)
            series_name = _fetch_series_name_for_source(source, source_id)
            if not series_name:
                print("Error: Could not auto-detect series name from URL.", file=sys.stderr)
                sys.exit(1)
            print(f"Series: {series_name}")
            print(f"Target: {target_folder}")
            episodes = _fetch_episodes_for_source(source, source_id)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Error fetching episodes: {e}", file=sys.stderr)
            sys.exit(1)

    if not episodes:
        print("No episodes found.")
        return

    print(f"Found {len(episodes)} episode(s).")

    downloaded = 0
    for episode in episodes:
        print(f"  Downloading S{episode.season:02d}E{episode.episode_number:02d} - {episode.title}")

        output_path = generate_output_path(target_folder, series_name, episode.season, episode.episode_number, episode.title)
        print(f"    -> {output_path}")

        if download_episode(episode.url, output_path):
            downloaded += 1
            print("    Done.")
        else:
            print("    Failed!", file=sys.stderr)

    print(f"Downloaded {downloaded} of {len(episodes)} episode(s).")


def cmd_redownload(args):
    """Force redownload of a specific episode."""
    db = Database(args.db)
    target_folder = Path(args.target) if args.target is not None else None

    try:
        try:
            series_id = int(args.series)
        except ValueError:
            series_list = db.list_series()
            series_id = None
            for s in series_list:
                if s.name.lower() == args.series.lower():
                    series_id = s.series_id
                    break
            if series_id is None:
                print(f"Series '{args.series}' not found", file=sys.stderr)
                sys.exit(1)

        series = db.get_series(series_id)
        if not series:
            print(f"Series ID {series_id} not found", file=sys.stderr)
            sys.exit(1)

        if target_folder is None:
            target_folder = Path(db.get_series_group_target(series_id))

        if db.delete_episode_record(series_id, args.season, args.episode):
            print(f"Removed episode record S{args.season:02d}E{args.episode:02d}")
        else:
            print(f"Episode S{args.season:02d}E{args.episode:02d} not found in database (will try download anyway)")

        try:
            source, source_id = _classify_url(series.mediathek_url)
            episodes = _fetch_episodes_for_source(source, source_id, args.season)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Error fetching episodes: {e}", file=sys.stderr)
            sys.exit(1)

        target_episode = None
        for ep in episodes:
            if ep.season == args.season and ep.episode_number == args.episode:
                target_episode = ep
                break

        if not target_episode:
            print(f"Episode S{args.season:02d}E{args.episode:02d} not found", file=sys.stderr)
            sys.exit(1)

        print(f"Downloading: {target_episode.title}")

        output_path = generate_output_path(target_folder, series.name, target_episode.season, target_episode.episode_number, target_episode.title)

        print(f"Output path: {output_path}")

        if download_episode(target_episode.url, output_path):
            db.mark_episode_downloaded(
                target_episode.episode_id, series.series_id, target_episode.season, target_episode.episode_number, target_episode.title, str(output_path)
            )
            print("Download complete!")
        else:
            print("Download failed!", file=sys.stderr)
            sys.exit(1)

    finally:
        db.close()


def cmd_mark(args):
    """Mark episodes or seasons as already downloaded (without downloading)."""
    db = Database(args.db)
    target_folder = Path(args.target) if args.target is not None else None

    try:
        # Find series by ID or name
        try:
            series_id = int(args.series)
        except ValueError:
            series_list = db.list_series()
            series_id = None
            for s in series_list:
                if s.name.lower() == args.series.lower():
                    series_id = s.series_id
                    break
            if series_id is None:
                print(f"Series '{args.series}' not found", file=sys.stderr)
                sys.exit(1)

        series = db.get_series(series_id)
        if not series:
            print(f"Series ID {series_id} not found", file=sys.stderr)
            sys.exit(1)

        if target_folder is None:
            target_folder = Path(db.get_series_group_target(series_id))

        # Fetch episodes for this series
        try:
            source, source_id = _classify_url(series.mediathek_url)
            episodes = _fetch_episodes_for_source(source, source_id, args.season if args.season else None)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Error fetching episodes: {e}", file=sys.stderr)
            sys.exit(1)

        marked = 0

        if args.episode:
            # Mark specific episode
            target = None
            for ep in episodes:
                if ep.episode_number == args.episode:
                    if args.season is not None and ep.season != args.season:
                        continue
                    target = ep
                    break
            if not target:
                if args.season is not None:
                    print(f"Episode S{args.season:02d}E{args.episode:02d} not found", file=sys.stderr)
                else:
                    print(f"Episode E{args.episode:02d} not found", file=sys.stderr)
                sys.exit(1)

            output_path = generate_output_path(target_folder, series.name, target.season, target.episode_number, target.title)
            db.mark_episode_downloaded(target.episode_id, series.series_id, target.season, target.episode_number, target.title, str(output_path))
            print(f"Marked: {series.name} - S{target.season:02d}E{target.episode_number:02d} - {target.title}")
            marked = 1
        elif args.season:
            # Mark entire season
            season_eps = [ep for ep in episodes if ep.season == args.season]
            for ep in season_eps:
                output_path = generate_output_path(target_folder, series.name, ep.season, ep.episode_number, ep.title)
                db.mark_episode_downloaded(ep.episode_id, series.series_id, ep.season, ep.episode_number, ep.title, str(output_path))
                marked += 1
            print(f"Marked {marked} episode(s) from {series.name} Season {args.season}")
        else:
            # Mark ALL episodes from this series
            for ep in episodes:
                output_path = generate_output_path(target_folder, series.name, ep.season, ep.episode_number, ep.title)
                db.mark_episode_downloaded(ep.episode_id, series.series_id, ep.season, ep.episode_number, ep.title, str(output_path))
                marked += 1
            print(f"Marked {marked} episode(s) from {series.name}")

    finally:
        db.close()


def cmd_group_create(args):
    """Create a new group."""
    db = Database(args.db)
    try:
        group_id = db.add_group(args.name, args.target)
        print(f"Created group '{args.name}' with ID {group_id}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        db.close()


def cmd_group_update(args):
    """Update an existing group."""
    db = Database(args.db)
    try:
        group = None
        try:
            group_id = int(args.identifier)
            group = db.get_group(group_id)
        except ValueError:
            group = db.get_group_by_name(args.identifier)

        if not group:
            print(f"Group '{args.identifier}' not found", file=sys.stderr)
            sys.exit(1)

        new_name = args.name if args.name else None
        new_target = args.target if args.target else None
        if new_name is None and new_target is None:
            print("Error: Nothing to update. Provide --name and/or --target.", file=sys.stderr)
            sys.exit(1)

        db.update_group(group.group_id, name=new_name, target_folder=new_target)
        print(f"Updated group '{args.identifier}'")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        db.close()


def cmd_group_delete(args):
    """Delete a group."""
    db = Database(args.db)
    try:
        group = None
        try:
            group_id = int(args.identifier)
            group = db.get_group(group_id)
        except ValueError:
            group = db.get_group_by_name(args.identifier)

        if not group:
            print(f"Group '{args.identifier}' not found", file=sys.stderr)
            sys.exit(1)

        db.delete_group(group.group_id)
        print(f"Deleted group '{group.name}'")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        db.close()


def cmd_group_list(args):
    """List all groups."""
    db = Database(args.db)
    try:
        groups = db.list_groups()
        if not groups:
            print("No groups defined.")
            return

        print(f"{'ID':<5} {'Name':<20} {'Target Folder'}")
        print("-" * 60)
        for g in groups:
            print(f"{g.group_id:<5} {g.name:<20} {g.target_folder}")
    finally:
        db.close()


def cmd_set_group(args):
    """Set the group for a series."""
    db = Database(args.db)
    try:
        # Find series by ID or name
        try:
            series_id = int(args.series)
        except ValueError:
            series_list = db.list_series()
            series_id = None
            for s in series_list:
                if s.name.lower() == args.series.lower():
                    series_id = s.series_id
                    break
            if series_id is None:
                print(f"Series '{args.series}' not found", file=sys.stderr)
                sys.exit(1)

        series = db.get_series(series_id)
        if not series:
            print(f"Series ID {series_id} not found", file=sys.stderr)
            sys.exit(1)

        # Find group by ID or name
        group = None
        try:
            group_id = int(args.group)
            group = db.get_group(group_id)
        except ValueError:
            group = db.get_group_by_name(args.group)

        if not group:
            print(f"Group '{args.group}' not found", file=sys.stderr)
            sys.exit(1)

        db.set_series_group(series_id, group.group_id)
        print(f"Set series '{series.name}' to group '{group.name}'")
    finally:
        db.close()
