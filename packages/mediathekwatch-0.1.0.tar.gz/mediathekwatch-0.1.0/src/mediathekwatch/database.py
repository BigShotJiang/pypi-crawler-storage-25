"""DuckDB database handler for storing series and episode state."""

from datetime import datetime
from pathlib import Path

import duckdb

from mediathekwatch.models import Group, Series


class Database:
    """DuckDB database handler for storing series and episode state."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = duckdb.connect(str(self.db_path))
        self._init_tables()

    def _init_tables(self):
        """Initialize database tables if they don't exist."""
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS groups (
                group_id INTEGER PRIMARY KEY,
                name VARCHAR NOT NULL UNIQUE,
                target_folder VARCHAR NOT NULL
            )
        """)
        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS group_id_seq START 1
        """)
        # Insert default group if not exists
        self.conn.execute("""
            INSERT INTO groups (group_id, name, target_folder)
            SELECT nextval('group_id_seq'), 'default', '.'
            WHERE NOT EXISTS (SELECT 1 FROM groups WHERE name = 'default')
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS monitored_series (
                series_id INTEGER PRIMARY KEY,
                name VARCHAR NOT NULL,
                mediathek_url VARCHAR NOT NULL UNIQUE,
                added_date TIMESTAMP NOT NULL,
                last_checked TIMESTAMP,
                group_id INTEGER DEFAULT 1
            )
        """)
        # Migrate existing series without group_id
        columns = self.conn.execute("PRAGMA table_info('monitored_series')").fetchall()
        has_group_id = any(row[1] == "group_id" for row in columns)
        if not has_group_id:
            self.conn.execute("ALTER TABLE monitored_series ADD COLUMN group_id INTEGER DEFAULT 1")
            self.conn.execute("UPDATE monitored_series SET group_id = 1 WHERE group_id IS NULL")
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS downloaded_episodes (
                episode_id VARCHAR PRIMARY KEY,
                series_id INTEGER NOT NULL,
                season INTEGER NOT NULL,
                episode_number INTEGER NOT NULL,
                episode_name VARCHAR NOT NULL,
                download_date TIMESTAMP NOT NULL,
                file_path VARCHAR NOT NULL,
                FOREIGN KEY (series_id) REFERENCES monitored_series(series_id)
            )
        """)
        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS series_id_seq START 1
        """)

    def add_series(self, name: str, mediathek_url: str, group_id: int = 1) -> int:
        """Add a new series to monitor. Returns the series_id."""
        result = self.conn.execute("SELECT series_id FROM monitored_series WHERE mediathek_url = ?", [mediathek_url]).fetchone()

        if result:
            raise ValueError(f"Series with URL {mediathek_url} already exists (ID: {result[0]})")

        row = self.conn.execute("SELECT nextval('series_id_seq')").fetchone()
        if row is None:
            raise RuntimeError("Failed to get next series ID from sequence")
        series_id = row[0]

        self.conn.execute(
            "INSERT INTO monitored_series (series_id, name, mediathek_url, added_date, group_id) VALUES (?, ?, ?, ?, ?)",
            [series_id, name, mediathek_url, datetime.now(), group_id],
        )
        return series_id

    def remove_series(self, series_id_or_name: str) -> bool:
        """Remove a series by ID or name. Returns True if removed."""
        try:
            series_id = int(series_id_or_name)
            # Delete downloaded episodes first to avoid foreign key violation
            self.conn.execute("DELETE FROM downloaded_episodes WHERE series_id = ?", [series_id])
            result = self.conn.execute("DELETE FROM monitored_series WHERE series_id = ? RETURNING series_id", [series_id]).fetchone()
        except ValueError:
            row = self.conn.execute("SELECT series_id FROM monitored_series WHERE name = ?", [series_id_or_name]).fetchone()
            if row is None:
                return False
            series_id = row[0]
            self.conn.execute("DELETE FROM downloaded_episodes WHERE series_id = ?", [series_id])
            result = self.conn.execute("DELETE FROM monitored_series WHERE name = ? RETURNING series_id", [series_id_or_name]).fetchone()

        return result is not None

    def list_series(self) -> list[Series]:
        """List all monitored series."""
        results = self.conn.execute(
            "SELECT series_id, name, mediathek_url, added_date, last_checked, group_id FROM monitored_series ORDER BY series_id"
        ).fetchall()

        return [Series(series_id=r[0], name=r[1], mediathek_url=r[2], added_date=r[3], last_checked=r[4], group_id=r[5]) for r in results]

    def get_series(self, series_id: int) -> Series | None:
        """Get a series by ID."""
        result = self.conn.execute(
            "SELECT series_id, name, mediathek_url, added_date, last_checked, group_id FROM monitored_series WHERE series_id = ?", [series_id]
        ).fetchone()

        if not result:
            return None

        return Series(series_id=result[0], name=result[1], mediathek_url=result[2], added_date=result[3], last_checked=result[4], group_id=result[5])

    def update_last_checked(self, series_id: int) -> None:
        """Update the last_checked timestamp for a series."""
        self.conn.execute("UPDATE monitored_series SET last_checked = ? WHERE series_id = ?", [datetime.now(), series_id])

    def is_episode_downloaded(self, episode_id: str) -> bool:
        """Check if an episode has already been downloaded."""
        result = self.conn.execute("SELECT 1 FROM downloaded_episodes WHERE episode_id = ?", [episode_id]).fetchone()
        return result is not None

    def mark_episode_downloaded(self, episode_id: str, series_id: int, season: int, episode_number: int, episode_name: str, file_path: str) -> None:
        """Mark an episode as downloaded."""
        self.conn.execute(
            """INSERT INTO downloaded_episodes
                (episode_id, series_id, season, episode_number, episode_name, download_date, file_path)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (episode_id) DO UPDATE SET
                download_date = excluded.download_date,
                file_path = excluded.file_path""",
            [episode_id, series_id, season, episode_number, episode_name, datetime.now(), file_path],
        )

    def delete_episode_record(self, series_id: int, season: int, episode_number: int) -> bool:
        """Delete an episode record to force redownload."""
        result = self.conn.execute(
            "DELETE FROM downloaded_episodes WHERE series_id = ? AND season = ? AND episode_number = ? RETURNING episode_id",
            [series_id, season, episode_number],
        ).fetchone()
        return result is not None

    # --- Group management ---

    def add_group(self, name: str, target_folder: str) -> int:
        """Add a new group. Returns the group_id."""
        existing = self.conn.execute("SELECT group_id FROM groups WHERE name = ?", [name]).fetchone()
        if existing:
            raise ValueError(f"Group '{name}' already exists (ID: {existing[0]})")

        row = self.conn.execute("SELECT nextval('group_id_seq')").fetchone()
        if row is None:
            raise RuntimeError("Failed to get next group ID from sequence")
        group_id = row[0]

        self.conn.execute(
            "INSERT INTO groups (group_id, name, target_folder) VALUES (?, ?, ?)",
            [group_id, name, target_folder],
        )
        return group_id

    def update_group(self, group_id: int, name: str | None = None, target_folder: str | None = None) -> bool:
        """Update a group's name and/or target folder. Returns True if updated."""
        if name is not None:
            existing = self.conn.execute("SELECT group_id FROM groups WHERE name = ? AND group_id != ?", [name, group_id]).fetchone()
            if existing:
                raise ValueError(f"Group name '{name}' already in use")
            self.conn.execute("UPDATE groups SET name = ? WHERE group_id = ?", [name, group_id])
        if target_folder is not None:
            self.conn.execute("UPDATE groups SET target_folder = ? WHERE group_id = ?", [target_folder, group_id])
        return True

    def delete_group(self, group_id: int) -> bool:
        """Delete a group and reassign its series to the default group. Returns True if deleted."""
        if group_id == 1:
            raise ValueError("Cannot delete the default group")

        # Reassign series to default group
        self.conn.execute("UPDATE monitored_series SET group_id = 1 WHERE group_id = ?", [group_id])
        result = self.conn.execute("DELETE FROM groups WHERE group_id = ? RETURNING group_id", [group_id]).fetchone()
        return result is not None

    def list_groups(self) -> list[Group]:
        """List all groups."""
        results = self.conn.execute("SELECT group_id, name, target_folder FROM groups ORDER BY group_id").fetchall()
        return [Group(group_id=r[0], name=r[1], target_folder=r[2]) for r in results]

    def get_group(self, group_id: int) -> Group | None:
        """Get a group by ID."""
        result = self.conn.execute("SELECT group_id, name, target_folder FROM groups WHERE group_id = ?", [group_id]).fetchone()
        if not result:
            return None
        return Group(group_id=result[0], name=result[1], target_folder=result[2])

    def get_group_by_name(self, name: str) -> Group | None:
        """Get a group by name."""
        result = self.conn.execute("SELECT group_id, name, target_folder FROM groups WHERE name = ?", [name]).fetchone()
        if not result:
            return None
        return Group(group_id=result[0], name=result[1], target_folder=result[2])

    def set_series_group(self, series_id: int, group_id: int) -> bool:
        """Set the group for a series. Returns True if updated."""
        result = self.conn.execute(
            "UPDATE monitored_series SET group_id = ? WHERE series_id = ? RETURNING series_id",
            [group_id, series_id],
        ).fetchone()
        return result is not None

    def get_series_group_target(self, series_id: int) -> str:
        """Get the target folder for a series' group."""
        result = self.conn.execute(
            "SELECT g.target_folder FROM groups g JOIN monitored_series s ON g.group_id = s.group_id WHERE s.series_id = ?",
            [series_id],
        ).fetchone()
        if not result:
            return "."
        return result[0]

    def has_non_default_groups(self) -> bool:
        """Check if any non-default groups exist."""
        result = self.conn.execute("SELECT 1 FROM groups WHERE group_id != 1 LIMIT 1").fetchone()
        return result is not None

    def close(self) -> None:
        """Close the database connection."""
        self.conn.close()
