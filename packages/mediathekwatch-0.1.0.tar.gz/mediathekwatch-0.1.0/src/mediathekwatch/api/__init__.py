"""API clients for ARD Mediathek, ARTE.tv and ZDF Mediathek."""

from mediathekwatch.api.ard import ARD
from mediathekwatch.api.arte import ARTE
from mediathekwatch.api.zdf import ZDF

__all__ = [
    "ARD",
    "ARTE",
    "ZDF",
]
