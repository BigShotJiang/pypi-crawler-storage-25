"""Handler for ZDF Mediathek API interactions."""

import json as json_mod
import re
import sys
import urllib.parse
from typing import Optional
from urllib.parse import urlparse

import requests

from mediathekwatch.models import Episode
from mediathekwatch.statics import HEADERS

ZDF_AUTH_KEY = "Bearer aa3noh4ohz9eeboo8shiesheec9ciequ9Quah7el"
ZDF_API_BASE = "https://api.zdf.de"
ZDF_WEB_BASE = "https://www.zdf.de"
ZDF_SEASON_QUERY_HASH = "9412a0f4ac55dc37d46975d461ec64bfd14380d815df843a1492348f77b5c99a"
ZDF_META_COLLECTION_QUERY_HASH = "c85ca9c636258a65961a81124abd0dbef06ab97eaca9345cbdfde23b54117242"

MAX_PAGES = 50

ZDF_HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    "Accept": "application/json",
    "Api-Auth": ZDF_AUTH_KEY,
}


class ZDF:
    """Handler for ZDF Mediathek API interactions."""

    AUTH_KEY = ZDF_AUTH_KEY
    API_BASE = ZDF_API_BASE
    WEB_BASE = ZDF_WEB_BASE
    ZDF_HEADERS = ZDF_HEADERS
    SEASON_QUERY_HASH = ZDF_SEASON_QUERY_HASH
    META_COLLECTION_QUERY_HASH = ZDF_META_COLLECTION_QUERY_HASH

    @staticmethod
    def is_zdf_url(url: str) -> bool:
        """Check if URL belongs to ZDF."""
        return "zdf.de" in urlparse(url).netloc

    @staticmethod
    def extract_canonical_id(url: str) -> Optional[str]:
        """Extract the canonical ID from a ZDF URL."""
        path = urlparse(url).path
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None
        return parts[-1]

    @staticmethod
    def fetch_series_name(canonical_id: str) -> Optional[str]:
        """Fetch the series name from the ZDF web page."""
        try:
            url = f"{ZDF.WEB_BASE}/{canonical_id}"
            response = requests.get(url, headers=HEADERS, timeout=30, stream=True)
            response.raise_for_status()
            # Read chunks until </title> to avoid buffering the entire page
            html = ""
            for chunk in response.iter_content(chunk_size=4096, decode_unicode=True):
                if chunk:
                    html += chunk
                    if "</title>" in html.lower():
                        break
            response.close()
            # Extract <title> tag content
            match = re.search(r"<title>([^<]+)</title>", html, re.IGNORECASE)
            if match:
                title = match.group(1).strip()
                # Remove common suffixes
                title = re.sub(r"\s*\|\s*ZDF\s*$", "", title, flags=re.IGNORECASE)
                title = re.sub(r"\s*-\s*ZDFmediathek\s*$", "", title, flags=re.IGNORECASE)
                # Harden: strip control chars, backslashes, newlines, and collapse whitespace
                title = re.sub(r"[\x00-\x1f\\]+", "", title)
                title = re.sub(r"\s+", " ", title).strip()
                if title:
                    return title
            return None
        except Exception as e:
            print(f"Error fetching ZDF series name: {e}", file=sys.stderr)
            return None

    @staticmethod
    def _build_graphql_url(operation: str, variables: dict, hash_value: str) -> str:
        extensions = json_mod.dumps({"persistedQuery": {"version": 1, "sha256Hash": hash_value}})
        variables_str = json_mod.dumps(variables)
        return f"{ZDF.API_BASE}/graphql?operationName={operation}&variables={urllib.parse.quote(variables_str)}&extensions={urllib.parse.quote(extensions)}"

    @staticmethod
    def _fetch_season_episodes(canonical_id: str, season_index: int, cursor: Optional[str] = None) -> tuple[list[Episode], Optional[str]]:
        """Fetch episodes for a specific season. Returns (episodes, next_cursor)."""
        variables: dict = {
            "seasonIndex": season_index,
            "episodesPageSize": 24,
            "canonical": canonical_id,
            "sortBy": [{"field": "EDITORIAL_DATE", "direction": "DESC"}],
        }
        if cursor:
            variables["episodesAfter"] = cursor

        url = ZDF._build_graphql_url("seasonByCanonical", variables, ZDF.SEASON_QUERY_HASH)
        headers = {**ZDF.ZDF_HEADERS, "x-apollo-operation-name": "seasonByCanonical"}
        try:
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            print(f"Warning: Failed to fetch ZDF season episodes: {e}", file=sys.stderr)
            return [], None

        episodes = []
        next_cursor = None

        if not data.get("data"):
            return episodes, next_cursor

        smart_collection = data["data"].get("smartCollectionByCanonical")
        if not smart_collection:
            return episodes, next_cursor

        seasons = smart_collection.get("seasons", {})
        season_nodes = seasons.get("nodes", [])
        if not season_nodes:
            return episodes, next_cursor

        season = season_nodes[0]
        episode_data = season.get("episodes", {})
        episode_nodes = episode_data.get("nodes", [])
        page_info = episode_data.get("pageInfo", {})

        for node in episode_nodes:
            episode = ZDF._parse_episode_node(node)
            if episode:
                episodes.append(episode)

        if page_info.get("hasNextPage") and page_info.get("endCursor"):
            next_cursor = page_info["endCursor"]

        return episodes, next_cursor

    @staticmethod
    def _parse_episode_node(node: dict) -> Optional[Episode]:
        """Parse a ZDF episode node into an Episode object."""
        try:
            episode_id = node.get("id")
            if not episode_id:
                return None

            title = node.get("title", "Unknown")
            subtitle = node.get("subtitle")
            if subtitle:
                title = f"{title} - {subtitle}"

            # Clean up title
            title = re.sub(r"\s+-\s+$", "", title)
            title = title.strip()

            episode_info = node.get("episodeInfo", {})
            season = episode_info.get("seasonNumber", 1) if episode_info else 1
            episode_number = episode_info.get("episodeNumber", 0) if episode_info else 0

            url = node.get("sharingUrl", "")
            aired_date = node.get("editorialDate")

            # Try to get duration from video data if available
            duration = None
            video = node.get("video")
            if video and isinstance(video, dict):
                current_media = video.get("currentMedia", {})
                if current_media and isinstance(current_media, dict):
                    nodes = current_media.get("nodes", [])
                    if nodes and isinstance(nodes, list):
                        for media_node in nodes:
                            if isinstance(media_node, dict):
                                dur = media_node.get("duration")
                                if dur:
                                    duration = int(dur)
                                    break

            return Episode(
                episode_id=episode_id,
                title=title,
                season=int(season),
                episode_number=int(episode_number),
                url=url,
                aired_date=aired_date,
                duration=duration,
            )
        except (KeyError, ValueError, TypeError) as e:
            print(f"Warning: Failed to parse ZDF episode node: {e}", file=sys.stderr)
            return None

    @staticmethod
    def _fetch_meta_collection_episodes(collection_id: str, cursor: Optional[str] = None) -> tuple[list[Episode], Optional[str]]:
        """Fetch episodes from a meta collection (non-season). Returns (episodes, next_cursor)."""
        pagination: dict[str, object] = {"first": 24}
        if cursor:
            pagination["after"] = cursor
        variables: dict = {
            "collectionId": collection_id,
            "input": {
                "appId": "ffw-mt-web-879d5c17",
                "filters": {"contentOwner": [], "fsk": [], "language": []},
                "pagination": pagination,
                "user": {"abGroup": "gruppe-d", "userSegment": "segment_0"},
                "tabId": None,
            },
        }

        url = ZDF._build_graphql_url("getMetaCollectionContent", variables, ZDF.META_COLLECTION_QUERY_HASH)
        headers = {**ZDF.ZDF_HEADERS, "x-apollo-operation-name": "getMetaCollectionContent"}
        try:
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            print(f"Warning: Failed to fetch ZDF meta collection episodes: {e}", file=sys.stderr)
            return [], None

        episodes = []
        next_cursor = None

        if not data.get("data"):
            return episodes, next_cursor

        meta = data["data"].get("metaCollectionContent")
        if not meta:
            return episodes, next_cursor

        collections = meta.get("smartCollections", [])
        for collection in collections:
            episode = ZDF._parse_episode_node(collection)
            if episode:
                episodes.append(episode)

        page_info = meta.get("pageInfo", {})
        if page_info.get("hasNextPage") and page_info.get("endCursor"):
            next_cursor = page_info["endCursor"]

        return episodes, next_cursor

    @staticmethod
    def _fetch_collection_overview(canonical_id: str) -> tuple[int, list[Episode], Optional[str]]:
        """Fetch collection overview. Returns (num_seasons, first_season_episodes, next_cursor)."""
        variables = {
            "seasonIndex": 0,
            "episodesPageSize": 24,
            "canonical": canonical_id,
            "sortBy": [{"field": "EDITORIAL_DATE", "direction": "DESC"}],
        }
        url = ZDF._build_graphql_url("seasonByCanonical", variables, ZDF.SEASON_QUERY_HASH)
        headers = {**ZDF.ZDF_HEADERS, "x-apollo-operation-name": "seasonByCanonical"}
        try:
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
        except Exception:
            return 0, [], None

        if not data.get("data"):
            return 0, [], None

        smart_collection = data["data"].get("smartCollectionByCanonical")
        if not smart_collection:
            return 0, [], None

        seasons = smart_collection.get("seasons", {})
        season_nodes = seasons.get("nodes", [])
        num_seasons = len(season_nodes)
        if not season_nodes:
            return 0, [], None

        season = season_nodes[0]
        episode_data = season.get("episodes", {})
        episode_nodes = episode_data.get("nodes", [])
        page_info = episode_data.get("pageInfo", {})

        episodes = []
        for node in episode_nodes:
            episode = ZDF._parse_episode_node(node)
            if episode:
                episodes.append(episode)

        next_cursor = None
        if page_info.get("hasNextPage") and page_info.get("endCursor"):
            next_cursor = page_info["endCursor"]

        return num_seasons, episodes, next_cursor

    @staticmethod
    def fetch_episodes(canonical_id: str) -> list[Episode]:
        """Fetch all episodes for a ZDF collection."""
        episodes = []
        seen_ids = set()

        num_seasons, first_eps, first_cursor = ZDF._fetch_collection_overview(canonical_id)

        if num_seasons > 0:
            # Season-based collection: reuse first season data from overview call
            for ep in first_eps:
                if ep.episode_id not in seen_ids:
                    seen_ids.add(ep.episode_id)
                    episodes.append(ep)

            # Continue paginating season 0 if needed
            cursor = first_cursor
            page = 0
            while cursor:
                page += 1
                if page > MAX_PAGES:
                    print("Warning: Reached page limit for season 0, stopping pagination", file=sys.stderr)
                    break
                season_eps, next_cursor = ZDF._fetch_season_episodes(canonical_id, 0, cursor)
                for ep in season_eps:
                    if ep.episode_id not in seen_ids:
                        seen_ids.add(ep.episode_id)
                        episodes.append(ep)
                cursor = next_cursor

            # Fetch remaining seasons
            for season_index in range(1, num_seasons):
                cursor = None
                page = 0
                while True:
                    page += 1
                    if page > MAX_PAGES:
                        print(f"Warning: Reached page limit for season {season_index}, stopping pagination", file=sys.stderr)
                        break
                    season_eps, next_cursor = ZDF._fetch_season_episodes(canonical_id, season_index, cursor)
                    for ep in season_eps:
                        if ep.episode_id not in seen_ids:
                            seen_ids.add(ep.episode_id)
                            episodes.append(ep)
                    if not next_cursor:
                        break
                    cursor = next_cursor
        else:
            # Try meta collection
            collection_id = canonical_id.replace("-", "_")
            cursor = None
            page = 0
            while True:
                page += 1
                if page > MAX_PAGES:
                    print("Warning: Reached page limit for meta collection, stopping pagination", file=sys.stderr)
                    break
                meta_eps, next_cursor = ZDF._fetch_meta_collection_episodes(collection_id, cursor)
                for ep in meta_eps:
                    if ep.episode_id not in seen_ids:
                        seen_ids.add(ep.episode_id)
                        episodes.append(ep)
                if not next_cursor:
                    break
                cursor = next_cursor

        return episodes
