"""Handler for ARTE.tv API interactions."""

import re
import sys
from typing import Optional
from urllib.parse import urlparse

import requests

from mediathekwatch.models import Episode
from mediathekwatch.statics import HEADERS

EMAC_BASE_URL = "https://api.arte.tv/api/emac/v4"

ARTE_COLLECTION_RE = re.compile(r"^RC-\d{6}$")
ARTE_VIDEO_ID_RE = re.compile(r"^\d{6}-\d{3}-[AF]$")


class ARTE:
    """Handler for ARTE.tv API interactions.

    ARTE uses EMAC v4 API with a different structure from ARD Mediathek.
    The collection endpoint returns zones containing season subcollections
    with episode data inline. yt-dlp handles ARTE downloads natively via
    the web page URLs, so we pass those instead of stream URLs.
    """

    COLLECTION_RE = ARTE_COLLECTION_RE
    VIDEO_ID_RE = ARTE_VIDEO_ID_RE

    @staticmethod
    def extract_collection_id(url: str) -> Optional[str]:
        """Extract an ARTE collection (RC-) or video ID from a URL."""
        path = urlparse(url).path
        parts = [p for p in path.split("/") if p]
        for part in reversed(parts):
            if ARTE.COLLECTION_RE.match(part) or ARTE.VIDEO_ID_RE.match(part):
                return part
        return None

    @staticmethod
    def is_arte_url(url: str) -> bool:
        """Check if URL belongs to ARTE.tv."""
        return "arte.tv" in urlparse(url).netloc

    @staticmethod
    def fetch_series_name(collection_id: str, lang: str = "de") -> Optional[str]:
        """Fetch the series name from an ARTE collection via EMAC v4 API."""
        try:
            url = f"{EMAC_BASE_URL}/{lang}/tv/collections/{collection_id}"
            response = requests.get(url, headers=HEADERS, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data.get("metadata", {}).get("title")
        except Exception as e:
            print(f"Error fetching ARTE series name: {e}", file=sys.stderr)
            return None

    @staticmethod
    def fetch_episodes_from_collection(collection_id: str, lang: str = "de") -> list[Episode]:
        """Fetch all episodes from an ARTE collection via EMAC v4 API.

        If the collection is a top-level series, its zones contain season
        subcollections whose items hold individual episodes.
        If the collection is already a season, its items are episodes directly.
        """
        episodes = []
        seen_ids = set()
        url = f"{EMAC_BASE_URL}/{lang}/tv/collections/{collection_id}"
        page = 0
        max_pages = 50

        while url and page < max_pages:
            page += 1
            try:
                response = requests.get(url, headers=HEADERS, timeout=30)
                response.raise_for_status()
                data = response.json()
            except Exception as e:
                print(f"Error fetching ARTE collection {collection_id}: {e}", file=sys.stderr)
                break

            zones = data.get("zones", [])
            for zone in zones:
                zone_code = zone.get("code", "")
                zone_content = zone.get("content", {})

                if zone_code.startswith("collection_subcollection_"):
                    # Season subcollection: items are episodes
                    items = zone_content.get("data", [])
                    for item in items:
                        ep = ARTE._parse_emac_item(item)
                        if ep and ep.episode_id not in seen_ids:
                            seen_ids.add(ep.episode_id)
                            episodes.append(ep)
                elif zone_code.startswith("collection_videos_"):
                    # Single-season show: videos listed directly
                    items = zone_content.get("data", [])
                    for item in items:
                        ep = ARTE._parse_emac_item(item)
                        if ep and ep.episode_id not in seen_ids:
                            seen_ids.add(ep.episode_id)
                            episodes.append(ep)

            url = data.get("nextPage") or data.get("pagination", {}).get("nextPage")
            if not url:
                break

        if page >= max_pages and url:
            print(f"Warning: Reached page limit for ARTE collection {collection_id}, stopping pagination", file=sys.stderr)

        return episodes

    @staticmethod
    def _parse_emac_item(item: dict) -> Optional[Episode]:
        """Parse an episode item from the EMAC v4 API."""
        try:
            program_id = item.get("programId") or item.get("id", "").rsplit("_", 1)[0]
            if not program_id:
                return None

            title = item.get("title", "Unknown")
            subtitle = item.get("subtitle")
            if subtitle:
                title = f"{title} - {subtitle}"

            # Use ARTE web page URL so yt-dlp handles the download natively
            link_url = item.get("link", {}).get("url", f"https://www.arte.tv/de/videos/{program_id}/")

            episode_info = item.get("episodeInfo", {})
            season_raw = episode_info.get("season")
            episode_number_raw = episode_info.get("episode")
            # Handle both missing keys and explicit None values
            season = int(season_raw) if season_raw is not None else 1
            episode_number = int(episode_number_raw) if episode_number_raw is not None else 0

            duration = None
            dur = item.get("duration")
            if isinstance(dur, int):
                duration = dur
            elif isinstance(dur, dict):
                duration = dur.get("seconds")

            return Episode(
                episode_id=program_id,
                title=title.strip(),
                season=season,
                episode_number=episode_number,
                url=link_url,
                duration=duration,
            )
        except (KeyError, ValueError, TypeError) as e:
            print(f"Warning: Failed to parse ARTE EMAC item: {e}", file=sys.stderr)
            return None

    @staticmethod
    def fetch_single_video(video_id: str, lang: str = "de") -> Optional[Episode]:
        """Fetch metadata for a single ARTE video."""
        url = f"https://api.arte.tv/api/player/v2/config/{lang}/{video_id}?platform=ARTE_NEXT"
        try:
            response = requests.get(url, headers=HEADERS, timeout=30)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            print(f"Error fetching ARTE video {video_id}: {e}", file=sys.stderr)
            return None

        return ARTE._parse_single_config(data, lang)

    @staticmethod
    def _parse_single_config(data: dict, lang: str) -> Optional[Episode]:
        """Parse a single video config response into an Episode."""
        try:
            attrs = data.get("data", {}).get("attributes", {})
            metadata = attrs.get("metadata", {})
            provider_id = metadata.get("providerId", "")

            title = metadata.get("title", "Unknown")
            subtitle = metadata.get("subtitle")
            if subtitle:
                title = f"{title} - {subtitle}"

            duration = None
            dur = metadata.get("duration")
            if dur and isinstance(dur, dict):
                duration = dur.get("seconds")

            streams = attrs.get("streams", [])
            video_url = streams[0]["url"] if streams else ""

            ep_number = 0
            match = re.match(r"\d{6}-(\d{3})-", provider_id)
            if match:
                ep_number = int(match.group(1))

            return Episode(
                episode_id=provider_id,
                title=title.strip(),
                season=1,
                episode_number=ep_number,
                url=video_url,
                duration=duration,
            )
        except (KeyError, ValueError, TypeError) as e:
            print(f"Warning: Failed to parse ARTE config: {e}", file=sys.stderr)
            return None
