from ._native import add, hello_from_rust

__version__ = "0.2.0rc1"


def get_sdk_version() -> str:
    return __version__


__all__ = ["__version__", "add", "get_sdk_version", "hello_from_rust"]
