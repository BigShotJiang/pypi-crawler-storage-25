use pyo3::prelude::*;

#[pyfunction(signature = (name=None))]
fn hello_from_rust(name: Option<&str>) -> String {
    private_only_core::hello_from_rust(name)
}

#[pyfunction]
fn add(left: i64, right: i64) -> i64 {
    private_only_core::add(left, right)
}

#[pymodule]
fn _native(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(hello_from_rust, module)?)?;
    module.add_function(wrap_pyfunction!(add, module)?)?;
    Ok(())
}
