pub fn hello_from_rust(name: Option<&str>) -> String {
    match name {
        Some(name) if !name.trim().is_empty() => format!("Hello, {name}, from Rust."),
        _ => "Hello from Rust.".to_string(),
    }
}
pub fn add(left: i64, right: i64) -> i64 {
    left + right
}

#[cfg(test)]
mod tests {
    use super::{add, hello_from_rust};

    #[test]
    fn greets_named_callers() {
        assert_eq!(hello_from_rust(Some("SDK")), "Hello, SDK, from Rust.");
    }

    #[test]
    fn adds_numbers() {
        assert_eq!(add(2, 3), 5);
    }
}
