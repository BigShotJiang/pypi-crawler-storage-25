from .imports import os,get_moviepy,get_whisper,get_logFile,SingletonMeta,DEFAULT_PATHS
from abstract_utilities import derive_media_type

logger = get_logFile(__name__)
DEFAULT_WHISPER_MODEL_PATH = DEFAULT_PATHS["whisper"]
class whisperManager(metaclass=SingletonMeta):
    def __init__(self,module_size: str = "base", whisper_model_path: str = None):
        if not hasattr(self, 'initialized') or module_size != self.module_size:
            self.whisper_model_path = whisper_model_path or DEFAULT_WHISPER_MODEL_PATH
            self.module_size = module_size
            self.whisper_model = get_whisper().load_model(self.module_size, download_root=self.whisper_model_path)
def get_whisper_model(module_size: str = "base", whisper_model_path: str = None):
    whisper_mgr = whisperManager(module_size=module_size,whisper_model_path=whisper_model_path)
    return whisper_mgr.whisper_model


def whisper_transcribe(
    audio_path: str,
    model_size: str = "small",
    language: str = "english",
    use_silence: bool = True,
    task=None,
    whisper_model_path: str = None
):
    if not os.path.isfile(audio_path):
        raise ValueError(
            f"Audio File doesnt exist {audio_path}"
        )
    model = get_whisper_model(module_size=model_size, whisper_model_path=whisper_model_path)
    return model.transcribe(audio_path, language=language)


    return metadata
def extract_audio_from_video(video_path: str, audio_path: str = None):
    """Extract audio from a video file using moviepy."""
    if audio_path == None:
        video_directory = os.path.dirname(video_path)
        audio_path = video_directory
    if os.path.isdir(audio_path):
        audio_path = os.path.join(audio_path,'audio.wav')
    try:
        logger.info(f"Extracting audio from {video_path} to {audio_path}")
        video = get_moviepy("mp").VideoFileClip(video_path)
        video.audio.write_audiofile(audio_path)
        video.close()
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Audio file {audio_path} was not created.")
        logger.info(f"Audio extracted successfully: {audio_path}")
        return audio_path
    except Exception as e:
        logger.error(f"Error extracting audio from {video_path}: {e}")
        return None

def transcribe_from_video(
    video_path,
    audio_path: str = None,
    model_size: str = "small",
    language: str = "english",
    use_silence: bool = True,
    task=None,
    whisper_model_path: str = None):
    audio_path = extract_audio_from_video(video_path)
    return whisper_transcribe(
        audio_path=audio_path,
        model_size =model_size,
        language= language,
        use_silence= use_silence,
        task=task,
        whisper_model_path=whisper_model_path
        )
    
def transcribe_file(
    path,
    model_size: str = "small",
    language: str = "english",
    use_silence: bool = True,
    task=None,
    whisper_model_path: str = None):
    audio_path=None
    media_type = derive_media_type(path)
    if media_type == 'audio':
        audio_path = path
    if media_type == 'video':
        audio_path = extract_audio_from_video(path)
    if audio_path:
        return whisper_transcribe(
            audio_path=audio_path,
            model_size =model_size,
            language= language,
            use_silence= use_silence,
            task=task,
            whisper_model_path=whisper_model_path
            )
