"""One-time script to generate compressed MNIST subset for bundling."""
import numpy as np
import struct
from pathlib import Path

raw_dir = Path("data_mnist/MNIST/raw")
out_path = Path("openwandb/data/mnist_demo.npz")
out_path.parent.mkdir(parents=True, exist_ok=True)

def read_idx_images(path):
    with open(path, 'rb') as f:
        magic, n, rows, cols = struct.unpack('>4I', f.read(16))
        return np.frombuffer(f.read(), dtype=np.uint8).reshape(n, rows, cols)

def read_idx_labels(path):
    with open(path, 'rb') as f:
        magic, n = struct.unpack('>2I', f.read(8))
        return np.frombuffer(f.read(), dtype=np.uint8)

train_img = read_idx_images(raw_dir / "train-images-idx3-ubyte")
train_lbl = read_idx_labels(raw_dir / "train-labels-idx1-ubyte")
test_img = read_idx_images(raw_dir / "t10k-images-idx3-ubyte")
test_lbl = read_idx_labels(raw_dir / "t10k-labels-idx1-ubyte")

print("Train: %s, Test: %s" % (train_img.shape, test_img.shape))

# Save subset: 10K train + 2K test
np.savez_compressed(str(out_path),
    train_images=train_img[:10000],
    train_labels=train_lbl[:10000],
    test_images=test_img[:2000],
    test_labels=test_lbl[:2000])

size_mb = out_path.stat().st_size / 1024 / 1024
print("Saved to %s (%.2f MB)" % (out_path, size_mb))

# Verify
d = np.load(str(out_path))
for k in d.files:
    print("  %s: %s %s" % (k, d[k].shape, d[k].dtype))
