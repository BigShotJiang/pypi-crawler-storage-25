﻿"""Allow running as `python -m xcat`."""
from xcat.cli import main

main()
