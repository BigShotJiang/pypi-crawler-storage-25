"""SDK client surface — ``AsyncClient`` (native) and ``Client`` (sync wrapper).

Per ``docs/spec/05-sdk-contract.md`` "Lifecycle" + "Identity context"
sections, this module hosts:

- ``AsyncClient`` for native async hosts.
- ``Client`` (sync) wrapping the async machinery via a managed event-loop
  thread. Both share the same context, transport, and buffer surface
  shape — the global default returned by :func:`init` is whichever the
  caller asks for via ``kind="sync"|"async"``.
- ``start_task_run`` / ``start_span`` context managers.
- ``shutdown()``.

Critical invariant: no public method may raise. Failures flow to
``_logger`` and the appropriate ``_metrics`` counter.
"""

from __future__ import annotations

import asyncio
import threading
from collections.abc import AsyncIterator, Awaitable, Iterator
from contextlib import asynccontextmanager, contextmanager, suppress
from typing import Any, TypeVar, cast

from ._config import Config
from ._context import (
    IdentityContext,
    current_context,
    pop_context,
    push_context,
    set_initial_context,
)
from ._flags import FlagCache, FlagRefresher
from ._flags import evaluate as evaluate_flag
from ._ids import new_span_id, new_trace_id, uuid7
from ._logger import get_logger
from ._metrics import Metrics
from ._redact import Redactor, RedactorPipeline
from ._transport import Transport, _utcnow

_T = TypeVar("_T")
_log = get_logger("client")


def _ensure_uuid_str(value: str | None) -> str:
    if value:
        return value
    return str(uuid7())


class AsyncClient:
    """Async-native client. Runs inside the caller's event loop."""

    def __init__(
        self,
        config: Config,
        *,
        http_client: Any | None = None,
    ) -> None:
        self._config = config
        self._metrics = Metrics()
        self._transport = Transport(config, self._metrics, http_client=http_client)
        self._redactors = RedactorPipeline()
        self._flag_cache = FlagCache()
        self._flag_refresher: FlagRefresher | None = None
        self._started = False
        self._closed = False
        if not config.disable:
            set_initial_context(
                agent_id=config.agent_id,
                project_id=config.project_id,
                environment=config.environment,
            )

    # ---- Lifecycle --------------------------------------------------------

    async def _ensure_started(self) -> None:
        if self._started or self._config.disable:
            return
        self._transport.start()
        self._started = True

    async def _ensure_flag_refresher(self) -> None:
        """Lazy: only spin up the 60s poll once ``flag()`` is actually called."""
        if self._config.disable:
            return
        if self._flag_refresher is None:
            self._flag_refresher = FlagRefresher(
                self._flag_cache,
                self._transport.http_client,
                self._config.endpoint,
                self._config.api_key,
            )
            self._flag_refresher.start()

    async def shutdown(self) -> None:
        """Flush and close. Idempotent. Never raises."""
        if self._closed:
            return
        self._closed = True
        if self._flag_refresher is not None:
            try:
                await self._flag_refresher.stop()
            except Exception:
                _log.warning("flag refresher stop failed", exc_info=True)
        try:
            await self._transport.aclose()
        except Exception:
            _log.warning("transport close failed", exc_info=True)

    # ---- Context managers -------------------------------------------------

    @asynccontextmanager
    async def start_task_run(
        self,
        agent_id: str | None = None,
        *,
        task_run_id: str | None = None,
        trace_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> AsyncIterator[IdentityContext]:
        """Push a task_run context. Generates ids where missing.

        Refuses to push without an ``agent_id`` (init or arg). Per
        contract: never silently drop to "unknown". On refusal we log
        and yield an empty context so the host code keeps running.
        """
        await self._ensure_started()
        resolved_agent = agent_id or current_context().agent_id or self._config.agent_id
        if not resolved_agent:
            _log.error(
                "start_task_run called with no agent_id (init nor arg); "
                "events emitted in this scope will be refused"
            )
            empty = IdentityContext()
            token = push_context(empty)
            try:
                yield empty
            finally:
                pop_context(token)
            return

        new_ctx = current_context().with_task_run(
            agent_id=resolved_agent,
            task_run_id=task_run_id or str(uuid7()),
            trace_id=trace_id,
            user_id=user_id,
            session_id=session_id,
        )
        token = push_context(new_ctx)
        try:
            yield new_ctx
        finally:
            pop_context(token)

    @asynccontextmanager
    async def start_span(self, name: str, kind: str = "internal") -> AsyncIterator[IdentityContext]:
        """Push a child span. Annotation-only at this layer; emit on log_*."""
        await self._ensure_started()
        del name, kind  # Used by integration layers; ids are what matters here.
        new_ctx = current_context().child_span()
        token = push_context(new_ctx)
        try:
            yield new_ctx
        finally:
            pop_context(token)

    # ---- Emit -------------------------------------------------------------

    async def emit(
        self,
        event_type: str,
        properties: dict[str, Any],
        *,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
    ) -> str | None:
        """Build, validate, enqueue an event. Returns ``event_id`` if buffered.

        Public manual-log methods land in Prompt 6; this is the
        underlying path they call into. Used by tests in this prompt.
        """
        if self._config.disable:
            return None
        await self._ensure_started()
        try:
            ctx = current_context()
            resolved_agent = agent_id or ctx.agent_id or self._config.agent_id
            if not resolved_agent:
                _log.warning(
                    "refusing to emit %s: no agent_id (init, start_task_run, or arg)",
                    event_type,
                )
                self._metrics.incr("events_validation_failed")
                return None

            synthetic = ctx.task_run_id is None
            resolved_task_run = task_run_id or ctx.task_run_id or str(uuid7())
            resolved_trace = ctx.trace_id or new_trace_id()
            # v0.1.1: every emit gets its own ``span_id`` so that two
            # back-to-back ``log_*`` (or two auto-instrumented LLM calls)
            # inside one ``start_task_run`` don't collapse into a single
            # node when the query API assembles the trace tree (it keys
            # spans_by_id on span_id and overwrites duplicates). The
            # current context's ``span_id`` becomes the new event's
            # ``parent_span_id`` — so explicit ``start_span`` blocks
            # still group their children correctly.
            resolved_span = new_span_id()
            resolved_parent = ctx.span_id

            event_id = uuid7()
            event_dict: dict[str, Any] = {
                "event_id": event_id,
                "event_type": event_type,
                "timestamp": _utcnow(),
                "trace_id": resolved_trace,
                "span_id": resolved_span,
                "parent_span_id": resolved_parent,
                "agent_id": resolved_agent,
                "task_run_id": resolved_task_run,
                "user_id": user_id or ctx.user_id,
                "session_id": session_id or ctx.session_id,
                "environment": environment or ctx.environment or self._config.environment,
                "sdk_name": self._config.sdk_name,
                "sdk_version": self._config.sdk_version,
                "properties": properties,
            }
            if self._config.project_id:
                event_dict["project_id"] = self._config.project_id

            self._redactors.maybe_warn_pii(event_dict.get("user_id"))
            event_dict = self._redactors.apply(event_dict)
            buffered = self._transport.enqueue(event_dict)
            if synthetic and buffered:
                _log.debug("emitted %s under synthetic task_run %s", event_type, resolved_task_run)
            return str(event_id) if buffered else None
        except Exception:
            _log.warning("emit failed unexpectedly", exc_info=True)
            return None

    async def flush(self) -> None:
        """Force a buffer drain. Never raises."""
        try:
            await self._transport.flush()
        except Exception:
            _log.warning("flush failed", exc_info=True)

    # ---- Manual log_* surface --------------------------------------------

    async def log_llm_call(
        self,
        model: str,
        system: str,
        *,
        input: list[Any] | None = None,
        output: list[Any] | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        total_tokens: int | None = None,
        duration_ms: float | None = None,
        finish_reason: str | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        max_tokens: int | None = None,
        response_id: str | None = None,
        error: dict[str, Any] | None = None,
        stream: bool | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.llm_call`` event. Honors ``capture_content=False``."""
        capture = self._config.capture_content
        props: dict[str, Any] = {
            "gen_ai.system": system,
            "gen_ai.request.model": model,
        }
        if temperature is not None:
            props["gen_ai.request.temperature"] = temperature
        if top_p is not None:
            props["gen_ai.request.top_p"] = top_p
        if max_tokens is not None:
            props["gen_ai.request.max_tokens"] = max_tokens
        if response_id is not None:
            props["gen_ai.response.id"] = response_id
        if finish_reason is not None:
            props["gen_ai.response.finish_reason"] = finish_reason
        if input_tokens is not None:
            props["gen_ai.usage.input_tokens"] = input_tokens
        if output_tokens is not None:
            props["gen_ai.usage.output_tokens"] = output_tokens
        if total_tokens is not None:
            props["gen_ai.usage.total_tokens"] = total_tokens
        if duration_ms is not None:
            props["duration_ms"] = duration_ms
        if error is not None:
            props["error"] = error
        if stream is not None:
            props["stream"] = stream
        if capture:
            if input is not None:
                props["input"] = input
            if output is not None:
                props["output"] = output
        props.update(extra)
        return await self.emit(
            "agent.llm_call",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_tool_call(
        self,
        name: str,
        *,
        input: Any = None,
        output: Any = None,
        status: str | None = None,
        duration_ms: float | None = None,
        error: dict[str, Any] | None = None,
        description: str | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.tool_call`` event. Honors ``capture_content=False``."""
        capture = self._config.capture_content
        props: dict[str, Any] = {"tool.name": name}
        if description is not None:
            props["tool.description"] = description
        if status is not None:
            props["tool.status"] = status
        if duration_ms is not None:
            props["duration_ms"] = duration_ms
        if error is not None:
            props["error"] = error
        if capture:
            if input is not None:
                props["tool.input"] = input
            if output is not None:
                props["tool.output"] = output
        props.update(extra)
        return await self.emit(
            "agent.tool_call",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_eval(
        self,
        name: str,
        score: float,
        *,
        label: str | None = None,
        reason: str | None = None,
        evaluator: str | None = None,
        ref_span_id: str | None = None,
        ref_task_run_id: str | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.eval`` event."""
        props: dict[str, Any] = {"eval.name": name, "eval.score": score}
        if label is not None:
            props["eval.label"] = label
        if reason is not None:
            props["eval.reason"] = reason
        if evaluator is not None:
            props["eval.evaluator"] = evaluator
        if ref_span_id is not None:
            props["eval.ref_span_id"] = ref_span_id
        if ref_task_run_id is not None:
            props["eval.ref_task_run_id"] = ref_task_run_id
        props.update(extra)
        return await self.emit(
            "agent.eval",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_business_event(
        self,
        name: str,
        *,
        revenue: float | None = None,
        currency: str | None = None,
        metadata: dict[str, Any] | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.business_event``."""
        props: dict[str, Any] = {"business.event_name": name}
        if revenue is not None:
            props["business.revenue"] = revenue
        if currency is not None:
            props["business.currency"] = currency
        if metadata is not None:
            props["business.metadata"] = metadata
        props.update(extra)
        return await self.emit(
            "agent.business_event",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_security_alert(
        self,
        alert_type: str,
        severity: str,
        *,
        description: str | None = None,
        scanner: str | None = None,
        action_taken: str | None = None,
        ref_span_id: str | None = None,
        details: dict[str, Any] | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.security_alert`` event."""
        props: dict[str, Any] = {
            "security.alert_type": alert_type,
            "security.severity": severity,
        }
        if description is not None:
            props["security.description"] = description
        if scanner is not None:
            props["security.scanner"] = scanner
        if action_taken is not None:
            props["security.action_taken"] = action_taken
        if ref_span_id is not None:
            props["security.ref_span_id"] = ref_span_id
        if details is not None:
            props["security.details"] = details
        props.update(extra)
        return await self.emit(
            "agent.security_alert",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_handoff(
        self,
        target_agent_id: str,
        *,
        reason: str | None = None,
        context: dict[str, Any] | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.handoff`` event."""
        props: dict[str, Any] = {"target_agent_id": target_agent_id}
        if reason is not None:
            props["reason"] = reason
        if context is not None:
            props["context"] = context
        props.update(extra)
        return await self.emit(
            "agent.handoff",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    async def log_retrieval(
        self,
        source: str,
        *,
        query: str | None = None,
        top_k: int | None = None,
        results_count: int | None = None,
        documents: list[Any] | None = None,
        duration_ms: float | None = None,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
        **extra: Any,
    ) -> str | None:
        """Emit an ``agent.retrieval_query`` event. Honors ``capture_content=False``."""
        capture = self._config.capture_content
        props: dict[str, Any] = {"retrieval.source": source}
        if top_k is not None:
            props["retrieval.top_k"] = top_k
        if results_count is not None:
            props["retrieval.results_count"] = results_count
        if duration_ms is not None:
            props["duration_ms"] = duration_ms
        if capture:
            if query is not None:
                props["retrieval.query"] = query
            if documents is not None:
                props["retrieval.documents"] = documents
        props.update(extra)
        return await self.emit(
            "agent.retrieval_query",
            props,
            agent_id=agent_id,
            task_run_id=task_run_id,
            user_id=user_id,
            session_id=session_id,
            environment=environment,
        )

    # ---- Flags ------------------------------------------------------------

    async def flag(
        self,
        key: str,
        default: Any,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        **context_extra: Any,
    ) -> Any:
        """Resolve a flag locally and emit ``agent.flag_check``.

        Returns the resolved value, or ``default`` if the cache has no
        entry for ``key``. Per the contract: no per-call network — the
        background refresher keeps the cache fresh every 60s.
        """
        await self._ensure_started()
        await self._ensure_flag_refresher()
        ctx = current_context()
        evaluation_context: dict[str, Any] = {
            "user_id": user_id or ctx.user_id,
            "agent_id": agent_id or ctx.agent_id or self._config.agent_id,
            "session_id": ctx.session_id,
            "environment": ctx.environment or self._config.environment,
        }
        evaluation_context.update(context_extra)

        flag_def = self._flag_cache.get(key)
        if flag_def is None:
            if self._flag_cache.is_empty:
                _log.warning("flag cache empty (or never fetched); returning default for %r", key)
            value = default
            variant: str | None = None
            reason = "default"
            experiment_id: str | None = None
        else:
            value, variant, reason = evaluate_flag(flag_def, evaluation_context)
            if value is None:
                value = default
            experiment_id = flag_def.experiment_id

        await self.emit(
            "agent.flag_check",
            {
                "flag.key": key,
                "flag.value": value,
                "flag.variant": variant,
                "flag.experiment_id": experiment_id,
                "flag.reason": reason,
            },
            user_id=user_id,
            agent_id=agent_id,
        )
        return value

    # ---- Routing ----------------------------------------------------------

    async def route(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        candidates: list[str] | None = None,
    ) -> dict[str, Any] | None:
        """POST ``/v1/routing/decide`` (or sidecar route_decide).

        Returns ``{"arm_id", "model", "decision_span_id"}`` on success,
        ``None`` on failure. Routes through the AgentRun sidecar when
        ``AGENTOS_RUNTIME=1``; direct HTTPS otherwise.
        """
        await self._ensure_started()
        from ._runtime import get_runtime_client

        runtime = get_runtime_client()
        if runtime is not None:
            try:
                return await runtime.route_decide(goal, context, candidates)
            except Exception:
                _log.warning("runtime route_decide failed", exc_info=True)
                return None

        body: dict[str, Any] = {"goal": goal}
        if context is not None:
            body["context"] = context
        if candidates is not None:
            body["candidates"] = candidates
        return await self._post_routing("/v1/routing/decide", body)

    async def route_outcome(
        self,
        decision_span_id: str,
        *,
        reward: float | None = None,
        success: bool | None = None,
        duration_ms: float | None = None,
        cost_usd: float | None = None,
        feedback_kind: str = "human",
        **extra: Any,
    ) -> dict[str, Any] | None:
        """POST ``/v1/routing/outcome`` (or sidecar route_outcome)."""
        await self._ensure_started()
        from ._runtime import get_runtime_client

        body: dict[str, Any] = {
            "decision_span_id": decision_span_id,
            "feedback_kind": feedback_kind,
        }
        if reward is not None:
            body["reward"] = reward
        if success is not None:
            body["success"] = success
        if duration_ms is not None:
            body["duration_ms"] = duration_ms
        if cost_usd is not None:
            body["cost_usd"] = cost_usd
        body.update(extra)

        runtime = get_runtime_client()
        if runtime is not None:
            try:
                return await runtime.route_outcome(
                    decision_span_id, **{k: v for k, v in body.items() if k != "decision_span_id"}
                )
            except Exception:
                _log.warning("runtime route_outcome failed", exc_info=True)
                return None
        return await self._post_routing("/v1/routing/outcome", body)

    async def _post_routing(self, path: str, body: dict[str, Any]) -> dict[str, Any] | None:
        url = f"{self._config.endpoint.rstrip('/')}{path}"
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self._config.api_key:
            headers["X-API-Key"] = self._config.api_key
        try:
            resp = await self._transport.http_client.post(
                url, json=body, headers=headers, timeout=10.0
            )
        except Exception:
            _log.warning("routing %s transport failure", path, exc_info=True)
            return None
        if not (200 <= resp.status_code < 300):
            _log.warning("routing %s returned status %d", path, resp.status_code)
            return None
        try:
            data = resp.json()
        except Exception:
            _log.warning("routing %s payload parse failed", path, exc_info=True)
            return None
        return data if isinstance(data, dict) else None

    # ---- Privacy ----------------------------------------------------------

    def add_redactor(self, fn: Redactor) -> None:
        """Append a redactor. Order is registration order."""
        self._redactors.add(fn)

    # ---- Test / advanced hooks -------------------------------------------

    @property
    def flag_cache(self) -> FlagCache:
        return self._flag_cache

    # ---- Introspection ----------------------------------------------------

    @property
    def metrics(self) -> dict[str, int]:
        """Snapshot of internal counters."""
        return self._metrics.snapshot()

    def on_metric(self, callback: Any) -> None:
        """Register a metric callback ``cb(name, delta)``."""
        self._metrics.add_callback(callback)

    @property
    def config(self) -> Config:
        return self._config

    # Internal hook for tests / fork handler.
    def _reset_after_fork(self) -> None:
        self._transport.reset_after_fork()
        self._started = False


class _LoopThread:
    """Background asyncio loop for the sync client to dispatch onto."""

    def __init__(self) -> None:
        self.loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._thread = threading.Thread(target=self._run, name="agentos-sdk", daemon=True)
        self._thread.start()
        self._ready.wait(timeout=5.0)

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)
        self._ready.set()
        try:
            self.loop.run_forever()
        finally:
            with suppress(Exception):
                self.loop.close()

    def run(self, coro: Awaitable[_T], timeout: float | None = None) -> _T:
        future = asyncio.run_coroutine_threadsafe(cast("Any", coro), self.loop)
        return cast("_T", future.result(timeout=timeout))

    def stop(self) -> None:
        if self.loop.is_running():
            self.loop.call_soon_threadsafe(self.loop.stop)
        self._thread.join(timeout=5.0)


class Client:
    """Synchronous client. Wraps :class:`AsyncClient` via a loop thread."""

    def __init__(
        self,
        config: Config,
        *,
        http_client: Any | None = None,
    ) -> None:
        self._loop_thread = _LoopThread()
        # Build the async client on the worker loop so its lock /
        # event objects bind to the right loop from the start.
        self._async = self._loop_thread.run(self._build_async(config, http_client))

    @staticmethod
    async def _build_async(config: Config, http_client: Any | None) -> AsyncClient:
        return AsyncClient(config, http_client=http_client)

    # ---- Lifecycle --------------------------------------------------------

    def shutdown(self) -> None:
        """Flush, close, and stop the worker loop."""
        try:
            self._loop_thread.run(
                self._async.shutdown(), timeout=self._async.config.shutdown_timeout_s + 2
            )
        except Exception:
            _log.warning("sync shutdown failed", exc_info=True)
        finally:
            self._loop_thread.stop()

    def flush(self) -> None:
        try:
            self._loop_thread.run(self._async.flush(), timeout=10.0)
        except Exception:
            _log.warning("sync flush failed", exc_info=True)

    # ---- Context managers -------------------------------------------------

    @contextmanager
    def start_task_run(
        self,
        agent_id: str | None = None,
        *,
        task_run_id: str | None = None,
        trace_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> Iterator[IdentityContext]:
        # Run start_task_run in a worker-thread coroutine so the
        # contextvars stack inherited there is the worker's. Caller's
        # thread also gets a context push for emit() to inherit from.
        ctx = current_context().with_task_run(
            agent_id=(agent_id or current_context().agent_id or self._async.config.agent_id),
            task_run_id=task_run_id or str(uuid7()),
            trace_id=trace_id,
            user_id=user_id,
            session_id=session_id,
        )
        if not ctx.agent_id:
            _log.error(
                "start_task_run called with no agent_id (init nor arg); "
                "events emitted in this scope will be refused"
            )
        token = push_context(ctx)
        try:
            yield ctx
        finally:
            pop_context(token)

    @contextmanager
    def start_span(self, name: str, kind: str = "internal") -> Iterator[IdentityContext]:
        del name, kind
        ctx = current_context().child_span()
        token = push_context(ctx)
        try:
            yield ctx
        finally:
            pop_context(token)

    # ---- Emit -------------------------------------------------------------

    def emit(
        self,
        event_type: str,
        properties: dict[str, Any],
        *,
        agent_id: str | None = None,
        task_run_id: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        environment: str | None = None,
    ) -> str | None:
        # Snapshot the caller's context so the worker-loop coroutine
        # sees the same identity stack. Without this the worker thread
        # would always see the empty default contextvar.
        ctx = current_context()

        async def _go() -> str | None:
            token = push_context(ctx)
            try:
                return await self._async.emit(
                    event_type,
                    properties,
                    agent_id=agent_id,
                    task_run_id=task_run_id,
                    user_id=user_id,
                    session_id=session_id,
                    environment=environment,
                )
            finally:
                pop_context(token)

        try:
            return self._loop_thread.run(_go(), timeout=10.0)
        except Exception:
            _log.warning("sync emit failed", exc_info=True)
            return None

    # ---- Manual log_* surface (sync wrappers) ----------------------------

    def _dispatch(self, coro: Any, timeout: float = 10.0) -> Any:
        try:
            return self._loop_thread.run(coro, timeout=timeout)
        except Exception:
            _log.warning("sync dispatch failed", exc_info=True)
            return None

    def log_llm_call(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_llm_call(*args, **kwargs))),
        )

    def log_tool_call(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_tool_call(*args, **kwargs))),
        )

    def log_eval(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_eval(*args, **kwargs))),
        )

    def log_business_event(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_business_event(*args, **kwargs))),
        )

    def log_security_alert(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_security_alert(*args, **kwargs))),
        )

    def log_handoff(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_handoff(*args, **kwargs))),
        )

    def log_retrieval(self, *args: Any, **kwargs: Any) -> str | None:
        ctx = current_context()
        return cast(
            "str | None",
            self._dispatch(self._with_ctx(ctx, self._async.log_retrieval(*args, **kwargs))),
        )

    @staticmethod
    async def _with_ctx(ctx: IdentityContext, coro: Awaitable[_T]) -> _T:
        token = push_context(ctx)
        try:
            return await coro
        finally:
            pop_context(token)

    # ---- Flags / routing / redactors --------------------------------------

    def flag(self, key: str, default: Any, **kwargs: Any) -> Any:
        ctx = current_context()
        return self._dispatch(self._with_ctx(ctx, self._async.flag(key, default, **kwargs)))

    def route(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        candidates: list[str] | None = None,
    ) -> dict[str, Any] | None:
        return cast(
            "dict[str, Any] | None",
            self._dispatch(self._async.route(goal, context, candidates), timeout=15.0),
        )

    def route_outcome(self, decision_span_id: str, **kwargs: Any) -> dict[str, Any] | None:
        return cast(
            "dict[str, Any] | None",
            self._dispatch(self._async.route_outcome(decision_span_id, **kwargs), timeout=15.0),
        )

    def add_redactor(self, fn: Redactor) -> None:
        self._async.add_redactor(fn)

    @property
    def flag_cache(self) -> FlagCache:
        return self._async.flag_cache

    # ---- Introspection ----------------------------------------------------

    @property
    def metrics(self) -> dict[str, int]:
        return self._async.metrics

    def on_metric(self, callback: Any) -> None:
        self._async.on_metric(callback)

    @property
    def config(self) -> Config:
        return self._async.config

    def _reset_after_fork(self) -> None:
        # The parent's loop thread doesn't survive the fork (only the
        # calling thread continues in the child). Discard the dead state
        # and rebuild a fresh loop thread + AsyncClient — the existing
        # asyncio.Lock / asyncio.Event are bound to the dead loop and
        # would deadlock if reused.
        config = self._async.config
        self._loop_thread = _LoopThread()
        self._async = self._loop_thread.run(self._build_async(config, None))
