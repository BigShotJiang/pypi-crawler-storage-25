"""Test ``agenthog._client`` AsyncClient + Client."""

from __future__ import annotations

import logging

import httpx
import pytest

from agenthog._client import AsyncClient, Client
from agenthog._config import Config

from .conftest import (
    MakeAsyncClient,
    MakeSyncClient,
    MockServer,
    business_event_props,
    llm_call_props,
)

# ---- Synthetic task_run for orphaned events --------------------------------


async def test_log_outside_task_run_creates_synthetic(make_async_client: MakeAsyncClient) -> None:
    client, server = make_async_client()
    try:
        # No start_task_run wrapping — should still emit with a fresh task_run_id.
        event_id = await client.emit("agent.business_event", business_event_props())
        assert event_id is not None
        await client.flush()
        events = server.events_received
        assert len(events) == 1
        assert events[0]["task_run_id"]  # auto-populated
        assert events[0]["agent_id"] == "agent-test"
    finally:
        await client.shutdown()


async def test_log_with_no_agent_id_anywhere_is_refused(
    make_async_client: MakeAsyncClient, caplog: pytest.LogCaptureFixture
) -> None:
    client, server = make_async_client(agent_id=None)
    try:
        with caplog.at_level(logging.WARNING, logger="agenthog.sdk"):
            event_id = await client.emit("agent.business_event", business_event_props())
        assert event_id is None
        await client.flush()
        assert server.request_count == 0
        assert any("agent_id" in rec.message for rec in caplog.records)
        assert client.metrics["events_validation_failed"] >= 1
    finally:
        await client.shutdown()


# ---- Sync vs async parity --------------------------------------------------


async def test_sync_and_async_produce_equivalent_streams(
    make_async_client: MakeAsyncClient,
) -> None:
    # Async path
    aclient, aserver = make_async_client(flush_batch_size=2)
    try:
        async with aclient.start_task_run("agent-test"):
            await aclient.emit("agent.llm_call", llm_call_props())
            await aclient.emit("agent.business_event", business_event_props())
        await aclient.flush()
    finally:
        await aclient.shutdown()

    async_events = aserver.events_received
    assert len(async_events) == 2
    assert {e["event_type"] for e in async_events} == {
        "agent.llm_call",
        "agent.business_event",
    }


def test_sync_client_emits_through_loop_thread(make_sync_client: MakeSyncClient) -> None:
    client, server = make_sync_client(flush_batch_size=2)
    try:
        with client.start_task_run("agent-test"):
            assert client.emit("agent.llm_call", llm_call_props()) is not None
            assert client.emit("agent.business_event", business_event_props()) is not None
        client.flush()
    finally:
        client.shutdown()
    events = server.events_received
    assert len(events) == 2
    types = {e["event_type"] for e in events}
    assert types == {"agent.llm_call", "agent.business_event"}


# ---- Per-event unique span_id (v0.1.1 regression guard) -------------------


async def test_each_emit_gets_a_unique_span_id_under_one_task_run(
    make_async_client: MakeAsyncClient,
) -> None:
    """Two emits inside one start_task_run must produce different span_ids.

    Regression guard for the v0.1.0 bug where every emit inherited the
    task_run's root span_id from context. The platform's trace tree
    assembly (services/query/app/traces.py) keys spans_by_id on
    span_id and overwrites duplicates, so duplicate span_ids made
    events disappear from the tree even though they landed in the
    events table.
    """
    client, server = make_async_client(flush_batch_size=4)
    try:
        async with client.start_task_run("agent-test") as ctx:
            await client.emit("agent.llm_call", llm_call_props())
            await client.emit("agent.business_event", business_event_props())
            await client.emit("agent.eval", {"eval.name": "x", "eval.score": 0.5})
        await client.flush()
    finally:
        await client.shutdown()

    events = server.events_received
    assert len(events) == 3
    span_ids = [e["span_id"] for e in events]
    assert len(set(span_ids)) == 3, f"expected 3 unique span_ids, got {span_ids}"
    # All three share the same trace_id (same task_run)
    trace_ids = {e["trace_id"] for e in events}
    assert len(trace_ids) == 1
    # All three share the same parent_span_id (the task_run's root span)
    parent_ids = {e["parent_span_id"] for e in events}
    assert len(parent_ids) == 1
    assert ctx.span_id in parent_ids


# ---- Metrics hook ----------------------------------------------------------


async def test_metrics_counters_advance(make_async_client: MakeAsyncClient) -> None:
    client, _server = make_async_client(flush_batch_size=1)
    seen: list[tuple[str, int]] = []

    def cb(name: str, delta: int) -> None:
        seen.append((name, delta))

    client.on_metric(cb)
    try:
        await client.emit("agent.business_event", business_event_props())
        await client.flush()
        assert client.metrics["events_sent"] == 1
        assert any(name == "events_sent" for name, _ in seen)
    finally:
        await client.shutdown()


# ---- disable=True ----------------------------------------------------------


async def test_disable_true_is_no_op(make_async_client: MakeAsyncClient) -> None:
    client, server = make_async_client(disable=True)
    try:
        result = await client.emit("agent.business_event", business_event_props())
        assert result is None
        await client.flush()
        assert server.request_count == 0
        assert client.metrics["events_sent"] == 0
        assert client.metrics["events_validation_failed"] == 0
    finally:
        await client.shutdown()


# ---- Never raises ----------------------------------------------------------


async def test_emit_does_not_raise_on_validation_failure(
    make_async_client: MakeAsyncClient,
) -> None:
    client, _ = make_async_client()
    try:
        # Bad schema: agent.llm_call requires gen_ai.system + gen_ai.request.model.
        result = await client.emit("agent.llm_call", {"gen_ai.system": "openai"})
        assert result is None
        assert client.metrics["events_validation_failed"] >= 1
    finally:
        await client.shutdown()


async def test_emit_does_not_raise_on_unknown_event_type(
    make_async_client: MakeAsyncClient,
) -> None:
    client, _ = make_async_client()
    try:
        result = await client.emit("agent.unknown_type", {})
        assert result is None
    finally:
        await client.shutdown()


def _broken_handler(req: httpx.Request) -> httpx.Response:
    raise httpx.ConnectError("simulated outage", request=req)


def test_sync_client_does_not_raise_on_network_outage() -> None:
    config = Config.from_env_and_args(
        api_key="test",
        endpoint="http://mock",
        agent_id="agent-x",
        flush_interval_ms=50,
        flush_batch_size=1,
        max_retries=2,
        shutdown_timeout_s=2.0,
        sdk_version="0.1.0-test",
    )
    http = httpx.AsyncClient(transport=httpx.MockTransport(_broken_handler))
    client = Client(config, http_client=http)
    try:
        # Public methods don't raise even when the network is broken.
        with client.start_task_run("agent-x"):
            assert client.emit("agent.business_event", business_event_props()) is not None
        client.flush()
        # Counter records the permanent failure after retries are exhausted.
        assert client.metrics["events_failed_permanent"] >= 1
    finally:
        client.shutdown()


# ---- Sync ↔ async event_id stability ---------------------------------------


async def test_event_id_is_stable_across_retries_via_client(
    make_async_client: MakeAsyncClient,
) -> None:
    server = MockServer(
        responses=[httpx.Response(503), httpx.Response(503), httpx.Response(200, json={})]
    )
    config = Config.from_env_and_args(
        api_key="test",
        endpoint="http://mock",
        agent_id="agent-x",
        flush_batch_size=1,
        flush_interval_ms=50,
        max_retries=5,
        sdk_version="0.1.0-test",
    )
    http = httpx.AsyncClient(transport=httpx.MockTransport(server.handler))
    client = AsyncClient(config, http_client=http)
    try:
        ev_id = await client.emit("agent.business_event", business_event_props())
        await client.flush()
        ids = [body["events"][0]["event_id"] for body in server.bodies]
        assert len(ids) == 3
        assert ids[0] == ids[1] == ids[2] == ev_id
    finally:
        await client.shutdown()
