#!/usr/bin/env python

import importlib
import logging
import os
import pathlib
from typing import Callable, Literal

import jsonargparse
import optuna
import torch
import yaml
from tbparse import SummaryReader
from torch import nn
from torch.utils.tensorboard import SummaryWriter

from .lr_scheduler import MyLrScheduler
from .initializer import MyInitializer
from .optimizer import MyOptimizer
from .logger import get_logger
from .test import MyTest
from .train import MyTrain


class Objective:
    def __init__(
        self,
        hpo_parser: jsonargparse.ArgumentParser,
        get_train_parser: Callable,
        logger: logging.Logger,
    ) -> None:
        self.hpo_parser = hpo_parser
        self.get_train_parser = get_train_parser
        self.logger = logger
        cfg = hpo_parser.parse_args(hpo_parser.args).train
        _, preprocess, _, model_cls = cfg.model.class_path.rsplit(".", 3)
        self.checkpoints_parent = (
            pathlib.Path(cfg.train.output_dir)
            / "checkpoints"
            / preprocess
            / model_cls
            / cfg.dataset.init_args.name
        )
        self.logs_parent = (
            pathlib.Path(cfg.train.output_dir)
            / "logs"
            / preprocess
            / model_cls
            / cfg.dataset.init_args.name
        )

    def __call__(self, trial: optuna.Trial):
        cfg = self.hpo_parser.parse_args(self.hpo_parser.args)
        trial_name = f"{cfg.train.train.trial_name}-{trial._trial_id}"
        checkpoints_path = self.checkpoints_parent / trial_name
        logs_path = self.logs_parent / trial_name
        os.makedirs(checkpoints_path, exist_ok=True)
        model_module, model_cls = cfg.train.model.class_path.rsplit(".", 1)

        self.logger.info("mandatory train config")
        cfg.train.train.trial_name = trial_name
        cfg.train.train.last_epoch = -1
        cfg.train.train.evaluation_only = False

        if issubclass(
            getattr(importlib.import_module(model_module), model_cls), nn.Module
        ):
            self.logger.info("choose initializer config")
            MyInitializer.hpo(trial, cfg.train)

            self.logger.info("choose optimizer config")
            MyOptimizer.hpo(trial, cfg.train, cfg.hpo.learning_rate_range)

            self.logger.info("choose lr_scheduler config")
            MyLrScheduler.hpo(trial, cfg.train)

        self.logger.info("choose dataset config")
        dataset_module, dataset_cls = cfg.train.dataset.class_path.rsplit(".", 1)
        getattr(importlib.import_module(dataset_module), dataset_cls).hpo(
            trial, cfg.train
        )

        self.logger.info("choose metric config")
        for metric in cfg.train.metric:
            metric_module, metric_cls = metric.class_path.rsplit(".", 1)
            getattr(importlib.import_module(metric_module), metric_cls).hpo(
                trial, cfg.train
            )

        self.logger.info("choose model config")
        getattr(importlib.import_module(model_module), model_cls).hpo(trial, cfg.train)

        self.logger.info("write train config")
        train_parser = self.get_train_parser()
        train_parser.save(
            cfg.train,
            checkpoints_path / "train.yaml",
            overwrite=True,
        )
        train_parser.args = ["--config", os.fspath(checkpoints_path / "train.yaml")]

        self.logger.info("write test config")
        with open(checkpoints_path / "test.yaml", "w") as fd:
            yaml.dump(
                {
                    "checkpoints_path": os.fspath(checkpoints_path),
                    "logs_path": os.fspath(logs_path),
                    "target": cfg.hpo.target,
                    "maximize_target": cfg.hpo.maximize_target,
                    "overwrite": {},
                },
                fd,
            )

        # train
        for epoch in MyTrain(**cfg.train.train.as_dict())(train_parser):
            df = SummaryReader(os.fspath(logs_path / "train"), pivot=True).scalars
            trial.report(
                value=df.loc[df["step"] == epoch, f"eval/{cfg.hpo.target}"].item(),
                step=epoch,
            )
            if trial.should_prune():
                break

        # test
        epoch = MyTest(
            checkpoints_path=checkpoints_path,
            logs_path=logs_path,
            target=cfg.hpo.target,
            maximize_target=cfg.hpo.maximize_target,
            overwrite={},
        )(train_parser)
        df = SummaryReader(os.fspath(logs_path / "test"), pivot=True).scalars
        target_metric_val = df.loc[df["step"] == epoch, f"test/{cfg.hpo.target}"].item()
        tensorboard_writer = SummaryWriter(self.logs_parent / "hpo")
        hparam_dict = {
            param_name: (
                param_val
                if isinstance(param_val, int)
                or isinstance(param_val, float)
                or isinstance(param_val, str)
                or isinstance(param_val, bool)
                or isinstance(param_val, torch.Tensor)
                else str(param_val)
            )
            for param_name, param_val in trial.params.items()
        }
        tensorboard_writer.add_hparams(
            hparam_dict=hparam_dict,
            metric_dict={f"test/{cfg.hpo.target}": target_metric_val},
            global_step=trial._trial_id,
        )
        tensorboard_writer.close()

        return target_metric_val


class MyHpo:
    def __init__(
        self,
        target: str,
        maximize_target: bool,
        learning_rate_range: list[float],
        study_name: str,
        n_trials: int,
        sampler: Literal[
            "GridSampler",
            "RandomSampler",
            "TPESampler",
            "CmaEsSampler",
            "GPSampler",
            "PartialFixedSampler",
            "NSGAIISampler",
            "QMCSampler",
        ],
        pruner: Literal[
            "MedianPruner",
            "NopPruner",
            "PatientPruner",
            "PercentilePruner",
            "SuccessiveHalvingPruner",
            "HyperbandPruner",
            "ThresholdPruner",
            "WilcoxonPruner",
        ],
        load_if_exists: bool,
        **kwargs,
    ):
        """Arguments of Hpo.

        Args:
            target: target metric name.
            maximize_target: maximize the target (false to minimize the target).
            learning_rate_range: range of learning rate of optimizer.
            study_name: the name of the study.
            n_trials: the total number of trials in the study.
            sampler: sampler continually narrows down the search space using the records of suggested parameter values and evaluated objective values.
            pruner: pruner to stop unpromising trials at the early stages.
            load_if_exists: flag to control the behavior to handle a conflict of study names. In the case where a study named study_name already exists in the storage.
        """

    def __call__(
        self,
        hpo_parser: jsonargparse.ArgumentParser,
        get_train_parser: Callable,
    ) -> None:
        cfg = hpo_parser.parse_args(hpo_parser.args)
        logger = get_logger(**cfg.train.logger.as_dict())

        logger.info("instantiate objective")
        objective = Objective(
            hpo_parser=hpo_parser,
            get_train_parser=get_train_parser,
            logger=logger,
        )

        logger.info("instantiate study")
        os.makedirs(objective.logs_parent, exist_ok=True)
        study = optuna.create_study(
            storage=optuna.storages.JournalStorage(
                optuna.storages.journal.JournalFileBackend(
                    os.fspath(objective.logs_parent / "optuna_journal_storage.log")
                ),
            ),
            sampler=getattr(
                importlib.import_module("optuna.samplers"), cfg.hpo.sampler
            )(),
            pruner=getattr(importlib.import_module("optuna.pruners"), cfg.hpo.pruner)(),
            study_name=cfg.hpo.study_name,
            direction="maximize" if cfg.hpo.maximize_target else "minimize",
            load_if_exists=cfg.hpo.load_if_exists,
        )

        logger.info("start study")
        study.optimize(
            func=objective,
            n_trials=cfg.hpo.n_trials,
        )
