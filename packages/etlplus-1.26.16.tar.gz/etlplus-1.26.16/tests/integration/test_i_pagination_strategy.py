"""
:mod:`tests.integration.test_i_pagination_strategy` module.

Integration tests for pagination strategies. We mock API extraction for both
page/offset and cursor modes and drive the CLI entry point to exercise the
public path under real configuration semantics.

Notes
-----
- Pagination logic resides on ``EndpointClient.paginate_url``; patching the
    RequestManager ``request_once`` helper suffices to intercept page fetches.
- Some legacy paths still use module-level extractors; we patch both the
    Typer handlers and :mod:`etlplus.ops.extract` for safety.
- ``time.sleep`` is neutralized to keep tests fast and deterministic.
"""

from __future__ import annotations

import importlib
import sys
import time
from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent
from textwrap import indent
from typing import TYPE_CHECKING
from typing import Any

import pytest

import etlplus.api._request_manager as rm_mod
from etlplus.cli import main
from etlplus.cli._handlers import dataops as dataops_mod

from .conftest import FakeEndpointClients
from .conftest import PipelineCfgFactory
from .conftest import RunPatched

# SECTION: PRAGMAS ========================================================== #

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

if TYPE_CHECKING:  # pragma: no cover - typing helpers only
    from tests.pytest_shared_support import JsonFileParser
    from tests.pytest_shared_support import JsonOutputParser

# SECTION: HELPERS ========================================================== #


extract_mod = importlib.import_module('etlplus.ops.extract')


def _build_api_pipeline_yaml(
    *,
    name: str,
    job_name: str,
    out_path: Path,
    options_block: str,
    source_url: str = 'https://example.test/api',
) -> str:
    """Render a minimal pipeline YAML for a single API source job."""

    cleaned_block = dedent(options_block).strip()
    if not cleaned_block:
        msg = 'options_block must not be empty'
        raise ValueError(msg)

    indented_options = indent(cleaned_block, ' ' * 8)

    return (
        f"""
name: {name}
sources:
  - name: src
    type: api
    url: {source_url}
targets:
  - name: dest
    type: file
    format: json
    path: {out_path}
jobs:
  - name: {job_name}
    extract:
      source: src
      options:
{indented_options}
    load:
        target: dest
"""
    ).strip()


@dataclass(slots=True)
class PageScenario:
    """Test scenario for page/offset pagination."""

    name: str
    page_size: int
    pages: list[list[dict[str, int]]]
    expected_ids: list[int]
    max_records: int | None = None

    def render_options_block(self) -> str:
        """Render a pagination options block for page-based scenarios."""

        max_records_line = (
            f'\n      max_records: {self.max_records}'
            if self.max_records is not None
            else ''
        )
        return dedent(
            f"""
            pagination:
                type: page
                page_param: page
                size_param: per_page
                page_size: {self.page_size}{max_records_line}
            """,
        )


@dataclass(slots=True)
class CursorBatch:
    """Single cursor pagination batch definition."""

    records: list[dict[str, Any]]
    next_cursor: str | None


@dataclass(slots=True)
class CursorScenario:
    """Cursor pagination scenario definition for CLI integration tests."""

    name: str
    page_size: int
    batches: tuple[CursorBatch, ...]
    expected_ids: list[str]
    options_block: str
    records_key: str = 'data'

    def render_options_block(self) -> str:
        """Return the dedented pagination block for the scenario."""

        return dedent(self.options_block)


CURSOR_SCENARIOS = (
    pytest.param(
        CursorScenario(
            name='cursor_records_path_explicit',
            page_size=2,
            records_key='data',
            expected_ids=['a', 'b', 'c'],
            options_block="""
            pagination:
                type: cursor
                cursor_param: cursor
                cursor_path: next
                page_size: 2
                records_path: data
            """,
            batches=(
                CursorBatch(
                    records=[{'id': 'a'}, {'id': 'b'}],
                    next_cursor='tok1',
                ),
                CursorBatch(records=[{'id': 'c'}], next_cursor=None),
            ),
        ),
        id='cursor_records_path_explicit',
    ),
    pytest.param(
        CursorScenario(
            name='cursor_records_path_inferred',
            page_size=2,
            records_key='items',
            expected_ids=['x', 'y', 'z'],
            options_block="""
            pagination:
              type: cursor
              cursor_param: cursor
              cursor_path: next
              page_size: 2
              # records_path intentionally omitted
            """,
            batches=(
                CursorBatch(
                    records=[{'id': 'x'}, {'id': 'y'}],
                    next_cursor='tok1',
                ),
                CursorBatch(records=[{'id': 'z'}], next_cursor=None),
            ),
        ),
        id='cursor_records_path_inferred',
    ),
)

PAGE_SCENARIOS = (
    pytest.param(
        PageScenario(
            name='page_offset_basic',
            page_size=2,
            pages=[[{'id': 1}, {'id': 2}], [{'id': 3}]],
            expected_ids=[1, 2, 3],
        ),
        id='page_offset_basic',
    ),
    pytest.param(
        PageScenario(
            name='page_offset_trim',
            page_size=3,
            pages=[[{'id': 1}, {'id': 2}, {'id': 3}], [{'id': 4}]],
            expected_ids=[1, 2],
            max_records=2,
        ),
        id='page_offset_trim',
    ),
)


@dataclass(slots=True)
class PaginationEdgeCase:
    """Edge-case pagination scenario definitions."""

    name: str
    pagination: dict[str, Any]
    expect: dict[str, Any]


PAGINATION_EDGE_CASES = (
    pytest.param(
        PaginationEdgeCase(
            name='page_zero_start_coerces_to_one',
            pagination={
                'type': 'page',
                'page_param': 'page',
                'size_param': 'per_page',
                'start_page': 0,
                'page_size': 10,
            },
            expect={'type': 'page', 'start_page': 1, 'page_size': 10},
        ),
        id='page_zero_start_coerces_to_one',
    ),
    pytest.param(
        PaginationEdgeCase(
            name='page_zero_size_coerces_default',
            pagination={
                'type': 'page',
                'page_param': 'page',
                'size_param': 'per_page',
                'start_page': 1,
                'page_size': 0,
            },
            expect={'type': 'page', 'start_page': 1, 'page_size': 100},
        ),
        id='page_zero_size_coerces_default',
    ),
    pytest.param(
        PaginationEdgeCase(
            name='cursor_zero_size_coerces_default',
            pagination={
                'type': 'cursor',
                'cursor_param': 'cursor',
                'cursor_path': 'next',
                'page_size': 0,
            },
            expect={'type': 'cursor', 'page_size': 100},
        ),
        id='cursor_zero_size_coerces_default',
    ),
    pytest.param(
        PaginationEdgeCase(
            name='limits_pass_through',
            pagination={
                'type': 'page',
                'page_param': 'page',
                'size_param': 'per_page',
                'start_page': 1,
                'page_size': 5,
                'max_pages': 2,
                'max_records': 3,
            },
            expect={'type': 'page', 'max_pages': 2, 'max_records': 3},
        ),
        id='limits_pass_through',
    ),
)


def _run_pipeline_and_collect(
    *,
    capsys: pytest.CaptureFixture[str],
    parse_json_output: JsonOutputParser,
    parse_json_file: JsonFileParser,
    out_path: Path,
    pipeline_cli_runner: Callable[..., str],
    pipeline_yaml: str,
    job_name: str,
    extract_func: Callable[..., Any],
) -> list[dict[str, Any]]:
    """Run the CLI pipeline and return parsed output rows.

    Parameters
    ----------
    capsys : pytest.CaptureFixture[str]
        Pytest capture fixture for CLI STDOUT.
    parse_json_output : JsonOutputParser
        Helper that parses JSON from CLI output.
    parse_json_file : JsonFileParser
        Helper that parses JSON from a file path.
    out_path : Path
        File path where the pipeline writes JSON results.
    pipeline_cli_runner : Callable[..., str]
        Helper that writes the YAML to disk and invokes the CLI.
    pipeline_yaml : str
        YAML configuration to execute.
    job_name : str
        Job name passed to the CLI ``--job`` flag.
    extract_func : Callable[..., Any]
        Fake API extractor used to satisfy HTTP calls.

    Returns
    -------
    list[dict[str, Any]]
        Parsed JSON rows written by the pipeline run.
    """

    pipeline_cli_runner(
        yaml_text=pipeline_yaml,
        run_name=job_name,
        extract_func=extract_func,
    )

    payload = parse_json_output(capsys.readouterr().out)
    assert payload.get('status') == 'ok'
    return parse_json_file(out_path)


# SECTION: FIXTURES ========================================================= #


@pytest.fixture(name='pipeline_cli_runner')
def pipeline_cli_runner_fixture(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> Callable[..., str]:
    """
    Provide a helper that runs the CLI against a temporary pipeline.

    Parameters
    ----------
    tmp_path : Path
        Temporary directory provided by pytest.
    monkeypatch : pytest.MonkeyPatch
        Fixture used to patch CLI dependencies.

    Returns
    -------
    Callable[..., str]
        Runner that writes the pipeline YAML, patches HTTP helpers, and
        returns the resulting config path.
    """

    def _run(
        *,
        yaml_text: str,
        run_name: str,
        extract_func: Callable[..., Any],
        request_func: Callable[..., Any] | None = None,
    ) -> str:
        """Run the CLI with the given pipeline YAML and patched extractors."""
        pipeline_path = tmp_path / 'pipeline.yml'
        pipeline_path.write_text(yaml_text, encoding='utf-8')
        cfg_path = str(pipeline_path)
        monkeypatch.setattr(dataops_mod, 'extract', extract_func)
        monkeypatch.setattr(extract_mod, 'extract', extract_func)

        def _default_request(
            self: rm_mod.RequestManager,
            method: str,
            url: str,
            *,
            session: Any,
            timeout: Any,
            **kwargs: Any,
        ) -> Any:
            return extract_func('api', url, **kwargs)

        monkeypatch.setattr(
            rm_mod.RequestManager,
            'request_once',
            request_func or _default_request,
        )
        monkeypatch.setattr(
            sys,
            'argv',
            ['etlplus', 'run', '--config', cfg_path, '--job', run_name],
        )
        rc = main()
        assert rc == 0
        return cfg_path

    return _run


# SECTION: TESTS ============================================================ #


class TestPaginationStrategies:
    """Integration tests for pagination strategies."""

    @pytest.fixture(autouse=True)
    def _no_sleep(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """
        Disable time.sleep to keep pagination tests fast and deterministic.
        """
        monkeypatch.setattr(time, 'sleep', lambda _s: None)

    @pytest.mark.parametrize(
        'scenario',
        CURSOR_SCENARIOS,
    )
    def test_cursor_modes(
        self,
        scenario: CursorScenario,
        tmp_path: Path,
        capsys: pytest.CaptureFixture[str],
        pipeline_cli_runner: Callable[..., str],
        parse_json_output: JsonOutputParser,
        parse_json_file: JsonFileParser,
    ) -> None:
        """
        Test end-to-end cursor-based pagination via the CLI.

        Parameters
        ----------
        scenario : CursorScenario
            Cursor pagination scenario to execute.
        tmp_path : Path
            Temporary directory managed by pytest.
        capsys : pytest.CaptureFixture[str]
            Capture fixture for CLI STDOUT/STDERR.
        pipeline_cli_runner : Callable[..., str]
            Helper that materializes and executes the pipeline configuration.
        parse_json_output : JsonOutputParser
            Helper that parses JSON from CLI output.
        parse_json_file : JsonFileParser
            Helper that parses JSON from a file path.
        """

        out_path = tmp_path / f'{scenario.name}.json'
        pipeline_yaml = _build_api_pipeline_yaml(
            name=scenario.name,
            job_name=f'job_{scenario.name}',
            out_path=out_path,
            options_block=scenario.render_options_block(),
        )

        cursor_tracker: dict[str, str | None] = {'expected': None}
        batches = iter(scenario.batches)

        def fake_extract(kind: str, _url: str, **kwargs: Any):
            assert kind == 'api'
            params = kwargs.get('params') or {}
            cur = params.get('cursor')
            limit = int(params.get('limit', scenario.page_size))
            assert cur == cursor_tracker['expected']
            assert limit == scenario.page_size

            try:
                batch = next(batches)
            except StopIteration:
                return {scenario.records_key: [], 'next': None}

            cursor_tracker['expected'] = batch.next_cursor
            return {
                scenario.records_key: batch.records,
                'next': batch.next_cursor,
            }

        data = _run_pipeline_and_collect(
            capsys=capsys,
            parse_json_output=parse_json_output,
            parse_json_file=parse_json_file,
            out_path=out_path,
            pipeline_cli_runner=pipeline_cli_runner,
            pipeline_yaml=pipeline_yaml,
            job_name=f'job_{scenario.name}',
            extract_func=fake_extract,
        )
        assert [r['id'] for r in data] == scenario.expected_ids

    @pytest.mark.parametrize(
        'scenario',
        PAGE_SCENARIOS,
    )
    def test_page_offset_modes(
        self,
        scenario: PageScenario,
        tmp_path: Path,
        capsys: pytest.CaptureFixture[str],
        pipeline_cli_runner: Callable[..., str],
        parse_json_output: JsonOutputParser,
        parse_json_file: JsonFileParser,
    ) -> None:
        """Test end-to-end page/offset pagination via the CLI."""
        out_path = tmp_path / f'{scenario.name}.json'
        job_name = f'job_{scenario.name}'

        pipeline_yaml = _build_api_pipeline_yaml(
            name=scenario.name,
            job_name=job_name,
            out_path=out_path,
            options_block=scenario.render_options_block(),
        )

        # Mock extract to return scenario-driven items per page.
        def fake_extract(kind: str, _url: str, **kwargs: Any):
            assert kind == 'api'
            params = kwargs.get('params') or {}
            page = int(params.get('page', 1))
            size = int(params.get('per_page', scenario.page_size))
            # Calculate remaining max_records for this request, if set
            remaining = scenario.max_records
            if remaining is not None:
                # Estimate how many records have already been emitted
                # (page-1)*size is a safe upper bound for this test's structure
                already_emitted = (page - 1) * size
                remaining = max(0, remaining - already_emitted)
                if remaining == 0:
                    return {'items': []}
                size = min(size, remaining)
            # Pages are 1-indexed; return up to 'size' records for this page.
            if 1 <= page <= len(scenario.pages):
                page_records = scenario.pages[page - 1][:size]
                return {'items': page_records}
            return {'items': []}

        data = _run_pipeline_and_collect(
            capsys=capsys,
            parse_json_output=parse_json_output,
            parse_json_file=parse_json_file,
            out_path=out_path,
            pipeline_cli_runner=pipeline_cli_runner,
            pipeline_yaml=pipeline_yaml,
            job_name=job_name,
            extract_func=fake_extract,
        )
        assert [r['id'] for r in data] == scenario.expected_ids

    @pytest.mark.parametrize(
        'scenario',
        PAGINATION_EDGE_CASES,
    )
    def test_pagination_edge_cases(
        self,
        scenario: PaginationEdgeCase,
        pipeline_cfg_factory: PipelineCfgFactory,
        fake_endpoint_client: FakeEndpointClients,
        run_patched: RunPatched,
    ) -> None:  # noqa: D401
        """
        Test pagination-coalescing edge cases with shared fixtures.

        This drives the runner wiring directly (not CLI) to assert the exact
        pagination mapping seen by the client after defaults/overrides.
        """
        cfg = pipeline_cfg_factory(
            extract_options={'pagination': deepcopy(scenario.pagination)},
        )

        fake_client, created = fake_endpoint_client
        result = run_patched(cfg, fake_client)

        assert result.get('status') in {'ok', 'success'}
        assert created, 'Expected client to be constructed'

        seen_pag = created[0].seen.get('pagination')
        assert isinstance(seen_pag, dict)
        assert scenario.expect.items() <= seen_pag.items()
