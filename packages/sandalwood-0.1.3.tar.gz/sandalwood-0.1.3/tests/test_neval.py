import numpy as np
import pytest

try:
    import torch

    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False
from sandalwood import mtf


# Old eval logic for comparison
def old_eval(mtf, evaluation_point):
    """The old eval logic for comparison."""
    evaluation_point = np.array(evaluation_point)
    term_values = np.prod(np.power(evaluation_point, mtf.exponents), axis=1)
    result = np.einsum("j,j->", mtf.coeffs, term_values)
    return result


@pytest.fixture(autouse=True)
def reset_mtf():
    """Resets the MTF library before and after each test."""
    mtf._INITIALIZED = False
    yield
    mtf._INITIALIZED = False


@pytest.fixture
def sample_mtf(backend_implementation):
    """A sample MTF for testing."""
    implementation = backend_implementation

    mtf.initialize_mtf(max_order=2, max_dimension=2, implementation=implementation)
    x = mtf.var(1, 2)
    y = mtf.var(2, 2)
    return x**2 + 2 * x * y + y**2 + 1


def test_neval_single_point(sample_mtf):
    """Tests neval with a single point and compares with old eval."""
    point = np.array([1.0, 2.0])

    # Expected result from old eval
    expected = old_eval(sample_mtf, point)

    # Result from neval
    result = sample_mtf.neval(point.reshape(1, -1))

    assert result.shape == (1,)
    assert np.allclose(result[0], expected)


def test_neval_multiple_points(sample_mtf):
    """Tests neval with multiple points."""
    points = np.array([[1.0, 2.0], [3.0, 4.0], [0.0, 0.0]])

    expected = np.array([
        old_eval(sample_mtf, points[0]),
        old_eval(sample_mtf, points[1]),
        old_eval(sample_mtf, points[2]),
    ])

    result = sample_mtf.neval(points)

    assert result.shape == (3,)
    assert np.allclose(result, expected)


def test_neval_error_handling(sample_mtf):
    """Tests the error handling of neval."""
    with pytest.raises(ValueError):
        # Incorrect dimension
        sample_mtf.neval(np.array([[1.0]]))

    with pytest.raises(ValueError):
        # Incorrect shape
        sample_mtf.neval(np.array([1.0, 2.0, 3.0]))


def test_eval_wrapper(sample_mtf):
    """Tests the new eval wrapper."""
    point = np.array([1.0, 2.0])

    # Expected result from old eval
    expected = old_eval(sample_mtf, point)

    # Result from new eval
    result = sample_mtf.eval(point)

    assert np.allclose(result, expected)

    # Test with 2D input
    result_2d = sample_mtf.eval(point.reshape(1, -1))
    assert np.allclose(result_2d, expected)

    # Test error handling for 2D input with more than one point
    with pytest.raises(ValueError):
        sample_mtf.eval(np.array([[1.0, 2.0], [3.0, 4.0]]))


@pytest.mark.skipif(not _TORCH_AVAILABLE, reason="torch not installed")
def test_neval_torch_tensor(sample_mtf):
    """Tests neval with a torch tensor (basic CPU, no grad path).

    The grad-tracking and device-safety paths are tested separately in
    test_neval_torch_requires_grad_safe and test_neval_torch_atleast_2d_correctness.
    """
    points = torch.tensor([[1.0, 2.0], [3.0, 4.0], [0.0, 0.0]], dtype=torch.float64)

    expected = np.array([
        old_eval(sample_mtf, points[0].numpy()),
        old_eval(sample_mtf, points[1].numpy()),
        old_eval(sample_mtf, points[2].numpy()),
    ])

    result = sample_mtf.neval(points)

    assert isinstance(result, torch.Tensor)
    assert result.shape == (3,)
    assert np.allclose(result.numpy(), expected)


def test_neval_large_batch(sample_mtf):
    """Tests neval with a batch size larger than the internal chunk size (10000)."""
    # Create 15000 points to trigger batching
    N = 15000
    points = np.ones((N, 2))

    # We know f(1,1) = 1^2 + 2*1*1 + 1^2 + 1 = 5
    # for sample_mtf = x^2 + 2xy + y^2 + 1

    # Ensure batched path is taken (if Numba not available) or just verified
    result = sample_mtf.neval(points)

    assert result.shape == (N,)
    assert np.allclose(result, 5.0)


@pytest.mark.skipif(not _TORCH_AVAILABLE, reason="torch not installed")
def test_neval_torch_requires_grad_safe(sample_mtf):
    """neval must not raise when given a requires_grad=True tensor.

    Guards TorchBackend.to_numpy detach-and-warn fix from feat/backend-hardening.
    Before the fix, passing a grad-tracked tensor raised RuntimeError deep
    inside PyTorch's numpy() call.
    """
    import warnings

    points = torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=torch.float64, requires_grad=True)

    # Should not raise; a UserWarning about gradient detachment is acceptable.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        result = sample_mtf.neval(points)

    # Result must still be numerically correct
    expected = np.array([
        old_eval(sample_mtf, [1.0, 2.0]),
        old_eval(sample_mtf, [3.0, 4.0]),
    ])
    if isinstance(result, torch.Tensor):
        result = result.detach().numpy()
    assert np.allclose(result, expected)


@pytest.mark.skipif(not _TORCH_AVAILABLE, reason="torch not installed")
def test_neval_torch_atleast_2d_correctness(sample_mtf):
    """neval with a single-row 2-D torch tensor must return shape (1,).

    Guards the exponents.reshape(1, -1) portability fix in taylor_function.neval
    introduced in feat/backend-hardening (replaces np.newaxis compound index
    which behaved differently for torch tensors).
    """
    single_point = torch.tensor([[1.0, 2.0]], dtype=torch.float64)  # shape (1, 2)
    result = sample_mtf.neval(single_point)

    expected = old_eval(sample_mtf, [1.0, 2.0])

    if isinstance(result, torch.Tensor):
        result_val = result.detach().numpy()
    else:
        result_val = result

    assert result_val.shape == (1,)
    assert np.allclose(result_val[0], expected)
