# TODO — haracz

## Phase 1 — MVP: Compare UoP vs JDG Ryczałt with Currency

The goal: `haracz compare 94450 --currency NOK` shows a rich table comparing offers.

| Task | Naive | Coop | Notes |
|------|-------|------|-------|
| config.py — TaxYear + ZUS + Health dataclasses | 1 hr | 15 min | From research docs, pure dataclasses |
| models.py — Breakdown + Comparison results | 45 min | 10 min | Typed frozen dataclasses |
| money.py — Decimal rounding (grosz, zloty) | 20 min | 5 min | Three functions |
| calculators/common.py — shared ZUS + PIT logic | 1 hr | 20 min | Core math |
| calculators/uop.py — gross→net (12-month) | 1.5 hr | 25 min | Month-by-month with bracket crossing |
| calculators/jdg_ryczalt.py — ryczałt 12% | 30 min | 10 min | Simpler — flat rate on revenue |
| compare.py — orchestrate + produce Comparison | 30 min | 10 min | Runs both, packages results |
| currency.py — NBP API + fallbacks | 45 min | 15 min | httpx with offline fallback |
| cli/formatters.py — Rich tables + panels | 1 hr | 20 min | The pretty part |
| cli/app.py + cli/compare.py — compare command | 45 min | 15 min | Thin wrapper calling lib |
| cli/uop.py + cli/jdg.py — individual commands | 30 min | 10 min | Simple single-scenario |
| tests — UoP, ryczałt, compare | 1 hr | 20 min | Verify against known values |
| uv init + install + smoke test | 15 min | 5 min | End-to-end verify |

**Phase 1 total: ~3 hours coop, 1 session**

## Phase 2 — Remaining Calculators + Detail View

| Task | Naive | Coop | Notes |
|------|-------|------|-------|
| calculators/jdg_liniowy.py — 19% flat | 30 min | 10 min | Reuses common.py |
| calculators/jdg_skala.py — 12%/32% | 45 min | 15 min | Progressive, same as UoP PIT logic |
| uop.py net→gross — binary search | 30 min | 10 min | Reverse calculation |
| Employer cost breakdown | 20 min | 5 min | Simple multiplier |
| --detailed flag — month-by-month table | 45 min | 15 min | 12-row rich table |
| Update compare to include all forms | 20 min | 10 min | Wire in new calculators |
| Tests for Phase 2 | 45 min | 15 min | Edge cases |

**Phase 2 total: ~1.5 hours coop, 1 session**

## Phase 3 — Server + Config + Polish

| Task | Naive | Coop | Notes |
|------|-------|------|-------|
| server/app.py — FastAPI endpoints matching CLI | 1 hr | 20 min | /compare, /uop, /jdg, /convert |
| Pydantic models for request/response | 30 min | 10 min | Mirror the lib models |
| TOML config loading | 30 min | 10 min | TaxYear.from_toml |
| CLAUDE.md | 15 min | 5 min | Project docs |
| README polish + examples | 20 min | 10 min | Screenshots, usage |
| v0.2.0 release | 10 min | 5 min | Tag + push |

**Phase 3 total: ~1 hour coop, 1 session**

---

## Summary

| Phase | What | Coop | Sessions |
|-------|------|------|----------|
| **Phase 1 — MVP** | UoP + ryczałt + compare + currency + CLI | ~3 hours | 1 |
| Phase 2 — Full calculators | liniowy + skala + reverse + detailed | ~1.5 hours | 1 |
| Phase 3 — Server + config | FastAPI + TOML + polish | ~1 hour | 1 |
| **Total** | | **~5.5 hours** | **2-3 sessions** |

MVP is one session. You'll be comparing offers tonight.
