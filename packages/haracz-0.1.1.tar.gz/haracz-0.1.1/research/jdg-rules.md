# JDG / B2B Tax Rules — 2025/2026

## Available Tax Forms

| Form | Rate | Notes |
|---|---|---|
| Skala podatkowa | 12% up to 120,000 PLN, 32% above | Kwota wolna 30,000. Health NOT deductible |
| Podatek liniowy | 19% flat | No kwota wolna. Health partially deductible (~11,600 PLN/yr cap) |
| Ryczałt — IT (PKD 62.0x) | 12% of revenue | No cost deduction. 50% of health deductible from revenue |
| Ryczałt — other rates | 8.5%, 15%, 17% | Depends on PKWiU classification |
| IP Box | 5% on qualifying IP income | Requires R&D documentation, nexus ratio. Compatible with liniowy/skala |

## ZUS Contributions (Monthly Estimates)

Base for preferencyjny = 30% of minimalne wynagrodzenie.
Base for pełny = 60% of prognozowane przeciętne wynagrodzenie.

| Component | Rate | Preferencyjny (~24 mo) | Pełny ZUS |
|---|---|---|---|
| Emerytalne | 19.52% | ~271 PLN | ~812 PLN |
| Rentowe | 8.00% | ~111 PLN | ~332 PLN |
| Chorobowe | 2.45% | ~34 PLN | ~102 PLN |
| Wypadkowe | ~1.67% | ~23 PLN | ~69 PLN |
| Fundusz Pracy | 2.45% | N/A | ~102 PLN |
| **Total (ex. health)** | | **~439 PLN** | **~1,417 PLN** |

Note: JDG pays BOTH employee and employer share of emerytalne/rentowe (hence 19.52% and 8%).

### Mały ZUS Plus

- Eligibility: prior-year revenue < 120,000 PLN
- Base: 50% of average monthly income, floored at 30% of min. wage
- Max 36 months in any 60-month window

## Składka Zdrowotna (Health Contribution)

| Tax Form | Calculation | Minimum |
|---|---|---|
| Skala podatkowa | 9% of income (rev - costs) | 9% of min. wage (~420 PLN) |
| Podatek liniowy | 4.9% of income | 9% of min. wage (~420 PLN) |
| Ryczałt < 60k rev | ~419 PLN/mo (9% of 60% avg wage) | fixed |
| Ryczałt 60k–300k | ~698 PLN/mo (9% of 100% avg wage) | fixed |
| Ryczałt > 300k | ~1,257 PLN/mo (9% of 180% avg wage) | fixed |

### Deductibility

| Tax Form | Health Deductible? |
|---|---|
| Skala | NO |
| Liniowy | Partially — capped at ~11,600 PLN/year from tax base |
| Ryczałt | 50% deductible from revenue |

## VAT

| Item | Value |
|---|---|
| Registration threshold | 200,000 PLN annual revenue |
| Domestic IT services | 23% VAT |
| B2B services to EU clients | Reverse charge (no Polish VAT) |
| Non-EU clients | Outside scope of Polish VAT |

## A1 Certificate & Foreign Clients

- Working for foreign clients **from Poland**: standard Polish ZUS/tax rules apply
- Travelling to EU client's country: obtain **A1 certificate** from ZUS (proves Polish social security coverage, avoids double contributions)
- Non-EU clients: no A1 needed
- Double tax treaties: check credit vs exemption method per country
