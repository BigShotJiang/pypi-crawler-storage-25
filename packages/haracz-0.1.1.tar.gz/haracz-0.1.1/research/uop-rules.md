# UoP (Umowa o Pracę) Tax Rules — 2025/2026

## PIT — Personal Income Tax

| Item | Value |
|---|---|
| First bracket | 12% up to 120,000 PLN/year |
| Second bracket | 32% above 120,000 PLN/year |
| Kwota wolna od podatku | 30,000 PLN/year |

## ZUS Employee Contributions

| Contribution | Rate |
|---|---|
| Emerytalne (retirement) | 9.76% |
| Rentowe (disability) | 1.50% |
| Chorobowe (sickness) | 2.45% |
| **Total social** | **13.71%** |
| Zdrowotne (health) | 9% of (gross - social contributions) |

Note: Zdrowotne is NOT deductible from PIT (since 2022 Polski Ład reform).

## ZUS Employer Contributions

| Contribution | Rate |
|---|---|
| Emerytalne (retirement) | 9.76% |
| Rentowe (disability) | 6.50% |
| Wypadkowe (accident) | 1.67% (standard; varies 0.67%–3.33%) |
| Fundusz Pracy (FP) | 2.45% |
| FGŚP | 0.10% |
| **Total employer** | **~20.48%** |

## ZUS Annual Cap (Limit Roczny)

Emerytalne and rentowe capped at 30x projected average monthly salary.
- 2025: 268,680 PLN
- 2026 estimate: ~280,000–290,000 PLN (depends on GUS announcement)

## Koszty Uzyskania Przychodu (Tax-Deductible Costs)

| Type | Monthly | Annual |
|---|---|---|
| Standard (single employer) | 250 PLN | 3,000 PLN |
| Elevated (commuting) | 300 PLN | 3,600 PLN |
| Standard (multiple employers) | 250 PLN each | max 4,500 PLN |
| Elevated (multiple employers) | 300 PLN each | max 5,400 PLN |

## Ulga Podatkowa (Tax Relief)

| Item | Value |
|---|---|
| Annual | 3,600 PLN (= 12% × 30,000 kwota wolna) |
| Monthly (via PIT-2) | 300 PLN |

Only applies in the 12% bracket.

## Minimum Wage

- 2025: 4,666 PLN (Jan), 4,785 PLN (Jul)
- 2026: expected ~4,900–5,100 PLN (verify Rozporządzenie Rady Ministrów)

## Special Rules

- **Ulga dla młodych (under 26):** PIT exempt on employment income up to 85,528 PLN/year. ZUS and health still apply.
- **PPK:** Employee 2% (default, up to 4%), Employer 1.5% (default, up to 4%).
