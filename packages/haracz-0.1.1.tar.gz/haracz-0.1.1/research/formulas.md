# Calculation Formulas

## UoP Gross-to-Net

```
INPUT: brutto (gross monthly salary)

Step 1 — ZUS Social Contributions (employee):
  emerytalne  = gross × 9.76%
  rentowe     = gross × 1.50%
  chorobowe   = gross × 2.45%
  zus_social  = gross × 13.71%

Step 2 — Health Contribution:
  podstawa_zdrowotnego = gross - zus_social
  zdrowotna = podstawa_zdrowotnego × 9%
  (NOT tax deductible)

Step 3 — Tax Base:
  podstawa = gross - zus_social - KUP
  KUP = 250 PLN/month (standard) or 300 PLN/month (commuting)
  Round DOWN to full złoty

Step 4 — PIT:
  If cumulative annual podstawa <= 120,000:
    pit = podstawa × 12% - ulga (300 PLN/month)
  If cumulative annual podstawa > 120,000:
    pit = podstawa × 32% (no ulga in 32% bracket)
  Round to full złoty

Step 5 — Net:
  netto = gross - zus_social - zdrowotna - pit

OUTPUT: netto
```

### Note on ZUS Annual Cap

When cumulative (emerytalne + rentowe) base reaches the annual cap (~280k PLN), stop deducting emerytalne and rentowe for remaining months. Chorobowe has no cap.

## Employer Cost (Koszt Pracodawcy)

```
employer_zus = gross × (9.76% + 6.50% + 1.67% + 2.45% + 0.10%)
            = gross × 20.48%

total_employer_cost = gross + employer_zus
                   = gross × 1.2048

With PPK:
  employer_ppk = gross × 1.5% (default)
  total = gross × 1.2048 + employer_ppk
```

## JDG Net Income Calculations

### Common Base

```
INPUT: monthly_revenue, monthly_costs, zus_type (full/preferential)

zus_social = (from ZUS table — fixed monthly amount, not % of revenue)
```

### Podatek Liniowy (19% flat)

```
income = revenue - costs - zus_social
zdrowotna = max(income × 4.9%, minimum_zdrowotna)
tax_base = income  (zdrowotna partially deductible up to cap ~11,600/yr)
pit = tax_base × 19%

net = revenue - costs - zus_social - zdrowotna - pit
```

### Skala Podatkowa (12%/32%)

```
income = revenue - costs - zus_social
zdrowotna = max(income × 9%, minimum_zdrowotna)
tax_base = income  (zdrowotna NOT deductible)

If cumulative annual tax_base <= 120,000:
  pit = tax_base × 12% - ulga (300/month)
Else:
  pit = 14,400 + (tax_base - 120,000) × 32%

net = revenue - costs - zus_social - zdrowotna - pit
```

### Ryczałt

```
INPUT: monthly_revenue, ryczalt_rate (8.5%, 12%, 15%)

zus_social = (from ZUS table)
zdrowotna = (fixed bracket based on annual revenue tier)

# 50% of zdrowotna is deductible from revenue
deductible_zdrowotna = zdrowotna × 50%
tax_base = revenue - deductible_zdrowotna
pit = tax_base × ryczalt_rate

net = revenue - zus_social - zdrowotna - pit
```

Note: Ryczałt has NO cost deduction — tax is on revenue, not profit.

## Comparison Summary

For a given employer budget (koszt pracodawcy):

```
UoP:
  gross = budget / 1.2048
  netto = gross-to-net formula above

JDG (invoice amount = budget, no VAT for simplicity):
  revenue = budget
  costs = (business expenses)
  net = JDG formula per chosen tax form
```

## Special Rules

| Rule | Effect |
|---|---|
| Ulga dla młodych (< 26) | PIT exempt up to 85,528 PLN/yr. ZUS + health still apply |
| PPK employee | 2% of gross reduces netto (optional, default opt-in) |
| PPK employer | 1.5% of gross added to employer cost |
| IP Box | 5% PIT on qualifying IP income instead of standard rate |
| ZUS annual cap | Emerytalne + rentowe stop when base hits ~280k PLN |
