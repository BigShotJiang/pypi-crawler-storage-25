"""UoP (Umowa o Pracę) calculator — gross to net, employer cost."""

from decimal import Decimal

from haracz.config import DEFAULT, TaxYear
from haracz.models import AnnualResult, EmployerCost, MonthlyBreakdown, TaxForm
from haracz.calculators.common import (
    calc_employer_zus,
    calc_uop_health,
    calc_uop_pit,
    calc_uop_zus_social,
)


def gross_to_net(
    gross_monthly: Decimal,
    *,
    config: TaxYear = DEFAULT,
    kup: Decimal | None = None,
    under_26: bool = False,
) -> AnnualResult:
    """Calculate 12-month UoP breakdown from monthly gross salary.

    Computes month-by-month to correctly handle:
    - PIT bracket crossing (12% → 32% when cumulative base exceeds threshold)
    - ZUS annual cap (emerytalne + rentowe stop at cap)

    Args:
        gross_monthly: Monthly brutto salary in PLN.
        config: Tax year configuration.
        kup: Override koszty uzyskania przychodu (default: standard 250 PLN).
        under_26: If True, PIT exempt up to 85,528 PLN/year.
    """
    if kup is None:
        kup = config.kup_standard

    months: list[MonthlyBreakdown] = []
    cumulative_tax_base = Decimal("0")
    cumulative_zus_base = Decimal("0")

    total_gross = Decimal("0")
    total_zus = Decimal("0")
    total_health = Decimal("0")
    total_pit = Decimal("0")
    total_net = Decimal("0")

    for month_num in range(1, 13):
        gross = gross_monthly

        # ZUS social — check annual cap for emerytalne + rentowe
        zus_social = calc_uop_zus_social(gross, config)

        # Check if we've hit the annual cap
        if cumulative_zus_base + gross > config.zus_annual_cap:
            # Past the cap — only chorobowe applies
            remaining = max(Decimal("0"), config.zus_annual_cap - cumulative_zus_base)
            from haracz.money import round_to_grosz

            capped_emerytalne = round_to_grosz(remaining * config.zus.emerytalne_employee)
            capped_rentowe = round_to_grosz(remaining * config.zus.rentowe_employee)
            chorobowe = round_to_grosz(gross * config.zus.chorobowe)
            zus_social = capped_emerytalne + capped_rentowe + chorobowe
        cumulative_zus_base += gross

        # Health contribution
        health = calc_uop_health(gross, zus_social)

        # PIT
        if under_26 and total_gross < Decimal("85528"):
            pit = Decimal("0")
        else:
            pit = calc_uop_pit(gross, zus_social, kup, cumulative_tax_base, config)

        tax_base = max(Decimal("0"), gross - zus_social - kup)
        cumulative_tax_base += tax_base

        # Net
        net = gross - zus_social - health - pit

        mb = MonthlyBreakdown(
            month=month_num,
            gross=gross,
            zus_social=zus_social,
            health=health,
            tax_base=tax_base,
            pit=pit,
            net=net,
        )
        months.append(mb)

        total_gross += gross
        total_zus += zus_social
        total_health += health
        total_pit += pit
        total_net += net

    return AnnualResult(
        tax_form=TaxForm.UOP,
        label="UoP",
        months=tuple(months),
        total_gross=total_gross,
        total_zus=total_zus,
        total_health=total_health,
        total_pit=total_pit,
        total_net=total_net,
    )


def employer_cost(
    gross_monthly: Decimal,
    *,
    config: TaxYear = DEFAULT,
) -> EmployerCost:
    """Calculate employer cost (koszt pracodawcy)."""
    employer_zus = calc_employer_zus(gross_monthly, config)
    total_monthly = gross_monthly + employer_zus
    return EmployerCost(
        gross=gross_monthly,
        employer_zus=employer_zus,
        total_monthly=total_monthly,
        total_annual=total_monthly * 12,
    )
