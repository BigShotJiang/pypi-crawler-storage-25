"""Shared calculation logic — ZUS, health, PIT brackets."""

from decimal import Decimal

from haracz.config import TaxYear
from haracz.money import round_to_grosz, round_to_zloty, truncate_to_zloty


def calc_uop_zus_social(gross: Decimal, config: TaxYear) -> Decimal:
    """Calculate employee ZUS social contributions (emerytalne + rentowe + chorobowe)."""
    return round_to_grosz(gross * config.zus.employee_social_rate)


def calc_uop_health(gross: Decimal, zus_social: Decimal) -> Decimal:
    """Calculate UoP health contribution (9% of gross - social)."""
    base = gross - zus_social
    return round_to_grosz(base * Decimal("0.09"))


def calc_uop_pit(
    gross: Decimal,
    zus_social: Decimal,
    kup: Decimal,
    cumulative_tax_base: Decimal,
    config: TaxYear,
) -> Decimal:
    """Calculate monthly PIT for UoP.

    Uses cumulative tax base to determine which bracket applies.
    Returns the PIT amount for this month (can be 0 if ulga covers it).
    """
    monthly_base = truncate_to_zloty(gross - zus_social - kup)
    if monthly_base < 0:
        monthly_base = Decimal("0")

    new_cumulative = cumulative_tax_base + monthly_base

    # Determine how much falls in each bracket
    if cumulative_tax_base >= config.pit_bracket_threshold:
        # Already fully in 32% bracket
        pit = round_to_zloty(monthly_base * config.pit_rate_2)
    elif new_cumulative <= config.pit_bracket_threshold:
        # Fully in 12% bracket
        pit = round_to_zloty(monthly_base * config.pit_rate_1 - config.ulga_monthly)
    else:
        # Bracket crossing this month
        in_12 = config.pit_bracket_threshold - cumulative_tax_base
        in_32 = monthly_base - in_12
        pit = round_to_zloty(
            in_12 * config.pit_rate_1 - config.ulga_monthly + in_32 * config.pit_rate_2
        )

    # PIT cannot be negative
    if pit < 0:
        pit = Decimal("0")

    return pit


def calc_employer_zus(gross: Decimal, config: TaxYear) -> Decimal:
    """Calculate total employer ZUS contributions."""
    return round_to_grosz(gross * config.zus.employer_total_rate)
