"""JDG Ryczałt calculator — flat tax on revenue."""

from decimal import Decimal
from typing import Literal

from haracz.config import DEFAULT, TaxYear
from haracz.models import AnnualResult, MonthlyBreakdown, TaxForm
from haracz.money import round_to_grosz, round_to_zloty


def _health_for_tier(cumulative_revenue: Decimal, config: TaxYear) -> Decimal:
    """Get monthly health contribution based on cumulative revenue tier.

    Tiers are based on annual revenue thresholds. When cumulative revenue
    crosses a threshold mid-year, the health contribution increases from
    that month onward.
    """
    h = config.health
    if cumulative_revenue <= h.ryczalt_tier1_cap:
        return h.ryczalt_tier1_amount
    elif cumulative_revenue <= h.ryczalt_tier2_cap:
        return h.ryczalt_tier2_amount
    else:
        return h.ryczalt_tier3_amount


def calculate(
    monthly_revenue: Decimal,
    *,
    rate: Decimal = Decimal("0.12"),
    config: TaxYear = DEFAULT,
    zus_type: Literal["pelny", "preferencyjny"] = "pelny",
) -> AnnualResult:
    """Calculate 12-month JDG ryczałt breakdown.

    Computes month-by-month to correctly handle:
    - Health contribution tier crossing (60k, 300k thresholds)

    Ryczałt rules:
    - Tax = rate × revenue (no cost deduction)
    - 50% of health contribution is deductible from revenue
    - ZUS social is a fixed monthly amount (not % of revenue)
    - Health is a fixed amount based on cumulative revenue tier

    Args:
        monthly_revenue: Monthly revenue (faktura amount, net of VAT).
        rate: Ryczałt rate (0.12 for IT, 0.085, 0.15).
        config: Tax year configuration.
        zus_type: "pelny" (full) or "preferencyjny" (first 24 months).
    """
    # ZUS social — fixed monthly amount
    if zus_type == "preferencyjny":
        zus_social = config.jdg_zus.preferencyjny_social
    else:
        zus_social = config.jdg_zus.pelny_social
        # Add fundusz pracy for full ZUS
        zus_social = zus_social + config.jdg_zus.pelny_fundusz_pracy

    months: list[MonthlyBreakdown] = []
    cumulative_revenue = Decimal("0")
    total_gross = Decimal("0")
    total_zus = Decimal("0")
    total_health = Decimal("0")
    total_pit = Decimal("0")
    total_net = Decimal("0")

    for month_num in range(1, 13):
        revenue = monthly_revenue
        cumulative_revenue += revenue

        # Health — tier based on cumulative revenue (changes mid-year)
        health = _health_for_tier(cumulative_revenue, config)

        # 50% of health is deductible from revenue for ryczałt
        deductible_health = round_to_grosz(health * Decimal("0.5"))

        # Tax base = revenue - 50% of health contribution
        tax_base = max(Decimal("0"), revenue - deductible_health)
        pit = round_to_zloty(tax_base * rate)

        # Net = revenue - ZUS social - health - PIT
        net = revenue - zus_social - health - pit

        mb = MonthlyBreakdown(
            month=month_num,
            gross=revenue,
            zus_social=zus_social,
            health=health,
            tax_base=tax_base,
            pit=pit,
            net=net,
        )
        months.append(mb)

        total_gross += revenue
        total_zus += zus_social
        total_health += health
        total_pit += pit
        total_net += net

    return AnnualResult(
        tax_form=TaxForm.JDG_RYCZALT,
        label=f"JDG Ryczałt {int(rate * 100)}%",
        months=tuple(months),
        total_gross=total_gross,
        total_zus=total_zus,
        total_health=total_health,
        total_pit=total_pit,
        total_net=total_net,
    )
