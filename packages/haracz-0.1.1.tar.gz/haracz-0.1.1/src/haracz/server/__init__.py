"""FastAPI server for haracz."""
