"""haracz API server — FastAPI + OpenAPI docs."""

try:
    from fastapi import FastAPI
    import uvicorn
except ImportError:
    raise SystemExit(
        "Server dependencies not installed. Run: pip install haracz[server]"
    )

from haracz import __version__

app = FastAPI(
    title="haracz",
    description="Polish employment & tax calculator API — UoP, JDG/B2B, all tax forms.",
    version=__version__,
)


@app.get("/health")
async def health():
    return {"status": "ok", "version": __version__}


def main():
    uvicorn.run("haracz.server.app:app", host="0.0.0.0", port=8000, reload=True)
