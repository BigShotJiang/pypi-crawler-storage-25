"""Comparison engine — run multiple calculators and produce side-by-side results."""

from decimal import Decimal

from haracz.config import DEFAULT, TaxYear
from haracz.models import AnnualResult, Comparison
from haracz.calculators import uop, jdg_ryczalt


def compare(
    amount: Decimal,
    *,
    config: TaxYear = DEFAULT,
    jdg_costs: Decimal = Decimal("0"),
    currency: str = "PLN",
    exchange_rate: Decimal | None = None,
    employer_budget: bool = False,
) -> Comparison:
    """Compare UoP vs JDG scenarios for a given amount.

    Default mode (employee-oriented):
        The amount is your offered number — UoP gross or JDG invoice.
        Same number, different tax treatment. "What do I take home?"

    Employer budget mode (--employer-budget):
        The amount is the company's total spend. UoP gross is derived
        by subtracting employer ZUS. JDG gets the full amount as revenue.

    Args:
        amount: Monthly amount in PLN.
        config: Tax year configuration.
        jdg_costs: Monthly business expenses for JDG.
        currency: Source currency code (for display).
        exchange_rate: Exchange rate used (for display, None if PLN).
        employer_budget: If True, treat amount as employer cost (not gross).
    """
    if employer_budget:
        # Employer mode: derive UoP gross from budget
        employer_rate = config.zus.employer_total_rate
        uop_gross = (amount / (1 + employer_rate)).quantize(Decimal("0.01"))
    else:
        # Employee mode: amount IS the gross
        uop_gross = amount

    # Calculate UoP
    uop_result = uop.gross_to_net(uop_gross, config=config)

    # JDG Ryczałt 12% (IT) — amount is always revenue
    ryczalt_result = jdg_ryczalt.calculate(
        amount,
        rate=Decimal("0.12"),
        config=config,
    )

    scenarios: list[AnnualResult] = [uop_result, ryczalt_result]

    return Comparison(
        budget_monthly=amount,
        currency=currency,
        budget_pln=amount,
        exchange_rate=exchange_rate,
        scenarios=tuple(scenarios),
    )
