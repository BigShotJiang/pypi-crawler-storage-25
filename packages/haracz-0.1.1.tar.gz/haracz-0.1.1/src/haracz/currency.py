"""Currency conversion — NBP API with offline fallbacks."""

from decimal import Decimal

# Hardcoded fallback rates (PLN per 1 unit of foreign currency)
FALLBACK_RATES: dict[str, Decimal] = {
    "NOK": Decimal("0.38"),
    "EUR": Decimal("4.30"),
    "USD": Decimal("4.05"),
    "GBP": Decimal("5.10"),
    "SEK": Decimal("0.39"),
    "CHF": Decimal("4.55"),
    "DKK": Decimal("0.58"),
    "CZK": Decimal("0.17"),
    "PLN": Decimal("1"),
}

NBP_API = "https://api.nbp.pl/api/exchangerates/rates/a/{code}/?format=json"


def get_rate(currency: str) -> Decimal:
    """Get PLN exchange rate for a currency.

    Tries NBP API first (if httpx available), falls back to hardcoded rates.
    Returns: how many PLN per 1 unit of the given currency.
    """
    code = currency.upper()
    if code == "PLN":
        return Decimal("1")

    # Try NBP API
    try:
        import httpx

        response = httpx.get(NBP_API.format(code=code), timeout=5.0)
        response.raise_for_status()
        data = response.json()
        mid_rate = data["rates"][0]["mid"]
        return Decimal(str(mid_rate))
    except Exception:
        pass

    # Fallback
    if code in FALLBACK_RATES:
        return FALLBACK_RATES[code]

    raise ValueError(f"Unknown currency: {currency}. Supported: {', '.join(FALLBACK_RATES.keys())}")


def convert(amount: Decimal, from_currency: str, to_currency: str = "PLN") -> Decimal:
    """Convert an amount to PLN (or between currencies via PLN).

    Args:
        amount: Amount in source currency.
        from_currency: Source currency code (e.g. "NOK", "EUR").
        to_currency: Target currency code (default "PLN").

    Returns:
        Converted amount rounded to 2 decimal places.
    """
    from_code = from_currency.upper()
    to_code = to_currency.upper()

    if from_code == to_code:
        return amount

    # Convert to PLN first
    pln_amount = amount * get_rate(from_code)

    if to_code == "PLN":
        return pln_amount.quantize(Decimal("0.01"))

    # Convert from PLN to target
    target_rate = get_rate(to_code)
    if target_rate == 0:
        raise ValueError(f"Cannot convert to {to_code}: rate is 0")

    return (pln_amount / target_rate).quantize(Decimal("0.01"))
