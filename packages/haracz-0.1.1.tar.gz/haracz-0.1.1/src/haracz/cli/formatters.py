"""Rich formatting helpers — tables, panels, colors."""

from decimal import Decimal

from rich.console import Console
from rich.table import Table

from haracz.models import AnnualResult, Comparison

console = Console()

# Color scheme
HEADER_STYLE = "bold bright_white"
MONEY_STYLE = "bright_green"
LABEL_STYLE = "cyan"
DIM_STYLE = "dim"


def format_pln(amount: Decimal) -> str:
    """Format PLN amount with thousands separator."""
    return f"{amount:,.2f}"


def format_pct(rate: Decimal) -> str:
    """Format as percentage."""
    return f"{rate * 100:.1f}%"


def render_comparison(comparison: Comparison, *, detailed: bool = False) -> None:
    """Render a full comparison table with Rich."""
    header_parts = [f"[bold]Budget:[/bold] [bright_green]{format_pln(comparison.budget_monthly)} PLN/mo[/bright_green]"]
    if comparison.exchange_rate:
        header_parts.append(
            f"[dim]({comparison.currency} × {comparison.exchange_rate} PLN)[/dim]"
        )
    header_parts.append(f"[dim]Annual: {format_pln(comparison.budget_monthly * 12)} PLN[/dim]")

    table = Table(
        show_header=True,
        header_style=HEADER_STYLE,
        border_style="bright_black",
        title="  ".join(header_parts),
        title_style="",
        padding=(0, 1),
    )

    table.add_column("Scenario", style=LABEL_STYLE, min_width=20)
    table.add_column("Gross/Rev", justify="right", style=MONEY_STYLE, min_width=10)
    table.add_column("ZUS", justify="right", style="red", min_width=8)
    table.add_column("Health", justify="right", style="red", min_width=8)
    table.add_column("PIT", justify="right", style="red", min_width=8)
    table.add_column("Net/mo", justify="right", min_width=10)
    table.add_column("Eff.Rate", justify="right", min_width=8)

    best_net = max(s.average_monthly_net for s in comparison.scenarios)

    for scenario in comparison.scenarios:
        net = scenario.average_monthly_net
        is_best = net == best_net

        net_str = format_pln(net)
        rate_str = format_pct(scenario.effective_rate)

        if is_best:
            net_str = f"[bold bright_green]{net_str}[/bold bright_green]"
            rate_str = f"[bold bright_green]{rate_str}[/bold bright_green]"
        else:
            net_str = f"[white]{net_str}[/white]"
            rate_str = f"[yellow]{rate_str}[/yellow]"

        table.add_row(
            scenario.label,
            format_pln(scenario.average_monthly_gross),
            format_pln(scenario.total_zus / 12),
            format_pln(scenario.total_health / 12),
            format_pln(scenario.total_pit / 12),
            net_str,
            rate_str,
        )

    console.print()
    console.print(table)

    best = max(comparison.scenarios, key=lambda s: s.average_monthly_net)
    diff = best.average_monthly_net - min(s.average_monthly_net for s in comparison.scenarios)
    console.print(
        f"\n  [bold bright_green]Best net:[/bold bright_green] {best.label} "
        f"([bright_green]+{format_pln(diff)} PLN/mo[/bright_green] vs worst)"
    )
    console.print()

    if detailed:
        for scenario in comparison.scenarios:
            render_detailed(scenario)


def render_single(result: AnnualResult, *, detailed: bool = False) -> None:
    """Render a single scenario result."""
    table = Table(
        show_header=True,
        header_style=HEADER_STYLE,
        border_style="bright_black",
        title=f"[bold]{result.label}[/bold] — Monthly Average",
    )

    table.add_column("Item", style=LABEL_STYLE)
    table.add_column("Monthly", justify="right", style=MONEY_STYLE)
    table.add_column("Annual", justify="right", style=DIM_STYLE)

    table.add_row("Gross / Revenue", format_pln(result.average_monthly_gross), format_pln(result.total_gross))
    table.add_row("ZUS Social", f"-{format_pln(result.total_zus / 12)}", f"-{format_pln(result.total_zus)}")
    table.add_row("Health", f"-{format_pln(result.total_health / 12)}", f"-{format_pln(result.total_health)}")
    table.add_row("PIT", f"-{format_pln(result.total_pit / 12)}", f"-{format_pln(result.total_pit)}")
    table.add_row("", "", "")
    table.add_row(
        "[bold]Net[/bold]",
        f"[bold bright_green]{format_pln(result.average_monthly_net)}[/bold bright_green]",
        f"[bright_green]{format_pln(result.total_net)}[/bright_green]",
    )
    table.add_row("Effective Rate", f"[yellow]{format_pct(result.effective_rate)}[/yellow]", "")

    console.print()
    console.print(table)
    console.print()

    if detailed:
        render_detailed(result)


def render_detailed(result: AnnualResult) -> None:
    """Render month-by-month breakdown table."""
    table = Table(
        show_header=True,
        header_style=HEADER_STYLE,
        border_style="bright_black",
        title=f"[bold]{result.label}[/bold] — Month by Month",
        padding=(0, 1),
    )

    table.add_column("Month", justify="center", style="bold", min_width=5)
    table.add_column("Gross/Rev", justify="right", style=MONEY_STYLE, min_width=10)
    table.add_column("ZUS", justify="right", style="red", min_width=8)
    table.add_column("Health", justify="right", style="red", min_width=8)
    table.add_column("PIT", justify="right", style="red", min_width=8)
    table.add_column("Net", justify="right", min_width=10)

    prev_net = None
    for m in result.months:
        net_str = format_pln(m.net)

        # Highlight changes from previous month
        if prev_net is not None and m.net != prev_net:
            diff = m.net - prev_net
            if diff < 0:
                net_str = f"[bold red]{net_str}[/bold red] [dim red]({diff:+,.0f})[/dim red]"
            else:
                net_str = f"[bold bright_green]{net_str}[/bold bright_green] [dim green]({diff:+,.0f})[/dim green]"
        else:
            net_str = f"[bright_green]{net_str}[/bright_green]"

        prev_net = m.net

        table.add_row(
            str(m.month),
            format_pln(m.gross),
            format_pln(m.zus_social),
            format_pln(m.health),
            format_pln(m.pit),
            net_str,
        )

    # Totals row
    table.add_section()
    table.add_row(
        "[bold]Total[/bold]",
        f"[bold]{format_pln(result.total_gross)}[/bold]",
        f"[bold red]{format_pln(result.total_zus)}[/bold red]",
        f"[bold red]{format_pln(result.total_health)}[/bold red]",
        f"[bold red]{format_pln(result.total_pit)}[/bold red]",
        f"[bold bright_green]{format_pln(result.total_net)}[/bold bright_green]",
    )
    table.add_row(
        "[bold]Avg/mo[/bold]",
        "",
        "",
        "",
        "",
        f"[bold yellow]{format_pln(result.average_monthly_net)}[/bold yellow]",
    )

    console.print()
    console.print(table)
    console.print()
