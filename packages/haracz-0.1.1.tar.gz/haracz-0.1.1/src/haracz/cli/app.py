"""haracz CLI — Polish employment & tax calculator."""

try:
    import typer
    from rich.console import Console
except ImportError:
    raise SystemExit(
        "CLI dependencies not installed. Run: pip install haracz[cli]"
    )

from decimal import Decimal
from typing import Optional

from haracz import __version__
from haracz.config import DEFAULT
from haracz.cli.formatters import console, render_comparison, render_single

app = typer.Typer(
    name="haracz",
    help="[bold]haracz[/bold] — Polish employment & tax calculator.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def version_callback(value: bool) -> None:
    if value:
        console.print(f"[bold]haracz[/bold] {__version__}")
        raise typer.Exit()


@app.callback()
def callback(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    pass


@app.command()
def uop(
    gross: float = typer.Argument(..., help="Monthly gross salary in PLN."),
    kup: Optional[float] = typer.Option(None, "--kup", help="Override koszty uzyskania przychodu."),
    under_26: bool = typer.Option(False, "--under-26", help="Apply ulga dla mlodych (PIT exempt <26)."),
    detailed: bool = typer.Option(False, "--detailed", "-d", help="Show month-by-month breakdown."),
) -> None:
    """Calculate UoP (employment contract) gross to net."""
    from haracz.calculators import uop as uop_calc

    result = uop_calc.gross_to_net(
        Decimal(str(gross)),
        config=DEFAULT,
        kup=Decimal(str(kup)) if kup else None,
        under_26=under_26,
    )
    render_single(result, detailed=detailed)


@app.command()
def jdg(
    revenue: float = typer.Argument(..., help="Monthly revenue in PLN."),
    rate: float = typer.Option(12, "--rate", "-r", help="Ryczalt rate (12, 8.5, 15)."),
    zus: str = typer.Option("pelny", "--zus", "-z", help="ZUS type: pelny or preferencyjny."),
    detailed: bool = typer.Option(False, "--detailed", "-d", help="Show month-by-month breakdown."),
) -> None:
    """Calculate JDG (B2B) ryczalt net income."""
    from haracz.calculators import jdg_ryczalt

    result = jdg_ryczalt.calculate(
        Decimal(str(revenue)),
        rate=Decimal(str(rate)) / 100,
        config=DEFAULT,
        zus_type=zus,  # type: ignore
    )
    render_single(result, detailed=detailed)


@app.command()
def compare(
    amount: float = typer.Argument(..., help="Monthly amount (gross for UoP, revenue for JDG)."),
    currency: Optional[str] = typer.Option(None, "--currency", "-c", help="Source currency (NOK, EUR, USD)."),
    jdg_costs: float = typer.Option(0, "--jdg-costs", help="Monthly JDG business costs."),
    employer_budget: bool = typer.Option(False, "--employer-budget", "-e", help="Treat amount as employer cost (derives UoP gross)."),
    detailed: bool = typer.Option(False, "--detailed", "-d", help="Show month-by-month breakdown for each scenario."),
) -> None:
    """Compare UoP vs JDG scenarios side by side.

    By default, the amount is YOUR number — UoP gross or JDG invoice.
    Use --employer-budget to treat it as the company's total spend.
    """
    from haracz.compare import compare as do_compare
    from haracz.currency import get_rate

    budget = Decimal(str(amount))
    rate = None
    source_currency = "PLN"

    if currency:
        source_currency = currency.upper()
        rate = get_rate(source_currency)
        budget_pln = (budget * rate).quantize(Decimal("0.01"))
        console.print(
            f"  [dim]{amount:,.2f} {source_currency} × {rate} = "
            f"[bright_green]{budget_pln:,.2f} PLN[/bright_green][/dim]"
        )
    else:
        budget_pln = budget

    result = do_compare(
        budget_pln,
        config=DEFAULT,
        jdg_costs=Decimal(str(jdg_costs)),
        currency=source_currency,
        exchange_rate=rate,
        employer_budget=employer_budget,
    )
    render_comparison(result, detailed=detailed)


def main() -> None:
    app()
