"""CLI interface for haracz."""
