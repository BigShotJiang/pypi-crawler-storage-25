"""Decimal rounding helpers for Polish tax calculations."""

from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP


def round_to_grosz(value: Decimal) -> Decimal:
    """Round to 2 decimal places (grosze) — standard rounding."""
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def truncate_to_zloty(value: Decimal) -> Decimal:
    """Truncate to full złoty (floor) — used for tax base (podstawa opodatkowania)."""
    return value.quantize(Decimal("1"), rounding=ROUND_DOWN)


def round_to_zloty(value: Decimal) -> Decimal:
    """Round to full złoty — used for PIT."""
    return value.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
