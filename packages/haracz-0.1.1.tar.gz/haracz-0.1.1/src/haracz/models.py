"""Result models — typed, frozen dataclasses returned by all calculators."""

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class TaxForm(Enum):
    UOP = "uop"
    JDG_SKALA = "jdg_skala"
    JDG_LINIOWY = "jdg_liniowy"
    JDG_RYCZALT = "jdg_ryczalt"


@dataclass(frozen=True)
class MonthlyBreakdown:
    """Single month calculation result."""

    month: int  # 1-12
    gross: Decimal  # brutto (or revenue for JDG)
    zus_social: Decimal
    health: Decimal
    tax_base: Decimal
    pit: Decimal
    net: Decimal


@dataclass(frozen=True)
class AnnualResult:
    """Full annual calculation with monthly breakdown."""

    tax_form: TaxForm
    label: str  # human-readable, e.g. "UoP" or "JDG Ryczałt 12%"
    months: tuple[MonthlyBreakdown, ...]  # 12 entries
    total_gross: Decimal
    total_zus: Decimal
    total_health: Decimal
    total_pit: Decimal
    total_net: Decimal

    @property
    def average_monthly_net(self) -> Decimal:
        """Average monthly net = annual net / 12."""
        return (self.total_net / 12).quantize(Decimal("0.01"))

    @property
    def average_monthly_gross(self) -> Decimal:
        """Average monthly gross = annual gross / 12."""
        return (self.total_gross / 12).quantize(Decimal("0.01"))

    @property
    def effective_rate(self) -> Decimal:
        """Effective tax+contribution rate = 1 - (net / gross)."""
        if self.total_gross == 0:
            return Decimal("0")
        return (1 - self.total_net / self.total_gross).quantize(Decimal("0.0001"))


@dataclass(frozen=True)
class EmployerCost:
    """Employer cost breakdown (UoP only)."""

    gross: Decimal
    employer_zus: Decimal
    total_monthly: Decimal
    total_annual: Decimal


@dataclass(frozen=True)
class Comparison:
    """Side-by-side comparison of multiple scenarios."""

    budget_monthly: Decimal  # input amount (what the company pays)
    currency: str  # "PLN" or source currency
    budget_pln: Decimal  # after conversion (same as budget if PLN)
    exchange_rate: Decimal | None  # None if PLN
    scenarios: tuple[AnnualResult, ...]
