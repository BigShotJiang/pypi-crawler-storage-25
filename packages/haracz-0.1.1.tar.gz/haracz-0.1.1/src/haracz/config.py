"""Tax year configuration — all parameters that change yearly."""

from dataclasses import dataclass, field
from decimal import Decimal


@dataclass(frozen=True)
class ZUSRates:
    """ZUS contribution rates (percentages as Decimals)."""

    # Employee
    emerytalne_employee: Decimal = Decimal("0.0976")
    rentowe_employee: Decimal = Decimal("0.0150")
    chorobowe: Decimal = Decimal("0.0245")

    # Employer
    emerytalne_employer: Decimal = Decimal("0.0976")
    rentowe_employer: Decimal = Decimal("0.0650")
    wypadkowe: Decimal = Decimal("0.0167")
    fundusz_pracy: Decimal = Decimal("0.0245")
    fgsp: Decimal = Decimal("0.0010")

    @property
    def employee_social_rate(self) -> Decimal:
        """Total employee social contribution rate (emerytalne + rentowe + chorobowe)."""
        return self.emerytalne_employee + self.rentowe_employee + self.chorobowe

    @property
    def employer_total_rate(self) -> Decimal:
        """Total employer contribution rate."""
        return (
            self.emerytalne_employer
            + self.rentowe_employer
            + self.wypadkowe
            + self.fundusz_pracy
            + self.fgsp
        )


@dataclass(frozen=True)
class JDGZUSAmounts:
    """Fixed monthly ZUS amounts for JDG (not rates — fixed PLN amounts)."""

    pelny_social: Decimal = Decimal("1417")
    preferencyjny_social: Decimal = Decimal("439")
    pelny_fundusz_pracy: Decimal = Decimal("102")


@dataclass(frozen=True)
class HealthRates:
    """Health contribution (składka zdrowotna) configuration."""

    # UoP and JDG skala
    uop_rate: Decimal = Decimal("0.09")
    jdg_skala_rate: Decimal = Decimal("0.09")

    # JDG liniowy
    jdg_liniowy_rate: Decimal = Decimal("0.049")
    liniowy_deduction_cap: Decimal = Decimal("11600")  # annual cap

    # Ryczałt tiers (fixed monthly amounts based on annual revenue)
    ryczalt_tier1_cap: Decimal = Decimal("60000")
    ryczalt_tier1_amount: Decimal = Decimal("461.66")
    ryczalt_tier2_cap: Decimal = Decimal("300000")
    ryczalt_tier2_amount: Decimal = Decimal("769.43")
    ryczalt_tier3_amount: Decimal = Decimal("1384.97")

    # Minimum health contribution base
    minimum_health: Decimal = Decimal("420")  # ~9% of min wage


@dataclass(frozen=True)
class TaxYear:
    """Complete tax year configuration. Frozen — create new instance to override."""

    year: int = 2025

    # PIT brackets
    pit_bracket_threshold: Decimal = Decimal("120000")  # annual
    pit_rate_1: Decimal = Decimal("0.12")
    pit_rate_2: Decimal = Decimal("0.32")
    pit_liniowy_rate: Decimal = Decimal("0.19")

    # Tax-free amount
    kwota_wolna: Decimal = Decimal("30000")
    ulga_monthly: Decimal = Decimal("300")  # = kwota_wolna * pit_rate_1 / 12

    # Koszty uzyskania przychodu
    kup_standard: Decimal = Decimal("250")
    kup_commuting: Decimal = Decimal("300")

    # ZUS annual cap (emerytalne + rentowe)
    zus_annual_cap: Decimal = Decimal("268680")

    # Minimum wage
    minimum_wage: Decimal = Decimal("4666")

    # Component configs
    zus: ZUSRates = field(default_factory=ZUSRates)
    jdg_zus: JDGZUSAmounts = field(default_factory=JDGZUSAmounts)
    health: HealthRates = field(default_factory=HealthRates)


# Pre-built configurations
YEAR_2025 = TaxYear()

YEAR_2026 = TaxYear(
    year=2026,
    zus_annual_cap=Decimal("285000"),  # estimated
    minimum_wage=Decimal("4900"),  # estimated
)

# Default config used when none specified
DEFAULT = YEAR_2025
