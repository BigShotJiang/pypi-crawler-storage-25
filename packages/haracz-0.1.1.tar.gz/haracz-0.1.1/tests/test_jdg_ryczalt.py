"""Tests for JDG Ryczalt calculator."""

from decimal import Decimal
from haracz.calculators import jdg_ryczalt
from haracz.config import YEAR_2025


def test_ryczalt_12_basic():
    """Standard ryczałt 12% calculation — 25,000 PLN/month revenue."""
    result = jdg_ryczalt.calculate(Decimal("25000"), rate=Decimal("0.12"), config=YEAR_2025)

    assert result.total_gross == Decimal("300000")  # 25k × 12
    assert result.label == "JDG Ryczałt 12%"
    assert len(result.months) == 12

    # Net should be roughly 19-21k average
    avg_net = result.average_monthly_net
    assert Decimal("19000") < avg_net < Decimal("22000"), f"avg_net={avg_net}"


def test_ryczalt_health_tier_crossing():
    """At 25k/month, health tier should change when cumulative revenue crosses thresholds."""
    result = jdg_ryczalt.calculate(Decimal("25000"), rate=Decimal("0.12"), config=YEAR_2025)

    h = YEAR_2025.health

    # Month 1: cumulative 25k → tier 1 (≤60k)
    assert result.months[0].health == h.ryczalt_tier1_amount

    # Month 3: cumulative 75k → tier 2 (>60k, ≤300k)
    assert result.months[2].health == h.ryczalt_tier2_amount

    # Months should NOT all have the same net (tier crossing)
    nets = set(m.net for m in result.months)
    assert len(nets) > 1, "Expected different monthly nets due to health tier crossing"


def test_ryczalt_8_5():
    """Ryczałt 8.5% — lower rate."""
    result = jdg_ryczalt.calculate(Decimal("25000"), rate=Decimal("0.085"), config=YEAR_2025)
    result_12 = jdg_ryczalt.calculate(Decimal("25000"), rate=Decimal("0.12"), config=YEAR_2025)

    # 8.5% should yield higher net than 12%
    assert result.total_net > result_12.total_net


def test_ryczalt_preferencyjny_zus():
    """Preferential ZUS — lower contributions."""
    full = jdg_ryczalt.calculate(Decimal("25000"), config=YEAR_2025, zus_type="pelny")
    pref = jdg_ryczalt.calculate(Decimal("25000"), config=YEAR_2025, zus_type="preferencyjny")

    # Preferential should have lower ZUS and therefore higher net
    assert pref.total_zus < full.total_zus
    assert pref.total_net > full.total_net


def test_health_tier_low_revenue():
    """Low revenue — stays in tier 1 all year."""
    result = jdg_ryczalt.calculate(Decimal("4000"), config=YEAR_2025)  # 48k/yr < 60k

    # All months should be tier 1 (cumulative never exceeds 60k)
    for m in result.months:
        assert m.health == YEAR_2025.health.ryczalt_tier1_amount


def test_health_tier_mid_revenue():
    """Mid revenue — starts tier 1, crosses to tier 2."""
    result = jdg_ryczalt.calculate(Decimal("10000"), config=YEAR_2025)  # 120k/yr

    h = YEAR_2025.health
    # Month 1-6: cumulative ≤60k → tier 1
    for m in result.months[:6]:
        assert m.health == h.ryczalt_tier1_amount
    # Month 7+: cumulative >60k → tier 2
    for m in result.months[6:]:
        assert m.health == h.ryczalt_tier2_amount


def test_health_tier_high_revenue():
    """High revenue — crosses all tiers."""
    result = jdg_ryczalt.calculate(Decimal("30000"), config=YEAR_2025)  # 360k/yr

    h = YEAR_2025.health
    # Month 1-2: cumulative ≤60k → tier 1
    assert result.months[0].health == h.ryczalt_tier1_amount
    assert result.months[1].health == h.ryczalt_tier1_amount
    # Month 3+: cumulative >60k → tier 2
    assert result.months[2].health == h.ryczalt_tier2_amount
    # Month 11+: cumulative >300k → tier 3
    assert result.months[10].health == h.ryczalt_tier3_amount
    assert result.months[11].health == h.ryczalt_tier3_amount
