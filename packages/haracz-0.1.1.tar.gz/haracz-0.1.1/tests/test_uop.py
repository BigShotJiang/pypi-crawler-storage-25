"""Tests for UoP calculator."""

from decimal import Decimal
from haracz.calculators import uop
from haracz.config import YEAR_2025


def test_gross_to_net_basic():
    """Standard UoP calculation — 10,000 PLN gross."""
    result = uop.gross_to_net(Decimal("10000"), config=YEAR_2025)

    assert result.total_gross == Decimal("120000")  # 10k × 12
    assert len(result.months) == 12

    # All months should have the same gross
    for m in result.months:
        assert m.gross == Decimal("10000")

    # Net should be roughly 7,100-7,200 PLN/month average
    avg_net = result.average_monthly_net
    assert Decimal("7000") < avg_net < Decimal("7500"), f"avg_net={avg_net}"

    # Effective rate should be ~27-30%
    assert Decimal("0.25") < result.effective_rate < Decimal("0.35"), f"rate={result.effective_rate}"


def test_gross_to_net_high_earner():
    """High earner — crosses 32% bracket."""
    result = uop.gross_to_net(Decimal("20000"), config=YEAR_2025)

    # Annual gross = 240k, exceeds 120k threshold
    assert result.total_gross == Decimal("240000")

    # Months should NOT all have the same net (bracket crossing)
    nets = [m.net for m in result.months]
    assert len(set(nets)) > 1, "Expected different monthly nets due to bracket crossing"

    # Later months should have lower net (32% bracket)
    assert nets[0] > nets[-1], "First month net should be higher than last"


def test_gross_to_net_minimum_wage():
    """Minimum wage — very low gross."""
    result = uop.gross_to_net(Decimal("4666"), config=YEAR_2025)

    # Should still produce valid results
    assert result.total_net > 0
    for m in result.months:
        assert m.net > 0
        assert m.zus_social > 0
        assert m.health > 0


def test_employer_cost():
    """Employer cost should be ~120% of gross."""
    cost = uop.employer_cost(Decimal("10000"), config=YEAR_2025)

    assert cost.gross == Decimal("10000")
    assert cost.employer_zus > Decimal("2000")
    assert cost.total_monthly > Decimal("12000")
    assert cost.total_annual == cost.total_monthly * 12


def test_annual_result_properties():
    """Test computed properties on AnnualResult."""
    result = uop.gross_to_net(Decimal("15000"), config=YEAR_2025)

    assert result.average_monthly_net > 0
    assert result.average_monthly_gross == Decimal("15000.00")
    assert 0 < result.effective_rate < 1
