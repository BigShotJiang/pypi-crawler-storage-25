"""Tests for comparison engine."""

from decimal import Decimal
from haracz.compare import compare
from haracz.config import YEAR_2025
from haracz.models import TaxForm


def test_compare_basic():
    """Basic comparison — should return UoP and JDG ryczałt."""
    result = compare(Decimal("25000"), config=YEAR_2025)

    assert result.budget_monthly == Decimal("25000")
    assert result.currency == "PLN"
    assert result.exchange_rate is None
    assert len(result.scenarios) == 2

    forms = {s.tax_form for s in result.scenarios}
    assert TaxForm.UOP in forms
    assert TaxForm.JDG_RYCZALT in forms


def test_compare_employee_mode_default():
    """Default mode: amount IS the UoP gross (not employer budget)."""
    result = compare(Decimal("25000"), config=YEAR_2025)

    uop_result = next(s for s in result.scenarios if s.tax_form == TaxForm.UOP)
    jdg_result = next(s for s in result.scenarios if s.tax_form == TaxForm.JDG_RYCZALT)

    # UoP gross should equal the input amount (employee mode)
    assert uop_result.average_monthly_gross == Decimal("25000.00")
    # JDG revenue also equals the input
    assert jdg_result.average_monthly_gross == Decimal("25000.00")


def test_compare_employer_budget_mode():
    """Employer budget mode: UoP gross is derived from budget."""
    result = compare(Decimal("25000"), config=YEAR_2025, employer_budget=True)

    uop_result = next(s for s in result.scenarios if s.tax_form == TaxForm.UOP)

    # UoP gross should be less than budget (budget / ~1.2048)
    assert uop_result.average_monthly_gross < Decimal("25000")
    assert uop_result.average_monthly_gross > Decimal("20000")


def test_compare_jdg_revenue_equals_amount():
    """JDG revenue should equal the amount in both modes."""
    result_employee = compare(Decimal("25000"), config=YEAR_2025)
    result_employer = compare(Decimal("25000"), config=YEAR_2025, employer_budget=True)

    jdg_emp = next(s for s in result_employee.scenarios if s.tax_form == TaxForm.JDG_RYCZALT)
    jdg_bud = next(s for s in result_employer.scenarios if s.tax_form == TaxForm.JDG_RYCZALT)

    assert jdg_emp.average_monthly_gross == Decimal("25000.00")
    assert jdg_bud.average_monthly_gross == Decimal("25000.00")


def test_compare_with_currency():
    """Comparison with currency conversion."""
    result = compare(
        Decimal("35000"),
        config=YEAR_2025,
        currency="NOK",
        exchange_rate=Decimal("0.38"),
    )

    assert result.currency == "NOK"
    assert result.exchange_rate == Decimal("0.38")
    assert len(result.scenarios) == 2
