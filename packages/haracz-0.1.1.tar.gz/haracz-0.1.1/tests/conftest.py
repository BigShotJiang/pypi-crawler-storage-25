"""Shared test fixtures."""

import pytest
from haracz.config import TaxYear, YEAR_2025


@pytest.fixture
def config() -> TaxYear:
    return YEAR_2025
