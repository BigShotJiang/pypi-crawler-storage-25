# PLAN — haracz

Polish employment & tax calculator. Three interfaces to one pure-Python engine:
- **Library** — `from haracz import ...` (zero deps)
- **CLI** — `haracz` command (typer + rich)
- **API** — `haracz-server` (FastAPI + OpenAPI)

## MVP — What We Actually Need First

Compare offers side by side: **UoP (progressive)** vs **JDG ryczałt 12% (IT)** in different currencies.

```bash
haracz compare 94450 --currency NOK           # Newbuilds offer
haracz compare 25000                           # PLN offer
haracz compare 5000 --currency EUR             # EU offer
```

Output: rich table showing UoP net vs JDG ryczałt 12% net for the same budget, monthly averages.

### MVP Clarification: UoP Progressive Tax

UoP PIT is calculated cumulatively — the employer applies 12% monthly until the 120k threshold, then switches to 32%. **Payslips are NOT equal across the year.** But for comparison purposes, we show:
- **Average monthly net** = annual net / 12 (the number you care about when comparing offers)
- **Month-by-month breakdown** available via `--detailed` flag (shows the bracket crossing)

### MVP Scope (Phase 1 only)

| Feature | In MVP | Later |
|---------|--------|-------|
| UoP gross→net (annual, averaged) | ✅ | |
| JDG ryczałt 12% | ✅ | |
| Compare command with rich table | ✅ | |
| Currency conversion (NBP + fallback) | ✅ | |
| JDG liniowy 19% | | Phase 2 |
| JDG skala 12%/32% | | Phase 2 |
| UoP net→gross (reverse) | | Phase 2 |
| Employer cost breakdown | | Phase 2 |
| FastAPI server endpoints | | Phase 3 |
| TOML config overrides | | Phase 3 |
| Month-by-month detailed view | | Phase 2 |

## Architecture

```
haracz/
├── pyproject.toml
├── CLAUDE.md
├── README.md
├── research/                          # existing research docs
├── src/
│   └── haracz/
│       ├── __init__.py                # public API re-exports
│       ├── py.typed                   # PEP 561 marker
│       ├── config.py                  # TaxYear dataclass with 2025/2026 defaults
│       ├── models.py                  # Result dataclasses (Breakdown, Comparison)
│       ├── money.py                   # Decimal rounding helpers (grosz, zloty)
│       ├── calculators/
│       │   ├── __init__.py
│       │   ├── common.py             # shared ZUS, health, PIT bracket logic
│       │   ├── uop.py                # gross→net, net→gross, employer cost
│       │   ├── jdg_skala.py          # 12%/32% progressive
│       │   ├── jdg_liniowy.py        # 19% flat
│       │   └── jdg_ryczalt.py        # 12%, 8.5%, 15%
│       ├── compare.py                 # run selected calculators, produce Comparison
│       ├── currency.py                # NBP API + hardcoded fallbacks
│       ├── cli/
│       │   ├── __init__.py
│       │   ├── app.py                 # Typer app, subcommand registration
│       │   ├── uop.py                # `haracz uop` command
│       │   ├── jdg.py                # `haracz jdg` command
│       │   ├── compare.py            # `haracz compare` command
│       │   ├── formatters.py         # Rich tables, panels, styling
│       │   └── config_cmd.py         # `haracz config show`
│       └── server/
│           ├── __init__.py
│           └── app.py                 # FastAPI app + uvicorn runner
└── tests/
    ├── conftest.py
    ├── test_uop.py
    ├── test_jdg_ryczalt.py
    └── test_compare.py
```

## Key Decisions

1. **Lib / CLI / Server split** — calculators are pure Python (zero deps). CLI adds typer+rich. Server adds fastapi+uvicorn. All optional extras.
2. **Decimal everywhere** — no floats. Polish tax rounding rules enforced.
3. **TaxYear dataclass** — frozen, hardcoded 2025/2026 defaults. Works without config files.
4. **Annual calculation with monthly average** — UoP computes 12 months (handles bracket crossing + ZUS cap), then divides for the comparison number. JDG ryczałt is simpler (flat rate on revenue).
5. **NBP API for currency** — free, no key, official PLN rates. Hardcoded fallbacks for offline.
6. **Compare is the flagship** — the command people will actually use. Everything else supports it.

## CLI Commands

### MVP
```bash
haracz compare 94450 --currency NOK           # convert NOK→PLN, compare UoP vs JDG
haracz compare 25000                           # PLN, compare all
haracz compare 25000 --jdg-costs 2000          # JDG with business expenses
haracz uop 15000                               # just UoP gross→net
haracz jdg 25000 --form ryczalt --rate 12      # just JDG ryczałt
```

### Later
```bash
haracz uop 10000 --reverse                     # net→gross
haracz uop 15000 --employer-cost               # employer cost breakdown
haracz jdg 25000 --form liniowy                # JDG flat 19%
haracz compare 25000 --detailed                # month-by-month
haracz convert 94450 NOK                       # just currency
haracz config show                             # active parameters
haracz-server                                  # FastAPI on :8000
```

## Library API

```python
from decimal import Decimal
from haracz import uop, jdg_ryczalt, compare, convert

# Single scenarios
result = uop.gross_to_net(Decimal("15000"))
print(f"Avg monthly net: {result.average_monthly_net}")

result = jdg_ryczalt.calculate(Decimal("25000"), rate=Decimal("0.12"))
print(f"Monthly net: {result.monthly_net}")

# Compare
comparison = compare(budget=Decimal("25000"))
for s in comparison.scenarios:
    print(f"{s.label}: {s.average_monthly_net}")

# With currency
pln = convert(Decimal("94450"), "NOK")
comparison = compare(budget=pln)
```

## Dependencies

| Library | Purpose | Extra |
|---------|---------|-------|
| (none) | Core lib — pure Python | required |
| typer>=0.15 | CLI framework | `[cli]` |
| rich>=13 | Terminal formatting | `[cli]` |
| httpx>=0.28 | NBP currency API | `[currency]` |
| fastapi>=0.115 | API server | `[server]` |
| uvicorn>=0.34 | ASGI server | `[server]` |
| pytest>=8 | Testing | dev |
| ruff>=0.9 | Linting | dev |

## Invariants

- No float anywhere — `Decimal` for all money
- Every calculator is a pure function — params in, frozen dataclass out
- CLI and server never contain calculation logic — they call the lib and format
- Config always optional — `TaxYear()` gives working defaults
- UoP annual = 12 monthly iterations (correct bracket crossing + ZUS cap)
- JDG ryczałt = flat rate on revenue (simpler, no bracket logic)
