# haracz

Polish employment & tax calculator — CLI tool and Python library.

Compare net income across UoP (Umowa o Pracę), JDG/B2B with all tax forms, side by side.

## Install

```bash
pip install haracz[all]    # CLI + currency conversion
pip install haracz          # library only
```

## CLI Usage

```bash
haracz uop 15000                          # gross to net
haracz jdg 25000 --form liniowy           # JDG flat 19%
haracz compare 25000                      # all scenarios side-by-side
haracz convert 94450 NOK --compare        # foreign contract comparison
```

## Library Usage

```python
from decimal import Decimal
from haracz import uop, compare_all

result = uop.gross_to_net(Decimal("15000"))
print(f"Net: {result.total_net}, Effective rate: {result.effective_rate:.1%}")
```

## Scenarios

- **UoP** — gross to net, net to gross, employer cost
- **JDG Skala Podatkowa** — 12%/32% progressive
- **JDG Podatek Liniowy** — 19% flat
- **JDG Ryczałt** — 12% (IT), 8.5%, 15%

## License

MIT
