# UniReport — Universal Test Reporter

[![PyPI](https://img.shields.io/pypi/v/unireport?color=3b82f6&label=pip)](https://pypi.org/project/unireport/)
[![npm](https://img.shields.io/npm/v/unireport?color=22c55e&label=npm)](https://www.npmjs.com/package/unireport)
[![Maven Central](https://img.shields.io/maven-central/v/dev.unireport/unireport?color=f59e0b)](https://search.maven.org/artifact/dev.unireport/unireport)
[![License: MIT](https://img.shields.io/badge/license-MIT-a855f7)](LICENSE)
[![Tests](https://img.shields.io/badge/self--tests-24%2F24%20passing-22c55e)](scripts/build.js)

**One install. Any language. Beautiful reports. Zero server.**

UniReport turns any JUnit XML into a stunning, self-contained HTML dashboard — automatically after every test run. No upload. No internet required. 100% offline.

---

## Install

```bash
pip install unireport                          # Python
npm install unireport --save-dev               # Node.js
# Java: dev.unireport:unireport:2.0.0 in pom.xml
```

---

## Quickstart

### Python (pytest)
```ini
# pytest.ini
[pytest]
vReport_Title               = My Project
vReport_output              = reports
vReport_history             = reports/.history
vReport_email_report_enable = false
```
```bash
pytest tests/
# → reports/velvetreport.html  ✓
```

### Node.js
```json
{ "scripts": { "posttest": "unireport generate junit.xml ./reports" } }
```
```bash
npm test
# → reports/unireport.html  ✓
```

### Java
```java
UniReport.generate("target/surefire-reports", "target/unireport");
```
```bash
mvn test
# → target/unireport/unireport.html  ✓
```

---

## Report Features

### Metrics & KPIs
- **12 KPI cards** — Total, Passed, Failed, Errors, Skipped, Retry Count, Pass Rate, Avg Test Time, Total Duration, Stability Score (0–100), Flaky %, Failure Reproducibility
- **Risk badge** — STABLE / UNSTABLE / HIGH RISK
- **Pass rate visual bar** with exact counts

### Test Details
- Expandable suite tree with per-test tabs: **Error**, **Steps**, **Logs**, **Console**, **Attachments**, **stderr**, **Info**
- **Run history dots** — last 5 statuses (🟢🔴🟡) per test
- **FLAKY badge** — auto-detected vs previous run
- Live search + filter by status (All / Passed / Failed / Skipped / Flaky)

### Visual Analysis
- **Result Heatmap** — test × spec file grid, colour-coded by status
- **Mind Map** (sidebar) — Root → Suite → Describe → Test, always visible, collapsible
- **Individual Test History Cards** — one card per test, mini bar chart (last 15 runs) + collapsible run table
- **Failure Analysis** — auto-classified: Assertion / Timeout / Network / Script

### Charts (10 total)
Pass/Fail donut · Duration histogram · **Test Volume & Outcome Trends** (line) · **Execution Duration Trends** (area) · **Duration by Spec File** (bar) · **Duration by Describe Block** (stacked column) · **Worker Distribution** (bar) · Browser Distribution (pie) · Top 10 Slowest · Suite Health

### History & Trends
- Auto-saved to `.history/` — up to 30 runs, ~3 KB each
- Pass rate trend line + run breakdown bar
- Commit `.history/` to git for team-wide trends

### Environment Detection
- Local / CI / Sharded environment display
- Worker count, browser list, framework auto-detection

### Export
- Download as HTML, CSV, JSON, or lightweight **Email HTML** summary

---

## Configuration Reference

### Python

| Key | CLI flag | Default | Description |
|-----|----------|---------|-------------|
| `vReport_Title` | `--vReport-title` | XML filename | Report title |
| `vReport_output` | `--vReport-output` | `reports` | Output folder |
| `vReport_history` | `--vReport-history` | `reports/.history` | History folder |
| `vReport_xml` | `--vReport-xml` | `.velvetreport_junit.xml` | XML path |
| `vReport_open` | `--vReport-open` | `false` | Auto-open browser |
| `vReport_disable` | `--vReport-disable` | `false` | Skip generation |
| `vReport_email_report_enable` | `--vReport-email-report-enable` | `false` | Attach email-ready HTML summary |

### Node.js CLI
```
unireport generate <xml> [output] [--title text] [--history dir] [--open]
unireport clear-history [dir]
unireport info / --version
```

### Java API
```java
UniReport.builder()
    .xmlPath("target/surefire-reports")
    .outputDir("target/unireport")
    .historyDir("target/unireport/.history")
    .title("My Suite")
    .openBrowser(false)
    .generate();
```

---

## Embedding Attachments

```python
# Python
import base64
b64 = base64.b64encode(page.screenshot()).decode()
print(f"[[ATTACHMENT|screenshot.png|{b64}]]")
```

```javascript
// Node.js
const b64 = (await page.screenshot()).toString('base64');
process.stdout.write(`[[ATTACHMENT|screenshot.png|${b64}]]\n`);
```

```java
// Java
byte[] shot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
System.out.println("[[ATTACHMENT|screenshot.png|" + Base64.getEncoder().encodeToString(shot) + "]]");
```

---

## Architecture — One Change, All Platforms

```
core/src/template.html   ← ALL UI (edit this to change the report)
core/src/parser.js       ← JUnit XML parser
core/src/history.js      ← History + email
        ↓
node scripts/build.js    ← Compiles to all 3 platforms
        ↓
packages/pip/            → PyPI
packages/npm/            → npmjs.com
packages/maven/          → Maven Central
```

**Making changes:**
```bash
# Edit core/src/template.html (or parser.js / history.js)
node scripts/build.js          # rebuild all platforms
node scripts/build.js --verify # rebuild + run 24 self-tests
```

---

## Publishing

```bash
node scripts/build.js                   # build all 3
npm run publish:pip                     # → PyPI
npm run publish:npm                     # → npmjs.com
cd packages/maven && mvn deploy         # → Maven Central
```

---

## Supported Frameworks

pytest · Playwright · Robot Framework · Jest · Cypress · Mocha · JUnit 5 · TestNG · Maven Surefire · Gradle · RSpec · PHPUnit · gotestsum · xUnit · NUnit · and any tool that outputs JUnit XML.

---

## License

MIT © UniReport Contributors

---

*Keywords: junit xml report generator, html test report, pytest html report, playwright test report, jest html reporter, cypress report, allure alternative, extent report alternative, offline html test report, self-contained test report, CI test dashboard, test history tracking, flaky test detection, test automation reporting, java test report, python test report, junit 5 report, maven surefire report*
