from .generator import generate_report
__version__ = "2.0.0"
__all__ = ["generate_report", "__version__"]
