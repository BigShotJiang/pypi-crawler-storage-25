from __future__ import annotations
import sys
from pathlib import Path
import pytest

def pytest_addoption(parser):
    g = parser.getgroup("unireport", "UniReport HTML Reporter")
    g.addoption("--unireport-title",   default=None)
    g.addoption("--unireport-output",  default=None)
    g.addoption("--unireport-history", default=None)
    g.addoption("--unireport-xml",     default=None)
    g.addoption("--unireport-open",    action="store_true", default=False)
    g.addoption("--unireport-disable", action="store_true", default=False)
    parser.addini("unireport_title",   default="",                 help="Report title")
    parser.addini("unireport_output",  default="unireport-output", help="Output directory")
    parser.addini("unireport_history", default="",                 help="History directory")
    parser.addini("unireport_xml",     default="",                 help="JUnit XML path")
    parser.addini("unireport_open",    default="false",            help="Open browser (true/false)")
    parser.addini("unireport_disable", default="false",            help="Disable UniReport (true/false)")

def pytest_configure(config):
    if _dis(config): return
    xml = _xml(config)
    if not getattr(config.option, "xmlpath", None): config.option.xmlpath = str(xml)
    Path(_out(config)).mkdir(parents=True, exist_ok=True)

def pytest_sessionfinish(session, exitstatus):
    config = session.config
    if _dis(config): return
    xml = Path(_xml(config)); out = Path(_out(config)); hist = Path(_hist(config, out))
    title = _title(config, xml); auto_open = bool(_opt(config,"unireport_open","--unireport-open",False))
    if not xml.exists(): print(f"
[UniReport] ⚠  XML not found at {xml}", file=sys.stderr); return
    try:
        from unireport.generator import generate_report
        generate_report(xml, out, history_dir=hist, title=title, open_browser=auto_open)
    except Exception as exc:
        print(f"
[UniReport] ⚠  {exc}", file=sys.stderr)

def _opt(c, ini_key, cli_flag, default):
    attr = cli_flag.lstrip("-").replace("-","_")
    v = getattr(c.option, attr, None)
    if v is not None and v != default: return v
    try:
        iv = c.getini(ini_key)
        if iv and iv not in ("false",""): return iv
    except (ValueError, KeyError): pass
    return default

def _dis(c): return _opt(c,"unireport_disable","--unireport-disable",False) in (True,"true","True","1")
def _xml(c): v=_opt(c,"unireport_xml","--unireport-xml",None); return Path(v) if v else Path(".unireport_junit.xml")
def _out(c): return _opt(c,"unireport_output","--unireport-output","unireport-output")
def _hist(c,out): v=_opt(c,"unireport_history","--unireport-history",None); return v if v else str(out/".history")
def _title(c,xml): v=_opt(c,"unireport_title","--unireport-title",None); return v if v else xml.stem
