from __future__ import annotations
import argparse, sys
from pathlib import Path
from unireport import __version__

def main(argv=None):
    p = argparse.ArgumentParser(prog="unireport", description=f"UniReport {__version__}")
    p.add_argument("--version", action="version", version=f"UniReport {__version__}")
    sub = p.add_subparsers(dest="cmd")
    g = sub.add_parser("generate", aliases=["gen"])
    g.add_argument("xml"); g.add_argument("output", nargs="?", default="unireport-output")
    g.add_argument("--history", default=None); g.add_argument("--title", default=None)
    g.add_argument("--open", action="store_true", default=False)
    ch = sub.add_parser("clear-history")
    ch.add_argument("history_dir", nargs="?", default="unireport-output/.history")
    sub.add_parser("info")
    args = p.parse_args(argv)
    if args.cmd in ("generate","gen"):
        from unireport.generator import generate_report
        generate_report(args.xml, args.output, history_dir=args.history, title=args.title, open_browser=args.open)
    elif args.cmd == "clear-history":
        import glob, os
        files = list(Path(args.history_dir).glob("run_*.json"))
        for f in files: f.unlink()
        print(f"[UniReport] ✓ Cleared {len(files)} run(s)")
    elif args.cmd == "info":
        print(f"UniReport : {__version__}\nPython    : {sys.version.split()[0]}\nPath      : {Path(__file__).parent}")
    else: p.print_help()
    return 0

if __name__ == "__main__": sys.exit(main())
