from .generator import generate_report
__version__ = "2.0.3"
__all__ = ["generate_report", "__version__"]
