from __future__ import annotations
import sys
from pathlib import Path
import pytest

def pytest_addoption(parser):
    g = parser.getgroup('velvet_report', 'VelvetReport HTML Reporter')
    g.addoption('--vReport-title',                default=None)
    g.addoption('--vReport-output',               default=None)
    g.addoption('--vReport-history',              default=None)
    g.addoption('--vReport-xml',                  default=None)
    g.addoption('--vReport-open',                 action='store_true', default=False)
    g.addoption('--vReport-disable',              action='store_true', default=False)
    g.addoption('--vReport-email-report-enable',  action='store_true', default=False)
    parser.addini('vReport_Title',               default='',                 help='Report title')
    parser.addini('vReport_output',              default='reports',          help='Output directory')
    parser.addini('vReport_history',             default='reports/.history', help='History directory')
    parser.addini('vReport_xml',                 default='',                 help='JUnit XML path')
    parser.addini('vReport_open',                default='false',            help='Open browser (true/false)')
    parser.addini('vReport_disable',             default='false',            help='Disable VelvetReport (true/false)')
    parser.addini('vReport_email_report_enable', default='false',            help='Generate email-ready HTML summary (true/false)')

def pytest_configure(config):
    if _dis(config): return
    xml = _xml(config)
    if not getattr(config.option, 'xmlpath', None): config.option.xmlpath = str(xml)
    Path(_out(config)).mkdir(parents=True, exist_ok=True)

def pytest_sessionfinish(session, exitstatus):
    config = session.config
    if _dis(config): return
    xml   = Path(_xml(config))
    out   = Path(_out(config))
    hist  = Path(_hist(config, out))
    title     = _title(config, xml)
    auto_open = bool(_opt(config, 'vReport_open', '--vReport-open', False))
    email_en  = _opt(config, 'vReport_email_report_enable', '--vReport-email-report-enable', False) in (True, 'true', 'True', '1')
    if not xml.exists():
        sys.stderr.write('[VelvetReport] WARNING: XML not found at ' + str(xml) + '\n')
        return
    try:
        from velvet_report.generator import generate_report
        generate_report(xml, out, history_dir=hist, title=title, open_browser=auto_open)
        if email_en:
            sys.stdout.write('[VelvetReport] email_report_enable=true — email HTML summary saved alongside report.\n')
    except Exception as exc:
        sys.stderr.write('[VelvetReport] ERROR: ' + str(exc) + '\n')

def _opt(c, ini_key, cli_flag, default):
    attr = cli_flag.lstrip('-').replace('-', '_')
    v = getattr(c.option, attr, None)
    if v is not None and v != default: return v
    try:
        iv = c.getini(ini_key)
        if iv and iv not in ('false', ''): return iv
    except (ValueError, KeyError): pass
    return default

def _dis(c):   return _opt(c, 'vReport_disable', '--vReport-disable', False) in (True, 'true', 'True', '1')
def _xml(c):
    v = _opt(c, 'vReport_xml', '--vReport-xml', None)
    return Path(v) if v else Path('.velvetreport_junit.xml')
def _out(c):   return _opt(c, 'vReport_output',  '--vReport-output',  'reports')
def _hist(c, out):
    v = _opt(c, 'vReport_history', '--vReport-history', None)
    return v if v else str(out / '.history')
def _title(c, xml):
    v = _opt(c, 'vReport_Title', '--vReport-title', None)
    return v if v else xml.stem