"""
PyTorch backend
"""
