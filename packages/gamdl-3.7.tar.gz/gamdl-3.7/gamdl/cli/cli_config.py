import inspect
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import click
from dataclass_click import argument, option

from ..api import AppleMusicApi, WrapperApi
from ..downloader import (
    AppleMusicBaseDownloader,
    AppleMusicDownloader,
    AppleMusicMusicVideoDownloader,
    DownloadMode,
    RemuxFormatMusicVideo,
    RemuxMode,
)
from ..interface import (
    AppleMusicBaseInterface,
    AppleMusicInterface,
    AppleMusicMusicVideoInterface,
    AppleMusicSongInterface,
    AppleMusicUploadedVideoInterface,
    ArtistMediaType,
    CoverFormat,
    MusicVideoCodec,
    MusicVideoResolution,
    SongCodec,
    SyncedLyricsFormat,
    UploadedVideoQuality,
)
from .utils import Csv

api_from_cookies_sig = inspect.signature(AppleMusicApi.create_from_netscape_cookies)
wrapper_api_create_sig = inspect.signature(WrapperApi.create)
api_create_sig = inspect.signature(AppleMusicApi.create)

base_interface_create_sig = inspect.signature(AppleMusicBaseInterface.create)
song_interface_sig = inspect.signature(AppleMusicSongInterface.__init__)
music_video_interface_sig = inspect.signature(AppleMusicMusicVideoInterface.__init__)
uploaded_video_interface_sig = inspect.signature(
    AppleMusicUploadedVideoInterface.__init__
)
interface_create_sig = inspect.signature(AppleMusicInterface)

base_downloader_sig = inspect.signature(AppleMusicBaseDownloader.__init__)
music_video_downloader_sig = inspect.signature(AppleMusicMusicVideoDownloader.__init__)
downloader_sig = inspect.signature(AppleMusicDownloader.__init__)


@dataclass
class CliConfig:
    # CLI specific options
    urls: Annotated[
        list[str],
        argument(
            nargs=-1,
            type=str,
            required=True,
        ),
    ]
    read_urls_as_txt: Annotated[
        bool,
        option(
            "--read-urls-as-txt",
            "-r",
            help="Read URLs from text files",
            is_flag=True,
        ),
    ]
    config_path: Annotated[
        str,
        option(
            "--config-path",
            help="Config file path",
            default=str(Path.home() / ".gamdl" / "config.ini"),
            type=click.Path(
                file_okay=True,
                dir_okay=False,
                writable=True,
                resolve_path=True,
            ),
        ),
    ]
    log_level: Annotated[
        str,
        option(
            "--log-level",
            help="Logging level",
            default="INFO",
            type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"]),
        ),
    ]
    log_file: Annotated[
        str,
        option(
            "--log-file",
            help="Log file path",
            default=None,
            type=click.Path(
                file_okay=True,
                dir_okay=False,
                writable=True,
                resolve_path=True,
            ),
        ),
    ]
    no_exceptions: Annotated[
        bool,
        option(
            "--no-exceptions",
            help="Don't print exceptions",
            is_flag=True,
        ),
    ]
    artist_auto_select: Annotated[
        ArtistMediaType | None,
        option(
            "--artist-auto-select",
            help="Automatically select artist content to download (only for artist URLs)",
            default=None,
            type=ArtistMediaType,
        ),
    ]
    database_path: Annotated[
        str,
        option(
            "--database-path",
            help="Path to the SQLite database file for registering downloaded media",
            default=None,
            type=click.Path(
                file_okay=True,
                dir_okay=False,
                writable=True,
                resolve_path=True,
            ),
        ),
    ]
    no_config_file: Annotated[
        bool,
        option(
            "--no-config-file",
            "-n",
            help="Don't use a config file",
            is_flag=True,
        ),
    ]
    # Wrapper specific options
    wrapper_url: Annotated[
        str,
        option(
            "--wrapper-url",
            help="Wrapper base URL",
            default=wrapper_api_create_sig.parameters["base_url"].default,
        ),
    ]
    # API specific options
    cookies_path: Annotated[
        str,
        option(
            "--cookies-path",
            "-c",
            help="Cookies file path",
            default=api_from_cookies_sig.parameters["cookies_path"].default,
            type=click.Path(
                file_okay=True,
                dir_okay=False,
                readable=True,
                resolve_path=True,
            ),
        ),
    ]
    language: Annotated[
        str,
        option(
            "--language",
            "-l",
            help="Metadata language",
            default=api_create_sig.parameters["language"].default,
        ),
    ]
    # Base Interface specific options
    cover_format: Annotated[
        CoverFormat,
        option(
            "--cover-format",
            help="Cover format",
            default=base_interface_create_sig.parameters["cover_format"].default,
            type=CoverFormat,
        ),
    ]
    cover_size: Annotated[
        int,
        option(
            "--cover-size",
            help="Cover size in pixels",
            default=base_interface_create_sig.parameters["cover_size"].default,
        ),
    ]
    wvd_path: Annotated[
        str | None,
        option(
            "--wvd-path",
            help=".wvd file path",
            default=base_interface_create_sig.parameters["wvd_path"].default,
            type=click.Path(
                file_okay=True,
                dir_okay=False,
                writable=False,
                resolve_path=True,
            ),
        ),
    ]
    use_wrapper: Annotated[
        bool,
        option(
            "--use-wrapper",
            help="Use wrapper for account, playback, and decryption requests",
            is_flag=True,
        ),
    ]
    # Song Interface Options
    synced_lyrics_format: Annotated[
        SyncedLyricsFormat,
        option(
            "--synced-lyrics-format",
            help="Synced lyrics format",
            default=song_interface_sig.parameters["synced_lyrics_format"].default,
            type=SyncedLyricsFormat,
        ),
    ]
    song_codec_piority: Annotated[
        list[SongCodec],
        option(
            "--song-codec-priority",
            help="Comma-separated codec priority",
            default=song_interface_sig.parameters["codec_priority"].default,
            type=Csv(SongCodec),
        ),
    ]
    use_album_date: Annotated[
        bool,
        option(
            "--use-album-date",
            help="Use album release date for songs",
            is_flag=True,
        ),
    ]
    # Music Video Interface Options
    music_video_resolution: Annotated[
        MusicVideoResolution,
        option(
            "--music-video-resolution",
            help="Max music video resolution",
            default=music_video_interface_sig.parameters["resolution"].default,
            type=MusicVideoResolution,
        ),
    ]
    music_video_codec_priority: Annotated[
        list[MusicVideoCodec],
        option(
            "--music-video-codec-priority",
            help="Comma-separated codec priority",
            default=music_video_interface_sig.parameters["codec_priority"].default,
            type=Csv(MusicVideoCodec),
        ),
    ]
    # Uploaded Video Interface Options
    uploaded_video_quality: Annotated[
        UploadedVideoQuality,
        option(
            "--uploaded-video-quality",
            help="Post video quality",
            default=uploaded_video_interface_sig.parameters["quality"].default,
            type=UploadedVideoQuality,
        ),
    ]
    # Base Downloader specific options
    output_path: Annotated[
        str,
        option(
            "--output-path",
            "-o",
            help="Output directory path",
            default=base_downloader_sig.parameters["output_path"].default,
            type=click.Path(
                file_okay=False,
                dir_okay=True,
                writable=True,
                resolve_path=True,
            ),
        ),
    ]
    temp_path: Annotated[
        str,
        option(
            "--temp-path",
            help="Temporary directory path",
            default=base_downloader_sig.parameters["temp_path"].default,
            type=click.Path(
                file_okay=False,
                dir_okay=True,
                writable=True,
                resolve_path=True,
            ),
        ),
    ]
    nm3u8dlre_path: Annotated[
        str,
        option(
            "--nm3u8dlre-path",
            help="N_m3u8DL-RE executable path",
            default=base_downloader_sig.parameters["nm3u8dlre_path"].default,
        ),
    ]
    ffmpeg_path: Annotated[
        str,
        option(
            "--ffmpeg-path",
            help="FFmpeg executable path",
            default=base_downloader_sig.parameters["ffmpeg_path"].default,
        ),
    ]
    download_mode: Annotated[
        DownloadMode,
        option(
            "--download-mode",
            help="Download mode",
            default=base_downloader_sig.parameters["download_mode"].default,
            type=DownloadMode,
        ),
    ]
    album_folder_template: Annotated[
        str,
        option(
            "--album-folder-template",
            help="Album folder template",
            default=base_downloader_sig.parameters["album_folder_template"].default,
        ),
    ]
    compilation_folder_template: Annotated[
        str,
        option(
            "--compilation-folder-template",
            help="Compilation folder template",
            default=base_downloader_sig.parameters[
                "compilation_folder_template"
            ].default,
        ),
    ]
    no_album_folder_template: Annotated[
        str,
        option(
            "--no-album-folder-template",
            help="No album folder template",
            default=base_downloader_sig.parameters["no_album_folder_template"].default,
        ),
    ]
    playlist_folder_template: Annotated[
        str,
        option(
            "--playlist-folder-template",
            help="Playlist folder template",
            default=base_downloader_sig.parameters["playlist_folder_template"].default,
        ),
    ]
    single_disc_file_template: Annotated[
        str,
        option(
            "--single-disc-file-template",
            help="Single disc file template",
            default=base_downloader_sig.parameters["single_disc_file_template"].default,
        ),
    ]
    multi_disc_file_template: Annotated[
        str,
        option(
            "--multi-disc-file-template",
            help="Multi disc file template",
            default=base_downloader_sig.parameters["multi_disc_file_template"].default,
        ),
    ]
    no_album_file_template: Annotated[
        str,
        option(
            "--no-album-file-template",
            help="No album file template",
            default=base_downloader_sig.parameters["no_album_file_template"].default,
        ),
    ]
    playlist_file_template: Annotated[
        str,
        option(
            "--playlist-file-template",
            help="Playlist file template",
            default=base_downloader_sig.parameters["playlist_file_template"].default,
        ),
    ]
    date_tag_template: Annotated[
        str,
        option(
            "--date-tag-template",
            help="Date tag template",
            default=base_downloader_sig.parameters["date_tag_template"].default,
        ),
    ]
    exclude_tags: Annotated[
        list[str],
        option(
            "--exclude-tags",
            help="Comma-separated tags to exclude",
            default=base_downloader_sig.parameters["exclude_tags"].default,
            type=Csv(str),
        ),
    ]
    truncate: Annotated[
        int,
        option(
            "--truncate",
            help="Max filename length",
            default=base_downloader_sig.parameters["truncate"].default,
        ),
    ]
    # DownloaderMusicVideo specific options
    music_video_remux_format: Annotated[
        RemuxFormatMusicVideo,
        option(
            "--music-video-remux-format",
            help="Music video remux format",
            default=music_video_downloader_sig.parameters["remux_format"].default,
            type=RemuxFormatMusicVideo,
        ),
    ]
    # Downloader specific options
    overwrite: Annotated[
        bool,
        option(
            "--overwrite",
            help="Overwrite existing files",
            is_flag=True,
        ),
    ]
    save_cover: Annotated[
        bool,
        option(
            "--save-cover",
            "-s",
            help="Save cover as separate file",
            is_flag=True,
        ),
    ]
    save_playlist: Annotated[
        bool,
        option(
            "--save-playlist",
            help="Save M3U8 playlist file",
            is_flag=True,
        ),
    ]
    no_synced_lyrics: Annotated[
        bool,
        option(
            "--no-synced-lyrics",
            help="Don't download synced lyrics",
            is_flag=True,
        ),
    ]
    synced_lyrics_only: Annotated[
        bool,
        option(
            "--synced-lyrics-only",
            help="Download only synced lyrics",
            is_flag=True,
        ),
    ]
