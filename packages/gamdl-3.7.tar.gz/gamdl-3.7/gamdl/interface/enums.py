from enum import Enum

from .constants import (
    ARTIST_AUTO_SELECT_KEY_MAP,
    ARTIST_AUTO_SELECT_STR_MAP,
    FOURCC_MAP,
    MEDIA_RATING_STR_MAP,
    MEDIA_TYPE_STR_MAP,
    SONG_CODEC_FLAVOR_MAP,
)


class SyncedLyricsFormat(Enum):
    LRC = "lrc"
    SRT = "srt"
    TTML = "ttml"


class MediaType(Enum):
    SONG = 1
    MUSIC_VIDEO = 6

    def __str__(self) -> str:
        return MEDIA_TYPE_STR_MAP[self.value]

    def __int__(self) -> int:
        return self.value


class MediaRating(Enum):
    NONE = 0
    EXPLICIT = 1
    CLEAN = 2

    def __str__(self) -> str:
        return MEDIA_RATING_STR_MAP[self.value]

    def __int__(self) -> int:
        return self.value


class MediaFileFormat(Enum):
    MP4 = "mp4"
    M4V = "m4v"
    M4A = "m4a"


class SongCodec(Enum):
    AAC_WEB = "aac-web"
    AAC_HE_WEB = "aac-he-web"
    # doesnt work with wrapper, gives ckc error
    # AAC_FPS_WEB = "aac-fps-web"
    # AAC_HE_FPS_WEB = "aac-he-fps-web"
    AAC = "aac"
    AAC_HE = "aac-he"
    AAC_BINAURAL = "aac-binaural"
    AAC_DOWNMIX = "aac-downmix"
    AAC_HE_BINAURAL = "aac-he-binaural"
    AAC_HE_DOWNMIX = "aac-he-downmix"
    ATMOS = "atmos"
    AC3 = "ac3"
    ALAC = "alac"
    ASK = "ask"

    @property
    def is_web(self) -> bool:
        return self.value.endswith("-web")

    @property
    def flavor(self) -> str | None:
        return SONG_CODEC_FLAVOR_MAP.get(self.value)

    @property
    def is_cenc(self) -> bool:
        return self.flavor is not None and "ctrp" in self.flavor


class MusicVideoCodec(Enum):
    H264 = "h264"
    H265 = "h265"
    ASK = "ask"

    def fourcc(self) -> str:
        return FOURCC_MAP[self.value]


class MusicVideoResolution(Enum):
    R240P = "240p"
    R360P = "360p"
    R480P = "480p"
    R540P = "540p"
    R720P = "720p"
    R1080P = "1080p"
    R1440P = "1440p"
    R2160P = "2160p"

    def __int__(self) -> int:
        return int(self.value[:-1])


class UploadedVideoQuality(Enum):
    BEST = "best"
    ASK = "ask"


class CoverFormat(Enum):
    JPG = "jpg"
    PNG = "png"
    RAW = "raw"


class ArtistMediaType(Enum):
    MAIN_ALBUMS = "main-albums"
    COMPILATION_ALBUMS = "compilation-albums"
    LIVE_ALBUMS = "live-albums"
    SINGLES_EPS = "singles-eps"
    ALL_ALBUMS = "all-albums"
    TOP_SONGS = "top-songs"
    MUSIC_VIDEOS = "music-videos"

    @property
    def path_key(self) -> tuple[str, str]:
        return ARTIST_AUTO_SELECT_KEY_MAP[self.value]

    def __str__(self) -> str:
        return ARTIST_AUTO_SELECT_STR_MAP[self.value]
