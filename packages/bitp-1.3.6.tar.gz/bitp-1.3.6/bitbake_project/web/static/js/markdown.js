/* Minimal Markdown to HTML renderer for AI output.
 * Handles: headers, tables, bold/italic, bullet/numbered lists,
 * fenced code blocks, inline code, horizontal rules, links.
 * Not a full CommonMark parser — optimized for typical LLM output.
 */
function renderMarkdown(text) {
  if (!text) return '';
  var lines = text.split('\n');
  var html = [];
  var inCode = false;
  var inTable = false;
  var inList = false;
  var listType = '';

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];

    // Fenced code blocks
    if (line.trimStart().startsWith('```')) {
      if (inCode) {
        html.push('</code></pre>');
        inCode = false;
      } else {
        if (inList) { html.push(listType === 'ul' ? '</ul>' : '</ol>'); inList = false; }
        if (inTable) { html.push('</tbody></table>'); inTable = false; }
        var lang = line.trim().slice(3).trim();
        html.push('<pre style="background:var(--bg-tertiary);padding:8px 12px;border-radius:4px;overflow-x:auto;margin:4px 0"><code>');
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      html.push(esc(line));
      html.push('\n');
      continue;
    }

    // Table rows
    if (line.trim().match(/^\|(.+)\|$/)) {
      // Check if separator row (|---|---|)
      if (line.trim().match(/^\|[\s:?-]+\|$/)) continue; // skip separator
      var cells = line.trim().slice(1, -1).split('|').map(function(c) { return c.trim(); });
      if (!inTable) {
        if (inList) { html.push(listType === 'ul' ? '</ul>' : '</ol>'); inList = false; }
        html.push('<table style="border-collapse:collapse;width:100%;margin:8px 0;font-size:var(--font-size-sm)">');
        html.push('<thead><tr>');
        cells.forEach(function(c) {
          html.push('<th style="border:1px solid var(--border);padding:4px 8px;text-align:left;background:var(--bg-tertiary)">' + inlineMarkdown(c) + '</th>');
        });
        html.push('</tr></thead><tbody>');
        inTable = true;
        continue;
      }
      html.push('<tr>');
      cells.forEach(function(c) {
        html.push('<td style="border:1px solid var(--border);padding:4px 8px">' + inlineMarkdown(c) + '</td>');
      });
      html.push('</tr>');
      continue;
    }
    if (inTable) {
      html.push('</tbody></table>');
      inTable = false;
    }

    // Empty line
    if (line.trim() === '') {
      if (inList) { html.push(listType === 'ul' ? '</ul>' : '</ol>'); inList = false; }
      html.push('<br>');
      continue;
    }

    // Horizontal rule
    if (line.trim().match(/^[-*_]{3,}$/)) {
      if (inList) { html.push(listType === 'ul' ? '</ul>' : '</ol>'); inList = false; }
      html.push('<hr style="border:none;border-top:1px solid var(--border);margin:8px 0">');
      continue;
    }

    // Headers
    var hMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (hMatch) {
      if (inList) { html.push(listType === 'ul' ? '</ul>' : '</ol>'); inList = false; }
      var level = hMatch[1].length;
      var sizes = ['', '1.4em', '1.2em', '1.1em', '1em', '0.95em', '0.9em'];
      html.push('<div style="font-weight:600;font-size:' + sizes[level] + ';margin:12px 0 4px">' + inlineMarkdown(hMatch[2]) + '</div>');
      continue;
    }

    // Bullet lists (-, *, +)
    var bulletMatch = line.match(/^(\s*)[-*+]\s+(.*)$/);
    if (bulletMatch) {
      if (!inList || listType !== 'ul') {
        if (inList) html.push(listType === 'ul' ? '</ul>' : '</ol>');
        html.push('<ul style="margin:4px 0;padding-left:20px">');
        inList = true;
        listType = 'ul';
      }
      html.push('<li>' + inlineMarkdown(bulletMatch[2]) + '</li>');
      continue;
    }

    // Numbered lists
    var numMatch = line.match(/^(\s*)\d+[.)]\s+(.*)$/);
    if (numMatch) {
      if (!inList || listType !== 'ol') {
        if (inList) html.push(listType === 'ul' ? '</ul>' : '</ol>');
        html.push('<ol style="margin:4px 0;padding-left:20px">');
        inList = true;
        listType = 'ol';
      }
      html.push('<li>' + inlineMarkdown(numMatch[2]) + '</li>');
      continue;
    }

    // Close list if we hit a non-list line
    if (inList) {
      html.push(listType === 'ul' ? '</ul>' : '</ol>');
      inList = false;
    }

    // Regular paragraph
    html.push('<div>' + inlineMarkdown(line) + '</div>');
  }

  // Close any open blocks
  if (inCode) html.push('</code></pre>');
  if (inTable) html.push('</tbody></table>');
  if (inList) html.push(listType === 'ul' ? '</ul>' : '</ol>');

  return html.join('');
}

/* Inline markdown: bold, italic, code, links, strikethrough */
function inlineMarkdown(text) {
  // Escape HTML first
  text = esc(text);
  // Inline code (must be before bold/italic to prevent interference)
  text = text.replace(/`([^`]+)`/g, '<code style="background:var(--bg-tertiary);padding:1px 4px;border-radius:3px;font-size:0.9em">$1</code>');
  // Bold + italic
  text = text.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  // Bold
  text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // Italic
  text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
  // Strikethrough
  text = text.replace(/~~(.+?)~~/g, '<del>$1</del>');
  // Links [text](url)
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" style="color:var(--accent)">$1</a>');
  return text;
}
