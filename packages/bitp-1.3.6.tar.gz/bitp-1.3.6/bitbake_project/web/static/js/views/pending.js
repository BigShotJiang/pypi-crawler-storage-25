/* Pending Changes view — unified browser for GitHub PRs, lore patches, etc.
 * Adapts columns and actions based on the auto-detected provider type.
 * Shares detail panel, AI summary tab, and markdown rendering patterns.
 */
const PendingView = {
  _nav: KeyboardNav(),
  _changes: [],
  _groups: [],
  _providerType: null,
  _description: '',
  _repo: '',
  _aiReviews: {},
  _aiActive: false,
  _aiTimeout: null,
  _aiCurrentId: null,
  _aiRawText: '',
  _maxPages: 1,
  _hasMore: false,

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'View details', action: 'Enter'},
    {key: '/', desc: 'Search'},
    {key: 'S', desc: 'Summarize (AI)', action: 'S'},
  ],

  _project() { return App.state.selectedProject || ''; },

  async render(container) {
    // Detect providers for all repos
    this._repoProviders = [];
    try {
      var detect = await API.pendingDetect('', this._project());
      this._repoProviders = detect.repos || [];
      this._providerType = detect.provider_type;
      this._description = detect.description || '';
      this._repo = detect.repo || '';

      // If the default provider is lore and no other provider types exist,
      // delegate to B4View for the full lore experience
      var nonLoreProviders = this._repoProviders.filter(r => r.provider_type && r.provider_type !== 'lore');
      if (detect.provider_type === 'lore' && nonLoreProviders.length === 0 && this._repoProviders.length > 0) {
        return B4View.render(container);
      }
    } catch (e) {
      // Fall through to pending view
    }

    // Build repo selector if multiple repos have providers
    var reposWithProviders = this._repoProviders.filter(r => r.provider_type);
    var repoSelectorHtml = '';
    if (reposWithProviders.length > 1) {
      repoSelectorHtml = '<select id="pending-repo-select" class="btn btn-sm" style="margin-left:12px;max-width:250px">';
      for (var i = 0; i < reposWithProviders.length; i++) {
        var r = reposWithProviders[i];
        var sel = r.path === this._repo ? ' selected' : '';
        repoSelectorHtml += '<option value="' + esc(r.path) + '"' + sel + '>' + esc(r.name) + ' (' + esc(r.provider_type) + ')</option>';
      }
      repoSelectorHtml += '</select>';
    }

    container.innerHTML = `
      <div class="view-header" style="flex-shrink:0;justify-content:flex-start;gap:12px">
        <h2>Pending Changes</h2>
        ${repoSelectorHtml}
        <span id="pending-provider-label" style="color:var(--text-muted);font-size:var(--font-size-sm)"></span>
      </div>
      <div class="recipes-split">
        <div class="recipes-left" id="pending-left">
          <div id="pending-list" style="flex:1;overflow-y:auto;min-height:0"></div>
        </div>
        <div class="recipes-resizer" id="pending-resizer" style="display:none"></div>
        <div id="pending-detail" class="recipes-preview-panel" style="display:none">
          <div class="recipes-preview-header" style="padding:2px 8px;min-height:0">
            <span style="display:flex;gap:0;margin-right:8px">
              <button class="btn btn-sm pending-detail-tab active" data-tab="content" style="border-radius:4px 4px 0 0;padding:2px 8px">Content</button>
              <button class="btn btn-sm pending-detail-tab" data-tab="ai" style="border-radius:4px 4px 0 0;padding:2px 8px;display:none">AI Summary</button>
            </span>
            <span id="pending-detail-title" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;font-size:var(--font-size-sm)"></span>
            <button class="btn btn-sm" id="pending-detail-close" title="Close preview" style="padding:2px 6px">\u00d7</button>
          </div>
          <div id="pending-tab-content" style="overflow:auto;flex:1">
            <div id="pending-detail-body" style="padding:12px 16px">
              <div class="recipes-preview-placeholder">Select an item to preview</div>
            </div>
          </div>
          <div id="pending-tab-ai" style="overflow:auto;flex:1;display:none">
            <div id="pending-ai-body" style="padding:12px 16px;font-size:var(--font-size-sm)"></div>
          </div>
        </div>
      </div>
      <div class="recipes-footer">
        <div class="recipes-footer-left">
          <span id="pending-status" style="color:var(--text-muted);font-size:var(--font-size-sm)"></span>
        </div>
        <div class="recipes-footer-right">
          <span style="display:flex;gap:1px;margin-right:8px">
            <button class="btn btn-sm" id="pending-font-down" title="Decrease font size">A-</button>
            <button class="btn btn-sm" id="pending-font-up" title="Increase font size">A+</button>
          </span>
          <button class="btn btn-sm" id="pending-refresh" title="Refresh">\u21bb Refresh</button>
        </div>
      </div>
    `;

    // Repo selector
    var repoSelect = document.getElementById('pending-repo-select');
    if (repoSelect) {
      repoSelect.addEventListener('change', () => {
        this._repo = repoSelect.value;
        var match = this._repoProviders.find(r => r.path === this._repo);
        if (match) {
          this._providerType = match.provider_type;
          this._description = match.description;
        }
        this._maxPages = 1;
        this._hideDetail();
        this._fetchAndRender();
      });
    }

    // Tab switching
    document.querySelectorAll('.pending-detail-tab').forEach(tab => {
      tab.addEventListener('click', () => this._switchTab(tab.dataset.tab));
    });

    // Close detail
    document.getElementById('pending-detail-close').addEventListener('click', () => this._hideDetail());

    // Refresh
    document.getElementById('pending-refresh').addEventListener('click', () => this._fetchAndRender());

    // Font size
    this._fontSize = parseInt(loadPreference('pending-font-size', '12'), 10);
    this._applyFontSize();
    document.getElementById('pending-font-down').addEventListener('click', () => {
      this._fontSize = Math.max(9, this._fontSize - 1);
      savePreference('pending-font-size', this._fontSize);
      this._applyFontSize();
    });
    document.getElementById('pending-font-up').addEventListener('click', () => {
      this._fontSize = Math.min(16, this._fontSize + 1);
      savePreference('pending-font-size', this._fontSize);
      this._applyFontSize();
    });

    // Resizable divider
    var resizer = document.getElementById('pending-resizer');
    var leftPanel = document.getElementById('pending-left');
    if (resizer && leftPanel) {
      // Saved width is only applied when detail panel is open
      this._savedLeftWidth = localStorage.getItem('bit-pending-left-width');
      var startX, startW;
      var onMouseMove = (e) => {
        var newW = startW + (e.clientX - startX);
        var clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      var onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        localStorage.setItem('bit-pending-left-width', Math.round(leftPanel.getBoundingClientRect().width));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    await this._fetchAndRender();
  },

  async _fetchAndRender() {
    var el = document.getElementById('pending-list');
    if (el) { el.className = 'loading'; el.textContent = 'Loading ' + (this._description || this._providerType || 'pending changes') + '...'; }

    var label = document.getElementById('pending-provider-label');
    if (label) label.textContent = this._description;

    if (!this._providerType) {
      if (el) {
        el.className = '';
        el.innerHTML = '<div class="empty-state"><h3>No provider detected</h3><p>This repo has no GitHub remote or lore mailing list mapping.</p></div>';
      }
      return;
    }

    try {
      var data = await API.pendingBrowse(this._repo, this._project(), this._maxPages);
      this._changes = data.changes || [];
      this._groups = data.groups || [];
      this._hasMore = !!data.has_more;
      this._renderList();

      var status = document.getElementById('pending-status');
      if (status) {
        status.textContent = this._changes.length + ' change(s) from ' + (data.description || this._providerType);
      }

    } catch (e) {
      if (el) {
        el.className = '';
        el.innerHTML = '<div class="empty-state"><h3>Error</h3><p>' + esc(e.message) + '</p></div>';
      }
    }
  },

  _applyFontSize() {
    var el = document.getElementById('pending-list');
    if (el) el.style.fontSize = this._fontSize + 'px';
    var detail = document.getElementById('pending-detail-body');
    if (detail) detail.style.fontSize = this._fontSize + 'px';
    var ai = document.getElementById('pending-ai-body');
    if (ai) ai.style.fontSize = this._fontSize + 'px';
  },

  _renderList() {
    var el = document.getElementById('pending-list');
    if (!el) return;
    el.className = '';

    var groups = this._groups;
    if (!groups.length) {
      el.innerHTML = '<div class="empty-state"><h3>No pending changes</h3></div>';
      this._nav.setRows([]);
      return;
    }

    var isGitHub = this._providerType === 'github';
    var html = '<table class="data-table" id="pending-table"><thead><tr>';
    if (isGitHub) {
      html += '<th>PR</th><th>Title</th><th>Author</th><th>Date</th><th>CI</th><th>Review</th><th>Labels</th>';
    } else {
      html += '<th>Subject</th><th>Author</th><th>Date</th><th>Status</th>';
    }
    html += '</tr></thead><tbody>';

    for (var gi = 0; gi < groups.length; gi++) {
      var g = groups[gi];
      var r = g.root;
      var idx = this._changes.findIndex(c => c.id === r.id);
      if (idx < 0) idx = gi;

      if (isGitHub) {
        var ciDot = r.ci_status === 'success' ? '<span style="color:var(--green)">\u25cf</span>'
                  : r.ci_status === 'failure' ? '<span style="color:var(--red)">\u25cf</span>'
                  : r.ci_status === 'pending' ? '<span style="color:var(--yellow)">\u25cf</span>'
                  : '<span style="color:var(--text-muted)">\u25cb</span>';
        var reviewIcon = r.review_status === 'approved' ? '<span style="color:var(--green)">\u2713</span>'
                       : r.review_status === 'changes_requested' ? '<span style="color:var(--red)">\u2717</span>'
                       : r.review_status === 'pending' ? '<span style="color:var(--yellow)">\u25cc</span>'
                       : '';
        var labels = (r.labels || []).map(l => '<span style="display:inline-block;padding:1px 6px;border-radius:9px;font-size:11px;background:var(--bg-tertiary);margin-right:2px">' + esc(l) + '</span>').join('');
        var draft = r.metadata && r.metadata.draft ? ' <span style="color:var(--text-muted)">(draft)</span>' : '';

        html += '<tr role="row" tabindex="-1" data-idx="' + idx + '" data-id="' + esc(r.id) + '" style="cursor:pointer">'
          + '<td style="color:var(--accent);white-space:nowrap">#' + esc(String(r.pr_number)) + '</td>'
          + '<td style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:0">' + esc(r.title) + draft + '</td>'
          + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(r.author) + '</td>'
          + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(r.date) + '</td>'
          + '<td style="text-align:center">' + ciDot + '</td>'
          + '<td style="text-align:center">' + reviewIcon + '</td>'
          + '<td>' + labels + '</td>'
          + '</tr>';
      } else {
        // Lore-style
        var badge = '';
        if (g.total_parts) {
          var complete = g.received_parts && g.received_parts >= g.total_parts;
          var color = complete ? 'var(--success, #22c55e)' : 'var(--warning, #eab308)';
          badge = '<span style="display:inline-block;padding:1px 6px;border-radius:9px;font-size:11px;font-weight:600;background:' + color + ';color:#000;margin-right:6px">'
            + (g.received_parts || 0) + '/' + g.total_parts + '</span>';
        }
        html += '<tr role="row" tabindex="-1" data-idx="' + idx + '" data-id="' + esc(r.id) + '" style="cursor:pointer">'
          + '<td style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:0">' + badge + esc(r.title) + '</td>'
          + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(r.author) + '</td>'
          + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(r.date) + '</td>'
          + '<td></td>'
          + '</tr>';

        // Children
        for (var ci = 0; ci < (g.children || []).length; ci++) {
          var child = g.children[ci];
          var childIdx = this._changes.findIndex(c => c.id === child.id);
          var isReply = /^(Re|Fwd):/i.test(child.title || '');
          var subjStyle = isReply ? 'color:var(--text-muted)' : 'color:var(--accent, #60a5fa)';
          var connector = ci === g.children.length - 1 ? '\u2514\u2500 ' : '\u251c\u2500 ';
          html += '<tr role="row" tabindex="-1" data-idx="' + (childIdx >= 0 ? childIdx : idx) + '" data-id="' + esc(child.id) + '" style="cursor:pointer">'
            + '<td style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:0"><span style="color:var(--text-muted);margin-left:16px;font-family:var(--font-mono)">' + connector + '</span><span style="' + subjStyle + '">' + esc(child.title) + '</span></td>'
            + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(child.author) + '</td>'
            + '<td style="color:var(--text-muted);white-space:nowrap">' + esc(child.date) + '</td>'
            + '<td></td>'
            + '</tr>';
        }
      }
    }

    html += '</tbody></table>';

    if (this._hasMore) {
      html += '<div style="text-align:center;padding:8px"><button class="btn" id="pending-load-more">Load more</button></div>';
    }

    el.innerHTML = html;

    // Load more handler
    var loadMoreBtn = document.getElementById('pending-load-more');
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', async () => {
        loadMoreBtn.textContent = 'Loading...';
        loadMoreBtn.disabled = true;
        this._maxPages++;
        await this._fetchAndRender();
      });
    }

    // Click handler
    el.querySelectorAll('tr[role="row"]').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showDetail(row);
      });
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showContextMenu(e, row);
      });
    });

    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));

    var table = document.getElementById('pending-table');
    if (table) initColumnResizer(table, 'pending');
  },

  handleKeyboard(e) {
    // Delegate to B4View when lore provider is active
    if (this._providerType === 'lore' && B4View.handleKeyboard) {
      return B4View.handleKeyboard(e);
    }
    if (e.key === 'Escape') {
      var panel = document.getElementById('pending-detail');
      if (panel && panel.style.display !== 'none') {
        e.preventDefault();
        this._hideDetail();
        return;
      }
    }
    if (this._nav.handleBasicKeys(e)) return;
    var row = this._nav.activeRow();
    if ((e.key === 'Enter' || e.key === 'ArrowRight') && row) {
      e.preventDefault();
      this._showDetail(row);
    } else if (e.key === '/' || e.key === 's') {
      // Future: search
    } else if (e.key === 'S' && row) {
      e.preventDefault();
      this._summarizeChange(row);
    }
  },

  async _showDetail(row) {
    var changeId = row.dataset.id;
    if (!changeId) return;

    var change = this._changes.find(c => c.id === changeId);
    if (!change) return;

    var panel = document.getElementById('pending-detail');
    var resizer = document.getElementById('pending-resizer');
    var title = document.getElementById('pending-detail-title');
    var body = document.getElementById('pending-detail-body');
    if (!panel || !body) return;

    panel.style.display = '';
    if (resizer) resizer.style.display = '';
    // Apply saved width when opening detail panel
    var leftPanel = document.getElementById('pending-left');
    if (leftPanel && this._savedLeftWidth) {
      leftPanel.style.flex = '0 0 ' + this._savedLeftWidth + 'px';
    }
    if (title) {
      if (change.url) {
        title.innerHTML = esc(change.title) + ' <a href="' + esc(change.url) + '" target="_blank" style="color:var(--accent);font-size:var(--font-size-sm);margin-left:8px" title="Open in browser">\u2197</a>';
      } else {
        title.textContent = change.title;
      }
    }

    // Show AI tab if review exists
    var aiTab = document.querySelector('.pending-detail-tab[data-tab="ai"]');
    var aiBody = document.getElementById('pending-ai-body');
    var review = this._aiReviews[changeId];
    if (review && aiTab) {
      aiTab.style.display = '';
      if (aiBody && typeof renderMarkdown === 'function') {
        aiBody.innerHTML = renderMarkdown(review);
      } else if (aiBody) {
        aiBody.textContent = review;
      }
    } else if (aiTab) {
      aiTab.style.display = 'none';
    }
    this._switchTab('content');

    body.innerHTML = '<div style="color:var(--text-muted)">Loading...</div>';
    var content = '';
    try {
      var data = await API.pendingContent(changeId, this._repo, this._project());
      content = data.content || change.content || '(no content)';
    } catch (e) {
      content = change.content || '(failed to load: ' + e.message + ')';
    }

    try {
      if (this._providerType === 'github') {
        if (typeof renderMarkdown === 'function') {
          body.innerHTML = renderMarkdown(content);
        } else {
          body.innerHTML = '<pre style="white-space:pre-wrap;word-break:break-word">' + esc(content) + '</pre>';
        }
      } else {
        body.innerHTML = '<pre style="white-space:pre-wrap;word-break:break-word;margin:0">' + esc(content) + '</pre>';
      }
    } catch (e) {
      body.innerHTML = '<div style="color:var(--error)">Failed to load: ' + esc(e.message) + '</div>';
    }
  },

  _hideDetail() {
    var panel = document.getElementById('pending-detail');
    var resizer = document.getElementById('pending-resizer');
    var leftPanel = document.getElementById('pending-left');
    if (panel) panel.style.display = 'none';
    if (resizer) resizer.style.display = 'none';
    // Reset left panel to fill available space
    if (leftPanel) leftPanel.style.flex = '1';
  },

  _switchTab(tabName) {
    document.querySelectorAll('.pending-detail-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.tab === tabName);
    });
    var contentTab = document.getElementById('pending-tab-content');
    var aiTab = document.getElementById('pending-tab-ai');
    if (contentTab) contentTab.style.display = tabName === 'content' ? '' : 'none';
    if (aiTab) aiTab.style.display = tabName === 'ai' ? '' : 'none';
  },

  async _summarizeChange(row) {
    var changeId = row.dataset.id;
    if (!changeId) return;

    var change = this._changes.find(c => c.id === changeId);
    if (!change) return;

    // Check AI status
    var status;
    try {
      status = await API.getAIStatus();
    } catch (e) {
      App.showToast('AI not available: ' + e.message, 'error');
      return;
    }
    if (!status.configured) {
      App.showToast('AI not configured \u2014 set up in Settings', 'error');
      return;
    }

    var presets = status.presets || ['changelog', 'technical-review', 'release-notes', 'security-audit'];
    var defaultPreset = status.default_preset || 'technical-review';
    var preset = await this._pickPreset(presets, defaultPreset);
    if (preset === null) return;

    var customPrompt = '';
    if (preset === 'custom') {
      customPrompt = prompt('Enter your prompt:');
      if (!customPrompt) return;
    }

    // Show AI tab
    var panel = document.getElementById('pending-detail');
    var resizer = document.getElementById('pending-resizer');
    if (panel) panel.style.display = '';
    if (resizer) resizer.style.display = '';

    var aiTab = document.querySelector('.pending-detail-tab[data-tab="ai"]');
    if (aiTab) aiTab.style.display = '';
    this._switchTab('ai');

    var aiBody = document.getElementById('pending-ai-body');
    if (aiBody) aiBody.innerHTML = '<span style="color:var(--text-muted)">Waiting for AI response...</span>'
      + ' <button id="pending-ai-stop" class="btn btn-sm" style="margin-left:8px">Stop</button>';

    var stopBtn = document.getElementById('pending-ai-stop');
    if (stopBtn) stopBtn.addEventListener('click', () => {
      this._stopAI();
      this._appendAIText('\n[Stopped]');
    });

    this._aiCurrentId = changeId;
    this._aiActive = true;
    this._aiRawText = '';
    this._aiReviews[changeId] = '';

    var self = this;
    window._pendingAI = {
      active: true,
      append: function(text) { self._appendAIText(text); },
    };

    this._aiTimeout = setTimeout(function() {
      if (self._aiActive) {
        self._stopAI();
        self._appendAIText('\n[Timed out]');
      }
    }, 180000);

    try {
      await API.pendingSummarize(changeId, change.title, this._repo, preset, customPrompt, this._project());
    } catch (e) {
      this._appendAIText('\n[Error: ' + e.message + ']');
    }
  },

  _appendAIText(text) {
    var aiBody = document.getElementById('pending-ai-body');
    if (!aiBody) return;
    if (aiBody.querySelector('#pending-ai-stop')) {
      aiBody.textContent = '';
      this._aiRawText = '';
    }
    this._aiRawText = (this._aiRawText || '') + text;
    if (typeof renderMarkdown === 'function') {
      aiBody.innerHTML = renderMarkdown(this._aiRawText);
    } else {
      aiBody.textContent = this._aiRawText;
    }
    aiBody.scrollTop = aiBody.scrollHeight;
    if (this._aiCurrentId) {
      this._aiReviews[this._aiCurrentId] = this._aiRawText;
    }
  },

  _stopAI() {
    this._aiActive = false;
    if (window._pendingAI) window._pendingAI.active = false;
    if (this._aiTimeout) {
      clearTimeout(this._aiTimeout);
      this._aiTimeout = null;
    }
  },

  _pickPreset(presets, defaultPreset) {
    return new Promise(function(resolve) {
      var overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      var dialog = document.createElement('div');
      dialog.className = 'modal';
      var optionsHtml = '';
      for (var i = 0; i < presets.length; i++) {
        var p = presets[i];
        var sel = p === defaultPreset ? ' selected' : '';
        optionsHtml += '<option value="' + esc(p) + '"' + sel + '>' + esc(p) + '</option>';
      }
      optionsHtml += '<option value="custom">Custom prompt...</option>';
      dialog.innerHTML =
        '<div class="modal-header"><span>Summarize with AI</span><button class="modal-close btn-icon">&times;</button></div>' +
        '<div class="modal-body">' +
          '<label style="display:block;margin-bottom:8px">Summary style:</label>' +
          '<select class="form-input" id="pending-preset-select">' + optionsHtml + '</select>' +
        '</div>' +
        '<div class="modal-footer">' +
          '<button class="btn modal-cancel-btn">Cancel</button>' +
          '<button class="btn btn-primary modal-ok-btn">Summarize</button>' +
        '</div>';
      overlay.appendChild(dialog);
      document.body.appendChild(overlay);
      var sel = dialog.querySelector('#pending-preset-select');
      if (sel) sel.focus();
      function dismiss(value) { overlay.remove(); resolve(value); }
      dialog.querySelector('.modal-close').onclick = function() { dismiss(null); };
      dialog.querySelector('.modal-cancel-btn').onclick = function() { dismiss(null); };
      dialog.querySelector('.modal-ok-btn').onclick = function() {
        dismiss(sel ? sel.value : defaultPreset);
      };
      overlay.addEventListener('click', function(ev) { if (ev.target === overlay) dismiss(null); });
    });
  },

  _showContextMenu(e, row) {
    var changeId = row.dataset.id;
    if (!changeId) return;

    var old = document.getElementById('pending-ctx-menu');
    if (old) old.remove();

    var menu = document.createElement('div');
    menu.id = 'pending-ctx-menu';
    menu.style.cssText = 'position:fixed;z-index:100;background:var(--bg-primary);border:1px solid var(--border);border-radius:6px;padding:4px;box-shadow:0 4px 12px rgba(0,0,0,0.3);min-width:120px';
    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';

    var items = this._providerType === 'github'
      ? [['View details', 'view'], ['Open in browser', 'open'], ['AI Summary', 'summarize'], ['Copy URL', 'copy']]
      : [['View', 'view'], ['AI Summary', 'summarize'], ['Copy ID', 'copy']];

    var self = this;
    items.forEach(function(item) {
      var btn = document.createElement('button');
      btn.className = 'btn';
      btn.textContent = item[0];
      btn.style.cssText = 'display:block;width:100%;text-align:left;margin-bottom:2px';
      btn.addEventListener('click', function() {
        menu.remove();
        if (item[1] === 'view') self._showDetail(row);
        else if (item[1] === 'open') {
          var c = self._changes.find(c => c.id === changeId);
          if (c && c.url) window.open(c.url, '_blank');
        }
        else if (item[1] === 'summarize') self._summarizeChange(row);
        else if (item[1] === 'copy') {
          var change = self._changes.find(c => c.id === changeId);
          if (change && change.url) {
            navigator.clipboard.writeText(change.url).then(
              () => App.showToast('Copied: ' + change.url, 'success'),
              () => App.showToast('URL: ' + change.url, 'success')
            );
          }
        }
      });
      menu.appendChild(btn);
    });

    document.body.appendChild(menu);
    var rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) menu.style.left = (window.innerWidth - rect.width - 4) + 'px';
    if (rect.bottom > window.innerHeight) menu.style.top = (window.innerHeight - rect.height - 4) + 'px';

    var dismiss = function(ev) {
      if (!menu.contains(ev.target)) { menu.remove(); document.removeEventListener('mousedown', dismiss, true); }
    };
    setTimeout(function() { document.addEventListener('mousedown', dismiss, true); }, 0);
  },
};
