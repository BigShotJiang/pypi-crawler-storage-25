/* Dashboard view — project table matching TUI layout
 * Group headers (Local / remote hosts) expand/collapse with localStorage.
 * Click row to expand TUI-style action submenu. Click name → explore.
 * Space key toggles project activation (green dot).  Navigation actions
 * (explore, update, config) pass the project path via App.state so views
 * can query the API with ?project= without changing the persistent active
 * project.
 */
const DashboardView = {
  _renderGen: 0,
  _activeRow: -1,
  _rows: [],
  _filterText: '',
  _filterFields: { name: true, description: false, branch: false, path: false, host: false, tags: false },
  _statusFilters: { dirty: false, ahead: false, behind: false },
  _activePaneName: 'All',
  _activePaneTags: [],  // empty = show all
  _allPanes: [],
  _allKnownTags: [],
  _activeAction: -1,  // index within expanded action items

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Open submenu'},
    {key: 'Space', desc: 'Activate/deactivate'},
    {key: 'Home/End', desc: 'First/last row'},
    {sep: true},
    {key: '/', desc: 'Search projects', action: '/'},
    {key: 'R', desc: 'Refresh project', action: 'R'},
    {key: 'n', desc: 'Rename project', action: 'n'},
    {key: 'c', desc: 'Settings', action: 'c'},
    {key: 'x', desc: 'Explore', action: 'x'},
    {key: 'u', desc: 'Update', action: 'u'},
    {key: 'S', desc: 'Shell', action: 'S'},
    {key: 'M', desc: 'Messages', action: 'M'},
    {key: 'm/?', desc: 'Command menu'},
    {key: 'Esc', desc: 'Close/clear'},
  ],

  async render(container, state) {
    const gen = ++this._renderGen;
    container.innerHTML = `
      <div class="view-header" style="margin-bottom:0">
        <h2 style="margin-bottom:0">Dashboard</h2>
      </div>
      <div class="tab-bar" id="dash-pane-tabs" style="margin-bottom:0"></div>
      <div id="dash-projects" class="loading">Loading projects</div>
      <div class="search-bar" id="dash-search-bar">
        <input type="text" id="dash-search" placeholder="/ Search projects..." aria-label="Filter projects">
        <span id="dash-search-count" style="color:var(--text-muted);font-size:var(--font-size-sm);align-self:center"></span>
        <div class="dash-filter-toggles" id="dash-filter-toggles">
          <span style="color:var(--text-muted);font-size:var(--font-size-xs);margin-right:4px">In:</span>
          <button class="btn btn-xs dash-field-toggle active" data-field="name" title="Search in project name">Name</button>
          <button class="btn btn-xs dash-field-toggle" data-field="description" title="Search in description">Desc</button>
          <button class="btn btn-xs dash-field-toggle" data-field="branch" title="Search in branch name">Branch</button>
          <button class="btn btn-xs dash-field-toggle" data-field="path" title="Search in project path">Path</button>
          <button class="btn btn-xs dash-field-toggle" data-field="host" title="Search in remote hostname">Host</button>
          <button class="btn btn-xs dash-field-toggle" data-field="tags" title="Search in tags">Tags</button>
          <span style="color:var(--border);margin:0 4px">|</span>
          <button class="btn btn-xs dash-status-toggle" data-status="dirty" title="Only dirty repos" style="color:var(--red)">Dirty</button>
          <button class="btn btn-xs dash-status-toggle" data-status="ahead" title="Only repos ahead of upstream" style="color:var(--accent)">Ahead</button>
          <button class="btn btn-xs dash-status-toggle" data-status="behind" title="Only repos behind upstream" style="color:var(--yellow)">Behind</button>
          <button class="btn btn-xs" id="dash-filter-clear" title="Clear all filters">Clear</button>
          <span style="color:var(--border);margin:0 4px">|</span>
          <span id="dash-pane-quick" style="display:inline-flex;gap:2px"></span>
        </div>
        <button class="btn" id="dash-refresh-inline" title="Refresh all">\u21bb</button>
        <button class="btn" id="dash-configure-inline" title="Configure">\u2699</button>
        <button class="btn" id="dash-commands-inline" title="Commands (m)">&#x2630;</button>
      </div>
    `;

    // Wire sidebar action items
    const manageBtn = document.getElementById('dash-manage');
    const configureBtn = document.getElementById('dash-configure');
    if (manageBtn) { manageBtn.onclick = (e) => { e.preventDefault(); this._manageModal(container, state); }; }
    if (configureBtn) { configureBtn.onclick = (e) => { e.preventDefault(); this._configureModal(); }; }
    const refreshInline = document.getElementById('dash-refresh-inline');
    if (refreshInline) { refreshInline.onclick = () => this.render(container, state); }
    const configInline = document.getElementById('dash-configure-inline');
    if (configInline) { configInline.onclick = () => this._configureModal(); }
    const commandsInline = document.getElementById('dash-commands-inline');
    if (commandsInline) { commandsInline.onclick = () => this._openCommandMenu(); }

    // Fixed bottom-right reset button
    let resetBtn = document.getElementById('dash-reset-order');
    if (!resetBtn) {
      resetBtn = document.createElement('button');
      resetBtn.id = 'dash-reset-order';
      resetBtn.className = 'btn dash-reset-order-fixed';
      resetBtn.title = 'Reset row order to default';
      resetBtn.textContent = 'Reset Order';
      document.body.appendChild(resetBtn);
    }
    resetBtn.style.display = '';
    resetBtn.onclick = () => {
      resetDashboardOrder();
      this.render(container, state);
    };

    // Live search/filter
    const searchInput = document.getElementById('dash-search');
    searchInput.addEventListener('input', () => {
      this._filterText = searchInput.value.toLowerCase();
      this._applyFilter();
    });
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        searchInput.value = '';
        this._filterText = '';
        this._statusFilters = { dirty: false, ahead: false, behind: false };
        this._switchPane('All');
        document.querySelectorAll('.dash-status-toggle').forEach(b => b.classList.remove('active'));
        this._applyFilter();
        searchInput.blur();
      }
    });

    // Field toggles (Name, Desc, Branch, Path, Host)
    document.querySelectorAll('.dash-field-toggle').forEach(btn => {
      if (this._filterFields[btn.dataset.field]) btn.classList.add('active');
      else btn.classList.remove('active');
      btn.addEventListener('click', () => {
        const f = btn.dataset.field;
        this._filterFields[f] = !this._filterFields[f];
        btn.classList.toggle('active');
        // Ensure at least one field is active
        if (!Object.values(this._filterFields).some(v => v)) {
          this._filterFields.name = true;
          document.querySelector('.dash-field-toggle[data-field="name"]').classList.add('active');
        }
        this._applyFilter();
      });
    });

    // Status toggles (Dirty, Ahead, Behind)
    document.querySelectorAll('.dash-status-toggle').forEach(btn => {
      if (this._statusFilters[btn.dataset.status]) btn.classList.add('active');
      else btn.classList.remove('active');
      btn.addEventListener('click', () => {
        const s = btn.dataset.status;
        this._statusFilters[s] = !this._statusFilters[s];
        btn.classList.toggle('active');
        this._applyFilter();
      });
    });

    // Load pane tabs dynamically
    this._loadPaneTabs();

    // Clear all filters
    document.getElementById('dash-filter-clear').addEventListener('click', () => {
      searchInput.value = '';
      this._filterText = '';
      this._filterFields = { name: true, description: false, branch: false, path: false, host: false, tags: false };
      this._statusFilters = { dirty: false, ahead: false, behind: false };
      this._switchPane('All');
      document.querySelectorAll('.dash-field-toggle').forEach(b => {
        b.classList.toggle('active', b.dataset.field === 'name');
      });
      document.querySelectorAll('.dash-status-toggle').forEach(b => b.classList.remove('active'));
      this._applyFilter();
    });

    try {
      const projects = await API.getProjects();
      const current = await API.getCurrentProject();
      state.projects = projects;
      this._allProjects = projects;
      this._renderProjects(projects, current.path);
      // Apply any lingering filters (status/pane toggles persist across re-renders)
      const hasActive = this._filterText || this._statusFilters.dirty || this._statusFilters.ahead || this._statusFilters.behind || this._activePaneTags.length;
      if (hasActive) this._applyFilter();
    } catch (e) {
      document.getElementById('dash-projects').innerHTML =
        `<div class="empty-state"><h3>Error loading projects</h3><p>${e.message}</p></div>`;
    }
  },

  _applyFilter() {
    const q = this._filterText;
    const ff = this._filterFields;
    const sf = this._statusFilters;
    const pt = this._activePaneTags;
    const hasStatusFilter = sf.dirty || sf.ahead || sf.behind;
    const hasPaneFilter = pt.length > 0;
    let visible = 0;
    let total = 0;
    this._rows.forEach(row => {
      total++;
      // Text match against selected fields
      let textMatch = !q;
      if (q) {
        if (ff.name && (row.dataset.name || '').toLowerCase().includes(q)) textMatch = true;
        if (ff.description && (row.dataset.desc || '').toLowerCase().includes(q)) textMatch = true;
        if (ff.branch && (row.dataset.branch || '').toLowerCase().includes(q)) textMatch = true;
        if (ff.path && (row.dataset.path || '').toLowerCase().includes(q)) textMatch = true;
        if (ff.host && (row.dataset.host || '').toLowerCase().includes(q)) textMatch = true;
        if (ff.tags && (row.dataset.tags || '').toLowerCase().includes(q)) textMatch = true;
      }
      // Status match (any active status filter must match)
      let statusMatch = !hasStatusFilter;
      if (hasStatusFilter) {
        if (sf.dirty && parseInt(row.dataset.dirty || '0') > 0) statusMatch = true;
        if (sf.ahead && parseInt(row.dataset.ahead || '0') > 0) statusMatch = true;
        if (sf.behind && parseInt(row.dataset.behind || '0') > 0) statusMatch = true;
      }
      // Pane tag match (intersection — project matches if any effective tag is in pane tags)
      let paneMatch = !hasPaneFilter;
      if (hasPaneFilter) {
        const rowTags = (row.dataset.tags || '').split(',').filter(Boolean);
        paneMatch = rowTags.some(t => pt.includes(t));
      }
      const match = textMatch && statusMatch && paneMatch;
      row.style.display = match ? '' : 'none';
      if (match) visible++;
    });
    // Hide action rows for hidden project rows and reset chevrons
    document.querySelectorAll('.dash-action-row').forEach(r => r.remove());
    document.querySelectorAll('tr[data-expanded="1"]').forEach(r => {
      const chevron = r.querySelector('.dash-row-toggle');
      if (chevron) chevron.textContent = '\u25b8';
      r.dataset.expanded = '';
    });
    // Update count
    const countEl = document.getElementById('dash-search-count');
    if (countEl) {
      const hasFilter = q || hasStatusFilter || hasPaneFilter;
      countEl.textContent = hasFilter ? `${visible} of ${total} projects` : '';
    }
  },

  _renderProjects(projects, currentPath) {
    const el = document.getElementById('dash-projects');
    if (!projects.length) {
      el.innerHTML = `<div class="empty-state">
        <h3>No projects registered</h3>
        <p>Add a project directory to get started.</p>
        <button class="btn btn-primary" onclick="document.getElementById('dash-manage').click()">Manage Projects</button>
      </div>`;
      return;
    }

    // Group: local first, then by remote host
    const local = [];
    const remoteByHost = {};
    projects.forEach(p => {
      if (p.remote) {
        const host = (p.path.match(/@([^:]+)/) || ['', 'remote'])[1];
        (remoteByHost[host] = remoteByHost[host] || []).push(p);
      } else {
        local.push(p);
      }
    });
    local.sort((a, b) => a.name.localeCompare(b.name));
    const sortedHosts = Object.keys(remoteByHost).sort();

    el.className = '';
    const actionMode = this._getActionMode();
    let html = `<table class="data-table" id="dash-table" role="grid" aria-label="Projects">
      <thead><tr>
        <th style="width:2ch"></th><th style="width:3ch"></th><th>Name</th><th>Branch</th><th>Status</th><th>Path</th>${actionMode !== 'expander' ? '<th class="row-actions-col"></th>' : ''}
      </tr></thead>`;

    const self = this;

    // --- Local group (own tbody) ---
    const colCount = actionMode !== 'expander' ? 7 : 6;

    if (local.length) {
      const localCollapsed = loadPreference('dash-group-local', false);
      html += `<tbody data-group="local">
        <tr class="dash-group-header">
          <td colspan="${colCount}" class="group-header-cell">
            <span class="drag-handle">&#9776;</span>
            <span class="group-toggle">${localCollapsed ? '\u25b6' : '\u25bc'}</span>
            \u2302 Local
            <button class="btn-icon dash-group-shell" data-ssh="" title="Shell">&gt;\u005f</button>
          </td></tr>`;
      local.forEach(p => { html += this._renderRow(p, currentPath, localCollapsed, actionMode); });
      html += '</tbody>';
    }

    // --- Remote groups (own tbody each) ---
    sortedHosts.forEach(host => {
      const key = 'remote-' + host;
      const collapsed = loadPreference('dash-group-' + key, false);
      const sshTarget = (remoteByHost[host][0].path.match(/^([^:]+):/) || ['', host])[1];
      html += `<tbody data-group="${esc(key)}">
        <tr class="dash-group-header">
          <td colspan="${colCount}" class="group-header-cell">
            <span class="drag-handle">&#9776;</span>
            <span class="group-toggle">${collapsed ? '\u25b6' : '\u25bc'}</span>
            \u21c4 ${esc(host)}
            <button class="btn-icon dash-group-shell" data-ssh="${esc(sshTarget)}" title="Shell">&gt;\u005f</button>
            <button class="btn-icon dash-host-addresses" data-host="${esc(host)}" title="SSH addresses">\u2699</button>
          </td></tr>`;
      remoteByHost[host].sort((a, b) => a.name.localeCompare(b.name));
      remoteByHost[host].forEach(p => { html += this._renderRow(p, currentPath, collapsed, actionMode); });
      html += '</tbody>';
    });

    // Standalone sync entry when no remote groups exist
    if (!sortedHosts.length) {
      html += `<tbody><tr class="dash-sync-row" data-host="">
        <td></td><td></td><td colspan="${colCount - 2}" style="padding:4px 24px;color:var(--text-muted);cursor:pointer">
          \u21bb sync from remote...
        </td>
      </tr></tbody>`;
    }

    html += '</table>';
    el.innerHTML = html;

    // Collect navigable rows
    this._rows = Array.from(el.querySelectorAll('tr[data-path]'));
    this._activeRow = -1;

    // Column resizer
    const table = document.getElementById('dash-table');
    if (table) initColumnResizer(table, 'dashboard');

    // Drag-and-drop reordering (group-level + row-level)
    if (table) initDashboardSortable(table);

    // --- Append sync + metrics rows AFTER sortable restores order (so they stay last) ---
    if (table) {
      table.querySelectorAll('tbody[data-group]').forEach(tbody => {
        const group = tbody.dataset.group || '';
        if (!group.startsWith('remote-')) return;
        const host = group.replace('remote-', '');
        const collapsed = loadPreference('dash-group-' + group, false);
        const syncTr = document.createElement('tr');
        syncTr.className = 'dash-sync-row';
        syncTr.dataset.host = host;
        if (collapsed) syncTr.style.display = 'none';
        syncTr.innerHTML = `<td></td><td></td><td colspan="${colCount - 2}" style="padding:4px 24px;color:var(--text-muted);cursor:pointer">\u21bb sync from ${esc(host)}...</td>`;
        tbody.appendChild(syncTr);
        // Metrics summary row (populated async) — click opens shell
        const metricsTr = document.createElement('tr');
        metricsTr.className = 'dash-metrics-row';
        metricsTr.dataset.host = host;
        const shellBtn = tbody.querySelector('.dash-group-shell');
        metricsTr.dataset.ssh = shellBtn ? shellBtn.dataset.ssh : host;
        if (collapsed) metricsTr.style.display = 'none';
        metricsTr.innerHTML = `<td></td><td></td><td colspan="${colCount - 2}" class="dash-metrics-cell" style="cursor:pointer"></td>`;
        tbody.appendChild(metricsTr);
      });
      this._fetchHostMetrics(null, this._renderGen);
    }

    // --- Group header collapse/expand ---
    el.querySelectorAll('.dash-group-header').forEach(hdr => {
      hdr.addEventListener('click', (e) => {
        // Don't toggle when dragging via handle or clicking shell button
        if (e.target.closest('.drag-handle') || e.target.closest('.dash-group-shell') || e.target.closest('.dash-host-addresses')) return;
        const tbody = hdr.closest('tbody');
        const group = tbody && tbody.dataset.group;
        if (!group) return;
        const key = 'dash-group-' + group;
        const isCollapsed = !loadPreference(key, false);
        savePreference(key, isCollapsed);
        const toggle = hdr.querySelector('.group-toggle');
        toggle.textContent = isCollapsed ? '\u25b6' : '\u25bc';
        // Show/hide project rows within this tbody
        tbody.querySelectorAll('tr[data-path]').forEach(row => {
          row.style.display = isCollapsed ? 'none' : '';
        });
        // Also hide action rows, sync rows, and metrics rows
        tbody.querySelectorAll('.dash-action-row, .dash-sync-row, .dash-metrics-row').forEach(r => {
          r.style.display = isCollapsed ? 'none' : '';
        });
      });
    });

    // --- Group header shell button ---
    el.querySelectorAll('.dash-group-shell').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!window.TerminalManager) {
          App.showToast('Terminal not available', 'error');
          return;
        }
        const ssh = btn.dataset.ssh;
        if (ssh) {
          const hostPart = ssh.replace(/^.*@/, '');
          TerminalManager.show({ ssh, title: 'Shell: ' + hostPart });
        } else {
          TerminalManager.show();
        }
      });
    });

    // --- Host addresses settings button ---
    el.querySelectorAll('.dash-host-addresses').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const host = btn.dataset.host;
        this._showHostAddressesDialog(host);
      });
    });

    // --- Row click → expand TUI-style action submenu (expander mode) or explore (icons mode) ---
    el.querySelectorAll('tr[data-path]').forEach(row => {
      row.addEventListener('click', (e) => {
        // If clicking a button or link inside actions, let it handle
        if (e.target.closest('.dash-action-row') || e.target.closest('.dash-name-link') || e.target.closest('.row-actions')) return;
        if (actionMode === 'icons') {
          this._navigateToView(row.dataset.path, 'explore');
        } else {
          this._toggleActions(row);
        }
      });
    });

    // --- Right-click context menu on project rows ---
    el.querySelectorAll('tr[data-path]').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showProjectContextMenu(e, row);
      });
    });

    // --- Icon bar button handlers (icons mode) ---
    if (actionMode !== 'expander') {
      el.querySelectorAll('.row-actions .btn-icon').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const row = btn.closest('tr');
          const path = row.dataset.path;
          const act = btn.dataset.action;
          if (act === 'explore' || act === 'update' || act === 'config') {
            this._navigateToView(path, act);
          } else if (act === 'shell') {
            this._openShell(path);
          } else if (act === 'refresh') {
            this._refreshRow(path, row);
          }
        });
      });
    }

    // --- Name click → toggle expander (expander mode) or explore (icons mode) ---
    el.querySelectorAll('.dash-name-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.stopPropagation();
        if (actionMode !== 'icons') {
          const row = link.closest('tr');
          if (row) this._toggleActions(row);
        } else {
          this._navigateToView(link.dataset.path, 'explore');
        }
      });
    });

    // --- Sync row click → remote sync ---
    el.querySelectorAll('.dash-sync-row').forEach(row => {
      row.addEventListener('click', async () => {
        let host = row.dataset.host;
        if (!host) {
          host = await promptModal('Enter user@host for remote sync:', '');
          if (!host) return;
        }
        const ok = await confirmModal(`Sync all projects from ${host}? This will scan and register remote projects.`);
        if (!ok) return;
        try {
          App.showToast(`Syncing from ${host}...`);
          var res = await API.remoteSync(host);
          App.showToast(`Synced from ${host}, ${res.added} project${res.added===1?'':'s'} added`, 'success');
          this.render(document.getElementById('view-container'), App.state);
        } catch (err) {
          App.showToast('Sync error: ' + err.message, 'error');
        }
      });
    });

    // --- Metrics row click → shell on host ---
    el.querySelectorAll('.dash-metrics-row').forEach(row => {
      row.addEventListener('click', () => {
        if (!window.TerminalManager) {
          App.showToast('Terminal not available', 'error');
          return;
        }
        const ssh = row.dataset.ssh;
        if (!ssh) return;
        const hostPart = ssh.replace(/^.*@/, '');
        TerminalManager.show({ ssh, title: 'Shell: ' + hostPart });
      });
    });

    // --- Status cell click → refresh ---
    el.querySelectorAll('.dash-status-cell').forEach(cell => {
      cell.addEventListener('click', async (e) => {
        e.stopPropagation();
        cell.innerHTML = '<span class="badge badge-loading">...</span>';
        try {
          const projects = await API.getProjects();
          const proj = projects.find(p => p.path === cell.dataset.path);
          if (proj && proj.summary) {
            cell.innerHTML = this._formatStatus(proj.summary);
          }
        } catch (err) {
          cell.innerHTML = '<span style="color:var(--red)">err</span>';
        }
      });
    });
  },

  /** Navigate to a view in the context of a project (without activating it). */
  _navigateToView(projectPath, viewName) {
    App.state.selectedProject = projectPath;
    // Find the project info so views can show name/host context
    const row = document.querySelector(`tr[data-path="${CSS.escape(projectPath)}"]`);
    App.state.selectedProjectName = (row && row.dataset.name) || projectPath.split('/').pop();
    App.state.selectedProjectRemote = !!(row && row.dataset.remote === 'true');
    App.state.selectedProjectHost = (row && row.dataset.host) || '';
    App.state.selectedProjectPersona = (row && row.dataset.persona) || 'yocto';
    App.navigate(viewName, true);
  },

  _openCommandMenu() {
    const row = this._activeRow >= 0 ? this._rows[this._activeRow] : null;
    const path = (row && row.dataset.path) || App.state.currentProject;
    const persona = (row && row.dataset.persona) || App.state.selectedProjectPersona || 'yocto';
    const isYocto = persona === 'yocto';

    commandMenu(isYocto).then((view) => {
      if (!view) return;
      if (path) {
        this._navigateToView(path, view);
      } else {
        App.navigate(view, true);
      }
    });
  },

  _renderRow(p, currentPath, hidden, actionMode) {
    const s = p.summary || {};
    const isCurrent = p.path === currentPath;
    const dot = isCurrent
      ? '<span class="status-dot clean" title="Active"></span>'
      : '<span class="status-dot" style="background:transparent"></span>';
    const status = this._formatStatus(s);
    const desc = p.description ? `<span style="color:var(--text-muted);font-size:var(--font-size-sm);font-style:italic;margin-left:8px">${esc(p.description)}</span>` : '';

    // Extract host from remote path (user@host:/path → host)
    const hostMatch = p.remote ? p.path.match(/@([^:]+):/) : null;
    const host = hostMatch ? hostMatch[1] : '';
    const effectiveTags = (p.effective_tags || [p.persona || 'yocto']).join(',');
    // Build type/tag badges for after the path
    const persona = p.persona || 'yocto';
    let metaHtml = '';
    if (persona !== 'yocto') {
      metaHtml += `<span style="color:var(--text-muted);font-size:var(--font-size-sm);margin-left:8px">(${esc(persona)})</span>`;
    }
    const explicitTags = p.tags || [];
    if (explicitTags.length) {
      metaHtml += explicitTags.map(t => `<span class="badge" style="font-size:var(--font-size-xs);margin-left:4px;padding:1px 5px;color:var(--accent)">${esc(t)}</span>`).join('');
    }
    return `<tr class="${isCurrent ? 'dash-current-row' : ''}" data-path="${esc(p.path)}" data-name="${esc(p.name)}" data-desc="${esc(p.description || '')}" data-branch="${esc(s.branch || '')}" data-dirty="${s.dirty_count || 0}" data-ahead="${s.ahead || 0}" data-behind="${s.behind || 0}" data-remote="${p.remote ? 'true' : 'false'}" data-host="${esc(host)}" data-persona="${esc(persona)}" data-tags="${esc(effectiveTags)}" data-explicit-tags="${esc((p.tags || []).join(','))}" data-last-updated="${s.last_updated || ''}" data-last-checked="${s.last_checked || ''}" role="row" tabindex="-1"${hidden ? ' style="display:none"' : ''}>
      <td><div class="dash-row-first-cell">${actionMode !== 'icons' ? '<span class="dash-row-toggle" title="Click to expand">\u25b8</span>' : '<span class="dash-row-toggle" style="visibility:hidden">\u25b8</span>'}<span class="drag-handle">&#9776;</span></div></td>
      <td>${dot}</td>
      <td>
        <span class="dash-name-link" data-path="${esc(p.path)}" title="Explore ${esc(p.name)}" style="cursor:pointer;font-weight:${isCurrent ? '600' : '400'}">${esc(p.name)}</span>${desc}
      </td>
      <td style="color:var(--accent)">${esc(s.branch || '')}</td>
      <td class="dash-status-cell" data-path="${esc(p.path)}" title="Click to refresh" style="cursor:pointer">${status}</td>
      <td style="color:var(--text-muted);font-size:var(--font-size-sm)">${esc(p.path)}${metaHtml}</td>
      ${actionMode !== 'expander' ? `<td class="row-actions">
        <button class="btn-icon" data-action="explore" title="Explore (x)">\u21c4</button>
        <button class="btn-icon" data-action="update" title="Update (u)">\u2191</button>
        <button class="btn-icon" data-action="config" title="Settings (c)">\u2699</button>
        <button class="btn-icon" data-action="shell" title="Shell (S)">>\u005f</button>
        <button class="btn-icon" data-action="refresh" title="Refresh (R)">\u21bb</button>
      </td>` : ''}
    </tr>`;
  },

  _formatStatus(s) {
    if (!s) return '';
    if (s.loading) return '<span class="badge badge-loading">loading...</span>';
    if (!s.repo_count) return '';
    const parts = [`${s.repo_count} repos`];
    if (s.dirty_count) parts.push(`<span style="color:var(--red)">\u270e${s.dirty_count}</span>`);
    if (s.ahead) parts.push(`<span style="color:var(--accent)">\u2191${s.ahead}</span>`);
    if (s.behind) {
      let behindStr = '\u2193' + s.behind;
      if (s.tracked_behind != null && s.tracked_behind < s.behind) {
        behindStr += ' <span style="color:var(--text-muted);font-size:var(--font-size-xs)">(' + s.tracked_behind + ' tracked)</span>';
      }
      parts.push('<span style="color:var(--yellow)">' + behindStr + '</span>');
    }
    if (!s.dirty_count && !s.ahead && !s.behind) parts.push(`<span style="color:var(--green)">\u2713</span>`);
    return parts.join(' ');
  },

  _formatRelativeTime(epoch) {
    if (!epoch) return '';
    const secs = Math.floor(Date.now() / 1000 - epoch);
    if (secs < 60) return 'just now';
    if (secs < 3600) return Math.floor(secs / 60) + 'm ago';
    if (secs < 86400) return Math.floor(secs / 3600) + 'h ago';
    return Math.floor(secs / 86400) + 'd ago';
  },

  _toggleActions(row) {
    const path = row.dataset.path;

    // If this row is already expanded, collapse it and return
    if (row.dataset.expanded === '1') {
      // Remove this row's action row
      const next = row.nextElementSibling;
      if (next && next.classList.contains('dash-action-row')) next.remove();
      const chevron = row.querySelector('.dash-row-toggle');
      if (chevron) chevron.textContent = '\u25b8';
      row.dataset.expanded = '';
      this._activeAction = -1;
      return;
    }

    // Expand this row
    row.dataset.expanded = '1';
    this._activeAction = -1;
    const chevron = row.querySelector('.dash-row-toggle');
    if (chevron) chevron.textContent = '\u25be';

    const isCurrent = row.classList.contains('dash-current-row');
    const isYocto = row.dataset.persona === 'yocto';
    const actionRow = document.createElement('tr');
    actionRow.className = 'dash-action-row';
    const acColspan = this._getActionMode() !== 'expander' ? 5 : 4;
    let menuHtml = `
        <div class="dash-action-item" data-act="explore"><span class="tree-line-span"></span> <span class="dash-act-icon">\u{1f50d}</span> explore <span class="dash-act-desc">Browse commits and repos</span></div>
        <div class="dash-action-item" data-act="shell"><span class="tree-line-span"></span> <span class="dash-act-icon">&gt;_</span> shell <span class="dash-act-desc">Open terminal in project</span></div>
        <div class="dash-action-item" data-act="refresh"><span class="tree-line-span"></span> <span class="dash-act-icon">\u21bb</span> refresh <span class="dash-act-desc">Refresh project status</span></div>
        <div class="dash-action-item" data-act="update"><span class="tree-line-span"></span> <span class="dash-act-icon">\u2191</span> update <span class="dash-act-desc">Update git repos</span></div>
        <div class="dash-action-item" data-act="pending"><span class="tree-line-span"></span> <span class="dash-act-icon">\u{1f4cb}</span> pending changes <span class="dash-act-desc">Browse PRs or mailing list patches</span></div>
        <div class="dash-action-item" data-act="export-prep"><span class="tree-line-span"></span> <span class="dash-act-icon">\u2699</span> pull request <span class="dash-act-desc">Prepare commits for upstream</span></div>`;
    if (isYocto) {
      menuHtml += `
        <div class="dash-action-item" data-act="export"><span class="tree-line-span"></span> <span class="dash-act-icon">\u{1f4e6}</span> export <span class="dash-act-desc">Export config to .conf.json</span></div>`;
    }
    menuHtml += `
        <div class="dash-action-item" data-act="config"><span class="tree-line-span"></span> <span class="dash-act-icon">\u2699</span> settings <span class="dash-act-desc">Repo and layer settings</span></div>
        <div class="dash-action-item" data-act="properties"><span class="tree-line-span"></span> <span class="dash-act-icon">\u{1f3f7}</span> properties <span class="dash-act-desc">Name, description, tags</span></div>
        <div class="dash-action-item" data-act="rename"><span class="tree-line-span"></span> <span class="dash-act-icon">\u270e</span> rename <span class="dash-act-desc">Rename project</span></div>
        <div class="dash-action-item" data-act="activate"><span class="tree-line-span"></span> <span class="dash-act-icon">${isCurrent ? '\u25cb' : '\u25cf'}</span> ${isCurrent ? 'deactivate' : 'activate'} <span class="dash-act-desc">${isCurrent ? 'Clear active project' : 'Set as active project'}</span></div>
        <div class="dash-action-item dash-action-danger" data-act="remove"><span class="tree-line-span"></span> <span class="dash-act-icon">\u2717</span> remove <span class="dash-act-desc">Remove from project list</span></div>`;
    // Detail rows: traits + last updated
    const traitParts = [];
    const persona = row.dataset.persona || 'yocto';
    if (persona !== 'yocto') traitParts.push(persona);
    const explicitTags = (row.dataset.explicitTags || '').split(',').filter(Boolean);
    explicitTags.forEach(t => traitParts.push(t));
    const desc = row.dataset.desc || '';
    if (desc) traitParts.push(desc);
    const lastUpdated = row.dataset.lastUpdated;
    const hasTraits = traitParts.length > 0;
    const hasUpdated = lastUpdated && lastUpdated !== '';
    if (hasTraits) {
      menuHtml += `<div class="dash-detail-row"><span class="tree-line-span"></span> <span class="dash-detail-label">traits</span> <span class="dash-detail-value">${esc(traitParts.join(' \u00b7 '))}</span></div>`;
    }
    if (hasUpdated) {
      const ago = this._formatRelativeTime(parseFloat(lastUpdated));
      let updatedDisplay = ago;
      const lastChecked = row.dataset.lastChecked;
      if (lastChecked && lastChecked !== '') {
        const checkedAgo = this._formatRelativeTime(parseFloat(lastChecked));
        updatedDisplay += ` (checked ${checkedAgo})`;
      }
      menuHtml += `<div class="dash-detail-row tree-last"><span class="tree-line-span"></span> <span class="dash-detail-label">last updated</span> <span class="dash-detail-value">${esc(updatedDisplay)}</span></div>`;
    }
    // Fix tree-last class on the last visible item
    const tmpDiv = document.createElement('div');
    tmpDiv.innerHTML = menuHtml;
    const allItems = tmpDiv.querySelectorAll('.dash-action-item, .dash-detail-row');
    allItems.forEach(el => el.classList.remove('tree-last'));
    if (allItems.length) allItems[allItems.length - 1].classList.add('tree-last');
    menuHtml = tmpDiv.innerHTML;
    actionRow.innerHTML = `<td></td><td></td><td colspan="${acColspan}" style="padding:0 12px 2px 24px">
      <div class="dash-actions-menu">${menuHtml}
      </div>
    </td>`;
    row.after(actionRow);

    // Action handlers
    actionRow.querySelectorAll('.dash-action-item').forEach(item => {
      item.addEventListener('click', async (e) => {
        e.stopPropagation();
        const act = item.dataset.act;
        if (act === 'activate') {
          this._activateProject(path, row);
        } else if (act === 'explore' || act === 'update' || act === 'config') {
          this._navigateToView(path, act);
        } else if (act === 'pending') {
          this._navigateToView(path, 'pending');
        } else if (act === 'shell') {
          this._openShell(path);
        } else if (act === 'rename') {
          this._renameProject(path, row);
        } else if (act === 'refresh') {
          this._refreshRow(path, row);
        } else if (act === 'properties') {
          this._editProjectProperties(path, row);
        } else if (act === 'export-prep' || act === 'export') {
          this._navigateToView(path, 'export');
        } else if (act === 'remove') {
          const ok = await confirmModal('Remove this project from the list?');
          if (ok) {
            try {
              await API.removeProject(path);
              App.showToast('Project removed', 'success');
              this.render(document.getElementById('view-container'), App.state);
            } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
          }
        }
      });
    });
  },

  async _renameProject(path, row) {
    const currentName = row.dataset.name || path.split('/').pop();
    const newName = await promptModal('Rename project:', currentName);
    if (!newName || newName === currentName) return;
    try {
      await API.renameProject(path, newName);
      App.showToast('Renamed: ' + currentName + ' \u2192 ' + newName, 'success');
      this.render(document.getElementById('view-container'), App.state);
    } catch (err) {
      App.showToast('Error: ' + err.message, 'error');
    }
  },

  async _refreshRow(path, row) {
    const statusCell = row.querySelector('.dash-status-cell');
    if (statusCell) statusCell.innerHTML = '<span class="badge badge-loading">...</span>';
    try {
      const projects = await API.getProjects();
      const proj = projects.find(p => p.path === path);
      if (proj && proj.summary && statusCell) {
        statusCell.innerHTML = this._formatStatus(proj.summary);
        // Update branch cell too
        const branchCell = row.children[3];
        if (branchCell && proj.summary.branch) {
          branchCell.textContent = proj.summary.branch;
        }
      }
      App.showToast('Refreshed', 'success');
    } catch (err) {
      if (statusCell) statusCell.innerHTML = '<span style="color:var(--red)">err</span>';
      App.showToast('Error: ' + err.message, 'error');
    }
  },

  async _activateProject(path, row) {
    try {
      const resp = await API.activateProject(path);
      const name = row.dataset.name || path.split('/').pop();
      // Update all rows: clear previous active, set new one
      this._rows.forEach(r => {
        const dot = r.querySelector('.status-dot');
        const nameLink = r.querySelector('.dash-name-link');
        if (r.dataset.path === path && resp.active) {
          r.classList.add('dash-current-row');
          if (dot) dot.classList.add('clean');
          if (nameLink) nameLink.style.fontWeight = '600';
        } else {
          r.classList.remove('dash-current-row');
          if (dot) dot.classList.remove('clean');
          if (nameLink) nameLink.style.fontWeight = '400';
        }
      });
      App.state.currentProject = resp.active ? path : null;
      App.showToast(resp.active ? 'Activated: ' + name : 'Deactivated: ' + name, 'success');
    } catch (err) {
      App.showToast('Error: ' + err.message, 'error');
    }
  },

  _openShell(path) {
    if (!window.TerminalManager) {
      App.showToast('Terminal not available', 'error');
      return;
    }
    // Parse project path: remote projects are "user@host:/remote/path"
    const m = path.match(/^(.+@[^:]+):(.*)$/);
    if (m) {
      // Remote project — SSH into host with tmux session
      const basename = m[2].replace(/\/+$/, '').split('/').pop();
      const session = 'bit-' + basename.replace(/[^a-zA-Z0-9_-]/g, '-');
      TerminalManager.show({ ssh: m[1], path: m[2], session: session, title: 'Shell: ' + m[1] });
    } else {
      // Local project — shell in project directory with tmux session
      const basename = path.replace(/\/+$/, '').split('/').pop();
      const session = 'bit-' + basename.replace(/[^a-zA-Z0-9_-]/g, '-');
      TerminalManager.show({ cwd: path, session: session, title: 'Shell: ' + path.split('/').pop() });
    }
  },

  async _showProjectContextMenu(e, row) {
    const path = row.dataset.path;
    // Highlight the row
    const idx = this._rows.indexOf(row);
    if (idx >= 0) this._moveToIndex(idx);

    const isCurrent = row.classList.contains('dash-current-row');
    const isYocto = row.dataset.persona === 'yocto';
    const items = [
      { label: isCurrent ? 'Deactivate' : 'Activate', icon: isCurrent ? '\u25cb' : '\u25cf', key: 'Space', action: 'activate' },
      { sep: true },
      { label: 'Explore', icon: '\ud83d\udd0d', key: 'x', action: 'explore' },
      { label: 'Update', icon: '\u2191', key: 'u', action: 'update' },
      { label: 'Settings', icon: '\u2699', key: 'c', action: 'config' },
      { label: 'Shell', icon: '>_', key: 'S', action: 'shell' },
      { label: 'Pending changes', icon: '\ud83d\udccb', key: 'l', action: 'pending' },
      { sep: true },
      { label: 'Rename', icon: '\u270e', key: 'n', action: 'rename' },
      { label: 'Refresh', icon: '\u21bb', key: 'R', action: 'refresh' },
      { label: 'Tags', icon: '\u{1f3f7}', action: 'tags' },
      { sep: true },
      { label: 'Pull request', icon: '\u2699', action: 'export-prep' },
      { label: 'Export config', icon: '\u{1f4e6}', action: 'export-config' },
    ];
    if (isYocto) {
      items.push({ label: 'Export', icon: '\u{1f4e6}', action: 'export' });
    }
    items.push({ sep: true });
    items.push({ label: 'Remove', icon: '\u2717', action: 'remove', danger: true });

    const action = await contextMenu(e.clientX, e.clientY, items);
    if (!action) return;
    if (action === 'activate') {
      this._activateProject(path, row);
    } else if (action === 'explore' || action === 'update' || action === 'config') {
      this._navigateToView(path, action);
    } else if (action === 'pending') {
      this._navigateToView(path, 'pending');
    } else if (action === 'shell') {
      this._openShell(path);
    } else if (action === 'rename') {
      this._renameProject(path, row);
    } else if (action === 'refresh') {
      this._refreshRow(path, row);
    } else if (action === 'tags') {
      this._editProjectTags(path, row);
    } else if (action === 'export-config') {
      App.state.configsTab = 'export';
      this._navigateToView(path, 'configs');
    } else if (action === 'export-prep' || action === 'export') {
      this._navigateToView(path, 'export');
    } else if (action === 'remove') {
      const ok = await confirmModal('Remove this project from the list?');
      if (ok) {
        try {
          await API.removeProject(path);
          App.showToast('Project removed', 'success');
          this.render(document.getElementById('view-container'), App.state);
        } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
      }
    }
  },

  _getActionMode() {
    return loadPreference('dash-action-mode', 'expander');
  },

  async _addProject() {
    // Step 1: Local or Remote?
    const mode = await modal('New Project', '<p>Where is this project?</p>', [
      { label: 'Local directory', value: 'local', primary: true },
      { label: 'Remote (SSH)', value: 'remote' },
    ]);
    if (!mode) return;

    let path, name, host;
    if (mode === 'local') {
      path = await pathBrowser('~', { title: 'Select Project Directory', allowNew: true });
      if (!path) return;
      name = path.split('/').pop();
    } else {
      host = await promptModal('Remote host (user@host):', '');
      if (!host) return;
      const remotePath = await pathBrowser('/home', { title: 'Select Remote Directory', host: host, allowNew: true });
      if (!remotePath) return;
      path = host + ':' + remotePath;
      name = remotePath.split('/').pop();
    }

    // Step 2: What kind of project?
    const choice = await modal('New Project', `
      <p style="margin-bottom:12px">Create project at: <strong>${esc(path)}</strong></p>
      <p style="color:var(--text-muted);font-size:var(--font-size-sm)">How should this project be set up?</p>
    `, [
      { label: 'Empty project', value: 'empty' },
      { label: 'Basic clone (3 core repos)', value: 'basic', primary: true },
      { label: 'Clone from config', value: 'config' },
    ]);
    if (!choice) return;

    try {
      if (choice === 'empty') {
        await API.addProject(path, name);
        App.showToast('Project added', 'success');
      } else if (choice === 'basic') {
        const branch = await promptModal('Branch:', 'master');
        if (branch === null) return;
        App.showToast('Creating project with core repos — watch for progress...');
        await API.setupClone({
          basic: true,
          branch: branch || 'master',
          project_dir: path,
          register_project: true,
          name: name,
        });
        App.showToast('Clone started — you will see per-repo progress updates', 'success');
      } else if (choice === 'config') {
        await this._pickConfigAndCreate(path, name);
      }
      this.render(document.getElementById('view-container'), App.state);
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  async _pickConfigAndCreate(path, name) {
    App.showToast('Loading configurations...');
    let entries;
    try {
      entries = await API.getSetupRegistry();
    } catch (e) {
      App.showToast('Failed to load registry: ' + e.message, 'error');
      return;
    }

    // Flatten to one row per configuration
    const rows = [];
    if (entries) {
      for (const entry of entries) {
        if (entry.configurations && entry.configurations.length) {
          for (const cfg of entry.configurations) {
            rows.push({ entry, cfg });
          }
        }
      }
    }

    if (!rows.length) {
      App.showToast('No configurations found in registry', 'error');
      return;
    }

    // Build a clickable selection list inside a custom modal
    const selected = await new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      let html = `<div class="modal">
        <div class="modal-header">
          <span>Pick Configuration</span>
          <button class="modal-close btn-icon">&times;</button>
        </div>
        <div class="modal-body" style="padding:0;max-height:400px;overflow-y:auto">`;
      for (let i = 0; i < rows.length; i++) {
        const { entry, cfg } = rows[i];
        const fname = (entry.filename || '').replace(/\.conf\.json$/, '');
        const desc = cfg.description || entry.description || '';
        html += `<div class="dash-action-item config-pick-item" data-idx="${i}" style="padding:10px 16px;cursor:pointer;border-bottom:1px solid var(--border)">
          <span class="badge" style="margin-right:6px">${esc(entry.source)}</span>
          <span style="color:var(--cyan)">${esc(fname)}</span>
          <span style="margin:0 4px;color:var(--border)">/</span>
          <strong style="color:var(--accent)">${esc(cfg.name)}</strong>
          ${desc ? '<br><span style="color:var(--text-muted);font-size:var(--font-size-sm);margin-left:4px">' + esc(desc) + '</span>' : ''}
        </div>`;
      }
      html += `</div>
        <div class="modal-footer"><button class="btn modal-cancel-btn">Cancel</button></div>
      </div>`;
      overlay.innerHTML = html;
      document.body.appendChild(overlay);

      function dismiss(val) { overlay.remove(); resolve(val); }
      overlay.querySelector('.modal-close').addEventListener('click', () => dismiss(null));
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', () => dismiss(null));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) dismiss(null); });
      overlay.querySelectorAll('.config-pick-item').forEach(item => {
        item.addEventListener('click', () => dismiss(parseInt(item.dataset.idx, 10)));
      });
    });

    if (selected === null || selected === undefined || !rows[selected]) return;

    const { entry, cfg } = rows[selected];
    App.showToast('Cloning from ' + cfg.name + '...');
    try {
      await API.setupClone({
        config_file: entry.path,
        config_name: cfg.name,
        project_dir: path,
        register_project: true,
        name: name,
      });
      App.showToast('Clone started — project will be registered when done', 'success');
    } catch (e) {
      App.showToast('Clone failed: ' + e.message, 'error');
    }
  },

  _manageModal(container, state) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `<div class="modal">
      <div class="modal-header">
        <span>Manage Projects</span>
        <button class="modal-close">\u00d7</button>
      </div>
      <div class="modal-body" style="padding:8px">
        <div class="dash-action-item" data-act="add-dir" style="padding:8px;cursor:pointer">
          <span class="dash-act-icon">+</span> Add directory
          <span class="dash-act-desc">Register a local project path</span>
        </div>
        <div class="dash-action-item" data-act="sync-remote" style="padding:8px;cursor:pointer">
          <span class="dash-act-icon">\u21bb</span> Sync from remote
          <span class="dash-act-desc">Sync projects from a remote host</span>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn modal-cancel-btn">Close</button>
      </div>
    </div>`;
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.querySelector('.modal-close').addEventListener('click', close);
    overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

    overlay.querySelectorAll('.dash-action-item').forEach(item => {
      item.addEventListener('click', async () => {
        const act = item.dataset.act;
        close();
        if (act === 'add-dir') {
          this._addProject();
        } else if (act === 'sync-remote') {
          const host = await promptModal('Enter user@host:', '');
          if (!host) return;
          const ok = await confirmModal(`Sync all projects from ${host}? This will scan and register remote projects.`);
          if (!ok) return;
          try {
            App.showToast(`Syncing from ${host}...`);
            var res = await API.remoteSync(host);
            App.showToast(`Synced from ${host}, ${res.added} project${res.added===1?'':'s'} added`, 'success');
            this.render(container, state);
          } catch (err) {
            App.showToast('Sync error: ' + err.message, 'error');
          }
        }
      });
    });
  },

  async _configureModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    // Load current settings
    let settings = {};
    try {
      const config = await API.getConfig();
      settings = config.settings || {};
    } catch (e) { /* use defaults */ }

    const options = {
      directory_browser: [
        ['auto', 'Auto-detect'], ['broot', 'broot'], ['ranger', 'ranger'],
        ['nnn', 'nnn'], ['fzf', 'fzf built-in'],
      ],
      git_viewer: [
        ['auto', 'Auto-detect'], ['tig', 'tig'], ['lazygit', 'lazygit'],
        ['gitui', 'gitui'], ['gitk', 'gitk'],
      ],
      preview_layout: [
        ['down', 'Bottom'], ['right', 'Side-by-side'], ['up', 'Top'],
      ],
      editor: [
        ['auto', 'Auto ($EDITOR)'], ['vim', 'vim'], ['nvim', 'neovim'],
        ['nano', 'nano'], ['emacs', 'emacs'], ['code', 'VS Code'],
      ],
      recipe_scan: [
        ['bitbake-layers', 'bitbake-layers'], ['file', 'File scan'],
      ],
      backup_prune_age: [
        ['0', 'Always'], ['1', '1 day'], ['3', '3 days'], ['7', '7 days'],
        ['14', '14 days'], ['30', '30 days'], ['never', 'Never'],
      ],
      host_metrics_refresh: [
        ['0', 'Off'], ['60', '1 minute'], ['120', '2 minutes'],
        ['300', '5 minutes'], ['600', '10 minutes'],
      ],
      default_dashboard_command: [
        ['explore', 'Explore'], ['update', 'Update'], ['config', 'Config'],
        ['shell', 'Shell'], ['recipes', 'Recipes'],
      ],
      web_autostart: [
        ['off', 'Off'], ['localhost', 'Localhost'], ['all', 'All interfaces'],
      ],
      web_open_browser: [
        ['false', 'Off'], ['true', 'On'],
      ],
      tmux_prefix: [
        ['C-a', 'Ctrl-A (screen)'], ['C-b', 'Ctrl-B (tmux)'],
        ['C-s', 'Ctrl-S'], ['C-q', 'Ctrl-Q'],
      ],
      nnn_colors: [
        ['6234', 'Cyan dirs (default)'], ['2234', 'Green dirs'],
        ['3234', 'Yellow dirs'], ['5234', 'Magenta dirs'],
      ],
      graph_renderer: [
        ['auto', 'Auto-detect'], ['graph-easy', 'Graph::Easy'], ['ascii', 'ASCII'],
      ],
      explore_load_size: [
        ['50', '50'], ['100', '100'], ['200', '200 (default)'],
        ['500', '500'], ['1000', '1000'],
      ],
    };

    const labels = {
      directory_browser: 'Dir browser',
      git_viewer: 'Git viewer',
      preview_layout: 'Preview layout',
      editor: 'Editor',
      recipe_scan: 'Recipe scan',
      backup_prune_age: 'Backup prune',
      host_metrics_refresh: 'Metrics refresh',
      default_dashboard_command: 'Default action',
      web_autostart: 'Web autostart',
      web_open_browser: 'Web open browser',
      tmux_prefix: 'Tmux prefix',
      nnn_colors: 'NNN colors',
      graph_renderer: 'Graph renderer',
      explore_load_size: 'Explore load size',
    };

    let bodyHtml = '';
    for (const [key, opts] of Object.entries(options)) {
      const current = String(settings[key] != null ? settings[key] : '');
      bodyHtml += `<div class="config-panel-row">
        <label>${esc(labels[key])}</label>
        <select class="form-select dash-config-select" data-key="${key}">`;
      opts.forEach(([val, label]) => {
        bodyHtml += `<option value="${esc(val)}"${current === val ? ' selected' : ''}>${esc(label)}</option>`;
      });
      bodyHtml += '</select></div>';
    }

    // Local preference: dashboard action mode
    const currentActionMode = loadPreference('dash-action-mode', 'expander');
    bodyHtml += `<div class="config-panel-row" style="margin-top:12px;padding-top:8px;border-top:1px solid var(--border)">
      <label>Dashboard actions</label>
      <select class="form-select" id="dash-action-mode-select">
        <option value="expander"${currentActionMode === 'expander' ? ' selected' : ''}>Expander submenu</option>
        <option value="icons"${currentActionMode === 'icons' ? ' selected' : ''}>Icon bar</option>
        <option value="both"${currentActionMode === 'both' ? ' selected' : ''}>Both</option>
      </select>
    </div>`;

    overlay.innerHTML = `<div class="modal" style="max-width:480px">
      <div class="modal-header">
        <span>Configure</span>
        <button class="modal-close">\u00d7</button>
      </div>
      <div class="modal-body" style="padding:12px">
        ${bodyHtml}
      </div>
      <div class="modal-footer">
        <button class="btn dash-config-all-btn">All settings</button>
        <button class="btn modal-cancel-btn">Close</button>
      </div>
    </div>`;
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.querySelector('.modal-close').addEventListener('click', close);
    overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
    overlay.querySelector('.dash-config-all-btn').addEventListener('click', () => {
      close();
      App.navigate('config', true);
    });
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

    // Dashboard action mode preference (localStorage, not server-side)
    const actionModeSel = overlay.querySelector('#dash-action-mode-select');
    if (actionModeSel) {
      actionModeSel.addEventListener('change', () => {
        savePreference('dash-action-mode', actionModeSel.value);
        App.showToast('Saved — re-rendering dashboard', 'success');
        close();
        this.render(document.getElementById('view-container'), App.state);
      });
    }

    // Save on change
    overlay.querySelectorAll('.dash-config-select').forEach(sel => {
      sel.addEventListener('change', async () => {
        try {
          await API.updateSettings({ [sel.dataset.key]: sel.value });
          // Live-apply metrics refresh timer
          if (sel.dataset.key === 'host_metrics_refresh') {
            const secs = parseInt(sel.value, 10);
            if (secs > 0) {
              App.startMetricsRefresh(secs * 1000);
            } else {
              App.stopMetricsRefresh();
            }
          }
          App.showToast('Saved', 'success');
        } catch (err) {
          App.showToast('Error: ' + err.message, 'error');
        }
      });
    });
  },

  async _syncRemote(container, state) {
    const host = await promptModal('Enter user@host:', '');
    if (!host) return;
    const ok = await confirmModal(`Sync all projects from ${host}? This will scan and register remote projects.`);
    if (!ok) return;
    try {
      App.showToast(`Syncing from ${host}...`);
      var res = await API.remoteSync(host);
      App.showToast(`Synced from ${host}, ${res.added} project${res.added===1?'':'s'} added`, 'success');
      this.render(container, state);
    } catch (err) {
      App.showToast('Sync error: ' + err.message, 'error');
    }
  },

  /** Get action items in the currently expanded submenu (if any). */
  _getExpandedActions() {
    const actionRow = document.querySelector('.dash-action-row');
    return actionRow ? Array.from(actionRow.querySelectorAll('.dash-action-item')) : [];
  },

  _highlightAction(items, idx) {
    items.forEach((el, i) => {
      if (i === idx) {
        el.classList.add('keyboard-active');
        el.scrollIntoView({ block: 'nearest' });
      } else {
        el.classList.remove('keyboard-active');
      }
    });
  },

  handleKeyboard(e) {
    // When search input is focused, only handle Escape
    const searchInput = document.getElementById('dash-search');
    if (document.activeElement === searchInput) {
      return; // let the input's own keydown handler manage Escape
    }

    if (!this._rows.length) return;

    // --- Submenu navigation mode (when a row is expanded) ---
    const actionItems = this._getExpandedActions();
    if (actionItems.length > 0) {
      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        this._activeAction = Math.min(this._activeAction + 1, actionItems.length - 1);
        this._highlightAction(actionItems, this._activeAction);
        return;
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        this._activeAction = Math.max(this._activeAction - 1, 0);
        this._highlightAction(actionItems, this._activeAction);
        return;
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (this._activeAction >= 0 && actionItems[this._activeAction]) {
          actionItems[this._activeAction].click();
        }
        return;
      } else if (e.key === 'ArrowLeft' || e.key === 'Escape') {
        e.preventDefault();
        // Collapse submenu, stay on same project row
        document.querySelectorAll('.dash-action-row').forEach(r => r.remove());
        document.querySelectorAll('tr[data-expanded="1"]').forEach(r => {
          const ch = r.querySelector('.dash-row-toggle');
          if (ch) ch.textContent = '\u25b8';
          r.dataset.expanded = '';
        });
        this._activeAction = -1;
        return;
      }
      // Other keys fall through to project-level shortcuts below
    }

    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      this._moveActive(1);
    } else if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      this._moveActive(-1);
    } else if (e.key === 'Enter' || e.key === 'ArrowRight') {
      e.preventDefault();
      if (this._activeRow >= 0) {
        this._toggleActions(this._rows[this._activeRow]);
      }
    } else if (e.key === 'ArrowLeft' || e.key === 'Escape') {
      // Clear search if active
      if (searchInput && searchInput.value) {
        searchInput.value = '';
        this._filterText = '';
        this._applyFilter();
      }
    } else if (e.key === 'Home') {
      e.preventDefault();
      // Find first visible row
      for (let i = 0; i < this._rows.length; i++) {
        if (this._rows[i].style.display !== 'none') { this._moveToIndex(i); break; }
      }
    } else if (e.key === 'End') {
      e.preventDefault();
      // Find last visible row
      for (let i = this._rows.length - 1; i >= 0; i--) {
        if (this._rows[i].style.display !== 'none') { this._moveToIndex(i); break; }
      }
    } else if (e.key === 'x') {
      e.preventDefault();
      const xPath = this._activeRow >= 0
        ? this._rows[this._activeRow].dataset.path
        : App.state.currentProject;
      if (!xPath) { App.showMessage('No active project', 'warn'); return; }
      this._navigateToView(xPath, 'explore');
    } else if (e.key === 'u') {
      e.preventDefault();
      const uPath = this._activeRow >= 0
        ? this._rows[this._activeRow].dataset.path
        : App.state.currentProject;
      if (!uPath) { App.showMessage('No active project', 'warn'); return; }
      this._navigateToView(uPath, 'update');
    } else if (e.key === 'R') {
      e.preventDefault();
      if (this._activeRow < 0) { App.showMessage('Select a project first', 'warn'); return; }
      this._refreshRow(this._rows[this._activeRow].dataset.path, this._rows[this._activeRow]);
    } else if (e.key === 'n') {
      e.preventDefault();
      if (this._activeRow < 0) { App.showMessage('Select a project first', 'warn'); return; }
      this._renameProject(this._rows[this._activeRow].dataset.path, this._rows[this._activeRow]);
    } else if (e.key === 'c') {
      e.preventDefault();
      const cPath = this._activeRow >= 0
        ? this._rows[this._activeRow].dataset.path
        : App.state.currentProject;
      if (!cPath) { App.showMessage('No active project', 'warn'); return; }
      this._navigateToView(cPath, 'config');
    } else if (e.key === 'S') {
      e.preventDefault();
      const sPath = this._activeRow >= 0
        ? this._rows[this._activeRow].dataset.path
        : App.state.currentProject;
      if (!sPath) { App.showMessage('No active project', 'warn'); return; }
      this._openShell(sPath);
    } else if (e.key === ' ') {
      e.preventDefault();
      if (this._activeRow < 0) { App.showMessage('Select a project first', 'warn'); return; }
      this._activateProject(this._rows[this._activeRow].dataset.path, this._rows[this._activeRow]);
    } else if (e.key === '/' && !e.shiftKey) {
      e.preventDefault();
      if (searchInput) searchInput.focus();
    } else if (e.key === 'M') {
      e.preventDefault();
      if (window.MessagesPanel) MessagesPanel.toggle();
    } else if (e.key === 'm' || e.key === '?') {
      e.preventDefault();
      this._openCommandMenu();
    }
  },

  _moveToIndex(idx) {
    if (idx < 0 || idx >= this._rows.length) return;
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    this._activeRow = idx;
    const row = this._rows[idx];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },

  _moveActive(delta) {
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    let next = this._activeRow + delta;
    // Skip hidden rows
    for (let attempts = 0; attempts < this._rows.length; attempts++) {
      if (next < 0) next = this._rows.length - 1;
      if (next >= this._rows.length) next = 0;
      if (this._rows[next].style.display !== 'none') break;
      next += delta > 0 ? 1 : -1;
    }
    this._activeRow = next;
    const row = this._rows[this._activeRow];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },

  async _showHostAddressesDialog(host) {
    // Fetch current addresses
    let addresses = [];
    try {
      const resp = await fetch(`/api/hosts/${encodeURIComponent(host)}/addresses`);
      if (resp.ok) {
        const data = await resp.json();
        addresses = data.addresses || [];
      }
    } catch (e) { /* ignore */ }

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    const dialog = document.createElement('div');
    dialog.className = 'modal';
    dialog.style.minWidth = '400px';

    const render = () => {
      let rows = '';
      if (!addresses.length) {
        rows = '<p style="color:var(--text-muted)">No alternate addresses configured.<br>Primary host will be used with port 22.</p>';
      } else {
        addresses.forEach((a, i) => {
          const label = i === 0 ? ' <span style="color:var(--text-muted)">(primary)</span>' : '';
          const upBtn = i > 0 ? `<button class="btn-sm addr-move" data-idx="${i}" data-dir="up" title="Move up">\u25b2</button>` : '<span style="width:28px"></span>';
          const downBtn = i < addresses.length - 1 ? `<button class="btn-sm addr-move" data-idx="${i}" data-dir="down" title="Move down">\u25bc</button>` : '<span style="width:28px"></span>';
          rows += `<div style="display:flex;align-items:center;gap:4px;margin:4px 0">
            <span style="width:16px;text-align:center;color:var(--text-muted);font-size:var(--font-size-sm)">${i + 1}</span>
            ${upBtn}${downBtn}
            <span style="flex:1">${esc(a.address)}:${a.port || 22}${label}</span>
            <button class="btn-sm addr-remove" data-idx="${i}" title="Remove">\u2715</button>
          </div>`;
        });
      }
      dialog.innerHTML = `
        <div class="modal-header"><span>SSH Addresses: ${esc(host)}</span><button class="modal-close addr-close">\u00d7</button></div>
        <div class="modal-body">
          <div class="addr-list">${rows}</div>
          <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
            <input type="text" class="addr-input" placeholder="address[:port]" style="flex:1;padding:4px 8px">
            <button class="btn-sm addr-add">Add</button>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-sm addr-close">Close</button>
        </div>`;

      dialog.querySelectorAll('.addr-remove').forEach(btn => {
        btn.addEventListener('click', async () => {
          const idx = parseInt(btn.dataset.idx);
          addresses.splice(idx, 1);
          await saveAddresses();
          render();
        });
      });

      dialog.querySelectorAll('.addr-move').forEach(btn => {
        btn.addEventListener('click', async () => {
          const idx = parseInt(btn.dataset.idx);
          const dir = btn.dataset.dir;
          const swap = dir === 'up' ? idx - 1 : idx + 1;
          if (swap < 0 || swap >= addresses.length) return;
          [addresses[idx], addresses[swap]] = [addresses[swap], addresses[idx]];
          await saveAddresses();
          render();
        });
      });

      const input = dialog.querySelector('.addr-input');
      dialog.querySelector('.addr-add').addEventListener('click', async () => {
        const val = input.value.trim();
        if (!val) return;
        let addr = val, port = 22;
        const m = val.match(/^(.+):(\d+)$/);
        if (m) { addr = m[1]; port = parseInt(m[2]); }
        // Auto-add primary if first entry
        if (!addresses.length) {
          addresses.push({ address: host, port: 22 });
        }
        addresses.push({ address: addr, port });
        await saveAddresses();
        input.value = '';
        render();
      });

      dialog.querySelectorAll('.addr-close').forEach(btn => {
        btn.addEventListener('click', () => overlay.remove());
      });
    };

    const saveAddresses = async () => {
      try {
        await fetch(`/api/hosts/${encodeURIComponent(host)}/addresses`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ addresses }),
        });
      } catch (e) {
        App.showToast('Failed to save addresses', 'error');
      }
    };

    overlay.appendChild(dialog);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });
    document.body.appendChild(overlay);
    render();
  },

  /** Fetch host metrics and populate inline summary rows on remote groups.
   *  If prefetchedData is provided, use it directly instead of calling the API.
   */
  async _fetchHostMetrics(prefetchedData, gen) {
    try {
      const data = prefetchedData || await API.getHostMetrics();
      if (gen && gen !== this._renderGen) return;  // skip metrics for superseded render
      (data.hosts || []).forEach(h => {
        const m = h.metrics || {};
        // Find matching metrics row(s) by host
        document.querySelectorAll(`.dash-metrics-row[data-host="${CSS.escape(h.host)}"]`).forEach(row => {
          const cell = row.querySelector('.dash-metrics-cell');
          if (!cell) return;
          if (m.error) {
            cell.innerHTML = `<span style="color:var(--text-muted);font-style:italic">\u21b3 unreachable</span>`;
            return;
          }
          const parts = [];
          const os = m.os || '';
          const kernel = m.kernel || '';
          if (os) parts.push(esc(os));
          if (kernel) parts.push(esc(kernel));
          const load1 = (m.load_1 || 0).toFixed(2);
          parts.push('load ' + load1);
          const memPct = m.mem_pct || 0;
          const memColor = memPct > 80 ? 'var(--red)' : memPct > 60 ? 'var(--yellow)' : 'var(--green)';
          parts.push(`mem <span style="color:${memColor}">${memPct}%</span>`);
          const disks = m.disks || [];
          if (disks.length) {
            const maxDisk = disks.reduce((a, d) => Math.max(a, parseInt(d.pct) || 0), 0);
            const diskColor = maxDisk > 80 ? 'var(--red)' : maxDisk > 60 ? 'var(--yellow)' : 'var(--green)';
            parts.push(`disk <span style="color:${diskColor}">${maxDisk}%</span>`);
          }
          cell.innerHTML = `<span style="color:var(--text-muted)">\u21b3 ${parts.join(' \u00b7 ')}</span>`;
        });
      });
    } catch (e) {
      // Silently ignore — metrics are supplementary
    }
  },

  // ---- Pane tabs ----

  async _loadPaneTabs() {
    try {
      const data = await API.getPanes();
      this._allPanes = data.panes || [];
      this._allKnownTags = data.all_tags || [];
      this._activePaneName = data.active || 'All';
      const activePane = this._allPanes.find(p => p.name === this._activePaneName);
      this._activePaneTags = activePane ? (activePane.tags || []) : [];
      this._renderPaneTabs();
    } catch (e) {
      // Fallback to defaults
      this._allPanes = [
        {name: 'All', tags: [], builtin: true},
        {name: 'Yocto', tags: ['yocto'], builtin: true},
        {name: 'Generic', tags: ['generic'], builtin: true},
      ];
      this._renderPaneTabs();
    }
  },

  _renderPaneTabs() {
    const container = document.getElementById('dash-pane-tabs');
    if (!container) return;
    let html = '';
    for (const pane of this._allPanes) {
      const active = pane.name === this._activePaneName ? ' active' : '';
      const tagHint = pane.tags.length ? pane.tags.join(', ') : 'All projects';
      html += `<button class="tab dash-pane-tab${active}" data-pane="${esc(pane.name)}" title="${esc(tagHint)}">${esc(pane.name)}</button>`;
    }
    html += `<button class="tab dash-pane-add" title="New pane" style="color:var(--text-muted);font-size:var(--font-size-sm)">+</button>`;
    container.innerHTML = html;

    // Wire click handlers
    container.querySelectorAll('.dash-pane-tab').forEach(btn => {
      btn.addEventListener('click', () => this._switchPane(btn.dataset.pane));
      btn.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._paneContextMenu(e, btn.dataset.pane);
      });
    });
    container.querySelector('.dash-pane-add').addEventListener('click', () => this._createPaneDialog());

    // Also render quick-filter buttons in the search bar
    const quickContainer = document.getElementById('dash-pane-quick');
    if (quickContainer) {
      let qhtml = '';
      for (const pane of this._allPanes) {
        const active = pane.name === this._activePaneName ? ' active' : '';
        qhtml += `<button class="btn btn-xs dash-pane-quick-btn${active}" data-pane="${esc(pane.name)}" title="${esc(pane.tags.join(', ') || 'All projects')}">${esc(pane.name)}</button>`;
      }
      quickContainer.innerHTML = qhtml;
      quickContainer.querySelectorAll('.dash-pane-quick-btn').forEach(btn => {
        btn.addEventListener('click', () => this._switchPane(btn.dataset.pane));
      });
    }
  },

  async _switchPane(name) {
    const pane = this._allPanes.find(p => p.name === name);
    if (!pane) return;
    this._activePaneName = name;
    this._activePaneTags = pane.tags || [];
    // Update tab and quick-filter active states
    document.querySelectorAll('.tab.dash-pane-tab').forEach(b => {
      b.classList.toggle('active', b.dataset.pane === name);
    });
    document.querySelectorAll('.dash-pane-quick-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.pane === name);
    });
    this._applyFilter();
    // Persist on server (fire and forget)
    API.activatePane(name).catch(() => {});
  },

  async _paneContextMenu(e, paneName) {
    const pane = this._allPanes.find(p => p.name === paneName);
    if (!pane) return;
    const items = [
      { label: 'Edit tags', icon: '\u270e', action: 'edit' },
    ];
    if (!pane.builtin) {
      items.push({ sep: true });
      items.push({ label: 'Delete pane', icon: '\u2717', action: 'delete', danger: true });
    }
    const action = await contextMenu(e.clientX, e.clientY, items);
    if (action === 'edit') {
      this._showTagPickerModal('Pane tags: ' + paneName, pane.tags || [], this._allKnownTags || [], async (newTags, _hidden, changed) => {
        if (changed) {
          try {
            const resp = await API.createPane(paneName, newTags);
            this._allPanes = resp.panes || this._allPanes;
            this._renderPaneTabs();
            if (paneName === this._activePaneName) {
              this._activePaneTags = newTags;
              this._applyFilter();
            }
          } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
        }
      });
    } else if (action === 'delete') {
      const ok = await confirmModal(`Delete pane "${paneName}"?`);
      if (!ok) return;
      try {
        const resp = await API.deletePane(paneName);
        this._allPanes = resp.panes || this._allPanes;
        if (this._activePaneName === paneName) {
          this._switchPane('All');
        }
        this._renderPaneTabs();
      } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
    }
  },

  async _createPaneDialog() {
    const name = await promptModal('New pane name:', '');
    if (!name) return;
    this._showTagPickerModal('Tags for pane: ' + name, [], this._allKnownTags || [], async (tags) => {
      try {
        const resp = await API.createPane(name, tags);
        this._allPanes = resp.panes || this._allPanes;
        this._renderPaneTabs();
        this._switchPane(name);
      } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
    });
  },

  // ---- Tag picker modal (shared by project tags and pane tags) ----

  _showTagPickerModal(title, currentTags, allKnownTags, onDone, remoteTags, currentHidden) {
    // Unified tag editor: local tags (add/remove) + remote tags (hide/unhide)
    // When remoteTags is provided, onDone receives (tags, hidden, tagsChanged, hiddenChanged)
    // When remoteTags is not provided, onDone receives (tags, [], tagsChanged, false) for backward compat
    const tags = [...currentTags];
    const hidden = currentHidden ? [...currentHidden] : [];
    const remote = remoteTags || [];
    const originalTagsSorted = JSON.stringify([...currentTags].sort());
    const originalHiddenSorted = JSON.stringify([...(currentHidden || [])].sort());

    function renderTagEditor() {
      let html = '<div style="margin-bottom:12px">';

      // Remote tags section (if any)
      if (remote.length) {
        html += '<div style="margin-bottom:8px;color:var(--text-muted);font-size:var(--font-size-sm)">Remote tags <span style="font-size:var(--font-size-xs)">(from host \u2014 click to hide/unhide)</span>:</div>';
        html += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">';
        for (const t of remote) {
          const isHidden = hidden.includes(t);
          html += `<span class="badge" style="cursor:pointer;padding:4px 8px;${isHidden ? 'opacity:0.35;text-decoration:line-through;' : ''}color:var(--text-muted)" data-tag="${esc(t)}" data-action="${isHidden ? 'unhide' : 'hide'}" title="${isHidden ? 'Click to unhide' : 'Click to hide'}">${esc(t)}</span>`;
        }
        html += '</div>';
      }

      // Local tags
      html += '<div style="margin-bottom:8px;color:var(--text-muted);font-size:var(--font-size-sm)">' + (remote.length ? 'Local tags:' : 'Current tags:') + '</div>';
      if (tags.length) {
        html += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">';
        for (const t of tags) {
          html += `<span class="badge" style="cursor:pointer;padding:4px 8px;color:var(--accent)" data-tag="${esc(t)}" data-action="remove" title="Click to remove">${esc(t)} \u00d7</span>`;
        }
        html += '</div>';
      } else {
        html += '<div style="color:var(--text-muted);margin-bottom:12px">(none)</div>';
      }

      // Available tags to add (exclude already-used local + remote tags)
      const allUsed = new Set([...tags, ...remote]);
      const available = allKnownTags.filter(t => !allUsed.has(t));
      if (available.length) {
        html += '<div style="margin-bottom:8px;color:var(--text-muted);font-size:var(--font-size-sm)">Add existing tag:</div>';
        html += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">';
        for (const t of available) {
          html += `<span class="badge" style="cursor:pointer;padding:4px 8px;opacity:0.6" data-tag="${esc(t)}" data-action="add" title="Click to add">+ ${esc(t)}</span>`;
        }
        html += '</div>';
      }
      html += '<div style="display:flex;gap:8px;align-items:center">';
      html += '<input type="text" id="tag-new-input" class="form-input" placeholder="New tag..." style="flex:1">';
      html += '<button class="btn btn-xs" id="tag-add-btn">Add</button>';
      html += '</div>';
      html += '</div>';
      return html;
    }

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    function show() {
      const dialog = document.createElement('div');
      dialog.className = 'modal';
      dialog.innerHTML = `
        <div class="modal-header"><span>${esc(title)}</span><button class="modal-close btn-icon">&times;</button></div>
        <div class="modal-body">${renderTagEditor()}</div>
        <div class="modal-footer"><button class="btn btn-primary" id="tag-done-btn">Done</button></div>
      `;
      overlay.innerHTML = '';
      overlay.appendChild(dialog);
      if (!overlay.parentNode) document.body.appendChild(overlay);

      const finish = () => {
        overlay.remove();
        const tagsChanged = JSON.stringify([...tags].sort()) !== originalTagsSorted;
        const hiddenChanged = JSON.stringify([...hidden].sort()) !== originalHiddenSorted;
        onDone(tags, hidden, tagsChanged, hiddenChanged);
      };
      dialog.querySelector('.modal-close').addEventListener('click', finish);
      dialog.querySelector('#tag-done-btn').addEventListener('click', finish);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) finish(); });

      // Remove local tag
      dialog.querySelectorAll('[data-action="remove"]').forEach(el => {
        el.addEventListener('click', () => {
          const idx = tags.indexOf(el.dataset.tag);
          if (idx >= 0) tags.splice(idx, 1);
          show();
        });
      });
      // Add local tag
      dialog.querySelectorAll('[data-action="add"]').forEach(el => {
        el.addEventListener('click', () => {
          if (!tags.includes(el.dataset.tag)) tags.push(el.dataset.tag);
          show();
        });
      });
      // Hide remote tag
      dialog.querySelectorAll('[data-action="hide"]').forEach(el => {
        el.addEventListener('click', () => {
          if (!hidden.includes(el.dataset.tag)) hidden.push(el.dataset.tag);
          show();
        });
      });
      // Unhide remote tag
      dialog.querySelectorAll('[data-action="unhide"]').forEach(el => {
        el.addEventListener('click', () => {
          const idx = hidden.indexOf(el.dataset.tag);
          if (idx >= 0) hidden.splice(idx, 1);
          show();
        });
      });

      const addBtn = dialog.querySelector('#tag-add-btn');
      const addInput = dialog.querySelector('#tag-new-input');
      const doAdd = () => {
        const v = addInput.value.trim();
        if (v && !tags.includes(v)) {
          tags.push(v);
          if (!allKnownTags.includes(v)) allKnownTags.push(v);
          show();
        }
      };
      addBtn.addEventListener('click', doAdd);
      addInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doAdd(); } });
      addInput.focus();
    }

    show();
  },

  // ---- Project properties modal (name, description, tags) ----

  async _editProjectProperties(path, row) {
    const persona = row.dataset.persona || 'yocto';
    const isRemote = row.dataset.remote === 'true';
    let proj, allKnownTags;
    try {
      const paneData = await API.getPanes();
      allKnownTags = (paneData.all_tags || []).filter(t => t !== persona);
      const projects = await API.getProjects();
      proj = projects.find(p => p.path === path) || {};
    } catch (e) {
      proj = {};
      allKnownTags = [];
    }

    const curName = proj.name || path.split('/').pop();
    const curDesc = proj.description || '';
    const curTags = proj.tags || [];
    const remoteTags = proj.remote_tags || [];
    const hiddenTags = proj.hidden_tags || [];
    const self = this;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    const dialog = document.createElement('div');
    dialog.className = 'modal';

    const allTagDisplay = () => {
      const parts = [];
      // Remote tags (visible ones)
      for (const t of remoteTags) {
        if (!hiddenTags.includes(t)) {
          parts.push(`<span class="badge" style="padding:2px 6px;color:var(--text-muted)" title="Remote tag">${esc(t)}</span>`);
        }
      }
      // Hidden remote tags (dimmed/strikethrough)
      for (const t of remoteTags) {
        if (hiddenTags.includes(t)) {
          parts.push(`<span class="badge" style="padding:2px 6px;color:var(--text-muted);opacity:0.35;text-decoration:line-through" title="Hidden remote tag">${esc(t)}</span>`);
        }
      }
      // Local tags
      for (const t of curTags) {
        parts.push(`<span class="badge" style="padding:2px 6px;color:var(--accent)" title="Local tag">${esc(t)}</span>`);
      }
      return parts.length ? parts.join(' ') : '<span style="color:var(--text-muted)">(none)</span>';
    };

    function render() {
      dialog.innerHTML = `
        <div class="modal-header"><span>Properties: ${esc(curName)}</span><button class="modal-close btn-icon">&times;</button></div>
        <div class="modal-body">
          <div style="margin-bottom:12px">
            <label style="color:var(--text-muted);font-size:var(--font-size-sm);display:block;margin-bottom:4px">Name</label>
            <div style="display:flex;gap:8px;align-items:center">
              <span id="prop-name-display">${esc(curName)}</span>
              <button class="btn btn-xs" id="prop-name-edit">\u270e</button>
            </div>
          </div>
          <div style="margin-bottom:12px">
            <label style="color:var(--text-muted);font-size:var(--font-size-sm);display:block;margin-bottom:4px">Description</label>
            <div style="display:flex;gap:8px;align-items:center">
              <span id="prop-desc-display" style="font-style:italic;color:var(--text-muted)">${curDesc ? esc(curDesc) : '(none)'}</span>
              <button class="btn btn-xs" id="prop-desc-edit">\u270e</button>
            </div>
          </div>
          <div style="margin-bottom:12px">
            <label style="color:var(--text-muted);font-size:var(--font-size-sm);display:block;margin-bottom:4px">Tags</label>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
              <span id="prop-tags-display">${allTagDisplay()}</span>
              <button class="btn btn-xs" id="prop-tags-edit">\u270e</button>
            </div>
          </div>
          ${curTags.includes('auto-update') ? `
          <div style="margin-bottom:12px">
            <label style="color:var(--text-muted);font-size:var(--font-size-sm);display:block;margin-bottom:4px">Auto-Update Settings</label>
            <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
              <span style="color:var(--text-muted)">Interval:</span>
              <select id="prop-interval" class="input" style="width:auto;padding:2px 6px">
                ${[15,30,60,120,240,480].map(m => `<option value="${m}"${m === (proj.auto_update?.interval_minutes || 60) ? ' selected' : ''}>${m < 60 ? m + 'm' : (m/60) + 'h'}</option>`).join('')}
              </select>
              <label style="color:var(--text-muted);display:flex;align-items:center;gap:4px;cursor:pointer">
                <input type="checkbox" id="prop-fetch-only" ${proj.auto_update?.fetch_only ? 'checked' : ''}>
                Fetch only
              </label>
            </div>
          </div>
          ` : ''}
        </div>
        <div class="modal-footer"><button class="btn btn-primary" id="prop-done-btn">Done</button></div>
      `;
    }

    render();
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    const wireHandlers = () => {
      dialog.querySelector('.modal-close').addEventListener('click', close);
      dialog.querySelector('#prop-done-btn').addEventListener('click', close);

      // Name edit
      dialog.querySelector('#prop-name-edit').addEventListener('click', async () => {
        const newName = await promptModal('Project name:', curName);
        if (newName && newName !== curName) {
          try {
            await API.renameProject(path, newName);
            row.dataset.name = newName;
            const nameEl = row.querySelector('.dash-name-link');
            if (nameEl) nameEl.textContent = newName;
            App.showToast('Name updated', 'success');
          } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
        }
      });

      // Description edit
      dialog.querySelector('#prop-desc-edit').addEventListener('click', async () => {
        const newDesc = await promptModal('Description:', curDesc);
        if (newDesc !== null && newDesc !== curDesc) {
          try {
            await API.updateProjectDescription(path, newDesc);
            proj.description = newDesc;
            const descEl = dialog.querySelector('#prop-desc-display');
            if (descEl) descEl.textContent = newDesc || '(none)';
            App.showToast('Description updated', 'success');
          } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
        }
      });

      // Unified tag edit
      dialog.querySelector('#prop-tags-edit').addEventListener('click', () => {
        self._showTagPickerModal('Tags: ' + curName, curTags, allKnownTags, async (newTags, newHidden, tagsChanged, hiddenChanged) => {
          if (tagsChanged) {
            try {
              curTags.length = 0;
              curTags.push(...newTags);
              await API.updateProjectTags(path, newTags);
            } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
          }
          if (hiddenChanged) {
            try {
              hiddenTags.length = 0;
              hiddenTags.push(...newHidden);
              await API.updateProjectHiddenTags(path, newHidden);
            } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
          }
          if (tagsChanged || hiddenChanged) {
            const disp = dialog.querySelector('#prop-tags-display');
            if (disp) disp.innerHTML = allTagDisplay();
            App.showToast('Tags updated', 'success');
          }
        }, remoteTags, hiddenTags);
      });

      // Auto-update settings
      const intervalSel = dialog.querySelector('#prop-interval');
      if (intervalSel) {
        intervalSel.addEventListener('change', async () => {
          try {
            await API._post('/api/daemon/project-config', { path, interval_minutes: parseInt(intervalSel.value) });
            proj.auto_update = proj.auto_update || {};
            proj.auto_update.interval_minutes = parseInt(intervalSel.value);
            App.showToast('Interval updated', 'success');
          } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
        });
      }
      const fetchOnlyCb = dialog.querySelector('#prop-fetch-only');
      if (fetchOnlyCb) {
        fetchOnlyCb.addEventListener('change', async () => {
          try {
            await API._post('/api/daemon/project-config', { path, fetch_only: fetchOnlyCb.checked });
            proj.auto_update = proj.auto_update || {};
            proj.auto_update.fetch_only = fetchOnlyCb.checked;
            App.showToast('Fetch-only updated', 'success');
          } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
        });
      }
    };
    wireHandlers();
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  },

  // ---- Standalone tag edit (kept for direct calls) ----

  async _editProjectTags(path, row) {
    const persona = row.dataset.persona || 'yocto';
    let projectTags, allKnownTags;
    try {
      const paneData = await API.getPanes();
      allKnownTags = (paneData.all_tags || []).filter(t => t !== persona);
      const projects = await API.getProjects();
      const proj = projects.find(p => p.path === path);
      projectTags = proj ? (proj.tags || []) : [];
    } catch (e) {
      projectTags = [];
      allKnownTags = [];
    }
    const name = row.dataset.name || path.split('/').pop();
    const self = this;
    this._showTagPickerModal('Tags: ' + name, projectTags, allKnownTags, async (newTags, _hidden, tagsChanged) => {
      if (tagsChanged) {
        try {
          await API.updateProjectTags(path, newTags);
          App.showToast('Tags updated', 'success');
          self.render(document.getElementById('view-container'), App.state);
        } catch (err) { App.showToast('Error: ' + err.message, 'error'); }
      }
    });
  },
};
