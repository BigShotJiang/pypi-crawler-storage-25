/* Config view — tree-structured settings matching TUI layout
 *
 * Sections: Repositories (expandable per-repo), Project, Branches,
 * Properties, Settings.  All sections are editable; changes save immediately.
 *
 * Reads App.state.selectedProject for project context (set by dashboard).
 * Passes ?project= to API so no project activation is needed.
 */
const ConfigView = {
  _config: null,
  _projectConf: null,  // lazy-loaded conf file data
  _expanded: {},  // section/repo expand state
  _confExpanded: {},  // which conf files are expanded
  _nav: KeyboardNav(),

  keyBindings: [
    {key: 'j/k', desc: 'Navigate'},
    {key: 'Enter', desc: 'Toggle expand', action: 'Enter'},
    {key: 'Space', desc: 'Toggle expand', action: ' '},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) {
      this._refreshNavRows();
      return;
    }
    var row = this._nav.activeRow();
    if ((e.key === 'Enter' || e.key === ' ') && row) {
      e.preventDefault();
      row.click();
    }
  },

  _refreshNavRows() {
    var el = document.getElementById('config-content');
    if (!el) return;
    this._nav.setRows(el.querySelectorAll('.config-section-header, .config-tree-row'));
  },

  _project() { return App.state.selectedProject || ''; },

  async render(container, state) {
    const projName = (App.state.selectedProjectName || App.state.selectedProject || App.state.currentProject || '').split('/').pop();
    const titlePrefix = projName ? projName + ': ' : '';
    container.innerHTML = `
      <div class="view-header">
        <h2>${esc(titlePrefix)}Settings</h2>
      </div>
      <div id="config-content" class="loading">Loading config</div>
    `;

    try {
      this._config = await API.getConfig(this._project());
      // Fetch tmux session for the current project's host (localhost for local)
      this._hostTmux = null;
      const host = App.state.selectedProjectHost || 'localhost';
      try {
        const resp = await API.getHostTmuxSession(host);
        this._hostTmux = { host, tmux_session: resp.tmux_session || '' };
      } catch (_) {}
      this._renderTree();
    } catch (e) {
      document.getElementById('config-content').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderTree() {
    const el = document.getElementById('config-content');
    if (!el) return;
    el.className = '';
    const c = this._config;

    let html = '';

    // --- Repositories section ---
    const reposExpanded = this._expanded['repos'] !== false;
    html += this._sectionHeader('repos', reposExpanded,
      `Repositories`, `${c.repos.length} repositories`);
    if (reposExpanded) {
      html += '<div class="config-children">';
      c.repos.forEach((repo, i) => {
        const repoKey = 'repo:' + repo.path;
        const expanded = this._expanded[repoKey];
        html += `<div class="config-tree-row${expanded ? ' config-tree-row-open' : ''}" data-repo="${esc(repo.path)}">
          <span class="config-repo-name">${esc(repo.display_name)}</span>
          <span class="config-repo-action badge badge-${repo.default_action === 'skip' ? 'skip' : repo.default_action === 'merge' ? 'behind' : 'clean'}">${esc(repo.default_action)}</span>
          <span class="config-repo-path">${esc(repo.path)}</span>
        </div>`;
        if (expanded) {
          html += this._renderRepoPanel(repo);
        }
      });
      html += '</div>';
    }

    // --- Project section (conf file browser) ---
    const projExpanded = this._expanded['project'];
    html += this._sectionHeader('project', projExpanded,
      'project', esc(c.project.path));
    if (projExpanded) {
      html += this._renderProjectPanel();
    }

    // --- Branches section ---
    const brExpanded = this._expanded['branches'];
    const bpCount = c.branches.priorities.length + c.branches.excludes.length;
    html += this._sectionHeader('branches', brExpanded,
      'branches', `${bpCount} patterns, stale ${c.branches.stale_days}d`);
    if (brExpanded) {
      html += this._renderBranchesPanel();
    }

    // --- Properties section ---
    const propsExpanded = this._expanded['properties'];
    html += this._sectionHeader('properties', propsExpanded,
      'properties', esc(c.project.name));
    if (propsExpanded) {
      html += this._renderPropertiesPanel();
    }

    // --- Settings section ---
    const setExpanded = this._expanded['settings'];
    html += this._sectionHeader('settings', setExpanded,
      'bit', 'configure options');
    if (setExpanded) {
      html += this._renderSettingsPanel();
    }

    // --- AI section ---
    const aiExpanded = this._expanded['ai'];
    html += this._sectionHeader('ai', aiExpanded,
      'AI', 'summarization settings');
    if (aiExpanded) {
      html += this._renderAIPanel();
    }

    // --- Pending Changes section ---
    const pendingExpanded = this._expanded['pending'];
    html += this._sectionHeader('pending', pendingExpanded,
      'Pending Changes', 'provider mapping per repo');
    if (pendingExpanded) {
      html += '<div class="config-inline-panel" id="pending-config-panel"><div style="color:var(--text-muted);padding:8px">Loading...</div></div>';
    }

    el.innerHTML = html;
    this._bindEvents(el);

    // Load pending config asynchronously
    if (pendingExpanded) {
      this._loadPendingConfig();
    }
    this._nav.setRows(el.querySelectorAll('.config-section-header, .config-tree-row'));
  },

  _sectionHeader(section, expanded, title, subtitle, isStatic) {
    const toggle = expanded ? '\u25bc' : '\u25b6';
    const cls = isStatic ? 'config-section-header config-section-static'
                         : 'config-section-header';
    const attr = section ? ` data-section="${section}"` : '';
    return `<div class="${cls}"${attr}>
      ${!isStatic ? `<span class="config-toggle">${toggle}</span>` : ''}
      <span class="config-section-title">${title}</span>
      <span class="config-section-subtitle">${subtitle}</span>
    </div>`;
  },

  _bindEvents(el) {
    // Section headers toggle
    el.querySelectorAll('.config-section-header[data-section]').forEach(hdr => {
      hdr.addEventListener('click', () => {
        const section = hdr.dataset.section;
        this._expanded[section] = !this._expanded[section];
        this._renderTree();
      });
    });

    // Repo row click -> toggle inline panel
    el.querySelectorAll('.config-tree-row[data-repo]').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('.config-inline-panel')) return;
        const key = 'repo:' + row.dataset.repo;
        this._expanded[key] = !this._expanded[key];
        this._renderTree();
      });
    });

    // Conf file edit button
    el.querySelectorAll('.config-conf-edit[data-path]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        fileEditor(btn.dataset.path);
      });
    });

    // Conf file row click -> toggle variable list
    el.querySelectorAll('.config-conf-file[data-conf]').forEach(row => {
      row.addEventListener('click', () => {
        const key = 'conf:' + row.dataset.conf;
        this._confExpanded[key] = !this._confExpanded[key];
        this._renderTree();
      });
    });

    // Repo panel inputs
    el.querySelectorAll('.config-repo-action-radio').forEach(radio => {
      radio.addEventListener('change', () => {
        this._saveRepoSetting(radio.dataset.repo, { default_action: radio.value });
      });
    });

    this._bindDebounced(el, '.config-repo-display-input', (input) => {
      this._saveRepoSetting(input.dataset.repo, { display_name: input.value });
    });

    this._bindDebounced(el, '.config-repo-push-input', (input) => {
      const val = input.value.trim();
      this._saveRepoSetting(input.dataset.repo, { push_target: val ? { push_url: val } : null });
    });

    // Branch filter buttons
    el.querySelectorAll('.config-branch-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const list = btn.dataset.list;
        const idx = parseInt(btn.dataset.idx, 10);
        const arr = [...this._config.branches[list]];
        arr.splice(idx, 1);
        this._saveBranches({ [list]: arr });
      });
    });

    el.querySelectorAll('.config-branch-add-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const list = btn.dataset.list;
        const input = el.querySelector(`.config-branch-add-input[data-list="${list}"]`);
        if (!input) return;
        const val = input.value.trim();
        if (!val) return;
        const arr = [...this._config.branches[list], val];
        this._saveBranches({ [list]: arr });
      });
    });

    // Branch add on Enter
    el.querySelectorAll('.config-branch-add-input').forEach(input => {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const btn = el.querySelector(`.config-branch-add-btn[data-list="${input.dataset.list}"]`);
          if (btn) btn.click();
        }
      });
    });

    this._bindDebounced(el, '.config-stale-input', (input) => {
      const val = parseInt(input.value, 10);
      if (!isNaN(val) && val >= 0) {
        this._saveBranches({ stale_days: val });
      }
    });

    // Properties inputs
    this._bindDebounced(el, '.config-prop-name', (input) => {
      this._saveProperties({ name: input.value });
    });
    this._bindDebounced(el, '.config-prop-desc', (input) => {
      this._saveProperties({ description: input.value });
    });

    // Settings dropdowns
    el.querySelectorAll('.config-setting-select').forEach(sel => {
      sel.addEventListener('change', () => {
        this._saveSetting(sel.dataset.key, sel.value);
      });
    });

    // Per-host tmux session select
    el.querySelectorAll('.config-tmux-session-select').forEach(sel => {
      sel.addEventListener('change', async () => {
        const host = sel.dataset.host;
        const val = sel.value === '__custom__' ? '' : sel.value;
        if (sel.value === '__custom__') {
          // Re-render to show the text input
          if (this._hostTmux) this._hostTmux.tmux_session = '';
          this._renderTree();
          const input = document.querySelector('.config-tmux-session-input');
          if (input) input.focus();
          return;
        }
        try {
          await API.setHostTmuxSession(host, val);
          if (this._hostTmux) this._hostTmux.tmux_session = val;
          this._renderTree();
          App.showToast('Saved', 'success');
        } catch (e) {
          App.showToast('Error: ' + e.message, 'error');
        }
      });
    });
    // Per-host tmux session custom name input (debounced)
    this._bindDebounced(el, '.config-tmux-session-input', async (input) => {
      const host = input.dataset.host;
      const val = input.value.trim();
      if (!val) return;
      try {
        await API.setHostTmuxSession(host, val);
        if (this._hostTmux) this._hostTmux.tmux_session = val;
        App.showToast('Saved', 'success');
      } catch (e) {
        App.showToast('Error: ' + e.message, 'error');
      }
    });

    // AI settings — selects
    el.querySelectorAll('.config-ai-select').forEach(sel => {
      sel.addEventListener('change', async () => {
        let value = sel.value;
        const key = sel.dataset.key;
        // Convert boolean strings
        if (value === 'true') value = true;
        else if (value === 'false') value = false;
        try {
          await API.updateAISettings({ [key]: value });
          this._config.settings[key] = value;
          // Re-render if provider changed (shows/hides conditional fields)
          if (key === 'ai_provider') this._renderTree();
          App.showToast('Saved', 'success');
        } catch (e) {
          App.showToast('Error: ' + e.message, 'error');
        }
      });
    });

    // AI settings — text inputs (debounced)
    this._bindDebounced(el, '.config-ai-input', async (input) => {
      const key = input.dataset.key;
      const val = input.value;
      try {
        await API.updateAISettings({ [key]: val });
        this._config.settings[key] = val;
        App.showToast('Saved', 'success');
      } catch (e) {
        App.showToast('Error: ' + e.message, 'error');
      }
    });

    // AI test button
    el.querySelectorAll('.config-ai-test').forEach(btn => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.textContent = 'Testing...';
        try {
          const status = await API.getAIStatus();
          if (status.configured) {
            App.showToast('AI configured: ' + status.provider + ' (' + status.model + ')', 'success');
          } else {
            App.showToast('AI not configured \u2014 check settings', 'error');
          }
        } catch (e) {
          App.showToast('Error: ' + e.message, 'error');
        }
        btn.disabled = false;
        btn.textContent = 'Test AI connection';
      });
    });
  },

  /** Attach debounced input handler to all matching elements. */
  _bindDebounced(el, selector, fn, delay) {
    delay = delay || 600;
    el.querySelectorAll(selector).forEach(input => {
      let timer;
      input.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(input), delay);
      });
    });
  },

  _renderRepoPanel(repo) {
    const pushUrl = (repo.push_target && repo.push_target.push_url) || '';
    const actions = ['rebase', 'merge', 'skip'];

    let html = `<div class="config-inline-panel">
      <div class="config-panel-row">
        <label>Display name</label>
        <input type="text" class="form-input config-repo-display-input" data-repo="${esc(repo.path)}"
               value="${esc(repo.display_name_custom ? repo.display_name : '')}"
               placeholder="${esc(repo.display_name)}">
      </div>
      <div class="config-panel-row">
        <label>Default action</label>
        <span class="config-radio-group">`;
    actions.forEach(a => {
      const checked = repo.default_action === a ? ' checked' : '';
      html += `<label class="config-radio">
        <input type="radio" name="action-${esc(repo.path)}" value="${a}"
               class="config-repo-action-radio" data-repo="${esc(repo.path)}"${checked}>
        ${a}
      </label>`;
    });
    html += `</span>
      </div>
      <div class="config-panel-row">
        <label>Push target</label>
        <input type="text" class="form-input config-repo-push-input" data-repo="${esc(repo.path)}"
               value="${esc(pushUrl)}" placeholder="none">
      </div>
    </div>`;
    return html;
  },

  _renderProjectPanel() {
    if (!this._projectConf) {
      // Lazy-load conf data on first expand
      this._loadProjectConf();
      return '<div class="config-inline-panel loading">Loading conf files</div>';
    }
    const pc = this._projectConf;
    if (!pc.files.length) {
      return '<div class="config-inline-panel"><span class="config-empty">No conf files found</span></div>';
    }

    let html = '<div class="config-inline-panel config-conf-panel">';
    pc.files.forEach(file => {
      const fkey = 'conf:' + file.path;
      const expanded = this._confExpanded[fkey];
      const varCount = file.variables.length;
      const marker = varCount ? (expanded ? '\u25bc' : '\u25b6') : '';
      html += `<div class="config-conf-file" data-conf="${esc(file.path)}">
        <span class="config-toggle">${marker}</span>
        <span class="config-conf-name">${esc(file.name)}</span>
        <span class="config-section-subtitle">${varCount} variables</span>
        <button class="btn-icon config-conf-edit" data-path="${esc(file.path)}" title="Edit file" style="margin-left:auto">\u270e</button>
      </div>`;
      if (expanded) {
        html += '<div class="config-conf-vars">';
        file.variables.forEach(v => {
          html += `<div class="config-conf-var">
            <span class="config-var-name">${esc(v.name)}</span>
            <span class="config-var-eq">=</span>
            <span class="config-var-value">${esc(v.value)}</span>
          </div>`;
        });
        html += '</div>';
      }
    });
    html += '</div>';
    return html;
  },

  async _loadProjectConf() {
    try {
      this._projectConf = await API.getProjectConf(this._project());
    } catch (e) {
      this._projectConf = { conf_dir: '', files: [] };
    }
    this._renderTree();
  },

  _renderBranchesPanel() {
    const b = this._config.branches;
    let html = '<div class="config-inline-panel">';

    // Priorities
    html += '<div class="config-panel-row config-panel-row-top"><label>Priority patterns</label>';
    html += '<div class="config-tag-list">';
    b.priorities.forEach((p, i) => {
      html += `<span class="config-tag config-tag-green">${esc(p)}
        <button class="config-tag-x config-branch-remove" data-list="priorities" data-idx="${i}">&times;</button>
      </span>`;
    });
    html += `<span class="config-tag-add">
      <input type="text" class="config-branch-add-input" data-list="priorities" placeholder="add pattern">
      <button class="config-branch-add-btn" data-list="priorities">+</button>
    </span></div></div>`;

    // Excludes
    html += '<div class="config-panel-row config-panel-row-top"><label>Exclude patterns</label>';
    html += '<div class="config-tag-list">';
    b.excludes.forEach((p, i) => {
      html += `<span class="config-tag config-tag-red">${esc(p)}
        <button class="config-tag-x config-branch-remove" data-list="excludes" data-idx="${i}">&times;</button>
      </span>`;
    });
    html += `<span class="config-tag-add">
      <input type="text" class="config-branch-add-input" data-list="excludes" placeholder="add pattern">
      <button class="config-branch-add-btn" data-list="excludes">+</button>
    </span></div></div>`;

    // Stale days
    html += `<div class="config-panel-row"><label>Stale days</label>
      <input type="number" class="form-input config-stale-input" value="${b.stale_days}" min="0" style="width:80px">
    </div>`;

    html += '</div>';
    return html;
  },

  _renderPropertiesPanel() {
    const p = this._config.project;
    return `<div class="config-inline-panel">
      <div class="config-panel-row"><label>Name</label>
        <input type="text" class="form-input config-prop-name" value="${esc(p.name)}"></div>
      <div class="config-panel-row"><label>Description</label>
        <input type="text" class="form-input config-prop-desc" value="${esc(p.description)}" placeholder="(none)"></div>
    </div>`;
  },

  _renderSettingsPanel() {
    const s = this._config.settings;

    const options = {
      directory_browser: [
        ['auto', 'Auto-detect'], ['broot', 'broot'], ['ranger', 'ranger'],
        ['nnn', 'nnn'], ['fzf', 'fzf built-in'],
      ],
      git_viewer: [
        ['auto', 'Auto-detect'], ['tig', 'tig'], ['lazygit', 'lazygit'],
        ['gitui', 'gitui'], ['gitk', 'gitk'],
      ],
      preview_layout: [
        ['down', 'Bottom'], ['right', 'Side-by-side'], ['up', 'Top'],
      ],
      editor: [
        ['auto', 'Auto ($EDITOR)'], ['vim', 'vim'], ['nvim', 'neovim'],
        ['nano', 'nano'], ['emacs', 'emacs'], ['code', 'VS Code'],
      ],
      recipe_scan: [
        ['bitbake-layers', 'bitbake-layers'], ['file', 'File scan'],
      ],
      backup_prune_age: [
        ['0', 'Always'], ['1', '1 day'], ['3', '3 days'], ['7', '7 days'],
        ['14', '14 days'], ['30', '30 days'], ['never', 'Never'],
      ],
      host_metrics_refresh: [
        ['0', 'Off'], ['60', '1 minute'], ['120', '2 minutes'],
        ['300', '5 minutes'], ['600', '10 minutes'],
      ],
      default_dashboard_command: [
        ['explore', 'Explore'], ['update', 'Update'], ['config', 'Config'],
        ['shell', 'Shell'], ['recipes', 'Recipes'],
      ],
      web_autostart: [
        ['off', 'Off'], ['localhost', 'Localhost'], ['all', 'All interfaces'],
      ],
      web_open_browser: [
        ['false', 'Off'], ['true', 'On'],
      ],
      web_terminal_mode: [
        ['panel', 'Panel (inline)'], ['maximized', 'Maximized (tab)'], ['popout', 'Pop-out window'],
      ],
      tmux_prefix: [
        ['C-a', 'Ctrl-A (screen)'], ['C-b', 'Ctrl-B (tmux)'],
        ['C-s', 'Ctrl-S'], ['C-q', 'Ctrl-Q'],
      ],
      nnn_colors: [
        ['6234', 'Cyan dirs (default)'], ['2234', 'Green dirs'],
        ['3234', 'Yellow dirs'], ['5234', 'Magenta dirs'],
      ],
      graph_renderer: [
        ['auto', 'Auto-detect'], ['graph-easy', 'Graph::Easy'], ['ascii', 'ASCII'],
      ],
      explore_load_size: [
        ['50', '50'], ['100', '100'], ['200', '200 (default)'],
        ['500', '500'], ['1000', '1000'],
      ],
    };

    const labels = {
      directory_browser: 'Dir browser',
      git_viewer: 'Git viewer',
      preview_layout: 'Preview layout',
      editor: 'Editor',
      recipe_scan: 'Recipe scan',
      backup_prune_age: 'Backup prune',
      host_metrics_refresh: 'Metrics refresh',
      default_dashboard_command: 'Default action',
      web_autostart: 'Web autostart',
      web_open_browser: 'Web open browser',
      web_terminal_mode: 'Terminal mode',
      tmux_prefix: 'Tmux prefix',
      nnn_colors: 'NNN colors',
      graph_renderer: 'Graph renderer',
      explore_load_size: 'Explore load size',
    };

    let html = '<div class="config-inline-panel">';
    for (const [key, opts] of Object.entries(options)) {
      const current = String(s[key] != null ? s[key] : '');
      html += `<div class="config-panel-row">
        <label>${esc(labels[key])}</label>
        <select class="form-select config-setting-select" data-key="${key}">`;
      opts.forEach(([val, label]) => {
        html += `<option value="${esc(val)}"${current === val ? ' selected' : ''}>${esc(label)}</option>`;
      });
      html += '</select></div>';
      // Insert per-host tmux session right after tmux_prefix
      if (key === 'tmux_prefix' && this._hostTmux) {
        const h = this._hostTmux;
        const isCustom = h.tmux_session && h.tmux_session !== 'auto';
        html += '<div class="config-panel-row">' +
          '<label>Tmux session</label>' +
          '<select class="form-select config-tmux-session-select" data-host="' + esc(h.host) + '">' +
          '<option value=""' + (!h.tmux_session ? ' selected' : '') + '>bit-* (per project)</option>' +
          '<option value="auto"' + (h.tmux_session === 'auto' ? ' selected' : '') + '>auto (any session)</option>' +
          '<option value="__custom__"' + (isCustom ? ' selected' : '') + '>Custom name</option>' +
          '</select></div>';
        if (isCustom) {
          html += '<div class="config-panel-row">' +
            '<label></label>' +
            '<input type="text" class="form-input config-tmux-session-input"' +
            ' data-host="' + esc(h.host) + '" value="' + esc(h.tmux_session) + '"' +
            ' placeholder="session name">' +
            '</div>';
        }
      }
    }
    html += '</div>';

    return html;
  },

  _renderAIPanel() {
    const s = this._config.settings;
    const provider = s.ai_provider || 'cli';
    const model = s.ai_model || 'claude-sonnet-4-20250514';
    const cliCmd = s.ai_cli_command || 'claude';
    const apiKey = s.ai_api_key || '';
    const apiBase = s.ai_api_base || '';
    const ollamaUrl = s.ai_ollama_url || 'http://localhost:11434';
    const defaultPreset = s.ai_default_preset || 'changelog';
    const includeDiffs = s.ai_include_diffs || false;

    let html = '<div class="config-inline-panel">';

    // Provider
    html += '<div class="config-panel-row"><label>Provider</label>';
    html += '<select class="form-select config-ai-select" data-key="ai_provider">';
    [['cli', 'CLI command'], ['claude-oauth', 'Claude (subscription)'], ['anthropic', 'Anthropic API'], ['openai', 'OpenAI-compatible'], ['ollama', 'Ollama']].forEach(([v, l]) => {
      html += `<option value="${v}"${provider === v ? ' selected' : ''}>${l}</option>`;
    });
    html += '</select></div>';

    // CLI command (shown when provider=cli)
    if (provider === 'cli') {
      html += '<div class="config-panel-row"><label>CLI command</label>';
      html += `<input type="text" class="form-input config-ai-input" data-key="ai_cli_command" value="${esc(cliCmd)}" placeholder="claude">`;
      html += '</div>';
    }

    // Model (shown for API providers and claude-oauth)
    if (provider !== 'cli') {
      html += '<div class="config-panel-row"><label>Model</label>';
      html += `<input type="text" class="form-input config-ai-input" data-key="ai_model" value="${esc(model)}" placeholder="claude-sonnet-4-20250514">`;
      html += '</div>';
    }

    // API key (for anthropic/openai)
    if (provider === 'anthropic' || provider === 'openai') {
      html += '<div class="config-panel-row"><label>API key</label>';
      html += `<input type="password" class="form-input config-ai-input" data-key="ai_api_key" value="${esc(apiKey)}" placeholder="sk-...">`;
      html += '</div>';
    }

    // API base URL (for openai)
    if (provider === 'openai') {
      html += '<div class="config-panel-row"><label>API base URL</label>';
      html += `<input type="text" class="form-input config-ai-input" data-key="ai_api_base" value="${esc(apiBase)}" placeholder="https://api.openai.com/v1">`;
      html += '</div>';
    }

    // Ollama URL
    if (provider === 'ollama') {
      html += '<div class="config-panel-row"><label>Ollama URL</label>';
      html += `<input type="text" class="form-input config-ai-input" data-key="ai_ollama_url" value="${esc(ollamaUrl)}" placeholder="http://localhost:11434">`;
      html += '</div>';
    }

    // Default preset
    html += '<div class="config-panel-row"><label>Default preset</label>';
    html += '<select class="form-select config-ai-select" data-key="ai_default_preset">';
    ['changelog', 'technical-review', 'release-notes', 'security-audit'].forEach(p => {
      html += `<option value="${p}"${defaultPreset === p ? ' selected' : ''}>${p}</option>`;
    });
    html += '</select></div>';

    // Include diffs
    html += '<div class="config-panel-row"><label>Include diffs</label>';
    html += `<select class="form-select config-ai-select" data-key="ai_include_diffs">`;
    html += `<option value="false"${!includeDiffs ? ' selected' : ''}>No (subjects + diffstat)</option>`;
    html += `<option value="true"${includeDiffs ? ' selected' : ''}>Yes (full patches)</option>`;
    html += '</select></div>';

    // Test button
    html += '<div class="config-panel-row"><label></label>';
    html += '<button class="btn config-ai-test">Test AI connection</button>';
    html += '</div>';

    html += '</div>';
    return html;
  },

  async _loadPendingConfig() {
    var panel = document.getElementById('pending-config-panel');
    if (!panel) return;
    try {
      var data = await API.pendingConfig(App.state.selectedProject || '');
      var repos = data.repos || [];
      if (!repos.length) {
        panel.innerHTML = '<div style="color:var(--text-muted);padding:8px">No repos found</div>';
        return;
      }
      var html = '<table style="width:100%;font-size:var(--font-size-sm);border-collapse:collapse">';
      html += '<thead><tr><th style="text-align:left;padding:4px 8px">Repo</th><th style="text-align:left;padding:4px 8px">Provider</th><th style="text-align:left;padding:4px 8px">Details</th></tr></thead><tbody>';
      for (var i = 0; i < repos.length; i++) {
        var r = repos[i];
        html += '<tr style="border-bottom:1px solid var(--border)">';
        html += '<td style="padding:4px 8px">' + esc(r.name) + '</td>';
        html += '<td style="padding:4px 8px">';
        var pt = r.provider_type || '';
        var isAuto = r.auto_detected;
        var autoLabel = 'Auto-detect';
        if (isAuto && pt) {
          var names = {github: 'GitHub', lore: 'Lore', maillist: 'Mailing list'};
          autoLabel = (names[pt] || pt) + ' (auto)';
        }
        html += '<select class="form-select pending-provider-select" data-repo="' + esc(r.path) + '" style="font-size:var(--font-size-sm)">';
        html += '<option value="auto"' + (isAuto ? ' selected' : '') + '>' + esc(autoLabel) + '</option>';
        html += '<option value="github"' + (!isAuto && pt === 'github' ? ' selected' : '') + '>GitHub</option>';
        html += '<option value="lore"' + (!isAuto && pt === 'lore' ? ' selected' : '') + '>Lore</option>';
        html += '<option value="maillist"' + (!isAuto && pt === 'maillist' ? ' selected' : '') + '>Mailing list</option>';
        html += '</select>';
        html += '</td>';
        html += '<td style="padding:4px 8px;color:var(--text-muted)">';
        if (r.auto_detected && r.provider_type) {
          html += esc(r.description) + ' <span style="opacity:0.5">(auto)</span>';
        } else if (r.configured) {
          html += esc(r.description);
        }
        html += '</td>';
        html += '</tr>';
      }
      html += '</tbody></table>';
      panel.innerHTML = html;

      // Bind change handlers
      panel.querySelectorAll('.pending-provider-select').forEach(sel => {
        sel.addEventListener('change', async () => {
          var repoPath = sel.dataset.repo;
          var val = sel.value;
          try {
            await API.pendingConfigUpdate({repo: repoPath, provider_type: val});
            App.showToast('Saved', 'success');
            this._loadPendingConfig();
          } catch (e) {
            App.showToast('Failed: ' + e.message, 'error');
          }
        });
      });
    } catch (e) {
      panel.innerHTML = '<div style="color:var(--error);padding:8px">Failed to load: ' + esc(e.message) + '</div>';
    }
  },

  async _saveRepoSetting(repoPath, data) {
    try {
      const name = repoPath.split('/').pop();
      await API.updateRepoConfig(name, data);
      App.showToast('Saved', 'success');
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  async _saveBranches(data) {
    try {
      await API.updateBranches(data, this._project());
      // Update local state and re-render
      if (data.priorities) this._config.branches.priorities = data.priorities;
      if (data.excludes) this._config.branches.excludes = data.excludes;
      if (data.stale_days !== undefined) this._config.branches.stale_days = data.stale_days;
      this._renderTree();
      App.showToast('Saved', 'success');
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  async _saveProperties(data) {
    try {
      await API.updateProperties(data, this._project());
      if (data.name !== undefined) this._config.project.name = data.name;
      if (data.description !== undefined) this._config.project.description = data.description;
      App.showToast('Saved', 'success');
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  async _saveSetting(key, value) {
    try {
      await API.updateSettings({ [key]: value });
      this._config.settings[key] = value;
      // Cache terminal mode for terminal-ws.js to read
      if (key === 'web_terminal_mode') {
        localStorage.setItem('bit-terminal-mode', value);
      }
      // Live-apply metrics refresh timer
      if (key === 'host_metrics_refresh') {
        const secs = parseInt(value, 10);
        if (secs > 0) {
          App.startMetricsRefresh(secs * 1000);
        } else {
          App.stopMetricsRefresh();
        }
      }
      App.showToast('Saved', 'success');
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

};
