/* bit web dashboard — app bootstrap, router, SSE client, state */
const App = (() => {
  const state = {
    currentView: null,
    currentProject: null,
    repos: [],
    projects: [],
    pinnedTabs: [],       // Array of { viewName, containerEl, tabEl }
    activeContentTab: 'view',  // 'view' | 'terminal' | pinned viewName
  };

  const views = {
    dashboard: DashboardView,
    explore: ExploreView,
    commits: CommitsView,
    branch: BranchView,
    update: UpdateView,
    config: ConfigView,
    patches: PatchesView,
    b4: B4View,
    pending: PendingView,
    recipes: RecipesView,
    fragments: FragmentsView,
    deps: DepsView,
    info: InfoView,
    export: ExportView,
    configs: SetupView,
    'layer-index': LayerIndexView,
    terminal: TerminalView,
    hosts: HostsView,
    https: HttpsView,
  };

  // Display names for views in tabs
  const viewLabels = {
    dashboard: 'Dashboard', explore: 'Explore', commits: 'Commits',
    branch: 'Branch', update: 'Update', config: 'Settings',
    patches: 'Patches', b4: 'B4 / Lore', pending: 'Pending Changes', recipes: 'Recipes',
    fragments: 'Fragments', deps: 'Dependencies', info: 'Info',
    export: 'Pull Request', configs: 'Config Files', 'layer-index': 'Layer Index',
    terminal: 'Terminal', hosts: 'Hosts', https: 'HTTPS',
  };

  let sseSource = null;
  let sseReconnectTimer = null;
  let _sseNavTimer = null;

  /** Debounced navigate for SSE events — coalesces rapid events into one re-render. */
  function sseNavigate(viewName) {
    if (_sseNavTimer) clearTimeout(_sseNavTimer);
    _sseNavTimer = setTimeout(() => {
      _sseNavTimer = null;
      navigate(viewName, true);
    }, 300);
  }

  // Host metrics auto-refresh timer
  let _metricsTimer = null;
  let _metricsIntervalMs = 0;

  // Message bar state
  const _messages = [];
  let _messageTimer = null;
  let _messageExpanded = false;

  function showMessage(text, type) {
    type = type || 'info';
    _messages.push({ time: new Date(), text, type });
    const bar = document.getElementById('message-bar');
    const textEl = document.getElementById('message-bar-text');
    const countEl = document.getElementById('message-bar-count');
    if (!bar || !textEl) return;
    textEl.textContent = text;
    textEl.className = 'message-' + type;
    countEl.textContent = _messages.length > 1 ? _messages.length : '';
    bar.style.display = '';
    // Auto-hide after 5s if not expanded
    if (_messageTimer) clearTimeout(_messageTimer);
    _messageTimer = setTimeout(() => {
      if (!_messageExpanded) _dismissMessageBar();
    }, 5000);
  }

  function _toggleMessageHistory() {
    const history = document.getElementById('message-bar-history');
    const toggle = document.getElementById('message-bar-toggle');
    if (!history) return;
    _messageExpanded = !_messageExpanded;
    history.style.display = _messageExpanded ? '' : 'none';
    if (toggle) toggle.textContent = _messageExpanded ? '\u25b4' : '\u25be';
    if (_messageExpanded) {
      // Render newest first
      history.innerHTML = _messages.slice().reverse().map(m => {
        const t = m.time.toLocaleTimeString();
        return `<div><span class="msg-time">${t}</span><span class="message-${m.type}">${esc(m.text)}</span></div>`;
      }).join('');
      // Cancel auto-hide while expanded
      if (_messageTimer) { clearTimeout(_messageTimer); _messageTimer = null; }
    }
  }

  function _dismissMessageBar() {
    const bar = document.getElementById('message-bar');
    const history = document.getElementById('message-bar-history');
    const toggle = document.getElementById('message-bar-toggle');
    if (bar) bar.style.display = 'none';
    if (history) history.style.display = 'none';
    if (toggle) toggle.textContent = '\u25be';
    _messageExpanded = false;
    if (_messageTimer) { clearTimeout(_messageTimer); _messageTimer = null; }
  }

  function getViewFromHash() {
    const hash = location.hash.slice(1) || 'dashboard';
    return hash;
  }

  // ── Content tab bar management ──

  function _contentTabBar() { return document.getElementById('content-tab-bar'); }

  function _viewLabel(viewName) {
    return viewLabels[viewName] || viewName.charAt(0).toUpperCase() + viewName.slice(1);
  }

  /** Show or hide the content tab bar based on whether there are pinned tabs or terminal is fullscreen. */
  function _syncTabBarVisibility() {
    const bar = _contentTabBar();
    if (!bar) return;
    const hasPinned = state.pinnedTabs.length > 0;
    const termFs = window.TerminalManager && TerminalManager.isFullscreen();
    bar.style.display = (hasPinned || termFs) ? 'flex' : 'none';
    // Show/hide terminal tab button
    const termBtn = document.getElementById('content-tab-terminal');
    if (termBtn) termBtn.style.display = termFs ? '' : 'none';
  }

  /** Update active state on all content tab buttons. */
  function _syncTabBarActive() {
    const bar = _contentTabBar();
    if (!bar) return;
    bar.querySelectorAll('.content-tab').forEach(el => {
      const key = el.dataset.contentTab;
      el.classList.toggle('active', key === state.activeContentTab);
    });
  }

  /** Update the "View" tab label to match the current unpinned view. */
  function _updateViewTabLabel(viewName) {
    const btn = document.getElementById('content-tab-view');
    if (btn) btn.textContent = _viewLabel(viewName);
  }

  /** Central tab switch — handles view, terminal, and pinned tabs. */
  function switchContentTab(tabKey) {
    state.activeContentTab = tabKey;
    const content = document.getElementById('content');
    const viewContainer = document.getElementById('view-container');

    if (tabKey === 'terminal') {
      // Terminal fullscreen — delegate to TerminalManager
      if (content) { content.style.display = 'none'; content.classList.remove('pinned-tab-active'); }
      state.pinnedTabs.forEach(t => { t.containerEl.style.display = 'none'; });
      if (window.TerminalManager) {
        TerminalManager.showTerminalDirect();
      }
    } else if (tabKey === 'view') {
      // Unpinned view — show #content with #view-container, hide pinned
      if (window.TerminalManager && TerminalManager.isFullscreen()) {
        TerminalManager.hideTerminalDirect();
      }
      state.pinnedTabs.forEach(t => { t.containerEl.style.display = 'none'; });
      if (content) { content.style.display = ''; content.classList.remove('pinned-tab-active'); }
      if (viewContainer) viewContainer.style.display = '';
    } else {
      // Pinned tab
      if (window.TerminalManager && TerminalManager.isFullscreen()) {
        TerminalManager.hideTerminalDirect();
      }
      if (viewContainer) viewContainer.style.display = 'none';
      if (content) { content.style.display = ''; content.classList.add('pinned-tab-active'); }
      state.pinnedTabs.forEach(t => {
        t.containerEl.style.display = (t.viewName === tabKey) ? '' : 'none';
      });
    }

    _syncTabBarVisibility();
    _syncTabBarActive();

    // Update keys panel for the active view
    if (tabKey === 'terminal') {
      updateKeysPanel(views.terminal);
    } else if (tabKey === 'view') {
      updateKeysPanel(views[state.currentView]);
    } else {
      updateKeysPanel(views[tabKey]);
    }
  }

  /** Pin a view as a persistent tab. */
  function pinView(viewName) {
    if (!views[viewName] || viewName === 'terminal') return;
    // Already pinned? Re-render it (context may have changed, e.g. different repo)
    // and switch to it.
    const existing = state.pinnedTabs.find(t => t.viewName === viewName);
    if (existing) {
      if (views[viewName].destroy) views[viewName].destroy();
      existing.containerEl.innerHTML = '';
      views[viewName].render(existing.containerEl, state);
      switchContentTab(viewName);
      return;
    }

    const content = document.getElementById('content');
    if (!content) return;

    // Create persistent container
    const containerEl = document.createElement('div');
    containerEl.className = 'pinned-view-container';
    containerEl.dataset.pinnedView = viewName;
    content.appendChild(containerEl);

    // Create tab button in the sortable zone
    const sortZone = document.getElementById('content-tabs-sortable');
    const tabEl = document.createElement('button');
    tabEl.className = 'content-tab content-tab-pinned';
    tabEl.dataset.contentTab = viewName;
    const label = document.createElement('span');
    label.textContent = _viewLabel(viewName);
    tabEl.appendChild(label);
    const closeBtn = document.createElement('span');
    closeBtn.className = 'content-tab-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.title = 'Close tab';
    tabEl.appendChild(closeBtn);

    if (sortZone) {
      const termTab = document.getElementById('content-tab-terminal');
      if (termTab && termTab.parentElement === sortZone) {
        sortZone.insertBefore(tabEl, termTab);
      } else {
        sortZone.appendChild(tabEl);
      }
    }

    // Tab click handlers
    tabEl.addEventListener('click', (e) => {
      if (e.target === closeBtn || closeBtn.contains(e.target)) return;
      switchContentTab(viewName);
    });
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      unpinView(viewName);
    });
    tabEl.addEventListener('auxclick', (e) => {
      if (e.button === 1) { e.preventDefault(); unpinView(viewName); }
    });

    state.pinnedTabs.push({ viewName, containerEl, tabEl });

    // If this view is currently in the unpinned slot, clear it and hide the View tab
    if (state.currentView === viewName) {
      if (state._activeView && state._activeView.destroy) state._activeView.destroy();
      const vc = document.getElementById('view-container');
      if (vc) vc.innerHTML = '';
      state._activeView = null;
      state.currentView = null;
      // Hide the View tab — it's empty now
      const viewTab = document.getElementById('content-tab-view');
      if (viewTab) viewTab.style.display = 'none';
    }

    // Render the view into the pinned container
    views[viewName].render(containerEl, state);

    _syncTabBarVisibility();
    switchContentTab(viewName);
    _savePinnedTabs();
  }

  /** Remove a pinned tab. */
  function unpinView(viewName) {
    const idx = state.pinnedTabs.findIndex(t => t.viewName === viewName);
    if (idx === -1) return;
    const tab = state.pinnedTabs[idx];

    // Destroy view if it has cleanup
    if (views[viewName] && views[viewName].destroy) {
      views[viewName].destroy();
    }
    tab.containerEl.remove();
    tab.tabEl.remove();
    state.pinnedTabs.splice(idx, 1);

    // If this was the active tab, switch elsewhere
    if (state.activeContentTab === viewName) {
      if (state.pinnedTabs.length > 0) {
        switchContentTab(state.pinnedTabs[0].viewName);
      } else {
        // No pins left — navigate to dashboard in the View tab
        navigate('dashboard', true);
      }
    }
    _syncTabBarVisibility();
    _savePinnedTabs();
  }

  /** Destroy all pinned view tabs (called on project switch). */
  function destroyAllPinnedTabs() {
    while (state.pinnedTabs.length > 0) {
      const tab = state.pinnedTabs[0];
      if (views[tab.viewName] && views[tab.viewName].destroy) {
        views[tab.viewName].destroy();
      }
      tab.containerEl.remove();
      tab.tabEl.remove();
      state.pinnedTabs.splice(0, 1);
    }
    if (state.activeContentTab !== 'view' && state.activeContentTab !== 'terminal') {
      state.activeContentTab = 'view';
    }
    _syncTabBarVisibility();
    _savePinnedTabs();
  }

  /** Persist pinned tab names to localStorage. */
  function _savePinnedTabs() {
    savePreference('pinned-tabs', state.pinnedTabs.map(t => t.viewName));
  }

  /** Restore pinned tabs from localStorage. */
  function _restorePinnedTabs() {
    const saved = loadPreference('pinned-tabs', []);
    if (!Array.isArray(saved) || saved.length === 0) return;
    saved.forEach(name => {
      if (views[name] && name !== 'terminal') pinView(name);
    });
    // Switch to first pinned tab
    if (state.pinnedTabs.length > 0) {
      switchContentTab(state.pinnedTabs[0].viewName);
    }
  }

  /** Refresh a pinned view (re-render in place). */
  function _refreshPinnedView(viewName) {
    const tab = state.pinnedTabs.find(t => t.viewName === viewName);
    if (!tab) return;
    if (views[viewName].destroy) views[viewName].destroy();
    tab.containerEl.innerHTML = '';
    views[viewName].render(tab.containerEl, state);
  }

  // ── Main navigation ──

  function navigate(viewName, force) {
    // Terminal is special — always toggle/maximize, never render as a view
    if (viewName === 'terminal') {
      if (window.TerminalManager) {
        if (TerminalManager.isFullscreen()) {
          // Already fullscreen — just switch to the terminal tab
          switchContentTab('terminal');
        } else {
          TerminalManager.maximize();
        }
      }
      _updateSidebarActive(viewName);
      return;
    }

    // Check if this view is pinned — just switch to its tab
    const pinned = state.pinnedTabs.find(t => t.viewName === viewName);
    if (pinned && !force) {
      switchContentTab(viewName);
      _updateSidebarActive(viewName);
      return;
    }
    // If pinned and force, re-render the pinned view and switch to it
    if (pinned && force) {
      _refreshPinnedView(viewName);
      switchContentTab(viewName);
      _updateSidebarActive(viewName);
      return;
    }

    // If there are already pinned tabs, auto-pin this view instead of using
    // the unpinned View slot — so it appears to the right of existing tabs.
    if (state.pinnedTabs.length > 0 && viewName !== 'terminal') {
      pinView(viewName);
      _updateSidebarActive(viewName);
      return;
    }

    if (state.currentView === viewName && !force) return;
    // Cancel any pending SSE-debounced re-render — this navigate supersedes it
    if (_sseNavTimer) { clearTimeout(_sseNavTimer); _sseNavTimer = null; }
    // Abort in-flight API requests from the previous view so they release
    // HTTP connection slots immediately (HTTP/1.1 browsers limit to 6).
    if (window._navAbortController) window._navAbortController.abort();
    window._navAbortController = new AbortController();
    window._navAbortSignal = window._navAbortController.signal;
    state.currentView = viewName;

    // Switch to the "View" content tab (away from terminal/pinned)
    if (state.activeContentTab !== 'view') {
      switchContentTab('view');
    }

    // If terminal is fullscreen and user navigates via sidebar, switch to view
    if (window.TerminalManager && TerminalManager.isFullscreen() && viewName !== 'terminal') {
      switchContentTab('view');
    }

    // Update nav
    _updateSidebarActive(viewName);

    // Hide view-specific fixed elements
    const dashReset = document.getElementById('dash-reset-order');
    if (dashReset) dashReset.style.display = 'none';
    const viewReset = document.getElementById('view-reset-order');
    if (viewReset) viewReset.style.display = 'none';

    // Show/hide dashboard sidebar actions
    document.querySelectorAll('.dash-sidebar-action').forEach(el => {
      el.style.display = viewName === 'dashboard' ? '' : 'none';
    });

    // Update Yocto section visibility based on selected project persona
    updateSidebarForPersona(viewName);

    // Ensure View tab is visible (may have been hidden when its view was pinned)
    const viewTabEl = document.getElementById('content-tab-view');
    if (viewTabEl) viewTabEl.style.display = '';

    // Render view
    const container = document.getElementById('view-container');
    container.dataset.view = viewName;
    // Mirror view name onto #content for full-width layout rules
    // (avoids reliance on CSS :has() which some browsers lack)
    document.getElementById('content').dataset.activeView = viewName;
    // Destroy previous view if it has cleanup
    if (state._activeView && state._activeView.destroy) {
      state._activeView.destroy();
    }
    const view = views[viewName];
    state._activeView = view || null;
    if (view) {
      container.innerHTML = '';
      view.render(container, state);
    } else {
      container.innerHTML = `<div class="empty-state"><h3>Unknown view: ${viewName}</h3></div>`;
    }

    // Update "View" tab label and keys panel
    _updateViewTabLabel(viewName);
    updateKeysPanel(view);
  }

  function _updateSidebarActive(viewName) {
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.view === viewName);
    });
  }

  function showToast(message, type = '', opts) {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    if (opts && opts.action && opts.onAction) {
      var btn = document.createElement('button');
      btn.textContent = opts.action;
      btn.style.cssText = 'margin-left:12px;padding:2px 10px;border:1px solid currentColor;border-radius:4px;background:transparent;color:inherit;cursor:pointer;font-size:inherit';
      btn.addEventListener('click', () => { toast.remove(); opts.onAction(); });
      toast.appendChild(btn);
    }
    document.body.appendChild(toast);
    const ms = type === 'error' ? 8000 : (opts && opts.action ? 10000 : 3000);
    setTimeout(() => toast.remove(), ms);
  }

  function showTerminal(text) {
    if (window.TerminalManager) {
      if (text !== undefined) {
        TerminalManager.appendCommandOutput(text);
      }
      return;
    }
    const panel = document.getElementById('terminal-panel');
    const output = document.getElementById('terminal-output');
    if (!panel || !output) return;
    panel.style.display = 'flex';
    if (text !== undefined) {
      output.textContent += text + '\n';
      output.scrollTop = output.scrollHeight;
    }
  }

  function clearTerminal() {
    if (window.TerminalManager) {
      TerminalManager.showCommandOutput('Command Output');
      return;
    }
    const el = document.getElementById('terminal-output');
    if (el) el.textContent = '';
  }

  function hideTerminal() {
    document.getElementById('terminal-panel').style.display = 'none';
  }

  // SSE
  function connectSSE() {
    if (sseSource) {
      sseSource.close();
    }
    sseSource = new EventSource('/api/events');

    sseSource.addEventListener('connected', () => {
      console.log('SSE connected');
    });

    sseSource.addEventListener('project_changed', (e) => {
      const data = JSON.parse(e.data);
      state.currentProject = data.path;
      updateProjectBadge();
      // Destroy all pinned view tabs — terminal tabs survive
      destroyAllPinnedTabs();
      // Re-render current view (debounced to avoid racing in-flight renders)
      if (state.currentView) sseNavigate(state.currentView);
    });

    sseSource.addEventListener('projects_list_changed', () => {
      if (state.currentView === 'dashboard') sseNavigate('dashboard');
      _refreshPinnedView('dashboard');
    });

    sseSource.addEventListener('repo_updated', (e) => {
      const data = JSON.parse(e.data);
      if (state.currentView === 'explore' || state.currentView === 'update' || state.currentView === 'commits') {
        sseNavigate(state.currentView);
      }
      // Also refresh relevant pinned views
      ['explore', 'update', 'commits'].forEach(v => _refreshPinnedView(v));
      showToast(`Repo updated: ${data.repo}`, 'success');
    });

    sseSource.addEventListener('refresh_complete', () => {
      if (state.currentView === 'explore' || state.currentView === 'update' || state.currentView === 'commits') {
        sseNavigate(state.currentView);
      }
      ['explore', 'update', 'commits'].forEach(v => _refreshPinnedView(v));
      showToast('Refresh complete', 'success');
    });

    sseSource.addEventListener('layer_clone_done', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone complete: ' + (data.layer_name || ''), 'success');
      if (state.currentView === 'layer-index') navigate('layer-index', true);
      _refreshPinnedView('layer-index');
    });

    sseSource.addEventListener('layer_clone_error', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone failed: ' + (data.error || 'unknown error'), 'error');
    });

    sseSource.addEventListener('setup_clone_done', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone complete: ' + (data.config_name || data.project_dir || ''), 'success');
      if (state.currentView === 'dashboard') navigate('dashboard', true);
      _refreshPinnedView('dashboard');
    });

    sseSource.addEventListener('setup_clone_error', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone failed: ' + (data.error || 'unknown error'), 'error');
    });

    sseSource.addEventListener('setup_clone_progress', (e) => {
      const data = JSON.parse(e.data);
      showToast(`Cloning ${data.repo} (${data.current}/${data.total})...`);
    });

    sseSource.addEventListener('host_metrics_updated', () => {
      if (state.currentView === 'hosts') navigate('hosts', true);
      // Also refresh inline metrics on the dashboard
      if (state.currentView === 'dashboard' && views.dashboard._fetchHostMetrics) {
        views.dashboard._fetchHostMetrics();
      }
    });

    sseSource.addEventListener('command_output', (e) => {
      const data = JSON.parse(e.data);
      // Route to AI panel if active (B4, Commits, or Pending view)
      var aiTarget = (window._b4AI && window._b4AI.active) ? window._b4AI
                   : (window._commitsAI && window._commitsAI.active) ? window._commitsAI
                   : (window._pendingAI && window._pendingAI.active) ? window._pendingAI
                   : null;
      if (aiTarget) {
        if (data.line) aiTarget.append(data.line);
        if (data.done) aiTarget.active = false;
        if (!data.done) return;
      }
      showTerminal(data.line);
      if (data.done) {
        showTerminal('--- done ---');
        // Notify any registered one-shot callback
        if (state._commandDoneCallback) {
          var cb = state._commandDoneCallback;
          state._commandDoneCallback = null;
          cb(data);
        }
      }
    });

    sseSource.onerror = () => {
      sseSource.close();
      sseSource = null;
      // Reconnect after delay
      if (sseReconnectTimer) clearTimeout(sseReconnectTimer);
      sseReconnectTimer = setTimeout(connectSSE, 3000);
    };
  }

  async function updateProjectBadge() {
    try {
      const resp = await API.getCurrentProject();
      state.currentProject = resp.path;
      const el = document.getElementById('project-name');
      const sectionTitle = document.getElementById('project-section-title');
      const tabProject = document.getElementById('content-tab-project');
      if (resp.path) {
        const name = resp.path.split('/').pop();
        el.textContent = name;
        el.title = resp.path;
        if (sectionTitle) sectionTitle.textContent = name;
        if (tabProject) { tabProject.textContent = name; tabProject.title = resp.path; }
      } else {
        el.textContent = 'No project';
        if (sectionTitle) sectionTitle.textContent = 'Project';
        if (tabProject) { tabProject.textContent = ''; tabProject.title = ''; }
      }
      updateYoctoSection();
    } catch (e) {
      // ignore
    }
  }

  async function updateYoctoSection() {
    const section = document.querySelector('.yocto-section');
    if (!section) return;
    try {
      const repos = await API.getRepos(state.currentProject);
      const hasYocto = Array.isArray(repos) && repos.some(r => r.layers && r.layers.length > 0);
      section.style.display = hasYocto ? '' : 'none';
    } catch (e) {
      section.style.display = 'none';
    }
  }

  function updateSidebarForPersona(viewName) {
    const section = document.querySelector('.yocto-section');
    const nameEl = document.getElementById('project-name');
    const sectionTitle = document.getElementById('project-section-title');

    if (viewName === 'dashboard') {
      // Re-check based on active project (async) — restores name + yocto visibility
      updateProjectBadge();
      // Restore yocto-only items (dashboard shows all)
      document.querySelectorAll('.yocto-only').forEach(el => { el.style.display = ''; });
      return;
    }

    // In project views, reflect the selected project in the sidebar
    const selectedName = state.selectedProjectName || '';
    if (selectedName && nameEl) {
      nameEl.textContent = selectedName;
      nameEl.title = state.selectedProject || '';
    }
    if (selectedName && sectionTitle) {
      sectionTitle.textContent = selectedName;
    }

    // Show/hide Yocto section and yocto-only items based on persona
    const persona = state.selectedProjectPersona || 'yocto';
    const isYocto = persona === 'yocto';
    if (section) section.style.display = isYocto ? '' : 'none';
    document.querySelectorAll('.yocto-only').forEach(el => {
      el.style.display = isYocto ? '' : 'none';
    });
  }

  function updateKeysPanel(view) {
    const el = document.getElementById('keys-content');
    if (!el) return;
    const bindings = (view && view.keyBindings) || [];
    if (!bindings.length) {
      el.innerHTML = '<div class="keys-none">No shortcuts</div>';
      return;
    }
    el.innerHTML = bindings.map(b => {
      if (b.sep) return '<div class="keys-sep"></div>';
      const cls = b.action ? 'keys-row keys-row-action' : 'keys-row';
      const actionAttr = b.action ? ` data-action-key="${esc(b.action)}"` : '';
      return `<div class="${cls}"${actionAttr}><span class="keys-key">${esc(b.key)}</span><span class="keys-desc">${esc(b.desc)}</span></div>`;
    }).join('');
    el.querySelectorAll('[data-action-key]').forEach(row => {
      row.addEventListener('click', () => {
        const key = row.dataset.actionKey;
        const v = _activeViewForKeyboard();
        if (v && typeof v.handleKeyboard === 'function') {
          v.handleKeyboard({ key, preventDefault() {} });
        }
      });
    });
  }

  /** Get the view object that should receive keyboard events. */
  function _activeViewForKeyboard() {
    const tab = state.activeContentTab;
    if (tab && tab !== 'view' && tab !== 'terminal') {
      return views[tab];  // pinned tab
    }
    return views[state.currentView];
  }

  function startMetricsRefresh(intervalMs) {
    stopMetricsRefresh();
    _metricsIntervalMs = intervalMs;
    if (!intervalMs || intervalMs <= 0) return;
    _metricsTimer = setInterval(async () => {
      try {
        const data = await API.getHostMetrics();
        if (state.currentView === 'hosts' && views.hosts._renderCards) {
          views.hosts._renderCards(data.hosts || []);
        }
        if (state.currentView === 'dashboard' && views.dashboard._fetchHostMetrics) {
          views.dashboard._fetchHostMetrics(data);
        }
      } catch (e) {
        // Silently ignore — metrics are supplementary
      }
    }, intervalMs);
  }

  function stopMetricsRefresh() {
    if (_metricsTimer) {
      clearInterval(_metricsTimer);
      _metricsTimer = null;
    }
    _metricsIntervalMs = 0;
  }

  function init() {
    // SSE
    connectSSE();

    // Start host metrics auto-refresh from saved config
    API.getConfig().then(cfg => {
      const s = cfg && cfg.settings;
      if (s) {
        if (s.host_metrics_refresh > 0) startMetricsRefresh(s.host_metrics_refresh * 1000);
        if (s.web_terminal_mode) localStorage.setItem('bit-terminal-mode', s.web_terminal_mode);
      }
    }).catch(() => {});

    // Project badge
    updateProjectBadge();

    // Hash routing
    window.addEventListener('hashchange', () => {
      state.currentView = null; // Force re-render on hash change
      navigate(getViewFromHash());
    });

    // Logo click — always navigate to dashboard (even if already there)
    document.getElementById('logo-link').addEventListener('click', (e) => {
      e.preventDefault();
      location.hash = 'dashboard';
      state.currentView = null;
      navigate('dashboard');
    });

    // Sidebar nav: single-click navigates, double-click pins
    // Use a timer to distinguish — suppress single-click if double-click follows
    let _navClickTimer = null;
    document.querySelectorAll('.nav-item[data-view]').forEach(el => {
      el.addEventListener('click', (e) => {
        const view = el.dataset.view;
        if (!view) return;
        if (_navClickTimer) clearTimeout(_navClickTimer);
        _navClickTimer = setTimeout(() => {
          _navClickTimer = null;
          navigate(view, true);
        }, 200);
      });
      el.addEventListener('dblclick', (e) => {
        e.preventDefault();
        if (_navClickTimer) { clearTimeout(_navClickTimer); _navClickTimer = null; }
        const view = el.dataset.view;
        if (view && view !== 'terminal') pinView(view);
      });
    });

    // Content tab bar: "View" tab click
    const viewTabBtn = document.getElementById('content-tab-view');
    if (viewTabBtn) viewTabBtn.addEventListener('click', () => switchContentTab('view'));
    // Terminal tab click is handled by TerminalManager.init()

    // Drag-reorder tabs via Sortable.js
    const sortZone = document.getElementById('content-tabs-sortable');
    if (sortZone && window.Sortable) {
      Sortable.create(sortZone, {
        animation: 150,
        ghostClass: 'sortable-ghost',
        filter: '#content-tab-view, #content-tab-terminal',  // View stays first, Terminal stays last
        onEnd: () => {
          // Sync pinnedTabs order to match DOM order
          const newOrder = [];
          sortZone.querySelectorAll('.content-tab-pinned').forEach(el => {
            const tab = state.pinnedTabs.find(t => t.viewName === el.dataset.contentTab);
            if (tab) newOrder.push(tab);
          });
          state.pinnedTabs = newOrder;
          _savePinnedTabs();
        },
      });
    }

    // Terminal close is handled by TerminalManager.init()

    // Message bar controls
    const msgToggle = document.getElementById('message-bar-toggle');
    const msgClose = document.getElementById('message-bar-close');
    if (msgToggle) msgToggle.addEventListener('click', _toggleMessageHistory);
    if (msgClose) msgClose.addEventListener('click', _dismissMessageBar);

    // Sidebar reset order button
    const sidebarReset = document.getElementById('sidebar-reset-order');
    if (sidebarReset) sidebarReset.addEventListener('click', () => {
      if (typeof resetSidebarOrder === 'function') resetSidebarOrder();
    });

    // Init terminal manager and messages panel
    if (window.TerminalManager) TerminalManager.init();
    if (window.MessagesPanel) {
      MessagesPanel.init();
      const navMsg = document.getElementById('nav-messages');
      if (navMsg) navMsg.addEventListener('click', () => MessagesPanel.toggle());
    }

    // Sidebar commands link
    const navCommands = document.getElementById('nav-commands');
    if (navCommands) {
      navCommands.addEventListener('click', () => {
        const persona = state.selectedProjectPersona || 'yocto';
        commandMenu(persona === 'yocto').then((view) => {
          if (view) location.hash = view;
        });
      });
    }

    // Keyboard event delegation to active view
    document.addEventListener('keydown', (e) => {
      // Skip if user is typing in an input/select/textarea or a modal is open
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
      if (document.querySelector('.modal-overlay')) return;

      // Backtick toggles terminal panel (unless typing in terminal)
      if (e.key === '`') {
        if (e.target.closest('.terminal-container')) return;
        e.preventDefault();
        if (window.MessagesPanel) MessagesPanel.hide();
        if (window.TerminalManager) TerminalManager.toggle();
        return;
      }

      // ? key: on dashboard, open command menu; elsewhere, toggle keys section
      if (e.key === '?') {
        if (state.currentView === 'dashboard') {
          const view = views[state.currentView];
          if (view && typeof view.handleKeyboard === 'function') {
            view.handleKeyboard(e);
          }
        } else {
          const keysSection = document.getElementById('keys-section');
          if (keysSection) {
            keysSection.classList.toggle('collapsed');
            savePreference('sidebar-keys', keysSection.classList.contains('collapsed'));
          }
        }
        return;
      }

      const view = _activeViewForKeyboard();
      if (view && typeof view.handleKeyboard === 'function') {
        view.handleKeyboard(e);
      }
    });

    // Collapsible sidebar sections (block-visibility pattern from zeddweb)
    document.querySelectorAll('.nav-section-title').forEach(title => {
      const section = title.parentElement;
      const sectionKey = section.dataset.section;
      if (sectionKey) {
        // Restore collapsed state
        const collapsed = loadPreference('sidebar-' + sectionKey, false);
        if (collapsed) section.classList.add('collapsed');

        title.addEventListener('click', () => {
          section.classList.toggle('collapsed');
          savePreference('sidebar-' + sectionKey, section.classList.contains('collapsed'));
        });
      }
    });

    // Theme selector
    const themeSelect = document.getElementById('theme-select');
    if (themeSelect) {
      const savedTheme = loadPreference('theme', '');
      themeSelect.value = savedTheme;
      document.documentElement.dataset.theme = savedTheme;
      themeSelect.addEventListener('change', () => {
        document.documentElement.dataset.theme = themeSelect.value;
        savePreference('theme', themeSelect.value);
      });
    }

    // Font settings (adapted from zeddweb preferences pattern)
    const fontSelect = document.getElementById('font-family-select');
    const fontSlider = document.getElementById('font-size-slider');
    const fontSizeDisplay = document.getElementById('font-size-display');

    if (fontSelect && fontSlider) {
      // Restore saved preferences
      const savedFont = loadPreference('font-family', null);
      const savedSize = loadPreference('font-size', 13);

      if (savedFont) {
        fontSelect.value = savedFont;
        document.documentElement.style.setProperty('--font-mono', savedFont);
      }
      fontSlider.value = savedSize;
      fontSizeDisplay.textContent = savedSize + 'px';
      if (savedSize !== 13) {
        document.documentElement.style.setProperty('--font-size-base', savedSize + 'px');
      }

      fontSelect.addEventListener('change', () => {
        const val = fontSelect.value;
        document.documentElement.style.setProperty('--font-mono', val);
        savePreference('font-family', val);
      });

      fontSlider.addEventListener('input', () => {
        const size = parseInt(fontSlider.value, 10);
        document.documentElement.style.setProperty('--font-size-base', size + 'px');
        fontSizeDisplay.textContent = size + 'px';
        savePreference('font-size', size);
      });
    }

    // Icon scale slider
    const iconSlider = document.getElementById('icon-size-slider');
    const iconSizeDisplay = document.getElementById('icon-size-display');
    if (iconSlider) {
      const savedIconScale = loadPreference('icon-scale', 100);
      iconSlider.value = savedIconScale;
      iconSizeDisplay.textContent = savedIconScale + '%';
      if (savedIconScale !== 100) {
        document.documentElement.style.setProperty('--icon-scale', savedIconScale / 100);
      }
      iconSlider.addEventListener('input', () => {
        const val = parseInt(iconSlider.value, 10);
        document.documentElement.style.setProperty('--icon-scale', val / 100);
        iconSizeDisplay.textContent = val + '%';
        savePreference('icon-scale', val);
      });
    }

    // Sidebar resize handle
    const sidebarHandle = document.getElementById('sidebar-resize-handle');
    const sidebar = document.getElementById('sidebar');
    if (sidebarHandle && sidebar) {
      const savedSidebarWidth = loadPreference('sidebar-width', null);
      if (savedSidebarWidth) {
        document.documentElement.style.setProperty('--sidebar-width', savedSidebarWidth + 'px');
      }
      let dragging = false, startX, startW;
      sidebarHandle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        dragging = true;
        startX = e.clientX;
        startW = sidebar.getBoundingClientRect().width;
        document.body.style.cursor = 'ew-resize';
        document.body.style.userSelect = 'none';
      });
      document.addEventListener('mousemove', (e) => {
        if (!dragging) return;
        const w = Math.min(400, Math.max(120, startW + (e.clientX - startX)));
        document.documentElement.style.setProperty('--sidebar-width', w + 'px');
      });
      document.addEventListener('mouseup', () => {
        if (!dragging) return;
        dragging = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = sidebar.getBoundingClientRect().width;
        savePreference('sidebar-width', Math.round(w));
      });
      sidebarHandle.addEventListener('dblclick', () => {
        document.documentElement.style.setProperty('--sidebar-width', '200px');
        savePreference('sidebar-width', null);
      });
    }

    // Navigate to initial view
    navigate(getViewFromHash());

    // Restore pinned tabs from previous session
    _restorePinnedTabs();
  }

  // Expose for views
  function onNextCommandDone(cb) {
    state._commandDoneCallback = cb;
  }

  window.App = {
    state,
    navigate,
    showToast,
    showMessage,
    showTerminal,
    clearTerminal,
    hideTerminal,
    updateKeysPanel,
    startMetricsRefresh,
    stopMetricsRefresh,
    pinView,
    unpinView,
    switchContentTab,
    onNextCommandDone,
  };

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return window.App;
})();
