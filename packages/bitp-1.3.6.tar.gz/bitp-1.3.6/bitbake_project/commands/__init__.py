#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Commands package for bit.

This package contains all command implementations:
- update: git pull/rebase layer repos
- explore: interactively explore commits
- export: export patches
- config: view and configure settings
- branch: view and switch branches
- layer-index: search and browse layer index
- setup: setup build environment
- setup clone: clone repos and register project
- repos: list repositories
- projects: manage multiple project directories
"""

# Import all run_* functions for CLI dispatch
from .update import run_update, run_single_repo_update
from .explore import run_explore, run_status, gather_repo_status
from .export import run_export, run_prepare_export
from .config import run_config, run_config_edit
from .branch import run_branch
from .search import run_search
from .setup import run_init, run_init_shell, run_bootstrap, run_setup_clone, run_setup_apply, run_setup_registry_copy, run_setup_export, run_setup_configs
from .repos import run_repos
from .projects import run_projects, run_dashboard, get_current_project, set_current_project, find_project_for_directory, resolve_project_by_name, load_projects, gather_all_project_summaries
from .ssh_remote import is_remote_project, ssh_check_connection, ssh_path_exists, remote_run_action
from .recipe import run_recipe
from .fragment import run_fragment
from .deps import run_deps
from .patches import run_patches
from .b4 import run_b4
from .ai import run_summarize
from .info import run_info, fzf_info_browser
from .query import run_query
from .daemon_cmd import run_daemon_command
from ..web import run_serve

# Also export fzf_available for CLI
from ..core import fzf_available

__all__ = [
    "run_update",
    "run_single_repo_update",
    "run_explore",
    "run_status",
    "gather_repo_status",
    "run_export",
    "run_prepare_export",
    "run_config",
    "run_config_edit",
    "run_branch",
    "run_search",
    "run_init",
    "run_init_shell",
    "run_bootstrap",
    "run_setup_clone",
    "run_setup_apply",
    "run_setup_registry_copy",
    "run_setup_export",
    "run_setup_configs",
    "run_repos",
    "run_projects",
    "run_dashboard",
    "get_current_project",
    "set_current_project",
    "resolve_project_by_name",
    "load_projects",
    "gather_all_project_summaries",
    "is_remote_project",
    "ssh_check_connection",
    "ssh_path_exists",
    "remote_run_action",
    "run_recipe",
    "run_fragment",
    "run_deps",
    "run_patches",
    "run_b4",
    "run_summarize",
    "run_info",
    "fzf_info_browser",
    "fzf_available",
    "run_query",
    "run_daemon_command",
    "run_serve",
]
