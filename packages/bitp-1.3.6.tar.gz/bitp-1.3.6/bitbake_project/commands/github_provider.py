#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""GitHub PR provider for the unified pending changes system.

Uses the `gh` CLI for all GitHub operations. The `gh` tool handles
authentication and provides structured JSON output. Falls back
gracefully if `gh` is not installed or not authenticated.
"""

import json
import os
import re
import shutil
import subprocess
from typing import Dict, List, Optional, Tuple

from ..core import Colors
from .pending import PendingChange, PendingChangeGroup, PendingChangeProvider, _get_github_owner_repo


# =============================================================================
# gh CLI Helpers
# =============================================================================

def gh_available() -> bool:
    """Check if gh CLI is installed and authenticated."""
    if not shutil.which("gh"):
        return False
    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def _run_gh(args: List[str], timeout: int = 30) -> Optional[str]:
    """Run a gh command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["gh"] + args,
            capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            return None
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None


# JSON fields to request from gh pr list
_PR_JSON_FIELDS = [
    "number", "title", "author", "createdAt", "url",
    "labels", "headRefName", "isDraft", "state",
    "statusCheckRollup", "reviews", "body",
    "reviewDecision", "additions", "deletions",
    "changedFiles",
]


# =============================================================================
# GitHub Provider
# =============================================================================

_GITHUB_ACTIONS = [
    ("VIEW", "View PR diff"),
    ("OPEN", "Open PR in browser"),
    ("CHECKOUT", "Checkout PR branch locally"),
    ("MERGE", "Merge PR into current branch"),
    ("DIFF", "View full diff in pager"),
    ("APPROVE", "Approve PR (gh pr review --approve)"),
    ("COMMENT", "Add review comment"),
    ("SUMMARIZE", "Summarize PR changes with AI"),
    ("REVIEW_EDIT", "Open AI review + diff in editor"),
    ("COPY", "Copy PR URL to clipboard"),
]


class GitHubProvider(PendingChangeProvider):
    """Pending change provider for GitHub pull requests via gh CLI."""
    provider_type = "github"

    def __init__(self, repo: str = ""):
        self.repo = repo
        self._owner_repo = _get_github_owner_repo(repo) if repo else ""

    def detect(self, repo: str, defaults: dict) -> bool:
        """Check if repo is on GitHub and gh is available."""
        if not _get_github_owner_repo(repo):
            return False
        return gh_available()

    def _ensure_owner_repo(self, repo: str = "") -> str:
        """Get owner/repo string, resolving from git remote if needed."""
        if self._owner_repo:
            return self._owner_repo
        r = repo or self.repo
        if r:
            self._owner_repo = _get_github_owner_repo(r) or ""
        return self._owner_repo

    def search(self, query: str, **kwargs) -> List[PendingChange]:
        """Search PRs by title/body."""
        owner_repo = self._ensure_owner_repo(kwargs.get("repo", ""))
        if not owner_repo:
            return []

        output = _run_gh([
            "pr", "list",
            "--repo", owner_repo,
            "--search", query,
            "--json", ",".join(_PR_JSON_FIELDS),
            "--limit", "50",
        ])
        if not output:
            return []

        try:
            prs = json.loads(output)
        except json.JSONDecodeError:
            return []

        return [self._parse_pr(pr) for pr in prs]

    def browse(self, **kwargs) -> List[PendingChange]:
        """List open PRs."""
        owner_repo = self._ensure_owner_repo(kwargs.get("repo", ""))
        if not owner_repo:
            return []

        output = _run_gh([
            "pr", "list",
            "--repo", owner_repo,
            "--state", "open",
            "--json", ",".join(_PR_JSON_FIELDS),
            "--limit", "50",
        ])
        if not output:
            return []

        try:
            prs = json.loads(output)
        except json.JSONDecodeError:
            return []

        return [self._parse_pr(pr) for pr in prs]

    def _parse_pr(self, pr: dict) -> PendingChange:
        """Convert gh pr JSON to PendingChange."""
        author = pr.get("author", {})
        author_name = author.get("login", "") if isinstance(author, dict) else str(author)

        # Labels
        labels = []
        for lbl in (pr.get("labels") or []):
            if isinstance(lbl, dict):
                labels.append(lbl.get("name", ""))
            elif isinstance(lbl, str):
                labels.append(lbl)

        # CI status from statusCheckRollup
        ci_status = ""
        checks = pr.get("statusCheckRollup") or []
        if checks:
            states = set()
            for check in checks:
                if isinstance(check, dict):
                    # Handles both CheckRun and StatusContext
                    conclusion = check.get("conclusion", "")
                    state = check.get("state", "")
                    if conclusion:
                        states.add(conclusion.upper())
                    elif state:
                        states.add(state.upper())
            if "FAILURE" in states or "ERROR" in states:
                ci_status = "failure"
            elif "PENDING" in states or "QUEUED" in states or "IN_PROGRESS" in states:
                ci_status = "pending"
            elif "SUCCESS" in states:
                ci_status = "success"

        # Review status
        review_decision = pr.get("reviewDecision", "")
        review_status = ""
        if review_decision == "APPROVED":
            review_status = "approved"
        elif review_decision == "CHANGES_REQUESTED":
            review_status = "changes_requested"
        elif review_decision == "REVIEW_REQUIRED":
            review_status = "pending"

        # Date formatting
        created = pr.get("createdAt", "")
        if "T" in created:
            created = created.split("T")[0]

        # Stats
        additions = pr.get("additions", 0)
        deletions = pr.get("deletions", 0)
        changed_files = pr.get("changedFiles", 0)

        return PendingChange(
            id=str(pr.get("number", "")),
            title=pr.get("title", ""),
            author=author_name,
            date=created,
            url=pr.get("url", ""),
            provider_type="github",
            content=pr.get("body", ""),
            labels=labels,
            ci_status=ci_status,
            review_status=review_status,
            pr_number=pr.get("number", 0),
            metadata={
                "branch": pr.get("headRefName", ""),
                "draft": pr.get("isDraft", False),
                "state": pr.get("state", ""),
                "additions": additions,
                "deletions": deletions,
                "changed_files": changed_files,
            },
        )

    def group(self, results: List[PendingChange]) -> List[PendingChangeGroup]:
        """Each PR is its own group."""
        return [PendingChangeGroup(root=r) for r in results]

    def get_content(self, change: PendingChange) -> str:
        """Fetch PR body + comments + diff."""
        owner_repo = self._owner_repo
        if not owner_repo:
            return change.content

        parts = []

        # PR body + comments via gh pr view
        view_output = _run_gh([
            "pr", "view", str(change.pr_number),
            "--repo", owner_repo,
            "--json", "body,comments,reviews",
        ], timeout=30)
        if view_output:
            try:
                view_data = json.loads(view_output)
                body = view_data.get("body", "")
                if body:
                    parts.append("## Description\n")
                    parts.append(body)

                # Review comments
                reviews = view_data.get("reviews") or []
                if reviews:
                    parts.append("\n## Reviews\n")
                    for rev in reviews:
                        author = rev.get("author", {}).get("login", "unknown") if isinstance(rev.get("author"), dict) else "unknown"
                        state = rev.get("state", "")
                        rev_body = rev.get("body", "")
                        submitted = rev.get("submittedAt", "")
                        if submitted and "T" in submitted:
                            submitted = submitted.split("T")[0]
                        parts.append(f"**{author}** ({state}) {submitted}")
                        if rev_body:
                            parts.append(f"> {rev_body}\n")
                        else:
                            parts.append("")

                # Comments
                comments = view_data.get("comments") or []
                if comments:
                    parts.append("\n## Comments\n")
                    for comment in comments:
                        author = comment.get("author", {}).get("login", "unknown") if isinstance(comment.get("author"), dict) else "unknown"
                        created = comment.get("createdAt", "")
                        if created and "T" in created:
                            created = created.split("T")[0]
                        comment_body = comment.get("body", "")
                        parts.append(f"**{author}** {created}")
                        parts.append(f"{comment_body}\n")
            except json.JSONDecodeError:
                if change.content:
                    parts.append(change.content)
        elif change.content:
            parts.append(change.content)

        # Diff
        diff = _run_gh([
            "pr", "diff", str(change.pr_number),
            "--repo", owner_repo,
        ], timeout=30)
        if diff:
            parts.append("\n## Diff\n")
            parts.append("```diff\n" + diff + "\n```")

        return "\n".join(parts)

    def get_actions(self) -> List[Tuple[str, str]]:
        return list(_GITHUB_ACTIONS)

    def execute_action(self, action: str, change: PendingChange,
                       repo: str, **kwargs) -> Optional[str]:
        """Execute GitHub-specific actions via gh CLI."""
        owner_repo = self._owner_repo
        pr_num = str(change.pr_number)

        if action == "OPEN":
            url = change.url or f"https://github.com/{owner_repo}/pull/{pr_num}"
            subprocess.run(["gh", "pr", "view", pr_num, "--repo", owner_repo, "--web"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return None

        elif action == "VIEW":
            diff = _run_gh(["pr", "diff", pr_num, "--repo", owner_repo], timeout=30)
            if diff:
                pager = os.environ.get("PAGER", "less")
                proc = subprocess.Popen([pager], stdin=subprocess.PIPE, text=True)
                proc.communicate(input=diff)
            else:
                print("Failed to fetch PR diff")
                input("Press Enter to continue...")

        elif action == "CHECKOUT":
            print(f"Checking out PR #{pr_num}...")
            result = subprocess.run(
                ["gh", "pr", "checkout", pr_num, "--repo", owner_repo],
                cwd=repo,
            )
            if result.returncode != 0:
                print(f"Checkout failed")
            else:
                print(f"Checked out PR #{pr_num}")
            input("Press Enter to continue...")

        elif action == "MERGE":
            print(f"Merging PR #{pr_num}...")
            result = subprocess.run(
                ["gh", "pr", "merge", pr_num, "--repo", owner_repo, "--merge"],
                cwd=repo,
            )
            if result.returncode != 0:
                print(f"Merge failed")
            else:
                print(f"PR #{pr_num} merged")
            input("Press Enter to continue...")

        elif action == "DIFF":
            diff = _run_gh(["pr", "diff", pr_num, "--repo", owner_repo], timeout=30)
            if diff:
                pager = os.environ.get("PAGER", "less")
                proc = subprocess.Popen([pager], stdin=subprocess.PIPE, text=True)
                proc.communicate(input=diff)

        elif action == "APPROVE":
            print(f"Approving PR #{pr_num}...")
            result = subprocess.run(
                ["gh", "pr", "review", pr_num, "--repo", owner_repo, "--approve"],
            )
            if result.returncode == 0:
                print("Approved")
            input("Press Enter to continue...")

        elif action == "COMMENT":
            try:
                body = input("Comment: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                return None
            if body:
                subprocess.run(
                    ["gh", "pr", "comment", pr_num, "--repo", owner_repo, "--body", body],
                )
            input("Press Enter to continue...")

        elif action == "COPY":
            url = change.url
            for cmd in [["xclip", "-selection", "clipboard"],
                        ["xsel", "--clipboard", "--input"],
                        ["wl-copy"], ["pbcopy"]]:
                try:
                    subprocess.run(cmd, input=url, text=True,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    print(f"Copied: {url}")
                    break
                except FileNotFoundError:
                    continue
            else:
                print(f"URL: {url}")
            input("Press Enter to continue...")

        return None

    def format_fzf_line(self, change: PendingChange, index: int) -> str:
        """Format PR as fzf menu line."""
        pr_num = f"#{change.pr_number}"
        title = change.title[:60]
        author = change.author[:15]
        date = change.date

        # CI status indicator
        ci_indicators = {
            "success": Colors.green("●"),
            "failure": Colors.red("●"),
            "pending": Colors.yellow("●"),
        }
        ci = ci_indicators.get(change.ci_status, Colors.DIM + "○" + Colors.RESET)

        # Review status indicator
        review_indicators = {
            "approved": Colors.green("✓"),
            "changes_requested": Colors.red("✗"),
            "pending": Colors.yellow("◌"),
        }
        review = review_indicators.get(change.review_status, "")

        # Labels (abbreviated)
        label_str = ""
        if change.labels:
            label_str = Colors.DIM + "[" + ",".join(l[:10] for l in change.labels[:3]) + "]" + Colors.RESET

        # Draft indicator
        draft = Colors.DIM + "(draft)" + Colors.RESET if change.metadata.get("draft") else ""

        line = f"{index}\t{Colors.cyan(pr_num):>8}  {title:<60}  {author:<15}  {date}  {ci} {review} {label_str} {draft}"
        return line

    def build_preview(self, change: PendingChange, preview_dir: str) -> str:
        """Build preview with header + dynamic conversation fetch."""
        owner_repo = self._owner_repo
        pr_num = change.pr_number

        # Write static header
        header_file = os.path.join(preview_dir, f"pr-{pr_num}-header.txt")
        with open(header_file, "w") as f:
            f.write(f"PR #{pr_num}: {change.title}\n")
            f.write(f"Author: {change.author}\n")
            f.write(f"Branch: {change.metadata.get('branch', '')}\n")
            f.write(f"Date: {change.date}\n")
            f.write(f"URL: {change.url}\n")
            if change.labels:
                f.write(f"Labels: {', '.join(change.labels)}\n")
            if change.ci_status:
                f.write(f"CI: {change.ci_status}\n")
            if change.review_status:
                f.write(f"Reviews: {change.review_status}\n")
            stats = change.metadata
            if stats.get("additions") or stats.get("deletions"):
                f.write(f"Changes: +{stats.get('additions', 0)} -{stats.get('deletions', 0)} "
                        f"({stats.get('changed_files', 0)} files)\n")

        # Write the fetch script once for all PRs
        fetch_script = os.path.join(preview_dir, "gh-preview.py")
        if not os.path.exists(fetch_script):
            with open(fetch_script, "w") as f:
                f.write("""#!/usr/bin/env python3
import json, subprocess, sys, os

pr_num = sys.argv[1]
owner_repo = sys.argv[2]
preview_dir = sys.argv[3]
header = os.path.join(preview_dir, f"pr-{pr_num}-header.txt")
cache = os.path.join(preview_dir, f"pr-{pr_num}-full.txt")

# Use cache if available
if os.path.exists(cache):
    with open(cache) as f:
        sys.stdout.write(f.read())
    sys.exit(0)

# Print header immediately
if os.path.exists(header):
    with open(header) as f:
        sys.stdout.write(f.read())
print()

# Fetch conversation
try:
    out = subprocess.check_output(
        ["gh", "pr", "view", pr_num, "--repo", owner_repo,
         "--json", "body,comments,reviews"],
        text=True, stderr=subprocess.DEVNULL, timeout=15,
    )
    d = json.loads(out)

    body = d.get("body", "")
    if body:
        print(body)
        print()

    for r in (d.get("reviews") or []):
        a = r.get("author", {}).get("login", "?") if isinstance(r.get("author"), dict) else "?"
        s = r.get("state", "")
        b = r.get("body", "")
        print(f"--- Review: {a} ({s}) ---")
        if b:
            print(b)
        print()

    for c in (d.get("comments") or []):
        a = c.get("author", {}).get("login", "?") if isinstance(c.get("author"), dict) else "?"
        t = c.get("createdAt", "")[:10]
        b = c.get("body", "")
        print(f"--- Comment: {a} {t} ---")
        print(b)
        print()

except Exception:
    pass
""")
            os.chmod(fetch_script, 0o755)

        # Return command that fetches and displays
        return f"python3 '{fetch_script}' {pr_num} {owner_repo} '{preview_dir}'"

    def get_description(self) -> str:
        return f"GitHub: {self._owner_repo}" if self._owner_repo else "GitHub PRs"
