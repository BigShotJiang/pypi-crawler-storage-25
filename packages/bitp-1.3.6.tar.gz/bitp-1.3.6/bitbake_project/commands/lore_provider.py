#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Lore/b4 provider adapter for the unified pending changes system.

Wraps existing b4.py functions, converting LoreResult to PendingChange
and back. This allows the lore browser to work through the generic
pending changes abstraction while reusing all existing lore code.
"""

import os
from typing import Dict, List, Optional, Tuple

from ..core import Colors
from .pending import PendingChange, PendingChangeGroup, PendingChangeProvider


# =============================================================================
# Conversion Functions
# =============================================================================

def lore_result_to_pending(lr) -> PendingChange:
    """Convert a LoreResult to PendingChange."""
    return PendingChange(
        id=lr.msgid,
        title=lr.subject,
        author=lr.author,
        date=lr.date,
        url=lr.url,
        provider_type="lore",
        content=lr.content,
        msgid=lr.msgid,
    )


def pending_to_lore_result(pc: PendingChange):
    """Convert a PendingChange back to LoreResult."""
    from .b4 import LoreResult
    return LoreResult(
        msgid=pc.msgid or pc.id,
        subject=pc.title,
        author=pc.author,
        date=pc.date,
        url=pc.url,
        content=pc.content,
    )


# =============================================================================
# Lore Provider
# =============================================================================

class LoreProvider(PendingChangeProvider):
    """Pending change provider backed by lore.kernel.org / b4."""
    provider_type = "lore"

    def __init__(self, repo: str = "", defaults: Optional[dict] = None):
        self.repo = repo
        self._defaults = defaults or {}
        self._list_name = None

    def _get_list_name(self, repo: str, defaults: dict) -> Optional[str]:
        """Get the lore mailing list name for this repo."""
        if self._list_name:
            return self._list_name
        from .b4 import _get_list_for_repo
        self._list_name = _get_list_for_repo(repo, defaults)
        return self._list_name

    def detect(self, repo: str, defaults: dict) -> bool:
        """Check if this repo has a known lore mailing list."""
        return self._get_list_name(repo, defaults) is not None

    def search(self, query: str, **kwargs) -> List[PendingChange]:
        """Search lore for patches matching query."""
        from .b4 import lore_search
        list_name = kwargs.get("list_name") or self._list_name
        results = lore_search(query, list_name=list_name)
        return [lore_result_to_pending(r) for r in results]

    def browse(self, **kwargs) -> List[PendingChange]:
        """Browse recent mailing list activity."""
        from .b4 import lore_browse_list
        repo = kwargs.get("repo", self.repo)
        defaults = kwargs.get("defaults", self._defaults)
        list_name = self._get_list_name(repo, defaults)
        if not list_name:
            return []
        results = lore_browse_list(list_name)
        return [lore_result_to_pending(r) for r in results]

    def group(self, results: List[PendingChange]) -> List[PendingChangeGroup]:
        """Group using b4's thread grouping logic."""
        from .b4 import group_into_threads
        # Convert back to LoreResult for grouping
        lore_results = [pending_to_lore_result(r) for r in results]
        groups = group_into_threads(lore_results)

        pending_groups = []
        for g in groups:
            root = lore_result_to_pending(g["root"])
            children = [lore_result_to_pending(c) for c in g["children"]]
            pending_groups.append(PendingChangeGroup(
                root=root,
                children=children,
                version=g.get("version"),
                total_parts=g.get("total_parts"),
                received_parts=g.get("received_parts"),
                metadata={"series_tag": g.get("series_tag"),
                           "subject_tags": g.get("subject_tags", [])},
            ))
        return pending_groups

    def get_content(self, change: PendingChange) -> str:
        """Fetch full thread content from lore."""
        from .b4 import fetch_lore_thread
        results = fetch_lore_thread(change.msgid or change.id, list_name="all")
        if not results:
            return change.content
        parts = []
        for r in results:
            parts.append(f"Subject: {r.subject}\nFrom: {r.author}\nDate: {r.date}\n\n{r.content}")
        return "\n\n---\n\n".join(parts)

    def get_actions(self) -> List[Tuple[str, str]]:
        """Return lore-specific actions."""
        return [
            ("VIEW", "View full thread"),
            ("APPLY", "Apply patch series (b4 am + git am)"),
            ("MBOX", "Download thread as mbox"),
            ("SUMMARIZE", "Summarize with AI"),
            ("COPY", "Copy message-id to clipboard"),
        ]

    def execute_action(self, action: str, change: PendingChange,
                       repo: str, **kwargs) -> Optional[str]:
        """Execute lore action by delegating to b4."""
        from .b4 import _execute_lore_action
        lr = pending_to_lore_result(change)
        _execute_lore_action(action, repo, lr)
        return None

    def format_fzf_line(self, change: PendingChange, index: int) -> str:
        """Format as lore-style line."""
        author = Colors.DIM + f"({change.author})" + Colors.RESET
        return f"{index}\t{change.date}  {Colors.cyan(change.title)}  {author}"

    def build_preview(self, change: PendingChange, preview_dir: str) -> str:
        """Write preview content for lore message."""
        preview_file = os.path.join(preview_dir, f"{change.id[:60].replace('/', '_')}.txt")
        try:
            with open(preview_file, "w") as f:
                f.write(f"Subject: {change.title}\n")
                f.write(f"From: {change.author}\n")
                f.write(f"Date: {change.date}\n")
                f.write(f"Message-Id: {change.msgid}\n")
                if change.url:
                    f.write(f"URL: {change.url}\n")
                f.write("\n")
                f.write(change.content or "(content not loaded)")
        except OSError:
            pass
        return f"cat '{preview_file}'"

    def get_description(self) -> str:
        return f"Lore: {self._list_name or 'mailing list'}"
