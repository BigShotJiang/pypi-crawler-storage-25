#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""AI-powered commit summarization.

Provides:
- Provider abstraction for LLM backends (CLI command, Anthropic, OpenAI-compat, Ollama)
- Preset prompt styles (changelog, technical-review, release-notes, security-audit)
- Commit data collection from git repos
- Lore thread data collection from email threads
- Streaming summarization entry point
"""

import json
import os
import subprocess
import sys
from typing import Dict, Iterator, List, Optional, Tuple


# =============================================================================
# Preset Prompts
# =============================================================================

SUMMARY_PRESETS: Dict[str, Tuple[str, str]] = {
    "changelog": (
        "Changelog",
        "You are a release engineer. Summarize the following commits as a concise, "
        "well-organized changelog. Group related changes under categories like "
        "Features, Bug Fixes, Improvements, etc. Use bullet points. "
        "Be concise but informative.",
    ),
    "technical-review": (
        "Technical Review",
        "You are a senior software engineer performing a technical review. "
        "Analyze these changes for: code quality, potential issues, architectural "
        "impact, and areas that may need attention. Be specific and constructive.",
    ),
    "release-notes": (
        "Release Notes",
        "You are a technical writer. Write user-facing release notes for these "
        "changes. Focus on what users need to know: new features, breaking changes, "
        "deprecations, and important fixes. Use clear, non-technical language where possible.",
    ),
    "security-audit": (
        "Security Audit",
        "You are a security engineer. Review these changes for security implications: "
        "new attack surface, input validation, authentication/authorization changes, "
        "cryptographic operations, and potential vulnerabilities. Flag anything that "
        "warrants closer review.",
    ),
}

# Friendly labels for preset picker
PRESET_CHOICES = list(SUMMARY_PRESETS.keys()) + ["custom"]


# =============================================================================
# AI Settings Defaults
# =============================================================================

AI_SETTINGS_DEFAULTS = {
    "ai_provider": "claude-oauth",
    "ai_model": "claude-haiku-4-5-20251001",
    "ai_api_key": "",
    "ai_api_base": "",
    "ai_ollama_url": "http://localhost:11434",
    "ai_cli_command": "claude",
    "ai_default_preset": "changelog",
    "ai_include_diffs": False,
}


def get_ai_settings(defaults: dict) -> dict:
    """Extract AI settings from defaults, filling in missing keys."""
    result = dict(AI_SETTINGS_DEFAULTS)
    for key in AI_SETTINGS_DEFAULTS:
        if key in defaults:
            result[key] = defaults[key]
    return result


# =============================================================================
# Provider Abstraction
# =============================================================================

class AIProvider:
    """Base class for LLM providers."""

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Yield response text chunks as they arrive."""
        raise NotImplementedError


class CLIProvider(AIProvider):
    """Invoke a configurable CLI command (claude, aichat, llm, sgpt, etc.).

    Pipes the prompt to stdin and streams stdout.  This is the default
    provider because it requires no API keys — just a CLI tool installed.
    """

    def __init__(self, command: str = "claude"):
        self.command = command

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        full_prompt = f"{system_prompt}\n\n{user_prompt}"
        cmd_parts = self.command.split()
        extra_args = []
        base_cmd = os.path.basename(cmd_parts[0])
        pipe_stdin = True  # default: pipe prompt via stdin

        if base_cmd == "claude":
            # Claude Code CLI: pipe prompt via stdin in print mode.
            # Use setsid to avoid session lock with other claude instances.
            # --dangerously-skip-permissions prevents interactive permission prompts.
            cmd_parts = ["setsid"] + cmd_parts
            extra_args = ["-p", "--output-format", "text",
                          "--dangerously-skip-permissions"]
            # pipe_stdin stays True — prompt goes via stdin
        elif base_cmd == "aichat":
            pass  # reads from stdin
        elif base_cmd == "llm":
            extra_args = ["-s", system_prompt]
            full_prompt = user_prompt  # llm takes system via -s
        elif base_cmd == "sgpt":
            pass  # reads from stdin

        try:
            proc = subprocess.Popen(
                cmd_parts + extra_args,
                stdin=subprocess.PIPE if pipe_stdin else subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )

            if base_cmd == "claude":
                # claude CLI: use communicate() with timeout — readline()
                # hangs indefinitely when called from a web server thread.
                # Pass stdin content via communicate() so write+close is atomic.
                try:
                    stdin_data = full_prompt if pipe_stdin else None
                    stdout, stderr = proc.communicate(input=stdin_data, timeout=120)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    yield "[Error: claude CLI timed out (120s). Try switching " \
                          "to a different provider in AI settings.]\n"
                    return
                if stdout:
                    yield stdout
                if proc.returncode != 0 and stderr and stderr.strip():
                    yield f"\n[Error from claude: {stderr.strip()}]\n"
            else:
                # Other CLI tools: stream line-by-line
                if pipe_stdin:
                    proc.stdin.write(full_prompt)
                    proc.stdin.close()
                while True:
                    line = proc.stdout.readline()
                    if not line:
                        break
                    yield line
                proc.wait()
                if proc.returncode != 0:
                    stderr = proc.stderr.read()
                    if stderr.strip():
                        yield f"\n[Error from {base_cmd}: {stderr.strip()}]\n"
        except FileNotFoundError:
            yield f"[Error: '{self.command}' not found. Install it or change ai_cli_command in settings.]\n"


class ClaudeOAuthProvider(AIProvider):
    """Call Anthropic Messages API directly using Claude Code's OAuth token.

    Reads the token from ~/.claude/.credentials.json — no SDK or API key needed.
    Uses urllib (stdlib) for HTTP, so there are no extra dependencies.
    This is the best provider for users with a Claude subscription.
    """

    def __init__(self, model: str = "claude-haiku-4-5-20251001"):
        self.model = model
        self._token = None

    def _get_token(self) -> Optional[str]:
        """Read OAuth access token from Claude Code credentials."""
        if self._token:
            return self._token
        creds_path = os.path.expanduser("~/.claude/.credentials.json")
        try:
            with open(creds_path) as f:
                creds = json.load(f)
            oauth = creds.get("claudeAiOauth", {})
            token = oauth.get("accessToken", "")
            if token:
                self._token = token
                return token
        except (OSError, json.JSONDecodeError, KeyError):
            pass
        return None

    def _make_request(self, token, payload):
        """Build and return a urllib Request object."""
        import urllib.request
        return urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "oauth-2025-04-20",
            },
            method="POST",
        )

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        import time
        import urllib.request
        import urllib.error

        token = self._get_token()
        if not token:
            yield "[Error: No Claude OAuth token found in ~/.claude/.credentials.json. " \
                  "Run 'claude' to authenticate first.]\n"
            return

        payload = json.dumps({
            "model": self.model,
            "max_tokens": 4096,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "stream": True,
        }).encode("utf-8")

        # Retry up to 4 times on 429 (rate limit) with exponential backoff
        max_retries = 4
        for attempt in range(max_retries + 1):
            req = self._make_request(token, payload)
            try:
                with urllib.request.urlopen(req, timeout=120) as resp:
                    for raw_line in resp:
                        line = raw_line.decode("utf-8", errors="replace").strip()
                        if not line or line.startswith(":"):
                            continue
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str == "[DONE]":
                                break
                            try:
                                event = json.loads(data_str)
                                etype = event.get("type", "")
                                if etype == "content_block_delta":
                                    delta = event.get("delta", {})
                                    text = delta.get("text", "")
                                    if text:
                                        yield text
                                elif etype == "error":
                                    err = event.get("error", {})
                                    yield f"\n[API error: {err.get('message', str(err))}]\n"
                                    return
                            except json.JSONDecodeError:
                                continue
                return  # success
            except urllib.error.HTTPError as e:
                if e.code == 429 and attempt < max_retries:
                    retry_after = e.headers.get("retry-after")
                    wait = int(retry_after) if retry_after else (2 ** attempt) * 5
                    wait = min(wait, 60)
                    yield f"[Rate limited, retrying in {wait}s...]\n"
                    time.sleep(wait)
                    continue
                body = e.read().decode("utf-8", errors="replace")[:500]
                yield f"[Anthropic API error {e.code}: {body}]\n"
                return
            except urllib.error.URLError as e:
                yield f"[Error connecting to Anthropic API: {e}]\n"
                return
            except Exception as e:
                yield f"[Error: {e}]\n"
                return


class AnthropicProvider(AIProvider):
    """Uses the anthropic Python SDK.  Requires ANTHROPIC_API_KEY env var or ai_api_key setting."""

    def __init__(self, api_key: str = "", model: str = "claude-sonnet-4-20250514"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.model = model

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        if not self.api_key:
            yield "[Error: ANTHROPIC_API_KEY not set. Set it in environment or ai_api_key in settings.]\n"
            return
        try:
            import anthropic
        except ImportError:
            yield "[Error: anthropic package not installed. Run: pip install anthropic]\n"
            return

        try:
            client = anthropic.Anthropic(api_key=self.api_key)
            with client.messages.stream(
                model=self.model,
                max_tokens=4096,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            ) as stream:
                for text in stream.text_stream:
                    yield text
        except Exception as e:
            yield f"\n[Anthropic API error: {e}]\n"


class OpenAICompatProvider(AIProvider):
    """OpenAI-compatible API (works with OpenAI, vLLM, llama.cpp, Ollama compat endpoint)."""

    def __init__(self, api_base: str = "", api_key: str = "", model: str = "gpt-4o"):
        self.api_base = api_base or "https://api.openai.com/v1"
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.model = model

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        if not self.api_key:
            yield "[Error: API key not set. Set ai_api_key in settings or OPENAI_API_KEY in environment.]\n"
            return
        try:
            import openai
        except ImportError:
            yield "[Error: openai package not installed. Run: pip install openai]\n"
            return

        try:
            client = openai.OpenAI(api_key=self.api_key, base_url=self.api_base)
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                max_tokens=4096,
                stream=True,
            )
            for chunk in response:
                delta = chunk.choices[0].delta if chunk.choices else None
                if delta and delta.content:
                    yield delta.content
        except Exception as e:
            yield f"\n[OpenAI API error: {e}]\n"


class OllamaProvider(AIProvider):
    """Ollama native REST API (http://localhost:11434)."""

    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama3"):
        self.base_url = base_url.rstrip("/")
        self.model = model

    def stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        import urllib.request
        import urllib.error

        url = f"{self.base_url}/api/chat"
        payload = json.dumps({
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": True,
        }).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        content = obj.get("message", {}).get("content", "")
                        if content:
                            yield content
                        if obj.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue
        except urllib.error.URLError as e:
            yield f"[Error connecting to Ollama at {self.base_url}: {e}]\n"
        except Exception as e:
            yield f"[Ollama error: {e}]\n"


# =============================================================================
# Provider Factory
# =============================================================================

def get_provider(settings: dict) -> AIProvider:
    """Instantiate the configured AI provider from settings.

    Raises ValueError if the provider type is unknown.
    """
    ai = get_ai_settings(settings)
    provider_type = ai["ai_provider"]
    model = ai["ai_model"]
    api_key = ai["ai_api_key"]

    if provider_type == "cli":
        return CLIProvider(command=ai["ai_cli_command"])
    elif provider_type == "claude-oauth":
        return ClaudeOAuthProvider(model=model)
    elif provider_type == "anthropic":
        return AnthropicProvider(api_key=api_key, model=model)
    elif provider_type == "openai":
        return OpenAICompatProvider(
            api_base=ai["ai_api_base"],
            api_key=api_key,
            model=model,
        )
    elif provider_type == "ollama":
        return OllamaProvider(base_url=ai["ai_ollama_url"], model=model)
    else:
        raise ValueError(f"Unknown AI provider: {provider_type}")


def is_ai_configured(settings: dict) -> bool:
    """Check whether AI summarization is usable with current settings."""
    ai = get_ai_settings(settings)
    provider = ai["ai_provider"]
    if provider == "cli":
        # CLI provider just needs the command to exist
        cmd = ai["ai_cli_command"].split()[0]
        return bool(cmd)
    elif provider == "claude-oauth":
        # Check if OAuth token exists
        creds_path = os.path.expanduser("~/.claude/.credentials.json")
        try:
            with open(creds_path) as f:
                creds = json.load(f)
            return bool(creds.get("claudeAiOauth", {}).get("accessToken"))
        except (OSError, json.JSONDecodeError):
            return False
    elif provider == "anthropic":
        return bool(ai["ai_api_key"] or os.environ.get("ANTHROPIC_API_KEY"))
    elif provider == "openai":
        return bool(ai["ai_api_key"] or os.environ.get("OPENAI_API_KEY"))
    elif provider == "ollama":
        return bool(ai["ai_ollama_url"])
    return False


# =============================================================================
# Commit Data Collection
# =============================================================================

def collect_commit_data(
    repo: str,
    hashes: List[str],
    include_diffs: bool = False,
) -> str:
    """Build prompt content from commit hashes.

    Default: subject + author + date + diffstat per commit.
    With include_diffs: adds full patch content.
    """
    parts = []
    fmt = "%H%n%s%n%an%n%ad%n"
    diff_args = ["-p"] if include_diffs else ["--stat"]

    for h in hashes:
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "show", "--format=" + fmt] + diff_args + [h],
                text=True,
                stderr=subprocess.DEVNULL,
            )
            parts.append(out.strip())
        except subprocess.CalledProcessError:
            parts.append(f"(could not retrieve commit {h})")
    return "\n\n---\n\n".join(parts)


def collect_lore_data(
    messages: List[dict],
    include_diffs: bool = False,
) -> str:
    """Build prompt content from lore thread messages.

    Each message dict should have keys: subject, author, date, body.
    If include_diffs is False, only includes subject + author + date + diffstat-like summary.
    """
    parts = []
    for msg in messages:
        subject = msg.get("subject", "(no subject)")
        author = msg.get("author", "")
        date = msg.get("date", "")
        body = msg.get("body", "")

        header = f"Subject: {subject}"
        if author:
            header += f"\nFrom: {author}"
        if date:
            header += f"\nDate: {date}"

        if include_diffs:
            parts.append(f"{header}\n\n{body}")
        else:
            # Include commit message, cover letter, and diffstat but skip
            # raw diff hunks (diff --git / @@ / +/- lines) to keep size down.
            lines = body.split("\n")
            summary_lines = []
            in_diff_hunk = False
            for line in lines:
                if line.startswith("diff --git "):
                    in_diff_hunk = True
                    continue
                if in_diff_hunk:
                    # Still include diffstat summary lines within hunks
                    if "files changed" in line or "file changed" in line:
                        summary_lines.append(line)
                        in_diff_hunk = False
                    # Skip raw diff lines (+, -, @@, index, etc.)
                    continue
                summary_lines.append(line)
            parts.append(f"{header}\n\n" + "\n".join(summary_lines))

    return "\n\n---\n\n".join(parts)


# =============================================================================
# Main Summarize Entry Points
# =============================================================================

def summarize_commits(
    repo: str,
    hashes: List[str],
    settings: dict,
    preset: str = "changelog",
    custom_prompt: str = "",
    include_diffs: bool = False,
) -> Iterator[str]:
    """Yield summary text chunks for the given commits.

    The caller handles display (write to terminal, stream via SSE, etc.).
    """
    # Build system prompt
    if custom_prompt:
        system_prompt = custom_prompt
    elif preset in SUMMARY_PRESETS:
        _, system_prompt = SUMMARY_PRESETS[preset]
    else:
        _, system_prompt = SUMMARY_PRESETS["changelog"]

    # Collect commit data
    ai_settings = get_ai_settings(settings)
    if not include_diffs:
        include_diffs = ai_settings.get("ai_include_diffs", False)

    commit_data = collect_commit_data(repo, hashes, include_diffs=include_diffs)
    if not commit_data.strip():
        yield "[No commit data found.]\n"
        return

    user_prompt = (
        f"Here are {len(hashes)} commit(s) to analyze:\n\n{commit_data}"
    )

    # Stream from provider
    provider = get_provider(settings)
    yield from provider.stream(system_prompt, user_prompt)


def summarize_lore_thread(
    messages: List[dict],
    settings: dict,
    preset: str = "technical-review",
    custom_prompt: str = "",
    include_diffs: bool = False,
) -> Iterator[str]:
    """Yield summary text chunks for a lore thread.

    messages: list of dicts with keys subject, author, date, body.
    """
    if custom_prompt:
        system_prompt = custom_prompt
    elif preset in SUMMARY_PRESETS:
        _, system_prompt = SUMMARY_PRESETS[preset]
    else:
        _, system_prompt = SUMMARY_PRESETS["technical-review"]

    # Lore messages ARE patches — always include the full body.
    # The include_diffs setting only applies to git commit summarization.
    thread_data = collect_lore_data(messages, include_diffs=True)
    if not thread_data.strip():
        yield "[No thread data found.]\n"
        return

    user_prompt = (
        f"Here is a mailing list thread with {len(messages)} message(s) to analyze:\n\n{thread_data}"
    )

    provider = get_provider(settings)
    yield from provider.stream(system_prompt, user_prompt)


# =============================================================================
# TUI Helpers
# =============================================================================

def build_preset_menu(default_preset: str = "changelog") -> List[str]:
    """Build inline dialog lines for the preset picker.

    Returns lines suitable for prepending/appending to an fzf menu
    as an inline dialog.  The default preset is marked with *.
    """
    lines = []
    for key, (label, _desc) in SUMMARY_PRESETS.items():
        marker = " *" if key == default_preset else ""
        lines.append(f"PRESET:{key}\t  {label}{marker}")
    lines.append(f"PRESET:custom\t  Custom prompt...")
    return lines


def fzf_pick_preset(default_preset: str = "changelog") -> Optional[str]:
    """Show fzf picker for summary presets as an inline dialog.

    Uses --disabled so the list is static, Esc cancels.
    Returns preset key or None if cancelled.
    """
    lines = build_preset_menu(default_preset)

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort",
                "--ansi",
                "--disabled",
                "--height", "~12",
                "--header", "Select summary style (Enter to confirm, Esc to cancel):",
                "--prompt", "Style: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ],
            input="\n".join(lines),
            stdout=subprocess.PIPE,
            text=True,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return None
        picked = result.stdout.strip().split("\t", 1)[0]
        return picked.replace("PRESET:", "")
    except FileNotFoundError:
        return default_preset


def fzf_get_custom_prompt() -> Optional[str]:
    """Get custom prompt text via fzf --print-query --disabled.

    Returns the typed text or None if cancelled.
    """
    try:
        result = subprocess.run(
            [
                "fzf",
                "--disabled",
                "--print-query",
                "--height", "~5",
                "--header", "Type your prompt (Enter to submit, Esc to cancel):",
                "--prompt", "Prompt: ",
            ],
            input="",
            stdout=subprocess.PIPE,
            text=True,
        )
        if result.returncode == 130:  # Esc
            return None
        lines = result.stdout.strip().splitlines()
        return lines[0] if lines else None
    except FileNotFoundError:
        return None


# =============================================================================
# Standalone CLI Entry Point
# =============================================================================

def run_summarize(args) -> int:
    """CLI entry point for 'bit summarize'."""
    from ..core import load_defaults
    from .common import resolve_repos_with_fallback, find_repo_by_identifier
    from .branch import get_local_commits

    defaults_file = getattr(args, "defaults_file", ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # Resolve repo
    repo_arg = getattr(args, "repo", None)
    hashes = getattr(args, "commits", None) or []
    preset = getattr(args, "preset", None) or defaults.get("ai_default_preset", "changelog")
    custom_prompt = getattr(args, "prompt", None) or ""
    include_diffs = getattr(args, "diffs", False)

    if custom_prompt:
        preset = "custom"

    # Find repo
    repo = None
    if repo_arg:
        # Try as direct path first
        if os.path.isdir(repo_arg):
            repo = os.path.abspath(repo_arg)
        else:
            # Try to resolve from project repos
            try:
                bblayers_path = getattr(args, "bblayers", None)
                if bblayers_path:
                    from .common import resolve_repos_with_fallback as _rrf
                    pairs, _sets = _rrf(bblayers_path, defaults)
                    repos = [r for _, r in pairs]
                else:
                    from .common import resolve_repos_with_fallback
                    pairs, _sets = resolve_repos_with_fallback(None, defaults, defaults_file=defaults_file)
                    repos = list(dict.fromkeys(r for _, r in pairs))
                repo = find_repo_by_identifier(repos, repo_arg, defaults)
            except Exception:
                pass
        if not repo:
            print(f"Repo not found: {repo_arg}", file=sys.stderr)
            return 1
    else:
        # Use default project's first repo, or CWD if it's a git repo
        try:
            repo = subprocess.check_output(
                ["git", "rev-parse", "--show-toplevel"],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
        except subprocess.CalledProcessError:
            # Try project repos
            try:
                pairs, _sets = resolve_repos_with_fallback(None, defaults, defaults_file=defaults_file)
                repos = list(dict.fromkeys(r for _, r in pairs))
                if repos:
                    repo = repos[0]
            except Exception:
                pass
        if not repo:
            print("No git repository found. Specify a repo or run from within one.", file=sys.stderr)
            return 1

    # Resolve commits
    if not hashes:
        # Default: summarize local (unpushed) commits
        from .branch import get_local_commits, current_branch
        branch = current_branch(repo)
        if not branch or branch == "(detached)":
            print("No branch found (detached HEAD). Specify commit hashes.", file=sys.stderr)
            return 1
        local_commits, _base = get_local_commits(repo, branch)
        if not local_commits:
            print(f"No local commits on {branch}.", file=sys.stderr)
            return 1
        hashes = [h for h, _ in local_commits]
        print(f"Summarizing {len(hashes)} local commit(s) on {branch}...\n", file=sys.stderr)

    # Pick preset interactively if not specified via CLI
    if not custom_prompt and not getattr(args, "preset", None):
        from ..core import fzf_available
        if fzf_available():
            picked = fzf_pick_preset(preset)
            if picked is None:
                return 0
            if picked == "custom":
                custom_prompt = fzf_get_custom_prompt()
                if not custom_prompt:
                    return 0
            else:
                preset = picked

    # Stream output
    try:
        for chunk in summarize_commits(
            repo, hashes, defaults,
            preset=preset,
            custom_prompt=custom_prompt,
            include_diffs=include_diffs,
        ):
            sys.stdout.write(chunk)
            sys.stdout.flush()
        print()  # final newline
    except KeyboardInterrupt:
        print("\n[Interrupted]", file=sys.stderr)
        return 130

    return 0
