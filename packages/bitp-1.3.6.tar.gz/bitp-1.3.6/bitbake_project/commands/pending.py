#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Unified pending changes abstraction.

Provides a provider-based system for browsing pending changes from
different sources (GitHub PRs, lore mailing lists, non-lore mailing
lists). Each provider implements the PendingChangeProvider interface.

The explore "l" key auto-detects the appropriate provider for a repo.
"""

import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Tuple

from ..core import Colors, load_defaults, save_defaults


# =============================================================================
# Data Model
# =============================================================================

@dataclass
class PendingChange:
    """Unified representation of a pending change from any source."""
    id: str                # msgid for lore, PR number string for GitHub
    title: str             # subject or PR title
    author: str
    date: str
    url: str
    provider_type: str     # "lore", "github", "maillist"
    content: str = ""
    # GitHub-specific (empty for lore)
    labels: List[str] = field(default_factory=list)
    ci_status: str = ""       # "success", "failure", "pending", ""
    review_status: str = ""   # "approved", "changes_requested", "pending", ""
    pr_number: int = 0
    # Lore-specific
    msgid: str = ""
    series_tag: str = ""
    # Provider-specific extras
    metadata: Dict = field(default_factory=dict)


@dataclass
class PendingChangeGroup:
    """Thread/group of related changes (patch series, PR with comments)."""
    root: PendingChange
    children: List[PendingChange] = field(default_factory=list)
    version: Optional[int] = None
    total_parts: Optional[int] = None
    received_parts: Optional[int] = None
    metadata: Dict = field(default_factory=dict)


# =============================================================================
# Provider Base Class
# =============================================================================

class PendingChangeProvider:
    """Base class for pending change providers."""
    provider_type: str = ""

    def detect(self, repo: str, defaults: dict) -> bool:
        """Return True if this provider can handle the given repo."""
        raise NotImplementedError

    def search(self, query: str, **kwargs) -> List[PendingChange]:
        """Search for pending changes."""
        raise NotImplementedError

    def browse(self, **kwargs) -> List[PendingChange]:
        """Browse recent pending changes."""
        raise NotImplementedError

    def group(self, results: List[PendingChange]) -> List[PendingChangeGroup]:
        """Group results into threads/series."""
        # Default: each result is its own group
        return [PendingChangeGroup(root=r) for r in results]

    def get_content(self, change: PendingChange) -> str:
        """Fetch full content/diff for a change."""
        raise NotImplementedError

    def get_actions(self) -> List[Tuple[str, str]]:
        """Return list of (action_key, label) for TUI action dialog."""
        return []

    def execute_action(self, action: str, change: PendingChange,
                       repo: str, **kwargs) -> Optional[str]:
        """Execute an action on a change. Returns status message or None."""
        return None

    def format_fzf_line(self, change: PendingChange, index: int) -> str:
        """Format a change as a single fzf menu line."""
        return f"{index}\t{change.date}  {change.title}  ({change.author})"

    def build_preview(self, change: PendingChange, preview_dir: str) -> str:
        """Write preview data and return preview command string for fzf."""
        # Default: write content to a file
        preview_file = os.path.join(preview_dir, f"{change.id}.txt")
        try:
            with open(preview_file, "w") as f:
                f.write(f"Title: {change.title}\n")
                f.write(f"Author: {change.author}\n")
                f.write(f"Date: {change.date}\n")
                f.write(f"URL: {change.url}\n\n")
                f.write(change.content or "(no content)")
        except OSError:
            pass
        return f"cat {preview_file}"

    def get_description(self) -> str:
        """Human-readable description for status messages."""
        return self.provider_type


# =============================================================================
# Provider Detection
# =============================================================================

def _is_github_repo(repo: str) -> bool:
    """Check if repo's remote URL points to github.com."""
    try:
        url = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False
    return "github.com" in url


def _get_github_owner_repo(repo: str) -> Optional[str]:
    """Extract owner/repo from git remote URL.

    Handles:
      https://github.com/owner/repo.git
      git@github.com:owner/repo.git
      ssh://git@github.com/owner/repo
    """
    try:
        url = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

    # HTTPS: https://github.com/owner/repo.git
    m = re.match(r'https?://github\.com/([^/]+/[^/]+?)(?:\.git)?$', url)
    if m:
        return m.group(1)

    # SSH: git@github.com:owner/repo.git
    m = re.match(r'git@github\.com:([^/]+/[^/]+?)(?:\.git)?$', url)
    if m:
        return m.group(1)

    # SSH URL: ssh://git@github.com/owner/repo
    m = re.match(r'ssh://[^@]*@github\.com/([^/]+/[^/]+?)(?:\.git)?$', url)
    if m:
        return m.group(1)

    return None


def get_pending_provider_config(defaults: dict, repo_path: str) -> Optional[dict]:
    """Get pending provider config from __pending_providers__[repo_path]."""
    providers = defaults.get("__pending_providers__", {})
    return providers.get(repo_path)


def set_pending_provider_config(
    defaults_file: str,
    defaults: dict,
    repo_path: str,
    provider_type: str,
    auto_detected: bool = True,
    **extra,
) -> None:
    """Save provider config for a repo."""
    providers = defaults.get("__pending_providers__", {})
    config = {"provider_type": provider_type, "auto_detected": auto_detected}
    config.update(extra)
    providers[repo_path] = config
    defaults["__pending_providers__"] = providers
    save_defaults(defaults_file, defaults)


def detect_provider(
    repo: str,
    defaults: Optional[dict] = None,
) -> Optional[PendingChangeProvider]:
    """Auto-detect the best pending change provider for a repo.

    Priority:
      1. Explicit config in __pending_providers__
      2. GitHub remote URL
      3. Lore list detection (existing b4 logic)
      4. None (caller should fall back to b4 menu)
    """
    if defaults is None:
        defaults = load_defaults(".bit.defaults")

    # 1. Check explicit config
    config = get_pending_provider_config(defaults, repo)
    if config:
        ptype = config.get("provider_type", "")
        if ptype == "github":
            from .github_provider import GitHubProvider
            return GitHubProvider(repo=repo)
        elif ptype == "lore":
            from .lore_provider import LoreProvider
            return LoreProvider(repo=repo, defaults=defaults)
        elif ptype == "maillist":
            from .maillist_provider import MaillistProvider
            return MaillistProvider(
                repo=repo,
                host=config.get("maillist_host", ""),
                group_name=config.get("maillist_group", ""),
            )

    # 2. Check GitHub remote
    if _is_github_repo(repo):
        from .github_provider import GitHubProvider
        provider = GitHubProvider(repo=repo)
        if provider.detect(repo, defaults):
            return provider

    # 3. Check non-lore mailing lists (groups.io) — before lore because
    #    groups.io lists are more specific than generic lore manifest matches
    #    (e.g. meta-virtualization has its own list, not the generic "yocto" lore list)
    from .maillist_provider import MaillistProvider
    maillist = MaillistProvider(repo=repo)
    if maillist.detect(repo, defaults):
        return maillist

    # 4. Check lore
    from .lore_provider import LoreProvider
    lore = LoreProvider(repo=repo, defaults=defaults)
    if lore.detect(repo, defaults):
        return lore

    return None


# =============================================================================
# Generic TUI Browser
# =============================================================================

def fzf_pending_browser(
    provider: PendingChangeProvider,
    results: List[PendingChange],
    repo: str,
) -> None:
    """Generic fzf browser for any pending change provider.

    Delegates formatting, actions, and preview to the provider.
    Reuses the same fzf patterns as fzf_lore_browser (inline action
    dialog, preview toggle, AI review integration).
    """
    from ..core import fzf_available, get_fzf_color_args
    from ..fzf_bindings import (
        get_browser_bindings,
        get_preview_header_suffix,
    )

    if not results:
        print(f"No pending changes found ({provider.get_description()})")
        return

    if not fzf_available():
        for r in results[:20]:
            print(f"  {r.date}  {r.title}  ({r.author})")
        return

    # Group results
    groups = provider.group(results)

    # Build preview infrastructure
    preview_dir = tempfile.mkdtemp(prefix="pending-preview-")
    preview_files = {}
    for i, r in enumerate(results):
        cmd = provider.build_preview(r, preview_dir)
        preview_files[i] = cmd

    # Write a preview script that dispatches by index
    preview_script = os.path.join(preview_dir, "preview.sh")
    with open(preview_script, "w") as f:
        f.write("#!/bin/sh\n")
        f.write('IDX="$1"\n')
        for idx, cmd in preview_files.items():
            f.write(f'if [ "$IDX" = "{idx}" ]; then {cmd}; exit; fi\n')
        f.write('echo "(no preview)"\n')
    os.chmod(preview_script, 0o755)

    # Build menu lines
    menu_lines = []
    for i, r in enumerate(results):
        menu_lines.append(provider.format_fzf_line(r, i))

    actions = provider.get_actions()
    show_actions = False
    selected_change: Optional[PendingChange] = None
    _ACT_PREFIX = "PENDACT:"
    ai_reviews: Dict[str, str] = {}  # change.id -> review file path

    try:
        while True:
            fzf_input = list(menu_lines)

            if show_actions and selected_change:
                act_lines = []
                for key, label in actions:
                    act_lines.append(f"{_ACT_PREFIX}{key}\t{Colors.cyan('│')}  {label}")
                title_short = selected_change.title[:50]
                act_lines.append(f"---\t{Colors.cyan(f'┌─ {title_short} ' + '─' * max(0, 40 - len(title_short)))}")
                fzf_input = act_lines + fzf_input

            fzf_cmd = [
                "fzf",
                "--no-sort", "--ansi", "--height", "100%",
                "--with-nth", "2..", "--delimiter", "\t",
                "--preview", f"{preview_script} {{1}}",
                "--preview-window", "right:50%:wrap",
            ]

            if show_actions:
                fzf_cmd.extend([
                    "--disabled",
                    "--header", f"{provider.get_description()} — Select action (Esc=back)\n"
                                f"{get_preview_header_suffix()}",
                    "--prompt", "Action: ",
                ])
            else:
                fzf_cmd.extend([
                    "--header", f"{provider.get_description()} — Enter=actions, q=quit\n"
                                f"{get_preview_header_suffix()}",
                    "--prompt", "Change: ",
                    "--bind", "load:last",
                ])

            fzf_cmd.extend(get_browser_bindings(include_esc=not show_actions))
            fzf_cmd.extend(get_fzf_color_args())

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input="\n".join(fzf_input),
                    stdout=subprocess.PIPE, text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                if show_actions:
                    show_actions = False
                    continue
                return

            output = result.stdout.strip()
            if output == "BACK":
                if show_actions:
                    show_actions = False
                    continue
                return

            key = output.split("\t")[0]

            if show_actions:
                if key.startswith(_ACT_PREFIX):
                    action = key[len(_ACT_PREFIX):]
                    show_actions = False
                    if action == "SUMMARIZE":
                        # AI summarize — reuse existing AI infrastructure
                        _run_ai_summary(provider, selected_change, repo,
                                        preview_dir, ai_reviews)
                    else:
                        provider.execute_action(action, selected_change, repo)
                else:
                    show_actions = False
                continue

            # Parse selection
            if key in ("---", ""):
                continue
            try:
                idx = int(key)
                selected_change = results[idx]
                show_actions = True
            except (ValueError, IndexError):
                continue

    finally:
        import shutil
        shutil.rmtree(preview_dir, ignore_errors=True)


def _run_ai_summary(
    provider: PendingChangeProvider,
    change: PendingChange,
    repo: str,
    preview_dir: str,
    ai_reviews: Dict[str, str],
) -> None:
    """Run AI summary on a pending change, write to file, show in pager."""
    from .ai import (
        summarize_lore_thread, summarize_commits,
        fzf_pick_preset, fzf_get_custom_prompt, get_ai_settings,
    )

    defaults = load_defaults(".bit.defaults")
    ai_settings = get_ai_settings(defaults)
    preset = fzf_pick_preset(ai_settings.get("ai_default_preset", "technical-review"))
    if preset is None:
        return
    custom_prompt = ""
    if preset == "custom":
        custom_prompt = fzf_get_custom_prompt()
        if not custom_prompt:
            return

    # Build content for AI
    content = provider.get_content(change)
    messages = [{"subject": change.title, "author": change.author,
                 "date": change.date, "body": content}]

    safe_id = re.sub(r'[^\w.-]', '_', change.id)[:60]
    review_file = os.path.join(preview_dir, f"ai-review-{safe_id}.txt")

    print(f"\nRunning AI ({preset})...")
    try:
        with open(review_file, "w") as rf:
            rf.write(f"AI Review ({preset}): {change.title}\n")
            rf.write("=" * 72 + "\n\n")
            for chunk in summarize_lore_thread(
                messages, defaults,
                preset=preset,
                custom_prompt=custom_prompt if preset == "custom" else "",
            ):
                sys.stdout.write(chunk)
                sys.stdout.flush()
                rf.write(chunk)
            rf.write("\n")
        print()
        ai_reviews[change.id] = review_file
        # Open in pager
        pager = os.environ.get("PAGER", "less")
        subprocess.run([pager, review_file])
    except KeyboardInterrupt:
        print("\n[Interrupted]")
