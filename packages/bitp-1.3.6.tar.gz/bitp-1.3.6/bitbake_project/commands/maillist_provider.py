#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Non-lore mailing list provider for the unified pending changes system.

Supports groups.io based mailing lists (e.g. lists.yoctoproject.org)
via their public RSS feeds. Each group provides an unauthenticated
RSS feed at /g/<group>/rss with recent messages including HTML content.
"""

import html
import os
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple

from ..core import Colors
from .pending import PendingChange, PendingChangeGroup, PendingChangeProvider


# =============================================================================
# Known groups.io mailing list mappings
# =============================================================================

# Map repo basename patterns to groups.io group names
_GROUPSIO_HINTS = [
    (r"meta-virtualization", "lists.yoctoproject.org", "meta-virtualization"),
    (r"meta-security", "lists.yoctoproject.org", "meta-security"),
    (r"meta-cloud-services", "lists.yoctoproject.org", "meta-cloud-services"),
    (r"meta-arm", "lists.yoctoproject.org", "meta-arm"),
    (r"meta-intel", "lists.yoctoproject.org", "meta-intel"),
    (r"meta-ti", "lists.yoctoproject.org", "meta-ti"),
    (r"meta-raspberrypi", "lists.yoctoproject.org", "meta-raspberrypi"),
    (r"meta-mingw", "lists.yoctoproject.org", "meta-mingw"),
    (r"meta-selinux", "lists.yoctoproject.org", "meta-selinux"),
]


def _parse_groupsio_url(url: str) -> Optional[Tuple[str, str]]:
    """Parse a mailing list URL into (host, group_name).

    Handles:
      https://lists.yoctoproject.org/g/meta-intel
      https://lists.yoctoproject.org/listinfo/meta-freescale
      http://lists.openembedded.org/mailman/listinfo/openembedded-core
    """
    if not url:
        return None
    # groups.io format: /g/<group>
    m = re.search(r'(lists\.[^/]+)/g/([^/\s?]+)', url)
    if m:
        return (m.group(1), m.group(2))
    # Old mailman format on lists.yoctoproject.org: /listinfo/<list>
    m = re.search(r'(lists\.yoctoproject\.org)/listinfo/([^/\s?]+)', url)
    if m:
        return (m.group(1), m.group(2))
    return None


def _detect_groupsio_list(repo: str) -> Optional[Tuple[str, str]]:
    """Detect a groups.io mailing list from a repo path.

    Checks (in order):
      1. Hardcoded hints for known repos
      2. OE Layer Index mailing_list_url field

    Returns (host, group_name) or None.
    """
    basename = os.path.basename(repo.rstrip("/")).lower()

    # 1. Hardcoded hints
    for pattern, host, group in _GROUPSIO_HINTS:
        if re.search(pattern, basename, re.IGNORECASE):
            return (host, group)

    # 2. OE Layer Index lookup
    try:
        from .setup import _fetch_layer_index
        data = _fetch_layer_index(force=False)
        if data:
            for entry in data:
                layer = entry.get("layer", {})
                layer_name = layer.get("name", "").lower()
                if layer_name and (layer_name == basename
                                   or basename.startswith(layer_name)
                                   or layer_name.startswith(basename)):
                    ml_url = layer.get("mailing_list_url", "")
                    result = _parse_groupsio_url(ml_url)
                    if result:
                        return result
    except Exception:
        pass

    return None


# =============================================================================
# HTML cleanup
# =============================================================================

def _html_to_text(html_str: str) -> str:
    """Convert HTML content from RSS to plain text."""
    # Remove tags
    text = re.sub(r'<br\s*/?>', '\n', html_str)
    text = re.sub(r'<blockquote>', '\n> ', text)
    text = re.sub(r'</blockquote>', '\n', text)
    text = re.sub(r'</?p>', '\n', text)
    text = re.sub(r'<[^>]+>', '', text)
    # Decode entities
    text = html.unescape(text)
    # Clean up whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


# =============================================================================
# RSS Feed Fetching
# =============================================================================

def _fetch_messages_html(host: str, group: str, max_pages: int = 3) -> List[PendingChange]:
    """Fetch messages from a groups.io HTML messages page with pagination.

    Scrapes the server-rendered HTML which has subject, author, timestamp,
    and preview text. Paginates via page=N&after=TOKEN params.
    """
    import datetime

    results = []
    base_url = f"https://{host}/g/{group}/messages"
    url = base_url

    for page in range(max_pages):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            })
            data = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", errors="replace")
        except Exception:
            break

        # Parse message blocks: <td id="MSGID" ...>...</td>
        blocks = re.findall(r'<td id="(\d+)"(.*?)</td>', data, re.DOTALL)
        if not blocks:
            break

        for msg_id, content in blocks:
            # Subject + link
            subj_m = re.search(r'<a[^>]*href="([^"]+)"[^>]*>\s*\n?\s*([^<]+?)\s*</a>', content)
            subject = html.unescape(subj_m.group(2).strip()) if subj_m else ""
            link = subj_m.group(1) if subj_m else f"https://{host}/g/{group}/message/{msg_id}"

            # Author
            author_m = re.search(r'By\s*\n\s*([^\n&<]+)', content)
            author = author_m.group(1).strip() if author_m else ""

            # Timestamp (nanoseconds from epoch)
            date = ""
            time_m = re.search(r'DisplayShortTime\((\d+)', content)
            if time_m:
                try:
                    epoch_sec = int(time_m.group(1)) / 1e9
                    dt = datetime.datetime.fromtimestamp(epoch_sec, tz=datetime.timezone.utc)
                    date = dt.strftime("%Y-%m-%d")
                except (ValueError, OSError):
                    pass

            # Preview text
            preview_m = re.search(r'truncate-two-lines">\s*\n?\s*([^<]+)', content)
            preview = html.unescape(preview_m.group(1).strip()) if preview_m else ""

            results.append(PendingChange(
                id=msg_id,
                title=subject,
                author=author,
                date=date,
                url=link,
                provider_type="maillist",
                content=preview,
                msgid=msg_id,
                metadata={"group": group, "host": host},
            ))

        # Find next page token
        next_m = re.search(r'messages\?page=\d+&after=(\d+)', data)
        if not next_m:
            break
        url = f"{base_url}?page={page + 2}&after={next_m.group(1)}"

    return results


def _fetch_rss(host: str, group: str) -> List[PendingChange]:
    """Fetch recent messages from a groups.io RSS feed (fallback, 20 items max)."""
    url = f"https://{host}/g/{group}/rss"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "bit/1.0"})
        data = urllib.request.urlopen(req, timeout=15).read()
    except Exception:
        return []

    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return []

    results = []
    for item in root.findall(".//item"):
        title = item.findtext("title", "")
        link = item.findtext("link", "")
        pub_date = item.findtext("pubDate", "")
        description = item.findtext("description", "")

        # Parse date
        date_short = pub_date
        date_match = re.search(r'(\d{1,2})\s+(\w{3})\s+(\d{4})', pub_date)
        if date_match:
            date_short = f"{date_match.group(3)}-{date_match.group(2)}-{date_match.group(1)}"

        # Author field: "email@... (Display Name)"
        author_raw = item.findtext("author", "")
        author = ""
        if author_raw:
            name_match = re.search(r'\(([^)]+)\)', author_raw)
            if name_match:
                author = name_match.group(1).strip()
            else:
                author = author_raw.strip()

        msg_id = ""
        id_match = re.search(r'/message/(\d+)', link)
        if id_match:
            msg_id = id_match.group(1)

        content = _html_to_text(description)

        results.append(PendingChange(
            id=msg_id or link,
            title=title,
            author=author,
            date=date_short,
            url=link,
            provider_type="maillist",
            content=content,
            msgid=msg_id,
            metadata={"group": group, "host": host},
        ))

    return results


# =============================================================================
# Mailing List Provider
# =============================================================================

_MAILLIST_ACTIONS = [
    ("VIEW", "View message in pager"),
    ("OPEN", "Open in browser"),
    ("SUMMARIZE", "Summarize with AI"),
    ("COPY", "Copy URL to clipboard"),
]


class MaillistProvider(PendingChangeProvider):
    """Pending change provider for groups.io mailing lists via RSS."""
    provider_type = "maillist"

    def __init__(self, repo: str = "", host: str = "", group_name: str = ""):
        self.repo = repo
        self.host = host
        self.group_name = group_name

    def detect(self, repo: str, defaults: dict) -> bool:
        """Check if repo matches a known groups.io mailing list."""
        result = _detect_groupsio_list(repo)
        if result:
            self.host, self.group_name = result
            return True
        return False

    def search(self, query: str, **kwargs) -> List[PendingChange]:
        """Search is not supported without auth — return browse filtered."""
        results = self.browse(**kwargs)
        if query:
            q = query.lower()
            results = [r for r in results if q in r.title.lower()
                       or q in r.content.lower()
                       or q in r.author.lower()]
        return results

    def browse(self, **kwargs) -> List[PendingChange]:
        """Browse recent messages. Uses HTML scraping (paginated)
        enriched with RSS content (full body for 20 most recent).

        Pass max_pages kwarg to control how many pages to fetch (default 1).
        """
        if not self.host or not self.group_name:
            repo = kwargs.get("repo", self.repo)
            defaults = kwargs.get("defaults", {})
            result = _detect_groupsio_list(repo)
            if result:
                self.host, self.group_name = result
            else:
                return []

        max_pages = kwargs.get("max_pages", 1)

        # Get paginated list from HTML (subjects, authors, dates, previews)
        results = _fetch_messages_html(self.host, self.group_name, max_pages=max_pages)

        # Enrich with full content from RSS (20 most recent have full bodies)
        rss_results = _fetch_rss(self.host, self.group_name)
        rss_by_id = {r.id: r for r in rss_results}
        for r in results:
            rss = rss_by_id.get(r.id)
            if rss and rss.content:
                r.content = rss.content

        if results:
            return results
        # Fall back to RSS only
        return rss_results

    def group(self, results: List[PendingChange]) -> List[PendingChangeGroup]:
        """Group by thread — match subject lines (strip Re:/Fwd: and [tags])."""
        thread_map: Dict[str, List[PendingChange]] = {}
        thread_order: List[str] = []

        for r in results:
            # Normalize subject: strip Re:/Fwd: and leading [tags]
            subj = re.sub(r'^(Re|Fwd):\s*', '', r.title, flags=re.IGNORECASE)
            subj = re.sub(r'^\[[^\]]*\]\s*', '', subj)
            key = subj.strip().lower()
            if key not in thread_map:
                thread_map[key] = []
                thread_order.append(key)
            thread_map[key].append(r)

        groups = []
        for key in thread_order:
            members = thread_map[key]
            # Sort by date (oldest first)
            members.sort(key=lambda r: r.date)
            root = members[0]
            children = members[1:]
            groups.append(PendingChangeGroup(root=root, children=children))
        return groups

    def get_content(self, change: PendingChange) -> str:
        """Fetch full message content. Uses cached RSS content if available,
        otherwise fetches via HTMX endpoint on groups.io."""
        # Only skip fetch if content is clearly a full message (not a preview)
        if change.content and len(change.content) > 500:
            return change.content

        # Fetch full body via HTMX request
        host = change.metadata.get("host", self.host)
        group = change.metadata.get("group", self.group_name)
        msg_id = change.msgid or change.id
        if not host or not group or not msg_id:
            return change.content

        try:
            url = f"https://{host}/g/{group}/message/{msg_id}"
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
                "HX-Request": "true",
            })
            data = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", errors="replace")

            # Find the message body div
            body_m = re.search(r'class="user-content">\s*<div[^>]*>(.*?)</div>\s*</div>', data, re.DOTALL)
            if body_m:
                return _html_to_text(body_m.group(1))
        except Exception:
            pass

        return change.content

    def get_actions(self) -> List[Tuple[str, str]]:
        return list(_MAILLIST_ACTIONS)

    def execute_action(self, action: str, change: PendingChange,
                       repo: str, **kwargs) -> Optional[str]:
        """Execute mailing list actions."""
        import subprocess

        if action == "VIEW":
            pager = os.environ.get("PAGER", "less")
            content = f"Subject: {change.title}\nDate: {change.date}\nURL: {change.url}\n\n{change.content}"
            proc = subprocess.Popen([pager], stdin=subprocess.PIPE, text=True)
            proc.communicate(input=content)

        elif action == "OPEN":
            if change.url:
                for cmd in [["xdg-open"], ["open"]]:
                    try:
                        subprocess.run(cmd + [change.url],
                                       stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL)
                        break
                    except FileNotFoundError:
                        continue

        elif action == "COPY":
            url = change.url
            for cmd in [["xclip", "-selection", "clipboard"],
                        ["xsel", "--clipboard", "--input"],
                        ["wl-copy"], ["pbcopy"]]:
                try:
                    subprocess.run(cmd, input=url, text=True,
                                   stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL)
                    print(f"Copied: {url}")
                    break
                except FileNotFoundError:
                    continue
            else:
                print(f"URL: {url}")
            input("Press Enter to continue...")

        return None

    def format_fzf_line(self, change: PendingChange, index: int) -> str:
        """Format as mailing list line."""
        is_reply = bool(re.match(r'^(Re|Fwd):', change.title, re.IGNORECASE))
        if is_reply:
            title_str = Colors.DIM + change.title + Colors.RESET
        else:
            title_str = Colors.cyan(change.title)
        author = Colors.DIM + f"({change.author})" + Colors.RESET if change.author else ""
        return f"{index}\t{change.date}  {title_str}  {author}"

    def build_preview(self, change: PendingChange, preview_dir: str) -> str:
        """Write message content to preview file."""
        safe_id = re.sub(r'[^\w.-]', '_', change.id)[:60]
        preview_file = os.path.join(preview_dir, f"msg-{safe_id}.txt")
        try:
            with open(preview_file, "w") as f:
                f.write(f"Subject: {change.title}\n")
                if change.author:
                    f.write(f"From: {change.author}\n")
                f.write(f"Date: {change.date}\n")
                f.write(f"URL: {change.url}\n\n")
                f.write(change.content or "(no content)")
        except OSError:
            pass
        return f"cat '{preview_file}'"

    def get_description(self) -> str:
        return f"Mailing list: {self.group_name}@{self.host}" if self.group_name else "Mailing list"
