#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for the pending changes abstraction."""

import pytest
from unittest.mock import patch, MagicMock

from bitbake_project.commands.pending import (
    PendingChange,
    PendingChangeGroup,
    PendingChangeProvider,
    _is_github_repo,
    _get_github_owner_repo,
    detect_provider,
    get_pending_provider_config,
)


class TestPendingChange:
    """Tests for the PendingChange dataclass."""

    def test_basic_creation(self):
        pc = PendingChange(
            id="123", title="Fix bug", author="alice",
            date="2026-01-01", url="https://example.com",
            provider_type="github",
        )
        assert pc.id == "123"
        assert pc.title == "Fix bug"
        assert pc.provider_type == "github"
        assert pc.labels == []
        assert pc.ci_status == ""
        assert pc.pr_number == 0

    def test_github_fields(self):
        pc = PendingChange(
            id="42", title="Add feature", author="bob",
            date="2026-03-15", url="https://github.com/org/repo/pull/42",
            provider_type="github",
            labels=["enhancement", "needs-review"],
            ci_status="success",
            review_status="approved",
            pr_number=42,
        )
        assert pc.labels == ["enhancement", "needs-review"]
        assert pc.ci_status == "success"
        assert pc.review_status == "approved"
        assert pc.pr_number == 42

    def test_lore_fields(self):
        pc = PendingChange(
            id="20260101-patch@example.com", title="[PATCH] Fix foo",
            author="charlie", date="2026-01-01",
            url="https://lore.kernel.org/all/20260101-patch@example.com/",
            provider_type="lore",
            msgid="20260101-patch@example.com",
            series_tag="[PATCH 1/3]",
        )
        assert pc.msgid == "20260101-patch@example.com"
        assert pc.series_tag == "[PATCH 1/3]"

    def test_metadata_defaults_to_empty(self):
        pc = PendingChange(
            id="1", title="t", author="a", date="d", url="u",
            provider_type="test",
        )
        assert pc.metadata == {}


class TestPendingChangeGroup:
    """Tests for PendingChangeGroup."""

    def test_basic_group(self):
        root = PendingChange(
            id="1", title="Root", author="a", date="d", url="u",
            provider_type="test",
        )
        child = PendingChange(
            id="2", title="Child", author="b", date="d", url="u",
            provider_type="test",
        )
        g = PendingChangeGroup(root=root, children=[child])
        assert g.root.id == "1"
        assert len(g.children) == 1
        assert g.version is None
        assert g.total_parts is None

    def test_series_metadata(self):
        root = PendingChange(
            id="1", title="Root", author="a", date="d", url="u",
            provider_type="lore",
        )
        g = PendingChangeGroup(
            root=root, version=2, total_parts=5, received_parts=5,
        )
        assert g.version == 2
        assert g.total_parts == 5
        assert g.received_parts == 5


class TestProviderBase:
    """Tests for the PendingChangeProvider base class."""

    def test_default_group_creates_individual_groups(self):
        provider = PendingChangeProvider()
        changes = [
            PendingChange(id="1", title="A", author="a", date="d", url="u", provider_type="t"),
            PendingChange(id="2", title="B", author="b", date="d", url="u", provider_type="t"),
        ]
        groups = provider.group(changes)
        assert len(groups) == 2
        assert groups[0].root.id == "1"
        assert groups[1].root.id == "2"
        assert groups[0].children == []

    def test_default_format_fzf_line(self):
        provider = PendingChangeProvider()
        pc = PendingChange(
            id="1", title="Fix bug", author="alice", date="2026-01-01",
            url="u", provider_type="t",
        )
        line = provider.format_fzf_line(pc, 0)
        assert "0\t" in line
        assert "Fix bug" in line
        assert "alice" in line


class TestGitHubURLDetection:
    """Tests for GitHub URL parsing from git remotes."""

    @patch("subprocess.check_output")
    def test_https_url(self, mock_git):
        mock_git.return_value = "https://github.com/yoctoproject/poky.git\n"
        assert _is_github_repo("/fake/repo") is True

    @patch("subprocess.check_output")
    def test_ssh_url(self, mock_git):
        mock_git.return_value = "git@github.com:yoctoproject/poky.git\n"
        assert _is_github_repo("/fake/repo") is True

    @patch("subprocess.check_output")
    def test_non_github_url(self, mock_git):
        mock_git.return_value = "https://git.openembedded.org/openembedded-core\n"
        assert _is_github_repo("/fake/repo") is False

    @patch("subprocess.check_output")
    def test_gitlab_url(self, mock_git):
        mock_git.return_value = "https://gitlab.com/org/repo.git\n"
        assert _is_github_repo("/fake/repo") is False

    @patch("subprocess.check_output", side_effect=FileNotFoundError)
    def test_git_not_found(self, mock_git):
        assert _is_github_repo("/fake/repo") is False

    @patch("subprocess.check_output")
    def test_owner_repo_https(self, mock_git):
        mock_git.return_value = "https://github.com/yoctoproject/poky.git\n"
        assert _get_github_owner_repo("/fake") == "yoctoproject/poky"

    @patch("subprocess.check_output")
    def test_owner_repo_https_no_git_suffix(self, mock_git):
        mock_git.return_value = "https://github.com/org/repo\n"
        assert _get_github_owner_repo("/fake") == "org/repo"

    @patch("subprocess.check_output")
    def test_owner_repo_ssh(self, mock_git):
        mock_git.return_value = "git@github.com:owner/repo.git\n"
        assert _get_github_owner_repo("/fake") == "owner/repo"

    @patch("subprocess.check_output")
    def test_owner_repo_ssh_url(self, mock_git):
        mock_git.return_value = "ssh://git@github.com/owner/repo.git\n"
        assert _get_github_owner_repo("/fake") == "owner/repo"

    @patch("subprocess.check_output")
    def test_owner_repo_non_github(self, mock_git):
        mock_git.return_value = "https://gitlab.com/org/repo.git\n"
        assert _get_github_owner_repo("/fake") is None


class TestDetectProvider:
    """Tests for provider auto-detection."""

    @patch("subprocess.check_output")
    def test_lore_detection(self, mock_git):
        # Non-GitHub URL, but matches lore hint patterns
        mock_git.return_value = "https://git.openembedded.org/openembedded-core\n"
        provider = detect_provider("/fake/openembedded-core", {})
        # Should detect as lore (openembedded-core matches hints)
        if provider:
            assert provider.provider_type == "lore"

    def test_explicit_config_github(self):
        defaults = {
            "__pending_providers__": {
                "/fake/repo": {"provider_type": "github"}
            }
        }
        provider = detect_provider("/fake/repo", defaults)
        assert provider is not None
        assert provider.provider_type == "github"

    def test_explicit_config_lore(self):
        defaults = {
            "__pending_providers__": {
                "/fake/repo": {"provider_type": "lore"}
            }
        }
        provider = detect_provider("/fake/repo", defaults)
        assert provider is not None
        assert provider.provider_type == "lore"

    def test_no_provider(self):
        defaults = {}
        with patch("subprocess.check_output", return_value="https://internal.corp/repo.git\n"):
            provider = detect_provider("/fake/repo", defaults)
        # May be None or lore depending on hint matching
        if provider:
            assert provider.provider_type in ("lore", "github")

    def test_config_lookup(self):
        defaults = {
            "__pending_providers__": {
                "/path/a": {"provider_type": "github", "auto_detected": True},
                "/path/b": {"provider_type": "lore"},
            }
        }
        assert get_pending_provider_config(defaults, "/path/a")["provider_type"] == "github"
        assert get_pending_provider_config(defaults, "/path/b")["provider_type"] == "lore"
        assert get_pending_provider_config(defaults, "/path/c") is None
