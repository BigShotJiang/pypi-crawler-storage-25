#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for the GitHub PR provider."""

import json
import pytest
from unittest.mock import patch, MagicMock

from bitbake_project.commands.github_provider import (
    GitHubProvider,
    gh_available,
    _run_gh,
)
from bitbake_project.commands.pending import PendingChange


# Sample gh pr list JSON output
SAMPLE_PR_JSON = [
    {
        "number": 42,
        "title": "Add support for new board",
        "author": {"login": "alice"},
        "createdAt": "2026-03-15T10:30:00Z",
        "url": "https://github.com/org/repo/pull/42",
        "labels": [{"name": "enhancement"}, {"name": "board-support"}],
        "headRefName": "feature/new-board",
        "isDraft": False,
        "state": "OPEN",
        "statusCheckRollup": [
            {"conclusion": "SUCCESS", "state": ""},
            {"conclusion": "SUCCESS", "state": ""},
        ],
        "reviews": [],
        "reviewDecision": "APPROVED",
        "body": "This adds support for the new XYZ board.\n\n## Changes\n- Add machine config\n- Add BSP layer",
        "additions": 150,
        "deletions": 10,
        "changedFiles": 5,
    },
    {
        "number": 43,
        "title": "Fix CVE-2026-1234",
        "author": {"login": "bob"},
        "createdAt": "2026-03-16T08:00:00Z",
        "url": "https://github.com/org/repo/pull/43",
        "labels": [{"name": "security"}],
        "headRefName": "fix/cve-2026-1234",
        "isDraft": True,
        "state": "OPEN",
        "statusCheckRollup": [
            {"conclusion": "FAILURE", "state": ""},
        ],
        "reviews": [],
        "reviewDecision": "CHANGES_REQUESTED",
        "body": "Fix for CVE-2026-1234",
        "additions": 5,
        "deletions": 2,
        "changedFiles": 1,
    },
    {
        "number": 44,
        "title": "WIP: Upgrade to v3.0",
        "author": {"login": "charlie"},
        "createdAt": "2026-03-17T14:00:00Z",
        "url": "https://github.com/org/repo/pull/44",
        "labels": [],
        "headRefName": "upgrade/v3",
        "isDraft": False,
        "state": "OPEN",
        "statusCheckRollup": [
            {"conclusion": "", "state": "PENDING"},
        ],
        "reviews": [],
        "reviewDecision": "REVIEW_REQUIRED",
        "body": "",
        "additions": 0,
        "deletions": 0,
        "changedFiles": 0,
    },
]


class TestGhAvailable:
    """Tests for gh CLI availability detection."""

    @patch("shutil.which", return_value="/usr/bin/gh")
    @patch("subprocess.run")
    def test_available(self, mock_run, mock_which):
        mock_run.return_value = MagicMock(returncode=0)
        assert gh_available() is True

    @patch("shutil.which", return_value=None)
    def test_not_installed(self, mock_which):
        assert gh_available() is False

    @patch("shutil.which", return_value="/usr/bin/gh")
    @patch("subprocess.run")
    def test_not_authenticated(self, mock_run, mock_which):
        mock_run.return_value = MagicMock(returncode=1)
        assert gh_available() is False


class TestRunGh:
    """Tests for the gh CLI wrapper."""

    @patch("subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout='{"ok": true}')
        result = _run_gh(["pr", "list"])
        assert result == '{"ok": true}'

    @patch("subprocess.run")
    def test_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = _run_gh(["pr", "list"])
        assert result is None

    @patch("subprocess.run", side_effect=FileNotFoundError)
    def test_not_found(self, mock_run):
        result = _run_gh(["pr", "list"])
        assert result is None


class TestGitHubProviderParsing:
    """Tests for GitHub PR JSON parsing."""

    def setup_method(self):
        self.provider = GitHubProvider(repo="/fake/repo")
        self.provider._owner_repo = "org/repo"

    def test_parse_basic_pr(self):
        pr = SAMPLE_PR_JSON[0]
        change = self.provider._parse_pr(pr)
        assert change.id == "42"
        assert change.title == "Add support for new board"
        assert change.author == "alice"
        assert change.date == "2026-03-15"
        assert change.pr_number == 42
        assert change.provider_type == "github"
        assert change.url == "https://github.com/org/repo/pull/42"

    def test_parse_labels(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.labels == ["enhancement", "board-support"]

    def test_parse_ci_success(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.ci_status == "success"

    def test_parse_ci_failure(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[1])
        assert change.ci_status == "failure"

    def test_parse_ci_pending(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[2])
        assert change.ci_status == "pending"

    def test_parse_review_approved(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.review_status == "approved"

    def test_parse_review_changes_requested(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[1])
        assert change.review_status == "changes_requested"

    def test_parse_review_pending(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[2])
        assert change.review_status == "pending"

    def test_parse_draft(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[1])
        assert change.metadata["draft"] is True

    def test_parse_non_draft(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.metadata["draft"] is False

    def test_parse_stats(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.metadata["additions"] == 150
        assert change.metadata["deletions"] == 10
        assert change.metadata["changed_files"] == 5

    def test_parse_branch(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert change.metadata["branch"] == "feature/new-board"

    def test_parse_body(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        assert "new XYZ board" in change.content

    def test_parse_empty_body(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[2])
        assert change.content == ""

    def test_parse_no_checks(self):
        pr = dict(SAMPLE_PR_JSON[0])
        pr["statusCheckRollup"] = None
        change = self.provider._parse_pr(pr)
        assert change.ci_status == ""

    def test_parse_no_labels(self):
        pr = dict(SAMPLE_PR_JSON[0])
        pr["labels"] = None
        change = self.provider._parse_pr(pr)
        assert change.labels == []


class TestGitHubProviderFormatting:
    """Tests for fzf line formatting."""

    def setup_method(self):
        self.provider = GitHubProvider(repo="/fake/repo")
        self.provider._owner_repo = "org/repo"

    def test_format_fzf_line(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[0])
        line = self.provider.format_fzf_line(change, 0)
        assert "0\t" in line
        assert "#42" in line
        assert "Add support" in line
        assert "alice" in line

    def test_format_draft_indicator(self):
        change = self.provider._parse_pr(SAMPLE_PR_JSON[1])
        line = self.provider.format_fzf_line(change, 1)
        assert "(draft)" in line


class TestGitHubProviderGrouping:
    """Tests for PR grouping."""

    def setup_method(self):
        self.provider = GitHubProvider(repo="/fake/repo")

    def test_each_pr_is_own_group(self):
        changes = [
            PendingChange(id="1", title="PR1", author="a", date="d", url="u", provider_type="github"),
            PendingChange(id="2", title="PR2", author="b", date="d", url="u", provider_type="github"),
        ]
        groups = self.provider.group(changes)
        assert len(groups) == 2
        assert groups[0].root.id == "1"
        assert groups[1].root.id == "2"
        assert groups[0].children == []


class TestGitHubProviderActions:
    """Tests for action list."""

    def test_actions_include_essentials(self):
        provider = GitHubProvider()
        actions = provider.get_actions()
        action_keys = [k for k, _ in actions]
        assert "VIEW" in action_keys
        assert "CHECKOUT" in action_keys
        assert "MERGE" in action_keys
        assert "SUMMARIZE" in action_keys
        assert "COPY" in action_keys

    def test_actions_have_labels(self):
        provider = GitHubProvider()
        for key, label in provider.get_actions():
            assert key
            assert label


class TestGitHubProviderDetect:
    """Tests for GitHub provider detection."""

    @patch("subprocess.check_output")
    @patch("shutil.which", return_value="/usr/bin/gh")
    @patch("subprocess.run")
    def test_detect_github_repo(self, mock_run, mock_which, mock_git):
        mock_git.return_value = "https://github.com/org/repo.git\n"
        mock_run.return_value = MagicMock(returncode=0)  # gh auth status
        provider = GitHubProvider()
        assert provider.detect("/fake/repo", {}) is True

    @patch("subprocess.check_output")
    def test_detect_non_github(self, mock_git):
        mock_git.return_value = "https://git.openembedded.org/repo\n"
        provider = GitHubProvider()
        assert provider.detect("/fake/repo", {}) is False

    def test_description(self):
        provider = GitHubProvider()
        provider._owner_repo = "org/repo"
        assert "org/repo" in provider.get_description()

    @patch("subprocess.check_output")
    def test_browse_returns_empty_without_owner_repo(self, mock_git):
        mock_git.side_effect = FileNotFoundError
        provider = GitHubProvider(repo="/nonexistent")
        results = provider.browse()
        assert results == []
