cdef class MorphotacticEngine:

    pass