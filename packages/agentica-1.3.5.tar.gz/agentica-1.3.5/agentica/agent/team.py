# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description: Team collaboration and transfer methods for Agent.

This module contains methods for team management, task transfer,
and tool retrieval. Uses clone() per call to prevent concurrent
state corruption, and when_to_use for improved LLM routing.
"""

import json
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Union,
)

from agentica.utils.log import logger
from agentica.tools.base import ModelTool, Tool, Function


def _serialize_content(content: Any) -> str:
    """Serialize agent response content to string.

    Handles Pydantic models, lists of Pydantic models, dicts, and plain values.
    """
    if isinstance(content, str):
        return content

    if hasattr(content, 'model_dump'):
        return json.dumps(content.model_dump(), ensure_ascii=False, default=str)

    if isinstance(content, (list, tuple)):
        items = [i.model_dump() if hasattr(i, 'model_dump') else i for i in content]
        return json.dumps(items, ensure_ascii=False, default=str)

    return json.dumps(content, ensure_ascii=False, default=str)


class TeamMixin:
    """Mixin class containing team and tool methods for Agent."""

    def as_tool(
        self,
        tool_name: Optional[str] = None,
        tool_description: Optional[str] = None,
        custom_output_extractor: Optional[Callable] = None,
    ) -> Function:
        """Convert this Agent to a Function that can be used by other agents.

        Args:
            tool_name: The name of the tool. Defaults to snake_case of agent name or 'agent_{id}'.
            tool_description: The tool description. Defaults to when_to_use or description.
            custom_output_extractor: Optional function to extract output from RunResponse.

        Returns:
            A Function instance that wraps this agent.
        """
        # Generate tool name
        if tool_name:
            name = tool_name
        elif self.name:
            name = self.name.lower().replace(' ', '_').replace('-', '_')
        else:
            name = f"agent_{self.agent_id[:8]}"

        # Generate description: prefer tool_description > when_to_use > description > role
        description = (
            tool_description
            or self.when_to_use
            or self.description
            or self.prompt_config.role
            or f"Run the {name} agent."
        )

        agent_self = self

        async def agent_entrypoint(message: str) -> str:
            """Run the agent with the given message and return the response."""
            clone = agent_self.clone()
            response = await clone.run(message)

            if custom_output_extractor and response:
                return custom_output_extractor(response)

            if response and response.content:
                return _serialize_content(response.content)
            return "No response from agent."

        return Function(
            name=name,
            description=description,
            entrypoint=agent_entrypoint,
        )

    def get_transfer_function(self) -> Function:
        """Get a function to transfer tasks to this agent.

        Returns:
            A Function instance that can transfer tasks to this agent.
        """
        agent_name = self.name or "agent"
        agent_description = (
            self.when_to_use
            or self.description
            or self.prompt_config.role
            or f"Transfer task to {agent_name}"
        )

        agent_self = self

        async def transfer_to_agent(task: str) -> str:
            """Transfer a task to this agent.

            Args:
                task: The task description to transfer.

            Returns:
                The response from the agent.
            """
            # Lifecycle: agent transfer hook
            caller = agent_self._transfer_caller
            if caller is not None and hasattr(caller, '_run_hooks') and caller._run_hooks is not None:
                await caller._run_hooks.on_agent_transfer(from_agent=caller, to_agent=agent_self)

            logger.info(f"Transferring task to {agent_name}: {task}")
            clone = agent_self.clone()
            response = await clone.run(message=task)

            if response and response.content:
                return _serialize_content(response.content)
            return "No response from agent"

        return Function(
            name=f"transfer_to_{agent_name.lower().replace(' ', '_')}",
            description=agent_description,
            entrypoint=transfer_to_agent,
        )

    def get_transfer_prompt(self) -> str:
        """Get prompt for transferring tasks to team members.

        Returns:
            A string with instructions for task transfer.
        """
        if not self.has_team():
            return ""

        transfer_prompt = "\n## Task Transfer\n"
        transfer_prompt += "You can transfer tasks to the following team members:\n"

        for member in self.team:
            member_name = member.name or "unnamed_agent"
            member_desc = (
                member.when_to_use
                or member.prompt_config.role
                or member.description
                or "No description"
            )
            transfer_prompt += f"- **{member_name}**: {member_desc}\n"

        transfer_prompt += "\nUse the appropriate transfer function to delegate tasks to team members.\n"
        return transfer_prompt

    def get_tools(self) -> Optional[List[Union[ModelTool, Tool, Callable, Dict, Function]]]:
        """Get all tools available to this agent.

        This includes:
        - User-provided tools
        - Default tools (chat history, knowledge base search, etc.)
        - Team transfer functions (if enabled)

        Returns:
            A list of tools, or None if no tools are available.
        """
        tools: List[Union[ModelTool, Tool, Callable, Dict, Function]] = []

        # Add user-provided tools
        if self.tools is not None:
            tools.extend(self.tools)

        # Add default tools based on settings
        # (knowledge and team transfer tools; history tools removed — history is in context)
        if self.knowledge is not None:
            if self.tool_config.search_knowledge:
                tools.append(self.search_knowledge_base)

            if self.tool_config.update_knowledge:
                tools.append(self.add_to_knowledge)

        # Add team transfer functions if team is present and transfer instructions are enabled
        if self.has_team() and self.team_config.add_transfer_instructions:
            for member in self.team:
                # Set caller reference for lifecycle hooks
                member._transfer_caller = self
                transfer_func = member.get_transfer_function()
                tools.append(transfer_func)

        return tools if len(tools) > 0 else []
