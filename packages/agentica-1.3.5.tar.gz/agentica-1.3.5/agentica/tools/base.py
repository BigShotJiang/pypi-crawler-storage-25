# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description:
This module provides classes for managing tools.
It includes an abstract base class for tools and a class for managing tool instances.
"""

import asyncio
import inspect
import json
import weakref
from collections import OrderedDict
from typing import Callable, get_type_hints, Any, Dict, Union, Optional, Type, TypeVar, List
from pydantic import BaseModel, Field, validate_call
from agentica.model.message import Message
from agentica.utils.log import logger

T = TypeVar("T")


class ToolCallException(Exception):
    def __init__(
            self,
            exc,
            user_message: Optional[Union[str, Message]] = None,
            agent_message: Optional[Union[str, Message]] = None,
            messages: Optional[List[Union[dict, Message]]] = None,
            stop_execution: bool = False,
    ):
        super().__init__(exc)
        self.user_message = user_message
        self.agent_message = agent_message
        self.messages = messages
        self.stop_execution = stop_execution


class RetryAgentRun(ToolCallException):
    """Exception raised when a tool call should be retried."""


class StopAgentRun(ToolCallException):
    """Exception raised when an agent should stop executing entirely."""

    def __init__(
            self,
            exc,
            user_message: Optional[Union[str, Message]] = None,
            agent_message: Optional[Union[str, Message]] = None,
            messages: Optional[List[Union[dict, Message]]] = None,
    ):
        super().__init__(
            exc, user_message=user_message, agent_message=agent_message, messages=messages, stop_execution=True
        )


def _safe_validate_call(c: Callable) -> Callable:
    """Wrap validate_call, stripping unresolvable forward-reference annotations.

    Pydantic's validate_call internally calls get_type_hints(), which tries to
    eval string annotations like ``self: "Agent"``. If the referenced class isn't
    importable in the function's module namespace, it raises NameError.

    Fix: remove such annotations from __annotations__ before validation. We only
    strip ``self`` (mixin methods) — other forward refs should be fixed at source.
    """
    # Handle bound methods - need to access underlying function via __func__
    func = c.__func__ if inspect.ismethod(c) else c
    annotations = getattr(func, "__annotations__", None)
    if annotations and "self" in annotations and isinstance(annotations["self"], str):
        # Don't mutate the original — copy annotations dict
        func.__annotations__ = {k: v for k, v in annotations.items() if k != "self"}
    return validate_call(c)


class Function(BaseModel):
    """Model for storing functions that can be called by an agent."""

    # The name of the function to be called.
    # Must be a-z, A-Z, 0-9, or contain underscores and dashes, with a maximum length of 64.
    name: str
    # A description of what the function does, used by the model to choose when and how to call the function.
    description: Optional[str] = None
    # The parameters the functions accepts, described as a JSON Schema object.
    # To describe a function that accepts no parameters, provide the value {"type": "object", "properties": {}}.
    parameters: Dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "properties": {}},
        description="JSON Schema object describing function parameters",
    )
    strict: Optional[bool] = None

    # The function to be called.
    entrypoint: Optional[Callable] = None
    # If True, the entrypoint processing is skipped and the Function is used as is.
    skip_entrypoint_processing: bool = False
    # If True, the arguments are sanitized before being passed to the function.
    sanitize_arguments: bool = True
    # If True, the function call will show the result along with sending it to the model.
    show_result: bool = False
    # If True, the agent will stop after the function call.
    stop_after_tool_call: bool = False
    # Hook that runs before the function is executed.
    # If defined, can accept the FunctionCall instance as a parameter.
    pre_hook: Optional[Callable] = None
    # Hook that runs after the function is executed, regardless of success/failure.
    # If defined, can accept the FunctionCall instance as a parameter.
    post_hook: Optional[Callable] = None
    # If True, this tool may execute concurrently with other concurrency_safe tools.
    # Read-only tools (read_file, glob, grep, web_search, fetch_url …) should be True.
    # Write/shell tools (execute, write_file, edit_file …) must remain False (default).
    # Mirrors CC's StreamingToolExecutor.isConcurrencySafe flag.
    concurrency_safe: bool = False
    # If True, the tool only reads data and never modifies state.
    # Used by permission systems to skip confirmation for safe operations.
    is_read_only: bool = False
    # If True, the tool performs irreversible operations (delete, overwrite, send, execute).
    # Used by permission systems to require extra caution or user confirmation.
    is_destructive: bool = False
    # Maximum result size (chars) before persisting to disk.
    # None = never persist (e.g. read_file — avoids reading its own persisted file).
    # Set a positive int to enable (e.g. 50_000 for execute/bash tools).
    # Mirrors CC's toolResultStorage maxResultSizeChars.
    max_result_size_chars: Optional[int] = None
    # Execution timeout in seconds. None = use default (120s).
    # Each tool invocation is wrapped with asyncio.wait_for(timeout=).
    timeout: Optional[int] = None
    # If True, the tool handles its own timeout internally (e.g. execute tool).
    # The outer asyncio.wait_for wrapper in Model.run_function_calls is skipped.
    manages_own_timeout: bool = False
    # Optional input validator called BEFORE execution.
    # Signature: (arguments: Dict[str, Any]) -> Optional[str]
    # Return None = valid; return error string = reject (skip execution, return as tool error).
    # Mirrors CC's validateInput() layer that runs before checkPermissions().
    validate_input: Optional[Callable] = None
    # Interrupt behavior when user cancels during tool execution.
    # "cancel" = tool can be cleanly terminated mid-execution (e.g. shell commands).
    # "block"  = tool must complete before honoring cancellation (e.g. agent delegation).
    # Mirrors CC's interruptBehavior() declaration.
    interrupt_behavior: str = "cancel"  # "cancel" | "block"
    # If True, tool description is NOT sent to LLM by default.
    # The tool can be discovered via a tool_search mechanism and loaded on demand.
    # Reduces per-call token cost when many tools are registered.
    # Mirrors CC's shouldDefer / isDeferredTool pattern.
    deferred: bool = False
    # Optional availability check. If set, called before including this tool
    # in the LLM schema. Return True = available, False = skip.
    # Used for tools that require API keys, specific platforms, etc.
    # Pattern borrowed from hermes-agent ToolRegistry.check_fn.
    available_when: Optional[Callable[[], bool]] = None

    # --*-- FOR INTERNAL USE ONLY --*--
    # Weak reference to the agent that the function is associated with.
    # Using weakref to avoid circular references that prevent garbage collection.
    # The reference chain Agent -> Model -> functions -> Function._agent -> Agent
    # would cause memory leaks without weakref.
    _agent_ref: Optional[weakref.ReferenceType] = None

    @property
    def _agent(self) -> Optional[Any]:
        """Get the agent from weak reference. Returns None if agent was garbage collected."""
        if self._agent_ref is not None:
            return self._agent_ref()
        return None

    @_agent.setter
    def _agent(self, agent: Optional[Any]) -> None:
        """Set the agent as a weak reference to avoid circular references."""
        if agent is not None:
            self._agent_ref = weakref.ref(agent)
        else:
            self._agent_ref = None

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump(exclude_none=True, include={"name", "description", "parameters", "strict"})

    def is_available(self) -> bool:
        """Check if this tool is currently available.

        If available_when is set, calls it and returns the result.
        If available_when is None, the tool is always available.
        Exceptions in available_when are caught and treated as unavailable.
        """
        if self.available_when is None:
            return True
        try:
            return bool(self.available_when())
        except Exception:
            return False

    @staticmethod
    def _parse_parameters(entrypoint: Callable, strict: bool = False) -> Dict[str, Any]:
        """Parse callable's type hints into JSON Schema parameters.

        Shared logic for from_callable() and process_entrypoint().
        """
        from inspect import signature
        from agentica.utils.json_util import get_json_schema

        parameters: Dict[str, Any] = {"type": "object", "properties": {}, "required": []}
        sig = signature(entrypoint)
        try:
            type_hints = get_type_hints(entrypoint)
        except NameError:
            type_hints = {}

        if "agent" in sig.parameters:
            type_hints.pop("agent", None)

        param_type_hints = {
            name: type_hints[name]
            for name in sig.parameters
            if name in type_hints and name != "return" and name != "agent"
        }
        parameters = get_json_schema(type_hints=param_type_hints, strict=strict)

        if strict:
            parameters["required"] = [name for name in parameters["properties"] if name != "agent"]
        else:
            parameters["required"] = [
                name
                for name, param in sig.parameters.items()
                if param.default == param.empty and name != "self" and name != "agent"
            ]
        return parameters

    @classmethod
    def from_callable(cls, c: Callable, strict: bool = False) -> "Function":
        from inspect import getdoc

        function_name = c.__name__
        try:
            parameters = cls._parse_parameters(c, strict=strict)
        except Exception as e:
            logger.warning(f"Could not parse args for {function_name}: {e}", exc_info=True)
            parameters = {"type": "object", "properties": {}, "required": []}

        # Check for @tool decorator metadata
        metadata = getattr(c, "_tool_metadata", None)
        if metadata:
            return cls(
                name=metadata["name"],
                description=metadata.get("description") or getdoc(c),
                parameters=parameters,
                entrypoint=_safe_validate_call(c),
                show_result=metadata.get("show_result", False),
                sanitize_arguments=metadata.get("sanitize_arguments", True),
                stop_after_tool_call=metadata.get("stop_after_tool_call", False),
                concurrency_safe=metadata.get("concurrency_safe", False),
                is_read_only=metadata.get("is_read_only", False),
                is_destructive=metadata.get("is_destructive", False),
                deferred=metadata.get("deferred", False),
                interrupt_behavior=metadata.get("interrupt_behavior", "cancel"),
                available_when=metadata.get("available_when", None),
            )

        return cls(
            name=function_name,
            description=getdoc(c),
            parameters=parameters,
            entrypoint=_safe_validate_call(c),
        )

    def process_entrypoint(self, strict: bool = False):
        """Process the entrypoint and make it ready for use by an agent."""
        from inspect import getdoc
        if self.skip_entrypoint_processing:
            return
        if self.entrypoint is None:
            return

        try:
            self.parameters = self._parse_parameters(self.entrypoint, strict=strict)
        except Exception as e:
            logger.warning(f"Could not parse args for {self.name}: {e}", exc_info=True)

        self.description = getdoc(self.entrypoint) or self.description
        self.entrypoint = _safe_validate_call(self.entrypoint)

    def get_type_name(self, t: Type[T]):
        name = str(t)
        if "list" in name or "dict" in name:
            return name
        else:
            return t.__name__

    def get_definition_for_prompt_dict(self) -> Optional[Dict[str, Any]]:
        """Returns a function definition that can be used in a prompt."""

        if self.entrypoint is None:
            return None

        try:
            type_hints = get_type_hints(self.entrypoint)
        except NameError:
            type_hints = {}
        return_type = type_hints.get("return", None)
        returns = None
        if return_type is not None:
            returns = self.get_type_name(return_type)

        function_info = {
            "name": self.name,
            "description": self.description,
            "arguments": self.parameters.get("properties", {}),
            "returns": returns,
        }
        return function_info

    def get_definition_for_prompt(self) -> Optional[str]:
        """Returns a function definition that can be used in a prompt."""
        import json

        function_info = self.get_definition_for_prompt_dict()
        if function_info is not None:
            return json.dumps(function_info, indent=2)
        return None


class FunctionCall(BaseModel):
    """Model for Function Calls"""

    # The function to be called.
    function: Function
    # The arguments to call the function with.
    arguments: Optional[Dict[str, Any]] = None
    # The result of the function call.
    result: Optional[Any] = None
    # The ID of the function call.
    call_id: Optional[str] = None

    # Error while parsing arguments or running the function.
    error: Optional[str] = None

    def get_call_str(self) -> str:
        """Returns a string representation of the function call."""
        if self.arguments is None:
            return f"{self.function.name}()"

        trimmed_arguments = {}
        for k, v in self.arguments.items():
            if isinstance(v, str) and len(v) > 100:
                trimmed_arguments[k] = "..."
            else:
                trimmed_arguments[k] = v
        call_str = f"{self.function.name}({', '.join([f'{k}={v}' for k, v in trimmed_arguments.items()])})"
        return call_str

    async def _call_func(self, func: Callable, **kwargs) -> Any:
        """Call a function, auto-detecting sync/async.

        Async functions are awaited directly.
        Sync functions run in a thread pool to avoid blocking the event loop.
        """
        import functools
        if inspect.iscoroutinefunction(func):
            return await func(**kwargs)
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, functools.partial(func, **kwargs)
        )

    def _build_args(self, func: Callable) -> Dict[str, Any]:
        """Build agent/fc args for a callable based on its signature."""
        from inspect import signature
        args = {}
        params = signature(func).parameters
        if "agent" in params:
            args["agent"] = self.function._agent
        if "fc" in params:
            args["fc"] = self
        return args

    async def _run_hook(self, hook: Optional[Callable]) -> None:
        """Execute a pre/post hook if it exists."""
        if hook is None:
            return
        hook_args = self._build_args(hook)
        try:
            await self._call_func(hook, **hook_args)
        except ToolCallException:
            raise
        except Exception as e:
            logger.warning(f"Error in hook callback: {e}")
            logger.exception(e)

    async def execute(self) -> bool:
        """Execute the function (async-first, single implementation).

        Supports both sync and async entrypoints:
        - async entrypoint -> awaited directly
        - sync entrypoint -> executed in thread pool via run_in_executor

        Returns:
            bool: True if the function call was successful, False otherwise.
        """
        if self.function.entrypoint is None:
            self.error = f"No entrypoint found for function: {self.function.name}"
            logger.warning(self.error)
            return False

        logger.debug(f"Running: {self.get_call_str()}")

        # Input validation — runs BEFORE pre_hook and execution.
        # Mirrors CC's validateInput() → checkPermissions() → call() pipeline.
        if self.function.validate_input is not None:
            try:
                validation_error = self.function.validate_input(self.arguments or {})
                if validation_error is not None:
                    self.error = f"Input validation failed: {validation_error}"
                    logger.debug(f"validate_input rejected {self.function.name}: {validation_error}")
                    return False
            except Exception as ve:
                self.error = f"Input validation error: {ve}"
                return False

        # Pre-hook
        await self._run_hook(self.function.pre_hook)

        # Build entrypoint args
        entrypoint_args = self._build_args(self.function.entrypoint)
        if self.arguments is not None:
            entrypoint_args.update(self.arguments)

        # Execute the function
        try:
            self.result = await self._call_func(self.function.entrypoint, **entrypoint_args)
            function_call_success = True
        except ToolCallException as e:
            logger.debug(f"{e.__class__.__name__}: {e}")
            self.error = str(e)
            raise
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.warning(f"Could not run function {self.get_call_str()}")
            logger.exception(e)
            self.error = str(e)
            return False

        # Post-hook
        await self._run_hook(self.function.post_hook)

        return function_call_success


class ModelTool(BaseModel):
    """Model for Tools"""

    # The type of tool
    type: str
    # The function to be called if type = "function"
    function: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump(exclude_none=True)


def get_function_call(
        name: str,
        arguments: Optional[str] = None,
        call_id: Optional[str] = None,
        functions: Optional[Dict[str, Function]] = None,
) -> Optional[FunctionCall]:
    # logger.debug(f"Getting function {name}")
    # logger.debug(f"Arguments: {arguments}, Call ID: {call_id}, name: {name}, functions: {functions}")
    if functions is None:
        return None

    function_to_call: Optional[Function] = None
    if name in functions:
        function_to_call = functions[name]
    if function_to_call is None:
        logger.error(f"Function {name} not found")
        return None

    function_call = FunctionCall(function=function_to_call)
    if call_id is not None:
        function_call.call_id = call_id
    if arguments is not None and arguments != "":
        try:
            if function_to_call.sanitize_arguments:
                if "None" in arguments:
                    arguments = arguments.replace("None", "null")
                if "True" in arguments:
                    arguments = arguments.replace("True", "true")
                if "False" in arguments:
                    arguments = arguments.replace("False", "false")
            _arguments = json.loads(arguments)
        except Exception as e:
            logger.error(f"Unable to decode function arguments:\n{arguments}\nError: {e}")
            function_call.error = f"Error while decoding function arguments:\n{arguments}\nError: {e}\n\n " \
                                  f"Please make sure we can json.loads() the arguments and retry."
            return function_call

        if not isinstance(_arguments, dict):
            logger.error(f"Function arguments are not a valid JSON object: {arguments}")
            function_call.error = "Function arguments are not a valid JSON object.\n\n Please fix and retry."
            return function_call

        try:
            clean_arguments: Dict[str, Any] = {}
            for k, v in _arguments.items():
                if isinstance(v, str):
                    _v = v.strip().lower()
                    if _v in ("none", "null"):
                        clean_arguments[k] = None
                    elif _v == "true":
                        clean_arguments[k] = True
                    elif _v == "false":
                        clean_arguments[k] = False
                    else:
                        clean_arguments[k] = v.strip()
                else:
                    clean_arguments[k] = v

            function_call.arguments = clean_arguments
        except Exception as e:
            logger.error(f"Unable to parsing function arguments:\n{arguments}\nError: {e}")
            function_call.error = f"Error while parsing function arguments: {e}\n\n Please fix and retry."
            return function_call
    return function_call


def get_function_call_for_tool_call(
        tool_call: Dict[str, Any], functions: Optional[Dict[str, Function]] = None
) -> Optional[FunctionCall]:
    if tool_call.get("type") == "function":
        _tool_call_id = tool_call.get("id")
        _tool_call_function = tool_call.get("function")
        if _tool_call_function is not None:
            _tool_call_function_name = _tool_call_function.get("name")
            _tool_call_function_arguments_str = _tool_call_function.get("arguments")
            if _tool_call_function_name is not None:
                return get_function_call(
                    name=_tool_call_function_name,
                    arguments=_tool_call_function_arguments_str,
                    call_id=_tool_call_id,
                    functions=functions,
                )
    return None


def extract_tool_call_from_string(text: str, start_tag: str = "<tool_call>", end_tag: str = "</tool_call>"):
    start_index = text.find(start_tag) + len(start_tag)
    end_index = text.find(end_tag)

    # Extracting the content between the tags
    return text[start_index:end_index].strip()


def remove_tool_calls_from_string(text: str, start_tag: str = "<tool_call>", end_tag: str = "</tool_call>"):
    """Remove multiple tool calls from a string."""
    while start_tag in text and end_tag in text:
        start_index = text.find(start_tag)
        end_index = text.find(end_tag) + len(end_tag)
        text = text[:start_index] + text[end_index:]
    return text


def extract_tool_from_xml(xml_str):
    # Find tool_name
    tool_name_start = xml_str.find("<tool_name>") + len("<tool_name>")
    tool_name_end = xml_str.find("</tool_name>")
    tool_name = xml_str[tool_name_start:tool_name_end].strip()

    # Find and process parameters block
    params_start = xml_str.find("<parameters>") + len("<parameters>")
    params_end = xml_str.find("</parameters>")
    parameters_block = xml_str[params_start:params_end].strip()

    # Extract individual parameters
    arguments = {}
    while parameters_block:
        # Find the next tag and its closing
        tag_start = parameters_block.find("<") + 1
        tag_end = parameters_block.find(">")
        tag_name = parameters_block[tag_start:tag_end]

        # Find the tag's closing counterpart
        value_start = tag_end + 1
        value_end = parameters_block.find(f"</{tag_name}>")
        value = parameters_block[value_start:value_end].strip()

        # Add to arguments
        arguments[tag_name] = value

        # Move past this tag
        parameters_block = parameters_block[value_end + len(f"</{tag_name}>"):].strip()

    return {"tool_name": tool_name, "parameters": arguments}


def remove_function_calls_from_string(
        text: str, start_tag: str = "<function_calls>", end_tag: str = "</function_calls>"
):
    """Remove multiple function calls from a string."""
    while start_tag in text and end_tag in text:
        start_index = text.find(start_tag)
        end_index = text.find(end_tag) + len(end_tag)
        text = text[:start_index] + text[end_index:]
    return text


class Tool:
    """Tool for managing functions."""

    def __init__(self, name: str = "tool", description: str = ""):
        self.name: str = name
        self.description = description
        self.functions: Dict[str, Function] = OrderedDict()

    def register(self, function: Callable[..., Any], sanitize_arguments: bool = True,
                 concurrency_safe: bool = False, is_read_only: bool = False,
                 is_destructive: bool = False,
                 available_when: Optional[Callable[[], bool]] = None):
        """Register a function with the toolkit.

        Args:
            function:           The callable to register.
            sanitize_arguments: If True, the arguments will be sanitized before
                                being passed to the function.
            concurrency_safe:   If True the function may run concurrently with other
                                concurrency_safe tools (e.g. read_file, glob).
            is_read_only:       If True, the function only reads data and never modifies state.
            is_destructive:     If True, the function performs irreversible operations.
            available_when:     Optional callback that returns True when the tool
                                should be exposed to the LLM.

        Returns:
            The registered function
        """
        try:
            f = Function(
                name=function.__name__,
                description=function.__doc__ or self.description,
                entrypoint=function,
                sanitize_arguments=sanitize_arguments,
                concurrency_safe=concurrency_safe,
                is_read_only=is_read_only,
                is_destructive=is_destructive,
                available_when=available_when,
            )
            self.functions[f.name] = f
        except Exception as e:
            logger.warning(f"Failed to create Function for: {function.__name__}")
            raise e

    def get_system_prompt(self) -> Optional[str]:
        """Get the system prompt to inject for this tool.

        Override this method in subclasses to provide tool-specific system prompts
        that guide the LLM on how to use the tool effectively.

        Returns:
            Optional[str]: The system prompt string, or None if no prompt is needed.
        """
        return None

    def __repr__(self):
        return f"<{self.__class__.__name__} name={self.name} functions={list(self.functions.keys())}>"

    def __str__(self):
        return self.__repr__()
