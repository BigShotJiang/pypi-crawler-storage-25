"""Vigil Client — Python SDK for Vigil Cloud.

Connect your AI agents to Vigil Cloud in 3 lines:

    from vigil_client import Vigil

    v = Vigil(api_key="vgl_...")
    v.signal("deploy complete", agent="my-bot")
    context = v.boot()
"""

from vigil_client.client import Vigil, VigilError

__version__ = "0.1.0"
__all__ = ["Vigil", "VigilError"]
