"""Vigil Cloud client — thin wrapper around the hosted REST API."""

import os
from typing import Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json


DEFAULT_URL = "https://app.vigil-agent.com"


class VigilError(Exception):
    """Error from the Vigil API."""
    def __init__(self, status: int, detail: str):
        self.status = status
        self.detail = detail
        super().__init__(f"Vigil API error {status}: {detail}")


class Vigil:
    """Client for Vigil Cloud.

    Args:
        api_key: Your Vigil API key (vgl_...). Also reads VIGIL_API_KEY env var.
        base_url: API base URL. Defaults to https://app.vigil-agent.com.
                  Also reads VIGIL_API_URL env var.

    Usage:
        v = Vigil(api_key="vgl_...")
        v.signal("starting work", agent="my-agent")
        context = v.boot()
        v.handoff(agent="my-agent", summary="finished task", files=["app.py"])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.api_key = api_key or os.environ.get("VIGIL_API_KEY", "")
        self.base_url = (base_url or os.environ.get("VIGIL_API_URL", DEFAULT_URL)).rstrip("/")

        if not self.api_key:
            raise VigilError(0, "No API key provided. Pass api_key= or set VIGIL_API_KEY env var.")

    def _request(self, method: str, path: str, body: dict = None) -> dict:
        """Make an authenticated API request. Uses only stdlib (no dependencies)."""
        url = f"{self.base_url}/api{path}"
        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", f"vigil-client/0.1.0")

        try:
            with urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except HTTPError as e:
            detail = e.read().decode() if e.fp else str(e)
            try:
                detail = json.loads(detail).get("detail", detail)
            except (json.JSONDecodeError, AttributeError):
                pass
            raise VigilError(e.code, detail) from None

    # ── Core Methods ─────────────────────────────────────────

    def signal(
        self,
        content: str,
        agent: str = "default",
        signal_type: str = "observation",
        to_agent: Optional[str] = None,
    ) -> dict:
        """Emit a signal.

        Args:
            content: Signal content (300-800 chars recommended)
            agent: Agent name emitting the signal
            signal_type: observation, decision, alert, or request
            to_agent: Optional target agent

        Returns:
            {"signal_id": int, "type": str, "chars": int, "budget": int}
        """
        body = {
            "agent": agent,
            "content": content,
            "signal_type": signal_type,
        }
        if to_agent:
            body["to_agent"] = to_agent
        return self._request("POST", "/signal", body)

    def boot(self) -> dict:
        """Boot with pre-compiled awareness context.

        Returns:
            {"frame": str, "awareness": str, "focus": list, "recent_signals": int, ...}
        """
        return self._request("GET", "/boot")

    def compile(self) -> dict:
        """Force a fresh awareness compilation.

        Returns:
            Compiled context dict
        """
        return self._request("POST", "/compile")

    def status(self) -> dict:
        """Get current awareness state.

        Returns:
            {"summary": str, "updated_at": str, "updated_by": str}
        """
        return self._request("GET", "/status")

    def signals(self, hours: int = 1, limit: int = 10, agent: str = "") -> list:
        """Read recent signals.

        Args:
            hours: Time window (1-168)
            limit: Max signals to return (1-100)
            agent: Filter by agent name

        Returns:
            List of signal dicts
        """
        params = f"?hours={hours}&limit={limit}"
        if agent:
            params += f"&agent={agent}"
        return self._request("GET", f"/signals{params}")

    # ── Session Management ───────────────────────────────────

    def handoff(
        self,
        agent: str,
        summary: str,
        files: list[str] = None,
        decisions: list[str] = None,
        next_steps: list[str] = None,
    ) -> dict:
        """End a session with a structured handoff.

        Args:
            agent: Agent ending the session
            summary: What was accomplished
            files: Files touched during session
            decisions: Key decisions made
            next_steps: What the next agent should do

        Returns:
            {"handoff_id": int, "status": "handed_off", "summary_chars": int}
        """
        return self._request("POST", "/handoff", {
            "agent": agent,
            "summary": summary,
            "files_touched": files or [],
            "decisions": decisions or [],
            "next_steps": next_steps or [],
        })

    def resume(self, agent: str = "") -> dict:
        """Resume from the last session's handoff.

        Args:
            agent: Agent resuming (optional)

        Returns:
            Handoff context dict
        """
        return self._request("POST", "/resume", {"agent": agent or "unknown"})

    def chain(self, limit: int = 3) -> dict:
        """Get a briefing of the last N handoffs.

        Returns:
            {"briefing": list}
        """
        return self._request("GET", f"/chain?limit={limit}")

    # ── Focus ────────────────────────────────────────────────

    def focus_add(self, description: str, priority: int = 5, owner: str = None) -> dict:
        """Add a focus item."""
        body = {"description": description, "priority": priority}
        if owner:
            body["owner"] = owner
        return self._request("POST", "/focus", body)

    def focus_list(self) -> list:
        """List active focus items."""
        return self._request("GET", "/focus")

    def focus_complete(self, focus_id: int) -> dict:
        """Complete a focus item."""
        return self._request("DELETE", f"/focus/{focus_id}")

    # ── Knowledge ────────────────────────────────────────────

    def know(self, key: str, value: str, category: str = "general") -> dict:
        """Store a knowledge entry."""
        return self._request("POST", "/knowledge", {
            "key": key, "value": value, "category": category,
        })

    def recall(self, query: str, limit: int = 10) -> list:
        """Fuzzy-search knowledge entries."""
        return self._request("GET", f"/knowledge/search/{query}?limit={limit}")

    def knowledge(self, key: str) -> dict:
        """Get a specific knowledge entry."""
        return self._request("GET", f"/knowledge/{key}")

    # ── Frames & Triggers ────────────────────────────────────

    def frames(self) -> list:
        """List registered frames."""
        return self._request("GET", "/frames")

    def register_frame(self, frame_id: str, description: str = "", triggers: list = None) -> dict:
        """Register a new frame."""
        return self._request("POST", "/frames", {
            "frame_id": frame_id, "description": description, "triggers": triggers or [],
        })

    def triggers(self) -> list:
        """List registered triggers."""
        return self._request("GET", "/triggers")

    def register_trigger(
        self, name: str, action_type: str, action_config: dict = None,
        signal_type: str = None, agent_pattern: str = "*", content_pattern: str = None,
    ) -> dict:
        """Register a new trigger."""
        body = {
            "name": name, "action_type": action_type,
            "action_config": action_config or {}, "agent_pattern": agent_pattern,
        }
        if signal_type:
            body["signal_type"] = signal_type
        if content_pattern:
            body["content_pattern"] = content_pattern
        return self._request("POST", "/triggers", body)

    # ── Usage ────────────────────────────────────────────────

    def usage(self) -> dict:
        """Get current month's usage and limits.

        Returns:
            {"tier": str, "usage": {"signal_count": int, ...}, "limits": {...}}
        """
        return self._request("GET", "/usage")

    # ── Utilities ────────────────────────────────────────────

    def agents(self) -> dict:
        """List known agents and their activity."""
        return self._request("GET", "/agents")

    def compact(self, dry_run: bool = False) -> dict:
        """Run signal compaction."""
        return self._request("POST", f"/compact?dry_run={str(dry_run).lower()}")
