"""SafeCadence Network Risk — local-first, multi-vendor network audit."""

__version__ = "2.3.0"
__author__ = "SafeCadence"
__license__ = "MIT"
