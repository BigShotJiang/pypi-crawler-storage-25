"""
SafeCadence Network Risk — command-line interface.

Examples:
    safecadence scan device.txt
    safecadence scan device.txt --vendor cisco-ios --output report.md
    safecadence scan device.txt --json report.json --save-history
    safecadence list-vendors
    safecadence list-rules --vendor cisco-ios
    safecadence rule-info cisco-ios-telnet-enabled
    safecadence ai-explain device.txt
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import click

from safecadence import __version__
from safecadence.ai import AIError, detect_provider, explain_findings
from safecadence.bulk import bulk_scan
from safecadence.core.registry import AdapterRegistry
from safecadence.core.schema import Asset, ScanResult, Severity
from safecadence.core.store import HistoryStore
from safecadence.dashboard import build_dashboard_data, load_scan_dir, render_dashboard
from safecadence.discovery import discover_subnet
from safecadence.enrichment import eol_status, find_cves
from safecadence.topology import (
    parse_lldp_text, render_dot, render_html, render_mermaid, render_text,
)
from safecadence.engines.config_audit import ConfigAuditEngine, load_rules
from safecadence.engines.health import compute_health, health_band
from safecadence.engines.risk import compute_risk, risk_band, summarize
from safecadence.reports.docx import to_docx
from safecadence.reports.html import to_html
from safecadence.reports.json import to_json
from safecadence.reports.markdown import to_markdown
from safecadence.reports.pdf import to_pdf


# --------------------------------------------------------------------------- #
# Pretty printing (rich) — degrades gracefully if rich isn't available.        #
# --------------------------------------------------------------------------- #
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    _CONSOLE = Console()

    def _print(*args, **kwargs):
        _CONSOLE.print(*args, **kwargs)

    def _has_rich() -> bool:
        return True
except ImportError:   # pragma: no cover
    _CONSOLE = None

    def _print(msg=""):
        click.echo(msg if isinstance(msg, str) else str(msg))

    def _has_rich() -> bool:
        return False


_SEV_COLOR = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH:     "red",
    Severity.MEDIUM:   "yellow",
    Severity.LOW:      "cyan",
    Severity.INFO:     "white",
}


# --------------------------------------------------------------------------- #
# Commands                                                                    #
# --------------------------------------------------------------------------- #
@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="safecadence")
def cli():
    """SafeCadence Network Risk — open-source network audit tool."""


@cli.command("scan")
@click.argument("source", type=click.Path(exists=True, readable=True))
@click.option("--vendor", default=None, help="Force a vendor adapter (e.g. cisco-ios).")
@click.option("--dir", "as_dir", is_flag=True,
              help="Treat SOURCE as a directory of configs and bulk-scan in parallel.")
@click.option("--workers", "-w", default=8, show_default=True,
              help="Parallel workers for --dir bulk mode.")
@click.option("--out-dir", type=click.Path(file_okay=False), default=None,
              help="Output directory for per-device JSON/Markdown reports in --dir mode.")
@click.option("--output", "-o", type=click.Path(dir_okay=False), default=None,
              help="Write the Markdown report to this file.")
@click.option("--json", "json_path", type=click.Path(dir_okay=False), default=None,
              help="Write the machine-readable JSON report to this file.")
@click.option("--html", "html_path", type=click.Path(dir_okay=False), default=None,
              help="Write a polished single-file HTML report.")
@click.option("--docx", "docx_path", type=click.Path(dir_okay=False), default=None,
              help="Write a Word .docx report (consultant-style).")
@click.option("--pdf", "pdf_path", type=click.Path(dir_okay=False), default=None,
              help="Write a paginated PDF report (pure stdlib, no deps).")
@click.option("--quiet", "-q", is_flag=True, help="Don't print the live summary.")
@click.option("--criticality", type=click.Choice(["low", "medium", "high", "critical"]),
              default="medium", show_default=True,
              help="Business criticality of the device (affects risk weighting).")
@click.option("--save-history", is_flag=True,
              help="Append the scan to local SQLite history.")
def scan(source, vendor, as_dir, workers, out_dir, output, json_path, html_path, docx_path,
         pdf_path, quiet, criticality, save_history):
    """Scan a config file (or a whole directory in --dir mode) and produce scored reports."""
    if as_dir:
        _bulk_scan(source, workers=workers, out_dir=out_dir, vendor=vendor,
                   criticality=criticality, save_history=save_history, quiet=quiet)
        return

    started = time.perf_counter()
    text = Path(source).read_text(encoding="utf-8", errors="replace")

    if vendor:
        adapter = AdapterRegistry.get(vendor)
        if adapter is None:
            click.echo(f"Unknown vendor: {vendor!r}. Try `safecadence list-vendors`.",
                       err=True)
            sys.exit(2)
    else:
        adapter = AdapterRegistry.detect(text, filename=str(source))
        if adapter is None:
            click.echo("Could not auto-detect vendor. Pass --vendor.", err=True)
            sys.exit(2)

    parsed = adapter.parse_config(text)
    findings = ConfigAuditEngine(vendor=adapter.slug).run(parsed)
    health = compute_health(parsed, findings)
    risk = compute_risk(findings, business_criticality=criticality)
    summary = summarize(findings)

    asset = Asset(
        asset_id=parsed.hostname or Path(source).stem,
        hostname=parsed.hostname,
        vendor=adapter.slug,
        model=parsed.model,
        os=parsed.os,
        version=parsed.version,
        device_type=parsed.device_type,
        business_criticality=criticality,
        interfaces=parsed.interfaces,
        neighbors=parsed.neighbors,
        health_score=health,
        risk_score=risk,
        health_band=health_band(health),
        risk_band=risk_band(risk),
        findings=findings,
    )

    duration_ms = int((time.perf_counter() - started) * 1000)

    # Enrichment: CVEs + EOL (always-on, 100% local from bundled data)
    cves_matched = find_cves(vendor=adapter.slug, os=parsed.os, version=parsed.version)
    eol_rec = eol_status(vendor=adapter.slug, os=parsed.os, version=parsed.version)
    eol_dict = None
    if eol_rec is not None:
        eol_dict = eol_rec.to_dict()
        eol_dict["status_today"] = eol_rec.status_today()

    result = ScanResult(
        source=str(source),
        vendor=adapter.slug,
        duration_ms=duration_ms,
        parsed=parsed,
        asset=asset,
        findings=findings,
        health_score=health,
        risk_score=risk,
        health_band=health_band(health),
        risk_band=risk_band(risk),
        summary=summary,
        cves=[c.to_dict() for c in cves_matched],
        eol=eol_dict,
    )

    if not quiet:
        _print_summary(result)

    if output:
        Path(output).write_text(to_markdown(result), encoding="utf-8")
        _print(f"[green]Markdown report:[/green] {output}" if _has_rich() else f"Markdown report: {output}")

    if json_path:
        Path(json_path).write_text(to_json(result), encoding="utf-8")
        _print(f"[green]JSON report:[/green] {json_path}" if _has_rich() else f"JSON report: {json_path}")

    if html_path:
        Path(html_path).write_text(to_html(result), encoding="utf-8")
        _print(f"[green]HTML report:[/green] {html_path}" if _has_rich() else f"HTML report: {html_path}")

    if docx_path:
        to_docx(result, docx_path)
        _print(f"[green]DOCX report:[/green] {docx_path}" if _has_rich() else f"DOCX report: {docx_path}")

    if pdf_path:
        to_pdf(result, pdf_path)
        _print(f"[green]PDF report:[/green] {pdf_path}" if _has_rich() else f"PDF report: {pdf_path}")

    if save_history:
        store = HistoryStore()
        sid = store.save(result)
        store.close()
        _print(f"Saved to local history (id #{sid}).")


def _bulk_scan(source, *, workers, out_dir, vendor, criticality, save_history, quiet):
    """Run a bulk scan over a directory of configs in parallel."""
    src = Path(source)
    if not src.is_dir():
        click.echo(f"--dir given but {source} is not a directory.", err=True)
        sys.exit(2)
    out_dir = out_dir or str(src.parent / (src.name + ".scans"))

    if _has_rich():
        from rich.progress import (Progress, SpinnerColumn, BarColumn, TextColumn,
                                   TimeElapsedColumn, MofNCompleteColumn)
        with Progress(
            SpinnerColumn(), TextColumn("[bold]{task.description}"),
            BarColumn(), MofNCompleteColumn(), TimeElapsedColumn(),
            console=_CONSOLE, transient=False,
        ) as prog:
            task = prog.add_task(f"Scanning {source}", total=None)
            def cb(done, total, summary):
                prog.update(task, total=total, completed=done,
                            description=f"{summary.hostname or '?'}  ({summary.vendor})")
            results = bulk_scan(
                src, workers=workers, out_dir=out_dir, vendor=vendor,
                criticality=criticality, save_history=save_history, progress_cb=cb,
            )
    else:
        results = bulk_scan(
            src, workers=workers, out_dir=out_dir, vendor=vendor,
            criticality=criticality, save_history=save_history,
        )

    if not results:
        click.echo("No config files found.", err=True)
        sys.exit(2)

    crit = sum(1 for r in results if r.risk >= 81)
    high = sum(1 for r in results if 61 <= r.risk < 81)
    err  = sum(1 for r in results if r.error)

    if not quiet and _has_rich():
        t = Table(title=f"Bulk scan summary — {len(results)} device(s)")
        t.add_column("Hostname", style="bold cyan")
        t.add_column("Vendor")
        t.add_column("Health", justify="right")
        t.add_column("Risk", justify="right")
        t.add_column("Findings", justify="right")
        t.add_column("CVEs", justify="right")
        t.add_column("EOL")
        t.add_column("ms", justify="right")
        for r in results[:20]:
            risk_color = "red" if r.risk >= 81 else "yellow" if r.risk >= 61 else "green"
            t.add_row(
                r.hostname or Path(r.source).stem, r.vendor,
                str(r.health), f"[{risk_color}]{r.risk}[/]",
                str(r.findings), str(r.cves),
                r.eol_status, str(r.duration_ms),
            )
        _CONSOLE.print(t)
        if len(results) > 20:
            _CONSOLE.print(f"[dim]…and {len(results)-20} more (full list in {out_dir}).[/dim]")
        _CONSOLE.print(
            f"\n[bold]Done.[/bold]  "
            f"[red]{crit} critical[/red] · [yellow]{high} high[/yellow] · "
            f"[dim]{err} errored[/dim]\n"
            f"Per-device JSON + Markdown written to: [green]{out_dir}[/green]\n"
            f"Build a fleet dashboard:   [cyan]safecadence dashboard --scans {out_dir}[/cyan]"
        )
    elif not quiet:
        click.echo(f"Scanned {len(results)} device(s). {crit} critical, {high} high, {err} errors.")
        click.echo(f"Output: {out_dir}")


@cli.command("list-vendors")
def list_vendors():
    """List every adapter registered in this build."""
    adapters = AdapterRegistry.all()
    if not adapters:
        click.echo("No adapters registered.")
        return
    if _has_rich():
        t = Table(title="Available adapters", show_lines=False)
        t.add_column("Slug", style="bold cyan")
        t.add_column("Label")
        t.add_column("OS family")
        t.add_column("SSH")
        for a in sorted(adapters, key=lambda x: x.slug):
            t.add_row(a.slug, a.label, ", ".join(a.os_family or []),
                      "yes" if a.supports_ssh() else "no")
        _CONSOLE.print(t)
    else:
        for a in sorted(adapters, key=lambda x: x.slug):
            click.echo(f"{a.slug:20s}  {a.label}")


@cli.command("list-rules")
@click.option("--vendor", default=None, help="Filter to one vendor (e.g. cisco-ios).")
def list_rules(vendor):
    """List every audit rule, optionally filtered by vendor."""
    rules = load_rules(vendor=vendor)
    if not rules:
        click.echo("No rules loaded.")
        return
    if _has_rich():
        t = Table(title=f"Rules ({len(rules)})")
        t.add_column("ID", style="cyan")
        t.add_column("Sev")
        t.add_column("Vendor")
        t.add_column("Domain")
        t.add_column("Title")
        for r in rules:
            t.add_row(r.id,
                      f"[{_SEV_COLOR[r.severity]}]{r.severity.value}[/]",
                      r.vendor, r.domain, r.title)
        _CONSOLE.print(t)
    else:
        for r in rules:
            click.echo(f"{r.id:40s} {r.severity.value:8s} {r.vendor:12s} {r.title}")


@cli.command("rule-info")
@click.argument("rule_id")
def rule_info(rule_id):
    """Show full detail for one rule."""
    for r in load_rules():
        if r.id == rule_id:
            click.echo(f"# {r.title}")
            click.echo(f"id:        {r.id}")
            click.echo(f"severity:  {r.severity.value}")
            click.echo(f"vendor:    {r.vendor}")
            click.echo(f"domain:    {r.domain}")
            click.echo()
            if r.description:
                click.echo("Description:")
                click.echo(f"  {r.description}")
            if r.remediation:
                click.echo()
                click.echo("Remediation:")
                click.echo(f"  {r.remediation}")
            if r.fix_snippet:
                click.echo()
                click.echo("Fix snippet:")
                for line in r.fix_snippet.splitlines():
                    click.echo(f"  {line}")
            if r.references:
                click.echo()
                click.echo("References:")
                for ref in r.references:
                    click.echo(f"  - {ref}")
            return
    click.echo(f"Rule {rule_id!r} not found.", err=True)
    sys.exit(2)


@cli.command("ai-explain")
@click.argument("source", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--vendor", default=None)
@click.option("--provider", type=click.Choice(["openai", "anthropic", "ollama", "auto", "none"]),
              default="auto", show_default=True,
              help="ollama = local LLM (set OLLAMA_HOST or use default 127.0.0.1:11434).")
@click.option("--model", default=None, help="Override the default model name.")
@click.option("--api-key", default=None, help="API key (else read from env).")
@click.option("--output", "-o", type=click.Path(dir_okay=False), default=None,
              help="Write the briefing to this Markdown file (in addition to printing).")
def ai_explain(source, vendor, provider, model, api_key, output):
    """Run a scan, then ask your BYO LLM for an executive remediation plan."""
    text = Path(source).read_text(encoding="utf-8", errors="replace")
    if vendor:
        adapter = AdapterRegistry.get(vendor)
    else:
        adapter = AdapterRegistry.detect(text, filename=str(source))
    if adapter is None:
        click.echo("Could not pick an adapter; pass --vendor.", err=True)
        sys.exit(2)

    parsed = adapter.parse_config(text)
    findings = ConfigAuditEngine(vendor=adapter.slug).run(parsed)
    health = compute_health(parsed, findings)
    risk = compute_risk(findings)
    asset = Asset(asset_id=parsed.hostname or Path(source).stem,
                  hostname=parsed.hostname, vendor=adapter.slug,
                  model=parsed.model, os=parsed.os, version=parsed.version,
                  device_type=parsed.device_type, findings=findings,
                  health_score=health, risk_score=risk,
                  health_band=health_band(health), risk_band=risk_band(risk))
    result = ScanResult(source=str(source), vendor=adapter.slug, duration_ms=0,
                        parsed=parsed, asset=asset, findings=findings,
                        health_score=health, risk_score=risk,
                        health_band=health_band(health), risk_band=risk_band(risk),
                        summary=summarize(findings))

    prov = None if provider == "auto" else provider
    try:
        out = explain_findings(result, provider=prov, api_key=api_key, model=model)
    except AIError as exc:
        click.echo(str(exc), err=True)
        sys.exit(2)

    if output:
        Path(output).write_text(out, encoding="utf-8")
        if _has_rich():
            _CONSOLE.print(f"[green]Saved AI briefing to:[/green] {output}")
        else:
            click.echo(f"Saved AI briefing to: {output}")

    if _has_rich():
        _CONSOLE.print(Panel(out, title="AI remediation briefing",
                             border_style="cyan", expand=True))
    else:
        click.echo(out)


@cli.command("discover")
@click.argument("cidr")
@click.option("--workers", "-w", default=64, show_default=True,
              help="Number of concurrent TCP probe workers.")
@click.option("--timeout", "-t", default=0.6, show_default=True,
              help="TCP connect timeout in seconds.")
@click.option("--extended", "-x", is_flag=True,
              help="Probe extended port set (slower, deeper).")
@click.option("--no-banner", is_flag=True,
              help="Skip banner-grabbing (faster, less info).")
@click.option("--no-dns", is_flag=True,
              help="Skip reverse DNS lookups.")
@click.option("--json", "json_path", type=click.Path(dir_okay=False), default=None,
              help="Write the discovery result to a JSON file.")
@click.option("--nmap", is_flag=True,
              help="Use nmap (if installed) instead of TCP-only sweep — gets richer service info.")
def discover(cidr, workers, timeout, extended, no_banner, no_dns, json_path, nmap):
    """Discover every device on a subnet (e.g. safecadence discover 10.10.10.0/24)."""
    import json as _json
    if nmap:
        from safecadence.discovery.nmap_scan import nmap_available, nmap_scan
        from safecadence.discovery.asset import DiscoveryResult
        from datetime import datetime as _dt, timezone as _tz
        if not nmap_available():
            click.echo("nmap not found on PATH. Install with: brew install nmap "
                       "(or apt install nmap). Falling back to TCP-only sweep...", err=True)
            nmap = False
        else:
            t0 = time.perf_counter()
            hosts = nmap_scan(cidr)
            duration_ms = int((time.perf_counter() - t0) * 1000)
            result = DiscoveryResult(
                subnet=cidr,
                started_at=_dt.now(_tz.utc).isoformat(),
                finished_at=_dt.now(_tz.utc).isoformat(),
                duration_ms=duration_ms,
                hosts_scanned=len(hosts) or 0,
                hosts_responding=len(hosts),
                hosts=hosts,
            )
    if not nmap:
        if _has_rich():
            with _CONSOLE.status(f"[cyan]Sweeping {cidr} with {workers} workers...[/cyan]"):
                result = discover_subnet(
                    cidr, workers=workers, timeout=timeout, extended=extended,
                    grab_banner=not no_banner, reverse_dns=not no_dns,
                )
        else:
            click.echo(f"Sweeping {cidr}...")
            result = discover_subnet(
                cidr, workers=workers, timeout=timeout, extended=extended,
                grab_banner=not no_banner, reverse_dns=not no_dns,
            )

    if json_path:
        Path(json_path).write_text(_json.dumps(result.to_dict(), indent=2), encoding="utf-8")

    if not _has_rich():
        click.echo(f"Scanned {result.hosts_scanned}, responding {result.hosts_responding}, in {result.duration_ms}ms")
        for h in result.hosts:
            click.echo(f"  {h.ip:15s} {h.vendor_guess or '?':18s} {h.os_guess or '?':10s} {h.device_type_guess or '?':10s} ports={h.open_ports}")
        if json_path:
            click.echo(f"JSON: {json_path}")
        return

    _CONSOLE.print(Panel.fit(
        f"[bold]{result.subnet}[/bold]   "
        f"scanned=[cyan]{result.hosts_scanned}[/cyan]   "
        f"responding=[bold green]{result.hosts_responding}[/bold green]   "
        f"duration=[cyan]{result.duration_ms}ms[/cyan]",
        title="Discovery", border_style="cyan"
    ))
    if not result.hosts:
        _CONSOLE.print("[yellow]No hosts responded.[/yellow]")
        return

    t = Table(show_header=True, header_style="bold")
    t.add_column("IP", style="bold cyan", no_wrap=True)
    t.add_column("Hostname")
    t.add_column("MAC", no_wrap=True)
    t.add_column("Vendor")
    t.add_column("OS")
    t.add_column("Type")
    t.add_column("Open ports", style="dim")
    for h in result.hosts:
        t.add_row(
            h.ip, h.hostname or "—", h.mac or "—",
            h.vendor_guess or "[dim]unknown[/dim]",
            h.os_guess or "[dim]?[/dim]",
            h.device_type_guess or "[dim]?[/dim]",
            ",".join(str(p) for p in h.open_ports),
        )
    _CONSOLE.print(t)
    if json_path:
        _CONSOLE.print(f"[green]JSON:[/green] {json_path}")
    _CONSOLE.print(
        "[dim]Tip: pull configs from network gear and pipe to "
        "[cyan]safecadence scan[/cyan] for a full audit.[/dim]"
    )


@cli.command("topology")
@click.argument("input_file", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--device", default="LOCAL", show_default=True,
              help="Name to use for the device whose LLDP output you're parsing.")
@click.option("--format", "fmt",
              type=click.Choice(["text", "mermaid", "dot", "html", "json"]),
              default="text", show_default=True)
@click.option("--output", "-o", type=click.Path(dir_okay=False), default=None,
              help="Write rendered output to this file (default: stdout).")
@click.option("--scans", "scans_dir", type=click.Path(exists=True, file_okay=False, readable=True),
              default=None,
              help="Directory of scan-result JSON files; matched to nodes by hostname/IP "
                   "and exposed in the HTML double-click panel (with running config).")
def topology(input_file, device, fmt, output, scans_dir):
    """Build a topology graph from LLDP / CDP neighbor output.

    Paste the output of `show lldp neighbors detail` (Cisco IOS / NX-OS,
    Aruba CX uses `show lldp neighbor-info detail`, Arista uses the same
    Cisco syntax) into a file and run:

        safecadence topology lldp.txt --format html -o map.html

    Pair with --scans to attach full per-device scan results (running config,
    findings, CVEs, EOL) to each node — surfaced on double-click in HTML mode.
    """
    import json as _json
    text = Path(input_file).read_text(encoding="utf-8", errors="replace")
    topo = parse_lldp_text(text, local_device=device)

    # Optional: attach per-device scan results
    if scans_dir:
        attached = 0
        for f in Path(scans_dir).iterdir():
            if f.suffix.lower() != ".json" or not f.is_file():
                continue
            try:
                d = _json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if topo.attach_scan_result(d):
                attached += 1
        if _has_rich():
            _CONSOLE.print(f"[dim]Attached {attached} scan result(s) from {scans_dir}[/dim]")
        else:
            click.echo(f"Attached {attached} scan result(s) from {scans_dir}")

    if fmt == "text":
        out = render_text(topo)
    elif fmt == "mermaid":
        out = render_mermaid(topo)
    elif fmt == "dot":
        out = render_dot(topo)
    elif fmt == "html":
        out = render_html(topo, title=f"Topology — {device}")
    else:  # json
        out = _json.dumps(topo.to_dict(), indent=2)

    if output:
        Path(output).write_text(out, encoding="utf-8")
        if _has_rich():
            _CONSOLE.print(f"[green]Wrote {fmt} to:[/green] {output}")
        else:
            click.echo(f"Wrote {fmt} to: {output}")
    else:
        click.echo(out)

    if _has_rich() and not output:
        _CONSOLE.print(
            f"\n[dim]{len(topo.nodes)} nodes · {len(topo.edges)} links discovered. "
            f"Try --format html -o map.html for an interactive view.[/dim]"
        )


@cli.command("dashboard")
@click.option("--scans", "scans_dir", type=click.Path(exists=True, file_okay=False),
              required=True,
              help="Directory of scan-result JSON files (each from `safecadence scan --json`).")
@click.option("--topology", "topology_file", type=click.Path(exists=True, dir_okay=False),
              default=None,
              help="Optional LLDP-output text file to embed as an interactive topology graph.")
@click.option("--device", default="LOCAL", show_default=True,
              help="Local device name when parsing the LLDP file.")
@click.option("--output", "-o", type=click.Path(dir_okay=False),
              default="dashboard.html", show_default=True,
              help="Output HTML file path.")
@click.option("--title", default="SafeCadence Fleet Dashboard", show_default=True)
def dashboard(scans_dir, topology_file, device, output, title):
    """Build a single-file HTML fleet dashboard from a directory of scan results.

    Example:
        safecadence dashboard --scans ./scans/ --topology lldp.txt -o dashboard.html
    """
    scans = load_scan_dir(scans_dir)
    if not scans:
        click.echo(f"No scan-result JSON files found under {scans_dir}.", err=True)
        sys.exit(2)

    topo_dict = None
    if topology_file:
        topo_text = Path(topology_file).read_text(encoding="utf-8", errors="replace")
        topo = parse_lldp_text(topo_text, local_device=device)
        # Attach scans to topo nodes too (for the embedded topology drill-down)
        for s in scans:
            topo.attach_scan_result(s)
        topo_dict = topo.to_dict()

    data = build_dashboard_data(scans, topology=topo_dict)
    html = render_dashboard(data, title=title)
    Path(output).write_text(html, encoding="utf-8")

    if _has_rich():
        _CONSOLE.print(Panel.fit(
            f"[bold]Fleet dashboard generated[/bold]\n"
            f"Devices:        [cyan]{data.overview['device_count']}[/cyan]\n"
            f"Avg risk:       [bold red]{data.overview['avg_risk']}[/bold red] / 100\n"
            f"Critical risk:  [bold red]{data.overview['critical_devices']}[/bold red] device(s)\n"
            f"KEV exposed:    [bold red]{data.overview['kev_devices']}[/bold red] device(s)\n"
            f"End-of-support: [bold yellow]{data.overview['eol_devices']}[/bold yellow] device(s)\n"
            f"Unique CVEs:    [cyan]{len(data.cves_by_id)}[/cyan]\n\n"
            f"Wrote: [green]{output}[/green]   ({Path(output).stat().st_size:,} bytes)\n"
            f"[dim]Open in browser: open {output}[/dim]",
            title="dashboard", border_style="cyan"
        ))
    else:
        click.echo(f"Wrote dashboard: {output}")
        click.echo(f"Devices: {data.overview['device_count']}")
        click.echo(f"Avg risk: {data.overview['avg_risk']}/100")


@cli.command("history")
@click.option("--limit", default=20, show_default=True)
def history(limit):
    """Show recent saved scans (only populated when --save-history was used)."""
    store = HistoryStore()
    rows = store.list(limit=limit)
    store.close()
    if not rows:
        click.echo("No saved history. Run a scan with --save-history first.")
        return
    if _has_rich():
        t = Table(title=f"Last {len(rows)} scans")
        for col in ("id", "started_at", "vendor", "hostname", "health", "risk", "findings", "source"):
            t.add_column(col)
        for r in rows:
            t.add_row(str(r["id"]), r["started_at"], r["vendor"], r["hostname"] or "—",
                      str(r["health"]), str(r["risk"]), str(r["findings"]), r["source"])
        _CONSOLE.print(t)
    else:
        for r in rows:
            click.echo(json.dumps(r))


# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #
def _print_summary(result: ScanResult) -> None:
    if not _has_rich():
        click.echo(f"Hostname: {result.parsed.hostname or '—'}")
        click.echo(f"Vendor:   {result.vendor}")
        click.echo(f"OS:       {result.parsed.os} {result.parsed.version}")
        click.echo(f"Health:   {result.health_score}/100 ({result.health_band})")
        click.echo(f"Risk:     {result.risk_score}/100 ({result.risk_band})")
        click.echo(f"Summary:  {result.summary}")
        click.echo(f"Findings: {len(result.findings)}")
        for f in result.findings[:10]:
            click.echo(f"  [{f.severity.value.upper():8s}] {f.title}")
        if len(result.findings) > 10:
            click.echo(f"  ...and {len(result.findings) - 10} more.")
        return

    p = result.parsed
    header = Text()
    header.append("SafeCadence Scan ", style="bold")
    header.append(f"v{__version__}", style="dim")

    enrich_lines = []
    if result.cves:
        kev_n = sum(1 for c in result.cves if c.get("kev"))
        crit_n = sum(1 for c in result.cves if c.get("severity") == "critical")
        kev_str = f" · [bold red]{kev_n} KEV[/bold red]" if kev_n else ""
        enrich_lines.append(
            f"CVEs: [bold red]{len(result.cves)}[/bold red] matched "
            f"({crit_n} critical{kev_str})"
        )
    if result.eol:
        st = result.eol.get("status_today", "")
        color = "red" if "end-of-support" in st else ("yellow" if "end-of-software" in st else "green")
        enrich_lines.append(
            f"EOL: [bold {color}]{st}[/bold {color}]   "
            f"end-of-software={result.eol.get('end_of_software', '—')}   "
            f"end-of-support={result.eol.get('end_of_support', '—')}"
        )
    enrich_block = "\n" + "\n".join(enrich_lines) if enrich_lines else ""

    _CONSOLE.print(Panel.fit(
        f"[bold]{p.hostname or result.source}[/bold]   "
        f"vendor=[cyan]{result.vendor}[/cyan]   os=[cyan]{p.os}[/cyan]   "
        f"version=[cyan]{p.version or '—'}[/cyan]   model=[cyan]{p.model or '—'}[/cyan]\n"
        f"health=[bold green]{result.health_score}[/bold green]/100 "
        f"([italic]{result.health_band}[/italic])    "
        f"risk=[bold red]{result.risk_score}[/bold red]/100 "
        f"([italic]{result.risk_band}[/italic])\n"
        f"summary: {result.summary}"
        f"{enrich_block}",
        title=header, border_style="cyan"
    ))
    if not result.findings:
        _CONSOLE.print("[green]No findings — clean device or no rules matched.[/green]")
        return

    t = Table(show_header=True, header_style="bold", show_lines=False)
    t.add_column("Severity", no_wrap=True)
    t.add_column("Rule")
    t.add_column("Title")
    for f in result.findings:
        t.add_row(
            f"[{_SEV_COLOR[f.severity]}]{f.severity.value.upper()}[/]",
            f.rule_id, f.title,
        )
    _CONSOLE.print(t)
    detected = detect_provider().value
    _CONSOLE.print(
        f"[dim]AI provider auto-detected: [bold]{detected}[/bold] — "
        f"run [cyan]safecadence ai-explain {result.source}[/cyan] for a plan.[/dim]"
    )


@cli.command("collect")
@click.argument("inventory", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--out-dir", type=click.Path(file_okay=False), default="collected",
              show_default=True)
@click.option("--workers", "-w", default=8, show_default=True)
@click.option("--timeout", "-t", default=30, show_default=True)
def collect_cmd(inventory, out_dir, workers, timeout):
    """SSH-collect running configs from every device in INVENTORY (YAML)."""
    from safecadence.collect import collect_all, load_inventory
    devices = load_inventory(inventory)

    def cb(done, total, r):
        status = "OK" if not r.error else "FAIL"
        if _has_rich():
            _CONSOLE.print(f"  [{done}/{total}] {r.name or r.host:30s} {status} {r.error or f'{r.bytes_received}b'}")
        else:
            click.echo(f"[{done}/{total}] {r.name or r.host} {status} {r.error or f'{r.bytes_received}b'}")
    results = collect_all(devices, out_dir=out_dir, workers=workers, timeout=timeout,
                          progress_cb=cb)
    ok = sum(1 for r in results if not r.error and r.bytes_received > 0)
    click.echo(f"\nCollected {ok}/{len(results)} configs into {out_dir}/")
    click.echo(f"Run:  safecadence scan {out_dir} --dir --out-dir {out_dir}.scans")


@cli.command("watch")
@click.argument("source", type=click.Path(exists=True))
@click.option("--interval", default=3600, show_default=True,
              help="Re-scan interval in seconds (default: hourly).")
@click.option("--out-dir", type=click.Path(file_okay=False), default=None)
@click.option("--workers", "-w", default=8, show_default=True)
@click.option("--once", is_flag=True, help="Run a single iteration and exit (for cron use).")
def watch_cmd(source, interval, out_dir, workers, once):
    """Re-scan SOURCE on an interval, diffing against the last run."""
    import json as _json
    src = Path(source)
    state_dir = Path(out_dir) if out_dir else src.parent / (src.name + ".watch")
    state_dir.mkdir(parents=True, exist_ok=True)
    last_path = state_dir / "last.json"

    def one_pass():
        from safecadence.bulk import bulk_scan
        results = bulk_scan(src if src.is_dir() else src.parent,
                            workers=workers, out_dir=str(state_dir / "scans"))
        snapshot = {r.hostname or Path(r.source).stem: {
            "risk": r.risk, "health": r.health, "findings": r.findings,
            "cves": r.cves, "eol": r.eol_status,
        } for r in results}
        prev = {}
        if last_path.exists():
            try:
                prev = _json.loads(last_path.read_text())
            except Exception:
                prev = {}
        diffs = []
        for name, cur in snapshot.items():
            old = prev.get(name)
            if old is None:
                diffs.append(f"  + NEW   {name}  risk={cur['risk']}")
                continue
            if cur["risk"] != old.get("risk") or cur["findings"] != old.get("findings"):
                diffs.append(
                    f"  ~ CHG   {name}  "
                    f"risk {old.get('risk')} → {cur['risk']}   "
                    f"findings {old.get('findings')} → {cur['findings']}"
                )
        for name in prev:
            if name not in snapshot:
                diffs.append(f"  - GONE  {name}")
        last_path.write_text(_json.dumps(snapshot, indent=2))
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"[{ts}] {len(results)} device(s) scanned · {len(diffs)} change(s):")
        for d in diffs[:30]:
            click.echo(d)

    one_pass()
    if once:
        return
    while True:
        time.sleep(interval)
        one_pass()


@cli.command("serve")
@click.option("--scans", "scans_dir", type=click.Path(exists=True, file_okay=False),
              required=True)
@click.option("--port", default=8765, show_default=True)
@click.option("--bind", default="127.0.0.1", show_default=True,
              help="Bind address. Defaults to localhost only for safety.")
@click.option("--topology", "topology_file", type=click.Path(exists=True, dir_okay=False),
              default=None)
def serve_cmd(scans_dir, port, bind, topology_file):
    """Serve the fleet dashboard over a local HTTP server (live regenerates on each request)."""
    import http.server
    import socketserver

    from safecadence.dashboard import build_dashboard_data, load_scan_dir, render_dashboard
    from safecadence.topology import parse_lldp_text

    def render_live() -> bytes:
        scans = load_scan_dir(scans_dir)
        topo = None
        if topology_file:
            t = parse_lldp_text(Path(topology_file).read_text(encoding="utf-8"),
                                local_device="LOCAL")
            for s in scans:
                t.attach_scan_result(s)
            topo = t.to_dict()
        data = build_dashboard_data(scans, topology=topo)
        return render_dashboard(data).encode("utf-8")

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a, **kw):    # quiet by default
            pass
        def do_GET(self):
            try:
                body = render_live()
            except Exception as exc:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(f"Render error: {exc}".encode())
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

    with socketserver.ThreadingTCPServer((bind, port), Handler) as httpd:
        httpd.allow_reuse_address = True
        url = f"http://{bind}:{port}/"
        click.echo(f"SafeCadence dashboard live at {url}")
        click.echo(f"  scans:    {scans_dir}")
        if topology_file:
            click.echo(f"  topology: {topology_file}")
        click.echo("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            click.echo("\nStopped.")


@cli.command("enrich")
@click.option("--refresh", is_flag=True,
              help="Refresh KEV + EOL feeds. Combine with --online (or --kev-file).")
@click.option("--online", is_flag=True,
              help="Fetch from public sources (CISA KEV + endoflife.date).")
@click.option("--kev-file", default=None,
              help="Path to a downloaded CISA KEV JSON (for air-gapped sites).")
@click.option("--show-stats", is_flag=True, help="Print bundled CVE / EOL DB stats.")
def enrich_cmd(refresh, online, kev_file, show_stats):
    """Inspect or refresh the bundled CVE + EOL datasets."""
    from safecadence.enrichment import load_cve_db, load_eol_db, refresh_eol, refresh_kev
    if refresh:
        try:
            kev_result = refresh_kev(online=online, kev_file=kev_file)
            click.echo(f"  KEV refresh: matched {kev_result['kev_total']} entries, "
                       f"updated {kev_result['rules_updated']} CVE records "
                       f"in {kev_result['files_touched']} file(s).")
        except Exception as exc:
            click.echo(f"  KEV refresh failed: {exc}", err=True)
        try:
            eol_result = refresh_eol(online=online)
            click.echo(f"  EOL refresh: {eol_result.get('updated', 0)} product file(s) refreshed.")
        except Exception as exc:
            click.echo(f"  EOL refresh failed: {exc}", err=True)
    db = load_cve_db()
    eol = load_eol_db()
    if _has_rich():
        t = Table(title="Bundled enrichment datasets")
        t.add_column("Vendor"); t.add_column("CVEs", justify="right"); t.add_column("EOL records", justify="right")
        vendors = sorted(set(list(db.keys()) + [r.vendor for r in eol]))
        for v in vendors:
            cves = len(db.get(v, []))
            eols = sum(1 for r in eol if r.vendor == v)
            t.add_row(v, str(cves), str(eols))
        _CONSOLE.print(t)
    else:
        click.echo(f"CVEs: {sum(len(v) for v in db.values())} across {len(db)} vendors")
        click.echo(f"EOL records: {len(eol)}")


@cli.command("api")
@click.option("--bind", default="127.0.0.1", show_default=True,
              help="Bind address. Defaults to localhost (private mode).")
@click.option("--port", default=8765, show_default=True)
@click.option("--db-url", default=None,
              help="DB URL (postgresql://… or sqlite:///path.db). Defaults to local SQLite.")
@click.option("--users-file", default=None,
              help="Path to safecadence-users.yaml (auto-bootstrapped on first run).")
@click.option("--reload", is_flag=True, help="Auto-reload on code changes (dev).")
def api_cmd(bind, port, db_url, users_file, reload):
    """Run the SafeCadence FastAPI server (REST API + auth)."""
    try:
        import uvicorn
    except ImportError:
        click.echo("API server requires the [server] extras. "
                   "Install with: pip install 'safecadence-network-risk[server]'", err=True)
        sys.exit(2)
    if users_file:
        os.environ["SC_USERS_FILE"] = users_file
    if db_url:
        os.environ["DATABASE_URL"] = db_url
    from safecadence.server import create_app
    app = create_app(db_url=db_url, users_file=users_file)
    uvicorn.run(app, host=bind, port=port)


@cli.command("ui")
@click.option("--host", default="127.0.0.1", show_default=True,
              help="Bind address. Defaults to localhost (private mode).")
@click.option("--port", default=8765, show_default=True,
              help="HTTP port (auto-finds the next free one if taken).")
@click.option("--no-browser", is_flag=True, default=False,
              help="Don't auto-open the browser.")
def ui_cmd(host, port, no_browser):
    """Launch the local web UI in your default browser.

    Single-user, no authentication, 100% local. Multi-tab dashboard with full
    CLI parity: scan, devices, discover, topology, CVEs, EOL, AI explainer,
    vault, history, settings.

    Requires the [server] extras:
      pip install 'safecadence-netrisk[server]'

    Example:
      safecadence ui                  # opens http://127.0.0.1:8765
      safecadence ui --port 9000      # custom port
      safecadence ui --no-browser     # don't auto-launch browser
    """
    try:
        from safecadence.ui import run_ui
    except ImportError as e:
        click.echo(f"UI launcher import failed: {e}", err=True)
        sys.exit(2)
    run_ui(host=host, port=port, open_browser=not no_browser)


@cli.command("vault")
@click.argument("action", type=click.Choice(["init", "set", "get", "list", "delete"]))
@click.argument("name", required=False)
@click.option("--value", default=None, help="Value for set (else prompted).")
@click.option("--path", "vault_path", default="safecadence.vault", show_default=True)
@click.option("--passphrase", default=None,
              help="Passphrase. Defaults to env SC_VAULT_PASS or prompts.")
def vault_cmd(action, name, value, vault_path, passphrase):
    """Manage the encrypted credential vault."""
    from safecadence.security import EncryptedVault, VaultError, derive_key, generate_key
    salt_path = vault_path + ".salt"
    if action == "init":
        click.echo("Random key generated. Set this in your env:")
        click.echo(f"  export SC_VAULT_KEY='{generate_key()}'")
        click.echo("Or use a passphrase: re-run any vault command with --passphrase.")
        return

    raw_key = os.environ.get("SC_VAULT_KEY")
    if not raw_key:
        if not passphrase:
            passphrase = os.environ.get("SC_VAULT_PASS") or click.prompt("Passphrase", hide_input=True)
        try:
            raw_key = derive_key(passphrase, salt_path=salt_path)
        except VaultError as exc:
            click.echo(str(exc), err=True); sys.exit(2)
    try:
        v = EncryptedVault(vault_path, key=raw_key)
    except VaultError as exc:
        click.echo(str(exc), err=True); sys.exit(2)

    if action == "list":
        for k in v.list(): click.echo(k)
    elif action == "get":
        if not name: click.echo("get requires NAME", err=True); sys.exit(2)
        click.echo(v.get(name) or "")
    elif action == "set":
        if not name: click.echo("set requires NAME", err=True); sys.exit(2)
        if value is None:
            value = click.prompt("Value", hide_input=True, confirmation_prompt=True)
        v.set(name, value); v.save()
        click.echo(f"Stored: {name}")
    elif action == "delete":
        if not name: click.echo("delete requires NAME", err=True); sys.exit(2)
        ok = v.delete(name); v.save()
        click.echo("Deleted." if ok else "Not found.")


@cli.group("admin")
def admin_cmd():
    """Manage SafeCadence API users (no server restart required)."""
    pass


@admin_cmd.command("reset-password")
@click.option("--username", "-u", default="admin", show_default=True)
@click.option("--password", "-p", default=None,
              help="New password. If omitted, a strong random one is generated and printed.")
@click.option("--tenant", default="default", show_default=True)
@click.option("--users-file", default="safecadence-users.yaml", show_default=True)
def admin_reset_password(username, password, tenant, users_file):
    """Reset (or create) a user's password in safecadence-users.yaml."""
    import secrets as _sec
    import yaml as _yaml
    try:
        from safecadence.server.auth import hash_password
    except RuntimeError as exc:
        click.echo(str(exc), err=True); sys.exit(2)

    p = Path(users_file)
    data = _yaml.safe_load(p.read_text(encoding="utf-8")) if p.exists() else {"tenants": {}}
    data.setdefault("tenants", {}).setdefault(tenant, {}).setdefault("users", [])

    if password is None:
        password = _sec.token_urlsafe(20)

    found = False
    for u in data["tenants"][tenant]["users"]:
        if u.get("username") == username:
            u["password_hash"] = hash_password(password)
            u.setdefault("roles", ["admin"])
            found = True
            break
    if not found:
        data["tenants"][tenant]["users"].append({
            "username": username,
            "password_hash": hash_password(password),
            "roles": ["admin"],
        })

    p.write_text(_yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass

    click.echo(f"User: {username}    Tenant: {tenant}")
    click.echo(f"New password: {password}")
    click.echo(f"Wrote: {p.resolve()}")


@admin_cmd.command("list-users")
@click.option("--users-file", default="safecadence-users.yaml", show_default=True)
def admin_list_users(users_file):
    """List every user across every tenant in the users file."""
    import yaml as _yaml
    p = Path(users_file)
    if not p.exists():
        click.echo(f"No users file at {p}", err=True); sys.exit(2)
    data = _yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    for tenant, t in (data.get("tenants") or {}).items():
        for u in t.get("users", []):
            click.echo(f"  {tenant:20s} {u.get('username','?'):20s} roles={u.get('roles',[])}")


@cli.command("export")
@click.argument("scans_dir", type=click.Path(exists=True, file_okay=False))
@click.option("--csv", "csv_path", required=True, type=click.Path(dir_okay=False),
              help="Output CSV path.")
def export_cmd(scans_dir, csv_path):
    """Export a directory of scan-result JSON files to a flat CSV."""
    import json as _json
    from safecadence.io_csv import write_assets_csv
    rows = []
    for f in sorted(Path(scans_dir).iterdir()):
        if f.suffix.lower() != ".json": continue
        try:
            rows.append(_json.loads(f.read_text(encoding="utf-8")))
        except Exception:
            continue
    n = write_assets_csv(rows, csv_path)
    click.echo(f"Wrote {n} row(s) to {csv_path}")


if __name__ == "__main__":   # pragma: no cover
    cli()
