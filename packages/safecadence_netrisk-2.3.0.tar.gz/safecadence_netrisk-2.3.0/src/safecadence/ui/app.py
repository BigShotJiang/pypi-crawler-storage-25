"""
FastAPI app for the local UI.

Differs from `safecadence.server.app` in two important ways:
  1. No authentication — assumes single-user local mode.
  2. Adds UI-specific endpoints (file uploads from drag-drop, discover proxy,
     enrichment refresh, BYOK AI proxy) that don't make sense in the
     production multi-tenant API.

Designed to run on localhost only. If you need network-accessible auth,
use `safecadence api` instead.
"""

from __future__ import annotations

import dataclasses
import os
import socket
import sys
import tempfile
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Optional

# Lazy import — the [server] extras are required to actually run the UI.
try:
    from fastapi import Body, FastAPI, File, HTTPException, Query, UploadFile
    from fastapi.responses import HTMLResponse, JSONResponse, Response
    _FASTAPI_OK = True
except ImportError:
    _FASTAPI_OK = False


def _check_extras() -> None:
    if not _FASTAPI_OK:
        sys.stderr.write(
            "\n  The local UI requires the [server] extras. Install with:\n"
            "    pip install 'safecadence-netrisk[server]'\n\n"
        )
        sys.exit(1)


def _to_jsonable(obj: Any) -> Any:
    """Convert dataclasses, sets, paths, etc. to JSON-friendly forms."""
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return _to_jsonable(dataclasses.asdict(obj))
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_to_jsonable(x) for x in obj]
    if isinstance(obj, Path):
        return str(obj)
    return obj


def create_app():
    _check_extras()

    # Late imports so import-time failures show friendly messages, not stack traces.
    from safecadence.bulk import _scan_one
    from safecadence.core.registry import AdapterRegistry
    from safecadence.dashboard import build_dashboard_data, render_dashboard
    from safecadence.engines.config_audit import load_rules
    from safecadence.storage import open_store

    app = FastAPI(
        title="SafeCadence Local UI",
        description="Single-user local web UI for safecadence-netrisk.",
        version="2.3.0",
        docs_url="/api/docs",
        redoc_url=None,
    )

    # Persistent local store — same SQLite the CLI uses
    db_path = Path.home() / ".safecadence" / "ui.sqlite"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    store = open_store(sqlite_path=str(db_path))

    INDEX_PATH = Path(__file__).parent / "templates" / "index.html"

    # ---------------------------------------------------------------- index
    @app.get("/", response_class=HTMLResponse)
    def index() -> str:
        return INDEX_PATH.read_text(encoding="utf-8")

    @app.get("/favicon.ico")
    def favicon() -> Response:
        return Response(content=b"", media_type="image/x-icon")

    # ---------------------------------------------------------------- core read
    @app.get("/api/health")
    def health() -> dict:
        return {"ok": True, "version": "2.3.0", "mode": "local-ui"}

    @app.get("/api/vendors")
    def list_vendors() -> list:
        # AdapterRegistry exposes adapter classes; expose the registered ids.
        out = []
        try:
            adapters = AdapterRegistry.list_adapters()  # may not exist
        except AttributeError:
            adapters = []
            try:
                # Probe the registry's internal map if available
                for vid in getattr(AdapterRegistry, "_adapters", {}).keys():
                    adapters.append({"id": vid})
            except Exception:
                pass
        for a in adapters:
            if isinstance(a, dict):
                out.append(a)
            else:
                out.append({
                    "id": getattr(a, "id", str(a)),
                    "name": getattr(a, "display_name", getattr(a, "id", str(a))),
                    "vendor": getattr(a, "vendor", ""),
                    "os": getattr(a, "os_name", ""),
                })
        return out

    @app.get("/api/rules")
    def list_rules(vendor: Optional[str] = None) -> list:
        rules = load_rules(vendor=vendor)
        out = []
        for r in rules:
            d = _to_jsonable(r)
            # Ensure these fields exist for the UI even if Rule doesn't carry them
            d.setdefault("id", getattr(r, "id", "?"))
            d.setdefault("title", getattr(r, "title", ""))
            d.setdefault("severity", getattr(r, "severity", "info"))
            d.setdefault("vendor", getattr(r, "vendor", ""))
            d.setdefault("tags", getattr(r, "tags", []) or [])
            out.append(d)
        return out

    @app.get("/api/cves")
    def list_cves(kev_only: bool = False) -> list:
        from safecadence.enrichment.cve import load_cve_db
        db = load_cve_db()  # dict[vendor -> list[dict]]
        rows = []
        for vendor, items in (db or {}).items():
            for item in items:
                d = dict(item)
                d.setdefault("vendor", vendor)
                rows.append(d)
        if kev_only:
            rows = [r for r in rows if r.get("kev")]
        return rows

    @app.get("/api/eol")
    def list_eol() -> list:
        from safecadence.enrichment.eol import load_eol_db
        records = load_eol_db()  # list[EOLRecord]
        return [_to_jsonable(r) for r in records]

    @app.get("/api/devices")
    def list_devices() -> list:
        return _to_jsonable(store.latest_per_host())

    @app.get("/api/devices/{hostname}")
    def get_device(hostname: str) -> dict:
        for d in store.latest_per_host():
            if (d.get("source") == hostname or d.get("hostname") == hostname
                or d.get("parsed_summary", {}).get("hostname") == hostname):
                return _to_jsonable(d)
        raise HTTPException(404, f"device '{hostname}' not found")

    @app.get("/api/scans")
    def list_scans(limit: int = 50) -> list:
        return _to_jsonable(store.list(limit=limit))

    @app.get("/api/scans/{scan_id}")
    def get_scan(scan_id: int) -> dict:
        s = store.get(scan_id)
        if not s:
            raise HTTPException(404, f"scan #{scan_id} not found")
        return _to_jsonable(s)

    @app.get("/api/dashboard.json")
    def dashboard_json() -> dict:
        scans = store.list(limit=500)
        # store.list returns summary rows; build_dashboard_data expects full scan dicts
        full = [store.get(s["id"]) for s in scans if s.get("id") is not None]
        full = [s for s in full if s]
        data = build_dashboard_data(full, topology=None)
        return _to_jsonable(data.to_dict())

    @app.get("/api/dashboard.html", response_class=HTMLResponse)
    def dashboard_html() -> str:
        scans = store.list(limit=500)
        full = [store.get(s["id"]) for s in scans if s.get("id") is not None]
        full = [s for s in full if s]
        data = build_dashboard_data(full, topology=None)
        return render_dashboard(data, title="SafeCadence Local Dashboard")

    # ---------------------------------------------------------------- scan
    async def _scan_upload(upload: UploadFile) -> dict:
        content = await upload.read()
        suffix = Path(upload.filename or "config.txt").suffix or ".txt"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tf:
            tf.write(content)
            tmp_path = Path(tf.name)
        try:
            scan_result, _ = _scan_one(tmp_path)
            if scan_result is None:
                return {"error": "no adapter matched", "filename": upload.filename}
            d = scan_result.to_dict()
            store.save(d)
            return d
        finally:
            try:
                tmp_path.unlink()
            except Exception:
                pass

    @app.post("/api/scan")
    async def scan_one(file: UploadFile = File(...)) -> dict:
        return await _scan_upload(file)

    @app.post("/api/scan/bulk")
    async def scan_bulk(files: list[UploadFile] = File(...)) -> dict:
        results = []
        for f in files:
            try:
                results.append(await _scan_upload(f))
            except Exception as e:
                results.append({"error": str(e), "filename": f.filename})
        return {"count": len(results), "results": results}

    # ---------------------------------------------------------------- discover
    @app.post("/api/discover")
    def discover(payload: dict = Body(...)) -> dict:
        from safecadence.discovery import discover_subnet
        cidr = (payload or {}).get("cidr", "").strip()
        if not cidr:
            raise HTTPException(400, "cidr required (e.g. 10.10.10.0/24)")
        try:
            hosts = discover_subnet(cidr, workers=64)
        except Exception as e:
            raise HTTPException(400, f"discover failed: {e}")
        results = []
        for h in hosts:
            d = _to_jsonable(h)
            # Normalize commonly-used fields for the UI
            d.setdefault("ip", getattr(h, "ip", ""))
            d.setdefault("hostname", getattr(h, "hostname", "") or "")
            d.setdefault("vendor", getattr(h, "vendor_guess", "") or getattr(h, "vendor", ""))
            d.setdefault("os", getattr(h, "os_guess", "") or getattr(h, "os", ""))
            d.setdefault("open_ports", list(getattr(h, "open_ports", []) or []))
            results.append(d)
        return {"cidr": cidr, "count": len(results), "results": results}

    # ---------------------------------------------------------------- enrichment refresh
    @app.post("/api/enrichment/refresh")
    def refresh_enrichment(source: str = Query("all", regex="^(all|cve|eol|kev)$")) -> dict:
        from safecadence.enrichment import refresh as refresh_mod
        try:
            if source in ("all", "cve", "kev"):
                refresh_mod.refresh_kev(online=True)
            if source in ("all", "eol"):
                refresh_mod.refresh_eol(online=True)
        except Exception as e:
            raise HTTPException(500, f"refresh failed: {e}")
        return {"ok": True, "source": source,
                "refreshed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}

    # ---------------------------------------------------------------- AI explain
    @app.post("/api/ai/explain")
    def ai_explain(payload: dict = Body(...)) -> dict:
        from safecadence.ai.client import explain_findings
        from safecadence.core.schema import ScanResult

        scan_id = payload.get("scan_id")
        provider = payload.get("provider", "openai")
        api_key = payload.get("api_key", "")
        model = payload.get("model")
        if not scan_id:
            raise HTTPException(400, "scan_id required")
        if not api_key and provider != "ollama":
            raise HTTPException(400, "api_key required for openai/anthropic")

        try:
            sid = int(scan_id)
        except (TypeError, ValueError):
            raise HTTPException(400, f"invalid scan_id: {scan_id}")

        scan_dict = store.get(sid)
        if not scan_dict:
            raise HTTPException(404, f"scan #{sid} not found")

        # explain_findings expects a ScanResult dataclass, but reconstructing
        # one from a dict is fragile (nested dataclasses). Easier path: write
        # a small shim that reads the dict directly.
        try:
            text = explain_findings(
                _DictShim(scan_dict),
                provider=provider,
                api_key=api_key,
                model=model,
            )
        except Exception as e:
            raise HTTPException(502, f"AI provider error: {e}")
        return {"scan_id": sid, "explanation": text, "provider": provider}

    # ---------------------------------------------------------------- vault (read-only stub)
    @app.get("/api/vault/list")
    def vault_list() -> list:
        # The vault requires a key. Until we add a UI flow for unlocking it,
        # the vault tab is a status/info view only. Use `safecadence vault`
        # CLI to manage credentials.
        vault_path = Path.home() / ".safecadence" / "vault.json"
        return [{"name": "(vault unlocked via CLI only)", "created_at": ""}] if vault_path.exists() else []

    @app.post("/api/vault/add")
    def vault_add(payload: dict = Body(...)) -> dict:
        raise HTTPException(
            501,
            "Vault writes require a master key — use `safecadence vault set NAME` "
            "from the CLI for now. UI-side vault unlock arrives in v2.4.x.",
        )

    return app


class _DictShim:
    """Adapt a stored scan dict to look enough like ScanResult for AI client.

    The AI client reads a handful of fields off the ScanResult dataclass
    (findings, summary, hostname/source). A dict shim is simpler than
    reconstructing the nested dataclasses.
    """

    def __init__(self, d: dict):
        self._d = d
        # Expose top-level fields as attributes for attribute access
        for k, v in d.items():
            try:
                setattr(self, k, v)
            except Exception:
                pass
        # Common derived fields the AI prompt references
        if "hostname" not in d:
            self.hostname = (d.get("parsed_summary") or {}).get("hostname") or d.get("source") or "unknown"
        self.findings = d.get("findings", [])
        self.summary = d.get("summary", "")
        self.health_score = d.get("health_score", 0)
        self.risk_score = d.get("risk_score", 0)

    def to_dict(self) -> dict:
        return self._d


def _is_port_free(host: str, port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, port))
        return True
    except OSError:
        return False


def _open_browser_when_ready(url: str, delay: float = 1.0) -> None:
    def _open():
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=_open, daemon=True).start()


def run(*, host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True) -> None:
    _check_extras()
    import uvicorn

    if not _is_port_free(host, port):
        for candidate in range(port + 1, port + 21):
            if _is_port_free(host, candidate):
                port = candidate
                break
        else:
            sys.stderr.write(f"No free port near {port}; specify --port.\n")
            sys.exit(1)

    url = f"http://{host}:{port}/"
    sys.stdout.write(f"\n  SafeCadence Local UI starting at {url}\n  Press Ctrl-C to stop.\n\n")

    if open_browser:
        _open_browser_when_ready(url)

    app = create_app()
    uvicorn.run(app, host=host, port=port, log_level="warning", access_log=False)
