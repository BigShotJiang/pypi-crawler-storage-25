"""CLI module for adkbot."""
