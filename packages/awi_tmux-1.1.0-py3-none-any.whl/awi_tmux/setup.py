from setuptools import setup, find_packages
import os

# When built from the awi_tmux/ directory, the parent dir contains the package
setup(
    name="awi-tmux",
    version="1.0.0",
    package_dir={"": ".."},
    packages=["awi_tmux", "awi_tmux.api", "awi_tmux.cli", "awi_tmux.utils"],
    include_package_data=True,
    entry_points={"console_scripts": ["awi=awi_tmux.main:main", "awi-dl=awi_tmux.main:main"]},
    install_requires=[
        "requests>=2.28",
        "loguru>=0.6",
        "rich>=13.0",
        "beautifulsoup4>=4.11",
        "pyfzf>=0.3",
        "tqdm>=4.64",
    ],
)
