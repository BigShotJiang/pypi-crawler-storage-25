"""
AWIClient — scraper for watchanimeworld.net (Anime World India).

Pipeline:
  1. search(query)            — /?s=query  → list of {title, url, type, slug}
  2. get_series_info(url)     — /series/{slug}/ → seasons, episodes per season
  3. get_movie_info(url)      — /movies/{slug}/ → metadata + player hash
  4. get_episode_info(url)    — /episode/{slug}/ → metadata + player hash
  5. get_hls(hash)            — zephyrflick player API → HLS m3u8 URL
  6. get_variants(m3u8)       — parse master playlist → quality list
"""

from __future__ import annotations

import base64
import json
import re
import urllib.parse
from typing import Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from loguru import logger

from awi_tmux.utils.constants import (
    AWI_BASE,
    AWI_AJAX,
    ZEPHYR_BASE,
    ZEPHYR_PLAYER_API,
    USER_AGENT,
    TIMEOUT,
)

_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update(_HEADERS)
    return s


def _soup(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "html.parser")


def _decode_player1_data(data_b64: str) -> List[Dict]:
    """Decode base64 JSON language list from player1.php?data=…"""
    try:
        padded = data_b64 + "==" * (4 - len(data_b64) % 4 if len(data_b64) % 4 else 0)
        decoded = base64.b64decode(padded).decode("utf-8", errors="replace")
        return json.loads(decoded)
    except Exception as e:
        logger.debug(f"player1 decode error: {e}")
        return []


def _extract_zephyr_hash(html: str) -> Optional[str]:
    """Extract zephyrflick video hash from page HTML."""
    m = re.search(r"zephyrflick\.top/video/([a-f0-9]{32})", html)
    return m.group(1) if m else None


def _extract_nonce(html: str) -> str:
    """Extract WordPress nonce from torofilm_Public JS object."""
    m = re.search(r'"nonce"\s*:\s*"([a-f0-9]+)"', html)
    return m.group(1) if m else ""


def _parse_master_playlist(master_url: str, text: str) -> List[Dict]:
    """Parse HLS master playlist into quality variant list."""
    # Derive the scheme+host base (e.g. https://play.zephyrflick.top)
    parsed = urllib.parse.urlparse(master_url)
    host_base = f"{parsed.scheme}://{parsed.netloc}"
    dir_base = master_url.rsplit("/", 1)[0]

    variants = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("#EXT-X-STREAM-INF"):
            res = re.search(r"RESOLUTION=(\d+x\d+)", line)
            bw = re.search(r"BANDWIDTH=(\d+)", line)
            quality = ""
            if res:
                h = int(res.group(1).split("x")[1])
                quality = f"{h}p"
            elif bw:
                quality = f"{int(bw.group(1))//1000}k"
            if i + 1 < len(lines):
                url = lines[i + 1].strip()
                if url and not url.startswith("#"):
                    if url.startswith("http"):
                        pass
                    elif url.startswith("/"):
                        url = host_base + url
                    else:
                        url = dir_base + "/" + url
                    variants.append({"quality": quality or "unknown", "url": url})
    return variants


class AWIClient:
    """Anime World India client — no browser, no cloudscraper."""

    def __init__(self):
        self._session = _session()

    def _get(self, url: str, **kwargs) -> requests.Response:
        return self._session.get(url, timeout=TIMEOUT, **kwargs)

    def _post(self, url: str, **kwargs) -> requests.Response:
        return self._session.post(url, timeout=TIMEOUT, **kwargs)

    # ------------------------------------------------------------------
    # 1. Search
    # ------------------------------------------------------------------

    def search(self, query: str) -> List[Dict]:
        """Search watchanimeworld.net, return list of results."""
        logger.info(f"Searching: {query}")
        try:
            r = self._get(f"{AWI_BASE}/", params={"s": query})
            r.raise_for_status()
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []

        soup = _soup(r.text)
        results = []

        for article in soup.select("article, .post-item, .item, .result-item"):
            a = article.select_one("a[href]")
            if not a:
                continue
            href = a.get("href", "")
            if not href.startswith(AWI_BASE):
                continue

            title_el = article.select_one("h2, h3, .title, .entry-title")
            title = title_el.get_text(strip=True) if title_el else a.get_text(strip=True)

            img = article.select_one("img")
            poster = img.get("src") or img.get("data-src") if img else ""

            kind = "series" if "/series/" in href else "movie" if "/movies/" in href else "unknown"

            results.append({
                "title": title,
                "url": href,
                "type": kind,
                "slug": href.rstrip("/").split("/")[-1],
                "poster": poster,
            })

        if not results:
            results = self._search_fallback(r.text, query)

        logger.info(f"Found {len(results)} results")
        return results

    def _search_fallback(self, html: str, query: str) -> List[Dict]:
        """Fallback: extract links directly via regex when no article tags."""
        results = []
        seen = set()
        for m in re.finditer(
            r'href=["\'](' + re.escape(AWI_BASE) + r'/(?:series|movies)/([^"\'<>\s]+))["\']',
            html,
        ):
            url, slug = m.group(1), m.group(2).rstrip("/")
            if url in seen:
                continue
            seen.add(url)
            kind = "series" if "/series/" in url else "movie"
            results.append({"title": slug.replace("-", " ").title(), "url": url, "type": kind, "slug": slug, "poster": ""})
        return results

    # ------------------------------------------------------------------
    # 2. Series info (seasons + episodes)
    # ------------------------------------------------------------------

    def get_series_info(self, url: str) -> Dict:
        """
        Fetch series page. Returns:
          {title, poster, description, seasons: [{number, episodes: [{title, url, ep_num}]}]}
        """
        logger.info(f"Fetching series: {url}")
        try:
            r = self._get(url)
            r.raise_for_status()
        except Exception as e:
            logger.error(f"Series page failed: {e}")
            return {}

        soup = _soup(r.text)
        html = r.text

        title_el = soup.select_one("h1, .entry-title, .title")
        title = title_el.get_text(strip=True) if title_el else url.rstrip("/").split("/")[-1]

        img = soup.select_one(".poster img, .thumb img, .entry-content img")
        poster = (img.get("src") or img.get("data-src", "")) if img else ""

        desc_el = soup.select_one(".sinopsis, .description, .entry-content p")
        description = desc_el.get_text(strip=True) if desc_el else ""

        nonce = _extract_nonce(html)
        post_id = self._extract_post_id(html)

        season_tabs = soup.select("[data-season]")
        season_numbers = sorted(set(
            int(el.get("data-season", 0)) for el in season_tabs if el.get("data-season", "").isdigit()
        ))

        if not season_numbers:
            season_numbers = [1]

        seasons = []
        for snum in season_numbers:
            eps = self._get_season_episodes(url, html, snum, post_id, nonce)
            if eps:
                seasons.append({"number": snum, "episodes": eps})

        return {
            "title": title,
            "url": url,
            "type": "series",
            "poster": poster,
            "description": description,
            "seasons": seasons,
        }

    def _extract_post_id(self, html: str) -> str:
        """Extract WordPress post ID from page HTML."""
        for pat in [r'data-post=["\'](\d+)["\']', r'"post_id"\s*:\s*(\d+)', r'postid-(\d+)']:
            m = re.search(pat, html)
            if m:
                return m.group(1)
        return ""

    def _get_season_episodes(self, series_url: str, html: str, season: int, post_id: str, nonce: str) -> List[Dict]:
        """Get episodes for a specific season — via AJAX first, then HTML fallback."""
        # Always try AJAX first (site loads latest season in HTML, not season 1)
        if post_id and nonce:
            episodes = self._ajax_season_episodes(post_id, season, nonce, series_url)
            if episodes:
                return episodes

        # Fallback: parse episodes from page HTML (only works for the default season)
        episodes = self._parse_episodes_from_html(html, season)
        if episodes:
            return episodes

        # Last resort: re-fetch with season param
        return self._fetch_season_via_url(series_url, season)

    def _parse_episodes_from_html(self, html: str, target_season: int) -> List[Dict]:
        """Parse episode list from embedded HTML."""
        soup = _soup(html)
        episodes = []

        for a in soup.select("a[href*='/episode/']"):
            href = a.get("href", "")
            if not href.startswith(AWI_BASE):
                continue
            slug = href.rstrip("/").split("/")[-1]
            # slug format: {series}-{season}x{episode}
            m = re.search(r"-(\d+)x(\d+)$", slug)
            if m:
                s_num = int(m.group(1))
                ep_num = int(m.group(2))
                if s_num != target_season:
                    continue
            else:
                ep_num = len(episodes) + 1

            title_el = a.select_one(".title, span, p") or a
            ep_title = title_el.get_text(strip=True) or f"Episode {ep_num}"

            episodes.append({
                "title": ep_title,
                "url": href,
                "ep_num": ep_num,
                "season": target_season,
                "slug": slug,
            })

        return sorted(episodes, key=lambda x: x["ep_num"])

    def _ajax_season_episodes(self, post_id: str, season: int, nonce: str, referer: str) -> List[Dict]:
        """Load season episodes via WordPress AJAX (action_select_season)."""
        try:
            r = self._post(
                AWI_AJAX,
                headers={
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": referer,
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data={
                    "action": "action_select_season",
                    "post": post_id,
                    "season": str(season),
                    "nonce": nonce,
                },
            )
            body = r.text.strip() if r.text else ""
            if body and body != "0":
                return self._parse_episodes_from_html(body, season)
        except Exception as e:
            logger.debug(f"Season AJAX failed (s{season}): {e}")
        return []

    def _fetch_season_via_url(self, series_url: str, season: int) -> List[Dict]:
        """Re-fetch series page with season query param."""
        try:
            r = self._get(series_url, params={"season": season})
            return self._parse_episodes_from_html(r.text, season)
        except Exception:
            return []

    # ------------------------------------------------------------------
    # 3. Movie info
    # ------------------------------------------------------------------

    def get_movie_info(self, url: str) -> Dict:
        """Fetch movie page, return {title, url, hash, languages, poster}."""
        logger.info(f"Fetching movie: {url}")
        try:
            r = self._get(url)
            r.raise_for_status()
        except Exception as e:
            logger.error(f"Movie page failed: {e}")
            return {}

        soup = _soup(r.text)
        html = r.text

        title_el = soup.select_one("h1, .entry-title, .title")
        title = title_el.get_text(strip=True) if title_el else url.rstrip("/").split("/")[-1]

        img = soup.select_one(".poster img, .thumb img")
        poster = (img.get("src") or img.get("data-src", "")) if img else ""

        zephyr_hash = _extract_zephyr_hash(html)
        languages = self._extract_languages(html)

        return {
            "title": title,
            "url": url,
            "type": "movie",
            "slug": url.rstrip("/").split("/")[-1],
            "poster": poster,
            "hash": zephyr_hash,
            "languages": languages,
        }

    # ------------------------------------------------------------------
    # 4. Episode info
    # ------------------------------------------------------------------

    def get_episode_info(self, url: str) -> Dict:
        """Fetch episode page, return {title, url, hash, languages, season, ep_num}."""
        logger.info(f"Fetching episode: {url}")
        try:
            r = self._get(url)
            r.raise_for_status()
        except Exception as e:
            logger.error(f"Episode page failed: {e}")
            return {}

        soup = _soup(r.text)
        html = r.text

        title_el = soup.select_one("h1, .entry-title, .title")
        title = title_el.get_text(strip=True) if title_el else url.rstrip("/").split("/")[-1]

        zephyr_hash = _extract_zephyr_hash(html)
        languages = self._extract_languages(html)

        slug = url.rstrip("/").split("/")[-1]
        m = re.search(r"-(\d+)x(\d+)$", slug)
        season = int(m.group(1)) if m else 1
        ep_num = int(m.group(2)) if m else 1

        return {
            "title": title,
            "url": url,
            "type": "episode",
            "slug": slug,
            "hash": zephyr_hash,
            "languages": languages,
            "season": season,
            "ep_num": ep_num,
        }

    def _extract_languages(self, html: str) -> List[Dict]:
        """Extract language list from player1.php data param."""
        m = re.search(r'player1\.php\?data=([A-Za-z0-9+/=%]+)', html)
        if not m:
            return []
        raw = urllib.parse.unquote(m.group(1))
        return _decode_player1_data(raw)

    # ------------------------------------------------------------------
    # 5. Get HLS stream URL
    # ------------------------------------------------------------------

    def get_hls(self, zephyr_hash: str) -> Optional[str]:
        """
        Call the zephyrflick player API and return the HLS master m3u8 URL.
        The session must have visited the embed page first (cookies).
        """
        if not zephyr_hash:
            return None

        embed_url = f"{ZEPHYR_BASE}/video/{zephyr_hash}"
        try:
            # Visit embed page first to get cookies
            self._get(embed_url)
        except Exception as e:
            logger.debug(f"Embed page visit failed: {e}")

        try:
            r = self._post(
                f"{ZEPHYR_PLAYER_API}?data={zephyr_hash}&do=getVideo",
                headers={
                    "Referer": embed_url,
                    "X-Requested-With": "XMLHttpRequest",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data={"hash": zephyr_hash, "r": AWI_BASE + "/"},
            )
            if not r.text.strip():
                logger.warning("Empty response from player API")
                return None
            data = r.json()
            url = data.get("videoSource") or data.get("securedLink")
            if url:
                logger.debug(f"HLS URL: {url[:80]}…")
            return url
        except Exception as e:
            logger.error(f"Player API failed: {e}")
            return None

    # ------------------------------------------------------------------
    # 6. Parse quality variants
    # ------------------------------------------------------------------

    def get_variants(self, master_url: str, referer: str = "") -> List[Dict]:
        """Fetch and parse HLS master playlist for quality variants."""
        try:
            hdr = {"User-Agent": USER_AGENT}
            if referer:
                hdr["Referer"] = referer
            r = requests.get(master_url, headers=hdr, timeout=TIMEOUT)
            r.raise_for_status()
            return _parse_master_playlist(master_url, r.text)
        except Exception as e:
            logger.debug(f"Master playlist fetch failed: {e}")
            return []

    # ------------------------------------------------------------------
    # Browse / listing
    # ------------------------------------------------------------------

    def browse(self, kind: str = "series", page: int = 1) -> List[Dict]:
        """Browse latest series or movies."""
        url = f"{AWI_BASE}/category/{'series' if kind == 'series' else 'movies'}/"
        try:
            r = self._get(url, params={"paged": page} if page > 1 else {})
            r.raise_for_status()
        except Exception as e:
            logger.error(f"Browse failed: {e}")
            return []
        return self._search_fallback(r.text, "")
