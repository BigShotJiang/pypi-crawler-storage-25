"""
HLS downloader for awi-tmux.
Saves each segment to disk individually — supports resume on interruption.
"""

from __future__ import annotations

import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional, Tuple

import requests
from loguru import logger
from tqdm import tqdm

from awi_tmux.utils.constants import USER_AGENT, TIMEOUT

_HEADERS = {"User-Agent": USER_AGENT}


def _make_headers(referer: str = "") -> dict:
    h = dict(_HEADERS)
    if referer:
        h["Referer"] = referer
    return h


def _fetch_playlist(url: str, referer: str = "") -> Tuple[List[str], str]:
    """Fetch an m3u8 playlist and return (segment_urls, base_url)."""
    r = requests.get(url, headers=_make_headers(referer), timeout=TIMEOUT)
    r.raise_for_status()
    parsed = url.rsplit("/", 1)[0]
    from urllib.parse import urlparse
    p = urlparse(url)
    host_base = f"{p.scheme}://{p.netloc}"
    lines = r.text.splitlines()
    segments = []
    for line in lines:
        line = line.strip()
        if line and not line.startswith("#"):
            if line.startswith("http"):
                segments.append(line)
            elif line.startswith("/"):
                segments.append(host_base + line)
            else:
                segments.append(f"{parsed}/{line}")
    return segments, parsed


def _download_one(idx: int, url: str, out_path: str, referer: str) -> Tuple[int, bool]:
    """Download a single segment to disk. Returns (idx, success)."""
    if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
        return idx, True

    for attempt in range(4):
        try:
            r = requests.get(url, headers=_make_headers(referer), timeout=TIMEOUT, stream=True)
            r.raise_for_status()
            with open(out_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=65536):
                    f.write(chunk)
            return idx, True
        except Exception as e:
            if attempt == 3:
                logger.warning(f"Segment {idx} failed after 4 tries: {e}")
                return idx, False
            time.sleep(1.5 * (attempt + 1))
    return idx, False


def download_hls(
    playlist_url: str,
    output_path: str,
    referer: str = "",
    workers: int = 4,
) -> bool:
    """
    Download an HLS playlist to a single .ts file with resume support.

    Segments are saved individually to {output_path}_segments/ so that
    interrupted downloads can resume — already-downloaded segments are skipped.

    Args:
        playlist_url: URL of the variant (non-master) m3u8.
        output_path:  Full path of the output .ts file.
        referer:      Referer header for segment requests.
        workers:      Number of parallel download threads.

    Returns:
        True on success, False on failure.
    """
    if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
        logger.info(f"Already downloaded: {output_path}")
        return True

    try:
        segments, _ = _fetch_playlist(playlist_url, referer)
    except Exception as e:
        logger.error(f"Failed to fetch playlist: {e}")
        return False

    if not segments:
        logger.error("No segments found in playlist")
        return False

    seg_dir = output_path.rsplit(".", 1)[0] + "_segments"
    Path(seg_dir).mkdir(parents=True, exist_ok=True)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    seg_paths = [os.path.join(seg_dir, f"seg_{i:06d}.ts") for i in range(len(segments))]

    already = sum(1 for p in seg_paths if os.path.exists(p) and os.path.getsize(p) > 0)
    pending = [(i, segments[i], seg_paths[i]) for i in range(len(segments))
               if not (os.path.exists(seg_paths[i]) and os.path.getsize(seg_paths[i]) > 0)]

    if already:
        logger.info(f"Resuming: {already} segments already done, {len(pending)} remaining")
    else:
        logger.info(f"Downloading {len(segments)} segments → {output_path}")

    failed_count = 0

    if pending:
        with tqdm(total=len(segments), initial=already, unit="seg",
                  desc="Downloading", ncols=80) as pbar:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(_download_one, i, url, path, referer): i
                    for i, url, path in pending
                }
                for fut in as_completed(futures):
                    _, ok = fut.result()
                    if not ok:
                        failed_count += 1
                    pbar.update(1)

    if failed_count > 0:
        total = len(segments)
        if failed_count > total * 0.05:
            logger.error(f"{failed_count}/{total} segments failed — run again to resume")
            return False
        logger.warning(f"{failed_count} segments failed (< 5%) — merging anyway")

    logger.info("Merging segments…")
    total_bytes = 0
    with open(output_path, "wb") as out_f:
        for p in seg_paths:
            if os.path.exists(p):
                with open(p, "rb") as seg_f:
                    chunk = seg_f.read()
                    out_f.write(chunk)
                    total_bytes += len(chunk)

    size_mb = total_bytes / 1_048_576
    logger.success(f"Saved: {output_path} ({size_mb:.1f} MB)")

    import shutil
    shutil.rmtree(seg_dir, ignore_errors=True)

    return True
