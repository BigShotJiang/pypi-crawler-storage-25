"""
awi-tmux — Anime World India CLI for Termux ARM64.

Streams & downloads Hindi/Tamil/Telugu/Malayalam/Kannada/English dubbed anime
from watchanimeworld.net. No browser required.

Usage:
  awi "naruto"                          search and download interactively
  awi --browse series                   browse latest series
  awi --browse movie                    browse latest movies
  awi "dragon ball z" --type series     search series only
  awi "naruto" --language Tamil         download Tamil dub
  awi "naruto" --episodes 1-10          batch download episodes 1-10
  awi "boruto" --play                   stream in mpv
  awi --url https://watchanimeworld.net/series/naruto/  direct URL
  awi --config                          show/edit config file
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from loguru import logger

from awi_tmux.cli.commands import cmd_search, cmd_series, cmd_movie, cmd_browse
from awi_tmux.utils import config
from awi_tmux.utils.constants import LANGUAGES

__version__ = "1.1.0"


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="awi",
        description="Anime World India downloader for Termux — watchanimeworld.net, no browser needed",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("query", nargs="?", metavar="query", help="Title to search for")
    p.add_argument("--url", "-u", metavar="URL", help="Direct URL to a series/movie/episode page")
    p.add_argument("--browse", "-b", metavar="{series,movie}", choices=["series", "movie"],
                   help="Browse latest series or movies")
    p.add_argument("--type", "-t", metavar="{series,movie}", choices=["series", "movie"],
                   dest="kind", help="Filter search to series or movie")
    p.add_argument("--language", "-l", metavar="LANG", default=None,
                   help=f"Preferred dub language: {', '.join(LANGUAGES)} (default: from config)")
    p.add_argument("--quality", "-q", metavar="QUALITY", default=None,
                   help="Preferred quality: best, 720p, 480p, 360p, 240p (default: from config)")
    p.add_argument("--episodes", "-e", metavar="RANGE",
                   help="Episode range: '1', '1-5', '1,3,5', 'all'")
    p.add_argument("--output", "-o", metavar="DIR", default=None,
                   dest="output_dir", help="Download directory (default: from config)")
    p.add_argument("--play", action="store_true", help="Stream in mpv instead of downloading")
    p.add_argument("--player", metavar="PLAYER", default=None,
                   help="Media player for --play (default: from config)")
    p.add_argument("--workers", "-w", metavar="N", type=int, default=None,
                   help="Parallel download workers (default: from config)")
    p.add_argument("--no-interactive", action="store_true",
                   help="Auto-select first result/server (batch mode)")
    p.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")
    p.add_argument("--config", action="store_true", dest="show_config",
                   help="Show or edit the config file (~/.config/awi-tmux/config.ini)")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main():
    parser = _build_parser()
    args = parser.parse_args()

    if args.verbose or config.is_verbose():
        logger.remove()
        import sys as _sys
        logger.add(_sys.stderr, level="DEBUG", colorize=True,
                   format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}")

    if args.show_config:
        config.cmd_show_config()
        from rich.console import Console
        Console().print("\n[dim]Edit with:[/dim] nano ~/.config/awi-tmux/config.ini\n")
        return

    # Resolve from config if not provided via CLI
    output_dir = args.output_dir or config.get_download_dir()
    workers = args.workers if args.workers is not None else config.get_workers()
    quality = args.quality or config.get_quality()
    language = args.language or config.get_language()
    player = args.player or config.get_player()

    common = dict(
        language=language,
        quality=quality,
        play=args.play,
        player=player,
        output_dir=output_dir,
        workers=workers,
        no_interactive=args.no_interactive,
    )

    if args.browse:
        cmd_browse(kind=args.browse, **common)
        return

    if args.url:
        url = args.url.rstrip("/")
        if "/series/" in url:
            cmd_series(url, episodes=args.episodes, **common)
        elif "/movies/" in url:
            cmd_movie(url, **{k: v for k, v in common.items() if k != "episodes"})
        elif "/episode/" in url:
            from awi_tmux.api.client import AWIClient
            from awi_tmux.cli.commands import _handle_stream
            client = AWIClient()
            info = client.get_episode_info(url)
            if info:
                _handle_stream(client, info, language, quality,
                               args.play, player, output_dir,
                               workers, args.no_interactive)
        else:
            parser.error("Unknown URL type. Expected /series/, /movies/, or /episode/ URL.")
        return

    if args.query:
        cmd_search(
            args.query,
            kind=args.kind,
            episodes=args.episodes,
            **common,
        )
        return

    parser.print_help()


if __name__ == "__main__":
    main()
