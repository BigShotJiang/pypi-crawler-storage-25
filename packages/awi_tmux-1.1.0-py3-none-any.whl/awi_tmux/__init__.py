"""awi-tmux — Anime World India CLI for Termux."""
__version__ = "1.0.0"
