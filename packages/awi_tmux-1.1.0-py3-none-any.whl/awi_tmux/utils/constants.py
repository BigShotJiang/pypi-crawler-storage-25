AWI_BASE = "https://watchanimeworld.net"
AWI_AJAX = f"{AWI_BASE}/wp-admin/admin-ajax.php"
ZEPHYR_BASE = "https://play.zephyrflick.top"
ZEPHYR_PLAYER_API = f"{ZEPHYR_BASE}/player/index.php"

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 11; Pixel 5) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Mobile Safari/537.36"
)
TIMEOUT = 20

LANGUAGES = ["Hindi", "Tamil", "Telugu", "Malayalam", "Kannada", "English", "Japanese"]
DEFAULT_LANGUAGE = "Hindi"
