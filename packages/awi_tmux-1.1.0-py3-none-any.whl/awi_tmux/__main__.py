from awi_tmux.main import main
main()
