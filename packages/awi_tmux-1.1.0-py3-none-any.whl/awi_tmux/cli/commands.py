"""
CLI command handlers for awi-tmux.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from loguru import logger
from rich.console import Console
from rich.table import Table

from awi_tmux.api.client import AWIClient
from awi_tmux.api.downloader import download_hls
from awi_tmux.utils import config as _cfg
from awi_tmux.utils.constants import DEFAULT_LANGUAGE, LANGUAGES, ZEPHYR_BASE

console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _pick_fzf(items: List[str], prompt: str = "Select: ") -> Optional[str]:
    """Use fzf for interactive selection, fall back to numbered menu."""
    try:
        from pyfzf import FzfPrompt
        fzf = FzfPrompt()
        chosen = fzf.prompt(items, f"--prompt='{prompt}' --height=40% --reverse")
        return chosen[0] if chosen else None
    except Exception:
        pass

    console.print(f"\n[bold]{prompt}[/bold]")
    for i, item in enumerate(items, 1):
        console.print(f"  [cyan]{i:>3}[/cyan]  {item}")
    try:
        raw = input("Enter number (or q to quit): ").strip()
        if raw.lower() == "q":
            return None
        idx = int(raw) - 1
        if 0 <= idx < len(items):
            return items[idx]
    except (ValueError, EOFError):
        pass
    return None


def _print_results(results: List[Dict]):
    t = Table(title="Results", show_lines=False)
    t.add_column("#", style="cyan", width=4)
    t.add_column("Title", style="bold")
    t.add_column("Type", width=8)
    t.add_column("Slug", style="dim")
    for i, r in enumerate(results, 1):
        t.add_row(str(i), r["title"], r["type"], r.get("slug", ""))
    console.print(t)


def _print_seasons(seasons: List[Dict]):
    t = Table(title="Seasons", show_lines=False)
    t.add_column("#", style="cyan", width=4)
    t.add_column("Season", style="bold")
    t.add_column("Episodes", width=10)
    for s in seasons:
        t.add_row(str(s["number"]), f"Season {s['number']}", str(len(s["episodes"])))
    console.print(t)


def _print_episodes(episodes: List[Dict]):
    t = Table(title="Episodes", show_lines=False)
    t.add_column("#", style="cyan", width=5)
    t.add_column("Episode", style="bold")
    for ep in episodes:
        t.add_row(str(ep["ep_num"]), ep["title"])
    console.print(t)


def _print_languages(languages: List[Dict]):
    t = Table(title="Languages", show_lines=False)
    t.add_column("#", style="cyan", width=4)
    t.add_column("Language", style="bold")
    for i, lang in enumerate(languages, 1):
        t.add_row(str(i), lang["language"])
    console.print(t)


def _choose_quality(variants: List[Dict], preferred: str = "best") -> str:
    if not variants:
        return ""

    t = Table(title="Quality Options", show_lines=False)
    t.add_column("#", style="cyan", width=4)
    t.add_column("Quality", style="bold")
    for i, v in enumerate(variants, 1):
        t.add_row(str(i), v["quality"])
    console.print(t)

    if preferred == "best":
        return variants[0]["url"]

    for v in variants:
        if v["quality"] == preferred:
            return v["url"]

    return variants[0]["url"]


def _parse_episode_range(spec: str, max_ep: int) -> List[int]:
    """Parse episode range: '1', '1-5', '1,3,5', 'all'."""
    if spec.lower() == "all":
        return list(range(1, max_ep + 1))
    nums = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            nums.update(range(int(a), int(b) + 1))
        else:
            nums.add(int(part))
    return sorted(n for n in nums if 1 <= n <= max_ep)


def _safe_filename(title: str) -> str:
    return re.sub(r'[\\/:*?"<>|]', "", title).strip().replace(" ", "_")


def _play_stream(url: str, title: str = "", player: str = "mpv", referer: str = ""):
    """Play a stream URL with the system media player."""
    cmd = [player, url]
    if player == "mpv":
        cmd += ["--no-terminal", "--quiet"]
        if referer:
            cmd += [f"--referrer={referer}"]
        if title:
            cmd += [f"--title={title}"]
    elif player == "vlc":
        cmd += ["--quiet"]
        if referer:
            cmd += [f"--http-referrer={referer}"]

    logger.info(f"Launching {player}: {title or url[:60]}")
    try:
        subprocess.run(cmd, check=False)
    except FileNotFoundError:
        logger.error(f"Player not found: {player}. Install it with: pkg install {player}")
    except Exception as e:
        logger.error(f"Player error: {e}")


# ---------------------------------------------------------------------------
# Core download/play logic
# ---------------------------------------------------------------------------

def _handle_stream(
    client: AWIClient,
    info: Dict,
    language: str,
    quality: str,
    play: bool,
    player: str,
    output_dir: str,
    workers: int,
    no_interactive: bool,
):
    """Common logic: get HLS → pick quality → download or play."""
    zephyr_hash = info.get("hash")
    if not zephyr_hash:
        console.print("[red]No video player found on this page.[/red]")
        return

    # Pick language
    languages = info.get("languages", [])
    if languages:
        _print_languages(languages)
        lang_names = [l["language"] for l in languages]

        if no_interactive:
            chosen_lang = next((l for l in languages if l["language"].lower() == language.lower()), languages[0])
        else:
            chosen_name = _pick_fzf(lang_names, "Select language: ")
            chosen_lang = next((l for l in languages if l["language"] == chosen_name), languages[0]) if chosen_name else languages[0]

        console.print(f"→ Language: [bold]{chosen_lang['language']}[/bold]")

    logger.info("Fetching HLS stream…")
    hls_url = client.get_hls(zephyr_hash)

    if not hls_url:
        console.print("[red]Could not extract HLS stream.[/red]")
        return

    referer = ZEPHYR_BASE + "/"
    variants = client.get_variants(hls_url, referer=referer)

    if variants:
        playlist_url = _choose_quality(variants, quality)
        if not no_interactive and quality == "best":
            labels = [v["quality"] for v in variants]
            chosen_q = _pick_fzf(labels, "Select quality: ")
            if chosen_q:
                chosen_v = next((v for v in variants if v["quality"] == chosen_q), variants[0])
                playlist_url = chosen_v["url"]
    else:
        playlist_url = hls_url

    logger.info(f"Stream: {playlist_url[:80]}…")

    if play:
        _play_stream(playlist_url, title=info.get("title", ""), player=player, referer=referer)
        return

    # Download
    title = info.get("title", "video")
    season = info.get("season")
    ep_num = info.get("ep_num")

    if season and ep_num:
        fname = f"{_safe_filename(title)}_S{season:02d}E{ep_num:02d}.ts"
    else:
        fname = f"{_safe_filename(title)}.ts"

    out_path = os.path.join(output_dir, fname)
    download_hls(playlist_url, out_path, referer=referer, workers=workers)


# ---------------------------------------------------------------------------
# Main command handlers
# ---------------------------------------------------------------------------

def cmd_search(
    query: str,
    kind: Optional[str] = None,
    language: str = DEFAULT_LANGUAGE,
    quality: str = "best",
    episodes: Optional[str] = None,
    play: bool = False,
    player: str = "mpv",
    output_dir: Optional[str] = None,
    workers: int = 4,
    no_interactive: bool = False,
):
    output_dir = output_dir or _cfg.get_download_dir()
    client = AWIClient()
    results = client.search(query)

    if not results:
        console.print("[red]No results found.[/red]")
        return

    if kind:
        results = [r for r in results if r["type"] == kind]
        if not results:
            console.print(f"[red]No {kind} results found.[/red]")
            return

    _print_results(results)

    if no_interactive:
        chosen = results[0]
    else:
        labels = [f"{r['title']} ({r['type']})" for r in results]
        chosen_label = _pick_fzf(labels, "Select title: ")
        if not chosen_label:
            return
        idx = labels.index(chosen_label)
        chosen = results[idx]

    console.print(f"\n→ [bold]{chosen['title']}[/bold] ({chosen['type']})")

    if chosen["type"] == "series":
        cmd_series(
            chosen["url"],
            language=language,
            quality=quality,
            episodes=episodes,
            play=play,
            player=player,
            output_dir=output_dir,
            workers=workers,
            no_interactive=no_interactive,
            client=client,
        )
    else:
        info = client.get_movie_info(chosen["url"])
        if not info:
            console.print("[red]Could not fetch movie info.[/red]")
            return
        _handle_stream(client, info, language, quality, play, player, output_dir, workers, no_interactive)


def cmd_series(
    url: str,
    language: str = DEFAULT_LANGUAGE,
    quality: str = "best",
    episodes: Optional[str] = None,
    play: bool = False,
    player: str = "mpv",
    output_dir: Optional[str] = None,
    workers: int = 4,
    no_interactive: bool = False,
    client: Optional[AWIClient] = None,
):
    output_dir = output_dir or _cfg.get_download_dir()
    if client is None:
        client = AWIClient()

    info = client.get_series_info(url)
    if not info or not info.get("seasons"):
        console.print("[red]Could not fetch series info or no episodes found.[/red]")
        return

    seasons = info["seasons"]
    _print_seasons(seasons)

    # Pick season
    if no_interactive or len(seasons) == 1:
        chosen_season = seasons[0]
    else:
        season_labels = [f"Season {s['number']} ({len(s['episodes'])} episodes)" for s in seasons]
        chosen_label = _pick_fzf(season_labels, "Select season: ")
        if not chosen_label:
            return
        idx = season_labels.index(chosen_label)
        chosen_season = seasons[idx]

    eps = chosen_season["episodes"]
    if not eps:
        console.print("[red]No episodes found for this season.[/red]")
        return

    _print_episodes(eps)

    # Determine which episodes to download
    if episodes:
        ep_nums = _parse_episode_range(episodes, len(eps))
        selected_eps = [ep for ep in eps if ep["ep_num"] in ep_nums]
    elif no_interactive:
        selected_eps = [eps[0]]
    else:
        ep_labels = [f"Ep {ep['ep_num']}: {ep['title']}" for ep in eps]
        chosen_label = _pick_fzf(ep_labels, "Select episode (or pick a range with --episodes): ")
        if not chosen_label:
            return
        idx = ep_labels.index(chosen_label)
        selected_eps = [eps[idx]]

    for ep in selected_eps:
        console.print(f"\n→ [bold]{ep['title']}[/bold] (S{ep.get('season',1):02d}E{ep['ep_num']:02d})")
        ep_info = client.get_episode_info(ep["url"])
        if not ep_info:
            console.print(f"[red]Could not fetch episode info.[/red]")
            continue
        _handle_stream(client, ep_info, language, quality, play, player, output_dir, workers, no_interactive)


def cmd_movie(
    url: str,
    language: str = DEFAULT_LANGUAGE,
    quality: str = "best",
    play: bool = False,
    player: str = "mpv",
    output_dir: Optional[str] = None,
    workers: int = 4,
    no_interactive: bool = False,
):
    output_dir = output_dir or _cfg.get_download_dir()
    client = AWIClient()
    info = client.get_movie_info(url)
    if not info:
        console.print("[red]Could not fetch movie info.[/red]")
        return
    _handle_stream(client, info, language, quality, play, player, output_dir, workers, no_interactive)


def cmd_browse(
    kind: str = "series",
    language: str = DEFAULT_LANGUAGE,
    quality: str = "best",
    play: bool = False,
    player: str = "mpv",
    output_dir: Optional[str] = None,
    workers: int = 4,
    no_interactive: bool = False,
):
    output_dir = output_dir or _cfg.get_download_dir()
    client = AWIClient()
    results = client.browse(kind)
    if not results:
        console.print("[red]No results.[/red]")
        return

    _print_results(results)

    labels = [f"{r['title']} ({r['type']})" for r in results]
    chosen_label = _pick_fzf(labels, f"Select {kind}: ")
    if not chosen_label:
        return
    idx = labels.index(chosen_label)
    chosen = results[idx]

    console.print(f"\n→ [bold]{chosen['title']}[/bold]")
    if chosen["type"] == "series":
        cmd_series(chosen["url"], language=language, quality=quality, play=play,
                   player=player, output_dir=output_dir, workers=workers, no_interactive=no_interactive)
    else:
        cmd_movie(chosen["url"], language=language, quality=quality, play=play,
                  player=player, output_dir=output_dir, workers=workers, no_interactive=no_interactive)
