"""
setup.py — configuração de instalação da biblioteca ppgrns_estatistica.

Este arquivo deve ficar NO DIRETÓRIO RAIZ do projeto, ao lado da pasta
ppgrns_estatistica/. Estrutura esperada:

    meu_projeto/
    ├── setup.py           ← este arquivo
    ├── README.md
    └── ppgrns_estatistica/
        ├── __init__.py
        ├── _utils.py
        ├── posicao.py
        ├── dispersao.py
        ├── inferencia.py
        ├── boxplot.py
        ├── histograma.py
        ├── carregar.py
        └── csv_xlsx.py

Instalação local (modo editável, ideal durante o desenvolvimento):
    pip install -e .

Instalação normal:
    pip install .
"""

from pathlib import Path
from setuptools import setup, find_packages

this_dir = Path(__file__).parent
readme_path = this_dir / "README.md"
long_description = (
    readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""
)

setup(
    name="ppgrns_estatistica",
    version="0.1.6",
    author="Evandro A. Nakajima",
    description="Biblioteca de suporte estatístico para o PPGRNS - UTFPR",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy",
        "scipy",
        "matplotlib",
        "openpyxl",
        "odfpy",
    ],
    extras_require={
        "interativo": ["ipywidgets"],
    },
    python_requires=">=3.8",
)