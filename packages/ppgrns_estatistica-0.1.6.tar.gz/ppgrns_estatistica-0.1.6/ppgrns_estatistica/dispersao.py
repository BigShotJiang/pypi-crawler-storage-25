"""
ppgrns_estatistica.dispersao
────────────────────────────
Medidas de dispersão e forma: amplitude, variância, desvio-padrão,
coeficiente de variação, IQR, assimetria e curtose.
"""

from ._utils import (
    selecionar_colunas,
    garantir_numerico,
    imprimir_titulo,
    imprimir_serie,
)
from .posicao import media, quartil


# ──────────────────────────────────────────────────────────────────────────────
# Amplitude
# ──────────────────────────────────────────────────────────────────────────────

def amplitude(dados, *colunas, mostrar=True):
    """Calcula a amplitude total (máximo − mínimo) das colunas selecionadas."""
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.max() - dados_num.min()

    if mostrar:
        imprimir_titulo("Amplitude Total")
        imprimir_serie(res)
    return res


# ──────────────────────────────────────────────────────────────────────────────
# Variância e desvio-padrão
# ──────────────────────────────────────────────────────────────────────────────

def variancia(dados, *colunas, amostral=True, mostrar=True):
    """
    Calcula a variância das colunas selecionadas.

    Parâmetros
    ----------
    amostral : bool
        True → divide por (n−1) [padrão, ddof=1].
        False → divide por n [populacional, ddof=0].
    """
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.var(ddof=1 if amostral else 0)

    if mostrar:
        tipo = "Amostral" if amostral else "Populacional"
        imprimir_titulo(f"Variância ({tipo})")
        imprimir_serie(res)
    return res


def desviopadrao(dados, *colunas, amostral=True, mostrar=True):
    """
    Calcula o desvio-padrão das colunas selecionadas.

    Parâmetros
    ----------
    amostral : bool
        True → ddof=1 (padrão). False → ddof=0 (populacional).
    """
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.std(ddof=1 if amostral else 0)

    if mostrar:
        tipo = "Amostral" if amostral else "Populacional"
        imprimir_titulo(f"Desvio Padrão ({tipo})")
        imprimir_serie(res)
    return res


# ──────────────────────────────────────────────────────────────────────────────
# Coeficiente de variação
# ──────────────────────────────────────────────────────────────────────────────

def coeficientevariacao(dados, *colunas, mostrar=True):
    """Calcula o coeficiente de variação (s / x̄) · 100."""
    cols = selecionar_colunas(dados, colunas)
    m = media(dados, *cols, mostrar=False)
    dp = desviopadrao(dados, *cols, amostral=True, mostrar=False)
    res = (dp / m) * 100

    if mostrar:
        imprimir_titulo("Coeficiente de Variação (%)")
        imprimir_serie(res)
    return res


# ──────────────────────────────────────────────────────────────────────────────
# IQR
# ──────────────────────────────────────────────────────────────────────────────

def iqr(dados, *colunas, metodo='exc', mostrar=True):
    """Calcula a amplitude interquartílica (Q3 − Q1)."""
    cols = selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q3 - q1

    if mostrar:
        imprimir_titulo(f"Amplitude Interquartílica (IQR - {metodo.upper()})")
        imprimir_serie(res)
    return res


# ──────────────────────────────────────────────────────────────────────────────
# Assimetria e curtose (com interpretação)
# ──────────────────────────────────────────────────────────────────────────────

def assimetria(dados, *colunas, mostrar=True):
    """
    Calcula a assimetria (skewness) e classifica a distribuição.

    Classificação:
        |g1| < 0.5   → Simétrica
        0.5 ≤ |g1| ≤ 1  → Moderada
        |g1| > 1     → Forte
    """
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.skew()

    if mostrar:
        imprimir_titulo("Assimetria (Skewness)")
        if res.empty:
            print("⚠️ Nenhuma coluna numérica.")
        else:
            for col, val in res.items():
                if abs(val) < 0.5:
                    classif = "Simétrica"
                    explica = "A distribuição é aproximadamente normal."
                elif abs(val) <= 1:
                    classif = "Moderada"
                    explica = "A distribuição tem uma leve inclinação."
                else:
                    classif = "Forte"
                    explica = "A distribuição é altamente inclinada."

                sentido = ""
                if abs(val) >= 0.5:
                    sentido = " (Positiva/Direita)" if val > 0 else " (Negativa/Esquerda)"

                print(f"{col}: {val:.4f} -> {classif}{sentido}")
                print(f"   └─ {explica}")
    return res


def curtose(dados, *colunas, mostrar=True):
    """
    Calcula a curtose excesso (Fisher) e classifica a distribuição.

    Classificação:
        |k| < 0.5  → Mesocúrtica (similar à normal)
        k ≥ 0.5   → Leptocúrtica (mais pontiaguda)
        k ≤ -0.5  → Platicúrtica (mais achatada)
    """
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.kurt()

    if mostrar:
        imprimir_titulo("Curtose (Kurtosis)")
        if res.empty:
            print("⚠️ Nenhuma coluna numérica.")
        else:
            for col, val in res.items():
                if abs(val) < 0.5:
                    classif = "Mesocúrtica"
                    explica = "A curvatura é semelhante à de uma normal."
                elif val >= 0.5:
                    classif = "Leptocúrtica"
                    explica = "A curva é mais pontiaguda (caudas pesadas)."
                else:
                    classif = "Platicúrtica"
                    explica = "A curva é mais achatada (caudas leves)."

                print(f"{col}: {val:.4f} -> {classif}")
                print(f"   └─ {explica}")
    return res
