"""
ppgrns_estatistica.boxplot
──────────────────────────
Geração de boxplots personalizáveis usando as estatísticas
calculadas pelo próprio pacote (Q1, mediana, Q3, limites).
"""

import matplotlib.pyplot as plt

from ._utils import selecionar_colunas, garantir_numerico
from .posicao import mediana, quartil, limiteinferior, limitesuperior


def _ajustar_lista(lista, padrao, n, nome_param):
    """
    Normaliza listas de parâmetros (cores, larguras, etc.) para ter
    exatamente n elementos, preenchendo com padrão ou truncando.
    """
    lista = list(lista) if lista else []
    if len(lista) > n:
        print(f"⚠️ Excesso de {nome_param}. Ignorando os itens extras.")
        return lista[:n]
    if len(lista) < n:
        if len(lista) > 0:
            print(f"⚠️ Faltam {nome_param}. Usando padrão para o restante.")
        complemento = padrao if not lista else lista[-1]
        lista.extend([complemento] * (n - len(lista)))
    return lista


def boxplot(
    dados,
    *colunas,
    larguras=None,
    cores=None,
    metodos=None,
    titulo="",
    horizontal=None,
    vertical="",
    qualidade=100,
    tamanhohorizontal=1,
    tamanhovertical=1,
    salvar='',
):
    """
    Cria boxplots personalizáveis usando Q1, mediana, Q3 e limites
    calculados pelo próprio pacote (método EXC ou INC por coluna).

    Parâmetros
    ----------
    dados : pd.DataFrame
    *colunas : str, list ou tuple
        Coluna(s) a plotar.
    larguras : list[float] ou None
        Largura de cada caixa.
    cores : list[str] ou None
        Cor de cada caixa.
    metodos : list[str] ou None
        'exc' ou 'inc' para cada coluna.
    titulo : str
        Título do gráfico.
    horizontal : list[str] ou None
        Rótulos do eixo X (se None, usa os nomes das colunas).
    vertical : str
        Rótulo do eixo Y.
    qualidade : int
        DPI. Padrão: 100.
    tamanhohorizontal, tamanhovertical : float
        Multiplicadores do tamanho base.
    salvar : str
        Nome do arquivo (sem extensão) para salvar como .png.
    """
    cols = selecionar_colunas(dados, colunas)
    n = len(cols)
    if n == 0:
        print("⚠️ Nenhuma coluna selecionada.")
        return

    # Normaliza parâmetros-lista para ter n elementos
    lista_larguras = _ajustar_lista(larguras, 1, n, "larguras")
    lista_cores = _ajustar_lista(cores, 'lightblue', n, "cores")
    lista_metodos = _ajustar_lista(metodos, 'exc', n, "métodos")
    lista_nomes = _ajustar_lista(horizontal, None, n, "nomes horizontais")
    for i in range(n):
        if lista_nomes[i] is None:
            lista_nomes[i] = cols[i]

    # Figura
    plt.figure(
        figsize=(10 * tamanhohorizontal, 6 * tamanhovertical),
        dpi=qualidade,
    )

    # Cálculo das estatísticas
    dados_num = garantir_numerico(dados, cols)
    stats_list = []

    for i, col in enumerate(cols):
        d = dados_num[col].dropna()
        if d.empty:
            continue

        m = lista_metodos[i]
        q1 = quartil(dados, col, quartil=1, metodo=m, mostrar=False).iloc[0]
        q2 = mediana(dados, col, mostrar=False).iloc[0]
        q3 = quartil(dados, col, quartil=3, metodo=m, mostrar=False).iloc[0]
        inf = limiteinferior(dados, col, metodo=m, mostrar=False).iloc[0]
        sup = limitesuperior(dados, col, metodo=m, mostrar=False).iloc[0]

        outliers = d[(d < inf) | (d > sup)].tolist()

        stats_list.append({
            'label': lista_nomes[i],
            'whislo': inf,
            'q1': q1,
            'med': q2,
            'q3': q3,
            'whishi': sup,
            'fliers': outliers,
        })

    if not stats_list:
        print("⚠️ Não foi possível gerar o boxplot com os dados fornecidos.")
        return

    # Plotagem
    ax = plt.subplot(111)
    for i, s in enumerate(stats_list):
        bp = ax.bxp([s], positions=[i], widths=lista_larguras[i], patch_artist=True)
        for patch in bp['boxes']:
            patch.set_facecolor(lista_cores[i])

    if titulo:
        plt.title(titulo, fontsize=14, pad=15)
    if vertical:
        plt.ylabel(vertical, fontsize=12)

    ax.set_xticklabels(lista_nomes)
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    plt.tight_layout()

    if salvar:
        nome_arquivo = f"{salvar}.png"
        plt.savefig(nome_arquivo, bbox_inches='tight')
        print(f"💾 Gráfico salvo: {nome_arquivo}")

    plt.show()
