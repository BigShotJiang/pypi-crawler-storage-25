"""
ppgrns_estatistica.histograma
─────────────────────────────
Geração de histogramas com rotulagem automática de intervalos.
"""

import matplotlib.pyplot as plt
import numpy as np

from ._utils import selecionar_colunas, garantir_numerico


def histograma(
    dados,
    *colunas,
    numerocolunas=None,
    cor='lightblue',
    titulo="",
    vertical="Frequência",
    qualidade=100,
    tamanhohorizontal=1,
    tamanhovertical=1,
    salvar='',
):
    """
    Gera um histograma de uma única variável.

    Se múltiplas colunas forem passadas, o gráfico é gerado para a primeira.

    Parâmetros
    ----------
    dados : pd.DataFrame
    *colunas : str, list ou tuple
        Coluna(s) a plotar. Aceita 'col', 'c1', 'c2' ou ['c1', 'c2'].
    numerocolunas : int ou None
        Número de classes (bins). None usa a regra 'auto' do NumPy.
    cor : str
        Cor das barras. Padrão: 'lightblue'.
    titulo : str
        Título do gráfico. Padrão: gerado automaticamente.
    vertical : str
        Rótulo do eixo Y. Padrão: 'Frequência'.
    qualidade : int
        DPI do gráfico. Padrão: 100.
    tamanhohorizontal, tamanhovertical : float
        Multiplicadores do tamanho base (10 x 6 polegadas).
    salvar : str
        Nome do arquivo (sem extensão) para salvar como .png.
    """
    cols = selecionar_colunas(dados, colunas)
    if not cols:
        print("⚠️ Nenhuma coluna selecionada.")
        return

    coluna = cols[0]
    dados_num = garantir_numerico(dados, [coluna])
    serie = dados_num[coluna].dropna()

    if serie.empty:
        print(f"⚠️ A coluna '{coluna}' não possui dados numéricos válidos.")
        return

    # Cálculo dos intervalos
    counts, bin_edges = np.histogram(
        serie, bins=numerocolunas if numerocolunas else 'auto'
    )
    n_bins = len(counts)
    labels = [
        f"{bin_edges[i]:.2f} - {bin_edges[i + 1]:.2f}"
        for i in range(n_bins)
    ]

    # Figura
    plt.figure(
        figsize=(10 * tamanhohorizontal, 6 * tamanhovertical),
        dpi=qualidade,
    )

    x_pos = np.arange(len(labels))
    plt.bar(x_pos, counts, width=0.95, color=cor, edgecolor='black', alpha=0.8)

    # Rotação dinâmica do eixo X
    rotacao = 0
    if 6 <= n_bins <= 12:
        rotacao = 45
    elif n_bins > 12:
        rotacao = 90

    plt.xticks(
        x_pos, labels,
        rotation=rotacao,
        ha='right' if rotacao > 0 else 'center',
    )

    # Títulos
    if titulo:
        plt.title(titulo, fontsize=14, pad=15)
    else:
        plt.title(f"Distribuição de Frequência: {coluna.capitalize()}", fontsize=12)

    plt.ylabel(vertical, fontsize=11)
    plt.xlabel("Intervalos de Classe", fontsize=11)
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    plt.tight_layout()

    if salvar:
        nome_arquivo = f"{salvar}.png"
        plt.savefig(nome_arquivo, bbox_inches='tight')
        print(f"💾 Gráfico salvo: {nome_arquivo}")

    plt.show()
