"""
ppgrns_estatistica.posicao
──────────────────────────
Medidas de posição: média, mediana, quartis, percentis
e limites para detecção de outliers.
"""

import numpy as np
import pandas as pd

from ._utils import (
    selecionar_colunas,
    garantir_numerico,
    imprimir_titulo,
    imprimir_serie,
)


# ──────────────────────────────────────────────────────────────────────────────
# Medidas centrais
# ──────────────────────────────────────────────────────────────────────────────

def media(dados, *colunas, mostrar=True):
    """Calcula a média aritmética das colunas selecionadas."""
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.mean(numeric_only=True)

    if mostrar:
        imprimir_titulo("Média")
        imprimir_serie(res)
    return res


def mediana(dados, *colunas, mostrar=True):
    """Calcula a mediana das colunas selecionadas."""
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)
    res = dados_num.median(numeric_only=True)

    if mostrar:
        imprimir_titulo("Mediana")
        imprimir_serie(res)
    return res


def moda(dados, *colunas, mostrar=True):
    """
    Calcula a moda (valor mais frequente) das colunas selecionadas.

    Diferente de média e mediana, a moda pode ser:
        • Única (unimodal): um único valor mais frequente.
        • Múltipla (bi/trimodal): vários valores empatam na maior frequência.
        • Amodal: todos os valores aparecem uma única vez.

    Retorna
    -------
    dict
        {coluna: {'modas': [v1, v2, ...], 'frequencia': int, 'tipo': str}}
        - 'modas': lista com o(s) valor(es) modal(is).
        - 'frequencia': quantas vezes cada moda aparece.
        - 'tipo': 'Unimodal', 'Bimodal', 'Trimodal', 'Multimodal' ou 'Amodal'.
    """
    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)

    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if serie.empty:
            continue

        contagem = serie.value_counts()
        freq_max = int(contagem.iloc[0])

        if freq_max == 1:
            # Todos os valores aparecem uma única vez → amodal
            modas = []
            tipo = "Amodal"
        else:
            modas = sorted(contagem[contagem == freq_max].index.tolist())
            n_modas = len(modas)
            if n_modas == 1:
                tipo = "Unimodal"
            elif n_modas == 2:
                tipo = "Bimodal"
            elif n_modas == 3:
                tipo = "Trimodal"
            else:
                tipo = "Multimodal"

        res_dict[col] = {
            "modas": modas,
            "frequencia": freq_max if modas else 0,
            "tipo": tipo,
        }

    if mostrar:
        imprimir_titulo("Moda")
        if not res_dict:
            print("⚠️ Nenhuma coluna numérica.")
        else:
            for col, info in res_dict.items():
                if info["tipo"] == "Amodal":
                    print(f"{col}: sem moda (todos os valores únicos) — Amodal")
                else:
                    modas_txt = ", ".join(f"{m:g}" for m in info["modas"])
                    print(
                        f"{col}: {modas_txt}  "
                        f"(frequência: {info['frequencia']}x) — {info['tipo']}"
                    )

    return res_dict


# ──────────────────────────────────────────────────────────────────────────────
# Quantis
# ──────────────────────────────────────────────────────────────────────────────

def _calcular_percentil(serie, p, metodo):
    """
    Calcula percentil com fallback para versões antigas do NumPy.

    metodo: 'exc' (Weibull) ou 'inc' (linear).
    """
    metodo_np = 'weibull' if metodo.lower() == 'exc' else 'linear'
    try:
        return np.percentile(serie, p, method=metodo_np)
    except TypeError:
        interp = 'linear' if metodo_np == 'linear' else 'higher'
        return np.percentile(serie, p, interpolation=interp)


def quartil(dados, *colunas, quartil=1, metodo='exc', mostrar=True):
    """
    Calcula o 1º, 2º ou 3º quartil usando o método EXC (Weibull) ou INC.

    Parâmetros
    ----------
    quartil : int
        1, 2 ou 3.
    metodo : str
        'exc' (exclusivo/Weibull) ou 'inc' (inclusivo/linear).
    """
    if quartil not in (1, 2, 3):
        raise ValueError(f"quartil deve ser 1, 2 ou 3. Recebido: {quartil}")
    if metodo.lower() not in ('exc', 'inc'):
        raise ValueError(f"metodo deve ser 'exc' ou 'inc'. Recebido: {metodo!r}")

    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)

    p = {1: 25, 2: 50, 3: 75}[quartil]
    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            res_dict[col] = _calcular_percentil(serie, p, metodo)

    res = pd.Series(res_dict)
    if mostrar:
        imprimir_titulo(f"{quartil}º Quartil ({metodo.upper()})")
        imprimir_serie(res, vazio_msg="⚠️ Sem dados numéricos.")
    return res


def percentil(dados, *colunas, percentil=50, metodo='exc', mostrar=True):
    """
    Calcula um percentil específico (0-100) para as colunas selecionadas.

    Parâmetros
    ----------
    percentil : float
        Valor entre 0 e 100.
    metodo : str
        'exc' (Weibull) ou 'inc' (linear).
    """
    if not (0 <= percentil <= 100):
        raise ValueError(
            f"percentil deve estar entre 0 e 100. Recebido: {percentil}"
        )
    if metodo.lower() not in ('exc', 'inc'):
        raise ValueError(f"metodo deve ser 'exc' ou 'inc'. Recebido: {metodo!r}")

    cols = selecionar_colunas(dados, colunas)
    dados_num = garantir_numerico(dados, cols)

    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            res_dict[col] = _calcular_percentil(serie, percentil, metodo)

    res = pd.Series(res_dict)
    if mostrar:
        imprimir_titulo(f"Percentil {percentil} ({metodo.upper()})")
        imprimir_serie(res, vazio_msg="⚠️ Sem dados numéricos.")
    return res


# ──────────────────────────────────────────────────────────────────────────────
# Limites para outliers
# ──────────────────────────────────────────────────────────────────────────────

def limiteinferior(dados, *colunas, metodo='exc', mostrar=True):
    """Calcula o limite inferior para outliers (Q1 − 1.5·IQR)."""
    cols = selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q1 - 1.5 * (q3 - q1)

    if mostrar:
        imprimir_titulo(f"Limite Inferior ({metodo.upper()})")
        imprimir_serie(res, vazio_msg="⚠️ Sem dados numéricos.")
    return res


def limitesuperior(dados, *colunas, metodo='exc', mostrar=True):
    """Calcula o limite superior para outliers (Q3 + 1.5·IQR)."""
    cols = selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q3 + 1.5 * (q3 - q1)

    if mostrar:
        imprimir_titulo(f"Limite Superior ({metodo.upper()})")
        imprimir_serie(res, vazio_msg="⚠️ Sem dados numéricos.")
    return res
