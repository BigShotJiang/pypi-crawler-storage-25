"""
ppgrns_estatistica.testet
─────────────────────────
Testes de hipótese para a média: t de Student nas três versões.

Funções disponíveis:
    testet_uma      — Uma amostra vs. valor de referência (μ₀)
    testet_duas     — Duas amostras independentes
    testet_pareado  — Duas amostras pareadas (mesma unidade experimental)
"""

import math
import warnings

import pandas as pd
from scipy import stats

from ._utils import (
    validar_serie,
    imprimir_titulo,
)


# ──────────────────────────────────────────────────────────────────────────────
# Helper interno de impressão (mesmo padrão de inferencia.py)
# ──────────────────────────────────────────────────────────────────────────────

def _linha(label, valor, unidade="", largura=36):
    texto = f"  {label:<{largura}}: "
    if isinstance(valor, float):
        print(f"{texto}{valor:>10.4f} {unidade}".rstrip())
    elif isinstance(valor, int):
        print(f"{texto}{valor:>10d} {unidade}".rstrip())
    else:
        print(f"{texto}{valor!s:>10} {unidade}".rstrip())


def _decisao(t_calc, t_crit, p_valor, alpha, h1_descricao, mostrar):
    """Imprime e retorna a string de decisão."""
    rejeita = abs(t_calc) > t_crit
    simbolo = "✔ Rejeita H₀" if rejeita else "✖ Não rejeita H₀"
    if mostrar:
        print()
        _linha("Valor crítico |t_crit|", t_crit)
        _linha("Estatística |t_calc|", abs(t_calc))
        _linha("p-valor (bicaudal)", p_valor)
        print()
        print(f"  {simbolo}")
        if rejeita:
            print(f"  → Há evidência estatística de que {h1_descricao} (p = {p_valor:.4f}).")
        else:
            print(f"  → Sem evidência suficiente para afirmar que {h1_descricao} (p = {p_valor:.4f}).")
    return rejeita


# ──────────────────────────────────────────────────────────────────────────────
# Teste t — Uma amostra
# ──────────────────────────────────────────────────────────────────────────────

def testet_uma(
    dados,
    coluna,
    mu0,
    alpha=0.05,
    mostrar=True,
):
    """
    Teste t para uma amostra: compara a média de um grupo com um
    valor de referência conhecido (μ₀).

    Parâmetros
    ----------
    dados : pd.DataFrame
        Conjunto de dados carregado com ef.carregardados().
    coluna : str
        Coluna numérica a testar.
    mu0 : float
        Valor de referência (padrão legal, valor histórico, meta).
    alpha : float
        Nível de significância. Padrão: 0.05 (5%).
    mostrar : bool
        Se True, imprime o resultado formatado. Padrão: True.

    Retorna
    -------
    dict
        {n, media, desvio_padrao, erro_padrao, t_calc, gl,
         t_crit, p_valor, rejeita_h0, alpha, mu0}

    Exemplos
    --------
    >>> ef.testet_uma(dados, 'od', mu0=6.0)
    >>> ef.testet_uma(dados, 'ph', mu0=7.0, alpha=0.01)
    """
    if not (0 < alpha < 1):
        raise ValueError(f"alpha deve estar entre 0 e 1. Recebido: {alpha}")

    serie = validar_serie(dados, coluna)
    n     = len(serie)
    med   = float(serie.mean())
    s     = float(serie.std(ddof=1))
    ep    = s / math.sqrt(n)
    gl    = n - 1

    if n < 5:
        warnings.warn(
            f"A coluna '{coluna}' possui apenas {n} observações. "
            "O resultado pode ser pouco confiável.",
            UserWarning, stacklevel=2,
        )

    t_calc = (med - float(mu0)) / ep
    t_crit = float(stats.t.ppf(1 - alpha / 2, df=gl))
    p_valor = float(2 * stats.t.sf(abs(t_calc), df=gl))

    if mostrar:
        imprimir_titulo(f"Teste t — Uma Amostra  ({coluna})")
        print(f"  H₀: μ = {mu0}    H₁: μ ≠ {mu0}    α = {alpha}")
        print()
        _linha("Tamanho amostral (n)", n)
        _linha("Média amostral (x̄)", med)
        _linha("Desvio padrão amostral (s)", s)
        _linha("Erro Padrão (s/√n)", ep)
        _linha("Graus de liberdade (gl)", gl)
        _linha("Estatística t_calc", t_calc)

    h1_desc = f"a média de '{coluna}' difere de {mu0}"
    rejeita = _decisao(t_calc, t_crit, p_valor, alpha, h1_desc, mostrar)

    return {
        "n": n, "media": med, "desvio_padrao": s, "erro_padrao": ep,
        "t_calc": t_calc, "gl": gl, "t_crit": t_crit,
        "p_valor": p_valor, "rejeita_h0": rejeita,
        "alpha": alpha, "mu0": float(mu0),
    }


# ──────────────────────────────────────────────────────────────────────────────
# Teste t — Duas amostras independentes
# ──────────────────────────────────────────────────────────────────────────────

def testet_duas(
    dados,
    coluna1,
    coluna2=None,
    grupo=None,
    alpha=0.05,
    variancia_igual=True,
    mostrar=True,
):
    """
    Teste t para duas amostras independentes. Aceita duas formas de uso:

    Forma 1 — Duas colunas separadas:
        ef.testet_duas(dados, 'riqueza_mata', 'riqueza_pastagem')

    Forma 2 — Uma coluna de resposta + coluna de grupo (2 níveis):
        ef.testet_duas(dados, 'riqueza', grupo='habitat')

    Parâmetros
    ----------
    dados : pd.DataFrame
        Conjunto de dados carregado com ef.carregardados().
    coluna1 : str
        Primeira coluna numérica (Forma 1) ou coluna resposta (Forma 2).
    coluna2 : str ou None
        Segunda coluna numérica (Forma 1). None se usar grupo.
    grupo : str ou None
        Coluna categórica com exatamente dois níveis (Forma 2).
        None se usar duas colunas.
    alpha : float
        Nível de significância. Padrão: 0.05.
    variancia_igual : bool
        True  → variâncias iguais, usa s_pooled (padrão).
        False → variâncias diferentes, usa teste de Welch (gl ajustado).
    mostrar : bool
        Se True, imprime o resultado formatado. Padrão: True.

    Retorna
    -------
    dict
        {grupo1, grupo2, n1, n2, media1, media2, s1, s2,
         t_calc, gl, t_crit, p_valor, rejeita_h0, alpha}

    Exemplos
    --------
    >>> ef.testet_duas(dados, 'riqueza_mata', 'riqueza_pastagem')
    >>> ef.testet_duas(dados, 'riqueza', grupo='habitat')
    >>> ef.testet_duas(dados, 'biomassa', grupo='uso', variancia_igual=False)
    """
    if not (0 < alpha < 1):
        raise ValueError(f"alpha deve estar entre 0 e 1. Recebido: {alpha}")

    if coluna2 is not None and grupo is not None:
        raise ValueError(
            "Use apenas uma forma: duas colunas (coluna1, coluna2) "
            "ou coluna + grupo. Não ambos."
        )
    if coluna2 is None and grupo is None:
        raise ValueError(
            "Informe a segunda coluna ou o argumento grupo.\n"
            "  Forma 1: testet_duas(dados, 'col1', 'col2')\n"
            "  Forma 2: testet_duas(dados, 'coluna', grupo='categoria')"
        )

    # ── Forma 1: duas colunas ─────────────────────────────────────────────────
    if coluna2 is not None:
        s1 = validar_serie(dados, coluna1)
        s2 = validar_serie(dados, coluna2)
        g1, g2 = coluna1, coluna2

    # ── Forma 2: coluna + grupo ───────────────────────────────────────────────
    else:
        if grupo not in dados.columns:
            raise ValueError(
                f"A coluna de grupo '{grupo}' não foi encontrada.\n"
                f"Colunas disponíveis: {list(dados.columns)}"
            )
        niveis = dados[grupo].dropna().unique()
        if len(niveis) != 2:
            raise ValueError(
                f"A coluna '{grupo}' deve ter exatamente 2 níveis. "
                f"Encontrados: {list(niveis)}"
            )
        g1, g2 = sorted(niveis, key=str)
        s1 = validar_serie(dados[dados[grupo] == g1], coluna1)
        s2 = validar_serie(dados[dados[grupo] == g2], coluna1)

    n1, n2   = len(s1), len(s2)
    m1, m2   = float(s1.mean()), float(s2.mean())
    dp1, dp2 = float(s1.std(ddof=1)), float(s2.std(ddof=1))

    if variancia_igual:
        # Desvio padrão combinado (pooled)
        sp2 = ((n1 - 1) * dp1**2 + (n2 - 1) * dp2**2) / (n1 + n2 - 2)
        sp  = math.sqrt(sp2)
        ep  = sp * math.sqrt(1 / n1 + 1 / n2)
        gl  = n1 + n2 - 2
        metodo = "Pooled (variâncias iguais)"
    else:
        # Welch — graus de liberdade aproximados
        ep  = math.sqrt(dp1**2 / n1 + dp2**2 / n2)
        num = (dp1**2 / n1 + dp2**2 / n2)**2
        den = (dp1**2 / n1)**2 / (n1 - 1) + (dp2**2 / n2)**2 / (n2 - 1)
        gl  = int(num / den)
        metodo = "Welch (variâncias diferentes)"

    t_calc = (m1 - m2) / ep
    t_crit = float(stats.t.ppf(1 - alpha / 2, df=gl))
    p_valor = float(2 * stats.t.sf(abs(t_calc), df=gl))

    if mostrar:
        rotulo = f"{g1} vs. {g2}"
        imprimir_titulo(f"Teste t — Duas Amostras Independentes  ({rotulo})")
        print(f"  H₀: μ_{g1} = μ_{g2}    H₁: μ_{g1} ≠ μ_{g2}    α = {alpha}")
        print(f"  Método: {metodo}")
        print()
        _linha(f"n  [{g1}]", n1)
        _linha(f"n  [{g2}]", n2)
        _linha(f"x̄  [{g1}]", m1)
        _linha(f"x̄  [{g2}]", m2)
        _linha(f"s  [{g1}]", dp1)
        _linha(f"s  [{g2}]", dp2)
        if variancia_igual:
            sp_val = math.sqrt(((n1-1)*dp1**2 + (n2-1)*dp2**2) / (n1+n2-2))
            _linha("Desvio padrão combinado (sp)", sp_val)
        _linha("Erro Padrão", ep)
        _linha("Graus de liberdade (gl)", gl)
        _linha("Estatística t_calc", t_calc)

    h1_desc = f"as médias de '{g1}' e '{g2}' são diferentes"
    rejeita = _decisao(t_calc, t_crit, p_valor, alpha, h1_desc, mostrar)

    return {
        "grupo1": g1, "grupo2": g2,
        "n1": n1, "n2": n2,
        "media1": m1, "media2": m2,
        "s1": dp1, "s2": dp2,
        "t_calc": t_calc, "gl": gl, "t_crit": t_crit,
        "p_valor": p_valor, "rejeita_h0": rejeita,
        "alpha": alpha,
    }


# ──────────────────────────────────────────────────────────────────────────────
# Teste t — Amostras pareadas
# ──────────────────────────────────────────────────────────────────────────────

def testet_pareado(
    dados,
    coluna_antes,
    coluna_depois,
    alpha=0.05,
    mostrar=True,
):
    """
    Teste t pareado: compara duas medições feitas na mesma unidade
    experimental (antes/depois, local A/local B no mesmo ponto, etc.).

    Parâmetros
    ----------
    dados : pd.DataFrame
        Conjunto de dados carregado com ef.carregardados().
    coluna_antes : str
        Coluna com os valores da primeira medição.
    coluna_depois : str
        Coluna com os valores da segunda medição.
    alpha : float
        Nível de significância. Padrão: 0.05.
    mostrar : bool
        Se True, imprime o resultado formatado. Padrão: True.

    Retorna
    -------
    dict
        {n, media_antes, media_depois, media_dif, s_dif,
         erro_padrao, t_calc, gl, t_crit, p_valor, rejeita_h0, alpha}

    Exemplos
    --------
    >>> ef.testet_pareado(dados, 'nitrogenio_antes', 'nitrogenio_depois')
    >>> ef.testet_pareado(dados, 'sp_antes', 'sp_depois', alpha=0.01)
    """
    if not (0 < alpha < 1):
        raise ValueError(f"alpha deve estar entre 0 e 1. Recebido: {alpha}")

    s_antes  = validar_serie(dados, coluna_antes)
    s_depois = validar_serie(dados, coluna_depois)

    # Alinhar pelo índice e eliminar pares com NaN
    df_par = pd.concat(
        [s_antes.rename("antes"), s_depois.rename("depois")], axis=1
    ).dropna()

    if df_par.empty:
        raise ValueError(
            "Não há pares completos (sem NaN) entre as duas colunas."
        )

    n    = len(df_par)
    difs = df_par["depois"] - df_par["antes"]
    md   = float(difs.mean())
    sd   = float(difs.std(ddof=1))
    ep   = sd / math.sqrt(n)
    gl   = n - 1

    if n < 5:
        warnings.warn(
            f"Apenas {n} pares disponíveis. O resultado pode ser pouco confiável.",
            UserWarning, stacklevel=2,
        )

    t_calc = md / ep
    t_crit = float(stats.t.ppf(1 - alpha / 2, df=gl))
    p_valor = float(2 * stats.t.sf(abs(t_calc), df=gl))

    if mostrar:
        imprimir_titulo(
            f"Teste t — Amostras Pareadas  "
            f"({coluna_depois} − {coluna_antes})"
        )
        print(f"  H₀: μ_d = 0    H₁: μ_d ≠ 0    α = {alpha}")
        print(f"  d_i = {coluna_depois} − {coluna_antes}")
        print()
        _linha("Número de pares (n)", n)
        _linha(f"Média [{coluna_antes}]", float(df_par['antes'].mean()))
        _linha(f"Média [{coluna_depois}]", float(df_par['depois'].mean()))
        _linha("Média das diferenças (d̄)", md)
        _linha("Desvio padrão das difs. (s_d)", sd)
        _linha("Erro Padrão (s_d/√n)", ep)
        _linha("Graus de liberdade (gl)", gl)
        _linha("Estatística t_calc", t_calc)

    h1_desc = (
        f"há diferença média entre '{coluna_depois}' e '{coluna_antes}'"
    )
    rejeita = _decisao(t_calc, t_crit, p_valor, alpha, h1_desc, mostrar)

    return {
        "n": n,
        "media_antes": float(df_par["antes"].mean()),
        "media_depois": float(df_par["depois"].mean()),
        "media_dif": md,
        "s_dif": sd,
        "erro_padrao": ep,
        "t_calc": t_calc,
        "gl": gl,
        "t_crit": t_crit,
        "p_valor": p_valor,
        "rejeita_h0": rejeita,
        "alpha": alpha,
    }