"""
ppgrns_estatistica.carregar
───────────────────────────
Carregamento e limpeza automática de planilhas (.xlsx / .ods),
detectando ambiente (Google Colab ou PC local).
"""

import io
import os
import sys

import pandas as pd


def carregardados():
    """
    Detecta o ambiente e carrega um arquivo .xlsx ou .ods.

    - No Google Colab: abre a interface de upload.
    - No PC local: abre a janela de seleção de arquivo (Tkinter).

    Aplica limpeza padronizada:
        • nomes de colunas em minúsculas, sem espaços e sem zero-width space
        • células de texto convertidas para número quando possível
        • vírgula decimal convertida em ponto

    Retorna
    -------
    pd.DataFrame ou None
        DataFrame já limpo, ou None se a operação foi cancelada.
    """
    no_colab = 'google.colab' in sys.modules
    df = None

    try:
        if no_colab:
            from google.colab import files
            print("🌐 Ambiente detectado: Google Colab")
            uploaded = files.upload()
            if not uploaded:
                return None
            nome_arquivo = list(uploaded.keys())[0]
            conteudo = uploaded[nome_arquivo]

            if nome_arquivo.endswith('.ods'):
                df = pd.read_excel(io.BytesIO(conteudo), engine='odf')
            else:
                df = pd.read_excel(io.BytesIO(conteudo))

        else:
            import tkinter as tk
            from tkinter import filedialog
            print("💻 Ambiente detectado: computador local")

            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            caminho_arquivo = filedialog.askopenfilename(
                title="Selecione sua planilha",
                filetypes=[("Planilhas", "*.xlsx *.ods")],
            )
            root.destroy()

            if not caminho_arquivo:
                print("Operação cancelada.")
                return None

            nome_arquivo = os.path.basename(caminho_arquivo)
            if nome_arquivo.endswith('.ods'):
                df = pd.read_excel(caminho_arquivo, engine='odf')
            else:
                df = pd.read_excel(caminho_arquivo)

        # ── Limpeza padronizada ──────────────────────────────────────────────
        if df is not None:
            # Nomes de colunas
            df.columns = (
                df.columns
                .str.replace('\u200b', '', regex=False)
                .str.strip()
                .str.lower()
            )

            # Conteúdo das células
            for col in df.columns:
                if df[col].dtype == 'object':
                    df[col] = (
                        df[col].astype(str)
                        .str.replace('\u200b', '', regex=False)
                        .str.replace(',', '.', regex=False)
                        .str.strip()
                    )
                    df[col] = pd.to_numeric(df[col], errors='coerce')

        return df

    except Exception as e:
        print(f"❌ Erro ao carregar: {e}")
        return None
