"""
ppgrns_estatistica.graficos_interativos
───────────────────────────────────────
Visualizações interativas para ensino de estatística.

Requer ambiente Jupyter/Colab com ipywidgets instalado.

Funções disponíveis:
    icinterativo — IC para a média com curva normal e sliders
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

from ._utils import validar_serie


# ──────────────────────────────────────────────────────────────────────────────
# Plot interno (curva de amostragem da média com o IC destacado)
# ──────────────────────────────────────────────────────────────────────────────

def _plotar_ic(n, media, s, confianca):
    """Plota a distribuição amostral da média com o IC em destaque."""
    alpha = 1 - confianca

    # Escolha da distribuição (critério n>30)
    if n > 30:
        valor_critico = stats.norm.ppf(1 - alpha / 2)
        dist_nome = "Normal (Z)"
        dist_curva = stats.norm
        dist_params = {}
    else:
        gl = n - 1
        valor_critico = stats.t.ppf(1 - alpha / 2, df=gl)
        dist_nome = f"t de Student (gl={gl})"
        dist_curva = stats.t
        dist_params = {'df': gl}

    ep = s / np.sqrt(n)               # erro padrão da média
    me = valor_critico * ep           # margem de erro
    lim_inf = media - me
    lim_sup = media + me

    # ── Domínio do eixo X ────────────────────────────────────────────────────
    # A curva representa a distribuição da MÉDIA amostral (dp = ep, não s).
    # Mostramos ±4 erros padrão ao redor da média — janela que sempre contém
    # mais de 99,99% da massa de probabilidade.
    xmin = media - 4 * ep
    xmax = media + 4 * ep
    x = np.linspace(xmin, xmax, 400)

    # Densidade da média amostral: z = (x - media) / ep
    z = (x - media) / ep
    y = dist_curva.pdf(z, **dist_params) / ep

    # ── Plot ─────────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(10, 4.5))

    # Curva de densidade completa
    ax.plot(x, y, color='#1f77b4', linewidth=2, zorder=3)

    # Preenche a região DENTRO do IC (área de confiança)
    mask_ic = (x >= lim_inf) & (x <= lim_sup)
    ax.fill_between(
        x[mask_ic], 0, y[mask_ic],
        color='#1f77b4', alpha=0.25,
        label=f'IC {int(confianca*100)}%',
        zorder=2,
    )

    # Preenche as caudas em vermelho suave
    mask_esq = x < lim_inf
    mask_dir = x > lim_sup
    ax.fill_between(x[mask_esq], 0, y[mask_esq], color='#d62728', alpha=0.15, zorder=2)
    ax.fill_between(x[mask_dir], 0, y[mask_dir], color='#d62728', alpha=0.15, zorder=2)

    # Linhas verticais dos limites e da média
    y_lim_inf = dist_curva.pdf((lim_inf - media) / ep, **dist_params) / ep
    y_lim_sup = dist_curva.pdf((lim_sup - media) / ep, **dist_params) / ep
    y_media   = dist_curva.pdf(0, **dist_params) / ep

    ax.vlines(lim_inf, 0, y_lim_inf, colors='#d62728', linewidth=2, zorder=4)
    ax.vlines(lim_sup, 0, y_lim_sup, colors='#d62728', linewidth=2, zorder=4)
    ax.vlines(media, 0, y_media, colors='black', linestyle='--', linewidth=1.5, zorder=4)

    # Marcador da média no eixo
    ax.plot(media, 0, 'o', color='black', markersize=8, zorder=5, clip_on=False)

    # ── Anotações ────────────────────────────────────────────────────────────
    y_top = y.max()

    ax.annotate(f'{lim_inf:.3f}', xy=(lim_inf, 0),
                xytext=(0, -22), textcoords='offset points',
                ha='center', color='#d62728', fontweight='bold', fontsize=10)

    ax.annotate(f'{lim_sup:.3f}', xy=(lim_sup, 0),
                xytext=(0, -22), textcoords='offset points',
                ha='center', color='#d62728', fontweight='bold', fontsize=10)

    ax.annotate(f'x̄ = {media:.3f}', xy=(media, y_media),
                xytext=(0, 8), textcoords='offset points',
                ha='center', fontweight='bold', fontsize=10)

    # Rótulo central informando a largura do IC
    ax.annotate(
        f'IC {int(confianca*100)}%  →  largura = {2*me:.3f}',
        xy=(media, y_top * 0.45),
        ha='center', fontsize=10, color='#1f77b4',
        bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#1f77b4', alpha=0.9),
    )

    # ── Estética ─────────────────────────────────────────────────────────────
    ax.set_title(
        f"Distribuição amostral da média — {dist_nome}\n"
        f"n = {n}   |   EP = s/√n = {ep:.3f}   |   "
        f"valor crítico = {valor_critico:.3f}   |   ME = {me:.3f}",
        fontsize=11, pad=12,
    )
    ax.set_xlabel("Valores possíveis para a média amostral", fontsize=10)
    ax.set_ylabel("Densidade", fontsize=10)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(0, y_top * 1.20)
    ax.grid(axis='x', linestyle='--', alpha=0.4)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    plt.show()


# ──────────────────────────────────────────────────────────────────────────────
# IC interativo
# ──────────────────────────────────────────────────────────────────────────────

def icinterativo(dados=None, coluna=None):
    """
    Exibe um painel interativo (Jupyter/Colab) para explorar o IC da média.

    Dois modos de uso:

    1. Com DataFrame e coluna — extrai n, média e s automaticamente:
           >>> ef.icinterativo(dados, 'lbee')

    2. Sem argumentos — modo manual com todos os campos editáveis:
           >>> ef.icinterativo()

    A interface permite ajustar o tamanho amostral (n) tanto pelo slider
    quanto digitando o valor: os dois controles ficam sincronizados.

    Parâmetros
    ----------
    dados : pd.DataFrame, opcional
        DataFrame de origem. Se fornecido, 'coluna' é obrigatória.
    coluna : str, opcional
        Nome da coluna numérica. Define os valores iniciais dos controles.

    Requisitos
    ----------
    Este recurso depende de 'ipywidgets' e só funciona em notebooks Jupyter
    ou Google Colab.
    """
    # ── Valida argumentos ANTES de checar a dependência opcional ────────────
    if dados is not None:
        if coluna is None:
            raise ValueError(
                "Quando 'dados' é fornecido, 'coluna' também deve ser."
            )
        serie = validar_serie(dados, coluna)
        n_inicial = len(serie)
        media_inicial = float(serie.mean())
        s_inicial = float(serie.std(ddof=1))
        rotulo = f" — {coluna}"
    else:
        n_inicial = 20
        media_inicial = 5.66
        s_inicial = 1.13
        rotulo = ""

    # ── Checa dependência opcional ──────────────────────────────────────────
    try:
        import ipywidgets as widgets
        from IPython.display import display
    except ImportError:
        raise ImportError(
            "icinterativo requer 'ipywidgets'. Instale com:\n"
            "    pip install ipywidgets\n"
            "E use dentro de um Jupyter Notebook ou Google Colab."
        )

    n_max = max(500, n_inicial * 3)

    # ── Controles do tamanho n: slider + input numérico sincronizados ───────
    n_slider = widgets.IntSlider(
        min=2, max=n_max, step=1, value=n_inicial,
        description='Tamanho (n):',
        continuous_update=False,
        layout=widgets.Layout(width='400px'),
    )
    n_input = widgets.BoundedIntText(
        min=2, max=n_max, step=1, value=n_inicial,
        layout=widgets.Layout(width='100px'),
    )
    # Sincroniza slider ↔ caixa numérica em ambas as direções
    widgets.jslink((n_slider, 'value'), (n_input, 'value'))
    n_box = widgets.HBox([n_slider, n_input])

    media_input = widgets.FloatText(
        value=round(media_inicial, 4),
        description='Média (x̄):',
    )
    s_input = widgets.FloatText(
        value=round(s_inicial, 4),
        description='Desvio (s):',
    )
    confianca_dd = widgets.Dropdown(
        options=[('90%', 0.90), ('95%', 0.95), ('99%', 0.99)],
        value=0.95,
        description='Confiança:',
    )

    # ── Área de saída única (evita duplicação do gráfico) ───────────────────
    saida = widgets.Output()

    def _atualizar(*_):
        with saida:
            saida.clear_output(wait=True)
            _plotar_ic(
                n=n_slider.value,
                media=media_input.value,
                s=s_input.value,
                confianca=confianca_dd.value,
            )

    # Observa mudanças em cada controle
    n_slider.observe(_atualizar, names='value')
    media_input.observe(_atualizar, names='value')
    s_input.observe(_atualizar, names='value')
    confianca_dd.observe(_atualizar, names='value')

    # Plot inicial
    _atualizar()

    # Layout final
    titulo = widgets.HTML(
        f"<h4 style='margin:4px 0'>🎛 Explorador de Intervalo de Confiança"
        f"{rotulo}</h4>"
        f"<div style='color:#666;font-size:0.9em;margin-bottom:8px'>"
        f"Ajuste o tamanho amostral (n) pela barra ou digitando o valor.</div>"
    )
    controles = widgets.VBox([
        titulo,
        n_box,
        media_input,
        s_input,
        confianca_dd,
    ])
    painel = widgets.VBox([controles, saida])

    display(painel)
    # Não retornamos o painel — evita duplicação por eco do Jupyter
    return None
