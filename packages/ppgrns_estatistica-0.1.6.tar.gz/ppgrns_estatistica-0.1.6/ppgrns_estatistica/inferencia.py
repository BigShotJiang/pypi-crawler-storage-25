"""
ppgrns_estatistica.inferencia
─────────────────────────────
Inferência estatística: intervalos de confiança e tamanho amostral.

Funções disponíveis:
    intervaloconfianca  — IC para a média (caso z ou t de Student)
    tamanhominimo       — Tamanho amostral mínimo para uma margem de erro
"""

import math
import warnings

from scipy import stats

from ._utils import (
    selecionar_colunas,
    validar_serie,
    imprimir_titulo,
)


# ──────────────────────────────────────────────────────────────────────────────
# Helper de impressão linha-a-linha (usado só aqui, relatórios mais densos)
# ──────────────────────────────────────────────────────────────────────────────

def _linha(label, valor, unidade="", largura=32):
    """Imprime 'label ...... valor unidade' alinhado."""
    texto = f"  {label:<{largura}}: "
    if isinstance(valor, float):
        print(f"{texto}{valor:>10.4f} {unidade}".rstrip())
    elif isinstance(valor, int):
        print(f"{texto}{valor:>10d} {unidade}".rstrip())
    else:
        print(f"{texto}{valor!s:>10} {unidade}".rstrip())


# ──────────────────────────────────────────────────────────────────────────────
# Intervalo de Confiança para a média
# ──────────────────────────────────────────────────────────────────────────────

def intervaloconfianca(
    dados,
    *colunas,
    confianca=0.95,
    sigma=None,
    mostrar=True,
):
    """
    Calcula o Intervalo de Confiança para a média populacional.

    Parâmetros
    ----------
    dados : pd.DataFrame
        Conjunto de dados carregado com ef.carregardados().
    *colunas : str, list ou tuple
        Uma ou mais colunas numéricas. Aceita:
            intervaloconfianca(df, 'col')
            intervaloconfianca(df, 'c1', 'c2')
            intervaloconfianca(df, ['c1', 'c2'])
    confianca : float
        Nível de confiança (0 < confianca < 1). Padrão: 0.95.
    sigma : float ou None
        - None (padrão): usa t de Student (σ desconhecido).
        - valor: usa Normal Z (σ conhecido).
    mostrar : bool
        Se True, imprime o resultado formatado. Padrão: True.

    Retorna
    -------
    dict
        Dicionário aninhado {coluna: {n, media, desvio_padrao, ...}}.

    Exemplos
    --------
    >>> ef.intervaloconfianca(dados, 'lbee')
    >>> ef.intervaloconfianca(dados, ['nitrogenio', 'fosforo'], confianca=0.99)
    >>> ef.intervaloconfianca(dados, 'ph', sigma=0.3)
    """
    if not (0 < confianca < 1):
        raise ValueError(
            f"O nível de confiança deve estar entre 0 e 1 (ex: 0.95). "
            f"Recebido: {confianca}"
        )

    cols = selecionar_colunas(dados, colunas)
    alpha = 1.0 - confianca
    resultados = {}

    for coluna in cols:
        serie = validar_serie(dados, coluna)
        n = len(serie)
        med = float(serie.mean())
        s = float(serie.std(ddof=1))

        if sigma is not None:
            # Caso Z — σ populacional conhecido
            sigma_val = float(sigma)
            distribuicao = "Normal (Z)"
            gl = None
            valor_critico = float(stats.norm.ppf(1 - alpha / 2))
            erro_padrao = sigma_val / math.sqrt(n)
        else:
            # Caso t — σ populacional desconhecido (mais comum)
            gl = n - 1
            distribuicao = "t de Student"
            valor_critico = float(stats.t.ppf(1 - alpha / 2, df=gl))
            erro_padrao = s / math.sqrt(n)

            if n < 5:
                warnings.warn(
                    f"A coluna '{coluna}' possui apenas {n} observações. "
                    "O IC pode ser pouco confiável com amostras tão pequenas.",
                    UserWarning,
                    stacklevel=2,
                )

        margem_erro = valor_critico * erro_padrao
        limite_inf = med - margem_erro
        limite_sup = med + margem_erro

        resultados[coluna] = {
            "n": n,
            "media": med,
            "desvio_padrao": s,
            "erro_padrao": erro_padrao,
            "distribuicao": distribuicao,
            "graus_liberdade": gl,
            "valor_critico": valor_critico,
            "margem_erro": margem_erro,
            "limite_inferior": limite_inf,
            "limite_superior": limite_sup,
            "confianca": confianca,
        }

        if mostrar:
            imprimir_titulo(f"Intervalo de Confiança — {coluna}")
            _linha("Tamanho amostral (n)", n)
            _linha("Média amostral (x̄)", med)
            _linha("Desvio padrão amostral (s)", s)
            _linha("Nível de confiança", f"{confianca * 100:.1f}%")
            _linha("Distribuição utilizada", distribuicao)
            if gl is not None:
                _linha("Graus de liberdade (ν)", gl)
                _linha(f"Valor crítico t({alpha/2:.3f}; {gl})", valor_critico)
            else:
                _linha(f"Valor crítico z({alpha/2:.3f})", valor_critico)
            _linha("Erro Padrão", erro_padrao)
            _linha("Margem de Erro (ME)", margem_erro)
            print(
                f"\n  IC {confianca*100:.0f}% = "
                f"[ {limite_inf:.4f}  ;  {limite_sup:.4f} ]"
            )
            print(
                f"  → Com {confianca*100:.0f}% de confiança, a média populacional "
                f"de '{coluna}'\n    está entre {limite_inf:.3f} e {limite_sup:.3f}."
            )

    return resultados


# ──────────────────────────────────────────────────────────────────────────────
# Tamanho amostral mínimo
# ──────────────────────────────────────────────────────────────────────────────

def tamanhominimo(
    dados,
    *colunas,
    margem,
    confianca=0.95,
    sigma=None,
    mostrar=True,
):
    """
    Calcula o tamanho amostral mínimo para atingir uma margem de erro.

    Parâmetros
    ----------
    dados : pd.DataFrame
        Conjunto de dados (usado para estimar s quando sigma=None).
    *colunas : str, list ou tuple
        Uma ou mais colunas numéricas.
    margem : float
        Margem de erro máxima desejada (na mesma unidade dos dados).
    confianca : float
        Nível de confiança. Padrão: 0.95.
    sigma : float ou None
        Desvio padrão populacional. Se None, usa s amostral como estimativa.
    mostrar : bool
        Exibe resultado formatado. Padrão: True.

    Retorna
    -------
    dict
        Dicionário aninhado com 'n_minimo' e demais parâmetros por coluna.

    Exemplos
    --------
    >>> ef.tamanhominimo(dados, 'nitrogenio', margem=2.0)
    >>> ef.tamanhominimo(dados, ['ph', 'mo'], margem=0.1, confianca=0.99)
    """
    if margem <= 0:
        raise ValueError(
            f"A margem de erro deve ser positiva. Recebido: {margem}"
        )
    if not (0 < confianca < 1):
        raise ValueError(
            f"O nível de confiança deve estar entre 0 e 1. Recebido: {confianca}"
        )

    cols = selecionar_colunas(dados, colunas)
    alpha = 1.0 - confianca
    z = float(stats.norm.ppf(1 - alpha / 2))
    resultados = {}

    for coluna in cols:
        serie = validar_serie(dados, coluna)
        n_atual = len(serie)

        if sigma is not None:
            dp = float(sigma)
            fonte_dp = f"σ = {dp:.4f} (fornecido)"
        else:
            dp = float(serie.std(ddof=1))
            fonte_dp = f"s = {dp:.4f} (amostral — estimativa)"

        n_min = math.ceil((z * dp / margem) ** 2)

        resultados[coluna] = {
            "coluna": coluna,
            "n_atual": n_atual,
            "n_minimo": n_min,
            "margem_erro": margem,
            "confianca": confianca,
            "desvio_padrao": dp,
            "valor_critico_z": z,
        }

        if mostrar:
            imprimir_titulo(f"Tamanho Amostral Mínimo — {coluna}")
            _linha("Nível de confiança", f"{confianca*100:.1f}%")
            _linha("Margem de erro desejada (E)", margem)
            _linha("Desvio padrão utilizado", dp)
            _linha("  → Fonte", fonte_dp)
            _linha("Valor crítico z", z)
            _linha("TAMANHO MÍNIMO (n)", n_min)
            _linha("Amostra atual (n)", n_atual)

            if n_atual >= n_min:
                print(
                    f"\n  ✔ A amostra atual ({n_atual}) já é suficiente "
                    f"para a margem de {margem}\n    com {confianca*100:.0f}% de confiança."
                )
            else:
                faltam = n_min - n_atual
                print(
                    f"\n  ✖ São necessárias mais {faltam} observação(ões) "
                    f"(total: {n_min})\n    para atingir a margem desejada."
                )

    return resultados
