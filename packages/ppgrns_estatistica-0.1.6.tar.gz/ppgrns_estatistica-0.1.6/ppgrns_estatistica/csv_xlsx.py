"""
ppgrns_estatistica.csv_xlsx
───────────────────────────
Conversão utilitária de arquivos .csv para .xlsx.
"""

import pandas as pd


def csv_para_xlsx(caminho_csv, caminho_xlsx, sep=',', encoding='utf-8'):
    """
    Converte um arquivo CSV em XLSX.

    Parâmetros
    ----------
    caminho_csv : str
        Caminho do arquivo CSV de entrada.
    caminho_xlsx : str
        Caminho do arquivo XLSX de saída.
    sep : str
        Separador do CSV. Padrão: ','. Use ';' se o CSV for no padrão BR.
    encoding : str
        Codificação do CSV. Padrão: 'utf-8'. Tente 'latin1' se houver
        problemas com acentuação.

    Retorna
    -------
    bool
        True se a conversão foi bem-sucedida; False caso contrário.

    Exemplos
    --------
    >>> csv_para_xlsx('dados.csv', 'dados.xlsx')
    >>> csv_para_xlsx('br.csv', 'br.xlsx', sep=';', encoding='latin1')
    """
    try:
        print(f"Lendo o arquivo: {caminho_csv}...")
        df = pd.read_csv(caminho_csv, sep=sep, encoding=encoding)
        print("Convertendo para Excel...")
        df.to_excel(caminho_xlsx, index=False, engine='openpyxl')
        print(f"✔ Arquivo salvo como: {caminho_xlsx}")
        return True
    except FileNotFoundError:
        print(f"❌ Arquivo não encontrado: {caminho_csv}")
        return False
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        return False
