"""
ppgrns_estatistica
──────────────────
Biblioteca de suporte estatístico para o PPGRNS - UTFPR.

Uso típico:
    import ppgrns_estatistica as ef

    dados = ef.carregardados()
    ef.media(dados, 'lbee')
    ef.intervaloconfianca(dados, ['lbee', 'ph'], confianca=0.95)
    ef.boxplot(dados, 'lbee', 'ph')
    ef.testet_uma(dados, 'od', mu0=6.0)
    ef.testet_duas(dados, 'riqueza', grupo='habitat')
    ef.testet_pareado(dados, 'nitrogenio_antes', 'nitrogenio_depois')
"""

__version__ = "0.1.6"
__author__ = "Evandro A. Nakajima"

# ── Importações públicas ─────────────────────────────────────────────────────

from .carregar import carregardados
from .csv_xlsx import csv_para_xlsx

from .posicao import (
    media,
    mediana,
    moda,
    quartil,
    percentil,
    limiteinferior,
    limitesuperior,
)

from .dispersao import (
    amplitude,
    variancia,
    desviopadrao,
    coeficientevariacao,
    iqr,
    assimetria,
    curtose,
)

from .inferencia import (
    intervaloconfianca,
    tamanhominimo,
)

from .testet import (
    testet_uma,
    testet_duas,
    testet_pareado,
)

from .boxplot import boxplot
from .histograma import histograma

from .graficos_interativos import icinterativo


# ── API pública explícita ────────────────────────────────────────────────────
# Define o que `from ppgrns_estatistica import *` exporta
# e serve como referência da API oficial.

__all__ = [
    # Carregamento
    "carregardados",
    "csv_para_xlsx",
    # Posição
    "media",
    "mediana",
    "moda",
    "quartil",
    "percentil",
    "limiteinferior",
    "limitesuperior",
    # Dispersão
    "amplitude",
    "variancia",
    "desviopadrao",
    "coeficientevariacao",
    "iqr",
    "assimetria",
    "curtose",
    # Inferência
    "intervaloconfianca",
    "tamanhominimo",
    # Teste t
    "testet_uma",
    "testet_duas",
    "testet_pareado",
    # Gráficos
    "boxplot",
    "histograma",
    # Gráficos interativos (Jupyter/Colab)
    "icinterativo",
]


# ── Limpeza do namespace ─────────────────────────────────────────────────────
# Remove os nomes dos submódulos do autocomplete (ef.posicao, ef.dispersao...).
# As funções continuam acessíveis como ef.media, ef.boxplot, etc.
# Os submódulos continuam funcionando internamente (via sys.modules),
# mas não aparecem mais como atributos do pacote.
#
# Cuidado: 'boxplot' e 'histograma' colidem — o módulo e a função têm o mesmo
# nome. O 'from .boxplot import boxplot' acima sobrescreve o nome do módulo
# pelo da função no namespace do pacote, então basta remover os outros.

for _submod in ('carregar', 'csv_xlsx', 'posicao', 'dispersao',
                'inferencia', 'testet', 'graficos_interativos'):
    if _submod in globals():
        del globals()[_submod]
del _submod
