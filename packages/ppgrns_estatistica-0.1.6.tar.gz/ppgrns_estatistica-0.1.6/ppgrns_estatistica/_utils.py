"""
ppgrns_estatistica._utils
─────────────────────────
Módulo interno com helpers compartilhados por toda a biblioteca.

Não faz parte da API pública — não deve ser importado diretamente pelo usuário.
"""

import pandas as pd


# ──────────────────────────────────────────────────────────────────────────────
# Seleção e preparação de colunas
# ──────────────────────────────────────────────────────────────────────────────

def selecionar_colunas(dados, colunas):
    """
    Padroniza a seleção de colunas para aceitar três formas de chamada:

    1. Nenhuma coluna (todas as do DataFrame):
       >>> media(df)

    2. Argumentos soltos:
       >>> media(df, 'col1', 'col2')

    3. Lista ou tupla única:
       >>> media(df, ['col1', 'col2'])

    Parâmetros
    ----------
    dados : pd.DataFrame
        DataFrame de origem.
    colunas : tuple
        Tupla capturada pelo *colunas da função que chama.

    Retorna
    -------
    list
        Lista de nomes de colunas.

    Exceções
    --------
    ValueError
        Se alguma coluna solicitada não existir no DataFrame.
    """
    if not colunas:
        return dados.columns.tolist()

    # Se veio uma lista/tupla única, desempacota
    if len(colunas) == 1 and isinstance(colunas[0], (list, tuple)):
        cols = list(colunas[0])
    else:
        cols = list(colunas)

    # Validação: todas as colunas devem existir
    ausentes = [c for c in cols if c not in dados.columns]
    if ausentes:
        raise ValueError(
            f"Coluna(s) não encontrada(s) no DataFrame: {ausentes}.\n"
            f"Colunas disponíveis: {list(dados.columns)}"
        )

    return cols


def garantir_numerico(dados, colunas):
    """
    Força a conversão das colunas selecionadas para tipo numérico,
    removendo caracteres invisíveis (zero-width space) e trocando
    vírgula por ponto decimal.

    Valores não conversíveis viram NaN.

    Parâmetros
    ----------
    dados : pd.DataFrame
        DataFrame de origem.
    colunas : list
        Lista de colunas já validadas (use selecionar_colunas antes).

    Retorna
    -------
    pd.DataFrame
        Cópia com as colunas convertidas para numérico.
    """
    df_limpo = dados[list(colunas)].copy()

    for col in df_limpo.columns:
        if not pd.api.types.is_numeric_dtype(df_limpo[col]):
            df_limpo[col] = (
                df_limpo[col].astype(str)
                .str.replace('\u200b', '', regex=False)   # zero-width space
                .str.replace(',', '.', regex=False)       # vírgula decimal
                .str.strip()
            )
            df_limpo[col] = pd.to_numeric(df_limpo[col], errors='coerce')

    return df_limpo


def validar_serie(dados, coluna):
    """
    Extrai e valida uma única coluna como Series numérica, sem NaN.

    Usada em funções de inferência que operam em uma coluna por vez
    (intervalo de confiança, tamanho mínimo, testes de hipótese).

    Parâmetros
    ----------
    dados : pd.DataFrame
        DataFrame de origem.
    coluna : str
        Nome da coluna a extrair.

    Retorna
    -------
    pd.Series
        Série numérica sem NaN.

    Exceções
    --------
    ValueError
        Se a coluna não existir ou não tiver valores numéricos válidos.
    """
    if coluna not in dados.columns:
        raise ValueError(
            f"A coluna '{coluna}' não foi encontrada no DataFrame.\n"
            f"Colunas disponíveis: {list(dados.columns)}"
        )
    serie = pd.to_numeric(dados[coluna], errors='coerce').dropna()
    if serie.empty:
        raise ValueError(
            f"A coluna '{coluna}' não contém valores numéricos válidos."
        )
    return serie


# ──────────────────────────────────────────────────────────────────────────────
# Formatação de saída no terminal
# ──────────────────────────────────────────────────────────────────────────────

def imprimir_titulo(titulo):
    """
    Imprime um título padronizado no estilo '--- Título ---'.

    Usado por todas as funções da biblioteca quando mostrar=True.
    """
    print(f"\n--- {titulo} ---")


def imprimir_serie(res, vazio_msg="⚠️ Nenhuma coluna numérica."):
    """
    Imprime uma pd.Series de resultados, ou uma mensagem se estiver vazia.
    """
    if res is None or (hasattr(res, "empty") and res.empty):
        print(vazio_msg)
    else:
        print(res.to_string())
