# Publishing `geneva-forecast` to PyPI

Step-by-step instructions for publishing a **test** version (TestPyPI) and the **real** version (PyPI).

---

## Prerequisites

```bash
# From the geneva-pip-package directory
pip install build twine
# — or —
pip install -e ".[dev]"
```

You'll need accounts on both registries:

| Registry | URL | Purpose |
|---|---|---|
| **TestPyPI** | https://test.pypi.org/account/register/ | Staging / dry-run |
| **PyPI** | https://pypi.org/account/register/ | Production |

> [!IMPORTANT]
> Both registries require **2FA** and an **API token** for uploads.
> Generate tokens at: *Account Settings → API tokens* on each site.

---

## 1 · Build the Package

From the `geneva-pip-package/` directory:

```bash
# Clean any previous builds
rm -rf dist/

# Build sdist + wheel
python -m build
```

This produces two files in `dist/`:
```
dist/
  geneva_forecast-0.1.0.tar.gz    ← source distribution
  geneva_forecast-0.1.0-py3-none-any.whl  ← wheel (binary)
```

> [!TIP]
> Run `twine check dist/*` to validate metadata before uploading.

---

## 2 · Deploy a TEST Version (TestPyPI)

TestPyPI is a separate, sandboxed registry. Use it to verify everything works before going live.

### 2a. Upload to TestPyPI

```bash
twine upload --repository testpypi dist/*
```

You'll be prompted for credentials:

| Field | Value |
|---|---|
| **Username** | `__token__` |
| **Password** | Your TestPyPI API token (starts with `pypi-`) |

### 2b. Verify the Upload

Your package will appear at:
```
https://test.pypi.org/project/geneva-forecast/
```

### 2c. Test-Install from TestPyPI

```bash
# Install from TestPyPI (pulling real deps from PyPI)
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            geneva-forecast
```

> [!NOTE]
> `--extra-index-url https://pypi.org/simple/` is needed so that `httpx` (a dependency) resolves from real PyPI, since TestPyPI doesn't mirror all packages.

### 2d. Smoke Test

```python
from geneva_forecast import GenevaClient, __version__
print(__version__)  # → "0.1.0"
```

---

## 3 · Deploy the REAL Version (PyPI)

Once you've validated on TestPyPI, publish to real PyPI.

### 3a. Upload to PyPI

```bash
twine upload dist/*
```

Credentials:

| Field | Value |
|---|---|
| **Username** | `__token__` |
| **Password** | Your PyPI API token (starts with `pypi-`) |

### 3b. Verify

```
https://pypi.org/project/geneva-forecast/
```

### 3c. Install

```bash
pip install geneva-forecast
```

---

## 4 · Bumping the Version

Before publishing an update, bump the version in **two places**:

1. `pyproject.toml` → `version = "X.Y.Z"`
2. `geneva_forecast/__init__.py` → `__version__ = "X.Y.Z"`

Then re-run the build + upload flow (steps 1–3).

> [!CAUTION]
> PyPI does **not** allow re-uploading the same version. You must bump the version number for every upload.

### Version Numbering Guide

| Version | When to use |
|---|---|
| `0.1.0` → `0.1.1` | Bug fixes, docs changes |
| `0.1.0` → `0.2.0` | New features, non-breaking |
| `0.x.y` → `1.0.0` | Stable public API release |

---

## 5 · Automating with a `.pypirc` (Optional)

To avoid being prompted for credentials every time, create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_REAL_PYPI_TOKEN

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_PYPI_TOKEN
```

Then upload with just:
```bash
twine upload --repository testpypi dist/*   # test
twine upload dist/*                          # production
```

> [!WARNING]
> Keep `~/.pypirc` permissions restricted: `chmod 600 ~/.pypirc`

---

## Quick Reference

```bash
# Full flow: build → check → test-upload → prod-upload
rm -rf dist/
python -m build
twine check dist/*
twine upload --repository testpypi dist/*    # ← test first
twine upload dist/*                          # ← then go live
```
