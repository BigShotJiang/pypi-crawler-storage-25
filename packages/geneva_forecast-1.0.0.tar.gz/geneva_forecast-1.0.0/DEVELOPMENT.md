# Geneva Forecast SDK — Development Guide

Internal development documentation for the `geneva-forecast` Python package.

## Project Structure

```
sdk/
├── geneva_forecast/          # Package source
│   ├── __init__.py           # Public API + version
│   ├── client.py             # GenevaClient HTTP client
│   ├── models.py             # Typed response models
│   ├── exceptions.py         # Custom exception hierarchy
│   └── plot.py               # Chart visualization (matplotlib)
├── examples/
│   ├── quickstart.py         # Full SDK demo with all features
│   └── plot_forecast.py      # Visualization demo with date labels
├── pyproject.toml            # Package metadata + build config
├── README.md                 # Public-facing (shown on PyPI)
├── DEVELOPMENT.md            # This file (internal only)
└── PUBLISHING.md             # PyPI publishing instructions
```

## Local Development Setup

```bash
cd sdk
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Running Examples

Set your API key and target environment:

```bash
# Against dev API
GENEVA_API_KEY=gva_... GENEVA_API_URL=https://api-dev.roadmap-tech.com python3 examples/quickstart.py

# Against local engine
GENEVA_API_KEY=gva_... GENEVA_API_URL=http://localhost:8000 python3 examples/quickstart.py

# Plot demo
GENEVA_API_KEY=gva_... GENEVA_API_URL=https://api-dev.roadmap-tech.com python3 examples/plot_forecast.py
```

## URL Configuration

The `GenevaClient` requires `api_url` as a constructor argument (no default).

| Environment | URL |
|---|---|
| Local dev | `http://localhost:8000` |
| Dev deployment | `https://api-dev.roadmap-tech.com` |
| Production | `https://api.roadmap-tech.com` |

The quickstart example defaults to `localhost:8000` via `GENEVA_API_URL` env var.
The public README shows `https://api.roadmap-tech.com` in all examples.

## All Forecast Parameters (Full Reference)

| Parameter | Type | Default | Description |
|---|---|---|---|
| `data` | `list[float]` | *required* | Time series observations (min 3, max 10,000) |
| `method` | `int \| None` | `None` | Method ID (0–9). `None` = Expert System auto-select |
| `seasonal_transform` | `int` | `0` | 0=None, 1=Seasonal, 2=MPT |
| `smoothing` | `bool` | `False` | Median data smoothing (3-period window) |
| `wave_periods` | `list[int]` | `[12]` | Seasonal periods (e.g. `[12]`, `[52,7]`) |
| `horizon` | `int \| None` | `None` | Periods to forecast (default: one full cycle) |
| `history_length` | `int \| None` | `None` | Override historical data length |
| `confidence_level` | `float \| None` | `None` | Prediction interval confidence (e.g. `0.95`) |
| `holdout_ratio` | `float \| None` | `None` | Fraction reserved for evaluation |
| `max_periods_factor` | `float \| None` | `None` | Fit window cap (nPPC × MPF). Auto-calculated when omitted. |
| `include` | `list[str]` | `["forecast", "metrics", "model_info"]` | Response sections to include |

## Building & Publishing

See [PUBLISHING.md](PUBLISHING.md) for full instructions.

Quick reference:

```bash
# Build
rm -rf dist/ && .venv/bin/python3 -m build

# Check
.venv/bin/twine check dist/*

# Upload to TestPyPI
.venv/bin/twine upload --repository testpypi dist/*

# Upload to PyPI
.venv/bin/twine upload dist/*
```

## Architecture Notes

- **`api_url` is a required param** — never hardcoded. Users always provide it.
- **Auto-MPF** — The engine automatically calculates `max_periods_factor` when not set.
- **matplotlib is a base dependency** — ships with every install for the plot module.
- **`plot.py` uses `dateutil.relativedelta`** — bundled with matplotlib, no extra deps.
- **The wheel only includes `geneva_forecast/`** — examples, tests, and dev docs are excluded.
