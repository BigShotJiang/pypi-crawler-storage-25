"""
Geneva Forecast SDK — Exception classes.
"""


class GenevaError(Exception):
    """Base exception for all Geneva SDK errors."""


class GenevaAPIError(GenevaError):
    """Raised when the Geneva API returns a 4xx or 5xx response."""

    def __init__(self, status_code: int, message: str, detail: str | None = None):
        self.status_code = status_code
        self.message = message
        self.detail = detail
        parts = [f"[{status_code}] {message}"]
        if detail:
            parts.append(f"  Detail: {detail}")
        super().__init__("\n".join(parts))


class GenevaConnectionError(GenevaError):
    """Raised when the Geneva API is unreachable."""


class GenevaTimeoutError(GenevaError):
    """Raised when a request to the Geneva API times out."""
