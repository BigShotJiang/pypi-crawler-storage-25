"""
Geneva Forecast — Python SDK for the Geneva Forecasting Engine API.

Usage::

    from geneva_forecast import GenevaClient

    client = GenevaClient(api_url="http://localhost:8000", api_key="gva_...")
    result = client.forecast(data=[120.5, 135.2, ...], horizon=12)

    for point in result.forecast:
        print(f"  Period {point.period}: {point.value:.2f}")
"""

from .client import GenevaClient
from .exceptions import (
    GenevaAPIError,
    GenevaConnectionError,
    GenevaError,
    GenevaTimeoutError,
)
from .models import (
    BatchForecastResult,
    ConformalForecastPoint,
    ConformalPredictionInfo,
    FittedPoint,
    ForecastPoint,
    ForecastResult,
    Metrics,
    ModelInfo,
    SeasonalPoint,
    SeriesResult,
    TrialInfo,
)

__version__ = "1.0.0"

__all__ = [
    # Client
    "GenevaClient",
    # Response models
    "ForecastResult",
    "BatchForecastResult",
    "SeriesResult",
    "ForecastPoint",
    "FittedPoint",
    "SeasonalPoint",
    "Metrics",
    "ModelInfo",
    "TrialInfo",
    "ConformalForecastPoint",
    "ConformalPredictionInfo",
    # Exceptions
    "GenevaError",
    "GenevaAPIError",
    "GenevaConnectionError",
    "GenevaTimeoutError",
]
