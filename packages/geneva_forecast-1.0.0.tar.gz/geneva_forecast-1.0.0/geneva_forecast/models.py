"""
Geneva Forecast SDK — Typed response models.

Lightweight dataclasses that mirror the Geneva Engine API response schema.
No external dependencies — uses only stdlib.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ─── Forecast sub-models ──────────────────────────────────────────────


@dataclass
class ForecastPoint:
    """A single forecasted period."""

    period: int
    value: float


@dataclass
class FittedPoint:
    """A single in-sample fitted value."""

    period: int
    value: float


@dataclass
class SeasonalPoint:
    """Seasonal and smoothed seasonal factor for a period."""

    period: int
    seasonal_factor: float
    smoothed_seasonal_factor: float


@dataclass
class Metrics:
    """Error metrics from the best-fit model."""

    mad: float
    mape: float
    rmse: float


@dataclass
class ModelInfo:
    """Information about the model selected/used."""

    method_id: int
    method_name: str
    transform_id: int
    transform_name: str
    smoothing: bool


@dataclass
class TrialInfo:
    """Diagnostic info for one trial fit."""

    trial_number: int
    method_id: int
    method_name: str
    transform_id: int
    transform_name: str
    smoothing: bool
    alpha: float
    beta: float
    gamma: float
    trend_hold: float
    cyclical_decay: float
    mpt_decay: float
    mad: float
    mape: float
    rmse: float


@dataclass
class ConformalForecastPoint:
    """A forecast point with conformal prediction interval bounds."""

    period: int
    forecast: float
    lower: float
    upper: float


@dataclass
class ConformalPredictionInfo:
    """Metadata about the conformal prediction computation."""

    confidence_level: float
    interval_width: float
    calibration_residuals: int
    method: str = "split_conformal"
    low_residual_warning: Optional[str] = None


# ─── Top-level response models ───────────────────────────────────────


@dataclass
class ForecastResult:
    """Result from a single /forecast call.

    Fields are populated based on the ``include`` parameter sent with the
    request.  By default only ``forecast``, ``metrics``, and ``model_info``
    are returned.
    """

    forecast: Optional[list[ForecastPoint]] = None
    fitted: Optional[list[FittedPoint]] = None
    seasonal_factors: Optional[list[SeasonalPoint]] = None
    metrics: Optional[Metrics] = None
    model_info: Optional[ModelInfo] = None
    trials: Optional[list[TrialInfo]] = None
    prediction_intervals: Optional[list[ConformalForecastPoint]] = None
    prediction_interval_info: Optional[ConformalPredictionInfo] = None


@dataclass
class SeriesResult:
    """Result for one series within a batch forecast."""

    id: Optional[str] = None
    status: str = "success"
    forecast: Optional[ForecastResult] = None
    error: Optional[str] = None


@dataclass
class BatchForecastResult:
    """Result from a /batch-forecast call."""

    results: list[SeriesResult] = field(default_factory=list)
    total_series: int = 0
    successful: int = 0
    failed: int = 0
    elapsed_ms: float = 0.0


# ─── Parsing helpers ─────────────────────────────────────────────────


def _parse_forecast_point(d: dict) -> ForecastPoint:
    return ForecastPoint(period=d["period"], value=d["value"])


def _parse_fitted_point(d: dict) -> FittedPoint:
    return FittedPoint(period=d["period"], value=d["value"])


def _parse_seasonal_point(d: dict) -> SeasonalPoint:
    return SeasonalPoint(
        period=d["period"],
        seasonal_factor=d["seasonal_factor"],
        smoothed_seasonal_factor=d["smoothed_seasonal_factor"],
    )


def _parse_metrics(d: dict) -> Metrics:
    return Metrics(mad=d["mad"], mape=d["mape"], rmse=d["rmse"])


def _parse_model_info(d: dict) -> ModelInfo:
    return ModelInfo(
        method_id=d["method_id"],
        method_name=d["method_name"],
        transform_id=d["transform_id"],
        transform_name=d["transform_name"],
        smoothing=d["smoothing"],
    )


def _parse_trial_info(d: dict) -> TrialInfo:
    return TrialInfo(
        trial_number=d["trial_number"],
        method_id=d["method_id"],
        method_name=d["method_name"],
        transform_id=d["transform_id"],
        transform_name=d["transform_name"],
        smoothing=d["smoothing"],
        alpha=d["alpha"],
        beta=d["beta"],
        gamma=d["gamma"],
        trend_hold=d["trend_hold"],
        cyclical_decay=d["cyclical_decay"],
        mpt_decay=d["mpt_decay"],
        mad=d["mad"],
        mape=d["mape"],
        rmse=d["rmse"],
    )


def _parse_conformal_point(d: dict) -> ConformalForecastPoint:
    return ConformalForecastPoint(
        period=d["period"],
        forecast=d["forecast"],
        lower=d["lower"],
        upper=d["upper"],
    )


def _parse_conformal_info(d: dict) -> ConformalPredictionInfo:
    return ConformalPredictionInfo(
        confidence_level=d["confidence_level"],
        interval_width=d["interval_width"],
        calibration_residuals=d["calibration_residuals"],
        method=d.get("method", "split_conformal"),
        low_residual_warning=d.get("low_residual_warning"),
    )


def _parse_forecast_result(data: dict) -> ForecastResult:
    """Parse the JSON response dict into a typed ForecastResult."""
    return ForecastResult(
        forecast=(
            [_parse_forecast_point(p) for p in data["forecast"]]
            if data.get("forecast")
            else None
        ),
        fitted=(
            [_parse_fitted_point(p) for p in data["fitted"]]
            if data.get("fitted")
            else None
        ),
        seasonal_factors=(
            [_parse_seasonal_point(p) for p in data["seasonal_factors"]]
            if data.get("seasonal_factors")
            else None
        ),
        metrics=_parse_metrics(data["metrics"]) if data.get("metrics") else None,
        model_info=(
            _parse_model_info(data["model_info"]) if data.get("model_info") else None
        ),
        trials=(
            [_parse_trial_info(t) for t in data["trials"]]
            if data.get("trials")
            else None
        ),
        prediction_intervals=(
            [_parse_conformal_point(p) for p in data["prediction_intervals"]]
            if data.get("prediction_intervals")
            else None
        ),
        prediction_interval_info=(
            _parse_conformal_info(data["prediction_interval_info"])
            if data.get("prediction_interval_info")
            else None
        ),
    )


def _parse_batch_result(data: dict) -> BatchForecastResult:
    """Parse the JSON response dict into a typed BatchForecastResult."""
    results = []
    for r in data.get("results", []):
        sr = SeriesResult(
            id=r.get("id"),
            status=r["status"],
            forecast=(
                _parse_forecast_result(r["forecast"]) if r.get("forecast") else None
            ),
            error=r.get("error"),
        )
        results.append(sr)

    return BatchForecastResult(
        results=results,
        total_series=data["total_series"],
        successful=data["successful"],
        failed=data["failed"],
        elapsed_ms=data["elapsed_ms"],
    )
