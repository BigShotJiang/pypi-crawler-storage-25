"""
Geneva Forecast SDK — HTTP Client.

Usage::

    from geneva_forecast import GenevaClient

    client = GenevaClient(
        api_url="http://localhost:8000",
        api_key="gva_...",
    )

    result = client.forecast(
        data=[120.5, 135.2, 142.8, 128.3, 155.1, 162.4, ...],
        horizon=12,
    )

    for point in result.forecast:
        print(f"  Period {point.period}: {point.value:.2f}")
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .exceptions import GenevaAPIError, GenevaConnectionError, GenevaTimeoutError
from .models import (
    BatchForecastResult,
    ForecastResult,
    _parse_batch_result,
    _parse_forecast_result,
)


class GenevaClient:
    """Synchronous client for the Geneva Forecasting Engine API.

    Parameters
    ----------
    api_url : str
        Base URL of the Geneva Engine API (e.g. ``"http://localhost:8000"``
        or ``"https://api.geneva.ai"``).
    api_key : str
        API key for authentication (sent as ``X-API-Key`` header).
    timeout : float
        Request timeout in seconds (default 30).
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        timeout: float = 30.0,
    ) -> None:
        # Strip trailing slash for clean URL joins
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self._client = httpx.Client(
            base_url=self.api_url,
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> GenevaClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ─── Core API ─────────────────────────────────────────────────────

    def forecast(
        self,
        data: list[float],
        *,
        method: Optional[int] = None,
        seasonal_transform: int = 0,
        smoothing: bool = False,
        wave_periods: list[int] | None = None,
        horizon: Optional[int] = None,
        history_length: Optional[int] = None,
        confidence_level: Optional[float] = None,
        holdout_ratio: Optional[float] = None,
        max_periods_factor: Optional[float] = None,
        include: list[str] | None = None,
    ) -> ForecastResult:
        """Run a single-series forecast.

        Parameters
        ----------
        data : list[float]
            Time series observations (min 3, max 10,000 data points).
        method : int, optional
            Forecasting method ID (0–9). ``None`` = Expert System auto-select.
        seasonal_transform : int
            0=None, 1=Seasonal, 2=MPT (Moving Periodic Total).
        smoothing : bool
            Enable median data smoothing (3-period window).
        wave_periods : list[int], optional
            Seasonal wave periods (default ``[12]``).
        horizon : int, optional
            Number of periods to forecast (default: one full cycle).
        history_length : int, optional
            Override number of historical data points to use.
        confidence_level : float, optional
            Confidence level for prediction intervals (e.g. 0.95).
        holdout_ratio : float, optional
            Fraction of data reserved for evaluation.
        max_periods_factor : float, optional
            Max Periods Factor — controls the fit window cap.
        include : list[str], optional
            Response sections to include. Default:
            ``["forecast", "metrics", "model_info"]``.

        Returns
        -------
        ForecastResult
            Typed forecast result with all requested response sections.

        Raises
        ------
        GenevaAPIError
            On 4xx/5xx HTTP responses from the API.
        GenevaConnectionError
            When the API is unreachable.
        GenevaTimeoutError
            When the request times out.
        """
        payload: dict[str, Any] = {"data": data}

        # Only include non-default optional fields
        if method is not None:
            payload["method"] = method
        if seasonal_transform != 0:
            payload["seasonal_transform"] = seasonal_transform
        if smoothing:
            payload["smoothing"] = smoothing
        if wave_periods is not None:
            payload["wave_periods"] = wave_periods
        if horizon is not None:
            payload["forecast_horizon"] = horizon
        if history_length is not None:
            payload["history_length"] = history_length
        if confidence_level is not None:
            payload["confidence_level"] = confidence_level
        if holdout_ratio is not None:
            payload["holdout_ratio"] = holdout_ratio
        if max_periods_factor is not None:
            payload["max_periods_factor"] = max_periods_factor
        if include is not None:
            payload["include"] = include

        data_raw = self._post("/forecast", payload)
        return _parse_forecast_result(data_raw)

    def batch_forecast(
        self,
        series: list[dict[str, Any]],
    ) -> BatchForecastResult:
        """Run a batch forecast on multiple time series.

        Parameters
        ----------
        series : list[dict]
            List of series dicts, each containing at minimum ``"data"``
            (list of floats).  Optionally include ``"id"`` (str) and any
            other forecast parameters (``method``, ``wave_periods``, etc.).

            Example::

                [
                    {"id": "sales_us", "data": [100, 120, ...], "horizon": 12},
                    {"id": "sales_eu", "data": [200, 210, ...], "horizon": 6},
                ]

        Returns
        -------
        BatchForecastResult
            Typed batch result with per-series results.
        """
        processed_series = []
        for s in series:
            s_copy = s.copy()
            if "horizon" in s_copy:
                s_copy["forecast_horizon"] = s_copy.pop("horizon")
            processed_series.append(s_copy)

        payload = {"series": processed_series}
        data_raw = self._post("/batch-forecast", payload)
        return _parse_batch_result(data_raw)

    # ─── Utility ──────────────────────────────────────────────────────

    def health(self) -> dict:
        """Check API health (``GET /health``).

        Returns the raw JSON response dict.
        """
        return self._get("/health")

    def ready(self) -> dict:
        """Deep readiness probe (``GET /ready``).

        Checks engine binary + database connectivity.
        Returns the raw JSON response dict.
        """
        return self._get("/ready")

    # ─── Internal ─────────────────────────────────────────────────────

    def _post(self, path: str, json_body: dict) -> dict:
        """POST to the API, handling errors."""
        try:
            response = self._client.post(path, json=json_body)
        except httpx.ConnectError as e:
            raise GenevaConnectionError(
                f"Could not connect to Geneva API at {self.api_url}: {e}"
            ) from e
        except httpx.TimeoutException as e:
            raise GenevaTimeoutError(
                f"Request to {self.api_url}{path} timed out: {e}"
            ) from e

        if response.status_code >= 400:
            self._raise_api_error(response)

        return response.json()

    def _get(self, path: str) -> dict:
        """GET from the API, handling errors."""
        try:
            response = self._client.get(path)
        except httpx.ConnectError as e:
            raise GenevaConnectionError(
                f"Could not connect to Geneva API at {self.api_url}: {e}"
            ) from e
        except httpx.TimeoutException as e:
            raise GenevaTimeoutError(
                f"Request to {self.api_url}{path} timed out: {e}"
            ) from e

        if response.status_code >= 400:
            self._raise_api_error(response)

        return response.json()

    @staticmethod
    def _raise_api_error(response: httpx.Response) -> None:
        """Parse an error response and raise GenevaAPIError."""
        try:
            body = response.json()
        except Exception:
            raise GenevaAPIError(
                status_code=response.status_code,
                message=response.text or "Unknown error",
            )

        # FastAPI validation errors come as {"detail": [...]}
        # Geneva errors come as {"error": "...", "detail": "..."}
        if "error" in body:
            raise GenevaAPIError(
                status_code=response.status_code,
                message=body["error"],
                detail=body.get("detail"),
            )
        elif "detail" in body:
            detail = body["detail"]
            if isinstance(detail, list):
                # Pydantic validation errors
                messages = []
                for err in detail:
                    loc = " → ".join(str(l) for l in err.get("loc", []))
                    messages.append(f"{loc}: {err.get('msg', '')}")
                raise GenevaAPIError(
                    status_code=response.status_code,
                    message="Validation error",
                    detail="; ".join(messages),
                )
            else:
                raise GenevaAPIError(
                    status_code=response.status_code,
                    message=str(detail),
                )
        else:
            raise GenevaAPIError(
                status_code=response.status_code,
                message=response.text or "Unknown error",
            )
