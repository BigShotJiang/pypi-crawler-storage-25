"""
Geneva Forecast — Chart Visualization.

Convenience function for plotting forecast results with matplotlib.

Usage::

    from geneva_forecast import GenevaClient
    from geneva_forecast.plot import plot_forecast

    client = GenevaClient(api_url="https://api.roadmap-tech.com", api_key="gva_...")
    result = client.forecast(
        data=monthly_sales,
        horizon=12,
        confidence_level=0.95,
        include=["forecast", "fitted", "prediction_intervals", "metrics", "model_info"],
    )

    # Period-numbered x-axis (default)
    plot_forecast(monthly_sales, result)

    # Calendar date x-axis
    plot_forecast(monthly_sales, result, start_date="2020-01-01", freq="MS")
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

try:
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    import matplotlib.ticker as ticker
except ImportError:
    raise ImportError(
        "matplotlib is required for plotting but could not be imported. "
        "Try reinstalling: pip install --force-reinstall geneva-forecast"
    )

from .models import ForecastResult


# ── Date generation helpers ─────────────────────────────────────────

_FREQ_MAP = {
    "MS": "month",     # Month Start
    "QS": "quarter",   # Quarter Start
    "W":  "week",      # Weekly
    "D":  "day",       # Daily
    "H":  "hour",      # Hourly
    "YS": "year",      # Year Start
}


def _generate_dates(start: datetime, freq: str, count: int) -> list[datetime]:
    """Generate a list of dates from a start date and frequency string.

    Parameters
    ----------
    start : datetime
        Starting date.
    freq : str
        Frequency code: ``"MS"`` (monthly), ``"QS"`` (quarterly),
        ``"W"`` (weekly), ``"D"`` (daily), ``"H"`` (hourly), ``"YS"`` (yearly).
    count : int
        Number of dates to generate.

    Returns
    -------
    list[datetime]
        The generated dates.
    """
    try:
        from dateutil.relativedelta import relativedelta
    except ImportError:
        raise ImportError(
            "python-dateutil is required for date-labeled charts. "
            "It is normally installed with matplotlib."
        )

    freq_upper = freq.upper()
    if freq_upper not in _FREQ_MAP:
        raise ValueError(
            f"Unsupported frequency '{freq}'. "
            f"Supported: {', '.join(_FREQ_MAP.keys())}"
        )

    dates = []
    current = start
    for _ in range(count):
        dates.append(current)
        if freq_upper == "MS":
            current += relativedelta(months=1)
        elif freq_upper == "QS":
            current += relativedelta(months=3)
        elif freq_upper == "W":
            current += timedelta(weeks=1)
        elif freq_upper == "D":
            current += timedelta(days=1)
        elif freq_upper == "H":
            current += timedelta(hours=1)
        elif freq_upper == "YS":
            current += relativedelta(years=1)

    return dates


def plot_forecast(
    data: list[float],
    result: ForecastResult,
    *,
    title: Optional[str] = None,
    confidence_level: float = 0.95,
    start_date: Optional[str] = None,
    freq: str = "MS",
    show: bool = True,
    save: Optional[str] = None,
    figsize: tuple[float, float] = (14, 7),
    dpi: int = 150,
) -> "matplotlib.figure.Figure":
    """Plot a Geneva forecast result with historical data and prediction intervals.

    Parameters
    ----------
    data : list[float]
        The original time series data passed to ``client.forecast()``.
    result : ForecastResult
        The result object returned by ``client.forecast()``.
    title : str, optional
        Custom chart title. Auto-generated if not provided.
    confidence_level : float
        Confidence level used for the prediction intervals (for labeling).
        Should match the value passed to ``client.forecast()``.
    start_date : str, optional
        Start date of the time series in ``YYYY-MM-DD`` format
        (e.g. ``"2020-01-01"``). When provided, the x-axis displays
        calendar dates instead of period numbers.
    freq : str
        Frequency of the time series. Only used when ``start_date`` is
        provided. Supported values:

        - ``"MS"`` — Monthly (default)
        - ``"QS"`` — Quarterly
        - ``"W"``  — Weekly
        - ``"D"``  — Daily
        - ``"H"``  — Hourly
        - ``"YS"`` — Yearly
    show : bool
        If True, display the chart interactively (``plt.show()``).
    save : str, optional
        File path to save the chart as an image (e.g. ``"forecast.png"``).
    figsize : tuple[float, float]
        Figure size in inches ``(width, height)``.
    dpi : int
        Resolution for saved images.

    Returns
    -------
    matplotlib.figure.Figure
        The matplotlib figure object (for further customization).

    Examples
    --------
    Basic forecast chart with period numbers::

        fig = plot_forecast(my_data, result)

    Chart with calendar date labels::

        plot_forecast(my_data, result, start_date="2020-01-01", freq="MS")

    Save without displaying::

        plot_forecast(my_data, result, show=False, save="forecast.png")
    """
    # ── Extract data from result ────────────────────────────────────
    forecast_pts = result.forecast or []
    fitted_pts = result.fitted or []
    intervals = result.prediction_intervals or []
    interval_info = result.prediction_interval_info
    metrics = result.metrics
    model_info = result.model_info

    n_data = len(data)
    n_forecast = len(forecast_pts)

    # ── Build x-axes (dates or period numbers) ──────────────────────
    use_dates = start_date is not None

    if use_dates:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError(
                f"start_date must be in YYYY-MM-DD format (got '{start_date}'). "
                f"Example: '2020-01-01'"
            )

        all_dates = _generate_dates(start_dt, freq, n_data + n_forecast)
        data_x = all_dates[:n_data]
        forecast_x = all_dates[n_data:]

        # Map fitted period numbers to dates
        if fitted_pts:
            fitted_x = [all_dates[pt.period - 1] for pt in fitted_pts
                        if pt.period - 1 < len(all_dates)]
        else:
            fitted_x = []

        # Divider position (halfway between last data point and first forecast)
        divider_x = data_x[-1] + (forecast_x[0] - data_x[-1]) / 2 if forecast_x else None
    else:
        data_x = list(range(1, n_data + 1))
        forecast_x = list(range(n_data + 1, n_data + n_forecast + 1))
        fitted_x = [pt.period for pt in fitted_pts] if fitted_pts else []
        divider_x = n_data + 0.5

    forecast_vals = [pt.value for pt in forecast_pts]
    fitted_vals = [pt.value for pt in fitted_pts] if fitted_pts else []

    # Prediction intervals
    lower_band = [pt.lower for pt in intervals] if intervals else []
    upper_band = [pt.upper for pt in intervals] if intervals else []

    # ── Styling ─────────────────────────────────────────────────────
    plt.style.use("seaborn-v0_8-darkgrid")
    fig, ax = plt.subplots(figsize=figsize)

    # Color palette
    c_data = "#2c3e50"
    c_fitted = "#e67e22"
    c_forecast = "#e74c3c"
    c_band = "#3498db"

    # Historical data
    ax.plot(
        data_x, data,
        color=c_data, linewidth=1.6, label="Historical Data",
        marker=".", markersize=3, zorder=3,
    )

    # Fitted values (in-sample model fit)
    if fitted_vals and fitted_x:
        ax.plot(
            fitted_x, fitted_vals,
            color=c_fitted, linewidth=1.2, linestyle="--",
            label="Fitted (In-sample)", alpha=0.7, zorder=2,
        )

    # Forecast
    ax.plot(
        forecast_x, forecast_vals,
        color=c_forecast, linewidth=2.2, label="Forecast",
        marker="o", markersize=5, zorder=4,
    )

    # Prediction interval bands
    if lower_band and upper_band:
        conf_pct = f"{confidence_level * 100:.0f}%"
        ax.fill_between(
            forecast_x, lower_band, upper_band,
            color=c_band, alpha=0.20,
            label=f"{conf_pct} Prediction Interval",
            zorder=1,
        )
        ax.plot(
            forecast_x, lower_band,
            color=c_band, linewidth=0.8, linestyle=":", alpha=0.6,
        )
        ax.plot(
            forecast_x, upper_band,
            color=c_band, linewidth=0.8, linestyle=":", alpha=0.6,
        )

    # Vertical divider between history and forecast
    if divider_x is not None:
        ax.axvline(
            x=divider_x, color="#7f8c8d", linestyle="-.",
            linewidth=1.0, alpha=0.6,
        )

    # ── Date axis formatting ────────────────────────────────────────
    if use_dates:
        locator = mdates.AutoDateLocator(minticks=6, maxticks=14)
        formatter = mdates.ConciseDateFormatter(locator)
        ax.xaxis.set_major_locator(locator)
        ax.xaxis.set_major_formatter(formatter)
        fig.autofmt_xdate(rotation=30, ha="right")

    # ── Info box ────────────────────────────────────────────────────
    info_lines = []

    if model_info:
        info_lines.append(f"Model: {model_info.method_name}")
        if model_info.transform_name and model_info.transform_name != "None":
            info_lines.append(f"Transform: {model_info.transform_name}")

    if metrics:
        parts = []
        if metrics.mad is not None:
            parts.append(f"MAD: {metrics.mad:.2f}")
        if metrics.mape is not None:
            parts.append(f"MAPE: {metrics.mape:.2f}%")
        if metrics.rmse is not None:
            parts.append(f"RMSE: {metrics.rmse:.2f}")
        if parts:
            info_lines.append("  |  ".join(parts))

    if interval_info:
        width = interval_info.interval_width or 0
        n_res = interval_info.calibration_residuals or 0
        info_lines.append(f"Band Width: ±{width / 2:.2f}  ({n_res} residuals)")

    if info_lines:
        info_text = "\n".join(info_lines)
        ax.text(
            0.02, 0.97, info_text,
            transform=ax.transAxes, fontsize=9,
            verticalalignment="top", fontfamily="monospace",
            bbox=dict(
                boxstyle="round,pad=0.5",
                facecolor="white", alpha=0.85, edgecolor="#bdc3c7",
            ),
        )

    # ── Labels and title ────────────────────────────────────────────
    if title is None:
        method = model_info.method_name if model_info else "Forecast"
        if intervals:
            conf_pct = f"{confidence_level * 100:.0f}%"
            title = f"Geneva Forecast — {method} with {conf_pct} Prediction Intervals"
        else:
            title = f"Geneva Forecast — {method}"

    ax.set_title(title, fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel("Date" if use_dates else "Period", fontsize=11)
    ax.set_ylabel("Value", fontsize=11)
    ax.legend(loc="lower left", fontsize=9, framealpha=0.9)

    # Format y-axis with commas for large numbers
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(
        lambda x, _: f"{x:,.0f}" if abs(x) >= 1000 else f"{x:.1f}"
    ))

    plt.tight_layout()

    # ── Save / show ─────────────────────────────────────────────────
    if save:
        fig.savefig(save, dpi=dpi, bbox_inches="tight")

    if show:
        plt.show()
    else:
        plt.close(fig)

    return fig
