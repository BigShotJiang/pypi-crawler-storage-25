#!/usr/bin/env python3
"""
Geneva Forecast SDK — Plot Example

Demonstrates the built-in chart visualization for forecast results.

    cd sdk
    pip install -e .
    GENEVA_API_KEY=gva_... python examples/plot_forecast.py

Set GENEVA_API_URL to target a specific API instance (default: https://api.roadmap-tech.com).
"""

import os
import sys

from geneva_forecast import GenevaClient, GenevaAPIError, GenevaConnectionError

# ─── Configuration ────────────────────────────────────────────────────

API_URL = os.getenv("GENEVA_API_URL", "https://api.roadmap-tech.com")
API_KEY = os.getenv("GENEVA_API_KEY", "YOUR_API_KEY_HERE")

if API_KEY == "YOUR_API_KEY_HERE":
    print("⚠️  Set GENEVA_API_KEY environment variable or edit this file.")
    print("   Example: GENEVA_API_KEY=gva_abc123 python examples/plot_forecast.py")
    sys.exit(1)


# ─── Sample Data ──────────────────────────────────────────────────────

# 6 years of monthly sales data — realistic noise, seasonal pattern, upward trend
MONTHLY_SALES = [
    112.0, 118.4, 132.1, 124.3, 121.1, 140.2,
    148.9, 153.7, 136.2, 119.0, 104.0, 118.5,
    121.3, 129.8, 138.5, 146.7, 128.4, 155.3,
    162.8, 149.1, 141.7, 119.5, 108.2, 126.3,
    133.9, 142.7, 156.1, 137.8, 145.2, 161.4,
    178.3, 168.0, 149.5, 125.3, 113.7, 132.8,
    139.5, 155.8, 148.2, 163.4, 152.7, 175.9,
    194.1, 181.3, 162.8, 140.6, 129.3, 148.7,
    157.2, 149.8, 171.6, 158.3, 168.9, 189.4,
    210.7, 195.2, 174.3, 153.1, 141.8, 163.9,
    172.4, 181.9, 195.7, 178.3, 183.5, 204.6,
    226.3, 213.8, 188.7, 165.4, 155.2, 179.8,
]


def main():
    print("=" * 60)
    print("Geneva Forecast SDK — Plot Example")
    print("=" * 60)

    # ── Connect ──────────────────────────────────────────────────
    client = GenevaClient(api_url=API_URL, api_key=API_KEY)

    try:
        health = client.health()
        print(f"\n✅ API is healthy: {health}")
    except GenevaConnectionError:
        print(f"\n❌ Could not connect to {API_URL}")
        sys.exit(1)

    # ── Run forecast with all the data needed for a rich chart ───
    print("\n📈 Running forecast with 95% prediction intervals...")

    try:
        result = client.forecast(
            data=MONTHLY_SALES,
            horizon=12,
            wave_periods=[12],
            confidence_level=0.95,
            include=["forecast", "fitted", "prediction_intervals", "metrics", "model_info"],
        )
    except GenevaAPIError as e:
        print(f"❌ API Error: {e}")
        sys.exit(1)

    # ── Print summary ────────────────────────────────────────────
    if result.model_info:
        print(f"   Model: {result.model_info.method_name}")
    if result.metrics:
        print(f"   MAPE:  {result.metrics.mape:.2f}%")
    if result.forecast:
        print(f"   Forecast points: {len(result.forecast)}")
    if result.prediction_intervals:
        print(f"   Prediction intervals: {len(result.prediction_intervals)} points")

    # ── Plot ─────────────────────────────────────────────────────
    print("\n📊 Generating chart...")

    try:
        from geneva_forecast.plot import plot_forecast
    except ImportError:
        print("❌ matplotlib not installed. Install with: pip install geneva-forecast[plot]")
        sys.exit(1)

    # Option 1: Show interactive chart with calendar dates on x-axis
    plot_forecast(MONTHLY_SALES, result, start_date="2020-01-01", freq="MS")

    # Option 2: Period numbers instead of dates (omit start_date)
    # plot_forecast(MONTHLY_SALES, result)

    # Option 3: Save to file without showing
    # plot_forecast(MONTHLY_SALES, result, start_date="2020-01-01", freq="MS",
    #               show=False, save="forecast.png")

    # Option 4: Custom title
    # plot_forecast(
    #     MONTHLY_SALES, result,
    #     start_date="2020-01-01", freq="MS",
    #     title="Q1 2026 Revenue Forecast",
    #     figsize=(16, 8),
    # )

    print("\n✅ Done!")
    client.close()


if __name__ == "__main__":
    main()
