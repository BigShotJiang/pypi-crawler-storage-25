#!/usr/bin/env python3
"""
Geneva Forecast SDK — Quickstart Example

Run with your local engine:

    cd geneva-pip-package
    pip install -e .
    python examples/quickstart.py

Requires the Geneva Engine API running on localhost:8000.
Set GENEVA_API_KEY in your environment or edit the key below.
"""

import os
import sys

from geneva_forecast import GenevaClient, GenevaAPIError, GenevaConnectionError


# ─── Configuration ────────────────────────────────────────────────────

API_URL = os.getenv("GENEVA_API_URL", "http://localhost:8000")
API_KEY = os.getenv("GENEVA_API_KEY", "YOUR_API_KEY_HERE")

if API_KEY == "YOUR_API_KEY_HERE":
    print("⚠️  Set GENEVA_API_KEY environment variable or edit this file.")
    print("   Example: GENEVA_API_KEY=gva_abc123 python examples/quickstart.py")
    sys.exit(1)


# ─── Sample Data ──────────────────────────────────────────────────────

# 6 years of monthly sales data (72 points)
MONTHLY_SALES = [
    112.0, 118.4, 132.1, 124.3, 121.1, 140.2,
    148.9, 153.7, 136.2, 119.0, 104.0, 118.5,
    121.3, 129.8, 138.5, 146.7, 128.4, 155.3,
    162.8, 149.1, 141.7, 119.5, 108.2, 126.3,
    133.9, 142.7, 156.1, 137.8, 145.2, 161.4,
    178.3, 168.0, 149.5, 125.3, 113.7, 132.8,
    139.5, 155.8, 148.2, 163.4, 152.7, 175.9,
    194.1, 181.3, 162.8, 140.6, 129.3, 148.7,
    157.2, 149.8, 171.6, 158.3, 168.9, 189.4,
    210.7, 195.2, 174.3, 153.1, 141.8, 163.9,
    172.4, 181.9, 195.7, 178.3, 183.5, 204.6,
    226.3, 213.8, 188.7, 165.4, 155.2, 179.8,
]

# Weekly data (2 years)
WEEKLY_VISITORS = [
    1200, 1350, 1280, 1420, 1380, 1500, 1450,
    1320, 1480, 1550, 1600, 1520, 1380, 1250,
    1180, 1300, 1420, 1380, 1500, 1460, 1550,
    1480, 1620, 1580, 1700, 1650, 1520, 1400,
    1280, 1350, 1450, 1400, 1520, 1480, 1580,
    1520, 1650, 1600, 1720, 1680, 1550, 1430,
    1310, 1380, 1480, 1440, 1560, 1520, 1620,
    1560, 1680, 1640, 1760, 1720, 1580, 1460,
    1340, 1410, 1510, 1470, 1590, 1550, 1650,
    1590, 1710, 1670, 1790, 1750, 1620, 1500,
    1380, 1450, 1550, 1510, 1630, 1590, 1690,
    1630, 1750, 1710, 1830, 1790, 1660, 1540,
    1420, 1490, 1590, 1550, 1670, 1630, 1730,
    1670, 1790, 1750, 1870, 1830, 1700, 1580,
    1460, 1530, 1630, 1590, 1710, 1670, 1770,
]


def main():
    client = GenevaClient(api_url=API_URL, api_key=API_KEY)

    # ── 1. Health Check ───────────────────────────────────────────────
    print("=" * 60)
    print("Geneva Forecast SDK — Quickstart")
    print("=" * 60)

    try:
        health = client.health()
        print(f"\n✅ API is healthy: {health}")
    except GenevaConnectionError:
        print(f"\n❌ Could not connect to {API_URL}")
        print("   Make sure the engine is running:")
        print("   cd engine && uvicorn api.app:app --port 8000")
        sys.exit(1)

    # ── 2. Single Forecast (Monthly) ──────────────────────────────────
    print("\n" + "─" * 60)
    print("📈 Single Forecast — Monthly Sales (12 months ahead)")
    print("─" * 60)

    try:
        result = client.forecast(
            data=MONTHLY_SALES,
            horizon=12,
            wave_periods=[12],
        )

        if result.forecast:
            for pt in result.forecast:
                print(f"  Period {pt.period:3d}: {pt.value:>10.2f}")

        if result.model_info:
            print(f"\n  Model:     {result.model_info.method_name}")
            print(f"  Transform: {result.model_info.transform_name}")

        if result.metrics:
            print(f"  MAD:  {result.metrics.mad:.4f}")
            print(f"  MAPE: {result.metrics.mape:.2f}%")
            print(f"  RMSE: {result.metrics.rmse:.4f}")

    except GenevaAPIError as e:
        print(f"  ❌ API Error: {e}")

    # ── 3. Forecast with Prediction Intervals ─────────────────────────
    print("\n" + "─" * 60)
    print("📊 Forecast with 95% Prediction Intervals")
    print("─" * 60)

    try:
        result = client.forecast(
            data=MONTHLY_SALES,
            horizon=12,
            wave_periods=[12],
            confidence_level=0.95,
            include=["forecast", "prediction_intervals", "metrics", "model_info"],
        )

        if result.prediction_intervals:
            print(f"  {'Period':>6}  {'Forecast':>10}  {'Lower':>10}  {'Upper':>10}  {'Width':>10}")
            print(f"  {'─' * 6}  {'─' * 10}  {'─' * 10}  {'─' * 10}  {'─' * 10}")
            for pt in result.prediction_intervals:
                width = pt.upper - pt.lower
                print(f"  {pt.period:6d}  {pt.forecast:10.2f}  {pt.lower:10.2f}  {pt.upper:10.2f}  {width:10.2f}")

        if result.prediction_interval_info:
            info = result.prediction_interval_info
            print(f"\n  Confidence: {info.confidence_level * 100:.0f}%")
            print(f"  Calibration residuals: {info.calibration_residuals}")
            if info.low_residual_warning:
                print(f"  ⚠️  {info.low_residual_warning}")

    except GenevaAPIError as e:
        print(f"  ❌ API Error: {e}")

    # ── 4. Batch Forecast ─────────────────────────────────────────────
    print("\n" + "─" * 60)
    print("📦 Batch Forecast — 3 Series")
    print("─" * 60)

    try:
        batch_result = client.batch_forecast(series=[
            {
                "id": "monthly_sales",
                "data": MONTHLY_SALES,
                "horizon": 6,
                "wave_periods": [12],
            },
            {
                "id": "weekly_visitors",
                "data": WEEKLY_VISITORS,
                "horizon": 13,
                "wave_periods": [52],
            },
            {
                "id": "short_series",
                "data": [10.0, 20.0, 15.0, 25.0, 20.0, 30.0],
                "horizon": 3,
            },
        ])

        print(f"\n  Total:      {batch_result.total_series}")
        print(f"  Successful: {batch_result.successful}")
        print(f"  Failed:     {batch_result.failed}")
        print(f"  Time:       {batch_result.elapsed_ms:.1f}ms")

        for sr in batch_result.results:
            print(f"\n  [{sr.id}]")
            if sr.status == "success" and sr.forecast and sr.forecast.forecast:
                values = [f"{p.value:.1f}" for p in sr.forecast.forecast]
                print(f"    Forecast: {', '.join(values)}")
                if sr.forecast.model_info:
                    print(f"    Model:    {sr.forecast.model_info.method_name}")
            else:
                print(f"    ❌ Error: {sr.error}")

    except GenevaAPIError as e:
        print(f"  ❌ API Error: {e}")

    # ── 5. Full Diagnostic Output ─────────────────────────────────────
    print("\n" + "─" * 60)
    print("🔬 Full Diagnostic Output (include=['all'])")
    print("─" * 60)

    try:
        result = client.forecast(
            data=MONTHLY_SALES,
            horizon=6,
            wave_periods=[12],
            include=["all"],
        )

        sections = []
        if result.forecast:
            sections.append(f"forecast ({len(result.forecast)} points)")
        if result.fitted:
            sections.append(f"fitted ({len(result.fitted)} points)")
        if result.seasonal_factors:
            sections.append(f"seasonal_factors ({len(result.seasonal_factors)} points)")
        if result.metrics:
            sections.append("metrics")
        if result.model_info:
            sections.append("model_info")
        if result.trials:
            sections.append(f"trials ({len(result.trials)} trials)")

        print(f"  Sections returned: {', '.join(sections)}")

        if result.trials:
            print(f"\n  Top {len(result.trials)} trials:")
            for trial in result.trials[:5]:
                print(
                    f"    #{trial.trial_number}: {trial.method_name} "
                    f"(transform={trial.transform_name}, "
                    f"MAPE={trial.mape:.2f}%)"
                )

    except GenevaAPIError as e:
        print(f"  ❌ API Error: {e}")

    # ── Done ──────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("✅ Quickstart complete!")
    print("=" * 60)

    client.close()


if __name__ == "__main__":
    main()
