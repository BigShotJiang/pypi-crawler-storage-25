# Changelog

All notable changes to Nexus are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.10.3] - 2026-04-01

### Added
- **PostToolUse prompt hook** for debugger enforcement — detects
  repeated test failures and enforces `/nx:debug` invocation instead
  of manual retry loops.

## [2.10.2] - 2026-04-01

### Fixed
- **Restore skill routing guardrails** — re-added the Skill Directory
  tables, Process Flow graph, Storage Tier Protocol, and Red Flags
  anti-rationalization table to the `using-nx-skills` SessionStart
  injection. These were trimmed in RDR-039 for compactness but their
  removal caused agents to stop invoking specialized skills (debugger,
  architect, etc.).

## [2.10.1] - 2026-04-01

### Fixed
- **Verification hooks now advisory-only** — removed test suite
  execution from both Stop and PreToolUse hooks. Running tests inside
  hooks caused multi-minute delays on routine operations. Both hooks
  now perform fast checks only (uncommitted changes, open beads,
  review markers) and never block.
- **PreToolUse output format** — corrected to use `hookSpecificOutput`
  with `permissionDecision` (PreToolUse protocol), not `decision`/`reason`
  (Stop protocol).
- **Bead ID extraction** — fixed BSD sed compatibility on macOS (`sed -E`
  instead of GNU-only `\+`/`\b`/`\|`).

## [2.10.0] - 2026-04-01

### Added
- **Verification config** (RDR-045) — `_DEFAULTS["verification"]` section
  in `.nexus.yml` with `on_stop`, `on_close`, `test_command`, `lint_command`,
  `test_timeout` keys. New `get_verification_config()` and
  `detect_test_command()` in `config.py` with auto-detection for 7 project
  types (Maven, Gradle, Python, Node, Rust, Make, Go).

## [2.9.2] - 2026-03-31

### Changed
- **Eradicate superpowers references** — removed all live superpowers
  delegation from nx README, preflight check, and 4 skill files.
  nx is now fully self-contained with no superpowers dependency.
- **Move WIP tutorial to branch** — `docs/tutorial/` moved to
  `wip/tutorial` branch, off main.

## [2.9.1] - 2026-03-31

### Added
- **Math-aware PDF extraction (RDR-044)** — three-backend auto-detect
  routing: Docling detects formula regions, MinerU re-extracts math-heavy
  papers with superior LaTeX output, PyMuPDF normalized as terminal fallback.
  - `nx index pdf --extractor [auto|docling|mineru]` CLI option
  - `has_formulas` boolean on all PDF chunks for downstream filtering
  - `formula_count` in extraction metadata
- **Sticky PDF extractor config** — `nx config set pdf.extractor=mineru`
  sets the default globally (`~/.config/nexus/config.yml`) or per-repo
  (`.nexus.yml`). CLI `--extractor` flag overrides config when passed.
- **`nx config set` dotted keys** — `nx config set pdf.extractor=mineru`
  now writes nested YAML config, not just credentials.
- **MinerU optional dependency** — `uv pip install 'conexus[mineru]'`
  installs `mineru[all]` for math-aware extraction. ~2-3 GB model download
  on first run.

### Fixed
- **Missing Docling transitive deps** — added `python-pptx` and
  `opencv-python-headless` to fix Docling import failures on some platforms.

## [2.8.5] - 2026-03-30

### Changed
- **Plan-enricher widened scope (RDR-043)** — reframed from audit-findings
  delivery to general bead enrichment. Execution context (file paths, code
  patterns, constraints, test commands) is now the primary purpose. Audit
  findings incorporated when available, no longer required. "Degraded mode"
  removed.
- **Review gates in plans** — strategic planner includes mandatory
  code-review-expert tasks after implementation phases.

## [2.8.4] - 2026-03-30

### Added
- **Review gates in plans** — strategic planner now includes mandatory
  code-review-expert tasks after implementation phases in every plan.
- **Bib enrichment opt-in** — `nx index pdf --enrich` flag wired through
  CLI (was documented but not implemented). Default is off.

### Fixed
- **Pagination correctness** — `store_list` uses true collection count,
  `search` footer distinguishes "may have more" from "end". Standardized
  footer format across all paged tools. 11 pagination tests added.
- **Empty `--where` values rejected** — `key=` and `key>=` raise clear
  CLI errors instead of passing empty strings to ChromaDB.

## [2.8.3] - 2026-03-30

### Changed
- **Bib enrichment default flipped to opt-in** — `nx index pdf` no longer
  queries Semantic Scholar by default. Pass `--enrich` to enable inline
  metadata lookup. Use `nx enrich <collection>` for deliberate backfill.
- **MCP tool pagination** — `search`, `store_list`, and `memory_search`
  return paged results with `offset` parameter. Standardized footer:
  `--- showing X-Y of Z. next: offset=N` / `(end)`. `store_list` uses
  true collection count. No data lost — agents page through all results.
- **Hook output optimized for AI** — SubagentStart reduced 43% (6.3K→3.6K
  chars), SessionStart reduced 55%. Same information, structured for LLM
  parsing.

### Fixed
- **sn plugin Serena hook** — clarified `jet_brains_*` tools work with any
  LSP backend (not IntelliJ-specific). Added `find_file`, `list_dir`,
  Serena memories. Full MCP-prefixed tool names. Context7 prefixes fixed.
- **`--where` empty values rejected** — `key=` and `key>=` now raise
  `BadParameter` instead of silently passing empty strings to ChromaDB.
- **`store_list` missing collection** — returns "Collection not found"
  instead of misleading "No entries".

## [2.8.2] - 2026-03-30

### Added
- **SessionStart capabilities summary** — main conversation now gets a
  compact overview of `--where` operators, `/nx:query` pipeline, `nx enrich`,
  and plan library MCP tools on every session start.

## [2.8.1] - 2026-03-30

### Fixed
- **T2 plans table migration** — existing `memory.db` files created during
  v2.8.0 before the `project` column was added now auto-migrate on open.
  `ALTER TABLE plans ADD COLUMN project` + FTS5 rebuild runs transparently.

## [2.8.0] - 2026-03-30

### Added
- **Analytical query pipeline** — `/nx:query` skill decomposes complex questions
  into multi-step plans (search → extract → summarize → compare → generate),
  dispatched via new `query-planner` and `analytical-operator` agents. Step
  outputs persist in T1 scratch for cross-dispatch reference. (RDR-042)
- **Bibliographic metadata enrichment** — `nx index pdf` queries Semantic Scholar
  for year, venue, authors, and citation count. Opt-in with `--enrich`.
  Backfill existing collections with `nx enrich <collection>`. (RDR-042)
- **Structured table detection** — PDF chunks on pages containing tables are
  tagged `chunk_type=table_page`. Filter with `--where chunk_type=table_page`.
  Page-level granularity via Docling `TableItem` detection. (RDR-042)
- **`--where` comparison operators** — `nx search --where` now supports `>=`,
  `<=`, `>`, `<`, `!=` in addition to `=`. Known numeric fields (`bib_year`,
  `bib_citation_count`, `page_count`, etc.) are auto-coerced to int. (RDR-042)
- **T2 plan library** — `plans` table with FTS5 search, project scoping, and
  MCP tools (`plan_save`, `plan_search`). Saves successful query execution
  plans for future reuse. (RDR-042)
- **Orchestrator self-correction** — failure relay protocol distinguishes
  ESCALATION sentinels (route to debugger) from incomplete output (retry up
  to 2x with augmented context). (RDR-042)
- **NDCG retrieval smoke test** — synthetic corpus + ground-truth queries in
  `tests/benchmarks/` verify the search pipeline runs end-to-end with ONNX
  MiniLM. (RDR-042)

### Fixed
- **sn plugin Serena hook** — SubagentStart hook now uses full MCP-prefixed
  tool names (`mcp__plugin_sn_serena__*`) so subagents can actually resolve
  and call Serena tools. Previously used short names that subagents couldn't
  find.

## [2.7.1] - 2026-03-28

### Added
- **nx: three-tier storage guidance for all agents** — SubagentStart hook injects
  nx MCP tool signatures (T1 scratch, T2 memory, T3 search/store) into every
  subagent. Non-nx agents (general-purpose, superpowers, etc.) can now use
  T1 scratch for inter-agent communication, read T2 project context, and query
  the T3 knowledge store.

## [2.7.0] - 2026-03-28

### Added
- **sn plugin** — new lightweight Claude Code plugin that bundles Serena and
  Context7 MCP servers with a SubagentStart hook that injects tool usage
  guidance into all subagents. Serena configured with `--context claude-code`
  (minimal tool surface) and `--project-from-cwd` (auto-detect project).
  Install independently: `/plugin install sn@nexus-plugins`.
- **nx: sequential thinking injection** — SubagentStart hook injects usage
  guidance for the sequential thinking MCP tool.

## [2.6.1] - 2026-03-27

### Fixed
- **rdr-accept planning detection** — was matching only `## Implementation Plan`
  with `### Phase` subheadings. Now scans 6 section names (Implementation Plan,
  Approach, Plan, Design, Steps, Execution) and 4 subheading types (Phase, Step,
  Stage, Part, plus numbered `###`). Default flipped from "no" to "yes" — false
  positives are cheap, false negatives skip planning on complex work.

### Docs
- Tutorial video scripts (sections 0-9), companion cheatsheet
- Automated recording pipeline: expect + asciinema + agg + ffmpeg + speed-mapping
- `make` in `docs/tutorial/vhs/` reproduces the full demo video from scratch

## [2.6.0] - 2026-03-26

### Added
- **T1 scratch inter-agent context sharing** (RDR-041) — standardized scratch
  tag vocabulary (`impl`, `checkpoint`, `failed-approach`, `hypothesis`,
  `discovery`, `decision`), sibling context SHOULD for relay-reliant agents
  with relay-over-scratch precedence rule, developer writes failed approaches
  to scratch, code reviewer checks scratch for developer struggles before
  reviewing, debugger checks scratch for predecessor findings.
- **Debugger escalation relay** includes `nx scratch` field for pre-escalation
  failed-approach entries.
- **Re-dispatch developer relay template** with structured nx store/memory
  artifact references from debugger output.
- **Escalation guard** — if developer circuit breaker fires twice for the same
  bead, escalate to human instead of infinite developer→debugger loop.

## [2.5.0] - 2026-03-25

### Added
- **Developer agent circuit breaker** (RDR-040) — after 2 consecutive test
  failures, the developer agent stops and outputs a structured ESCALATION
  report. The parent dispatches the debugger with the failure context. Counter
  tracks test runs (not root causes), resets on green or new invocation.
  Supersedes the advisory "Recommend debugger" escalation trigger.
- **Debugger escalation relay template** in development skill — parent-side
  dispatch instructions with field mapping from escalation report to debugger
  relay.
- **Developer → debugger routing** in orchestration skill — escalation edge
  in routing diagram and quick reference table.

## [2.4.2] - 2026-03-25

### Docs
- **Python 3.14 troubleshooting** — `uv tool update` reuses the existing
  environment's Python, so upgrading under 3.14 doesn't auto-switch to 3.13
  despite the `requires-python` cap. Documented `--force --python 3.13` as
  the fix. Added `head -1 $(which nx)` diagnostic.

## [2.4.1] - 2026-03-24

### Fixed
- **`--collection` flag bypass of `t3_collection_name()`** — `nx index pdf --collection knowledge` now correctly normalizes to `knowledge__knowledge`, matching search conventions. Previously created bare collections invisible to `nx search` with wrong embedding model.
- **`memory promote --collection` same bug** — bare collection names in `nx memory promote` now normalized via `t3_collection_name()`.
- **Updated `--collection` help text** — no longer says "Fully-qualified" since bare names are now accepted and auto-normalized.
- **Updated CCE post-mortem** — linked RDR-040 resolution and documented the `--collection` naming variant.

## [2.4.0] - 2026-03-24

### Added
- **`nx collection reindex <name>`** — delete and re-index a collection from source files with pre-delete safety check, per-type dispatch (code/docs/rdr/knowledge), and post-reindex verification (A4)
- **`collection_list` MCP tool** — list all T3 collections with document counts and models (B2)
- **`collection_info` MCP tool** — detailed collection metadata including index/query models (B3)
- **`collection_verify` MCP tool** — known-document retrieval health probe (B4)
- **Per-chunk progress for pdf/md indexing** — `--monitor` now shows tqdm bar during embedding, not just post-hoc metadata (A5)
- **Retrieval quality unit tests** — assert semantic rank ordering with real ONNX embeddings (A1)
- **Cross-model invariant regression test** — fails if CCE index/query models diverge (A3)

### Fixed
- **Single-chunk CCE model mismatch** — documents with only 1 chunk in CCE collections now use `contextualized_embed()` instead of falling back to `voyage-4`, which produced vectors in an incompatible space (C1)
- **Unpaginated `col.get()` in indexer** — `_prune_deleted_files`, `_prune_misclassified`, and `_run_index_frecency_only` now paginate at 300 records to handle ChromaDB Cloud's hard cap (C2/C3)
- **Mixed-model CCE batches** — partial CCE failure now re-embeds the entire document with voyage-4 for consistency, preventing mixed-space vectors (C4)
- **MCP collection cache race** — `_get_collection_names()` uses atomic tuple assignment to eliminate the window where concurrent threads could see an empty list (C5)
- **`info_cmd` unbounded `col.get()`** — now uses `limit=300` for best-effort timestamp sampling
- **`reindex_cmd` corpus metadata** — derives corpus from collection name instead of storing empty string

### Changed
- **MCP `search` default** — changed from `corpus="knowledge"` to `corpus="knowledge,code,docs"` matching CLI behavior; added `"all"` alias for all corpora including rdr (B1)
- **`collection verify --deep`** — enhanced with known-document probe, distance reporting, and `VerifyResult` dataclass (A2)

### Docs
- Updated CLI reference, architecture docs, MCP tool reference, CLAUDE.md, and nx plugin CHANGELOG for all RDR-040 changes (D1–D6)

### References
- RDR-040: CCE Post-Mortem Gap Closure & MCP Server Enhancement
- Post-mortem: `docs/rdr/post-mortem/cce-query-model-mismatch.md`
- Epic: nexus-5rn1 (16 beads, all closed)
- PR: #118

## [2.3.6] - 2026-03-23

### Fixed
- **Restore voyageai as required dependency** — the `conexus[cloud]` optional extra
  was an unnecessary workaround. Since `requires-python < 3.14` blocks the only
  incompatible Python version, voyageai always works on supported Pythons. Reverted
  to direct `import voyageai` with no guards. Removed the `cloud` extra.

## [2.3.5] - 2026-03-23

### Docs
- **Streamlined getting-started guide** — linear flow from prerequisites through
  install, verify, use, plugin, cloud. Added `nx doctor` verify step, Python 3.14
  workaround, `uv tool update` instructions, and `conexus[cloud]`/`conexus[local]`
  extras documentation.
- **Three-pass substantive critique** — fixed query model docs (CCE collections use
  voyage-context-3 for both index and query), removed "T3 cloud" mislabeling from
  CLI reference, corrected tuning YAML structure (nested subsections, not flat keys),
  fixed local-mode auto-detection docs (either key absent, not both), added missing
  `--on-locked` flag and `NX_VOYAGEAI_READ_TIMEOUT_SECONDS` env var, corrected
  minified code detection description, and replaced all `pip install` with `uv` syntax.
- **Unprefixed skill references** — corrected `/rdr-create` → `/nx:rdr-create` etc.
  across all documentation and RDR files.

### Fixed
- **`is_local_mode()` docstring** — corrected to match implementation (either key
  absent triggers local mode, not both).

## [2.3.4] - 2026-03-23

### Fixed
- **Python 3.14 compatibility** — `voyageai` uses Pydantic v1 compat layer which
  is broken on Python ≥ 3.14. Moved `voyageai` from required to optional dependency
  (`pip install conexus[cloud]`). Capped `requires-python` to `<3.14` so uv/pip
  auto-select Python 3.13. All `import voyageai` sites guarded with clear error
  messages pointing to `conexus[cloud]`.
- **Unprefixed skill references in docs** — all `/rdr-create`, `/rdr-close`, etc.
  corrected to `/nx:rdr-create`, `/nx:rdr-close` across 11 documentation files.

## [2.3.3] - 2026-03-23

### Fixed
- **Python 3.14 compatibility** (partial) — guarded `import voyageai` in `t3.py`
  but missed `retry.py` and other import sites. Superseded by 2.3.4.

## [2.3.2] - 2026-03-22

### Fixed
- **Planning chain bypass prevention** — agents can no longer skip the
  strategic-planner → plan-auditor → plan-enricher chain by creating beads
  directly or compensating when subagents fail. PROHIBITION block added to
  rdr-accept, chain mandatory for multi-phase RDRs.
- **Silent bead content corruption** — `bd update --description "..."` silently
  destroys multi-line markdown (backticks, `$variables`, nested quotes). Replaced
  with Write tool → `--body-file` pattern in plan-enricher agent and skill.
- **Dead T2 idempotency code** — removed Python comparisons against always-None
  `t2_status`; self-healing logic moved to Action section with live `memory_get`.
- **Unbound placeholders** — fixed `{id}`, `{t2_status}`, `{repo_name}`, `{type}`
  leaking from Python into agent instructions; standardized to `<ID>` notation.

### Added
- **Known Pitfalls** section in writing-nx-skills skill — documents the
  `--description` corruption bug so future agent authors use `--body-file`.

## [2.3.1] - 2026-03-22

### Fixed
- **StopFailure hook junk beads** — guarded side effects behind `CLAUDECODE` env var
  so test runs no longer create junk beads and memories via `bd`.

## [2.3.0] - 2026-03-22

### Added
- **PostCompact hook** — re-injects in-progress bead state and T1 scratch entries
  after conversation compaction. Only emits output when there is content to show.
- **StopFailure hook** — logs API failure context to beads memory for observability.
  Creates a blocker bead on rate limits. Handles null `error_details` gracefully.
- **Integration tests in release checklist** — `uv run pytest -m integration` is now
  a required pre-release step in `docs/contributing.md`.

### Fixed
- **Test isolation** — patched `get_credential` in T3/store tests to prevent
  `~/.config/nexus/config.yml` from leaking real credentials into unit tests.
- **PostCompact scratch test** — no longer false-fails on CI when `nx scratch list`
  returns no entries.

### Docs
- RDR-039 closed: all 4 phases implemented.

## [2.2.0] - 2026-03-21

### Changed
- **Plugin hooks cleanup** — removed 5 dead/redundant hook scripts
  (`mcp_health_hook.sh`, `setup.sh`, `bead_context_hook.py`,
  `permission-request-stdin.sh`, `readonly-agent-guard.sh`) and 3 hook events
  (Setup, PostToolUse, PermissionRequest). Hooks reduced from 9 to 5.
- **Orchestrator upgraded** from haiku to sonnet — routing ambiguous requests
  needs reasoning depth.
- **T2 memory dedup** — removed duplicate T2 output from `session_start()`;
  `session_start_hook.py` via `t2_prefix_scan.py` is the single source.

### Fixed
- **rdr_hook.py** — added `closed` status to `_STATUS_ORDER` (was missing,
  caused wrong reconciliation direction), terminal conflicts now warn instead
  of auto-reconciling, fixed `_update_file_status` blank-line accumulation,
  reads `.nexus.yml` for RDR path instead of hardcoding `docs/rdr`.
- **"Task tool" → "Agent tool"** — corrected 19 stale references across skills,
  commands, and relay template.

## [2.1.1] - 2026-03-15

### Fixed
- **Plugin skill references** — all 19 nx plugin files now use fully-qualified
  `/nx:skill-name` form instead of short `/skill-name` which Claude Code cannot
  resolve for plugin-namespaced skills. Affected agents, commands, hooks, skills,
  and README.

## [2.1.0] - 2026-03-15

### Added
- **Local T3 backend** (RDR-038) — zero-config semantic search using ChromaDB
  `PersistentClient` + bundled ONNX MiniLM embeddings. `pip install conexus &&
  nx index repo . && nx search "query"` works with no API keys.
- `is_local_mode()` auto-detection: activates local mode when cloud credentials
  are absent. Force with `NX_LOCAL=1` or `NX_LOCAL=0`.
- `LocalEmbeddingFunction` with two tiers: tier 0 (bundled all-MiniLM-L6-v2,
  384d) and tier 1 (fastembed bge-base-en-v1.5, 768d via `pip install conexus[local]`).
- `NX_LOCAL_CHROMA_PATH` env var to override local ChromaDB storage path
  (default: `~/.local/share/nexus/chroma`).
- `nx doctor` shows local mode health checks: path, embedding model, collection
  count, disk usage. Cloud checks skipped in local mode.
- `[local]` optional dependency group: `pip install conexus[local]` for better
  embedding quality via fastembed.
- `sqlite3.OperationalError('database is locked')` added to retryable errors
  for PersistentClient concurrent write handling.
- Indexer pipeline local mode: `embed_fn` injection in `IndexContext`, local
  embedding in code/prose/PDF indexers.
- Search reranker skipped in local mode (no Voyage AI reranker available).
- `memory promote` uses `make_t3()` — works seamlessly in both local and cloud mode.

### Changed
- `T3Database.__init__` accepts `local_mode` and `local_path` parameters
  (first branch, before cloud probe).
- `make_t3()` returns local or cloud T3Database based on `is_local_mode()`.
- `store.py` `_t3()` skips cloud credential checks in local mode.
- MAX_QUERY_RESULTS clamping and CCE embedding paths gated on `_local_mode`.

### Docs
- `getting-started.md`: local-first zero-config section before cloud setup.
- `configuration.md`: local mode config reference (NX_LOCAL, NX_LOCAL_CHROMA_PATH).
- `storage-tiers.md`: local vs cloud T3 comparison table with tier details.
- `architecture.md`: updated T3 description for local/cloud backends.
- `README.md`: updated Quick Start and tier table for zero-config local mode.
- `CLAUDE.md`: updated T3 description and source layout for `local_ef.py`.

## [2.0.0] - 2026-03-14

### Breaking Changes
- **T3 storage consolidated from 4 databases to 1** (RDR-037) — `chroma_database`
  is now the actual database name, not a base prefix. All collection prefixes
  (`code__*`, `docs__*`, `rdr__*`, `knowledge__*`) coexist in a single ChromaDB
  Cloud database.
  - `nx config init` provisions 1 database instead of 4
  - `nx doctor` checks 1 database instead of 4
  - Old four-database layout is auto-detected on startup with migration guidance
  - Set `NX_MIGRATED=1` after migrating to skip the probe
  - **Migration is non-destructive** — old databases are never modified or deleted.
    They remain in your ChromaDB Cloud dashboard until you choose to remove them.
  - Migration steps:
    1. Export with the **pre-upgrade** version: `nx store export --all`
    2. Upgrade nexus
    3. Provision single DB: `nx config init` (creates `{chroma_database}`)
    4. Re-index repos: `nx index repo .`
    5. Import stored knowledge: `nx store import`
    6. Set flag: `export NX_MIGRATED=1` (or `nx config set migrated 1`)
    7. Verify: `nx doctor`
    8. Optional: delete the 4 old databases from the ChromaDB Cloud dashboard

### Changed
- `T3Database.__init__` uses probe-first single-client connection (was four-client loop)
- `_client_for()` is now a shim returning the single client (routing removed)
- `ensure_databases()` creates 1 database (was 4)
- `OldLayoutDetected` exception raised when old `{base}_code` database still exists

## [1.12.1] - 2026-03-14

### Docs
- **README intro paragraph** — rewritten for clarity: leads with what Nexus is,
  then what it provides, then the compounding value proposition.

## [1.12.0] - 2026-03-13

### Docs
- **README rewrite** — problem-first framing centered on knowledge management
  lifecycle rather than repository indexing. Three intro paragraphs: context loss
  problem, Nexus as solution with compounding knowledge, RDR as human-AI design
  system for team alignment.
- **Three tiers, one lifecycle** — storage tier section rewritten to explain why
  each tier exists (different lifetimes, different access patterns) and how agents
  use them cooperatively. T1 consistently framed as inter-agent coordination, not
  developer scratch pad.
- **Getting Started reorganized** — local-first flow: Install → T1/T2 (no keys) →
  Claude Code plugin → T3 semantic search. Readers get value before configuring
  cloud credentials.
- **RDR documentation overhaul** — Overview, Workflow, Nexus Integration, and
  Templates all edited for readability. Reduced density, removed duplication across
  documents, flattened deep heading nesting, removed excess section dividers.
- **docs/README restructured** — Core Concepts / RDR / Plugin / Reference grouping
  with improved descriptions.
- **Cross-document consistency** — T1 terminology, Getting Started descriptions,
  nav bar headers/footers, and link targets aligned across all docs.

## [1.11.1] - 2026-03-13

### Fixed
- **rdr-accept chain orchestration** — the planning chain (strategic-planner →
  plan-auditor → plan-enricher) broke after the planner completed because agents
  relied on impossible agent-to-agent relay (subagents cannot spawn subagents).
  The accept skill now explicitly orchestrates all three sequential dispatches.
- **Agent handoff model** — replaced "Successor Enforcement" sections across all
  15 agents with "Recommended Next Step" output blocks. Agents now output structured
  handoff recommendations; the caller (skill or main conversation) dispatches the
  next agent. Removes dead code that instructed agents to use tools they don't have.
- **Template variable mismatches** — `{rdr_file_path}` and `{path}` corrected to
  `{rdr_file}` in rdr-accept command and skill
- **Stale "spawn" imperatives** — architect-planner and developer agents updated
  from "spawn X" to output-oriented language matching the new handoff model
- **enrich-plan skill** added to using-nx-skills directory (was missing from
  skill registry table)
- **Flaky test on Python 3.13** — `test_entries_6_to_8_title_only` failed in CI
  because all entries shared the same second-level timestamp, making SQLite
  ordering non-deterministic. Test now asserts on snippet/title-only counts
  rather than specific entry names.

## [1.11.0] - 2026-03-12

### Added
- **Post-accept planning workflow** (RDR-036) — `/rdr-accept` now offers an optional
  planning handoff after acceptance: auto-detects multi-phase RDRs (2+ phases defaults
  yes), dispatches `strategic-planner → plan-auditor → plan-enricher` chain to create
  and enrich execution beads at accept time rather than close time
- **plan-enricher agent** (sonnet) — terminal node in planning chain; enriches beads
  with audit findings, execution context, file paths, and codebase alignment
- **`/enrich-plan` skill and command** — invoke plan-enricher standalone or as part of
  the RDR planning chain
- **Conditional successor routing in plan-auditor** — uses T1 `rdr-planning-context`
  tag with RDR ID correlation to route to plan-enricher only in RDR planning context

### Changed
- **`/rdr-close` bead decomposition replaced with advisory** — close no longer creates
  beads; displays a read-only bead status table (if beads exist from accept-time
  planning) and lets the human decide which to close
- **strategic-planner Phase 3** renamed from "Audit and Iteration" to "Audit Handoff";
  removed aspirational "iterate based on audit feedback" instruction
- Plugin now has 15 agents (was 14) and 28 skills (was 27)

## [1.10.3] - 2026-03-12

### Fixed
- **PyPI README links** — converted all relative markdown links to absolute GitHub URLs
  so documentation links work on the PyPI project page

### Docs
- Updated RDR section in README to reflect actual usage (35+ RDRs and counting) rather
  than hypothetical projections; added concrete cross-reference example (RDR-035/023)

## [1.10.2] - 2026-03-12

### Fixed
- **Remove `tools:` frontmatter from all 14 agents** (RDR-035) — Claude Code has a
  confirmed bug where explicit `tools:` declarations in plugin-defined agents filter
  out MCP tools, rendering the MCP server non-functional for subagents. Agents now
  inherit all tools from the parent session; the PermissionRequest hook remains as
  runtime enforcement.

### Docs
- Updated `nx/README.md` and `docs/contributing.md` to document the `tools:` bug
- Added supersession note to RDR-023, post-implementation note to RDR-034
- Created and closed RDR-035

## [1.10.1] - 2026-03-11

### Fixed
- Removed `SessionEnd` hook — Claude Code cancels hooks during process teardown,
  producing a spurious "Hook cancelled" error on every exit. The T1 server stops
  automatically when the process tree dies; the hook was effectively a no-op.

## [1.10.0] - 2026-03-11

### Added
- **MCP server for agent storage operations** (RDR-034) — FastMCP server (`nx-mcp`)
  exposing 8 structured tools for direct T1/T2/T3 access by agents without Bash
  dependency. Tools: `search`, `store_put`, `store_list`, `memory_put`, `memory_get`,
  `memory_search`, `scratch`, `scratch_manage`. Thread-safe lazy singletons with
  double-checked locking for T1/T3; per-call context managers for T2. Collection
  name cache with 60s TTL and short-circuit for fully-qualified corpus names.
  Entry point: `nx-mcp = "nexus.mcp_server:main"` in pyproject.toml.
- **Plugin migration to MCP tools** — all 14 agents, shared protocols, and 9 skills
  updated from CLI syntax (`nx scratch put ...`) to MCP tool syntax
  (`mcp__plugin_nx_nexus__scratch`). Human-facing docs (`docs/`) retain CLI syntax.

### Changed
- `id` parameter renamed to `entry_id` in `scratch()` and `scratch_manage()` MCP tools
  to avoid shadowing Python builtin.

### Docs
- Architecture diagram updated with dual Human→CLI / Agent→MCP access paths.
- Storage tiers doc notes two access paths (CLI for humans, MCP for agents).
- Plugin README expanded with full MCP Servers section and permission auto-approval.
- Contributing guide notes MCP tool requirements for agent authoring.

## [1.9.1] - 2026-03-10

### Docs
- **Documentation audit for 1.9.0 features** — all user-visible features now documented:
  - `architecture.md`: module map updated with decomposed indexer modules (`code_indexer.py`,
    `prose_indexer.py`, `index_context.py`, `indexer_utils.py`, `languages.py`) and `exporter.py`
  - `configuration.md`: new `[tuning]` section documenting all `TuningConfig` parameters
  - `storage-tiers.md`: T3 export/import section with usage examples and format description
  - `repo-indexing.md`: CODE extension count corrected (52), pipeline versioning section,
    minified code handling section
  - `README.md`: store command description updated
- **Release process hardened** — `docs/contributing.md` step 2 now requires a mandatory docs
  audit against `git log` before every release, with a checklist of docs to verify. Quick
  reference table expanded to list all docs that may need updates.

## [1.9.0] - 2026-03-10

### Added
- **Hybrid search score boosting** (RDR-026) — ripgrep exact-match results boost
  vector search scores by `EXACT_MATCH_BOOST=0.15`. Pre-reranker capture of
  `rg_file_paths` and `rg_matched_lines` metadata for downstream context windowing.
  Ripgrep-only results (files not in vector top-K) kept with `RG_FLOOR_SCORE * 0.8`
  penalty. Snapshot regression tests for search quality via syrupy.
- **Context line windowing** (RDR-027 Phase 1) — `-A`/`-B`/`-C` flags now center
  on matching lines within chunks (keyword match or rg_matched_lines) rather than
  always showing from chunk start. `-C N` changed from after-only alias to
  before+after (matching grep semantics). Bridge merging joins nearby matches
  separated by ≤2 lines.
- **Syntax highlighting** (RDR-027 Phase 2) — `--bat` flag pipes results through
  `bat` with per-file batching, merged line ranges, and graceful fallback. Skipped
  when `--no-color` or `NO_COLOR` is set.
- **Compact mode** (RDR-027 Phase 3) — `--compact` flag outputs one line per result
  in `path:line:text` format (grep-compatible).
- **Query-aware vimgrep** — `--vimgrep` now reports the best-matching line within
  the chunk when a query is provided, not always the first line.
- **Unified language registry** (RDR-028) — consolidated `LANGUAGE_REGISTRY` in
  `nexus.languages` maps 44 file extensions to 31 tree-sitter AST languages.
  Single source of truth replaces scattered `AST_EXTENSIONS`, `_COMMENT_CHARS`,
  and classifier extension sets. 8 new AST languages: Clojure, Dart, Elixir,
  Erlang, Haskell, Julia, OCaml, Perl.
- **Pipeline version stamping** (RDR-029) — `PIPELINE_VERSION` constant (currently 4)
  stored in collection metadata. `--force-stale` flag on `nx index repo` re-indexes
  only collections whose stamped version is outdated. `nx doctor` reports pipeline
  version status per collection.
- **Collection export/import** (RDR-031) — `nx store export` writes collections to
  portable `.nxexp` files (JSON header + gzip-compressed msgpack stream of records
  with embeddings). `nx store import` restores without re-embedding. Supports
  `--include`/`--exclude` glob filters, `--all` for bulk export, `--remap` for
  path substitution on import, and `--collection` for rename on import. Embedding
  model mismatch is rejected to prevent vector space corruption.
- **`nx store get`** — retrieve a T3 entry by its 16-char hex document ID, with
  optional `--json` output.
- **Minified code handling** — AST chunker detects minified files (avg line length
  > 500 chars) and falls back to byte-based splitting instead of producing
  single-chunk monsters.

### Changed
- **Indexer module decomposition** (RDR-032) — `indexer.py` split into focused
  modules: `code_indexer.py` (AST chunking + context extraction), `prose_indexer.py`
  (markdown indexing), `index_context.py` (IndexContext dataclass), `indexer_utils.py`
  (shared utilities). Backward-compatible re-exports from `nexus.indexer`.
- **TuningConfig externalized** (RDR-032) — `vector_weight`, `frecency_weight`,
  `file_size_threshold`, `ripgrep_timeout`, `pdf_chunk_chars`, and other knobs
  now read from `~/.config/nexus/config.yml` `[tuning]` section. Defaults derived
  from `TuningConfig()` dataclass to prevent drift.

### Fixed
- **Reliability hardening** (RDR-030) — silent error audit across 24 catch-and-pass
  blocks. All `except` blocks now log via structlog at appropriate levels. Log output
  directed to stderr; warnings suppressed in structured search output. T2 FTS5
  title field added to index for memory search.
- **Streaming export/import** — export writes page-by-page directly to gzip stream
  instead of accumulating all records in memory. Import flushes batches as records
  are unpacked from a single file handle (eliminates TOCTOU window). msgpack
  Unpacker limited to 10 MB buffer to prevent memory exhaustion on crafted input.
- **IndexContext.voyage_key** marked `repr=False` to prevent API key leakage in
  logs and tracebacks.
- **Empty remap prefix guard** — `nx store import --remap ":foo"` now raises
  `UsageError` instead of silently matching every path.
- **Code indexer double-encode fix** — content hashing uses `source_bytes` directly
  instead of re-encoding from the already-decoded string.

### Docs
- `cli-reference.md` updated with `nx store get`, `nx store export`, `nx store import`,
  and `--force-stale` flag documentation.

### Tests
- 2209 tests (up from ~2050 in 1.8.0). New coverage for `_extract_context` (5 AST
  scenarios), `index_code_file` happy path, `index_prose_file` non-markdown path,
  exporter edge cases (empty collection, corrupt msgpack, remap validation),
  and `TuningConfig` wiring.

## [1.8.0] - 2026-03-08

### Changed
- **Language-agnostic agents** (RDR-025) — renamed 3 Java-specific agents to
  language-agnostic names: `java-developer` → `developer`, `java-debugger` →
  `debugger`, `java-architect-planner` → `architect-planner`. Agents now read
  CLAUDE.md at runtime to detect language, build system, test command, and coding
  conventions. Slash commands renamed: `/java-implement` → `/implement`,
  `/java-debug` → `/debug`, `/java-architecture` → `/architecture`.
- **Plugin registry updated** — all pipelines, predecessor/successor chains,
  naming aliases, and model summary reflect new agent names.

### Added
- **CLAUDE.md preflight check** — `/nx-preflight` now includes a section 6 that
  validates CLAUDE.md has language, build system, and test command information.
  Missing sections show `[?]` warnings (not errors).

## [1.7.1] - 2026-03-07

### Added
- **Project-local `/release` skill** — enforces the full release checklist from
  `docs/contributing.md` as an actionable step-by-step workflow. Prevents skipping
  steps like `uv tool install --reinstall` or using `gh release create` instead
  of `git tag`.

## [1.7.0] - 2026-03-07

### Added
- **Agent tool permissions** (RDR-023) — all 14 nx agents now have explicit `tools`
  frontmatter following least-privilege assignments. Each agent declares only the
  tools it needs (Read/Grep/Glob, Bash, Write/Edit, WebSearch/WebFetch, Agent).
  Sequential thinking MCP tool added to all agents uniformly.
- **PermissionRequest hook expansion** (RDR-023) — auto-approve safe non-Bash tools
  (Read, Grep, Glob, Write, Edit, WebSearch, WebFetch, Agent, sequential thinking)
  so subagents are not silently denied. Bash allowlist expanded with `uv run pytest`,
  additional `bd` subcommands, and read-only `git branch`/`git tag` forms.
- **RDR process guardrails** (RDR-024) — soft-warning pre-checks at three workflow
  points to catch implementation attempts on ungated/unaccepted RDRs:
  brainstorming-gate skill (step 6), strategic-planner relay validation (step 6),
  and bead context hook (regex RDR-NNN detection).

### Fixed
- **git branch/tag hook patterns** — restricted to read-only forms only (`git branch -a`,
  `git tag -l`). Previously, bare `branch` and `tag` matched destructive operations
  like `git branch -D` and `git tag -d`.

## [1.6.1] - 2026-03-06

### Fixed
- **PermissionRequest hook** — auto-approve all `nx *` subcommands (previously only read-only
  subcommands were approved). `nx collection delete` is explicitly denied and requires
  user confirmation. New subcommands added in future releases are approved automatically.

## [1.6.0] - 2026-03-06

### Added
- **`nx memory delete`** (RDR-022) — delete T2 memory entries by `--project`/`--title`,
  `--id`, or `--project`/`--all`. Confirmation prompt shows `project/title` and content
  preview. `--yes` bypasses prompts. `--all` requires `--project` and is mutually
  exclusive with `--title` and `--id`.
- **`nx store delete`** (RDR-022) — delete T3 knowledge entries by exact 16-char `--id`
  or by `--title` (exact metadata match, paginated to handle multi-chunk documents).
  `--collection` is required. `--yes` bypasses the `--title` confirmation prompt.
- **`nx scratch delete`** (RDR-022) — delete a T1 scratch entry by ID prefix (as shown
  by `nx scratch list`). No confirmation prompt (T1 is ephemeral). Session ownership is
  verified before deleting — entries from other sessions cannot be removed.
- `T2Database.delete()` overloaded with `id: int | None` keyword argument, matching the
  `get()` API pattern.
- `T3Database.delete_by_id()`, `find_ids_by_title()` (paginated), `batch_delete()`.
- `T1Database.delete()` with two-step session-ownership check.

### Changed
- `nx store list` now shows the full 16-char document ID (previously truncated to 12),
  enabling copy-paste into `nx store delete --id`.

## [1.5.3] - 2026-03-05

### Docs
- Corrected release notes: 1.5.2 CHANGELOG now includes RDR-020 Voyage AI timeout
  entries that were missing from the initial squash merge.

## [1.5.2] - 2026-03-05

### Added
- **Voyage AI read timeout** (RDR-020) — all `voyageai.Client` construction sites now
  receive `timeout=120.0` (configurable via `voyageai.read_timeout_seconds` in config or
  `NX_VOYAGEAI_READ_TIMEOUT_SECONDS` env var) and `max_retries=3`. Prevents indefinite
  hangs on stalled Voyage AI API calls.
- **Voyage AI transient-error retry** — `_voyage_with_retry` wraps all six Voyage AI
  call sites (CCE embed, fallback embed, standard embed, code embed, rerank) with
  exponential backoff (1 → 2 → 4 s, capped at 10 s) retrying `APIConnectionError` and
  `TryAgain` up to 3 times. Errors handled by the built-in `max_retries` tenacity layer
  (Timeout, RateLimitError, ServiceUnavailableError) are kept disjoint.

### Refactor
- **`nexus.retry` leaf module** — moved `_chroma_with_retry`, `_is_retryable_chroma_error`,
  `_voyage_with_retry`, and `_is_retryable_voyage_error` from `db/t3.py` into a new
  `retry.py` with no `nexus.*` imports. Eliminates a local-import workaround in
  `scoring.py` that was required to avoid a circular-import test-isolation bug.

## [1.5.1] - 2026-03-04

### Fixed
- **ChromaDB transient error retry** — all ChromaDB Cloud network calls in `db/t3.py`,
  `indexer.py`, and `doc_indexer.py` are now wrapped with `_chroma_with_retry` (from
  `retry.py`): exponential
  backoff (2 → 4 → 8 → 16 → 30 s, capped) retrying up to 5 times on HTTP 429/502/503/504
  and transport-level errors (`ConnectError`, `ReadTimeout`). Non-retryable errors raise
  immediately. Fixes multi-thousand-file indexing runs aborted by a single transient 504.

### Docs
- **Transient Error Resilience section** added to `docs/repo-indexing.md` documenting
  retry behaviour and link to RDR-019.
- **Pre-push release checklist** added to `docs/contributing.md` to catch missing
  `uv.lock` commits before tagging.

### Tests
- Unit and integration tests for `_is_retryable_chroma_error` and `_chroma_with_retry`.
- `test_uv_lock_version_matches_pyproject` added to `TestMarketplaceVersion` — CI now
  enforces that `pyproject.toml`, `uv.lock`, and `marketplace.json` all carry the same
  version.

## [1.5.0] - 2026-03-04

### Added
- **Auto-provision T3 databases** — `nx config init` now creates the ChromaDB Cloud tenant
  and database automatically; `nx migrate` has been removed.

### Fixed
- `chroma_tenant` is now optional in credential validation.
- Resolve real tenant UUID before admin calls; use `get_database` for existence check.

### Docs
- White-glove UX polish: help text, wizard flow, troubleshooting, plugin agents/skills,
  and RDR documentation.
- RDR-001, 002, 017, 018 closed as implemented.

### Tests
- Coverage gaps from test-validator audit closed.

## [1.4.0] - 2026-03-03

### Added
- **File lock on `index_repository`** — per-repo `fcntl.flock` prevents concurrent
  indexing of the same repository. Supports `--on-locked skip` (return immediately,
  default) and `--on-locked wait` (block until lock released).
- **`nx hooks install / uninstall / status`** — installs `post-commit`, `post-merge`,
  and `post-rewrite` git hooks that automatically trigger `nx index repo` on each
  commit/merge. Hooks use a sentinel-bounded stanza so they compose safely with
  pre-existing hook scripts.
- **Hooks reminder in `nx index repo`** — on first successful index, if no hooks are
  installed the CLI prints a one-time suggestion to run `nx hooks install`.
- **`nx doctor` hooks check** — reports hook installation status and checks the index
  log for recent errors.

### Removed
- **`nx serve` / Flask / Waitress** — the polling server and all associated code
  (`server.py`, `server_main.py`, `polling.py`, `commands/serve.py`) have been
  deleted. Git hooks replace the auto-indexing use-case. Dependencies `flask>=3.0`
  and `waitress>=3.0` removed from `pyproject.toml`.

### Docs
- `cli-reference.md`: `nx serve` section replaced with `nx hooks` section.
- `repo-indexing.md`: HEAD polling explanation replaced with git hooks explanation.
- `architecture.md`: Server module row replaced with Hooks module row.
- `configuration.md`: `server.port` / `server.headPollInterval` rows removed.
- `contributing.md`: `nx hooks install` added to development setup steps.

## [1.3.0] - 2026-03-03

### Added
- **`--force` flag** on all four `nx index` subcommands (`repo`, `pdf`, `md`, `rdr`) —
  bypasses staleness check and re-chunks/re-embeds in-place. Mutually exclusive with
  `--frecency-only` (repo) and `--dry-run` (pdf).
- **`--monitor` flag** on all four `nx index` subcommands — prints per-file progress
  lines with file name, chunk count, and elapsed time. For `pdf` and `md`, prints
  page range, title, author, and section count after indexing.
- **Auto-enable monitor in non-TTY contexts** — per-file output is now emitted
  automatically when stdout is not a TTY (piped, backgrounded, CI), without needing
  `--monitor`. The flag remains available to force output in interactive sessions.
- **tqdm progress bar** on `repo` and `rdr` subcommands — shows a file-count bar in
  interactive TTY sessions; auto-suppressed when piped or backgrounded.
- **`on_start` / `on_file` progress callbacks** on the indexer layer — `index_repository`
  and `batch_index_markdowns` accept optional callbacks for real-time progress reporting.
- **`return_metadata`** parameter on `index_pdf` and `index_markdown` — returns a dict
  with chunk count, page range, title, author, and section count instead of a plain int.
- **Proactive 12 KB chunk byte cap** (`SAFE_CHUNK_BYTES = 12_288`) — single constant in
  `chroma_quotas.py` enforced across all three chunkers:
  - `chunker.py` escape hatch fixed: single oversized lines are now truncated at the
    UTF-8 boundary instead of emitted as-is.
  - `md_chunker.py` byte cap post-pass added after semantic/naive splitting.
  - `pdf_chunker.py` byte cap post-pass added after char splitting.
  - `t3.py _write_batch` last-resort drop-and-warn for any document exceeding
    `MAX_DOCUMENT_BYTES` (16 384) before upsert.

### Fixed
- **AST chunk line ranges** (RDR-016) — line numbers now derived from
  `node.start_char_idx` / `node.end_char_idx` instead of a hardcoded formula that
  produced systematically wrong ranges.
- **`_run_index` missing registry entry** — returns `{}` instead of raising when the
  path is not registered, preventing unhandled exceptions on first-run edge cases.

### Changed
- **Indexer helpers** return `int` chunk count instead of `bool` — callers get
  actionable count rather than a success/failure flag.

### Docs
- `cli-reference.md` updated with full `nx index` flag coverage: `--force`, `--monitor`
  (with auto-enable note), `--collection`, `--dry-run`, and `--frecency-only` mutual
  exclusion.

## [1.2.0] - 2026-03-03

### Added
- **`ContentClass.SKIP`** — fourth classification category silently ignores known-noise
  files (config, markup, shader, lock) instead of emitting them into `docs__` collections.
  18 extensions skipped: `.xml`, `.json`, `.yml`, `.yaml`, `.toml`, `.properties`,
  `.ini`, `.cfg`, `.conf`, `.gradle`, `.html`, `.htm`, `.css`, `.svg`, `.cmd`, `.bat`,
  `.ps1`, `.lock`.
- **Expanded code extensions** — 9 new extensions classified as CODE: `.proto`, `.cl`,
  `.comp`, `.frag`, `.vert`, `.metal`, `.glsl`, `.wgsl`, `.hlsl` (Protobuf and GPU
  shaders now indexed into `code__` with `voyage-code-3`).
- **Shebang detection** — extensionless files are classified as CODE when their first two
  bytes are `#!`, SKIP otherwise (catches `Makefile`, `LICENSE`, etc. correctly).
- **Context prefix injection (embed-only)** — each code chunk's embedding text is
  prefixed with `// File: X  Class: Y  Method: Z  Lines: N–M`. The raw chunk text is
  stored in ChromaDB unchanged; only the Voyage AI embedding call sees the prefix.
  Improves recall for algorithm-level queries in domain-specific codebases.
- **14-language class/method extraction** via tree-sitter `DEFINITION_TYPES` mapping
  (Python, Java, Go, TypeScript, Rust, C, C++, C#, Ruby, PHP, Swift, Kotlin, Scala).
  Used to populate the `class_name` and `method_name` fields in the context prefix.
- **AST language expansion** — `AST_EXTENSIONS` expanded from 16 to 28 mappings across
  19 parsers: Kotlin, Scala, Swift, PHP, Lua, Objective-C now receive AST-aware chunking.
- **`preserve_code_blocks`** — `SemanticMarkdownChunker` now defaults to
  `preserve_code_blocks=True`, preventing fenced code blocks from being split mid-content.
- **`_STRUCTURAL_TOKEN_TYPES` blocklist** — `paragraph_open`, `list_item_open`,
  `tr_open`, and similar structural markdown-it-py tokens are filtered so content
  appears exactly once per chunk (eliminates duplication from open/close token pairs).

### Changed
- **Chunk metadata** now includes `class_name`, `method_name`, and `embedding_model`
  fields on all code chunks.

### Removed
- **`--chunk-size` and `--no-chunk-warning`** flags removed from `nx index repo` —
  chunk size is not user-configurable; these flags were dead after the AST-first pipeline.

## [1.1.1] - 2026-03-02

### Fixed
- **`nx doctor` server check** — optional Nexus server now shows `✓` with status in
  detail string instead of `✗` with a Fix: hint, preventing false failures in
  preflight scripts that check exit code.

### Changed
- **Release process docs** — added explicit `uv sync` step and `uv.lock` to the
  `git add` list so lock file is never missed in a release commit.

### Docs
- RDR skill docs: `rdr-close` pre-check aligned with actual command behaviour
  (`"accepted"` not `"final"`); agent and skill counts corrected after PM removal.

## [1.1.0] - 2026-03-02

### Removed
- **`nx pm` command layer** — `nx pm new/status/close/list/archive/restore` commands
  removed. T2 memory (`nx memory`) serves this purpose directly with less overhead.
- **Mixedbread integration** — `--mxbai` search flag and `fetch_mxbai_results()` removed.
  Voyage AI via ChromaDB Cloud covers all semantic search needs.

### Added
- **`bd` and `uv` checks in `nx doctor`** — both reported as optional (informational only,
  no exit 1); `bd` includes install URL when absent.

### Fixed
- **`chroma` CLI no longer required on PATH** — `start_t1_server()` now locates the
  `chroma` entry-point relative to `sys.executable`, so it is always found when
  `conexus` is installed via `uv tool install` or `uv sync`. No separate install step.

## [1.0.0] - 2026-03-01

First stable release. Promoted from rc10 after live validation. No functional changes
from rc10 — this entry marks the API, CLI, and plugin contract as stable.

### Changed
- `Development Status` classifier promoted from `4 - Beta` to `5 - Production/Stable`.

## [1.0.0rc10] - 2026-03-01

### Changed
- Version bump to rc10 for release candidate validation prior to 1.0.0 final.
- Polish pass: CHANGELOG entries for rc7/rc8/rc9, hook script package name fix
  (conexus not nexus), skill count corrected to 28, serena-code-nav added to
  plugin README, free tier callout for ChromaDB and Voyage AI.

## [1.0.0rc9] - 2026-03-01

### Added
- **Storage tier awareness for agents**: SubagentStart hook injects live T1 scratch entries
  into every spawned agent's context — agents see what siblings and parent agents already
  discovered this session without duplicating work.
- **Storage Tier Protocol** in `using-nx-skills` SKILL.md: T3→T2→T1 read-widest-first
  table and T1→persist→knowledge-tidy write path, giving all agents a clear data discipline.

### Fixed
- **T2 FTS5 search crash on hyphenated queries**: `nx memory search "foo-bar"` raised
  `sqlite3.OperationalError: no such column: bar` — FTS5 was interpreting hyphens as column
  filter separators. Added `_sanitize_fts5()` helper that quotes special-character tokens
  before `MATCH`. Trailing `*` prefix wildcard preserved. Applies to `search()`,
  `search_glob()`, and `search_by_tag()`.

## [1.0.0rc8] - 2026-03-01

### Added
- **T1 ChromaDB HTTP server** (RDR-010): replaced `EphemeralClient` with a per-session
  `chroma run` subprocess. All agents spawned from the same Claude Code window share one
  T1 scratch namespace via PPID chain propagation — cross-process `nx scratch` reads and
  writes work correctly across separate shell invocations.
- **`serena-code-nav` skill**: navigate code by symbol — find definitions, all callers,
  type hierarchies, and safe renames without reading whole files.
- **`nx hook session-start` / `session-end`** (RDR-008): nx workflow integration hooks
  for session lifecycle management; T1 server is started on session-start and stopped on
  session-end.
- **`using-nx-skills` skill polish**: full 29-skill directory table with 5 categories,
  Announce step in process flow, 12 red flags (up from 7), `brainstorming-gate` replaces
  `verification-before-completion` in Skill Priority. Registry trigger conditions sharpened
  for knowledge-tidier, orchestrator, and substantive-critic. SessionStart hook matcher
  tightened to `startup|resume|clear|compact`.

### Removed
- **`--agentic` and `--answer` flags** removed from `nx search` (RDR-009): both modes
  required Anthropic API key and added latency for marginal benefit. Answer synthesis and
  agentic refinement are now agent responsibilities via the plugin skill suite.

### Fixed
- **T1 server startup**: removed `--log-level ERROR` from `chroma run` invocation — flag
  was dropped in chroma 1.x and silently caused every T1 start to exit code 2, falling
  back to isolated per-process EphemeralClient.
- **Session file keyed to grandparent PID**: `hooks.py` now calls `_ppid_of(os.getppid())`
  to reach the stable Claude Code PID rather than the transient shell subprocess that dies
  immediately after writing the session file.
- **T1 SESSIONS_DIR test isolation**: added `autouse` pytest fixture redirecting
  `SESSIONS_DIR` to `tmp_path`, preventing tests from discovering a live server's session
  records.

## [1.0.0rc7] - 2026-02-28

### Added
- **File-size scoring penalty for code search** (RDR-006): chunks from large files are
  down-ranked proportionally — `score *= min(1.0, 30 / chunk_count)`. Applied unconditionally
  to all `code__` results regardless of `--hybrid`. Files ≤ 30 chunks are unaffected.
- `nx search --max-file-chunks N`: pre-filters code results to files with at most N chunks
  via a ChromaDB `chunk_count $lte` where filter. Combines with `--where` using `$and`.
- **T2 multi-namespace prefix scan** (RDR-007): SubagentStart hook surfaces all
  `{repo}*` T2 namespaces (not just the bare project namespace) with a cap algorithm:
  5 entries with snippet + 3 title-only + remainder as count per namespace; 15-entry
  cross-namespace hard cap.
- `nx index repo --chunk-size N`: configurable lines-per-chunk for code files
  (default 150, minimum 1).
- `nx index repo --no-chunk-warning`: suppress the large-file pre-scan warning.
- **Large-file pre-scan warning**: detects code files exceeding 30× chunk size before
  indexing and suggests `--chunk-size 80`; adaptive recommendation when chunk size is
  already set.

## [1.0.0rc6] - 2026-02-28

### Fixed
- **CCE query model mismatch** (P0, affected rc1–rc5): `docs__`, `knowledge__`, and `rdr__`
  collections were indexed with `voyage-context-3` (CCE) but queried with `voyage-4`.
  These two models produce vectors in incompatible geometric spaces (cosine similarity ≈ 0.05
  — effectively random noise). All three collection types were returning semantically
  meaningless results since rc1. `code__` collections were unaffected.
  Fix: `corpus.py` returns `voyage-context-3` for CCE collections; `T3Database.search()`
  bypasses the ChromaDB `VoyageAIEmbeddingFunction` for CCE collections and calls
  `contextualized_embed([[query]], input_type="query")` directly. `T3Database.put()`
  likewise uses `contextualized_embed` with `input_type="document"` so single entries
  stored via `nx store put` land in the same CCE vector space as indexed chunks.
  **All CCE-indexed collections (`docs__*`, `knowledge__*`, `rdr__*`) must be re-indexed
  after upgrading from rc1–rc5.**

## [1.0.0rc5] - 2026-02-28

### Added
- **Four-store T3 architecture** (RDR-004): T3 now routes collections to four dedicated
  ChromaDB Cloud databases (`{base}_code`, `{base}_docs`, `{base}_rdr`, `{base}_knowledge`),
  one per content type. All routing is internal to `T3Database`; no CLI commands change.
- `nx migrate t3`: new command that copies collections from an old single-database T3 store
  to the new four-store layout. Idempotent; copies embeddings verbatim (no re-embedding).
- `nx doctor` now checks connectivity to all four T3 databases when credentials are present.

### Fixed
- Eliminated spurious per-corpus warning noise during `nx search`: warnings now fire once per unmatched corpus term across all collections, not once per internal resolver call

## [1.0.0rc4] - 2026-02-27

### Added
- `/rdr-accept` slash command with gate-result verification and T2 status synchronization
- `rdr-accept` skill: accepts gated RDRs, updates T2 and file frontmatter atomically (RDR-002)
- `-v`/`--verbose` flag for `nx` CLI: enables debug logging for network calls and index operations
- RDR indexing status shown in `nx index repo` output (count of RDRs indexed)
- MCP sequential-thinking server (`.mcp.json`): replaces `nx thought` for compaction-resilient reasoning chains

### Changed
- `nx thought` session isolation now uses Claude session ID instead of `getsid(0)` (RDR-002)
- SessionStart hook: T2 session records synchronized on startup (RDR-002)
- Sequential-thinking skill updated to use `mcp__sequential-thinking__sequentialthinking` instead of `nx thought add`

### Fixed
- `rdr-gate`: strip fenced code blocks before extracting section headings (false negatives on structured RDRs)
- `rdr-list` and all RDR commands: handle `RDR-NNN` naming convention; single-pass Python heredoc
- `hooks.json` format: wrap in `{hooks:{}}` with matcher/hooks nesting (plugin hook discovery was silently failing)
- Empty strings filtered from embedding batches before Voyage AI calls (prevented API errors on sparse content)
- Suppressed `llama_index` pydantic `validate_default` warning and `httpx`/`httpcore` wire-trace noise in `-v` mode
- structlog level in tests follows `pytest --log-level` (default: WARNING); debug logs surface on failure
- `rdr-accept` skill: description, relay template, PRODUCE section, and `nx scratch` reference now conform to plugin structure tests

## [1.0.0rc3] - 2026-02-26

## [1.0.0-rc2] - 2026-02-26

### Added
- Six RDR slash commands with live context injection (`/rdr-create`, `/rdr-list`, `/rdr-show`, `/rdr-research`, `/rdr-gate`, `/rdr-close`)
  - Each command pre-fetches project state (RDR dir, existing IDs, T2 metadata, active beads, git branch) before invoking the corresponding skill
  - Mirrors the context-injection pattern used by agent commands (`/review-code`, `/create-plan`, etc.)
- Plugin test suite: 752 unit + structural tests covering install simulation, `$CLAUDE_PLUGIN_ROOT` reference integrity, markdown link resolution, hook script presence, and marketplace version consistency
- E2E debug-load scenario (scenario 00): validates plugin load diagnostics, hook script execution, and component discovery via Claude `-p` mode without a live interactive session
- E2E test sandbox now includes locally-cached superpowers plugin alongside nx, enabling cross-plugin skill validation
- E2E isolation guard: verifies `nx@nexus-plugins` loads from dev repo, not the installed v1 cache

### Changed
- RDR skills now read the RDR directory from `.nexus.yml` `indexing.rdr_paths[0]` (default: `docs/rdr`) instead of hardcoding the path — consistent with the nx repo indexer config
- `registry.yaml` RDR skill entries updated with `command_file` references linking skills to their context-injecting command counterparts

### Fixed
- Marketplace version corrected from `1.0.0-rc1` to `1.0.0-rc2` (plugin structure test caught mismatch)
- E2E test harness: Python 3.14 incompatibility with chromadb/pydantic resolved by pinning install to Python 3.12

## [1.0.0-rc1] - 2026-02-25

### Added
- `nx thought` command group: session-scoped sequential thinking chains backed by T2 SQLite
  - `nx thought add CONTENT` — append thought, return full accumulated chain + MCP-equivalent metadata
  - `nx thought show` / `close` / `list` — chain lifecycle management
  - Chains scoped per session via `os.getsid(0)`, expire after 24 hours
  - Semantic equivalence with sequential-thinking MCP server: `thoughtHistoryLength`, `branches[]`, `nextThoughtNeeded`, `totalThoughts` auto-adjustment
  - Compaction-resilient: state stored externally in T2, not in Claude's context window
- `nx:sequential-thinking` skill: replaces external MCP dependency; uses `nx thought add` for compaction-resilient chains
- `/nx-preflight` slash command: checks all plugin dependencies (nx CLI, nx doctor, bd, superpowers) with PASS/FAIL per check
- Plugin prerequisites section in `nx/README.md` with dependency table and install commands
- Smart repository indexing: code routed to `code__` collections, prose to `docs__`, PDFs to `docs__`
- 12-language AST chunking via tree-sitter (Python, JS, TS, Java, Go, Rust, C, C++, Ruby, C#, Bash, TSX)
- Semantic markdown chunking via markdown-it-py with section-boundary awareness
- RDR (Research-Design-Review) document indexing into dedicated `rdr__` collections
- `nx index rdr` command for manual RDR indexing
- Frecency scoring: git commit history decay weighting for hybrid search ranking
- `--frecency-only` reindex flag: update scores without re-embedding
- Hybrid search: semantic + ripgrep keyword scoring with `--hybrid` flag
- Agentic search mode: multi-step Haiku query refinement with `--agentic` flag
- Answer synthesis mode: cited answers via Haiku with `--answer`/`-a` flag
- Reranking via Voyage AI `rerank-2.5` with automatic fallback
- Path-scoped search with `[path]` positional argument
- `--where` filter support for metadata queries
- `-A`/`-B`/`-C` context lines flags for `nx search`
- `--vimgrep` and `--files` output formats
- `nx pm` full lifecycle: init, status, resume, search, archive, restore
- `nx store list` subcommand
- `nx collection verify --deep` deep verification
- Background server HEAD polling for auto-reindex on commit
- Claude Code plugin (`nx/`): 15 agents, 26 skills, session hooks, slash commands
- RDR workflow skills: rdr-create, rdr-list, rdr-show, rdr-research, rdr-gate, rdr-close
- E2E test suite requiring no API keys (1258 tests)
- Integration test suite with real API keys (`-m integration`)

### Changed
- `sequential-thinking` skill now uses `nx thought add` as its tool-call mechanism (compaction-resilient by design)
- All agents previously using `mcp__sequential-thinking__sequentialthinking` updated to use `nx:sequential-thinking` skill
- All 11 agents with sequential-thinking now have domain-specific thought patterns, When to Use, and control reminders
- `nx doctor` improved: Python version check, inline credential fix hints, non-fatal server check
- CLI help text audited and aligned with `docs/cli-reference.md`; 15+ mismatches corrected
- Renamed `nx index code` → `nx index repo`
- Collection names use `__` separator (never `:`)
- Session ID scoped by `os.getsid(0)` (terminal group leader PID) for worktree isolation
- Stable collection names across git worktrees via `git rev-parse --git-common-dir`
- Embedding models: `voyage-code-3` for code indexing, `voyage-context-3` (CCE) for docs/knowledge, `voyage-4` for all queries
- T1 session architecture: shared EphemeralClient store + `getsid(0)` anchor
- Plugin discovery: `.claude-plugin/marketplace.json` at repo root (replaces `nx/.claude-plugin/plugin.json`)
- `nx pm` namespace collapsed; session hooks simplified
- Plugin slash commands: `/plan` → `/create-plan`, `/code-review` → `/review-code`

### Fixed
- CCE fallback metadata bug
- Search round-robin interleaving
- Collection name collision on overflow
- Registry resilience under concurrent access
- Credential TOCTOU race condition
- `nx serve stop` dead code removed
- Indexer ignorePatterns filtering
- Upsert idempotency in doc pipeline
- T1/T2 thread-safe reads

### Removed
- `nx install` / `nx uninstall` legacy commands
- `nx pm migrate` command
- Homebrew tap formula (superseded by `uv tool install`)
- `nx/.claude-plugin/` legacy plugin discovery directory

## [0.4.0] - 2026-02-24

### Added
- nx plugin v0.4.0: brainstorming-gate, verification-before-completion, receiving-code-review, using-nx-skills, dispatching-parallel-agents, writing-nx-skills skills
- Graphviz flowcharts in decision-heavy skills
- REQUIRED SUB-SKILL cross-reference markers
- Companion reference.md for nexus skill
- SessionStart hook for using-nx-skills injection
- PostToolUse hook with bd create matcher

### Changed
- All skill descriptions rewritten to CSO "Use when [condition]" pattern
- Relay templates deduplicated: hybrid cross-reference to RELAY_TEMPLATE.md
- Agent-delegating commands simplified with pre-filled relay parts
- Nexus skill split into quick-ref SKILL.md + detailed reference.md

### Fixed
- PostToolUse hook performance: now fires only on bd create, not every tool use
- Removed non-standard frontmatter fields from all skills

## [0.3.2] - 2026-02-22

### Added
- E2E tests for indexer pipeline and HEAD-polling logic

### Fixed
- `nx serve stop` dead code path

## [0.3.1] - 2026-02-22

### Added
- `nx store list` subcommand
- Integration test improvements: knowledge corpus scoping

### Changed
- README full readability pass: clearer setup path, optional vs required deps

## [0.3.0] - 2026-02-22

### Added
- Voyage AI CCE (`voyage-context-3`) for docs and knowledge collections at index time
- Ripgrep hybrid search: `rg` cache wired to `--hybrid` retrieval
- `--content` flag and `[path]` path-scoping for `nx search`
- `--where` metadata filter, `-A`/`-B`/`-C` context flags, `--reverse`, `-m` alias
- P0 regression test suite
- T3 factory extraction (`make_t3()`) with `_client`/`_ef_override` injection for tests
- `nx pm promote` and `NX_ANSWER` env override
- `nx collection verify --deep` and info enhancements
- Frecency-only reindex flag

### Changed
- Removed pdfplumber in favour of pymupdf4llm
- `search_engine.py` refactored into focused modules (`scoring.py`, `search_engine.py`, `answer.py`, `types.py`, `errors.py`)
- structlog migration

### Fixed
- 10 P0 bugs, 10 P1 bugs, 10 P2 bugs, 5 P3 observations
- CCE fallback metadata bug; `batch_size` dead parameter removed
- `serve` status/stop lifecycle, collection collision, registry resilience
- Credential TOCTOU, env override error handling
- T1 session architecture (getsid anchor, thread-safe reads)

## [0.2.0] - 2026-02-21

### Added
- `nx config` command with credential management and `config init` wizard
- Integration test suite (requires real API keys)
- E2E test suite (no API keys, 505 tests at release)
- T1 session architecture overhaul: shared EphemeralClient + getsid(0) anchor
- Scratch tier fix for CLI use outside Claude Code

### Changed
- Full README rewrite: installation, quickstart, command reference, architecture

### Fixed
- Scratch tier session isolation
- 5-stream global code review: 15 critical/significant fixes (mxbai chunk ID, security, resilience)

## [0.1.0] - 2026-02-21

### Added
- Project scaffold: `src/nexus/` package, `nx` CLI entry point via Click
- T1: `chromadb.EphemeralClient` + ONNX MiniLM, session-scoped scratch (`nx scratch`)
- T2: SQLite + FTS5 WAL, per-project persistent memory (`nx memory`)
- T3: `chromadb.CloudClient` + Voyage AI, permanent knowledge store (`nx store`, `nx search`)
- `nx index repo` (originally `nx index code`): git-aware code indexing with tree-sitter AST
- `nx serve`: Flask/Waitress background daemon with HEAD polling for auto-reindex
- `nx pm`: project management lifecycle (init, status, resume, search, archive, restore)
- `nx doctor`: prerequisite health check
- Claude Code plugin (`nx/`): initial agents, skills, hooks, registry
- Config system: 4-level precedence (defaults → global → per-repo → env vars)
- Hybrid search: semantic + ripgrep keyword scoring
- Answer synthesis: Haiku with cited `<cite i="N">` references
- Agentic search: multi-step Haiku query refinement
- Phase 1–8 implementations covering all CLI surface

[Unreleased]: https://github.com/Hellblazer/nexus/compare/v1.12.0...HEAD
[1.12.0]: https://github.com/Hellblazer/nexus/compare/v1.11.1...v1.12.0
[1.11.1]: https://github.com/Hellblazer/nexus/compare/v1.11.0...v1.11.1
[1.11.0]: https://github.com/Hellblazer/nexus/compare/v1.10.3...v1.11.0
[1.10.3]: https://github.com/Hellblazer/nexus/compare/v1.10.2...v1.10.3
[1.10.2]: https://github.com/Hellblazer/nexus/compare/v1.10.1...v1.10.2
[1.10.1]: https://github.com/Hellblazer/nexus/compare/v1.10.0...v1.10.1
[1.10.0]: https://github.com/Hellblazer/nexus/compare/v1.9.1...v1.10.0
[1.9.1]: https://github.com/Hellblazer/nexus/compare/v1.9.0...v1.9.1
[1.9.0]: https://github.com/Hellblazer/nexus/compare/v1.8.0...v1.9.0
[1.0.0]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc10...v1.0.0
[1.0.0rc10]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc9...v1.0.0rc10
[1.0.0rc10]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc9...v1.0.0rc10
[1.0.0rc9]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc8...v1.0.0rc9
[1.0.0rc8]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc7...v1.0.0rc8
[1.0.0rc7]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc6...v1.0.0rc7
[1.0.0rc6]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc5...v1.0.0rc6
[1.0.0rc5]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc4...v1.0.0rc5
[1.0.0rc4]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc3...v1.0.0rc4
[1.0.0rc3]: https://github.com/Hellblazer/nexus/compare/v1.0.0rc2...v1.0.0rc3
[1.0.0rc2]: https://github.com/Hellblazer/nexus/compare/v1.0.0-rc1...v1.0.0rc2
[1.0.0-rc1]: https://github.com/Hellblazer/nexus/compare/v0.4.0...v1.0.0-rc1
[0.4.0]: https://github.com/Hellblazer/nexus/compare/v0.3.2...v0.4.0
[0.3.2]: https://github.com/Hellblazer/nexus/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/Hellblazer/nexus/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/Hellblazer/nexus/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/Hellblazer/nexus/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/Hellblazer/nexus/releases/tag/v0.1.0
