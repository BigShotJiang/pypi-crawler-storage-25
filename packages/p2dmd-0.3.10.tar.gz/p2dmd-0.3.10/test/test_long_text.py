import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.p2dmd import replace_all, split_code

b = '''
```
fvewfv
```
nknknlnkj
```
kjbkjbk
'''
print(b.split('```'))

a = '''
'''

print(len(a))

text = replace_all(a, r"(```[\D\d\s]+?```)", split_code)
print(text)
