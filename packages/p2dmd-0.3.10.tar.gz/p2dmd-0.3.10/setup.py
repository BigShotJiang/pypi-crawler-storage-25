from pathlib import Path
from setuptools import setup, find_packages

setup(
    name="p2dmd",
    version="0.3.10",
    description="p2dmd is a Markdown to Telegram-specific-markdown converter.",
    long_description=Path("README.md").open(encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages("src"),
    package_dir={"": "src"},
    py_modules=["p2dmd", "latex2unicode"],
)
