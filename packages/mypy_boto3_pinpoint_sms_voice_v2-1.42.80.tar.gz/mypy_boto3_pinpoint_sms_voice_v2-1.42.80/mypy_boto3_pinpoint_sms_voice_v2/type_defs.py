"""
Type annotations for pinpoint-sms-voice-v2 service type definitions.

[Documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_pinpoint_sms_voice_v2/type_defs/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from mypy_boto3_pinpoint_sms_voice_v2.type_defs import AccountAttributeTypeDef

    data: AccountAttributeTypeDef = ...
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import IO, Any, Union

from botocore.response import StreamingBody

from .literals import (
    AccountAttributeNameType,
    AccountLimitNameType,
    AttachmentStatusType,
    CarrierStatusType,
    ConfigurationSetFilterNameType,
    CountryLaunchStatusType,
    DestinationCountryParameterKeyType,
    EventTypeType,
    FieldRequirementType,
    FieldTypeType,
    KeywordActionType,
    LanguageCodeType,
    MessageFeedbackStatusType,
    MessageTypeType,
    NotifyConfigurationFilterNameType,
    NotifyConfigurationStatusType,
    NotifyConfigurationTierType,
    NotifyTemplateFilterNameType,
    NotifyTemplateStatusType,
    NumberCapabilityType,
    NumberStatusType,
    NumberTypeType,
    OwnerType,
    PhoneNumberFilterNameType,
    PhoneNumberTypeType,
    PoolFilterNameType,
    PoolOriginationIdentitiesFilterNameType,
    PoolStatusType,
    ProtectConfigurationFilterNameType,
    ProtectConfigurationRuleOverrideActionType,
    ProtectConfigurationRuleSetNumberOverrideFilterNameType,
    ProtectStatusType,
    RcsAgentFilterNameType,
    RcsAgentStatusType,
    RegistrationAssociationBehaviorType,
    RegistrationAssociationFilterNameType,
    RegistrationDisassociationBehaviorType,
    RegistrationFilterNameType,
    RegistrationStatusType,
    RegistrationTypeFilterNameType,
    RegistrationVersionStatusType,
    RequestableNumberTypeType,
    SenderIdFilterNameType,
    SpendLimitNameType,
    TemplateVariableSourceType,
    TemplateVariableTypeType,
    TestingAgentStatusType,
    TierUpgradeStatusType,
    VerificationChannelType,
    VerificationStatusType,
    VerifiedDestinationNumberFilterNameType,
    VoiceIdType,
    VoiceMessageBodyTextTypeType,
)

if sys.version_info >= (3, 12):
    from typing import Literal, NotRequired, TypedDict
else:
    from typing_extensions import Literal, NotRequired, TypedDict


__all__ = (
    "AccountAttributeTypeDef",
    "AccountLimitTypeDef",
    "AssociateOriginationIdentityRequestTypeDef",
    "AssociateOriginationIdentityResultTypeDef",
    "AssociateProtectConfigurationRequestTypeDef",
    "AssociateProtectConfigurationResultTypeDef",
    "BlobTypeDef",
    "CarrierLookupRequestTypeDef",
    "CarrierLookupResultTypeDef",
    "CarrierStatusInformationTypeDef",
    "CloudWatchLogsDestinationTypeDef",
    "ConfigurationSetFilterTypeDef",
    "ConfigurationSetInformationTypeDef",
    "CountryLaunchStatusFilterTypeDef",
    "CountryLaunchStatusInformationTypeDef",
    "CreateConfigurationSetRequestTypeDef",
    "CreateConfigurationSetResultTypeDef",
    "CreateEventDestinationRequestTypeDef",
    "CreateEventDestinationResultTypeDef",
    "CreateNotifyConfigurationRequestTypeDef",
    "CreateNotifyConfigurationResultTypeDef",
    "CreateOptOutListRequestTypeDef",
    "CreateOptOutListResultTypeDef",
    "CreatePoolRequestTypeDef",
    "CreatePoolResultTypeDef",
    "CreateProtectConfigurationRequestTypeDef",
    "CreateProtectConfigurationResultTypeDef",
    "CreateRcsAgentRequestTypeDef",
    "CreateRcsAgentResultTypeDef",
    "CreateRegistrationAssociationRequestTypeDef",
    "CreateRegistrationAssociationResultTypeDef",
    "CreateRegistrationAttachmentRequestTypeDef",
    "CreateRegistrationAttachmentResultTypeDef",
    "CreateRegistrationRequestTypeDef",
    "CreateRegistrationResultTypeDef",
    "CreateRegistrationVersionRequestTypeDef",
    "CreateRegistrationVersionResultTypeDef",
    "CreateVerifiedDestinationNumberRequestTypeDef",
    "CreateVerifiedDestinationNumberResultTypeDef",
    "DeleteAccountDefaultProtectConfigurationResultTypeDef",
    "DeleteConfigurationSetRequestTypeDef",
    "DeleteConfigurationSetResultTypeDef",
    "DeleteDefaultMessageTypeRequestTypeDef",
    "DeleteDefaultMessageTypeResultTypeDef",
    "DeleteDefaultSenderIdRequestTypeDef",
    "DeleteDefaultSenderIdResultTypeDef",
    "DeleteEventDestinationRequestTypeDef",
    "DeleteEventDestinationResultTypeDef",
    "DeleteKeywordRequestTypeDef",
    "DeleteKeywordResultTypeDef",
    "DeleteMediaMessageSpendLimitOverrideResultTypeDef",
    "DeleteNotifyConfigurationRequestTypeDef",
    "DeleteNotifyConfigurationResultTypeDef",
    "DeleteNotifyMessageSpendLimitOverrideResultTypeDef",
    "DeleteOptOutListRequestTypeDef",
    "DeleteOptOutListResultTypeDef",
    "DeleteOptedOutNumberRequestTypeDef",
    "DeleteOptedOutNumberResultTypeDef",
    "DeletePoolRequestTypeDef",
    "DeletePoolResultTypeDef",
    "DeleteProtectConfigurationRequestTypeDef",
    "DeleteProtectConfigurationResultTypeDef",
    "DeleteProtectConfigurationRuleSetNumberOverrideRequestTypeDef",
    "DeleteProtectConfigurationRuleSetNumberOverrideResultTypeDef",
    "DeleteRcsAgentRequestTypeDef",
    "DeleteRcsAgentResultTypeDef",
    "DeleteRegistrationAttachmentRequestTypeDef",
    "DeleteRegistrationAttachmentResultTypeDef",
    "DeleteRegistrationFieldValueRequestTypeDef",
    "DeleteRegistrationFieldValueResultTypeDef",
    "DeleteRegistrationRequestTypeDef",
    "DeleteRegistrationResultTypeDef",
    "DeleteResourcePolicyRequestTypeDef",
    "DeleteResourcePolicyResultTypeDef",
    "DeleteTextMessageSpendLimitOverrideResultTypeDef",
    "DeleteVerifiedDestinationNumberRequestTypeDef",
    "DeleteVerifiedDestinationNumberResultTypeDef",
    "DeleteVoiceMessageSpendLimitOverrideResultTypeDef",
    "DescribeAccountAttributesRequestPaginateTypeDef",
    "DescribeAccountAttributesRequestTypeDef",
    "DescribeAccountAttributesResultTypeDef",
    "DescribeAccountLimitsRequestPaginateTypeDef",
    "DescribeAccountLimitsRequestTypeDef",
    "DescribeAccountLimitsResultTypeDef",
    "DescribeConfigurationSetsRequestPaginateTypeDef",
    "DescribeConfigurationSetsRequestTypeDef",
    "DescribeConfigurationSetsResultTypeDef",
    "DescribeKeywordsRequestPaginateTypeDef",
    "DescribeKeywordsRequestTypeDef",
    "DescribeKeywordsResultTypeDef",
    "DescribeNotifyConfigurationsRequestPaginateTypeDef",
    "DescribeNotifyConfigurationsRequestTypeDef",
    "DescribeNotifyConfigurationsResultTypeDef",
    "DescribeNotifyTemplatesRequestPaginateTypeDef",
    "DescribeNotifyTemplatesRequestTypeDef",
    "DescribeNotifyTemplatesResultTypeDef",
    "DescribeOptOutListsRequestPaginateTypeDef",
    "DescribeOptOutListsRequestTypeDef",
    "DescribeOptOutListsResultTypeDef",
    "DescribeOptedOutNumbersRequestPaginateTypeDef",
    "DescribeOptedOutNumbersRequestTypeDef",
    "DescribeOptedOutNumbersResultTypeDef",
    "DescribePhoneNumbersRequestPaginateTypeDef",
    "DescribePhoneNumbersRequestTypeDef",
    "DescribePhoneNumbersResultTypeDef",
    "DescribePoolsRequestPaginateTypeDef",
    "DescribePoolsRequestTypeDef",
    "DescribePoolsResultTypeDef",
    "DescribeProtectConfigurationsRequestPaginateTypeDef",
    "DescribeProtectConfigurationsRequestTypeDef",
    "DescribeProtectConfigurationsResultTypeDef",
    "DescribeRcsAgentCountryLaunchStatusRequestPaginateTypeDef",
    "DescribeRcsAgentCountryLaunchStatusRequestTypeDef",
    "DescribeRcsAgentCountryLaunchStatusResultTypeDef",
    "DescribeRcsAgentsRequestPaginateTypeDef",
    "DescribeRcsAgentsRequestTypeDef",
    "DescribeRcsAgentsResultTypeDef",
    "DescribeRegistrationAttachmentsRequestPaginateTypeDef",
    "DescribeRegistrationAttachmentsRequestTypeDef",
    "DescribeRegistrationAttachmentsResultTypeDef",
    "DescribeRegistrationFieldDefinitionsRequestPaginateTypeDef",
    "DescribeRegistrationFieldDefinitionsRequestTypeDef",
    "DescribeRegistrationFieldDefinitionsResultTypeDef",
    "DescribeRegistrationFieldValuesRequestPaginateTypeDef",
    "DescribeRegistrationFieldValuesRequestTypeDef",
    "DescribeRegistrationFieldValuesResultTypeDef",
    "DescribeRegistrationSectionDefinitionsRequestPaginateTypeDef",
    "DescribeRegistrationSectionDefinitionsRequestTypeDef",
    "DescribeRegistrationSectionDefinitionsResultTypeDef",
    "DescribeRegistrationTypeDefinitionsRequestPaginateTypeDef",
    "DescribeRegistrationTypeDefinitionsRequestTypeDef",
    "DescribeRegistrationTypeDefinitionsResultTypeDef",
    "DescribeRegistrationVersionsRequestPaginateTypeDef",
    "DescribeRegistrationVersionsRequestTypeDef",
    "DescribeRegistrationVersionsResultTypeDef",
    "DescribeRegistrationsRequestPaginateTypeDef",
    "DescribeRegistrationsRequestTypeDef",
    "DescribeRegistrationsResultTypeDef",
    "DescribeSenderIdsRequestPaginateTypeDef",
    "DescribeSenderIdsRequestTypeDef",
    "DescribeSenderIdsResultTypeDef",
    "DescribeSpendLimitsRequestPaginateTypeDef",
    "DescribeSpendLimitsRequestTypeDef",
    "DescribeSpendLimitsResultTypeDef",
    "DescribeVerifiedDestinationNumbersRequestPaginateTypeDef",
    "DescribeVerifiedDestinationNumbersRequestTypeDef",
    "DescribeVerifiedDestinationNumbersResultTypeDef",
    "DisassociateOriginationIdentityRequestTypeDef",
    "DisassociateOriginationIdentityResultTypeDef",
    "DisassociateProtectConfigurationRequestTypeDef",
    "DisassociateProtectConfigurationResultTypeDef",
    "DiscardRegistrationVersionRequestTypeDef",
    "DiscardRegistrationVersionResultTypeDef",
    "EventDestinationTypeDef",
    "GetProtectConfigurationCountryRuleSetRequestTypeDef",
    "GetProtectConfigurationCountryRuleSetResultTypeDef",
    "GetResourcePolicyRequestTypeDef",
    "GetResourcePolicyResultTypeDef",
    "KeywordFilterTypeDef",
    "KeywordInformationTypeDef",
    "KinesisFirehoseDestinationTypeDef",
    "ListNotifyCountriesRequestPaginateTypeDef",
    "ListNotifyCountriesRequestTypeDef",
    "ListNotifyCountriesResultTypeDef",
    "ListPoolOriginationIdentitiesRequestPaginateTypeDef",
    "ListPoolOriginationIdentitiesRequestTypeDef",
    "ListPoolOriginationIdentitiesResultTypeDef",
    "ListProtectConfigurationRuleSetNumberOverridesRequestPaginateTypeDef",
    "ListProtectConfigurationRuleSetNumberOverridesRequestTypeDef",
    "ListProtectConfigurationRuleSetNumberOverridesResultTypeDef",
    "ListRegistrationAssociationsRequestPaginateTypeDef",
    "ListRegistrationAssociationsRequestTypeDef",
    "ListRegistrationAssociationsResultTypeDef",
    "ListTagsForResourceRequestTypeDef",
    "ListTagsForResourceResultTypeDef",
    "NotifyConfigurationFilterTypeDef",
    "NotifyConfigurationInformationTypeDef",
    "NotifyCountryInformationTypeDef",
    "NotifyTemplateFilterTypeDef",
    "NotifyTemplateInformationTypeDef",
    "OptOutListInformationTypeDef",
    "OptedOutFilterTypeDef",
    "OptedOutNumberInformationTypeDef",
    "OriginationIdentityMetadataTypeDef",
    "PaginatorConfigTypeDef",
    "PhoneNumberFilterTypeDef",
    "PhoneNumberInformationTypeDef",
    "PoolFilterTypeDef",
    "PoolInformationTypeDef",
    "PoolOriginationIdentitiesFilterTypeDef",
    "ProtectConfigurationCountryRuleSetInformationTypeDef",
    "ProtectConfigurationFilterTypeDef",
    "ProtectConfigurationInformationTypeDef",
    "ProtectConfigurationRuleSetNumberOverrideFilterItemTypeDef",
    "ProtectConfigurationRuleSetNumberOverrideTypeDef",
    "PutKeywordRequestTypeDef",
    "PutKeywordResultTypeDef",
    "PutMessageFeedbackRequestTypeDef",
    "PutMessageFeedbackResultTypeDef",
    "PutOptedOutNumberRequestTypeDef",
    "PutOptedOutNumberResultTypeDef",
    "PutProtectConfigurationRuleSetNumberOverrideRequestTypeDef",
    "PutProtectConfigurationRuleSetNumberOverrideResultTypeDef",
    "PutRegistrationFieldValueRequestTypeDef",
    "PutRegistrationFieldValueResultTypeDef",
    "PutResourcePolicyRequestTypeDef",
    "PutResourcePolicyResultTypeDef",
    "RcsAgentFilterTypeDef",
    "RcsAgentInformationTypeDef",
    "RegistrationAssociationFilterTypeDef",
    "RegistrationAssociationMetadataTypeDef",
    "RegistrationAttachmentFilterTypeDef",
    "RegistrationAttachmentsInformationTypeDef",
    "RegistrationDeniedReasonInformationTypeDef",
    "RegistrationFieldDefinitionTypeDef",
    "RegistrationFieldDisplayHintsTypeDef",
    "RegistrationFieldValueInformationTypeDef",
    "RegistrationFilterTypeDef",
    "RegistrationInformationTypeDef",
    "RegistrationSectionDefinitionTypeDef",
    "RegistrationSectionDisplayHintsTypeDef",
    "RegistrationTypeDefinitionTypeDef",
    "RegistrationTypeDisplayHintsTypeDef",
    "RegistrationTypeFilterTypeDef",
    "RegistrationVersionFilterTypeDef",
    "RegistrationVersionInformationTypeDef",
    "RegistrationVersionStatusHistoryTypeDef",
    "ReleasePhoneNumberRequestTypeDef",
    "ReleasePhoneNumberResultTypeDef",
    "ReleaseSenderIdRequestTypeDef",
    "ReleaseSenderIdResultTypeDef",
    "RequestPhoneNumberRequestTypeDef",
    "RequestPhoneNumberResultTypeDef",
    "RequestSenderIdRequestTypeDef",
    "RequestSenderIdResultTypeDef",
    "ResponseMetadataTypeDef",
    "SelectOptionDescriptionTypeDef",
    "SelectValidationTypeDef",
    "SendDestinationNumberVerificationCodeRequestTypeDef",
    "SendDestinationNumberVerificationCodeResultTypeDef",
    "SendMediaMessageRequestTypeDef",
    "SendMediaMessageResultTypeDef",
    "SendNotifyTextMessageRequestTypeDef",
    "SendNotifyTextMessageResultTypeDef",
    "SendNotifyVoiceMessageRequestTypeDef",
    "SendNotifyVoiceMessageResultTypeDef",
    "SendTextMessageRequestTypeDef",
    "SendTextMessageResultTypeDef",
    "SendVoiceMessageRequestTypeDef",
    "SendVoiceMessageResultTypeDef",
    "SenderIdAndCountryTypeDef",
    "SenderIdFilterTypeDef",
    "SenderIdInformationTypeDef",
    "SetAccountDefaultProtectConfigurationRequestTypeDef",
    "SetAccountDefaultProtectConfigurationResultTypeDef",
    "SetDefaultMessageFeedbackEnabledRequestTypeDef",
    "SetDefaultMessageFeedbackEnabledResultTypeDef",
    "SetDefaultMessageTypeRequestTypeDef",
    "SetDefaultMessageTypeResultTypeDef",
    "SetDefaultSenderIdRequestTypeDef",
    "SetDefaultSenderIdResultTypeDef",
    "SetMediaMessageSpendLimitOverrideRequestTypeDef",
    "SetMediaMessageSpendLimitOverrideResultTypeDef",
    "SetNotifyMessageSpendLimitOverrideRequestTypeDef",
    "SetNotifyMessageSpendLimitOverrideResultTypeDef",
    "SetTextMessageSpendLimitOverrideRequestTypeDef",
    "SetTextMessageSpendLimitOverrideResultTypeDef",
    "SetVoiceMessageSpendLimitOverrideRequestTypeDef",
    "SetVoiceMessageSpendLimitOverrideResultTypeDef",
    "SnsDestinationTypeDef",
    "SpendLimitTypeDef",
    "SubmitRegistrationVersionRequestTypeDef",
    "SubmitRegistrationVersionResultTypeDef",
    "SupportedAssociationTypeDef",
    "TagResourceRequestTypeDef",
    "TagTypeDef",
    "TemplateVariableMetadataTypeDef",
    "TestingAgentInformationTypeDef",
    "TextValidationTypeDef",
    "TimestampTypeDef",
    "UntagResourceRequestTypeDef",
    "UpdateEventDestinationRequestTypeDef",
    "UpdateEventDestinationResultTypeDef",
    "UpdateNotifyConfigurationRequestTypeDef",
    "UpdateNotifyConfigurationResultTypeDef",
    "UpdatePhoneNumberRequestTypeDef",
    "UpdatePhoneNumberResultTypeDef",
    "UpdatePoolRequestTypeDef",
    "UpdatePoolResultTypeDef",
    "UpdateProtectConfigurationCountryRuleSetRequestTypeDef",
    "UpdateProtectConfigurationCountryRuleSetResultTypeDef",
    "UpdateProtectConfigurationRequestTypeDef",
    "UpdateProtectConfigurationResultTypeDef",
    "UpdateRcsAgentRequestTypeDef",
    "UpdateRcsAgentResultTypeDef",
    "UpdateSenderIdRequestTypeDef",
    "UpdateSenderIdResultTypeDef",
    "VerifiedDestinationNumberFilterTypeDef",
    "VerifiedDestinationNumberInformationTypeDef",
    "VerifyDestinationNumberRequestTypeDef",
    "VerifyDestinationNumberResultTypeDef",
)


class AccountAttributeTypeDef(TypedDict):
    Name: AccountAttributeNameType
    Value: str


class AccountLimitTypeDef(TypedDict):
    Name: AccountLimitNameType
    Used: int
    Max: int


class AssociateOriginationIdentityRequestTypeDef(TypedDict):
    PoolId: str
    OriginationIdentity: str
    IsoCountryCode: NotRequired[str]
    ClientToken: NotRequired[str]


class ResponseMetadataTypeDef(TypedDict):
    RequestId: str
    HTTPStatusCode: int
    HTTPHeaders: dict[str, str]
    RetryAttempts: int
    HostId: NotRequired[str]


class AssociateProtectConfigurationRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    ConfigurationSetName: str


BlobTypeDef = Union[str, bytes, IO[Any], StreamingBody]


class CarrierLookupRequestTypeDef(TypedDict):
    PhoneNumber: str


class CarrierStatusInformationTypeDef(TypedDict):
    CarrierName: str
    Status: CarrierStatusType


class CloudWatchLogsDestinationTypeDef(TypedDict):
    IamRoleArn: str
    LogGroupArn: str


class ConfigurationSetFilterTypeDef(TypedDict):
    Name: ConfigurationSetFilterNameType
    Values: Sequence[str]


class CountryLaunchStatusFilterTypeDef(TypedDict):
    Name: Literal["country-launch-status"]
    Values: Sequence[str]


class TagTypeDef(TypedDict):
    Key: str
    Value: str


class KinesisFirehoseDestinationTypeDef(TypedDict):
    IamRoleArn: str
    DeliveryStreamArn: str


class SnsDestinationTypeDef(TypedDict):
    TopicArn: str


class CreateRegistrationAssociationRequestTypeDef(TypedDict):
    RegistrationId: str
    ResourceId: str


class CreateRegistrationVersionRequestTypeDef(TypedDict):
    RegistrationId: str


class RegistrationVersionStatusHistoryTypeDef(TypedDict):
    DraftTimestamp: datetime
    SubmittedTimestamp: NotRequired[datetime]
    AwsReviewingTimestamp: NotRequired[datetime]
    ReviewingTimestamp: NotRequired[datetime]
    RequiresAuthenticationTimestamp: NotRequired[datetime]
    ApprovedTimestamp: NotRequired[datetime]
    DiscardedTimestamp: NotRequired[datetime]
    DeniedTimestamp: NotRequired[datetime]
    RevokedTimestamp: NotRequired[datetime]
    ArchivedTimestamp: NotRequired[datetime]


class DeleteConfigurationSetRequestTypeDef(TypedDict):
    ConfigurationSetName: str


class DeleteDefaultMessageTypeRequestTypeDef(TypedDict):
    ConfigurationSetName: str


class DeleteDefaultSenderIdRequestTypeDef(TypedDict):
    ConfigurationSetName: str


class DeleteEventDestinationRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    EventDestinationName: str


class DeleteKeywordRequestTypeDef(TypedDict):
    OriginationIdentity: str
    Keyword: str


class DeleteNotifyConfigurationRequestTypeDef(TypedDict):
    NotifyConfigurationId: str


class DeleteOptOutListRequestTypeDef(TypedDict):
    OptOutListName: str


class DeleteOptedOutNumberRequestTypeDef(TypedDict):
    OptOutListName: str
    OptedOutNumber: str


class DeletePoolRequestTypeDef(TypedDict):
    PoolId: str


class DeleteProtectConfigurationRequestTypeDef(TypedDict):
    ProtectConfigurationId: str


class DeleteProtectConfigurationRuleSetNumberOverrideRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    DestinationPhoneNumber: str


class DeleteRcsAgentRequestTypeDef(TypedDict):
    RcsAgentId: str


class DeleteRegistrationAttachmentRequestTypeDef(TypedDict):
    RegistrationAttachmentId: str


class DeleteRegistrationFieldValueRequestTypeDef(TypedDict):
    RegistrationId: str
    FieldPath: str


class DeleteRegistrationRequestTypeDef(TypedDict):
    RegistrationId: str


class DeleteResourcePolicyRequestTypeDef(TypedDict):
    ResourceArn: str


class DeleteVerifiedDestinationNumberRequestTypeDef(TypedDict):
    VerifiedDestinationNumberId: str


class PaginatorConfigTypeDef(TypedDict):
    MaxItems: NotRequired[int]
    PageSize: NotRequired[int]
    StartingToken: NotRequired[str]


class DescribeAccountAttributesRequestTypeDef(TypedDict):
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeAccountLimitsRequestTypeDef(TypedDict):
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class KeywordFilterTypeDef(TypedDict):
    Name: Literal["keyword-action"]
    Values: Sequence[str]


class KeywordInformationTypeDef(TypedDict):
    Keyword: str
    KeywordMessage: str
    KeywordAction: KeywordActionType


class NotifyConfigurationFilterTypeDef(TypedDict):
    Name: NotifyConfigurationFilterNameType
    Values: Sequence[str]


class NotifyConfigurationInformationTypeDef(TypedDict):
    NotifyConfigurationArn: str
    NotifyConfigurationId: str
    DisplayName: str
    UseCase: Literal["CODE_VERIFICATION"]
    EnabledChannels: list[NumberCapabilityType]
    Tier: NotifyConfigurationTierType
    TierUpgradeStatus: TierUpgradeStatusType
    Status: NotifyConfigurationStatusType
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    DefaultTemplateId: NotRequired[str]
    PoolId: NotRequired[str]
    EnabledCountries: NotRequired[list[str]]
    RejectionReason: NotRequired[str]


class NotifyTemplateFilterTypeDef(TypedDict):
    Name: NotifyTemplateFilterNameType
    Values: Sequence[str]


class DescribeOptOutListsRequestTypeDef(TypedDict):
    OptOutListNames: NotRequired[Sequence[str]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]
    Owner: NotRequired[OwnerType]


class OptOutListInformationTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    CreatedTimestamp: datetime


class OptedOutFilterTypeDef(TypedDict):
    Name: Literal["end-user-opted-out"]
    Values: Sequence[str]


class OptedOutNumberInformationTypeDef(TypedDict):
    OptedOutNumber: str
    OptedOutTimestamp: datetime
    EndUserOptedOut: bool


class PhoneNumberFilterTypeDef(TypedDict):
    Name: PhoneNumberFilterNameType
    Values: Sequence[str]


class PhoneNumberInformationTypeDef(TypedDict):
    PhoneNumberArn: str
    PhoneNumber: str
    Status: NumberStatusType
    IsoCountryCode: str
    MessageType: MessageTypeType
    NumberCapabilities: list[NumberCapabilityType]
    NumberType: NumberTypeType
    MonthlyLeasingPrice: str
    TwoWayEnabled: bool
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    PhoneNumberId: NotRequired[str]
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]
    InternationalSendingEnabled: NotRequired[bool]
    PoolId: NotRequired[str]
    RegistrationId: NotRequired[str]


class PoolFilterTypeDef(TypedDict):
    Name: PoolFilterNameType
    Values: Sequence[str]


class PoolInformationTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    Status: PoolStatusType
    MessageType: MessageTypeType
    TwoWayEnabled: bool
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    SharedRoutesEnabled: bool
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]


class ProtectConfigurationFilterTypeDef(TypedDict):
    Name: ProtectConfigurationFilterNameType
    Values: Sequence[str]


class ProtectConfigurationInformationTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    CreatedTimestamp: datetime
    AccountDefault: bool
    DeletionProtectionEnabled: bool


class RcsAgentFilterTypeDef(TypedDict):
    Name: RcsAgentFilterNameType
    Values: Sequence[str]


class RegistrationAttachmentFilterTypeDef(TypedDict):
    Name: Literal["attachment-status"]
    Values: Sequence[str]


class RegistrationAttachmentsInformationTypeDef(TypedDict):
    RegistrationAttachmentArn: str
    RegistrationAttachmentId: str
    AttachmentStatus: AttachmentStatusType
    CreatedTimestamp: datetime
    AttachmentUploadErrorReason: NotRequired[Literal["INTERNAL_ERROR"]]
    AttachmentUrl: NotRequired[str]


class DescribeRegistrationFieldDefinitionsRequestTypeDef(TypedDict):
    RegistrationType: str
    SectionPath: NotRequired[str]
    FieldPaths: NotRequired[Sequence[str]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationFieldValuesRequestTypeDef(TypedDict):
    RegistrationId: str
    VersionNumber: NotRequired[int]
    SectionPath: NotRequired[str]
    FieldPaths: NotRequired[Sequence[str]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class RegistrationFieldValueInformationTypeDef(TypedDict):
    FieldPath: str
    SelectChoices: NotRequired[list[str]]
    TextValue: NotRequired[str]
    RegistrationAttachmentId: NotRequired[str]
    DeniedReason: NotRequired[str]
    Feedback: NotRequired[str]


class DescribeRegistrationSectionDefinitionsRequestTypeDef(TypedDict):
    RegistrationType: str
    SectionPaths: NotRequired[Sequence[str]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class RegistrationTypeFilterTypeDef(TypedDict):
    Name: RegistrationTypeFilterNameType
    Values: Sequence[str]


class RegistrationVersionFilterTypeDef(TypedDict):
    Name: Literal["registration-version-status"]
    Values: Sequence[str]


class RegistrationFilterTypeDef(TypedDict):
    Name: RegistrationFilterNameType
    Values: Sequence[str]


class RegistrationInformationTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationType: str
    RegistrationStatus: RegistrationStatusType
    CurrentVersionNumber: int
    CreatedTimestamp: datetime
    ApprovedVersionNumber: NotRequired[int]
    LatestDeniedVersionNumber: NotRequired[int]
    AdditionalAttributes: NotRequired[dict[str, str]]


class SenderIdAndCountryTypeDef(TypedDict):
    SenderId: str
    IsoCountryCode: str


class SenderIdFilterTypeDef(TypedDict):
    Name: SenderIdFilterNameType
    Values: Sequence[str]


class SenderIdInformationTypeDef(TypedDict):
    SenderIdArn: str
    SenderId: str
    IsoCountryCode: str
    MessageTypes: list[MessageTypeType]
    MonthlyLeasingPrice: str
    DeletionProtectionEnabled: bool
    Registered: bool
    RegistrationId: NotRequired[str]


class DescribeSpendLimitsRequestTypeDef(TypedDict):
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class SpendLimitTypeDef(TypedDict):
    Name: SpendLimitNameType
    EnforcedLimit: int
    MaxLimit: int
    Overridden: bool


class VerifiedDestinationNumberFilterTypeDef(TypedDict):
    Name: VerifiedDestinationNumberFilterNameType
    Values: Sequence[str]


class VerifiedDestinationNumberInformationTypeDef(TypedDict):
    VerifiedDestinationNumberArn: str
    VerifiedDestinationNumberId: str
    DestinationPhoneNumber: str
    Status: VerificationStatusType
    CreatedTimestamp: datetime
    RcsAgentId: NotRequired[str]


class DisassociateOriginationIdentityRequestTypeDef(TypedDict):
    PoolId: str
    OriginationIdentity: str
    IsoCountryCode: NotRequired[str]
    ClientToken: NotRequired[str]


class DisassociateProtectConfigurationRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    ConfigurationSetName: str


class DiscardRegistrationVersionRequestTypeDef(TypedDict):
    RegistrationId: str


class GetProtectConfigurationCountryRuleSetRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    NumberCapability: NumberCapabilityType


class ProtectConfigurationCountryRuleSetInformationTypeDef(TypedDict):
    ProtectStatus: ProtectStatusType


class GetResourcePolicyRequestTypeDef(TypedDict):
    ResourceArn: str


class ListNotifyCountriesRequestTypeDef(TypedDict):
    Channels: NotRequired[Sequence[NumberCapabilityType]]
    UseCases: NotRequired[Sequence[Literal["CODE_VERIFICATION"]]]
    Tier: NotRequired[NotifyConfigurationTierType]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class NotifyCountryInformationTypeDef(TypedDict):
    IsoCountryCode: str
    CountryName: str
    SupportedChannels: list[NumberCapabilityType]
    SupportedUseCases: list[Literal["CODE_VERIFICATION"]]
    SupportedTiers: list[NotifyConfigurationTierType]
    CustomerOwnedIdentityRequired: bool


class PoolOriginationIdentitiesFilterTypeDef(TypedDict):
    Name: PoolOriginationIdentitiesFilterNameType
    Values: Sequence[str]


class OriginationIdentityMetadataTypeDef(TypedDict):
    OriginationIdentityArn: str
    OriginationIdentity: str
    IsoCountryCode: str
    NumberCapabilities: list[NumberCapabilityType]
    PhoneNumber: NotRequired[str]


class ProtectConfigurationRuleSetNumberOverrideFilterItemTypeDef(TypedDict):
    Name: ProtectConfigurationRuleSetNumberOverrideFilterNameType
    Values: Sequence[str]


class ProtectConfigurationRuleSetNumberOverrideTypeDef(TypedDict):
    DestinationPhoneNumber: str
    CreatedTimestamp: datetime
    Action: ProtectConfigurationRuleOverrideActionType
    IsoCountryCode: NotRequired[str]
    ExpirationTimestamp: NotRequired[datetime]


class RegistrationAssociationFilterTypeDef(TypedDict):
    Name: RegistrationAssociationFilterNameType
    Values: Sequence[str]


class RegistrationAssociationMetadataTypeDef(TypedDict):
    ResourceArn: str
    ResourceId: str
    ResourceType: str
    IsoCountryCode: NotRequired[str]
    PhoneNumber: NotRequired[str]


class ListTagsForResourceRequestTypeDef(TypedDict):
    ResourceArn: str


TemplateVariableMetadataTypeDef = TypedDict(
    "TemplateVariableMetadataTypeDef",
    {
        "Type": TemplateVariableTypeType,
        "Required": bool,
        "Description": NotRequired[str],
        "MaxLength": NotRequired[int],
        "MinValue": NotRequired[int],
        "MaxValue": NotRequired[int],
        "DefaultValue": NotRequired[str],
        "Pattern": NotRequired[str],
        "Sample": NotRequired[str],
        "Source": NotRequired[TemplateVariableSourceType],
    },
)


class PutKeywordRequestTypeDef(TypedDict):
    OriginationIdentity: str
    Keyword: str
    KeywordMessage: str
    KeywordAction: NotRequired[KeywordActionType]


class PutMessageFeedbackRequestTypeDef(TypedDict):
    MessageId: str
    MessageFeedbackStatus: MessageFeedbackStatusType


class PutOptedOutNumberRequestTypeDef(TypedDict):
    OptOutListName: str
    OptedOutNumber: str


TimestampTypeDef = Union[datetime, str]


class PutRegistrationFieldValueRequestTypeDef(TypedDict):
    RegistrationId: str
    FieldPath: str
    SelectChoices: NotRequired[Sequence[str]]
    TextValue: NotRequired[str]
    RegistrationAttachmentId: NotRequired[str]


class PutResourcePolicyRequestTypeDef(TypedDict):
    ResourceArn: str
    Policy: str


class TestingAgentInformationTypeDef(TypedDict):
    Status: TestingAgentStatusType
    RegistrationId: str
    TestingAgentId: NotRequired[str]


class RegistrationDeniedReasonInformationTypeDef(TypedDict):
    Reason: str
    ShortDescription: str
    LongDescription: NotRequired[str]
    DocumentationTitle: NotRequired[str]
    DocumentationLink: NotRequired[str]


class SelectValidationTypeDef(TypedDict):
    MinChoices: int
    MaxChoices: int
    Options: list[str]


TextValidationTypeDef = TypedDict(
    "TextValidationTypeDef",
    {
        "MinLength": int,
        "MaxLength": int,
        "Pattern": str,
    },
)


class SelectOptionDescriptionTypeDef(TypedDict):
    Option: str
    Title: NotRequired[str]
    Description: NotRequired[str]


class RegistrationSectionDisplayHintsTypeDef(TypedDict):
    Title: str
    ShortDescription: str
    LongDescription: NotRequired[str]
    DocumentationTitle: NotRequired[str]
    DocumentationLink: NotRequired[str]


class RegistrationTypeDisplayHintsTypeDef(TypedDict):
    Title: str
    ShortDescription: NotRequired[str]
    LongDescription: NotRequired[str]
    DocumentationTitle: NotRequired[str]
    DocumentationLink: NotRequired[str]


class SupportedAssociationTypeDef(TypedDict):
    ResourceType: str
    AssociationBehavior: RegistrationAssociationBehaviorType
    DisassociationBehavior: RegistrationDisassociationBehaviorType
    IsoCountryCode: NotRequired[str]


class ReleasePhoneNumberRequestTypeDef(TypedDict):
    PhoneNumberId: str


class ReleaseSenderIdRequestTypeDef(TypedDict):
    SenderId: str
    IsoCountryCode: str


class SendDestinationNumberVerificationCodeRequestTypeDef(TypedDict):
    VerifiedDestinationNumberId: str
    VerificationChannel: VerificationChannelType
    LanguageCode: NotRequired[LanguageCodeType]
    OriginationIdentity: NotRequired[str]
    ConfigurationSetName: NotRequired[str]
    Context: NotRequired[Mapping[str, str]]
    DestinationCountryParameters: NotRequired[Mapping[DestinationCountryParameterKeyType, str]]


class SendMediaMessageRequestTypeDef(TypedDict):
    DestinationPhoneNumber: str
    OriginationIdentity: str
    MessageBody: NotRequired[str]
    MediaUrls: NotRequired[Sequence[str]]
    ConfigurationSetName: NotRequired[str]
    MaxPrice: NotRequired[str]
    TimeToLive: NotRequired[int]
    Context: NotRequired[Mapping[str, str]]
    DryRun: NotRequired[bool]
    ProtectConfigurationId: NotRequired[str]
    MessageFeedbackEnabled: NotRequired[bool]


class SendNotifyTextMessageRequestTypeDef(TypedDict):
    NotifyConfigurationId: str
    DestinationPhoneNumber: str
    TemplateVariables: Mapping[str, str]
    TemplateId: NotRequired[str]
    TimeToLive: NotRequired[int]
    Context: NotRequired[Mapping[str, str]]
    ConfigurationSetName: NotRequired[str]
    DryRun: NotRequired[bool]
    MessageFeedbackEnabled: NotRequired[bool]


class SendNotifyVoiceMessageRequestTypeDef(TypedDict):
    NotifyConfigurationId: str
    DestinationPhoneNumber: str
    TemplateVariables: Mapping[str, str]
    TemplateId: NotRequired[str]
    VoiceId: NotRequired[VoiceIdType]
    TimeToLive: NotRequired[int]
    Context: NotRequired[Mapping[str, str]]
    ConfigurationSetName: NotRequired[str]
    DryRun: NotRequired[bool]
    MessageFeedbackEnabled: NotRequired[bool]


class SendTextMessageRequestTypeDef(TypedDict):
    DestinationPhoneNumber: str
    OriginationIdentity: NotRequired[str]
    MessageBody: NotRequired[str]
    MessageType: NotRequired[MessageTypeType]
    Keyword: NotRequired[str]
    ConfigurationSetName: NotRequired[str]
    MaxPrice: NotRequired[str]
    TimeToLive: NotRequired[int]
    Context: NotRequired[Mapping[str, str]]
    DestinationCountryParameters: NotRequired[Mapping[DestinationCountryParameterKeyType, str]]
    DryRun: NotRequired[bool]
    ProtectConfigurationId: NotRequired[str]
    MessageFeedbackEnabled: NotRequired[bool]


class SendVoiceMessageRequestTypeDef(TypedDict):
    DestinationPhoneNumber: str
    OriginationIdentity: str
    MessageBody: NotRequired[str]
    MessageBodyTextType: NotRequired[VoiceMessageBodyTextTypeType]
    VoiceId: NotRequired[VoiceIdType]
    ConfigurationSetName: NotRequired[str]
    MaxPricePerMinute: NotRequired[str]
    TimeToLive: NotRequired[int]
    Context: NotRequired[Mapping[str, str]]
    DryRun: NotRequired[bool]
    ProtectConfigurationId: NotRequired[str]
    MessageFeedbackEnabled: NotRequired[bool]


class SetAccountDefaultProtectConfigurationRequestTypeDef(TypedDict):
    ProtectConfigurationId: str


class SetDefaultMessageFeedbackEnabledRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    MessageFeedbackEnabled: bool


class SetDefaultMessageTypeRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    MessageType: MessageTypeType


class SetDefaultSenderIdRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    SenderId: str


class SetMediaMessageSpendLimitOverrideRequestTypeDef(TypedDict):
    MonthlyLimit: int


class SetNotifyMessageSpendLimitOverrideRequestTypeDef(TypedDict):
    MonthlyLimit: int


class SetTextMessageSpendLimitOverrideRequestTypeDef(TypedDict):
    MonthlyLimit: int


class SetVoiceMessageSpendLimitOverrideRequestTypeDef(TypedDict):
    MonthlyLimit: int


class SubmitRegistrationVersionRequestTypeDef(TypedDict):
    RegistrationId: str
    AwsReview: NotRequired[bool]


class UntagResourceRequestTypeDef(TypedDict):
    ResourceArn: str
    TagKeys: Sequence[str]


class UpdateNotifyConfigurationRequestTypeDef(TypedDict):
    NotifyConfigurationId: str
    DefaultTemplateId: NotRequired[str]
    PoolId: NotRequired[str]
    EnabledCountries: NotRequired[Sequence[str]]
    EnabledChannels: NotRequired[Sequence[NumberCapabilityType]]
    DeletionProtectionEnabled: NotRequired[bool]


class UpdatePhoneNumberRequestTypeDef(TypedDict):
    PhoneNumberId: str
    TwoWayEnabled: NotRequired[bool]
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]
    SelfManagedOptOutsEnabled: NotRequired[bool]
    OptOutListName: NotRequired[str]
    InternationalSendingEnabled: NotRequired[bool]
    DeletionProtectionEnabled: NotRequired[bool]


class UpdatePoolRequestTypeDef(TypedDict):
    PoolId: str
    TwoWayEnabled: NotRequired[bool]
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]
    SelfManagedOptOutsEnabled: NotRequired[bool]
    OptOutListName: NotRequired[str]
    SharedRoutesEnabled: NotRequired[bool]
    DeletionProtectionEnabled: NotRequired[bool]


class UpdateProtectConfigurationRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    DeletionProtectionEnabled: NotRequired[bool]


class UpdateRcsAgentRequestTypeDef(TypedDict):
    RcsAgentId: str
    DeletionProtectionEnabled: NotRequired[bool]
    OptOutListName: NotRequired[str]
    SelfManagedOptOutsEnabled: NotRequired[bool]
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]
    TwoWayEnabled: NotRequired[bool]


class UpdateSenderIdRequestTypeDef(TypedDict):
    SenderId: str
    IsoCountryCode: str
    DeletionProtectionEnabled: NotRequired[bool]


class VerifyDestinationNumberRequestTypeDef(TypedDict):
    VerifiedDestinationNumberId: str
    VerificationCode: str


class AssociateOriginationIdentityResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    OriginationIdentityArn: str
    OriginationIdentity: str
    IsoCountryCode: str
    ResponseMetadata: ResponseMetadataTypeDef


class AssociateProtectConfigurationResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class CarrierLookupResultTypeDef(TypedDict):
    E164PhoneNumber: str
    DialingCountryCode: str
    IsoCountryCode: str
    Country: str
    MCC: str
    MNC: str
    Carrier: str
    PhoneNumberType: PhoneNumberTypeType
    ResponseMetadata: ResponseMetadataTypeDef


class CreateRegistrationAssociationResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationType: str
    ResourceArn: str
    ResourceId: str
    ResourceType: str
    IsoCountryCode: str
    PhoneNumber: str
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteAccountDefaultProtectConfigurationResultTypeDef(TypedDict):
    DefaultProtectConfigurationArn: str
    DefaultProtectConfigurationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteDefaultMessageTypeResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    MessageType: MessageTypeType
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteDefaultSenderIdResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    SenderId: str
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteKeywordResultTypeDef(TypedDict):
    OriginationIdentityArn: str
    OriginationIdentity: str
    Keyword: str
    KeywordMessage: str
    KeywordAction: KeywordActionType
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteMediaMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteNotifyConfigurationResultTypeDef(TypedDict):
    NotifyConfigurationArn: str
    NotifyConfigurationId: str
    DisplayName: str
    UseCase: Literal["CODE_VERIFICATION"]
    DefaultTemplateId: str
    PoolId: str
    EnabledCountries: list[str]
    EnabledChannels: list[NumberCapabilityType]
    Tier: NotifyConfigurationTierType
    TierUpgradeStatus: TierUpgradeStatusType
    Status: NotifyConfigurationStatusType
    RejectionReason: str
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteNotifyMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteOptOutListResultTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteOptedOutNumberResultTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    OptedOutNumber: str
    OptedOutTimestamp: datetime
    EndUserOptedOut: bool
    ResponseMetadata: ResponseMetadataTypeDef


class DeletePoolResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    Status: PoolStatusType
    MessageType: MessageTypeType
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    SharedRoutesEnabled: bool
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteProtectConfigurationResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    CreatedTimestamp: datetime
    AccountDefault: bool
    DeletionProtectionEnabled: bool
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteProtectConfigurationRuleSetNumberOverrideResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    DestinationPhoneNumber: str
    CreatedTimestamp: datetime
    Action: ProtectConfigurationRuleOverrideActionType
    IsoCountryCode: str
    ExpirationTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteRcsAgentResultTypeDef(TypedDict):
    RcsAgentArn: str
    RcsAgentId: str
    Status: RcsAgentStatusType
    CreatedTimestamp: datetime
    DeletionProtectionEnabled: bool
    OptOutListName: str
    SelfManagedOptOutsEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    TwoWayEnabled: bool
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteRegistrationAttachmentResultTypeDef(TypedDict):
    RegistrationAttachmentArn: str
    RegistrationAttachmentId: str
    AttachmentStatus: AttachmentStatusType
    AttachmentUploadErrorReason: Literal["INTERNAL_ERROR"]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteRegistrationFieldValueResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    FieldPath: str
    SelectChoices: list[str]
    TextValue: str
    RegistrationAttachmentId: str
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteRegistrationResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationType: str
    RegistrationStatus: RegistrationStatusType
    CurrentVersionNumber: int
    ApprovedVersionNumber: int
    LatestDeniedVersionNumber: int
    AdditionalAttributes: dict[str, str]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteResourcePolicyResultTypeDef(TypedDict):
    ResourceArn: str
    Policy: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteTextMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteVerifiedDestinationNumberResultTypeDef(TypedDict):
    VerifiedDestinationNumberArn: str
    VerifiedDestinationNumberId: str
    DestinationPhoneNumber: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteVoiceMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class DescribeAccountAttributesResultTypeDef(TypedDict):
    AccountAttributes: list[AccountAttributeTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeAccountLimitsResultTypeDef(TypedDict):
    AccountLimits: list[AccountLimitTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DisassociateOriginationIdentityResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    OriginationIdentityArn: str
    OriginationIdentity: str
    IsoCountryCode: str
    ResponseMetadata: ResponseMetadataTypeDef


class DisassociateProtectConfigurationResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class GetResourcePolicyResultTypeDef(TypedDict):
    ResourceArn: str
    Policy: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class PutKeywordResultTypeDef(TypedDict):
    OriginationIdentityArn: str
    OriginationIdentity: str
    Keyword: str
    KeywordMessage: str
    KeywordAction: KeywordActionType
    ResponseMetadata: ResponseMetadataTypeDef


class PutMessageFeedbackResultTypeDef(TypedDict):
    MessageId: str
    MessageFeedbackStatus: MessageFeedbackStatusType
    ResponseMetadata: ResponseMetadataTypeDef


class PutOptedOutNumberResultTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    OptedOutNumber: str
    OptedOutTimestamp: datetime
    EndUserOptedOut: bool
    ResponseMetadata: ResponseMetadataTypeDef


class PutProtectConfigurationRuleSetNumberOverrideResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    DestinationPhoneNumber: str
    CreatedTimestamp: datetime
    Action: ProtectConfigurationRuleOverrideActionType
    IsoCountryCode: str
    ExpirationTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class PutRegistrationFieldValueResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    FieldPath: str
    SelectChoices: list[str]
    TextValue: str
    RegistrationAttachmentId: str
    ResponseMetadata: ResponseMetadataTypeDef


class PutResourcePolicyResultTypeDef(TypedDict):
    ResourceArn: str
    Policy: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class ReleasePhoneNumberResultTypeDef(TypedDict):
    PhoneNumberArn: str
    PhoneNumberId: str
    PhoneNumber: str
    Status: NumberStatusType
    IsoCountryCode: str
    MessageType: MessageTypeType
    NumberCapabilities: list[NumberCapabilityType]
    NumberType: NumberTypeType
    MonthlyLeasingPrice: str
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    RegistrationId: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class ReleaseSenderIdResultTypeDef(TypedDict):
    SenderIdArn: str
    SenderId: str
    IsoCountryCode: str
    MessageTypes: list[MessageTypeType]
    MonthlyLeasingPrice: str
    Registered: bool
    RegistrationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendDestinationNumberVerificationCodeResultTypeDef(TypedDict):
    MessageId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendMediaMessageResultTypeDef(TypedDict):
    MessageId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendNotifyTextMessageResultTypeDef(TypedDict):
    MessageId: str
    TemplateId: str
    ResolvedMessageBody: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendNotifyVoiceMessageResultTypeDef(TypedDict):
    MessageId: str
    TemplateId: str
    ResolvedMessageBody: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendTextMessageResultTypeDef(TypedDict):
    MessageId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SendVoiceMessageResultTypeDef(TypedDict):
    MessageId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SetAccountDefaultProtectConfigurationResultTypeDef(TypedDict):
    DefaultProtectConfigurationArn: str
    DefaultProtectConfigurationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SetDefaultMessageFeedbackEnabledResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    MessageFeedbackEnabled: bool
    ResponseMetadata: ResponseMetadataTypeDef


class SetDefaultMessageTypeResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    MessageType: MessageTypeType
    ResponseMetadata: ResponseMetadataTypeDef


class SetDefaultSenderIdResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    SenderId: str
    ResponseMetadata: ResponseMetadataTypeDef


class SetMediaMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class SetNotifyMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class SetTextMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class SetVoiceMessageSpendLimitOverrideResultTypeDef(TypedDict):
    MonthlyLimit: int
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateNotifyConfigurationResultTypeDef(TypedDict):
    NotifyConfigurationArn: str
    NotifyConfigurationId: str
    DisplayName: str
    UseCase: Literal["CODE_VERIFICATION"]
    DefaultTemplateId: str
    PoolId: str
    EnabledCountries: list[str]
    EnabledChannels: list[NumberCapabilityType]
    Tier: NotifyConfigurationTierType
    TierUpgradeStatus: TierUpgradeStatusType
    Status: NotifyConfigurationStatusType
    RejectionReason: str
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class UpdatePhoneNumberResultTypeDef(TypedDict):
    PhoneNumberArn: str
    PhoneNumberId: str
    PhoneNumber: str
    Status: NumberStatusType
    IsoCountryCode: str
    MessageType: MessageTypeType
    NumberCapabilities: list[NumberCapabilityType]
    NumberType: NumberTypeType
    MonthlyLeasingPrice: str
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    InternationalSendingEnabled: bool
    DeletionProtectionEnabled: bool
    RegistrationId: str
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class UpdatePoolResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    Status: PoolStatusType
    MessageType: MessageTypeType
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    SharedRoutesEnabled: bool
    DeletionProtectionEnabled: bool
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateProtectConfigurationResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    CreatedTimestamp: datetime
    AccountDefault: bool
    DeletionProtectionEnabled: bool
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateRcsAgentResultTypeDef(TypedDict):
    RcsAgentArn: str
    RcsAgentId: str
    Status: RcsAgentStatusType
    CreatedTimestamp: datetime
    DeletionProtectionEnabled: bool
    OptOutListName: str
    SelfManagedOptOutsEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    TwoWayEnabled: bool
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateSenderIdResultTypeDef(TypedDict):
    SenderIdArn: str
    SenderId: str
    IsoCountryCode: str
    MessageTypes: list[MessageTypeType]
    MonthlyLeasingPrice: str
    DeletionProtectionEnabled: bool
    Registered: bool
    RegistrationId: str
    ResponseMetadata: ResponseMetadataTypeDef


class VerifyDestinationNumberResultTypeDef(TypedDict):
    VerifiedDestinationNumberArn: str
    VerifiedDestinationNumberId: str
    DestinationPhoneNumber: str
    Status: VerificationStatusType
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CountryLaunchStatusInformationTypeDef(TypedDict):
    IsoCountryCode: str
    Status: CountryLaunchStatusType
    RegistrationId: str
    CarrierStatus: list[CarrierStatusInformationTypeDef]
    RcsPlatformId: NotRequired[str]


class DescribeConfigurationSetsRequestTypeDef(TypedDict):
    ConfigurationSetNames: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[ConfigurationSetFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRcsAgentCountryLaunchStatusRequestTypeDef(TypedDict):
    RcsAgentId: str
    IsoCountryCodes: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[CountryLaunchStatusFilterTypeDef]]
    MaxResults: NotRequired[int]
    NextToken: NotRequired[str]


class CreateConfigurationSetRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateConfigurationSetResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreateNotifyConfigurationRequestTypeDef(TypedDict):
    DisplayName: str
    UseCase: Literal["CODE_VERIFICATION"]
    EnabledChannels: Sequence[NumberCapabilityType]
    DefaultTemplateId: NotRequired[str]
    PoolId: NotRequired[str]
    EnabledCountries: NotRequired[Sequence[str]]
    DeletionProtectionEnabled: NotRequired[bool]
    ClientToken: NotRequired[str]
    Tags: NotRequired[Sequence[TagTypeDef]]


class CreateNotifyConfigurationResultTypeDef(TypedDict):
    NotifyConfigurationArn: str
    NotifyConfigurationId: str
    DisplayName: str
    UseCase: Literal["CODE_VERIFICATION"]
    DefaultTemplateId: str
    PoolId: str
    EnabledCountries: list[str]
    EnabledChannels: list[NumberCapabilityType]
    Tier: NotifyConfigurationTierType
    TierUpgradeStatus: TierUpgradeStatusType
    Status: NotifyConfigurationStatusType
    RejectionReason: str
    DeletionProtectionEnabled: bool
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreateOptOutListRequestTypeDef(TypedDict):
    OptOutListName: str
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateOptOutListResultTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreatePoolRequestTypeDef(TypedDict):
    OriginationIdentity: str
    MessageType: MessageTypeType
    IsoCountryCode: NotRequired[str]
    DeletionProtectionEnabled: NotRequired[bool]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreatePoolResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    Status: PoolStatusType
    MessageType: MessageTypeType
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    SharedRoutesEnabled: bool
    DeletionProtectionEnabled: bool
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreateProtectConfigurationRequestTypeDef(TypedDict):
    ClientToken: NotRequired[str]
    DeletionProtectionEnabled: NotRequired[bool]
    Tags: NotRequired[Sequence[TagTypeDef]]


class CreateProtectConfigurationResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    CreatedTimestamp: datetime
    AccountDefault: bool
    DeletionProtectionEnabled: bool
    Tags: list[TagTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class CreateRcsAgentRequestTypeDef(TypedDict):
    DeletionProtectionEnabled: NotRequired[bool]
    OptOutListName: NotRequired[str]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateRcsAgentResultTypeDef(TypedDict):
    RcsAgentArn: str
    RcsAgentId: str
    Status: RcsAgentStatusType
    DeletionProtectionEnabled: bool
    OptOutListName: str
    CreatedTimestamp: datetime
    SelfManagedOptOutsEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    TwoWayEnabled: bool
    Tags: list[TagTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class CreateRegistrationAttachmentRequestTypeDef(TypedDict):
    AttachmentBody: NotRequired[BlobTypeDef]
    AttachmentUrl: NotRequired[str]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateRegistrationAttachmentResultTypeDef(TypedDict):
    RegistrationAttachmentArn: str
    RegistrationAttachmentId: str
    AttachmentStatus: AttachmentStatusType
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreateRegistrationRequestTypeDef(TypedDict):
    RegistrationType: str
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateRegistrationResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationType: str
    RegistrationStatus: RegistrationStatusType
    CurrentVersionNumber: int
    AdditionalAttributes: dict[str, str]
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class CreateVerifiedDestinationNumberRequestTypeDef(TypedDict):
    DestinationPhoneNumber: str
    RcsAgentId: NotRequired[str]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class CreateVerifiedDestinationNumberResultTypeDef(TypedDict):
    VerifiedDestinationNumberArn: str
    VerifiedDestinationNumberId: str
    DestinationPhoneNumber: str
    Status: VerificationStatusType
    RcsAgentId: str
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class ListTagsForResourceResultTypeDef(TypedDict):
    ResourceArn: str
    Tags: list[TagTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class RequestPhoneNumberRequestTypeDef(TypedDict):
    IsoCountryCode: str
    MessageType: MessageTypeType
    NumberCapabilities: Sequence[NumberCapabilityType]
    NumberType: RequestableNumberTypeType
    OptOutListName: NotRequired[str]
    PoolId: NotRequired[str]
    RegistrationId: NotRequired[str]
    InternationalSendingEnabled: NotRequired[bool]
    DeletionProtectionEnabled: NotRequired[bool]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class RequestPhoneNumberResultTypeDef(TypedDict):
    PhoneNumberArn: str
    PhoneNumberId: str
    PhoneNumber: str
    Status: NumberStatusType
    IsoCountryCode: str
    MessageType: MessageTypeType
    NumberCapabilities: list[NumberCapabilityType]
    NumberType: RequestableNumberTypeType
    MonthlyLeasingPrice: str
    TwoWayEnabled: bool
    TwoWayChannelArn: str
    TwoWayChannelRole: str
    SelfManagedOptOutsEnabled: bool
    OptOutListName: str
    InternationalSendingEnabled: bool
    DeletionProtectionEnabled: bool
    PoolId: str
    RegistrationId: str
    Tags: list[TagTypeDef]
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class RequestSenderIdRequestTypeDef(TypedDict):
    SenderId: str
    IsoCountryCode: str
    MessageTypes: NotRequired[Sequence[MessageTypeType]]
    DeletionProtectionEnabled: NotRequired[bool]
    Tags: NotRequired[Sequence[TagTypeDef]]
    ClientToken: NotRequired[str]


class RequestSenderIdResultTypeDef(TypedDict):
    SenderIdArn: str
    SenderId: str
    IsoCountryCode: str
    MessageTypes: list[MessageTypeType]
    MonthlyLeasingPrice: str
    DeletionProtectionEnabled: bool
    Registered: bool
    Tags: list[TagTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class TagResourceRequestTypeDef(TypedDict):
    ResourceArn: str
    Tags: Sequence[TagTypeDef]


class CreateEventDestinationRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    EventDestinationName: str
    MatchingEventTypes: Sequence[EventTypeType]
    CloudWatchLogsDestination: NotRequired[CloudWatchLogsDestinationTypeDef]
    KinesisFirehoseDestination: NotRequired[KinesisFirehoseDestinationTypeDef]
    SnsDestination: NotRequired[SnsDestinationTypeDef]
    ClientToken: NotRequired[str]


class EventDestinationTypeDef(TypedDict):
    EventDestinationName: str
    Enabled: bool
    MatchingEventTypes: list[EventTypeType]
    CloudWatchLogsDestination: NotRequired[CloudWatchLogsDestinationTypeDef]
    KinesisFirehoseDestination: NotRequired[KinesisFirehoseDestinationTypeDef]
    SnsDestination: NotRequired[SnsDestinationTypeDef]


class UpdateEventDestinationRequestTypeDef(TypedDict):
    ConfigurationSetName: str
    EventDestinationName: str
    Enabled: NotRequired[bool]
    MatchingEventTypes: NotRequired[Sequence[EventTypeType]]
    CloudWatchLogsDestination: NotRequired[CloudWatchLogsDestinationTypeDef]
    KinesisFirehoseDestination: NotRequired[KinesisFirehoseDestinationTypeDef]
    SnsDestination: NotRequired[SnsDestinationTypeDef]


class CreateRegistrationVersionResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    RegistrationVersionStatus: RegistrationVersionStatusType
    RegistrationVersionStatusHistory: RegistrationVersionStatusHistoryTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class DiscardRegistrationVersionResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    RegistrationVersionStatus: RegistrationVersionStatusType
    RegistrationVersionStatusHistory: RegistrationVersionStatusHistoryTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class SubmitRegistrationVersionResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    RegistrationVersionStatus: RegistrationVersionStatusType
    RegistrationVersionStatusHistory: RegistrationVersionStatusHistoryTypeDef
    AwsReview: bool
    ResponseMetadata: ResponseMetadataTypeDef


class DescribeAccountAttributesRequestPaginateTypeDef(TypedDict):
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeAccountLimitsRequestPaginateTypeDef(TypedDict):
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeConfigurationSetsRequestPaginateTypeDef(TypedDict):
    ConfigurationSetNames: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[ConfigurationSetFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeOptOutListsRequestPaginateTypeDef(TypedDict):
    OptOutListNames: NotRequired[Sequence[str]]
    Owner: NotRequired[OwnerType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRcsAgentCountryLaunchStatusRequestPaginateTypeDef(TypedDict):
    RcsAgentId: str
    IsoCountryCodes: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[CountryLaunchStatusFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationFieldDefinitionsRequestPaginateTypeDef(TypedDict):
    RegistrationType: str
    SectionPath: NotRequired[str]
    FieldPaths: NotRequired[Sequence[str]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationFieldValuesRequestPaginateTypeDef(TypedDict):
    RegistrationId: str
    VersionNumber: NotRequired[int]
    SectionPath: NotRequired[str]
    FieldPaths: NotRequired[Sequence[str]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationSectionDefinitionsRequestPaginateTypeDef(TypedDict):
    RegistrationType: str
    SectionPaths: NotRequired[Sequence[str]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeSpendLimitsRequestPaginateTypeDef(TypedDict):
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListNotifyCountriesRequestPaginateTypeDef(TypedDict):
    Channels: NotRequired[Sequence[NumberCapabilityType]]
    UseCases: NotRequired[Sequence[Literal["CODE_VERIFICATION"]]]
    Tier: NotRequired[NotifyConfigurationTierType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeKeywordsRequestPaginateTypeDef(TypedDict):
    OriginationIdentity: str
    Keywords: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[KeywordFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeKeywordsRequestTypeDef(TypedDict):
    OriginationIdentity: str
    Keywords: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[KeywordFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeKeywordsResultTypeDef(TypedDict):
    OriginationIdentityArn: str
    OriginationIdentity: str
    Keywords: list[KeywordInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeNotifyConfigurationsRequestPaginateTypeDef(TypedDict):
    NotifyConfigurationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[NotifyConfigurationFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeNotifyConfigurationsRequestTypeDef(TypedDict):
    NotifyConfigurationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[NotifyConfigurationFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeNotifyConfigurationsResultTypeDef(TypedDict):
    NotifyConfigurations: list[NotifyConfigurationInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeNotifyTemplatesRequestPaginateTypeDef(TypedDict):
    TemplateIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[NotifyTemplateFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeNotifyTemplatesRequestTypeDef(TypedDict):
    TemplateIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[NotifyTemplateFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeOptOutListsResultTypeDef(TypedDict):
    OptOutLists: list[OptOutListInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeOptedOutNumbersRequestPaginateTypeDef(TypedDict):
    OptOutListName: str
    OptedOutNumbers: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[OptedOutFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeOptedOutNumbersRequestTypeDef(TypedDict):
    OptOutListName: str
    OptedOutNumbers: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[OptedOutFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeOptedOutNumbersResultTypeDef(TypedDict):
    OptOutListArn: str
    OptOutListName: str
    OptedOutNumbers: list[OptedOutNumberInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribePhoneNumbersRequestPaginateTypeDef(TypedDict):
    PhoneNumberIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[PhoneNumberFilterTypeDef]]
    Owner: NotRequired[OwnerType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribePhoneNumbersRequestTypeDef(TypedDict):
    PhoneNumberIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[PhoneNumberFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]
    Owner: NotRequired[OwnerType]


class DescribePhoneNumbersResultTypeDef(TypedDict):
    PhoneNumbers: list[PhoneNumberInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribePoolsRequestPaginateTypeDef(TypedDict):
    PoolIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[PoolFilterTypeDef]]
    Owner: NotRequired[OwnerType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribePoolsRequestTypeDef(TypedDict):
    PoolIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[PoolFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]
    Owner: NotRequired[OwnerType]


class DescribePoolsResultTypeDef(TypedDict):
    Pools: list[PoolInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeProtectConfigurationsRequestPaginateTypeDef(TypedDict):
    ProtectConfigurationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[ProtectConfigurationFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeProtectConfigurationsRequestTypeDef(TypedDict):
    ProtectConfigurationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[ProtectConfigurationFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeProtectConfigurationsResultTypeDef(TypedDict):
    ProtectConfigurations: list[ProtectConfigurationInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRcsAgentsRequestPaginateTypeDef(TypedDict):
    RcsAgentIds: NotRequired[Sequence[str]]
    Owner: NotRequired[OwnerType]
    Filters: NotRequired[Sequence[RcsAgentFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRcsAgentsRequestTypeDef(TypedDict):
    RcsAgentIds: NotRequired[Sequence[str]]
    Owner: NotRequired[OwnerType]
    Filters: NotRequired[Sequence[RcsAgentFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationAttachmentsRequestPaginateTypeDef(TypedDict):
    RegistrationAttachmentIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationAttachmentFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationAttachmentsRequestTypeDef(TypedDict):
    RegistrationAttachmentIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationAttachmentFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationAttachmentsResultTypeDef(TypedDict):
    RegistrationAttachments: list[RegistrationAttachmentsInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRegistrationFieldValuesResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    VersionNumber: int
    RegistrationFieldValues: list[RegistrationFieldValueInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRegistrationTypeDefinitionsRequestPaginateTypeDef(TypedDict):
    RegistrationTypes: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationTypeFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationTypeDefinitionsRequestTypeDef(TypedDict):
    RegistrationTypes: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationTypeFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationVersionsRequestPaginateTypeDef(TypedDict):
    RegistrationId: str
    VersionNumbers: NotRequired[Sequence[int]]
    Filters: NotRequired[Sequence[RegistrationVersionFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationVersionsRequestTypeDef(TypedDict):
    RegistrationId: str
    VersionNumbers: NotRequired[Sequence[int]]
    Filters: NotRequired[Sequence[RegistrationVersionFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationsRequestPaginateTypeDef(TypedDict):
    RegistrationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeRegistrationsRequestTypeDef(TypedDict):
    RegistrationIds: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[RegistrationFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeRegistrationsResultTypeDef(TypedDict):
    Registrations: list[RegistrationInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeSenderIdsRequestPaginateTypeDef(TypedDict):
    SenderIds: NotRequired[Sequence[SenderIdAndCountryTypeDef]]
    Filters: NotRequired[Sequence[SenderIdFilterTypeDef]]
    Owner: NotRequired[OwnerType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeSenderIdsRequestTypeDef(TypedDict):
    SenderIds: NotRequired[Sequence[SenderIdAndCountryTypeDef]]
    Filters: NotRequired[Sequence[SenderIdFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]
    Owner: NotRequired[OwnerType]


class DescribeSenderIdsResultTypeDef(TypedDict):
    SenderIds: list[SenderIdInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeSpendLimitsResultTypeDef(TypedDict):
    SpendLimits: list[SpendLimitTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeVerifiedDestinationNumbersRequestPaginateTypeDef(TypedDict):
    VerifiedDestinationNumberIds: NotRequired[Sequence[str]]
    DestinationPhoneNumbers: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[VerifiedDestinationNumberFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class DescribeVerifiedDestinationNumbersRequestTypeDef(TypedDict):
    VerifiedDestinationNumberIds: NotRequired[Sequence[str]]
    DestinationPhoneNumbers: NotRequired[Sequence[str]]
    Filters: NotRequired[Sequence[VerifiedDestinationNumberFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class DescribeVerifiedDestinationNumbersResultTypeDef(TypedDict):
    VerifiedDestinationNumbers: list[VerifiedDestinationNumberInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class GetProtectConfigurationCountryRuleSetResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    NumberCapability: NumberCapabilityType
    CountryRuleSet: dict[str, ProtectConfigurationCountryRuleSetInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateProtectConfigurationCountryRuleSetRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    NumberCapability: NumberCapabilityType
    CountryRuleSetUpdates: Mapping[str, ProtectConfigurationCountryRuleSetInformationTypeDef]


class UpdateProtectConfigurationCountryRuleSetResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    NumberCapability: NumberCapabilityType
    CountryRuleSet: dict[str, ProtectConfigurationCountryRuleSetInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef


class ListNotifyCountriesResultTypeDef(TypedDict):
    NotifyCountries: list[NotifyCountryInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class ListPoolOriginationIdentitiesRequestPaginateTypeDef(TypedDict):
    PoolId: str
    Filters: NotRequired[Sequence[PoolOriginationIdentitiesFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListPoolOriginationIdentitiesRequestTypeDef(TypedDict):
    PoolId: str
    Filters: NotRequired[Sequence[PoolOriginationIdentitiesFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class ListPoolOriginationIdentitiesResultTypeDef(TypedDict):
    PoolArn: str
    PoolId: str
    OriginationIdentities: list[OriginationIdentityMetadataTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class ListProtectConfigurationRuleSetNumberOverridesRequestPaginateTypeDef(TypedDict):
    ProtectConfigurationId: str
    Filters: NotRequired[Sequence[ProtectConfigurationRuleSetNumberOverrideFilterItemTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListProtectConfigurationRuleSetNumberOverridesRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    Filters: NotRequired[Sequence[ProtectConfigurationRuleSetNumberOverrideFilterItemTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class ListProtectConfigurationRuleSetNumberOverridesResultTypeDef(TypedDict):
    ProtectConfigurationArn: str
    ProtectConfigurationId: str
    RuleSetNumberOverrides: list[ProtectConfigurationRuleSetNumberOverrideTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class ListRegistrationAssociationsRequestPaginateTypeDef(TypedDict):
    RegistrationId: str
    Filters: NotRequired[Sequence[RegistrationAssociationFilterTypeDef]]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListRegistrationAssociationsRequestTypeDef(TypedDict):
    RegistrationId: str
    Filters: NotRequired[Sequence[RegistrationAssociationFilterTypeDef]]
    NextToken: NotRequired[str]
    MaxResults: NotRequired[int]


class ListRegistrationAssociationsResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationType: str
    RegistrationAssociations: list[RegistrationAssociationMetadataTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class NotifyTemplateInformationTypeDef(TypedDict):
    TemplateId: str
    Version: int
    TemplateType: Literal["OTP_VERIFICATION"]
    Channels: list[NumberCapabilityType]
    CreatedTimestamp: datetime
    TierAccess: NotRequired[list[NotifyConfigurationTierType]]
    Status: NotRequired[NotifyTemplateStatusType]
    SupportedCountries: NotRequired[list[str]]
    LanguageCode: NotRequired[str]
    Content: NotRequired[str]
    Variables: NotRequired[dict[str, TemplateVariableMetadataTypeDef]]
    SupportedVoiceIds: NotRequired[list[VoiceIdType]]


class PutProtectConfigurationRuleSetNumberOverrideRequestTypeDef(TypedDict):
    ProtectConfigurationId: str
    DestinationPhoneNumber: str
    Action: ProtectConfigurationRuleOverrideActionType
    ClientToken: NotRequired[str]
    ExpirationTimestamp: NotRequired[TimestampTypeDef]


class RcsAgentInformationTypeDef(TypedDict):
    RcsAgentArn: str
    RcsAgentId: str
    Status: RcsAgentStatusType
    CreatedTimestamp: datetime
    DeletionProtectionEnabled: bool
    SelfManagedOptOutsEnabled: bool
    TwoWayEnabled: bool
    OptOutListName: NotRequired[str]
    TwoWayChannelArn: NotRequired[str]
    TwoWayChannelRole: NotRequired[str]
    PoolId: NotRequired[str]
    TestingAgent: NotRequired[TestingAgentInformationTypeDef]


class RegistrationVersionInformationTypeDef(TypedDict):
    VersionNumber: int
    RegistrationVersionStatus: RegistrationVersionStatusType
    RegistrationVersionStatusHistory: RegistrationVersionStatusHistoryTypeDef
    DeniedReasons: NotRequired[list[RegistrationDeniedReasonInformationTypeDef]]
    Feedback: NotRequired[str]


class RegistrationFieldDisplayHintsTypeDef(TypedDict):
    Title: str
    ShortDescription: str
    LongDescription: NotRequired[str]
    DocumentationTitle: NotRequired[str]
    DocumentationLink: NotRequired[str]
    SelectOptionDescriptions: NotRequired[list[SelectOptionDescriptionTypeDef]]
    TextValidationDescription: NotRequired[str]
    ExampleTextValue: NotRequired[str]


class RegistrationSectionDefinitionTypeDef(TypedDict):
    SectionPath: str
    DisplayHints: RegistrationSectionDisplayHintsTypeDef


class RegistrationTypeDefinitionTypeDef(TypedDict):
    RegistrationType: str
    DisplayHints: RegistrationTypeDisplayHintsTypeDef
    SupportedAssociations: NotRequired[list[SupportedAssociationTypeDef]]


class DescribeRcsAgentCountryLaunchStatusResultTypeDef(TypedDict):
    RcsAgentId: str
    RcsAgentArn: str
    CountryLaunchStatus: list[CountryLaunchStatusInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class ConfigurationSetInformationTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    EventDestinations: list[EventDestinationTypeDef]
    CreatedTimestamp: datetime
    DefaultMessageType: NotRequired[MessageTypeType]
    DefaultSenderId: NotRequired[str]
    DefaultMessageFeedbackEnabled: NotRequired[bool]
    ProtectConfigurationId: NotRequired[str]


class CreateEventDestinationResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    EventDestination: EventDestinationTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteConfigurationSetResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    EventDestinations: list[EventDestinationTypeDef]
    DefaultMessageType: MessageTypeType
    DefaultSenderId: str
    DefaultMessageFeedbackEnabled: bool
    CreatedTimestamp: datetime
    ResponseMetadata: ResponseMetadataTypeDef


class DeleteEventDestinationResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    EventDestination: EventDestinationTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class UpdateEventDestinationResultTypeDef(TypedDict):
    ConfigurationSetArn: str
    ConfigurationSetName: str
    EventDestination: EventDestinationTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class DescribeNotifyTemplatesResultTypeDef(TypedDict):
    NotifyTemplates: list[NotifyTemplateInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRcsAgentsResultTypeDef(TypedDict):
    RcsAgents: list[RcsAgentInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRegistrationVersionsResultTypeDef(TypedDict):
    RegistrationArn: str
    RegistrationId: str
    RegistrationVersions: list[RegistrationVersionInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class RegistrationFieldDefinitionTypeDef(TypedDict):
    SectionPath: str
    FieldPath: str
    FieldType: FieldTypeType
    FieldRequirement: FieldRequirementType
    DisplayHints: RegistrationFieldDisplayHintsTypeDef
    SelectValidation: NotRequired[SelectValidationTypeDef]
    TextValidation: NotRequired[TextValidationTypeDef]


class DescribeRegistrationSectionDefinitionsResultTypeDef(TypedDict):
    RegistrationType: str
    RegistrationSectionDefinitions: list[RegistrationSectionDefinitionTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRegistrationTypeDefinitionsResultTypeDef(TypedDict):
    RegistrationTypeDefinitions: list[RegistrationTypeDefinitionTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeConfigurationSetsResultTypeDef(TypedDict):
    ConfigurationSets: list[ConfigurationSetInformationTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class DescribeRegistrationFieldDefinitionsResultTypeDef(TypedDict):
    RegistrationType: str
    RegistrationFieldDefinitions: list[RegistrationFieldDefinitionTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]
