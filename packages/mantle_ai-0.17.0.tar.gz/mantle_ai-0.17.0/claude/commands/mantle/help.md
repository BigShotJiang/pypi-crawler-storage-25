# Mantle Commands

## Setup & Onboarding
- `/mantle:adopt` — Onboard an existing project into Mantle (reverse-engineer design docs)

## Idea & Validation
- `/mantle:idea` — Log an idea with structured metadata
- `/mantle:challenge` — Challenge your idea from multiple angles
- `/mantle:research` — Research and validate an idea with web evidence

## Design
- `/mantle:design-product` — Create product design (the what and why)
- `/mantle:design-system` — Create system design (the how) with decision logging
- `/mantle:revise-product` — Revise product design + log what changed
- `/mantle:revise-system` — Revise system design + log what changed

## Bug Capture
- `/mantle:bug` — Quick structured bug capture during any session

## Planning
- `/mantle:plan-issues` — Break work into vertical slice issues
- `/mantle:add-issue` — Add a single new issue to the backlog
- `/mantle:shape-issue [issue-number]` — Shape an issue: evaluate approaches before decomposing
- `/mantle:plan-stories [issue-number]` — Decompose issues into implementable stories

## Implementation
- `/mantle:build [issue-number]` — Automated pipeline: shape → stories → implement → verify in one pass
- `/mantle:implement [issue-number]` — Run the implementation orchestration loop (stories only)

## Verification & Review
- `/mantle:verify` — Run project-specific verification
- `/mantle:review` — Checklist-based human review

## Learning
- `/mantle:retrospective [issue-number]` — Capture implementation learnings after an issue

## Context & Knowledge
- `/mantle:status` — Show current project state
- `/mantle:resume` — Project briefing and context restore
- `/mantle:add-skill` — Create or update a skill node

## Skills & Tags

| Command | Purpose |
|---|---|
| `mantle list-tags` | Discover available tags grouped by prefix |
| `mantle list-skills --tag <tag>` | Filter skills by tag |

**Tip:** Run `mantle list-tags` to discover tags, then `mantle list-skills --tag <tag>` to filter.

## Help
- `/mantle:help` — This command
