"""Web chat channel — outbound WebSocket relay (no SSH, no password)."""

import asyncio
import base64
import json
import mimetypes
import os
import uuid
from pathlib import Path
from typing import Any

import websockets
from loguru import logger

from flowly.bus.events import InboundMessage, OutboundMessage
from flowly.bus.queue import MessageBus
from flowly.channels.base import BaseChannel
from flowly.config.schema import WebChannelConfig


def _save_attachments(attachments: list[dict], media_dir: Path) -> list[str]:
    """Resolve attachments to local file paths.

    Supports two modes:
      - ``filePath``: native path (desktop local — zero-copy).
      - ``content``: base64-encoded data (remote clients via relay).
    """
    media_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for att in attachments:
        # Prefer native file path (desktop local optimisation)
        file_path = att.get("filePath", "")
        if file_path and Path(file_path).is_file():
            paths.append(str(Path(file_path)))
            continue

        # Fall back to base64 content
        content = att.get("content", "")
        if not content:
            continue
        if isinstance(content, str) and "," in content and content.startswith("data:"):
            content = content.split(",", 1)[1]
        try:
            data = base64.b64decode(content)
        except Exception:
            continue
        mime = att.get("mimeType", "")
        filename = att.get("fileName", "")
        ext = Path(filename).suffix if filename else (mimetypes.guess_extension(mime) or "")
        fpath = media_dir / f"{uuid.uuid4().hex}{ext}"
        fpath.write_bytes(data)
        paths.append(str(fpath))
    return paths


class WebChannel(BaseChannel):
    """
    Web chat channel using an outbound relay WebSocket.

    The VPS connects OUTWARD to the proxy (like Telegram polls Telegram servers).
    The browser connects to the proxy with Firebase JWT — no SSH, no password.

    Protocol:
      VPS  → proxy /relay?token=<agent_jwt>  (persistent outbound connection)
      Browser → proxy /?token=<browser_jwt>  (routed through agent connection)

    Messages forwarded from proxy have a `sessionId` field identifying the browser.
    Responses sent back include the same `sessionId` so the proxy can route them.
    """

    name = "web"

    def __init__(self, config: WebChannelConfig, bus: MessageBus):
        super().__init__(config, bus)
        self.config: WebChannelConfig = config
        self._ws = None
        self._reconnect_delay = 5  # seconds
        self._max_reconnect_delay = 60
        # Track active browser sessions: sessionId → asyncio.Event (response ready)
        self._pending: dict[str, asyncio.Queue] = {}
        # Map session_key (e.g. "web:FirestoreId") → relay session_id (browser UUID)
        self._session_key_to_relay_id: dict[str, str] = {}

    async def start(self) -> None:
        """Connect outbound to relay proxy and keep reconnecting (Telegram-like)."""
        if not self.config.enabled:
            return
        if not self.config.auth_token:
            logger.error("[WebChannel] auth_token not set — cannot connect to relay")
            return
        if not self.config.server_id:
            # Try env fallback
            self.config.server_id = os.environ.get("FLOWLY_SERVER_ID", "")
        if not self.config.server_id:
            logger.error("[WebChannel] server_id not set — cannot connect to relay")
            return

        self._running = True
        delay = self._reconnect_delay

        while self._running:
            try:
                await self._connect_and_run()
                delay = self._reconnect_delay  # reset on clean disconnect
            except Exception as e:
                if not self._running:
                    break
                logger.warning(f"[WebChannel] Disconnected ({e}), reconnecting in {delay}s...")
                await asyncio.sleep(delay)
                delay = min(delay * 2, self._max_reconnect_delay)

    async def stop(self) -> None:
        self._running = False
        if self._ws:
            await self._ws.close()
            self._ws = None

    async def send(self, msg: OutboundMessage) -> None:
        """Send agent response back to the browser via the relay proxy."""
        if not self._ws:
            logger.warning("[WebChannel] Cannot send — not connected to relay")
            return

        session_id = msg.chat_id  # chat_id = sessionId for web channel
        run_id = msg.metadata.get("run_id", str(uuid.uuid4()))

        # Build content blocks — always start with text
        content_blocks: list[dict[str, Any]] = []
        if msg.content:
            content_blocks.append({"type": "text", "text": msg.content})

        # Encode media files as base64 image blocks (relay uploads to S3)
        for media_path in msg.media:
            try:
                p = Path(media_path)
                if not p.is_file():
                    continue
                mime_type = mimetypes.guess_type(str(p))[0] or "image/png"
                if not mime_type.startswith("image/"):
                    continue
                data = base64.b64encode(p.read_bytes()).decode("ascii")
                content_blocks.append({
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": mime_type,
                        "data": data,
                    },
                })
                logger.info(f"[WebChannel] Attached image {p.name} ({p.stat().st_size / 1024:.0f}KB)")
            except Exception as e:
                logger.warning(f"[WebChannel] Failed to attach media {media_path}: {e}")

        # Ensure at least one content block
        if not content_blocks:
            content_blocks.append({"type": "text", "text": ""})

        # Send final chat event (browser MoltbotClient listens for this)
        event_msg = {
            "type": "event",
            "sessionId": session_id,
            "event": "chat",
            "data": {
                "state": "final",
                "runId": run_id,
                "message": {
                    "content": content_blocks,
                },
            },
        }
        try:
            await self._ws.send(json.dumps(event_msg))
        except Exception as e:
            logger.error(f"[WebChannel] Failed to send response: {e}")

    async def send_approval_event(
        self,
        session_key: str,
        approval_id: str,
        command: str,
        expires_at: float,
    ) -> None:
        """Push exec approval request to the browser/iOS via relay."""
        if not self._ws:
            return

        # Resolve to relay session_id (browser UUID) from session_key
        relay_id = self._session_key_to_relay_id.get(session_key)
        if not relay_id:
            # Try with web: prefix
            relay_id = self._session_key_to_relay_id.get(f"web:{session_key}")
        if not relay_id:
            logger.warning(f"[WebChannel] No relay session found for {session_key}")
            return

        event_msg = {
            "type": "event",
            "sessionId": relay_id,
            "event": "exec.approval.requested",
            "data": {
                "id": approval_id,
                "command": command,
                "expiresAt": expires_at,
            },
        }
        try:
            await self._ws.send(json.dumps(event_msg))
            logger.info(f"[WebChannel] Sent approval event {approval_id} to relay session {relay_id}")
        except Exception as e:
            logger.error(f"[WebChannel] Failed to send approval event: {e}")

    async def send_compaction_event(
        self,
        session_key: str,
        tokens_before: int,
        tokens_after: int,
        messages_removed: int,
        phase: str = "completed",
    ) -> None:
        """Notify the browser/iOS that context is being compacted or was compacted."""
        if not self._ws:
            return

        relay_id = self._session_key_to_relay_id.get(session_key)
        if not relay_id:
            relay_id = self._session_key_to_relay_id.get(f"web:{session_key}")
        if not relay_id:
            return

        event_msg = {
            "type": "event",
            "sessionId": relay_id,
            "event": "compaction",
            "data": {
                "phase": phase,
                "tokensBefore": tokens_before,
                "tokensAfter": tokens_after,
                "messagesRemoved": messages_removed,
            },
        }
        try:
            await self._ws.send(json.dumps(event_msg))
            logger.info(f"[WebChannel] Sent compaction event to relay session {relay_id}")
        except Exception as e:
            logger.debug(f"[WebChannel] Failed to send compaction event: {e}")

    async def _connect_and_run(self) -> None:
        """Open one WebSocket connection to the relay proxy and process messages."""
        from jose import jwt as jose_jwt
        import time

        jwt_secret = os.environ.get("MOLTBOT_PROXY_JWT_SECRET", "")
        if not jwt_secret or jwt_secret == "flowly-moltbot-proxy-secret-change-in-production":
            # Use server-specific auth token from config as fallback (not a hardcoded default)
            jwt_secret = self.config.auth_token or ""
        if not jwt_secret:
            logger.warning("[WebChannel] No JWT secret configured — set MOLTBOT_PROXY_JWT_SECRET env var")

        # Build agent JWT
        now = int(time.time())
        payload = {
            "type": "agent",
            "serverId": self.config.server_id,
            "gatewayAuthToken": self.config.auth_token,
            "iat": now,
            "exp": now + 3600 * 24,  # 24h — long-lived agent token
            "iss": "flowly",
            "aud": "moltbot-proxy",
        }
        token = jose_jwt.encode(payload, jwt_secret, algorithm="HS256")
        url = f"{self.config.relay_url}?token={token}"

        logger.info(f"[WebChannel] Connecting to relay: {self.config.relay_url}")

        async with websockets.connect(url, ping_interval=30, ping_timeout=10) as ws:
            self._ws = ws
            logger.info("[WebChannel] Connected to relay proxy")

            async for raw in ws:
                if not self._running:
                    break
                try:
                    msg = json.loads(raw)
                    await self._handle_relay_message(ws, msg)
                except json.JSONDecodeError:
                    logger.warning("[WebChannel] Invalid JSON from relay")
                except Exception as e:
                    logger.error(f"[WebChannel] Error handling relay message: {e}")

        self._ws = None

    async def _handle_relay_message(self, ws, msg: dict) -> None:
        """Handle a message forwarded by the relay proxy."""
        msg_type = msg.get("type")

        if msg_type == "ready":
            logger.info("[WebChannel] Relay confirmed agent ready")

        elif msg_type == "browser-connected":
            session_id = msg.get("sessionId", "")
            logger.info(f"[WebChannel] Browser connected: {session_id}")

        elif msg_type == "browser-disconnected":
            session_id = msg.get("sessionId", "")
            logger.info(f"[WebChannel] Browser disconnected: {session_id}")
            self._pending.pop(session_id, None)

        elif msg_type == "rpc":
            await self._handle_rpc(ws, msg)

        elif msg_type == "ping":
            session_id = msg.get("sessionId")
            pong = {"type": "pong", "timestamp": msg.get("timestamp")}
            if session_id:
                pong["sessionId"] = session_id
            await ws.send(json.dumps(pong))

        else:
            logger.debug(f"[WebChannel] Unhandled relay message type: {msg_type}")

    async def _handle_rpc(self, ws, msg: dict) -> None:
        """Handle an RPC call from the browser (forwarded by proxy)."""
        method = msg.get("method", "")
        rpc_id = msg.get("id", "")
        params = msg.get("params", {})
        session_id = msg.get("sessionId", "")

        if method == "chat.send":
            message_text = params.get("message", "")
            session_key = params.get("sessionKey") or f"web:{session_id}"
            idempotency_key = params.get("idempotencyKey") or str(uuid.uuid4())

            # Track mapping so approval events can find the relay session
            self._session_key_to_relay_id[session_key] = session_id
            if not session_key.startswith("web:"):
                self._session_key_to_relay_id[f"web:{session_key}"] = session_id
            run_id = idempotency_key

            # Save attachments to disk
            media: list[str] = []
            attachments = params.get("attachments") or []
            if attachments:
                media_dir = get_flowly_home() / "media"
                media = _save_attachments(attachments, media_dir)

            # ACK immediately with runId
            ack = {
                "type": "rpc",
                "id": rpc_id,
                "sessionId": session_id,
                "result": {"runId": run_id},
            }
            await ws.send(json.dumps(ack))

            # Build streaming callback — sends delta events to this browser session.
            # Captures ws and session_id at call time (safe even if self._ws reconnects).
            async def stream_callback(delta: str) -> None:
                await ws.send(json.dumps({
                    "type": "event",
                    "sessionId": session_id,
                    "event": "chat",
                    "data": {"state": "streaming", "runId": run_id, "delta": delta},
                }))

            # Process message asynchronously (don't block the recv loop)
            asyncio.create_task(
                self._process_message(session_id, session_key, message_text, run_id, stream_callback, media)
            )

        elif method == "chat.abort":
            run_id = params.get("runId", "")
            ack = {"type": "rpc", "id": rpc_id, "sessionId": session_id, "result": {}}
            await ws.send(json.dumps(ack))

        elif method == "chat.history":
            # History is managed by Firestore on the client side — return empty
            ack = {
                "type": "rpc",
                "id": rpc_id,
                "sessionId": session_id,
                "result": {"messages": []},
            }
            await ws.send(json.dumps(ack))

        elif method == "exec.approval.resolve":
            approval_id = params.get("id", "")
            decision = params.get("decision", "")
            if decision in ("allow-once", "allow-always", "deny"):
                from flowly.exec.approval_manager import get_approval_manager
                manager = get_approval_manager()
                ok = manager.resolve(approval_id, decision)
                ack = {"type": "rpc", "id": rpc_id, "sessionId": session_id, "result": {"ok": ok}}
            else:
                ack = {"type": "rpc", "id": rpc_id, "sessionId": session_id, "error": {"code": "INVALID", "message": "Invalid decision"}}
            await ws.send(json.dumps(ack))

        else:
            logger.warning(f"[WebChannel] Unknown RPC method: {method}")

    async def _process_message(
        self,
        session_id: str,
        session_key: str,
        content: str,
        run_id: str,
        stream_callback=None,
        media: list[str] | None = None,
    ) -> None:
        """Push message to bus and wait for agent response."""
        inbound_with_session = _WebInboundMessage(
            channel="web",
            sender_id=session_id,
            chat_id=session_id,
            content=content,
            media=media or [],
            metadata={"session_key": session_key, "run_id": run_id, "stream_callback": stream_callback},
            _session_key=session_key,
        )

        await self.bus.publish_inbound(inbound_with_session)


# ---------------------------------------------------------------------------
# InboundMessage subclass that allows overriding session_key
# ---------------------------------------------------------------------------

from dataclasses import dataclass, field
from datetime import datetime
from flowly.bus.events import InboundMessage as _Base
from flowly.profile import get_flowly_home


@dataclass
class _WebInboundMessage(_Base):
    _session_key: str = ""

    @property
    def session_key(self) -> str:  # type: ignore[override]
        return self._session_key or f"web:{self.chat_id}"
