# -*- coding: utf-8 -*-
# Copyright 2018, CS GROUP - France, https://www.csgroup.eu/
#
# This file is part of EODAG project
#     https://www.github.com/CS-SI/EODAG
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""EODAG product package"""

from eodag.utils.deserialize import unregistered_product_from_item

try:
    # import from eodag-cube if installed
    from eodag_cube.api.product import (  # pyright: ignore[reportMissingImports]
        Asset,
        AssetsDict,
        EOProduct,
    )
except ImportError:
    from ._assets import Asset, AssetsDict  # type: ignore[assignment]
    from ._product import EOProduct  # type: ignore[assignment]


# exportable content
__all__ = ["Asset", "AssetsDict", "EOProduct", "unregistered_product_from_item"]
