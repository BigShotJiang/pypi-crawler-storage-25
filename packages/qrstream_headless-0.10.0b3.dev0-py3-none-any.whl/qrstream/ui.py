"""
Unified progress / status UI layer for qrstream.

This module owns ALL user-facing progress, phase, and status output
produced by the encoder / decoder pipelines.  Business functions do
not call ``print`` or ``tqdm`` directly — they emit semantic events
(``probe_start``, ``scan_update``, ``encode_done``, …) through a
:class:`ProgressReporter` protocol object, and three concrete
implementations decide how to render them:

* :class:`RichReporter` — animated, colour, pip-style thin progress
  bars plus a qBittorrent-style block map for file recovery.  Also
  handles ``verbose`` mode on TTY (debug lines are routed through
  :meth:`rich.console.Console.log`).

* :class:`LogReporter` — single-line, appendable ``key=value``
  records for CI / ``tee`` / remote log capture; throttles
  ``scan_update`` / ``recover_update`` / ``encode_update`` to avoid
  spamming log files.

* :class:`QuietReporter` — emits errors and the final success line
  only; used for scripted invocations.

Error / warning messages that must remain captured by ``capsys`` in
existing tests continue to be ``print``-ed by ``cli.py`` directly —
the reporter ``error`` / ``warn`` methods are layered on top and
route to ``stderr`` for interactive / log mode.

Concrete renderers encapsulated here:

* :class:`SlidingHitWindow` — fixed-length ``deque`` tracking
  per-frame detect success for the *hit* metric shown beside the
  Scan / Recover bars.
* :func:`render_block_map` — source-block location map (colourised
  via Rich ``Text`` spans when available).
* :func:`render_range_strip` — targeted-recovery segment strip
  projected onto the video timeline.
"""

from __future__ import annotations

import enum
import math
import os
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Iterable, Protocol, Sequence

_RICH_IMPORT_ERROR: Exception | None = None
try:  # Rich is a hard dependency (declared in pyproject.toml).
    from rich.console import Console, Group
    from rich.live import Live
    from rich.progress import (
        BarColumn,
        Progress,
        ProgressColumn,
        SpinnerColumn,
        TextColumn,
    )
    from rich.color import Color as _RichColor
    from rich.style import Style as _RichStyle
    from rich.table import Column
    from rich.text import Text
    _RICH_AVAILABLE = True
except Exception as _exc:  # pragma: no cover — rich missing/old → log/quiet
    _RICH_AVAILABLE = False
    _RICH_IMPORT_ERROR = _exc


# ── Enums ────────────────────────────────────────────────────────


class OutputMode(str, enum.Enum):
    """User-selectable output modes (``--output-mode`` on the CLI).

    ``AUTO`` resolves at runtime: interactive on TTY, log otherwise.
    """

    AUTO = "auto"
    INTERACTIVE = "interactive"
    LOG = "log"
    QUIET = "quiet"
    VERBOSE = "verbose"


class Phase(str, enum.Enum):
    PROBE = "probe"
    SCAN = "scan"
    RECOVER = "recover"
    SAVE = "save"
    ENCODE = "encode"


# ── Sliding hit window ───────────────────────────────────────────


class SlidingHitWindow:
    """Fixed-length 0/1 deque tracking recent detect success.

    Used by Scan / Recover to show the ``hit`` metric — a windowed
    average of "QR decoded this frame?" over the last *N* processed
    frames.
    """

    __slots__ = ("_samples",)

    def __init__(self, capacity: int = 128):
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self._samples: deque[int] = deque(maxlen=capacity)

    def push(self, hit: bool) -> None:
        self._samples.append(1 if hit else 0)

    @property
    def ratio(self) -> float:
        if not self._samples:
            return 0.0
        return sum(self._samples) / len(self._samples)

    def clear(self) -> None:
        self._samples.clear()


# ── Block map / Range strip renderers ────────────────────────────


# Density thresholds for bucket rendering.
#
# Design: the File row's colour progression must read at a glance
# as "more recovered = warmer/brighter colour", matching the
# qBittorrent "completed chunks" aesthetic.  The colour spine goes
#
#     grey  →  blue  →  cyan  →  green
#
# — a single monotonic path through the blue/green family that
# aligns with the Scan row's cyan bar and the final "done" state
# (bright_green).
#
# Two orthogonal axes combine to give 10 perceptually-distinct
# tiers without ever reshuffling the hue:
#
#   Hue:      grey35 → grey50 → blue → bright_blue → cyan →
#             bright_cyan → green → bright_green
#   Glyph:    ░ (empty) → ▒ (half) → ▓ (full) → █ (solid)
#
# Both axes are monotone, so even on terminals that flatten some
# hues into each other users can still read progress from the
# glyph alone (and vice-versa for truecolor themes that wash out
# the ░▒▓ difference).
#
# Low density (≤ 35 %) is deliberately fine-grained — on large
# files that band dominates the whole scan and we want the user
# to see *early* progress differentiation there, not a solid
# colour block.  grey50 at density (0, 0.08] keeps the "first
# chunk just landed" signal visible without breaking the hue spine.
_DENSITY_CHAR_AND_STYLE: tuple[tuple[float, str, str], ...] = (
    (0.00,    "░", "grey35"),        # 0 ── untouched
    (0.08,    "░", "grey50"),        # 1 ── first chunk landed
    (0.20,    "░", "blue"),          # 2 ── sparse blue
    (0.35,    "▒", "bright_blue"),   # 3 ── denser blue
    (0.50,    "▒", "cyan"),          # 4 ── blue → cyan pivot
    (0.65,    "▓", "cyan"),          # 5 ── cyan, glyph gains body
    (0.80,    "▓", "bright_cyan"),   # 6 ── bright cyan
    (0.92,    "▓", "green"),         # 7 ── entering green
    (0.999,   "▓", "bright_green"),  # 8 ── near-complete
    (1.00,    "█", "bright_green"),  # 9 ── fully recovered
)

# ── Block-map truecolor gradient ─────────────────────────────────
# Smooth RGB gradient for the block-map with non-linear density
# mapping.  LT fountain decoding recovers slowly at first (need
# enough unique seeds) then accelerates sharply at the end — the
# "peeling avalanche".  To make early progress visually prominent,
# we apply a concave power curve (exponent < 1) so the colour
# changes faster in the low-density region.
#
# Colour spine: dark teal → teal → cyan-green → green → bright_green
# 100% done: hard jump to lighter green (signals completion).
_BLOCK_GRADIENT_ANCHORS: list[tuple[float, tuple[int, int, int]]] = [
    (0.00, (20, 30, 35)),       # near-black teal
    (0.05, (20, 45, 55)),       # very dark teal
    (0.10, (20, 60, 72)),       # dark teal
    (0.18, (20, 75, 88)),       # teal emerging
    (0.30, (22, 90, 98)),       # deep teal (desaturated)
    (0.45, (28, 115, 110)),     # teal-cyan (muted)
    (0.60, (32, 140, 105)),     # mid cyan-green
    (0.75, (38, 162, 90)),      # cyan-green (muted)
    (0.90, (45, 180, 70)),      # green (muted)
    (1.00, (55, 200, 65)),      # muted green (gradient end)
]

# Non-linear density exponent: < 1 stretches the early region
# (more colour change per unit density at the start, less at end).
_BLOCK_GRADIENT_GAMMA = 0.55

# Glyph thresholds for truecolor mode — use solid block throughout
# so colour alone conveys density without glyph-induced brightness
# jumps at tier boundaries.
_BLOCK_GLYPH_THRESHOLDS: tuple[tuple[float, str], ...] = (
    (1.00, "█"),
)


def _density_cell(density: float) -> tuple[str, str]:
    """Return ``(char, rich_style)`` for a bucket density in [0, 1].

    The ``_DENSITY_CHAR_AND_STYLE`` table is sorted by ascending
    density threshold; the first tier whose threshold is ≥ the
    input density wins.  Both the glyph (``░ → ▒ → ▓ → █``) and
    the hue (``grey → blue → cyan → green``) advance monotonically
    along the table, so users can read progress from either axis
    alone when a terminal theme collapses some colours.

    TODO(block-map-relative-density): In the current mapping every
    cell is thresholded against absolute density (recovered /
    bucket_size).  That works beautifully for small files where
    ``k / width`` is O(1) — single-block recoveries immediately
    push a cell into a higher colour tier, giving the familiar
    qBittorrent-style "speckled" look.  For large files where
    ``k >> width`` (e.g. k=20000 over width=80 → 250 source blocks
    per cell) every cell's density stays glued to the global
    ``file_pct`` for most of the scan, so the whole bar fades
    through the same colour tier in lockstep and only snaps to
    ``█ bright_green`` in the final peeling avalanche.

    A future enhancement could remap the middle tiers from
    "absolute density" to "density relative to the global
    progress" so that cells slightly ahead of the average render
    darker and cells behind render lighter — preserving the
    block-map semantics (a cell's colour still corresponds to a
    real region of the file) while restoring per-cell visual
    contrast on large-k scans.  Not implemented yet: this would
    slightly redefine what the colour means (ahead-of-average vs.
    fully-recovered) and users may prefer the current honest
    mapping.  Revisit if large-file UX feedback asks for it.
    """
    density = max(0.0, min(1.0, density))
    for thresh, ch, style in _DENSITY_CHAR_AND_STYLE:
        if density <= thresh:
            return ch, style
    return _DENSITY_CHAR_AND_STYLE[-1][1], _DENSITY_CHAR_AND_STYLE[-1][2]


def _density_cell_truecolor(density: float) -> tuple[str, str]:
    """Return ``(char, rgb_style_str)`` using smooth truecolor gradient.

    Applies a non-linear gamma curve so colour changes are weighted
    towards the lower densities (matching LT fountain's slow-start,
    fast-finish recovery pattern).
    """
    density = max(0.0, min(1.0, density))

    # Fully recovered: saturation jump — from muted green to vivid
    # pure green.  Same brightness, much higher saturation.
    if density >= 1.0:
        return "█", "rgb(0,230,0)"

    # Determine glyph from density.
    glyph = _BLOCK_GLYPH_THRESHOLDS[-1][1]
    for thresh, ch in _BLOCK_GLYPH_THRESHOLDS:
        if density <= thresh:
            glyph = ch
            break

    # Apply gamma curve: stretches early colours, compresses late.
    t = density ** _BLOCK_GRADIENT_GAMMA

    # Interpolate through the RGB anchors using the remapped t.
    anchors = _BLOCK_GRADIENT_ANCHORS
    if t <= anchors[0][0]:
        r, g, b = anchors[0][1]
    elif t >= anchors[-1][0]:
        r, g, b = anchors[-1][1]
    else:
        for i in range(len(anchors) - 1):
            lo_t, lo_col = anchors[i]
            hi_t, hi_col = anchors[i + 1]
            if lo_t <= t <= hi_t:
                span = hi_t - lo_t
                frac = (t - lo_t) / span if span > 0 else 0.0
                r = int(lo_col[0] + (hi_col[0] - lo_col[0]) * frac)
                g = int(lo_col[1] + (hi_col[1] - lo_col[1]) * frac)
                b = int(lo_col[2] + (hi_col[2] - lo_col[2]) * frac)
                break
        else:
            r, g, b = anchors[-1][1]

    return glyph, f"rgb({r},{g},{b})"


def compute_block_map_cells(
    recovered: Iterable[int] | set[int] | dict[int, object],
    k: int,
    width: int,
    *,
    truecolor: bool = False,
) -> list[tuple[str, str, float]]:
    """Compute ``(char, style, density)`` cells for a block map.

    Parameters
    ----------
    recovered
        Container of recovered source-block indices (``set`` /
        ``dict`` / iterable).  Membership test via ``in``.
    k
        Total number of source blocks.
    width
        Target number of cells (terminal columns) to render.
    truecolor
        When True, use smooth RGB gradient colours; otherwise use
        discrete named-colour tiers.

    Notes
    -----
    The returned cell count always matches ``width`` so the visual
    block strip can align with progress bars even when ``k`` is much
    smaller than the available terminal width.
    """
    if k <= 0 or width <= 0:
        return []

    if isinstance(recovered, dict):
        recovered_set = recovered  # dict supports ``in`` on keys
    else:
        recovered_set = (
            recovered if hasattr(recovered, "__contains__")
            else set(recovered)
        )

    cell_fn = _density_cell_truecolor if truecolor else _density_cell
    cells: list[tuple[str, str, float]] = []
    scale = k / width
    for cell_idx in range(width):
        start = cell_idx * scale
        end = (cell_idx + 1) * scale
        lo = int(math.floor(start))
        hi = min(k - 1, int(math.ceil(end) - 1))
        covered = 0.0
        total_overlap = 0.0
        for block_idx in range(lo, hi + 1):
            overlap = min(end, block_idx + 1.0) - max(start, float(block_idx))
            if overlap > 0.0:
                total_overlap += overlap
                if block_idx in recovered_set:
                    covered += overlap
        # Snap to 1.0 when all blocks in this cell are recovered
        # (avoids floating-point near-miss like 0.99999).
        if total_overlap > 0.0 and covered >= total_overlap - 1e-9:
            density = 1.0
        else:
            density = covered / scale if scale > 0 else 0.0
        ch, style = cell_fn(density)
        cells.append((ch, style, density))
    return cells


def render_block_map_plain(
    recovered: Iterable[int] | set[int] | dict[int, object],
    k: int,
    width: int,
) -> str:
    """Plain-text block map (no colour codes) for log mode."""
    cells = compute_block_map_cells(recovered, k, width)
    return "".join(ch for ch, _, _ in cells)


def render_block_map_rich(
    recovered: Iterable[int] | set[int] | dict[int, object],
    k: int,
    width: int,
    *,
    truecolor: bool = False,
) -> "Text":
    """Rich ``Text`` object with per-cell colour spans."""
    cells = compute_block_map_cells(recovered, k, width, truecolor=truecolor)
    text = Text()
    for ch, style, _ in cells:
        text.append(ch, style=style)
    return text


# Range-strip characters.  Keep it short and terminal-safe.
_RANGE_IDLE = "·"
_RANGE_PENDING = "▁"
_RANGE_CURRENT = "▶"
_RANGE_DONE = "█"


def compute_range_strip_cells(
    segments: Sequence[tuple[int, int]],
    total_frames: int,
    width: int,
    *,
    current: tuple[int, int] | None = None,
    scanned: Iterable[tuple[int, int]] = (),
) -> list[tuple[str, str]]:
    """Project recovery segments onto a fixed-width video timeline.

    Parameters
    ----------
    segments
        Pending / planned recovery ranges as ``(start, end)``
        inclusive frame indices.
    total_frames
        Length of the source video in frames.
    width
        Target number of cells.
    current
        Active range being scanned (rendered with ``current`` style).
    scanned
        Already-finished ranges (rendered with ``done`` style).
    """
    if width <= 0:
        return []
    if total_frames <= 0:
        return [(_RANGE_IDLE, "grey35") for _ in range(width)]

    cells: list[tuple[str, str]] = [(_RANGE_IDLE, "grey35") for _ in range(width)]

    def _mark(start: int, end: int, ch: str, style: str) -> None:
        lo = max(0, min(total_frames - 1, start))
        hi = max(0, min(total_frames - 1, end))
        if hi < lo:
            return
        a = int(lo * width // total_frames)
        b = int(hi * width // total_frames)
        a = max(0, min(width - 1, a))
        b = max(0, min(width - 1, b))
        for i in range(a, b + 1):
            cells[i] = (ch, style)

    # Planning order: pending < scanned < current so current wins.
    for s, e in segments:
        _mark(s, e, _RANGE_PENDING, "yellow")
    for s, e in scanned:
        _mark(s, e, _RANGE_DONE, "green")
    if current is not None:
        _mark(current[0], current[1], _RANGE_CURRENT, "bright_cyan")
    return cells


def render_range_strip_plain(
    segments: Sequence[tuple[int, int]],
    total_frames: int,
    width: int,
    *,
    current: tuple[int, int] | None = None,
    scanned: Iterable[tuple[int, int]] = (),
) -> str:
    cells = compute_range_strip_cells(
        segments, total_frames, width,
        current=current, scanned=scanned,
    )
    return "".join(ch for ch, _ in cells)


def render_range_strip_rich(
    segments: Sequence[tuple[int, int]],
    total_frames: int,
    width: int,
    *,
    current: tuple[int, int] | None = None,
    scanned: Iterable[tuple[int, int]] = (),
) -> "Text":
    cells = compute_range_strip_cells(
        segments, total_frames, width,
        current=current, scanned=scanned,
    )
    text = Text()
    for ch, style in cells:
        text.append(ch, style=style)
    return text


# ── Reporter protocol ────────────────────────────────────────────


class ProgressReporter(Protocol):
    """Semantic progress/status event sink.

    Reporter methods must be cheap (called per-frame in hot paths)
    and side-effect-safe; concrete implementations absorb exceptions
    internally so UI issues never interrupt encode/decode.
    """

    # Generic
    def info(self, message: str) -> None: ...
    def warn(self, message: str) -> None: ...
    def error(self, message: str) -> None: ...
    def debug(self, message: str) -> None: ...
    def close(self) -> None: ...

    # Decode
    def probe_start(self) -> None: ...
    def probe_update(self, *, scanned: int, total: int,
                     detect: float, phase: str) -> None: ...
    def probe_done(self, *, sample: int, detect: float,
                   repeat: float,
                   crop_reduction: float | None,
                   observed: int | None = None,
                   total_probed: int | None = None,
                   max_dim: int | None = None) -> None: ...

    def scan_start(self, *, total_frames: int,
                   total_blocks: int | None = None) -> None: ...
    def scan_update(self, *, video_pct: float, hit_window: float,
                    file_pct: float,
                    recovered: object,
                    k: int | None) -> None: ...
    def scan_done(self) -> None: ...

    def recover_start(self, *, level: str,
                      segments: Sequence[tuple[int, int]],
                      total_frames: int) -> None: ...
    def recover_update(self, *, progress_pct: float, hit_window: float,
                       file_pct: float, recovered: object,
                       k: int | None,
                       current_range: tuple[int, int] | None) -> None: ...
    def recover_done(self) -> None: ...

    def ge_start(self, *, stage: str, recovered: int, k: int) -> None: ...
    def ge_done(self, *, success: bool, recovered: int, k: int) -> None: ...

    def save_done(self, *, output_path: str, bytes_written: int) -> None: ...

    # Encode
    def encode_start(self, *, duration_sec: float, fps: int,
                     qr_version: int, mode: str,
                     overhead: float) -> None: ...
    def encode_update(self, *, progress_pct: float,
                      speed_fps: float,
                      eta_sec: float) -> None: ...
    def encode_done(self, *, output_path: str,
                    size_bytes: int) -> None: ...

    # Calibrate
    def calibrate_generate_start(self, *, preset: str,
                                 total_frames: int) -> None: ...
    def calibrate_generate_update(self, *,
                                  progress_pct: float) -> None: ...
    def calibrate_generate_done(self, *,
                                output_path: str | None) -> None: ...
    def calibrate_analyze_start(self, *,
                                total_frames: int) -> None: ...
    def calibrate_analyze_update(self, *, progress_pct: float,
                                 segment: str) -> None: ...
    def calibrate_analyze_done(self) -> None: ...


# ── Helpers ──────────────────────────────────────────────────────


def _fmt_duration(seconds: float) -> str:
    if seconds is None or seconds != seconds or seconds < 0:
        return "--:--"
    seconds = int(round(seconds))
    if seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m:02d}:{s:02d}"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{s:02d}"


def _fmt_size(n: int) -> str:
    if n is None or n < 0:
        return "?"
    units = ("B", "KB", "MB", "GB", "TB")
    i = 0
    x = float(n)
    while x >= 1024 and i < len(units) - 1:
        x /= 1024
        i += 1
    if i == 0:
        return f"{int(x)} {units[i]}"
    return f"{x:.1f} {units[i]}"


def _fmt_pct(x: float) -> str:
    return f"{max(0.0, min(100.0, x)):.1f}%"


_STATUS_LABEL_WIDTH = 8


def _pad_status_label(label: str) -> str:
    """Return a fixed-width left-aligned label for status rows."""
    return f"{label:<{_STATUS_LABEL_WIDTH}}"


def _pad_stacked_status_label(label: str) -> str:
    """Match the extra inter-column gap Rich inserts after progress labels."""
    return _pad_status_label(label) + " "


def _log_escape(value: object) -> str:
    """Escape a value for ``key=value`` log output."""
    s = str(value)
    if not s:
        return '""'
    if any(c in s for c in (" ", "=", '"', "\t")):
        s = s.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{s}"'
    return s


# ── Quiet reporter ───────────────────────────────────────────────


class QuietReporter:
    """Emits nothing but errors and one final success line."""

    def __init__(self, stream=None):
        self._stream = stream if stream is not None else sys.stderr

    def _write(self, text: str) -> None:
        try:
            self._stream.write(text)
            if not text.endswith("\n"):
                self._stream.write("\n")
            self._stream.flush()
        except Exception:
            pass

    # Generic ------------------------------------------------------
    def info(self, message: str) -> None:  # pragma: no cover — silent
        return

    def warn(self, message: str) -> None:
        self._write(f"Warning: {message}")

    def error(self, message: str) -> None:
        self._write(f"Error: {message}")

    def debug(self, message: str) -> None:  # pragma: no cover — silent
        return

    def close(self) -> None:  # pragma: no cover — nothing to close
        return

    # Decode -------------------------------------------------------
    def probe_start(self) -> None: return
    def probe_update(self, **_kw) -> None: return
    def probe_done(self, **_kw) -> None: return
    def scan_start(self, **_kw) -> None: return
    def scan_update(self, **_kw) -> None: return
    def scan_done(self) -> None: return
    def recover_start(self, **_kw) -> None: return
    def recover_update(self, **_kw) -> None: return
    def recover_done(self) -> None: return
    def ge_start(self, **_kw) -> None: return
    def ge_done(self, **_kw) -> None: return

    def save_done(self, *, output_path: str, bytes_written: int) -> None:
        self._write(f"Saved: {output_path} ({_fmt_size(bytes_written)})")

    # Encode -------------------------------------------------------
    def encode_start(self, **_kw) -> None: return
    def encode_update(self, **_kw) -> None: return

    def encode_done(self, *, output_path: str, size_bytes: int) -> None:
        self._write(f"Encoded: {output_path} ({_fmt_size(size_bytes)})")

    # Calibrate ----------------------------------------------------
    def calibrate_generate_start(self, **_kw) -> None: return
    def calibrate_generate_update(self, **_kw) -> None: return
    def calibrate_generate_done(self, **_kw) -> None: return
    def calibrate_analyze_start(self, **_kw) -> None: return
    def calibrate_analyze_update(self, **_kw) -> None: return
    def calibrate_analyze_done(self) -> None: return


# ── Log reporter (key=value) ─────────────────────────────────────


@dataclass
class _ThrottleState:
    last_ts: float = 0.0
    last_pct: float = -1.0


class LogReporter:
    """Append-only ``key=value`` line log.

    Throttles per-frame updates to at most once every 2s or every 5%
    progress delta (whichever comes first).  ``phase=...
    status=start|done`` events always emit.  In ``verbose`` mode the
    throttle is relaxed (min 0.5s) and ``map`` / ``debug`` keys are
    included.
    """

    def __init__(self, stream=None, *, verbose: bool = False,
                 pct_step: float = 5.0,
                 min_interval_sec: float = 2.0):
        self._stream = stream if stream is not None else sys.stderr
        self._verbose = verbose
        self._pct_step = pct_step
        self._min_interval = 0.5 if verbose else min_interval_sec
        self._state: dict[str, _ThrottleState] = {}

    # ── internal helpers ─────────────────────────────────────
    def _timestamp(self) -> str:
        return time.strftime("%H:%M:%S", time.localtime())

    def _write_line(self, **fields) -> None:
        try:
            parts = [f"{k}={_log_escape(v)}"
                     for k, v in fields.items() if v is not None]
            line = f"[{self._timestamp()}] " + " ".join(parts)
            self._stream.write(line)
            if not line.endswith("\n"):
                self._stream.write("\n")
            self._stream.flush()
        except Exception:
            pass

    def _should_emit(self, key: str, pct: float) -> bool:
        now = time.monotonic()
        state = self._state.setdefault(key, _ThrottleState())
        if state.last_pct < 0:
            state.last_ts = now
            state.last_pct = pct
            return True
        if abs(pct - state.last_pct) >= self._pct_step:
            state.last_ts = now
            state.last_pct = pct
            return True
        if (now - state.last_ts) >= self._min_interval:
            state.last_ts = now
            state.last_pct = pct
            return True
        return False

    # ── generic ───────────────────────────────────────────────
    def info(self, message: str) -> None:
        self._write_line(event="info", msg=message)

    def warn(self, message: str) -> None:
        self._write_line(event="warn", msg=message)

    def error(self, message: str) -> None:
        self._write_line(event="error", msg=message)

    def debug(self, message: str) -> None:
        if self._verbose:
            self._write_line(event="debug", msg=message)

    def close(self) -> None:
        return

    # ── decode ────────────────────────────────────────────────
    def probe_start(self) -> None:
        self._write_line(phase="probe", status="start")

    def probe_update(self, *, scanned: int, total: int,
                     detect: float, phase: str) -> None:
        if not self._should_emit("probe", scanned / total * 100 if total else 0):
            return
        fields: dict = {"phase": "probe", "status": phase,
                        "scanned": scanned, "total": total}
        if phase == "scanning":
            fields["detect"] = f"{detect * 100:.0f}%"
        self._write_line(**fields)

    def probe_done(self, *, sample: int, detect: float, repeat: float,
                   crop_reduction: float | None,
                   observed: int | None = None,
                   total_probed: int | None = None,
                   max_dim: int | None = None) -> None:
        fields = {
            "phase": "probe",
            "status": "done",
            "sample": sample,
            "detect": f"{detect * 100:.0f}%",
            "repeat": f"{repeat:.1f}",
        }
        if crop_reduction is None:
            fields["crop_reduction"] = "off"
        else:
            fields["crop_reduction"] = f"{crop_reduction * 100:.0f}%"
        if observed is not None:
            fields["observed"] = observed
        if total_probed is not None:
            fields["total_probed"] = total_probed
        if max_dim is not None:
            fields["max_dim"] = f"{max_dim}px"
        self._write_line(**fields)

    def scan_start(self, *, total_frames: int,
                   total_blocks: int | None = None) -> None:
        fields = {"phase": "scan", "status": "start",
                  "total_frames": total_frames}
        if total_blocks is not None:
            fields["total_blocks"] = total_blocks
        self._write_line(**fields)
        self._state.pop("scan", None)

    def scan_update(self, *, video_pct: float, hit_window: float,
                    file_pct: float, recovered: object,
                    k: int | None) -> None:
        if not self._should_emit("scan", video_pct):
            return
        fields = {
            "phase": "scan",
            "video": _fmt_pct(video_pct),
            "file": _fmt_pct(file_pct),
            "hit_window": f"{hit_window * 100:.0f}%",
        }
        if self._verbose and k and k > 0:
            try:
                term_cols = os.get_terminal_size().columns
            except (OSError, ValueError):
                term_cols = 80
            width = min(96, max(16, term_cols - 24))
            fields["map"] = render_block_map_plain(recovered, k, width)
        self._write_line(**fields)

    def scan_done(self) -> None:
        self._write_line(phase="scan", status="done")

    def recover_start(self, *, level: str,
                      segments: Sequence[tuple[int, int]],
                      total_frames: int) -> None:
        self._write_line(phase="recover", status="start",
                         level=level, segments=len(segments),
                         total_frames=total_frames)
        self._state.pop("recover", None)

    def recover_update(self, *, progress_pct: float, hit_window: float,
                       file_pct: float, recovered: object,
                       k: int | None,
                       current_range: tuple[int, int] | None) -> None:
        if not self._should_emit("recover", progress_pct):
            return
        fields = {
            "phase": "recover",
            "progress": _fmt_pct(progress_pct),
            "file": _fmt_pct(file_pct),
            "hit_window": f"{hit_window * 100:.0f}%",
        }
        if self._verbose and k and k > 0:
            fields["map"] = render_block_map_plain(recovered, k, 48)
        self._write_line(**fields)

    def recover_done(self) -> None:
        self._write_line(phase="recover", status="done")

    def ge_start(self, *, stage: str, recovered: int, k: int) -> None:
        self._write_line(phase="ge", status="start", stage=stage,
                         recovered=recovered, total=k)

    def ge_done(self, *, success: bool, recovered: int, k: int) -> None:
        self._write_line(phase="ge", status="done",
                         result="success" if success else "incomplete",
                         recovered=recovered, total=k)

    def save_done(self, *, output_path: str, bytes_written: int) -> None:
        self._write_line(phase="save", status="done",
                         output=output_path, bytes=bytes_written)

    # ── encode ────────────────────────────────────────────────
    def encode_start(self, *, duration_sec: float, fps: int,
                     qr_version: int, mode: str, overhead: float) -> None:
        self._write_line(phase="encode", status="start",
                         duration=f"{duration_sec:.1f}s",
                         fps=fps, qr=f"v{qr_version}",
                         mode=mode, overhead=f"{overhead:.1f}x")
        self._state.pop("encode", None)

    def encode_update(self, *, progress_pct: float, speed_fps: float,
                      eta_sec: float) -> None:
        if not self._should_emit("encode", progress_pct):
            return
        self._write_line(phase="encode",
                         progress=_fmt_pct(progress_pct),
                         speed=f"{speed_fps:.1f}fps",
                         eta=_fmt_duration(eta_sec))

    def encode_done(self, *, output_path: str, size_bytes: int) -> None:
        self._write_line(phase="encode", status="done",
                         output=output_path, size=_fmt_size(size_bytes))

    # Calibrate
    def calibrate_generate_start(self, *, preset: str,
                                 total_frames: int) -> None:
        self._write_line(phase="calibrate-generate", status="start",
                         preset=preset, total_frames=total_frames)

    def calibrate_generate_update(self, *, progress_pct: float) -> None:
        if not self._should_emit("calibrate-generate", progress_pct):
            return
        self._write_line(phase="calibrate-generate",
                         progress=_fmt_pct(progress_pct))

    def calibrate_generate_done(self, *,
                                output_path: str | None) -> None:
        self._write_line(phase="calibrate-generate", status="done",
                         output=output_path or "(display)")

    def calibrate_analyze_start(self, *, total_frames: int) -> None:
        self._write_line(phase="calibrate-analyze", status="start",
                         total_frames=total_frames)

    def calibrate_analyze_update(self, *, progress_pct: float,
                                 segment: str) -> None:
        if not self._should_emit("calibrate-analyze", progress_pct):
            return
        self._write_line(phase="calibrate-analyze",
                         progress=_fmt_pct(progress_pct),
                         segment=segment)

    def calibrate_analyze_done(self) -> None:
        self._write_line(phase="calibrate-analyze", status="done")


# ── Rich reporter ────────────────────────────────────────────────


if _RICH_AVAILABLE:

    def _task_pct(task) -> str:
        total = task.total
        if total is None or total <= 0:
            return " --%"
        pct = max(0.0, min(100.0, task.completed / total * 100.0))
        return f"{pct:3.0f}%"

    # ── Detect-rate colour gradient ──────────────────────────────

    # Colour anchor points for the detect-rate indicator.
    # The gradient interpolates linearly between adjacent anchors:
    #
    #   0–50 %  : red       (255, 70, 70)   — detection too low
    #   50–60 % : red→orange interpolation   — danger zone
    #   60–70 % : orange→yellow→green        — marginal
    #   70–80 % : transitioning to green     — good
    #   80–100% : green     (0, 200, 80)     — perfect
    #
    _DET_GRADIENT_ANCHORS: list[tuple[float, tuple[int, int, int]]] = [
        (0.00, (255, 70, 70)),    # red
        (0.50, (255, 70, 70)),    # still red at 50%
        (0.60, (255, 165, 0)),    # orange
        (0.70, (220, 220, 0)),    # yellow
        (0.80, (0, 200, 80)),     # green
        (1.00, (0, 200, 80)),     # still green at 100%
    ]

    # Discrete named-colour fallback for terminals without truecolor
    # (standard 16-color or 256-color that may not render RGB well).
    _DET_DISCRETE_STYLES: list[tuple[float, str]] = [
        (0.50, "bold red"),
        (0.60, "bold bright_red"),
        (0.70, "bold yellow"),
        (0.80, "bold green"),
    ]

    def _lerp_rgb(
        c1: tuple[int, int, int],
        c2: tuple[int, int, int],
        t: float,
    ) -> tuple[int, int, int]:
        """Linearly interpolate between two RGB colours."""
        return (
            int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t),
        )

    def _detect_rate_style(hit: float, truecolor: bool = True) -> _RichStyle:
        """Return a Rich Style for the detect-rate value.

        When *truecolor* is True, produces a smooth RGB gradient keyed
        to the anchor points above.  When False, falls back to discrete
        named colours that render correctly on any terminal.
        """
        hit = max(0.0, min(1.0, hit))

        if not truecolor:
            # Discrete fallback: walk thresholds from low to high.
            style_name = "bold green"
            for threshold, name in _DET_DISCRETE_STYLES:
                if hit < threshold:
                    style_name = name
                    break
            return _RichStyle.parse(style_name)

        # Truecolor gradient: find the two surrounding anchors and
        # interpolate between them.
        anchors = _DET_GRADIENT_ANCHORS
        # Clamp to the range of anchors.
        if hit <= anchors[0][0]:
            r, g, b = anchors[0][1]
        elif hit >= anchors[-1][0]:
            r, g, b = anchors[-1][1]
        else:
            # Find segment.
            for i in range(len(anchors) - 1):
                lo_pct, lo_col = anchors[i]
                hi_pct, hi_col = anchors[i + 1]
                if lo_pct <= hit <= hi_pct:
                    span = hi_pct - lo_pct
                    t = (hit - lo_pct) / span if span > 0 else 0.0
                    r, g, b = _lerp_rgb(lo_col, hi_col, t)
                    break
            else:
                r, g, b = anchors[-1][1]
        return _RichStyle(color=_RichColor.from_rgb(r, g, b), bold=True)

    def _detect_rate_markup(hit: float, truecolor: bool = True) -> str:
        """Return a Rich markup string for the detect-rate percentage.

        Used in contexts where the description is a plain string with
        embedded Rich markup (e.g. probe spinner TextColumn).
        """
        hit = max(0.0, min(1.0, hit))
        pct_text = f"{hit * 100:.0f}%"

        if not truecolor:
            if hit < 0.50:
                return f"[bold red]{pct_text}[/bold red]"
            elif hit < 0.60:
                return f"[bold bright_red]{pct_text}[/bold bright_red]"
            elif hit < 0.70:
                return f"[bold yellow]{pct_text}[/bold yellow]"
            elif hit < 0.80:
                return f"[bold green]{pct_text}[/bold green]"
            else:
                return f"[bold green]{pct_text}[/bold green]"

        # Truecolor: compute RGB via gradient and emit as markup.
        anchors = _DET_GRADIENT_ANCHORS
        if hit <= anchors[0][0]:
            r, g, b = anchors[0][1]
        elif hit >= anchors[-1][0]:
            r, g, b = anchors[-1][1]
        else:
            for i in range(len(anchors) - 1):
                lo_pct, lo_col = anchors[i]
                hi_pct, hi_col = anchors[i + 1]
                if lo_pct <= hit <= hi_pct:
                    span = hi_pct - lo_pct
                    t = (hit - lo_pct) / span if span > 0 else 0.0
                    r, g, b = _lerp_rgb(lo_col, hi_col, t)
                    break
            else:
                r, g, b = anchors[-1][1]
        return f"[bold rgb({r},{g},{b})]{pct_text}[/bold rgb({r},{g},{b})]"


    class _DetectStatsColumn(ProgressColumn):
        """Show percent + detection/speed/ETA with a single-space gap.

        The bracketed content is built from whichever ``task.fields``
        are available, so the same column serves both Scan (fps + ETA
        once calibrated) and Recover (detect only).
        """

        def render(self, task):  # type: ignore[override]
            fields = task.fields or {}
            hit = fields.get("hit")
            fps = fields.get("fps")
            eta = fields.get("eta")
            parts: list[str] = []
            if hit is not None:
                parts.append(f"detect {hit * 100:.0f}%")
            if fps is not None and fps > 0:
                parts.append(f"{fps:.1f} fps")
            if eta is not None:
                parts.append(f"ETA {_fmt_duration(eta)}")
            pct = _task_pct(task)
            if not parts:
                return Text(pct, style="bright_cyan")
            return Text(
                f"{pct} ({' · '.join(parts)})",
                style="bright_cyan",
            )


    class _EncodeStatsColumn(ProgressColumn):
        """Show percent + fps/ETA with a single-space gap."""

        def render(self, task):  # type: ignore[override]
            fields = task.fields or {}
            fps = fields.get("fps")
            eta_override = fields.get("eta_override")
            parts: list[str] = []
            if fps is not None:
                parts.append(f"{fps:.1f} fps")
            if eta_override is not None:
                parts.append(f"ETA {_fmt_duration(eta_override)}")
            pct = _task_pct(task)
            if not parts:
                return Text(pct, style="bright_magenta")
            return Text(
                f"{pct} ({', '.join(parts)})",
                style="bright_magenta",
            )


    # ── Decode-phase shared columns (Scan + File rows) ───────────
    #
    # Scan and File live in the same :class:`Progress` so Rich
    # lays out their columns (label / bar / stats) in a shared
    # table and guarantees visual alignment.  Each task carries a
    # ``kind`` field ("scan" / "file") that the custom columns
    # dispatch on.


    def _render_hit_colored_bar(
        text: "Text",
        hit_history: list[tuple[float, float]],
        cell_count: int,
        char: str,
        bar_pct: float = 100.0,
    ) -> None:
        """Append *cell_count* characters to *text*, each coloured by
        the detect rate at the corresponding position in the bar.

        *hit_history* is a list of ``(video_pct, hit_rate)`` samples.
        Each bar cell is mapped to a video position and the nearest
        history sample's hit_rate determines its colour.
        """
        if not hit_history or cell_count <= 0:
            return
        for i in range(cell_count):
            # Map cell position to video percentage.
            cell_pct = (i + 0.5) / cell_count * bar_pct
            # Find the nearest history sample by video_pct.
            # Binary-search-like: history is roughly sorted by pct.
            best_hit = hit_history[-1][1]
            best_dist = float("inf")
            for h_pct, h_hit in hit_history:
                dist = abs(h_pct - cell_pct)
                if dist < best_dist:
                    best_dist = dist
                    best_hit = h_hit
                elif h_pct > cell_pct:
                    break  # history is sorted, no need to look further
            style = _detect_rate_style(best_hit, truecolor=True)
            text.append(char, style=style)


    def _render_decode_bar(task, width: int, truecolor: bool = False) -> "Text":
        """Render the decode bar for a single row.

        Scan rows get a Rich-style thin bar (``━``) with a bright
        tip glyph so the bar still shows motion in the first
        percent of a long video.

        File rows render the qBittorrent-style block map directly:
        one cell per roughly ``k / width`` source blocks, coloured
        by recovery density using either the smooth truecolor
        gradient or the discrete named-colour tiers.  No overlay /
        tip glyph — the block map alone is the progress indicator;
        the accompanying stats cell (``N/K blocks``) carries the
        precise counter.
        """
        kind = (task.fields or {}).get("kind", "scan")
        total = task.total or 1
        pct = max(0.0, min(100.0, task.completed / total * 100.0))
        if kind == "file":
            recovered = (task.fields or {}).get("recovered") or {}
            k = (task.fields or {}).get("k") or 0
            text = Text()
            if k > 0 and width > 0:
                cells = compute_block_map_cells(
                    recovered, k, width, truecolor=truecolor)
                for ch, style, _density in cells:
                    text.append(ch, style=style)
            else:
                # No graph yet — faint placeholder of the right
                # width so Scan/File stay aligned before the
                # decoder has seen its first QR.
                text.append("░" * max(0, width), style="grey35")
            return text
        # Scan / Recover (kind == "scan")
        tip_style = (task.fields or {}).get(
            "bar_tip_style", "bright_cyan")
        body_style = (task.fields or {}).get(
            "bar_body_style", "cyan")
        done_style = (task.fields or {}).get(
            "bar_done_style", "bright_cyan")
        hit_history = (task.fields or {}).get("hit_history")
        text = Text()
        if width <= 0:
            return text
        if pct >= 100.0:
            if hit_history and truecolor:
                _render_hit_colored_bar(text, hit_history, width, "━")
            else:
                text.append("━" * width, style=done_style)
            return text
        filled = pct / 100.0 * width
        full_cells = int(filled)
        frac = filled - full_cells
        if full_cells > 0:
            if hit_history and truecolor:
                _render_hit_colored_bar(
                    text, hit_history, full_cells, "━",
                    bar_pct=pct)
            else:
                text.append("━" * full_cells, style=body_style)
        if full_cells < width:
            # Tip glyph — use current detect rate colour if available.
            if hit_history and truecolor:
                current_hit = hit_history[-1][1] if hit_history else 0.0
                tip_s = _detect_rate_style(current_hit, truecolor=True)
                if frac > 0.5:
                    text.append("╸", style=tip_s)
                else:
                    text.append("╺", style=tip_s)
            else:
                if frac > 0.5:
                    text.append("╸", style=tip_style)
                else:
                    text.append("╺", style=tip_style)
            remaining = width - full_cells - 1
            if remaining > 0:
                text.append("━" * remaining, style="grey23")
        return text


    class _DynamicDecodeBar:
        """Bar renderable that fills whichever width Rich allots it.

        Implementing :class:`rich.console.ConsoleRenderable` lets
        us read ``options.max_width`` at render time and fill the
        entire bar column, so Scan's right edge reaches the
        terminal edge regardless of how wide the stats text
        happens to be on any given frame.  Both Scan and File use
        the same renderable class sharing the same column, so
        their left- and right-edges are aligned by construction.
        """

        __slots__ = ("_task", "_min_width", "_max_width", "_truecolor")

        def __init__(self, task, min_width: int, max_width: int,
                     truecolor: bool = False):
            self._task = task
            self._min_width = max(1, int(min_width))
            self._max_width = max(self._min_width, int(max_width))
            self._truecolor = truecolor

        def __rich_console__(self, console, options):
            allotted = options.max_width
            if allotted is None or allotted <= 0:
                allotted = self._min_width
            width = max(self._min_width,
                        min(self._max_width, int(allotted)))
            yield _render_decode_bar(self._task, width, self._truecolor)

        def __rich_measure__(self, console, options):
            from rich.measure import Measurement
            return Measurement(self._min_width, self._max_width)


    class _DecodeLabelColumn(ProgressColumn):
        """Render the left-hand 'Scan' / 'File' label."""

        def render(self, task):  # type: ignore[override]
            fields = task.fields or {}
            kind = fields.get("kind", "scan")
            label = fields.get("label") or kind.capitalize()
            style = fields.get("label_style", "bold cyan")
            return Text(_pad_status_label(label), style=style)


    class _DecodeBarColumn(ProgressColumn):
        """Shared expanding bar column (Scan + File aligned).

        The underlying :class:`_DynamicDecodeBar` renderable reads
        its allotted width at render time, so when the stats cell
        shortens (e.g. ETA hides early in the scan) the bar grows
        to fill the right edge.  ``min_width`` / ``max_width``
        bound the bar so it still has "breathing room" columns on
        very narrow terminals and doesn't spam a 1000-cell block
        map on very wide ones.
        """

        def __init__(self, min_width: int = 24, max_width: int = 200,
                     truecolor: bool = False):
            super().__init__(
                table_column=Column(ratio=1, no_wrap=True),
            )
            self._min_width = max(1, int(min_width))
            self._max_width = max(self._min_width, int(max_width))
            self._truecolor = truecolor

        def render(self, task):  # type: ignore[override]
            return _DynamicDecodeBar(
                task,
                min_width=self._min_width,
                max_width=self._max_width,
                truecolor=self._truecolor,
            )


    class _DecodeStatsColumn(ProgressColumn):
        """Right-hand stats column.

        Scan:  ``24.0% (ETA 00:42, det 74%)``
        File:  ``24.0%  123/512 blocks``

        The Scan bracket keeps only user-actionable metrics:
        ETA (what people actually watch) and the detection rate
        (a diagnostic flag — sudden drops usually mean the source
        video hit a troublesome segment).  fps is intentionally
        omitted: it's a derived number that rarely drives a
        decision, and cutting it frees horizontal budget for the
        block-map.  The fps value is still computed internally
        because it's the EWMA estimator that feeds ETA; it just
        isn't surfaced.
        """

        def __init__(self, *, truecolor: bool = True):
            super().__init__()
            self._truecolor = truecolor

        def render(self, task):  # type: ignore[override]
            fields = task.fields or {}
            kind = fields.get("kind", "scan")
            total = task.total or 1
            pct = max(0.0, min(100.0, task.completed / total * 100.0))
            pct_str = f"{pct:5.1f}%"
            if kind == "file":
                k = fields.get("k") or 0
                recovered = fields.get("recovered") or {}
                if isinstance(recovered, dict):
                    n = len(recovered)
                elif hasattr(recovered, "__len__"):
                    try:
                        n = len(recovered)  # type: ignore[arg-type]
                    except Exception:
                        n = 0
                else:
                    n = 0
                if k > 0:
                    return Text(
                        f"{pct_str}  {n}/{k} blocks",
                        style="bold",
                    )
                return Text(pct_str, style="bold")
            # Scan / Recover — ETA first, then detect rate.  fps
            # is deliberately dropped: it's a non-actionable
            # derived metric and the space is better spent on the
            # bar itself.
            hit = fields.get("hit")
            eta = fields.get("eta")
            style = fields.get("stats_style", "bright_cyan")
            if hit is None and eta is None:
                return Text(pct_str, style=style)
            # Build a composite Text so detect-rate gets its own
            # colour while pct / ETA keep the base style.
            result = Text(pct_str, style=style)
            result.append(" (", style=style)
            first = True
            if eta is not None:
                result.append(f"ETA {_fmt_duration(eta)}", style=style)
                first = False
            if hit is not None:
                if not first:
                    result.append(", ", style=style)
                # Colour the detect-rate value by magnitude:
                #   ≥ 70 %  → green  (healthy, efficient decode)
                #   30–69 % → yellow (sub-optimal, needs more frames)
                #   < 30 %  → red    (unreliable detection)
                det_style = _detect_rate_style(hit, self._truecolor)
                # Reserve a 3-digit slot ("  9%" / " 83%" / "100%")
                # so the stats cell has a constant width.  Without
                # this the bar column gets re-laid-out every time
                # the detect-rate digit count changes and the
                # whole row appears to twitch.
                result.append("det ", style=style)
                result.append(f"{hit * 100:>3.0f}%", style=det_style)
            result.append(")", style=style)
            return result


else:  # pragma: no cover — exercised only when rich is unavailable
    _DetectStatsColumn = _EncodeStatsColumn = None  # type: ignore[assignment]
    _DecodeLabelColumn = _DecodeBarColumn = None  # type: ignore[assignment]
    _DecodeStatsColumn = None  # type: ignore[assignment]


class RichReporter:
    """Animated Rich-driven reporter (interactive / verbose-on-tty).

    Scan / Recover use a two-row layout (``Scan`` / ``File`` or
    ``Recover`` / ``File``) sharing the same Rich :class:`Progress`
    table so the label / bar / stats columns line up visually.  The
    File row is the coloured block-map rendered as a fixed-width
    bar; its stats column shows ``pct  N/K blocks`` so the user can
    see exactly how many source blocks have been recovered.  The
    Scan row's stats column adds ``fps`` and ``ETA`` once the
    estimate has stabilised.  Targeted recovery additionally
    renders the segment strip above the two rows.
    """

    _MAP_MIN_WIDTH = 24
    # Upper bound on the rendered bar width.  Must be generous
    # enough that on an ultra-wide terminal the bar still reaches
    # the right edge (≈ term_width − label − stats).  200 covers
    # 4K terminals; below that we let the expanding column clamp
    # us naturally.  Do NOT tighten this without checking that
    # the Scan row still looks "full-width" on normal (~120-col)
    # terminals — the previous 80-cell cap caused a visible gap
    # between the bar and the stats cell.
    _MAP_MAX_WIDTH = 200
    _RANGE_LABEL = _pad_stacked_status_label("Range")
    # Rough width budget (chars) reserved on the right for the
    # stats column.  A full Scan line looks like
    # ``100.0% (ETA 00:08, det 93%)`` (~27 chars) which fits
    # within this budget on an 80-column terminal and leaves
    # more room for the shared bar.
    _STATS_WIDTH = 28
    # Smoothing constant for the exponentially-weighted fps
    # estimator used by the Scan ETA.  0.3 balances responsiveness
    # against jitter on short bursty scans.
    _FPS_EWMA_ALPHA = 0.3

    def __init__(self, *, verbose: bool = False, stream=None):
        if not _RICH_AVAILABLE:
            raise RuntimeError("rich is required for RichReporter; "
                               "install with `pip install rich`.")
        self._console = Console(
            file=stream if stream is not None else sys.stderr,
            stderr=stream is None,
            highlight=False,
            soft_wrap=False,
        )
        self._truecolor = (self._console.color_system == "truecolor")
        self._verbose = verbose
        self._live: Live | None = None
        self._progress: Progress | None = None
        # Scan / Recover is the "driver" task; File is the
        # companion row that reflects decoder state derived from
        # the same event stream.
        self._task_id: int | None = None
        self._file_task_id: int | None = None
        # Cached range-strip overlay (Recover only).
        self._range_map_text: Text | None = None
        # Recover state
        self._recover_segments: Sequence[tuple[int, int]] = ()
        self._recover_total_frames: int = 0
        self._recover_scanned: list[tuple[int, int]] = []
        self._probe_spinner_progress: Progress | None = None
        self._probe_task_id: int | None = None
        self._ge_spinner_progress: Progress | None = None
        self._ge_task_id: int | None = None
        # Scan ETA/fps timing state.
        self._scan_started_at: float = 0.0
        self._scan_total_frames: int = 0
        self._scan_last_fps: float = 0.0
        self._scan_last_emit_ts: float = 0.0

    # ── internal ──────────────────────────────────────────────
    def _terminal_width(self) -> int:
        """Best-effort console width (falls back to 80)."""
        try:
            return self._console.size.width
        except Exception:
            return 80

    def _reset_scan_timing(self) -> None:
        self._scan_started_at = 0.0
        self._scan_total_frames = 0
        self._scan_last_fps = 0.0
        self._scan_last_emit_ts = 0.0

    def _estimate_scan_fps_eta(
        self, video_pct: float,
    ) -> tuple[float | None, float | None]:
        """Return smoothed ``(fps, eta_sec)`` for the Scan row.

        Uses wall-clock elapsed time against ``video_pct`` so the
        estimator is robust even when the decoder skips frames
        (sample_rate > 1).  Suppresses output for the first second
        / first 1 % to avoid wildly unstable early estimates.
        """
        if self._scan_total_frames <= 0:
            return None, None
        now = time.monotonic()
        elapsed = max(0.0, now - self._scan_started_at)
        if elapsed < 1.0 or video_pct <= 1.0:
            return None, None
        done_frames = self._scan_total_frames * video_pct / 100.0
        inst_fps = done_frames / elapsed if elapsed > 0 else 0.0
        if self._scan_last_fps <= 0:
            self._scan_last_fps = inst_fps
        else:
            alpha = self._FPS_EWMA_ALPHA
            self._scan_last_fps = (
                alpha * inst_fps + (1 - alpha) * self._scan_last_fps
            )
        remaining = max(0.0,
                        self._scan_total_frames - done_frames)
        if self._scan_last_fps > 0:
            eta = remaining / self._scan_last_fps
        else:
            eta = None
        return self._scan_last_fps, eta

    def _stop_live(self) -> None:
        if self._live is not None:
            try:
                self._live.stop()
            except Exception:
                pass
            self._live = None
        self._progress = None
        self._task_id = None
        self._file_task_id = None
        self._range_map_text = None
        self._reset_scan_timing()

    def _build_group(self) -> Group:
        parts: list[object] = []
        if self._range_map_text is not None:
            range_line = Text()
            range_line.append(self._RANGE_LABEL, style="bold")
            range_line.append_text(self._range_map_text)
            parts.append(range_line)
        if self._progress is not None:
            parts.append(self._progress)
        return Group(*parts)

    def _refresh(self) -> None:
        if self._live is None:
            return
        try:
            self._live.update(self._build_group())
        except Exception:
            pass

    def _build_decode_progress(self) -> Progress:
        """Create a Progress configured for the Scan/File layout.

        The bar column is configured to expand into whatever
        horizontal space the stats cell doesn't use, so the bar
        right-edge reaches the terminal edge on every frame.
        """
        return Progress(
            _DecodeLabelColumn(),
            _DecodeBarColumn(
                min_width=self._MAP_MIN_WIDTH,
                max_width=self._MAP_MAX_WIDTH,
                truecolor=self._truecolor,
            ),
            _DecodeStatsColumn(truecolor=self._truecolor),
            console=self._console,
            transient=False,
            expand=True,
        )

    # ── generic ───────────────────────────────────────────────
    def info(self, message: str) -> None:
        self._console.print(message)

    def warn(self, message: str) -> None:
        self._console.print(f"[yellow]Warning:[/yellow] {message}")

    def error(self, message: str) -> None:
        self._console.print(f"[bold red]Error:[/bold red] {message}")

    def debug(self, message: str) -> None:
        if self._verbose:
            self._console.log(f"[dim]{message}[/dim]")

    def close(self) -> None:
        self._stop_live()

    # ── decode: probe ────────────────────────────────────────
    def probe_start(self) -> None:
        self._stop_live()
        self._probe_spinner_progress = Progress(
            SpinnerColumn(style="cyan"),
            TextColumn(
                f"[bold cyan]{_pad_status_label('Probe')}[/bold cyan]"
            ),
            TextColumn("[cyan]{task.description}[/cyan]"),
            console=self._console,
            transient=True,
        )
        self._probe_task_id = self._probe_spinner_progress.add_task(
            "starting...", total=None)
        self._live = Live(
            self._probe_spinner_progress,
            console=self._console,
            refresh_per_second=12,
            transient=True,
        )
        self._live.start()

    def probe_update(self, *, scanned: int, total: int,
                     detect: float, phase: str) -> None:
        if self._probe_spinner_progress is None or self._probe_task_id is None:
            return
        if phase == "reading":
            desc = f"reading frames {scanned}/{total}"
        elif phase == "scanning":
            det_markup = _detect_rate_markup(detect, self._truecolor)
            desc = f"scanning {scanned}/{total}, detect {det_markup}"
        elif phase == "calibrating":
            desc = "calibrating"
        else:
            desc = phase
        try:
            self._probe_spinner_progress.update(
                self._probe_task_id, description=desc)
        except Exception:
            pass

    def probe_done(self, *, sample: int, detect: float, repeat: float,
                   crop_reduction: float | None,
                   observed: int | None = None,
                   total_probed: int | None = None,
                   max_dim: int | None = None) -> None:
        """Summarise the probe outcome and the derived decode plan.

        The output is split into two lines so the observed metrics
        ("what we saw") don't get visually mixed up with the plan
        parameters ("what we'll do"):

        .. code-block:: text

           Probe   ✓ observed 281/360 frames  detect 78%
           Plan    sample=1  repeat=2.5  crop=-43%  max_dim=1080px

        ``observed`` / ``total_probed`` are optional; when absent
        the first line degrades gracefully to just the detect rate.
        ``max_dim`` (the adaptive downscale target) is only shown
        when the probe produced a value.
        """
        self._stop_live()
        self._probe_spinner_progress = None
        self._probe_task_id = None

        # Line 1 — observations.
        obs_bits: list[str] = []
        if observed is not None and total_probed and total_probed > 0:
            obs_bits.append(
                f"observed "
                f"[bold]{observed}[/bold]/[bold]{total_probed}[/bold] frames"
            )
        elif observed is not None:
            obs_bits.append(f"observed [bold]{observed}[/bold] frames")
        obs_bits.append(
            f"detect {_detect_rate_markup(detect, self._truecolor)}"
        )
        self._console.print(
            f"[bold cyan]{_pad_status_label('Probe')}[/bold cyan] "
            f"[green]✓[/green]  " + "  ".join(obs_bits)
        )

        # Line 2 — plan parameters.
        if crop_reduction is None:
            crop_str = "crop=[dim]off[/dim]"
        else:
            crop_str = f"crop=[green]-{crop_reduction * 100:.0f}%[/green]"
        plan_bits = [
            f"sample=[bold]{sample}[/bold]",
            f"repeat=[bold]{repeat:.1f}[/bold]",
            crop_str,
        ]
        if max_dim is not None:
            plan_bits.append(f"max_dim=[bold]{max_dim}px[/bold]")
        self._console.print(
            f"[bold cyan]{_pad_status_label('Plan')}[/bold cyan]  "
            + "  ".join(plan_bits)
        )

    # ── decode: scan ──────────────────────────────────────────
    def scan_start(self, *, total_frames: int,
                   total_blocks: int | None = None) -> None:
        self._stop_live()
        self._progress = self._build_decode_progress()
        self._task_id = self._progress.add_task(
            "scan",
            total=max(1, total_frames),
            kind="scan",
            label="Scan",
            label_style="bold cyan",
            stats_style="bright_cyan",
            bar_body_style="cyan",
            bar_tip_style="bright_cyan",
            bar_done_style="bright_cyan",
            hit=0.0,
            fps=None,
            eta=None,
        )
        self._file_task_id = self._progress.add_task(
            "file",
            total=100,
            kind="file",
            label="File",
            label_style="bold cyan",
            stats_style="bold",
            recovered={},
            k=total_blocks or 0,
        )
        self._scan_started_at = time.monotonic()
        self._scan_total_frames = max(1, total_frames)
        self._scan_last_fps = 0.0
        self._scan_last_emit_ts = 0.0
        self._hit_history: list[tuple[float, float]] = []  # (video_pct, hit_rate)
        self._live = Live(
            self._build_group(),
            console=self._console,
            refresh_per_second=12,
            transient=False,
        )
        self._live.start()

    def scan_update(self, *, video_pct: float, hit_window: float,
                    file_pct: float, recovered: object,
                    k: int | None) -> None:
        if (self._progress is None
                or self._task_id is None
                or self._file_task_id is None):
            return
        # Record detect-rate history for the coloured scan bar.
        self._hit_history.append((video_pct, hit_window))
        total = self._progress.tasks[self._task_id].total or 1
        completed = max(0.0, min(total, video_pct / 100.0 * total))
        fps, eta = self._estimate_scan_fps_eta(video_pct)
        try:
            self._progress.update(
                self._task_id,
                completed=completed,
                hit=hit_window,
                fps=fps,
                eta=eta,
                hit_history=self._hit_history,
            )
        except Exception:
            pass
        # File row — ``completed`` is a 0..100 percentage just so
        # the task carries a percent that matches ``file_pct``;
        # the bar itself paints from ``recovered`` / ``k`` via the
        # block-map, not from this number.
        file_completed = max(0.0, min(100.0, file_pct))
        try:
            self._progress.update(
                self._file_task_id,
                completed=file_completed,
                recovered=recovered or {},
                k=k or 0,
            )
        except Exception:
            pass
        self._refresh()

    def scan_done(self) -> None:
        if self._progress is not None and self._task_id is not None:
            try:
                total = self._progress.tasks[self._task_id].total or 1
                self._progress.update(self._task_id, completed=total)
            except Exception:
                pass
        self._stop_live()

    # ── decode: recover ──────────────────────────────────────
    def recover_start(self, *, level: str,
                      segments: Sequence[tuple[int, int]],
                      total_frames: int) -> None:
        self._stop_live()
        self._recover_segments = list(segments)
        self._recover_total_frames = max(1, total_frames)
        self._recover_scanned = []
        self._hit_history = []  # reset for recover phase
        self._progress = self._build_decode_progress()
        self._task_id = self._progress.add_task(
            "recover",
            total=1000,
            kind="scan",
            label="Recover",
            label_style="bold yellow",
            stats_style="bright_yellow",
            bar_body_style="yellow",
            bar_tip_style="bright_yellow",
            bar_done_style="bright_yellow",
            hit=0.0,
            fps=None,
            eta=None,
        )
        self._file_task_id = self._progress.add_task(
            "file",
            total=100,
            kind="file",
            label="File",
            label_style="bold cyan",
            stats_style="bold",
            recovered={},
            k=0,
        )
        # Range strip width mirrors the bar column — fall back to
        # a sensible middle ground since the expanding bar column
        # resolves its final width only at render time.
        range_width = max(self._MAP_MIN_WIDTH,
                          min(self._MAP_MAX_WIDTH,
                              self._terminal_width()
                              - _STATUS_LABEL_WIDTH
                              - self._STATS_WIDTH
                              - 4))
        self._range_map_text = render_range_strip_rich(
            self._recover_segments,
            self._recover_total_frames,
            range_width,
        )
        # Announce the active level so the user knows which
        # targeted-recovery strategy is running.
        self._console.print(
            f"[bold yellow]{_pad_status_label('Recover')}[/bold yellow] "
            f"[dim]level={level}  segments={len(self._recover_segments)}[/dim]"
        )
        self._live = Live(
            self._build_group(),
            console=self._console,
            refresh_per_second=12,
            transient=False,
        )
        self._live.start()

    def recover_update(self, *, progress_pct: float, hit_window: float,
                       file_pct: float, recovered: object,
                       k: int | None,
                       current_range: tuple[int, int] | None) -> None:
        if (self._progress is None
                or self._task_id is None
                or self._file_task_id is None):
            return
        self._hit_history.append((progress_pct, hit_window))
        try:
            self._progress.update(
                self._task_id,
                completed=max(0.0, min(1000.0, progress_pct * 10.0)),
                hit=hit_window,
                hit_history=self._hit_history,
            )
        except Exception:
            pass
        # Range strip — rebuild each update; it's cheap and the
        # current range pointer shifts regularly.
        range_width = max(self._MAP_MIN_WIDTH,
                          min(self._MAP_MAX_WIDTH,
                              self._terminal_width()
                              - _STATUS_LABEL_WIDTH
                              - self._STATS_WIDTH
                              - 4))
        self._range_map_text = render_range_strip_rich(
            self._recover_segments,
            self._recover_total_frames,
            range_width,
            current=current_range,
            scanned=self._recover_scanned,
        )
        try:
            self._progress.update(
                self._file_task_id,
                completed=max(0.0, min(100.0, file_pct)),
                recovered=recovered or {},
                k=k or 0,
            )
        except Exception:
            pass
        self._refresh()

    def recover_done(self) -> None:
        if self._progress is not None and self._task_id is not None:
            try:
                self._progress.update(self._task_id, completed=1000)
            except Exception:
                pass
        self._stop_live()

    # ── decode: GE rescue ─────────────────────────────────────
    def ge_start(self, *, stage: str, recovered: int, k: int) -> None:
        self._stop_live()
        self._ge_spinner_progress = Progress(
            SpinnerColumn(style="magenta"),
            TextColumn(
                f"[bold magenta]{_pad_status_label('GE')}[/bold magenta]"
            ),
            TextColumn("[magenta]{task.description}[/magenta]"),
            console=self._console,
            transient=True,
        )
        self._ge_task_id = self._ge_spinner_progress.add_task(
            f"solving stalled LT graph ({recovered}/{k} blocks)",
            total=None,
        )
        self._live = Live(
            self._ge_spinner_progress,
            console=self._console,
            refresh_per_second=12,
            transient=True,
        )
        self._live.start()

    def ge_done(self, *, success: bool, recovered: int, k: int) -> None:
        self._stop_live()
        self._ge_spinner_progress = None
        self._ge_task_id = None
        if success:
            self._console.print(
                f"[bold magenta]{_pad_status_label('GE')}[/bold magenta] "
                f"[green]✓[/green]  recovered {recovered}/{k} blocks"
            )
        else:
            self._console.print(
                f"[bold magenta]{_pad_status_label('GE')}[/bold magenta] "
                f"[dim]· rank insufficient, continue recovery "
                f"({recovered}/{k} blocks)[/dim]"
            )

    # ── save ──────────────────────────────────────────────────
    def save_done(self, *, output_path: str, bytes_written: int) -> None:
        self._stop_live()
        self._console.print(
            f"[bold green]Save[/bold green]   [green]✓[/green]  "
            f"{output_path}  [dim]{_fmt_size(bytes_written)}[/dim]"
        )

    # ── encode ────────────────────────────────────────────────
    def encode_start(self, *, duration_sec: float, fps: int,
                     qr_version: int, mode: str, overhead: float) -> None:
        self._stop_live()
        self._console.print(
            f"[bold green]Encode[/bold green]  "
            f"video=[bold]{_fmt_duration(duration_sec)}[/bold]  "
            f"fps=[bold]{fps}[/bold]  "
            f"qr=[bold]V{qr_version}[/bold]  "
            f"mode=[bold]{mode}[/bold]  "
            f"overhead=[bold]{overhead:.1f}x[/bold]"
        )
        self._progress = Progress(
            TextColumn(
                f"[bold green]{_pad_status_label('Encode')}[/bold green]"
            ),
            BarColumn(bar_width=None, complete_style="green",
                      finished_style="bright_green",
                      pulse_style="bright_green"),
            _EncodeStatsColumn(),
            console=self._console,
            transient=False,
        )
        self._task_id = self._progress.add_task(
            "encode", total=1000, fps=0.0, eta_override=None)
        self._live = Live(
            self._progress,
            console=self._console,
            refresh_per_second=12,
            transient=False,
        )
        self._live.start()

    def encode_update(self, *, progress_pct: float, speed_fps: float,
                      eta_sec: float) -> None:
        if self._progress is None or self._task_id is None:
            return
        try:
            self._progress.update(
                self._task_id,
                completed=max(0.0, min(1000.0, progress_pct * 10.0)),
                fps=speed_fps,
                eta_override=eta_sec,
            )
        except Exception:
            pass

    def encode_done(self, *, output_path: str, size_bytes: int) -> None:
        if self._progress is not None and self._task_id is not None:
            try:
                self._progress.update(self._task_id, completed=1000)
            except Exception:
                pass
        self._stop_live()
        self._console.print(
            f"[bold green]Done[/bold green]   {output_path}  "
            f"[dim]{_fmt_size(size_bytes)}[/dim]"
        )

    # Calibrate ────────────────────────────────────────────────────
    def calibrate_generate_start(self, *, preset: str,
                                 total_frames: int) -> None:
        self._stop_live()
        self._console.print(
            f"[bold cyan]Calibrate[/bold cyan]  "
            f"preset=[bold]{preset}[/bold]  frames=[bold]{total_frames}[/bold]"
        )
        self._progress = Progress(
            TextColumn(
                f"[bold cyan]{_pad_status_label('Calib')}[/bold cyan]"
            ),
            BarColumn(bar_width=None, complete_style="cyan",
                      finished_style="bright_cyan", pulse_style="cyan"),
            TextColumn("{task.percentage:>3.0f}%"),
            console=self._console,
            transient=False,
        )
        self._task_id = self._progress.add_task("calibrate", total=1000)
        self._live = Live(
            self._progress,
            console=self._console,
            refresh_per_second=12,
            transient=False,
        )
        self._live.start()

    def calibrate_generate_update(self, *,
                                  progress_pct: float) -> None:
        if self._progress is None or self._task_id is None:
            return
        try:
            self._progress.update(
                self._task_id,
                completed=max(0.0, min(1000.0, progress_pct * 10.0)),
            )
        except Exception:
            pass

    def calibrate_generate_done(self, *,
                                output_path: str | None) -> None:
        if self._progress is not None and self._task_id is not None:
            try:
                self._progress.update(self._task_id, completed=1000)
            except Exception:
                pass
        self._stop_live()
        target = output_path or "(display)"
        self._console.print(
            f"[bold green]Done[/bold green]   Calibration video: {target}"
        )

    def calibrate_analyze_start(self, *, total_frames: int) -> None:
        self._stop_live()
        frame_count = total_frames if total_frames > 0 else "?"
        self._console.print(
            f"[bold cyan]Analyze[/bold cyan]  calibration video  "
            f"frames=[bold]{frame_count}[/bold]"
        )
        pct_column = (TextColumn("{task.percentage:>3.0f}%")
                      if total_frames > 0 else TextColumn("[cyan]scan[/cyan]"))
        self._progress = Progress(
            TextColumn(
                f"[bold cyan]{_pad_status_label('Analyze')}[/bold cyan]"
            ),
            BarColumn(bar_width=None, complete_style="cyan",
                      finished_style="bright_cyan", pulse_style="cyan"),
            pct_column,
            TextColumn("[dim]{task.fields[segment]}[/dim]"),
            console=self._console,
            transient=False,
        )
        total = 1000 if total_frames > 0 else None
        self._task_id = self._progress.add_task(
            "analyze", total=total,
            segment=f"0/{frame_count} frames, 0 decoded",
        )
        self._live = Live(
            self._progress,
            console=self._console,
            refresh_per_second=12,
            transient=False,
        )
        self._live.start()

    def calibrate_analyze_update(self, *, progress_pct: float,
                                 segment: str) -> None:
        if self._progress is None or self._task_id is None:
            return
        try:
            task = self._progress.tasks[self._task_id]
            if task.total is None:
                self._progress.update(self._task_id, segment=segment)
            else:
                self._progress.update(
                    self._task_id,
                    completed=max(0.0, min(1000.0, progress_pct * 10.0)),
                    segment=segment,
                )
        except Exception:
            pass

    def calibrate_analyze_done(self) -> None:
        if self._progress is not None and self._task_id is not None:
            try:
                task = self._progress.tasks[self._task_id]
                if task.total is not None:
                    self._progress.update(self._task_id, completed=1000)
            except Exception:
                pass
        self._stop_live()
        self._console.print(
            "[bold green]Done[/bold green]   Calibration analysis complete"
        )


# ── Resolver ─────────────────────────────────────────────────────


def _rich_unavailable_reason() -> str:
    if _RICH_AVAILABLE:
        return ""
    if _RICH_IMPORT_ERROR is None:
        return "rich is not installed"
    exc = _RICH_IMPORT_ERROR
    return f"{type(exc).__name__}: {exc}"


def resolve_output_mode(mode: OutputMode | str,
                        *, stderr_isatty: bool | None = None,
                        explicit: bool = True) -> "ProgressReporter":
    """Construct the appropriate reporter for ``mode``.

    ``AUTO`` chooses :class:`RichReporter` when stderr is a TTY (and
    Rich imported cleanly), else :class:`LogReporter`.

    When the caller explicitly asked for ``interactive`` or ``verbose``
    (``explicit=True``, the default) but Rich is unavailable, a single
    warning line is written to stderr so the user understands why
    they're seeing log-style output instead of the animated UI.
    """
    if isinstance(mode, str):
        try:
            mode = OutputMode(mode)
        except ValueError as exc:
            raise ValueError(
                f"Unknown output mode: {mode!r}. Expected one of "
                f"{[m.value for m in OutputMode]}."
            ) from exc

    if stderr_isatty is None:
        try:
            stderr_isatty = bool(sys.stderr.isatty())
        except Exception:
            stderr_isatty = False

    def _warn_rich_unavailable(requested: str) -> None:
        if not explicit:
            return
        reason = _rich_unavailable_reason() or "unknown"
        try:
            sys.stderr.write(
                f"Warning: --output-mode={requested} requested but Rich UI "
                f"is unavailable ({reason}); falling back to log output. "
                f"Install/upgrade with `pip install -U 'rich>=13.0.0'`.\n"
            )
            sys.stderr.flush()
        except Exception:
            pass

    if mode is OutputMode.QUIET:
        return QuietReporter()
    if mode is OutputMode.LOG:
        return LogReporter(verbose=False)
    if mode is OutputMode.VERBOSE:
        if _RICH_AVAILABLE and stderr_isatty:
            return RichReporter(verbose=True)
        if not _RICH_AVAILABLE:
            _warn_rich_unavailable("verbose")
        return LogReporter(verbose=True)
    if mode is OutputMode.INTERACTIVE:
        if _RICH_AVAILABLE:
            return RichReporter(verbose=False)
        # Explicit interactive request with no Rich → hard fail so the
        # user knows immediately instead of silently getting log output.
        if explicit:
            reason = _rich_unavailable_reason() or "unknown"
            raise RuntimeError(
                f"--output-mode=interactive requires the Rich library "
                f"but it is unavailable ({reason}). Install or upgrade "
                f"with `pip install -U 'rich>=13.0.0'`, or pass "
                f"`--output-mode=log` / `--output-mode=auto` instead."
            )
        _warn_rich_unavailable("interactive")
        return LogReporter(verbose=False)
    # AUTO
    if _RICH_AVAILABLE and stderr_isatty:
        return RichReporter(verbose=False)
    return LogReporter(verbose=False)


__all__ = [
    "OutputMode",
    "Phase",
    "ProgressReporter",
    "RichReporter",
    "LogReporter",
    "QuietReporter",
    "SlidingHitWindow",
    "resolve_output_mode",
    "render_block_map_plain",
    "render_block_map_rich",
    "render_range_strip_plain",
    "render_range_strip_rich",
    "compute_block_map_cells",
    "compute_range_strip_cells",
]
