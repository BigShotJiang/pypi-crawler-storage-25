from fasr_asr_qwen3.models.asr import Qwen3_06BForASR, Qwen3_17BForASR

__all__ = ["Qwen3_06BForASR", "Qwen3_17BForASR"]
