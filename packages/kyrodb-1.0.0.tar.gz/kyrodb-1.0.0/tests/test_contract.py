from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import kyrodb
from kyrodb._routes import ROUTES


def test_sdk_routes_match_pinned_openapi_contract() -> None:
    contract = json.loads(Path("contracts/kyro-runtime.v1.openapi.json").read_text())
    observed = {}
    for path, methods in contract["paths"].items():
        for method, operation in methods.items():
            observed[operation["operationId"]] = {
                "method": method.upper(),
                "path": path,
                "plane": operation["x-kyro-plane"],
                "response_model": _response_model_name(contract, operation),
                "request_model": _request_model_name(operation),
                "path_params": tuple(_parameter_names(operation, "path")),
                "query_params": tuple(_parameter_names(operation, "query")),
            }

    expected_operation_ids = {
        "retrieve": "retrieveContext",
        "invalidate": "invalidateContext",
        "ingest_change_event": "ingestChangeEvent",
        "upsert_document": "upsertDocument",
        "delete_document": "deleteDocument",
        "record_feedback": "recordContextFeedback",
        "get_feedback": "getContextFeedback",
        "get_trace": "getTrace",
        "diagnose_trace": "diagnoseTrace",
        "health": "getContextHealth",
        "context_proof_report": "getContextProofReport",
        "build_proof_bundle": "buildProofBundle",
        "build_root_cause_report": "buildRootCauseReport",
        "diff_replay_runs": "diffReplayRuns",
        "run_counterfactual_replay": "runCounterfactualReplay",
        "create_shadow_session": "createShadowSession",
        "export_replay_capture": "exportReplayCapture",
    }

    assert set(ROUTES) == set(expected_operation_ids)
    for route_name, operation_id in expected_operation_ids.items():
        route = ROUTES[route_name]
        contract_route = observed[operation_id]
        assert route.method == contract_route["method"]
        assert route.path == contract_route["path"]
        assert route.plane == contract_route["plane"]
        assert route.response_model == contract_route["response_model"]
        assert route.request_model == contract_route["request_model"]
        assert route.path_params == contract_route["path_params"]
        assert route.query_params == contract_route["query_params"]


def test_pinned_contract_matches_runtime_contract_when_available() -> None:
    runtime_contract_path = Path("../docs/api/kyro-runtime.v1.openapi.json")
    if not runtime_contract_path.exists():
        return

    sdk_contract = json.loads(Path("contracts/kyro-runtime.v1.openapi.json").read_text())
    runtime_contract = json.loads(runtime_contract_path.read_text())

    assert sdk_contract == runtime_contract


def _response_model_name(contract: dict, operation: dict) -> str:
    response = operation["responses"]["200"]
    if "$ref" in response:
        response_name = response["$ref"].rsplit("/", 1)[1]
        response = contract["components"]["responses"][response_name]
    schema = response["content"]["application/json"]["schema"]
    if "$ref" in schema:
        return schema["$ref"].rsplit("/", 1)[1]
    if schema.get("type") == "array":
        items = schema["items"]
        if "$ref" in items:
            return f"list[{items['$ref'].rsplit('/', 1)[1]}]"
    raise AssertionError(f"unsupported response schema for {operation['operationId']}")


def _request_model_name(operation: dict) -> Optional[str]:
    request_body = operation.get("requestBody")
    if request_body is None:
        return None
    if "$ref" in request_body:
        return request_body["$ref"].rsplit("/", 1)[1]
    schema = request_body["content"]["application/json"]["schema"]
    if "$ref" in schema:
        return schema["$ref"].rsplit("/", 1)[1]
    return operation["operationId"][0].upper() + operation["operationId"][1:] + "Request"


def _parameter_names(operation: dict, location: str) -> list[str]:
    names: list[str] = []
    for parameter in operation.get("parameters", []):
        if "$ref" in parameter:
            ref_name = parameter["$ref"].rsplit("/", 1)[1]
            if ref_name == "TraceId" and location == "path":
                names.append("trace_id")
            continue
        if parameter.get("in") == location:
            names.append(parameter["name"])
    return names


def test_public_import_surface_exports_method_models() -> None:
    expected = {
        "RetrieveRequest",
        "ProofBundle",
        "ProofBundleRequest",
        "ProofBundleSource",
        "PartnerReplayRecordSummary",
        "PartnerReplayRunSummary",
        "PartnerReplayStepDiffSummary",
        "RootCauseReport",
        "RootCauseReportRequest",
        "ReplayDiffRequest",
        "ReplayDiffResult",
        "CounterfactualReplayRequest",
        "CounterfactualResult",
        "ReplayCaptureExport",
        "ReplayPrimerState",
        "ShadowSessionCreateRequest",
        "ShadowSessionCreateResponse",
        "TrafficCaptureArtifact",
        "OwnershipMode",
    }

    assert expected.issubset(set(kyrodb.__all__))
    for name in expected:
        assert hasattr(kyrodb, name)
