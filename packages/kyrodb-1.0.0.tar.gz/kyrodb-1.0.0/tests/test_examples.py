from __future__ import annotations

import runpy
from pathlib import Path


def test_examples_are_import_safe() -> None:
    for path in Path("examples").glob("*.py"):
        namespace = runpy.run_path(str(path), run_name=f"kyrodb_example_{path.stem}")
        assert callable(namespace["main"])
