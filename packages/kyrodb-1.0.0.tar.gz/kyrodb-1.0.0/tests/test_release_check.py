from __future__ import annotations

import subprocess
import sys


def test_release_check_source_metadata_gate_passes() -> None:
    completed = subprocess.run(
        [sys.executable, "scripts/check_release.py", "--no-build"],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    assert "release check passed" in completed.stdout
