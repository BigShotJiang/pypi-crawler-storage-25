from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import pytest


@pytest.fixture
def packet_payload() -> dict[str, Any]:
    return {
        "packet_id": "packet_1",
        "trace_id": "trace_1",
        "status": "complete",
        "freshness": {"served_freshness_mode": "balanced", "safe_as_of": "gen_1"},
        "items": [{"id": "doc_1", "score": 0.98}],
        "meta": {"cache": "miss"},
    }


@pytest.fixture
def trace_payload() -> dict[str, Any]:
    return {
        "trace_id": "trace_1",
        "scope": {"tenant_id": "acme", "namespace": "kb"},
        "status": "complete",
        "freshness_generation": 1,
        "items_returned": 1,
    }


@pytest.fixture
def feedback_payload() -> dict[str, Any]:
    return {
        "trace_id": "trace_1",
        "signal": "stale",
        "received_at": datetime.now(timezone.utc).isoformat(),
        "trace_known": True,
    }
