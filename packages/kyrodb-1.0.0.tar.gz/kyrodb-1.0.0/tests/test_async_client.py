from __future__ import annotations

import asyncio

import httpx
import pytest

from kyrodb import AsyncKyroDBClient, Scope
from kyrodb.errors import KyroDBDecodeError, KyroDBRedirectBlockedError


def test_async_retrieve_matches_sync_surface(packet_payload: dict) -> None:
    async def run() -> None:
        async def handler(request: httpx.Request) -> httpx.Response:
            assert request.headers["authorization"] == "Bearer data-token"
            return httpx.Response(200, json=packet_payload, request=request)

        client = AsyncKyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="data-token",
            http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)),
        )
        try:
            packet = await client.retrieve(
                query_embedding=[1.0],
                scope=Scope(tenant_id="acme", namespace="kb"),
            )
        finally:
            await client.close()

        assert packet.trace_id == "trace_1"

    asyncio.run(run())


def test_async_redirects_are_blocked_and_redacted() -> None:
    async def run() -> None:
        token = "async-secret"

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                308,
                headers={"location": f"https://evil.example/{token}"},
                request=request,
            )

        client = AsyncKyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token=token,
            http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)),
        )
        try:
            with pytest.raises(KyroDBRedirectBlockedError) as raised:
                await client.retrieve(
                    query_embedding=[1.0],
                    scope=Scope(tenant_id="acme", namespace="kb"),
                )
        finally:
            await client.close()

        assert token not in str(raised.value)
        assert "evil.example" not in str(raised.value)

    asyncio.run(run())


def test_async_response_schema_errors_are_redacted() -> None:
    async def run() -> None:
        secret = "async-raw-document"

        async def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"raw": secret}, request=request)

        client = AsyncKyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="data-token",
            http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)),
        )
        try:
            with pytest.raises(KyroDBDecodeError) as raised:
                await client.retrieve(
                    query_embedding=[1.0],
                    scope=Scope(tenant_id="acme", namespace="kb"),
                )
        finally:
            await client.close()

        assert secret not in str(raised.value)
        assert "body_sha256=" in str(raised.value)

    asyncio.run(run())
