from __future__ import annotations

import pytest

from kyrodb._routes import format_path


def test_format_path_url_encodes_trace_ids_without_path_widening() -> None:
    path = format_path("/v1/traces/{trace_id}", trace_id="tenant/acme trace#1")

    assert path == "/v1/traces/tenant%2Facme%20trace%231"


def test_format_path_rejects_ambiguous_path_parameters() -> None:
    with pytest.raises(ValueError):
        format_path("/v1/traces/{trace_id}", trace_id="")
    with pytest.raises(ValueError):
        format_path("/v1/traces/{trace_id}", trace_id=" trace")
    with pytest.raises(ValueError):
        format_path("/v1/traces/{trace_id}", trace_id="trace\n1")
