from __future__ import annotations

import json

import httpx
import pytest

from kyrodb import (
    CounterfactualIntervention,
    CounterfactualReplayScenario,
    KyroDBClient,
    ReplayDiffRequest,
    ReplayRunReport,
    RuntimeFilter,
    Scope,
    TrafficCaptureArtifact,
)
from kyrodb.errors import KyroDBValidationError
from kyrodb.models import PacketStatus


def test_retrieve_posts_strict_payload_and_parses_context_packet(packet_payload: dict) -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json=packet_payload, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    packet = client.retrieve(
        query_embedding=[1.0, 0.0],
        scope=Scope(tenant_id="acme", namespace="kb"),
        filters=RuntimeFilter.exact("product", "billing"),
        top_k=3,
        freshness_mode="balanced",
    )

    assert packet.status is PacketStatus.COMPLETE
    assert packet.trace_id == "trace_1"
    assert seen[0].method == "POST"
    assert seen[0].url.path == "/v1/context/retrieve"
    assert seen[0].headers["authorization"] == "Bearer data-token"
    body = json.loads(seen[0].content)
    assert body["filters"] == {"type": "exact", "key": "product", "value": "billing"}


def test_observability_uses_observability_token(trace_payload: dict) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer obs-token"
        assert request.url.path == "/v1/traces/trace_1"
        return httpx.Response(200, json=trace_payload, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    trace = client.observability.get_trace("trace_1")

    assert trace.trace_id == "trace_1"


def test_observability_trace_ids_are_path_encoded(trace_payload: dict) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.raw_path == b"/v1/traces/tenant%2Facme%20trace%231"
        return httpx.Response(200, json=trace_payload, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    trace = client.observability.get_trace("tenant/acme trace#1")

    assert trace.trace_id == "trace_1"


def test_admin_export_capture_uses_recent_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/replay/capture"
        assert request.url.params["recent"] == "5"
        assert request.headers["authorization"] == "Bearer obs-token"
        return httpx.Response(
            200,
            json={
                "schema_version": 3,
                "generated_at": "2026-04-29T00:00:00Z",
                "total_steps": 0,
                "steps": [],
            },
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    capture = client.admin.export_replay_capture(recent=5)

    assert capture.schema_version == 3


def test_recent_query_params_are_validated_before_send() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise AssertionError("request should not be sent")

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBValidationError):
        client.observability.context_proof_report(recent=0)
    with pytest.raises(KyroDBValidationError):
        client.admin.export_replay_capture(recent=1001)


def test_request_validation_errors_are_stable_and_public_safe() -> None:
    secret = "secret-filter-value"

    def handler(request: httpx.Request) -> httpx.Response:
        raise AssertionError("invalid request should not be sent")

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBValidationError) as raised:
        client.retrieve(
            query_embedding=[1.0],
            scope=Scope(tenant_id="acme", namespace="kb"),
            top_k="3",
            filters=RuntimeFilter.exact("product", secret),
        )

    assert raised.value.status_code == 0
    assert secret not in str(raised.value)
    assert raised.value.body_sha256 is not None


def test_admin_replay_diff_uses_typed_request_model() -> None:
    seen: list[dict] = []
    empty_run = ReplayRunReport(
        generated_at="2026-04-29T00:00:00Z",
        total_steps=0,
        retrieve_steps=0,
        complete_count=0,
        degraded_count=0,
        stale_blocked_count=0,
        total_latency_ms=0.0,
        records=[],
    )

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(json.loads(request.content))
        return httpx.Response(
            200,
            json={
                "compared_steps": 0,
                "changed_steps": 0,
                "cache_hit_gains": 0,
                "completion_gains": 0,
                "diagnosis_changes": 0,
                "latency_delta_ms": 0.0,
                "only_in_baseline_count": 0,
                "only_in_candidate_count": 0,
                "duplicate_key_count": 0,
                "validation_warning_count": 0,
                "diffs": [],
                "redactions": [],
            },
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    result = client.admin.diff_replay_runs(
        ReplayDiffRequest(baseline=empty_run, candidate=empty_run)
    )

    assert result.compared_steps == 0
    assert seen[0]["baseline"]["total_steps"] == 0


def test_admin_counterfactual_request_is_typed_and_strict() -> None:
    capture = TrafficCaptureArtifact(
        schema_version=3,
        generated_at="2026-04-29T00:00:00Z",
        total_steps=1,
        steps=[{"sequence": 1}],
    )
    scenario = CounterfactualReplayScenario(
        name="drop noisy step",
        interventions=[CounterfactualIntervention.drop_step(0)],
    )

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        assert body["scenario"]["interventions"][0] == {"type": "drop_step", "step_index": 0}
        return httpx.Response(
            200,
            json={
                "generated_at": "2026-04-29T00:00:00Z",
                "scenario_key": "counterfactual_scenario_v2_test",
                "intervention_count": 1,
                "transformed_steps": 0,
                "baseline_run_summary": _empty_partner_run_summary(),
                "counterfactual_run_summary": _empty_partner_run_summary(),
                "replay_diff_summary": _empty_partner_diff_summary(),
                "stale_block_delta": 0,
                "degraded_delta": 0,
                "completion_delta": 0,
                "redactions": [],
            },
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    result = client.admin.run_counterfactual_replay(capture=capture, scenario=scenario)

    assert result.stale_block_delta == 0


def _empty_partner_run_summary() -> dict:
    return {
        "generated_at": "2026-04-29T00:00:00Z",
        "total_steps": 0,
        "retrieve_steps": 0,
        "complete_count": 0,
        "degraded_count": 0,
        "stale_blocked_count": 0,
        "total_latency_ms": 0.0,
        "records": [],
        "redactions": [],
    }


def _empty_partner_diff_summary() -> dict:
    return {
        "compared_steps": 0,
        "changed_steps": 0,
        "cache_hit_gains": 0,
        "completion_gains": 0,
        "diagnosis_changes": 0,
        "latency_delta_ms": 0.0,
        "only_in_baseline_count": 0,
        "only_in_candidate_count": 0,
        "duplicate_key_count": 0,
        "validation_warning_count": 0,
        "diffs": [],
        "redactions": [],
    }
