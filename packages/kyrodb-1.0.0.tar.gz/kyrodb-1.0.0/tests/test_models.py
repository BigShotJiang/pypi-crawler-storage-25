from __future__ import annotations

import pytest
from pydantic import ValidationError

from kyrodb import (
    ChangeTarget,
    ContextFeedback,
    CounterfactualIntervention,
    CounterfactualReplayScenario,
    FeedbackSignal,
    RuntimeFilter,
    Scope,
    ShadowSessionCreateRequest,
    TrafficCaptureArtifact,
    WriteScope,
)
from kyrodb.models import (
    CounterfactualReplayRequest,
    DeleteDocumentRequest,
    ProofBundle,
    ProofBundleSource,
    ReplayCaptureExport,
    ReplayPrimerState,
    RetrieveRequest,
)


def test_scope_is_strict_and_uses_entitlement_boundary() -> None:
    scope = Scope(tenant_id="acme", namespace="kb", entitlement_boundary="enterprise")

    assert scope.model_dump(exclude_none=True) == {
        "tenant_id": "acme",
        "namespace": "kb",
        "entitlement_boundary": "enterprise",
    }
    with pytest.raises(ValidationError):
        Scope(tenant_id="acme", namespace="kb", product_tier="legacy")  # type: ignore[call-arg]


def test_runtime_filter_validates_connector_executable_keys_and_shapes() -> None:
    filter_ = RuntimeFilter.all(
        [
            RuntimeFilter.exact("product", "billing"),
            RuntimeFilter.one_of("region", ["us", "eu"]),
            RuntimeFilter.range("score", 0.0, 1.0),
        ]
    )

    assert filter_.model_dump(mode="json", exclude_none=True)["type"] == "and"
    with pytest.raises(ValidationError):
        RuntimeFilter.exact("product;drop", "billing")
    with pytest.raises(ValidationError):
        RuntimeFilter.one_of("product", [])
    with pytest.raises(ValidationError):
        RuntimeFilter.range("score", 2.0, 1.0)
    with pytest.raises(ValidationError):
        RuntimeFilter.one_of("product", ["x"] * 257)
    with pytest.raises(ValidationError):
        RuntimeFilter(
            type="exact",
            key="product",
            value="billing",
            filters=[RuntimeFilter.exact("x", "y")],
        )


def test_change_target_requires_variant_specific_identifier() -> None:
    with pytest.raises(ValidationError):
        ChangeTarget(type="document")

    assert ChangeTarget(type="document", doc_id="doc_1").doc_id == "doc_1"
    with pytest.raises(ValidationError):
        ChangeTarget(type="document", doc_id="doc_1", tenant_id="acme")
    with pytest.raises(ValidationError):
        ChangeTarget(type="all", doc_id="doc_1")


def test_identity_fields_reject_whitespace_and_control_characters() -> None:
    with pytest.raises(ValidationError):
        Scope(tenant_id=" acme", namespace="kb")
    with pytest.raises(ValidationError):
        Scope(tenant_id="acme", namespace="kb", auth_scope=[])
    with pytest.raises(ValidationError):
        ChangeTarget(type="document", doc_id="doc\n1")
    with pytest.raises(ValidationError):
        Scope(tenant_id="x" * 257, namespace="kb")


def test_retrieve_request_rejects_empty_or_non_finite_embeddings() -> None:
    with pytest.raises(ValidationError):
        RetrieveRequest(query_embedding=[], scope=Scope(tenant_id="acme", namespace="kb"))
    with pytest.raises(ValidationError):
        RetrieveRequest(
            query_embedding=[float("nan")],
            scope=Scope(tenant_id="acme", namespace="kb"),
        )
    with pytest.raises(ValidationError):
        RetrieveRequest(
            query_embedding=[0.0] * 16_385,
            scope=Scope(tenant_id="acme", namespace="kb"),
        )
    with pytest.raises(ValidationError):
        RetrieveRequest(
            query_embedding=[0.0],
            scope=Scope(tenant_id="acme", namespace="kb"),
            top_k=101,
        )


def test_delete_request_uses_narrow_write_scope() -> None:
    request = DeleteDocumentRequest(
        scope=WriteScope(tenant_id="acme", namespace="kb"),
        id="doc_1",
    )

    assert request.model_dump(mode="json") == {
        "scope": {"tenant_id": "acme", "namespace": "kb"},
        "id": "doc_1",
    }


def test_feedback_allows_forward_compatible_evidence_fields() -> None:
    feedback = ContextFeedback(trace_id="trace_1", signal=FeedbackSignal.STALE, reviewer="qa")

    assert feedback.model_extra == {"reviewer": "qa"}


def test_shadow_session_schema_version_is_pinned() -> None:
    request = ShadowSessionCreateRequest(replay_primer={})

    assert request.schema_version == 1
    with pytest.raises(ValidationError):
        ShadowSessionCreateRequest(schema_version=2, replay_primer={})


def test_replay_primer_and_capture_export_validate_integrity() -> None:
    primer = ReplayPrimerState(current_generation=1, processed_change_event_ids=["evt_1"])
    export = ReplayCaptureExport(
        schema_version=3,
        generated_at="2026-04-29T00:00:00Z",
        total_steps=1,
        steps=[{"sequence": 1}],
        replay_primer=primer,
    )

    assert export.replay_primer is not None
    assert export.replay_primer.current_generation == 1
    with pytest.raises(ValidationError):
        ReplayCaptureExport(
            schema_version=3,
            generated_at="2026-04-29T00:00:00Z",
            total_steps=1,
            steps=[],
        )
    with pytest.raises(ValidationError):
        ReplayCaptureExport(
            schema_version=4,
            generated_at="2026-04-29T00:00:00Z",
            total_steps=0,
            steps=[],
        )
    with pytest.raises(ValidationError):
        ReplayPrimerState(
            current_generation=1,
            processed_change_event_ids=["evt_1", "evt_1"],
        )


def test_response_capture_export_can_be_reused_for_counterfactual_request() -> None:
    export = ReplayCaptureExport(
        schema_version=3,
        generated_at="2026-04-29T00:00:00Z",
        total_steps=1,
        steps=[{"sequence": 1}],
    )
    scenario = CounterfactualReplayScenario(
        name="drop noisy step",
        interventions=[CounterfactualIntervention.drop_step(1)],
    )

    request = CounterfactualReplayRequest(capture=export, scenario=scenario)

    assert request.capture.total_steps == 1


def test_proof_bundle_sources_are_typed_strings() -> None:
    bundle = ProofBundle(
        schema_version=2,
        generated_at="2026-04-29T00:00:00Z",
        baseline_capture_source="live_capture_export",
        baseline_capture_summary={},
        baseline_run_summary={},
        baseline_metrics={},
        candidate_run_source="caller_supplied",
        stale_prevented_count=0,
        missing_trace_evidence_count=0,
        evidence_quality={},
        feedback_entries_considered=0,
        feedback_signal_counts=[],
        incident_examples=[],
        debug_examples=[],
        resolution_examples=[],
        trust_summary=[],
    )

    assert bundle.baseline_capture_source is ProofBundleSource.LIVE_CAPTURE_EXPORT
    assert bundle.candidate_run_source is ProofBundleSource.CALLER_SUPPLIED


def test_counterfactual_and_capture_requests_validate_shape_limits() -> None:
    scenario = CounterfactualReplayScenario(
        name="drop noisy step",
        interventions=[CounterfactualIntervention.drop_step(0)],
    )
    capture = TrafficCaptureArtifact(
        schema_version=3,
        generated_at="2026-04-29T00:00:00Z",
        total_steps=1,
        steps=[{"sequence": 1}],
    )

    assert scenario.interventions[0].type == "drop_step"
    assert capture.total_steps == 1
    with pytest.raises(ValidationError):
        CounterfactualIntervention(type="drop_step", step_index=0, before_step_index=1)
    with pytest.raises(ValidationError):
        TrafficCaptureArtifact(
            schema_version=3,
            generated_at="2026-04-29T00:00:00Z",
            total_steps=2,
            steps=[{"sequence": 1}],
        )
    with pytest.raises(ValidationError):
        TrafficCaptureArtifact(
            schema_version=3,
            generated_at="2026-04-29T00:00:00Z",
            total_steps=2,
            steps=[{"sequence": 2}, {"sequence": 1}],
        )
