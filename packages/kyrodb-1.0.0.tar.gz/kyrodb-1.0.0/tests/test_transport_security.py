from __future__ import annotations

import httpx
import pytest

from kyrodb import KyroDBClient, Scope
from kyrodb.errors import (
    KyroDBAuthError,
    KyroDBConfigurationError,
    KyroDBDecodeError,
    KyroDBEvidenceError,
    KyroDBRedirectBlockedError,
    KyroDBResponseTooLargeError,
    KyroDBServerError,
    KyroDBValidationError,
)
from kyrodb.transport import SyncKyroTransport, TransportConfig


def test_rejects_plaintext_non_loopback_url() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(base_url="http://api.example.com", data_plane_token="data")


def test_allows_plaintext_loopback_url() -> None:
    client = KyroDBClient(base_url="http://127.0.0.1:8080", data_plane_token="data")

    try:
        assert "data" not in repr(client)
    finally:
        client.close()


def test_requires_data_plane_token() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(base_url="https://runtime.example.com", data_plane_token=None)  # type: ignore[arg-type]


def test_rejects_unsafe_authorization_header_values() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(base_url="https://runtime.example.com", data_plane_token="abc def")
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(base_url="https://runtime.example.com", data_plane_token="abc\x7fdef")


def test_rejects_invalid_shadow_session_ids() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="data",
            shadow_session_id="kss_bad/session",
        )
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="data",
            shadow_session_id="x" * 97,
        )


def test_rejects_shared_tokens_without_explicit_opt_in() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="same",
            observability_token="same",
        )


def test_redirects_are_blocked_before_body_is_consumed() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(307, headers={"location": "http://evil.example/steal"})

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-secret",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBRedirectBlockedError):
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))


def test_redirect_error_omits_sensitive_location() -> None:
    token = "data-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            307,
            headers={"location": f"https://evil.example/steal?token={token}"},
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token=token,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBRedirectBlockedError) as raised:
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    error_text = str(raised.value)
    assert token not in error_text
    assert "evil.example" not in error_text


def test_error_mapping_redacts_tokens_and_omits_raw_body() -> None:
    token = "data-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == f"Bearer {token}"
        return httpx.Response(
            401,
            json={"error": f"invalid token {token}", "code": "UNAUTHORIZED"},
            headers={"x-request-id": f"request-{token}"},
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token=token,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBAuthError) as raised:
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    error_text = str(raised.value)
    assert token not in error_text
    assert token not in str(raised.value.request_id)
    assert raised.value.body_length is not None
    assert raised.value.body_sha256 is not None


def test_nested_error_payloads_do_not_leak_through_exception_fields() -> None:
    secret = "raw-evidence-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            500,
            json={"error": {"secret": secret}, "code": ["TRACE_PERSISTENCE_FAILED", secret]},
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBServerError) as raised:
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    assert secret not in str(raised.value)


def test_evidence_failures_are_not_reported_as_overload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            503,
            json={
                "error": "trace evidence could not be persisted for this retrieval",
                "code": "TRACE_PERSISTENCE_FAILED",
            },
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBEvidenceError):
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))


def test_json_constants_are_rejected_as_invalid_json() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b'{"packet_id": NaN}', request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBDecodeError):
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))


def test_extra_headers_cannot_override_sdk_auth_headers() -> None:
    transport = SyncKyroTransport(
        TransportConfig(base_url="https://runtime.example.com", data_plane_token="data"),
        http_client=httpx.Client(
            transport=httpx.MockTransport(
                lambda request: httpx.Response(200, json={}, request=request)
            )
        ),
    )

    with pytest.raises(KyroDBConfigurationError):
        transport.request_json(
            "GET",
            "/v1/health/context",
            plane="data",
            extra_headers={"authorization": "Bearer attacker"},
        )


def test_response_size_limit_is_enforced() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"x" * 64, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        max_response_bytes=8,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBResponseTooLargeError):
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))


def test_request_size_limit_is_enforced_before_send() -> None:
    sent = False

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal sent
        sent = True
        return httpx.Response(200, json={}, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        max_request_bytes=32,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBValidationError):
        client.retrieve(
            query_embedding=[1.0, 2.0, 3.0],
            scope=Scope(tenant_id="acme", namespace="kb"),
        )

    assert sent is False


def test_response_schema_errors_do_not_echo_raw_payload() -> None:
    secret = "tenant-secret-document-content"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"raw": secret}, request=request)

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBDecodeError) as raised:
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    error_text = str(raised.value)
    assert secret not in error_text
    assert "body_sha256=" in error_text


def test_observability_surfaces_require_observability_token() -> None:
    client = KyroDBClient(base_url="https://runtime.example.com", data_plane_token="data")

    with pytest.raises(KyroDBConfigurationError):
        _ = client.observability
    with pytest.raises(KyroDBConfigurationError):
        _ = client.admin
