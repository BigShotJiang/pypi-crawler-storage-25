from __future__ import annotations

import httpx
import pytest

from kyrodb import KyroDBClient, Scope
from kyrodb.errors import KyroDBConfigurationError


def test_client_from_env_loads_required_and_optional_values(packet_payload: dict) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer data-token"
        assert request.headers["kyro-shadow-session-id"] == "shadow-1"
        return httpx.Response(200, json=packet_payload, request=request)

    client = KyroDBClient.from_env(
        {
            "KYRO_RUNTIME_URL": "https://runtime.example.com",
            "KYRO_DATA_PLANE_TOKEN": "data-token",
            "KYRO_OBSERVABILITY_TOKEN": "obs-token",
            "KYRO_SHADOW_SESSION_ID": "shadow-1",
        },
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    packet = client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    assert packet.trace_id == "trace_1"


def test_client_from_env_fails_closed_when_required_values_are_missing() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient.from_env({"KYRO_DATA_PLANE_TOKEN": "data-token"})


def test_client_from_env_does_not_trim_secret_values() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient.from_env(
            {
                "KYRO_RUNTIME_URL": "https://runtime.example.com",
                "KYRO_DATA_PLANE_TOKEN": " data-token",
            }
        )
