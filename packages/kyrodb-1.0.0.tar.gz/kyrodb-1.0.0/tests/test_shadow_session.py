from __future__ import annotations

import httpx
import pytest

from kyrodb import KyroDBClient, Scope
from kyrodb.errors import KyroDBConfigurationError, KyroDBOverloadedError


def test_shadow_session_header_is_sent_and_redacted() -> None:
    session_id = "shadow-session-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["kyro-shadow-session-id"] == session_id
        return httpx.Response(
            503,
            json={
                "error": f"shadow session {session_id} unavailable",
                "code": "GATEWAY_OVERLOADED",
            },
            request=request,
        )

    client = KyroDBClient(
        base_url="https://runtime.example.com",
        data_plane_token="data-token",
        observability_token="obs-token",
        shadow_session_id=session_id,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    with pytest.raises(KyroDBOverloadedError) as raised:
        client.retrieve(query_embedding=[1.0], scope=Scope(tenant_id="acme", namespace="kb"))

    assert session_id not in str(raised.value)


def test_shadow_session_header_rejects_header_injection() -> None:
    with pytest.raises(KyroDBConfigurationError):
        KyroDBClient(
            base_url="https://runtime.example.com",
            data_plane_token="data-token",
            shadow_session_id="session\r\nx-evil: yes",
        )
