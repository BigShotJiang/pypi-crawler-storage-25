from __future__ import annotations

import json
import os
import uuid
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any, Optional

import pytest

from kyrodb import (
    ChangeEvent,
    ChangeScope,
    ChangeTarget,
    ChangeTargetType,
    ChangeType,
    ContextFeedback,
    CounterfactualIntervention,
    CounterfactualReplayScenario,
    DeleteDocumentRequest,
    Document,
    FeedbackSignal,
    FreshnessMode,
    KyroDBClient,
    PacketStatus,
    ReplayDiffRequest,
    ReplayPrimerState,
    ReplayRunReport,
    Scope,
    UpsertDocumentRequest,
    WriteScope,
)
from kyrodb.errors import KyroDBConfigurationError

pytestmark = pytest.mark.live


def test_live_retrieve_trace_diagnosis_and_health() -> None:
    client = _live_client()
    scope = _live_scope()
    embedding = _live_embedding()

    with client:
        packet = client.retrieve(
            query_embedding=embedding,
            scope=scope,
            top_k=int(os.environ.get("KYRO_TEST_TOP_K", "3")),
            freshness_mode=FreshnessMode(os.environ.get("KYRO_TEST_FRESHNESS_MODE", "balanced")),
        )
        assert packet.trace_id
        assert packet.status in {
            PacketStatus.COMPLETE,
            PacketStatus.PARTIAL,
            PacketStatus.DEGRADED,
            PacketStatus.STALE_BLOCKED,
        }

        trace = client.observability.get_trace(packet.trace_id)
        assert trace.trace_id == packet.trace_id

        diagnosis = client.observability.diagnose_trace(packet.trace_id)
        assert diagnosis.trace_id == packet.trace_id

        health = client.observability.health()
        assert health.status in {"healthy", "degraded", "unhealthy"}


def test_live_admin_evidence_exports_are_typed() -> None:
    client = _live_client()
    with client:
        report = client.observability.context_proof_report(recent=1)
        assert report.traces_considered >= 0

        capture = client.admin.export_replay_capture(recent=1)
        assert capture.schema_version >= 1
        assert capture.total_steps == len(capture.steps)


def test_live_qdrant_change_feedback_and_proof_flow() -> None:
    if os.environ.get("KYRO_LIVE_QDRANT_TESTS") != "1":
        pytest.skip("set KYRO_LIVE_QDRANT_TESTS=1 for connector mutation/evidence live coverage")
    client = _live_client()
    scope = _live_scope()

    with client:
        packet = client.retrieve(
            query_embedding=_live_embedding(),
            scope=scope,
            top_k=int(os.environ.get("KYRO_TEST_TOP_K", "3")),
            freshness_mode=FreshnessMode.BALANCED,
        )
        feedback = client.record_feedback(
            ContextFeedback(trace_id=packet.trace_id, signal=FeedbackSignal.USEFUL)
        )
        assert feedback.trace_id == packet.trace_id

        result = client.ingest_change_event(
            ChangeEvent(
                target=ChangeTarget(type=ChangeTargetType.NAMESPACE, namespace=scope.namespace),
                change_type=ChangeType.NAMESPACE_REBUILT,
                scope=ChangeScope(tenant_id=scope.tenant_id, namespace=scope.namespace),
                timestamp=datetime.now(timezone.utc),
                source_event_id=f"python-sdk-live-{uuid.uuid4()}",
            )
        )
        assert result.accepted is True

        bundle = client.admin.build_proof_bundle(recent=5)
        assert bundle.schema_version >= 1

        root_cause = client.admin.build_root_cause_report(recent=5, include_non_stale=True)
        assert root_cause.schema_version >= 1


def test_live_pgvector_write_through_ack_flow() -> None:
    if os.environ.get("KYRO_LIVE_PGVECTOR_MUTATION_TESTS") != "1":
        pytest.skip("set KYRO_LIVE_PGVECTOR_MUTATION_TESTS=1 for write-through live coverage")
    client = _live_client()
    scope = _live_scope()
    write_scope = WriteScope(tenant_id=scope.tenant_id, namespace=scope.namespace)
    doc_id = os.environ.get("KYRO_TEST_MUTATION_DOC_ID", f"python-sdk-live-{uuid.uuid4()}")

    with client:
        upsert = client.upsert_document(
            UpsertDocumentRequest(
                scope=write_scope,
                document=Document(
                    id=doc_id,
                    embedding=_live_embedding(),
                    content="python sdk live mutation fixture",
                    metadata={"source": "python_sdk_live"},
                ),
            )
        )
        assert upsert.mutation_ack.verified is True

        delete = client.delete_document(DeleteDocumentRequest(scope=write_scope, id=doc_id))
        assert delete.mutation_ack.verified is True


def test_live_replay_diff_counterfactual_and_shadow_session_flow() -> None:
    if os.environ.get("KYRO_LIVE_REPLAY_TESTS") != "1":
        pytest.skip("set KYRO_LIVE_REPLAY_TESTS=1 for replay/shadow live coverage")
    client = _live_client()

    with client:
        capture = client.admin.export_replay_capture(recent=10)
        if capture.total_steps == 0:
            pytest.skip("live replay capture has no steps to replay")

        empty_run = ReplayRunReport(
            generated_at=datetime.now(timezone.utc).isoformat(),
            total_steps=0,
            retrieve_steps=0,
            complete_count=0,
            degraded_count=0,
            stale_blocked_count=0,
            total_latency_ms=0.0,
            records=[],
        )
        diff = client.admin.diff_replay_runs(
            ReplayDiffRequest(baseline=empty_run, candidate=empty_run)
        )
        assert diff.compared_steps == 0

        scenario = CounterfactualReplayScenario(
            name="drop first captured step",
            interventions=[
                CounterfactualIntervention.drop_step(_captured_step_index(capture.steps[0]))
            ],
        )
        summary = client.admin.run_counterfactual_replay(capture=capture, scenario=scenario)
        assert summary.transformed_steps >= 0

        replay_primer = _captured_replay_primer(capture.replay_primer, capture.steps)
        if replay_primer is None:
            pytest.skip("live replay capture has no replay_primer for shadow-session creation")
        session = client.admin.create_shadow_session(replay_primer=replay_primer)
        assert session.session_id


def _captured_step_index(step: Mapping[str, Any]) -> int:
    observed = step.get("observed_record")
    if isinstance(observed, Mapping):
        step_index = observed.get("step_index")
        if isinstance(step_index, int):
            return step_index
    sequence = step.get("sequence")
    if isinstance(sequence, int):
        return sequence
    raise ValueError("captured replay step does not include an integer step index")


def _captured_replay_primer(
    top_level_primer: Optional[ReplayPrimerState],
    steps: list[Mapping[str, Any]],
) -> Optional[ReplayPrimerState]:
    if top_level_primer is not None and not top_level_primer.is_empty():
        return top_level_primer
    for step in reversed(steps):
        primer = step.get("pre_step_replay_primer")
        if isinstance(primer, Mapping):
            replay_primer = ReplayPrimerState.model_validate(dict(primer))
            if not replay_primer.is_empty():
                return replay_primer
    return top_level_primer


def _live_client() -> KyroDBClient:
    if os.environ.get("KYRO_LIVE_TESTS") != "1":
        pytest.skip("set KYRO_LIVE_TESTS=1 to run live runtime tests")
    try:
        return KyroDBClient.from_env(
            allow_insecure_http=os.environ.get("KYRO_ALLOW_INSECURE_HTTP") == "1",
            allow_shared_tokens=os.environ.get("KYRO_ALLOW_SHARED_TOKENS") == "1",
            timeout=float(os.environ.get("KYRO_TEST_TIMEOUT_SECONDS", "15")),
        )
    except KyroDBConfigurationError as error:
        pytest.skip(f"live KyroDB client is not configured: {error}")


def _live_scope() -> Scope:
    return Scope(
        tenant_id=os.environ.get("KYRO_TEST_TENANT_ID", "acme"),
        namespace=os.environ.get("KYRO_TEST_NAMESPACE", "kb"),
        auth_scope=_optional_json_list(os.environ, "KYRO_TEST_AUTH_SCOPE"),
    )


def _live_embedding() -> list[float]:
    raw = os.environ.get("KYRO_TEST_QUERY_EMBEDDING", "[1.0, 0.0, 0.0, 0.0]")
    decoded = json.loads(raw)
    if not isinstance(decoded, list) or not all(isinstance(item, (int, float)) for item in decoded):
        raise ValueError("KYRO_TEST_QUERY_EMBEDDING must be a JSON array of numbers")
    return [float(item) for item in decoded]


def _optional_json_list(env: Mapping[str, str], name: str) -> Optional[list[str]]:
    raw = env.get(name)
    if raw is None:
        return None
    decoded: Any = json.loads(raw)
    if not isinstance(decoded, list) or not all(isinstance(item, str) for item in decoded):
        raise ValueError(f"{name} must be a JSON array of strings")
    return decoded
