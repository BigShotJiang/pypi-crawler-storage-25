from __future__ import annotations

import argparse

from kyrodb import KyroDBClient, ProofBundleRequest


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a redacted KyroDB proof bundle.")
    parser.add_argument("--recent", type=int, default=50, help="recent retained capture steps")
    args = parser.parse_args()

    with KyroDBClient.from_env() as client:
        bundle = client.admin.build_proof_bundle(ProofBundleRequest(recent=args.recent))
        print(
            {
                "schema_version": bundle.schema_version,
                "stale_prevented_count": bundle.stale_prevented_count,
                "missing_trace_evidence_count": bundle.missing_trace_evidence_count,
                "trust_summary": bundle.trust_summary,
            }
        )


if __name__ == "__main__":
    main()
