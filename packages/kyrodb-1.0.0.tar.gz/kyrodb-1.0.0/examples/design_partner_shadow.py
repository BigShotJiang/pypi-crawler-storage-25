from __future__ import annotations

import argparse
import hashlib
import os

from kyrodb import KyroDBClient, ShadowSessionCreateRequest


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create a candidate shadow session from retained KyroDB replay evidence."
    )
    parser.add_argument("--recent", type=int, default=50, help="recent retained capture steps")
    parser.add_argument(
        "--candidate-url-env",
        default="KYRO_CANDIDATE_RUNTIME_URL",
        help="environment variable containing the candidate runtime URL",
    )
    parser.add_argument(
        "--candidate-data-token-env",
        default="KYRO_CANDIDATE_DATA_PLANE_TOKEN",
        help="environment variable containing the candidate data-plane token",
    )
    parser.add_argument(
        "--candidate-observability-token-env",
        default="KYRO_CANDIDATE_OBSERVABILITY_TOKEN",
        help="environment variable containing the candidate observability token",
    )
    args = parser.parse_args()

    with KyroDBClient.from_env() as baseline:
        capture = baseline.admin.export_replay_capture(recent=args.recent)
        if capture.replay_primer is None:
            raise SystemExit("capture did not include replay_primer; enable replay capture first")

    candidate_base_url = os.environ[args.candidate_url_env]
    candidate_data_token = os.environ[args.candidate_data_token_env]
    candidate_observability_token = os.environ[args.candidate_observability_token_env]

    candidate_admin = KyroDBClient(
        base_url=candidate_base_url,
        data_plane_token=candidate_data_token,
        observability_token=candidate_observability_token,
    )
    with candidate_admin:
        session = candidate_admin.admin.create_shadow_session(
            ShadowSessionCreateRequest(replay_primer=capture.replay_primer)
        )

    candidate = KyroDBClient(
        base_url=candidate_base_url,
        data_plane_token=candidate_data_token,
        observability_token=candidate_observability_token,
        shadow_session_id=session.session_id,
    )
    with candidate:
        health = candidate.observability.health()
        print(
            {
                "shadow_session_key": _redacted_session_key(session.session_id),
                "expires_at": session.expires_at.isoformat(),
                "candidate_health": health.status,
            }
        )


def _redacted_session_key(session_id: str) -> str:
    return "shadow_session_sha256_" + hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:16]


if __name__ == "__main__":
    main()
