from __future__ import annotations

import argparse

from kyrodb import KyroDBClient


def main() -> None:
    parser = argparse.ArgumentParser(description="Fetch KyroDB trace diagnosis evidence.")
    parser.add_argument("trace_id", help="Trace ID returned by KyroDBClient.retrieve")
    args = parser.parse_args()

    with KyroDBClient.from_env() as client:
        diagnosis = client.observability.diagnose_trace(args.trace_id)
        print(
            {
                "trace_id": diagnosis.trace_id,
                "kind": diagnosis.kind.value,
                "summary": diagnosis.summary,
                "actions": diagnosis.recommended_actions,
            }
        )


if __name__ == "__main__":
    main()
