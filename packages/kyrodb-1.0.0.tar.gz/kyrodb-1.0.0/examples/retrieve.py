from __future__ import annotations

import os

from kyrodb import KyroDBClient, Scope


def main() -> None:
    client = KyroDBClient(
        base_url=os.environ["KYRO_RUNTIME_URL"],
        data_plane_token=os.environ["KYRO_DATA_PLANE_TOKEN"],
        observability_token=os.environ.get("KYRO_OBSERVABILITY_TOKEN"),
    )
    with client:
        packet = client.retrieve(
            query_embedding=[1.0, 0.0, 0.0, 0.0],
            scope=Scope(tenant_id="acme", namespace="kb"),
            top_k=3,
            freshness_mode="balanced",
        )
        print({"trace_id": packet.trace_id, "status": packet.status.value})


if __name__ == "__main__":
    main()
