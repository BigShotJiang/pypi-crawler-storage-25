# Changelog

All notable changes to the KyroDB Python SDK are recorded here.

## 1.0.0 - 2026-04-29

- First public context-runtime SDK release for the KyroDB Runtime HTTP API.
- Bootstrap typed synchronous and asynchronous clients.
- Add split data-plane, observability, and admin evidence surfaces.
- Enforce HTTPS, redirect blocking, bounded request/response bodies, and public-safe error handling.
- Add strict request models, flexible response models, OpenAPI route/plane contract tests, and live gates for Qdrant, pgvector write-through, replay, proof, and shadow workflows.

### Pivot Note

- Earlier `kyrodb` PyPI releases (`0.1.0` and `0.2.0`) belonged to the legacy vector-database SDK.
- `1.0.0` and later are the KyroDB context-runtime SDK line.
