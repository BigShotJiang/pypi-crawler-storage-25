from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Callable, Optional

import httpx


def json_response(
    payload: Mapping[str, Any],
    *,
    status_code: int = 200,
    headers: Optional[Mapping[str, str]] = None,
) -> httpx.Response:
    return httpx.Response(status_code=status_code, json=dict(payload), headers=headers)


def mock_transport(handler: Callable[[httpx.Request], httpx.Response]) -> httpx.MockTransport:
    return httpx.MockTransport(handler)
