from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any, Optional, TypeVar

from pydantic import BaseModel, ValidationError

from .errors import KyroDBValidationError
from .models import MAX_RECENT

ModelT = TypeVar("ModelT", bound=BaseModel)


def coerce_model(
    model_type: type[ModelT],
    value: Optional[object],
    kwargs: Mapping[str, Any],
) -> ModelT:
    try:
        if value is not None and kwargs:
            raise ValueError("pass either a request object/mapping or keyword fields, not both")
        if isinstance(value, model_type):
            return value
        if value is None:
            return model_type.model_validate(_normalize_model_values(dict(kwargs)))
        if isinstance(value, Mapping):
            return model_type.model_validate(_normalize_model_values(dict(value)))
        raise TypeError(f"expected {model_type.__name__}, mapping, or keyword fields")
    except (TypeError, ValueError, ValidationError) as error:
        raise _sdk_validation_error(model_type.__name__, value, kwargs, error) from error


def _normalize_model_values(value: object) -> object:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", exclude_none=True)
    if isinstance(value, Mapping):
        return {key: _normalize_model_values(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_normalize_model_values(item) for item in value]
    if isinstance(value, tuple):
        return [_normalize_model_values(item) for item in value]
    return value


def payload(model: BaseModel) -> dict[str, Any]:
    return model.model_dump(mode="json", exclude_none=True)


def validate_recent(value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise _sdk_validation_error("recent", value, {}, TypeError("recent must be an integer"))
    if value < 1 or value > MAX_RECENT:
        raise _sdk_validation_error(
            "recent",
            value,
            {},
            ValueError(f"recent must be between 1 and {MAX_RECENT}"),
        )
    return value


def _sdk_validation_error(
    label: str,
    value: object,
    kwargs: Mapping[str, Any],
    error: Exception,
) -> KyroDBValidationError:
    body = _fingerprint_payload(value, kwargs)
    return KyroDBValidationError(
        status_code=0,
        code="SDK_VALIDATION_FAILED",
        message=f"invalid KyroDB {label} request: {type(error).__name__}",
        body_sha256=body[0],
        body_length=body[1],
    )


def _fingerprint_payload(value: object, kwargs: Mapping[str, Any]) -> tuple[str, int]:
    payload_value: object
    if kwargs:
        payload_value = dict(kwargs)
    elif isinstance(value, BaseModel):
        payload_value = value.model_dump(mode="json", exclude_none=True)
    else:
        payload_value = value
    encoded = json.dumps(
        payload_value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest(), len(encoded)
