from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
from urllib.parse import quote

DATA_PLANE = "data"
OBSERVABILITY_PLANE = "observability"
ADMIN_PLANE = "observability-admin"


@dataclass(frozen=True)
class Route:
    method: str
    path: str
    plane: str
    response_model: str
    request_model: Optional[str] = None
    path_params: tuple[str, ...] = ()
    query_params: tuple[str, ...] = ()


ROUTES: dict[str, Route] = {
    "retrieve": Route(
        "POST", "/v1/context/retrieve", DATA_PLANE, "ContextPacket", "RetrieveRequest"
    ),
    "invalidate": Route(
        "POST",
        "/v1/context/invalidate",
        DATA_PLANE,
        "ChangeEventResult",
        "InvalidationRequest",
    ),
    "ingest_change_event": Route(
        "POST",
        "/v1/events/change",
        DATA_PLANE,
        "ChangeEventResult",
        "ChangeEvent",
    ),
    "upsert_document": Route(
        "POST",
        "/v1/documents/upsert",
        DATA_PLANE,
        "DocumentMutationResult",
        "UpsertDocumentRequest",
    ),
    "delete_document": Route(
        "POST",
        "/v1/documents/delete",
        DATA_PLANE,
        "DocumentMutationResult",
        "DeleteDocumentRequest",
    ),
    "record_feedback": Route(
        "POST",
        "/v1/context/feedback",
        DATA_PLANE,
        "StoredContextFeedback",
        "ContextFeedback",
    ),
    "get_feedback": Route(
        "GET",
        "/v1/context/feedback/{trace_id}",
        OBSERVABILITY_PLANE,
        "list[StoredContextFeedback]",
        path_params=("trace_id",),
    ),
    "get_trace": Route(
        "GET",
        "/v1/traces/{trace_id}",
        OBSERVABILITY_PLANE,
        "ContextTrace",
        path_params=("trace_id",),
    ),
    "diagnose_trace": Route(
        "GET",
        "/v1/traces/{trace_id}/diagnosis",
        OBSERVABILITY_PLANE,
        "TraceDiagnosis",
        path_params=("trace_id",),
    ),
    "health": Route("GET", "/v1/health/context", ADMIN_PLANE, "ContextHealth"),
    "context_proof_report": Route(
        "GET",
        "/v1/proofs/context",
        OBSERVABILITY_PLANE,
        "ContextProofReport",
        query_params=("recent",),
    ),
    "build_proof_bundle": Route(
        "POST",
        "/v1/proofs/bundle",
        ADMIN_PLANE,
        "ProofBundle",
        "ProofBundleRequest",
    ),
    "build_root_cause_report": Route(
        "POST",
        "/v1/root-cause/report",
        ADMIN_PLANE,
        "RootCauseReport",
        "RootCauseReportRequest",
    ),
    "diff_replay_runs": Route(
        "POST",
        "/v1/replay/diff",
        ADMIN_PLANE,
        "ReplayDiffResult",
        "ReplayDiffRequest",
    ),
    "run_counterfactual_replay": Route(
        "POST",
        "/v1/replay/counterfactual",
        ADMIN_PLANE,
        "CounterfactualResult",
        "CounterfactualReplayRequest",
    ),
    "create_shadow_session": Route(
        "POST",
        "/v1/replay/shadow-sessions",
        ADMIN_PLANE,
        "ShadowSessionCreateResponse",
        "ShadowSessionCreateRequest",
    ),
    "export_replay_capture": Route(
        "GET",
        "/v1/replay/capture",
        ADMIN_PLANE,
        "ReplayCaptureExport",
        query_params=("recent",),
    ),
}


def format_path(template: str, **path_params: str) -> str:
    encoded = {name: _encode_path_param(name, value) for name, value in path_params.items()}
    return template.format(**encoded)


def _encode_path_param(name: str, value: str) -> str:
    if not value:
        raise ValueError(f"{name} path parameter must be non-empty")
    if value != value.strip():
        raise ValueError(f"{name} path parameter must not contain surrounding whitespace")
    if any(ord(character) < 0x20 for character in value):
        raise ValueError(f"{name} path parameter must not contain control characters")
    return quote(value, safe="")
