from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Optional

import httpx

from ._coerce import coerce_model, payload, validate_recent
from ._env import client_kwargs_from_env
from ._response import parse_model, parse_model_list
from ._routes import ROUTES, format_path
from .models import (
    ChangeEvent,
    ChangeEventResult,
    ContextFeedback,
    ContextHealth,
    ContextPacket,
    ContextProofReport,
    ContextTrace,
    CounterfactualReplayRequest,
    CounterfactualResult,
    DeleteDocumentRequest,
    DocumentMutationResult,
    InvalidationRequest,
    ProofBundle,
    ProofBundleRequest,
    ReplayCaptureExport,
    ReplayDiffRequest,
    ReplayDiffResult,
    RetrieveRequest,
    RootCauseReport,
    RootCauseReportRequest,
    ShadowSessionCreateRequest,
    ShadowSessionCreateResponse,
    StoredContextFeedback,
    TraceDiagnosis,
    UpsertDocumentRequest,
)
from .transport import SyncKyroTransport, TransportConfig


class KyroDBClient:
    """Synchronous KyroDB Runtime client.

    Data-plane methods live on the root client. Observability and admin evidence
    methods are intentionally split onto `client.observability` and
    `client.admin` so privilege boundaries remain visible in application code.
    """

    def __init__(
        self,
        *,
        base_url: str,
        data_plane_token: str,
        observability_token: Optional[str] = None,
        shadow_session_id: Optional[str] = None,
        allow_insecure_http: bool = False,
        allow_shared_tokens: bool = False,
        timeout: float = 10.0,
        max_response_bytes: int = 16 * 1024 * 1024,
        max_request_bytes: int = 4 * 1024 * 1024,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        config = TransportConfig(
            base_url=base_url,
            data_plane_token=data_plane_token,
            observability_token=observability_token,
            shadow_session_id=shadow_session_id,
            allow_insecure_http=allow_insecure_http,
            allow_shared_tokens=allow_shared_tokens,
            timeout=timeout,
            max_response_bytes=max_response_bytes,
            max_request_bytes=max_request_bytes,
        )
        self._transport = SyncKyroTransport(config, http_client=http_client)
        self._observability = ObservabilityAPI(self._transport)
        self._admin = AdminAPI(self._transport)

    @classmethod
    def from_env(
        cls,
        env: Optional[Mapping[str, str]] = None,
        **overrides: Any,
    ) -> KyroDBClient:
        kwargs = client_kwargs_from_env(env)
        kwargs.update(overrides)
        return cls(**kwargs)

    def __repr__(self) -> str:
        return f"KyroDBClient(base_url={self._transport.base_url!r}, tokens=<redacted>)"

    def __enter__(self) -> KyroDBClient:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def close(self) -> None:
        self._transport.close()

    @property
    def observability(self) -> ObservabilityAPI:
        self._transport.require_observability_token()
        return self._observability

    @property
    def admin(self) -> AdminAPI:
        self._transport.require_observability_token()
        return self._admin

    def retrieve(self, request: Optional[object] = None, **kwargs: Any) -> ContextPacket:
        route = ROUTES["retrieve"]
        model = coerce_model(RetrieveRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ContextPacket, data, label="retrieve")

    def invalidate(self, request: Optional[object] = None, **kwargs: Any) -> ChangeEventResult:
        route = ROUTES["invalidate"]
        model = coerce_model(InvalidationRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ChangeEventResult, data, label="invalidate")

    def ingest_change_event(
        self,
        event: Optional[object] = None,
        **kwargs: Any,
    ) -> ChangeEventResult:
        route = ROUTES["ingest_change_event"]
        model = coerce_model(ChangeEvent, event, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ChangeEventResult, data, label="ingest_change_event")

    def upsert_document(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> DocumentMutationResult:
        route = ROUTES["upsert_document"]
        model = coerce_model(UpsertDocumentRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(DocumentMutationResult, data, label="upsert_document")

    def delete_document(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> DocumentMutationResult:
        route = ROUTES["delete_document"]
        model = coerce_model(DeleteDocumentRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(DocumentMutationResult, data, label="delete_document")

    def record_feedback(
        self,
        feedback: Optional[object] = None,
        **kwargs: Any,
    ) -> StoredContextFeedback:
        route = ROUTES["record_feedback"]
        model = coerce_model(ContextFeedback, feedback, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(StoredContextFeedback, data, label="record_feedback")


class ObservabilityAPI:
    def __init__(self, transport: SyncKyroTransport) -> None:
        self._transport = transport

    def get_feedback(self, trace_id: str) -> list[StoredContextFeedback]:
        route = ROUTES["get_feedback"]
        data = self._transport.request_json(
            route.method,
            format_path(route.path, trace_id=trace_id),
            plane=route.plane,
        )
        return parse_model_list(StoredContextFeedback, data, label="get_feedback")

    def get_trace(self, trace_id: str) -> ContextTrace:
        route = ROUTES["get_trace"]
        data = self._transport.request_json(
            route.method,
            format_path(route.path, trace_id=trace_id),
            plane=route.plane,
        )
        return parse_model(ContextTrace, data, label="get_trace")

    def diagnose_trace(self, trace_id: str) -> TraceDiagnosis:
        route = ROUTES["diagnose_trace"]
        data = self._transport.request_json(
            route.method,
            format_path(route.path, trace_id=trace_id),
            plane=route.plane,
        )
        return parse_model(TraceDiagnosis, data, label="diagnose_trace")

    def health(self) -> ContextHealth:
        route = ROUTES["health"]
        data = self._transport.request_json(route.method, route.path, plane=route.plane)
        return parse_model(ContextHealth, data, label="health")

    def context_proof_report(self, *, recent: Optional[int] = None) -> ContextProofReport:
        route = ROUTES["context_proof_report"]
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            params={"recent": validate_recent(recent)},
        )
        return parse_model(ContextProofReport, data, label="context_proof_report")


class AdminAPI:
    def __init__(self, transport: SyncKyroTransport) -> None:
        self._transport = transport

    def build_proof_bundle(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> ProofBundle:
        route = ROUTES["build_proof_bundle"]
        model = coerce_model(ProofBundleRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ProofBundle, data, label="build_proof_bundle")

    def build_root_cause_report(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> RootCauseReport:
        route = ROUTES["build_root_cause_report"]
        model = coerce_model(RootCauseReportRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(RootCauseReport, data, label="build_root_cause_report")

    def diff_replay_runs(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> ReplayDiffResult:
        route = ROUTES["diff_replay_runs"]
        model = coerce_model(ReplayDiffRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ReplayDiffResult, data, label="diff_replay_runs")

    def run_counterfactual_replay(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> CounterfactualResult:
        route = ROUTES["run_counterfactual_replay"]
        model = coerce_model(CounterfactualReplayRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(CounterfactualResult, data, label="run_counterfactual_replay")

    def create_shadow_session(
        self,
        request: Optional[object] = None,
        **kwargs: Any,
    ) -> ShadowSessionCreateResponse:
        route = ROUTES["create_shadow_session"]
        model = coerce_model(ShadowSessionCreateRequest, request, kwargs)
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            json_payload=payload(model),
        )
        return parse_model(ShadowSessionCreateResponse, data, label="create_shadow_session")

    def export_replay_capture(self, *, recent: Optional[int] = None) -> ReplayCaptureExport:
        route = ROUTES["export_replay_capture"]
        data = self._transport.request_json(
            route.method,
            route.path,
            plane=route.plane,
            params={"recent": validate_recent(recent)},
        )
        return parse_model(ReplayCaptureExport, data, label="export_replay_capture")
