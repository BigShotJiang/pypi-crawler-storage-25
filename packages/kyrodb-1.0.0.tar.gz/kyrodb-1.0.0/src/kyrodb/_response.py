from __future__ import annotations

import hashlib
import json
from typing import Any, TypeVar

from pydantic import BaseModel, ValidationError

from .errors import KyroDBDecodeError

ModelT = TypeVar("ModelT", bound=BaseModel)


def parse_model(model_type: type[ModelT], data: Any, *, label: str) -> ModelT:
    try:
        return model_type.model_validate(data)
    except ValidationError as error:
        raise _decode_error(label, data) from error


def parse_model_list(model_type: type[ModelT], data: Any, *, label: str) -> list[ModelT]:
    if not isinstance(data, list):
        raise _decode_error(label, data)
    parsed: list[ModelT] = []
    for index, entry in enumerate(data):
        try:
            parsed.append(model_type.model_validate(entry))
        except ValidationError as error:
            raise _decode_error(f"{label}[{index}]", data) from error
    return parsed


def _decode_error(label: str, data: Any) -> KyroDBDecodeError:
    body_sha256, body_length = _fingerprint(data)
    return KyroDBDecodeError(
        "KyroDB runtime returned a response that did not match the SDK contract "
        f"for {label}; body_sha256={body_sha256} body_length={body_length}"
    )


def _fingerprint(data: Any) -> tuple[str, int]:
    encoded = json.dumps(
        data,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest(), len(encoded)
