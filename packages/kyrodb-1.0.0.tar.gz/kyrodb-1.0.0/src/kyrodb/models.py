from __future__ import annotations

import json
import math
import re
from collections.abc import Mapping
from datetime import datetime
from enum import Enum
from typing import Any, Literal, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

JsonObject = dict[str, Any]
_CONNECTOR_KEY = re.compile(r"^[A-Za-z0-9_]+$")
EnumT = TypeVar("EnumT", bound=Enum)

MAX_BODY_BYTES = 4 * 1024 * 1024
MAX_EMBEDDING_DIMENSIONS = 16_384
MAX_TOP_K = 100
MAX_SCOPE_COMPONENT_BYTES = 256
MAX_AUTH_SCOPES = 32
MAX_DOCUMENT_ID_BYTES = 1_024
MAX_DOCUMENT_CONTENT_BYTES = 1024 * 1024
MAX_METADATA_ENTRIES = 256
MAX_METADATA_KEY_BYTES = 128
MAX_METADATA_VALUE_BYTES = 4_096
MAX_FILTER_DEPTH = 16
MAX_FILTER_NODES = 256
MAX_FILTER_VALUES = 256
MAX_FEEDBACK_COMMENT_BYTES = 8_192
MAX_REPLAY_STEPS = 2_000
MAX_RECENT = 1_000
MIN_CAPTURE_SCHEMA_VERSION = 2
CURRENT_CAPTURE_SCHEMA_VERSION = 3


def _byte_len(value: str) -> int:
    return len(value.encode("utf-8"))


def _clean_text(
    label: str,
    value: str,
    *,
    required: bool = False,
    max_bytes: Optional[int] = None,
) -> str:
    if required and not value:
        raise ValueError(f"{label} must be non-empty")
    if value != value.strip():
        raise ValueError(f"{label} must not contain surrounding whitespace")
    if any(ord(character) < 0x20 or ord(character) == 0x7F for character in value):
        raise ValueError(f"{label} must not contain control characters")
    if max_bytes is not None and _byte_len(value) > max_bytes:
        raise ValueError(f"{label} must be at most {max_bytes} bytes")
    return value


def _clean_optional_text(
    label: str,
    value: Optional[str],
    *,
    max_bytes: Optional[int] = None,
) -> Optional[str]:
    if value is None:
        return None
    if not value:
        raise ValueError(f"{label} must be non-empty when provided")
    return _clean_text(label, value, max_bytes=max_bytes)


def _clean_text_list(
    label: str,
    value: Optional[list[str]],
    *,
    max_items: Optional[int] = None,
    max_bytes: Optional[int] = None,
) -> Optional[list[str]]:
    if value is None:
        return None
    if not value:
        raise ValueError(f"{label} must be non-empty when provided")
    if max_items is not None and len(value) > max_items:
        raise ValueError(f"{label} must contain at most {max_items} entries")
    return [
        _clean_text(f"{label} entry", entry, required=True, max_bytes=max_bytes) for entry in value
    ]


def _clean_json_object(label: str, value: JsonObject) -> JsonObject:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object")
    return value


def _stable_json_key(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _model_to_json_if_needed(value: object) -> object:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", exclude_none=True)
    return value


def _is_rfc3339_datetime(value: object) -> bool:
    if not isinstance(value, str) or not value:
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def _coerce_enum(enum_type: type[EnumT], label: str, value: object) -> object:
    if isinstance(value, enum_type):
        return value
    if isinstance(value, str):
        try:
            return enum_type(value)
        except ValueError as error:
            allowed = ", ".join(member.value for member in enum_type)
            raise ValueError(f"{label} must be one of: {allowed}") from error
    return value


def _reject_present_fields(model: BaseModel, fields: tuple[str, ...], variant: str) -> None:
    unexpected = [field for field in fields if getattr(model, field) is not None]
    if unexpected:
        joined = ", ".join(unexpected)
        raise ValueError(f"{variant} filter does not allow field(s): {joined}")


def _runtime_filter_stats(filter_: RuntimeFilter, depth: int = 1) -> tuple[int, int]:
    if filter_.type in (RuntimeFilterType.AND, RuntimeFilterType.OR):
        children = filter_.filters or []
        child_stats = [_runtime_filter_stats(child, depth + 1) for child in children]
        nodes = 1 + sum(child_nodes for child_nodes, _ in child_stats)
        max_depth = max((child_depth for _, child_depth in child_stats), default=depth)
        return nodes, max_depth
    if filter_.type == RuntimeFilterType.NOT and filter_.filter is not None:
        child_nodes, child_depth = _runtime_filter_stats(filter_.filter, depth + 1)
        return 1 + child_nodes, child_depth
    return 1, depth


class _StrictRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        validate_assignment=True,
        strict=True,
    )


class _FlexibleRequest(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True, validate_assignment=True)


class _Response(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class PacketStatus(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    DEGRADED = "degraded"
    STALE_BLOCKED = "stale_blocked"


class FreshnessMode(str, Enum):
    STRICT = "strict"
    BALANCED = "balanced"
    EVENTUAL = "eventual"


class OwnershipMode(str, Enum):
    WRITE_THROUGH = "write_through"
    EVENT_FEED = "event_feed"
    SNAPSHOT_BUNDLE = "snapshot_bundle"
    BEST_EFFORT = "best_effort"


class RuntimeFilterType(str, Enum):
    EXACT = "exact"
    IN = "in"
    RANGE = "range"
    AND = "and"
    OR = "or"
    NOT = "not"


class ChangeTargetType(str, Enum):
    DOCUMENT = "document"
    NAMESPACE = "namespace"
    CONNECTOR = "connector"
    BUNDLE = "bundle"
    POLICY = "policy"
    TENANT = "tenant"
    ALL = "all"


class ChangeType(str, Enum):
    CONTENT_UPDATED = "content_updated"
    METADATA_UPDATED = "metadata_updated"
    DELETED = "deleted"
    CREATED = "created"
    UNPUBLISHED = "unpublished"
    ACCESS_POLICY_UPDATED = "access_policy_updated"
    BUNDLE_PUBLISHED = "bundle_published"
    NAMESPACE_REBUILT = "namespace_rebuilt"
    CONNECTOR_RESYNCED = "connector_resynced"


class MutationOutcome(str, Enum):
    INSERTED = "inserted"
    UPDATED = "updated"
    DELETED = "deleted"
    NOT_FOUND = "not_found"


class FeedbackSignal(str, Enum):
    USEFUL = "useful"
    IRRELEVANT = "irrelevant"
    STALE = "stale"
    WRONG_SCOPE = "wrong_scope"


class TraceDiagnosisKind(str, Enum):
    FRESHNESS_DOWNGRADE = "freshness_downgrade"
    STRICT_FRESHNESS_BLOCKED = "strict_freshness_blocked"
    WATERMARK_GENERATION_LAG = "watermark_generation_lag"
    WATERMARK_GENERATION_AHEAD = "watermark_generation_ahead"
    WEAK_WATERMARK_EVIDENCE = "weak_watermark_evidence"
    FEEDBACK_REPORTED_STALE = "feedback_reported_stale"
    FEEDBACK_REPORTED_WRONG_SCOPE = "feedback_reported_wrong_scope"
    FRESH_BUT_IRRELEVANT = "fresh_but_irrelevant"
    BACKEND_UNAVAILABLE = "backend_unavailable"
    STALE_FALLBACK = "stale_fallback"
    CACHE_REUSE_HIT = "cache_reuse_hit"
    FRESH_BACKEND_FETCH = "fresh_backend_fetch"


class ReplayStepType(str, Enum):
    RETRIEVE = "retrieve"
    CHANGE_EVENT = "change_event"
    INVALIDATE = "invalidate"
    UPSERT = "upsert"
    DELETE = "delete"


class ReplayStatus(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    DEGRADED = "degraded"
    STALE_BLOCKED = "stale_blocked"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    INSERTED = "inserted"
    UPDATED = "updated"
    DELETED = "deleted"
    NOT_FOUND = "not_found"
    ERROR = "error"


class CounterfactualInterventionType(str, Enum):
    DROP_STEP = "drop_step"
    MOVE_STEP_BEFORE = "move_step_before"
    MOVE_STEP_AFTER = "move_step_after"


class ProofBundleSource(str, Enum):
    LIVE_CAPTURE_EXPORT = "live_capture_export"
    LIVE_SHADOW_RUN = "live_shadow_run"
    CALLER_SUPPLIED = "caller_supplied"


class Scope(_StrictRequest):
    tenant_id: str
    namespace: str
    app_id: Optional[str] = None
    locale: Optional[str] = None
    auth_scope: Optional[list[str]] = None
    entitlement_boundary: Optional[str] = None
    embedding_model_id: Optional[str] = None
    reranker_version: Optional[str] = None
    prompt_template_version: Optional[str] = None

    @field_validator("tenant_id", "namespace")
    @classmethod
    def _required_non_empty(cls, value: str) -> str:
        return _clean_text(
            "scope field",
            value,
            required=True,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )

    @field_validator(
        "app_id",
        "locale",
        "entitlement_boundary",
        "embedding_model_id",
        "reranker_version",
        "prompt_template_version",
    )
    @classmethod
    def _optional_scope_identity(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text("scope field", value, max_bytes=MAX_SCOPE_COMPONENT_BYTES)

    @field_validator("auth_scope")
    @classmethod
    def _auth_scope_entries(cls, value: Optional[list[str]]) -> Optional[list[str]]:
        return _clean_text_list(
            "auth_scope",
            value,
            max_items=MAX_AUTH_SCOPES,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )


class WriteScope(_StrictRequest):
    tenant_id: str
    namespace: str

    @field_validator("tenant_id", "namespace")
    @classmethod
    def _required_non_empty(cls, value: str) -> str:
        return _clean_text(
            "write scope field",
            value,
            required=True,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )


class RuntimeFilter(_StrictRequest):
    type: RuntimeFilterType
    key: Optional[str] = None
    value: Optional[str] = None
    values: Optional[list[str]] = None
    min: Optional[float] = None
    max: Optional[float] = None
    filters: Optional[list[RuntimeFilter]] = None
    filter: Optional[RuntimeFilter] = None

    @classmethod
    def exact(cls, key: str, value: str) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.EXACT, key=key, value=value)

    @classmethod
    def one_of(cls, key: str, values: list[str]) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.IN, key=key, values=values)

    @classmethod
    def range(cls, key: str, min: float, max: float) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.RANGE, key=key, min=min, max=max)

    @classmethod
    def all(cls, filters: list[RuntimeFilter]) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.AND, filters=filters)

    @classmethod
    def any(cls, filters: list[RuntimeFilter]) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.OR, filters=filters)

    @classmethod
    def not_(cls, filter: RuntimeFilter) -> RuntimeFilter:
        return cls(type=RuntimeFilterType.NOT, filter=filter)

    @field_validator("type", mode="before")
    @classmethod
    def _type_enum(cls, value: object) -> object:
        return _coerce_enum(RuntimeFilterType, "filter type", value)

    @field_validator("key")
    @classmethod
    def _connector_key(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        if not _CONNECTOR_KEY.fullmatch(value):
            raise ValueError(
                "filter keys must contain only ASCII letters, numbers, and underscores"
            )
        _clean_text("filter key", value, required=True, max_bytes=MAX_METADATA_KEY_BYTES)
        return value

    @field_validator("value")
    @classmethod
    def _value_non_empty(cls, value: Optional[str]) -> Optional[str]:
        if value == "":
            raise ValueError("filter value must be non-empty")
        if value is not None and _byte_len(value) > MAX_METADATA_VALUE_BYTES:
            raise ValueError(f"filter value must be at most {MAX_METADATA_VALUE_BYTES} bytes")
        return value

    @model_validator(mode="after")
    def _validate_variant(self) -> RuntimeFilter:
        if self.type == RuntimeFilterType.EXACT:
            if self.key is None or self.value is None:
                raise ValueError("exact filter requires key and value")
            _reject_present_fields(self, ("values", "min", "max", "filters", "filter"), "exact")
        elif self.type == RuntimeFilterType.IN:
            if self.key is None or not self.values:
                raise ValueError("in filter requires key and non-empty values")
            if len(self.values) > MAX_FILTER_VALUES:
                raise ValueError(f"in filter values must contain at most {MAX_FILTER_VALUES} items")
            if any(value == "" for value in self.values):
                raise ValueError("in filter values must be non-empty")
            if any(_byte_len(value) > MAX_METADATA_VALUE_BYTES for value in self.values):
                raise ValueError(
                    f"in filter values must be at most {MAX_METADATA_VALUE_BYTES} bytes each"
                )
            _reject_present_fields(self, ("value", "min", "max", "filters", "filter"), "in")
        elif self.type == RuntimeFilterType.RANGE:
            if self.key is None or self.min is None or self.max is None:
                raise ValueError("range filter requires key, min, and max")
            if not math.isfinite(self.min) or not math.isfinite(self.max):
                raise ValueError("range filter bounds must be finite")
            if self.min > self.max:
                raise ValueError("range filter min must be <= max")
            _reject_present_fields(self, ("value", "values", "filters", "filter"), "range")
        elif self.type in (RuntimeFilterType.AND, RuntimeFilterType.OR):
            if not self.filters:
                raise ValueError("logical filters require at least one child filter")
            _reject_present_fields(
                self,
                ("key", "value", "values", "min", "max", "filter"),
                self.type.value,
            )
        elif self.type == RuntimeFilterType.NOT:
            if self.filter is None:
                raise ValueError("not filter requires a child filter")
            _reject_present_fields(
                self,
                ("key", "value", "values", "min", "max", "filters"),
                "not",
            )
        nodes, depth = _runtime_filter_stats(self)
        if nodes > MAX_FILTER_NODES:
            raise ValueError(f"filter tree must contain at most {MAX_FILTER_NODES} nodes")
        if depth > MAX_FILTER_DEPTH:
            raise ValueError(f"filter tree depth must be at most {MAX_FILTER_DEPTH}")
        return self


class ChangeTarget(_StrictRequest):
    type: ChangeTargetType
    doc_id: Optional[str] = None
    namespace: Optional[str] = None
    connector_id: Optional[str] = None
    bundle_id: Optional[str] = None
    policy_key: Optional[str] = None
    tenant_id: Optional[str] = None

    @field_validator("type", mode="before")
    @classmethod
    def _type_enum(cls, value: object) -> object:
        return _coerce_enum(ChangeTargetType, "change target type", value)

    @field_validator("doc_id")
    @classmethod
    def _optional_document_identity(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text(
            "change target document field",
            value,
            max_bytes=MAX_DOCUMENT_ID_BYTES,
        )

    @field_validator("namespace", "connector_id", "bundle_id", "policy_key", "tenant_id")
    @classmethod
    def _optional_target_identity(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text(
            "change target field",
            value,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )

    @model_validator(mode="after")
    def _validate_target(self) -> ChangeTarget:
        requirements = {
            ChangeTargetType.DOCUMENT: ("doc_id", self.doc_id),
            ChangeTargetType.NAMESPACE: ("namespace", self.namespace),
            ChangeTargetType.CONNECTOR: ("connector_id", self.connector_id),
            ChangeTargetType.BUNDLE: ("bundle_id", self.bundle_id),
            ChangeTargetType.POLICY: ("policy_key", self.policy_key),
            ChangeTargetType.TENANT: ("tenant_id", self.tenant_id),
        }
        required = requirements.get(self.type)
        if required is not None:
            field_name, value = required
            if not value:
                raise ValueError(f"{self.type.value} target requires {field_name}")
        allowed_fields = {
            ChangeTargetType.DOCUMENT: {"doc_id"},
            ChangeTargetType.NAMESPACE: {"namespace"},
            ChangeTargetType.CONNECTOR: {"connector_id"},
            ChangeTargetType.BUNDLE: {"bundle_id"},
            ChangeTargetType.POLICY: {"policy_key"},
            ChangeTargetType.TENANT: {"tenant_id"},
            ChangeTargetType.ALL: set(),
        }[self.type]
        present_unexpected = [
            field
            for field in (
                "doc_id",
                "namespace",
                "connector_id",
                "bundle_id",
                "policy_key",
                "tenant_id",
            )
            if field not in allowed_fields and getattr(self, field) is not None
        ]
        if present_unexpected:
            joined = ", ".join(present_unexpected)
            raise ValueError(f"{self.type.value} target does not allow field(s): {joined}")
        return self


class ChangeScope(_StrictRequest):
    tenant_id: Optional[str] = None
    namespace: Optional[str] = None
    connector_id: Optional[str] = None

    @field_validator("tenant_id", "namespace", "connector_id")
    @classmethod
    def _optional_scope_identity(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text(
            "change scope field", value, max_bytes=MAX_SCOPE_COMPONENT_BYTES
        )


class RetrieveRequest(_StrictRequest):
    query_embedding: list[float]
    scope: Scope
    filters: Optional[RuntimeFilter] = None
    top_k: int = Field(default=6, ge=1, le=MAX_TOP_K)
    freshness_mode: Optional[FreshnessMode] = None
    include_content: bool = True
    trace: bool = True

    @field_validator("freshness_mode", mode="before")
    @classmethod
    def _freshness_mode_enum(cls, value: object) -> object:
        if value is None:
            return None
        return _coerce_enum(FreshnessMode, "freshness_mode", value)

    @field_validator("query_embedding")
    @classmethod
    def _embedding_is_finite(cls, value: list[float]) -> list[float]:
        if not value:
            raise ValueError("query_embedding must contain at least one number")
        if len(value) > MAX_EMBEDDING_DIMENSIONS:
            raise ValueError(
                f"query_embedding must contain at most {MAX_EMBEDDING_DIMENSIONS} numbers"
            )
        if any(not math.isfinite(component) for component in value):
            raise ValueError("query_embedding must contain only finite numbers")
        return value


class ChangeEvent(_FlexibleRequest):
    target: ChangeTarget
    change_type: ChangeType
    scope: ChangeScope
    timestamp: datetime
    source_event_id: str
    revision: Optional[str] = None

    @field_validator("source_event_id")
    @classmethod
    def _source_event_id_non_empty(cls, value: str) -> str:
        return _clean_text(
            "source_event_id",
            value,
            required=True,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )

    @field_validator("revision")
    @classmethod
    def _optional_revision(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text("revision", value, max_bytes=MAX_SCOPE_COMPONENT_BYTES)


class InvalidationRequest(_StrictRequest):
    target: ChangeTarget
    tenant_id: Optional[str] = None
    reason: Optional[str] = None

    @field_validator("tenant_id")
    @classmethod
    def _optional_tenant_id(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text("tenant_id", value, max_bytes=MAX_SCOPE_COMPONENT_BYTES)


class Document(_StrictRequest):
    id: str
    embedding: Optional[list[float]] = None
    content: Optional[str] = None
    metadata: Optional[dict[str, str]] = None

    @field_validator("id")
    @classmethod
    def _id_non_empty(cls, value: str) -> str:
        return _clean_text(
            "document id",
            value,
            required=True,
            max_bytes=MAX_DOCUMENT_ID_BYTES,
        )

    @field_validator("embedding")
    @classmethod
    def _embedding_is_finite(cls, value: Optional[list[float]]) -> Optional[list[float]]:
        if value is not None:
            if not value:
                raise ValueError("embedding must contain at least one number when provided")
            if len(value) > MAX_EMBEDDING_DIMENSIONS:
                raise ValueError(
                    f"embedding must contain at most {MAX_EMBEDDING_DIMENSIONS} numbers"
                )
            if any(not math.isfinite(component) for component in value):
                raise ValueError("embedding must contain only finite numbers")
        return value

    @field_validator("content")
    @classmethod
    def _content_bounded(cls, value: Optional[str]) -> Optional[str]:
        if value is not None and _byte_len(value) > MAX_DOCUMENT_CONTENT_BYTES:
            raise ValueError(f"document content must be at most {MAX_DOCUMENT_CONTENT_BYTES} bytes")
        return value

    @field_validator("metadata")
    @classmethod
    def _metadata_bounded(cls, value: Optional[dict[str, str]]) -> Optional[dict[str, str]]:
        if value is None:
            return None
        if len(value) > MAX_METADATA_ENTRIES:
            raise ValueError(
                f"document metadata must contain at most {MAX_METADATA_ENTRIES} entries"
            )
        for key, metadata_value in value.items():
            if not _CONNECTOR_KEY.fullmatch(key):
                raise ValueError(
                    "document metadata keys must contain only ASCII letters, "
                    "numbers, and underscores"
                )
            _clean_text(
                "document metadata key", key, required=True, max_bytes=MAX_METADATA_KEY_BYTES
            )
            if _byte_len(metadata_value) > MAX_METADATA_VALUE_BYTES:
                raise ValueError(
                    f"document metadata values must be at most {MAX_METADATA_VALUE_BYTES} bytes"
                )
        return value


class UpsertDocumentRequest(_StrictRequest):
    scope: WriteScope
    document: Document


class DeleteDocumentRequest(_StrictRequest):
    scope: WriteScope
    id: str

    @field_validator("id")
    @classmethod
    def _id_non_empty(cls, value: str) -> str:
        return _clean_text(
            "document id",
            value,
            required=True,
            max_bytes=MAX_DOCUMENT_ID_BYTES,
        )


class ContextFeedback(_FlexibleRequest):
    trace_id: str
    signal: FeedbackSignal
    item_ids: Optional[list[str]] = None
    comment: Optional[str] = None

    @field_validator("trace_id")
    @classmethod
    def _trace_id_non_empty(cls, value: str) -> str:
        return _clean_text("trace_id", value, required=True, max_bytes=MAX_DOCUMENT_ID_BYTES)

    @field_validator("item_ids")
    @classmethod
    def _item_ids(cls, value: Optional[list[str]]) -> Optional[list[str]]:
        return _clean_text_list(
            "item_ids",
            value,
            max_items=MAX_FILTER_VALUES,
            max_bytes=MAX_DOCUMENT_ID_BYTES,
        )

    @field_validator("comment")
    @classmethod
    def _comment_bounded(cls, value: Optional[str]) -> Optional[str]:
        if value is not None and _byte_len(value) > MAX_FEEDBACK_COMMENT_BYTES:
            raise ValueError(f"feedback comment must be at most {MAX_FEEDBACK_COMMENT_BYTES} bytes")
        return value


class ProofBundleRequest(_StrictRequest):
    recent: Optional[int] = Field(default=None, ge=1, le=MAX_RECENT)
    baseline_capture: Optional[TrafficCaptureArtifact] = None
    candidate_run: Optional[ReplayRunReport] = None

    @field_validator("baseline_capture", "candidate_run", mode="before")
    @classmethod
    def _coerce_artifact_models(cls, value: object) -> object:
        return _model_to_json_if_needed(value)


class RootCauseReportRequest(_StrictRequest):
    recent: Optional[int] = Field(default=None, ge=1, le=MAX_RECENT)
    trace_id: Optional[str] = None
    max_incidents: Optional[int] = Field(default=None, ge=1, le=MAX_REPLAY_STEPS)
    include_non_stale: bool = False

    @field_validator("trace_id")
    @classmethod
    def _optional_trace_id(cls, value: Optional[str]) -> Optional[str]:
        return _clean_optional_text("trace_id", value, max_bytes=MAX_DOCUMENT_ID_BYTES)


class CounterfactualIntervention(_StrictRequest):
    type: CounterfactualInterventionType
    step_index: int = Field(ge=0)
    before_step_index: Optional[int] = Field(default=None, ge=0)
    after_step_index: Optional[int] = Field(default=None, ge=0)

    @field_validator("type", mode="before")
    @classmethod
    def _type_enum(cls, value: object) -> object:
        return _coerce_enum(
            CounterfactualInterventionType,
            "counterfactual intervention type",
            value,
        )

    @classmethod
    def drop_step(cls, step_index: int) -> CounterfactualIntervention:
        return cls(type=CounterfactualInterventionType.DROP_STEP, step_index=step_index)

    @classmethod
    def move_step_before(
        cls,
        step_index: int,
        before_step_index: int,
    ) -> CounterfactualIntervention:
        return cls(
            type=CounterfactualInterventionType.MOVE_STEP_BEFORE,
            step_index=step_index,
            before_step_index=before_step_index,
        )

    @classmethod
    def move_step_after(
        cls,
        step_index: int,
        after_step_index: int,
    ) -> CounterfactualIntervention:
        return cls(
            type=CounterfactualInterventionType.MOVE_STEP_AFTER,
            step_index=step_index,
            after_step_index=after_step_index,
        )

    @model_validator(mode="after")
    def _validate_intervention_shape(self) -> CounterfactualIntervention:
        if self.type == CounterfactualInterventionType.DROP_STEP:
            if self.before_step_index is not None or self.after_step_index is not None:
                raise ValueError("drop_step intervention only allows step_index")
        elif self.type == CounterfactualInterventionType.MOVE_STEP_BEFORE:
            if self.before_step_index is None:
                raise ValueError("move_step_before intervention requires before_step_index")
            if self.after_step_index is not None:
                raise ValueError("move_step_before intervention does not allow after_step_index")
        elif self.type == CounterfactualInterventionType.MOVE_STEP_AFTER:
            if self.after_step_index is None:
                raise ValueError("move_step_after intervention requires after_step_index")
            if self.before_step_index is not None:
                raise ValueError("move_step_after intervention does not allow before_step_index")
        return self


class CounterfactualReplayScenario(_StrictRequest):
    name: str
    interventions: list[CounterfactualIntervention]

    @field_validator("name")
    @classmethod
    def _name_non_empty(cls, value: str) -> str:
        return _clean_text(
            "scenario name",
            value,
            required=True,
            max_bytes=MAX_SCOPE_COMPONENT_BYTES,
        )

    @field_validator("interventions")
    @classmethod
    def _interventions_non_empty(
        cls,
        value: list[CounterfactualIntervention],
    ) -> list[CounterfactualIntervention]:
        if not value:
            raise ValueError("scenario.interventions must contain at least one intervention")
        if len(value) > MAX_REPLAY_STEPS:
            raise ValueError(
                f"scenario.interventions must contain at most {MAX_REPLAY_STEPS} entries"
            )
        return value


class ContextPacket(_Response):
    packet_id: str
    trace_id: str
    status: PacketStatus
    freshness: JsonObject
    items: list[JsonObject]
    meta: JsonObject
    omissions: list[Any] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ContextTrace(_Response):
    trace_id: str
    scope: Scope
    status: PacketStatus
    freshness_generation: int
    items_returned: int


class ChangeEventResult(_Response):
    accepted: bool
    generation: int
    entries_invalidated: int
    detail: Optional[str] = None


class MutationAck(_Response):
    id: str
    scope: WriteScope
    verified: bool


class DocumentMutationResult(_Response):
    id: str
    outcome: MutationOutcome
    generation: int
    entries_invalidated: int
    invalidated_scope: JsonObject
    mutation_ack: MutationAck
    revision: Optional[str] = None


class StoredContextFeedback(_Response):
    trace_id: str
    signal: FeedbackSignal
    received_at: datetime
    trace_known: bool
    item_ids: Optional[list[str]] = None
    comment: Optional[str] = None


class TraceDiagnosis(_Response):
    trace_id: str
    kind: TraceDiagnosisKind
    summary: str
    recommended_actions: list[str]
    evidence: list[str] = Field(default_factory=list)
    feedback_signals: list[FeedbackSignal] = Field(default_factory=list)


class ContextHealth(_Response):
    status: str
    connector: str
    connector_health: str
    freshness_generation: int
    trace_retention: Optional[str] = None
    feedback_retention: Optional[str] = None
    capture_retention: Optional[str] = None
    trace_evidence_healthy: bool
    feedback_evidence_healthy: bool
    capture_evidence_healthy: bool
    planner_state_healthy: bool
    connector_capabilities: Optional[JsonObject] = None
    connector_certification: Optional[JsonObject] = None
    evidence_failures: list[str] = Field(default_factory=list)


class ContextProofReport(_Response):
    generated_at: datetime
    traces_considered: int
    feedback_entries_considered: int
    reuse_hit_rate: float
    degraded_count: int
    stale_blocked_count: int
    downgraded_count: int
    avg_latency_ms: float
    proof_quality: JsonObject
    connector_certification: JsonObject
    incident_counts: list[JsonObject] = Field(default_factory=list)
    feedback_signal_counts: list[JsonObject] = Field(default_factory=list)
    incident_trace_keys: list[str] = Field(default_factory=list)
    negative_feedback_trace_keys: list[str] = Field(default_factory=list)
    redactions: list[str] = Field(default_factory=list)


class ReplayRecord(_Response):
    step_index: int
    label: str
    step_type: ReplayStepType
    status: ReplayStatus
    generation: int
    ownership_mode: Optional[OwnershipMode] = None
    warnings: list[str]
    items: list[JsonObject]


class ReplayRunReport(_Response):
    generated_at: datetime
    total_steps: int
    retrieve_steps: int
    complete_count: int
    degraded_count: int
    stale_blocked_count: int
    total_latency_ms: float
    records: list[ReplayRecord]

    @model_validator(mode="after")
    def _validate_replay_run_shape(self) -> ReplayRunReport:
        if len(self.records) > MAX_REPLAY_STEPS:
            raise ValueError(f"replay run records must contain at most {MAX_REPLAY_STEPS} entries")
        if self.total_steps != len(self.records):
            raise ValueError("replay run total_steps must match records length")
        return self


class ReplayDiffRequest(_StrictRequest):
    baseline: ReplayRunReport
    candidate: ReplayRunReport

    @field_validator("baseline", "candidate", mode="before")
    @classmethod
    def _coerce_replay_runs(cls, value: object) -> object:
        return _model_to_json_if_needed(value)


class PartnerReplayRecordSummary(_Response):
    step_key: str
    step_index: int
    step_type: ReplayStepType
    status: ReplayStatus
    generation: int
    cache_hit: Optional[bool] = None
    requested_freshness_mode: Optional[FreshnessMode] = None
    served_freshness_mode: Optional[FreshnessMode] = None
    diagnosis_kind: Optional[TraceDiagnosisKind] = None
    mutation_outcome: Optional[MutationOutcome] = None
    mutation_ack_verified: Optional[bool] = None
    item_count: int
    warning_count: int
    watermark_count: int
    diagnostic_note_count: int


class PartnerReplayRunSummary(_Response):
    generated_at: datetime
    total_steps: int
    retrieve_steps: int
    complete_count: int
    degraded_count: int
    stale_blocked_count: int
    total_latency_ms: float
    records: list[PartnerReplayRecordSummary]
    redactions: list[str] = Field(default_factory=list)


class PartnerReplayStepDiffSummary(_Response):
    step_key: str
    step_index: int
    step_type: ReplayStepType
    changed_fields: list[str]
    baseline: PartnerReplayRecordSummary
    candidate: PartnerReplayRecordSummary


class ReplayPrimerState(_FlexibleRequest):
    current_generation: int = Field(default=0, ge=0)
    scope_generations: list[JsonObject] = Field(default_factory=list)
    processed_change_events: list[JsonObject] = Field(default_factory=list)
    processed_change_event_ids: list[str] = Field(default_factory=list)

    def is_empty(self) -> bool:
        return (
            self.current_generation == 0
            and not self.scope_generations
            and not self.processed_change_events
            and not self.processed_change_event_ids
        )

    @model_validator(mode="after")
    def _validate_primer_shape(self) -> ReplayPrimerState:
        for label, values in (
            ("scope_generations", self.scope_generations),
            ("processed_change_events", self.processed_change_events),
            ("processed_change_event_ids", self.processed_change_event_ids),
        ):
            if len(values) > MAX_REPLAY_STEPS:
                raise ValueError(f"replay_primer.{label} must contain at most {MAX_REPLAY_STEPS}")
        for event_id in self.processed_change_event_ids:
            _clean_text(
                "replay_primer.processed_change_event_ids entry",
                event_id,
                required=True,
                max_bytes=MAX_SCOPE_COMPONENT_BYTES,
            )
        if len(set(self.processed_change_event_ids)) != len(self.processed_change_event_ids):
            raise ValueError("replay_primer.processed_change_event_ids contains duplicates")

        seen_scopes: set[str] = set()
        for index, scope_generation in enumerate(self.scope_generations):
            generation = scope_generation.get("generation")
            if isinstance(generation, bool) or not isinstance(generation, int):
                raise ValueError(
                    f"replay_primer.scope_generations[{index}].generation must be an integer"
                )
            if generation > self.current_generation:
                raise ValueError(
                    "replay_primer.scope_generations"
                    f"[{index}].generation exceeds current_generation"
                )
            if not _is_rfc3339_datetime(scope_generation.get("acknowledged_at")):
                raise ValueError(
                    f"replay_primer.scope_generations[{index}].acknowledged_at must be RFC3339"
                )
            invalidation = scope_generation.get("invalidation")
            if isinstance(invalidation, Mapping) and not _is_rfc3339_datetime(
                invalidation.get("timestamp")
            ):
                raise ValueError(
                    "replay_primer.scope_generations"
                    f"[{index}].invalidation.timestamp must be RFC3339"
                )
            scope_key = _stable_json_key(scope_generation.get("scope"))
            if scope_key in seen_scopes:
                raise ValueError("replay_primer.scope_generations contains duplicate scopes")
            seen_scopes.add(scope_key)

        seen_outcomes: set[str] = set()
        for index, outcome in enumerate(self.processed_change_events):
            source_event_id = outcome.get("source_event_id")
            if not isinstance(source_event_id, str):
                raise ValueError(
                    "replay_primer.processed_change_events"
                    f"[{index}].source_event_id must be a string"
                )
            _clean_text(
                f"replay_primer.processed_change_events[{index}].source_event_id",
                source_event_id,
                required=True,
                max_bytes=MAX_SCOPE_COMPONENT_BYTES,
            )
            original_generation = outcome.get("original_generation")
            if isinstance(original_generation, bool) or not isinstance(original_generation, int):
                raise ValueError(
                    "replay_primer.processed_change_events"
                    f"[{index}].original_generation must be an integer"
                )
            if original_generation > self.current_generation:
                raise ValueError(
                    "replay_primer.processed_change_events"
                    f"[{index}].original_generation exceeds current_generation"
                )
            for optional_key in ("event_fingerprint", "idempotency_key"):
                optional_value = outcome.get(optional_key)
                if optional_value is not None:
                    if not isinstance(optional_value, str):
                        raise ValueError(
                            "replay_primer.processed_change_events"
                            f"[{index}].{optional_key} must be a string"
                        )
                    _clean_text(
                        f"replay_primer.processed_change_events[{index}].{optional_key}",
                        optional_value,
                        required=True,
                        max_bytes=MAX_SCOPE_COMPONENT_BYTES,
                    )
            lookup_key = outcome.get("idempotency_key") or source_event_id
            if lookup_key in seen_outcomes:
                raise ValueError(
                    "replay_primer.processed_change_events contains duplicate idempotency keys"
                )
            seen_outcomes.add(str(lookup_key))
        return self


class ShadowSessionCreateRequest(_StrictRequest):
    schema_version: Literal[1] = 1
    replay_primer: ReplayPrimerState
    allow_connector_mutations: bool = False

    @field_validator("replay_primer", mode="before")
    @classmethod
    def _coerce_replay_primer(cls, value: object) -> object:
        return _model_to_json_if_needed(value)


class TrafficCaptureArtifact(_FlexibleRequest):
    schema_version: int = Field(ge=MIN_CAPTURE_SCHEMA_VERSION, le=CURRENT_CAPTURE_SCHEMA_VERSION)
    generated_at: datetime
    total_steps: int = Field(ge=0)
    steps: list[JsonObject]
    replay_primer: Optional[ReplayPrimerState] = None

    @model_validator(mode="after")
    def _total_steps_matches_steps(self) -> TrafficCaptureArtifact:
        if len(self.steps) > MAX_REPLAY_STEPS:
            raise ValueError(f"capture steps must contain at most {MAX_REPLAY_STEPS} entries")
        if self.total_steps != len(self.steps):
            raise ValueError("capture total_steps must match steps length")
        _validate_capture_steps(self.steps)
        if (
            self.total_steps == 0
            and self.replay_primer is not None
            and not self.replay_primer.is_empty()
        ):
            raise ValueError("empty capture artifacts must not carry replay_primer state")
        _validate_top_level_replay_primer(self.replay_primer, self.steps)
        return self


class CounterfactualReplayRequest(_StrictRequest):
    capture: TrafficCaptureArtifact
    scenario: CounterfactualReplayScenario

    @field_validator("capture", mode="before")
    @classmethod
    def _coerce_capture_model(cls, value: object) -> object:
        return _model_to_json_if_needed(value)

    @field_validator("scenario", mode="before")
    @classmethod
    def _coerce_scenario_model(cls, value: object) -> object:
        return _model_to_json_if_needed(value)


class ReplayDiffResult(_Response):
    compared_steps: int
    changed_steps: int
    cache_hit_gains: int
    completion_gains: int
    diagnosis_changes: int
    latency_delta_ms: float
    only_in_baseline_count: int
    only_in_candidate_count: int
    duplicate_key_count: int
    validation_warning_count: int
    diffs: list[PartnerReplayStepDiffSummary]
    redactions: list[str] = Field(default_factory=list)


class CounterfactualResult(_Response):
    generated_at: datetime
    scenario_key: str
    intervention_count: int
    transformed_steps: int
    baseline_run_summary: PartnerReplayRunSummary
    counterfactual_run_summary: PartnerReplayRunSummary
    replay_diff_summary: ReplayDiffResult
    stale_block_delta: int
    degraded_delta: int
    completion_delta: int
    redactions: list[str] = Field(default_factory=list)


class ProofBundle(_Response):
    schema_version: int
    generated_at: datetime
    baseline_capture_source: ProofBundleSource
    baseline_capture_summary: JsonObject
    baseline_run_summary: JsonObject
    baseline_metrics: JsonObject
    candidate_run_source: Optional[ProofBundleSource] = None
    candidate_run_summary: Optional[JsonObject] = None
    candidate_metrics: Optional[JsonObject] = None
    replay_diff_summary: Optional[JsonObject] = None
    stale_prevented_count: int
    missing_trace_evidence_count: int
    evidence_quality: JsonObject
    feedback_entries_considered: int
    feedback_signal_counts: list[JsonObject]
    incident_examples: list[JsonObject]
    debug_examples: list[JsonObject]
    resolution_examples: list[JsonObject]
    evidence_warnings: list[str] = Field(default_factory=list)
    trust_summary: list[str]


class RootCauseReport(_Response):
    schema_version: int
    generated_at: datetime
    capture_summary: JsonObject
    traces_considered: int
    stale_incident_count: int
    safety_incident_count: int
    missing_trace_evidence_count: int
    root_causes: list[JsonObject]
    incidents: list[JsonObject]
    evidence_quality: JsonObject
    redactions: list[str]
    warnings: list[str] = Field(default_factory=list)


class ShadowSessionCreateResponse(_Response):
    schema_version: int
    session_id: str
    expires_at: datetime


class ReplayCaptureExport(_Response):
    schema_version: int = Field(ge=MIN_CAPTURE_SCHEMA_VERSION, le=CURRENT_CAPTURE_SCHEMA_VERSION)
    generated_at: datetime
    total_steps: int = Field(ge=0)
    steps: list[JsonObject]
    replay_primer: Optional[ReplayPrimerState] = None

    @model_validator(mode="after")
    def _validate_export_shape(self) -> ReplayCaptureExport:
        if len(self.steps) > MAX_REPLAY_STEPS:
            raise ValueError(f"capture steps must contain at most {MAX_REPLAY_STEPS} entries")
        if self.total_steps != len(self.steps):
            raise ValueError("capture total_steps must match steps length")
        _validate_capture_steps(self.steps)
        if (
            self.total_steps == 0
            and self.replay_primer is not None
            and not self.replay_primer.is_empty()
        ):
            raise ValueError("empty capture exports must not carry replay_primer state")
        _validate_top_level_replay_primer(self.replay_primer, self.steps)
        return self


def _validate_capture_steps(steps: list[JsonObject]) -> None:
    previous_sequence = -1
    observed_step_indexes: set[int] = set()
    for index, step in enumerate(steps):
        sequence = step.get("sequence")
        if isinstance(sequence, bool) or not isinstance(sequence, int):
            raise ValueError(f"capture steps[{index}].sequence must be an integer")
        if sequence <= previous_sequence:
            raise ValueError("capture step sequences must be strictly increasing")
        previous_sequence = sequence
        observed_record = step.get("observed_record")
        if isinstance(observed_record, Mapping):
            step_index = observed_record.get("step_index")
            if isinstance(step_index, bool) or not isinstance(step_index, int):
                raise ValueError(
                    f"capture steps[{index}].observed_record.step_index must be an integer"
                )
            if step_index in observed_step_indexes:
                raise ValueError("capture observed_record step_index values must be unique")
            observed_step_indexes.add(step_index)
        captured_at = step.get("captured_at")
        if captured_at is not None and not _is_rfc3339_datetime(captured_at):
            raise ValueError(f"capture steps[{index}].captured_at must be RFC3339")


def _validate_top_level_replay_primer(
    replay_primer: Optional[ReplayPrimerState],
    steps: list[JsonObject],
) -> None:
    if replay_primer is None or not steps:
        return
    first_primer = steps[0].get("pre_step_replay_primer")
    if first_primer is None:
        return
    if not isinstance(first_primer, Mapping):
        raise ValueError("capture steps[0].pre_step_replay_primer must be an object")
    top_level = replay_primer.model_dump(mode="json", exclude_none=True)
    if top_level != dict(first_primer):
        raise ValueError(
            "top-level replay_primer must match the first retained step pre_step_replay_primer"
        )


def dump_request(model: BaseModel) -> JsonObject:
    return model.model_dump(mode="json", exclude_none=True)


def ensure_mapping(value: Mapping[str, Any]) -> JsonObject:
    return dict(value)


RuntimeFilter.model_rebuild()
ProofBundleRequest.model_rebuild()
