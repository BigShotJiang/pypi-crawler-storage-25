from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any, Optional

from .errors import KyroDBConfigurationError

DEFAULT_BASE_URL_ENV = "KYRO_RUNTIME_URL"
DEFAULT_DATA_PLANE_TOKEN_ENV = "KYRO_DATA_PLANE_TOKEN"
DEFAULT_OBSERVABILITY_TOKEN_ENV = "KYRO_OBSERVABILITY_TOKEN"
DEFAULT_SHADOW_SESSION_ID_ENV = "KYRO_SHADOW_SESSION_ID"


def client_kwargs_from_env(
    env: Optional[Mapping[str, str]] = None,
    *,
    base_url_env: str = DEFAULT_BASE_URL_ENV,
    data_plane_token_env: str = DEFAULT_DATA_PLANE_TOKEN_ENV,
    observability_token_env: str = DEFAULT_OBSERVABILITY_TOKEN_ENV,
    shadow_session_id_env: str = DEFAULT_SHADOW_SESSION_ID_ENV,
) -> dict[str, Any]:
    source = os.environ if env is None else env
    kwargs = {
        "base_url": _required(source, base_url_env),
        "data_plane_token": _required(source, data_plane_token_env),
    }
    observability_token = _optional(source, observability_token_env)
    if observability_token is not None:
        kwargs["observability_token"] = observability_token
    shadow_session_id = _optional(source, shadow_session_id_env)
    if shadow_session_id is not None:
        kwargs["shadow_session_id"] = shadow_session_id
    return kwargs


def _required(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if value is None:
        raise KyroDBConfigurationError(f"missing required environment variable {name}")
    return value


def _optional(env: Mapping[str, str], name: str) -> Optional[str]:
    value = env.get(name)
    if value == "":
        raise KyroDBConfigurationError(f"environment variable {name} must be unset or non-empty")
    return value
