from __future__ import annotations

from typing import Optional


class KyroDBError(Exception):
    """Base SDK exception."""


class KyroDBConfigurationError(KyroDBError, ValueError):
    """Raised when client configuration is unsafe or incomplete."""


class KyroDBTransportError(KyroDBError):
    """Raised for network, TLS, timeout, and connection failures."""


class KyroDBResponseTooLargeError(KyroDBTransportError):
    """Raised when a response exceeds the configured byte budget."""


class KyroDBDecodeError(KyroDBTransportError):
    """Raised when the runtime returns invalid JSON."""


class KyroDBRedirectBlockedError(KyroDBTransportError):
    """Raised when the runtime responds with a redirect."""


class KyroDBAPIError(KyroDBError):
    """Public-safe runtime error envelope.

    The raw response body is intentionally not retained. Use `body_sha256` and
    `body_length` for correlation without risking sensitive payload disclosure.
    """

    def __init__(
        self,
        *,
        status_code: int,
        code: str,
        message: str,
        acknowledged: Optional[bool] = None,
        retry_after: Optional[str] = None,
        request_id: Optional[str] = None,
        body_sha256: Optional[str] = None,
        body_length: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.acknowledged = acknowledged
        self.retry_after = retry_after
        self.request_id = request_id
        self.body_sha256 = body_sha256
        self.body_length = body_length

    def __str__(self) -> str:
        detail = f"KyroDB API error {self.status_code} {self.code}: {self.message}"
        if self.acknowledged is not None:
            detail = f"{detail} acknowledged={self.acknowledged}"
        if self.retry_after:
            detail = f"{detail} retry_after={self.retry_after}"
        return detail


class KyroDBAuthError(KyroDBAPIError):
    """Raised for authentication or authorization failures."""


class KyroDBValidationError(KyroDBAPIError):
    """Raised for request validation failures reported by the runtime."""


class KyroDBRateLimitError(KyroDBAPIError):
    """Raised when the runtime rejects a request due to rate limiting."""


class KyroDBEvidenceError(KyroDBAPIError):
    """Raised when runtime evidence stores or freshness state fail closed."""


class KyroDBOverloadedError(KyroDBAPIError):
    """Raised when the runtime is protecting evidence/admin capacity."""


class KyroDBServerError(KyroDBAPIError):
    """Raised for non-validation runtime failures."""
