# Release Checklist

Run every command from the `python-sdk/` repository root.

## Required Gates

Start from a clean `dist/` directory so old, unreleasable filenames are not uploaded by accident.

```bash
python -m ruff format --check .
python -m ruff check .
python -m pytest
python -m mypy src/kyrodb
python -m build
python scripts/check_release.py
```

## Optional Security Gate

```bash
python -m pip install ".[security]"
pip-audit .
```

## Live Runtime Gate

Live tests are opt-in so local and CI runs never mutate a runtime accidentally.

```bash
KYRO_LIVE_TESTS=1 \
KYRO_RUNTIME_URL=https://runtime.example.com \
KYRO_DATA_PLANE_TOKEN=... \
KYRO_OBSERVABILITY_TOKEN=... \
python -m pytest -m live
```

Use `KYRO_TEST_TENANT_ID`, `KYRO_TEST_NAMESPACE`, and `KYRO_TEST_QUERY_EMBEDDING` to point the tests at a known seeded fixture.

## Publish Flow

`kyrodb` was previously used for legacy vector-database SDK releases. Do not reuse old
`0.1.0` or `0.2.0` filenames on PyPI; `1.0.0` is the first context-runtime SDK line.

Preferred path: use `.github/workflows/publish.yml` with PyPI Trusted Publishing.
Configure trusted publishers before running it:

- TestPyPI publisher: project `kyrodb`, owner `KyroDB`, repository `python-sdk`, workflow `publish.yml`, environment `testpypi`.
- PyPI publisher: project `kyrodb`, owner `KyroDB`, repository `python-sdk`, workflow `publish.yml`, environment `pypi`.

Run the workflow manually with `target=testpypi` first. The workflow uploads to
TestPyPI and smoke-installs `kyrodb==1.0.0` from TestPyPI. After that passes, run
the same workflow with `target=pypi`.

Fallback local-token flow:

```bash
python -m build
python -m twine check dist/*
python -m twine upload --repository testpypi dist/*
python -m twine upload dist/*
```
