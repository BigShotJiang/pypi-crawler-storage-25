from __future__ import annotations

import argparse
import re
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate KyroDB SDK release artifacts.")
    parser.add_argument(
        "--no-build",
        action="store_true",
        help="skip python -m build and validate source metadata only",
    )
    args = parser.parse_args()

    errors = release_errors(build=not args.no_build)
    if errors:
        for error in errors:
            print(f"release check failed: {error}", file=sys.stderr)
        return 1
    print("release check passed")
    return 0


def release_errors(*, build: bool) -> list[str]:
    errors: list[str] = []
    version = _read_pyproject_version()
    package_version = _read_package_version()
    if version != package_version:
        errors.append(f"pyproject version {version!r} != package version {package_version!r}")

    for relative in (
        "README.md",
        "CHANGELOG.md",
        "RELEASE.md",
        "LICENSE",
        "contracts/kyro-runtime.v1.openapi.json",
        "src/kyrodb/py.typed",
    ):
        if not (ROOT / relative).is_file():
            errors.append(f"missing required release file {relative}")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    for expected in (
        "KYRO_RUNTIME_URL",
        "KYRO_DATA_PLANE_TOKEN",
        "KYRO_OBSERVABILITY_TOKEN",
        "KYRO_LIVE_TESTS",
    ):
        if expected not in readme:
            errors.append(f"README.md does not document {expected}")

    if build:
        completed = subprocess.run(
            [sys.executable, "-m", "build"],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.returncode != 0:
            errors.append(f"python -m build failed: {completed.stderr.strip()}")
            return errors
        errors.extend(_artifact_errors(version))

    return errors


def _read_pyproject_version() -> str:
    match = re.search(
        r'^version\s*=\s*"([^"]+)"',
        (ROOT / "pyproject.toml").read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    if match is None:
        raise RuntimeError("pyproject.toml does not define project.version")
    return match.group(1)


def _read_package_version() -> str:
    version_file = ROOT / "src" / "kyrodb" / "_version.py"
    match = re.search(
        r'^__version__\s*=\s*"([^"]+)"',
        version_file.read_text(encoding="utf-8"),
        flags=re.MULTILINE,
    )
    if match is None:
        raise RuntimeError("src/kyrodb/_version.py does not define __version__")
    return match.group(1)


def _artifact_errors(version: str) -> list[str]:
    errors: list[str] = []
    wheel = DIST / f"kyrodb-{version}-py3-none-any.whl"
    sdist = DIST / f"kyrodb-{version}.tar.gz"
    expected_artifacts = {wheel.name, sdist.name}
    if DIST.is_dir():
        for artifact in sorted(DIST.iterdir()):
            if artifact.is_file() and artifact.name.startswith("kyrodb-"):
                if artifact.name not in expected_artifacts:
                    errors.append(
                        f"unexpected stale distribution artifact {artifact.name}; "
                        "clean dist/ before publishing"
                    )
    if not wheel.is_file():
        errors.append(f"missing wheel artifact {wheel.name}")
    if not sdist.is_file():
        errors.append(f"missing source artifact {sdist.name}")
    if wheel.is_file():
        with zipfile.ZipFile(wheel) as archive:
            names = set(archive.namelist())
        if "kyrodb/py.typed" not in names:
            errors.append("wheel is missing kyrodb/py.typed")
    if sdist.is_file():
        with tarfile.open(sdist) as archive:
            names = set(archive.getnames())
        prefix = f"kyrodb-{version}/"
        for required in (
            "README.md",
            "CHANGELOG.md",
            "RELEASE.md",
            "LICENSE",
            "contracts/kyro-runtime.v1.openapi.json",
        ):
            if f"{prefix}{required}" not in names:
                errors.append(f"sdist is missing {required}")
    return errors


if __name__ == "__main__":
    raise SystemExit(main())
