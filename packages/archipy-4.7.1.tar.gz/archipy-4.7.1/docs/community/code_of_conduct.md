---
title: Code of Conduct
description: ArchiPy community standards for respectful and inclusive collaboration.
---

# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in the ArchiPy community a harassment-free
experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex
characteristics, gender identity and expression, level of experience, education, socioeconomic status,
nationality, personal appearance, race, caste, colour, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy
community.

## Our Standards

**Examples of behaviour that contributes to a positive environment:**

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologising to those affected by our mistakes
- Focusing on what is best not just for us as individuals, but for the overall community

**Examples of unacceptable behaviour:**

- The use of sexualised language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information without explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of acceptable behaviour
and will take appropriate and fair corrective action in response to any behaviour that they deem
inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all community spaces, and also applies when an individual is officially
representing the community in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behaviour may be reported to the community leaders
via the [GitHub repository](https://github.com/SyntaxArc/ArchiPy). All complaints will be reviewed and
investigated promptly and fairly.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/),
version 2.1, available at
[https://www.contributor-covenant.org/version/2/1/code_of_conduct.html](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html).

## See Also

- [Contributing](contributing.md) — how to contribute code, docs, and bug reports
