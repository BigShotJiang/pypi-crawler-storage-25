"""
Config commands - CLI interface for settings management.
"""

from typing import TYPE_CHECKING, Optional

from .result import CommandResult

if TYPE_CHECKING:
    from ..core import MultiClaw
    from .handler import CommandHandler


# Known networks with their names
KNOWN_NETWORKS = {
    8453: "Base Mainnet",
    84532: "Base Sepolia",
    1: "Ethereum Mainnet",
    11155111: "Ethereum Sepolia",
    1187947933: "SKALE Base",
    324705682: "SKALE Base Sepolia",
}


class ConfigCommands:
    """Handles config commands."""

    def __init__(self, core: "MultiClaw", handler: "CommandHandler"):
        self.core = core
        self.handler = handler

    def execute(self, args: list[str]) -> CommandResult:
        """Execute a config subcommand."""
        if not args:
            return self._cmd_show([])

        subcmd = args[0].lower()
        subargs = args[1:]

        if subcmd == "show":
            return self._cmd_show(subargs)
        elif subcmd == "set":
            return self._cmd_set(subargs)
        elif subcmd == "get":
            return self._cmd_get(subargs)
        else:
            return CommandResult.fail(f"Unknown config command: {subcmd}")

    def _cmd_show(self, args: list[str]) -> CommandResult:
        """Show current settings."""
        settings = self.core.settings_manager.settings

        lines = ["Current Settings:"]
        lines.append("")
        lines.append("Signing:")
        lines.append(f"  verify-settlements: {'on' if settings.signing.verify_settlements else 'off'}")
        lines.append(f"  replay-window: {settings.signing.max_request_age_seconds}s")

        lines.append("")
        lines.append("Networks:")
        for chain_id_str, enabled in sorted(settings.signing.enabled_networks.items()):
            try:
                chain_id = int(chain_id_str)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                status = "enabled" if enabled else "disabled"
                lines.append(f"  {chain_id} ({name}): {status}")
            except ValueError:
                pass

        lines.append("")
        lines.append("Server:")
        lines.append(f"  default-port: {settings.server.default_port}")
        lines.append(f"  allow-lan: {'on' if settings.server.allow_lan else 'off'}")

        lines.append("")
        lines.append("Display:")
        default_net = settings.display.default_network
        net_name = KNOWN_NETWORKS.get(default_net, f"Chain {default_net}")
        lines.append(f"  default-network: {default_net} ({net_name})")

        lines.append("")
        lines.append("RPC Endpoints:")
        for chain_id, name in sorted(KNOWN_NETWORKS.items()):
            endpoint = settings.rpc.endpoints.get(str(chain_id))
            value = endpoint if endpoint else "(default)"
            lines.append(f"  {chain_id} ({name}): {value}")

        return CommandResult.ok("\n".join(lines))

    def _cmd_get(self, args: list[str]) -> CommandResult:
        """Get a specific setting value."""
        if not args:
            return CommandResult.fail("Usage: config get <setting>")

        setting = args[0].lower()
        settings = self.core.settings_manager

        if setting == "verify-settlements":
            value = "on" if settings.get_verify_settlements() else "off"
            return CommandResult.ok(f"verify-settlements: {value}")

        elif setting == "replay-window":
            value = settings.get_max_request_age()
            return CommandResult.ok(f"replay-window: {value}s")

        elif setting == "default-port":
            value = settings.get_default_port()
            return CommandResult.ok(f"default-port: {value}")

        elif setting == "allow-lan":
            value = "on" if settings.get_allow_lan() else "off"
            return CommandResult.ok(f"allow-lan: {value}")

        elif setting == "default-network":
            value = settings.get_default_network()
            name = KNOWN_NETWORKS.get(value, "")
            return CommandResult.ok(f"default-network: {value} ({name})")

        elif setting.startswith("network"):
            # config get network 8453
            if len(args) < 2:
                return CommandResult.fail("Usage: config get network <chain_id>")
            try:
                chain_id = int(args[1])
                enabled = settings.is_network_enabled(chain_id)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                status = "enabled" if enabled else "disabled"
                return CommandResult.ok(f"{chain_id} ({name}): {status}")
            except ValueError:
                return CommandResult.fail(f"Invalid chain ID: {args[1]}")

        elif setting.startswith("rpc"):
            # config get rpc 8453
            if len(args) < 2:
                return CommandResult.fail("Usage: config get rpc <chain_id>")
            try:
                chain_id = int(args[1])
                endpoint = settings.get_rpc_endpoint(chain_id)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                value = endpoint if endpoint else "(default)"
                return CommandResult.ok(f"rpc {chain_id} ({name}): {value}")
            except ValueError:
                return CommandResult.fail(f"Invalid chain ID: {args[1]}")

        else:
            return CommandResult.fail(f"Unknown setting: {setting}")

    def _cmd_set(self, args: list[str]) -> CommandResult:
        """Set a configuration value."""
        if len(args) < 2:
            return CommandResult.fail(
                "Usage: config set <setting> <value>\n"
                "\n"
                "Settings:\n"
                "  verify-settlements on|off    - Enable/disable settlement verification\n"
                "  replay-window <seconds>      - Set max request age (min 30)\n"
                "  network <chain_id> on|off    - Enable/disable a network\n"
                "  default-port <port>          - Set default server port\n"
                "  allow-lan on|off             - Allow LAN connections\n"
                "  default-network <chain_id>   - Set default network for display\n"
                "  rpc <chain_id> <url|default> - Set custom RPC endpoint"
            )

        setting = args[0].lower()
        value = args[1]
        settings = self.core.settings_manager

        if setting == "verify-settlements":
            if value.lower() in ("on", "true", "1", "yes"):
                settings.set_verify_settlements(True)
                return CommandResult.ok("Settlement verification enabled")
            elif value.lower() in ("off", "false", "0", "no"):
                settings.set_verify_settlements(False)
                return CommandResult.ok("Settlement verification disabled")
            else:
                return CommandResult.fail("Value must be 'on' or 'off'")

        elif setting == "replay-window":
            try:
                seconds = int(value)
                if seconds < 30:
                    return CommandResult.fail("Replay window must be at least 30 seconds")
                settings.set_max_request_age(seconds)
                return CommandResult.ok(f"Replay window set to {seconds}s")
            except ValueError:
                return CommandResult.fail("Value must be a number of seconds")

        elif setting == "network":
            # config set network 8453 on
            if len(args) < 3:
                return CommandResult.fail("Usage: config set network <chain_id> on|off")
            try:
                chain_id = int(value)
            except ValueError:
                return CommandResult.fail(f"Invalid chain ID: {value}")

            enable_value = args[2].lower()
            if enable_value in ("on", "true", "1", "yes", "enabled"):
                settings.set_network_enabled(chain_id, True)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                if chain_id not in KNOWN_NETWORKS:
                    return CommandResult.ok(
                        f"Warning: Network {chain_id} is not a recognized chain. "
                        f"Balance checking and transaction verification will not work.\n"
                        f"Network {chain_id} enabled."
                    )
                return CommandResult.ok(f"Network {chain_id} ({name}) enabled")
            elif enable_value in ("off", "false", "0", "no", "disabled"):
                settings.set_network_enabled(chain_id, False)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                return CommandResult.ok(f"Network {chain_id} ({name}) disabled")
            else:
                return CommandResult.fail("Value must be 'on' or 'off'")

        elif setting == "default-port":
            try:
                port = int(value)
                if port < 1 or port > 65535:
                    return CommandResult.fail("Port must be between 1 and 65535")
                settings.set_default_port(port)
                return CommandResult.ok(f"Default port set to {port}")
            except ValueError:
                return CommandResult.fail("Value must be a port number")

        elif setting == "allow-lan":
            if value.lower() in ("on", "true", "1", "yes"):
                settings.set_allow_lan(True)
                return CommandResult.ok("LAN connections allowed")
            elif value.lower() in ("off", "false", "0", "no"):
                settings.set_allow_lan(False)
                return CommandResult.ok("LAN connections disabled")
            else:
                return CommandResult.fail("Value must be 'on' or 'off'")

        elif setting == "default-network":
            try:
                chain_id = int(value)
                settings.set_default_network(chain_id)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                return CommandResult.ok(f"Default network set to {chain_id} ({name})")
            except ValueError:
                return CommandResult.fail("Value must be a chain ID")

        elif setting == "rpc":
            # config set rpc 8453 https://example.com
            if len(args) < 3:
                return CommandResult.fail("Usage: config set rpc <chain_id> <url|default>")
            try:
                chain_id = int(value)
            except ValueError:
                return CommandResult.fail(f"Invalid chain ID: {value}")

            endpoint = args[2]
            if endpoint.lower() == "default":
                settings.set_rpc_endpoint(chain_id, None)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                return CommandResult.ok(f"RPC endpoint for {chain_id} ({name}) reset to default")
            else:
                settings.set_rpc_endpoint(chain_id, endpoint)
                name = KNOWN_NETWORKS.get(chain_id, f"Chain {chain_id}")
                return CommandResult.ok(f"RPC endpoint for {chain_id} ({name}) set to {endpoint}")

        else:
            return CommandResult.fail(f"Unknown setting: {setting}")
