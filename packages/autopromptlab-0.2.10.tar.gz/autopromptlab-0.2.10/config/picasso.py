from __future__ import annotations

# Remote URL for the Picasso repository — used for all session clones.
PICASSO_REMOTE_URL = "https://github.com/infinity-microsoft/picasso.git"

# Sparse checkout paths - only these directories will be checked out.
SPARSE_CHECKOUT_PATHS = [
    "Service.Chat/Inference/Prompts/Templates",
    "Orchestration/Extensions",
    "evals/prompts",
]

