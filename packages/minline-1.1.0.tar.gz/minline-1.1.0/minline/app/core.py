import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardMarkup

from minline.session import SessionManager, SqliteSessionManager, MessageManager, SessionKeys
from minline.user_storage import FileSystemUserStorage
from minline.core import Question, InputEvent
from minline.ui.renderers import get_renderer
from minline.routing.registry import RouteRegistry
from minline.routing.callback_router import CallbackRouter

from minline.app.commands.context import CommandContext
from minline.app.commands.registry import CommandRegistry

from aiogram.filters import CommandStart
from aiogram.types import Message

from minline.routing import (
    RouteResolver,
    NavigationStack,
    NavigationProtocol,
)
from minline.routing.utils import parent_path

logger = logging.getLogger(__name__)

class MinlineApp:
    def __init__(self, token: str, session_manager: SessionManager = None, user_storage = None):
        self.bot = Bot(token)
        self.dp = Dispatcher()
        self.routes = RouteResolver()
        self.nav = NavigationStack()
        self.nav_protocol = NavigationProtocol()
        self.commands = CommandRegistry()
        self.session: SessionManager = session_manager or SqliteSessionManager("sessions.db")
        self.user_storage = user_storage or FileSystemUserStorage()
        self.messages = MessageManager(self.session)
        self.is_404 = {}
        self.workflow = None  # Form will be set by developer if needed
        self.active_questions = {}  # Track active question per user: {chat_id: Question}
        
        # New: Tight routing transport layer
        self.route_registry = RouteRegistry()
        self.callback_router = CallbackRouter(self.route_registry)
        self._startup_complete = False

        @self.dp.message(CommandStart())
        async def _start(msg: Message):
            await self._render(msg, "/", source="start")

        @self.dp.message()
        async def my_custom_handler(msg: Message):
            chat_id = msg.chat.id
            text = msg.text
            
            # Check if user has active Question (standalone or from Form)
            if chat_id in self.active_questions:
                question = self.active_questions[chat_id]
                
                # Create InputEvent from message
                input_event = InputEvent.from_text(text, chat_id, msg.from_user.id)
                
                # Validate input
                result = await question.validate_input(input_event)
                
                if not result.ok:
                    # Validation failed - show error with question
                    error_msg = f"{result.error}\n\n{question.text}"
                    try:
                        await self.bot.send_message(chat_id, error_msg)
                    except Exception as e:
                        logger.error(f"Failed to send validation error: {e}", exc_info=True)
                    return
                
                # Validation passed - handle with Form if exists
                if self.workflow is not None:
                    # Store answer in workflow
                    await self.workflow.answer_question_async(chat_id, self.session, question.id, input_event.value)
                    
                    # Check if form complete
                    if await self.workflow.is_complete_async(chat_id, self.session):
                        # Form done
                        del self.active_questions[chat_id]
                        await self.workflow.reset_async(chat_id, self.session)
                        await self._render(msg, "/form/complete")
                        return
                    
                    # Advance to next question
                    next_question = await self.workflow.next_question_async(chat_id, self.session)
                    if next_question:
                        self.active_questions[chat_id] = next_question
                        await self._ask_question(chat_id, next_question)
                    return
                else:
                    # Standalone question - done
                    del self.active_questions[chat_id]
                    # Proceed to normal routing
            
            # No active question - check if workflow exists and start it
            if self.workflow is not None and chat_id not in self.active_questions:
                # Try to get first question from form
                first_question = await self.workflow.get_current_question_async(chat_id, self.session)
                if first_question:
                    self.active_questions[chat_id] = first_question
                    await self._ask_question(chat_id, first_question)
                    return
            
            # Normal routing
            path = "/custom"
            await self._render(msg, path)

        @self.dp.callback_query()
        async def callback(cb: types.CallbackQuery):
            data = cb.data

            if data.startswith(self.nav_protocol.BACK):
                path = self.nav.current(cb.message.chat.id) if self.is_404.get(cb.message.chat.id) else self.nav.back(cb.message.chat.id)
                await self._render(cb, path, push=False)
                return

            if data.startswith(self.nav_protocol.ROUTE):
                raw = data.replace(self.nav_protocol.ROUTE, "")
                base = self.nav.current(cb.message.chat.id).rstrip("/")
                path = raw if raw.startswith("/") else f"{base}/{raw}"
                await self._render(cb, path, push=True)
                return
            
            # Handle Button route= parameter
            if data.startswith("__route:"):
                path = data.replace("__route:", "")
                await self._render(cb, path, push=True)
                return

            await cb.answer("Action executed")





    def route(self, path: str):
        """
        Register a route handler and add to tight routing transport layer.
        
        Args:
            path: Route path (e.g., "/settings/books")
        
        Returns:
            Decorator function
        """
        def decorator(func):
            # Register with legacy route resolver (for backward compatibility)
            self.routes.register(path, func)
            
            # Register with new tight routing transport layer
            self.route_registry.register(path, func, command="ml")
            
            return func
        return decorator

    def command(self, name: str):
        def decorator(func):
            self.commands.register(name, func)
            return func
        return decorator
    
    async def _ask_question(self, chat_id: int, question: Question):
        """Send question to user."""
        try:
            renderer = get_renderer(question.renderer)
            markup = renderer.render(question, show_back=False)
            
            msg = await self.bot.send_message(
                chat_id,
                question.text,
                reply_markup=markup
            )
            await self.messages.set(chat_id, msg.message_id)
        except Exception as e:
            logger.error(f"Failed to ask question {question.id} to {chat_id}: {e}", exc_info=True)

    async def _render(self, msg_obj: types.Message | types.CallbackQuery, path: str, push=True, source=None):
        if isinstance(msg_obj, types.Message):
            chat_id = msg_obj.chat.id
        elif isinstance(msg_obj, types.CallbackQuery):
            chat_id = msg_obj.message.chat.id
        else:
            raise TypeError("msg_obj must be Message or CallbackQuery")

        handler = self.routes.resolve(path)

        if handler is None:
            from minline.routing.menu import Menu
            menu = Menu.not_found(path)
            self.is_404[chat_id] = True
            push = False
            show_back = True
        else:
            menu = handler()
            self.is_404[chat_id] = False
            show_back = path != "/"

        if push:
            self.nav.push(chat_id, path)

        markup = menu.render(show_back=show_back)

        last_id = await self.messages.get(chat_id)

        # If this is a callback query, try to edit the message in place
        if isinstance(msg_obj, types.CallbackQuery):
            try:
                await self.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=msg_obj.message.message_id,
                    text=menu.text,
                    reply_markup=markup
                )
                await self.messages.set(chat_id, msg_obj.message.message_id)
                return
            except Exception as e:
                logger.warning(f"Failed to edit callback message {msg_obj.message.message_id} for chat {chat_id}: {e}")
        
        # If this is a regular message, delete it
        if isinstance(msg_obj, types.Message):
            try:
                await msg_obj.delete()
            except Exception as e:
                logger.debug(f"Failed to delete user message for chat {chat_id}: {e}")

        # Try to edit the last menu message if it exists
        if last_id and not isinstance(msg_obj, types.CallbackQuery):
            try:
                await self.bot.edit_message_text(chat_id=chat_id, message_id=last_id,
                                                text=menu.text, reply_markup=markup)
                await self.messages.set(chat_id, last_id)
                return
            except Exception as e:
                logger.warning(f"Failed to edit message {last_id} for chat {chat_id}: {e}")
                try:
                    await self.bot.delete_message(chat_id, last_id)
                except Exception as e:
                    logger.warning(f"Failed to delete message {last_id} for chat {chat_id}: {e}")

        # Send new message as fallback
        try:
            msg = await self.bot.send_message(chat_id, menu.text, reply_markup=markup)
            await self.messages.set(chat_id, msg.message_id)
        except Exception as e:
            logger.error(f"Failed to send message to chat {chat_id}: {e}")



    def current_path(self, user_id) -> str:
        return self.nav.get(user_id)

    def can_go_back(self, user_id) -> bool:
        return self.current_path(user_id) != "/"

    def parent_path(self, path: str) -> str:
        return parent_path(path)
    
    async def _startup(self):
        """
        Initialize framework on startup.
        Called before polling begins.
        Finalizes route registry and sets up callback router.
        """
        if self._startup_complete:
            return
        
        logger.info("Minline starting up...")
        
        # Finalize route registry (enables collision detection)
        self.route_registry.finalize()
        
        # Setup callback router
        self.callback_router.setup()
        self.dp.include_router(self.callback_router.get_router())
        
        # Log statistics
        registry_stats = self.route_registry.get_stats()
        logger.info(f"✓ Minline ready. Routes: {registry_stats['total_routes']}")
        
        self._startup_complete = True
        
    def run(self):
        """Run the bot with proper startup sequence."""
        async def main():
            await self._startup()
            await self.dp.start_polling(self.bot)
        
        asyncio.run(main())
