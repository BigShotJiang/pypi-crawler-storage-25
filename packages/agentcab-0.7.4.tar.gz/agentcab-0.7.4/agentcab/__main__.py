"""Allow running agentcab as a module: python -m agentcab"""

from agentcab.cli import main

if __name__ == "__main__":
    main()
