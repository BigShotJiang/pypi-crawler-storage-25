"""Marketplace commands"""

import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def marketplace():
    """Browse and search available APIs"""
    pass


@marketplace.command()
@click.option("--query", "-q", help="Search query for API name/description")
@click.option("--category", "-c", help="Filter by category")
@click.option("--sort-by", "-s",
              type=click.Choice(["popular", "newest", "price_low", "price_high", "rating"]),
              help="Sort order")
@click.option("--page", type=int, default=1, help="Page number")
@click.option("--page-size", type=int, default=20, help="Items per page")
@require_auth
def list(query, category, sort_by, page, page_size):
    """List available APIs in the marketplace

    Examples:
        # List all APIs
        agentcab marketplace list

        # Search for translation APIs
        agentcab marketplace list --query "translation"

        # Filter by category
        agentcab marketplace list --category nlp

        # Sort by popularity
        agentcab marketplace list --sort-by popular
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.list_apis(
            query=query,
            category=category,
            sort_by=sort_by,
            page=page,
            page_size=page_size,
        )

        apis = result.get("items", [])
        total = result.get("total", 0)

        if not apis:
            click.echo("No APIs found.")
            return

        click.echo(f"\n{'ID':<40} {'Name':<30} {'Price':<10} {'Rating':<8} {'Calls'}")
        click.echo("-" * 100)

        for api in apis:
            api_id = api['id'][:38] + ".."  # Truncate long IDs
            name = api['name'][:28] + ".." if len(api['name']) > 30 else api['name']
            max_p = api.get('max_price_credits')
            price = f"{api['price_credits']}~{max_p} cr" if max_p and max_p > api['price_credits'] else f"{api['price_credits']} cr"
            rating = f"{api.get('rating', 0):.1f}/5" if api.get('rating') else "N/A"
            calls = str(api.get('call_count', 0))

            # Color code by trial status
            if api.get('is_trial'):
                name_str = click.style(name + " [FREE]", fg="green")
            else:
                name_str = name

            click.echo(
                f"{api_id:<40} "
                f"{name_str:<30} "
                f"{price:<10} "
                f"{rating:<8} "
                f"{calls}"
            )

        click.echo(f"\nShowing {len(apis)} of {total} API(s) (Page {page}/{(total + page_size - 1) // page_size})")
        click.echo(f"\nView details: agentcab marketplace get <api_id>")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@marketplace.command()
@click.argument("api_id")
@require_auth
def get(api_id):
    """Get detailed information about an API

    Example:
        agentcab marketplace get api_abc123
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        api = client.get_api(api_id)

        click.echo(click.style(f"\n📦 {api['name']}", fg="cyan", bold=True))
        click.echo(f"ID: {api['id']}")
        click.echo(f"\n{api.get('description', 'No description')}")

        click.echo(click.style("\n💰 Pricing", fg="cyan"))
        if api.get('is_trial'):
            click.echo(click.style("  FREE TRIAL - Try this API for free!", fg="green", bold=True))
        max_p = api.get('max_price_credits')
        if max_p and max_p > api['price_credits']:
            click.echo(f"  Price: {api['price_credits']}~{max_p} credits per call (dynamic, actual cost based on usage)")
        else:
            click.echo(f"  Price: {api['price_credits']} credits per call")

        click.echo(click.style("\n📊 Statistics", fg="cyan"))
        click.echo(f"  Total calls: {api.get('call_count', 0)}")
        click.echo(f"  Success rate: {api.get('success_count', 0) / max(api.get('call_count', 1), 1) * 100:.1f}%")
        if api.get('rating'):
            click.echo(f"  Rating: {api['rating']:.1f}/5")

        if api.get('example_call_id'):
            click.echo(click.style(f"\\n📝 Example Call", fg="cyan"))
            click.echo(f"  Call ID: {api['example_call_id']}")

        if api.get('category'):
            click.echo(click.style(f"\n🏷️  Category", fg="cyan"))
            click.echo(f"  {api['category']}")

        if api.get('tags'):
            click.echo(click.style(f"\n🔖 Tags", fg="cyan"))
            click.echo(f"  {', '.join(api['tags'])}")

        click.echo(click.style("\n📥 Input Schema", fg="cyan"))
        import json
        click.echo(f"  {json.dumps(api['input_schema'], indent=2)}")

        click.echo(click.style("\n📤 Output Schema", fg="cyan"))
        click.echo(f"  {json.dumps(api['output_schema'], indent=2)}")

        click.echo(click.style(f"\n💡 Usage", fg="cyan"))
        click.echo(f"  agentcab call {api['id']} --input '{{...}}'")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()

