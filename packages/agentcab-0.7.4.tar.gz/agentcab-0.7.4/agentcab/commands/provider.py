"""Provider commands"""

import json
import click
from agentcab import ProviderClient, ProviderWorker
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def provider():
    """Manage your APIs and run workers"""
    pass


@provider.command()
@click.option("--name", required=True, help="API name")
@click.option("--description", required=True, help="API description")
@click.option("--category", help="API category")
@click.option("--price", type=int, required=True, help="Price in credits (min price for dynamic pricing)")
@click.option("--max-price", type=int, default=None, help="Max price for dynamic pricing (enables pay-per-use)")
@click.option("--max-workers", type=int, default=5, help="Max concurrent jobs")
@click.option("--input-schema", required=True, help="Input JSON schema (as JSON string)")
@click.option("--output-schema", required=True, help="Output JSON schema (as JSON string)")
@click.option("--tags", help="Comma-separated tags")
@require_auth
def create(name, description, category, price, max_price, max_workers, input_schema, output_schema, tags):
    """Create a new API

    Example:
        agentcab provider create \\
          --name "Translation API" \\
          --description "Translate English to Chinese" \\
          --category nlp \\
          --price 10 \\
          --input-schema '{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}' \\
          --output-schema '{"type":"object","properties":{"translation":{"type":"string"}}}'
    """
    try:
        input_schema_obj = json.loads(input_schema)
        output_schema_obj = json.loads(output_schema)
    except json.JSONDecodeError as e:
        click.echo(click.style(f"✗ Error: Invalid JSON schema: {e}", fg="red"))
        raise click.Abort()

    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        api = client.create_api(
            name=name,
            description=description,
            input_schema=input_schema_obj,
            output_schema=output_schema_obj,
            price_credits=price,
            category=category,
            tags=tags_list,
            max_concurrent_jobs=max_workers,
            max_price_credits=max_price,
        )

        click.echo(click.style("✓ API created successfully!", fg="green"))
        click.echo(f"  ID: {api['id']}")
        click.echo(f"  Name: {api['name']}")
        max_p = api.get('max_price_credits')
        if max_p and max_p > api['price_credits']:
            click.echo(f"  Price: {api['price_credits']}~{max_p} credits (dynamic)")
        else:
            click.echo(f"  Price: {api['price_credits']} credits")
        click.echo(f"\nStart worker with: agentcab provider start")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@require_auth
def list():
    """List your APIs"""
    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        apis = client.list_my_apis()

        if not apis:
            click.echo("No APIs found. Create one with 'agentcab provider create'")
            return

        click.echo(f"\n{'ID':<40} {'Name':<30} {'Price':<10} {'Status'}")
        click.echo("-" * 90)

        for api in apis:
            max_p = api.get('max_price_credits')
            price_str = f"{api['price_credits']}~{max_p}" if max_p and max_p > api['price_credits'] else str(api['price_credits'])
            click.echo(
                f"{api['id']:<40} "
                f"{api['name']:<30} "
                f"{price_str:<10} "
                f"{api.get('status', 'active')}"
            )

        click.echo(f"\nTotal: {len(apis)} API(s)")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@click.argument("api_id")
@click.option("--name", help="Update API name")
@click.option("--description", help="Update API description")
@click.option("--category", help="Update API category")
@click.option("--price", type=int, help="Update price in credits")
@click.option("--max-price", type=int, default=None, help="Update max price for dynamic pricing (0 to disable)")
@click.option("--max-workers", type=int, help="Update max concurrent jobs")
@click.option("--input-schema", help="Update input JSON schema (as JSON string)")
@click.option("--output-schema", help="Update output JSON schema (as JSON string)")
@click.option("--tags", help="Update comma-separated tags")
@click.option("--is-trial/--no-trial", default=None, help="Enable/disable free trial")
@require_auth
def update(api_id, name, description, category, price, max_price, max_workers, input_schema, output_schema, tags, is_trial):
    """Update an existing API

    Example:
        agentcab provider update api_abc123 --name "New Name" --price 20
        agentcab provider update api_abc123 --description "Updated description" --is-trial
    """
    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    # Build update payload
    updates = {}
    if name:
        updates["name"] = name
    if description:
        updates["description"] = description
    if category:
        updates["category"] = category
    if price is not None:
        updates["price_credits"] = price
    if max_price is not None:
        updates["max_price_credits"] = max_price if max_price > 0 else None
    if max_workers is not None:
        updates["max_concurrent_jobs"] = max_workers
    if tags:
        updates["tags"] = [t.strip() for t in tags.split(",")]
    if is_trial is not None:
        updates["is_trial"] = is_trial

    # Parse JSON schemas if provided
    if input_schema:
        try:
            updates["input_schema"] = json.loads(input_schema)
        except json.JSONDecodeError as e:
            click.echo(click.style(f"✗ Error: Invalid input schema JSON: {e}", fg="red"))
            raise click.Abort()

    if output_schema:
        try:
            updates["output_schema"] = json.loads(output_schema)
        except json.JSONDecodeError as e:
            click.echo(click.style(f"✗ Error: Invalid output schema JSON: {e}", fg="red"))
            raise click.Abort()

    if not updates:
        click.echo(click.style("✗ Error: No updates provided", fg="red"))
        raise click.Abort()

    try:
        api = client.update_api(api_id, **updates)

        click.echo(click.style("✓ API updated successfully!", fg="green"))
        click.echo(f"  ID: {api['id']}")
        click.echo(f"  Name: {api['name']}")
        max_p = api.get('max_price_credits')
        if max_p and max_p > api['price_credits']:
            click.echo(f"  Price: {api['price_credits']}~{max_p} credits (dynamic)")
        else:
            click.echo(f"  Price: {api['price_credits']} credits")
        if api.get('is_trial'):
            click.echo(f"  Trial: Enabled (free to try)")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@click.argument("api_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@require_auth
def delete(api_id, yes):
    """Delete an API

    Example:
        agentcab provider delete api_abc123
    """
    if not yes:
        click.confirm(
            click.style(f"Are you sure you want to delete API {api_id}?", fg="yellow"),
            abort=True
        )

    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.delete_api(api_id)

        if result:
            click.echo(click.style("✓ API deleted successfully!", fg="green"))
        else:
            click.echo(click.style("✗ Failed to delete API", fg="red"))
            raise click.Abort()

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@click.option("--command", help="Shell command to execute for each job")
@click.option("--agent-url", help="HTTP URL to forward jobs to")
@click.option("--poll-interval", type=int, default=5, help="Seconds between polling")
@click.option("--max-workers", type=int, default=1, help="Number of concurrent workers")
@click.option("--timeout", type=int, default=30, help="Request timeout in seconds")
@require_auth
def start(command, agent_url, poll_interval, max_workers, timeout):
    """Start worker to process jobs

    The worker will continuously poll for new jobs and process them.

    Examples:
        # Using shell command
        agentcab provider start --command "python my_agent.py"

        # Using HTTP endpoint
        agentcab provider start --agent-url "http://localhost:8000/process"

        # Multiple workers
        agentcab provider start --command "python my_agent.py" --max-workers 3
    """
    if not command and not agent_url:
        click.echo(click.style("✗ Error: Must provide --command or --agent-url", fg="red"))
        raise click.Abort()

    click.echo(click.style("Starting AgentCab worker...", fg="cyan"))
    click.echo(f"  Poll interval: {poll_interval}s")
    click.echo(f"  Max workers: {max_workers}")
    click.echo(f"  Timeout: {timeout}s")
    if command:
        click.echo(f"  Command: {command}")
    if agent_url:
        click.echo(f"  Agent URL: {agent_url}")
    click.echo("\nPress Ctrl+C to stop\n")

    try:
        worker = ProviderWorker(
            api_key=get_api_key(),
            base_url=get_base_url(),
            command=command,
            agent_url=agent_url,
            poll_interval=poll_interval,
            max_workers=max_workers,
            timeout=timeout,
        )
        worker.run()

    except KeyboardInterrupt:
        click.echo(click.style("\n\n✓ Worker stopped", fg="yellow"))
    except Exception as e:
        click.echo(click.style(f"\n✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@click.argument("amount", type=int)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@require_auth
def withdraw(amount, yes):
    """Request withdrawal of credits to your Stripe account

    The amount is in credits (100 credits = $1 USD).
    Minimum withdrawal: 1000 credits ($10).
    Withdrawal frequency: Once per 30 days.

    Example:
        agentcab provider withdraw 5000  # Withdraw $50
    """
    if amount < 1000:
        click.echo(click.style("✗ Error: Minimum withdrawal is 1000 credits ($10)", fg="red"))
        raise click.Abort()

    amount_usd = amount / 100

    if not yes:
        click.confirm(
            click.style(
                f"Withdraw {amount} credits (${amount_usd:.2f} USD) to your Stripe account?",
                fg="yellow"
            ),
            abort=True
        )

    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        withdrawal = client.create_withdrawal(amount_credits=amount)

        click.echo(click.style("\n✓ Withdrawal request submitted!", fg="green"))
        click.echo(f"  Withdrawal ID: {withdrawal['id']}")
        click.echo(f"  Amount: {withdrawal['credits']} credits (${withdrawal['amount_usd']:.2f} USD)")
        click.echo(f"  Status: {withdrawal['status']}")

        if withdrawal['status'] == 'pending':
            click.echo(click.style("\n⏳ Your withdrawal is pending review", fg="yellow"))
            click.echo("  Large withdrawals may require manual approval")
            click.echo("  You will be notified once processed")

        click.echo(f"\nCheck status: agentcab provider withdrawals")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@require_auth
def withdrawals():
    """View withdrawal history

    Example:
        agentcab provider withdrawals
    """
    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        # Get wallet info first
        wallet = client.get_wallet()

        click.echo(click.style("\n💰 Wallet Balance", fg="cyan", bold=True))
        click.echo(f"  Available: {wallet['credits']} credits (${wallet['credits'] / 100:.2f} USD)")

        # Get withdrawal history
        result = client.list_withdrawals()
        withdrawals_list = result.get("items", [])
        total = result.get("total", 0)

        if not withdrawals_list:
            click.echo(click.style("\n📤 No Withdrawals Yet", fg="cyan", bold=True))
            click.echo("  You haven't made any withdrawal requests")
            click.echo(f"\nRequest withdrawal: agentcab provider withdraw <amount>")
            return

        click.echo(click.style("\n📤 Withdrawal History", fg="cyan", bold=True))
        click.echo(f"\n{'ID':<40} {'Amount':<15} {'Status':<12} {'Created At'}")
        click.echo("-" * 90)

        for w in withdrawals_list:
            w_id = w['id'][:38] + ".."
            amount = f"{w['credits']} cr (${w['amount_usd']:.2f})"
            status = w['status']
            created_at = w.get('created_at', '')[:19]

            # Color code by status
            if status == 'success':
                status_str = click.style(status, fg="green")
            elif status == 'failed':
                status_str = click.style(status, fg="red")
            elif status == 'pending':
                status_str = click.style(status, fg="yellow")
            else:
                status_str = status

            click.echo(
                f"{w_id:<40} "
                f"{amount:<15} "
                f"{status_str:<12} "
                f"{created_at}"
            )

        click.echo(f"\nTotal: {total} withdrawal(s)")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
