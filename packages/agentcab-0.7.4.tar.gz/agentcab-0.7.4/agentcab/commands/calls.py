"""Calls history commands"""

import json
import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def calls():
    """View call history and details"""
    pass


@calls.command()
@click.option("--page", type=int, default=1, help="Page number")
@click.option("--page-size", type=int, default=20, help="Items per page")
@require_auth
def list(page, page_size):
    """List your API call history

    Examples:
        # List recent calls
        agentcab calls list

        # View specific page
        agentcab calls list --page 2 --page-size 10
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.list_my_calls(page=page, page_size=page_size)
        calls_list = result.get("items", [])
        total = result.get("total", 0)

        if not calls_list:
            click.echo("No calls found. Make your first call with 'agentcab call'")
            return

        click.echo(f"\n{'Call ID':<40} {'API Name':<25} {'Status':<12} {'Cost':<8} {'Created At'}")
        click.echo("-" * 110)

        for call in calls_list:
            call_id = call['id'][:38] + ".."
            api_name = call.get('skill_name', 'N/A')[:23] + ".." if len(call.get('skill_name', '')) > 25 else call.get('skill_name', 'N/A')
            status = call['status']
            cost = f"{call.get('credits_cost', 0)} cr"
            created_at = call.get('started_at', '')[:19]

            # Color code by status
            if status == 'success':
                status_str = click.style(status, fg="green")
            elif status in ['failed', 'timeout']:
                status_str = click.style(status, fg="red")
            elif status == 'processing':
                status_str = click.style(status, fg="yellow")
            else:
                status_str = status

            click.echo(
                f"{call_id:<40} "
                f"{api_name:<25} "
                f"{status_str:<12} "
                f"{cost:<8} "
                f"{created_at}"
            )

        click.echo(f"\nShowing {len(calls_list)} of {total} call(s) (Page {page}/{(total + page_size - 1) // page_size})")
        click.echo(f"\nView details: agentcab calls get <call_id>")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@calls.command()
@click.argument("call_id")
@require_auth
def get(call_id):
    """Get detailed information about a specific call

    Example:
        agentcab calls get call_abc123
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        call = client.get_call(call_id)

        click.echo(click.style(f"\n📞 Call Details", fg="cyan", bold=True))
        click.echo(f"Call ID: {call['id']}")
        click.echo(f"API ID: {call['skill_id']}")
        if call.get('skill_name'):
            click.echo(f"API Name: {call['skill_name']}")

        # Status
        status = call['status']
        if status == 'success':
            status_str = click.style(status.upper(), fg="green", bold=True)
        elif status in ['failed', 'timeout']:
            status_str = click.style(status.upper(), fg="red", bold=True)
        elif status == 'processing':
            status_str = click.style(status.upper(), fg="yellow", bold=True)
        else:
            status_str = status.upper()

        click.echo(f"\nStatus: {status_str}")

        # Timing
        click.echo(click.style(f"\n⏱️  Timing", fg="cyan"))
        click.echo(f"Started: {call.get('started_at', 'N/A')}")
        if call.get('completed_at'):
            click.echo(f"Completed: {call['completed_at']}")
        if call.get('duration_ms'):
            click.echo(f"Duration: {call['duration_ms']}ms")

        # Cost
        click.echo(click.style(f"\n💰 Cost", fg="cyan"))
        click.echo(f"Credits: {call.get('credits_cost', 0)}")

        # Input
        click.echo(click.style(f"\n📥 Input", fg="cyan"))
        if call.get('input_data'):
            click.echo(json.dumps(call['input_data'], indent=2, ensure_ascii=False))
        else:
            click.echo("  N/A")

        # Output
        if call.get('output_data'):
            click.echo(click.style(f"\n📤 Output", fg="cyan"))
            click.echo(json.dumps(call['output_data'], indent=2, ensure_ascii=False))

        # Error
        if call.get('error_message'):
            click.echo(click.style(f"\n❌ Error", fg="red"))
            click.echo(f"  {call['error_message']}")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
