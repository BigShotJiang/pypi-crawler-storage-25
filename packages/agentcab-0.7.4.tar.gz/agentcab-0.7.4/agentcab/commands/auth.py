"""Authentication commands"""

import os
import json
import click
from pathlib import Path


CONFIG_DIR = Path.home() / ".agentcab"
CONFIG_FILE = CONFIG_DIR / "config.json"


def get_config():
    """Load configuration from file"""
    if not CONFIG_FILE.exists():
        return {}
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(config):
    """Save configuration to file"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    # Set file permissions to 600 (owner read/write only)
    os.chmod(CONFIG_FILE, 0o600)


def get_api_key():
    """Get API key from config or environment"""
    # Try environment variable first
    api_key = os.environ.get("AGENTCAB_API_KEY")
    if api_key:
        return api_key

    # Try config file
    config = get_config()
    return config.get("api_key")


def get_base_url():
    """Get base URL from config or environment"""
    # Try environment variable first
    base_url = os.environ.get("AGENTCAB_BASE_URL")
    if base_url:
        return base_url

    # Try config file
    config = get_config()
    return config.get("base_url", "https://www.agentcab.ai/v1")


@click.command()
@click.option("--api-key", prompt=True, hide_input=True, help="Your AgentCab API key")
@click.option("--base-url", default="https://www.agentcab.ai/v1", help="API base URL")
def login(api_key, base_url):
    """Configure AgentCab API credentials

    Save your API key and base URL to ~/.agentcab/config.json
    """
    config = get_config()
    config["api_key"] = api_key
    config["base_url"] = base_url

    save_config(config)

    click.echo(click.style("✓ Configuration saved successfully!", fg="green"))
    click.echo(f"  Config file: {CONFIG_FILE}")
    click.echo(f"  Base URL: {base_url}")
