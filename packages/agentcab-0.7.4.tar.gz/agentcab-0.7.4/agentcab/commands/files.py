"""Files commands"""

import os
import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def files():
    """Manage files (upload, download, list, delete)"""
    pass


@files.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--call-id", help="Associate file with a specific call ID")
@require_auth
def upload(file_path, call_id):
    """Upload a file

    Pricing tiers:
    - 0-1MB: 10 credits
    - 1-10MB: 50 credits
    - 10-50MB: 100 credits
    - 50-100MB: 200 credits

    Example:
        agentcab files upload document.pdf
        agentcab files upload image.png --call-id call_abc123
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        # Get file size for display
        file_size = os.path.getsize(file_path)
        file_size_mb = file_size / (1024 * 1024)

        click.echo(click.style(f"Uploading {os.path.basename(file_path)} ({file_size_mb:.2f} MB)...", fg="cyan"))

        result = client.upload_file(file_path, call_id=call_id)

        click.echo(click.style("\n✓ File uploaded successfully!", fg="green"))
        click.echo(f"  File ID: {result['file_id']}")
        click.echo(f"  Filename: {result['filename']}")
        click.echo(f"  Size: {result['file_size']} bytes")
        click.echo(f"  Cost: {result.get('cost_credits', 'N/A')} credits")
        click.echo(f"  URL: {result['url']}")
        click.echo(f"  Expires: {result['expires_at']}")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@files.command()
@click.argument("file_id")
@click.argument("save_path", type=click.Path())
@require_auth
def download(file_id, save_path):
    """Download a file by ID

    Example:
        agentcab files download file_abc123 ./downloaded.pdf
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        click.echo(click.style(f"Downloading file {file_id}...", fg="cyan"))

        result_path = client.download_file(file_id, save_path)

        file_size = os.path.getsize(result_path)
        file_size_mb = file_size / (1024 * 1024)

        click.echo(click.style("\n✓ File downloaded successfully!", fg="green"))
        click.echo(f"  Saved to: {result_path}")
        click.echo(f"  Size: {file_size_mb:.2f} MB")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@files.command()
@click.option("--page", type=int, default=1, help="Page number")
@click.option("--page-size", type=int, default=20, help="Items per page")
@require_auth
def list(page, page_size):
    """List your uploaded files

    Example:
        agentcab files list
        agentcab files list --page 2 --page-size 10
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.list_files(page=page, page_size=page_size)
        files_list = result.get("items", [])
        total = result.get("total", 0)

        if not files_list:
            click.echo("No files found. Upload one with 'agentcab files upload'")
            return

        click.echo(f"\n{'File ID':<40} {'Filename':<30} {'Size':<10} {'Created At'}")
        click.echo("-" * 100)

        for file in files_list:
            file_size = file.get('file_size', 0)
            file_size_mb = file_size / (1024 * 1024)
            created_at = file.get('created_at', '')[:19]  # Trim to datetime

            click.echo(
                f"{file['id']:<40} "
                f"{file['filename']:<30} "
                f"{file_size_mb:>8.2f}MB "
                f"{created_at}"
            )

        click.echo(f"\nShowing {len(files_list)} of {total} file(s) (Page {page})")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@files.command()
@click.argument("file_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@require_auth
def delete(file_id, yes):
    """Delete a file by ID

    Example:
        agentcab files delete file_abc123
    """
    if not yes:
        click.confirm(
            click.style(f"Are you sure you want to delete file {file_id}?", fg="yellow"),
            abort=True
        )

    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.delete_file(file_id)

        if result.get("deleted"):
            click.echo(click.style("✓ File deleted successfully!", fg="green"))
        else:
            click.echo(click.style("✗ Failed to delete file", fg="red"))
            raise click.Abort()

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
