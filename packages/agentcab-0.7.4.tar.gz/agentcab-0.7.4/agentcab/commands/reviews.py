"""Reviews commands"""

import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def reviews():
    """Manage API reviews (create, update, list, delete)"""
    pass


@reviews.command()
@click.argument("api_id")
@click.option("--rating", type=int, required=True, help="Rating (1-5)")
@click.option("--comment", help="Review comment")
@require_auth
def create(api_id, rating, comment):
    """Create a review for an API

    Note: You must have called the API at least once before reviewing.

    Example:
        agentcab reviews create api_abc123 --rating 5 --comment "Great API!"
    """
    if rating < 1 or rating > 5:
        click.echo(click.style("✗ Error: Rating must be between 1 and 5", fg="red"))
        raise click.Abort()

    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        review = client.create_review(api_id, rating=rating, comment=comment)

        click.echo(click.style("✓ Review created successfully!", fg="green"))
        click.echo(f"  API ID: {api_id}")
        click.echo(f"  Rating: {review['rating']}/5")
        if review.get('comment'):
            click.echo(f"  Comment: {review['comment']}")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@reviews.command()
@click.argument("api_id")
@click.option("--rating", type=int, help="Update rating (1-5)")
@click.option("--comment", help="Update review comment")
@require_auth
def update(api_id, rating, comment):
    """Update your review for an API

    Example:
        agentcab reviews update api_abc123 --rating 4
        agentcab reviews update api_abc123 --comment "Updated comment"
    """
    if rating is not None and (rating < 1 or rating > 5):
        click.echo(click.style("✗ Error: Rating must be between 1 and 5", fg="red"))
        raise click.Abort()

    if rating is None and comment is None:
        click.echo(click.style("✗ Error: Must provide --rating or --comment", fg="red"))
        raise click.Abort()

    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        review = client.update_review(api_id, rating=rating, comment=comment)

        click.echo(click.style("✓ Review updated successfully!", fg="green"))
        click.echo(f"  API ID: {api_id}")
        click.echo(f"  Rating: {review['rating']}/5")
        if review.get('comment'):
            click.echo(f"  Comment: {review['comment']}")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@reviews.command()
@click.argument("api_id")
@click.option("--page", type=int, default=1, help="Page number")
@click.option("--page-size", type=int, default=20, help="Items per page")
@require_auth
def list(api_id, page, page_size):
    """List reviews for an API

    Example:
        agentcab reviews list api_abc123
        agentcab reviews list api_abc123 --page 2
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.get_reviews(api_id, page=page, page_size=page_size)
        reviews_list = result.get("items", [])
        total = result.get("total", 0)

        if not reviews_list:
            click.echo(f"No reviews found for API {api_id}")
            return

        click.echo(f"\n{'User':<30} {'Rating':<10} {'Comment':<50} {'Created At'}")
        click.echo("-" * 110)

        for review in reviews_list:
            user = review.get('user_name', review.get('user_id', 'Unknown'))[:28]
            rating = f"{review['rating']}/5"
            comment = (review.get('comment', '')[:48] + '..') if len(review.get('comment', '')) > 50 else review.get('comment', '')
            created_at = review.get('created_at', '')[:19]  # Trim to datetime

            # Color code rating
            if review['rating'] >= 4:
                rating_str = click.style(rating, fg="green")
            elif review['rating'] >= 3:
                rating_str = click.style(rating, fg="yellow")
            else:
                rating_str = click.style(rating, fg="red")

            click.echo(
                f"{user:<30} "
                f"{rating_str:<10} "
                f"{comment:<50} "
                f"{created_at}"
            )

        click.echo(f"\nShowing {len(reviews_list)} of {total} review(s) (Page {page})")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@reviews.command()
@click.argument("api_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@require_auth
def delete(api_id, yes):
    """Delete your review for an API

    Example:
        agentcab reviews delete api_abc123
    """
    if not yes:
        click.confirm(
            click.style(f"Are you sure you want to delete your review for API {api_id}?", fg="yellow"),
            abort=True
        )

    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        result = client.delete_review(api_id)

        if result.get("deleted"):
            click.echo(click.style("✓ Review deleted successfully!", fg="green"))
        else:
            click.echo(click.style("✗ Failed to delete review", fg="red"))
            raise click.Abort()

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
