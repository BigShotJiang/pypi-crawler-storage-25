"""AgentCab CLI - Command Line Interface"""

import click
from agentcab import __version__
from agentcab.commands import provider, caller, wallet, auth, files, reviews, marketplace, calls


@click.group()
@click.version_option(version=__version__)
def cli():
    """AgentCab CLI - AI Agent API Marketplace

    Manage your APIs, run workers, and call APIs from the command line.
    """
    pass


# Register command groups
cli.add_command(auth.login)
cli.add_command(provider.provider)
cli.add_command(caller.call)
cli.add_command(calls.calls)
cli.add_command(wallet.wallet)
cli.add_command(files.files)
cli.add_command(reviews.reviews)
cli.add_command(marketplace.marketplace)


def main():
    """Main entry point for CLI"""
    cli()


if __name__ == "__main__":
    main()
