# plots.pyi

from typing import Any, Optional, Tuple, Union, Sequence, Literal
import numpy as np

from .config import TikzConfig as TikzConfig
from .figure import Figure as Figure
from .state import main_name as main_name, next_show_num as next_show_num
from .axes import Axes

ArrayLike = Union[Sequence[float], np.ndarray]
ColorLike = Union[str, Sequence[float]]
LineStyle = Literal["-", "--", "-.", ":", "solid", "dashed", "dashdot", "none", ""]
MarkerStyle = Literal["o", "s", "^", "v", "x", "+", ".", "*", "None", ""]

# --- Figure / Axes creation ---

def figure(*, figsize: Optional[Tuple[float, float]] = ...) -> Figure:
    """
    Create a new figure.

    Parameters
    ----------
    figsize : tuple of float, optional
        Figure size in inches (width, height).
    """
    ...

def subplot(
    nrows: int,
    ncols: int,
    index: int,
    sharex: Optional[Axes] = ...,
    sharey: Optional[Axes] = ...
) -> Axes:
    """
    Create a subplot and make it current.
    """
    ...

def subplots(
    nrows: int = 1,
    ncols: int = 1,
    sharex: Optional[Axes] = ...,
    sharey: Optional[Axes] = ...,
    **kwargs: Any
) -> Tuple[Figure, Union[Axes, np.ndarray]]:
    """
    Create a figure and a set of subplots.

    Returns
    -------
    fig : Figure
    ax : Axes or ndarray of Axes
        - Single Axes if nrows*ncols == 1
        - 1D array if one dimension is 1
        - 2D array otherwise
    figsize : tuple, optional
        Figure size in inches (width, height).
    sharex, sharey : Axes, optional
        Specify if row, column or all subplots should share x or y axis.
    """
    ...


# --- Axis label / limits ---

def xlabel(label: str) -> None:
    """
    Set x-axis label.
    """
    ...

def ylabel(label: str) -> None:
    """
    Set y-axis label.
    """
    ...

def title(text: str) -> None:
    """
    Set plot title.
    """
    ...

def xlim(*args: Any, left: Optional[float] = ..., right: Optional[float] = ...) -> None:
    """
    Set x-axis limit(-s). Set as tuple or as kwargs (left, right).

    """
    ...

def ylim(*args: Any, bottom: Optional[float] = ..., top: Optional[float] = ...) -> None:
    """
    Set y-axis limit(-s). Set as tuple or as kwargs (top, bottom).

    """
    ...

def xscale(*args: Any, base: Optional[float] = ...) -> None:
    """
    Set x-axis scale (to log).
    """
    ...

def yscale(*args: Any, base: Optional[float] = ...) -> None:
    """
    Set y-axis scale (to log).
    """
    ...

def xticks(ticks: Sequence[float], labels: Optional[Sequence[str]] = ...) -> None:
    """
    Set x-axis ticks and their labels.
    """
    ...

def yticks(ticks: Sequence[float], labels: Optional[Sequence[str]] = ...) -> None:
    """
    Set y-axis ticks and their labels.
    """
    ...

def grid(self, visible: bool = True, which: Literal["major","minor","both"] = "major", alpha: Optional[float] = ..., color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
             linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ..., linewidth: Optional[float]= ..., lw: Optional[float] = ...) -> None: 
        """
        Set grid.

        Parameters
        ----------
        visible: bool, default True
            Show grid
        which: {"major", "minor", "both"}, default "major"
            Grid selector
        alpha: float, optional
            Opacity
        color or c: all matplotlib color formats (without X11/xkcd), optional
            Grid color: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible
        linestyle or ls: str, optional
            Grid line style
        linewidth or lw: float, optional
            Grid line width in pt
        """
def set_minorticks_num(num: int) -> None:
        """
        Set number of minor ticks between major ticks.

        Parameters
        ----------
        num: int
            Number of minor ticks between major ticks.
        """
def legend(*args: Any, loc: Optional[Union[int,str,Tuple[float,float]]] = ...) -> None:
    """
    Show legend for the selected axis.

    Parameters
    ----------
    loc: int, str or tuple, optional
        Location of legend (as in matplotlib: 1 - upper right, 2 - upper left, ... or with tuple of relative coordinates).
    """
    ...


# --- Plotting (verbatim docstrings) ---

def plot(
    x: ArrayLike = ..., y: ArrayLike = ..., fmt: Optional[str] = ...,
    *,
    alpha: Optional[float] = ...,
    color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
    linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ...,
    linewidth: Optional[float]= ..., lw: Optional[float] = ...,
    marker: Optional[MarkerStyle] = ...,
    markersize: Optional[float] = ..., ms: Optional[float] = ...,
    label: Optional[str] = ...
) -> None:
    """
    Draw a general plot to the selected axis.

    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints

    fmt: str, optional
        Style

    alpha: float, optional
        Opacity

    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible

    label: str, optional
        Legned entry

    linestyle or ls: str, optional
        Line style

    linewidth or lw: float, optional
        Line width in pt
    
    marker: str, optional
        Marker type

    markersize or ms: float, optional
        Mark size in pt
    """
    ...
def errorbar(self, x: ArrayLike = ..., y: ArrayLike = ..., yerr: Optional[ArrayLike | float] = ..., xerr: Optional[ArrayLike | float] = ..., fmt: Optional[str] = ..., *, alpha: Optional[float] = ..., color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
             linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ..., linewidth: Optional[float]= ..., lw: Optional[float] = ...,
             marker: Optional[MarkerStyle] = ..., markersize: Optional[float] = ..., ms: Optional[float] = ...,  label:Optional[str]=...) -> None:
    """
    Draw a plot with errrorbars to the selected axis.
    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints
    yerr, xerr: ArrayLike or float
        Datapoint error (constant, symmetric, asymmetric)
    fmt: str, optional
        Style
    alpha: float, optional
        Opacity
    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible
    label: str, optional
        Legned entry
    linestyle or ls: str, optional
        Line style
    linewidth or lw: float, optional
        Line width in pt
    
    marker: str, optional
        Marker type
    markersize or ms: float, optional
        Mark size in pt
    """
    ...
def scatter(
    x: ArrayLike = ..., y: ArrayLike = ..., fmt: Optional[str] = ...,
    *,
    alpha: Optional[float] = ...,
    color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
    marker: Optional[MarkerStyle] = ...,
    markersize: Optional[float] = ..., ms: Optional[float] = ...,
    label: Optional[str] = ...
) -> None:
    """
    Draw a scatter plot to the selected axis.
    
    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints

    fmt: str, optional
        Style

    alpha: float, optional
        Opacity

    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible

    label: str, optional
        Legned entry
    
    marker: str, optional
        Marker type

    markersize or ms: float, optional
        Mark size in pt
    """
    ...

def semilogy(
    x: ArrayLike = ..., y: ArrayLike = ..., base: Optional[float] = 10,
    fmt: Optional[str] = ...,
    *,
    alpha: Optional[float] = ...,
    color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
    linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ...,
    linewidth: Optional[float]= ..., lw: Optional[float] = ...,
    marker: Optional[MarkerStyle] = ...,
    markersize: Optional[float] = ..., ms: Optional[float] = ...,
    label: Optional[str] = ...
) -> None:
    """
    Draw a general plot to the selected axis and change the current y-axis into log mode.

    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints

    base: float, optional
        Log basis, default 10

    fmt: str, optional
        Style

    alpha: float, optional
        Opacity

    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible

    label: str, optional
        Legned entry

    linestyle or ls: str, optional
        Line style

    linewidth or lw: float, optional
        Line width in pt
    
    marker: str, optional
        Marker type

    markersize or ms: float, optional
        Mark size in pt
    """
    ...

def stem(self, *args: Any, orientation: Literal["horizontal","vertical"] = "vertical", linefmt:Optional[str] = ..., markerfmt:Optional[str]=...,
         label:Optional[str]=...) -> None: 
    """
    Draw a stem plot to the selected axis.
    Parameters
    ----------
    locs, heads: ArrayLike
        Datapoints for plot, (x,y) for vertical, (y,x) for horizontal
    orientation: {"vertical", "horizontal"}, default "vertical
        Orientation of stems
    alpha: float, optional
        Opacity
    linefmt, markerfmt: str, optional
        Short style of line and marker
    label: str, optional
        Legend entry
    """
    ...

def fill_between(
    self,
    x: ArrayLike,
    y1: ArrayLike,
    y2: Optional[ArrayLike] = ...,
    alpha: Optional[float] = ...,
    color: Optional[ColorLike] = ...,
    c: Optional[ColorLike] = ...
) -> None: 
    """
    Fill space between two plots (or a single plot and x-axis).
    Parameters
    ----------
    x,y1, y2 : ArrayLike or float (y2 optional)
        Datapoints, if matched with existing plot, that line will be recycled to save tikz memory.
    alpha: float, optional
        Opacity
    color or c: all matplotlib color formats (without X11/xkcd), optional
        Fill color: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible
    label: str, optional
        Legend entry
    """
    ...

def loglog(self, x: ArrayLike = ..., y: ArrayLike = ..., base: Optional[float] = 10,  fmt: Optional[str] = ...,*, alpha: Optional[float] = ..., color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
             linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ..., linewidth: Optional[float]= ..., lw: Optional[float] = ...,
             marker: Optional[MarkerStyle] = ..., markersize: Optional[float] = ..., ms: Optional[float] = ...) -> None:
    """
    Draw a general plot to the selected axis and change the current axis into log mode.

    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints
    base: float, optional
        Log basis, default 10
    fmt: str, optional
        Style
    alpha: float, optional
        Opacity
    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible
    label: str, optional
        Legned entry
    linestyle or ls: str, optional
        Line style
    linewidth or lw: float, optional
        Line width in pt
    
    marker: str, optional
        Marker type
    markersize or ms: float, optional
        Mark size in pt
    """
    ...

def hlines(
    self,
    y: Union[float, Sequence[float]],
    xmin: Union[float, Sequence[float]],
    xmax: Union[float, Sequence[float]],
    colors: Union[str, Sequence[str]] = "k",
    linestyles: Union[str, Sequence[str]] = "solid",
) -> None: 
    """
    Draw horizontal lines to the selected axis.
    """
    ...

def vlines(
    self,
    x: Union[float, Sequence[float]],
    ymin: Union[float, Sequence[float]],
    ymax: Union[float, Sequence[float]],
    colors: Union[str, Sequence[str]] = "k",
    linestyles: Union[str, Sequence[str]] = "solid",
) -> None: 
    """
    Draw vertical lines to the selected axis.
    """
    ...

def semilogx(self, x: ArrayLike = ..., y: ArrayLike = ..., base: Optional[float] = 10,  fmt: Optional[str] = ...,*, alpha: Optional[float] = ..., color: Optional[ColorLike] = ..., c: Optional[ColorLike] = ...,
             linestyle: Optional[LineStyle] = ..., ls: Optional[LineStyle] = ..., linewidth: Optional[float]= ..., lw: Optional[float] = ...,
             marker: Optional[MarkerStyle] = ..., markersize: Optional[float] = ..., ms: Optional[float] = ...) -> None:
    """
    Draw a general plot to the selected axis and change the current x-axis into log mode.
    Parameters
    ----------
    x,y : ArrayLike or float
        Datapoints
    base: float, optional
        Log basis, default 10
    fmt: str, optional
        Style
    alpha: float, optional
        Opacity
    color or c: all matplotlib color formats (without X11/xkcd), optional
        color of line and markers: RGB/RGBA (tuple), HEX (str), grayscale (float), single-char (str), name (str), default cycle ("CX", X int), none for invisible
    label: str, optional
        Legned entry
    linestyle or ls: str, optional
        Line style
    linewidth or lw: float, optional
        Line width in pt
    
    marker: str, optional
        Marker type
    markersize or ms: float, optional
        Mark size in pt
    """
    ...
def imshow(self, *args: Any, cmap: Optional[str] = ...) -> Tuple[Any, str, float, float]: 
    """
    Draw image to the selected axis from array. Uses matplotlib imshow() to export to PDF, then inputs the image to the axis. Return may be used to initialize Colorbar().
    """
    ...

def minorticks_num(self, num: int) -> None:
    ...
    """
    Set number of minor ticks between major ticks.
    
    Parameters
    ----------
    num: int
        Number of minor ticks between major ticks.
    """

def savefig(filename: str) -> None:
    """
    Save figure to .tex/.tikz file.

    If no extension is provided, '.tex' is appended.
    """
    ...

def show() -> None:
    """
    Save figure to autogenerated filename and clear it.
    """
    ...

def clf() -> None:
    """
    Clear current figure.
    """
    ...

def gca() -> Axes:
    """
    Get current axis.
    """
    ...