from setuptools import setup,find_packages as fp
with open("README.md","r",encoding="utf-8") as f:
    long_desc = f.read()
setup(
    name="YFKJ_suite",
    version="1.1.0",
    author="音符空间/NoteSpace",
    description="我的个人工具包",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    install_requires=["rich>=13.0.0","pydub>=0.25.1","opencv-python>=4.8.0", "Pillow>=10.0.0","numpy>=1.24.0"],
    packages=fp(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ]
)