"""
This module offers mathematical calculation and utility functions.
"""
import math
import io
import base64 as b64
def nth_root(a:float,n:float=2)->float:
    if(a<0):
        return None
    return a**(1.0/n)
def rotate(xy:tuple[int,int],cxy:tuple[int,int],ang:int,isint:bool=True)->tuple[int,int]:
    """
    Rotate a point (x, y) around a center point (cx, cy).
    """
    x,y,cx,cy = xy[0],xy[1],cxy[0],cxy[1]
    angr = math.radians(ang)
    cos_t = math.cos(angr)
    sin_t = math.sin(angr)
    dx = x-cx
    dy = y-cy
    ndx = dx*cos_t-dy*sin_t
    ndy = dx*sin_t+dy*cos_t
    nx = cx+ndx
    ny = cy+ndy
    if(isint):
        return round(nx),round(ny)
    else:
        return nx,ny