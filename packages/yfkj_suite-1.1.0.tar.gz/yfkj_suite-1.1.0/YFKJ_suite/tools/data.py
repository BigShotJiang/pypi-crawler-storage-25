"""
This module provides data conversion and processing utilities.
"""
import io
import base64 as b64
def base64_to_BytesIO(base64_str:str)->io.BytesIO:
    """
    Decodes a Base64 encoded string into an in-memory BytesIO stream object.
    
    This function converts the input Base64 string into raw bytes and wraps 
    them in a BytesIO buffer for in-memory binary data manipulation, 
    which is widely used in scenarios such as image processing, 
    file streaming, and binary data transmission.

    :param base64_str: Base64 encoded string to be decoded
    :return: io.BytesIO: In-memory binary stream containing the decoded data
    """
    return io.BytesIO(b64.b64decode(base64_str))