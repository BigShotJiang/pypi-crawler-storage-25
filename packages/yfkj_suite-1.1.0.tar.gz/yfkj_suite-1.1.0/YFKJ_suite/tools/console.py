"""
This module provides console interface and interaction utilities.
"""
import os,sys,math
from rich.console import Console as cons
def cls()->None:
    """
    Clear the console screen (Windows/macOS/Linux).
    """
    os.system('cls' if(sys.platform)=='win32' else 'clear')
def print_bar(console:cons,fore_text:str,chars_width:int,progress:float,fore_text_color:str="#ffffff",fore_progress_color:str="#ffffff",back_progress_color:str="#505050",back_text_color:str="#00aaff")->None:
    """
    Display a colored progress bar with text and percentage.

    :param console: Rich console instance for output
    :param fore_text: Text displayed before the progress bar
    :param chars_width: Total width of the progress bar in characters
    :param progress: Progress value, float between 0 and 1
    :param fore_text_color: Color of the leading text
    :param fore_progress_color: Color of the filled part
    :param back_progress_color: Color of the unfilled part
    :param back_text_color: Color of the percentage text
    """
    if(progress<0 or progress>1):
        raise ValueError("Progress must be a float between 0 and 1!")
    console.print(f"[{fore_text_color}]{fore_text}[/][{fore_progress_color}]{'█'*math.ceil(chars_width*progress)}[/][{back_progress_color}]{'█'*(chars_width-math.ceil(chars_width*progress))}[/][{back_text_color}]{math.ceil(progress*100)}%[/]")