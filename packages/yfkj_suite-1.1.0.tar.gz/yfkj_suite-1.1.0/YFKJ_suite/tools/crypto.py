"""
This module implements data encryption and decryption functionalities.
"""
def en_unicode(a:str,n:int)->str:
    """
    Encode a string by shifting each character's Unicode value by n.
    """
    d = a.split("\n")
    bro = []
    for st in d:
        try:
            out = ""
            for i in st:
                out += chr(ord(i)+n)
            bro.append(out)
        except Exception as e:
            return "ERROR:"+str(e)
    return "\n".join(bro)+f"{{{n}}}"
def de_unicode(a:str)->str:
    """
    Decode a string encoded by en_unicode.
    """
    bro = []
    n = ""
    er = 0
    for i in range(len(a)-2,1,-1):
        if(a[i]=="{"):
            er = i
            break
        n = a[i]+n
    n = int(n)
    a = a[0:er]
    d = a.split("\n")
    for st in d:
        try:
            out = ""
            for i in st:
                out += chr(ord(i)-n)
            bro.append(out)
        except Exception as e:
            return "ERROR:"+str(e)
    return "\n".join(bro)