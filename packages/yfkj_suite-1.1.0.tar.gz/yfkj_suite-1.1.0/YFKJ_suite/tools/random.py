"""
This module handles true random related operations.
"""
import secrets as secr
def rand_int(x:int,y:int)->int:
    """
    Generate a true random integer between x and y (inclusive).
    """
    if(x>y):
        x,y = y,x
    return secr.randbelow(y-x+1)+x
def rand_float(x:float,y:float,precision:int=None)->float:
    """
    Generate a true random float number between x and y (inclusive).

    :param precision: Number of decimal places to keep (optional)
    """
    if(x>y):
        x,y = y,x
    ran1 = secr.randbits(53)/(2**53)
    res = x+(y-x)*ran1
    if(not precision==None):
        res = round(res,precision)
    return res
def rand_choice(lst:list):
    """
    Select a cryptographically secure random element from a list.
    
    :param lst: The list to select a random element from.
    """
    if(not lst):
        raise ValueError("List cannot be empty!")
    return lst[secr.randbelow(len(lst))]
def rand_shuffle(lst:list):
    """
    Shuffle a list in cryptographically secure random order.

    :param lst: The list to be shuffled.
    """
    if(not lst):
        raise ValueError("List cannot be empty!")
    arr:list = lst.copy()
    n = len(arr)
    for i in range(n-1,0,-1):
        j = secr.randbelow(i+1)
        arr[i],arr[j] = arr[j],arr[i]
    return arr