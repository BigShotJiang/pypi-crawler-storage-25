"""
This module contains media processing related components.
"""
from pydub import AudioSegment as ase
from pydub.playback import play
import threading as thr
import numpy as np
import cv2
from PIL import Image as img
import io
def play_audio(audio_segment:ase)->None:
    """
    Play audio asynchronously in a background thread.
    
    Starts a new thread to play the given audio segment, preventing the main
    program from being blocked during audio playback.
    """
    th1 = thr.Thread(target=play,args=[audio_segment])
    th1.start()

class NewVideo:
    """
    A class for creating and writing a new video file.
    Provides frame adding and finalizing operations.
    """
    def __init__(self,out_file:str|io.BytesIO,width:int,height:int,fps:int=60)->None:
        self.w:int = width
        self.h:int = height
        self.vw:cv2.VideoWriter = cv2.VideoWriter(out_file,cv2.VideoWriter_fourcc(*"mp4v"),fps,(self.w,self.h))
    def add_frame(self,PIL_image:img.Image)->None:
        """
        Add a PIL image as a frame to the video.
        """
        self.vw.write(cv2.cvtColor(np.array(PIL_image),cv2.COLOR_RGB2BGR))
    def done(self)->None:
        """
        Finalize and save the video file, release all video resources.
        Call this method after adding all frames to complete video generation.
        """
        self.vw.release()
class OpenVideo:
    """
    A class for reading and processing an existing video file.
    Provides frame reading, video information and resource management.
    """
    def __init__(self,source:str|io.BytesIO) -> None:
        self.vc:cv2.VideoCapture = cv2.VideoCapture(source)
        self.isop:bool = self.vc.isOpened()
        self.w:int = int(self.vc.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.h:int = int(self.vc.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.fps:float = self.vc.get(cv2.CAP_PROP_FPS)
        self.tolfr:int = int(self.vc.get(cv2.CAP_PROP_FRAME_COUNT))
        self.dura:float = self.tolfr/self.fps if(self.fps>0) else 0.0
        self.forc:int = int(self.vc.get(cv2.CAP_PROP_FOURCC))
        self.codec:str = "".join([chr((self.forc>>8*i)&0xFF) for i in range(4)])
        self.bps:int = int(self.vc.get(cv2.CAP_PROP_BITRATE))
        self.kbps:float = self.bps/1000
    def get_nth_frame(self,n:int)->img.Image|None:
        """
        Get the nth frame of video and return as PIL Image object.
        
        :param n: Target frame index starting from 0
        :return: PIL Image if valid, None if out of range or failed
        """
        if(not self.isop or n<0 or n>=self.tolfr):
            return None
        self.vc.set(cv2.CAP_PROP_POS_FRAMES,n)
        rec:bool
        fra:np.ndarray
        rec,fra = self.vc.read()
        if(not rec):
            return None
        return img.fromarray(cv2.cvtColor(fra,cv2.COLOR_BGR2RGB))
    def get_info(self)->dict:
        """
        Get all video information as a dictionary.
        
        :return: dictionary containing complete video information
        """
        info:dict = {"Video opened":f"{self.isop}","Resolution":f"{self.w}x{self.h}","FPS":f"{self.fps:.2f}","Total frames":f"{self.tolfr}","Duration":f"{self.dura:.2f}s","Codec":f"{self.codec}","Bitrate":f"{self.kbps:.2f}kbps({self.bps}bps)"}
        return info
    def close(self)->None:
        """
        Release video capture resource and close video stream.
        """
        self.vc.release()