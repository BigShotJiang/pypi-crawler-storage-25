from __future__ import annotations

import json
import math
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Protocol

from ..adapters.db.base import DBAdapter
from ..adapters.llm.base import LLMAdapter, LLMCompletionRequest, LLMMessage
from ..core.composer import Composer
from ..core.decomposer import Decomposer
from ..core.hasher import Hasher
from ..core.minhash import MinHash
from ..core.normalizer import Normalizer
from ..core.uncertainty import UncertaintyEstimator
from ..types import (
    CacheEntry,
    CacheType,
    CompletionRequest,
    CompletionResponse,
    ComposeCacheConfig,
    ComposeCacheError,
    ComposeCacheErrorCode,
    DecompositionResult,
    SubQuery,
    SubQueryHit,
)

SHORT_UTTERANCES = {"ok", "okay", "stop", "hi", "hello", "thanks", "thank you"}
COUNTRY_HINTS = {
    "usa",
    "us",
    "united states",
    "nepal",
    "india",
    "china",
    "france",
    "germany",
    "japan",
    "canada",
    "uk",
    "united kingdom",
}
ENTITY_STOPWORDS = {
    "what",
    "which",
    "who",
    "where",
    "when",
    "how",
    "is",
    "the",
    "of",
    "and",
    "or",
    "area",
    "capital",
    "city",
    "gdp",
    "compare",
}
UNIT_HINTS = {"km", "km2", "sqm", "sqkm", "sq", "miles", "mi", "usd", "eur", "percent"}
ANSWER_TYPE_HINTS = {
    "person_role": ["president", "prime minister", "ceo", "founder", "leader", "minister", "mayor"],
    "measurement": ["length", "width", "height", "area", "size", "distance", "population", "gdp", "revenue"],
    "location": ["capital", "city", "country", "where", "location", "address"],
    "time": ["when", "date", "year", "age", "founded", "created", "started"],
    "definition": ["what is", "define", "meaning", "explain"],
    "procedure": ["how to", "steps", "process", "install", "setup", "configure"],
}


class Orchestrator:
    _NEGATIVE_TTL = "1h"

    def __init__(
        self,
        db: DBAdapter,
        llm: LLMAdapter,
        embedder: "Embedder",
        config: ComposeCacheConfig,
    ) -> None:
        self._db = db
        self._llm = llm
        self._embedder = embedder
        self._config = config
        self._uncertainty = UncertaintyEstimator()
        self._decomposer = Decomposer(
            llm=llm,
            enabled=config.decomposition.enabled,
            model=config.decomposition.model,
        )
        self._composer = Composer(llm=llm, model=config.decomposition.model)

    def complete(self, request: CompletionRequest, ttl: str | None = None) -> CompletionResponse:
        start = time.time()
        query = self._extract_query(request)
        doc_fingerprint = (
            MinHash.from_document_ids([doc.id for doc in request.documents]) if request.documents else None
        )

        decomposition = self._decomposer.classify(query)

        if decomposition.type.value == "atomic":
            answer = self._probe_and_resolve(query, doc_fingerprint, request, is_sub_query=False, ttl=ttl)
            return CompletionResponse(
                content=answer.content,
                cache_type=CacheType(answer.from_cache if answer.cached else "miss"),
                sub_query_hits=[
                    SubQueryHit(
                        id=0,
                        query=query,
                        hit=answer.cached,
                        from_cache=answer.from_cache,
                        decision_reason=answer.decision_reason,
                        semantic_score=answer.semantic_score,
                    )
                ],
                tokens_saved=answer.tokens_saved,
                latency_ms=int((time.time() - start) * 1000),
                cost_saved=self._estimate_cost_saved(answer.tokens_saved),
                decision_reason=answer.decision_reason,
            )

        answers: dict[int, ResolvedAnswer] = {}

        independent = [sq for sq in decomposition.sub_queries if not sq.depends_on]
        for sq in independent:
            answers[sq.id] = self._probe_and_resolve(sq.text, doc_fingerprint, request, is_sub_query=True, ttl=ttl)

        dependent = [sq for sq in self._topological_order(decomposition.sub_queries) if sq.depends_on]
        for sq in dependent:
            resolved_query = self._substitute_dependencies(sq.text, sq.depends_on, answers)
            answers[sq.id] = self._probe_and_resolve(
                resolved_query,
                doc_fingerprint,
                request,
                is_sub_query=True,
                ttl=ttl,
            )

        composed = self._composer.compose(
            original_query=query,
            query_type=decomposition.type,
            sub_queries=decomposition.sub_queries,
            answers={k: v.content for k, v in answers.items()},
        )

        sub_hits = self._to_sub_query_hits(decomposition, answers)
        tokens_saved = sum(answers[hit.id].tokens_saved for hit in sub_hits if hit.id in answers)

        return CompletionResponse(
            content=composed,
            cache_type=self._determine_cache_type(sub_hits),
            sub_query_hits=sub_hits,
            tokens_saved=tokens_saved,
            latency_ms=int((time.time() - start) * 1000),
            cost_saved=self._estimate_cost_saved(tokens_saved),
            decision_reason=self._determine_cache_type(sub_hits).value,
        )

    def _probe_and_resolve(
        self,
        query: str,
        doc_fingerprint: bytes | None,
        request: CompletionRequest,
        is_sub_query: bool,
        ttl: str | None,
    ) -> "ResolvedAnswer":
        normalized = Normalizer.normalize(query)
        params_hash = Hasher.hash_params(
            {
                "model": request.model,
                "temperature": request.temperature or 0,
                "top_p": request.top_p or 1,
                "max_tokens": request.max_tokens or 0,
            }
        )
        exact_key = Hasher.hash(normalized, doc_fingerprint, params_hash)

        exact_hit = self._db.get_by_key(exact_key)
        if exact_hit:
            return ResolvedAnswer(
                content=exact_hit.response,
                cached=True,
                from_cache="exact",
                tokens_saved=exact_hit.tokens_saved,
                decision_reason="exact_hit",
                semantic_score=1.0,
            )

        pre_rejection = self._pre_semantic_rejection(query)

        embedding = self._embedder.embed(normalized)

        negative_candidates = self._db.negative_similarity_search(embedding, 5)
        for negative_candidate in negative_candidates:
            if not negative_candidate.query_embedding:
                continue
            query_sim = self._cosine_similarity(embedding, negative_candidate.query_embedding)
            if query_sim >= self._config.thresholds.query:
                refusal_message = negative_candidate.refusal_reason or "Request cannot be answered safely."
                return ResolvedAnswer(
                    content=refusal_message,
                    cached=True,
                    from_cache="semantic",
                    tokens_saved=0,
                    decision_reason="semantic_hit",
                    semantic_score=query_sim,
                )

        candidates = self._db.similarity_search(embedding, 5)
        last_rejection = pre_rejection or "miss"
        top_semantic_score: float | None = None

        for positive_candidate in candidates:
            if not positive_candidate.query_embedding:
                continue

            query_sim = self._cosine_similarity(embedding, positive_candidate.query_embedding)
            if doc_fingerprint and positive_candidate.doc_fingerprint:
                doc_sim = MinHash.jaccard_from_signatures(doc_fingerprint, positive_candidate.doc_fingerprint)
            elif doc_fingerprint and not positive_candidate.doc_fingerprint:
                doc_sim = 0.0
            else:
                doc_sim = 1.0

            accepted, rejection_reason, semantic_score = self._evaluate_semantic_candidate(
                query=query,
                query_sim=query_sim,
                doc_sim=doc_sim,
                candidate=positive_candidate,
            )
            top_semantic_score = max(top_semantic_score or 0.0, semantic_score)
            last_rejection = rejection_reason

            if pre_rejection is not None:
                accepted = False
                rejection_reason = pre_rejection
                last_rejection = pre_rejection

            if accepted:
                return ResolvedAnswer(
                    content=positive_candidate.response,
                    cached=True,
                    from_cache="semantic",
                    tokens_saved=positive_candidate.tokens_saved,
                    decision_reason="semantic_hit",
                    semantic_score=semantic_score,
                )

        llm_response = self._llm.complete(
            LLMCompletionRequest(
                model=request.model,
                messages=[LLMMessage(role="user", content=query)],
                temperature=request.temperature,
                top_p=request.top_p,
                max_tokens=request.max_tokens,
            )
        )

        uncertainty = self._uncertainty.estimate(query, llm_response.content, llm_response.logprobs)
        usage_tokens = (
            llm_response.usage.total_tokens
            if llm_response.usage is not None
            else max(1, math.ceil(len(llm_response.content) / 4))
        )

        refusal_reason = self._refusal_reason(llm_response.content)

        if uncertainty <= self._config.thresholds.uncertainty and refusal_reason is None:
            self._db.insert(
                CacheEntry(
                    cache_key=exact_key,
                    query_text=query,
                    query_normalized=normalized,
                    response=llm_response.content,
                    model=request.model,
                    params_hash=params_hash,
                    query_embedding=embedding,
                    doc_fingerprint=doc_fingerprint,
                    uncertainty=uncertainty,
                    is_sub_query=is_sub_query,
                    tokens_saved=usage_tokens,
                    expires_at=self._to_expiry(ttl),
                )
            )
        elif refusal_reason is not None:
            self._db.insert_negative(
                cache_key=exact_key,
                query_embedding=embedding,
                refusal_reason=refusal_reason,
                expires_at=self._to_expiry(self._NEGATIVE_TTL),
            )

        return ResolvedAnswer(
            content=llm_response.content,
            cached=False,
            from_cache="miss",
            tokens_saved=0,
            decision_reason=last_rejection,
            semantic_score=top_semantic_score,
        )

    def _extract_query(self, request: CompletionRequest) -> str:
        for message in reversed(request.messages):
            if message.role == "user" and bool(message.content.strip()):
                return message.content
        raise ComposeCacheError(
            ComposeCacheErrorCode.INVALID_QUERY,
            "No non-empty user message found in request.messages",
        )

    def _to_sub_query_hits(
        self, decomposition: DecompositionResult, answers: dict[int, "ResolvedAnswer"]
    ) -> list[SubQueryHit]:
        out: list[SubQueryHit] = []
        for sq in decomposition.sub_queries:
            answer = answers.get(sq.id)
            out.append(
                SubQueryHit(
                    id=sq.id,
                    query=sq.text,
                    hit=answer.cached if answer else False,
                    from_cache=answer.from_cache if answer else "miss",
                    decision_reason=answer.decision_reason if answer else "miss",
                    semantic_score=answer.semantic_score if answer else None,
                )
            )
        return out

    def _pre_semantic_rejection(self, query: str) -> str | None:
        if not self._config.safe_semantic.safe_semantic_mode:
            return None

        normalized = Normalizer.normalize(query)
        tokens = [token for token in normalized.split(" ") if token]
        if (
            self._config.safe_semantic.strict_short_query_policy
            and (len(tokens) < 3 or len(normalized) < 8 or normalized in SHORT_UTTERANCES)
        ):
            return "rejected_short_ambiguous"
        return None

    def _evaluate_semantic_candidate(
        self,
        query: str,
        query_sim: float,
        doc_sim: float,
        candidate: CacheEntry,
    ) -> tuple[bool, str, float]:
        semantic_score = max(0.0, min(1.0, query_sim * 0.9 + doc_sim * 0.1))
        drift = 1 - query_sim

        score_pass = (
            query_sim >= self._config.thresholds.query
            and doc_sim >= self._config.thresholds.document
            and semantic_score >= self._effective_min_semantic_score(query, candidate.response)
            and drift <= self._config.safe_semantic.max_semantic_drift
        )
        uncertainty_pass = candidate.uncertainty <= self._config.thresholds.uncertainty
        entity_pass = (
            not self._config.safe_semantic.require_entity_overlap
            or not self._has_entity_mismatch(query, f"{candidate.query_text} {candidate.response}")
        )
        intent_pass = (
            not self._config.safe_semantic.require_intent_match
            or not self._has_intent_mismatch(query, candidate.query_text)
        )

        if not score_pass or not uncertainty_pass:
            return False, "rejected_low_confidence", semantic_score
        if not entity_pass:
            return False, "rejected_entity_mismatch", semantic_score
        if not intent_pass:
            return False, "rejected_intent_mismatch", semantic_score

        validator = self._validate_semantic_reuse(query, candidate.query_text, candidate.response, semantic_score)
        if not validator.reusable:
            return False, validator.reason, semantic_score
        return True, "semantic_hit", semantic_score

    def _effective_min_semantic_score(self, query: str, response: str) -> float:
        score = self._config.safe_semantic.min_semantic_score
        tokens = [token for token in Normalizer.normalize(query).split(" ") if token]
        entities = self._extract_entities(query)
        facts_count = len(re.findall(r"\b\d+(?:\.\d+)?\b", response))

        if len(tokens) <= 5:
            score += 0.02
        if entities.named or entities.numbers or entities.units:
            score += 0.02
        if facts_count >= 3:
            score += 0.01
        return max(0.0, min(1.0, score))

    def _has_intent_mismatch(self, query: str, candidate_query: str) -> bool:
        left = self._classify_answer_type(query)
        right = self._classify_answer_type(candidate_query)
        return left != "unknown" and right != "unknown" and left != right

    def _classify_answer_type(self, text: str) -> str:
        normalized = Normalizer.normalize(text).lower()
        for answer_type, hints in ANSWER_TYPE_HINTS.items():
            if any(re.search(rf"\b{re.escape(hint)}\b", normalized) for hint in hints):
                return answer_type
        return "unknown"

    def _has_entity_mismatch(self, query: str, candidate_text: str) -> bool:
        query_entities = self._extract_entities(query)
        candidate_entities = self._extract_entities(candidate_text)

        if not query_entities.named and not query_entities.numbers and not query_entities.units:
            return False

        if query_entities.named and not query_entities.named.intersection(candidate_entities.named):
            return True
        if query_entities.numbers and not query_entities.numbers.intersection(candidate_entities.numbers):
            return True
        if query_entities.units and not query_entities.units.intersection(candidate_entities.units):
            return True
        return False

    def _extract_entities(self, text: str) -> "ExtractedEntities":
        lower = text.lower()
        named: set[str] = set()
        numbers: set[str] = set(re.findall(r"\b\d+(?:\.\d+)?\b", lower))
        units: set[str] = set()

        for hint in COUNTRY_HINTS:
            if re.search(rf"\b{re.escape(hint)}\b", lower):
                named.add(hint)

        for match in re.findall(r"\b[A-Z][a-z]+\b|\b[A-Z]{2,}\b", text):
            normalized = match.lower()
            if normalized not in ENTITY_STOPWORDS and len(normalized) > 2:
                named.add(normalized)

        for token in re.split(r"[^a-z0-9]+", lower):
            if token in UNIT_HINTS:
                units.add(token)

        return ExtractedEntities(named=named, numbers=numbers, units=units)

    def _validate_semantic_reuse(
        self, query: str, candidate_query: str, candidate_answer: str, semantic_score: float
    ) -> "SemanticValidatorResult":
        mode = self._config.safe_semantic.semantic_validator_mode
        if mode == "off":
            return SemanticValidatorResult(reusable=True, confidence=1.0, reason="semantic_hit")
        if mode == "borderline" and semantic_score >= self._config.safe_semantic.min_semantic_score + 0.04:
            return SemanticValidatorResult(reusable=True, confidence=1.0, reason="semantic_hit")

        try:
            response = self._llm.complete(
                LLMCompletionRequest(
                    model=self._config.decomposition.model,
                    messages=[
                        LLMMessage(
                            role="system",
                            content=(
                                "You validate semantic cache reuse. Return JSON only with reusable:boolean, "
                                "confidence:number between 0 and 1, reason:string. Reusable means the cached "
                                "answer directly answers the new query with the same intent, answer type, and context."
                            ),
                        ),
                        LLMMessage(
                            role="user",
                            content=json.dumps(
                                {
                                    "new_query": query,
                                    "cached_query": candidate_query,
                                    "cached_answer": candidate_answer,
                                }
                            ),
                        ),
                    ],
                    temperature=0,
                    max_tokens=120,
                    response_format_json=True,
                )
            )
            payload = json.loads(response.content)
            reusable = payload.get("reusable") is True
            confidence = float(payload.get("confidence", 0.0))
            if reusable and confidence >= self._config.safe_semantic.semantic_validator_min_confidence:
                return SemanticValidatorResult(reusable=True, confidence=confidence, reason="semantic_hit")
        except Exception:
            pass

        return SemanticValidatorResult(
            reusable=False,
            confidence=0.0,
            reason="rejected_validator_mismatch",
        )

    def _determine_cache_type(self, hits: list[SubQueryHit]) -> CacheType:
        if not hits:
            return CacheType.MISS
        total_hits = len([h for h in hits if h.hit])
        if total_hits == 0:
            return CacheType.MISS
        if total_hits == len(hits):
            return CacheType.EXACT if all(h.from_cache == "exact" for h in hits) else CacheType.SEMANTIC
        return CacheType.PARTIAL

    def _topological_order(self, sub_queries: list[SubQuery]) -> list[SubQuery]:
        by_id = {sq.id: sq for sq in sub_queries}
        visited: set[int] = set()
        order: list[SubQuery] = []

        def visit(sq_id: int) -> None:
            if sq_id in visited:
                return
            visited.add(sq_id)
            sq = by_id.get(sq_id)
            if not sq:
                return
            for dep in sq.depends_on:
                visit(dep)
            order.append(sq)

        for sq in sub_queries:
            visit(sq.id)
        return order

    def _substitute_dependencies(
        self, text: str, dependencies: list[int], answers: dict[int, "ResolvedAnswer"]
    ) -> str:
        resolved = text
        for dep in dependencies:
            dep_content = answers[dep].content if dep in answers else ""
            resolved = re.sub(r"\{" + str(dep) + r"\}", dep_content, resolved)
        return resolved

    def _to_expiry(self, ttl: str | None) -> datetime | None:
        if not ttl:
            return None
        match = re.match(r"^(\d+)([smhdw])$", ttl.lower())
        if not match:
            return None
        value = int(match.group(1))
        unit = match.group(2)

        if unit == "s":
            delta = timedelta(seconds=value)
        elif unit == "m":
            delta = timedelta(minutes=value)
        elif unit == "h":
            delta = timedelta(hours=value)
        elif unit == "d":
            delta = timedelta(days=value)
        else:
            delta = timedelta(weeks=value)

        return datetime.now(tz=timezone.utc) + delta

    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        length = min(len(a), len(b))
        if length == 0:
            return 0.0

        dot = 0.0
        norm_a = 0.0
        norm_b = 0.0
        for i in range(length):
            dot += a[i] * b[i]
            norm_a += a[i] * a[i]
            norm_b += b[i] * b[i]
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / ((norm_a**0.5) * (norm_b**0.5))

    def _estimate_cost_saved(self, tokens_saved: int) -> float:
        return round(tokens_saved * 0.000002, 6)

    def _is_refusal(self, text: str) -> bool:
        return self._refusal_reason(text) is not None

    def _refusal_reason(self, text: str) -> str | None:
        lower = text.lower()
        phrases = ["i cannot", "i can't", "i am unable", "sorry, i"]
        for phrase in phrases:
            if phrase in lower:
                return f"refusal:{phrase}"
        return None


@dataclass(slots=True)
class ResolvedAnswer:
    content: str
    cached: bool
    from_cache: str
    tokens_saved: int
    decision_reason: str
    semantic_score: float | None = None


@dataclass(slots=True)
class ExtractedEntities:
    named: set[str]
    numbers: set[str]
    units: set[str]


@dataclass(slots=True)
class SemanticValidatorResult:
    reusable: bool
    confidence: float
    reason: str


class Embedder(Protocol):
    def embed(self, text: str) -> list[float]:
        ...
