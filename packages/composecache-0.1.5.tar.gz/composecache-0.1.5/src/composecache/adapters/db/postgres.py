from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

import psycopg
from pgvector.psycopg import register_vector  # type: ignore[import-untyped]

from ...types import CacheEntry, ComposeCacheError, ComposeCacheErrorCode, NegativeCacheEntry
from .base import DBAdapter


class PostgresAdapter(DBAdapter):
    def __init__(self, connection_string: str, table_name: str = "llm_cache") -> None:
        self._connection_string = connection_string
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", table_name):
            raise ComposeCacheError(
                ComposeCacheErrorCode.INVALID_CONFIG,
                "Invalid table name",
                {"table_name": table_name},
            )
        self._table_name = table_name
        self._conn: psycopg.Connection | None = None

    def connect(self) -> None:
        try:
            if self._conn:
                self._conn.close()
            self._conn = psycopg.connect(self._connection_string)
            register_vector(self._conn)
            with self._conn.cursor() as cur:
                cur.execute("SELECT 1")
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_CONNECTION_FAILED,
                "Failed to connect to PostgreSQL",
                {"cause": str(exc)},
            ) from exc

    def migrate(self) -> None:
        if not self._conn:
            self.connect()
        assert self._conn is not None

        migration_path = Path(__file__).resolve().parents[2] / "sql" / "001_init.sql"
        try:
            migration = migration_path.read_text(encoding="utf-8")
            with self._conn.cursor() as cur:
                cur.execute(migration)
            self._conn.commit()
        except Exception as exc:
            self._conn.rollback()
            raise ComposeCacheError(
                ComposeCacheErrorCode.MIGRATION_FAILED,
                "Failed to run migration",
                {"cause": str(exc)},
            ) from exc

    def get_by_key(self, key: str) -> CacheEntry | None:
        if not self._conn:
            return None
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    f"""SELECT * FROM {self._table_name}
                    WHERE cache_key = %s
                      AND (expires_at IS NULL OR expires_at > NOW())
                    LIMIT 1""",
                    (key,),
                )
                row = cur.fetchone()
            if not row:
                return None
            return self._map_row(row)
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to fetch cache entry",
                {"operation": "get_by_key", "cause": str(exc)},
            ) from exc

    def similarity_search(self, embedding: list[float], k: int) -> list[CacheEntry]:
        if not self._conn:
            return []
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    """
                    SELECT * FROM {table_name}
                    WHERE query_embedding IS NOT NULL
                      AND (expires_at IS NULL OR expires_at > NOW())
                    ORDER BY query_embedding <=> %s
                    LIMIT %s
                    """.format(table_name=self._table_name),
                    (embedding, k),
                )
                rows = cur.fetchall()
            return [self._map_row(row) for row in rows]
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to run similarity search",
                {"operation": "similarity_search", "cause": str(exc)},
            ) from exc

    def negative_similarity_search(self, embedding: list[float], k: int) -> list[NegativeCacheEntry]:
        if not self._conn:
            return []
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    """
                    SELECT * FROM llm_cache_negative
                    WHERE query_embedding IS NOT NULL
                      AND (expires_at IS NULL OR expires_at > NOW())
                    ORDER BY query_embedding <=> %s
                    LIMIT %s
                    """,
                    (embedding, k),
                )
                rows = cur.fetchall()
            return [self._map_negative_row(row) for row in rows]
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to run negative similarity search",
                {"operation": "negative_similarity_search", "cause": str(exc)},
            ) from exc

    def insert(self, entry: CacheEntry) -> None:
        if not self._conn:
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute(
                    """
                                        INSERT INTO {table_name} (
                      cache_key, query_text, query_normalized, response, model, params_hash,
                      query_embedding, doc_fingerprint, uncertainty, is_sub_query,
                      parent_query_id, tokens_saved, expires_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (cache_key)
                    DO UPDATE SET
                                            hit_count = {table_name}.hit_count + 1,
                      last_hit_at = NOW()
                                        """.format(table_name=self._table_name),
                    (
                        entry.cache_key,
                        entry.query_text,
                        entry.query_normalized,
                        entry.response,
                        entry.model,
                        entry.params_hash,
                        entry.query_embedding,
                        entry.doc_fingerprint,
                        entry.uncertainty,
                        entry.is_sub_query,
                        entry.parent_query_id,
                        entry.tokens_saved,
                        entry.expires_at,
                    ),
                )
            self._conn.commit()
        except Exception as exc:
            self._conn.rollback()
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to insert cache entry",
                {"operation": "insert", "cause": str(exc)},
            ) from exc

    def insert_negative(
        self,
        cache_key: str,
        query_embedding: list[float],
        refusal_reason: str,
        expires_at: datetime | None = None,
    ) -> None:
        if not self._conn:
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO llm_cache_negative (
                      cache_key,
                      query_embedding,
                      refusal_reason,
                      expires_at
                    ) VALUES (%s, %s, %s, %s)
                    ON CONFLICT (cache_key)
                    DO UPDATE SET
                      query_embedding = EXCLUDED.query_embedding,
                      refusal_reason = EXCLUDED.refusal_reason,
                      expires_at = EXCLUDED.expires_at
                    """,
                    (cache_key, query_embedding, refusal_reason, expires_at),
                )
            self._conn.commit()
        except Exception as exc:
            self._conn.rollback()
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to insert negative cache entry",
                {"operation": "insert_negative", "cause": str(exc)},
            ) from exc

    def delete(self, key: str) -> None:
        if not self._conn:
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"DELETE FROM {self._table_name} WHERE cache_key = %s", (key,))
            self._conn.commit()
        except Exception as exc:
            self._conn.rollback()
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to delete cache entry",
                {"operation": "delete", "cause": str(exc)},
            ) from exc

    def purge(self, older_than: datetime | None = None, model: str | None = None) -> int:
        if not self._conn:
            return 0

        conditions: list[str] = []
        params: list[object] = []

        if older_than is not None:
            conditions.append("created_at < %s")
            params.append(older_than)
        if model is not None:
            conditions.append("model = %s")
            params.append(model)

        where_clause = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"DELETE FROM {self._table_name}{where_clause}", tuple(params))
                deleted = cur.rowcount or 0
            self._conn.commit()
            return deleted
        except Exception as exc:
            self._conn.rollback()
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to purge cache entries",
                {"operation": "purge", "cause": str(exc)},
            ) from exc

    def stats(self) -> dict[str, float]:
        if not self._conn:
            return {"total_entries": 0.0, "hit_rate": 0.0}
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    """
                    SELECT
                      COUNT(*)::int AS total,
                      COALESCE(SUM(CASE WHEN hit_count > 0 THEN 1 ELSE 0 END), 0)::int AS hits
                    FROM {table_name}
                    """.format(table_name=self._table_name)
                )
                row = cur.fetchone() or {"total": 0, "hits": 0}
            total = float(row["total"])
            hits = float(row["hits"])
            hit_rate = 0.0 if total == 0 else hits / total
            return {"total_entries": total, "hit_rate": hit_rate}
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_FAILED,
                "Failed to compute cache stats",
                {"operation": "stats", "cause": str(exc)},
            ) from exc

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _map_row(self, row: dict[str, Any]) -> CacheEntry:
        query_embedding = row.get("query_embedding")
        embedding: list[float] | None = None
        if isinstance(query_embedding, str):
            stripped = query_embedding.strip().strip("[]")
            embedding = [float(x) for x in stripped.split(",") if x.strip()] if stripped else []
        elif isinstance(query_embedding, list):
            embedding = [float(x) for x in query_embedding]

        doc_fingerprint = row.get("doc_fingerprint")
        uncertainty = self._to_float(row.get("uncertainty"), 0.0)
        parent_query_id = self._to_int(row.get("parent_query_id"))
        hit_count = self._to_int(row.get("hit_count"), 0)
        tokens_saved = self._to_int(row.get("tokens_saved"), 0)
        created_at = row.get("created_at") if isinstance(row.get("created_at"), datetime) else None
        last_hit_at = row.get("last_hit_at") if isinstance(row.get("last_hit_at"), datetime) else None
        expires_at = row.get("expires_at") if isinstance(row.get("expires_at"), datetime) else None

        return CacheEntry(
            cache_key=str(row.get("cache_key", "")),
            query_text=str(row.get("query_text", "")),
            query_normalized=str(row.get("query_normalized", "")),
            response=str(row.get("response", "")),
            model=str(row.get("model", "")),
            params_hash=str(row.get("params_hash", "")),
            query_embedding=embedding,
            doc_fingerprint=doc_fingerprint if isinstance(doc_fingerprint, bytes) else None,
            uncertainty=uncertainty,
            is_sub_query=bool(row.get("is_sub_query", False)),
            parent_query_id=parent_query_id,
            hit_count=hit_count,
            tokens_saved=tokens_saved,
            created_at=created_at,
            last_hit_at=last_hit_at,
            expires_at=expires_at,
        )

    def _map_negative_row(self, row: dict[str, Any]) -> NegativeCacheEntry:
        query_embedding = row.get("query_embedding")
        embedding: list[float] | None = None
        if isinstance(query_embedding, str):
            stripped = query_embedding.strip().strip("[]")
            embedding = [float(x) for x in stripped.split(",") if x.strip()] if stripped else []
        elif isinstance(query_embedding, list):
            embedding = [float(x) for x in query_embedding]

        created_at = row.get("created_at") if isinstance(row.get("created_at"), datetime) else None
        expires_at = row.get("expires_at") if isinstance(row.get("expires_at"), datetime) else None
        refusal_reason = row.get("refusal_reason")

        return NegativeCacheEntry(
            cache_key=str(row.get("cache_key", "")),
            query_embedding=embedding,
            refusal_reason=str(refusal_reason) if refusal_reason is not None else None,
            created_at=created_at,
            expires_at=expires_at,
        )

    def _to_int(self, value: Any, default: int = 0) -> int:
        if value is None:
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _to_float(self, value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default
