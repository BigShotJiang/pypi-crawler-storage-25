from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping

from .adapters.db.base import DBAdapter
from .adapters.db.postgres import PostgresAdapter
from .adapters.llm.openai_adapter import OpenAIAdapter
from .core.embedder import TransformerEmbedder
from .core.orchestrator import Orchestrator
from .types import (
    CompletionRequest,
    CompletionResponse,
    ComposeCacheConfig,
    ComposeCacheError,
    ComposeCacheErrorCode,
    DocumentLike,
    Message,
)


class ComposeCache:
    def __init__(
        self,
        database_url: str,
        openai_api_key: str,
        ttl: str | None = "7d",
        table_name: str = "llm_cache",
    ) -> None:
        self._config = ComposeCacheConfig(
            database_url=database_url,
            openai_api_key=openai_api_key,
            ttl=ttl,
            table_name=table_name,
        )
        self._db: DBAdapter = PostgresAdapter(database_url, table_name=table_name)
        self._llm = OpenAIAdapter(openai_api_key)
        self._embedder = TransformerEmbedder()
        self._orchestrator = Orchestrator(self._db, self._llm, self._embedder, self._config)
        self._initialized = False

    def complete(self, request: Mapping[str, Any]) -> dict[str, Any]:
        self._ensure_initialized()

        if "model" not in request:
            raise ComposeCacheError(
                ComposeCacheErrorCode.INVALID_QUERY,
                "request.model is required",
            )

        messages = self._parse_messages(request.get("messages", []))
        if not any(m.role == "user" and bool(m.content.strip()) for m in messages):
            raise ComposeCacheError(
                ComposeCacheErrorCode.INVALID_QUERY,
                "request.messages must contain at least one non-empty user message",
            )

        typed_request = CompletionRequest(
            model=str(request["model"]),
            messages=messages,
            documents=self._parse_documents(request.get("documents")),
            temperature=self._to_optional_float(request.get("temperature")),
            top_p=self._to_optional_float(request.get("top_p")),
            max_tokens=self._to_optional_int(request.get("max_tokens")),
        )

        result: CompletionResponse = self._orchestrator.complete(typed_request, ttl=self._config.ttl)
        return {
            "content": result.content,
            "cache_type": result.cache_type.value,
            "sub_query_hits": [
                {
                    "id": h.id,
                    "query": h.query,
                    "hit": h.hit,
                    "from": h.from_cache,
                    "decision_reason": h.decision_reason,
                    "semantic_score": h.semantic_score,
                }
                for h in result.sub_query_hits
            ],
            "tokens_saved": result.tokens_saved,
            "latency_ms": result.latency_ms,
            "cost_saved": result.cost_saved,
            "decision_reason": result.decision_reason,
        }

    def stats(self) -> dict[str, Any]:
        self._ensure_initialized()
        stats = self._db.stats()
        return {
            "total_entries": int(stats.get("total_entries", 0)),
            "hit_rate": float(stats.get("hit_rate", 0.0)),
            "cost_saved_total": 0.0,
            "avg_latency_ms": 0.0,
            "top_queries": [],
        }

    def purge(self, older_than: str | None = None, model: str | None = None) -> int:
        self._ensure_initialized()
        older_than_date = self._duration_to_date(older_than) if older_than else None
        return self._db.purge(older_than=older_than_date, model=model)

    def invalidate(self, cache_key: str) -> None:
        self._ensure_initialized()
        self._db.delete(cache_key)

    def close(self) -> None:
        self._db.close()

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return

        self._db.connect()
        self._db.migrate()
        self._initialized = True

    def _duration_to_date(self, duration: str) -> datetime:
        match = re.match(r"^(\d+)([smhdw])$", duration.lower())
        if not match:
            return datetime.fromtimestamp(0, tz=timezone.utc)

        value = int(match.group(1))
        unit = match.group(2)
        if unit == "s":
            delta = timedelta(seconds=value)
        elif unit == "m":
            delta = timedelta(minutes=value)
        elif unit == "h":
            delta = timedelta(hours=value)
        elif unit == "d":
            delta = timedelta(days=value)
        else:
            delta = timedelta(weeks=value)

        return datetime.now(tz=timezone.utc) - delta

    def _parse_messages(self, payload: Any) -> list[Message]:
        if not isinstance(payload, list):
            return []

        out: list[Message] = []
        for item in payload:
            if isinstance(item, Message):
                out.append(item)
                continue
            if isinstance(item, Mapping):
                out.append(
                    Message(
                        role=str(item.get("role", "user")),
                        content=str(item.get("content", "")),
                    )
                )
        return out

    def _parse_documents(self, payload: Any) -> list[DocumentLike]:
        if not isinstance(payload, list):
            return []

        out: list[DocumentLike] = []
        for item in payload:
            if isinstance(item, DocumentLike):
                out.append(item)
                continue
            if isinstance(item, Mapping):
                doc_id = str(item.get("id", "")).strip()
                if not doc_id:
                    continue
                content = item.get("content")
                metadata = item.get("metadata")
                out.append(
                    DocumentLike(
                        id=doc_id,
                        content=str(content) if content is not None else None,
                        metadata=metadata if isinstance(metadata, dict) else None,
                    )
                )
        return out

    def _to_optional_float(self, value: Any) -> float | None:
        if value is None:
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _to_optional_int(self, value: Any) -> int | None:
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
