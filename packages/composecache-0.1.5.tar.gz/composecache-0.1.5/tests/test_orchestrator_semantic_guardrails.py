from __future__ import annotations

import json
from datetime import datetime

from composecache.adapters.llm.base import LLMCompletionRequest, LLMCompletionResponse, LLMUsage
from composecache.core.hasher import Hasher
from composecache.core.normalizer import Normalizer
from composecache.core.orchestrator import Orchestrator
from composecache.types import (
    CacheEntry,
    CompletionRequest,
    ComposeCacheConfig,
    Message,
    NegativeCacheEntry,
)


class MockDB:
    def __init__(self) -> None:
        self.by_key: dict[str, CacheEntry] = {}
        self.semantic_entries: list[CacheEntry] = []

    def connect(self) -> None:
        pass

    def migrate(self) -> None:
        pass

    def get_by_key(self, key: str) -> CacheEntry | None:
        return self.by_key.get(key)

    def similarity_search(self, embedding: list[float], k: int) -> list[CacheEntry]:
        return self.semantic_entries[:k]

    def negative_similarity_search(self, embedding: list[float], k: int) -> list[NegativeCacheEntry]:
        return []

    def insert(self, entry: CacheEntry) -> None:
        self.by_key[entry.cache_key] = entry
        if entry.query_embedding:
            self.semantic_entries.append(entry)

    def insert_negative(
        self,
        cache_key: str,
        query_embedding: list[float],
        refusal_reason: str,
        expires_at: datetime | None = None,
    ) -> None:
        pass

    def delete(self, key: str) -> None:
        self.by_key.pop(key, None)

    def purge(self, older_than: datetime | None = None, model: str | None = None) -> int:
        return 0

    def stats(self) -> dict[str, float]:
        return {"total_entries": float(len(self.by_key)), "hit_rate": 1.0}

    def close(self) -> None:
        pass


class MockLLM:
    def __init__(self) -> None:
        self.prompts: list[str] = []

    def complete(self, request: LLMCompletionRequest) -> LLMCompletionResponse:
        system = request.messages[0].content if request.messages else ""
        if "classify questions" in system:
            return LLMCompletionResponse(content='{"type":"atomic","sub_queries":[]}')

        if "semantic cache reuse" in system:
            payload = json.loads(request.messages[-1].content)
            new_query = payload["new_query"].lower()
            cached_query = payload["cached_query"].lower()
            measurement = ("length", "width", "height", "area", "population", "gdp", "distance")
            person_role = ("president", "prime minister", "ceo", "founder", "leader")
            reusable = any(term in new_query for term in measurement) == any(
                term in cached_query for term in measurement
            ) and any(term in new_query for term in person_role) == any(
                term in cached_query for term in person_role
            )
            return LLMCompletionResponse(
                content=json.dumps(
                    {
                        "reusable": reusable,
                        "confidence": 0.96 if reusable else 0.99,
                        "reason": "same intent" if reusable else "different answer type",
                    }
                )
            )

        prompt = request.messages[-1].content
        self.prompts.append(prompt)
        if "length of nepal" in prompt.lower():
            return LLMCompletionResponse(
                content="Nepal is about 885 km long east to west.",
                usage=LLMUsage(prompt_tokens=10, completion_tokens=10, total_tokens=20),
            )
        return LLMCompletionResponse(
            content=f"LLM:{prompt}",
            usage=LLMUsage(prompt_tokens=10, completion_tokens=10, total_tokens=20),
        )


class MockEmbedder:
    def __init__(self, vectors: dict[str, list[float]]) -> None:
        self.vectors = vectors

    def embed(self, text: str) -> list[float]:
        return self.vectors.get(Normalizer.normalize(text), [0.1, 0.1, 0.1])


def _params_hash() -> str:
    return Hasher.hash_params({"model": "gpt-4o-mini", "temperature": 0, "top_p": 1, "max_tokens": 0})


def test_strict_guardrails_accept_paraphrase_and_reject_same_entity_intent_mismatch() -> None:
    db = MockDB()
    llm = MockLLM()
    embedder = MockEmbedder(
        {
            "who is the president of nepal?": [1, 0, 0],
            "who is nepal's president?": [0.99, 0.01, 0],
            "length of nepal": [0.995, 0.005, 0],
        }
    )
    config = ComposeCacheConfig(
        database_url="postgres://unused",
        openai_api_key="test",
    )

    params_hash = _params_hash()
    db.insert(
        CacheEntry(
            cache_key=Hasher.hash(Normalizer.normalize("Who is the president of Nepal?"), None, params_hash),
            query_text="Who is the president of Nepal?",
            query_normalized=Normalizer.normalize("Who is the president of Nepal?"),
            response="Ram Chandra Poudel is the president of Nepal.",
            model="gpt-4o-mini",
            params_hash=params_hash,
            query_embedding=[1, 0, 0],
            uncertainty=0.05,
            tokens_saved=30,
        )
    )

    orchestrator = Orchestrator(db, llm, embedder, config)
    paraphrase = orchestrator.complete(
        request=CompletionRequest(
            model="gpt-4o-mini",
            messages=[Message(role="user", content="Who is Nepal's president?")],
        )
    )

    assert paraphrase.cache_type.value == "semantic"
    assert paraphrase.content == "Ram Chandra Poudel is the president of Nepal."

    length_response = orchestrator.complete(
        request=CompletionRequest(
            model="gpt-4o-mini",
            messages=[Message(role="user", content="Length of Nepal")],
        )
    )

    assert length_response.cache_type.value == "miss"
    assert "885 km" in length_response.content
    assert "president" not in length_response.content.lower()
    assert length_response.sub_query_hits[0].decision_reason == "rejected_intent_mismatch"


def test_strict_guardrails_reject_short_ambiguous_queries() -> None:
    db = MockDB()
    llm = MockLLM()
    embedder = MockEmbedder({"ok": [1, 0, 0]})
    orchestrator = Orchestrator(
        db,
        llm,
        embedder,
        ComposeCacheConfig(database_url="postgres://unused", openai_api_key="test"),
    )

    response = orchestrator.complete(
        request=CompletionRequest(
            model="gpt-4o-mini",
            messages=[Message(role="user", content="ok")],
        )
    )

    assert response.cache_type.value == "miss"
    assert response.sub_query_hits[0].decision_reason == "rejected_short_ambiguous"
