# Hello, Python!

A minimal HTTP server listening on `localhost` port `3000`.

```
python3 main.py
```
