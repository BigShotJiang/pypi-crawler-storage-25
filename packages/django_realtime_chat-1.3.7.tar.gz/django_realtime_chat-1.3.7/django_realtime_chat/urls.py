from django.urls import path
from . import views

app_name = "django_realtime_chat"

urlpatterns = [
    # Page principale du chat
    path("", views.chat_home, name="chat_home"),

    # Démarrer ou récupérer une conversation avec un utilisateur
    path("start/<int:user_id>/", views.start_conversation, name="start_conversation"),

    # Historique des messages d'une conversation
    path("history/<int:conversation_id>/", views.message_history, name="message_history"),

    # Upload de fichier dans une conversation
    path("upload/", views.FileUploadView.as_view(), name="file_upload"),

    # Liste de tous les utilisateurs disponibles
    path("users/", views.user_list, name="user_list"),

    # Gestion des clés de chiffrement
    path("keys/", views.UserKeyView.as_view(), name="user_key"),
    path("keys/<int:user_id>/", views.PublicKeyView.as_view(), name="public_key"),
]
