from django.apps import AppConfig


class DjangoRealtimeChatConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_realtime_chat"
    verbose_name = "Realtime Chat"
