import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model

User = get_user_model()


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]

        if not self.user or not self.user.is_authenticated:
            await self.close()
            return

        # Groupe personnel de l'utilisateur (pour recevoir les messages entrants)
        self.user_group = f"user_{self.user.id}"
        await self.channel_layer.group_add(self.user_group, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, "user_group"):
            await self.channel_layer.group_discard(self.user_group, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        message_text = data.get("message", "").strip()
        receiver_id = data.get("receiver_id")
        image_url = data.get("image_url")
        file_url = data.get("file_url")
        file_name = data.get("file_name")
        reply_to_id = data.get("reply_to_id")

        if not receiver_id:
            return

        if not message_text and not image_url and not file_url:
            return

        # Sauvegarder le message en base de données
        msg = await self.save_message(receiver_id, message_text, reply_to_id)
        if not msg:
            return

        payload = {
            "type": "chat_message",
            "message": message_text,
            "sender_id": self.user.id,
            "sender_username": self.user.username,
            "conversation_id": msg["conversation_id"],
            "message_id": msg["id"],
            "created_at": msg["created_at"],
            "image_url": image_url,
            "file_url": file_url,
            "file_name": file_name,
            "reply_to_id": msg.get("reply_to_id"),
            "reply_to_content": msg.get("reply_to_content"),
            "reply_to_sender_username": msg.get("reply_to_sender_username"),
            "reply_to_sender_id": msg.get("reply_to_sender_id"),
        }

        # Envoyer au destinataire (son groupe personnel)
        await self.channel_layer.group_send(f"user_{receiver_id}", payload)

        # Envoyer en écho à l'expéditeur
        await self.channel_layer.group_send(self.user_group, payload)

    async def chat_message(self, event):
        """Handler appelé quand un message arrive dans le groupe."""
        await self.send(text_data=json.dumps({
            "message": event.get("message"),
            "sender_id": event["sender_id"],
            "sender_username": event["sender_username"],
            "conversation_id": event["conversation_id"],
            "message_id": event["message_id"],
            "created_at": event["created_at"],
            "image_url": event.get("image_url"),
            "file_url": event.get("file_url"),
            "file_name": event.get("file_name"),
            "reply_to_id": event.get("reply_to_id"),
            "reply_to_content": event.get("reply_to_content"),
            "reply_to_sender_username": event.get("reply_to_sender_username"),
            "reply_to_sender_id": event.get("reply_to_sender_id"),
        }))

    @database_sync_to_async
    def save_message(self, receiver_id, content, reply_to_id=None):
        from .models import Conversation, Message

        try:
            receiver = User.objects.get(id=receiver_id)
        except User.DoesNotExist:
            return None

        conv, _ = Conversation.objects.get_or_create_between(self.user, receiver)

        # Mettre à jour updated_at de la conversation
        conv.save()

        kwargs = dict(conversation=conv, sender=self.user, content=content)

        reply_msg = None
        if reply_to_id:
            try:
                reply_msg = Message.objects.select_related("sender").get(id=reply_to_id)
                kwargs["reply_to"] = reply_msg
            except Message.DoesNotExist:
                pass

        msg = Message.objects.create(**kwargs)

        result = {
            "id": msg.id,
            "conversation_id": conv.id,
            "created_at": msg.created_at.isoformat(),
        }
        if reply_msg:
            result["reply_to_id"] = reply_msg.id
            result["reply_to_content"] = reply_msg.content
            result["reply_to_sender_username"] = reply_msg.sender.username
            result["reply_to_sender_id"] = reply_msg.sender.id
        return result
