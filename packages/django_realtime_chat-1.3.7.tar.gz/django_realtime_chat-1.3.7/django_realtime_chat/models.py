from django.db import models
from django.contrib.auth import get_user_model
import json

User = get_user_model()


class ConversationManager(models.Manager):
    def get_or_create_between(self, user1, user2):
        """Récupère ou crée une conversation entre deux utilisateurs (ordre indifférent)."""
        conv = self.filter(
            models.Q(user1=user1, user2=user2) |
            models.Q(user1=user2, user2=user1)
        ).first()
        if conv:
            return conv, False
        return self.create(user1=user1, user2=user2), True


class Conversation(models.Model):
    user1 = models.ForeignKey(
        User, related_name="conversations1", on_delete=models.CASCADE
    )
    user2 = models.ForeignKey(
        User, related_name="conversations2", on_delete=models.CASCADE
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ConversationManager()

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return f"Conversation {self.user1.username} ↔ {self.user2.username}"

    def other_user_for(self, user):
        return self.user2 if self.user1 == user else self.user1


class UserKey(models.Model):
    """Stocke la clé publique ECDH d'un utilisateur."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='encryption_key')
    public_key = models.TextField()  # Clé publique en format JSON (exported key)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Clé publique de {self.user.username}"

    def get_public_key_data(self):
        """Retourne la clé publique sous forme de dict."""
        return json.loads(self.public_key)

    def set_public_key_data(self, key_data):
        """Stocke la clé publique depuis un dict."""
        self.public_key = json.dumps(key_data)


class Message(models.Model):
    conversation = models.ForeignKey(
        Conversation, related_name="messages", on_delete=models.CASCADE
    )
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(blank=True)
    file = models.FileField(upload_to="chat_files/", null=True, blank=True)
    file_type = models.CharField(max_length=100, blank=True)
    image = models.FileField(upload_to="chat_images/", null=True, blank=True)
    reply_to = models.ForeignKey(
        'self', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='replies'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.created_at:%H:%M}] {self.sender.username}: {self.content[:40]}"
