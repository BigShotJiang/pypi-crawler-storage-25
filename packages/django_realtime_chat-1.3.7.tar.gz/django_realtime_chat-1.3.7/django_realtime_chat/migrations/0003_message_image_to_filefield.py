from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("django_realtime_chat", "0002_userkey"),
    ]

    operations = [
        migrations.AlterField(
            model_name="message",
            name="image",
            field=models.FileField(blank=True, null=True, upload_to="chat_images/"),
        ),
    ]
