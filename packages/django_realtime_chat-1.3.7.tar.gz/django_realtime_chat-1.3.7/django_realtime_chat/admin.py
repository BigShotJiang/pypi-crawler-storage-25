from django.contrib import admin
from .models import Conversation, Message


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ("id", "user1", "user2", "created_at", "updated_at")
    list_filter = ("created_at",)
    search_fields = ("user1__username", "user2__username")


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("id", "conversation", "sender", "content_preview", "created_at")
    list_filter = ("created_at",)
    search_fields = ("sender__username", "content")

    def content_preview(self, obj):
        return obj.content[:60] + "..." if len(obj.content) > 60 else obj.content
    content_preview.short_description = "Contenu"



admin.site.register(Conversation, ConversationAdmin)
admin.site.register(Message, MessageAdmin)