# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Shared helper to resolve which model tracks the recorder should consume.

Hoisted out of ``runtimes/http/http_runtime.py`` so the production
:class:`reactor_runtime.runtimes._redis._redis_runtime.RedisRuntime`
(REA-1953) can reuse the same logic without duplicating the
single-track-auto-pick rules.

Kept out of ``runtime_api.py`` deliberately: the base ``Runtime`` does
not own the recording subsystem (per REA-1958's contract — only the
``self.recorder`` slot lives there), so this helper sits next to
``SessionRecorder`` instead.
"""

from __future__ import annotations

from typing import Optional, Tuple

from reactor_runtime.interface.tracks.descriptors import Audio
from reactor_runtime.interface.tracks.output import all_output_tracks
from reactor_runtime.recording.config import RecordingConfig


def resolve_track_names(
    recording_config: RecordingConfig,
) -> Tuple[Optional[str], Optional[str], Optional[int]]:
    """Pick the video and audio track names the recorder should consume.

    Returns ``(video_track_name, audio_track_name, audio_sample_rate)``.

    Auto-pick rules:

    * If ``recording_config.video_track`` / ``audio_track`` is set
      explicitly, honour it verbatim.
    * Otherwise, if the model exposes exactly one track of the kind,
      pick it automatically.
    * If the model exposes multiple tracks of the same kind and the
      operator hasn't disambiguated via config, return ``None`` for
      that kind — the caller logs and skips recording (best-effort,
      we never fail the wire path because recording can't be set up).

    The audio sample rate is read from the resolved ``Audio`` descriptor's
    ``sample_rate`` class attribute (defaulting to 48 kHz).

    Track topology comes from the global ``OUTPUT_REGISTRY`` (populated
    when ``Output`` subclasses are imported), not from the model class
    itself — ``Output._tracks`` lives on the :class:`Output` subclass,
    not the :class:`ReactorModel`.
    """
    tracks = all_output_tracks()

    video_names = [n for n, marker in tracks.items() if not issubclass(marker, Audio)]
    audio_names = [n for n, marker in tracks.items() if issubclass(marker, Audio)]

    video_track = recording_config.video_track
    if video_track is None:
        video_track = video_names[0] if len(video_names) == 1 else None

    audio_track = recording_config.audio_track
    if audio_track is None:
        audio_track = audio_names[0] if len(audio_names) == 1 else None

    audio_sample_rate: Optional[int] = None
    if audio_track is not None:
        audio_marker = tracks.get(audio_track)
        if audio_marker is not None:
            audio_sample_rate = int(getattr(audio_marker, "sample_rate", 48_000))

    return video_track, audio_track, audio_sample_rate
