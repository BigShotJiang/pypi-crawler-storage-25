# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Reactor session recording subsystem.

Continuous fMP4 chunk encoder + pluggable upload sink that hooks into
:class:`OutputBuffer` via ``add_callback`` and ships chunks to a sink
(``LocalDirSink`` for local dev, ``S3PresignedSink`` for production —
the latter is added in a follow-up PR alongside the Supervisor RPC).

See the Video Recording Feature plan in Notion for the end-to-end
contract; this package implements the *Runtime (recording subsystem)*
component described there.
"""

from reactor_runtime.recording.config import (
    AudioEncoderConfig,
    RecordingConfig,
    VideoEncoderConfig,
)
from reactor_runtime.recording.session_recorder import (
    ClipResult,
    RecorderDisabledError,
    SessionRecorder,
)
from reactor_runtime.recording.sinks import LocalDirSink, RecordingSink

__all__ = [
    "AudioEncoderConfig",
    "ClipResult",
    "LocalDirSink",
    "RecorderDisabledError",
    "RecordingConfig",
    "RecordingSink",
    "SessionRecorder",
    "VideoEncoderConfig",
]
