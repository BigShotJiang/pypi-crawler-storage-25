# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""``RecordingConfig`` — the typed ``recording:`` block of ``reactor.yaml``.

All fields have sensible defaults so a model with no ``recording:`` block
records nothing (``enabled=False``); flipping ``enabled: true`` is
sufficient for the common case.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class VideoEncoderConfig:
    """Video encoder knobs surfaced into ffmpeg argv.

    Defaults match the *fast* preset documented in the plan; tune
    ``crf`` lower for higher quality at the cost of bitrate.

    ``target_width`` / ``target_height`` lock the encoder to a fixed
    resolution regardless of what the model emits.  Frames smaller
    than the target are upscaled; larger ones are downscaled.  This is
    the right knob for WebRTC sources, where the browser's bandwidth
    estimator ramps the outgoing video resolution up over the first
    few seconds — without a target the recorder would lock to the
    initial (low) resolution and downscale every subsequent frame.
    """

    codec: str = "h264"
    preset: str = "veryfast"
    crf: int = 23
    max_width: Optional[int] = None
    target_width: Optional[int] = None
    target_height: Optional[int] = None

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "VideoEncoderConfig":
        return cls(
            codec=str(raw.get("codec", cls.codec)),
            preset=str(raw.get("preset", cls.preset)),
            crf=int(raw.get("crf", cls.crf)),
            max_width=(
                int(raw["max_width"]) if raw.get("max_width") is not None else None
            ),
            target_width=(
                int(raw["target_width"])
                if raw.get("target_width") is not None
                else None
            ),
            target_height=(
                int(raw["target_height"])
                if raw.get("target_height") is not None
                else None
            ),
        )


@dataclass
class AudioEncoderConfig:
    """Audio encoder knobs surfaced into ffmpeg argv."""

    codec: str = "aac"
    bitrate_kbps: int = 128

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "AudioEncoderConfig":
        return cls(
            codec=str(raw.get("codec", cls.codec)),
            bitrate_kbps=int(raw.get("bitrate_kbps", cls.bitrate_kbps)),
        )


@dataclass
class RecordingConfig:
    """Top-level ``recording:`` block parsed from ``reactor.yaml``.

    ``video_track`` / ``audio_track`` are only required when the model
    declares more than one Video or Audio track respectively; with a
    single-track model the recorder picks the lone track automatically.
    """

    enabled: bool = False
    # Default tuned for "live" feel: 4 s chunks give a tail-clip lag of
    # roughly ``chunk_seconds + 1 s`` cold-start, so "last N seconds"
    # ends about 5 s in the past.  Trade-off vs. larger chunks is a
    # ~5–10 % bitrate increase (more forced IDRs) — acceptable for the
    # freshness gain.  Models that prioritise archive size over
    # freshness can override via ``recording.chunk_seconds`` in
    # ``reactor.yaml``.
    chunk_seconds: int = 4
    clip_max_seconds: int = 300
    # Trim the session-start pre-roll from clip playlists by clamping
    # ``start_marker`` forward to the first real (non-duplicate) frame
    # the recorder observes.  Set to ``False`` to keep that pre-roll
    # in clips.
    skip_leading_black: bool = True
    video_track: Optional[str] = None
    audio_track: Optional[str] = None
    video: VideoEncoderConfig = field(default_factory=VideoEncoderConfig)
    audio: AudioEncoderConfig = field(default_factory=AudioEncoderConfig)

    @classmethod
    def from_dict(cls, raw: Optional[Dict[str, Any]]) -> "RecordingConfig":
        """Parse a raw ``recording:`` mapping; missing block → defaults."""
        if not raw:
            return cls()
        return cls(
            enabled=bool(raw.get("enabled", cls.enabled)),
            chunk_seconds=int(raw.get("chunk_seconds", cls.chunk_seconds)),
            clip_max_seconds=int(raw.get("clip_max_seconds", cls.clip_max_seconds)),
            skip_leading_black=bool(
                raw.get("skip_leading_black", cls.skip_leading_black)
            ),
            video_track=raw.get("video_track"),
            audio_track=raw.get("audio_track"),
            video=VideoEncoderConfig.from_dict(raw.get("video") or {}),
            audio=AudioEncoderConfig.from_dict(raw.get("audio") or {}),
        )
