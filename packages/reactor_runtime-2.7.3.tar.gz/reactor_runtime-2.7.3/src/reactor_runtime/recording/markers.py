# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Wall-clock marker bookkeeping for the recording subsystem.

The recorder cannot pin a fixed FPS because production pipelines use
dynamic FPS (the OutputBuffer recomputes its emission rate each
iteration).  Markers and chunk-boundary math therefore live entirely
in wall-clock seconds since session start, set by ffmpeg's
``-use_wallclock_as_timestamps 1`` on each input pipe.
"""

from __future__ import annotations

import threading
import time
from typing import Optional, Tuple


class MarkerBookkeeper:
    """Tracks ``now_marker`` and the latest fully-uploaded chunk index.

    Thread-safe — ``mark_chunk_uploaded`` is called from the uploader
    thread while ``compute_*_range`` is called from the runtime's
    asyncio loop on the inbound runtime-message dispatch path.
    """

    def __init__(self) -> None:
        self._session_start = time.monotonic()
        self._last_uploaded_chunk_idx: int = -1
        # Sticky marker latched by :meth:`mark_first_real_frame`;
        # ``None`` until the recorder sees its first non-duplicate
        # bundle.
        self._first_real_frame_marker: Optional[float] = None
        self._lock = threading.Lock()

    def now_marker(self) -> float:
        """Wall-clock seconds since the recorder started."""
        return time.monotonic() - self._session_start

    @property
    def last_uploaded_chunk_idx(self) -> int:
        """Index of the most recent chunk known to be in the sink, or -1."""
        with self._lock:
            return self._last_uploaded_chunk_idx

    @property
    def first_real_frame_marker(self) -> Optional[float]:
        """Wall-clock of the first real (non-duplicate) bundle, or
        ``None`` if no real frame has landed yet."""
        with self._lock:
            return self._first_real_frame_marker

    def mark_chunk_uploaded(self, idx: int) -> None:
        """Advance ``last_uploaded_chunk_idx`` monotonically.

        Out-of-order calls (uploader retries land late) are accepted
        but do not regress the marker.
        """
        with self._lock:
            if idx > self._last_uploaded_chunk_idx:
                self._last_uploaded_chunk_idx = idx

    def mark_first_real_frame(self) -> None:
        """Latch the wall-clock at which the first real frame was seen.

        Idempotent and one-shot — only the first call has an effect,
        so the marker pins the session-start pre-roll and is never
        moved by later idle periods.
        """
        with self._lock:
            if self._first_real_frame_marker is None:
                self._first_real_frame_marker = time.monotonic() - self._session_start

    def compute_clip_range(
        self, duration_seconds: float, *, skip_leading_black: bool = False
    ) -> Tuple[float, float]:
        """Resolve ``requestClip`` to a ``(start_marker, end_marker)`` pair.

        ``end_marker`` is the wall-clock at request time (``now_marker``),
        intentionally unclamped against ``last_uploaded_chunk_idx`` —
        the response is a *promise* that includes the chunk currently
        being written by ffmpeg.  The ``/clips`` manifest endpoint
        returns ``202 Retry-After`` until that chunk lands, and the SDK
        polls until ``200``.  This keeps the runtime's response
        latency at one round-trip regardless of where in the chunk
        cycle the client asks.

        When ``skip_leading_black`` is true and the first-real-frame
        marker has been latched, ``start`` is clamped forward to that
        marker.  Without the latch the clamp is skipped so callers
        always receive a non-empty range.
        """
        end_marker = self.now_marker()
        start_marker = max(0.0, end_marker - duration_seconds)
        if skip_leading_black:
            with self._lock:
                first_real = self._first_real_frame_marker
            if first_real is not None:
                start_marker = max(start_marker, first_real)
        return start_marker, end_marker

    def compute_recording_range(
        self, *, skip_leading_black: bool = False
    ) -> Tuple[float, float]:
        """``requestRecording`` is just a clip from session start to
        now.  Honours ``skip_leading_black`` with the same fallback
        as :meth:`compute_clip_range`.
        """
        end_marker = self.now_marker()
        start_marker = 0.0
        if skip_leading_black:
            with self._lock:
                first_real = self._first_real_frame_marker
            if first_real is not None:
                start_marker = first_real
        return start_marker, end_marker
