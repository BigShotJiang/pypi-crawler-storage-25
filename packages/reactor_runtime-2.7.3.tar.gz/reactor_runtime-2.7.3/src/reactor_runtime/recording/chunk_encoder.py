# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Continuous fMP4 chunk encoder backed by a single ``ffmpeg`` subprocess.

The encoder is *lazy*: ffmpeg spawns on the first :meth:`feed_video`
call so the frame's ``shape`` derives the ``-s WxH`` argument.  Output
is HLS-fMP4 (``init.mp4`` + ``chunk_NNNNN.m4s``); see ``_build_argv``
for the full flag rationale.  The audio pipe, second ``-i``, and
``-map 1:a`` are omitted when ``has_audio=False``.
"""

from __future__ import annotations

import os
import signal
import subprocess
import threading
from pathlib import Path
from typing import List, Optional

import numpy as np

from reactor_runtime.recording.config import RecordingConfig
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


def _resize_nearest(frame: np.ndarray, target_w: int, target_h: int) -> np.ndarray:
    """Nearest-neighbour resize using only numpy; no-op when already sized."""
    h, w = frame.shape[:2]
    if h == target_h and w == target_w:
        return frame
    y_idx = (np.arange(target_h) * (h / target_h)).astype(np.int64)
    x_idx = (np.arange(target_w) * (w / target_w)).astype(np.int64)
    return frame[y_idx[:, None], x_idx[None, :]]


def _build_argv(
    output_dir: Path,
    width: int,
    height: int,
    has_audio: bool,
    audio_sample_rate: Optional[int],
    config: RecordingConfig,
    video_read_fd: int,
    audio_read_fd: Optional[int],
) -> List[str]:
    """Construct the ffmpeg argv.

    Video input uses ``-use_wallclock_as_timestamps 1``: ffmpeg stamps
    each frame at the moment it reads it off the pipe, so the recorded
    PTS reflects the model's actual emission cadence (which is dynamic
    on most Reactor models — OutputBuffer recomputes its rate every
    iteration from ``compute_time``).  The recorder's feed worker
    therefore does NOT pace itself; it writes frames straight through
    and ffmpeg owns the timeline.

    Audio still derives DTS from byte count + sample rate (no wallclock
    flag) — wallclock-stamping a sample-rate-paced batch produces
    non-monotonic per-sample DTS in AAC and stalls the encoder.  Audio
    is fed at exactly ``sample_rate * dt`` samples per video frame
    (see ``SessionRecorder._next_audio_chunk``) so its byte-derived
    DTS still tracks wall-clock 1:1 with video's PTS.
    """
    # ``-probesize 32 -analyzeduration 0`` on every input: rawvideo /
    # s16le are fully described by ``-f`` + format flags, so ffmpeg's
    # default 5 MB / 5 s ``avformat_find_stream_info`` probe is pure
    # cost.  Worse, it deadlocks the recorder: the parent fills the
    # 64 KB video pipe long before the audio side has 5 MB, then blocks
    # on ``os.write`` while ffmpeg's main thread is still parked on the
    # empty audio pipe inside find_stream_info.
    argv: List[str] = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "warning",
        # video input
        "-probesize",
        "32",
        "-analyzeduration",
        "0",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{width}x{height}",
        "-use_wallclock_as_timestamps",
        "1",
        # ffmpeg 8's scheduler parks the demuxer when its packet queue
        # fills (default 8); at 720p+ with audio writes outpacing
        # video, that wedges our worker's os.write indefinitely.
        # 1024 is well past the imbalance.
        "-thread_queue_size",
        "1024",
        "-i",
        f"pipe:{video_read_fd}",
    ]
    if has_audio:
        assert audio_read_fd is not None
        # NOTE: no -use_wallclock_as_timestamps on audio.  Wallclock-
        # stamping a sample-rate-paced batch produces non-monotonic
        # per-sample DTS in AAC ("Queue input is backward in time")
        # and stalls ffmpeg.  Byte-count-derived DTS is always monotonic.
        argv += [
            "-probesize",
            "32",
            "-analyzeduration",
            "0",
            "-f",
            "s16le",
            "-ar",
            str(audio_sample_rate or 48_000),
            "-ac",
            "1",
            "-thread_queue_size",
            "1024",
            "-i",
            f"pipe:{audio_read_fd}",
            "-map",
            "0:v",
            "-map",
            "1:a",
        ]
    # video encoder
    vcodec = "libx264" if config.video.codec == "h264" else "libx265"
    argv += [
        "-c:v",
        vcodec,
        "-preset",
        config.video.preset,
        "-crf",
        str(config.video.crf),
        "-tune",
        "zerolatency",
        # x264 sliced-threads (auto-enabled by ``-tune zerolatency``)
        # deadlocks at 720p+ on ffmpeg 8.  Force frame-threads instead;
        # the recorder doesn't care about per-frame latency.
        "-x264-params",
        "sliced-threads=0",
        "-force_key_frames",
        f"expr:gte(t,n_forced*{config.chunk_seconds})",
    ]
    if has_audio:
        argv += [
            "-c:a",
            config.audio.codec,
            "-b:a",
            f"{config.audio.bitrate_kbps}k",
        ]
    # HLS+fMP4 muxer (was ``-f dash``: dash's segment-rename trips
    # ENOENT on macOS, killing the encoder ~10s in).  Same byte-level
    # output, more robust segment-close, 0-indexed by default — which
    # matches our marker math.  The generated ``.m3u8`` is ignored;
    # the ``/clips`` endpoint composes its own manifest.
    argv += [
        "-f",
        "hls",
        "-hls_segment_type",
        "fmp4",
        "-hls_time",
        str(config.chunk_seconds),
        "-hls_list_size",
        "0",
        "-hls_flags",
        "independent_segments",
        "-hls_fmp4_init_filename",
        "init.mp4",
        "-hls_segment_filename",
        str(output_dir / "chunk_%05d.m4s"),
        str(output_dir / "manifest.m3u8"),
    ]
    return argv


class ChunkEncoder:
    """Drives a long-lived ``ffmpeg`` subprocess for a session.

    Lifecycle:

    1. ``__init__`` records the work dir; no subprocess yet.
    2. First :meth:`feed_video` call spawns ffmpeg using the frame's
       shape to derive ``WxH``.
    3. Subsequent ``feed_video`` / ``feed_audio`` calls write raw
       bytes into the corresponding pipe.
    4. :meth:`stop` closes the write fds, sends SIGTERM, joins, then
       SIGKILLs if ffmpeg refuses to exit.
    """

    def __init__(
        self,
        output_dir: Path,
        config: RecordingConfig,
        has_audio: bool,
        audio_sample_rate: Optional[int],
    ) -> None:
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._config = config
        self._has_audio = has_audio
        self._audio_sample_rate = audio_sample_rate

        self._proc: Optional[subprocess.Popen] = None
        self._video_w: Optional[int] = None
        self._audio_w: Optional[int] = None
        self._width: Optional[int] = None
        self._height: Optional[int] = None
        self._lock = threading.Lock()
        self._failed = False
        # Sticky one-way latch flipped by ``stop()`` so the feed worker
        # can't lazy-respawn a phantom ffmpeg after teardown began.
        # See the lock-guarded re-check in :meth:`feed_video`.
        self._stopped = False

    @property
    def output_dir(self) -> Path:
        return self._output_dir

    @property
    def failed(self) -> bool:
        """True once the encoder is dead and unrecoverable for this session."""
        return self._failed or (
            self._proc is not None and self._proc.poll() is not None
        )

    def feed_video(self, frame: np.ndarray) -> None:
        """Push a single ``(H, W, 3) uint8`` frame into the encoder.

        Frames at a different size than the encoder is locked to are
        nearest-neighbour resized so a varying resolution from the
        model never breaks the rawvideo pipe.  Raises ``RuntimeError``
        if the encoder is dead — caller disables recording for the
        session.
        """
        if frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError(f"feed_video expects (H, W, 3); got shape {frame.shape}")
        if self._proc is None:
            with self._lock:
                # Re-check under the lock; a concurrent ``stop()`` may
                # have latched ``_stopped`` between the outer check
                # above and here.
                if self._stopped:
                    raise RuntimeError("ChunkEncoder is stopped")
                if self._proc is None:
                    # Prefer explicit target dims so a WebRTC source
                    # whose initial resolution is below the negotiated
                    # max (BWE ramp-up) still records at the target.
                    tw = self._config.video.target_width
                    th = self._config.video.target_height
                    if tw and th:
                        self._spawn(width=int(tw), height=int(th))
                    else:
                        h, w, _ = frame.shape
                        self._spawn(width=int(w), height=int(h))
        if self._failed:
            raise RuntimeError("ChunkEncoder is in a failed state")
        if (
            self._width is not None
            and self._height is not None
            and (frame.shape[1] != self._width or frame.shape[0] != self._height)
        ):
            frame = _resize_nearest(frame, self._width, self._height)
        assert self._video_w is not None
        try:
            os.write(self._video_w, np.ascontiguousarray(frame).tobytes())
        except BrokenPipeError as exc:
            self._failed = True
            raise RuntimeError("ffmpeg video pipe broke") from exc

    def feed_audio(self, samples: np.ndarray) -> None:
        """Push int16 PCM samples into the audio pipe.

        No-op when ``has_audio=False``; the audio fd was never opened.
        """
        if not self._has_audio or self._audio_w is None:
            return
        if self._failed:
            raise RuntimeError("ChunkEncoder is in a failed state")
        if samples.dtype != np.int16:
            samples = samples.astype(np.int16)
        try:
            os.write(self._audio_w, np.ascontiguousarray(samples).tobytes())
        except BrokenPipeError as exc:
            self._failed = True
            raise RuntimeError("ffmpeg audio pipe broke") from exc

    def _spawn(self, width: int, height: int) -> None:
        video_r, video_w = os.pipe()
        audio_r: Optional[int]
        audio_w: Optional[int]
        if self._has_audio:
            audio_r, audio_w = os.pipe()
        else:
            audio_r, audio_w = None, None

        argv = _build_argv(
            output_dir=self._output_dir,
            width=width,
            height=height,
            has_audio=self._has_audio,
            audio_sample_rate=self._audio_sample_rate,
            config=self._config,
            video_read_fd=video_r,
            audio_read_fd=audio_r,
        )
        pass_fds: tuple[int, ...]
        if self._has_audio:
            assert audio_r is not None  # narrowed: has_audio → both fds opened
            pass_fds = (video_r, audio_r)
        else:
            pass_fds = (video_r,)
        try:
            self._proc = subprocess.Popen(  # noqa: S603 — argv list, no shell
                argv,
                pass_fds=pass_fds,
                stdin=subprocess.DEVNULL,
            )
        except FileNotFoundError as exc:
            for fd in (video_r, video_w, audio_r, audio_w):
                if fd is not None:
                    try:
                        os.close(fd)
                    except OSError:
                        pass
            self._failed = True
            raise RuntimeError(
                "ffmpeg binary not found on PATH; install ffmpeg to enable recording"
            ) from exc
        # Parent doesn't read; only the child needs the read ends.
        os.close(video_r)
        if audio_r is not None:
            os.close(audio_r)

        self._video_w = video_w
        self._audio_w = audio_w
        self._width = width
        self._height = height
        logger.info(
            "ChunkEncoder spawned ffmpeg",
            pid=self._proc.pid,
            width=width,
            height=height,
            audio=self._has_audio,
        )

    def stop(self, timeout: float = 5.0) -> None:
        """Close the input fds and shut down ffmpeg cleanly.

        Best-effort: if the process refuses to exit within ``timeout``
        we escalate to SIGKILL.  Always safe to call (no-op if the
        encoder never spawned).
        """
        with self._lock:
            # Latch first so a concurrent ``feed_video`` taking the
            # lock bails out instead of spawning over the fds we are
            # about to close.
            self._stopped = True
            for fd in (self._video_w, self._audio_w):
                if fd is not None:
                    try:
                        os.close(fd)
                    except OSError:
                        pass
            self._video_w = None
            self._audio_w = None
            proc = self._proc
            self._proc = None
        if proc is None:
            return
        if proc.poll() is None:
            try:
                proc.send_signal(signal.SIGTERM)
            except ProcessLookupError:
                return
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2.0)
