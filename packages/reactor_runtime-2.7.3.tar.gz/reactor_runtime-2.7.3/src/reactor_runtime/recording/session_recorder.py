# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Public entrypoint that ties encoder, uploader, markers, and sink together.

A :class:`SessionRecorder` is built per session by the runtime layer
(``HttpRuntime`` for now, ``RedisRuntime`` later).  The runtime
registers ``recorder._on_bundle_sync`` as an OutputBuffer callback so
the recorder sees every frame the buffer emits — including gap-fill
duplicates, which are recorded so the resulting file's wall-clock
duration matches the live wire.

``request_clip`` / ``request_recording`` are answered synchronously
from the recorder's local state (no Supervisor RPC at clip-request
time).
"""

from __future__ import annotations

import math
import queue
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import urlencode

import numpy as np

from reactor_runtime.recording.chunk_encoder import ChunkEncoder
from reactor_runtime.recording.chunk_uploader import ChunkUploader
from reactor_runtime.recording.config import RecordingConfig
from reactor_runtime.recording.markers import MarkerBookkeeper
from reactor_runtime.recording.sinks import RecordingSink
from reactor_runtime.transports.media import MediaBundle, TrackKind
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class RecorderDisabledError(RuntimeError):
    """Raised by ``request_*`` when the recorder cannot serve the request.

    Reasons include: encoder crashed, recorder was never started, or
    recording is disabled by config.  Callers translate this into a
    ``clipFailed`` runtime message envelope.
    """


@dataclass(frozen=True)
class ClipResult:
    """Resolved outcome of a ``requestClip`` / ``requestRecording`` call.

    The runtime returns immediately on every request — it does *not*
    block until the in-progress chunk has been finalised.  Instead the
    response is a promise: ``end_marker`` reflects wall-clock at
    request time and may point inside a chunk ffmpeg is still
    writing.  The ``/clips`` manifest endpoint returns
    ``202 Retry-After`` while that chunk is in flight; the SDK polls
    until ``200``.

    ``start_marker`` / ``end_marker`` / ``now_marker`` are session-
    relative seconds (since recorder start).  ``predicted_ready_at_ms``
    is a **Unix epoch in milliseconds** — the runtime's estimate of
    when the clip will be servable by ``/clips``.  An epoch lets the
    client decide independently whether to keep polling (epoch is
    still in the near future), give up and surface a failure (epoch
    has passed by more than a configured slack — the runtime likely
    crashed mid-clip), or schedule a UX "ready at HH:MM:SS"
    indicator.  Matches JS ``Date.now()`` exactly.

    ``playlist_url`` is a **path-only** URL (e.g.
    ``/clips?session_id=…&start=…&end=…``).  The SDK is the only
    component that knows the absolute origin to prepend — the local
    HttpRuntime serves the path itself, the production Coordinator
    serves the same path on its public host.  Keeping the runtime
    out of the absolute-URL game means the Redis runtime never has
    to learn the production Coordinator URL, and the SDK never has
    to special-case local vs prod.
    """

    session_id: str
    kind: str
    start_marker: float
    end_marker: float
    now_marker: float
    predicted_ready_at_ms: int
    playlist_url: str
    # Wall-clock of the first real (non-duplicate) frame the recorder
    # observed, or ``None`` if none has landed yet.  Surfaced for
    # observability; ``start_marker`` already uses it when
    # ``RecordingConfig.skip_leading_black`` is on.
    first_real_frame_marker: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "kind": self.kind,
            "start_marker": self.start_marker,
            "end_marker": self.end_marker,
            "now_marker": self.now_marker,
            "predicted_ready_at_ms": self.predicted_ready_at_ms,
            "playlist_url": self.playlist_url,
            "first_real_frame_marker": self.first_real_frame_marker,
        }


class SessionRecorder:
    """Per-session recorder built by the runtime at session start.

    The recorder is *best-effort*: an encoder crash flips
    ``self._disabled`` and any subsequent ``request_*`` raises
    :class:`RecorderDisabledError`.  Chunks that already made it into
    the sink remain accessible.
    """

    def __init__(
        self,
        config: RecordingConfig,
        session_id: str,
        sink: RecordingSink,
        video_track_name: str,
        audio_track_name: Optional[str],
        audio_sample_rate: Optional[int],
        work_dir: Path,
        keepalive_interval: float = 1.0,
    ) -> None:
        self._config = config
        self._session_id = session_id
        self._sink = sink
        self._video_track = video_track_name
        self._audio_track = audio_track_name
        self._audio_sample_rate = audio_sample_rate or 48_000
        self._work_dir = Path(work_dir)
        self._work_dir.mkdir(parents=True, exist_ok=True)

        self._markers = MarkerBookkeeper()
        self._encoder = ChunkEncoder(
            output_dir=self._work_dir,
            config=config,
            has_audio=audio_track_name is not None,
            audio_sample_rate=audio_sample_rate,
        )
        self._uploader = ChunkUploader(
            encoder_dir=self._work_dir,
            sink=sink,
            markers=self._markers,
            chunk_seconds=float(config.chunk_seconds),
            encoder_alive=lambda: not self._encoder.failed,
        )
        self._started = False
        self._disabled = False

        # Bounded feed queue decouples the OutputBuffer emission thread
        # from ffmpeg's blocking ``os.write``: when the encoder
        # backpressures we drop from the *recording*, never the wire.
        # Small on purpose — we want recent loss, not stale buffering.
        self._feed_queue: "queue.Queue[Optional[Tuple[np.ndarray, Optional[np.ndarray]]]]" = queue.Queue(
            maxsize=4
        )
        self._feed_thread: Optional[threading.Thread] = None
        self._feed_stop = threading.Event()
        self._dropped_frames: int = 0

        # Keepalive throttle for gap-fill duplicates.  Real frames are
        # always passed through; duplicates (the OutputBuffer's own
        # gap-fills when the model yields ``Idle`` or its inference
        # generator stalls) are passed through at most once every
        # ``keepalive_interval`` seconds — enough to keep ffmpeg's
        # wallclock-stamped PTS advancing across HLS chunk boundaries
        # so the marker math holds during long model pauses, without
        # paying full-rate I/O for visually-identical frames.
        self._keepalive_interval = max(0.0, float(keepalive_interval))
        self._last_fed_t: float = 0.0
        # Wall-clock of the previous video frame fed to the encoder.
        # Used to compute the audio-fill sample count per video tick
        # (``audio_sample_rate * dt``), which keeps audio DTS tracking
        # video PTS 1:1 regardless of the model's instantaneous FPS.
        self._last_video_wall_t: float = 0.0

        # Audio jitter buffer: model audio batches are variably sized;
        # we accumulate them and emit ``round(sample_rate * dt)``
        # samples per video tick (silence-pad on underrun, queue the
        # surplus on overrun).  Capped at ~1 s so the recording can't
        # accumulate unbounded audio latency.
        self._audio_jitter_buf: List[np.ndarray] = []
        self._audio_buffered_samples: int = 0
        self._audio_buffer_cap_samples: int = self._audio_sample_rate

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def disabled(self) -> bool:
        return self._disabled or self._encoder.failed

    @property
    def chunk_seconds(self) -> int:
        return self._config.chunk_seconds

    def start(self) -> None:
        """Start the uploader + feed-worker threads; encoder spawns lazily."""
        if self._started:
            return
        self._uploader.start()
        self._feed_stop.clear()
        self._feed_thread = threading.Thread(
            target=self._feed_loop, name="recording-feed", daemon=True
        )
        self._feed_thread.start()
        self._started = True
        logger.info(
            "SessionRecorder started",
            session_id=self._session_id,
            work_dir=str(self._work_dir),
        )

    def stop(self) -> None:
        """Tear down feed worker, encoder, and uploader.

        Emits a structured ``SessionRecorder stopped`` log with
        ``clean=…`` and per-thread leak flags so failed joins surface
        in monitoring instead of leaking ffmpeg + uploader threads
        silently.
        """
        if not self._started:
            return
        # Disable callbacks first so a racing _on_bundle_sync becomes
        # a no-op even before its OutputBuffer subscription is removed.
        self._disabled = True
        # Signal the feed loop to drain and exit; sentinel unblocks .get().
        self._feed_stop.set()
        try:
            self._feed_queue.put_nowait(None)
        except queue.Full:
            # Queue full → worker will see _feed_stop on its next iteration.
            pass
        feed_thread = self._feed_thread
        self._feed_thread = None
        # Stop the encoder before joining the feed worker: the worker's
        # blocking call is ``os.write()`` into the ffmpeg pipe and only
        # unblocks when the pipe is closed.
        self._encoder.stop()
        if feed_thread is not None:
            feed_thread.join(timeout=2.0)
        feed_leaked = feed_thread is not None and feed_thread.is_alive()
        uploader_clean = self._uploader.stop(flush_remaining=True)
        self._started = False
        # Cleanup the encoder's transient working dir.  Chunks that
        # made it to the sink are already copied to the served dir;
        # whatever's left here is leftover ffmpeg scratch (manifest.mpd,
        # un-promoted .tmp segments, etc.) that we don't need.  Done
        # AFTER ffmpeg exits so the muxer can't trip on the rmtree.
        try:
            shutil.rmtree(self._work_dir, ignore_errors=True)
        except Exception:
            logger.exception(
                "Failed to clean encoder work dir; leaking",
                work_dir=str(self._work_dir),
            )
        clean = not feed_leaked and uploader_clean
        log = logger.info if clean else logger.error
        log(
            "SessionRecorder stopped",
            session_id=self._session_id,
            last_uploaded_chunk_idx=self._markers.last_uploaded_chunk_idx,
            dropped=self._dropped_frames,
            clean=clean,
            feed_leaked=feed_leaked,
            uploader_leaked=not uploader_clean,
        )

    # ------------------------------------------------------------------
    # OutputBuffer integration
    # ------------------------------------------------------------------

    def _on_bundle_sync(self, bundle: MediaBundle, duplicate: bool) -> None:
        """Per-tick callback registered on the model's :class:`OutputBuffer`.

        Non-blocking: pushes onto the feed queue and returns.  The
        ``recording-feed`` worker thread does the blocking ``os.write``
        to ffmpeg.

        **Real frames** (``duplicate=False``) are always passed through.

        **Duplicates** (``duplicate=True``) are the OutputBuffer's
        gap-fill emissions when the model yields :data:`Idle` or
        otherwise fails to emit on a tick.  We rate-limit them to one
        per ``_keepalive_interval`` seconds: enough to keep ffmpeg's
        wallclock-stamped PTS advancing across HLS chunk boundaries
        (so ``last_uploaded_chunk_idx`` keeps progressing during a
        long model pause and the marker math holds), but cheap enough
        not to burn full-rate pipe I/O on visually-identical frames.
        """
        if self._disabled or not self._started:
            return
        now = time.monotonic()
        if not duplicate:
            # Idempotent latch; only the first call takes effect.
            self._markers.mark_first_real_frame()
        if duplicate:
            if (
                self._keepalive_interval <= 0.0
                or (now - self._last_fed_t) < self._keepalive_interval
            ):
                return
        # Resolve tracks on the emission thread (cheap dict lookups);
        # only the heavy os.write happens on the feed worker.
        video_td = bundle.tracks.get(self._video_track)
        if video_td is None:
            videos = bundle.get_tracks_by_kind(TrackKind.VIDEO)
            if not videos:
                return
            video_td = videos[0]
        audio_data: Optional[np.ndarray] = None
        if self._audio_track is not None:
            audio_td = bundle.tracks.get(self._audio_track)
            if audio_td is not None:
                audio_data = audio_td.data
        # The OutputBuffer's cache is per-model, so the first
        # duplicates of a new session can carry the previous session's
        # last frame.  Black-fill them until a real frame lands so the
        # leading pre-roll is genuinely black rather than stale content.
        video_data = video_td.data
        if duplicate and self._markers.first_real_frame_marker is None:
            video_data = np.zeros_like(video_data)
            if audio_data is not None:
                audio_data = np.zeros_like(audio_data)
        try:
            self._feed_queue.put_nowait((video_data, audio_data))
        except queue.Full:
            self._dropped_frames += 1
            # Cold-start can fill the queue for a few hundred frames;
            # throttle to avoid log spam.
            if self._dropped_frames == 1 or self._dropped_frames % 300 == 0:
                logger.warning(
                    "Recorder feed queue full; dropping frame to keep wire path unblocked",
                    dropped_total=self._dropped_frames,
                )
            return
        # Update the keepalive watermark only when the bundle was
        # actually accepted onto the queue.  If we update it on
        # ``queue.Full`` we'd silently extend the keepalive window
        # past the point where ffmpeg is healthy enough to drain.
        self._last_fed_t = now

    def _feed_loop(self) -> None:
        """Worker thread: drains ``_feed_queue`` into the ffmpeg pipes.

        No artificial pacing — ffmpeg uses
        ``-use_wallclock_as_timestamps`` so it stamps PTS at pipe-read
        time; we simply hand frames over as fast as the queue produces
        them.  Per-frame audio fill is computed from wall-clock dt
        between consecutive video frames so audio's byte-derived DTS
        tracks video's PTS 1:1 regardless of dynamic FPS.

        An encoder failure flips ``_disabled`` and exits the loop —
        subsequent ``request_*`` calls will return ``clipFailed``.
        """
        while True:
            if self._feed_stop.is_set() and self._feed_queue.empty():
                return
            try:
                item = self._feed_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                return
            video, audio = item
            now = time.monotonic()
            # On the first frame we have no prior anchor; fall back to
            # one ``1/30`` slot so the audio fill is non-zero.  After
            # that, dt naturally tracks the model's dynamic cadence.
            dt = (
                now - self._last_video_wall_t
                if self._last_video_wall_t > 0.0
                else 1.0 / 30.0
            )
            self._last_video_wall_t = now
            try:
                self._encoder.feed_video(video)
                if self._audio_track is not None:
                    target_samples = max(0, int(round(self._audio_sample_rate * dt)))
                    av_chunk = self._next_audio_chunk(audio, target_samples)
                    if av_chunk is not None:
                        self._encoder.feed_audio(av_chunk)
            except Exception:
                logger.exception(
                    "Recorder encoder feed failed; disabling for this session"
                )
                self._disabled = True
                # Drain the queue so producer side won't keep dropping.
                try:
                    while True:
                        self._feed_queue.get_nowait()
                except queue.Empty:
                    pass
                return

    def _next_audio_chunk(
        self, model_audio: Optional[np.ndarray], target: int
    ) -> Optional[np.ndarray]:
        """Produce exactly ``target`` samples for ffmpeg.

        ``target`` is computed by the caller as
        ``round(audio_sample_rate * dt_since_previous_video_frame)`` so
        each batch represents exactly the same wall-clock interval as
        the video frame it accompanies.  Echoes model audio when
        present, silence-pads on underrun, and queues surplus for the
        next tick.
        """
        if target <= 0:
            return None

        # Append any incoming model audio to the jitter buffer.
        if model_audio is not None and model_audio.size > 0:
            flat = np.ascontiguousarray(model_audio, dtype=np.int16).reshape(-1)
            self._audio_jitter_buf.append(flat)
            self._audio_buffered_samples += flat.size

        # Trim the front of the buffer if it has grown beyond the cap;
        # this caps recording latency at ~1 s of audio when the model
        # bursts faster than video.
        while self._audio_buffered_samples > self._audio_buffer_cap_samples:
            head = self._audio_jitter_buf[0]
            drop = self._audio_buffered_samples - self._audio_buffer_cap_samples
            if head.size <= drop:
                self._audio_jitter_buf.pop(0)
                self._audio_buffered_samples -= head.size
            else:
                self._audio_jitter_buf[0] = head[drop:]
                self._audio_buffered_samples -= drop

        # Pull exactly ``target`` samples; pad with silence on underrun.
        out = np.empty(target, dtype=np.int16)
        filled = 0
        while filled < target and self._audio_jitter_buf:
            head = self._audio_jitter_buf[0]
            take = min(head.size, target - filled)
            out[filled : filled + take] = head[:take]
            filled += take
            if take == head.size:
                self._audio_jitter_buf.pop(0)
            else:
                self._audio_jitter_buf[0] = head[take:]
            self._audio_buffered_samples -= take
        if filled < target:
            out[filled:] = 0  # silence pad
        return out.reshape(1, -1)

    # ------------------------------------------------------------------
    # Clip / recording requests
    # ------------------------------------------------------------------

    def request_clip(self, duration_seconds: float, kind: str = "snap") -> ClipResult:
        """Resolve a snap-clip request to markers + a playlist URL.

        Returns immediately with ``end_marker = now_marker`` — i.e. the
        promise includes the chunk ffmpeg is currently writing.  The
        ``/clips`` manifest endpoint will ``202 Retry-After`` until
        that chunk lands; the SDK polls until ``200``.

        Honours :attr:`RecordingConfig.skip_leading_black`.
        """
        if self.disabled:
            raise RecorderDisabledError("recorder disabled or encoder crashed")
        capped = min(float(duration_seconds), float(self._config.clip_max_seconds))
        if capped <= 0:
            raise ValueError("duration_seconds must be positive")
        start, end = self._markers.compute_clip_range(
            capped, skip_leading_black=self._config.skip_leading_black
        )
        return self._build_result(kind=kind, start=start, end=end)

    def request_recording(self) -> ClipResult:
        """Resolve a full-recording request; ``end = now``.

        Same promise-then-poll semantics as :meth:`request_clip` and
        honours :attr:`RecordingConfig.skip_leading_black`.
        """
        if self.disabled:
            raise RecorderDisabledError("recorder disabled or encoder crashed")
        start, end = self._markers.compute_recording_range(
            skip_leading_black=self._config.skip_leading_black
        )
        return self._build_result(kind="recording", start=start, end=end)

    def _build_result(self, kind: str, start: float, end: float) -> ClipResult:
        now = self._markers.now_marker()
        # Estimate when the in-progress chunk will close.  The
        # dominant term is the time until the next chunk boundary; sink
        # copy after that is sub-second on local fs and not modeled.
        # If chunk_seconds isn't configured the estimate degenerates
        # to "now" (the SDK should still poll /clips with backoff).
        cs = float(self._config.chunk_seconds)
        if cs > 0:
            next_boundary = (math.floor(now / cs) + 1) * cs
            wait_s = max(0.0, next_boundary - now)
        else:
            wait_s = 0.0
        predicted_ready_at_ms = int(round((time.time() + wait_s) * 1000))
        # ``kind`` is a body-only discriminator; keeping it out of the
        # URL means identical content always has one canonical URL.
        # The URL is path-only — the SDK prepends the runtime/Coordinator
        # origin it already knows.  See ``ClipResult.playlist_url``.
        query = urlencode(
            {
                "session_id": self._session_id,
                "start": f"{start:.3f}",
                "end": f"{end:.3f}",
            }
        )
        playlist_url = f"/clips?{query}"
        return ClipResult(
            session_id=self._session_id,
            kind=kind,
            start_marker=start,
            end_marker=end,
            now_marker=now,
            predicted_ready_at_ms=predicted_ready_at_ms,
            playlist_url=playlist_url,
            first_real_frame_marker=self._markers.first_real_frame_marker,
        )
