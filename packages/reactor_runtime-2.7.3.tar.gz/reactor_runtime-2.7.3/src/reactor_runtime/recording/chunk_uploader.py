# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Background thread that ships closed encoder segments to a sink.

The uploader watches the encoder's output directory by polling for
the next-numbered segment file (``init.mp4`` first, then
``chunk_00000.m4s``, ``chunk_00001.m4s``, …).  Polling is chosen over
``inotify`` for portability — the production runtime can switch to
``inotify`` in a follow-up without changing the public surface here.

A segment "closing" is detected by the *next-numbered* file appearing:
ffmpeg writes ``chunk_N`` and starts ``chunk_(N+1)`` only when chunk N
is fully flushed, so once we see chunk_(N+1) on disk chunk_N is safe
to upload.  The very last chunk of a session is flushed when ffmpeg
exits, observed by the caller via ``stop(flush_remaining=True)``.
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Callable, Optional

from reactor_runtime.recording.markers import MarkerBookkeeper
from reactor_runtime.recording.sinks import RecordingSink
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class ChunkUploader:
    """Polls an encoder output dir and dispatches closed chunks to the sink.

    Lifecycle:

    * :meth:`start` spawns the watcher thread.
    * :meth:`stop` signals shutdown and joins.  Pass
      ``flush_remaining=True`` to drain whatever is on disk after the
      encoder has exited (the final chunk that polling alone wouldn't
      catch because its successor never appears).
    """

    def __init__(
        self,
        encoder_dir: Path,
        sink: RecordingSink,
        markers: MarkerBookkeeper,
        *,
        chunk_seconds: float = 4.0,
        max_retries: int = 3,
        poll_interval: float = 0.1,
        encoder_alive: Optional[Callable[[], bool]] = None,
    ) -> None:
        self._dir = Path(encoder_dir)
        self._sink = sink
        self._markers = markers
        self._chunk_seconds = chunk_seconds
        self._max_retries = max_retries
        self._poll_interval = poll_interval
        self._encoder_alive = encoder_alive
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._uploaded_init = False
        # ffmpeg's HLS muxer (with ``-hls_segment_type fmp4``) numbers
        # segments from 0 by default — the same numbering our marker
        # math (``chunk_idx * chunk_seconds``) and the ``/clips``
        # manifest endpoint already assume.  No translation needed.
        self._next_idx = 0
        # Read by ``_run`` after the stop signal to decide whether the
        # worker should drain leftover chunks before exiting.  Set by
        # ``stop()`` *before* signalling stop so the worker reads it
        # consistently on its way out.  See ``stop()`` docstring for
        # why the drain has to happen on this thread rather than the
        # caller's.
        self._flush_on_exit = False

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="recording-uploader", daemon=True
        )
        self._thread.start()

    def stop(self, *, flush_remaining: bool = True, timeout: float = 30.0) -> bool:
        """Signal the watcher to exit; optionally drain final chunks.

        Returns ``True`` when the worker joined cleanly, ``False`` when
        both join attempts timed out.  Always closes the sink before
        returning.

        The drain runs on the worker thread; see REA-2268.
        """
        self._flush_on_exit = flush_remaining
        self._stop.set()
        thread = self._thread
        self._thread = None
        clean = True
        if thread is not None:
            thread.join(timeout=timeout)
            if thread.is_alive():
                # Close the sink to cancel any in-flight presign future,
                # then give the worker a short grace window to exit.
                self._safe_close_sink()
                thread.join(timeout=2.0)
                if thread.is_alive():
                    clean = False
                    logger.error(
                        "ChunkUploader.stop join timed out; thread leaked",
                        timeout_s=timeout,
                        next_idx=self._next_idx,
                    )
        self._safe_close_sink()
        return clean

    def _safe_close_sink(self) -> None:
        try:
            self._sink.close()
        except Exception:
            logger.exception("RecordingSink.close() raised; resources may leak")

    def _run(self) -> None:
        try:
            while not self._stop.is_set():
                progress = self._tick()
                if not progress:
                    self._stop.wait(self._poll_interval)
            # Final drain happens here, in the worker thread, so the
            # caller-side ``stop()`` doesn't accidentally drive
            # ``run_coroutine_threadsafe(...).result()`` from the
            # asyncio loop thread.  See ``stop()`` docstring.
            if self._flush_on_exit:
                self._drain_final()
        except Exception:
            logger.exception("ChunkUploader thread crashed")

    def _tick(self) -> bool:
        """Upload as many ready chunks as possible.  Returns True if anything moved."""
        moved = False
        if not self._uploaded_init and self._init_ready():
            init_path = self._dir / "init.mp4"
            if self._safe_upload_init(init_path):
                self._uploaded_init = True
                moved = True
        # A chunk is "closed" when its successor exists on disk.  We
        # don't delete the source after copying — ffmpeg's HLS muxer
        # keeps live references via its sidecar manifest and would
        # trip on the next rename if we removed it.  The encoder dir
        # is rmtree'd on session stop anyway.
        while True:
            current = self._dir / f"chunk_{self._next_idx:05d}.m4s"
            successor = self._dir / f"chunk_{self._next_idx + 1:05d}.m4s"
            if not (current.exists() and successor.exists()):
                break
            if self._safe_upload_chunk(self._next_idx, current):
                self._markers.mark_chunk_uploaded(self._next_idx)
                self._log_chunk_latency(self._next_idx, current)
            # Increment unconditionally: a permanently-failed upload
            # (``_safe_upload_chunk`` returned False after exhausting
            # retries) is a drop, not a stall. We advance past it so
            # the uploader continues to flush newer chunks rather than
            # head-of-line blocking on a single bad segment. The drop
            # is observable via the WARN logged inside
            # ``_safe_upload_chunk`` and shows up as a discontinuity in
            # the HLS playlist (which players tolerate).
            self._next_idx += 1
            moved = True
        return moved

    def _drain_final(self) -> None:
        """Pick up the final chunk (and init, if it raced ahead) after stop."""
        if not self._uploaded_init and self._init_ready():
            init_path = self._dir / "init.mp4"
            if self._safe_upload_init(init_path):
                self._uploaded_init = True
        while True:
            current = self._dir / f"chunk_{self._next_idx:05d}.m4s"
            if not current.exists():
                break
            if self._safe_upload_chunk(self._next_idx, current):
                self._markers.mark_chunk_uploaded(self._next_idx)
                self._log_chunk_latency(self._next_idx, current)
            self._next_idx += 1

    def _log_chunk_latency(self, idx: int, sink_path: Path) -> None:
        """Log encoder → sink pipeline overhead for the just-uploaded chunk.

        ``pipeline_lag`` is the wall-clock time between when ffmpeg
        finished writing the chunk (file mtime) and when we finished
        copying it to the sink.  Crucially this excludes any time the
        model is paused/idle: no chunks close during a pause, so the
        metric doesn't drift over long silent stretches the way a
        ``now_marker − content_end`` lag would.
        """
        try:
            close_t = sink_path.stat().st_mtime
        except OSError:
            return
        pipeline_lag = time.time() - close_t
        # Per-chunk; emitted once every chunk_seconds so it dominates
        # INFO output for any session longer than ~30s.  Keep visible
        # at DEBUG for diagnostics.
        logger.debug(
            "chunk_uploaded",
            idx=idx,
            pipeline_lag_s=round(pipeline_lag, 2),
        )

    def _init_ready(self) -> bool:
        """``init.mp4`` is safe to upload once it has bytes.

        ffmpeg creates the file at startup (size 0) and only writes
        the codec headers when flushing the first segment, so polling
        ``exists()`` alone copies a 0-byte placeholder.  Wait for a
        non-empty file or for the first chunk to appear.
        """
        init_path = self._dir / "init.mp4"
        if not init_path.exists():
            return False
        try:
            if init_path.stat().st_size > 0:
                return True
        except OSError:
            return False
        # init.mp4 exists but is empty.  Treat the existence of the
        # first chunk as a strong signal that ffmpeg has flushed init.
        return (self._dir / "chunk_00000.m4s").exists()

    def _safe_upload_init(self, path: Path) -> bool:
        for attempt in range(self._max_retries):
            try:
                self._sink.upload_init(path)
                return True
            except Exception:
                logger.exception(
                    "Sink.upload_init failed",
                    attempt=attempt + 1,
                    max_retries=self._max_retries,
                )
                time.sleep(0.05 * (2**attempt))
        logger.error("Dropped init.mp4", retries=self._max_retries)
        return False

    def _safe_upload_chunk(self, idx: int, path: Path) -> bool:
        for attempt in range(self._max_retries):
            try:
                self._sink.upload_chunk(idx, path)
                return True
            except Exception:
                logger.exception(
                    "Sink.upload_chunk failed",
                    idx=idx,
                    attempt=attempt + 1,
                    max_retries=self._max_retries,
                )
                time.sleep(0.05 * (2**attempt))
        logger.error("Dropped chunk", idx=idx, retries=self._max_retries)
        return False

    @staticmethod
    def _safe_unlink(path: Path) -> None:
        try:
            path.unlink()
        except OSError:
            pass
