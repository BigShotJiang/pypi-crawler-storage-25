# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Pluggable destinations for recorded fMP4 chunks.

The recorder doesn't know about S3 or the Supervisor directly — it
hands closed segments to a :class:`RecordingSink` and forgets about
them.  Today this package ships only :class:`LocalDirSink` (used by
the HTTP runtime in dev mode); the production ``S3PresignedSink`` is
added in a follow-up PR alongside the Supervisor's ``CreateChunkUrl``
RPC.
"""

from __future__ import annotations

import abc
import shutil
from pathlib import Path


class RecordingSink(abc.ABC):
    """Abstract destination for the encoder's closed segment files.

    Implementations must be safe to call from a single uploader
    thread; they are NEVER called concurrently for the same chunk
    index by the runtime.  A failed call should raise — the uploader
    handles retries and eventual drops.
    """

    @abc.abstractmethod
    def upload_init(self, local_path: Path) -> None:
        """Persist the one-time fMP4 init segment (``init.mp4``)."""

    @abc.abstractmethod
    def upload_chunk(self, idx: int, local_path: Path) -> None:
        """Persist a media segment (``chunk_NNNNN.m4s``)."""

    def close(self) -> None:
        """Release any sink-owned resources (HTTP clients, file handles, …).

        Called once by :meth:`ChunkUploader.stop` after the final drain.
        The default implementation is a no-op so sinks that don't hold
        external resources (e.g. :class:`LocalDirSink`) need not override
        it.  Implementations must be idempotent: ``close`` after a
        ``stop`` that already drained is allowed; ``close`` without any
        prior ``upload_*`` call is allowed.
        """


class LocalDirSink(RecordingSink):
    """Copies chunks into a session-scoped directory on local disk.

    Used by ``HttpRuntime`` so the FastAPI app can serve them via
    ``FileResponse`` from the same process.  We *copy* (not move) so
    the encoder-side temp file lifecycle remains the uploader's
    responsibility — the uploader deletes its temp file after a
    successful sink call.
    """

    def __init__(self, target_dir: Path, session_id: str) -> None:
        self._dir = Path(target_dir) / session_id
        self._dir.mkdir(parents=True, exist_ok=True)

    @property
    def session_dir(self) -> Path:
        """Absolute path of the per-session served directory."""
        return self._dir

    def upload_init(self, local_path: Path) -> None:
        shutil.copyfile(local_path, self._dir / "init.mp4")

    def upload_chunk(self, idx: int, local_path: Path) -> None:
        shutil.copyfile(local_path, self._dir / f"chunk_{idx:05d}.m4s")
