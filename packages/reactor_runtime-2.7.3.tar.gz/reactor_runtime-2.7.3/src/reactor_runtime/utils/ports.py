# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Port number validation shared across the runtime.

Lives in `reactor_runtime.utils` (not the `serve` subpackage) because the
GStreamer transport, the http runtime config, and the _redis runtime config
all need port validation independently of the entrypoint CLI.
"""

import argparse

# Valid port range bounds (avoid privileged ports 0-1023).
MIN_VALID_PORT = 1024
MAX_VALID_PORT = 65535


def validate_port(port: int) -> None:
    """Raise ValueError if ``port`` is outside [MIN_VALID_PORT, MAX_VALID_PORT]."""
    if not (MIN_VALID_PORT <= port <= MAX_VALID_PORT):
        raise ValueError(
            f"port must be between {MIN_VALID_PORT} and {MAX_VALID_PORT}, got {port}"
        )


def _valid_port(value: str) -> int:
    """argparse type-converter: parse + range-check a port string.

    Translates the underlying ValueError into argparse.ArgumentTypeError so
    the CLI surfaces a clean ``error: argument --port: …`` message instead
    of a stack trace.
    """
    try:
        port = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid int value: '{value}'")
    try:
        validate_port(port)
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e))
    return port
