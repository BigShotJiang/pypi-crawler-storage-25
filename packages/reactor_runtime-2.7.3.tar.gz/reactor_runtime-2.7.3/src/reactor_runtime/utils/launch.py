# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Entry point for running the Reactor runtime."""

import asyncio
import logging
import os
import sys
from typing import Callable, List, Optional

from reactor_runtime import __version__
from reactor_runtime.config import ReactorConfig
from reactor_runtime.utils.log import (
    LOG_DATEFMT,
    LOG_FORMAT,
    LOG_FORMAT_BRIEF,
    ColorFormatter,
    get_logger,
)

logger = get_logger(__name__)


def add_import_paths(paths: List[str]) -> None:
    """Prepend provided directories to sys.path if they exist."""
    for p in paths:
        if not p:
            continue
        ap = os.path.abspath(p)
        if os.path.isdir(ap) and ap not in sys.path:
            sys.path.insert(0, ap)


def configure_logging(level: str, show_timestamps: bool = True) -> None:
    fmt = LOG_FORMAT if show_timestamps else LOG_FORMAT_BRIEF
    handler = logging.StreamHandler()
    handler.setFormatter(ColorFormatter(fmt, datefmt=LOG_DATEFMT))
    logging.root.addHandler(handler)
    logging.root.setLevel(getattr(logging, level.upper(), logging.INFO))
    logging.getLogger("aiortc").setLevel(logging.WARNING)
    logging.getLogger("av").setLevel(logging.WARNING)
    logging.getLogger("aioice").setLevel(logging.WARNING)
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    # Per-request httpx INFO logs would emit one line per recorded
    # chunk and embed presigned credentials in the URL.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _infer_runtime_name(serve_fn: Callable) -> str:
    """Derive a short runtime label from the serve function's module path.

    e.g. ``reactor_runtime.runtimes.http.http_runtime`` -> ``http``
         ``reactor_runtime.runtimes._redis._redis_runtime`` -> ``redis``
    """
    parts = getattr(serve_fn, "__module__", "").split(".")
    if len(parts) >= 3:
        return parts[2].lstrip("_")
    return "unknown"


def run_reactor_runtime(
    runtime_serve_fn: Callable,
    reactor_config: ReactorConfig,
    model_root: Optional[str] = None,
    log_level: str = "INFO",
    show_timestamps: bool = True,
    **runtime_kwargs,
) -> None:
    """Run the Reactor runtime.

    Args:
        runtime_serve_fn: The ``serve()`` function from the runtime module.
        reactor_config: Parsed ``reactor.yaml`` (with ``config`` resolved
            to an absolute path and ``config_overrides`` populated).
        model_root: Directory to add to sys.path for model imports.
        log_level: Logging level.
        show_timestamps: Include timestamps in log output (disabled for local
            HTTP runtime where output is watched interactively).
        **runtime_kwargs: Runtime-specific arguments passed to serve().
    """
    configure_logging(log_level, show_timestamps=show_timestamps)

    runtime_name = _infer_runtime_name(runtime_serve_fn)
    logger.info(
        "Starting reactor runtime",
        version=__version__,
        runtime=runtime_name,
    )
    model_kw: dict = {
        "name": reactor_config.name,
        "entrypoint": reactor_config.model,
    }
    if reactor_config.config:
        model_kw["config"] = reactor_config.config
    logger.info("Model detected", **model_kw)

    if model_root is not None:
        add_import_paths([model_root])

    asyncio.run(
        runtime_serve_fn(
            reactor_config=reactor_config,
            **runtime_kwargs,
        )
    )
