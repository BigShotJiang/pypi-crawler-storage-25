# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Path resolution helpers for the Reactor runtime.

Currently exposes :func:`get_weights_path`, the canonical way for model code
to locate its weights directory. The same call works unchanged from local
development to production: locally the user points
``$REACTOR_WEIGHTS_PATH`` at their checkout (or sets ``runtime.weights_path``
in ``reactor.yaml``), in production the deployment sets the env var to the
namespaced cache directory mounted into the container.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

ENV_REACTOR_WEIGHTS_PATH = "REACTOR_WEIGHTS_PATH"
"""Environment variable that overrides the weights root."""

DEFAULT_WEIGHTS_PATH = "~/.cache/reactor_registry"
"""Default weights root used when no override is configured.

Matches the on-disk convention used by every Reactor model today and the
mount point used by the Reactor compute Helm chart.
"""

# Optional override sourced from ``reactor.yaml`` (``runtime.weights_path``
# in the modern shape, top-level ``weights_path`` in the legacy shape).
# Wired up by the runtime CLI's ``RunCommand`` after parsing reactor.yaml,
# so partner code can keep calling :func:`get_weights_path` with no
# arguments and still pick up the YAML-level override.
#
# Strictly internal — partners must not touch this. Tests reset by passing
# ``None`` to :func:`_set_configured_weights_path`.
_configured_weights_path: Optional[str] = None


def _set_configured_weights_path(path: Optional[str]) -> None:
    """Register a weights-path override sourced from ``reactor.yaml``.

    Called once per process by the runtime CLI after parsing reactor.yaml.
    Empty strings and ``None`` both clear the override (so a missing or
    blank ``runtime.weights_path`` falls through to the default).
    """
    global _configured_weights_path
    _configured_weights_path = path or None


def get_weights_path() -> Path:
    """Return the root directory under which model weights live.

    Resolution order:

    1. ``$REACTOR_WEIGHTS_PATH`` if set and non-empty.
    2. ``runtime.weights_path`` from ``reactor.yaml`` if registered by the
       runtime CLI (see :func:`_set_configured_weights_path`).
    3. :data:`DEFAULT_WEIGHTS_PATH` (``~/.cache/reactor_registry``).

    The returned path has ``~`` expanded but is not required to exist on
    disk. Resolving and validating subpaths is the caller's responsibility.

    Typical usage::

        from reactor_runtime import get_weights_path

        weights = get_weights_path()
        transformer = AutoModel.from_pretrained(weights / "wan2_2" / "transformer")
        vae_ckpt = weights / "wan2_2" / "vae" / "model.safetensors"

    In production the deployment sets ``REACTOR_WEIGHTS_PATH`` to the
    namespaced cache directory for the model release
    (``/.cache/reactor_registry/<model-uuid>/<release>``) so that the same
    code runs unchanged from local development to production. Locally,
    partners can either export the env var or commit a
    ``runtime.weights_path: ./weights`` line to ``reactor.yaml``.
    """
    raw = (
        os.environ.get(ENV_REACTOR_WEIGHTS_PATH)
        or _configured_weights_path
        or DEFAULT_WEIGHTS_PATH
    )
    return Path(os.path.expanduser(raw))
