# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Rate-controlled emission buffer.

Receives complete :class:`Output` instances via :meth:`submit`,
converts them to :class:`MediaBundle`, and drains them at a smooth FPS
on a dedicated thread.  No accumulation, no buckets — the ``Output``
type system guarantees completeness at construction time.

Three-stage pipeline::

    submit(Output)  →  Queue[MediaBundle]  →  Emission thread → callback
"""

from __future__ import annotations

import queue
import threading
import time
from typing import Callable, Dict, List, Optional

import numpy as np

from reactor_runtime.interface.tracks.descriptors import Audio
from reactor_runtime.interface.tracks.output import Output, all_output_tracks
from reactor_runtime.transports.media import (
    MediaBundle,
    TrackData,
    TrackDirection,
    TrackInfo,
    TrackKind,
)
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

DEFAULT_FRAME_DIMENSIONS: tuple[int, int, int] = (720, 1280, 3)


def split_batch(bundle: MediaBundle) -> List[MediaBundle]:
    """Split a multi-video-frame bundle into single-frame bundles.

    All batched (4D) video tracks must share the same batch size.
    Non-batched (3D) video tracks are replicated into each output
    bundle.  Audio tracks are split proportionally across frames.

    Returns the original bundle unchanged if there is nothing to split
    (no video tracks, no batched tracks, or batch size <= 1).
    """
    video_tracks = bundle.get_tracks_by_kind(TrackKind.VIDEO)
    if not video_tracks:
        return [bundle]

    batched = [(td, td.data.shape[0]) for td in video_tracks if td.data.ndim == 4]
    if not batched:
        return [bundle]

    n_frames = batched[0][1]
    if n_frames == 1:
        for td, _ in batched:
            td.data = td.data[0]
        return [bundle]

    for td, n in batched:
        if n != n_frames:
            raise ValueError(
                f"Video track '{td.info.name}' has batch size {n}, "
                f"expected {n_frames} (from '{batched[0][0].info.name}')"
            )

    video_splits: Dict[str, List[np.ndarray]] = {}
    for td in video_tracks:
        if td.data.ndim == 4:
            video_splits[td.info.name] = list(td.data)
        else:
            video_splits[td.info.name] = [td.data] * n_frames

    audio_tracks = bundle.get_tracks_by_kind(TrackKind.AUDIO)
    audio_splits: Dict[str, List[np.ndarray]] = {}
    for td in audio_tracks:
        audio = td.data
        if audio.ndim == 1:
            audio = audio.reshape(1, -1)
        audio_splits[td.info.name] = np.array_split(audio, n_frames, axis=1)

    info_by_name: Dict[str, TrackInfo] = {
        td.info.name: td.info for td in video_tracks + audio_tracks
    }

    # Safe to index with i in range(n_frames):
    # - video_splits: 4D tracks have exactly n_frames items (batch size validated
    #   above), 3D tracks are replicated to n_frames via [data] * n_frames.
    # - audio_splits: np.array_split always returns exactly n_frames sub-arrays.
    result: List[MediaBundle] = []
    for i in range(n_frames):
        tracks: Dict[str, TrackData] = {}
        for name, frames in video_splits.items():
            tracks[name] = TrackData(info=info_by_name[name], data=frames[i])
        for name, chunks in audio_splits.items():
            tracks[name] = TrackData(info=info_by_name[name], data=chunks[i])
        result.append(MediaBundle(tracks=tracks))
    return result


class OutputBuffer:
    """Rate-controlled emission buffer.

    Ingestion converts a typed :class:`Output` instance into a
    :class:`MediaBundle`, splits multi-frame batches, and enqueues
    single-frame bundles.  The emission thread drains the queue at a
    smooth, rate-controlled FPS and delivers via the callback.

    Args:
        queue_depth: Maximum number of bundles that can sit in the
            emission queue before :meth:`submit` blocks the caller.
            Higher values absorb model-side jitter but add latency —
            at *N* fps, a depth of *D* means up to *D/N* seconds of
            buffered output before the client sees it.  Lower values
            tighten latency but may cause the model to stall waiting
            for the emission thread to drain.
    """

    def __init__(self, queue_depth: int = 10) -> None:
        # Ordered list of per-tick observers.  Callbacks fire in
        # registration order on every emission tick; an exception in
        # one callback is logged and does not block the others.
        self._callbacks: List[Callable[[MediaBundle, bool], None]] = []
        self._callbacks_lock: threading.Lock = threading.Lock()

        self._q: queue.Queue[MediaBundle] = queue.Queue(maxsize=queue_depth)

        # FPS control — store both rate and period to avoid 1/fps on every tick
        self._fixed_fps: float = 0.0
        self._interval: float = 0.0

        # Emission thread.  _emission_stop is the single source of truth
        # for whether emission is active: set = stopped, cleared = running.
        # Initialised as set (stopped) so _enqueue() is a no-op before
        # start_emission() is called.
        self._emission_thread: Optional[threading.Thread] = None
        self._emission_stop: threading.Event = threading.Event()
        self._emission_stop.set()
        self._emission_lock: threading.Lock = threading.Lock()

        # State for gap fill / black frame
        self._last_emitted: Optional[MediaBundle] = None
        self._frame_dims: Optional[tuple[int, int, int]] = None

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def add_callback(self, fn: Callable[[MediaBundle, bool], None]) -> None:
        """Register a per-tick callback.

        Idempotent: registering the same ``fn`` twice leaves the
        callback list with a single entry. This mirrors
        :meth:`remove_callback` which has always been a no-op on
        already-unregistered functions — callers shouldn't have to
        track registration state.

        The callback receives ``(bundle, duplicate)`` on every emission
        tick.  Callbacks fire in registration order and are isolated
        from each other: an exception raised by one is logged and the
        remaining callbacks still fire.
        """
        with self._callbacks_lock:
            if fn not in self._callbacks:
                self._callbacks.append(fn)

    def remove_callback(self, fn: Callable[[MediaBundle, bool], None]) -> None:
        """Deregister a previously added callback.

        No-op if *fn* was never registered.
        """
        with self._callbacks_lock:
            try:
                self._callbacks.remove(fn)
            except ValueError:
                pass

    # ------------------------------------------------------------------
    # FPS control
    # ------------------------------------------------------------------

    def set_fps(self, fps: float) -> None:
        """Set the emission FPS.

        Called automatically from class attributes, and may be called
        programmatically (e.g. in ``load()``).  When ``compute_time``
        is passed to :meth:`emit`, ``emit()`` calls ``set_fps()``
        with the effective rate derived from frame count / compute time.
        """
        if fps <= 0:
            raise ValueError(f"fps must be positive, got {fps}")
        self._fixed_fps = fps
        self._interval = 1.0 / fps

    @property
    def fps(self) -> float:
        """Current emission FPS."""
        return self._fixed_fps

    # ------------------------------------------------------------------
    # Stage 1: Ingestion
    # ------------------------------------------------------------------

    def submit(self, output: Output, *, drop: bool = False) -> int:
        """Convert an Output instance to MediaBundle(s) and enqueue.

        By default, blocks the calling thread when the queue is full —
        this throttles the model to match the emission FPS.  When
        *drop* is ``True``, frames that don't fit are silently
        discarded instead of blocking.

        Args:
            output: An :class:`Output` instance.
            drop: If ``True``, skip frames when the queue is full
                instead of blocking.

        Returns:
            The number of individual frames actually enqueued.
        """
        bundle = self._to_bundle(output)
        frames = split_batch(bundle)
        enqueued = 0
        for single in frames:
            if self._enqueue(single, drop=drop):
                enqueued += 1
        return enqueued

    def _to_bundle(self, output: Output) -> MediaBundle:
        """Build a MediaBundle from an Output instance's track annotations."""
        tracks: Dict[str, TrackData] = {}
        for name, marker in type(output)._tracks.items():
            data = getattr(output, name)
            if issubclass(marker, Audio):
                kind = TrackKind.AUDIO
                rate = float(getattr(marker, "sample_rate", 48_000))
            else:
                kind = TrackKind.VIDEO
                rate = 0.0
            info = TrackInfo(
                name=name,
                kind=kind,
                rate=rate,
                direction=TrackDirection.OUT,
            )
            tracks[name] = TrackData(info=info, data=data)
        return MediaBundle(tracks=tracks)

    # ------------------------------------------------------------------
    # Stage 2: Queue
    # ------------------------------------------------------------------

    def _enqueue(self, bundle: MediaBundle, *, drop: bool = False) -> bool:
        """Enqueue a single-frame bundle.

        When *drop* is False (default), spins with a 100ms put timeout
        until a slot opens — this is the throttle point that paces the
        model to the emission FPS.  When *drop* is True, tries once
        and returns False if the queue is full.

        Returns True if the bundle was enqueued, False otherwise.
        """
        if drop:
            try:
                self._q.put_nowait(bundle)
                return True
            except queue.Full:
                return False
        while not self._emission_stop.is_set():
            try:
                self._q.put(bundle, timeout=0.1)
                return True
            except queue.Full:
                continue
        return False

    def _drain_queue(self) -> None:
        while True:
            try:
                self._q.get_nowait()
            except queue.Empty:
                return

    # ------------------------------------------------------------------
    # Stage 3: Emission loop
    # ------------------------------------------------------------------

    def _dispatch(self, bundle: MediaBundle, duplicate: bool) -> None:
        """Fire every registered callback in order with error isolation.

        We snapshot the callback list under the lock so callbacks that
        register/deregister siblings during dispatch don't perturb the
        current tick.  Each callback is wrapped so an exception in one
        does not block the others.
        """
        with self._callbacks_lock:
            callbacks = list(self._callbacks)
        for fn in callbacks:
            try:
                fn(bundle, duplicate)
            except Exception as ex:
                # ``logger.exception`` already attaches sys.exc_info()'s
                # traceback; we also surface the type + message as
                # structured fields so log queries on ``exc_type`` /
                # ``exc_msg`` / ``callback`` work without traceback
                # parsing. Without these explicit fields a silent
                # malfunction in a downstream callback looks like
                # "feature X didn't fire" with no obvious cause.
                logger.exception(
                    "OutputBuffer callback raised; continuing with remaining callbacks",
                    callback=repr(fn),
                    exc_type=type(ex).__name__,
                    exc_msg=str(ex),
                )

    def _emission_loop(self) -> None:
        abs_next_tick = time.perf_counter()
        try:
            while not self._emission_stop.is_set():
                interval = self._interval

                bundle: Optional[MediaBundle] = None
                try:
                    bundle = self._q.get_nowait()
                except queue.Empty:
                    pass

                if bundle is not None:
                    vtracks = bundle.get_tracks_by_kind(TrackKind.VIDEO)
                    if vtracks:
                        vd = vtracks[0].data
                        if vd.ndim == 3:
                            self._frame_dims = (vd.shape[0], vd.shape[1], vd.shape[2])

                    self._last_emitted = bundle
                    self._dispatch(bundle, False)
                else:
                    last = self._last_emitted
                    if last is not None:
                        self._dispatch(last.video_only(), True)
                    else:
                        self._dispatch(self._create_black_bundle(), True)

                # Absolute-time tick scheduling.  We advance by one interval
                # each iteration to keep a steady cadence (no drift from
                # sleep jitter or callback duration).
                abs_next_tick += interval
                now = time.perf_counter()
                # Guard against stalls (GC pause, slow callback, etc.):
                # if abs_next_tick has fallen more than one full interval
                # behind wall-clock time, we're hopelessly late.  Without
                # this, the loop would rapid-fire hundreds of iterations
                # trying to "catch up", emitting a burst of useless
                # gap-fill frames.  Instead, we skip ahead and resume at
                # the next clean tick boundary.
                if abs_next_tick < now - interval:
                    abs_next_tick = now + interval
                self._sleep_until(abs_next_tick)

        except Exception:
            logger.exception("Emission loop crashed")
            self._emission_stop.set()

    # ------------------------------------------------------------------
    # Precise sleep
    # ------------------------------------------------------------------

    _SLEEP_CHUNK: float = 0.005  # 5ms — sleep + spin-wait threshold

    def _sleep_until(self, deadline: float) -> None:
        """Sleep until *deadline* (perf_counter), waking instantly on stop.

        Chunked Event.wait() while remaining > _SLEEP_CHUNK, then
        spin-wait for the final stretch.  OS sleep granularity can
        overshoot by 1-15ms, so we never sleep for less than one chunk.
        """
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0 or self._emission_stop.is_set():
                return
            if remaining > self._SLEEP_CHUNK:
                if self._emission_stop.wait(timeout=self._SLEEP_CHUNK):
                    return
            # remaining <= _SLEEP_CHUNK: spin-wait for precision

    # ------------------------------------------------------------------
    # Black frame
    # ------------------------------------------------------------------

    def _create_black_bundle(self) -> MediaBundle:
        dims = self._frame_dims or DEFAULT_FRAME_DIMENSIONS
        black = np.zeros(dims, dtype=np.uint8)
        video_out = {
            name: marker
            for name, marker in all_output_tracks().items()
            if not issubclass(marker, Audio)
        }
        if video_out:
            tracks = {
                name: TrackData(
                    info=TrackInfo(
                        name=name,
                        kind=TrackKind.VIDEO,
                        rate=0.0,
                        direction=TrackDirection.OUT,
                    ),
                    data=black,
                )
                for name in video_out
            }
            return MediaBundle(tracks=tracks)
        return MediaBundle.from_video_frame(black)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start_emission(self) -> None:
        # Deliberate relaxed read of ``self._callbacks`` without
        # ``_callbacks_lock``: ``start_emission`` runs once during the
        # model's start path, strictly serialised with the model loop
        # bootstrap, and never concurrently with
        # ``add_callback`` / ``remove_callback`` (callbacks must already
        # be registered to pass this guard). Acquiring the lock here
        # would only protect against a race that the call ordering
        # already precludes.
        if not self._callbacks:
            raise RuntimeError(
                "Cannot start emission: no callback registered. "
                "Call output_buffer.add_callback() first."
            )
        if self._fixed_fps <= 0:
            raise RuntimeError(
                "Cannot start emission: FPS not set. Call set_fps() first."
            )
        with self._emission_lock:
            if not self._emission_stop.is_set():
                return
            self._emission_stop.clear()
            self._emission_thread = threading.Thread(
                target=self._emission_loop, name="emission"
            )
            self._emission_thread.start()

    def stop_emission(self) -> None:
        with self._emission_lock:
            if self._emission_stop.is_set():
                return
            self._emission_stop.set()
            thread = self._emission_thread
            self._emission_thread = None
        if thread:
            thread.join(timeout=2.0)
            if thread.is_alive():
                raise RuntimeError("Emission thread did not stop within 2s. ")

    def clear(self) -> None:
        """Reset all state for a new session."""
        self._last_emitted = None
        self._frame_dims = None
        self._drain_queue()

    def flush(self) -> None:
        """Empty the queue and insert a black frame."""
        self._drain_queue()
        self._last_emitted = None
        black = self._create_black_bundle()
        try:
            self._q.put_nowait(black)
        except queue.Full:
            pass
