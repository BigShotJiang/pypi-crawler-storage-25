# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Internal entrypoint package.

Invoked as `python -m reactor_runtime.serve <subcommand> [flags]` — typically
by the container CMD / Go reactor CLI's docker-run dispatcher, never
directly by partners. Subcommand surface (`run`, `schema`) is an
implementation detail; flags reaching this package come pre-validated by
the public Go CLI. Workspace scaffolding (`init`) lives in the Go CLI on
top of this package and never runs inside a model container.
"""
