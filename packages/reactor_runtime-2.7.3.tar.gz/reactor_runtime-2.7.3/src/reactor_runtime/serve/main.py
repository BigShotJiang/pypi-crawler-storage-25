# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
import argparse
import sys


def main():
    # `prog` mirrors the actual invocation form so argparse usage / error
    # messages are self-describing for anyone who lands inside a container
    # and runs the entrypoint by hand. There is no console script — this
    # module is invoked exclusively as `python -m reactor_runtime.serve`.
    parser = argparse.ArgumentParser(prog="python -m reactor_runtime.serve")
    subparsers = parser.add_subparsers(dest="command")

    from .commands import (
        RunCommand,
        SchemaCommand,
    )

    RunCommand.register_subcommand(subparsers)
    SchemaCommand.register_subcommand(subparsers)

    args, remaining = parser.parse_known_args()
    if hasattr(args, "func"):
        if args.func == RunCommand:
            command = args.func(args, remaining_args=remaining)
        else:
            if remaining:
                parser.error(f"Unrecognized arguments: {' '.join(remaining)}")
            command = args.func(args)
        command.run()
    else:
        parser.print_help()
        sys.exit(1)
