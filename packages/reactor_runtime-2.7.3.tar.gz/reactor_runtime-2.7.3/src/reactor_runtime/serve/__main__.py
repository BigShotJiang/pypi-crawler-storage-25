# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Module entry point for `python -m reactor_runtime.serve`.

Container CMDs and the Go CLI's docker-run dispatcher invoke this; nobody
should call it as a console script (no `[project.scripts]` entry exists).
The actual subcommand registration lives in `main.py` so it can be unit-
tested without exec'ing the module.
"""

from reactor_runtime.serve.main import main

if __name__ == "__main__":
    main()
