# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Run command — loads reactor.yaml and starts the runtime."""

import os
import re
import sys
from pathlib import Path

from omegaconf import OmegaConf
from reactor_runtime.serve.utils.config import print_model_config_help
from reactor_runtime.serve.utils.runtime import load_runtime
from reactor_runtime.utils.ports import _valid_port
from reactor_runtime.config import ReactorConfig
from reactor_runtime.transports.config import (
    GSTREAMER_INSTALL_URL,
    resolve_default_transport,
    validate_transport_available,
)
from reactor_runtime.utils.launch import run_reactor_runtime
from reactor_runtime.utils.log import get_logger
from reactor_runtime.utils.paths import _set_configured_weights_path

logger = get_logger(__name__)

_MODEL_NAME_ENV_VAR = "MODEL_NAME"
_MODEL_NAME_MAX_LENGTH = 128
_MODEL_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9-]*$")

_REACTOR_YAML = "reactor.yaml"


class RunCommand:
    @staticmethod
    def register_subcommand(subparsers):
        """Register run command with basic args. Runtime-specific args are parsed later."""
        run_parser = subparsers.add_parser(
            "run",
            help="Run reactor runtime from reactor.yaml",
            add_help=False,
        )
        run_parser.add_argument(
            "--path",
            "-p",
            type=str,
            default=None,
            help="Path to model directory (default: cwd)",
        )
        run_parser.add_argument(
            "--runtime",
            type=str,
            default="http",
            help="Runtime to use (default: http)",
        )
        run_parser.add_argument(
            "-v",
            "--verbose",
            action="store_true",
            help="Enable verbose (DEBUG) logging",
        )
        run_parser.add_argument(
            "-h",
            "--help",
            action="store_true",
            help="Show help message",
        )
        run_parser.add_argument(
            "--config-help",
            action="store_true",
            help="Show available model config options",
        )
        run_parser.add_argument(
            "--debug",
            action="store_true",
            help="Enable debugpy and wait for debugger",
        )
        run_parser.add_argument(
            "--debug-port",
            type=_valid_port,
            default=5678,
            help="debugpy port (default: 5678)",
        )
        run_parser.set_defaults(func=RunCommand)

    def __init__(self, args, remaining_args=None):
        """Initialize with parsed arguments."""
        self.args = args
        self.remaining_args = remaining_args or []

    def run(self):
        """Run the reactor runtime with the model discovered from reactor.yaml."""
        model_path = Path(self.args.path).resolve() if self.args.path else Path.cwd()

        if not model_path.exists() or not model_path.is_dir():
            print(f"Error: Invalid model path: {model_path}")
            return

        # ---------------------------------------------------------
        # Load reactor.yaml
        # ---------------------------------------------------------
        reactor_yaml_path = model_path / _REACTOR_YAML
        if not reactor_yaml_path.exists():
            print(
                f"Error: {_REACTOR_YAML} not found in {model_path}.\n"
                f"Create a {_REACTOR_YAML} with at least:\n"
                "  runtime:\n"
                "    import: module:ClassName"
            )
            return

        raw_yaml = OmegaConf.to_container(
            OmegaConf.load(str(reactor_yaml_path)), resolve=True
        )
        if not isinstance(raw_yaml, dict):
            print(f"Error: {_REACTOR_YAML} must be a YAML mapping")
            return

        try:
            reactor_config = ReactorConfig.from_dict(raw_yaml)
        except KeyError:
            print(
                f"Error: {_REACTOR_YAML} must declare a model entrypoint, "
                "either as 'runtime.import' (e.g. 'runtime:\\n  import: "
                "my_module:MyModel') or, for legacy configs, as a top-level "
                "'model: my_module:MyModel' field."
            )
            return

        # ---------------------------------------------------------
        # Model name (from YAML or env override)
        # ---------------------------------------------------------
        if not reactor_config.name:
            reactor_config.name = reactor_config.model
        env_name = os.environ.get(_MODEL_NAME_ENV_VAR)
        if env_name:
            if len(env_name) > _MODEL_NAME_MAX_LENGTH:
                print(f"Error: {_MODEL_NAME_ENV_VAR} too long")
                return
            if not _MODEL_NAME_PATTERN.match(env_name):
                print(f"Error: {_MODEL_NAME_ENV_VAR} has invalid chars")
                return
            reactor_config.name = env_name

        # ---------------------------------------------------------
        # Resolve model config path + CLI overrides
        # ---------------------------------------------------------
        model_overrides = []
        extra_args = []
        for arg in self.remaining_args:
            if arg.startswith("--model."):
                model_overrides.append(arg.replace("--model.", ""))
            else:
                extra_args.append(arg)
        self.remaining_args = extra_args

        if model_overrides and not reactor_config.config:
            print(
                "Error: --model.* overrides require a 'config' field in "
                f"{_REACTOR_YAML} (e.g. config: config.yaml)"
            )
            return

        if reactor_config.config:
            if not Path(reactor_config.config).is_absolute():
                reactor_config.config = str(model_path / reactor_config.config)
            reactor_config.config_overrides = model_overrides

        # ---------------------------------------------------------
        # Wire reactor.yaml's weights_path into the get_weights_path()
        # helper so model code can call it with no arguments and still
        # see the YAML override. Relative values are resolved against the
        # model root, mirroring how `runtime.config` is resolved above —
        # partners write `runtime.weights_path: ./weights` and have it
        # work no matter which cwd the runtime entrypoint is invoked from.
        # ~ expansion happens lazily inside get_weights_path().
        # ---------------------------------------------------------
        if reactor_config.weights_path:
            resolved = reactor_config.weights_path
            if not resolved.startswith("~") and not Path(resolved).is_absolute():
                resolved = str(model_path / resolved)
            _set_configured_weights_path(resolved)

        # Handle --config-help
        if self.args.config_help:
            if reactor_config.config:
                print_model_config_help(reactor_config.config)
            else:
                print("No config file specified in reactor.yaml")
            return

        # ---------------------------------------------------------
        # Load runtime
        # ---------------------------------------------------------
        runtime_name = self.args.runtime

        try:
            config_class, serve_fn = load_runtime(runtime_name)
        except (ModuleNotFoundError, AttributeError) as e:
            print(f"Error: {e}")
            return

        runtime_parser = config_class.parser()

        if self.args.help:
            # `--help` is what someone exec'ing into the container and
            # invoking the entrypoint by hand most often hits. Surface
            # the actual invocation form (no console script ships).
            print(
                "Usage: python -m reactor_runtime.serve run [--path DIR] [--runtime NAME] [-v/--verbose] [--debug] [runtime options]"
            )
            print("\nBase options:")
            print("  --path, -p DIR       Path to model directory (default: cwd)")
            print("  --runtime NAME       Runtime to use (default: http)")
            print("  -v, --verbose        Enable verbose (DEBUG) logging")
            print("  --debug              Enable debugpy and wait for debugger")
            print("  --debug-port PORT    debugpy port (default: 5678)")
            print(f"\nRuntime-specific options for '{runtime_name}':")
            runtime_parser.print_help()
            return

        runtime_args, unrecognized = runtime_parser.parse_known_args(
            self.remaining_args
        )
        runtime_kwargs = vars(runtime_args)

        if unrecognized:
            print(f"Error: Unrecognized arguments: {' '.join(unrecognized)}")
            sys.exit(1)

        # Transport resolution
        _ORANGE = "\033[33m"
        _RESET = "\033[0m"
        if runtime_kwargs.get("transport_type") is None:
            runtime_kwargs["transport_type"] = resolve_default_transport()
        else:
            try:
                validate_transport_available(runtime_kwargs["transport_type"])
                print(
                    f"{_ORANGE}Transport: "
                    f"{runtime_kwargs['transport_type'].name.lower()}{_RESET}"
                )
            except ImportError as exc:
                name = runtime_kwargs["transport_type"].name.lower()
                print(
                    f"{_ORANGE}Transport '{name}' not available.\n"
                    f"{exc}\n"
                    f"Install GStreamer: {GSTREAMER_INSTALL_URL}{_RESET}"
                )
                return

        # ---------------------------------------------------------
        # Debug
        # ---------------------------------------------------------
        if self.args.debug:
            try:
                import debugpy

                debugpy.listen(("localhost", self.args.debug_port))
                print(f"Debugger listening on localhost:{self.args.debug_port}")
                print("Waiting for debugger to attach...")
                debugpy.wait_for_client()
                print("Debugger attached!")
            except ImportError:
                print("Error: debugpy not installed")
                return

        # ---------------------------------------------------------
        # Run
        # ---------------------------------------------------------
        log_level = "DEBUG" if self.args.verbose else "INFO"
        detailed_logs = runtime_kwargs.pop("detailed_logs", False)

        try:
            run_reactor_runtime(
                runtime_serve_fn=serve_fn,
                reactor_config=reactor_config,
                model_root=str(model_path),
                log_level=log_level,
                show_timestamps=detailed_logs,
                **runtime_kwargs,
            )
        except KeyboardInterrupt:
            print("\nReactor runtime stopped by user.")
        except Exception as e:
            print(f"Error running reactor runtime: {e}")
            raise
