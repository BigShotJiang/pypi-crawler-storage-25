# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Subcommands exposed by the runtime entrypoint.

Each command is implemented as a class with a ``register_subcommand``
classmethod and a ``run`` instance method (HuggingFace-style). The Go
`reactor` CLI dispatches to these via container CMD overrides — workspace
scaffolding (`init`) lives in the Go CLI, not here, since it never needs
to run inside a model container.
"""

from .run import RunCommand
from .schema import SchemaCommand

__all__ = [
    "RunCommand",
    "SchemaCommand",
]
