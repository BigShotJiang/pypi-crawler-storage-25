# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Model-config helpers private to the serve entrypoint."""

from omegaconf import OmegaConf


def print_model_config_help(config_path: str) -> None:
    """Print available model configuration options from a config file.

    Renders every key in the YAML alongside its default value and the
    `--model.<key>=<value>` override syntax. Backs the
    `--config-help` flag on the run subcommand.
    """
    try:
        cfg = OmegaConf.load(config_path)
    except Exception as e:
        print(f"Error loading config file '{config_path}': {e}")
        return

    print(f"\nModel configuration options from: {config_path}")
    print("=" * 60)
    print("\nAvailable parameters (override with --model.<key>=<value>):\n")

    def _print_config(config, prefix=""):
        """Recursively print config keys with their values."""
        for key, value in config.items():
            full_key = f"{prefix}{key}" if prefix else key
            if OmegaConf.is_config(value):
                _print_config(value, prefix=f"{full_key}.")
            else:
                value_type = type(value).__name__
                print(f"  --model.{full_key}={value}")
                print(f"      Type: {value_type}, Default: {value}\n")

    _print_config(cfg)
    print("=" * 60)
