# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Typed configuration parsed from ``reactor.yaml``.

:class:`ReactorConfig` is the runtime-level configuration that identifies
the model entry point and slug.  Track topology is inferred from the
model class via the ``OUTPUT_REGISTRY`` / ``INPUT_REGISTRY``.

Emission settings (``fps``, ``buffer_size``) are declared as class
attributes on the model class, not in YAML.  Model-specific parameters
(latent dims, learning rate, etc.) live in a separate config file
pointed to by ``ReactorConfig.config``.

Two YAML shapes are supported:

* Modern (richer ``reactor.yaml`` shared with the ``reactor`` CLI)::

      model:
          name: my-model              # slug, optional
          # ...other CLI-only fields are ignored here
      runtime:
          import: my_module:MyModel   # entrypoint, required
          config: config.yaml         # optional model config
          weights_path: ./weights     # optional weights root override

* Legacy (top-level keys, kept for backwards compatibility)::

      model: my_module:MyModel        # entrypoint
      name: my-model                  # optional slug
      config: config.yaml             # optional model config
      weights_path: ./weights         # optional weights root override

  Loading a legacy file emits a one-shot deprecation warning pointing
  partners at the modern shape and the ``reactor`` Go CLI.

The runtime only reads the few fields it needs; any additional keys —
in particular the rich ``model.*`` metadata used by the ``reactor`` CLI
(``display-name``, ``description``, ``gpu``, ``extra-args``, ...) —
are deliberately ignored.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from reactor_runtime.recording.config import RecordingConfig
from reactor_runtime.utils.log import get_logger

_logger = get_logger(__name__)

# Multi-line WARNING surfaced once per process when ``from_dict`` is
# invoked on a legacy (top-level ``model``/``name``/``config``) reactor.yaml.
# The runtime keeps reading the legacy shape so partners aren't broken,
# but we want them to migrate to the richer shape — either by hand or by
# regenerating the file with the ``reactor`` Go CLI.
_LEGACY_DEPRECATION_MSG = (
    "reactor.yaml is using the legacy top-level shape "
    "(model: / name: / config:); this is DEPRECATED and will be removed "
    "in a future release. Please migrate to the modern shape:\n"
    "  model:\n"
    "    name: my-model\n"
    "  runtime:\n"
    "    import: my_module:MyModel\n"
    "    config: config.yaml\n"
    "The 'reactor' Go CLI generates this format automatically; install "
    "with `brew install reactor-team/tools/reactor-cli` and run "
    "`reactor init <name>` in a fresh workspace, or copy the new shape "
    "by hand."
)

# Module-level guard so the warning fires once per process even if multiple
# reactor.yaml files are loaded (e.g. from tests).  Reset by tests via
# ``_reset_legacy_warning_for_tests``.
_legacy_warned = False


def _reset_legacy_warning_for_tests() -> None:
    """Test helper: clear the once-per-process warning latch."""
    global _legacy_warned
    _legacy_warned = False


@dataclass
class ReactorConfig:
    """Parsed ``reactor.yaml``.

    Attributes:
        model: The model entrypoint spec, ``module:ClassName``.  Sourced
            from ``runtime.import`` (modern) or top-level ``model``
            (legacy).
        name: Model slug used on the wire (Redis streams, logs).
            Sourced from ``model.name`` (modern) or top-level ``name``
            (legacy).  Empty string when not set.
        config: Optional path to a model-specific YAML config.  Sourced
            from ``runtime.config`` (modern) or top-level ``config``
            (legacy).  The caller is responsible for resolving relative
            paths to absolute before passing to :func:`build_model`.
        config_overrides: CLI dotlist overrides
            (e.g. ``["lr=0.001", "batch=4"]``) merged on top of the
            loaded config file.
        weights_path: Optional override for the weights root consumed by
            :func:`reactor_runtime.get_weights_path`.  Sourced from
            ``runtime.weights_path`` (modern) or top-level ``weights_path``
            (legacy). When set, takes precedence over the built-in default
            but is itself overridden by ``$REACTOR_WEIGHTS_PATH``.  The
            runtime CLI resolves relative paths against the model root
            before registering this with the helper, so partners can
            commit ``runtime.weights_path: ./weights`` and have it work
            from any cwd.
        recording: Parsed ``recording:`` block (top-level in
            ``reactor.yaml``).  Defaults to a disabled recorder so
            existing models opt in by setting ``recording.enabled: true``.
    """

    model: str
    name: str = ""
    config: Optional[str] = None
    config_overrides: List[str] = field(default_factory=list)
    weights_path: Optional[str] = None
    recording: RecordingConfig = field(default_factory=RecordingConfig)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "ReactorConfig":
        """Parse a raw YAML dict into a :class:`ReactorConfig`.

        Accepts both the modern (``model:`` / ``runtime:`` sections) and
        legacy (top-level ``model`` / ``name`` / ``config``) shapes.
        Detection is based on whether ``runtime`` is a mapping or
        ``model`` is a mapping (legacy ``model`` is always a string).

        Raises:
            KeyError: when neither schema provides a model entrypoint.
        """
        runtime_section = raw.get("runtime")
        model_section = raw.get("model")

        # Recording is a top-level sibling to runtime: / model:.
        recording = RecordingConfig.from_dict(raw.get("recording"))

        modern = isinstance(runtime_section, dict) or isinstance(model_section, dict)

        if modern:
            runtime_section = (
                runtime_section if isinstance(runtime_section, dict) else {}
            )
            model_section = model_section if isinstance(model_section, dict) else {}

            entrypoint = runtime_section.get("import")
            if not entrypoint:
                raise KeyError(
                    "runtime.import is required in reactor.yaml "
                    "(e.g. 'runtime:\\n  import: my_module:MyModel')"
                )

            slug = model_section.get("name") or ""

            return cls(
                model=str(entrypoint),
                name=str(slug),
                config=runtime_section.get("config"),
                weights_path=runtime_section.get("weights_path") or None,
                recording=recording,
            )

        if "model" not in raw:
            raise KeyError("model")

        global _legacy_warned
        if not _legacy_warned:
            _legacy_warned = True
            _logger.warning(_LEGACY_DEPRECATION_MSG)

        return cls(
            model=raw["model"],
            name=raw.get("name", "") or "",
            config=raw.get("config"),
            weights_path=raw.get("weights_path") or None,
            recording=recording,
        )
