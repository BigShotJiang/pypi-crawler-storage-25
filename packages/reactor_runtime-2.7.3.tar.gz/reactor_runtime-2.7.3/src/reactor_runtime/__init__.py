# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
from importlib.metadata import version, PackageNotFoundError

from reactor_runtime.config import ReactorConfig

from reactor_runtime.interface import (
    ReactorCore,
    ReactorModel,
    Event,
    Connected,
    Disconnected,
    EVENT_REGISTRY,
    ModelMessage,
    MESSAGE_REGISTRY,
    FieldInfo,
    InputField,
    InputFrame,
    Output,
    Input,
    Video,
    Audio,
    OUTPUT_REGISTRY,
    INPUT_REGISTRY,
    OutputBuffer,
    InputBuffer,
    event,
    connected,
    disconnected,
)
from reactor_runtime.profiling.singleton import get_profiler
from reactor_runtime.utils.paths import get_weights_path

try:
    __version__ = version("reactor_runtime")
except PackageNotFoundError:
    __version__ = "0.0.0.dev"

__all__ = [
    "ReactorConfig",
    "ReactorCore",
    "ReactorModel",
    "Event",
    "Connected",
    "Disconnected",
    "EVENT_REGISTRY",
    "ModelMessage",
    "MESSAGE_REGISTRY",
    "FieldInfo",
    "InputField",
    "InputFrame",
    "Output",
    "Input",
    "Video",
    "Audio",
    "OUTPUT_REGISTRY",
    "INPUT_REGISTRY",
    "OutputBuffer",
    "InputBuffer",
    "event",
    "connected",
    "disconnected",
    "get_profiler",
    "get_weights_path",
    "__version__",
]
