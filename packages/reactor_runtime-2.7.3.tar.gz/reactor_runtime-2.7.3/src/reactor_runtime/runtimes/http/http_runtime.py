# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
HTTP Runtime for Reactor

An HTTP-based runtime that exposes REST endpoints for session management
and WebRTC for real-time video/audio/data streaming.

Used by the JS SDK's ``LocalCoordinatorClient`` for local development.

Session endpoints:
    POST   /start_session                               - Start session (returns capabilities)
    POST   /stop_session                                - Stop session

Transport endpoints:
    GET    /sessions/{id}/transport/webrtc/ice_servers   - ICE server config
    POST   /sessions/{id}/transport/webrtc/sdp_params    - Send SDP offer (async, 202)
    GET    /sessions/{id}/transport/webrtc/sdp_params    - Poll for SDP answer
    PUT    /sessions/{id}/transport/webrtc/sdp_params    - Reconnect (new SDP offer)

Other:
    GET    /health                                       - Health check
"""

import asyncio
import math
import os
import re
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Request
from importlib.metadata import version as _pkg_version, PackageNotFoundError

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from reactor_runtime.schema import ModelSchema
from reactor_runtime.config import ReactorConfig
from reactor_runtime.model_state import ModelEvent, ModelState
import uvicorn

from reactor_runtime.recording import (
    LocalDirSink,
    SessionRecorder,
)
from reactor_runtime.recording.track_resolver import resolve_track_names
from reactor_runtime.runtime_api import Runtime
from reactor_runtime.transports.media import (
    InputFrame,
    MediaBundle,
    TrackMapping,
)
from reactor_runtime.utils.log import get_logger
from reactor_runtime.transports import (
    WebRTCTransport,
    WebRTCSupersededError,
    EventType,
    MessageEvent,
    DisconnectedEvent,
    AudioFrameEvent,
    VideoFrameEvent,
    PingTimeoutEvent,
)
from reactor_runtime.transports.config import (
    resolve_default_transport,
    validate_transport_available,
)
from reactor_runtime.transports.types import (
    IceTransportPolicy,
    TransportConfig,
    WebRTCSignalingState,
)
from reactor_runtime.runtimes.http.config import HttpRuntimeConfig
from reactor_runtime.runtimes.http.types import (
    CreateUploadRequest,
    SdpOfferRequest,
    IceCandidatesRequest,
)

logger = get_logger(__name__)

try:
    _runtime_version = _pkg_version("reactor_runtime")
except PackageNotFoundError:
    _runtime_version = "0.0.0"

SESSION_ID = "local"

# Manifest endpoint only serves the canonical fMP4 file names that the
# encoder + LocalDirSink produce.  Anything else (path traversal, weird
# extensions) gets a 404.
_CHUNK_FILENAME_RE = re.compile(r"^(init\.mp4|chunk_\d{5}\.m4s)$")

# Recording session ids are always ``str(uuid.uuid4())`` (lowercase
# 8-4-4-4-12 hex; see ``_start_recorder``).  Validating the URL path
# segment against this shape before letting it concatenate into
# ``self._recordings_dir / session_id`` closes the path-traversal vector
# on both ``/clips`` and ``/clips/chunks/{session_id}/{filename}`` —
# without it, a URL-encoded ``..`` could escape the recordings root.
_RECORDING_SESSION_ID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)


def _validate_session_id(session_id: str) -> None:
    if session_id != SESSION_ID:
        raise HTTPException(status_code=404, detail="Session not found")


# =============================================================================
# HttpRuntime
# =============================================================================


class HttpRuntime(Runtime):
    """HTTP runtime with decoupled session/transport signaling.

    Implements the REST protocol matching the JS SDK v3
    (``LocalCoordinatorClient`` + ``WebRTCTransportClient``).
    """

    config: HttpRuntimeConfig

    def __init__(self, config: HttpRuntimeConfig) -> None:
        """Initialize the HTTP runtime.

        Args:
            config: HttpRuntimeConfig containing model and runtime-specific settings.
        """
        # WebRTC transport - single connection at a time
        # Protected by _client_lock for thread-safe access
        self._webrtc_client: Optional[WebRTCTransport] = None
        self._client_lock = asyncio.Lock()
        self._server: Optional[uvicorn.Server] = None

        # Local file upload store: upload_id -> {name, mime_type, size, data?}
        self._upload_store: Dict[str, Dict[str, Any]] = {}

        # Process-scoped recordings directory.  Either user-supplied
        # via ``--recordings-dir`` (persists across runtime restarts)
        # or a fresh temp dir owned by this process (cleaned up by
        # the OS on exit).  Resolved once at init time so the
        # manifest / chunk endpoints can serve files via plain
        # filesystem existence checks — no per-session registry.
        if config.recordings_dir is not None:
            self._recordings_dir = Path(config.recordings_dir)
        else:
            self._recordings_dir = Path(tempfile.mkdtemp(prefix="reactor-recordings-"))
        self._recordings_dir.mkdir(parents=True, exist_ok=True)

        # FastAPI app
        self.app = FastAPI(title="Reactor HTTP Runtime")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self._setup_routes()

        super().__init__(config)

    # ===============================
    # Route Setup
    # ===============================

    def _setup_routes(self) -> None:
        """Setup FastAPI routes for the local runtime protocol."""

        # -----------------------------------------------------------
        # Session endpoints
        # -----------------------------------------------------------

        @self.app.post("/start_session")
        async def start_session():
            """Start a session and return full capabilities immediately."""
            if self.current_state != ModelState.READY:
                raise HTTPException(
                    status_code=400,
                    detail=f"Cannot start session in state {self.current_state.value}",
                )

            model_schema = ModelSchema.from_config(
                self.config.reactor_config,
                model_cls=type(self.model) if self.model else None,
            )

            success = self.send(ModelEvent.START_SESSION)
            if not success:
                raise HTTPException(
                    status_code=400,
                    detail="Failed to start session",
                )

            return {
                "session_id": SESSION_ID,
                "cluster": "local",
                "server_info": {"server_version": _runtime_version},
                "selected_transport": {"protocol": "webrtc", "version": "1.0"},
                "model": {"name": self.config.reactor_config.name},
                "capabilities": model_schema.to_legacy_tracks_only(),
                "schema": model_schema.to_openapi(),
                "state": self.current_state.value,
            }

        @self.app.post("/stop_session")
        async def stop_session():
            """Stop the current session."""
            success = self.send(ModelEvent.STOP_SESSION)
            if not success:
                if self.current_state in (
                    ModelState.READY,
                    ModelState.CREATED,
                    ModelState.TERMINATED,
                ):
                    return JSONResponse(status_code=200, content=None)
                raise HTTPException(
                    status_code=409,
                    detail=f"Cannot stop session in state {self.current_state.value}",
                )

            return JSONResponse(status_code=200, content=None)

        # -----------------------------------------------------------
        # Transport endpoints
        # -----------------------------------------------------------

        @self.app.get("/sessions/{session_id}/transport/webrtc/ice_servers")
        async def ice_servers(session_id: str):
            """Return ICE server configuration for WebRTC peer connection."""
            _validate_session_id(session_id)
            return {"ice_servers": self.config.ice_servers_json}

        @self.app.post("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def post_sdp_params(session_id: str, request: SdpOfferRequest):
            """Accept an SDP offer and start WebRTC connection setup in the background.

            Returns 202 immediately.  The client polls
            ``GET .../sdp_params`` for the answer.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            await self._clear_existing_transport()

            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.put("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def put_sdp_params(session_id: str, request: SdpOfferRequest):
            """Reconnect with a new SDP offer.

            Same logic as POST — stops existing transport and creates a new one.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            await self._clear_existing_transport()

            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.get("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def get_sdp_params(session_id: str):
            """Poll for the SDP answer.

            Returns:
                200 with ``{ "sdp_answer": "..." }`` if the transport is ready.
                202 if the transport is still being created.
                404 if no session is active.
            """
            _validate_session_id(session_id)

            client = self._webrtc_client
            if client is not None:
                signaling = client.get_signaling()
                if not isinstance(signaling, WebRTCSignalingState):
                    raise HTTPException(
                        status_code=500,
                        detail=f"Unexpected signaling type: {type(signaling).__name__}",
                    )
                if signaling.sdp_answer is not None:
                    return {
                        "sdp_answer": signaling.sdp_answer.sdp,
                    }

            if self.current_state in (ModelState.WAITING, ModelState.ORPHANED):
                return JSONResponse(status_code=202, content=None)

            raise HTTPException(status_code=404, detail="No pending SDP offer")

        @self.app.post("/sessions/{session_id}/transport/webrtc/ice_candidates")
        async def post_ice_candidates(session_id: str, request: IceCandidatesRequest):
            """Forward a batch of trickle ICE candidates to the WebRTC transport.

            Mirrors the Coordinator contract documented in
            ``docs/REST-API.md``. Candidates that arrive before the
            transport is installed are buffered by the base
            :class:`Runtime` and replayed when the runtime enters
            STREAMING — see
            :meth:`reactor_runtime.runtime_api.Runtime.add_ice_candidate`.

            Returns 202 fire-and-forget with an empty body, or
            ``{"warning": "..."}`` if the client included ``session_id``
            in the body (which is ignored — the URL path param is
            authoritative).
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            for cand in request.candidates:
                asyncio.create_task(
                    self.add_ice_candidate(
                        cand.candidate, cand.sdp_mid, cand.sdp_mline_index
                    )
                )

            logger.info(
                f"Received {len(request.candidates)} trickle ICE candidate(s)",
                is_final=request.is_final,
            )

            response: Dict[str, Any] = {}
            if request.session_id:
                response["warning"] = (
                    "session_id in request body is ignored; "
                    "use the URL path parameter only"
                )
                logger.warning(
                    "Client sent session_id in ICE candidates body (ignored)",
                    body_session_id=request.session_id,
                )

            return JSONResponse(status_code=202, content=response)

        # -----------------------------------------------------------
        # Upload endpoints (local file store)
        # -----------------------------------------------------------

        @self.app.post("/sessions/{session_id}/uploads")
        async def create_upload(session_id: str, req: CreateUploadRequest):
            """Allocate a local upload slot (mirrors Coordinator endpoint)."""
            _validate_session_id(session_id)
            if not req.name:
                raise HTTPException(status_code=400, detail="name is required")
            if not req.mime_type:
                raise HTTPException(status_code=400, detail="mime_type is required")
            if req.size <= 0:
                raise HTTPException(status_code=400, detail="size must be > 0")

            upload_id = str(uuid.uuid4())
            self._upload_store[upload_id] = {
                "name": req.name,
                "mime_type": req.mime_type,
                "size": req.size,
            }
            port = self.config.port
            upload_url = f"http://localhost:{port}/uploads/{upload_id}"
            path = f"sessions/{session_id}/uploads/{upload_id}/{req.name}"
            logger.info(
                "Upload slot created",
                upload_id=upload_id,
                name=req.name,
            )
            return JSONResponse(
                status_code=201,
                content={
                    "presigned_id": upload_id,
                    "presigned_url": upload_url,
                    "path": path,
                },
            )

        @self.app.put("/uploads/{upload_id}")
        async def put_upload(upload_id: str, request: Request):
            """Receive file bytes for a previously allocated upload slot."""
            if upload_id not in self._upload_store:
                raise HTTPException(status_code=404, detail="Upload not found")
            entry = self._upload_store[upload_id]
            if "data" in entry:
                raise HTTPException(status_code=409, detail="Upload already completed")
            body = await request.body()
            expected_size = entry.get("size", 0)
            if expected_size and len(body) != expected_size:
                raise HTTPException(
                    status_code=400,
                    detail=f"Content-Length mismatch: expected {expected_size}, got {len(body)}",
                )
            entry["data"] = body
            logger.info(
                "Upload received",
                upload_id=upload_id,
                size=len(body),
            )
            return JSONResponse(status_code=200, content=None)

        # -----------------------------------------------------------
        # Recording: manifest + chunk endpoints
        # -----------------------------------------------------------

        @self.app.get("/clips")
        async def get_clip_manifest(session_id: str, start: float, end: float):
            """Compose an HLS ``.m3u8`` manifest for a marker range.

            Mirrors the production Coordinator endpoint contract
            (200 / 202 / 410) so the JS SDK never special-cases local
            vs prod.  Locally we point chunk URLs at our own
            ``/clips/chunks/...`` route — no S3, no presigning.

            ``kind`` (``snap`` vs ``recording``) is intentionally NOT a
            URL parameter — the manifest is fully described by
            ``(session_id, start, end)`` and the chunks on disk.  The
            discriminator lives only on the ``clipReady`` response body
            so clients can route their own UI without re-parsing URLs.
            """
            return self._build_clip_manifest(
                session_id=session_id, start=start, end=end
            )

        @self.app.get("/clips/chunks/{session_id}/{filename}")
        async def get_clip_chunk(session_id: str, filename: str):
            """Serve a single fMP4 segment from local disk."""
            if not _RECORDING_SESSION_ID_RE.match(session_id):
                raise HTTPException(
                    status_code=410, detail="Session unknown or aged out"
                )
            if not _CHUNK_FILENAME_RE.match(filename):
                raise HTTPException(status_code=404, detail="Not found")
            sess_dir = self._recordings_dir / session_id
            if not sess_dir.is_dir():
                raise HTTPException(
                    status_code=410, detail="Session unknown or aged out"
                )
            file_path = sess_dir / filename
            if not file_path.is_file():
                raise HTTPException(status_code=404, detail="Chunk not found")
            return FileResponse(
                file_path,
                media_type=(
                    "video/mp4" if filename == "init.mp4" else "video/iso.segment"
                ),
            )

        # -----------------------------------------------------------
        # Health check
        # -----------------------------------------------------------

        @self.app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "model": self.config.reactor_config.name,
                "state": self.current_state.value,
            }

    # ===============================
    # WebRTC Connection Management
    # ===============================

    async def _clear_existing_transport(self) -> None:
        """Stop and null the current WebRTC client, clearing stale signaling state.

        Fires ``CLIENT_DISCONNECTED`` if a transport was active so the
        state machine transitions correctly (e.g. ``STREAMING`` →
        ``ORPHANED``).

        Called by the POST/PUT ``sdp_params`` endpoints *before*
        spawning ``_create_transport_background``, so the teardown
        happens synchronously in the request handler while the creation
        runs as a fire-and-forget background task.
        """
        async with self._client_lock:
            if self._webrtc_client is not None:
                logger.info("Stopping existing WebRTC client")
                self._webrtc_client.stop()
                self._webrtc_client = None
                self.send(ModelEvent.CLIENT_DISCONNECTED)

    async def _create_transport_background(
        self, sdp_offer: str, track_mapping: TrackMapping
    ) -> None:
        """Background task: create a WebRTC transport and install it.

        **Concurrency model — why a post-creation lock check is needed:**

        Teardown and creation are split across two steps:

        1. *Teardown* (in the request handler): the POST/PUT endpoint
           calls ``_clear_existing_transport`` synchronously before
           spawning this background task.
        2. *Creation* (this method, fire-and-forget):
           ``WebRTCTransport.create()`` is async and yields to the event
           loop (SDP exchange, ICE gathering).  During this window the
           client can send another POST/PUT which tears down again and
           spawns a second background task.  Two tasks now race to
           install their transport.

        When installation re-acquires ``_client_lock``, two guards
        prevent stale transports from being installed:

        - ``_webrtc_client is not None``: the other background task
          already won the race and installed its transport.  Ours is
          stale — stop it and return.
        - ``send(CLIENT_CONNECTED)`` returns ``False``: the session was
          stopped or timed out while we were creating the transport, so
          the state machine rejects the transition.  The transport is
          no longer needed — stop it.

        ``WebRTCSupersededError`` can also be raised from *inside*
        ``WebRTCTransport.create()`` if the transport backend detects
        its stop event was set during setup (e.g. runtime shutdown).
        This is a benign abort — the transport was no longer needed.

        On any failure the error is logged but not re-raised; the orphan
        timeout (managed by ``runtime_api.py``) will eventually clean up
        the session.

        Args:
            sdp_offer: The SDP offer string.
            track_mapping: Track mapping from the client.
        """
        try:
            logger.info("Creating new WebRTC connection (background)")
            transport = await WebRTCTransport.create(
                self.config.transport_type,
                sdp_offer=sdp_offer,
                track_mapping=track_mapping,
                config=TransportConfig(
                    ice_servers=self.config.ice_servers,
                    port_range=self.config.webrtc_port_range,
                    transport_policy=self.config.ice_transport_policy,
                    ping_timeout_seconds=self.config.ping_timeout,
                ),
            )

            async with self._client_lock:
                if self._webrtc_client is not None:
                    transport.stop()
                    logger.warning("Connection superseded by concurrent request")
                    return

                success = self.send(ModelEvent.CLIENT_CONNECTED, client=transport)
                if not success:
                    transport.stop()
                    logger.warning(
                        "Session expired while waiting for client connection",
                        state=self.current_state.value,
                    )
                    return

        except WebRTCSupersededError:
            logger.warning("WebRTC connection was superseded during creation")
        except Exception as e:
            logger.exception("Failed to create WebRTC transport (background)", error=e)

    def _setup_webrtc_handlers(self, client: WebRTCTransport) -> None:
        """Setup event handlers for a WebRTC client."""

        def on_message(event: MessageEvent):
            """Handle incoming data channel message."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_data_channel_message(event.data), self.loop
                )

        def on_disconnect(event: DisconnectedEvent):
            if not self.loop.is_closed():
                logger.info("WebRTC disconnected", reason=event.reason)
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        def on_video_frame(event: VideoFrameEvent):
            self._on_incoming_video_frame(event.frame, event.track_name)

        def on_audio_frame(event: AudioFrameEvent):
            self._on_incoming_audio_frame(event.frame, event.track_name)

        def on_ping_timeout(event: PingTimeoutEvent):
            if not self.loop.is_closed():
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        client.on(EventType.MESSAGE, on_message)
        client.on(EventType.DISCONNECTED, on_disconnect)
        client.on(EventType.VIDEO_FRAME, on_video_frame)
        client.on(EventType.AUDIO_FRAME, on_audio_frame)
        client.on(EventType.PING_TIMEOUT, on_ping_timeout)

    async def _stop_webrtc_client(self) -> None:
        """Stop and clear the current WebRTC client."""
        async with self._client_lock:
            if self._webrtc_client is not None:
                self._webrtc_client.stop()
                self._webrtc_client = None

    async def _on_data_channel_message(self, message: str) -> None:
        """Handle incoming data channel message.
        Delegates to the common handler in the abstract Runtime class.
        """
        await self._handle_incoming_data_channel_message(message)

    async def _download_uploaded_file(self, upload_id: str) -> bytes:
        """Read an uploaded file from the local in-memory store.

        The data is retained so the same upload can be read multiple times
        within a session.  The entire store is cleared on session cleanup.
        """
        entry = self._upload_store.get(upload_id)
        if entry is None or "data" not in entry:
            raise FileNotFoundError(f"Upload {upload_id} not found in local store")
        return entry["data"]

    def _on_ping_received(self) -> None:
        """Forward client ping to the WebRTC client's watchdog."""
        if self._webrtc_client:
            self._webrtc_client.notify_ping()

    def _on_incoming_video_frame(
        self, frame: InputFrame, track_name: str = "video"
    ) -> None:
        """Handle an incoming video :class:`InputFrame` from the WebRTC transport.

        Routes the frame into the model's per-track :class:`InputBuffer`,
        preserving ``pts`` so model code can read it via
        ``(await self.input.<track>.read(n))[i].pts``.
        """
        if self.model is not None:
            self.model._push_media(track_name, frame)

    def _on_incoming_audio_frame(
        self, frame: InputFrame, track_name: str = "audio"
    ) -> None:
        """Handle an incoming audio :class:`InputFrame` from the WebRTC transport.

        Routes the frame into the model's per-track :class:`InputBuffer`,
        preserving ``pts`` so model code can align audio chunks with
        video frames by timestamp.
        """
        if self.model is not None:
            self.model._push_media(track_name, frame)

    # -----------------------------------------------------------------
    # Transport abstract method implementations
    # -----------------------------------------------------------------

    def _active_webrtc_client(self) -> Optional[WebRTCTransport]:
        """Expose the live WebRTC transport to the base ``Runtime``
        so trickle ICE candidates can be buffered and forwarded — see
        :meth:`reactor_runtime.runtime_api.Runtime.add_ice_candidate`.
        """
        return self._webrtc_client

    async def send_out_app_message(self, data: dict) -> None:
        """Send an application message via the WebRTC data channel."""
        client = self._webrtc_client
        if client is not None:
            client.send_message(data)

    async def send_out_runtime_message(self, data: dict) -> None:
        """Send a runtime message via the WebRTC data channel."""
        client = self._webrtc_client
        if client is not None:
            client.send_message(data)

    async def send_out_app_bundle(
        self, media_bundle: MediaBundle, duplicate: bool
    ) -> None:
        """Send a multi-track media bundle via the WebRTC transport.

        Silently skips if no WebRTC connection is active.
        """
        client = self._webrtc_client
        if client is not None:
            client.send_media(media_bundle)

    # -----------------------------------------------------------------
    # Recording: lifecycle + manifest helpers
    # -----------------------------------------------------------------

    def _build_clip_manifest(
        self, *, session_id: str, start: float, end: float
    ) -> Response:
        """Resolve a marker range to an HLS ``.m3u8`` body.

        Returns a FastAPI :class:`Response` with the appropriate status:

        * ``200`` — chunks are on disk; manifest body returned.
        * ``202`` + ``Retry-After`` — boundary chunk hasn't been
          uploaded yet (mirrors the prod ``S3 HEAD`` race).
        * ``410`` — session unknown or aged out.

        ``chunk_seconds`` is read from the runtime's current
        :class:`RecordingConfig`.  This is fine because the value is
        process-scoped: the HTTP runtime lives one config to one
        process, and ``chunk_seconds`` doesn't change during a run.
        Pointing the runtime at a persistent ``--recordings-dir``
        whose chunks were produced under a different ``chunk_seconds``
        is unsupported — manifest math will be wrong by design.
        """
        if not _RECORDING_SESSION_ID_RE.match(session_id):
            raise HTTPException(status_code=410, detail="Session unknown or aged out")

        if not (math.isfinite(start) and start >= 0):
            raise HTTPException(
                status_code=400,
                detail="start must be a finite non-negative number",
            )
        if not (math.isfinite(end) and end > start):
            raise HTTPException(
                status_code=400,
                detail="end must be a finite number greater than start",
            )

        chunk_seconds = self.config.reactor_config.recording.chunk_seconds
        if chunk_seconds <= 0:
            raise HTTPException(status_code=500, detail="Invalid chunk_seconds")

        sess_dir = self._recordings_dir / session_id
        if not sess_dir.is_dir():
            raise HTTPException(status_code=410, detail="Session unknown or aged out")

        chunk_start_idx = max(0, math.floor(start / chunk_seconds))
        chunk_end_idx = max(chunk_start_idx, math.ceil(end / chunk_seconds) - 1)

        boundary_chunk = sess_dir / f"chunk_{chunk_end_idx:05d}.m4s"
        if not boundary_chunk.is_file():
            return Response(status_code=202, headers={"Retry-After": "2"})
        if not (sess_dir / "init.mp4").is_file():
            return Response(status_code=202, headers={"Retry-After": "2"})

        lines = [
            "#EXTM3U",
            "#EXT-X-VERSION:7",
            f"#EXT-X-TARGETDURATION:{chunk_seconds}",
            "#EXT-X-PLAYLIST-TYPE:VOD",
            f'#EXT-X-MAP:URI="/clips/chunks/{session_id}/init.mp4"',
        ]
        for idx in range(chunk_start_idx, chunk_end_idx + 1):
            lines.append(f"#EXTINF:{chunk_seconds:.3f},")
            lines.append(f"/clips/chunks/{session_id}/chunk_{idx:05d}.m4s")
        lines.append("#EXT-X-ENDLIST")
        body = "\n".join(lines) + "\n"
        return Response(
            content=body,
            status_code=200,
            media_type="application/vnd.apple.mpegurl",
        )

    def _start_recorder(self) -> None:
        """Build a :class:`SessionRecorder` and register it on the OutputBuffer.

        Best-effort: any failure here logs and skips recording rather
        than failing the session (the wire path must work even if
        recording can't be set up).
        """
        rec_cfg = self.config.reactor_config.recording
        if not rec_cfg.enabled or self.model is None:
            return

        video_track, audio_track, audio_sample_rate = resolve_track_names(rec_cfg)
        if video_track is None:
            logger.warning(
                "Recording enabled but no video track resolved; skipping recorder",
                reactor_recording_video_track=rec_cfg.video_track,
            )
            return

        served_dir = self._recordings_dir
        session_id = str(uuid.uuid4())
        sink = LocalDirSink(target_dir=served_dir, session_id=session_id)
        encoder_dir = served_dir / f"_encoder-{session_id}"

        try:
            recorder = SessionRecorder(
                config=rec_cfg,
                session_id=session_id,
                sink=sink,
                video_track_name=video_track,
                audio_track_name=audio_track,
                audio_sample_rate=audio_sample_rate,
                work_dir=encoder_dir,
            )
            # Register the callback BEFORE starting the recorder so a
            # failure between the two steps is either a no-op
            # (registration failed → recorder never started) or a
            # missing-callback gap (start failed → registered callback
            # writes to a queue whose drain thread isn't running). Both
            # are observable from ``self.recorder is None``; the
            # opposite order leaks the encoder + uploader threads when
            # ``add_callback`` raises after a successful ``start``.
            self.model.output_buffer.add_callback(recorder._on_bundle_sync)
            recorder.start()
        except Exception:
            logger.exception("Failed to start session recorder; continuing without")
            # Best-effort detach so the callback doesn't fire into a
            # half-built recorder if start raised. ``remove_callback``
            # is idempotent (REA-1948) so calling it before
            # ``add_callback`` ran is safe.
            try:
                self.model.output_buffer.remove_callback(recorder._on_bundle_sync)
            except Exception:
                pass
            return

        self.recorder = recorder
        logger.info(
            "Session recorder armed",
            recording_session_id=session_id,
            served_dir=str(served_dir),
            video_track=video_track,
            audio_track=audio_track or "<none>",
        )

    def _stop_recorder(self) -> None:
        """Tear down the active recorder; safe to call when none exists.

        Per-session state (the ``<recordings_dir>/<session_id>/``
        folder) lives on the filesystem and is *not* cleaned up here
        — historical clips remain queryable via ``/clips`` for the
        lifetime of the runtime process (or longer when the operator
        passes a persistent ``--recordings-dir``).
        """
        recorder = self.recorder
        if recorder is None:
            return
        if self.model is not None:
            try:
                self.model.output_buffer.remove_callback(recorder._on_bundle_sync)
            except Exception:
                logger.exception("Failed to remove recorder callback")
        try:
            recorder.stop()
        except Exception:
            logger.exception("Failed to stop session recorder")
        self.recorder = None

    # -----------------------------------------------------------------
    # State machine hooks
    # -----------------------------------------------------------------

    def on_before_start_session(self, **kwargs) -> None:
        """Wire up the recorder before the state machine flips to WAITING."""
        self._start_recorder()

    def on_before_stop_session(self, **kwargs) -> None:
        self._stop_recorder()
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_client_connected(self, **kwargs) -> None:
        """Handler called before the client connected event is sent.
        Installs the client setting up event handlers.
        """
        client = kwargs.get("client")
        assert client is not None, "Client must be provided"
        self._setup_webrtc_handlers(client)
        self._webrtc_client = client
        client.start_ping_watchdog()

    def on_before_client_disconnected(self, **kwargs) -> None:
        """Cleanup called after the WebRTC client is disconnected.
        This frees the resource used by the WebRTC client thread.
        """
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_cleanup_complete(self, **kwargs) -> None:
        # Belt-and-braces stop: also tear the recorder down here so
        # session-end paths that bypass STOP_SESSION (notably the
        # orphan-timeout path ORPHANED → CLOSING via TIMEOUT) can't
        # leak the recorder.  ``_stop_recorder`` is idempotent so the
        # normal STOP_SESSION path is a no-op here.  REA-2338.
        self._stop_recorder()
        self._upload_store.clear()

    # -----------------------------------------------------------------
    # State-machine hooks
    # -----------------------------------------------------------------

    def on_enter_TERMINATED(self, previous_state: ModelState) -> None:
        super().on_enter_TERMINATED(previous_state)
        if self._server is not None:
            self._server.should_exit = True

    # -----------------------------------------------------------------
    # State hooks
    # -----------------------------------------------------------------

    def on_before_initialization_success(self, **kwargs) -> None:
        aqua, reset = "\033[96m", "\033[0m"
        url = f"http://{self.config.host}:{self.config.port}"
        logger.info("Started runtime process", pid=os.getpid())
        logger.info(f"Reactor runtime running on {aqua}{url}{reset}")

    # -----------------------------------------------------------------
    # run()
    # -----------------------------------------------------------------

    async def run(self) -> None:
        """Main entry point to run the HTTP runtime.
        Starts the FastAPI server with uvicorn.
        """
        uvicorn_config = uvicorn.Config(
            app=self.app,
            host=self.config.host,
            port=self.config.port,
            log_level="warning",
            access_log=False,
        )
        self._server = uvicorn.Server(uvicorn_config)

        try:
            await self._server.serve()
        except KeyboardInterrupt:
            logger.info("HTTP runtime interrupted")
        finally:
            self._server = None
            await self._stop_webrtc_client()
            await self.shutdown()


# ---------------------------------------------------------------------------
# serve() entry point (called by the CLI)
# ---------------------------------------------------------------------------


async def serve(
    reactor_config: ReactorConfig,
    **kwargs,
) -> None:
    """Entry point for running the HTTP runtime from a CLI.

    Args:
        reactor_config: Parsed reactor.yaml configuration (with ``config``
            resolved to an absolute path and ``config_overrides`` populated).
        **kwargs: Runtime-specific arguments from HttpRuntimeConfig.parser()
            - host: Host to bind to (default: "0.0.0.0")
            - port: Port to bind to (default: 8080)
            - orphan_timeout: Seconds to wait before stopping orphaned session (default: 30.0)
            - ping_timeout: WebRTC client ping watchdog seconds (default from RuntimeConfig; 0 disables)
            - webrtc_port_range: WebRTC ICE UDP port range as tuple (min, max) (default: None)
            - stun_servers: List of STUN server URLs (default: None, uses Google STUN)
            - turn_servers: List of TURN servers in format "username;credential;url" (default: None)
            - transport_type: WebRTC transport backend (default: None -> auto-detect)
    """
    transport_type = kwargs.get("transport_type")
    if transport_type is not None:
        try:
            validate_transport_available(transport_type)
        except ImportError as e:
            raise RuntimeError(
                f"Transport '{transport_type.name}' not available: {e}"
            ) from e
    else:
        transport_type = resolve_default_transport()

    config = HttpRuntimeConfig(
        reactor_config=reactor_config,
        host=kwargs.get("host", "0.0.0.0"),
        port=kwargs.get("port", 8080),
        orphan_timeout=kwargs.get("orphan_timeout", 30.0),
        ping_timeout=kwargs.get("ping_timeout"),
        webrtc_port_range=kwargs.get("webrtc_port_range"),
        stun_servers=kwargs.get("stun_servers"),
        turn_servers=kwargs.get("turn_servers"),
        ice_transport_policy=kwargs.get("ice_transport_policy", IceTransportPolicy.ALL),
        transport_type=transport_type,
        profiling_output_dir=kwargs.get("profiling_output_dir"),
        record=kwargs.get("record", False),
        recordings_dir=kwargs.get("recordings_dir"),
    )

    runtime = HttpRuntime(config)
    asyncio.create_task(runtime.load())
    await runtime.run()
