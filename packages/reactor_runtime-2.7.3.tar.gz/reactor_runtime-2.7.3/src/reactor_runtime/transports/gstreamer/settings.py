# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
GStreamer transport settings.

Configuration used by the GStreamer WebRTC client (e.g. supported video/audio codecs
for SDP negotiation, RTP header extensions, encoder/decoder selection, and
:data:`HW_CODECS_ENABLED`). Hardware codecs default off unless
:data:`ENV_GST_HW_CODECS_ENABLED` is set to a truthy value (``1``, ``true``, ``yes``, ``on``).

Video BWE defaults (kbps) for :class:`~reactor_runtime.transports.gstreamer.sender.video.VideoSender`
when using ``rtpgccbwe`` can be overridden with positive integer environment variables:
:data:`ENV_GST_VIDEO_BWE_MIN_BITRATE_KBPS`, :data:`ENV_GST_VIDEO_BWE_MAX_BITRATE_KBPS`,
:data:`ENV_GST_VIDEO_BWE_TARGET_BITRATE_KBPS`. Invalid or missing values keep the built-in
default for that field; if after overrides ``min > max``, min/max fall back to defaults
and the target is clamped to ``[min, max]``.

When applying GCC bandwidth estimates, the transport first compares the estimate to the
sum of current video sender targets; if the relative gap is at most
:data:`VIDEO_BWE_TARGET_UPDATE_RELATIVE_THRESHOLD`, encoders are left unchanged. Otherwise
the estimate is split evenly across video senders (remainder distributed one kbps at a time).

:data:`ENV_GST_VIDEO_RTX_MAX_SIZE_PACKETS` (positive integer) and
:data:`ENV_GST_VIDEO_RTX_MAX_SIZE_TIME_MS` (non-negative integer, milliseconds) tune
``rtprtxsend`` retransmission history (``max-size-packets`` and ``max-size-time`` in
GStreamer). ``GST_VIDEO_RTX_MAX_SIZE_TIME_MS=0`` means no time limit. Invalid values keep
the built-in default for that field.

:data:`ENV_GST_SUPPORTED_VIDEO_CODECS_PRIORITY` optionally reorders and filters
:data:`_SUPPORTED_VIDEO_CODECS`. Tokens are comma-separated. Each token is either
a codec name (e.g. ``VP8``) matching a built-in ``codec`` field exactly, or
``NAME:fmtp`` where ``fmtp`` uses SDP-style ``key=value`` pairs separated by
``;``. A token with ``:`` selects the **first** row in ``_SUPPORTED_VIDEO_CODECS`` with
that ``codec`` where every parsed ``key=value`` matches that row's
``parameters`` (unknown keys or values mean the token is skipped). A bare codec
name selects **every** built-in row with that ``codec``, in list order.
Whitespace-only or empty after parsing leaves the default order unchanged. If
the env var is set but **no** token resolves to a built-in row, the default list
is used and a warning is logged.
"""

import os
from typing import Dict, List, Optional, Set, Tuple

from reactor_runtime.transports.gstreamer.sdp.codec import (
    CodecEntry,
    parse_fmtp_params,
)
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

# =========================================================================
# Environment variables
# =========================================================================

# If unset, hardware codecs are off. Set to 1/true/yes/on to enable NVENC/NVDEC/etc.
ENV_GST_HW_CODECS_ENABLED = "GST_HW_CODECS_ENABLED"

# Optional overrides for VideoSender BWE bitrates (kbps). Must be positive decimal integers.
ENV_GST_VIDEO_BWE_MIN_BITRATE_KBPS = "GST_VIDEO_BWE_MIN_BITRATE_KBPS"
ENV_GST_VIDEO_BWE_MAX_BITRATE_KBPS = "GST_VIDEO_BWE_MAX_BITRATE_KBPS"
ENV_GST_VIDEO_BWE_TARGET_BITRATE_KBPS = "GST_VIDEO_BWE_TARGET_BITRATE_KBPS"

# Optional rtprtxsend retransmission buffer (see _resolve_video_rtx_buffer).
ENV_GST_VIDEO_RTX_MAX_SIZE_PACKETS = "GST_VIDEO_RTX_MAX_SIZE_PACKETS"
ENV_GST_VIDEO_RTX_MAX_SIZE_TIME_MS = "GST_VIDEO_RTX_MAX_SIZE_TIME_MS"

# Optional sort for supported video codecs (order of preference).
ENV_GST_SUPPORTED_VIDEO_CODECS_PRIORITY = "GST_SUPPORTED_VIDEO_CODECS_PRIORITY"

# =========================================================================
# Video BWE
# =========================================================================
_DEFAULT_VIDEO_BWE_MIN_BITRATE_KBPS = 500
_DEFAULT_VIDEO_BWE_MAX_BITRATE_KBPS = 10000
_DEFAULT_VIDEO_BWE_TARGET_BITRATE_KBPS = 4000


def _parse_positive_int_env(name: str) -> Optional[int]:
    raw = os.getenv(name)
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    if not s.isdecimal():
        return None
    v = int(s)
    if v <= 0:
        logger.warning(f"Invalid positive integer environment variable: {name}={s}")
        return None
    return v


def _parse_non_negative_int_env(name: str) -> Optional[int]:
    """Parse a decimal integer environment variable; ``0`` is valid."""
    raw = os.getenv(name)
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    if not s.isdecimal():
        return None
    return int(s)


def _resolve_video_bwe_bitrates() -> Tuple[int, int, int]:
    min_kbps = (
        _parse_positive_int_env(ENV_GST_VIDEO_BWE_MIN_BITRATE_KBPS)
        or _DEFAULT_VIDEO_BWE_MIN_BITRATE_KBPS
    )
    max_kbps = (
        _parse_positive_int_env(ENV_GST_VIDEO_BWE_MAX_BITRATE_KBPS)
        or _DEFAULT_VIDEO_BWE_MAX_BITRATE_KBPS
    )
    target_kbps = (
        _parse_positive_int_env(ENV_GST_VIDEO_BWE_TARGET_BITRATE_KBPS)
        or _DEFAULT_VIDEO_BWE_TARGET_BITRATE_KBPS
    )
    if min_kbps > max_kbps:
        min_kbps = _DEFAULT_VIDEO_BWE_MIN_BITRATE_KBPS
        max_kbps = _DEFAULT_VIDEO_BWE_MAX_BITRATE_KBPS
    target_kbps = max(min_kbps, min(max_kbps, target_kbps))
    return min_kbps, max_kbps, target_kbps


# Resolved at import time (kbps) for rtpgccbwe / VideoSender.
(
    VIDEO_BWE_MIN_BITRATE_KBPS,
    VIDEO_BWE_MAX_BITRATE_KBPS,
    VIDEO_BWE_TARGET_BITRATE_KBPS,
) = _resolve_video_bwe_bitrates()

# GCC estimate vs. aggregate current video bitrate: skip redistribution when relative
# difference is at most this value (see ``GStreamerTransport._on_bwe_estimate``).
VIDEO_BWE_TARGET_UPDATE_RELATIVE_THRESHOLD = 0.05


# =========================================================================
# Video RTX (rtprtxsend history)
# =========================================================================
_DEFAULT_VIDEO_RTX_MAX_SIZE_PACKETS = 512
_DEFAULT_VIDEO_RTX_MAX_SIZE_TIME_MS = 200


def _resolve_video_rtx_buffer() -> Tuple[int, int]:
    """
    Return ``(max_size_packets, max_size_time_ms)`` for ``rtprtxsend``.

    ``max_size_time_ms`` of ``0`` is passed through to mean unlimited retention time
    in the element (GStreamer ``max-size-time`` = 0).
    """
    packets = (
        _parse_positive_int_env(ENV_GST_VIDEO_RTX_MAX_SIZE_PACKETS)
        or _DEFAULT_VIDEO_RTX_MAX_SIZE_PACKETS
    )
    time_ms = _parse_non_negative_int_env(ENV_GST_VIDEO_RTX_MAX_SIZE_TIME_MS)
    if time_ms is None:
        time_ms = _DEFAULT_VIDEO_RTX_MAX_SIZE_TIME_MS
    return packets, time_ms


VIDEO_RTX_MAX_SIZE_PACKETS, VIDEO_RTX_MAX_SIZE_TIME_MS = _resolve_video_rtx_buffer()


# =========================================================================
# Hardware codecs
# =========================================================================
def _hw_codecs_enabled_from_env() -> bool:
    raw = os.getenv(ENV_GST_HW_CODECS_ENABLED)
    if raw is None:
        return False
    return raw.strip().lower() in ("1", "true", "yes", "on")


# When False, video encoder/decoder bins use software elements only (e.g. x264/x265,
# libav decoders), not GPU-backed plugins (NVENC, NVDEC, VA-API, etc.).
HW_CODECS_ENABLED: bool = _hw_codecs_enabled_from_env()

# =========================================================================
# Supported video codecs
# =========================================================================

# Default supported video codecs (order by priority)
_SUPPORTED_VIDEO_CODECS: List[CodecEntry] = [
    {"codec": "VP9", "parameters": {"profile-id": "0"}},
    {"codec": "VP8"},
    {
        "codec": "H264",
        "parameters": {
            "profile-level-id": "42e01f",
            "packetization-mode": "1",
        },
    },
    {"codec": "AV1", "parameters": {"profile": "0"}},
    {"codec": "H265"},
]


def _builtin_str_params(entry: CodecEntry) -> Dict[str, str]:
    """Return ``parameters`` as ``Dict[str, str]`` for matching."""
    p = entry.get("parameters")
    if not isinstance(p, dict):
        return {}
    return {k: v for k, v in p.items() if isinstance(k, str) and isinstance(v, str)}


def _entry_row_key(entry: CodecEntry) -> Tuple[str, Tuple[Tuple[str, str], ...]]:
    """Stable key for deduplicating resolved built-in rows."""
    codec = entry.get("codec")
    c = codec if isinstance(codec, str) else ""
    params = _builtin_str_params(entry)
    return (c, tuple(sorted(params.items())))


def _find_builtin_rows_for_priority_token(
    codec_name: str, token_params: Dict[str, str]
) -> List[CodecEntry]:
    """
    Return copies of :class:`CodecEntry` rows in ``_SUPPORTED_VIDEO_CODECS`` that
    this env token may select (possibly empty).

    ``codec_name`` must equal each row's ``codec`` field. If ``token_params`` is
    empty, every row with that codec is returned, in list order. Otherwise each
    key/value in ``token_params`` must match that row's parameters (extra keys on
    the row are allowed); only the **first** such row is returned.
    """
    matches: List[CodecEntry] = []
    for entry in _SUPPORTED_VIDEO_CODECS:
        c = entry.get("codec")
        if not isinstance(c, str) or c != codec_name:
            continue
        builtin_params = _builtin_str_params(entry)
        if not token_params:
            matches.append(dict(entry))
            continue
        ok = True
        for k, want in token_params.items():
            if builtin_params.get(k) != want:
                ok = False
                break
        if ok:
            matches.append(dict(entry))
            break
    return matches


def _split_codec_priority_token(token: str) -> Tuple[str, Dict[str, str]]:
    """
    Parse one comma-separated priority token into codec name and fmtp overrides.

    ``VP8`` → (``VP8``, {}). ``H264:profile-level-id=42e01f;packetization-mode=1``
    → (``H264``, ``{...}``). Only ``key=value`` pairs are kept (flags without
    ``=`` are dropped), matching
    :func:`~reactor_runtime.transports.gstreamer.sdp.codec.parse_fmtp_params`.
    """
    s = token.strip()
    if not s:
        return ("", {})
    if ":" not in s:
        return (s, {})
    name, _, rest = s.partition(":")
    name = name.strip()
    if not name:
        return ("", {})
    parsed = parse_fmtp_params(rest)
    params = {k: v for k, v in parsed.items() if v is not None and isinstance(v, str)}
    return (name, params)


def _supported_video_codecs_from_env() -> List[CodecEntry]:
    """
    Return :data:`_SUPPORTED_VIDEO_CODECS` ordered and filtered by
    :data:`ENV_GST_SUPPORTED_VIDEO_CODECS_PRIORITY` when set.

    The env value is comma-separated. Each token selects one or more rows from
    ``_SUPPORTED_VIDEO_CODECS`` (see :func:`_find_builtin_rows_for_priority_token`).
    Tokens that resolve to no rows are skipped. Order follows the env string,
    then built-in list order within a bare-codec token. The same built-in row is
    not added twice (duplicate tokens / duplicate selections). If the env var is
    unset, empty, or contains no non-empty tokens, returns a copy of
    ``_SUPPORTED_VIDEO_CODECS``. If the env var is set but no token resolves to a
    row, logs a warning and returns a copy of ``_SUPPORTED_VIDEO_CODECS``.
    """
    raw = os.getenv(ENV_GST_SUPPORTED_VIDEO_CODECS_PRIORITY)
    if raw is None or not raw.strip():
        return list(_SUPPORTED_VIDEO_CODECS)

    tokens = [p.strip() for p in raw.split(",") if p.strip()]
    if not tokens:
        return list(_SUPPORTED_VIDEO_CODECS)

    ordered: List[CodecEntry] = []
    seen_rows: Set[Tuple[str, Tuple[Tuple[str, str], ...]]] = set()
    for token in tokens:
        codec_name, env_params = _split_codec_priority_token(token)
        if not codec_name:
            continue
        for matched in _find_builtin_rows_for_priority_token(codec_name, env_params):
            key = _entry_row_key(matched)
            if key in seen_rows:
                continue
            ordered.append(matched)
            seen_rows.add(key)

    if not ordered:
        logger.warning(
            f"GST_SUPPORTED_VIDEO_CODECS_PRIORITY={raw!r} matched no supported "
            f"codecs; using default codec list"
        )
        return list(_SUPPORTED_VIDEO_CODECS)

    return ordered


# Ordered list of supported video codecs for SDP offer/answer and encoder selection.
# The first entry that appears in the remote SDP offer is chosen.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_VIDEO_CODECS: List[CodecEntry] = _supported_video_codecs_from_env()


# Ordered list of supported audio codecs for SDP filtering.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_AUDIO_CODECS: List[CodecEntry] = [
    {"codec": "Opus"},
]

# =========================================================================
# RTP header extensions
# =========================================================================

# RTP header extension URIs we mirror in answers and on outgoing video RTP caps when
# the peer offer includes them (order preserved). Add entries to negotiate more.
RTP_HEADER_EXTENSION_URI_TRANSPORT_WIDE_CC = (
    "http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01"
)

SUPPORTED_RTP_HEADER_EXTENSION_URIS: Tuple[str, ...] = (
    RTP_HEADER_EXTENSION_URI_TRANSPORT_WIDE_CC,
)
