# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Model schema descriptor.

:class:`ModelSchema` is the structured representation of what a model
can do — its tracks, registered events, and emission settings.
Track topology is introspected from the model's ``OUTPUT_REGISTRY`` and
``INPUT_REGISTRY``; events come from ``EVENT_REGISTRY``; outbound
messages from ``MESSAGE_REGISTRY``.

The version field allows clients and tooling to detect schema changes.
"""

from __future__ import annotations

import copy
import dataclasses
import enum
import inspect
import logging
from dataclasses import dataclass, field
from typing import (
    Any,
    Dict,
    List,
    Literal,
    Optional,
    get_args,
    get_origin,
    get_type_hints,
)

from reactor_runtime.config import ReactorConfig
from reactor_runtime.interface.events.event import EVENT_REGISTRY
from reactor_runtime.interface.events.messages import MESSAGE_REGISTRY
from reactor_runtime.interface.defaults import (
    _NO_DEFAULT,
    FieldInfo,
    field_info_to_json_schema,
)
from reactor_runtime.interface.tracks.descriptors import Audio
from reactor_runtime.interface.tracks.input import INPUT_REGISTRY
from reactor_runtime.interface.tracks.output import OUTPUT_REGISTRY
from reactor_runtime.interface.upload import UploadedFile
from reactor_runtime.utils.typing import unwrap_optional


logger = logging.getLogger(__name__)

_DEFAULT_VERSION = "v0.0.0"

_TYPE_MAP: Dict[type, str] = {
    int: "integer",
    float: "number",
    str: "string",
    bool: "boolean",
}

_UPLOAD_REFERENCE_SCHEMA = {
    "type": "object",
    "format": "reactor-upload-reference",
    "description": "Reference to a file uploaded via the Reactor presigned-URL protocol.",
    "properties": {
        "upload_id": {"type": "string", "format": "uuid"},
        "name": {"type": "string"},
        "mime_type": {"type": "string"},
        "size": {"type": "integer"},
    },
    "required": ["upload_id", "name", "mime_type", "size"],
}


def _resolve_type(raw_type: Any) -> Dict[str, Any]:
    """Resolve a type annotation into an OpenAPI 3.1 JSON Schema fragment."""
    inner = unwrap_optional(raw_type)
    if inner is not None:
        return {"anyOf": [_resolve_type(inner), {"type": "null"}]}

    origin = get_origin(raw_type)

    if origin is Literal:
        values = list(get_args(raw_type))
        value_types = {type(v) for v in values}
        if value_types == {int}:
            return {"type": "integer", "enum": values}
        if value_types == {float}:
            return {"type": "number", "enum": values}
        if value_types == {bool}:
            return {"type": "boolean", "enum": values}
        if value_types == {str}:
            return {"type": "string", "enum": values}
        # Mixed-type Literal: emit `enum` without a `type` keyword so
        # JSON Schema accepts any listed value. A `type` constraint would
        # contradict at least one of the literal values.
        return {"enum": values}

    if origin is list or origin is List:
        args = get_args(raw_type)
        if args:
            return {"type": "array", "items": _resolve_type(args[0])}
        return {"type": "array"}

    if origin is dict or origin is Dict:
        args = get_args(raw_type)
        if args and len(args) == 2:
            return {"type": "object", "additionalProperties": _resolve_type(args[1])}
        return {"type": "object"}

    if isinstance(raw_type, type):
        if raw_type is list:
            return {"type": "array"}

        if raw_type is dict:
            return {"type": "object"}

        if raw_type is UploadedFile:
            return {"$ref": "#/components/schemas/ReactorUploadReference"}

        if issubclass(raw_type, enum.Enum):
            members = [m.value for m in raw_type]
            value_types = {type(v) for v in members}
            if value_types == {int}:
                return {"type": "integer", "enum": members}
            elif value_types == {float}:
                return {"type": "number", "enum": members}
            return {"type": "string", "enum": members}

        if dataclasses.is_dataclass(raw_type):
            try:
                hints = get_type_hints(raw_type)
            except Exception:
                hints = {f.name: f.type for f in dataclasses.fields(raw_type)}
            properties: Dict[str, Any] = {}
            required: List[str] = []
            for f in dataclasses.fields(raw_type):
                properties[f.name] = _resolve_type(hints.get(f.name, f.type))
                if (
                    f.default is dataclasses.MISSING
                    and f.default_factory is dataclasses.MISSING
                ):
                    required.append(f.name)
            schema: Dict[str, Any] = {"type": "object", "properties": properties}
            if required:
                schema["required"] = required
            return schema

        json_type = _TYPE_MAP.get(raw_type)
        if json_type is not None:
            return {"type": json_type}

        raise TypeError(
            f"Unsupported type {raw_type!r} in schema generation. "
            f"Supported: int, float, str, bool, Literal[...], Optional[T], "
            f"List[T], Dict[K,V], Enum, dataclass, UploadedFile."
        )

    raise TypeError(
        f"Unsupported annotation {raw_type!r} in schema generation. "
        f"Supported: int, float, str, bool, Literal[...], Optional[T], "
        f"List[T], Dict[K,V], Enum, dataclass, UploadedFile."
    )


def _coerce_default(value: Any) -> Any:
    """Make a Python default JSON-serializable.

    Enum members are unwrapped to their ``.value`` recursively so raw
    enum instances nested inside ``list`` / ``dict`` / ``tuple`` defaults
    don't sneak through and crash ``json.dumps``.
    """
    if isinstance(value, enum.Enum):
        return value.value
    if isinstance(value, list):
        return [_coerce_default(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_coerce_default(v) for v in value)
    if isinstance(value, dict):
        return {k: _coerce_default(v) for k, v in value.items()}
    return value


def _class_type_hints(cls: type) -> Dict[str, Any]:
    """Return ``get_type_hints(cls)`` or an empty dict if resolution fails.

    Computed once per dataclass so string annotations under
    ``from __future__ import annotations`` (PEP 563) don't get resolved
    once per field.
    """
    try:
        return get_type_hints(cls)
    except Exception:
        return {}


def _resolve_field_type(
    f: dataclasses.Field,
    hints: Optional[Dict[str, Any]] = None,
) -> Any:
    """Resolve a dataclass field's type, tolerating PEP 563 string
    annotations. *hints* should be pre-computed by the caller via
    :func:`_class_type_hints` to avoid N calls per class.
    """
    if not isinstance(f.type, str):
        return f.type
    if hints is None:
        return f.type
    return hints.get(f.name, f.type)


def _materialize_default(f: dataclasses.Field) -> Any:
    """Return the dataclass field's static default, or ``MISSING``.

    Raw ``dataclasses.field(default_factory=...)`` is rejected at
    class-creation time on both :class:`Event` and :class:`ModelMessage`
    subclasses, and the public :class:`InputField` / :class:`MessageField`
    APIs reject ``default_factory=`` too. Schema generation therefore
    never needs to invoke a factory — any factory it sees means the
    field is effectively required, and ``MISSING`` tells downstream
    consumers to mark it as such.
    """
    if f.default is not dataclasses.MISSING:
        return f.default
    return dataclasses.MISSING


def _field_schema(
    f: dataclasses.Field,
    field_infos: Optional[Dict[str, FieldInfo]] = None,
    hints: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a JSON-friendly schema dict from a dataclass field."""
    schema = _resolve_type(_resolve_field_type(f, hints))

    default_val = _materialize_default(f)
    info: Optional[FieldInfo] = None

    if isinstance(default_val, FieldInfo):
        info = default_val
        default_val = info.default
    elif field_infos is not None:
        info = field_infos.get(f.name)

    if default_val is dataclasses.MISSING and info is not None:
        if info.default is not _NO_DEFAULT:
            default_val = info.default

    if default_val is not dataclasses.MISSING and default_val is not _NO_DEFAULT:
        schema["default"] = _coerce_default(default_val)

    if info is not None:
        field_info_to_json_schema(schema, info)

    return schema


def _normalize_docstring(doc: Optional[str]) -> str:
    """Normalise a Python docstring for emission into a schema description.

    Applies PEP 257 dedentation via :func:`inspect.cleandoc`, then collapses
    each paragraph's internal newlines into single spaces. Blank lines are
    preserved as paragraph separators (``\\n\\n``). Net effect: a docstring
    wrapped across multiple source lines for code-style reasons reads as
    one logical sentence downstream, while explicit paragraph breaks are
    kept.

    Paragraphs that contain at least one indented line after
    :func:`inspect.cleandoc` are passed through verbatim instead of
    collapsed. This protects indented blocks — code examples, bulleted
    or numbered lists, definition lists — from being silently flattened
    into one space-joined line that would mangle their semantics in the
    rendered schema (e.g. ``"    result = foo()\\n    # comment"``
    collapsing to ``"result = foo() # comment"``).
    """
    if not doc:
        return ""
    cleaned = inspect.cleandoc(doc)
    if not cleaned:
        return ""
    paragraphs: List[str] = []
    for para in cleaned.split("\n\n"):
        lines = para.splitlines()
        non_empty = [line for line in lines if line.strip()]
        if not non_empty:
            continue
        if any(line != line.lstrip() for line in non_empty):
            # Paragraph contains an indented block (code, list, etc.).
            # Preserve as-is — the indentation carries meaning and would
            # be destroyed by the line-collapsing path below.
            paragraphs.append(para)
        else:
            paragraphs.append(" ".join(line.strip() for line in non_empty))
    return "\n\n".join(paragraphs)


def _split_summary_description(text: str) -> tuple[str, str]:
    """Split a normalised docstring into ``(summary, description)``.

    *summary* is the first paragraph (a single line, suitable for
    OpenAPI ``summary``). *description* is the full normalised text
    (suitable for OpenAPI ``description``). For single-paragraph
    inputs both values are equal; callers can omit ``description``
    in that case to avoid duplicating content in the emitted document.
    """
    if not text:
        return "", ""
    paragraphs = text.split("\n\n")
    return paragraphs[0], text


def _event_schema(cls: type) -> Dict[str, Any]:
    """Build a JSON-friendly schema from an Event @dataclass."""
    if not dataclasses.is_dataclass(cls):
        return {}
    field_infos = getattr(cls, "_field_infos", None)
    hints = _class_type_hints(cls)
    return {
        f.name: _field_schema(f, field_infos, hints) for f in dataclasses.fields(cls)
    }


def _message_schema(cls: type) -> Dict[str, Any]:
    """Build a schema from a ModelMessage @dataclass, including descriptions."""
    if not dataclasses.is_dataclass(cls):
        return {}
    descriptions = getattr(cls, "_field_descriptions", {})
    hints = _class_type_hints(cls)
    result: Dict[str, Any] = {}
    for f in dataclasses.fields(cls):
        schema = _resolve_type(_resolve_field_type(f, hints))
        desc = descriptions.get(f.name)
        if desc:
            schema["description"] = desc
        default_val = _materialize_default(f)
        if default_val is not dataclasses.MISSING:
            schema["default"] = _coerce_default(default_val)
        result[f.name] = schema
    return result


@dataclass
class EventSchema:
    """Schema for a single event."""

    description: str = ""
    schema: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MessageSchema:
    """Schema for a single outbound message type."""

    description: str = ""
    schema: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TrackSchema:
    """A single track's metadata in the schema payload."""

    kind: str
    direction: str
    rate: float = 0.0


@dataclass
class ModelSchema:
    """Versioned schema descriptor for a Reactor model.

    Built from the global registries (populated when the model class is
    imported) and a :class:`ReactorConfig` for identity.

    Version invariant
    -----------------
    The internal :attr:`version` string **always carries a ``v`` prefix**
    (for example ``"v0.0.0"`` or ``"v1.2.3-gabcdef0"``). This matches the
    canonical release-tag format stored by the Coordinator's schema
    registry, so :meth:`to_openapi` can emit ``info.version`` as-is — no
    normalisation at emit time.

    The only place the prefix is stripped is :meth:`to_legacy_tracks_only`,
    which produces the deprecated ``protocol_version`` wire field parsed
    by :func:`reactor_runtime.runtimes._redis.utils._parse_version_string`
    as a bare ``"major.minor.patch"``. That legacy parser uses
    ``str.isdigit()`` per component and would silently degrade a
    ``v``-prefixed input to ``0.0.0``, hence the explicit strip.

    Callers that construct :class:`ModelSchema` directly (for example the
    ``reactor-runtime schema`` CLI when ``--version`` is passed) must honour
    this invariant by prepending ``v`` if the supplied value is bare.
    """

    version: str = _DEFAULT_VERSION
    model: str = ""
    name: str = ""
    description: str = ""
    tracks: Dict[str, TrackSchema] = field(default_factory=dict)
    events: Dict[str, EventSchema] = field(default_factory=dict)
    messages: Dict[str, MessageSchema] = field(default_factory=dict)

    @classmethod
    def from_config(
        cls,
        config: ReactorConfig,
        model_cls: Optional[type] = None,
    ) -> "ModelSchema":
        """Build schema from a ReactorConfig + the global registries.

        Track topology is introspected from ``OUTPUT_REGISTRY`` /
        ``INPUT_REGISTRY``; events from ``EVENT_REGISTRY``; messages
        from ``MESSAGE_REGISTRY``.

        When *model_cls* is provided, handler descriptions are extracted
        from the class's ``@event`` decorators via ``_get_handlers()``.

        Args:
            config: The parsed reactor.yaml (for model name).
            model_cls: The concrete model class (subclass of
                ``ReactorModel``).  Used to extract ``@event`` handler
                descriptions.  Optional — when ``None``, descriptions
                default to empty strings.
        """
        tracks = cls._build_tracks()
        descriptions = cls._extract_handler_descriptions(model_cls)

        events: Dict[str, EventSchema] = {}
        for event_name, event_cls in EVENT_REGISTRY.items():
            if event_name in ("connected", "disconnected"):
                continue
            events[event_name] = EventSchema(
                description=descriptions.get(event_name, ""),
                schema=_event_schema(event_cls),
            )

        messages: Dict[str, MessageSchema] = {}
        for msg_name, msg_cls in MESSAGE_REGISTRY.items():
            # Read ``_user_doc`` (snapshotted on ``__init_subclass__``)
            # instead of ``__doc__`` because ``@dataclass`` auto-fills
            # ``__doc__`` with a signature string for any subclass that
            # omits a real docstring — and we don't want
            # ``"GenerationReset(reason: str)"`` showing up as a
            # description in the OpenAPI schema.
            user_doc = getattr(msg_cls, "_user_doc", None)
            messages[msg_name] = MessageSchema(
                description=_normalize_docstring(user_doc),
                schema=_message_schema(msg_cls),
            )

        return cls(
            model=config.model,
            name=config.name,
            tracks=tracks,
            events=events,
            messages=messages,
        )

    @staticmethod
    def _marker_kind(marker: type) -> str:
        if issubclass(marker, Audio):
            return "audio"
        return "video"

    @classmethod
    def _build_tracks(cls) -> Dict[str, TrackSchema]:
        """Introspect INPUT_REGISTRY and OUTPUT_REGISTRY for track metadata.

        Input tracks are listed first so that their m-line indices in
        the SDP come before output tracks.  GStreamer's webrtcbin maps
        ``src_N`` pads to m-line indices; placing sendonly (input) tracks
        first ensures incoming media pads map to the correct track names.

        Raises:
            ValueError: If an input and output track share the same name.
        """
        tracks: Dict[str, TrackSchema] = {}

        for input_cls in INPUT_REGISTRY.values():
            for name, marker in input_cls._tracks.items():
                tracks[name] = TrackSchema(
                    kind=cls._marker_kind(marker),
                    direction="in",
                )

        for output_cls in OUTPUT_REGISTRY.values():
            for name, marker in output_cls._tracks.items():
                if name in tracks:
                    raise ValueError(
                        f"Track name '{name}' is declared as both input and output"
                    )
                tracks[name] = TrackSchema(
                    kind=cls._marker_kind(marker),
                    direction="out",
                )

        return tracks

    @staticmethod
    def _extract_handler_descriptions(
        model_cls: Optional[type],
    ) -> Dict[str, str]:
        """Extract event handler descriptions from a model class.

        Calls ``_get_handlers()`` (available on ``ReactorModel``
        subclasses) and collects the ``description`` from each
        ``EventEntry``.  Returns an empty dict if the class doesn't
        support handler introspection.
        """
        if model_cls is None:
            return {}
        get_handlers = getattr(model_cls, "_get_handlers", None)
        if get_handlers is None:
            return {}
        try:
            handlers = get_handlers()
            return {name: entry.description for name, entry in handlers.events.items()}
        except Exception:
            return {}

    _MODEL_TO_CLIENT_DIRECTION = {"out": "recvonly", "in": "sendonly"}

    def to_openapi(self) -> Dict[str, Any]:
        """Produce a fully compliant OpenAPI 3.1 document for this model."""
        paths: Dict[str, Any] = {}
        for event_name, event_schema in self.events.items():
            properties = {}
            required = []
            for field_name, field_schema in event_schema.schema.items():
                properties[field_name] = field_schema
                if "default" not in field_schema:
                    required.append(field_name)
            body_schema: Dict[str, Any] = {"type": "object", "properties": properties}
            if required:
                body_schema["required"] = required
            paths[f"/events/{event_name}"] = {
                "post": {
                    "operationId": event_name,
                    "summary": event_schema.description or f"Trigger {event_name}",
                    "requestBody": {
                        "required": True,
                        "content": {"application/json": {"schema": body_schema}},
                    },
                    "responses": {"202": {"description": "Event accepted"}},
                }
            }

        webhooks: Dict[str, Any] = {}
        for msg_name, msg_schema in self.messages.items():
            properties = {}
            required = []
            for field_name, field_schema in msg_schema.schema.items():
                properties[field_name] = field_schema
                if "default" not in field_schema:
                    required.append(field_name)
            body_schema = {"type": "object", "properties": properties}
            if required:
                body_schema["required"] = required
            operation: Dict[str, Any] = {
                "operationId": msg_name,
                "requestBody": {
                    "required": True,
                    "content": {"application/json": {"schema": body_schema}},
                },
            }
            if msg_schema.description:
                summary, description = _split_summary_description(
                    msg_schema.description
                )
                operation["summary"] = summary
                if description != summary:
                    operation["description"] = description
            webhooks[msg_name] = {"post": operation}

        x_reactor: Dict[str, Any] = {
            "tracks": [
                {"name": name, "kind": t.kind, "direction": t.direction}
                for name, t in self.tracks.items()
            ],
        }

        components: Dict[str, Any] = {
            "schemas": {
                "ReactorUploadReference": copy.deepcopy(_UPLOAD_REFERENCE_SCHEMA),
            }
        }

        # Per the class invariant, self.version always carries a 'v'
        # prefix — emit it directly. The OpenAPI info.version matches the
        # release tag stored in the Coordinator's schema registry.
        doc: Dict[str, Any] = {
            "openapi": "3.1.0",
            "info": {
                "title": self.name or self.model,
                "version": self.version,
                "description": self.description,
            },
            "x-reactor": x_reactor,
        }
        if paths:
            doc["paths"] = paths
        if webhooks:
            doc["webhooks"] = webhooks
        doc["components"] = components
        return doc

    def to_legacy_tracks_only(self) -> Dict[str, Any]:
        """Produce a minimal legacy payload with tracks only (empty commands).

        Used for backward compatibility with the proto TransportCapabilities
        message and older HTTP clients.

        ``protocol_version`` is emitted WITHOUT the ``v`` prefix that the
        internal :attr:`version` always carries, because the legacy parser
        (:func:`reactor_runtime.runtimes._redis.utils._parse_version_string`)
        expects a bare ``major.minor.patch`` and silently maps non-digit
        components to ``0``. See the class docstring for the full
        ``ModelSchema.version`` invariant.
        """
        tracks_list = [
            {
                "name": name,
                "kind": t.kind,
                "direction": self._MODEL_TO_CLIENT_DIRECTION.get(
                    t.direction, t.direction
                ),
            }
            for name, t in self.tracks.items()
        ]
        # Strip the 'v' prefix so protocol_version stays parseable as a
        # bare semver by the legacy wire-format consumer.
        legacy_version = (
            self.version[1:] if self.version.startswith("v") else self.version
        )
        return {
            "protocol_version": legacy_version,
            "tracks": tracks_list,
            "commands": [],
            "emission_fps": None,
        }
