# Reactor Runtime

A Python framework for building real-time, interactive video models. Write your ML code — Reactor handles networking, media transport, and client connections.

## Installation

```bash
pip install reactor-runtime
```

## Quick Example

```python
from dataclasses import dataclass
from reactor_runtime.interface import Output, Video, ReactorPipeline, InputState, InputField

@dataclass
class MyOutput(Output):
    video: Video

@dataclass
class MyState(InputState):
    prompt: str = InputField(default="a sunny meadow")

class MyModel(ReactorPipeline):
    state: MyState

    def load(self, config):
        self.pipe = load_my_model(config["checkpoint"])

    def inference(self):
        while True:
            frame = self.pipe.forward(prompt=self.state.prompt)
            yield MyOutput(video=frame)
```

Implement `inference()` as a generator that yields frames. Clients can update `self.state` mid-generation — no restart, no re-queue.

## Key Features

- **Real-time streaming** — frames delivered over WebRTC as they're generated
- **Live interaction** — clients change inputs mid-generation via typed, validated state
- **No transport code** — no WebRTC, WebSocket, or video encoding to manage
- **Scaffold & run** — the Go `reactor` CLI gives you `reactor init` / `reactor run`; the
  Python runtime ships its own `reactor-runtime` script for standalone use

## Standalone usage (no Go CLI)

The runtime CLI is installed as `reactor-runtime` so it never shadows the Go
`reactor` binary. If you only use the Python runtime:

```bash
pip install reactor-runtime
reactor-runtime init my-model
cd my-model
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
reactor-runtime run
```

The Go `reactor` CLI delegates to this same `reactor-runtime` script under the
hood; both `reactor run` (Go) and `reactor-runtime run` (standalone) execute the
same Python entry point.
