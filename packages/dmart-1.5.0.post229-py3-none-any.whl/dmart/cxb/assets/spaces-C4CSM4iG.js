import{w as s}from"./svelte-B0Rx3Yhd.js";const o=s(null);export{o as s};
