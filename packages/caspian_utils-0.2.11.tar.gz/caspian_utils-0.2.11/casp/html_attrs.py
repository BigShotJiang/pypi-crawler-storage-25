from __future__ import annotations
from .string_helpers import camel_to_kebab
from typing import Any, Dict, Optional
import html
import json
from markupsafe import Markup

# Map Python-safe names to HTML attributes
ALIAS_MAP = {
    "class_name": "class",
    "className": "class",
    "html_for": "for",
    "htmlFor": "for",
    "defaultValue": "defaultvalue",
    "defaultChecked": "defaultchecked",
}


def _flatten_classes(*classes: Any) -> list[str]:
    parts: list[str] = []

    for c in classes:
        if not c:
            continue
        if isinstance(c, (list, tuple, set)):
            s = " ".join(str(x) for x in c if x)
        else:
            s = str(c).strip()
        if s:
            parts.append(s)
    return parts


def _unwrap_expression(value: str) -> str | None:
    stripped = value.strip()

    if stripped.startswith("{") and stripped.endswith("}"):
        return stripped[1:-1].strip()

    return None


def _use_frontend_tw_merge() -> bool:
    try:
        from .caspian_config import get_config

        return bool(getattr(get_config(), "tailwindcss", False))
    except Exception:
        return False


def _to_tw_merge_arg(value: str) -> str:
    expression = _unwrap_expression(value)
    if expression is not None:
        if expression.startswith("twMerge(") and expression.endswith(")"):
            return expression[len("twMerge("):-1].strip()
        return expression

    return json.dumps(value)


def merge_classes(*classes: Any) -> str:
    parts = _flatten_classes(*classes)

    if not parts:
        return ""

    if not _use_frontend_tw_merge():
        return " ".join(parts)

    if len(parts) == 1:
        existing_expression = _unwrap_expression(parts[0])
        if existing_expression == parts[0].strip()[1:-1].strip() and parts[0].strip().startswith("{twMerge("):
            return parts[0].strip()

    args = ", ".join(_to_tw_merge_arg(part) for part in parts)
    return f"{{twMerge({args})}}"


def _to_attr_value(v: Any) -> Optional[str]:
    # XML-strict: booleans should have explicit values
    if v is None:
        return None
    if isinstance(v, bool):
        return "true" if v else None  # omit false
    if isinstance(v, (list, tuple, set)):
        s = " ".join(str(x) for x in v if x)
        return s if s else None
    s = str(v)
    return s if s != "" else None


def get_attributes(props: Dict[str, Any], overrides: Optional[Dict[str, Any]] = None) -> Markup:
    """
    Build ONE attribute string.
    - Resolves Aliases first (className -> class).
    - Normalizes ALL keys to kebab-case (dataSlot -> data-slot).
    - Merges defaults (props) and overrides to ensure correct precedence.
    - Returns Markup() so Jinja does not double-escape the quotes.
    """

    final_attrs: Dict[str, str] = {}

    # Helper to process a dictionary into the final map
    def process_source(source: Dict[str, Any]):
        if not source:
            return

        for k, v in source.items():
            if not k:
                continue

            # 1. Check Alias Map first (e.g., class_name -> class)
            key_name = ALIAS_MAP.get(k, k)

            # 2. Normalize to Kebab Case ALWAYS
            # This ensures that 'dataSlot' (from compiler) overwrites 'data-slot' (from defaults)
            # regardless of whether the value has mustache syntax or not.
            final_key = camel_to_kebab(key_name)

            # 3. Process value to string
            val = _to_attr_value(v)

            if val is not None:
                final_attrs[final_key] = val

    # 1. Process defaults (props) first
    process_source(props)

    # 2. Process overrides second (this overwrites keys from step 1)
    if overrides:
        process_source(overrides)

    # 3. Build string
    parts: list[str] = []
    # Sorting keys for consistent output
    for k in sorted(final_attrs.keys()):
        v = final_attrs[k]
        parts.append(f'{k}="{html.escape(v, quote=True)}"')

    # 4. Return as Safe Markup
    return Markup(" ".join(parts))
