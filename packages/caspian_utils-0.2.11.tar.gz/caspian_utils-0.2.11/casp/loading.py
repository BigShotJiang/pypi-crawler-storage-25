from .caspian_config import get_files_index
import os
import json

ROUTE_FILES_PATH = './settings/files-list.json'
_loading_cache_key = None
_loading_cache_html = ''


def get_route_files():
    if os.path.exists(ROUTE_FILES_PATH):
        with open(ROUTE_FILES_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []


def get_loading_files():
    global _loading_cache_key, _loading_cache_html

    idx = get_files_index()
    loading_sources = []
    cache_key = []

    for loading in idx.loadings:
        file_path = loading.file.lstrip('./')
        if not os.path.exists(file_path):
            continue

        mtime_ns = os.stat(file_path).st_mtime_ns
        cache_key.append((file_path, loading.url_scope, mtime_ns))
        loading_sources.append((file_path, loading.url_scope))

    normalized_key = tuple(cache_key)
    if _loading_cache_key == normalized_key:
        return _loading_cache_html

    loading_parts = []
    for file_path, url_scope in loading_sources:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        loading_parts.append(
            f'<div pp-loading-url="{url_scope}">{content}</div>'
        )

    loading_content = ''.join(loading_parts)
    result = f'<div style="display: none;" id="loading-file-1B87E">{loading_content}</div>' if loading_content else ''

    _loading_cache_key = normalized_key
    _loading_cache_html = result

    return result
