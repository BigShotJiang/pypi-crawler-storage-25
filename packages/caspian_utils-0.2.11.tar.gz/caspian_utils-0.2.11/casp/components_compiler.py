from __future__ import annotations

from .component_decorator import Component, load_component_from_path
from .html_native import (
    parse_fragment,
    replace_tag_with_html,
    serialize_fragment,
    significant_top_level_nodes,
)
from .string_helpers import camel_to_kebab, kebab_to_camel
from bs4.element import Tag
from collections import OrderedDict
from typing import Any, Dict, Iterable, List, NamedTuple, Optional, Tuple, TypedDict
import hashlib
import inspect
import os
import re
import uuid


_GROUPED_IMPORT_RE = re.compile(
    r'<!--\s*@import\s*\{([^}]+)\}\s*from\s*["\']?([^"\'>\s]+)["\']?\s*-->'
)
_SINGLE_IMPORT_RE = re.compile(
    r'<!--\s*@import\s+(?!\{)(\w+)(?:\s+as\s+(\w+))?\s+from\s*["\']?([^"\'>\s]+)["\']?\s*-->'
)
_GROUPED_IMPORT_STRIP_RE = re.compile(
    r'<!--\s*@import\s*\{[^}]+\}\s*from\s*["\']?[^"\'>\s]+["\']?\s*-->\n?'
)
_SINGLE_IMPORT_STRIP_RE = re.compile(
    r'<!--\s*@import\s+\w+(?:\s+as\s+\w+)?\s+from\s*["\']?[^"\'>\s]+["\']?\s*-->\n?'
)
_MAX_IMPORT_PARSE_CACHE = 256
_import_parse_cache: OrderedDict[str, Tuple[str, Tuple[Tuple[str, str, str], ...]]] = OrderedDict()


class ImportDefinition(TypedDict):
    original: str
    alias: str
    path: str


class UnknownComponentError(RuntimeError):
    """Raised when an x-* component tag cannot be resolved."""


class TemplateRootError(RuntimeError):
    """Raised when a page, layout, or component template has an invalid root."""


class AttrToken(NamedTuple):
    name: str
    value: Optional[str]
    quote: Optional[str] = None


class TagToken(NamedTuple):
    name: str
    is_close: bool
    is_self: bool
    start: int
    end: int
    attrs: Tuple[AttrToken, ...]


def build_pp_component_key(scope: str, source_id: str) -> str:
    safe_scope = re.sub(r'[^a-z0-9]+', '_', scope.lower()).strip('_') or 'component'
    digest = hashlib.md5(str(source_id).encode('utf-8')).hexdigest()[:8]
    return f"{safe_scope}_{digest}"


def _format_template_label(template_kind: str, source_name: Optional[str]) -> str:
    label = (template_kind or 'template').strip() or 'template'
    if source_name:
        return f"{label} template '{source_name}'"
    return f"{label} template"


def _raise_template_root_error(
    template_kind: str,
    source_name: Optional[str],
    detail: str,
) -> None:
    label = _format_template_label(template_kind, source_name)
    raise TemplateRootError(
        f"{label} must have exactly one top-level HTML element so Caspian can inject pp-component. {detail}"
    )


def _single_root_tag(
    soup,
    *,
    template_kind: str,
    source_name: Optional[str],
    control_mode: bool,
    allow_component_root: bool = False,
) -> Optional[Tag]:
    significant = significant_top_level_nodes(soup)

    def fail(detail: str) -> Optional[Tag]:
        if control_mode:
            _raise_template_root_error(template_kind, source_name, detail)
        return None

    if not significant:
        return fail('Found no root element.')
    if len(significant) > 1:
        return fail('Found sibling content after the root element.')
    root = significant[0]
    if not isinstance(root, Tag):
        return fail('Found non-element content before the root element.')
    if not allow_component_root and str(root.name).startswith("x-"):
        return fail(
            f"Found <{root.name}> as the root. The root must be a native HTML element, not a component tag."
        )
    return root


def _wrap_with_pp_component_host(soup, unique_key: str) -> str:
    wrapper = soup.new_tag("div")
    wrapper["pp-component"] = unique_key
    wrapper["style"] = "display: contents"

    for child in list(soup.contents):
        wrapper.append(child.extract())

    soup.append(wrapper)
    return serialize_fragment(soup)


def inject_pp_component_root(
    html: str,
    unique_key: str,
    *,
    template_kind: str = 'template',
    source_name: Optional[str] = None,
    control_mode: bool = True,
    preserve_existing_root: bool = False,
    allow_fragment_host: bool = False,
) -> str:
    soup = parse_fragment(html)
    root = _single_root_tag(
        soup,
        template_kind=template_kind,
        source_name=source_name,
        control_mode=control_mode and not allow_fragment_host,
    )
    if root is None:
        if allow_fragment_host:
            return _wrap_with_pp_component_host(soup, unique_key)
        return html

    if preserve_existing_root and root.has_attr("pp-component"):
        return _wrap_with_pp_component_host(soup, unique_key)

    root["pp-component"] = unique_key
    return serialize_fragment(soup)


def _remember_import_parse(html: str, cleaned_html: str, imports: Tuple[Tuple[str, str, str], ...]) -> None:
    _import_parse_cache[html] = (cleaned_html, imports)
    _import_parse_cache.move_to_end(html)
    while len(_import_parse_cache) > _MAX_IMPORT_PARSE_CACHE:
        _import_parse_cache.popitem(last=False)


def extract_imports(html: str) -> List[ImportDefinition]:
    imports: List[ImportDefinition] = []

    for match in _GROUPED_IMPORT_RE.finditer(html):
        members = match.group(1)
        path = match.group(2)
        for member in members.split(','):
            member = member.strip()
            if not member:
                continue
            if ' as ' in member:
                original, alias = [part.strip() for part in member.split(' as ', 1)]
            else:
                original = member
                alias = member
            imports.append({'original': original, 'alias': alias, 'path': path})

    for match in _SINGLE_IMPORT_RE.finditer(html):
        original = match.group(1)
        alias = match.group(2) or original
        path = match.group(3)
        imports.append({'original': original, 'alias': alias, 'path': path})

    return imports


def strip_imports(html: str) -> str:
    html = _GROUPED_IMPORT_STRIP_RE.sub('', html)
    html = _SINGLE_IMPORT_STRIP_RE.sub('', html)
    return html


def build_alias_map(
    imports: Iterable[ImportDefinition | Tuple[str, str, str]],
    base_dir: str = "",
) -> Dict[str, Component]:
    alias_map: Dict[str, Component] = {}
    for imp in imports:
        if isinstance(imp, dict):
            original = imp['original']
            alias = imp['alias']
            path = imp['path']
        else:
            original, alias, path = imp

        comp = load_component_from_path(path, original, base_dir)
        if comp:
            alias_map[alias] = comp
    return alias_map


def _prepare_imports(html: str) -> Tuple[str, Tuple[Tuple[str, str, str], ...]]:
    cached = _import_parse_cache.get(html)
    if cached is not None:
        _import_parse_cache.move_to_end(html)
        return cached

    imports = tuple(
        (imp['original'], imp['alias'], imp['path'])
        for imp in extract_imports(html)
    )
    cleaned_html = strip_imports(html)
    _remember_import_parse(html, cleaned_html, imports)
    return cleaned_html, imports


def process_imports(html: str, base_dir: str = "") -> tuple[str, Dict[str, Component]]:
    if '@import' not in html:
        return html, {}

    cleaned_html, imports = _prepare_imports(html)
    alias_map = build_alias_map(imports, base_dir)
    return cleaned_html, alias_map


def accepts_children(fn: Any) -> bool:
    if isinstance(fn, Component):
        return fn.accepts_children

    sig = inspect.signature(fn)
    params = sig.parameters
    return 'children' in params or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())


def wrap_children_template(children_html: str, owner_scope: str) -> str:
    if not children_html:
        return ""

    stripped = str(children_html).strip()
    if not stripped:
        return ""
    if stripped.startswith('<template pp-owner='):
        return children_html

    owner = owner_scope or "app"
    return f'<template pp-owner="{owner}">\n{children_html}\n</template>'


def _component_tag_name(alias: str) -> str:
    return f"x-{camel_to_kebab(alias)}"


def _component_lookup(alias_map: Dict[str, Component]) -> Dict[str, Tuple[str, Component]]:
    return {
        _component_tag_name(alias): (alias, component)
        for alias, component in alias_map.items()
    }


def _node_children_html(node: Tag) -> str:
    return "".join(str(child) for child in node.contents)


def _prop_value(value: Any) -> str:
    if isinstance(value, list):
        return " ".join(str(item) for item in value)
    if value is True or value is None:
        return ""
    return str(value)


def _props_from_node(node: Tag) -> Dict[str, str]:
    props: Dict[str, str] = {}
    for name, value in node.attrs.items():
        camel = kebab_to_camel(str(name))
        if camel not in props:
            props[camel] = _prop_value(value)
    return props


def _find_unknown_component_tag(soup, lookup: Dict[str, Tuple[str, Component]]) -> Optional[str]:
    for node in soup.find_all(True):
        name = str(node.name)
        if name.startswith("x-") and name not in lookup:
            return name
    return None


async def _render_component_node(
    node: Tag,
    alias: str,
    component_fn: Component,
    *,
    parent_scope: str,
    base_dir: str,
    alias_map: Dict[str, Component],
    depth: int,
) -> str:
    props = _props_from_node(node)
    children_html = _node_children_html(node)
    unique_id = f"{alias.lower()}_{uuid.uuid4().hex[:8]}"

    if children_html and accepts_children(component_fn):
        props['children'] = wrap_children_template(children_html, parent_scope)

    if isinstance(component_fn, Component) and component_fn.is_async:
        component_html = await component_fn.acall(**props)
    else:
        component_html = component_fn(**props)

    rendered_component_html = str(component_html).strip()
    source_path = component_fn.source_path
    component_dir = os.path.dirname(source_path) if source_path is not None else base_dir
    component_html = await transform_components(
        rendered_component_html,
        parent_scope=unique_id,
        base_dir=component_dir,
        alias_map=alias_map,
        _depth=depth + 1,
    )

    return inject_pp_component_root(
        str(component_html).strip(),
        unique_id,
        template_kind='component',
        source_name=getattr(component_fn, 'source_path', None) or alias,
        control_mode=True,
        preserve_existing_root=True,
    )


async def transform_components(
    html: str,
    parent_scope: str = "app",
    base_dir: str = "",
    alias_map: Optional[Dict[str, Component]] = None,
    _depth: int = 0
) -> str:
    if _depth > 50:
        return html

    html = str(html)
    has_imports = '@import' in html
    has_components = '<x-' in html.lower()

    if not alias_map and not has_imports and not has_components:
        return html

    html, local_alias_map = process_imports(html, base_dir)
    merged_map = {**(alias_map or {}), **local_alias_map}
    lookup = _component_lookup(merged_map)

    if not lookup:
        if has_components:
            soup = parse_fragment(html)
            unknown = _find_unknown_component_tag(soup, lookup)
            if unknown:
                raise UnknownComponentError(
                    f'Component tag <{unknown}> is not imported or does not exist. '
                    'Add an @import comment for the component, or remove the tag if it is not a Caspian component.'
                )
        return html

    soup = parse_fragment(html)

    while True:
        target: Optional[Tag] = None
        alias = ""
        component_fn: Optional[Component] = None

        for node in soup.find_all(True):
            found = lookup.get(str(node.name))
            if found:
                target = node
                alias, component_fn = found
                break

        if target is None or component_fn is None:
            break

        replacement = await _render_component_node(
            target,
            alias,
            component_fn,
            parent_scope=parent_scope,
            base_dir=base_dir,
            alias_map=merged_map,
            depth=_depth,
        )
        replace_tag_with_html(target, replacement)

    unknown = _find_unknown_component_tag(soup, lookup)
    if unknown:
        raise UnknownComponentError(
            f'Component tag <{unknown}> is not imported or does not exist. '
            'Add an @import comment for the component, or remove the tag if it is not a Caspian component.'
        )

    return serialize_fragment(soup)
