from typing import Dict, Callable, Any, Optional, Union, List
import os
import re
import secrets
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from functools import wraps
import httpx
from fastapi import Request, Response
from fastapi.responses import RedirectResponse
import asyncio


_request_ctx: ContextVar[Optional[Request]
                         ] = ContextVar('request', default=None)


@dataclass
class AuthSettings:
    # Secrets
    secret_key: str = field(
        default_factory=lambda: os.getenv("AUTH_SECRET", "changeme"))
    cookie_name: str = field(default_factory=lambda: os.getenv(
        "AUTH_COOKIE_NAME", "auth_token"))

    # Token settings
    default_token_validity: str = "1h"
    token_auto_refresh: bool = False

    # Route protection
    is_all_routes_private: bool = True
    private_routes: list[str] = field(default_factory=list)
    public_routes: list[str] = field(default_factory=lambda: ["/"])
    auth_routes: list[str] = field(
        default_factory=lambda: ["/signin", "/signup"])

    # Role-based access
    is_role_based: bool = False
    role_identifier: str = "role"

    # IMPORTANT: current implementation expects ROUTE/PATTERN -> [ROLES]
    role_based_routes: dict[str, list[str]] = field(default_factory=dict)

    # Redirects / prefixes
    default_signin_redirect: str = "/dashboard"
    default_signout_redirect: str = "/signin"
    api_auth_prefix: str = "/api/auth"

    def __post_init__(self):
        self.cookie_name = str(self.cookie_name or "auth_token")


# Global settings instance
_settings: AuthSettings = AuthSettings()


def _normalize_route_path(route: str) -> str:
    normalized = str(route or "/").strip()
    if not normalized:
        return "/"
    if not normalized.startswith("/"):
        normalized = f"/{normalized}"
    if len(normalized) > 1:
        normalized = normalized.rstrip("/")
    return normalized or "/"


def _split_route_segments(route: str) -> list[str]:
    normalized = _normalize_route_path(route)
    if normalized == "/":
        return []
    return [segment for segment in normalized.strip("/").split("/") if segment]


def _is_optional_catch_all_segment(segment: str) -> bool:
    return segment.startswith('[[...') and segment.endswith(']]') and len(segment) > 7


def _is_catch_all_segment(segment: str) -> bool:
    return segment.startswith('[...') and segment.endswith(']') and len(segment) > 5


def _is_dynamic_segment(segment: str) -> bool:
    if _is_optional_catch_all_segment(segment) or _is_catch_all_segment(segment):
        return False
    return segment.startswith('[') and segment.endswith(']') and len(segment) > 2


def _is_fastapi_path_segment(segment: str) -> bool:
    return segment.startswith('{') and segment.endswith('}') and segment.endswith(':path}')


def _is_fastapi_dynamic_segment(segment: str) -> bool:
    return segment.startswith('{') and segment.endswith('}') and len(segment) > 2


def _route_pattern_to_regex(route_pattern: str) -> re.Pattern:
    normalized = _normalize_route_path(route_pattern)
    if normalized == '/':
        return re.compile(r'^/$')

    regex_parts = ['^']
    for segment in _split_route_segments(normalized):
        if _is_optional_catch_all_segment(segment):
            regex_parts.append(r'(?:/.*)?')
        elif _is_catch_all_segment(segment) or _is_fastapi_path_segment(segment):
            regex_parts.append(r'/.+')
        elif _is_dynamic_segment(segment) or _is_fastapi_dynamic_segment(segment):
            regex_parts.append(r'/[^/]+')
        else:
            regex_parts.append('/' + re.escape(segment))

    regex_parts.append('$')
    return re.compile(''.join(regex_parts))


def _route_pattern_matches_request(route_pattern: str, request_path: str) -> bool:
    normalized_pattern = _normalize_route_path(route_pattern)
    normalized_request = _normalize_route_path(request_path)

    if normalized_pattern == normalized_request:
        return True

    return bool(_route_pattern_to_regex(normalized_pattern).fullmatch(normalized_request))


def _route_scope_matches_request(route_scope: str, request_path: str) -> bool:
    normalized_scope = _normalize_route_path(route_scope)
    normalized_request = _normalize_route_path(request_path)

    if _route_pattern_matches_request(normalized_scope, normalized_request):
        return True

    scope_segments = _split_route_segments(normalized_scope)
    request_segments = _split_route_segments(normalized_request)
    if not scope_segments or len(request_segments) <= len(scope_segments):
        return False

    request_prefix = '/' + '/'.join(request_segments[:len(scope_segments)])
    return _route_pattern_matches_request(normalized_scope, request_prefix)


def _route_specificity(route_pattern: str) -> tuple[int, int, int, int]:
    normalized = _normalize_route_path(route_pattern)
    static_count = 0
    dynamic_count = 0
    catch_all_count = 0
    segment_count = 0

    for segment in _split_route_segments(normalized):
        segment_count += 1
        if _is_optional_catch_all_segment(segment) or _is_catch_all_segment(segment) or _is_fastapi_path_segment(segment):
            catch_all_count += 1
        elif _is_dynamic_segment(segment) or _is_fastapi_dynamic_segment(segment):
            dynamic_count += 1
        else:
            static_count += 1

    return (static_count, segment_count, -catch_all_count, -dynamic_count)


def _matches_route_scope(route_scopes: list[str], request_path: str) -> bool:
    return any(_route_scope_matches_request(route_scope, request_path) for route_scope in route_scopes)


def _find_best_matching_scope(route_scopes: list[str], request_path: str) -> Optional[str]:
    best_scope = None
    best_score = None

    for route_scope in route_scopes:
        if not _route_scope_matches_request(route_scope, request_path):
            continue

        score = _route_specificity(route_scope)
        if best_score is None or score > best_score:
            best_scope = route_scope
            best_score = score

    return best_scope


def configure_auth(settings: AuthSettings) -> None:
    """
    Configure auth at app startup. Call this before app starts.

    Example:
        configure_auth(AuthSettings(
            default_signin_redirect="/app",
            private_routes=["/dashboard", "/settings"],
            role_based_routes={
                "/admin": ["admin", "superadmin"],
                "/reports": ["admin", "manager", "user"],
            },
            on_sign_in=lambda user: print(f"Welcome {user.get('name')}"),
        ))
    """
    global _settings
    _settings = settings
    Auth._instance = None
    Auth.get_instance()


def get_auth_settings() -> AuthSettings:
    """Get current auth settings."""
    return _settings


@dataclass
class GoogleProvider:
    """Google OAuth provider. Reads secrets from env if not provided."""
    client_id: str = field(
        default_factory=lambda: os.getenv("GOOGLE_CLIENT_ID", ""))
    client_secret: str = field(
        default_factory=lambda: os.getenv("GOOGLE_CLIENT_SECRET", ""))
    redirect_uri: str = field(
        default_factory=lambda: os.getenv("GOOGLE_REDIRECT_URI", ""))
    max_age: str = "30d"


@dataclass
class GithubProvider:
    """GitHub OAuth provider. Reads secrets from env if not provided."""
    client_id: str = field(
        default_factory=lambda: os.getenv("GITHUB_CLIENT_ID", ""))
    client_secret: str = field(
        default_factory=lambda: os.getenv("GITHUB_CLIENT_SECRET", ""))
    max_age: str = "30d"


class Auth:
    PAYLOAD_NAME = "payload_name_8639D"
    PAYLOAD_SESSION_KEY = "payload_session_key_2183A"

    _instance: Optional["Auth"] = None
    _cookie_name: str = ""
    _providers: List[Any] = []

    def __init__(self) -> None:
        self._settings = _settings
        Auth._cookie_name = self._settings.cookie_name

    @classmethod
    def get_instance(cls) -> "Auth":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def set_request(cls, request: Request):
        _request_ctx.set(request)

    @classmethod
    def get_request(cls) -> Optional[Request]:
        return _request_ctx.get()

    @classmethod
    def set_providers(cls, *providers) -> None:
        """Set OAuth providers for the auth instance."""
        cls._providers = list(providers)

    @classmethod
    def get_providers(cls) -> List[Any]:
        return cls._providers

    @property
    def settings(self) -> AuthSettings:
        return self._settings

    @property
    def cookie_name(self) -> str:
        return Auth._cookie_name

    def _get_session(self) -> dict:
        request = self.get_request()
        if request and hasattr(request, 'session'):
            return request.session
        return {}

    # ====
    # ROUTE CHECKING
    # ====
    def is_public_route(self, path: str) -> bool:
        """Check if path is inside a configured public route scope."""
        return _matches_route_scope(self._settings.public_routes, path)

    def is_auth_route(self, path: str) -> bool:
        """Check if path is inside a configured auth route scope."""
        return _matches_route_scope(self._settings.auth_routes, path)

    def is_private_route(self, path: str) -> bool:
        """Check if path requires authentication."""
        if self._settings.is_all_routes_private:
            return not (self.is_public_route(path) or self.is_auth_route(path))
        return _matches_route_scope(self._settings.private_routes, path)

    def get_required_roles(self, path: str) -> Optional[List[str]]:
        """Get required roles for the most specific matching route scope, if any."""
        matched_scope = _find_best_matching_scope(list(self._settings.role_based_routes.keys()), path)
        if matched_scope is None:
            return None
        return self._settings.role_based_routes.get(matched_scope)

    # ====
    # CORE AUTH METHODS
    # ====
    def sign_in(
        self,
        data: Union[dict, str, Any],
        token_validity: Optional[str] = None,
        redirect_to: Union[bool, str] = False,
    ) -> Union[str, Response]:
        validity = token_validity or self._settings.default_token_validity
        exp_time = self._calculate_expiration(validity)

        data = self._normalize_payload(data)

        payload = {
            self.PAYLOAD_NAME: data,
            "exp": exp_time,
            "iat": datetime.now(timezone.utc).timestamp(),
        }

        session = self._get_session()
        session[self.PAYLOAD_SESSION_KEY] = payload
        session["csrf_token"] = secrets.token_hex(32)

        if redirect_to is True:
            return RedirectResponse(url=self._settings.default_signin_redirect, status_code=303)
        if isinstance(redirect_to, str) and redirect_to:
            return RedirectResponse(url=redirect_to, status_code=303)

        return "ok"

    def sign_out(self, redirect_to: Optional[str] = None) -> Optional[Response]:
        session = self._get_session()
        session.pop(self.PAYLOAD_SESSION_KEY, None)
        session.pop("csrf_token", None)
        session.clear()

        target = redirect_to or self._settings.default_signout_redirect
        if target:
            return RedirectResponse(url=target, status_code=303)
        return None

    def is_authenticated(self) -> bool:
        session = self._get_session()
        payload = session.get(self.PAYLOAD_SESSION_KEY)
        if not isinstance(payload, dict):
            return False

        exp = payload.get("exp")
        if exp is not None:
            try:
                now_ts = datetime.now(timezone.utc).timestamp()
                if float(exp) < now_ts:
                    session.pop(self.PAYLOAD_SESSION_KEY, None)
                    return False
            except Exception:
                session.pop(self.PAYLOAD_SESSION_KEY, None)
                return False

        if payload.get(self.PAYLOAD_NAME) is None:
            session.pop(self.PAYLOAD_SESSION_KEY, None)
            return False

        return True

    def get_payload(self) -> Optional[Dict[str, Any]]:
        session = self._get_session()
        payload = session.get(self.PAYLOAD_SESSION_KEY)
        if not isinstance(payload, dict):
            return None

        data = payload.get(self.PAYLOAD_NAME)
        if isinstance(data, dict):
            return data
        if data is not None:
            return {"value": data}
        return None

    def refresh_session(self) -> None:
        """
        Extends the session expiration if token_auto_refresh is enabled.
        This implements a 'sliding window' session.
        """
        if not self._settings.token_auto_refresh:
            return

        session = self._get_session()
        payload = session.get(self.PAYLOAD_SESSION_KEY)

        # Ensure payload exists and is a dictionary
        if isinstance(payload, dict):
            # Calculate new expiration time based on default validity
            # e.g., if valid for "1h", set exp to Now + 1h
            validity = self._settings.default_token_validity
            try:
                new_exp = self._calculate_expiration(validity)
                payload["exp"] = new_exp

                # Re-assign to ensure the session backend detects the change
                session[self.PAYLOAD_SESSION_KEY] = payload
            except Exception as e:
                print(f"Error refreshing session: {e}")

    def check_role(self, user: Any, allowed_roles: List[str]) -> bool:
        """Check if user has one of the allowed roles."""
        if isinstance(user, dict):
            user_role = user.get(self._settings.role_identifier, "")
        else:
            user_role = str(user) if user else ""
        return user_role in allowed_roles

    # ====
    # OAUTH PROVIDERS
    # ====
    async def auth_providers(self, *providers) -> Optional[Response]:
        """Handle OAuth provider signin/callback routes."""
        request = self.get_request()
        if not request:
            return None

        path_parts = request.url.path.strip("/").split("/")

        # Handle signin redirects
        if request.method == "GET" and "signin" in path_parts:
            for provider in providers:
                if isinstance(provider, GithubProvider) and "github" in path_parts:
                    url = (
                        "https://github.com/login/oauth/authorize"
                        f"?scope=user:email%20read:user&client_id={provider.client_id}"
                    )
                    return RedirectResponse(url=url)

                if isinstance(provider, GoogleProvider) and "google" in path_parts:
                    url = (
                        "https://accounts.google.com/o/oauth2/v2/auth?"
                        "scope=email%20profile&response_type=code&"
                        f"client_id={provider.client_id}&"
                        f"redirect_uri={provider.redirect_uri}"
                    )
                    return RedirectResponse(url=url)

        # Handle callbacks
        code = request.query_params.get("code")
        if request.method == "GET" and "callback" in path_parts and code:
            if "github" in path_parts:
                provider = self._find_provider(providers, GithubProvider)
                if provider:
                    return await self._github_callback(provider, code)
            if "google" in path_parts:
                provider = self._find_provider(providers, GoogleProvider)
                if provider:
                    return await self._google_callback(provider, code)

        return None

    async def _github_callback(self, provider: GithubProvider, code: str) -> Optional[Response]:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                token_resp = await client.post(
                    "https://github.com/login/oauth/access_token",
                    data={
                        "client_id": provider.client_id,
                        "client_secret": provider.client_secret,
                        "code": code,
                    },
                    headers={"Accept": "application/json"},
                )
                token_data = token_resp.json()
                access_token = token_data.get("access_token")
                if not access_token:
                    return None

                headers = {"Authorization": f"Bearer {access_token}",
                           "Accept": "application/json"}

                email_resp, user_resp = await asyncio.gather(
                    client.get(
                        "https://api.github.com/user/emails", headers=headers),
                    client.get("https://api.github.com/user", headers=headers),
                )

                email_data = email_resp.json()
                emails = email_data if isinstance(email_data, list) else []
                primary_email = next(
                    (e.get("email") for e in emails if e.get(
                        "primary") and e.get("verified")), None
                )

                user_data_raw = user_resp.json()
                user_info = user_data_raw if isinstance(
                    user_data_raw, dict) else {}

            user_data = {
                "name": user_info.get("login"),
                "email": primary_email,
                "image": user_info.get("avatar_url"),
                "provider": "github",
                "provider_id": str(user_info.get("id")) if user_info.get("id") is not None else None,
            }

            self.sign_in(user_data, provider.max_age)
            return RedirectResponse(url=self._settings.default_signin_redirect, status_code=303)
        except Exception:
            return None

    async def _google_callback(self, provider: GoogleProvider, code: str) -> Optional[Response]:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                token_resp = await client.post(
                    "https://oauth2.googleapis.com/token",
                    data={
                        "client_id": provider.client_id,
                        "client_secret": provider.client_secret,
                        "code": code,
                        "grant_type": "authorization_code",
                        "redirect_uri": provider.redirect_uri,
                    },
                )
                token_data = token_resp.json()
                access_token = token_data.get("access_token")
                if not access_token:
                    return None

                user_resp = await client.get(
                    "https://www.googleapis.com/oauth2/v1/userinfo",
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                user_data_raw = user_resp.json()
                user_info = user_data_raw if isinstance(
                    user_data_raw, dict) else {}

            user_data = {
                "name": user_info.get("name"),
                "email": user_info.get("email"),
                "image": user_info.get("picture"),
                "provider": "google",
                "provider_id": str(user_info.get("id")) if user_info.get("id") is not None else None,
            }

            self.sign_in(user_data, provider.max_age)
            return RedirectResponse(url=self._settings.default_signin_redirect, status_code=303)
        except Exception:
            return None

    # ====
    # HELPERS
    # ====
    def _normalize_payload(self, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        if "role" not in data:
            ur = data.get("userRole")
            if isinstance(ur, dict):
                data["role"] = (
                    ur.get("name") or ur.get("slug") or ur.get(
                        "role") or ur.get("value") or ur.get("id")
                )
            elif isinstance(ur, str):
                data["role"] = ur

        return data

    def _calculate_expiration(self, duration: str) -> int:
        match = re.match(r"^(\d+)(s|m|h|d)$", duration)
        if not match:
            raise ValueError(f"Invalid duration format: {duration}")

        value, unit = int(match.group(1)), match.group(2)
        delta = {
            "s": timedelta(seconds=value),
            "m": timedelta(minutes=value),
            "h": timedelta(hours=value),
            "d": timedelta(days=value),
        }[unit]

        return int((datetime.now(timezone.utc) + delta).timestamp())

    def _find_provider(self, providers, provider_type):
        for p in providers:
            if isinstance(p, provider_type):
                return p
        return None


# Singleton instance
auth = Auth.get_instance()


# ====
# BACKWARDS COMPATIBILITY
# ====
class AuthConfig:
    """Backwards compatibility alias."""
    PUBLIC_ROUTES = property(lambda self: _settings.public_routes)
    PRIVATE_ROUTES = property(lambda self: _settings.private_routes)
    AUTH_ROUTES = property(lambda self: _settings.auth_routes)
    IS_ALL_ROUTES_PRIVATE = property(
        lambda self: _settings.is_all_routes_private)
    DEFAULT_SIGNIN_REDIRECT = property(
        lambda self: _settings.default_signin_redirect)
    DEFAULT_SIGNOUT_REDIRECT = property(
        lambda self: _settings.default_signout_redirect)

    @staticmethod
    def check_auth_role(user: Any, allowed_roles: List[str]) -> bool:
        return auth.check_role(user, allowed_roles)


# ====
# DECORATORS
# ====
def require_auth(redirect_to: Optional[str] = None):
    """Decorator to require authentication for a route."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request = Auth.get_request()
            if not auth.is_authenticated():
                target = redirect_to or "/signin"
                next_url = request.url.path if request else "/"
                return RedirectResponse(url=f"{target}?next={next_url}", status_code=303)
            return await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
        return wrapper
    return decorator


def require_role(*roles: str, redirect_to: str = "/unauthorized"):
    """Decorator to require specific roles for a route. Roles are strings."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request = Auth.get_request()
            if not auth.is_authenticated():
                path = request.url.path if request else "/"
                return RedirectResponse(url=f"/signin?next={path}", status_code=303)

            user = auth.get_payload()
            if not auth.check_role(user, list(roles)):
                return RedirectResponse(url=redirect_to, status_code=303)

            return await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
        return wrapper
    return decorator


def guest_only(redirect_to: Optional[str] = None):
    """Decorator for routes that should only be accessible to non-authenticated users."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request = Auth.get_request()
            if auth.is_authenticated():
                target = redirect_to or auth.settings.default_signin_redirect
                next_url = request.query_params.get(
                    "next", target) if request else target
                return RedirectResponse(url=next_url, status_code=303)
            return await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
        return wrapper
    return decorator


def get_csrf_token() -> str:
    """Get or generate CSRF token from session."""
    request = Auth.get_request()
    if request and hasattr(request, 'session'):
        csrf_token = request.session.get("csrf_token")
        if not csrf_token:
            csrf_token = secrets.token_hex(32)
            request.session["csrf_token"] = csrf_token
        return csrf_token
    return ""
