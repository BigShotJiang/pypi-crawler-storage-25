from __future__ import annotations

from bs4 import BeautifulSoup
from bs4.builder._htmlparser import HTMLParserTreeBuilder
from bs4.element import Comment, Declaration, Doctype, NavigableString, Tag
from typing import Iterable, Optional


IGNORABLE_NODE_TYPES = (Comment, Declaration, Doctype)


class _PreserveAllWhitespaceTags:
    def __contains__(self, tag_name: object) -> bool:
        return isinstance(tag_name, str)


def _create_fragment_builder() -> HTMLParserTreeBuilder:
    # Fragment parsing needs source-faithful whitespace so component projection
    # and runtime-owned templates survive round-trips through BeautifulSoup.
    return HTMLParserTreeBuilder(
        preserve_whitespace_tags=_PreserveAllWhitespaceTags(),
    )


def parse_fragment(html: str) -> BeautifulSoup:
    return BeautifulSoup(str(html), builder=_create_fragment_builder())


def serialize_fragment(soup: BeautifulSoup | Tag) -> str:
    if isinstance(soup, BeautifulSoup):
        return str(soup)
    return "".join(str(child) for child in soup.contents)


def is_ignorable_top_level_node(node) -> bool:
    if isinstance(node, IGNORABLE_NODE_TYPES):
        return True
    if isinstance(node, NavigableString):
        return not str(node).replace("\ufeff", "").strip()
    return False


def top_level_elements(soup: BeautifulSoup | Tag) -> list[Tag]:
    return [
        node for node in soup.contents
        if isinstance(node, Tag)
    ]


def significant_top_level_nodes(soup: BeautifulSoup | Tag) -> list:
    return [
        node for node in soup.contents
        if not is_ignorable_top_level_node(node)
    ]


def find_single_root_element(html: str) -> Optional[Tag]:
    soup = parse_fragment(html)
    significant = significant_top_level_nodes(soup)
    if len(significant) != 1 or not isinstance(significant[0], Tag):
        return None
    return significant[0]


def append_html(target: Tag, html_items: Iterable[str]) -> None:
    for item in html_items:
        fragment = parse_fragment(item)
        for child in list(fragment.contents):
            target.append(child.extract())


def replace_tag_with_html(tag: Tag, html: str) -> None:
    fragment = parse_fragment(html)
    new_nodes = list(fragment.contents)
    if not new_nodes:
        tag.decompose()
        return

    first = new_nodes[0].extract()
    tag.replace_with(first)
    cursor = first
    for node in new_nodes[1:]:
        cursor.insert_after(node.extract())
        cursor = node
