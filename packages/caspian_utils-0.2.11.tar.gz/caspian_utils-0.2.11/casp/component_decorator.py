from .layout import RenderedTemplate, compile_template, load_template_file
from .html_attrs import get_attributes, merge_classes
from .syntax_compiler import transpile_syntax
from .caspian_config import get_config
from typing import Callable, TypeVar, Dict, Optional, Any, Union
from collections import OrderedDict
from markupsafe import Markup
import inspect
import os
import importlib
import importlib.util
import time

R = TypeVar('R')

_component_registry: Dict[str, 'Component'] = {}
_COMPONENT_CACHE_MAX = 128
_component_load_cache = OrderedDict()
_COMPONENT_PATH_CACHE_MAX = 256
_component_path_cache = OrderedDict()
_COMPONENT_STAT_CACHE_MAX = 256
_COMPONENT_STAT_CACHE_WINDOW_NS = 50_000_000
_component_stat_cache = OrderedDict()


def _remember_component(cache_key, mtime_ns: int, component: 'Component') -> None:
    _component_load_cache[cache_key] = (mtime_ns, component)
    _component_load_cache.move_to_end(cache_key)
    while len(_component_load_cache) > _COMPONENT_CACHE_MAX:
        _component_load_cache.popitem(last=False)


def _remember_component_path(cache_key, file_path: str) -> None:
    _component_path_cache[cache_key] = file_path
    _component_path_cache.move_to_end(cache_key)
    while len(_component_path_cache) > _COMPONENT_PATH_CACHE_MAX:
        _component_path_cache.popitem(last=False)


def _remember_component_stat(file_path: str, checked_at_ns: int, mtime_ns: int) -> None:
    _component_stat_cache[file_path] = (checked_at_ns, mtime_ns)
    _component_stat_cache.move_to_end(file_path)
    while len(_component_stat_cache) > _COMPONENT_STAT_CACHE_MAX:
        _component_stat_cache.popitem(last=False)


def _get_component_mtime_ns(file_path: str) -> int:
    now_ns = time.perf_counter_ns()
    cached = _component_stat_cache.get(file_path)
    if cached is not None and now_ns - cached[0] <= _COMPONENT_STAT_CACHE_WINDOW_NS:
        _component_stat_cache.move_to_end(file_path)
        return cached[1]

    mtime_ns = os.stat(file_path).st_mtime_ns
    _remember_component_stat(file_path, now_ns, mtime_ns)
    return mtime_ns


def _resolve_component_file_path(path: str, component_name: str, base_dir: str = "") -> str:
    cache_key = (path, component_name, base_dir)
    cached_path = _component_path_cache.get(cache_key)
    if cached_path is not None:
        _component_path_cache.move_to_end(cache_key)
        return cached_path

    if path == '.' or path == './':
        full_path = os.path.join(
            base_dir, f"{component_name}.py") if base_dir else f"{component_name}.py"
    elif path.startswith('./') or path.startswith('../') or path == '..':
        full_path = os.path.normpath(os.path.join(
            base_dir, path)) if base_dir else os.path.normpath(path)
    else:
        full_path = path

    if full_path.endswith('.py'):
        file_path = full_path
    elif os.path.isdir(full_path):
        file_path = os.path.join(full_path, f"{component_name}.py")
    else:
        file_path = f"{full_path}.py" if not os.path.isdir(
            full_path) else os.path.join(full_path, f"{component_name}.py")

    resolved_path = os.path.abspath(file_path)
    _remember_component_path(cache_key, resolved_path)
    return resolved_path


class Component:
    """Wrapper class for PulsePoint components (sync & async)"""
    _is_pp_component: bool = True
    source_path: Optional[str] = None

    def __init__(self, fn: Callable, source_path: Optional[str] = None):
        self.fn = fn
        self.is_async = inspect.iscoroutinefunction(fn)
        self.source_path = source_path
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__
        self.__signature__ = inspect.signature(fn)
        self.accepts_children = 'children' in self.__signature__.parameters or any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in self.__signature__.parameters.values()
        )
        _component_registry[fn.__name__] = self

    def _resolve_class_props(self, kwargs: dict) -> dict:
        """Normalize class / class_name / className into a single class value."""
        c_raw = kwargs.get("class")
        c_name = kwargs.get("class_name")
        c_react = kwargs.pop("className", None)

        candidates = [c for c in [c_raw, c_name, c_react] if c]

        if candidates:
            try:
                cfg = get_config()
                use_tailwind = cfg.tailwindcss
            except Exception:
                use_tailwind = False

            if use_tailwind:
                merged = merge_classes(*candidates)
            else:
                parts = []
                for c in candidates:
                    if isinstance(c, (list, tuple, set)):
                        parts.append(" ".join(str(x) for x in c if x))
                    else:
                        parts.append(str(c).strip())
                merged = " ".join(p for p in parts if p)

            kwargs["class"] = merged

            if "class_name" in self.__signature__.parameters:
                kwargs["class_name"] = merged
            else:
                kwargs.pop("class_name", None)

        if "htmlFor" in kwargs:
            kwargs["html_for"] = kwargs.pop("htmlFor")

        return kwargs

    def __call__(self, *args, **kwargs) -> Union[str, Markup]:
        """Sync call — only works for sync components."""
        kwargs = self._resolve_class_props(kwargs)

        if self.is_async:
            raise RuntimeError(
                f"Async component '{self.__name__}' must be rendered through the async pipeline. "
                f"Use 'await {self.__name__}.acall()' instead."
            )

        result = self.fn(*args, **kwargs)
        if isinstance(result, str) and not isinstance(result, Markup):
            return Markup(result)
        return result

    async def acall(self, *args, **kwargs) -> Union[str, Markup]:
        """Async call — works for BOTH sync and async components."""
        kwargs = self._resolve_class_props(kwargs)

        if self.is_async:
            result = await self.fn(*args, **kwargs)
        else:
            result = self.fn(*args, **kwargs)

        if isinstance(result, str) and not isinstance(result, Markup):
            return Markup(result)
        return result


def component(fn: Callable) -> Component:
    """Decorator to mark and register a PulsePoint component (sync or async)"""
    return Component(fn)


def load_component_from_path(path: str, component_name: str, base_dir: str = "") -> Component | None:
    file_path = _resolve_component_file_path(path, component_name, base_dir)

    try:
        mtime_ns = _get_component_mtime_ns(file_path)
    except OSError:
        return None

    cache_key = (file_path, component_name)
    cached = _component_load_cache.get(cache_key)
    if cached is not None and cached[0] == mtime_ns:
        _component_load_cache.move_to_end(cache_key)
        cached_component = cached[1]
        cached_component.source_path = file_path
        return cached_component

    cached_mtime_ns = cached[0] if cached is not None else None

    try:
        cwd = os.path.abspath(os.getcwd())
        try:
            is_local_module = os.path.commonpath([cwd, file_path]) == cwd
        except ValueError:
            is_local_module = False

        if is_local_module:
            rel_path = os.path.relpath(file_path, cwd)
            if not rel_path.startswith('..'):
                module_name = os.path.splitext(
                    rel_path)[0].replace(os.sep, '.')
                module = importlib.import_module(module_name)
                if cached_mtime_ns is not None and cached_mtime_ns != mtime_ns:
                    module = importlib.reload(module)
                comp = getattr(module, component_name, None)
                if isinstance(comp, Component):
                    comp.source_path = file_path
                    _remember_component(cache_key, mtime_ns, comp)
                    return comp
    except (ImportError, ValueError, AttributeError):
        pass

    try:
        unique_module_name = f"pp_component_{file_path.replace(os.sep, '_').replace('.', '_')}"
        spec = importlib.util.spec_from_file_location(
            unique_module_name, file_path)
        if spec is None or spec.loader is None:
            return None
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        comp = getattr(module, component_name, None)
        if isinstance(comp, Component):
            comp.source_path = file_path
            _remember_component(cache_key, mtime_ns, comp)
            return comp
    except Exception as e:
        print(
            f"Error loading component {component_name} from {file_path}: {e}")
        return None

    return None


# ====
# TEMPLATE RENDERING (Jinja2 powered)
# ====

def render_html(file_path: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> str:
    """
    Load HTML template and render with Jinja2.
    Supports passing a dictionary of props as the second argument.

    Usage:
        render_html(__file__, {"prop": "val"}) 
        # or 
        render_html(__file__, prop="val")
    """
    # 1. Merge Context
    final_context = {}

    if context is not None:
        if isinstance(context, dict):
            final_context.update(context)
        else:
            final_context['context'] = context

    final_context.update(kwargs)

    # 2. Resolve file path relative to caller
    frame = inspect.currentframe()
    if frame and frame.f_back:
        caller_file = frame.f_back.f_globals.get('__file__', '')
        if caller_file:
            base_dir = os.path.dirname(caller_file)
            full_path = os.path.join(base_dir, file_path)
        else:
            full_path = file_path
    else:
        full_path = file_path

    if full_path.endswith('.py'):
        full_path = full_path[:-3] + '.html'

    content = load_template_file(full_path)
    content = transpile_syntax(content)

    # 3. EXTRACT CHILDREN
    children_content = final_context.pop("children", "")

    # 4. MARK CHILDREN AS SAFE
    safe_children = Markup(children_content) if children_content else ""

    # 5. GENERATE ATTRIBUTES
    props_string = get_attributes(final_context)

    # 6. RENDER
    template = compile_template(content)
    rendered = template.render(props=props_string, children=safe_children, **final_context)
    return RenderedTemplate(rendered, os.path.abspath(full_path))


# ====
# EXPORTS
# ====

__all__ = [
    'Component',
    'component',
    'load_component_from_path',
    'render_html',
    '_component_registry',
]
