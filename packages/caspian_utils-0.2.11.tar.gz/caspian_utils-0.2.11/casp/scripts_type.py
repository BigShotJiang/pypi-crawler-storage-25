from __future__ import annotations

from .html_native import parse_fragment, serialize_fragment


def transform_scripts(html_content: str) -> str:
    """Add type='text/pp' to body script tags using native HTML parsing."""
    html_content = str(html_content)
    if '<script' not in html_content.lower() or '<body' not in html_content.lower():
        return html_content

    soup = parse_fragment(html_content)
    body = soup.body
    if body is None:
        return html_content

    changed = False
    for script in body.find_all('script'):
        if not script.has_attr('type'):
            script['type'] = 'text/pp'
            changed = True

    if not changed:
        return html_content

    return serialize_fragment(soup)

