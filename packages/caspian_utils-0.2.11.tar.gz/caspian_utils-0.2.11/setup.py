from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='caspian-utils',
    version='0.2.11',
    author='Jefferson Abraham',
    packages=find_packages(),
    install_requires=[
        "fastapi==0.136.1",
        "uvicorn==0.46.0",
        "python-dotenv==1.2.2",
        "jinja2==3.1.6",
        "tailwind-merge==0.3.3",
        "slowapi==0.1.9",
        "python-multipart==0.0.27",
        "starsessions==2.2.1",
        "httpx==0.28.1",
        "werkzeug==3.1.8",
        "cuid2==2.0.1",
        "nanoid==2.0.0",
        "python-ulid==3.1.0",
    ],
    description='A utility package for Caspian projects',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/TheSteelNinjaCode/caspian_utils',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.14',
)
