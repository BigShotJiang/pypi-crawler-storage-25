"""
Configuration for advance tests.
"""

