"""
Core tests for xwjson.
"""
