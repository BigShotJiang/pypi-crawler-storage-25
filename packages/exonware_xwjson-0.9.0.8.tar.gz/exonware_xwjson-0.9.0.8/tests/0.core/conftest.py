"""
Configuration for core tests.
"""

