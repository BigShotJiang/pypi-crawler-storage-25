"""
Unit tests for xwjson.
"""
