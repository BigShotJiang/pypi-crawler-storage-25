"""
Configuration for unit tests.
"""

