"""
Configuration for integration tests.
"""

