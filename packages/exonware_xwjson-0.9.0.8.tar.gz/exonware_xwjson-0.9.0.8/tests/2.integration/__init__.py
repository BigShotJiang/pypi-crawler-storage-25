"""
Integration tests for xwjson.
"""
