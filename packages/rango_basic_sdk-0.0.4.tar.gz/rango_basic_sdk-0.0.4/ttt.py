import decimal

from rango_basic_sdk import AsyncClient as RangoClient
from rango_basic_sdk.models import Blockchain, XrplChangeTrustLinePrerequisite


if __name__ == '__main__':
    async def _main():
        _rango = RangoClient(
            base_url='http://localhost:8080',
            api_key='4a624ab5-16ff-4f96-90b7-ab00ddfc342c',
            log_http_debug=True,
        )

        from_ = 'XRPL.XRP'
        to_ = 'XRPL.RLUSD--RLUSD-rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De'
        amount_mr = 1500000

        quote = await _rango.routing.quote(
            from_=from_,
            to=to_,
            amount=amount_mr,
            slippage=3.0,
        )
        print('quote')
        print(quote)
        print(quote.route)
        print(quote.route.swapper)

        swap = await _rango.transaction.swap(
            from_=from_,
            to=to_,
            amount=amount_mr,
            slippage=3.0,
            from_address='rPWrVmZQ3kBhxiBMdk9zqnkpF2MUhobi8x',
            to_address='rPWrVmZQ3kBhxiBMdk9zqnkpF2MUhobi8x',
            disable_estimate=True,
            # swappers=['NearIntent'],
            # swappers_exclude=True,
        )

        print('swap')
        print(swap)
        print(swap.route)
        print(swap.tx)
        print('type of swap.tx')
        print(type(swap.tx))


    import asyncio

    asyncio.run(_main())