from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import os

from pydantic import TypeAdapter

import httpx
import logging

from . import models

# First ``servers`` URL from the OpenAPI document (``None`` if the spec defines none).
DEFAULT_SERVER_URL: Optional[str] = "https://public-api.rango.exchange"

_log = logging.getLogger(__name__)
_MAX_HTTP_DEBUG_BODY = 16_384


def _truncate_debug_text(s: str, limit: int = _MAX_HTTP_DEBUG_BODY) -> str:
    if len(s) <= limit:
        return s
    return s[:limit] + "…(truncated)"


def _sync_http_debug_event_hooks() -> Dict[str, List[Any]]:
    """Log each request/response pair at DEBUG after the response is received."""

    def on_response(response: httpx.Response) -> None:
        response.read()
        req = response.request
        req_body = ""
        try:
            raw = req.content
            if raw:
                req_body = _truncate_debug_text(raw.decode("utf-8", errors="replace"))
        except Exception:
            req_body = "<request body unavailable>"
        resp_body = ""
        try:
            if response.content:
                resp_body = _truncate_debug_text(response.text)
        except Exception:
            resp_body = "<response body unavailable>"
        _log.debug(
            "HTTP %s %s -> %s %s | request_headers=%r request_body=%r | "
            "response_headers=%r response_body=%r",
            req.method,
            req.url,
            response.status_code,
            response.reason_phrase,
            dict(req.headers),
            req_body or "(empty)",
            dict(response.headers),
            resp_body or "(empty)",
        )

    return {"response": [on_response]}


def _async_http_debug_event_hooks() -> Dict[str, List[Any]]:
    async def on_response(response: httpx.Response) -> None:
        await response.aread()
        req = response.request
        req_body = ""
        try:
            raw = req.content
            if raw:
                req_body = _truncate_debug_text(raw.decode("utf-8", errors="replace"))
        except Exception:
            req_body = "<request body unavailable>"
        resp_body = ""
        try:
            if response.content:
                resp_body = _truncate_debug_text(response.text)
        except Exception:
            resp_body = "<response body unavailable>"
        _log.debug(
            "HTTP %s %s -> %s %s | request_headers=%r request_body=%r | "
            "response_headers=%r response_body=%r",
            req.method,
            req.url,
            response.status_code,
            response.reason_phrase,
            dict(req.headers),
            req_body or "(empty)",
            dict(response.headers),
            resp_body or "(empty)",
        )

    return {"response": [on_response]}


def _security_value_from_kw_or_env(
    value: Optional[str], env_name: str
) -> Optional[str]:
    """Use the constructor keyword when provided; otherwise read *env_name* from the OS environment."""
    if value is not None:
        return value
    found = os.environ.get(env_name)
    return found if found else None


class BalanceOperations:
    """Operations with tag ``Balance``."""

    def __init__(self, root: Client) -> None:
        self._root = root

    def balance(
        self, blockchain: models.Blockchain, address: str
    ) -> Optional[models.WalletDetailsResponse]:
        """
        Balance

        Get all tokens' balances for the given wallet address.

        Args:
            blockchain (models.Blockchain): Blockchain Wire name ``blockchain`` (query).
            address (str): User's wallet address Wire name ``address`` (query).

        Returns:
            ``Optional[models.WalletDetailsResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.balance.balance(blockchain=models.Blockchain.BSC, address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88")
                    print(result)
        """
        url = f"/basic/balance"
        params: Dict[str, Any] = {}
        params["blockchain"] = blockchain
        params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.WalletDetailsResponse.model_validate(response.json())

    def get_token_balance(
        self,
        wallet_address: str,
        blockchain: models.Blockchain,
        symbol: str,
        address: Optional[str] = None,
    ) -> Optional[models.TokenBalanceResponse]:
        """
        Token Balance

        Get balance of the given wallet address for a specific token.

        Args:
            wallet_address (str): User's wallet address Wire name ``walletAddress``
                                  (query).
            blockchain (models.Blockchain): Blockchain Wire name ``blockchain`` (query).
            symbol (str): Token Symbol Wire name ``symbol`` (query).
            address (Optional[str]): Token Address, This is ignored or null for native
                                     tokens which have no address Wire name ``address``
                                     (query).

        Returns:
            ``Optional[models.TokenBalanceResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.balance.get_token_balance(wallet_address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88", blockchain=models.Blockchain.BSC, symbol="USDT", address="0x55d398326f99059ff775485246999027b3197955")
                    print(result)
        """
        url = f"/basic/token-balance"
        params: Dict[str, Any] = {}
        params["walletAddress"] = wallet_address
        params["blockchain"] = blockchain
        params["symbol"] = symbol
        if address is not None:
            params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.TokenBalanceResponse.model_validate(response.json())


class MetadataOperations:
    """Operations with tag ``Metadata``."""

    def __init__(self, root: Client) -> None:
        self._root = root

    def get_blockchains(self) -> Optional[List[models.BasicApiBlockchainMeta]]:
        """
        Blockchains Metadata

        Metadata of all blockchains

        Returns:
            ``Optional[List[models.BasicApiBlockchainMeta]]`` — JSON response parsed
            into the declared type when the body is non-empty; ``None`` for HTTP 204/205
            or an empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.metadata.get_blockchains()
                    print(result)
        """
        url = f"/basic/meta/blockchains"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return [
            models.BasicApiBlockchainMeta.model_validate(x) for x in response.json()
        ]

    def get_custom_token_data(
        self, blockchain: models.Blockchain, address: str
    ) -> Optional[models.BasicCustomTokenResponse]:
        """
        Custom token

        Returns the token details for user desired token that is not available on Rango
        official list. currently supports Solana and EVM based blockchains

        Args:
            blockchain (models.Blockchain): The blockchain of the custom token Wire name
                                            ``blockchain`` (query).
            address (str): The address of the custom token Wire name ``address``
                           (query).

        Returns:
            ``Optional[models.BasicCustomTokenResponse]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.metadata.get_custom_token_data(blockchain=models.Blockchain.BSC, address="0x5ac5e6Af46Ef285B3536833E65D245c49b608d9b")
                    print(result)
        """
        url = f"/basic/meta/custom-token"
        params: Dict[str, Any] = {}
        params["blockchain"] = blockchain
        params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicCustomTokenResponse.model_validate(response.json())

    def get_messaging_protocols(self) -> Optional[models.MessagingProtocolsResponse]:
        """
        Messaging Protocols Metadata

        Metadata of all messaging protocols

        Returns:
            ``Optional[models.MessagingProtocolsResponse]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.metadata.get_messaging_protocols()
                    print(result)
        """
        url = f"/basic/meta/messaging-protocols"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.MessagingProtocolsResponse.model_validate(response.json())

    def get_swappers(self) -> Optional[List[models.SwapperMetaFullDto]]:
        """
        Swappers Metadata

        Metadata of all swappers

        Returns:
            ``Optional[List[models.SwapperMetaFullDto]]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.metadata.get_swappers()
                    print(result)
        """
        url = f"/basic/meta/swappers"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return [models.SwapperMetaFullDto.model_validate(x) for x in response.json()]

    def meta(
        self,
        blockchains: Optional[List[models.Blockchain]] = None,
        blockchains_exclude: Optional[bool] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        transaction_types: Optional[List[models.GenericTransactionType]] = None,
        transaction_types_exclude: Optional[bool] = None,
        exclude_non_populars: Optional[bool] = None,
    ) -> Optional[models.BasicApiMetaResponse]:
        """
        Metadata (tokens, swappers, blockchains)

        Get all tokens, DEX, and bridges metadata.

        Args:
            blockchains (Optional[List[models.Blockchain]]): The list of all accepted
                                                             blockchains. An empty list
                                                             means no filter is required
                                                             Wire name ``blockchains``
                                                             (query).
            blockchains_exclude (Optional[bool]): Defines the provided blockchains as
                                                  the include/exclude list. Default is
                                                  false (include) Wire name
                                                  ``blockchainsExclude`` (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            transaction_types (Optional[List[models.GenericTransactionType]]): Blockchain Type Wire
                                                                               name
                                                                               ``transactionTypes``
                                                                               (query).
            transaction_types_exclude (Optional[bool]): Defines the provided swappers'
                                                        tags as the include/exclude
                                                        list. Default is false (include)
                                                        Wire name
                                                        ``transactionTypesExclude``
                                                        (query).
            exclude_non_populars (Optional[bool]): Exclude non popular tokens. Default
                                                   is false (include) Wire name
                                                   ``excludeNonPopulars`` (query).

        Returns:
            ``Optional[models.BasicApiMetaResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.metadata.meta()
                    print(result)
        """
        url = f"/basic/meta"
        params: Dict[str, Any] = {}
        if blockchains is not None:
            params["blockchains"] = blockchains
        if blockchains_exclude is not None:
            params["blockchainsExclude"] = blockchains_exclude
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if transaction_types is not None:
            params["transactionTypes"] = transaction_types
        if transaction_types_exclude is not None:
            params["transactionTypesExclude"] = transaction_types_exclude
        if exclude_non_populars is not None:
            params["excludeNonPopulars"] = exclude_non_populars
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiMetaResponse.model_validate(response.json())


class RoutingOperations:
    """Operations with tag ``Routing``."""

    def __init__(self, root: Client) -> None:
        self._root = root

    def get_connected_assets(
        self, from_: str
    ) -> Optional[models.ConnectedAssetsResponse]:
        """
        Connected Assets

        Get all tokens which has route with single-step swap from intended asset. Empty
        `asset` list in response indicates all assets on that chain are connected

        Args:
            from_ (str): The asset which is going to be swapped into other assets Wire
                         name ``from`` (query).

        Returns:
            ``Optional[models.ConnectedAssetsResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.routing.get_connected_assets(from_="ETH.USDC--0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48")
                    print(result)
        """
        url = f"/basic/connected-assets"
        params: Dict[str, Any] = {}
        params["from"] = from_
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.ConnectedAssetsResponse.model_validate(response.json())

    def quote(
        self,
        from_: str,
        to: str,
        amount: int,
        slippage: Optional[float] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        messaging_protocols: Optional[List[models.ParamMessagingProtocolsItem]] = None,
        im_message: Optional[str] = None,
        source_contract: Optional[str] = None,
        destination_contract: Optional[str] = None,
        contract_call: Optional[bool] = None,
        referrer_code: Optional[str] = None,
        referrer_fee: Optional[float] = None,
        avoid_native_fee: Optional[bool] = None,
        enable_centralized_swappers: Optional[bool] = None,
        header_x_rango_id: Optional[str] = None,
    ) -> Optional[models.BasicApiQuoteResponse]:
        """
        Quote (Get Best Route)

        Get the best route for swapping X to Y via Rango Exchange routing protocol

        Args:
            from_ (str): The asset X that user likes to swap Wire name ``from`` (query).
            to (str): The asset Y that user wants to swap X into that Wire name ``to``
                      (query).
            amount (int): The machine-readable amount of asset X that is going to be
                          swapped Wire name ``amount`` (query).
            slippage (Optional[float]): Amount of user's preferred slippage in percent.
                                        if you don't send it, it will assume 0.5%
                                        slippage Wire name ``slippage`` (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            messaging_protocols (Optional[List[models.ParamMessagingProtocolsItem]]): Message protocols which
                                                                                      will be used to call
                                                                                      message before or after
                                                                                      swap Wire name
                                                                                      ``messagingProtocols``
                                                                                      (query).
            im_message (Optional[str]): Message to call after or before swap transaction
                                        Wire name ``imMessage`` (query).
            source_contract (Optional[str]): Contract address which should be called
                                             before swap transaction Wire name
                                             ``sourceContract`` (query).
            destination_contract (Optional[str]): Contract address which should be
                                                  called after swap transaction Wire
                                                  name ``destinationContract`` (query).
            contract_call (Optional[bool]): set this parameter to `true` if you wants to
                                            send transactions through a contract Wire
                                            name ``contractCall`` (query).
            referrer_code (Optional[str]): Referrer code Wire name ``referrerCode``
                                           (query).
            referrer_fee (Optional[float]): Referrer fee in percent Wire name
                                            ``referrerFee`` (query).
            avoid_native_fee (Optional[bool]): When it is true, Swappers that have
                                               native tokens as fee must be excluded.
                                               example: when you call it from AA
                                               account. Wire name ``avoidNativeFee``
                                               (query).
            enable_centralized_swappers (Optional[bool]): Specify that centralized
                                                          swappers must be included in
                                                          swappers or not. Default is
                                                          false (exclude) Wire name
                                                          ``enableCentralizedSwappers``
                                                          (query).
            header_x_rango_id (Optional[str]): A unique client generated Id, better use
                                               UUID Wire name ``X-Rango-Id`` (header).

        Returns:
            ``Optional[models.BasicApiQuoteResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.routing.quote(from_="BSC.BNB", to="AVAX_CCHAIN.USDT.E--0xc7198437980c041c805a1edcba50c1ce5db95118", amount=10000000000000000, slippage=3.5)
                    print(result)
        """
        url = f"/basic/quote"
        params: Dict[str, Any] = {}
        params["from"] = from_
        params["to"] = to
        params["amount"] = amount
        if slippage is not None:
            params["slippage"] = slippage
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if messaging_protocols is not None:
            params["messagingProtocols"] = messaging_protocols
        if im_message is not None:
            params["imMessage"] = im_message
        if source_contract is not None:
            params["sourceContract"] = source_contract
        if destination_contract is not None:
            params["destinationContract"] = destination_contract
        if contract_call is not None:
            params["contractCall"] = contract_call
        if referrer_code is not None:
            params["referrerCode"] = referrer_code
        if referrer_fee is not None:
            params["referrerFee"] = referrer_fee
        if avoid_native_fee is not None:
            params["avoidNativeFee"] = avoid_native_fee
        if enable_centralized_swappers is not None:
            params["enableCentralizedSwappers"] = enable_centralized_swappers
        req_headers: Dict[str, str] = {}
        if header_x_rango_id is not None:
            req_headers["X-Rango-Id"] = str(header_x_rango_id)
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiQuoteResponse.model_validate(response.json())


class TransactionOperations:
    """Operations with tag ``Transaction``."""

    def __init__(self, root: Client) -> None:
        self._root = root

    def is_approved(
        self, request_id: str, tx_id: str
    ) -> Optional[models.CheckApprovalResponse]:
        """
        Check Approval TX Status

        When swap endpoint returns a non-null value for the approval transaction, and
        user signs that tx, you should periodically call this endpoint to see if the
        approval tx is completed. After a successful check, you could proceed with the
        main transaction.

        Args:
            request_id (str): unique ID generated by quote endpoint Wire name
                              ``requestId`` (query).
            tx_id (str): Approve transaction tx id Wire name ``txId`` (query).

        Returns:
            ``Optional[models.CheckApprovalResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.transaction.is_approved(request_id="b3a12c6d-86b8-4c21-97e4-809151dd4036", tx_id="0x7f17aaba51d1f24204cd8b02251001d3704add46d84840a5826b95ef49b8b74f")
                    print(result)
        """
        url = f"/basic/is-approved"
        params: Dict[str, Any] = {}
        params["requestId"] = request_id
        params["txId"] = tx_id
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.CheckApprovalResponse.model_validate(response.json())

    def report_tx(
        self, body: models.BasicApiReportTransactionRequest
    ) -> Optional[models.BasicApiReportTransactionResponse]:
        """
        Report Failed TX

        Use it when the user rejects the transaction in wallet or the wallet fails to
        handle the transaction. Calling this endpoint is not required, but is useful for
        reporting and we recommend you to call it.Consider that transactions include
        Inbound tx, cannot be reported as failed or canceled!!

        Args:
            body (models.BasicApiReportTransactionRequest): JSON request body.

        Returns:
            ``Optional[models.BasicApiReportTransactionResponse]`` — JSON response
            parsed into the declared type when the body is non-empty; ``None`` for HTTP
            204/205 or an empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.transaction.report_tx(body=models.BasicApiReportTransactionRequest(event_type=models.BasicApiReportTransactionRequestEventType.USER_REJECT, request_id="688b308e-a06b-4a4e-a837-220d458b8642"))
                    print(result)
        """
        url = f"/basic/report-tx"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        json_body: Any = None
        if body is not None:
            json_body = body.model_dump(
                mode="json",
                by_alias=True,
                exclude_none=True,
            )
        response = self._root._client.request(
            "POST",
            url,
            params=params or None,
            headers=req_headers or None,
            json=json_body,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiReportTransactionResponse.model_validate(response.json())

    def status(
        self, request_id: str, tx_id: str
    ) -> Optional[models.BasicApiStatusResponse]:
        """
        Check TX Status

        Check if the user swapp has succeeded or not. When a user signs the swap
        transaction on his/her wallet, you should call this endpoint periodically to see
        the swap status.

        Args:
            request_id (str): unique ID generated by quote endpoint Wire name
                              ``requestId`` (query).
            tx_id (str): Last signed transaction's id Wire name ``txId`` (query).

        Returns:
            ``Optional[models.BasicApiStatusResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.transaction.status(request_id="b3a12c6d-86b8-4c21-97e4-809151dd4036", tx_id="0xfa88b705a5b4049adac7caff50c887d9600ef023ef1a937f8f8b6f44e90042b5")
                    print(result)
        """
        url = f"/basic/status"
        params: Dict[str, Any] = {}
        params["requestId"] = request_id
        params["txId"] = tx_id
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiStatusResponse.model_validate(response.json())

    def swap(
        self,
        from_: str,
        to: str,
        amount: int,
        slippage: float,
        from_address: str,
        to_address: str,
        disable_estimate: Optional[bool] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        messaging_protocols: Optional[List[models.ParamMessagingProtocolsItem]] = None,
        im_message: Optional[str] = None,
        source_contract: Optional[str] = None,
        destination_contract: Optional[str] = None,
        infinite_approve: Optional[bool] = None,
        contract_call: Optional[bool] = None,
        referrer_fee: Optional[float] = None,
        referrer_address: Optional[str] = None,
        referrer_code: Optional[str] = None,
        avoid_native_fee: Optional[bool] = None,
        enable_centralized_swappers: Optional[bool] = None,
        use_max_native_token_balance: Optional[bool] = None,
        header_x_rango_id: Optional[str] = None,
    ) -> Optional[models.BasicApiSwapResponse]:
        """
        Create TX (Swap)

        Generating the transaction data for calling dex/bridge contract via Rango
        Exchange.

        Args:
            from_ (str): The asset X that user likes to swap Wire name ``from`` (query).
            to (str): The asset Y that user wants to swap X into that Wire name ``to``
                      (query).
            amount (int): The machine-readable amount of asset X that is going to be
                          swapped Wire name ``amount`` (query).
            slippage (float): Amount of user's preferred slippage in percent Wire name
                              ``slippage`` (query).
            from_address (str): User wallet address Wire name ``fromAddress`` (query).
            to_address (str): Destination wallet address Wire name ``toAddress``
                              (query).
            disable_estimate (Optional[bool]): This field should be false when the
                                               client wants to preview the route to the
                                               user and true when the user accepts the
                                               swap. If it's true, the server will be
                                               much slower to respond but will check
                                               some prerequisites, including the balance
                                               of X and any required fees in the user's
                                               wallets. Wire name ``disableEstimate``
                                               (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required. Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            messaging_protocols (Optional[List[models.ParamMessagingProtocolsItem]]): Message protocols which
                                                                                      will be used to call
                                                                                      message before or after
                                                                                      swap Wire name
                                                                                      ``messagingProtocols``
                                                                                      (query).
            im_message (Optional[str]): Message to call after or before swap transaction
                                        Wire name ``imMessage`` (query).
            source_contract (Optional[str]): Contract address which should be called
                                             before swap transaction Wire name
                                             ``sourceContract`` (query).
            destination_contract (Optional[str]): Contract address which should be
                                                  called after swap transaction Wire
                                                  name ``destinationContract`` (query).
            infinite_approve (Optional[bool]): Use this parameter if you want infinite
                                               approve from user Wire name
                                               ``infiniteApprove`` (query).
            contract_call (Optional[bool]): set this parameter to `true` if you wants to
                                            send transactions through a contract Wire
                                            name ``contractCall`` (query).
            referrer_fee (Optional[float]): Referrer fee in percent, e.g. 0.3 Wire name
                                            ``referrerFee`` (query).
            referrer_address (Optional[str]): Referrer wallet address on source asset
                                              (from) blockchain Wire name
                                              ``referrerAddress`` (query).
            referrer_code (Optional[str]): Referrer code Wire name ``referrerCode``
                                           (query).
            avoid_native_fee (Optional[bool]): When it is true, Swappers that have
                                               native tokens as fee must be excluded.
                                               example: when you call it from AA
                                               account. Wire name ``avoidNativeFee``
                                               (query).
            enable_centralized_swappers (Optional[bool]): Specify that centralized
                                                          swappers must be included in
                                                          swappers or not. Default is
                                                          false (exclude) Wire name
                                                          ``enableCentralizedSwappers``
                                                          (query).
            use_max_native_token_balance (Optional[bool]): Forces transaction creation
                                                           by subtracting fees from
                                                           input if balance is
                                                           insufficient. Wire name
                                                           ``useMaxNativeTokenBalance``
                                                           (query).
            header_x_rango_id (Optional[str]): A unique client generated Id, better use
                                               UUID Wire name ``X-Rango-Id`` (header).

        Returns:
            ``Optional[models.BasicApiSwapResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                with Client(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = client.transaction.swap(from_="BSC.BNB", to="AVAX_CCHAIN.USDT.E--0xc7198437980c041c805a1edcba50c1ce5db95118", amount=10000000000000000, slippage=3.5, from_address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88", to_address="0x6f33bb1763eebead07cf8815a62fcd7b30311fa3", disable_estimate=False, infinite_approve=False)
                    print(result)
        """
        url = f"/basic/swap"
        params: Dict[str, Any] = {}
        params["from"] = from_
        params["to"] = to
        params["amount"] = amount
        params["slippage"] = slippage
        params["fromAddress"] = from_address
        params["toAddress"] = to_address
        if disable_estimate is not None:
            params["disableEstimate"] = disable_estimate
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if messaging_protocols is not None:
            params["messagingProtocols"] = messaging_protocols
        if im_message is not None:
            params["imMessage"] = im_message
        if source_contract is not None:
            params["sourceContract"] = source_contract
        if destination_contract is not None:
            params["destinationContract"] = destination_contract
        if infinite_approve is not None:
            params["infiniteApprove"] = infinite_approve
        if contract_call is not None:
            params["contractCall"] = contract_call
        if referrer_fee is not None:
            params["referrerFee"] = referrer_fee
        if referrer_address is not None:
            params["referrerAddress"] = referrer_address
        if referrer_code is not None:
            params["referrerCode"] = referrer_code
        if avoid_native_fee is not None:
            params["avoidNativeFee"] = avoid_native_fee
        if enable_centralized_swappers is not None:
            params["enableCentralizedSwappers"] = enable_centralized_swappers
        if use_max_native_token_balance is not None:
            params["useMaxNativeTokenBalance"] = use_max_native_token_balance
        req_headers: Dict[str, str] = {}
        if header_x_rango_id is not None:
            req_headers["X-Rango-Id"] = str(header_x_rango_id)
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiSwapResponse.model_validate(response.json())


class Client:
    """
    Simple and Easy to use APIs for Rango Aggregation protocols for dApps and Wallets
    for single step cross-chain and on-chain swaps using the best route and all the
    available on-chain liquidity across all blockchain networks.

    Pass ``log_http_debug=True`` and configure logging for this module (e.g.
    ``logging.getLogger(__name__).setLevel(logging.DEBUG)`` on ``…client``) to emit each
    HTTP request and response at DEBUG, including headers and bodies. This may log
    credentials—use only in trusted environments.

    Optional ``proxy`` is forwarded to the underlying ``httpx`` client (a proxy URL
    string or ``httpx.URL``).

    Security credentials may be passed as constructor keyword arguments or read from
    environment variables (see the README); constructor values take precedence when both
    are set.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        *,
        api_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        proxy: Optional[Union[str, httpx.URL]] = None,
        log_http_debug: bool = False,
    ) -> None:
        _resolved = base_url if base_url is not None else DEFAULT_SERVER_URL
        if not _resolved:
            raise ValueError(
                "No base URL: pass base_url=… or define servers in the OpenAPI document.",
            )
        self._base_url = _resolved.rstrip("/")
        self._headers = dict(headers or {})
        self._proxy = proxy
        self._sec_apiKey = _security_value_from_kw_or_env(
            api_key,
            "RANGO_BASIC_API_KEY",
        )
        if not self._sec_apiKey:
            raise ValueError(
                "OpenAPI security scheme "
                + "apiKey"
                + ": pass keyword argument "
                + "api_key"
                + ", or set environment variable "
                + "RANGO_BASIC_API_KEY"
                + "."
            )

        _hooks: Optional[Dict[str, List[Any]]] = (
            _sync_http_debug_event_hooks() if log_http_debug else None
        )
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=self._headers,
            timeout=timeout,
            proxy=self._proxy,
            event_hooks=_hooks,
        )
        self.balance = BalanceOperations(self)
        self.metadata = MetadataOperations(self)
        self.routing = RoutingOperations(self)
        self.transaction = TransactionOperations(self)

    def _apply_security(
        self,
        operation_scheme_keys: List[str],
        params: Dict[str, Any],
        headers: Dict[str, str],
        cookies: Optional[Dict[str, str]],
    ) -> None:
        if "apiKey" in operation_scheme_keys and self._sec_apiKey is not None:
            params["apiKey"] = self._sec_apiKey

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncBalanceOperations:
    """Operations with tag ``Balance``."""

    def __init__(self, root: AsyncClient) -> None:
        self._root = root

    async def balance(
        self, blockchain: models.Blockchain, address: str
    ) -> Optional[models.WalletDetailsResponse]:
        """
        Balance

        Get all tokens' balances for the given wallet address.

        Args:
            blockchain (models.Blockchain): Blockchain Wire name ``blockchain`` (query).
            address (str): User's wallet address Wire name ``address`` (query).

        Returns:
            ``Optional[models.WalletDetailsResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.balance.balance(blockchain=models.Blockchain.BSC, address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88")
                    print(result)
        """
        url = f"/basic/balance"
        params: Dict[str, Any] = {}
        params["blockchain"] = blockchain
        params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.WalletDetailsResponse.model_validate(response.json())

    async def get_token_balance(
        self,
        wallet_address: str,
        blockchain: models.Blockchain,
        symbol: str,
        address: Optional[str] = None,
    ) -> Optional[models.TokenBalanceResponse]:
        """
        Token Balance

        Get balance of the given wallet address for a specific token.

        Args:
            wallet_address (str): User's wallet address Wire name ``walletAddress``
                                  (query).
            blockchain (models.Blockchain): Blockchain Wire name ``blockchain`` (query).
            symbol (str): Token Symbol Wire name ``symbol`` (query).
            address (Optional[str]): Token Address, This is ignored or null for native
                                     tokens which have no address Wire name ``address``
                                     (query).

        Returns:
            ``Optional[models.TokenBalanceResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.balance.get_token_balance(wallet_address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88", blockchain=models.Blockchain.BSC, symbol="USDT", address="0x55d398326f99059ff775485246999027b3197955")
                    print(result)
        """
        url = f"/basic/token-balance"
        params: Dict[str, Any] = {}
        params["walletAddress"] = wallet_address
        params["blockchain"] = blockchain
        params["symbol"] = symbol
        if address is not None:
            params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.TokenBalanceResponse.model_validate(response.json())


class AsyncMetadataOperations:
    """Operations with tag ``Metadata``."""

    def __init__(self, root: AsyncClient) -> None:
        self._root = root

    async def get_blockchains(self) -> Optional[List[models.BasicApiBlockchainMeta]]:
        """
        Blockchains Metadata

        Metadata of all blockchains

        Returns:
            ``Optional[List[models.BasicApiBlockchainMeta]]`` — JSON response parsed
            into the declared type when the body is non-empty; ``None`` for HTTP 204/205
            or an empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.metadata.get_blockchains()
                    print(result)
        """
        url = f"/basic/meta/blockchains"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return [
            models.BasicApiBlockchainMeta.model_validate(x) for x in response.json()
        ]

    async def get_custom_token_data(
        self, blockchain: models.Blockchain, address: str
    ) -> Optional[models.BasicCustomTokenResponse]:
        """
        Custom token

        Returns the token details for user desired token that is not available on Rango
        official list. currently supports Solana and EVM based blockchains

        Args:
            blockchain (models.Blockchain): The blockchain of the custom token Wire name
                                            ``blockchain`` (query).
            address (str): The address of the custom token Wire name ``address``
                           (query).

        Returns:
            ``Optional[models.BasicCustomTokenResponse]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.metadata.get_custom_token_data(blockchain=models.Blockchain.BSC, address="0x5ac5e6Af46Ef285B3536833E65D245c49b608d9b")
                    print(result)
        """
        url = f"/basic/meta/custom-token"
        params: Dict[str, Any] = {}
        params["blockchain"] = blockchain
        params["address"] = address
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicCustomTokenResponse.model_validate(response.json())

    async def get_messaging_protocols(
        self,
    ) -> Optional[models.MessagingProtocolsResponse]:
        """
        Messaging Protocols Metadata

        Metadata of all messaging protocols

        Returns:
            ``Optional[models.MessagingProtocolsResponse]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.metadata.get_messaging_protocols()
                    print(result)
        """
        url = f"/basic/meta/messaging-protocols"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.MessagingProtocolsResponse.model_validate(response.json())

    async def get_swappers(self) -> Optional[List[models.SwapperMetaFullDto]]:
        """
        Swappers Metadata

        Metadata of all swappers

        Returns:
            ``Optional[List[models.SwapperMetaFullDto]]`` — JSON response parsed into
            the declared type when the body is non-empty; ``None`` for HTTP 204/205 or
            an empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.metadata.get_swappers()
                    print(result)
        """
        url = f"/basic/meta/swappers"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return [models.SwapperMetaFullDto.model_validate(x) for x in response.json()]

    async def meta(
        self,
        blockchains: Optional[List[models.Blockchain]] = None,
        blockchains_exclude: Optional[bool] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        transaction_types: Optional[List[models.GenericTransactionType]] = None,
        transaction_types_exclude: Optional[bool] = None,
        exclude_non_populars: Optional[bool] = None,
    ) -> Optional[models.BasicApiMetaResponse]:
        """
        Metadata (tokens, swappers, blockchains)

        Get all tokens, DEX, and bridges metadata.

        Args:
            blockchains (Optional[List[models.Blockchain]]): The list of all accepted
                                                             blockchains. An empty list
                                                             means no filter is required
                                                             Wire name ``blockchains``
                                                             (query).
            blockchains_exclude (Optional[bool]): Defines the provided blockchains as
                                                  the include/exclude list. Default is
                                                  false (include) Wire name
                                                  ``blockchainsExclude`` (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            transaction_types (Optional[List[models.GenericTransactionType]]): Blockchain Type Wire
                                                                               name
                                                                               ``transactionTypes``
                                                                               (query).
            transaction_types_exclude (Optional[bool]): Defines the provided swappers'
                                                        tags as the include/exclude
                                                        list. Default is false (include)
                                                        Wire name
                                                        ``transactionTypesExclude``
                                                        (query).
            exclude_non_populars (Optional[bool]): Exclude non popular tokens. Default
                                                   is false (include) Wire name
                                                   ``excludeNonPopulars`` (query).

        Returns:
            ``Optional[models.BasicApiMetaResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.metadata.meta()
                    print(result)
        """
        url = f"/basic/meta"
        params: Dict[str, Any] = {}
        if blockchains is not None:
            params["blockchains"] = blockchains
        if blockchains_exclude is not None:
            params["blockchainsExclude"] = blockchains_exclude
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if transaction_types is not None:
            params["transactionTypes"] = transaction_types
        if transaction_types_exclude is not None:
            params["transactionTypesExclude"] = transaction_types_exclude
        if exclude_non_populars is not None:
            params["excludeNonPopulars"] = exclude_non_populars
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiMetaResponse.model_validate(response.json())


class AsyncRoutingOperations:
    """Operations with tag ``Routing``."""

    def __init__(self, root: AsyncClient) -> None:
        self._root = root

    async def get_connected_assets(
        self, from_: str
    ) -> Optional[models.ConnectedAssetsResponse]:
        """
        Connected Assets

        Get all tokens which has route with single-step swap from intended asset. Empty
        `asset` list in response indicates all assets on that chain are connected

        Args:
            from_ (str): The asset which is going to be swapped into other assets Wire
                         name ``from`` (query).

        Returns:
            ``Optional[models.ConnectedAssetsResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.routing.get_connected_assets(from_="ETH.USDC--0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48")
                    print(result)
        """
        url = f"/basic/connected-assets"
        params: Dict[str, Any] = {}
        params["from"] = from_
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.ConnectedAssetsResponse.model_validate(response.json())

    async def quote(
        self,
        from_: str,
        to: str,
        amount: int,
        slippage: Optional[float] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        messaging_protocols: Optional[List[models.ParamMessagingProtocolsItem]] = None,
        im_message: Optional[str] = None,
        source_contract: Optional[str] = None,
        destination_contract: Optional[str] = None,
        contract_call: Optional[bool] = None,
        referrer_code: Optional[str] = None,
        referrer_fee: Optional[float] = None,
        avoid_native_fee: Optional[bool] = None,
        enable_centralized_swappers: Optional[bool] = None,
        header_x_rango_id: Optional[str] = None,
    ) -> Optional[models.BasicApiQuoteResponse]:
        """
        Quote (Get Best Route)

        Get the best route for swapping X to Y via Rango Exchange routing protocol

        Args:
            from_ (str): The asset X that user likes to swap Wire name ``from`` (query).
            to (str): The asset Y that user wants to swap X into that Wire name ``to``
                      (query).
            amount (int): The machine-readable amount of asset X that is going to be
                          swapped Wire name ``amount`` (query).
            slippage (Optional[float]): Amount of user's preferred slippage in percent.
                                        if you don't send it, it will assume 0.5%
                                        slippage Wire name ``slippage`` (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            messaging_protocols (Optional[List[models.ParamMessagingProtocolsItem]]): Message protocols which
                                                                                      will be used to call
                                                                                      message before or after
                                                                                      swap Wire name
                                                                                      ``messagingProtocols``
                                                                                      (query).
            im_message (Optional[str]): Message to call after or before swap transaction
                                        Wire name ``imMessage`` (query).
            source_contract (Optional[str]): Contract address which should be called
                                             before swap transaction Wire name
                                             ``sourceContract`` (query).
            destination_contract (Optional[str]): Contract address which should be
                                                  called after swap transaction Wire
                                                  name ``destinationContract`` (query).
            contract_call (Optional[bool]): set this parameter to `true` if you wants to
                                            send transactions through a contract Wire
                                            name ``contractCall`` (query).
            referrer_code (Optional[str]): Referrer code Wire name ``referrerCode``
                                           (query).
            referrer_fee (Optional[float]): Referrer fee in percent Wire name
                                            ``referrerFee`` (query).
            avoid_native_fee (Optional[bool]): When it is true, Swappers that have
                                               native tokens as fee must be excluded.
                                               example: when you call it from AA
                                               account. Wire name ``avoidNativeFee``
                                               (query).
            enable_centralized_swappers (Optional[bool]): Specify that centralized
                                                          swappers must be included in
                                                          swappers or not. Default is
                                                          false (exclude) Wire name
                                                          ``enableCentralizedSwappers``
                                                          (query).
            header_x_rango_id (Optional[str]): A unique client generated Id, better use
                                               UUID Wire name ``X-Rango-Id`` (header).

        Returns:
            ``Optional[models.BasicApiQuoteResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.routing.quote(from_="BSC.BNB", to="AVAX_CCHAIN.USDT.E--0xc7198437980c041c805a1edcba50c1ce5db95118", amount=10000000000000000, slippage=3.5)
                    print(result)
        """
        url = f"/basic/quote"
        params: Dict[str, Any] = {}
        params["from"] = from_
        params["to"] = to
        params["amount"] = amount
        if slippage is not None:
            params["slippage"] = slippage
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if messaging_protocols is not None:
            params["messagingProtocols"] = messaging_protocols
        if im_message is not None:
            params["imMessage"] = im_message
        if source_contract is not None:
            params["sourceContract"] = source_contract
        if destination_contract is not None:
            params["destinationContract"] = destination_contract
        if contract_call is not None:
            params["contractCall"] = contract_call
        if referrer_code is not None:
            params["referrerCode"] = referrer_code
        if referrer_fee is not None:
            params["referrerFee"] = referrer_fee
        if avoid_native_fee is not None:
            params["avoidNativeFee"] = avoid_native_fee
        if enable_centralized_swappers is not None:
            params["enableCentralizedSwappers"] = enable_centralized_swappers
        req_headers: Dict[str, str] = {}
        if header_x_rango_id is not None:
            req_headers["X-Rango-Id"] = str(header_x_rango_id)
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiQuoteResponse.model_validate(response.json())


class AsyncTransactionOperations:
    """Operations with tag ``Transaction``."""

    def __init__(self, root: AsyncClient) -> None:
        self._root = root

    async def is_approved(
        self, request_id: str, tx_id: str
    ) -> Optional[models.CheckApprovalResponse]:
        """
        Check Approval TX Status

        When swap endpoint returns a non-null value for the approval transaction, and
        user signs that tx, you should periodically call this endpoint to see if the
        approval tx is completed. After a successful check, you could proceed with the
        main transaction.

        Args:
            request_id (str): unique ID generated by quote endpoint Wire name
                              ``requestId`` (query).
            tx_id (str): Approve transaction tx id Wire name ``txId`` (query).

        Returns:
            ``Optional[models.CheckApprovalResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.transaction.is_approved(request_id="b3a12c6d-86b8-4c21-97e4-809151dd4036", tx_id="0x7f17aaba51d1f24204cd8b02251001d3704add46d84840a5826b95ef49b8b74f")
                    print(result)
        """
        url = f"/basic/is-approved"
        params: Dict[str, Any] = {}
        params["requestId"] = request_id
        params["txId"] = tx_id
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.CheckApprovalResponse.model_validate(response.json())

    async def report_tx(
        self, body: models.BasicApiReportTransactionRequest
    ) -> Optional[models.BasicApiReportTransactionResponse]:
        """
        Report Failed TX

        Use it when the user rejects the transaction in wallet or the wallet fails to
        handle the transaction. Calling this endpoint is not required, but is useful for
        reporting and we recommend you to call it.Consider that transactions include
        Inbound tx, cannot be reported as failed or canceled!!

        Args:
            body (models.BasicApiReportTransactionRequest): JSON request body.

        Returns:
            ``Optional[models.BasicApiReportTransactionResponse]`` — JSON response
            parsed into the declared type when the body is non-empty; ``None`` for HTTP
            204/205 or an empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.transaction.report_tx(body=models.BasicApiReportTransactionRequest(event_type=models.BasicApiReportTransactionRequestEventType.USER_REJECT, request_id="688b308e-a06b-4a4e-a837-220d458b8642"))
                    print(result)
        """
        url = f"/basic/report-tx"
        params: Dict[str, Any] = {}
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        json_body: Any = None
        if body is not None:
            json_body = body.model_dump(
                mode="json",
                by_alias=True,
                exclude_none=True,
            )
        response = await self._root._client.request(
            "POST",
            url,
            params=params or None,
            headers=req_headers or None,
            json=json_body,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiReportTransactionResponse.model_validate(response.json())

    async def status(
        self, request_id: str, tx_id: str
    ) -> Optional[models.BasicApiStatusResponse]:
        """
        Check TX Status

        Check if the user swapp has succeeded or not. When a user signs the swap
        transaction on his/her wallet, you should call this endpoint periodically to see
        the swap status.

        Args:
            request_id (str): unique ID generated by quote endpoint Wire name
                              ``requestId`` (query).
            tx_id (str): Last signed transaction's id Wire name ``txId`` (query).

        Returns:
            ``Optional[models.BasicApiStatusResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.transaction.status(request_id="b3a12c6d-86b8-4c21-97e4-809151dd4036", tx_id="0xfa88b705a5b4049adac7caff50c887d9600ef023ef1a937f8f8b6f44e90042b5")
                    print(result)
        """
        url = f"/basic/status"
        params: Dict[str, Any] = {}
        params["requestId"] = request_id
        params["txId"] = tx_id
        req_headers: Dict[str, str] = {}
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiStatusResponse.model_validate(response.json())

    async def swap(
        self,
        from_: str,
        to: str,
        amount: int,
        slippage: float,
        from_address: str,
        to_address: str,
        disable_estimate: Optional[bool] = None,
        swappers: Optional[List[str]] = None,
        swappers_exclude: Optional[bool] = None,
        swapper_groups: Optional[List[str]] = None,
        swappers_groups_exclude: Optional[bool] = None,
        messaging_protocols: Optional[List[models.ParamMessagingProtocolsItem]] = None,
        im_message: Optional[str] = None,
        source_contract: Optional[str] = None,
        destination_contract: Optional[str] = None,
        infinite_approve: Optional[bool] = None,
        contract_call: Optional[bool] = None,
        referrer_fee: Optional[float] = None,
        referrer_address: Optional[str] = None,
        referrer_code: Optional[str] = None,
        avoid_native_fee: Optional[bool] = None,
        enable_centralized_swappers: Optional[bool] = None,
        use_max_native_token_balance: Optional[bool] = None,
        header_x_rango_id: Optional[str] = None,
    ) -> Optional[models.BasicApiSwapResponse]:
        """
        Create TX (Swap)

        Generating the transaction data for calling dex/bridge contract via Rango
        Exchange.

        Args:
            from_ (str): The asset X that user likes to swap Wire name ``from`` (query).
            to (str): The asset Y that user wants to swap X into that Wire name ``to``
                      (query).
            amount (int): The machine-readable amount of asset X that is going to be
                          swapped Wire name ``amount`` (query).
            slippage (float): Amount of user's preferred slippage in percent Wire name
                              ``slippage`` (query).
            from_address (str): User wallet address Wire name ``fromAddress`` (query).
            to_address (str): Destination wallet address Wire name ``toAddress``
                              (query).
            disable_estimate (Optional[bool]): This field should be false when the
                                               client wants to preview the route to the
                                               user and true when the user accepts the
                                               swap. If it's true, the server will be
                                               much slower to respond but will check
                                               some prerequisites, including the balance
                                               of X and any required fees in the user's
                                               wallets. Wire name ``disableEstimate``
                                               (query).
            swappers (Optional[List[str]]): The list of all accepted swappers. An empty
                                            list means no filter is required. Wire name
                                            ``swappers`` (query).
            swappers_exclude (Optional[bool]): Defines the provided swappers as the
                                               include/exclude list. Default is false
                                               (include) Wire name ``swappersExclude``
                                               (query).
            swapper_groups (Optional[List[str]]): The list of all included/excluded
                                                  swappers based on tag, empty list
                                                  means no filter is required Wire name
                                                  ``swapperGroups`` (query).
            swappers_groups_exclude (Optional[bool]): Defines the provided swappers'
                                                      tags as the include/exclude list.
                                                      Default is false (include) Wire
                                                      name ``swappersGroupsExclude``
                                                      (query).
            messaging_protocols (Optional[List[models.ParamMessagingProtocolsItem]]): Message protocols which
                                                                                      will be used to call
                                                                                      message before or after
                                                                                      swap Wire name
                                                                                      ``messagingProtocols``
                                                                                      (query).
            im_message (Optional[str]): Message to call after or before swap transaction
                                        Wire name ``imMessage`` (query).
            source_contract (Optional[str]): Contract address which should be called
                                             before swap transaction Wire name
                                             ``sourceContract`` (query).
            destination_contract (Optional[str]): Contract address which should be
                                                  called after swap transaction Wire
                                                  name ``destinationContract`` (query).
            infinite_approve (Optional[bool]): Use this parameter if you want infinite
                                               approve from user Wire name
                                               ``infiniteApprove`` (query).
            contract_call (Optional[bool]): set this parameter to `true` if you wants to
                                            send transactions through a contract Wire
                                            name ``contractCall`` (query).
            referrer_fee (Optional[float]): Referrer fee in percent, e.g. 0.3 Wire name
                                            ``referrerFee`` (query).
            referrer_address (Optional[str]): Referrer wallet address on source asset
                                              (from) blockchain Wire name
                                              ``referrerAddress`` (query).
            referrer_code (Optional[str]): Referrer code Wire name ``referrerCode``
                                           (query).
            avoid_native_fee (Optional[bool]): When it is true, Swappers that have
                                               native tokens as fee must be excluded.
                                               example: when you call it from AA
                                               account. Wire name ``avoidNativeFee``
                                               (query).
            enable_centralized_swappers (Optional[bool]): Specify that centralized
                                                          swappers must be included in
                                                          swappers or not. Default is
                                                          false (exclude) Wire name
                                                          ``enableCentralizedSwappers``
                                                          (query).
            use_max_native_token_balance (Optional[bool]): Forces transaction creation
                                                           by subtracting fees from
                                                           input if balance is
                                                           insufficient. Wire name
                                                           ``useMaxNativeTokenBalance``
                                                           (query).
            header_x_rango_id (Optional[str]): A unique client generated Id, better use
                                               UUID Wire name ``X-Rango-Id`` (header).

        Returns:
            ``Optional[models.BasicApiSwapResponse]`` — JSON response parsed into the
            declared type when the body is non-empty; ``None`` for HTTP 204/205 or an
            empty body.

        Examples:
                async with AsyncClient(api_key='c6381a79-2817-4602-83bf-6a641a409e32') as client:
                    result = await client.transaction.swap(from_="BSC.BNB", to="AVAX_CCHAIN.USDT.E--0xc7198437980c041c805a1edcba50c1ce5db95118", amount=10000000000000000, slippage=3.5, from_address="0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88", to_address="0x6f33bb1763eebead07cf8815a62fcd7b30311fa3", disable_estimate=False, infinite_approve=False)
                    print(result)
        """
        url = f"/basic/swap"
        params: Dict[str, Any] = {}
        params["from"] = from_
        params["to"] = to
        params["amount"] = amount
        params["slippage"] = slippage
        params["fromAddress"] = from_address
        params["toAddress"] = to_address
        if disable_estimate is not None:
            params["disableEstimate"] = disable_estimate
        if swappers is not None:
            params["swappers"] = swappers
        if swappers_exclude is not None:
            params["swappersExclude"] = swappers_exclude
        if swapper_groups is not None:
            params["swapperGroups"] = swapper_groups
        if swappers_groups_exclude is not None:
            params["swappersGroupsExclude"] = swappers_groups_exclude
        if messaging_protocols is not None:
            params["messagingProtocols"] = messaging_protocols
        if im_message is not None:
            params["imMessage"] = im_message
        if source_contract is not None:
            params["sourceContract"] = source_contract
        if destination_contract is not None:
            params["destinationContract"] = destination_contract
        if infinite_approve is not None:
            params["infiniteApprove"] = infinite_approve
        if contract_call is not None:
            params["contractCall"] = contract_call
        if referrer_fee is not None:
            params["referrerFee"] = referrer_fee
        if referrer_address is not None:
            params["referrerAddress"] = referrer_address
        if referrer_code is not None:
            params["referrerCode"] = referrer_code
        if avoid_native_fee is not None:
            params["avoidNativeFee"] = avoid_native_fee
        if enable_centralized_swappers is not None:
            params["enableCentralizedSwappers"] = enable_centralized_swappers
        if use_max_native_token_balance is not None:
            params["useMaxNativeTokenBalance"] = use_max_native_token_balance
        req_headers: Dict[str, str] = {}
        if header_x_rango_id is not None:
            req_headers["X-Rango-Id"] = str(header_x_rango_id)
        self._root._apply_security(["apiKey"], params, req_headers, None)

        response = await self._root._client.request(
            "GET",
            url,
            params=params or None,
            headers=req_headers or None,
        )
        response.raise_for_status()
        if response.status_code in (204, 205) or not response.content:
            return None
        return models.BasicApiSwapResponse.model_validate(response.json())


class AsyncClient:
    """
    Simple and Easy to use APIs for Rango Aggregation protocols for dApps and Wallets
    for single step cross-chain and on-chain swaps using the best route and all the
    available on-chain liquidity across all blockchain networks.

    Pass ``log_http_debug=True`` and configure logging for this module (e.g.
    ``logging.getLogger(__name__).setLevel(logging.DEBUG)`` on ``…client``) to emit each
    HTTP request and response at DEBUG, including headers and bodies. This may log
    credentials—use only in trusted environments.

    Optional ``proxy`` is forwarded to the underlying ``httpx`` client (a proxy URL
    string or ``httpx.URL``).

    Security credentials may be passed as constructor keyword arguments or read from
    environment variables (see the README); constructor values take precedence when both
    are set.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        *,
        api_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        proxy: Optional[Union[str, httpx.URL]] = None,
        log_http_debug: bool = False,
    ) -> None:
        _resolved = base_url if base_url is not None else DEFAULT_SERVER_URL
        if not _resolved:
            raise ValueError(
                "No base URL: pass base_url=… or define servers in the OpenAPI document.",
            )
        self._base_url = _resolved.rstrip("/")
        self._headers = dict(headers or {})
        self._proxy = proxy
        self._sec_apiKey = _security_value_from_kw_or_env(
            api_key,
            "RANGO_BASIC_API_KEY",
        )
        if not self._sec_apiKey:
            raise ValueError(
                "OpenAPI security scheme "
                + "apiKey"
                + ": pass keyword argument "
                + "api_key"
                + ", or set environment variable "
                + "RANGO_BASIC_API_KEY"
                + "."
            )

        _ahooks: Optional[Dict[str, List[Any]]] = (
            _async_http_debug_event_hooks() if log_http_debug else None
        )
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=self._headers,
            timeout=timeout,
            proxy=self._proxy,
            event_hooks=_ahooks,
        )
        self.balance = AsyncBalanceOperations(self)
        self.metadata = AsyncMetadataOperations(self)
        self.routing = AsyncRoutingOperations(self)
        self.transaction = AsyncTransactionOperations(self)

    def _apply_security(
        self,
        operation_scheme_keys: List[str],
        params: Dict[str, Any],
        headers: Dict[str, str],
        cookies: Optional[Dict[str, str]],
    ) -> None:
        if "apiKey" in operation_scheme_keys and self._sec_apiKey is not None:
            params["apiKey"] = self._sec_apiKey

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
