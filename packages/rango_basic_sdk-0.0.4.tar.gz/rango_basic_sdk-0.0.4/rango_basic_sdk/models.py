from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field
from decimal import Decimal


class BaseClientModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")


class _WireStrEnum(str, Enum):
    """String enums: ``str(member)``, ``f"{member}"``, and ``"x" + member`` use the wire value (like ``StrEnum``)."""

    __str__ = str.__str__
    __format__ = str.__format__


class BasicApiQuoteResponseRouteRestrictionType(_WireStrEnum):
    INCLUSIVE = "INCLUSIVE"
    EXCLUSIVE = "EXCLUSIVE"


class BasicApiReportTransactionRequestEventType(_WireStrEnum):
    """Type of the event that happened"""

    FETCH_TX_FAILED = "FETCH_TX_FAILED"
    USER_REJECT = "USER_REJECT"
    USER_CANCEL = "USER_CANCEL"
    CALL_WALLET_FAILED = "CALL_WALLET_FAILED"
    SEND_TX_FAILED = "SEND_TX_FAILED"
    CLIENT_UNEXPECTED_BEHAVIOUR = "CLIENT_UNEXPECTED_BEHAVIOUR"
    TX_EXPIRED = "TX_EXPIRED"
    INSUFFICIENT_APPROVE = "INSUFFICIENT_APPROVE"
    USER_CANCELED_TX = "USER_CANCELED_TX"
    CALL_OR_SEND_FAILED = "CALL_OR_SEND_FAILED"
    TX_FAILED_IN_BLOCKCHAIN = "TX_FAILED_IN_BLOCKCHAIN"
    WRONG_TX_HASH = "WRONG_TX_HASH"


class BasicApiStarkNetTransactionFeeDataAvailabilityMode(_WireStrEnum):
    """Fee data availability mode"""

    L1 = "L1"
    L2 = "L2"


class BasicApiSwapFeeExpenseType(_WireStrEnum):
    FROM_SOURCE_WALLET = "FROM_SOURCE_WALLET"
    DECREASE_FROM_OUTPUT = "DECREASE_FROM_OUTPUT"
    FROM_DESTINATION_WALLET = "FROM_DESTINATION_WALLET"


class BasicApiSwapResponseResultType(_WireStrEnum):
    """Route state"""

    OK = "OK"
    HIGH_IMPACT = "HIGH_IMPACT"
    INPUT_LIMIT_ISSUE = "INPUT_LIMIT_ISSUE"
    NO_ROUTE = "NO_ROUTE"


class Blockchain(_WireStrEnum):
    """The blockchain which this token belongs to"""

    BTC = "BTC"
    ETH = "ETH"
    MEGAETH = "MEGAETH"
    BSC = "BSC"
    SONIC = "SONIC"
    SOLANA = "SOLANA"
    BASE = "BASE"
    SUI = "SUI"
    LINEA = "LINEA"
    ARBITRUM = "ARBITRUM"
    OPTIMISM = "OPTIMISM"
    AVAX_CCHAIN = "AVAX_CCHAIN"
    TRON = "TRON"
    TON = "TON"
    POLYGON = "POLYGON"
    ZKSYNC = "ZKSYNC"
    FANTOM = "FANTOM"
    DOGE = "DOGE"
    TAIKO = "TAIKO"
    ZORA = "ZORA"
    MODE = "MODE"
    BERACHAIN = "BERACHAIN"
    STARKNET = "STARKNET"
    POLYGONZK = "POLYGONZK"
    SCROLL = "SCROLL"
    BLAST = "BLAST"
    COSMOS = "COSMOS"
    OSMOSIS = "OSMOSIS"
    NEUTRON = "NEUTRON"
    NOBLE = "NOBLE"
    DYDX = "DYDX"
    CRONOS = "CRONOS"
    BNB = "BNB"
    AURORA = "AURORA"
    MAYA = "MAYA"
    THOR = "THOR"
    BOBA = "BOBA"
    MOONBEAM = "MOONBEAM"
    MOONRIVER = "MOONRIVER"
    OKC = "OKC"
    BOBA_BNB = "BOBA_BNB"
    BOBA_AVALANCHE = "BOBA_AVALANCHE"
    LTC = "LTC"
    BCH = "BCH"
    HARMONY = "HARMONY"
    EVMOS = "EVMOS"
    HECO = "HECO"
    METIS = "METIS"
    SIF = "SIF"
    BRISE = "BRISE"
    STARGAZE = "STARGAZE"
    FUSE = "FUSE"
    CRYPTO_ORG = "CRYPTO_ORG"
    CHIHUAHUA = "CHIHUAHUA"
    BANDCHAIN = "BANDCHAIN"
    COMDEX = "COMDEX"
    REGEN = "REGEN"
    IRIS = "IRIS"
    EMONEY = "EMONEY"
    GNOSIS = "GNOSIS"
    JUNO = "JUNO"
    AXELAR = "AXELAR"
    STRIDE = "STRIDE"
    KCC = "KCC"
    MARS = "MARS"
    TERRA = "TERRA"
    TELOS = "TELOS"
    BITSONG = "BITSONG"
    AKASH = "AKASH"
    KI = "KI"
    PERSISTENCE = "PERSISTENCE"
    MEDIBLOC = "MEDIBLOC"
    KUJIRA = "KUJIRA"
    SENTINEL = "SENTINEL"
    INJECTIVE = "INJECTIVE"
    SECRET = "SECRET"
    KONSTELLATION = "KONSTELLATION"
    STARNAME = "STARNAME"
    BITCANNA = "BITCANNA"
    UMEE = "UMEE"
    DESMOS = "DESMOS"
    LUMNETWORK = "LUMNETWORK"
    TERRA_CLASSIC = "TERRA_CLASSIC"
    CELO = "CELO"
    DASH = "DASH"
    SHIMMER = "SHIMMER"
    XLAYER = "XLAYER"
    IOTA = "IOTA"
    UNICHAIN = "UNICHAIN"
    SONEIUM = "SONEIUM"
    KATANA = "KATANA"
    MONAD = "MONAD"
    PLASMA = "PLASMA"
    HYPEREVM = "HYPEREVM"
    NEAR = "NEAR"
    CITREA = "CITREA"
    STABLE = "STABLE"
    POLKADOT = "POLKADOT"
    ZETA_CHAIN = "ZETA_CHAIN"
    XRPL = "XRPL"
    STELLAR = "STELLAR"
    ZCASH = "ZCASH"
    GOERLI = "GOERLI"
    GOERLI_ARBITRUM = "GOERLI_ARBITRUM"
    GOERLI_OPTIMISM = "GOERLI_OPTIMISM"
    SEPOLIA = "SEPOLIA"
    SEPOLIA_ARBITRUM = "SEPOLIA_ARBITRUM"
    SEPOLIA_OPTIMISM = "SEPOLIA_OPTIMISM"
    HYPERLIQUID = "HYPERLIQUID"


class CheckApprovalResponseTxStatus(_WireStrEnum):
    """status of given txId"""

    RUNNING = "running"
    FAILED = "failed"
    SUCCESS = "success"


class CosmosMessageSignType(_WireStrEnum):
    """
    Sign type is important field to consider, you should use AMINO or DIRECT mode of
    wallet depending on value of this field
    """

    AMINO = "AMINO"
    DIRECT = "DIRECT"


class GenericTransactionPrerequisiteType(_WireStrEnum):
    """Transaction Prerequisite type. e.g. StellarTrustLine"""

    EVM_APPROVE = "EVM_APPROVE"
    STELLAR_CHANGE_TRUSTLINE = "STELLAR_CHANGE_TRUSTLINE"
    XRPL_CHANGE_TRUSTLINE = "XRPL_CHANGE_TRUSTLINE"


class GenericTransactionType(_WireStrEnum):
    """Blockchain transaction type. e.g. EVM"""

    EVM = "EVM"
    TRANSFER = "TRANSFER"
    COSMOS = "COSMOS"
    SOLANA = "SOLANA"
    ZK_ROLLUP = "ZK_ROLLUP"
    TRON = "TRON"
    TON = "TON"
    STARKNET = "STARKNET"
    SUI = "SUI"
    NEAR = "NEAR"
    STELLAR = "STELLAR"
    XRPL = "XRPL"
    HYPERLIQUID = "HYPERLIQUID"


class ParamMessagingProtocolsItem(_WireStrEnum):
    CBRIDGE = "CBRIDGE"
    ANYCALL = "ANYCALL"
    SATELLITE = "SATELLITE"
    LAYER_ZERO = "LAYER_ZERO"
    WORMHOLE = "WORMHOLE"


class SolanaTransactionTxType(_WireStrEnum):
    """type of Solana transaction. available values are {LEGACY, VERSIONED}"""

    LEGACY = "LEGACY"
    VERSIONED = "VERSIONED"


class StatusOutputType(_WireStrEnum):
    REVERTED_TO_INPUT = "REVERTED_TO_INPUT"
    MIDDLE_ASSET_IN_SRC = "MIDDLE_ASSET_IN_SRC"
    MIDDLE_ASSET_IN_DEST = "MIDDLE_ASSET_IN_DEST"
    DESIRED_OUTPUT = "DESIRED_OUTPUT"


class SwapperMetaDtoTypesItem(_WireStrEnum):
    """Swapper type"""

    BRIDGE = "BRIDGE"
    DEX = "DEX"
    AGGREGATOR = "AGGREGATOR"
    OFF_CHAIN = "OFF_CHAIN"


class TransferTransactionMemoType(_WireStrEnum):
    """Specifies the type of memo that dApps should use for decoding."""

    UTF8 = "UTF8"
    HEX = "HEX"
    SCRIPT = "SCRIPT"


class AbstractBlockchainMetaInfo(BaseClientModel):
    address_url: str = Field(alias="addressUrl")
    block_explorer_urls: List[str] = Field(alias="blockExplorerUrls")
    info_type: str = Field(alias="infoType")
    transaction_url: str = Field(alias="transactionUrl")


class Amount(BaseClientModel):
    """
    The amount of an asset, including value & decimals. The amount is machine-readable,
    to make it human-readable it should be shifted by decimals.
    """

    amount: int = Field(
        alias="amount",
        description="The machine-readable amount shifted by decimals",
        examples=[1000000000000000000],
    )
    decimals: int = Field(
        alias="decimals",
        description="The decimals of the token in blockchain",
        examples=[18],
    )


class Asset(BaseClientModel):
    """An asset unique by triple of (blockchain, symbol, address)"""

    address: Optional[str] = Field(
        default=None,
        alias="address",
        description="Smart contract address of token, null for native tokens",
        examples=["0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d"],
    )
    blockchain: Blockchain = Field(
        alias="blockchain",
        description="The blockchain which this token belongs to",
        examples=[Blockchain.BSC],
    )
    symbol: str = Field(
        alias="symbol",
        description="The display symbol, e.g. USDT, BTC, etc.",
        examples=["USDC"],
    )


class AssetWithTicker(BaseClientModel):
    """An asset with its ticker"""

    address: Optional[str] = Field(
        default=None,
        alias="address",
        description="Contract address of the asset, null for native tokens",
        examples=["0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d"],
    )
    blockchain: Blockchain = Field(
        alias="blockchain", description="Blockchain of asset", examples=[Blockchain.BSC]
    )
    symbol: str = Field(
        alias="symbol", description="Symbol of an asset", examples=["USDC"]
    )
    ticker: str = Field(
        alias="ticker",
        description=("""
                    Deprecated. The ticker of the asset which normally is a combination of
                    symbol and address, required by some javascript wallets
                    """),
        deprecated=True,
    )


class BaseResponse(BaseClientModel):
    error: Optional[str] = Field(default=None, alias="error")
    error_code: Optional[int] = Field(default=None, alias="errorCode")
    trace_id: Optional[int] = Field(default=None, alias="traceId")


class BasicApiEvmBridgeData(BaseClientModel):
    """EVM bridging data"""

    dest_chain_id: int = Field(alias="destChainId")
    dest_token: Optional[str] = Field(default=None, alias="destToken")
    dest_token_amt: Optional[int] = Field(default=None, alias="destTokenAmt")
    dest_token_decimals: int = Field(alias="destTokenDecimals")
    dest_token_price: Optional[Decimal] = Field(default=None, alias="destTokenPrice")
    dest_tx_hash: Optional[str] = Field(default=None, alias="destTxHash")
    src_chain_id: int = Field(alias="srcChainId")
    src_token: Optional[str] = Field(default=None, alias="srcToken")
    src_token_amt: int = Field(alias="srcTokenAmt")
    src_token_decimals: int = Field(alias="srcTokenDecimals")
    src_token_price: Optional[Decimal] = Field(default=None, alias="srcTokenPrice")
    src_tx_hash: Optional[str] = Field(default=None, alias="srcTxHash")


class BasicApiQuoteResponseRouteRestriction(BaseClientModel):
    """Amount restriction for a swapper"""

    max: Optional[int] = Field(default=None, alias="max")
    min: Optional[int] = Field(default=None, alias="min")
    type_: BasicApiQuoteResponseRouteRestrictionType = Field(alias="type")


class BasicApiReportTransactionRequest(BaseClientModel):
    """Data of the event including its type and an extra metadata"""

    data: Optional[Dict[str, str]] = Field(
        default=None,
        alias="data",
        description=("""
                    A list of key-value for extra details. (String to String map). it is
                    deprecated
                    """),
        deprecated=True,
        examples=[{"message": "user rejected the transaction"}],
    )
    event_type: BasicApiReportTransactionRequestEventType = Field(
        alias="eventType",
        description="Type of the event that happened",
        examples=[BasicApiReportTransactionRequestEventType.USER_REJECT],
    )
    reason: Optional[str] = Field(
        default=None, alias="reason", description="Reason of problem in transaction"
    )
    request_id: str = Field(
        alias="requestId",
        description="RequestId from best route endpoint",
        examples=["688b308e-a06b-4a4e-a837-220d458b8642"],
    )
    tags: Optional[Dict[str, str]] = Field(
        default=None, alias="tags", description="List of tags"
    )


class BasicApiReportTransactionResponse(BaseClientModel):
    """Response of report-tx endpoint"""

    error: Optional[str] = Field(
        default=None, alias="error", description="Error occurred during operation"
    )
    error_code: Optional[int] = Field(
        default=None,
        alias="errorCode",
        description="Error code show error type in rango",
    )
    trace_id: Optional[int] = Field(
        default=None,
        alias="traceId",
        description="Trace id help Rango support to resolve the issue",
    )


class BasicApiToken(BaseClientModel):
    """A token's metadata, which is unique by (blockchain, symbol, and address)"""

    address: Optional[str] = Field(default=None, alias="address")
    blockchain: Blockchain = Field(alias="blockchain")
    blockchain_image: Optional[str] = Field(default=None, alias="blockchainImage")
    chain_id: Optional[str] = Field(default=None, alias="chainId")
    decimals: int = Field(alias="decimals")
    image: str = Field(alias="image")
    is_popular: bool = Field(alias="isPopular")
    name: Optional[str] = Field(default=None, alias="name")
    supported_swappers: List[str] = Field(
        alias="supportedSwappers",
        description="Supported swappers for this token",
        examples=[["oneInch"]],
    )
    symbol: str = Field(alias="symbol")
    usd_price: Optional[float] = Field(default=None, alias="usdPrice")


class BlockchainNativeCurrency(BaseClientModel):
    decimals: int = Field(alias="decimals")
    name: str = Field(alias="name")
    symbol: str = Field(alias="symbol")


class CheckApprovalResponse(BaseClientModel):
    """Check approve response body"""

    current_approved_amount: Optional[Decimal] = Field(
        default=None,
        alias="currentApprovedAmount",
        description="current approved amount",
        examples=[Decimal("8.0")],
    )
    is_approved: bool = Field(
        alias="isApproved",
        description="A flag indicating whether the approve tx was successful or not",
        examples=[True],
    )
    required_approved_amount: Optional[Decimal] = Field(
        default=None,
        alias="requiredApprovedAmount",
        description="required approve amount",
        examples=[Decimal("10.0")],
    )
    tx_status: Optional[CheckApprovalResponseTxStatus] = Field(
        default=None,
        alias="txStatus",
        description="status of given txId",
        examples=["running, failed, success, null"],
    )


class Coin(BaseClientModel):
    amount: str = Field(alias="amount")
    denom: str = Field(alias="denom")


class CosmosChainBech32Config(BaseClientModel):
    bech32_prefix_acc_addr: str = Field(alias="bech32PrefixAccAddr")
    bech32_prefix_acc_pub: str = Field(alias="bech32PrefixAccPub")
    bech32_prefix_cons_addr: str = Field(alias="bech32PrefixConsAddr")
    bech32_prefix_cons_pub: str = Field(alias="bech32PrefixConsPub")
    bech32_prefix_val_addr: str = Field(alias="bech32PrefixValAddr")
    bech32_prefix_val_pub: str = Field(alias="bech32PrefixValPub")


class CosmosChainBip44(BaseClientModel):
    coin_type: int = Field(alias="coinType")


class CosmosChainCurrency(BaseClientModel):
    coin_decimals: int = Field(alias="coinDecimals")
    coin_denom: str = Field(alias="coinDenom")
    coin_gecko_id: str = Field(alias="coinGeckoId")
    coin_image_url: str = Field(alias="coinImageUrl")
    coin_minimal_denom: str = Field(alias="coinMinimalDenom")


class CosmosChainStakeCurrency(BaseClientModel):
    coin_decimals: int = Field(alias="coinDecimals")
    coin_denom: str = Field(alias="coinDenom")
    coin_gecko_id: str = Field(alias="coinGeckoId")
    coin_image_url: str = Field(alias="coinImageUrl")
    coin_minimal_denom: str = Field(alias="coinMinimalDenom")


class CosmosGasPriceStep(BaseClientModel):
    average: float = Field(alias="average")
    high: float = Field(alias="high")
    low: float = Field(alias="low")


class ExplorerUrl(BaseClientModel):
    """
    A transaction's url that can be displayed to advanced user to track the progress
    """

    description: Optional[str] = Field(
        default=None,
        alias="description",
        description=("""
                    A custom display name to help user distinguish the transactions from
                    eachother. Ex: `Inbound`, `Outbound`, `Bridge`, or null
                    """),
        examples=["Inbound"],
    )
    url: str = Field(
        alias="url",
        description="Url of the transaction in bscscan/harmony explorer/plygonscan/etc.",
        examples=[
            "https://etherscan.io/tx/0xa1a37ce2063c4764da27d990a22a0c89ed8ac585286a77aa02e1c1998203de19",
        ],
    )


class GenericTransactionPrerequisite(BaseClientModel):
    """Prerequisite of a transaction"""

    block_chain: Blockchain = Field(
        alias="blockChain",
        description="The blockchain that this transaction prerequisite must be executed on",
    )
    type_: GenericTransactionPrerequisiteType = Field(
        alias="type", description="Transaction Prerequisite type. e.g. StellarTrustLine"
    )


class HyperliquidTransactionActionMessage(BaseClientModel):
    """hyperliquid action to send"""

    amount: str = Field(
        alias="amount", description="amount to transfer in human readable format"
    )
    destination: str = Field(
        alias="destination", description="destination address on hyperliquid"
    )
    hyperliquid_chain: str = Field(
        alias="hyperliquidChain", description="mainnet/testnet indicator"
    )
    signature_chain_id: str = Field(
        alias="signatureChainId", description="signature chain ID in hex"
    )
    time: int = Field(
        alias="time", description="message generation time in long format"
    )
    type_: str = Field(alias="type", description="hyperliquid action type")


class MessagingProtocolModel(BaseClientModel):
    id: str = Field(alias="id")


class Msg(BaseClientModel):
    type_: str = Field(alias="type")


class PSBTInputToSign(BaseClientModel):
    address: str = Field(alias="address")
    signing_indexes: List[int] = Field(alias="signingIndexes")


class ProtoMsg(BaseClientModel):
    type_url: str = Field(alias="type_url")
    value: List[int] = Field(alias="value")


class SolanaInstructionKey(BaseClientModel):
    is_signer: bool = Field(alias="isSigner")
    is_writable: bool = Field(alias="isWritable")
    pubkey: str = Field(alias="pubkey")


class SolanaSignature(BaseClientModel):
    """List of signatures. fills only if message is already partially signed"""

    public_key: str = Field(alias="publicKey")
    signature: str = Field(alias="signature")


class StarkNetResourceBound(BaseClientModel):
    """Resource bound for a specific gas type"""

    max_amount: str = Field(
        alias="maxAmount", description="Maximum amount of the resource"
    )
    max_price_per_unit: str = Field(
        alias="maxPricePerUnit", description="Maximum price per unit of the resource"
    )


class StarknetCallData(BaseClientModel):
    """Single calldata to call a contract"""

    calldata: Optional[List[str]] = Field(
        default=None, alias="calldata", description="Function inputs"
    )
    contract_address: str = Field(
        alias="contractAddress", description="Contract address to call"
    )
    entrypoint: str = Field(alias="entrypoint", description="Function name to call")


class StellarTransactionPreconditionsLedgerBounds(BaseClientModel):
    """
    ledger bounds of stellar transaction data, Transaction only valid for ledger numbers
    n such that minLedger <= n < maxLedger (if maxLedger == 0, then only minLedger is
    checked)
    """

    max_ledger: int = Field(
        alias="maxLedger",
        description="Maximum ledger for transaction validity, 0 here means no maxLedger",
    )
    min_ledger: int = Field(
        alias="minLedger", description="Minimum ledger for transaction validity"
    )


class StellarTransactionPreconditionsTimeBounds(BaseClientModel):
    """time bounds of stellar transaction data"""

    max_time: int = Field(
        alias="maxTime",
        description="Unix timestamped constraint for minimum time of transaction validity",
    )
    min_time: int = Field(
        alias="minTime",
        description="Unix timestamped constraint for minimum time of transaction validity",
    )


class SwapFeeMeta(BaseClientModel):
    """Meta data of swap fee"""

    type_: str = Field(alias="type")


class SwapperMetaDto(BaseClientModel):
    """Metadata of Swapper"""

    enabled: bool = Field(alias="enabled")
    id: str = Field(alias="id")
    logo: str = Field(alias="logo")
    swapper_group: str = Field(alias="swapperGroup")
    title: str = Field(alias="title")
    types: Optional[List[SwapperMetaDtoTypesItem]] = Field(default=None, alias="types")


class SwapperSupportedBlockchain(BaseClientModel):
    """Supported blockchains of Swapper"""

    destinations: List[Blockchain] = Field(alias="destinations")
    source: Blockchain = Field(alias="source")


class TokenBalanceResponse(BaseClientModel):
    balance: Optional[int] = Field(
        default=None, alias="balance", description="The balance of the asset"
    )
    error: Optional[str] = Field(
        default=None, alias="error", description="Error occurred during operation"
    )
    error_code: Optional[int] = Field(
        default=None,
        alias="errorCode",
        description="Error code show error type in rango",
    )
    price: Optional[float] = Field(
        default=None, alias="price", description="The price unit of the asset"
    )
    trace_id: Optional[int] = Field(
        default=None,
        alias="traceId",
        description="Trace id help Rango support to resolve the issue",
    )


class TonTransactionMessage(BaseClientModel):
    """TON message model"""

    address: str = Field(alias="address", description="Receiver's address.")
    amount: str = Field(alias="amount", description="Amount to send in nanoTon")
    payload: Optional[str] = Field(
        default=None,
        alias="payload",
        description="Base64 encoded contract specific payload to add to the transaction.",
    )
    state_init: Optional[str] = Field(
        default=None,
        alias="stateInit",
        description="Base64 encoded contract specific stateInit to add to the transaction.",
    )


class TronTransaction(BaseClientModel):
    """Payload of Trx Transaction"""

    owner_address: str = Field(alias="owner_address")
    type_: str = Field(alias="type")


class TrxContractWrapperParameterValue(BaseClientModel):
    type_: str = Field(alias="type")


class AssetBalance(BaseClientModel):
    """Balance of Asset in specified wallet"""

    amount: Amount = Field(
        alias="amount",
        description=("""
                    The amount of an asset, including value & decimals. The amount is
                    machine-readable, to make it human-readable it should be shifted by
                    decimals.
                    """),
    )
    asset: Asset = Field(
        alias="asset",
        description="An asset unique by triple of (blockchain, symbol, address)",
    )
    price: Optional[float] = Field(
        default=None, alias="price", description="The price unit of the asset"
    )


class BasicApiBlockchainMetaSummary(BaseClientModel):
    """Blockchain metadata"""

    address_patterns: List[str] = Field(
        alias="addressPatterns", description="Wallet address patterns"
    )
    chain_id: Optional[str] = Field(default=None, alias="chainId")
    default_decimals: int = Field(
        alias="defaultDecimals", description="Native token decimals"
    )
    fee_assets: List[Asset] = Field(alias="feeAssets")
    name: str = Field(alias="name")
    type_: Optional[GenericTransactionType] = Field(
        default=None, alias="type", description="Blockchain transaction type. e.g. EVM"
    )


class BasicApiQuotePath(BaseClientModel):
    """A single step form a multi step route"""

    estimated_time_in_seconds: int = Field(
        alias="estimatedTimeInSeconds", description="Swap estimated time"
    )
    expected_output: int = Field(alias="expectedOutput", description="Swap output")
    from_: BasicApiToken = Field(
        alias="from",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )
    input_amount: int = Field(alias="inputAmount", description="Swap inputAmount")
    swapper: SwapperMetaDto = Field(alias="swapper", description="Metadata of Swapper")
    swapper_type: SwapperMetaDtoTypesItem = Field(
        alias="swapperType", description="Swapper type"
    )
    to: BasicApiToken = Field(
        alias="to",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )


class BasicCustomTokenResponse(BaseClientModel):
    error: Optional[str] = Field(
        default=None, alias="error", description="Error occurred during operation"
    )
    error_code: Optional[int] = Field(
        default=None,
        alias="errorCode",
        description="Error code show error type in rango",
    )
    token: Optional[BasicApiToken] = Field(
        default=None,
        alias="token",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )
    trace_id: Optional[int] = Field(
        default=None,
        alias="traceId",
        description="Trace id help Rango support to resolve the issue",
    )


class CosmosMetaInfo(AbstractBlockchainMetaInfo):
    bech32_config: CosmosChainBech32Config = Field(alias="bech32Config")
    bip44: CosmosChainBip44 = Field(alias="bip44")
    chain_name: str = Field(alias="chainName")
    cosmostation_api_url: Optional[str] = Field(
        default=None, alias="cosmostationApiUrl"
    )
    cosmostation_denom_trace_path: str = Field(alias="cosmostationDenomTracePath")
    cosmostation_lcd_url: Optional[str] = Field(
        default=None, alias="cosmostationLcdUrl"
    )
    currencies: List[CosmosChainCurrency] = Field(alias="currencies")
    experimental: bool = Field(alias="experimental")
    explorer_url_to_tx: str = Field(alias="explorerUrlToTx")
    features: List[str] = Field(alias="features")
    fee_currencies: List[CosmosChainCurrency] = Field(alias="feeCurrencies")
    gas_price_step: Optional[CosmosGasPriceStep] = Field(
        default=None, alias="gasPriceStep"
    )
    mint_scan_name: Optional[str] = Field(default=None, alias="mintScanName")
    rest: str = Field(alias="rest")
    rpc: str = Field(alias="rpc")
    stake_currency: CosmosChainStakeCurrency = Field(alias="stakeCurrency")


class CosmosRawTransferData(BaseClientModel):
    """
    An alternative to CosmosMessage object for the cosmos wallets that do not support
    generic Cosmos messages
    """

    amount: int = Field(
        alias="amount",
        description="The machine-readable amount to transfer",
        examples=[1000000000000000000],
    )
    asset: AssetWithTicker = Field(
        alias="asset", description="An asset with its ticker"
    )
    decimals: int = Field(
        alias="decimals", description="The decimals for this asset", examples=[18]
    )
    memo: Optional[str] = Field(
        default=None, alias="memo", description="Memo of transaction, can be null"
    )
    method: str = Field(
        alias="method", description="The method value", examples=["transfer"]
    )
    recipient: str = Field(
        alias="recipient", description="The recipient address of transaction"
    )


class CosmosStdFee(BaseClientModel):
    amount: List[Coin] = Field(alias="amount")
    gas: str = Field(alias="gas")


class EvmApprovePrerequisite(GenericTransactionPrerequisite):
    amount: int = Field(
        alias="amount",
        description="Minimum expected allowance in machine-readable units",
        examples=[1000000000000000000],
    )
    spender: str = Field(
        alias="spender",
        description="Spender contract address that will use the allowance",
    )
    token: str = Field(
        alias="token", description="Token contract address that should be approved"
    )
    wallet: str = Field(
        alias="wallet",
        description="User's wallet address that should approve allowance",
    )


class EvmMetaInfo(AbstractBlockchainMetaInfo):
    chain_name: str = Field(alias="chainName")
    enable_gas_v2: bool = Field(alias="enableGasV2")
    native_currency: BlockchainNativeCurrency = Field(alias="nativeCurrency")
    rpc_urls: List[str] = Field(alias="rpcUrls")


class EvmNetworkFeeMeta(SwapFeeMeta):
    gas_limit: int = Field(alias="gasLimit")
    gas_price: int = Field(alias="gasPrice")


class HyperliquidMetaInfo(AbstractBlockchainMetaInfo):
    pass


class MessagingProtocolsResponse(BaseClientModel):
    protocols: List[MessagingProtocolModel] = Field(alias="protocols")


class PSBT(BaseClientModel):
    """Partially signed bitcoin transaction"""

    inputs_to_sign: Optional[List[PSBTInputToSign]] = Field(
        default=None, alias="inputsToSign"
    )
    unsigned_psbt_base64: str = Field(alias="unsignedPsbtBase64")


class RoutingAccessItem(BaseClientModel):
    assets: List[Asset] = Field(alias="assets")
    blockchain: Blockchain = Field(alias="blockchain")


class SolanaInstruction(BaseClientModel):
    """List of instructions"""

    data: str = Field(alias="data")
    keys: List[SolanaInstructionKey] = Field(alias="keys")
    program_id: str = Field(alias="programId")


class SolanaMetaInfo(AbstractBlockchainMetaInfo):
    pass


class StarkNetMetaInfo(AbstractBlockchainMetaInfo):
    chain_name: str = Field(alias="chainName")
    native_currency: BlockchainNativeCurrency = Field(alias="nativeCurrency")


class StarkNetResourceBounds(BaseClientModel):
    """Resource bounds for different gas types"""

    l1_data_gas: StarkNetResourceBound = Field(
        alias="l1DataGas", description="Resource bound for a specific gas type"
    )
    l1_gas: StarkNetResourceBound = Field(
        alias="l1Gas", description="Resource bound for a specific gas type"
    )
    l2_gas: StarkNetResourceBound = Field(
        alias="l2Gas", description="Resource bound for a specific gas type"
    )


class StatusOutput(BaseClientModel):
    """Transactions output"""

    amount: int = Field(alias="amount")
    received_token: BasicApiToken = Field(
        alias="receivedToken",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )
    type_: StatusOutputType = Field(alias="type")


class StellarChangeTrustLinePrerequisite(GenericTransactionPrerequisite):
    code: str = Field(alias="code", description="Stellar Asset Code", examples=["USDC"])
    issuer: str = Field(
        alias="issuer",
        description="Stellar Asset Issuer",
        examples=["GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN"],
    )
    value: Decimal = Field(
        alias="value",
        description="Minimum expected limit value of trustline",
        examples=[Decimal("922337203685.4775")],
    )
    wallet: str = Field(
        alias="wallet", description="User's wallet address", examples=["G....."]
    )


class StellarMetaInfo(AbstractBlockchainMetaInfo):
    pass


class StellarTransactionPreconditions(BaseClientModel):
    """
    CAP-21 PreconditionsV2 of transaction transaction
    (https://github.com/stellar/stellar-protocol/blob/master/core/cap-0021.md)
    """

    extra_signers: Optional[List[str]] = Field(
        default=None,
        alias="extraSigners",
        description=("""
                    For the transaction to be valid, there must be a signature corresponding
                    to every Signer in this array, even if the signature is not otherwise
                    required by the sourceAccount or operations.
                    """),
    )
    ledger_bounds: Optional[StellarTransactionPreconditionsLedgerBounds] = Field(
        default=None,
        alias="ledgerBounds",
        description=("""
                    ledger bounds of stellar transaction data, Transaction only valid for
                    ledger numbers n such that minLedger <= n < maxLedger (if maxLedger ==
                    0, then only minLedger is checked)
                    """),
    )
    min_seq_age: Optional[int] = Field(
        default=None,
        alias="minSeqAge",
        description=("""
                    For the transaction to be valid, the current ledger time must be at
                    least minSeqAge greater than sourceAccount's seqTime.
                    """),
    )
    min_seq_ledger_gap: Optional[int] = Field(
        default=None,
        alias="minSeqLedgerGap",
        description=("""
                    For the transaction to be valid, the current ledger number must be at
                    least minSeqLedgerGap greater than sourceAccount's seqLedger.
                    """),
    )
    min_seq_number: Optional[int] = Field(
        default=None,
        alias="minSeqNumber",
        description=("""
                    If NULL, only valid when sourceAccount's sequence number is seqNum - 1.
                    Otherwise, valid when sourceAccount's sequence number n satisfies
                    minSeqNum <= n < tx.seqNum. Note that after execution the account's
                    sequence number is always raised to tx.seqNum
                    """),
    )
    time_bounds: Optional[StellarTransactionPreconditionsTimeBounds] = Field(
        default=None,
        alias="timeBounds",
        description="time bounds of stellar transaction data",
    )


class SuiMetaInfo(AbstractBlockchainMetaInfo):
    pass


class SwapperMetaFullDto(BaseClientModel):
    """Metadata of Swapper"""

    enabled: bool = Field(alias="enabled")
    id: str = Field(alias="id")
    logo: str = Field(alias="logo")
    supported_blockchains: List[SwapperSupportedBlockchain] = Field(
        alias="supportedBlockchains"
    )
    swapper_group: str = Field(alias="swapperGroup")
    title: str = Field(alias="title")
    types: Optional[List[SwapperMetaDtoTypesItem]] = Field(default=None, alias="types")


class TonMetaInfo(AbstractBlockchainMetaInfo):
    pass


class TransferMetaInfo(AbstractBlockchainMetaInfo):
    pass


class TrxContractWrapperParameter(BaseClientModel):
    type_url: Optional[str] = Field(default=None, alias="type_url")
    value: Optional[TrxContractWrapperParameterValue] = Field(
        default=None, alias="value"
    )


class XRPLMetaInfo(AbstractBlockchainMetaInfo):
    pass


class XrplChangeTrustLinePrerequisite(GenericTransactionPrerequisite):
    currency: str = Field(
        alias="currency", description="Xrpl Currency", examples=["RLUSD"]
    )
    issuer: str = Field(
        alias="issuer",
        description="Xrpl Asset Issuer",
        examples=["rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De"],
    )
    value: str = Field(
        alias="value",
        description="Minimum expected limit value of trust",
        examples=["1000000000"],
    )
    wallet: str = Field(
        alias="wallet", description="User's wallet address", examples=["r....."]
    )


class BasicApiBlockchainMeta(BaseClientModel):
    """List of all supported blockchains"""

    address_patterns: List[str] = Field(
        alias="addressPatterns", description="Wallet address patterns"
    )
    chain_id: Optional[str] = Field(default=None, alias="chainId")
    color: str = Field(alias="color")
    default_decimals: int = Field(
        alias="defaultDecimals", description="Native token decimals"
    )
    display_name: str = Field(alias="displayName")
    enabled: bool = Field(alias="enabled")
    fee_assets: List[Asset] = Field(alias="feeAssets")
    info: Optional[
        Union[
            CosmosMetaInfo,
            EvmMetaInfo,
            HyperliquidMetaInfo,
            SolanaMetaInfo,
            StarkNetMetaInfo,
            StellarMetaInfo,
            SuiMetaInfo,
            TonMetaInfo,
            TransferMetaInfo,
            XRPLMetaInfo,
        ]
    ] = Field(default=None, alias="info")
    logo: str = Field(alias="logo")
    name: str = Field(alias="name")
    short_name: str = Field(alias="shortName")
    sort: int = Field(alias="sort")
    type_: Optional[GenericTransactionType] = Field(
        default=None, alias="type", description="Blockchain transaction type. e.g. EVM"
    )


class BasicApiStatusResponse(BaseClientModel):
    """Transaction status response"""

    bridge_data: Optional[BasicApiEvmBridgeData] = Field(
        default=None, alias="bridgeData", description="EVM bridging data"
    )
    diagnosis_url: Optional[str] = Field(
        default=None,
        alias="diagnosisUrl",
        description=("""
                    Some times transaction will fail and user need follow this diagnosis to
                    redeem the assets
                    """),
    )
    error: Optional[str] = Field(default=None, alias="error")
    explorer_url: Optional[List[ExplorerUrl]] = Field(
        default=None, alias="explorerUrl", description="Transactions explorer urls"
    )
    output: Optional[StatusOutput] = Field(
        default=None, alias="output", description="Transactions output"
    )
    status: Optional[CheckApprovalResponseTxStatus] = Field(
        default=None, alias="status"
    )


class BasicApiSwapFee(BaseClientModel):
    amount: int = Field(alias="amount")
    expense_type: BasicApiSwapFeeExpenseType = Field(alias="expenseType")
    meta: Optional[EvmNetworkFeeMeta] = Field(default=None, alias="meta")
    name: str = Field(alias="name")
    token: BasicApiToken = Field(
        alias="token",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )


class ConnectedAssetsResponse(BaseClientModel):
    data: List[RoutingAccessItem] = Field(alias="data")


class CosmosMessage(BaseClientModel):
    """
    A real cosmos message, most fields of this object should be directly passed to
    wallet for signing by user, the important part is `msgs` field that contains all the
    cosmos actions that should be performed.
    """

    account_number: Optional[int] = Field(default=None, alias="account_number")
    chain_id: Optional[str] = Field(default=None, alias="chainId")
    fee: Optional[CosmosStdFee] = Field(default=None, alias="fee")
    memo: Optional[str] = Field(default=None, alias="memo")
    msgs: List[Msg] = Field(alias="msgs")
    proto_msgs: List[ProtoMsg] = Field(alias="protoMsgs")
    rpc_url: Optional[str] = Field(default=None, alias="rpcUrl")
    sequence: Optional[int] = Field(default=None, alias="sequence")
    sign_type: CosmosMessageSignType = Field(
        alias="signType",
        description=("""
                    Sign type is important field to consider, you should use AMINO or DIRECT
                    mode of wallet depending on value of this field
                    """),
    )
    source: Optional[int] = Field(default=None, alias="source")


class GenericTransaction(BaseClientModel):
    """Transaction's raw data"""

    expected_output: Decimal = Field(alias="expectedOutput")
    prerequisites: List[
        Union[
            EvmApprovePrerequisite,
            StellarChangeTrustLinePrerequisite,
            XrplChangeTrustLinePrerequisite,
        ]
    ] = Field(alias="prerequisites")
    type_: GenericTransactionType = Field(
        alias="type", description="Blockchain transaction type. e.g. EVM"
    )


class StellarTransactionData(BaseClientModel):
    """The data and parameters for building the stellar transaction"""

    base_fee: Optional[int] = Field(
        default=None,
        alias="baseFee",
        description=("""
                    Recommended base fee (in stroops) for building the stellar transaction,
                    can be null or overridden on client side based on user's demand
                    """),
    )
    memo_xdr_base64: Optional[str] = Field(
        default=None,
        alias="memoXdrBase64",
        description="Base64-encoded Memo XDR of stellar transaction",
    )
    operations_xdr_base64: List[str] = Field(
        alias="operationsXdrBase64",
        description="List of Base64-encoded XDR for each operation in the transaction",
    )
    preconditions: Optional[StellarTransactionPreconditions] = Field(
        default=None,
        alias="preconditions",
        description=("""
                    CAP-21 PreconditionsV2 of transaction transaction
                    (https://github.com/stellar/stellar-protocol/blob/master/core/cap-0021.md)
                    """),
    )


class TrxContractWrapper(BaseClientModel):
    parameter: TrxContractWrapperParameter = Field(alias="parameter")
    type_: str = Field(alias="type")


class WalletDetails(BaseClientModel):
    """A wallet's details"""

    address: str = Field(
        alias="address",
        description="Address of the wallet",
        examples=["0x55d398326f99059ff775485246999027b3197955"],
    )
    balances: Optional[List[AssetBalance]] = Field(
        default=None,
        alias="balances",
        description=("""
                    Balance of the wallet, null value means server failed to fetch balances,
                    empty list indicates that the wallet is empty
                    """),
    )
    block_chain: Blockchain = Field(
        alias="blockChain",
        description="The blockchain which this wallet belongs to",
        examples=[Blockchain.BSC],
    )
    explorer_url: str = Field(
        alias="explorerUrl",
        description="The explorer url of the wallet, e.g. bscscan or harmony explorer",
        examples=[
            "https://bscscan.com/address/0x9F8cCdaFCc39F3c7D6EBf637c9151673CBc36b88",
        ],
    )
    failed: bool = Field(
        alias="failed",
        description=("""
                    If it's true, it means that Rango could not fetch this wallet's balance;
                    maybe trying again later could solve the problem.
                    """),
        examples=[False],
    )


class BasicApiEvmTransaction(GenericTransaction):
    approve_data: Optional[str] = Field(
        default=None,
        alias="approveData",
        description=("""
                    The data of approve transaction. If it's null means that there is no
                    need to approve.
                    """),
    )
    approve_to: Optional[str] = Field(
        default=None,
        alias="approveTo",
        description=("""
                    Address of token contract which should be called with approveData (This
                    is not the spender address, the spender is encoded in approveData).
                    """),
    )
    block_chain: BasicApiBlockchainMetaSummary = Field(
        alias="blockChain", description="Blockchain metadata"
    )
    from_: str = Field(
        alias="from", description="The source wallet address, it can be null"
    )
    gas_limit: Optional[str] = Field(
        default=None,
        alias="gasLimit",
        description="Recommended gas limit for transaction",
    )
    gas_price: Optional[int] = Field(
        default=None,
        alias="gasPrice",
        description="Recommended gas price for transaction (For non eip1559 transactions)",
    )
    max_fee_per_gas: Optional[int] = Field(
        default=None,
        alias="maxFeePerGas",
        description=("""
                    The maximum fee per unit of gas willing to be paid for the transaction
                    (inclusive of baseFeePerGas and maxPriorityFeePerGas)
                    """),
    )
    max_priority_fee_per_gas: Optional[int] = Field(
        default=None,
        alias="maxPriorityFeePerGas",
        description=("""
                    The maximum price of the consumed gas to be included as a tip to the
                    validator
                    """),
    )
    priority_gas_price: Optional[int] = Field(
        default=None,
        alias="priorityGasPrice",
        description=("""
                    The maximum price of the consumed gas to be included as a tip to the
                    validator
                    """),
    )
    tx_data: Optional[str] = Field(
        default=None,
        alias="txData",
        description=("""
                    The data of smart contract call, it can be null in case of native token
                    transfer
                    """),
    )
    tx_to: str = Field(
        alias="txTo", description="Address of smart contract that is going to be called"
    )
    value: Optional[str] = Field(
        default=None,
        alias="value",
        description="The amount of transaction in case of native token transfer",
    )


class BasicApiMetaResponse(BaseClientModel):
    """A wrapper class for all tokens, blockchains, and swappers' metadata of Rango"""

    blockchains: List[BasicApiBlockchainMeta] = Field(
        alias="blockchains", description="List of all supported blockchains"
    )
    swappers: List[SwapperMetaDto] = Field(
        alias="swappers", description="List of all DEXes & Bridges"
    )
    tokens: List[BasicApiToken] = Field(
        alias="tokens", description="List of all tokens"
    )


class BasicApiQuoteResponseRoute(BaseClientModel):
    """Route found by Rango"""

    amount_restriction: Optional[BasicApiQuoteResponseRouteRestriction] = Field(
        default=None,
        alias="amountRestriction",
        description="Amount restriction for a swapper",
    )
    estimated_time_in_seconds: int = Field(alias="estimatedTimeInSeconds")
    fee: List[BasicApiSwapFee] = Field(alias="fee")
    fee_usd: Optional[float] = Field(
        default=None, alias="feeUsd", description="fee in usd"
    )
    from_: BasicApiToken = Field(
        alias="from",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )
    output_amount: int = Field(alias="outputAmount", description="Swap output")
    output_amount_min: int = Field(
        alias="outputAmountMin", description="Minimum swap output"
    )
    output_amount_usd: Optional[float] = Field(
        default=None, alias="outputAmountUsd", description="Swap output in usd"
    )
    path: Optional[List[BasicApiQuotePath]] = Field(
        default=None,
        alias="path",
        description="List of swap steps which make whole route",
    )
    price_impact_usd: Optional[Decimal] = Field(
        default=None,
        alias="priceImpactUsd",
        description="Price change amount based on usd",
        examples=[Decimal("0.244168")],
    )
    price_impact_usd_percent: Optional[Decimal] = Field(
        default=None,
        alias="priceImpactUsdPercent",
        description="Percentage change in price based on usd",
        examples=[Decimal("0.0011")],
    )
    swapper: SwapperMetaDto = Field(alias="swapper", description="Metadata of Swapper")
    to: BasicApiToken = Field(
        alias="to",
        description=("""
                    A token's metadata, which is unique by (blockchain, symbol, and address)
                    """),
    )


class BasicApiStarkNetTransaction(GenericTransaction):
    approve_calls: Optional[List[StarknetCallData]] = Field(
        default=None, alias="approveCalls", description="List of approves calldata"
    )
    block_chain: Blockchain = Field(alias="blockChain")
    calls: Optional[List[StarknetCallData]] = Field(
        default=None,
        alias="calls",
        description="List of calldata to sign a multiple transaction",
    )
    fee_data_availability_mode: Optional[
        BasicApiStarkNetTransactionFeeDataAvailabilityMode
    ] = Field(
        default=None,
        alias="feeDataAvailabilityMode",
        description="Fee data availability mode",
    )
    nonce_data_availability_mode: Optional[
        BasicApiStarkNetTransactionFeeDataAvailabilityMode
    ] = Field(
        default=None,
        alias="nonceDataAvailabilityMode",
        description="Nonce data availability mode",
    )
    resource_bounds: StarkNetResourceBounds = Field(
        alias="resourceBounds", description="Resource bounds for different gas types"
    )
    tip: Optional[int] = Field(
        default=None, alias="tip", description="Tip for the sequencer"
    )


class CosmosTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain",
        description=("""
                    The blockchain that this transaction will be executed in, same as the
                    input blockchainof create transaction
                    """),
    )
    data: CosmosMessage = Field(
        alias="data",
        description=("""
                    A real cosmos message, most fields of this object should be directly
                    passed to wallet for signing by user, the important part is `msgs` field
                    that contains all the cosmos actions that should be performed.
                    """),
    )
    from_wallet_address: str = Field(
        alias="fromWalletAddress",
        description=("""
                    Address of wallet that this transaction should be executed in, same as
                    the create transaction request's input
                    """),
    )
    raw_transfer: Optional[CosmosRawTransferData] = Field(
        default=None,
        alias="rawTransfer",
        description=("""
                    An alternative to CosmosMessage object for the cosmos wallets that do
                    not support generic Cosmos messages
                    """),
    )


class HyperliquidTransaction(GenericTransaction):
    action: HyperliquidTransactionActionMessage = Field(
        alias="action", description="hyperliquid action to send"
    )
    block_chain: Optional[Blockchain] = Field(default=None, alias="blockChain")
    message: str = Field(
        alias="message",
        description="EIP712 Json message to be signed by the user's wallet",
    )
    nonce: int = Field(
        alias="nonce",
        description="nonce for the transaction. must match time in the action parameter",
    )


class SolanaTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain", description="Transaction blockchain"
    )
    from_: str = Field(
        alias="from", description="Wallet address of transaction initiator"
    )
    identifier: str = Field(
        alias="identifier", description="Transaction identifier in case of retry"
    )
    instructions: List[SolanaInstruction] = Field(
        alias="instructions", description="List of instructions"
    )
    recent_blockhash: Optional[str] = Field(
        default=None,
        alias="recentBlockhash",
        description="Recent blockHash. fills only if message is already partially signed",
    )
    serialized_message: Optional[str] = Field(default=None, alias="serializedMessage")
    signatures: List[SolanaSignature] = Field(
        alias="signatures",
        description="List of signatures. fills only if message is already partially signed",
    )
    tx_type: SolanaTransactionTxType = Field(
        alias="txType",
        description="type of Solana transaction. available values are {LEGACY, VERSIONED}",
    )


class StellarTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain",
        description="The blockchain that this transaction is going to run in",
    )
    data: StellarTransactionData = Field(
        alias="data",
        description="The data and parameters for building the stellar transaction",
    )


class SuiTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain", description="Transaction blockchain"
    )
    json_tx_parameters: Dict[str, Any] = Field(
        alias="jsonTxParameters",
        description="Transaction Json string that should be con select and sign in wallet",
    )
    unsigned_ptb_base64: str = Field(
        alias="unsignedPtbBase64",
        description="Transaction ByteArray that should be send to the wallet for signing",
    )


class TonTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain",
        description="The blockchain that this transaction is going to run in",
    )
    from_: str = Field(
        alias="from",
        description=("""
                    The sender address in '<wc>:<hex>' format from which DApp intends to
                    send the transaction. Current account.address by default.
                    """),
    )
    messages: List[TonTransactionMessage] = Field(
        alias="messages", description="Messages to send: min is 1, max is 4."
    )
    network: str = Field(
        alias="network",
        description=("""
                    The network (mainnet or testnet) where DApp intends to send the
                    transaction. If not set, the transaction is sent to the network
                    currently set in the wallet, but this is not safe and DApp should always
                    strive to set the network. If the network parameter is set, but the
                    wallet has a different network set, the wallet should show an alert and
                    DO NOT ALLOW TO SEND this transaction. +mainnet: "-239" testnet: "-3"
                    """),
    )
    valid_until: int = Field(
        alias="validUntil",
        description="Sending transaction deadline in unix epoch seconds.",
    )


class TransferTransaction(GenericTransaction):
    amount: int = Field(
        alias="amount",
        description="The machine-readable amount of transaction",
        examples=[1000000000000000000],
    )
    asset: AssetWithTicker = Field(
        alias="asset", description="An asset with its ticker"
    )
    decimals: int = Field(alias="decimals", description="The decimals of the asset")
    from_wallet_address: str = Field(
        alias="fromWalletAddress",
        description="Source wallet address that can sign this transaction",
    )
    memo: Optional[str] = Field(
        default=None, alias="memo", description="The memo of transaction, can be null"
    )
    memo_type: Optional[TransferTransactionMemoType] = Field(
        default=None,
        alias="memoType",
        description="Specifies the type of memo that dApps should use for decoding.",
    )
    method: str = Field(
        alias="method",
        description=("""
                    The method that should be passed to wallet including `deposit`,
                    `transfer`
                    """),
    )
    psbt: Optional[PSBT] = Field(
        default=None, alias="psbt", description="Partially signed bitcoin transaction"
    )
    recipient_address: Optional[str] = Field(
        default=None,
        alias="recipientAddress",
        description="Destination wallet address that the fund should be sent to",
    )


class TrxRawData(BaseClientModel):
    """Raw data of TrxTransaction"""

    contract: List[TrxContractWrapper] = Field(alias="contract")
    data: str = Field(alias="data")
    expiration: int = Field(alias="expiration")
    fee_limit: Optional[int] = Field(default=None, alias="fee_limit")
    ref_block_bytes: str = Field(alias="ref_block_bytes")
    ref_block_hash: str = Field(alias="ref_block_hash")
    timestamp: int = Field(alias="timestamp")


class WalletDetailsResponse(BaseClientModel):
    """A list of wallets details"""

    wallets: List[WalletDetails] = Field(alias="wallets")


class XrplTransaction(GenericTransaction):
    block_chain: Blockchain = Field(
        alias="blockChain",
        description="The blockchain that this transaction is going to run in",
    )
    data: Any = Field(
        alias="data",
        description=("""
                    Xrpl Json Transaction info baased on [Xrpl
                    Docs](https://xrpl.org/docs/references/protocol/transactions/types)
                    """),
    )


class BasicApiQuoteResponse(BaseClientModel):
    """The best route response was found by Rango."""

    error: Optional[str] = Field(
        default=None, alias="error", description="Error occurred during operation"
    )
    error_code: Optional[int] = Field(
        default=None,
        alias="errorCode",
        description="Error code show error type in rango",
    )
    request_id: str = Field(
        alias="requestId",
        description=("""
                    The unique requestId generated for this request by server. It should be
                    passed down to all other endpoints if this swap continues on
                    """),
        examples=["d10657ce-b13a-405c-825b-b47f8a5096aa"],
    )
    result_type: BasicApiSwapResponseResultType = Field(
        alias="resultType", description="Route state"
    )
    route: Optional[BasicApiQuoteResponseRoute] = Field(
        default=None, alias="route", description="Route found by Rango"
    )
    trace_id: Optional[int] = Field(
        default=None,
        alias="traceId",
        description="Trace id help Rango support to resolve the issue",
    )


class BasicApiTrxTransaction(GenericTransaction):
    payload: Optional[Any] = Field(
        default=None,
        alias="__payload__",
        description="the payload data for transaction",
    )
    approve_tx_id: Optional[str] = Field(
        default=None,
        alias="approveTxID",
        description="the txID data for approve transaction",
    )
    approve_visible: Optional[bool] = Field(
        default=None,
        alias="approveVisible",
        description="the visible data for approve transaction",
    )
    approve_payload: Optional[Any] = Field(
        default=None,
        alias="approve_payload",
        description="the payload data for approve transaction",
    )
    approve_raw_data: Optional[TrxRawData] = Field(
        default=None, alias="approve_raw_data", description="Raw data of TrxTransaction"
    )
    approve_raw_data_hex: Optional[str] = Field(
        default=None,
        alias="approve_raw_data_hex",
        description="The hex data for approve transaction",
    )
    block_chain: BasicApiBlockchainMetaSummary = Field(
        alias="blockChain", description="Blockchain metadata"
    )
    raw_data: Optional[TrxRawData] = Field(
        default=None, alias="raw_data", description="Raw data of TrxTransaction"
    )
    raw_data_hex: Optional[str] = Field(
        default=None,
        alias="raw_data_hex",
        description="The hex data for smart contract call",
    )
    tx_id: str = Field(
        alias="txID", description="the txID data for smart contract call"
    )
    visible: bool = Field(
        alias="visible", description="the visible data for smart contract call"
    )


class BasicApiSwapResponse(BaseClientModel):
    """Swap response"""

    error: Optional[str] = Field(default=None, alias="error")
    error_code: Optional[int] = Field(default=None, alias="errorCode")
    request_id: str = Field(alias="requestId")
    result_type: BasicApiSwapResponseResultType = Field(alias="resultType")
    route: Optional[BasicApiQuoteResponseRoute] = Field(
        default=None, alias="route", description="Route found by Rango"
    )
    trace_id: Optional[int] = Field(default=None, alias="traceId")
    tx: Optional[
        Union[
            BasicApiEvmTransaction,
            BasicApiStarkNetTransaction,
            BasicApiTrxTransaction,
            CosmosTransaction,
            HyperliquidTransaction,
            SolanaTransaction,
            StellarTransaction,
            SuiTransaction,
            TonTransaction,
            TransferTransaction,
            XrplTransaction,
        ]
    ] = Field(default=None, alias="tx", discriminator="type")
