"""
nexcode - CLI for the Nexcode AI
"""

__version__ = "0.5.1"
__app_name__ = "nexcode"
__description__ = "CLI for the Nexcode AI - configure providers and run workspace agents from your terminal"
