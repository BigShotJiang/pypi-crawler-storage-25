"""
reporter.py - Internal investigation engine for Nexcode Agent.

This module runs before the Fix Planner. Its purpose is to search, read, and
understand the codebase based on the user's issue, building up investigation
memory before producing routing metadata and a report for the main assistant.
"""

import json
from pathlib import Path
from rich.console import Console

from nexcode.agent_runtime.prompt_context import build_compact_workspace_summary, summarize_tool_observation
from nexcode.agent_runtime.presentation import ui_detail, ui_status, ui_thought, ui_done
from nexcode.agent_runtime.task_scope import resolve_task_scope
from nexcode.agent_runtime.workspace import safe_path

console = Console()


def _existing_workspace_files(workspace: Path, items) -> list[str]:
    if isinstance(items, str):
        candidates = [items]
    elif isinstance(items, list):
        candidates = items
    else:
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        value = str(item or "").strip()
        if not value or value in seen:
            continue
        candidate = value.split(" (", 1)[0].strip()
        if not candidate:
            continue
        try:
            target = safe_path(workspace, candidate)
        except Exception:
            continue
        if not target.exists() or not target.is_file():
            continue
        seen.add(candidate)
        normalized.append(candidate.replace("\\", "/"))
    return normalized

REPORTER_SYSTEM_PROMPT = """
You are the internal investigation engine for Nexcode Agent. Your job is to
survey the codebase, diagnose bugs, understand architecture, and prepare
evidence-backed guidance for the main assistant.

You are NOT the final user-facing assistant. Any user-facing text that you put
into `user_instructions` or `final_report` must sound like Nexcode Agent
speaking naturally. Never mention being an investigator, never mention routing,
scratchpads, or internal tools, and never say you are performing an
investigation unless the user explicitly asks about internals.

The user has presented a query or reported a bug. You must figure out what
needs to be changed, how confident you are, and what depth of action is required.

# RULES

1. **STRICTLY PROHIBITED FROM MODIFYING THE WORKSPACE (CRITICAL)**:
   - You are AN INVESTIGATOR ONLY. Your goal is to survey, diagnose, and report.
   - You are **FORBIDDEN** from creating, writing, deleting, or modifying any files in the workspace (including creating "test" or "script" files).
   - If the user asks to "Create a file", your job is to confirm it doesn't exist and define what the content should be in your `final_report`.
   - Never use `run_command` to execute shell redirects (e.g., `echo "..." > file.py`) or pipes (|) to provide input. These are "black box" and non-Antigravity-parity.
   - Instead, use the **`run_command` → `command_status` → `send_command_input`** workflow for all interactive diagnostics.
   - Use `command_status` to check if a process is waiting for input, and `send_command_input(command_id, input_string="your_input\n")` to answer prompts.
   - Any violation of the "No Pipes/Redirects" rule is a SYSTEM FAILURE.
   - Observer only. Implement nothing. Let the Coder handle all execution/creation.

2. **SCRATCHPAD IS YOUR WORKING MEMORY** — treat it like a senior engineer's notepad:
   - On EVERY tool call, update `scratchpad_update` with your findings so far (bullet format).
   - Track: files checked, patterns found, open questions, confirmed flaws.
   - Ask yourself: "What have I confirmed? What still needs verification?" before each tool call.
   - Do NOT paste raw tool output — write distilled conclusions only.

3. **BATCH READS, TARGETED GREPS**:
   - Use `multi_read` to read multiple files at once — never read one file per turn when 3 are needed.
   - Use `grep_search` to find patterns GLOBALLY before assuming where something is.
   - **Both `read_file` and `multi_read` are size-aware — identical rules per file:**
     * Small files (≤350 lines) → returns the FULL numbered content. Read it directly.
     * Large files → returns first 80 + last 20 lines and tells you the TOTAL line count.
       After seeing the preview, use `read_lines(path, start_line, end_line)` to read the
       exact section you need. Never skip straight to submit_report after a large-file preview.
   - `read_lines` has NO truncation — whatever range you request, you get in full.
   - `read_lines` output always includes: `FILE: path [lines X–Y of Z total]` so you always
     know your position. Use this to plan the next range to read if needed.
   - `search_file` always includes the total line count in its output — use it to locate
     a term before calling `read_lines` on the surrounding range.

4. **THE FOLLOW-THROUGH RULE (CRITICAL — this is what separates surface reviews from real ones)**:
   - When `grep_search` returns matches, do NOT use match counts as a finding. Read the actual lines.
   - When you find a flaw (e.g. bare `except`), follow it:
     a. Read the surrounding context (what is being swallowed?)
     b. Trace the caller (who calls this function? what breaks if this fails silently?)
     c. THEN add it as a finding with full context.
   - Example of LAZY (not acceptable): "Found 5 bare `except` statements — error handling is weak."
   - Example of DEEP (required): "`executor.py:dispatch_tool()` swallows JSON parse errors silently.
     Called by `run_plan_step()` which continues execution on failure — agent runs blind if any tool call
     returns malformed JSON. Impact: silent plan corruption with no user feedback."

5. **CROSS-FILE TRACING (SEMANTIC AWARENESS)**:
   - Do not read files in isolation. When you find a function or class, you MUST know who calls it.
   - Use the `find_callers` tool to definitively find every file that imports or executes a target symbol. Do NOT rely entirely on `grep_search` to find callers, as you will miss aliases.
   - Use the `find_definition` tool to quickly locate where a symbol is implemented.
   - Architectural findings require tracing at least 2 hops: entry point → module → sub-module.
   - If a function needs to be updated, YOU MUST add its callers to your `checked_files` list so the planner knows the blast radius.

6. **SELF-QUESTION BEFORE SUBMITTING**:
   Ask yourself these questions before calling `submit_report`:
   - "Can a developer read my findings and immediately know what to fix, in which file, at which line?"
   - "Have I followed every grep match to its actual code, or did I just count matches?"
   - "Have I traced the impact — what actually breaks if this flaw exists?"
   - If ANY answer is "no" or "not sure", do another read/grep before submitting.

7. **DEPTH MATCHES COMPLEXITY**:
   - Simple/local bug: 2-4 tool calls. grep → read → submit.
   - Architecture review / broad audit: 6-12+ tool calls. Read entry points, grep patterns,
     follow findings, trace callers, cross-check multiple modules, then submit.
   - For broad issues: read the shared config/entry point + 2-3 representative modules.
     Do NOT try to read every single file — identify the pattern, trace its impact, submit.

8. **NO RUNTIME/BUILD TESTS**: You are an investigator ONLY. STRICTLY FORBIDDEN from running
   `npm run build`, `npm test`, `pytest`, or trying to compile. Just read code and `submit_report`.

9. Every final report MUST include:
   - `complexity`: `simple` or `complex`
   - `confidence`: `low`, `medium`, or `high`
   - `checked_files`: the key files or areas you inspected
   - `needs_plan_preview`: true for complex code changes, false for simple/local fixes
   - when code changes are needed: `target_scope` (`single_file`, `localized`, or `project_wide`)
     and `validation_level` (`none`, `scoped`, or `broad`)
   - set `overwrite_existing` to true only when the user explicitly asked to replace an existing file

10. If you return `answer_only`, you MUST include:
   - what you checked
   - why the answer is correct
   - how the user can verify it

11. If you return `need_more_info`, state exactly what detail is missing and why it matters.
12. If you return `code_change` for a broad issue, describe the affected pattern or surfaces, not just one file.
13. For explicit create-new-file requests, do NOT reinterpret generic words like test, script, or helper
    as permission to overwrite an existing file named `test.py`, `script.py`, etc.
14. If the user asks for a plain algorithm/script file, do NOT assume `unittest`, `pytest`, or a separate
    validation harness unless the user explicitly asked for tests.

15. **HISTORY vs FRESH INVESTIGATION**:
    - You may receive a "Previous Session History" block. Use it wisely:
    - FOLLOW-UP query (user references past work: "improve that", "fix what you found", "continue")
      → Use history as starting context, then verify anything relevant is still true by reading the code.
    - FRESH query (new topic, new analysis: "review my code", "find flaws", "give me a diagram")
      → Treat history as BACKGROUND ONLY. Do a FULL fresh investigation.
      → NEVER say "previous review found X" as a finding. Re-read the code. Re-verify everything.
      → Previous findings may be stale, incomplete, or based on a different state of the codebase.

16. **FAILURE RECOVERY (PIVOTING)**:
    - If the user reports that your previous fix "didn't work", "is still broken", or caused a new error, you MUST NOT repeat the same investigation path.
    - You must structurally investigate WHY the previous fix failed and pivot your understanding to a completely new root cause.

You must call exactly ONE tool per response in a valid JSON object.

The `"thinking"` field is CRITICAL — it must be SPECIFIC and ADVANCING, never generic:
- It MUST reflect what you just learned from the previous tool result.
- It MUST state exactly WHY you are calling the next tool (what gap you're filling).
- It MUST NOT repeat mode labels like "Review-only mode:" or "In consult mode:" on every turn.
- It MUST NOT restate the user's request. That's already known.
- WRONG: "Review-only mode: full codebase audit. From recent multi_read, found issues."
- RIGHT: "multi_read revealed bare `except Exception: pass` in executor.py:dispatch_tool() line 631.
   I need grep_search to find all callers of dispatch_tool() to assess the blast radius."

{"thinking": "I can see from the workspace index that executor.py and reporter.py are the largest files. I'll batch-read both entry point functions to understand the control flow before searching for specific flaws.", "scratchpad_update": "- Starting fresh: reading executor.py + reporter.py entry points", "tool": "multi_read", "args": {"paths": ["nexcode/agent_runtime/executor.py", "nexcode/agent_runtime/reporter.py"], "focus_terms": ["def run", "def execute", "def investigate"]}}
{"thinking": "grep returned 5 matches for bare except in executor.py lines 420, 631, 788. I need to read_lines around each to understand what is being swallowed — match count alone is not a finding.", "scratchpad_update": "- 5 bare excepts in executor.py — need to read actual context", "tool": "read_lines", "args": {"path": "nexcode/agent_runtime/executor.py", "start_line": 625, "end_line": 640}}


# THE FINAL TOOL


When your investigation is complete, call:

{{
  "thinking": "I now understand the issue completely.",
  "tool": "submit_report",
  "args": {{
    "resolution_type": "code_change",
    "issue_category": "unknown",
    "complexity": "simple",
    "confidence": "medium",
    "checked_files": ["src/app.tsx"],
    "needs_plan_preview": false,
    "user_instructions": "",
    "is_question": false,
    "investigation_scratchpad": "Your internal notes and deductions so far...",
    "final_report": "A highly detailed, file-by-file breakdown of what is wrong and EXACTLY what the Fix Planner must do to fix it."
  }}
}}

RESOLUTION ROUTING (CRITICAL):
- Set resolution_type to ONE of:
  - "code_change": code edits are required; Fix Planner should run.
  - "user_action_only": no code edits needed; the user must do something (restart dev server, clear cache, run a command).
  - "answer_only": user asked a question OR the request is already satisfied in the codebase; answer in user_instructions and stop.
  - "need_more_info": you cannot proceed; ask for missing info in user_instructions and stop.
- issue_category should be ONE of: "stale_cache", "config", "data", "ui", "unknown"
- If resolution_type is "user_action_only" / "answer_only" / "need_more_info":
  - Set is_question=true (backwards compatibility with agent.py's early-exit behavior).
  - Put the user-facing message (with exact steps/commands) in user_instructions.
  - final_report can be brief or the same as user_instructions.
- IMPORTANT: If the user asks to fix something and you confirm it's already fixed, use "answer_only" and include:
   - what files/patterns you checked
   - why it is already correct
   - how the user can verify (steps/expected result)
"""


REPORTER_CONSULT_ONLY_APPENDIX = """

CONSULT-ONLY MODE:
- The user is primarily asking for suggestions, explanation, guidance, or evaluation.
- You may inspect the codebase to ground your answer, but you are NOT authorized to initiate implementation work.
- Prefer `resolution_type="answer_only"` unless the user's wording explicitly asks to implement or modify code.
- Summarize what currently exists, what could be improved, and the highest-value suggestions based on the actual codebase.
- Avoid proposing direct edits as if they are already approved. Frame changes as recommendations.

INVESTIGATION DEPTH (CRITICAL — outcome-based, not count-based):
- Start with `search_workspace` or `list_files` to discover which files are relevant.
- Then READ the actual code using `multi_read`, `read_file`, or `read_lines`. Do NOT skip this.
- Use `grep_search` to find patterns, duplication, anti-patterns, or missing guards across the codebase.
- Keep investigating until you can give a SPECIFIC, CODE-GROUNDED answer:
  - Bad (not ready): "agent.py is large and possibly monolithic"
  - Good (ready): "agent.py's `run_agent()` function at line 420 mixes routing, retry logic, and state persistence — these should be separated"
- Only call `submit_report` when your findings are specific enough that a developer could act on them without guessing.
- How many files to read is YOUR decision based on complexity. A small project may need 2 reads; a large one may need 8+.
"""

REPORTER_REVIEW_ONLY_APPENDIX = """

REVIEW-ONLY MODE:
- The user is asking for an audit, review, or architecture critique of the current codebase.
- You are NOT authorized to change code in this mode.
- Prefer `resolution_type="answer_only"` unless a blocking ambiguity requires `need_more_info`.
- Focus on architecture, maintainability, correctness risks, missing boundaries, fragile flows, and testing gaps.

INVESTIGATION DEPTH (CRITICAL — outcome-based, not count-based):
- Start with `search_workspace` or `list_files` to map the codebase structure.
- Then READ the key files using `multi_read` to understand actual implementation.
- Use `grep_search` to find anti-patterns: bare `except`, silent failures, repeated logic, missing type hints, hardcoded values.
- Continue investigating until EVERY finding in your report is backed by something you actually read:
  - Bad (not ready): "error handling could be improved"
  - Good (ready): "reporter.py line 642 catches all exceptions with `except Exception: pass` silently — errors disappear"
- Only call `submit_report` when you can cite specific file names, function names, line ranges, or code patterns.
- Depth is YOUR call. Explore as much as needed to give findings a developer can immediately act on.

DIAGRAM SYNTAX RULES (CRITICAL — when producing any diagram):
- ALWAYS use valid Mermaid `graph TD` syntax. NEVER use ASCII flowcharts (no `|`, `v`, `+-->`, `-->` outside mermaid blocks).
- Every node label with spaces, parentheses, or special characters MUST be quoted: `A["agent.py:handle_agent_cli()"]`
- Use `-->` for arrows, `-- label -->` for labeled edges.
- Valid example:
  ```mermaid
  graph TD
    A["CLI Input"] --> B["agent.py:handle_agent_cli()"]
    B --> C{"Route Kind?"}
    C -->|execution_request| D["planner.py:extract_plan_steps()"]
    C -->|review_only| E["reporter.py:run_investigation()"]
    D --> F["executor.py:execute_plan()"]
  ```
- Test your Mermaid mentally: every `-->` must connect two valid node IDs.
"""




_ALLOWED_RESOLUTION_TYPES = {"code_change", "user_action_only", "answer_only", "need_more_info"}
_ALLOWED_ISSUE_CATEGORIES = {"stale_cache", "config", "data", "ui", "unknown"}
_ALLOWED_COMPLEXITY = {"simple", "complex"}
_ALLOWED_CONFIDENCE = {"low", "medium", "high"}
_ALLOWED_TARGET_SCOPES = {"single_file", "localized", "project_wide"}
_ALLOWED_VALIDATION_LEVELS = {"none", "scoped", "broad"}


REPORTER_TOOLS_DESCRIPTION = """
# AVAILABLE TOOLS

You must use exactly one of these tools per turn:

1. `grep_search(query: str, path: str = ".", include_patterns: list[str] = None)`
   Search for a regex pattern across files. 
   - `query`: The regex or string to find.
   - `path`: Directory to search (default ".").
   - `include_patterns`: Optional list of glob patterns to restrict search (e.g. ["*.ts", "*.vue"]).

2. `list_files(path: str = ".")`
   List all files in a directory recursively (ignoring build/system artifacts).
   Each entry shows: path, size (KB), and line count  e.g. `lib/ai/models.ts  [18.4KB 515L]`
   Use line count to decide: ≤350L → read_file (full); >350L → read_lines (targeted).
   - `path`: The directory to list.

3. `multi_read(paths: list[str], focus_terms: list[str] = None)`
   Read multiple files or excerpts at once.
   - `paths`: List of relative file paths.
   - `focus_terms`: Optional terms to help center excerpts on relevant code.

4. `read_file(path: str)`
   Read the entire content of a single file.

5. `search_file(path: str, query: str)`
   Search for a string within a specific file and return matching lines.

6. `read_lines(path: str, start_line: int, end_line: int)`
   Read a specific 1-indexed line range.

7. `search_workspace(query: str, top_k: int = 15)`
   Search the workspace index for files relevant to a query.
   Returns ranked file paths with exports, line count, and summary.
   - Use this FIRST for broad or exploratory requests ("explore my code", "find performance issues", "audit architecture").
   - For targeted queries it returns the most relevant files; for vague queries it returns the full index map.
   - After calling this, use `multi_read` or `read_file` to inspect the files you care about.

8. `run_command(cmd: str, path: str = ".", background: bool = False, timeout_ms: int = 5000)`
   Execute a shell command. By default, it waits up to `timeout_ms`. If it doesn't finish, it returns a `command_id` and detaches to the background.
   - `background: True` runs it completely asynchronously from the start.
   - Use this to start dev servers, run test suites, or execute scripts.

9. `command_status(command_id: str, line_count: int = 50)`
   Check the live status (RUNNING, DONE) and view the recent `stdout/stderr` of a background process.
   - Use this after `run_command` detaches a process.

10. `send_command_input(command_id: str, input_string: str = None, terminate: bool = False)`
   Send standard input (like "Y\n" or "password\n") to an interactive script that is blocked/hanging, or forcibly kill a background running process with `terminate=True`.

11. `fetch_url(url: str, max_chars: int = 20000)`
   Fetch a URL and return its content as plain text (HTML stripped).
   Use for: library docs, API references, changelogs, GitHub issues, npm/pypi package details.
   - `url`: Must start with http:// or https://
   - `max_chars`: How many chars to return (default 20000, max 60000)

12. `find_callers(target_symbol: str)`
    Finds all direct callers or usages of a target function/class across the workspace.
    Use this to trace blast-radius dependencies when proposing changes to APIs.
    - `target_symbol`: Exact name of the function or class.

13. `find_definition(target_symbol: str)`
    Finds the exact file and line where a function or class is defined.

14. `web_search(query: str, max_results: int = 6)`
    Search the web using DuckDuckGo. Returns titles + snippets + URLs.
    Use for: error messages, library docs, API names, CVEs, changelogs.
    Workflow: web_search(query) → read snippets → fetch_url(url) for full page.

15. `submit_report(...)`
    Call this ONLY when your investigation is complete.
"""


def _build_reporter_system_prompt(routing_mode: str) -> str:
    base = REPORTER_SYSTEM_PROMPT
    if routing_mode == "consult_only":
        base += REPORTER_CONSULT_ONLY_APPENDIX
    elif routing_mode == "review_only":
        base += REPORTER_REVIEW_ONLY_APPENDIX
    
    return base + "\n\n" + REPORTER_TOOLS_DESCRIPTION


def _validate_tool_call(t_name: str, t_args: dict) -> str | None:
    """
    Validate tool arguments against the actual function signature.
    Returns an error message if invalid, or None if valid.
    """
    import inspect
    from nexcode.agent_runtime.tool_registry import get_tool
    
    if t_name == "submit_report":
        return None
        
    try:
        func = get_tool(t_name)
    except Exception:
        return f"Error: Tool '{t_name}' is not recognized. Valid tools are: grep_search, list_files, multi_read, read_file, search_file, read_lines, run_command, command_status, send_command_input, submit_report."
        
    sig = inspect.signature(func)
    # The 'workspace' arg is injected by the runner, so we ignore it in validation
    params = list(sig.parameters.keys())
    if "workspace" in params:
        params.remove("workspace")
        
    # Check for unexpected arguments
    unexpected = [k for k in t_args if k not in params]
    if unexpected:
        valid_args = ", ".join(params)
        return f"Error: Tool '{t_name}' received unexpected argument(s): {', '.join(unexpected)}. Valid arguments are: {valid_args}."
        
    # Check for missing required arguments (those without defaults)
    missing = [
        k for k, v in sig.parameters.items() 
        if k != "workspace" and v.default is inspect.Parameter.empty and k not in t_args
    ]
    if missing:
        return f"Error: Tool '{t_name}' is missing required argument(s): {', '.join(missing)}."
        
    return None


def _build_reporter_user_prompt(
    orig_prompt: str,
    history_str: str,
    prompt: str,
    os_name: str,
    workspace_summary: str,
    routing_mode: str,
) -> str:
    if routing_mode == "consult_only":
        request_label = "User's Current Message"
        kickoff = (
            "Begin your investigation. Your first step should be to read the most relevant files "
            "using multi_read — not just search the index. "
            "If the user is asking how something works, read the actual entry point code first. "
            "Do NOT generate any diagrams, summaries, or architecture descriptions until you have "
            "read enough real code to use actual function names, module names, and real call flows."
        )
    elif routing_mode == "review_only":
        request_label = "User's Review Request"
        kickoff = (
            "Begin your investigation. Your FIRST tool call should be multi_read on the most important files "
            "based on the workspace summary — start reading actual code immediately. "
            "For architecture/diagram requests: you MUST read the real entry point functions and trace real call flows "
            "before drawing any diagram. A diagram using placeholder letters (A, B, C...) instead of real "
            "function/module names is UNACCEPTABLE — every node must come from code you actually read. "
            "Keep reading until you can describe the system with specific function names, file paths, and real data flows."
        )

    else:
        request_label = "User's Current Request/Bug"
        kickoff = "Begin your investigation. Identify the next best read or search to understand the required changes."
    import datetime
    now = datetime.datetime.now()
    current_time = now.strftime("%Y-%m-%d %H:%M:%S (%A)")
    
    return (
        f"Original Project Goal:\n{orig_prompt}\n\n"
        f"{history_str}"
        f"Assistant Routing Mode: {routing_mode}\n\n"
        f"{request_label}:\n{prompt}\n\n"
        f"Environment: {os_name}\n"
        f"Current Date/Time: {current_time}\n\n"
        f"Workspace Summary:\n{workspace_summary}\n\n"
        f"{kickoff}"
    )


def _append_scratchpad(existing: str, update: str, max_tokens: int = 20_000) -> str:
    """Append a scratchpad update, keeping the combined notes within a real token budget.

    Uses estimate_tokens (tiktoken o200k_base) for accurate accounting.
    When over budget, the oldest notes are trimmed — most-recent notes survive.
    """
    update = (update or "").strip()
    if not update:
        return existing or ""

    combined = f"{existing.rstrip()}\n{update}" if existing else update

    try:
        from nexcode.agent_runtime.token_utils import estimate_tokens
        if estimate_tokens(combined) <= max_tokens:
            return combined
        # Over budget — trim from the top until we fit
        lines = combined.splitlines()
        while lines and estimate_tokens("\n".join(lines)) > max_tokens:
            lines.pop(0)
        trimmed = "\n".join(lines)
        return f"[... earlier notes trimmed to fit token budget ...]\n{trimmed}"
    except Exception:
        # Fallback: character-based (4 chars ≈ 1 token → 20K tokens ≈ 80K chars)
        char_limit = max_tokens * 4
        if len(combined) <= char_limit:
            return combined
        return combined[-char_limit:]


def _normalize_checked_files(workspace: Path | None, raw_checked_files) -> list[str]:
    if workspace is None:
        if isinstance(raw_checked_files, str):
            items = [raw_checked_files]
        elif isinstance(raw_checked_files, list):
            items = raw_checked_files
        else:
            return []
        normalized: list[str] = []
        seen: set[str] = set()
        for item in items:
            value = str(item or "").strip()
            if not value or value in seen:
                continue
            seen.add(value)
            normalized.append(value.split(" (", 1)[0].strip().replace("\\", "/"))
        return [item for item in normalized if item]
    return _existing_workspace_files(workspace, raw_checked_files)


def _normalize_submit_report_args(workspace: Path | dict, t_args: dict | None = None) -> dict:
    workspace_arg = workspace
    if t_args is None:
        workspace = None
        t_args = dict(workspace_arg or {}) if isinstance(workspace_arg, dict) else {}
    else:
        workspace = workspace_arg if isinstance(workspace_arg, Path) else None
    resolution_type = str(t_args.get("resolution_type") or "code_change").strip()
    if resolution_type not in _ALLOWED_RESOLUTION_TYPES:
        resolution_type = "code_change"

    issue_category = str(t_args.get("issue_category") or "unknown").strip()
    if issue_category not in _ALLOWED_ISSUE_CATEGORIES:
        issue_category = "unknown"

    user_instructions = str(t_args.get("user_instructions") or "").strip()
    final_report = str(t_args.get("final_report") or "").strip()
    scratchpad = str(t_args.get("investigation_scratchpad") or "")
    complexity = str(t_args.get("complexity") or "simple").strip().lower()
    if complexity not in _ALLOWED_COMPLEXITY:
        complexity = "simple"
    confidence = str(t_args.get("confidence") or "medium").strip().lower()
    if confidence not in _ALLOWED_CONFIDENCE:
        confidence = "medium"
    checked_files = _normalize_checked_files(workspace, t_args.get("checked_files"))
    needs_plan_preview = bool(t_args.get("needs_plan_preview", complexity == "complex"))
    clarification_reason = str(t_args.get("clarification_reason") or "").strip()
    verification_steps = str(t_args.get("verification_steps") or "").strip()
    target_scope = str(t_args.get("target_scope") or "").strip().lower()
    overwrite_existing = bool(t_args.get("overwrite_existing", False))
    validation_level = str(t_args.get("validation_level") or "").strip().lower()

    is_question = bool(t_args.get("is_question", False))
    if resolution_type in {"user_action_only", "answer_only", "need_more_info"}:
        is_question = True

    if not user_instructions and resolution_type != "code_change":
        user_instructions = final_report
    if not final_report:
        final_report = user_instructions

    if target_scope not in _ALLOWED_TARGET_SCOPES:
        if checked_files and len(checked_files) == 1:
            target_scope = "single_file"
        elif checked_files:
            target_scope = "localized"
        else:
            target_scope = "project_wide" if complexity == "complex" else "localized"
    if validation_level not in _ALLOWED_VALIDATION_LEVELS:
        validation_level = "broad" if complexity == "complex" else "scoped"

    if resolution_type == "answer_only" and not final_report:
        final_report = user_instructions

    if resolution_type == "need_more_info":
        if not clarification_reason:
            clarification_reason = "I am missing a detail needed to continue safely."
        if not user_instructions:
            user_instructions = "Please share the missing detail so I can continue."
        final_report = user_instructions

    return {
        "is_question": is_question,
        "resolution_type": resolution_type,
        "issue_category": issue_category,
        "user_instructions": user_instructions,
        "report": final_report,
        "scratchpad": scratchpad,
        "complexity": complexity,
        "confidence": confidence,
        "checked_files": checked_files,
        "needs_plan_preview": needs_plan_preview,
        "clarification_reason": clarification_reason,
        "target_scope": target_scope,
        "overwrite_existing": overwrite_existing,
        "validation_level": validation_level,
        "verification_steps": verification_steps,
    }

def run_investigation(
    workspace: Path,
    prompt: str,
    orig_prompt: str,
    verbose: bool = False,
    image_urls: list[str] = None,
    fix_history: list = None,
    routing_mode: str = "implementation",
    task_scope=None,
) -> dict:
    """
    Run the Reporter loop until it submits a final report.
    Returns normalized routing metadata and the final report for the assistant flow.
    """
    from nexcode.config import load_access, load_agent_config
    from nexcode.agent_runtime.planner import _call_gateway
    from nexcode.agent_runtime.tool_registry import load_all_tools, get_tool
    
    acc = load_access()
    agent_cfg = load_agent_config(workspace)
    load_all_tools()
    
    status_msg = ui_status("Investigation", "Analyzing code...")
    with console.status(status_msg, spinner="point") as status:
        effective_scope = task_scope or resolve_task_scope(
            workspace,
            user_message=prompt,
            mode_hint=routing_mode,
        )
        workspace_summary, _ = build_compact_workspace_summary(
            workspace,
            query=prompt,
            checked_files=list(effective_scope.focused_files),
            task_scope=effective_scope,
        )
        
        import sys
        os_name = "Windows" if sys.platform == "win32" else "Linux/Mac"
        
        history_str = ""
        if fix_history:
            history_str = "PREVIOUS SESSION HISTORY (background context only):\n"
            for h in fix_history[-10:]:
                if isinstance(h, dict):
                    history_str += f"- Request: {h.get('prompt', 'Unknown')}\n  Outcome: {h.get('outcome', 'Done')}\n"
            history_str += "\n"
            
        user_p = _build_reporter_user_prompt(
            orig_prompt=orig_prompt,
            history_str=history_str,
            prompt=prompt,
            os_name=os_name,
            workspace_summary=workspace_summary,
            routing_mode=routing_mode,
        )
        
        observations = []
        scratchpad = ""
        try:
            from nexcode.agent_runtime.workspace import load_agent_state
            scratchpad = load_agent_state(workspace).get("reporter_scratchpad", "")
        except Exception: pass
        
        step_count = 1
        _max_steps = 20 if routing_mode in {"review_only", "consult_only"} else 14

        for attempt in range(1, _max_steps + 1):
            try:
                sys_p = _build_reporter_system_prompt(routing_mode)
                if scratchpad:
                    sys_p += f"\n\nCURRENT SCRATCHPAD MEMORY:\n{scratchpad}"
                    
                obs_text = "\n\n".join(observations[-30:])
                current_user_text = f"{user_p}\n\nRELEVANT OBSERVATIONS:\n{obs_text}\n\nNext step?"
                
                response, _usage = _call_gateway(
                    api_key=acc["api_key"],
                    endpoint=acc["endpoint"],
                    model=agent_cfg["model"],
                    system_prompt=sys_p,
                    user_prompt=current_user_text,
                    json_mode=True
                )
                
                from nexcode.agent_runtime.executor import extract_json
                tool_call = extract_json(response)
                if not tool_call or "tool" not in tool_call:
                    observations.append("System: No tool call found.")
                    continue
                    
                t_name = tool_call["tool"]
                t_args = tool_call.get("args", {})
                thinking = tool_call.get("thinking", "")
                scratchpad = _append_scratchpad(scratchpad, str(tool_call.get("scratchpad_update", "")))
                
                if thinking:
                    if verbose:
                        console.print(ui_thought(thinking))
                    else:
                        short = thinking.split('.')[0].strip()[:80]
                        status.update(ui_status("Investigating", short))
                
                if t_name == "submit_report":
                    status.stop()
                    console.print(ui_done("Investigation complete"))
                    res = _normalize_submit_report_args(workspace, t_args)
                    res["scratchpad"] = scratchpad
                    return res
                    
                if verbose:
                    console.print(ui_detail("Action", f"{t_name}"))
                
                # Execute tool
                val_err = _validate_tool_call(t_name, t_args)
                if val_err:
                    result = val_err
                else:
                    func = get_tool(t_name)
                    result = func(workspace, **t_args)

                observations.append(f"Observation from {t_name}:\n{summarize_tool_observation(t_name, result)}")
                if verbose:
                    console.print(ui_detail("Result", f"Received data"))

            except Exception as e:
                observations.append(f"System Error: {e}")
                if verbose: console.print(ui_status("Error", str(e), tone="error"))
            
            step_count += 1

        status.stop()
        console.print(ui_status("Warning", "Max steps reached", tone="warning"))
        return _normalize_submit_report_args(workspace, {"resolution_type": "answer_only", "report": "Timeout."})
