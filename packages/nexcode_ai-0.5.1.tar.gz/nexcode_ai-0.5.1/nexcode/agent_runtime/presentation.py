"""
presentation.py - Shared Rich markup helpers for a professional CLI presentation.
"""

from __future__ import annotations
from typing import Any
from rich.console import Console, Group
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich import box as rbox

_TONE_STYLES = {
    "info": "bold cyan",
    "accent": "bold magenta",
    "success": "bold green",
    "warning": "bold yellow",
    "error": "bold red",
    "neutral": "bold white",
    "muted": "dim",
}


def _style_for(tone: str) -> str:
    return _TONE_STYLES.get((tone or "info").lower(), _TONE_STYLES["info"])


def ui_header(title: str, details: str = "") -> str:
    cleaned_title = str(title or "").strip() or "Nexcode"
    cleaned_details = str(details or "").strip()
    if cleaned_details:
        return f"[bold white]{cleaned_title}[/bold white] [dim]{cleaned_details}[/dim]"
    return f"[bold white]{cleaned_title}[/bold white]"


def ui_status(label: str, message: str, tone: str = "info", width: int = 12) -> str:
    cleaned_label = str(label or "").strip() or "Status"
    cleaned_message = str(message or "").strip()
    padded_label = cleaned_label.ljust(max(width, len(cleaned_label)))
    style = _style_for(tone)
    if cleaned_message:
        return f"[{style}]{padded_label}[/{style}] {cleaned_message}"
    return f"[{style}]{padded_label}[/{style}]"


def ui_detail(label: str, message: str, width: int = 12) -> str:
    cleaned_label = str(label or "").strip() or "Detail"
    cleaned_message = str(message or "").strip()
    padded_label = cleaned_label.ljust(max(width, len(cleaned_label)))
    if cleaned_message:
        return f"[dim]{padded_label}[/dim] {cleaned_message}"
    return f"[dim]{padded_label}[/dim]"


def ui_step(step_idx: int, total_steps: int, task: str) -> str:
    return f"[bold magenta]Step {step_idx}/{total_steps}[/bold magenta] [white]{task}[/white]"


def ui_timing(message: str) -> str:
    return ui_detail("Timing", message)


def ui_card(title: str, content: Any, tone: str = "info") -> Group:
    """A minimal presentation group instead of a heavy framed card."""
    style = _style_for(tone).split()[1] if " " in _style_for(tone) else _style_for(tone)
    header = Text()
    if title:
        header.append(title, style="bold " + style)
    return Group(header, content)


def ui_thought(text: str) -> Text:
    """A minimal styling for an internal thought, matching Junie's quiet approach."""
    return Text(text, style="dim italic")


def ui_diff(filename: str, diff_text: str) -> Text:
    """
    A minimal syntax-colored diff, mimicking the cleaner Junie-style presentation.
    Shows the changed chunks without any surrounding boxes or background colors.
    """
    lines = diff_text.splitlines()
    formatted = Text()
    
    formatted.append(f"  {filename}\n", style="bold underline")
    
    for line in lines:
        if line.startswith("+++") or line.startswith("---") or line.startswith("Index:"):
            continue
        if line.startswith("@@"):
            formatted.append(f"  {line}\n", style="dim cyan")
        elif line.startswith("+"):
            formatted.append(f"  {line}\n", style="bold green")
        elif line.startswith("-"):
            formatted.append(f"  {line}\n", style="bold red")
        else:
            formatted.append(f"  {line}\n")

    return formatted


def ui_done(message: str) -> str:
    """A clean completion marker."""
    return f"[bold green]✔[/bold green] {message}"


def ui_divider(label: str = "") -> Text:
    """A minimal horizontal divider."""
    if not label:
        return Text("─" * 40, style="dim")
    return Text(f"─ {label} " + "─" * (35 - len(label)), style="dim")
