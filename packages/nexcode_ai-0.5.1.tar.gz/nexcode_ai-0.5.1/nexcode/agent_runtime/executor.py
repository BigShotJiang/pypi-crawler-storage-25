"""
executor.py — The main Agent Execution Loop.

Orchestrates: Coder → Editor → Verifier → Repair cycle per plan step.
Key improvements:
  - Tolerant JSON parsing (parse_tool_call_from_text as fallback)
  - Raw LLM response logging (preview only, no secrets)
  - REPAIR MODE instead of force-submit/reject on duplicate loops
  - Canonical tool signatures (read ops unique per-file+args)
  - Per-step step_attempts counter; global_iterations only on file writes
  - All file-writes routed through Editor (atomic + snapshot + rollback)
  - HLU escalation when reject_count exceeds max_rejects threshold
  - Verifier and Repair agents integrated
"""
import ast
import re
import json
import time
from pathlib import Path
from rich.console import Console, Group
from rich.text import Text

from nexcode.config import load_access, load_agent_config
from nexcode.agent_runtime.prompt_context import summarize_tool_observation
from nexcode.agent_runtime.project_profile import detect_project_profile
from nexcode.agent_runtime.task_scope import resolve_task_scope
from nexcode.agent_runtime.workspace import (
    cleanup_step_scratch_dir,
    get_logs_dir,
    get_project_root,
    get_step_scratch_dir,
    is_scratch_path,
    save_agent_state,
    load_agent_state,
    get_agent_artifacts_dir,
    normalize_rel_path,
    record_recent_targets,
    resolve_agent_path,
)
from nexcode.agent_runtime.tool_registry import load_all_tools, get_tool
from nexcode.agent_runtime.workspace_index import update_index_for_files
from nexcode.agent_runtime.planner import _call_gateway
from nexcode.agent_runtime.presentation import ui_detail, ui_status, ui_step, ui_card, ui_thought, ui_diff, ui_divider
from nexcode.agent_runtime.token_utils import UsageData
from nexcode.utils import generate_diff
from nexcode.tools.shell_tools import extract_command_paths

console = Console()


# ---------------------------------------------------------------------------
# JSON Parsing helpers
# ---------------------------------------------------------------------------

def extract_json(text: str):
    """Robust JSON extraction — tries fences, whole text, and brace-scan."""
    # 1. Markdown fences
    if "```json" in text:
        match = re.search(r'```json(.*?)```', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1).strip())
            except Exception:
                pass
    if "```" in text:
        match = re.search(r'```(.*?)```', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1).strip())
            except Exception:
                pass

    # 2. Whole text
    try:
        return json.loads(text.strip())
    except Exception:
        pass

    # 3. Brace scan: find first '{' then squeeze from last '}'
    start = text.find("{")
    if start == -1:
        return None
    for i in range(len(text) - 1, start - 1, -1):
        if text[i] == "}":
            candidate = text[start:i + 1]
            try:
                return json.loads(candidate)
            except Exception:
                continue
    return None


def parse_tool_call_from_text(text: str):
    """
    Tolerant parser for tool calls. Tries:
      1. extract_json — if it has 'tool' and 'args', return.
      2. Brute-force brace-scan for a JSON object with both 'tool' and 'args'.
      3. Regex TOOL:/tool= + ARGS:/args= pattern.
    Returns dict or None.
    """
    o = extract_json(text)
    if isinstance(o, dict) and "tool" in o and "args" in o:
        return o

    # Brute-force brace scan
    opens = [m.start() for m in re.finditer(r'\{', text)]
    for start in opens:
        for end in range(len(text), start, -1):
            candidate = text[start:end]
            if '"tool"' in candidate and '"args"' in candidate:
                try:
                    parsed = json.loads(candidate)
                    if isinstance(parsed, dict) and "tool" in parsed and "args" in parsed:
                        return parsed
                except Exception:
                    continue

    # Regex fallback: TOOL: name  ARGS: {...}
    m = re.search(r'tool[:=]\s*["\']?([a-zA-Z0-9_]+)["\']?', text, re.IGNORECASE)
    if m:
        tool = m.group(1)
        m2 = re.search(r'args[:=]\s*(\{.*\})', text, re.DOTALL | re.IGNORECASE)
        args = {}
        if m2:
            try:
                args = json.loads(m2.group(1))
            except Exception:
                args = {}
        return {"tool": tool, "args": args}
    return None


def summarize_result(result, max_len: int = 500000) -> str:
    """Last-resort pruning for oversized tool results."""
    if not isinstance(result, str):
        result = str(result)
    if len(result) <= max_len:
        return result
    lines = result.splitlines()
    if len(lines) < 20:
        return result[:max_len] + "..."
    head = "\n".join(lines[:12])
    tail = "\n".join(lines[-12:])
    return (
        f"{head}\n\n"
        f"... [{len(lines) - 24} lines omitted by the runtime guardrail to keep the active context usable.] ...\n"
        f"Use `search_file`, `read_lines`, or the saved artifact path from the tool output for exact follow-up inspection.\n\n"
        f"{tail}"
    )

_BOOTSTRAP_STEP_TYPES = {"setup", "bootstrap", "scaffold", "initialization"}

_PROJECT_INIT_MARKERS = (
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "Pipfile",
    "poetry.lock",
    "Cargo.toml",
    "go.mod",
    "composer.json",
    "mix.exs",
)

_PROJECT_INIT_IGNORED = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    ".next",
    "dist",
    "build",
    "node_modules",
}

_BOOTSTRAP_COMMAND_PATTERNS = (
    "create-next-app",
    "create vite",
    "create-vite",
    "npm create vite",
    "cargo new",
    "django-admin startproject",
    "npm init",
    "pnpm create",
    "yarn create",
)

_BOOTSTRAP_FRAMEWORK_RE = re.compile(
    r"\b(?:next(?:\.js)?|vite|react|vue|angular|svelte|nuxt|remix|astro|django|flask|fastapi|laravel|rails|phoenix|express)\b"
)
_BOOTSTRAP_NEW_PROJECT_RE = re.compile(
    r"\binitialize(?:\s+(?:a|an))?\s+new\s+(?:project|app|application|workspace)\b"
)
_BOOTSTRAP_GENERIC_RE = re.compile(
    r"\b(?:scaffold|bootstrap|create)\b.*\b(?:project root|workspace|project structure|new project)\b"
)


def _is_framework_bootstrap_step(plan_item: dict) -> bool:
    step_type = str(plan_item.get("type", "")).strip().lower()
    if step_type and step_type not in _BOOTSTRAP_STEP_TYPES:
        return False
    task = str(plan_item.get("task", "")).lower()
    goal = str(plan_item.get("goal", "")).lower()
    text = f"{task} {goal}"
    if any(pattern in text for pattern in _BOOTSTRAP_COMMAND_PATTERNS):
        return True
    if _BOOTSTRAP_FRAMEWORK_RE.search(text) and re.search(r"\b(?:scaffold|bootstrap|initialize|create)\b", text):
        return True
    if _BOOTSTRAP_NEW_PROJECT_RE.search(text):
        return True
    return _BOOTSTRAP_GENERIC_RE.search(text) is not None


def _bootstrap_target_dir_from_plan_item(plan_item: dict) -> str:
    file_targets, dir_targets = _step_explicit_write_targets(plan_item)
    if dir_targets:
        return sorted(dir_targets, key=len)[0]
    for target in sorted(file_targets, key=len):
        parent = normalize_rel_path(str(Path(target).parent).replace("\\", "/")).rstrip("/")
        if parent not in {"", "."}:
            return parent
    return ""


def _bootstrap_target_dir_from_tool(tool_name: str, tool_args: dict, plan_item: dict | None = None) -> str:
    if tool_name == "scaffold_next_app":
        target = normalize_rel_path(str(tool_args.get("target_dir") or "")).rstrip("/")
        if target not in {"", "."}:
            return target
    if tool_name == "run_command":
        command_path = normalize_rel_path(str(tool_args.get("path") or ".")).rstrip("/")
        if command_path not in {"", "."}:
            return command_path
    return _bootstrap_target_dir_from_plan_item(plan_item or {})


def _project_is_initialized(workspace: Path, rel_dir: str = "") -> bool:
    project_root = get_project_root(workspace)
    normalized_rel_dir = normalize_rel_path(str(rel_dir or "")).rstrip("/")
    if normalized_rel_dir in {"", "."}:
        target_root = project_root
    else:
        target_root = (project_root / normalized_rel_dir).resolve()
        try:
            target_root.relative_to(project_root.resolve())
        except ValueError:
            return False
    if any((project_root / marker).exists() for marker in _PROJECT_INIT_MARKERS):
        if normalized_rel_dir in {"", "."}:
            return True
    if any((target_root / marker).exists() for marker in _PROJECT_INIT_MARKERS):
        return True
    try:
        for entry in target_root.iterdir():
            if entry.name in _PROJECT_INIT_IGNORED:
                continue
            return True
    except FileNotFoundError:
        return False
    except Exception:
        return False
    return False


def _is_bootstrap_command(tool_name: str, tool_args: dict) -> bool:
    if tool_name == "scaffold_next_app":
        return True
    if tool_name != "run_command":
        return False
    cmd = str(tool_args.get("cmd", "")).lower()
    return any(pattern in cmd for pattern in _BOOTSTRAP_COMMAND_PATTERNS)


def _bootstrap_write_guard_message(plan_item: dict, workspace: Path, tool_name: str, tool_args: dict | None = None) -> str | None:
    if tool_name not in WRITE_TOOLS:
        return None
    if not _is_framework_bootstrap_step(plan_item):
        return None
    bootstrap_target = _bootstrap_target_dir_from_tool(tool_name, tool_args or {}, plan_item)
    if _project_is_initialized(workspace, bootstrap_target):
        return None
    location = f" under `{bootstrap_target}`" if bootstrap_target else ""
    return (
        f"ERROR: This step is a framework initialization step, and the project has not been bootstrapped yet{location}. "
        "Manual file writes are forbidden until initialization succeeds. "
        "Use `scaffold_next_app` or an official CLI bootstrap command via `run_command`, then verify project files exist."
    )


def _is_shadcn_step(plan_item: dict) -> bool:
    task = str(plan_item.get("task", "")).lower()
    return any(pattern in task for pattern in ("npx shadcn", "npx shadcn-ui", "shadcn/ui", "shadcn "))


def _shadcn_postconditions_met(workspace: Path) -> bool:
    project_root = get_project_root(workspace)
    if not (project_root / "components.json").exists():
        return False

    candidate_dirs = [
        project_root / "components" / "ui",
        project_root / "src" / "components" / "ui",
    ]
    candidate_files = [
        project_root / "lib" / "utils.ts",
        project_root / "src" / "lib" / "utils.ts",
    ]
    return any(path.exists() for path in candidate_dirs + candidate_files)


def _shadcn_write_guard_message(plan_item: dict, workspace: Path, tool_name: str) -> str | None:
    if tool_name not in WRITE_TOOLS:
        return None
    if not _is_shadcn_step(plan_item):
        return None
    if _shadcn_postconditions_met(workspace):
        return None
    return (
        "ERROR: This step depends on real shadcn/ui initialization, but the required generated files do not exist yet. "
        "Manual file writes are forbidden until `setup_shadcn` succeeds and creates the support files. "
        "Inspect the workspace, retry the dedicated shadcn setup tool, and verify `components.json` plus `lib/utils.ts` or generated UI files exist first."
    )


def _is_shadcn_command(tool_name: str, tool_args: dict) -> bool:
    if tool_name in {"setup_shadcn", "add_shadcn_components"}:
        return True
    if tool_name != "run_command":
        return False
    cmd = str(tool_args.get("cmd", "")).lower()
    return "shadcn@latest" in cmd or "shadcn-ui@latest" in cmd or re.search(r"\bshadcn\b", cmd) is not None


def _load_ui_contract(workspace: Path) -> dict:
    state = load_agent_state(workspace)
    contract = state.get("ui_contract", {})
    return contract if isinstance(contract, dict) else {}


def _is_shell_or_theme_step(plan_item: dict) -> bool:
    text = f"{plan_item.get('task', '')} {plan_item.get('goal', '')}".lower()
    return any(
        token in text
        for token in (
            "theme foundation",
            "theme parity",
            "theme provider",
            "theme toggle",
            "app shell",
            "layout shell",
            "layout",
            "sidebar",
            "topbar",
            "navbar",
            "navigation",
            "globals.css",
            "polish",
            "responsive audit",
            "visual audit",
        )
    )


def _shared_shell_write_guard_message(plan_item: dict, workspace: Path, tool_name: str, targeted_paths: set[str]) -> str | None:
    if not _tool_writes_scoped_paths(tool_name, targeted_paths):
        return None
    if _is_shell_or_theme_step(plan_item):
        return None
    contract = _load_ui_contract(workspace)
    protected_shell_files = {normalize_rel_path(path) for path in contract.get("protected_shell_files", [])}
    touched_shell_files = sorted(path for path in targeted_paths if normalize_rel_path(path) in protected_shell_files)
    if not touched_shell_files:
        return None
    return (
        "ERROR: This write touches shared shell or theme foundation files, but the current step is not a shell/theme step. "
        f"Protected file(s): {', '.join(touched_shell_files)}. "
        "Use the dedicated shell/theme/polish step to modify these shared UI files so later page work does not collapse the app layout."
    )


_STEP_PATH_TOKEN_RE = re.compile(r'[`"\']?([A-Za-z0-9_.-]+(?:[\\/][A-Za-z0-9_.-]+)+)[`"\']?')


def _extract_step_path_tokens(text: str) -> set[str]:
    if not text:
        return set()
    matches = _STEP_PATH_TOKEN_RE.findall(str(text))
    normalized: set[str] = set()
    for token in matches:
        token = str(token).strip().strip(".,;:)]}>\'\"`")
        token = token.replace("\\", "/")
        token = normalize_rel_path(token)
        if token:
            normalized.add(token.rstrip("/"))
    return normalized


def _step_explicit_write_targets(plan_item: dict) -> tuple[set[str], set[str]]:
    """
    Infer a strict file/directory scope for the current plan step.

    Returns (file_targets, dir_targets). If both are empty, no strict scoping applies.

    This is intentionally conservative: we only scope when the step text contains
    explicit file or directory paths. Otherwise, the Coder is allowed to explore.
    """
    file_targets: set[str] = set()
    dir_targets: set[str] = set()

    explicit_list = plan_item.get("files")
    if isinstance(explicit_list, list):
        for entry in explicit_list:
            token = normalize_rel_path(str(entry).replace("\\", "/")).rstrip("/")
            if not token:
                continue
            if "." in Path(token).name:
                file_targets.add(token)
            else:
                dir_targets.add(token)

    combined_text = f"{plan_item.get('task', '')} {plan_item.get('goal', '')} {plan_item.get('design_notes', '')}"
    for token in _extract_step_path_tokens(combined_text):
        if "." in Path(token).name:
            file_targets.add(token)
        else:
            dir_targets.add(token)

    return file_targets, dir_targets


def _path_in_step_scope(path: str, file_targets: set[str], dir_targets: set[str]) -> bool:
    normalized = normalize_rel_path(path).rstrip("/")
    if not normalized:
        return True
    if is_scratch_path(normalized):
        return True
    # Also allow literal scratch/step-N/... paths (agent may use actual filesystem path
    # instead of the scratch: virtual prefix — treat both as scratch-protected).
    if normalized.startswith("scratch/") or normalized.startswith("scratch\\"):
        return True
    if normalized in file_targets:
        return True
    for prefix in dir_targets:
        if normalized == prefix or normalized.startswith(prefix + "/"):
            return True
    return False


def _tool_writes_scoped_paths(tool_name: str, targeted_paths: set[str]) -> bool:
    return tool_name in WRITE_TOOLS or (tool_name == "run_command" and bool(targeted_paths))


def _format_step_scope_summary(plan_item: dict) -> str:
    file_targets, dir_targets = _step_explicit_write_targets(plan_item)
    if not file_targets and not dir_targets:
        return "project files needed for the current step"
    parts = []
    if file_targets:
        parts.append("files: " + ", ".join(sorted(file_targets)))
    if dir_targets:
        parts.append("dirs: " + ", ".join(sorted(dir_targets)))
    return " | ".join(parts)


def _build_step_boundary_note(workspace: Path, plan_item: dict) -> str:
    scratch_dir = get_step_scratch_dir(workspace, plan_item.get("step"))
    return (
        f"CURRENT STEP: {plan_item.get('task', '')}\n"
        f"ALLOWED WRITE SCOPE: {_format_step_scope_summary(plan_item)}\n"
        f"SCRATCH SPACE: use `scratch:` paths for temporary helpers (active dir: {scratch_dir.name}).\n"
        "BOUNDARY: You may try alternate approaches, scratch helpers, and local tests within this step, "
        "but do not modify files outside the allowed scope or begin later-step work."
    )


def _step_scope_write_guard_message(plan_item: dict, tool_name: str, targeted_paths: set[str]) -> str | None:
    """
    Prevent the Coder from mutating unrelated files in a narrowly-scoped step.

    This is the main guardrail that prevents the "Step says edit file A, but the
    model rewrites files A/B/C in one go" failure mode.
    """
    if not _tool_writes_scoped_paths(tool_name, targeted_paths):
        return None
    if not targeted_paths:
        return None

    file_targets, dir_targets = _step_explicit_write_targets(plan_item)
    if not file_targets and not dir_targets:
        return None

    violations = sorted(path for path in targeted_paths if not _path_in_step_scope(path, file_targets, dir_targets))
    if not violations:
        return None

    allowed_parts = []
    if file_targets:
        allowed_parts.append("files: " + ", ".join(sorted(file_targets)))
    if dir_targets:
        allowed_parts.append("dirs: " + ", ".join(sorted(dir_targets)))

    return (
        "ERROR: Step scope violation. This step is narrowly scoped to specific file(s)/dir(s), "
        f"but you attempted to modify unrelated path(s): {', '.join(violations)}. "
        f"Allowed scope: {' | '.join(allowed_parts)}. "
        "Only perform edits within the allowed scope for this step. "
        "Use `scratch:` for temporary helpers or move this work into the dedicated structural step."
    )


def _extract_verifier_blocking_paths(workspace: Path, feedback_text: str) -> set[str]:
    """
    Extract file paths from verifier feedback so REPAIR MODE can expand step scope
    to include *blocking* files (e.g. lint errors in Hero.tsx).

    Returns normalized relative paths rooted at the resolved workspace project root when possible.
    """
    text = str(feedback_text or "")
    if not text.strip():
        return set()

    project_root = get_project_root(workspace).resolve()
    normalized: set[str] = set()

    # Absolute Windows paths (e.g. D:\repo\...\src\file.tsx)
    for m in re.findall(r"([A-Za-z]:\\\\[^\r\n]+?\.[A-Za-z0-9]+)", text):
        try:
            rel = Path(m).resolve().relative_to(project_root)
            normalized.add(normalize_rel_path(str(rel).replace("\\", "/")))
        except Exception:
            continue

    # Absolute POSIX paths (rare on Windows, but safe)
    for m in re.findall(r"(/[^ \r\n]+?\.[A-Za-z0-9]+)", text):
        try:
            rel = Path(m).resolve().relative_to(project_root)
            normalized.add(normalize_rel_path(str(rel).replace("\\", "/")))
        except Exception:
            continue

    # Relative tokens (src/... or app/...)
    slashed = text.replace("\\", "/")
    for m in re.findall(r"((?:src|app|components|lib)/[^\s\r\n]+?\.[A-Za-z0-9]+)", slashed):
        normalized.add(normalize_rel_path(m))

    return {p for p in normalized if p}


def _filter_repair_paths_to_step_roots(
    workspace: Path,
    plan_item: dict,
    candidate_paths: set[str],
    verification_targets: list[str] | set[str] | tuple[str, ...] | None = None,
) -> set[str]:
    if not candidate_paths:
        return set()

    normalized_candidates = {
        normalize_rel_path(str(candidate).replace("\\", "/")).rstrip("/")
        for candidate in candidate_paths
        if candidate
    }
    normalized_candidates = {candidate for candidate in normalized_candidates if candidate}

    file_targets, dir_targets = _step_explicit_write_targets(plan_item)
    allowed_by_step_scope = {
        candidate for candidate in normalized_candidates if _path_in_step_scope(candidate, file_targets, dir_targets)
    }

    normalized_verification_targets = {
        normalize_rel_path(str(target).replace("\\", "/")).rstrip("/")
        for target in (verification_targets or [])
        if target
    }
    normalized_verification_targets = {
        target for target in normalized_verification_targets if target and not is_scratch_path(target)
    }
    allowed_by_verifier = normalized_candidates & normalized_verification_targets

    if file_targets or dir_targets:
        return allowed_by_step_scope | allowed_by_verifier
    if normalized_verification_targets:
        return allowed_by_verifier
    return normalized_candidates


def _build_workspace_facts(workspace: Path) -> str:
    project_root = get_project_root(workspace)
    app_dir = "src/app" if (project_root / "src" / "app").exists() else "app"
    globals_path = f"{app_dir}/globals.css"
    lib_dir = "src/lib" if (project_root / "src" / "lib").exists() or (project_root / "src").exists() else "lib"
    components_dir = "src/components" if (project_root / "src" / "components").exists() or (project_root / "src").exists() else "components"
    tailwind_configs = [
        name for name in ("tailwind.config.ts", "tailwind.config.js", "tailwind.config.mjs", "tailwind.config.cjs")
        if (project_root / name).exists()
    ]

    tailwind_version = ""
    package_json = project_root / "package.json"
    if package_json.exists():
        try:
            package_data = json.loads(package_json.read_text(encoding="utf-8"))
            tailwind_version = (
                package_data.get("devDependencies", {}).get("tailwindcss")
                or package_data.get("dependencies", {}).get("tailwindcss")
                or ""
            )
        except Exception:
            tailwind_version = ""

    facts = [
        f"- App directory: `{app_dir}`",
        f"- Primary globals stylesheet: `{globals_path}`",
        f"- Component directory should default to `{components_dir}`",
        f"- Lib directory should default to `{lib_dir}`",
    ]
    if tailwind_configs:
        facts.append(f"- Existing Tailwind config file(s): {', '.join(f'`{name}`' for name in tailwind_configs)}")
    else:
        facts.append("- No Tailwind config file exists right now.")
    if tailwind_version:
        facts.append(f"- Installed tailwindcss version: `{tailwind_version}`")
        if str(tailwind_version).lstrip("^~").startswith("4"):
            facts.append("- Tailwind v4 may rely on `@import \"tailwindcss\"` and PostCSS without a `tailwind.config.ts` file. Do not assume that config file exists.")

    return "\n".join(facts)


def _detect_stack_profile(workspace: Path, plan_item: dict) -> str:
    return detect_project_profile(workspace, plan_item).primary_stack



def _extract_tool_paths(workspace: Path, tool_name: str, tool_args: dict) -> set[str]:
    paths: set[str] = set()
    if tool_name in {
        "read_file", "read_lines", "search_file", "write_file", "replace_in_file",
        "patch_file", "delete_file", "delete_directory", "make_directory"
    }:
        path = normalize_rel_path(tool_args.get("path", ""))
        if path:
            paths.add(path)
    elif tool_name in {"move_path", "copy_path"}:
        for key in ("src", "dest"):
            path = normalize_rel_path(tool_args.get(key, ""))
            if path:
                paths.add(path)
    elif tool_name == "multi_read":
        for path in tool_args.get("paths", []) or []:
            normalized = normalize_rel_path(path)
            if normalized:
                paths.add(normalized)
    elif tool_name == "run_command":
        exec_path = normalize_rel_path(tool_args.get("path", ""))
        if exec_path and exec_path not in {"", "."}:
            paths.add(exec_path.rstrip("/"))
        paths.update(extract_command_paths(workspace, str(tool_args.get("cmd", "")), path=str(tool_args.get("path", "."))))
    elif tool_name == "scaffold_next_app":
        target_dir = normalize_rel_path(tool_args.get("target_dir", ""))
        if target_dir and target_dir not in {"", "."}:
            paths.add(target_dir.rstrip("/"))
    return paths


def _format_repair_plan(fix_plan: list[dict]) -> str:
    lines = []
    for idx, item in enumerate(fix_plan, 1):
        task = item.get("task", "Unknown task")
        rationale = item.get("rationale", "")
        line = f"{idx}. {task}"
        if rationale:
            line += f" | Why: {rationale}"
        lines.append(line)
    return "\n".join(lines)


# Fatal patterns that indicate a broken build / runtime.
# Checked against EVERY run_command / wait_for_output result.
_FATAL_BUILD_PATTERNS = [
    "Module not found",
    "Can't resolve",
    "Cannot find module",
    "SyntaxError",
    "Parsing ecmascript source code failed",
    "Export default doesn't exist",
    "Failed to compile",
    "Build failed",
    "error TS",
    "ENOENT",
    "ERR_MODULE_NOT_FOUND",
    "Could not resolve",
    "Unexpected token",
    "is not defined",
]


def _scan_for_runtime_errors(output: str) -> list[str]:
    """
    Scan command output for known fatal build/runtime error patterns.
    Returns a list of matched error snippets (empty list == clean).

    This is intentionally broad — false positives are better than letting
    a broken build slip through to submit_step.
    """
    if not isinstance(output, str):
        return []
    found = []
    for pattern in _FATAL_BUILD_PATTERNS:
        # Case-insensitive scan; only match once per pattern
        if pattern.lower() in output.lower():
            # Grab a short excerpt around the first match for context
            idx = output.lower().find(pattern.lower())
            excerpt = output[max(0, idx - 30): idx + 120].replace("\n", " ").strip()
            found.append(f"[{pattern}] ...{excerpt}...")
    return found


def _log_llm_response(state: dict, workspace: Path, phase: str, step_idx: int,
                      response: str, iteration: int) -> None:
    """Append a preview of the raw LLM response to state and .agent/.ai_logs (no secrets)."""
    preview = response[:400].replace("\n", " ")
    state.setdefault("llm_raw_responses", []).append({
        "phase": phase,
        "step": step_idx,
        "iteration": iteration,
        "preview": preview,
    })
    # Also write to jsonl log
    try:
        logs_dir = get_logs_dir(workspace)
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_entry = json.dumps({
            "phase": phase, "step": step_idx,
            "iteration": iteration, "preview": preview
        })
        with open(logs_dir / "llm_requests.jsonl", "a", encoding="utf-8") as f:
            f.write(log_entry + "\n")
    except Exception:
        pass


def _log_tool_run(workspace: Path, tool_name: str, tool_args: dict, result: str) -> None:
    """Append tool execution record to .agent/.ai_logs/tool_runs.log."""
    try:
        logs_dir = get_logs_dir(workspace)
        logs_dir.mkdir(parents=True, exist_ok=True)
        entry = f"[TOOL] {tool_name} | args={json.dumps(tool_args, separators=(',',':'))[:200]} | result={result[:200]}\n"
        with open(logs_dir / "tool_runs.log", "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Canonical tool signature
# ---------------------------------------------------------------------------

def canonical_tool_signature(tool_name: str, tool_args: dict) -> str:
    """
    Build canonical signature for duplicate-detection.
    Read ops: unique per path + all args.
    Write ops: unique per operation plus the smallest stable identifier for the edit target.
    """
    if tool_name in {"read_file", "list_files", "search_file", "read_lines"}:
        args_copy = dict(tool_args)
        if "path" in args_copy:
            args_copy["path"] = normalize_rel_path(args_copy["path"])
        return f"READ:{tool_name}:{json.dumps(args_copy, sort_keys=True, separators=(',', ':'))}"

    path = normalize_rel_path(tool_args.get("path", ""))

    if tool_name == "replace_in_file":
        target = tool_args.get("target_text", "")
        return f"WRITE:{tool_name}:{path}:{json.dumps(target[:200], separators=(',', ':'))}"

    if tool_name == "patch_file":
        start_line = tool_args.get("start_line", "")
        end_line = tool_args.get("end_line", "")
        return f"WRITE:{tool_name}:{path}:{start_line}:{end_line}"

    if tool_name == "write_file":
        # Full rewrites to the same file are still suspiciously repetitive.
        return f"WRITE:{tool_name}:{path}"

    if tool_name in {"move_path", "copy_path"}:
        src = normalize_rel_path(tool_args.get("src", ""))
        dest = normalize_rel_path(tool_args.get("dest", ""))
        return f"WRITE:{tool_name}:{src}:{dest}"

    if tool_name == "make_directory":
        return f"WRITE:{tool_name}:{path}"

    if tool_name == "run_command":
        command = str(tool_args.get("cmd", "")).strip()
        return f"WRITE:{tool_name}:{path}:{json.dumps(command[:200], separators=(',', ':'))}"

    return f"WRITE:{tool_name}:{path}:{json.dumps(tool_args, sort_keys=True, separators=(',', ':'))[:200]}"


def _build_guard_recovery_note(
    must_reread_files: set[str],
    lint_inspection_targets: set[str],
    inspected_files: set[str],
) -> str:
    """Tell the coder exactly how to recover after guard-triggered states."""
    notes = []
    pending_lint_paths = sorted(path for path in lint_inspection_targets if path not in inspected_files)
    if pending_lint_paths:
        notes.append(
            "MANDATORY NEXT ACTION: Before editing again, inspect these verifier-flagged file(s) "
            f"with `read_file`, `read_lines`, `search_file`, or `multi_read`: {', '.join(pending_lint_paths)}."
        )
    if must_reread_files:
        notes.append(
            "MANDATORY NEXT ACTION: A previous edit target was stale. Your first tool call in the next turn "
            f"must reread these file(s): {', '.join(sorted(must_reread_files))}."
        )
    return "\n".join(notes)


def _build_step_transfer_notes(step_summary: str, coder_notes: str) -> str:
    """Merge persistent step summary memory with transient coder notes."""
    parts = []
    if step_summary:
        parts.append(f"STEP MEMORY SUMMARY:\n{step_summary}")
    if coder_notes:
        parts.append(coder_notes)
    return "\n\n".join(parts)


_PYTHON_FORMAT_ONLY_AUTOFIX_CODES = {
    "E301",
    "E302",
    "E303",
    "E304",
    "E305",
    "E306",
    "W291",
    "W292",
    "W293",
    "W391",
    "W392",
}


def _extract_lint_codes(text: str) -> set[str]:
    return {match.upper() for match in re.findall(r"\b([A-Z]\d{3})\b", str(text or ""))}


def _is_top_level_comment_line(line: str) -> bool:
    stripped = line.lstrip()
    return bool(stripped.startswith("#") and stripped == line)


def _python_anchor_line(lines: list[str], node: ast.AST) -> int:
    candidate_lines = [int(getattr(node, "lineno", 1) or 1)]
    for decorator in getattr(node, "decorator_list", []) or []:
        candidate_lines.append(int(getattr(decorator, "lineno", 1) or 1))

    anchor = min(candidate_lines)
    while anchor > 1 and _is_top_level_comment_line(lines[anchor - 2]):
        anchor -= 1
    return anchor


def _normalize_python_format_only_source(source: str) -> str | None:
    normalized = str(source or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = normalized.split("\n")
    if lines and lines[-1] == "":
        lines = lines[:-1]
    lines = [line.rstrip(" \t") for line in lines]

    parse_source = "\n".join(lines)
    if parse_source:
        parse_source += "\n"
    try:
        module = ast.parse(parse_source or "\n")
    except SyntaxError:
        return None

    top_level_nodes = [node for node in module.body if hasattr(node, "lineno")]
    required_blank_lines: dict[int, int] = {}
    previous_was_block = False

    for index, node in enumerate(top_level_nodes):
        anchor = _python_anchor_line(lines, node)
        is_block = isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        required: int | None = None

        if index == 0:
            required = 0 if is_block else None
        elif is_block or previous_was_block:
            required = 2

        if required is not None:
            required_blank_lines[anchor] = max(required_blank_lines.get(anchor, required), required)
        previous_was_block = is_block

    for anchor in sorted(required_blank_lines, reverse=True):
        required = required_blank_lines[anchor]
        start_idx = max(anchor - 1, 0)
        blank_start = start_idx
        while blank_start > 0 and lines[blank_start - 1].strip() == "":
            blank_start -= 1
        replacement = [""] * required
        if blank_start == 0 and required == 0:
            replacement = []
        lines[blank_start:start_idx] = replacement

    while lines and lines[0].strip() == "":
        lines.pop(0)
    while lines and lines[-1].strip() == "":
        lines.pop()

    return ("\n".join(lines) + "\n") if lines else ""


def _attempt_format_only_autofix(
    workspace: Path,
    step_idx: int,
    verifier_result: dict,
) -> tuple[list[str], list[str]]:
    from nexcode.agent_runtime.editor import apply_tool_call

    if str(verifier_result.get("failure_classification") or "").strip() != "format_only":
        return [], []

    lint_output = str(verifier_result.get("checks", {}).get("lint", {}).get("output") or "")
    lint_codes = _extract_lint_codes(lint_output)
    if lint_codes and not lint_codes.issubset(_PYTHON_FORMAT_ONLY_AUTOFIX_CODES):
        return [], []

    changed_files: list[str] = []
    notes: list[str] = []
    seen: set[str] = set()

    for raw_target in verifier_result.get("verification_targets", []) or []:
        target = normalize_rel_path(str(raw_target or "")).rstrip("/")
        if not target or target in seen or is_scratch_path(target):
            continue
        seen.add(target)

        if Path(target).suffix.lower() != ".py":
            continue

        file_path = resolve_agent_path(workspace, target, step_idx)
        if not file_path.exists() or not file_path.is_file():
            continue

        try:
            original = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        rewritten = _normalize_python_format_only_source(original)
        if rewritten is None or rewritten == original:
            continue

        write_result = apply_tool_call(
            workspace,
            {
                "tool": "write_file",
                "args": {
                    "path": target,
                    "content": rewritten,
                },
            },
            step_idx,
        )
        if write_result.get("status") != "success":
            continue

        for changed in write_result.get("files_changed", []) or [target]:
            normalized_changed = normalize_rel_path(str(changed or "")).rstrip("/")
            if normalized_changed and normalized_changed not in changed_files:
                changed_files.append(normalized_changed)
        notes.append(target)

    return changed_files, notes


def _classify_guard_violation(tool_name: str, message: str) -> str:
    text = str(message or "").lower()
    if "step scope violation" in text:
        return "step_scope"
    if tool_name == "run_command" and (
        "not allowed" in text
        or "relative to the project or scratch" in text
        or "escapes the resolved workspace project root" in text
        or "requires exactly one source" in text
        or "requires at least one relative path" in text
    ):
        return "shell_policy"
    return ""


def _build_guard_escalation_note(plan_item: dict, violation_kind: str) -> str:
    scope_summary = _format_step_scope_summary(plan_item)
    if violation_kind == "step_scope":
        return (
            "ACTIVE GUARD RECOVERY:\n"
            f"- Stay inside this write scope: {scope_summary}\n"
            "- If you need a temporary helper, place it under `scratch:`.\n"
            "- Do not perform route moves, page creation, or other later-step work until this step is submitted."
        )
    if violation_kind == "shell_policy":
        return (
            "ACTIVE GUARD RECOVERY:\n"
            "- For repo refactors, prefer `make_directory`, `move_path`, and `copy_path` over unsupported shell tricks.\n"
            "- Keep shell filesystem commands relative to the current project or `scratch:` directory only.\n"
            f"- Stay inside this write scope: {scope_summary}"
        )
    return ""


def _record_guard_violation(
    state: dict,
    plan_item: dict,
    step_idx: int,
    violation_kind: str,
    message: str,
    guard_failure_counts: dict[str, int],
) -> tuple[int, str]:
    if not violation_kind:
        return 0, ""
    count = guard_failure_counts.get(violation_kind, 0) + 1
    guard_failure_counts[violation_kind] = count
    note = _build_guard_escalation_note(plan_item, violation_kind)
    if note:
        state[f"coder_notes_{step_idx}"] = note
    if count >= 2:
        return count, (
            f"Repeated guard failure ({violation_kind}) while implementing '{plan_item.get('task', '')}'. "
            f"Latest error: {message}"
        )
    return count, ""


def _format_usage_brief(usage: UsageData) -> str:
    return (
        f"input={usage.input_tokens:,} | "
        f"output={usage.output_tokens:,} | "
        f"reasoning={usage.reasoning_tokens:,} | "
        f"total={usage.total_tokens:,} | "
        f"cost=${usage.cumulative_cost:.6f}"
    )


def _auto_inspect_paths(
    workspace: Path,
    paths: list[str],
    inspected_files: set[str],
    lint_inspection_targets: set[str],
    must_reread_files: set[str],
) -> str:
    """Refresh file contents automatically after a guard fires so the next turn has real context."""
    normalized = sorted({normalize_rel_path(path) for path in paths if path})
    if not normalized:
        return ""

    load_all_tools()
    tool_func = get_tool("multi_read")
    result = tool_func(workspace, paths=normalized)
    pruned = summarize_result(result)
    _log_tool_run(workspace, "multi_read", {"paths": normalized}, pruned)

    for path in normalized:
        inspected_files.add(path)
        lint_inspection_targets.discard(path)
        must_reread_files.discard(path)
    return summarize_tool_observation("multi_read", pruned)


# ---------------------------------------------------------------------------
# Allowed tool sets
# ---------------------------------------------------------------------------

CODER_ALLOWED_TOOLS = {
    "write_file", "replace_in_file", "read_file",
    "list_files", "search_file", "read_lines", "patch_file",
    "delete_file", "delete_directory", "make_directory", "move_path", "copy_path",
    "run_command", "multi_read", "grep_search",
    "submit_step", "wait_for_output", "stop_command", "scaffold_next_app",
    "setup_shadcn", "add_shadcn_components", "command_status", "send_command_input"
}
REVIEWER_ALLOWED_TOOLS = {
    "read_file", "list_files", "run_command", "run_tests",
    "replace_in_file", "patch_file"
}

WRITE_TOOLS = {
    "write_file", "replace_in_file", "patch_file", "delete_file", "delete_directory",
    "make_directory", "move_path", "copy_path"
}

# ---------------------------------------------------------------------------
# System Prompts
# ---------------------------------------------------------------------------

CODER_SYSTEM_PROMPT = """
# Coder System Prompt

You are an **expert autonomous coding agent** implementing the current step of an implementation plan.

Your responsibility is **only to read, write, or modify code** to complete the provided task.

You must **not manage workflow, approvals, or planning**.  
Your job is **pure code implementation**.

---

# Operating Rules

1. Execute **ONLY the current step** of the plan.
2. You **must call ONE OR MORE tools per response** using the `"calls"` array.
3. **SPEED IS CRITICAL — BATCH EVERYTHING:** Write ALL files for this step in a SINGLE response. Do NOT read a file first and then write it in a second turn unless you need to modify an EXISTING file. For new files, emit all `write_file` calls together in one `"calls"` array. Each extra turn costs 30–60 seconds of latency.
     3.1. **Direct Execution:** Prefer running target files directly (e.g., `python file.py` or `node file.js`) in your verification turns instead of creating unnecessary scratch "wrapper" scripts.
     3.2. **Interactive Execution (Antigravity Parity):**
        - For interactive scripts (migrations, CLI prompts), `run_command` will return a `command_id` if it doesn't finish within 5s.
        - **STRICT MANDATE:** You are **FORBIDDEN** from using shell pipes (e.g., `echo "input" | python script.py`) for testing interactive prompts, even if you saw the Investigator use them. They are fragile and not Antigravity-parity.
        - Instead, use the `run_command` + `command_status` + `send_command_input` workflow to ensure full terminal interaction.
        - Use `command_status` to view the latest output and check if the process is waiting for input.
        - Use `send_command_input(command_id, input_string="your_input\n")` to answer prompts or interact with a live TTY.
     3.3. **Investigation Isolation (CRITICAL):**
        - The Investigation phase may use "hacks" (like shell pipes or redirects) to survey the codebase.
        - **IGNORE THESE PATTERNS.** You are the Coder. Your implementation and verification MUST follow the structured tool rules (3.1 and 3.2 above).
        - Never copy-paste `run_command` strings from the Investigator if they contain `|`, `>`, or `>>`.
4. Your response **must be a single valid JSON object containing a "thinking" string and a "calls" array**.
5. **Never include explanations, markdown formatting, comments, or conversational text.**
6. Provide **syntactically correct and complete code**. Never use placeholders like `TODO`, `lorem ipsum`, or `[insert here]`.
6. **Robust File Reading:**  
   - For large files, default to `search_file` plus `read_lines` so you inspect exact ranges before editing.
   - `multi_read` can batch relevant excerpts from multiple files when you already know the likely surfaces.
   - `read_file` returns files with line numbers prefixed (example: `1 | import os`).  
   - Do **NOT** include the line number prefix (e.g. `1 | `) in:
     - `target_text` for `replace_in_file`
     - `write_file` content
7. **CRITICAL PREFERENCE:**  
   Use `replace_in_file` whenever possible instead of `patch_file`.  
   This ensures minimal and precise edits.
8. **Fallback Strategy:**  
   If multiple edit attempts fail (for example, patch mismatches), fall back to rewriting the file using `write_file`.
8.1. **Scoped Retries & Pivoting:**  
    You may try alternate implementations, use `scratch:` temporary helpers, and run local smoke tests within the current step.  
    Do not start later-step work or modify files outside the current step scope. If an approach is clearly failing, PIVOT to a new one instead of repeating the same mistake.
8.2. **Background Processes:**
    - For long-running servers, you can leave them in the background while you perform other tasks.
9. **Content Enforcement:**  
   Always use the exact information provided in **CONTENT DATA**.  
   Do **not invent data or summarize it.**
10. **Design Compliance:**
    Follow the **DESIGN SPEC** for layout, component structure, and styling instructions. If the DESIGN SPEC includes a CSS Design System (custom properties, typography, color tokens), you MUST implement it exactly as specified.
11. **UI Quality Standards for React/Next Projects (CRITICAL):**
    When building React, Next.js, or other component-based web interfaces, functional-but-generic output is NEVER acceptable. You MUST meet ALL of the following:
    - **Theme contract:** Implement semantic theme tokens in the real globals CSS file and keep light/dark mode visually distinct and readable.
    - **Shared shell:** Multi-page apps must share a coherent shell with navigation, header rhythm, spacing system, and content framing.
    - **Visual hierarchy:** Every major page should have a heading, supporting copy, primary action area, and clearly separated content regions.
    - **Task-fit styling:** Choose layout patterns, density, and visual treatment based on the actual product. Do not force one repeated dashboard style across unrelated tasks.
    - **Surface depth:** Avoid a single flat background with identical surfaces. Use layered surfaces, gradients, borders, shadows or blur only when they fit the chosen direction.
    - **Complex surface theming:** Any data-heavy or interactive surfaces present in the task must inherit the active theme and remain legible in both modes.
    - **Responsive polish:** Layouts must remain intentional on desktop and mobile. Avoid washed-out light mode, muddy dark mode, and default-looking third-party component styling.
    - **Theme parity:** If the app includes settings, theming, or a theme switch, ensure the provider, toggle wiring, and both mode palettes are implemented instead of styling only one mode.
12. **UI Quality Standards for Non-React Projects (CRITICAL):**
    When writing plain HTML, Flask/Jinja templates, Django templates, Vue/Svelte files, or vanilla CSS — generic, unstyled output is NEVER acceptable. You MUST meet ALL of the following minimum standards:
    - **CSS Variables:** Define all colors, spacing, and typography as CSS custom properties in `:root {}`. Never hardcode hex values or pixel values for spacing inline.
    - **Google Fonts:** Always include a `<link>` tag in `<head>` to load a modern web font from the DESIGN SPEC (Inter, Plus Jakarta Sans, DM Sans, or Outfit). Never use default browser fonts.
    - **CSS Reset:** Include `*, *::before, *::after { box-sizing: border-box; }` and reset `margin: 0; padding: 0` on body.
    - **Typography Scale:** Use rem-based font sizes from the DESIGN SPEC. Body text must be at least 1rem (16px). Headings must use a clear visual hierarchy.
    - **Spacing System:** Use the spacing variables from the DESIGN SPEC for all margins, padding, and gaps. Never use arbitrary pixel values like `padding: 7px`.
    - **Color System:** Background must not be plain white (`#fff` or `white`) unless the DESIGN SPEC explicitly calls for it. Use surface color tokens for depth.
    - **Layout:** Never use float-based layouts. Use CSS Grid or Flexbox. All layouts must be responsive with mobile-first `@media` breakpoints.
    - **Component Polish:** Every button, link, and input must have a `:hover` and `:focus` state. Buttons must have `border-radius`, `padding`, and a hover transition. Cards must have `border-radius`, `box_shadow`, and proper padding.
    - **No CSS Color Keywords:** Never use `background: blue`, `color: red`, or other bare CSS keyword colors. Always use CSS variables or specific hex values from the DESIGN SPEC.
    - **CSS File Separation:** For plain HTML projects, always write styles in a separate `style.css` file and `<link>` it. Never embed more than 5 lines in a `<style>` tag inside HTML.
13. **SUBMIT STEP (CRITICAL):**  
    When you have fully completed the task and verified your changes, you MUST explicitly call the `submit_step` tool. The system will NOT advance to verification until you submit. **WARNING:** Do NOT call `submit_step` if the previous tool logs contain an error.
13.1. **Scratch Space (CRITICAL):**
    For ANY temporary file (test CSV, fixture, helper script), you MUST use the `scratch:` prefix — e.g. `scratch:sample.csv`, `scratch:helpers/test.js`. Do NOT use literal paths like `scratch/step-2/file.csv` or `tmp/file.csv`. The `scratch:` prefix maps to a per-step isolated directory and is ALWAYS allowed regardless of step scope. Violation of this rule causes a scope guard error.
14. **Project Scaffolding (CRITICAL):**
    The runtime provides a dedicated workspace `project/` root for application code. Treat that directory as the app root by default.
    If the user explicitly asks for a separate app or nested structure, you MAY scaffold into a deliberate subdirectory under the project root instead of the root itself.
    If the project requires Next.js and the chosen target directory is empty, you MUST use `scaffold_next_app` to bootstrap the app there. For other frameworks, verify the chosen target directory is empty with `list_files` before using the official CLI. Do NOT manually write framework boilerplate from scratch.
    **FORBIDDEN:** If scaffolding fails, do NOT "fake" initialization by manually writing `package.json`, `tsconfig.json`, framework config files, or starter app files during the bootstrap step. Retry or diagnose initialization instead.
15. **Error Sensitivity & Workspace Consistency (CRITICAL):**
    - If a tool call returns an error (e.g. exit code 1, "Command not found", or "File not found"), you MUST analyze and FIX the issue in your next iteration. 
    - **MANDATORY**: If you are running a dev server (e.g., `npm run dev`), you MUST check its background output for "Error", "Module not found", or "Syntax Error". Do NOT ignore these errors. If a module is missing, check `package.json` and install it. Never ignore a tool error or a runtime build error by submitting the step.
    - **Project root**: Assume `path="."` refers to the resolved workspace project root. Only use other `path` values when the user explicitly requested nested folders or when you are operating on a deliberate subdirectory inside the project.
    - **Scaffold reality check**: Read the actual file tree before editing framework files. If `src/app` exists, edit `src/app/*` rather than `app/*`. If no `tailwind.config.*` file exists, do not assume one should exist. Tailwind v4 projects often only use `postcss.config.*` plus CSS imports.
16. **Background Process Safety (CRITICAL):**
    Before deleting a directory or installing dependencies (`npm install`, `pnpm install`), you MUST terminate any background processes (like `npm run dev`) that might be using those files. Use `send_command_input(command_id, terminate=True)` or `stop_command(pid)` if you have a running process ID. Failure to stop processes will lead to "Access Denied" or "File in use" errors on Windows.
16. **Pre-Submit Checklist (MANDATORY for JS/TS projects — check BEFORE calling submit_step):**
    You MUST mentally verify ALL of the following before calling `submit_step`. If ANY item fails, fix it first:
    - [ ] All imports resolve — no "Module not found" or "Can't resolve" in output.
    - [ ] All JSX/TSX tags are properly closed (no unclosed `<div>`, `<li>`, `<motion.div>` etc.).
    - [ ] All exported components use `export default` OR matching named exports — no "Export default doesn't exist".
    - [ ] No TypeScript `error TS` remaining in build output.
    - [ ] Shared theme tokens and shell styling still apply after this step; no touched page is left visually unthemed.
    - [ ] If the product includes dark/light mode, both modes remain legible for the files touched in this step.
    - [ ] `run_command` / `wait_for_output` output was checked and contains NONE of the following fatal strings:
          `"Module not found"`, `"SyntaxError"`, `"Parsing ecmascript"`, `"Failed to compile"`, `"Build failed"`, `"error TS"`, `"Export default doesn't exist"`.

    **FORBIDDEN:** If `run_command` or `wait_for_output` output in the CURRENT step contains ANY of the strings above, you are EXPLICITLY FORBIDDEN from calling `submit_step`. You MUST fix all errors first.

---

# Reliability & Troubleshooting Guides

## 1. Dependency Conflicts (Node.js)
If `npm install` fails with **ERESOLVE** (peer dependency conflicts), especially with React 19:
- Retry with `npm install --legacy-peer-deps`.
- If missing specific packages like `tailwindcss`, `sonner`, `next-themes`, or `class-variance-authority`, ensure they are present in `package.json` or install them explicitly.

## 2. Verification via Background Server (CRITICAL)
For web projects (Next.js, Vite, etc.), before calling `submit_step`, you MUST:
1. Run `npm run dev` in background: `run_command(cmd="npm run dev", background=True)`.
2. Wait for verification: `wait_for_output(match_string="localhost:3000", timeout=60)`. 
   - **BRITTLE MATCH WARNING:** Avoid using full lines with exact spacing like `"Local:    http://localhost:3000"`. Use short, unique substrings like `"localhost:3000"` or `"Ready"` instead.
3. If errors like "Can't resolve", "Module not found", or "CssSyntaxError" appear in the output, you MUST fix them before submitting.

## 3. Directory Cleanup (Node.js)
- NEVER use `npx rimraf` or `rm -rf` for large folders like `node_modules` if a native tool is available.
- ALWAYS use the `delete_directory` tool for removing folders. It is significantly faster (uses native `shutil.rmtree`) and safer than shell commands.

## 3. CSS & JSX Best Practices
- **CSS Import Order:** All `@import` rules (e.g., Google Fonts, Tailwind) MUST come at the top of the file, before any other rules.
- **Tailwind Config:** Use the Tailwind files that actually exist in the scaffolded project. In Tailwind v4, `tailwind.config.js/ts` may be absent; prefer `@import "tailwindcss";` in the real globals CSS file and only create a config file when the toolchain truly requires it.
- **shadcn/ui:** Prefer `npx shadcn@latest ...` for new projects. Before submitting a shadcn setup step, verify that `components.json` and generated UI files or `lib/utils.ts` exist.
- **Closed JSX Tags:** Ensure all JSX components and tags are properly closed (e.g., `</li>` after items). Failure to close tags causes fatal parsing errors.

---

# Available Tools

## run_command
Run a shell command safely in the workspace.
WARNING: ONLY safe commands for the detected project stack are allowed. This includes the core filesystem/git tools plus stack-appropriate CLIs such as npm/pnpm/yarn/node, python/pytest, cargo, go, dotnet, mvn/gradle, php/composer, ruby/bundle, mix, and swift when the workspace indicates that stack.

run_command(cmd: str, path: str = ".", background: bool = False)

- The **path** argument specifies the working directory relative to the resolved workspace project root.
- If starting a long-running process (like `npm run dev`), use `background=True` so you don't block.

---

## scaffold_next_app
Bootstrap a Next.js app into the resolved workspace project root or a deliberate subdirectory inside it.

scaffold_next_app(app_name: str = "app", use_tailwind: bool = True, use_src_dir: bool = True, package_manager: str = "npm", target_dir: str | None = None)

- Use this for a brand new Next.js target directory instead of inventing framework boilerplate by hand.
- Set `target_dir` when the user explicitly wants a separate app under a subfolder.
- This tool verifies that `package.json` was created before reporting success.

---

## setup_shadcn
Initialize shadcn/ui in the resolved workspace project root using a dedicated non-interactive tool.

setup_shadcn(template: str = "next", base: str = "radix", css_variables: bool = True, force: bool = False, preset: str = "")

- Use this instead of raw `run_command` for `shadcn init`.
- This tool verifies that `components.json` and generated support files actually exist.

---

## add_shadcn_components
Add one or more shadcn/ui components using a dedicated tool.

add_shadcn_components(components: list[str])

- Use this instead of raw `run_command` for `shadcn add ...`.
- This tool validates that requested components were generated.

---

## wait_for_output
Wait for a specific string to appear in the output of a background process.

wait_for_output(match_string: str, timeout: int = 60, pid: int = None)

---
 
## stop_command
Terminates a background process by its PID. Use this before deleting folders or re-installing dependencies if a dev server is running.

stop_command(pid: int)

---

## command_status
Check the status and recent output of a background process.

command_status(command_id: str, line_count: int = 50)

---

## send_command_input
Send standard input to a running command (like "y\n") or terminate it.

send_command_input(command_id: str, input_string: str = None, terminate: bool = False)

---


## delete_file
Delete a file entirely.
WARNING: Only use this if a file is completely wrong or named incorrectly and needs to be wiped from the workspace.

delete_file(path: str)

---

## delete_directory
Recursively delete a directory and all its contents.
WARNING: Use this with caution for cleaning up folders like `node_modules` or `dist`.

delete_directory(path: str)

---

## write_file
Create or overwrite a file with full content.

write_file(path: str, content: str)

Example showing how to write multiple files at once:

{
  "thinking": "I need to initialize the html and css files.",
  "calls": [
    {
      "tool": "write_file",
      "args": {
        "path": "index.html",
        "content": "<!DOCTYPE html>\n<html>\n<head></head>\n<body></body>\n</html>"
      }
    },
    {
      "tool": "write_file",
      "args": {
        "path": "style.css",
        "content": "body { margin: 0; }"
      }
    }
  ]
}

---

## make_directory
Create a directory, including any missing parent directories.

make_directory(path: str)

---

## move_path
Move a file or directory inside the project or `scratch:` space.

move_path(src: str, dest: str, overwrite: bool = False)

---

## copy_path
Copy a file or directory inside the project or `scratch:` space.

copy_path(src: str, dest: str, overwrite: bool = False)

---

## replace_in_file
Replace exact text inside an existing file.

replace_in_file(path: str, target_text: str, replacement_text: str)

---

## read_file
Read the full contents of a file.

read_file(path: str)

---

## list_files
List files inside a directory.

list_files(path: str)

---

## search_file
Search for a string inside a file.

search_file(path: str, query: str)

---

## read_lines
Read a specific line range from a file.

read_lines(path: str, start_line: int, end_line: int)

---

## patch_file
Replace a specific line range in a file.

patch_file(path: str, start_line: int, end_line: int, new_content: str)

---

## multi_read
Read multiple files at once. For large files this returns relevant excerpt windows instead of blind truncation. (max 10 paths)

multi_read(paths: list[str], focus_terms: list[str] = None, context_lines: int = 30, max_windows: int = 8)

---

## grep_search
Search for a regex pattern globally across the codebase.

grep_search(query: str, include_patterns: list[str] = None)

---

## search_workspace
Search the workspace index for files relevant to a query. Returns ranked file paths with exports, line count, and summary.

Use this tool **before reading files** when the task is broad or exploratory (e.g. "review my project for flaws", "find where auth is handled", "what files relate to payments"). The LLM decides the search terms — no keyword lists required.

- If files score above zero: returns the ranked, focused file list.
- If nothing scores (very broad/vague query): returns the full index map so you can self-orient and pick what to read next.

search_workspace(query: str, top_k: int = 15)

---

## submit_step
Call this tool when you have fully completed the current step and verified your code successfully.
**WARNING:** Never call this tool if a previous tool in the same step returned an error that has not been resolved.

submit_step()

---

# JSON OUTPUT REQUIREMENT (CRITICAL)

Your response **must contain ONLY ONE JSON object**.

Do NOT include:

- explanations
- markdown formatting
- code blocks
- text before or after the JSON
- comments
- multiple objects

Your response must start with `{` and end with `}`. It must contain `"thinking"` and `"calls"`.

Incorrect example (chatting before JSON):

Sure, here are the files:

{
  "thinking": "Setting up...",
  "calls": [
    {
      "tool": "create_file",
      "args": {
        "path": "app.py"
      }
    }
  ]
}

Correct example:

{
  "thinking": "The step asks to create the boilerplate HTML, and then patch the auth.py file. I will do both now.",
  "calls": [
    {
      "tool": "write_file",
      "args": {
        "path": "index.html",
        "content": "<html></html>"
      }
    },
    {
      "tool": "patch_file",
      "args": {
        "path": "auth.py",
        "start_line": 10,
        "end_line": 12,
        "new_content": "def login():\n    pass"
      }
    }
  ]
}

---

# Important Reminder

You are **NOT a chat assistant**.

You are a **coding execution agent**.

Your entire response must be **a single JSON tool call**.
"""


def _build_coder_system_prompt(workspace: Path, plan_item: dict) -> str:
    profile = detect_project_profile(workspace, plan_item)
    stack = profile.primary_stack
    stack_rules = {
        "nextjs": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Next.js App Router.\n"
            "- Follow the scaffolded Next.js layout that actually exists in the workspace.\n"
            "- Prefer `scaffold_next_app`, `setup_shadcn`, and `add_shadcn_components` over raw shell guesses.\n"
            "- For route moves or structural refactors, prefer `move_path`, `copy_path`, and `make_directory`, and use `scratch:` only for temporary helpers.\n"
            "- Treat theme foundation, shared shell quality, and page composition as real deliverables, not optional polish.\n"
            "- If dark/light mode or settings exist, ensure semantic theme tokens, provider wiring, and both readable palettes are implemented.\n"
            "- For lint/build failures, inspect the exact file before editing and rerun the failing command after changes."
        ),
        "react": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: React web app.\n"
            "- Respect the real project structure and config files that already exist.\n"
            "- Do not invent framework files that are absent without verifying the toolchain requires them."
        ),
        "node": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Node.js app.\n"
            "- Use the package manager and scripts that already exist in the repository.\n"
            "- Prefer script-driven verification over inventing ad hoc commands."
        ),
        "python-web": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Python web framework.\n"
            "- Follow the framework conventions present in the repository.\n"
            "- Prefer deterministic verification with tests and syntax checks after edits."
        ),
        "python": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Python.\n"
            "- Prefer surgical edits and rerun relevant tests or compile checks after changes."
        ),
        "rust": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Rust.\n"
            "- Respect the crate layout and Cargo manifests already present.\n"
            "- Prefer `cargo test` and `cargo check` style verification after code changes."
        ),
        "go": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Go.\n"
            "- Follow the existing module and package boundaries in `go.mod` and the repo layout.\n"
            "- Prefer `go test ./...` and `go build ./...` for verification when relevant."
        ),
        "dotnet": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: .NET.\n"
            "- Respect the existing solution and project files instead of inventing a new layout.\n"
            "- Prefer `dotnet test` and `dotnet build` when verification is needed."
        ),
        "java-gradle": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Gradle JVM.\n"
            "- Use the existing Gradle wrapper or Gradle build files already in the repository.\n"
            "- Prefer wrapper-driven verification instead of ad hoc compilation commands."
        ),
        "java-maven": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Maven JVM.\n"
            "- Use the existing Maven wrapper or `pom.xml` lifecycle already in the repository.\n"
            "- Prefer Maven lifecycle commands for build and test verification."
        ),
        "php": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: PHP.\n"
            "- Follow the existing Composer and framework conventions present in the workspace.\n"
            "- Prefer framework or Composer test commands over inventing new tooling."
        ),
        "ruby": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Ruby.\n"
            "- Respect the existing Bundler, Rake, Rails, or RSpec structure in the repository.\n"
            "- Use the established test and task entry points already present."
        ),
        "elixir": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Elixir.\n"
            "- Follow the Mix project structure and favor `mix test` or `mix compile` verification.\n"
            "- Keep changes aligned with the app and lib layout already present."
        ),
        "swift": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Swift Package Manager.\n"
            "- Respect the existing package manifest and module layout.\n"
            "- Prefer `swift test` and `swift build` for verification."
        ),
        "static-web": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: Static web app.\n"
            "- Infer behavior from the real HTML, CSS, and JS assets that already exist.\n"
            "- Keep interactions progressive and avoid inventing framework structure."
        ),
        "generic": (
            "\n\n# Current Stack Focus\n"
            "Detected stack: generic or mixed.\n"
            "- Infer behavior from the actual files in the workspace rather than assuming a framework layout.\n"
            "- Use `scratch:` for temporary helpers and keep permanent edits inside the current step scope."
        ),
    }
    prompt = CODER_SYSTEM_PROMPT + stack_rules.get(stack, stack_rules["generic"])
    
    prompt += (
        "\n\n# CRITICAL RULES (IGNORE AT YOUR OWN PERIL)\n"
        "- NEVER use UNIX shell commands like `head`, `tail`, `wc`, `cat`, or `grep` via `run_command`. "
        "Use your native tools (`read_file`, `read_lines`, `search_file`, `grep_search`) instead.\n"
        "- If you discover that a file ALREADY matches the target state for this step "
        "(e.g., changes were already applied in a previous interrupted run), DO NOT re-apply your edits blindly. "
        "Call `submit_step` immediately."
    )

    additional = [label for label in profile.stack_ids[1:] if label != stack]
    if additional:
        prompt += "\n- Additional detected tooling: " + ", ".join(additional) + "."
    return prompt


# ---------------------------------------------------------------------------
# Main execution loop
# ---------------------------------------------------------------------------

def execute_plan(plan: list, workspace: Path, verbose: bool = False, user_message: str = ""):
    """
    Iterate over the plan using a Multi-Agent (Coder → Editor → Reviewer) Architecture.
    """
    load_all_tools()
    from nexcode.agent_runtime.tool_registry import TOOLS
    from nexcode.agent_runtime.editor import apply_tool_call, acquire_lock, release_lock

    agent_cfg = load_agent_config(workspace)
    acc = load_access()
    max_steps = agent_cfg["max_steps"]
    max_rejects = agent_cfg.get("max_rejects", 5)
    max_step_attempts = agent_cfg.get("max_step_attempts", 12)
    coder_context_summary_threshold = agent_cfg.get("coder_context_summary_threshold", 250000)
    model = agent_cfg["model"]

    # Acquire workspace lock
    if not acquire_lock(workspace):
        console.print(ui_status("Error", "Another agent process is already running in this workspace.", tone="error"))
        console.print(ui_detail("Recovery", "If this lock is stale, delete `.agent/.ai_lock` and retry."))
        return

    try:
        _execute_plan_inner(
            plan, workspace, verbose, acc, model,
            max_steps, max_rejects, max_step_attempts, coder_context_summary_threshold, TOOLS,
            user_message=user_message
        )
    finally:
        release_lock(workspace)


def _execute_plan_inner(plan, workspace, verbose, acc, model,
                        max_steps, max_rejects, max_step_attempts, coder_context_summary_threshold, TOOLS,
                        user_message=""):
    """Core execution loop — separated so lock is always released in execute_plan."""
    from nexcode.agent_runtime.editor import apply_tool_call
    from nexcode.agent_runtime.verifier import run_verification
    from nexcode.agent_runtime.repair import run_repair, _write_hlu_report

    state = load_agent_state(workspace)

    if not state.get("architecture_memory") and plan and not state.get("is_fix"):
        from nexcode.agent_runtime.designer import generate_design
        state["architecture_memory"] = generate_design(
            state.get("original_prompt", ""), plan, workspace, verbose
        )

    step_count = 0
    global_iterations = 0   # counts meaningful file-write operations
    plan_total = len(plan)

    for plan_item in plan:
        # Reload state from disk to ensure we have the latest completed_steps (especially in multi-turn REPL)
        state = load_agent_state(workspace)
        
        step_idx = plan_item["step"]
        task_desc = plan_item["task"]

        if step_idx in state["completed_steps"]:
            continue

        console.print("")
        console.print(ui_step(step_idx, plan_total, task_desc))
        state["current_step"] = step_idx
        save_agent_state(workspace, state)
        cleanup_step_scratch_dir(workspace, step_idx)

        step_changes = {}   # filename -> diff_text
        step_summary = ""
        step_resolved = False
        step_iterations = 0
        step_max_iterations = 5 

        state["reject_count"] = state.get("reject_count", 0)
        # Reset reject count per step
        state["reject_count"] = 0
        coder_history = state.get(f"coder_history_{step_idx}", [])
        reviewer_history = state.get(f"reviewer_history_{step_idx}", [])
        step_usage = UsageData.from_dict(state.get(f"step_usage_{step_idx}", {}))

        # Context compression: show relevant plan window
        plan_preview = []
        for p in plan:
            if p["step"] == step_idx:
                plan_preview.append(f"-> STEP {p['step']}: {p['task']} (CURRENT)")
            elif p["step"] in state["completed_steps"][-2:]:
                plan_preview.append(f"   Step {p['step']}: {p['task']} (DONE)")
            elif p["step"] > step_idx and p["step"] <= step_idx + 4:
                plan_preview.append(f"   Step {p['step']}: {p['task']} (PENDING)")

        repair_attempt = 0  # Track repair attempts per step
        announced_repair_scope_files: set[str] = set()

        while not step_resolved and global_iterations < max_steps and step_iterations < step_max_iterations:
            step_iterations += 1

            # HLU escalation if too many rejections
            if state.get("reject_count", 0) >= max_rejects:
                _write_hlu_report(workspace, step_idx, coder_history,
                                  diagnostics="Max rejections exceeded.")
                console.print(ui_status("Escalation", f"Step {step_idx} was rejected {max_rejects}+ times", tone="error"))
                console.print(ui_status("Report", "See .agent/.ai_logs/hlu_report.md for details. Pausing the agent.", tone="error"))
                state["status"] = "waiting_human"
                save_agent_state(workspace, state)
                return

            # -----------------------------------------------------------------
            # 1. CODER / FIXER PHASE
            # -----------------------------------------------------------------
            if verbose:
                agent_label = "Fixer" if state.get("is_fix") else "Coder"
                console.print(ui_status("Phase", f"{agent_label} phase for step {step_idx}"))
            coder_done = False
            last_coder_call = None
            consecutive_duplicates = 0
            step_attempts = 0
            writes_this_phase = 0      # counts successful file writes this coder phase
            reads_after_write = 0      # verification reads after a write
            read_only_turns_in_phase = 0 # tracks consecutive turns with no writes
            last_write_files = []      # track files written in this coder phase
            last_usage = None          # track last API usage for precise token management
            guard_failure_counts: dict[str, int] = {}
            force_repair_diagnostics = ""
            must_reread_files = set(state.get(f"must_reread_files_{step_idx}", []))
            lint_inspection_targets = set(state.get(f"lint_targets_{step_idx}", []))
            inspected_files = set()

            # How many distinct files does this step expect to write?
            # Use plan_item["files"] if present, else default 1.
            expected_writes = max(1, len([f for f in plan_item.get("files", []) if f]))

            while not coder_done and step_attempts < max_step_attempts:
                step_attempts += 1

                from nexcode.agent_runtime.context import build_context
                from nexcode.agent_runtime.token_utils import estimate_tokens

                history_est = estimate_tokens("\n".join(coder_history))
                # Build context from focused files plus a capped workspace summary.
                inst_mem = state.get("instruction_memory", state.get("original_prompt", ""))
                arch_mem = state.get("architecture_memory", "")
                design_mem_json = json.dumps(state.get("design_memory", {}), indent=2)
                design_spec = f"{arch_mem}\n\n---\nStructured Design Memory:\n{design_mem_json}" if arch_mem else design_mem_json
                content_mem = state.get(
                    "compressed_content_memory",
                    json.dumps(state.get("content_memory", {}), indent=2)
                )
                step_summary = state.get(f"coder_summary_{step_idx}", "")
                coder_notes = _build_step_transfer_notes(
                    step_summary,
                    _build_step_boundary_note(workspace, plan_item)
                    + ("\n\n" + state.get(f"coder_notes_{step_idx}", "") if state.get(f"coder_notes_{step_idx}", "") else ""),
                )

                context_block, context_meta = build_context(
                    workspace, task_desc, plan_preview, coder_history,
                    instruction_memory=inst_mem,
                    user_message=user_message,
                    design_memory=design_spec,
                    content_memory=content_mem,
                    coder_notes=coder_notes,
                    rationale=plan_item.get("rationale", ""),
                    forensics=state.get("investigation_report", ""),
                    preferred_files=plan_item.get("files", []),
                    report_checked_files=state.get("investigation_checked_files", []),
                    recent_files=last_write_files + sorted(inspected_files),
                    verifier_feedback=state.get(f"last_rejection_feedback_{step_idx}", ""),
                    return_metadata=True,
                )
                workspace_facts = _build_workspace_facts(workspace)
                context_block = f"{context_block}\n\nCURRENT WORKSPACE FACTS:\n{workspace_facts}"
                prompt_size_est = context_meta.get("total_tokens", 0) + estimate_tokens(workspace_facts)
                if verbose:
                    console.print(
                        ui_detail(
                            "Prompt",
                            "history={history} | workspace={workspace_tokens} | files={files} | total={total}".format(
                                history=context_meta.get("history_tokens", history_est),
                                workspace_tokens=context_meta.get("workspace_summary_tokens", 0),
                                files=context_meta.get("relevant_file_tokens", 0),
                                total=prompt_size_est,
                            ),
                        )
                    )

                last_summary_attempt = int(state.get(f"last_summary_attempt_{step_idx}", 0) or 0)
                ready_for_summary = last_summary_attempt == 0 or (step_attempts - last_summary_attempt) >= 2
                if coder_history and ready_for_summary and prompt_size_est > coder_context_summary_threshold:
                    if verbose:
                        console.print("")
                        console.print(ui_detail("Context", f"Step context threshold reached ({prompt_size_est} tokens). Consolidating progress."))
                    prior_step_summary = state.get(f"coder_summary_{step_idx}", "")
                    history_blob = "\n".join(coder_history)
                    prior_summary_block = ""
                    if prior_step_summary:
                        prior_summary_block = f"Existing condensed step summary:\n{prior_step_summary}\n\n"
                    consolidate_req = (
                        f"You are a technical lead. The coding agent has been working on this step for many turns.\n"
                        f"Current Task: {task_desc}\n\n"
                        f"{prior_summary_block}"
                        f"All recent history for this step (logs, thoughts, errors):\n{history_blob}\n\n"
                        "Please provide a dense, senior-level technical summary of:\n"
                        "1. What has been achieved so far in this step.\n"
                        "2. Every error or roadblock encountered and the lessons learned.\n"
                        "3. The current state and the precise next technical hurdle to solve.\n\n"
                        "Keep it technical and objective."
                    )
                    try:
                        acc_c = load_access()
                        cfg_c = load_agent_config(workspace)
                        step_summary, usage_c = _call_gateway(
                            acc_c["api_key"], acc_c["endpoint"], cfg_c["model"],
                            "You are a senior developer providing high-fidelity progress summaries for complex tasks.",
                            consolidate_req, json_mode=False
                        )
                        coder_history = [f"Summary of work so far in this step: {step_summary}"] + coder_history[-2:]
                        state[f"coder_summary_{step_idx}"] = step_summary
                        state[f"coder_history_{step_idx}"] = coder_history
                        state[f"last_summary_attempt_{step_idx}"] = step_attempts
                        cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
                        cum_usage.add(usage_c, model=model)
                        step_usage.add(usage_c, model=model)
                        state["cumulative_usage"] = cum_usage.to_dict()
                        state[f"step_usage_{step_idx}"] = step_usage.to_dict()
                        save_agent_state(workspace, state)
                        last_usage = None
                        continue
                    except Exception as e:
                        console.print(ui_status("Warning", f"Failed to consolidate step history: {e}", tone="warning"))

                repair_prompt = ""
                if state.get("reject_count", 0) > 0:
                    last_feedback = state.get(f"last_rejection_feedback_{step_idx}", "Unknown rejection reason.")
                    repair_prompt = (
                        f"\n\n🚨 REPAIR MODE ACTIVATED (Rejected {state.get('reject_count')} times)\n"
                        f"REVIEWER FEEDBACK:\n{last_feedback}\n\n"
                        f"You MUST use your file tools to write the necessary code fixes to resolve these issues."
                    )
                if state.get("reject_count", 0) >= 3:
                    repair_prompt += (
                        "\n\nYou have been rejected multiple times. "
                        "You MUST rewrite the entire file using `write_file` with complete, "
                        "correct code. No placeholders."
                    )

                guard_recovery_note = _build_guard_recovery_note(
                    must_reread_files, lint_inspection_targets, inspected_files
                )
                if guard_recovery_note:
                    guard_recovery_note = f"\n\n{guard_recovery_note}"

                # Submit nudge: move to TOP of context when writes have already happened
                if writes_this_phase > 0:
                    submit_nudge = (
                        f"🚨 MANDATORY: You have written {writes_this_phase} file(s). "
                        f"If you are finished implementing this step, YOU MUST call `submit_step()` to finalize it.\n\n"
                    )
                    loop_context = f"{submit_nudge}{context_block}{guard_recovery_note}{repair_prompt}"
                else:
                    loop_context = (
                        f"{context_block}\n\n"
                        f"Execute the next tool call. If this step requires NO code changes (e.g. testing), "
                        f"simply perform your reads and the Submitter will take over automatically."
                        f"{guard_recovery_note}{repair_prompt}"
                    )


                if verbose:
                    console.print(ui_status("Iteration", f"{step_attempts}/{max_step_attempts}"))

                try:
                    tool_call = None
                    json_attempts = 0
                    current_loop_context = loop_context

                    while json_attempts < 3:
                        coder_system_prompt = _build_coder_system_prompt(workspace, plan_item)
                        response, usage = _call_gateway(
                            acc["api_key"], acc["endpoint"], model,
                            coder_system_prompt, current_loop_context
                        )
                        last_usage = usage
                        
                        # Update cumulative usage in state
                        cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
                        cum_usage.add(usage, model=model)
                        step_usage.add(usage, model=model)
                        state["cumulative_usage"] = cum_usage.to_dict()
                        state[f"step_usage_{step_idx}"] = step_usage.to_dict()
                        save_agent_state(workspace, state)

                        if verbose:
                            console.print(
                                ui_detail(
                                    "Usage",
                                    f"input={usage.input_tokens} | output={usage.output_tokens} | total={usage.total_tokens} | reasoning={usage.reasoning_tokens}",
                                )
                            )
                            console.print(ui_detail("Session", f"total usage={cum_usage.total_tokens} tokens"))

                        # Log raw response (preview only)
                        _log_llm_response(state, workspace, "coder", step_idx, response, step_attempts)

                        # Tolerant parsing: first extract_json, then parse_tool_call_from_text
                        parsed_json = extract_json(response)
                        
                        # Accept the new {"thinking": "...", "calls": [...]} format
                        if isinstance(parsed_json, dict) and "calls" in parsed_json and isinstance(parsed_json["calls"], list):
                            tool_calls = parsed_json["calls"]
                            thinking = parsed_json.get("thinking", "")
                            break
                        
                        # Fallback: if it's the old single object format, wrap it in a list
                        if isinstance(parsed_json, dict) and "tool" in parsed_json and "args" in parsed_json:
                            tool_calls = [parsed_json]
                            thinking = ""
                            break

                        json_attempts += 1
                        if verbose:
                            console.print(ui_status("Warning", f"JSON parse failed ({json_attempts}/3). Retrying.", tone="warning"))
                        error_msg = (
                            f"CRITICAL ERROR: Your previous response was invalid. "
                            f"You MUST return EXACTLY ONE JSON object containing a 'thinking' string and a 'calls' array of tools. "
                            f"Invalid response was: {response[:200]}"
                        )
                        current_loop_context = f"{loop_context}\n\n{error_msg}"

                    if not tool_calls:
                        coder_history.append(
                            "Error: Failed to generate valid JSON tool calls after 3 attempts."
                        )
                        console.print(ui_status("Blocked", "Coder failed to produce valid JSON. Retrying the loop.", tone="error"))
                        break

                    if thinking:
                        if verbose:
                            console.print(ui_thought(thinking))
                        # Non-verbose: we silence the 'Thinking' text print.
                        # The spinner is enough to show activity.
                        coder_history.append(f"Coder thought: {thinking}")

                    batch_writes = 0
                    batch_has_runtime_error = False  # tracks fatal errors found in run_command output

                    # Execute all tools in the One-Shot Batch
                    for tool_call in tool_calls:
                        tool_name = tool_call.get("tool")
                        tool_args = tool_call.get("args", {})
                        # Initialize targeted_paths early so guard functions can reference it safely
                        # before _extract_tool_paths() is called later in the loop.
                        targeted_paths = _extract_tool_paths(workspace, tool_name, tool_args)

                        if verbose:
                            # Smart action label: tool + most meaningful arg, no raw JSON dump
                            def _coder_fmt_action(name: str, args: dict) -> str:
                                if not args:
                                    return name
                                key_val = (
                                    args.get("target_file") or args.get("path") or
                                    args.get("command") or args.get("query") or
                                    args.get("new_file_path") or ""
                                )
                                key_val = str(key_val).replace("\\", "/").split("/")[-1]
                                key_val = key_val[:50].strip()
                                return f"{name} → {key_val}" if key_val else name
                            console.print(ui_detail("Action", _coder_fmt_action(tool_name, tool_args)))

                        # 1. Handle "Virtual" tools (internal to Executor)
                        if tool_name == "submit_step":
                            # Block submit if fatal runtime errors were detected in this batch
                            if batch_has_runtime_error:
                                console.print(ui_status("Blocked", "submit_step blocked because runtime errors exist in this step output. Fix them first.", tone="error"))
                                coder_history.append(
                                    "SYSTEM: submit_step was BLOCKED because fatal runtime errors were detected "
                                    "in a run_command output earlier in this batch. "
                                    "Review the error report above and fix all errors before submitting."
                                )
                                break
                            bootstrap_target = _bootstrap_target_dir_from_plan_item(plan_item)
                            if _is_framework_bootstrap_step(plan_item) and not _project_is_initialized(workspace, bootstrap_target):
                                console.print(ui_status("Blocked", "submit_step blocked because project bootstrap has not succeeded yet.", tone="error"))
                                coder_history.append(
                                    "SYSTEM: submit_step was BLOCKED because this bootstrap step has not created the project files yet. "
                                    "You must successfully initialize the framework before submitting."
                                )
                                break
                            if _is_shadcn_step(plan_item) and not _shadcn_postconditions_met(workspace):
                                console.print(ui_status("Blocked", "submit_step blocked because shadcn/ui setup postconditions are missing.", tone="error"))
                                coder_history.append(
                                    "SYSTEM: submit_step was BLOCKED because the shadcn/ui setup step has not produced `components.json` "
                                    "and generated UI assets yet. Verify the CLI output and inspect the real files before submitting."
                                )
                                break
                            if verbose:
                                console.print(ui_status("Submission", "Step submitted", tone="success"))
                            coder_history.append("System: Coder explicitly called submit_step.")
                            coder_done = True
                            break

                        # 2. Validate tool is permitted for this agent
                        if tool_name not in CODER_ALLOWED_TOOLS:
                            err_msg = f"Error: Tool '{tool_name}' not permitted. Allowed: {', '.join(CODER_ALLOWED_TOOLS)}"
                            coder_history.append(err_msg)
                            console.print(ui_status("Blocked", err_msg, tone="error"))
                            continue

                        # 3. Validate tool is registered
                        if tool_name not in TOOLS:
                            err_msg = f"Error: Invalid tool '{tool_name}'."
                            coder_history.append(err_msg)
                            console.print(ui_status("Blocked", err_msg, tone="error"))
                            continue

                        bootstrap_guard = _bootstrap_write_guard_message(plan_item, workspace, tool_name, tool_args)
                        if bootstrap_guard:
                            console.print(ui_status("Blocked", f"Bootstrap guard: {bootstrap_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {bootstrap_guard}")
                            break
                        shadcn_write_guard = _shadcn_write_guard_message(plan_item, workspace, tool_name)
                        if shadcn_write_guard:
                            console.print(ui_status("Blocked", f"shadcn guard: {shadcn_write_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {shadcn_write_guard}")
                            break
                        shell_guard = _shared_shell_write_guard_message(plan_item, workspace, tool_name, targeted_paths)
                        if shell_guard:
                            console.print(ui_status("Blocked", f"shared shell guard: {shell_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {shell_guard}")
                            break
                        guard_plan_item = plan_item
                        if state.get("reject_count", 0) > 0:
                            # REPAIR MODE: allow edits to files explicitly reported by the Verifier as blocking.
                            feedback = state.get(f"last_rejection_feedback_{step_idx}", "")
                            allow_paths = _filter_repair_paths_to_step_roots(
                                workspace,
                                plan_item,
                                _extract_verifier_blocking_paths(workspace, feedback),
                                state.get(f"verification_targets_{step_idx}", []),
                            )
                            if allow_paths:
                                guard_plan_item = dict(plan_item)
                                files_list = list(guard_plan_item.get("files") or [])
                                existing = {
                                    normalize_rel_path(str(x).replace("\\", "/")).rstrip("/")
                                    for x in files_list
                                    if x
                                }
                                newly_allowed = []
                                for p in sorted(allow_paths):
                                    if p not in existing:
                                        files_list.append(p)
                                        if p not in announced_repair_scope_files:
                                            newly_allowed.append(p)
                                            announced_repair_scope_files.add(p)
                                guard_plan_item["files"] = files_list
                                if newly_allowed:
                                    msg = "REPAIR MODE: Temporarily allowing edits to verifier-blocking file(s): " + ", ".join(newly_allowed)
                                    console.print(ui_detail("Repair scope", msg))
                                    coder_history.append(f"SYSTEM: {msg}")

                        step_scope_guard = _step_scope_write_guard_message(guard_plan_item, tool_name, targeted_paths)
                        if step_scope_guard:
                            console.print(ui_status("Blocked", f"step scope guard: {step_scope_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {step_scope_guard}")
                            _, repair_diag = _record_guard_violation(
                                state,
                                plan_item,
                                step_idx,
                                _classify_guard_violation(tool_name, step_scope_guard),
                                step_scope_guard,
                                guard_failure_counts,
                            )
                            if repair_diag:
                                force_repair_diagnostics = repair_diag
                            break
                        if _is_shadcn_command(tool_name, tool_args) and not _is_shadcn_step(plan_item):
                            shadcn_guard = (
                                "ERROR: shadcn/ui CLI commands are only allowed during the dedicated shadcn setup step. "
                                "Do not perform future-step work while the current step is still in progress."
                            )
                            console.print(ui_status("Blocked", f"step isolation guard: {shadcn_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {shadcn_guard}")
                            break
                        if tool_name == "run_command" and _is_shadcn_command(tool_name, tool_args):
                            shadcn_tool_guard = (
                                "ERROR: Use the dedicated `setup_shadcn` or `add_shadcn_components` tools for shadcn/ui commands "
                                "instead of raw run_command."
                            )
                            console.print(ui_status("Blocked", f"tool routing guard: {shadcn_tool_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {shadcn_tool_guard}")
                            break

                        tool_signature = canonical_tool_signature(tool_name, tool_args)
                        if tool_signature == last_coder_call:
                            consecutive_duplicates += 1
                        else:
                            last_coder_call = tool_signature
                            consecutive_duplicates = 1

                        if tool_name in {"replace_in_file", "patch_file"} and consecutive_duplicates >= 3:
                            duplicate_guard = (
                                "ERROR: You are repeating the same edit attempt without changing the target. "
                                "Re-read the file contents and choose a different exact target or rewrite the file."
                            )
                            console.print(ui_status("Blocked", f"duplicate edit guard: {duplicate_guard}", tone="error"))
                            coder_history.append(f"Tool {tool_name} Error: {duplicate_guard}")
                            auto_read = _auto_inspect_paths(
                                workspace,
                                targeted_paths,
                                inspected_files,
                                lint_inspection_targets,
                                must_reread_files,
                            )
                            if auto_read:
                                console.print(ui_detail("Auto-read", "Refreshed the blocked file for the next turn"))
                                coder_history.append(f"SYSTEM AUTO-INSPECTION:\n{auto_read}")
                            break

                        if tool_name in {"write_file", "replace_in_file", "patch_file"}:
                            blocked_lint_paths = sorted(path for path in targeted_paths if path in lint_inspection_targets and path not in inspected_files)
                            allow_direct_format_repair = bool(state.get(f"allow_direct_format_repair_{step_idx}", False))
                            if blocked_lint_paths and not allow_direct_format_repair:
                                lint_guard = (
                                    "ERROR: Verifier reported lint issues for this file. "
                                    "You must inspect the file with `read_file`, `read_lines`, or `search_file` before editing it."
                                )
                                console.print(ui_status("Blocked", f"lint inspection guard: {lint_guard}", tone="error"))
                                coder_history.append(f"Tool {tool_name} Error: {lint_guard} Affected file(s): {', '.join(blocked_lint_paths)}")
                                auto_read = _auto_inspect_paths(
                                    workspace,
                                    blocked_lint_paths,
                                    inspected_files,
                                    lint_inspection_targets,
                                    must_reread_files,
                                )
                                if auto_read:
                                    console.print(ui_detail("Auto-read", "Inspected the verifier-flagged file for the next turn"))
                                    coder_history.append(f"SYSTEM AUTO-INSPECTION:\n{auto_read}")
                                break
                            blocked_reread_paths = sorted(path for path in targeted_paths if path in must_reread_files)
                            if blocked_reread_paths:
                                reread_guard = (
                                    "ERROR: A previous edit attempt could not find the requested target text. "
                                    "You must re-read the file before attempting another edit."
                                )
                                console.print(ui_status("Blocked", f"re-read guard: {reread_guard}", tone="error"))
                                coder_history.append(f"Tool {tool_name} Error: {reread_guard} Affected file(s): {', '.join(blocked_reread_paths)}")
                                auto_read = _auto_inspect_paths(
                                    workspace,
                                    blocked_reread_paths,
                                    inspected_files,
                                    lint_inspection_targets,
                                    must_reread_files,
                                )
                                if auto_read:
                                    console.print(ui_detail("Auto-read", "Refreshed the file after the stale-target error"))
                                    coder_history.append(f"SYSTEM AUTO-INSPECTION:\n{auto_read}")
                                break

                        # Route writes through Editor, reads direct
                        if tool_name in WRITE_TOOLS:
                            existing_before = state.setdefault(f"preexisting_paths_{step_idx}", {})
                            for path in targeted_paths:
                                if path in existing_before:
                                    continue
                                try:
                                    existing_before[path] = resolve_agent_path(workspace, path, step_idx).exists()
                                except Exception:
                                    existing_before[path] = False
                            editor_result = apply_tool_call(workspace, tool_call, step_idx)
                            result = editor_result["details"]
                            if editor_result["status"] == "success":
                                for path in targeted_paths:
                                    lint_inspection_targets.discard(path)
                                    must_reread_files.discard(path)
                                for f in editor_result.get("files_changed", []):
                                    if not is_scratch_path(f) and f not in last_write_files:
                                        last_write_files.append(f)
                                recent_paths = [f for f in editor_result.get("files_changed", []) if f and not is_scratch_path(f)]
                                if recent_paths:
                                    kind_overrides = {path: "file" for path in recent_paths}
                                    existing_before = state.get(f"preexisting_paths_{step_idx}", {})
                                    state = record_recent_targets(
                                        state,
                                        recent_paths,
                                        role="edited",
                                        source="implementation",
                                        kind_overrides=kind_overrides,
                                    )
                                    for recent_path in recent_paths:
                                        preexisting = bool(existing_before.get(recent_path))
                                        if not preexisting:
                                            state = record_recent_targets(
                                                state,
                                                [recent_path],
                                                role="created",
                                                source="implementation",
                                                kind_overrides={recent_path: "file"},
                                            )
                                writes_this_phase += 1
                                batch_writes += 1
                                reads_after_write = 0  # reset read counter on new write
                                global_iterations += 1  # Only count meaningful writes
                                state.pop(f"allow_direct_format_repair_{step_idx}", None)

                                # Update workspace index immediately so semantic search sees changes
                                if recent_paths:
                                    update_index_for_files(workspace, recent_paths)
                                
                                # Auto-Retry loop via AST local validation
                                syntax_errs = []
                                for path in targeted_paths:
                                    if path.endswith(".py") and not is_scratch_path(path):
                                        try:
                                            _fp = resolve_agent_path(workspace, path, step_idx)
                                            if _fp.exists():
                                                ast.parse(_fp.read_text(encoding="utf-8"))
                                        except SyntaxError as se:
                                            syntax_errs.append(f"{path}: {se.msg} (Line {se.lineno})")
                                        except Exception:
                                            pass
                                if syntax_errs:
                                    err_block = "🚨 LOCAL SYNTAX ERROR PREVENTED WRITE SUCCESS:\n" + "\n".join(syntax_errs)
                                    console.print(ui_status("Blocked", "Syntax errors detected. submit_step blocked.", tone="error"))
                                    coder_history.append(err_block + "\nYou MUST fix these syntax errors. submit_step is blocked.")
                                    batch_has_runtime_error = True
                                else:
                                    # Collect diffs for the UI summary
                                    if editor_result.get("backup") and editor_result.get("metadata"):
                                        snap_base = Path(editor_result["backup"])
                                        for f_meta in editor_result["metadata"].get("files", []):
                                            f_path = f_meta["path"]
                                            if is_scratch_path(f_path): continue
                                            try:
                                                old_p = snap_base / f_meta["backup_path"]
                                                new_p = resolve_agent_path(workspace, f_path, step_idx)
                                                old_txt = old_p.read_text(encoding="utf-8") if old_p.exists() else ""
                                                new_txt = new_p.read_text(encoding="utf-8") if new_p.exists() else ""
                                                if old_txt != new_txt:
                                                    diff = generate_diff(f_path, old_txt, new_txt)
                                                    step_changes[f_path] = diff
                                            except Exception:
                                                pass

                                    if verbose:
                                        console.print(ui_status("Editor", f"{tool_name} completed: {result[:80]}", tone="success"))
                                    else:
                                        # High-level clean output
                                        targets = ", ".join(targeted_paths)
                                        console.print(ui_status("Editing", f"Applied changes to {targets}", tone="success"))

                                    coder_history.append(
                                        f"Observation from {tool_name}:\n{summarize_tool_observation(tool_name, result)}"
                                    )
                            else:
                                if tool_name in {"replace_in_file", "patch_file"} and "target_text not found" in result.lower():
                                    for path in targeted_paths:
                                        must_reread_files.add(path)
                                console.print(ui_status("Editor", f"{tool_name} failed: {result}", tone="error"))
                                coder_history.append(
                                    f"Editor {tool_name} Error: {summarize_tool_observation(tool_name, result)}"
                                )
                        else:
                            tool_func = get_tool(tool_name)
                            result = tool_func(workspace, **tool_args)
                            pruned = summarize_result(result)
                            history_result = summarize_tool_observation(tool_name, pruned)
                            _log_tool_run(workspace, tool_name, tool_args, pruned)

                            if (
                                not (result.startswith("ERROR") or result.startswith("Error"))
                                and _is_framework_bootstrap_step(plan_item)
                                and _is_bootstrap_command(tool_name, tool_args)
                                and not _project_is_initialized(
                                    workspace,
                                    _bootstrap_target_dir_from_tool(tool_name, tool_args, plan_item),
                                )
                            ):
                                bootstrap_error = (
                                    "ERROR: Bootstrap command completed without creating the expected project files in the target workspace directory. "
                                    "Do not continue with manual file writes. Retry initialization or adjust the scaffold command."
                                )
                                console.print(ui_status("Blocked", f"tool error: {bootstrap_error}", tone="error"))
                                coder_history.append(f"Tool {tool_name} Error: {bootstrap_error}")
                                break

                            if result.startswith("ERROR") or result.startswith("Error"):
                                console.print(ui_status("Blocked", f"tool error: {result[:100]}", tone="error"))
                                coder_history.append(f"Tool {tool_name} Error: {history_result}")
                                violation_kind = _classify_guard_violation(tool_name, result)
                                _, repair_diag = _record_guard_violation(
                                    state,
                                    plan_item,
                                    step_idx,
                                    violation_kind,
                                    result,
                                    guard_failure_counts,
                                )
                                if repair_diag:
                                    force_repair_diagnostics = repair_diag
                                # For policy/scope guard violations: stop the batch so the agent
                                # can re-plan the next turn.
                                # For command execution errors (non-zero exit, syntax, etc.):
                                # use 'continue' — the agent can proceed with later tool calls
                                # in the same batch (e.g. run more checks, then decide to fix).
                                # Only hard-break on shell_policy guard violations.
                                if violation_kind in {"step_scope", "shell_policy"}:
                                    break
                                # Non-policy run_command failures: log and continue (soft fail)
                                # so the batch is not needlessly aborted. 
                            else:
                                console.print(ui_status("Action", f"{tool_name} completed", tone="success"))
                                coder_history.append(f"Observation from {tool_name}:\n{history_result}")
                                if tool_name in {"scaffold_next_app", "setup_shadcn", "add_shadcn_components"} and targeted_paths:
                                    state = record_recent_targets(
                                        state,
                                        sorted(targeted_paths),
                                        role="created" if tool_name == "scaffold_next_app" else "edited",
                                        source="implementation",
                                        kind_overrides={path: "dir" for path in targeted_paths},
                                    )
                                if tool_name in {"read_file", "read_lines", "search_file", "multi_read"}:
                                    for path in targeted_paths:
                                        inspected_files.add(path)
                                        lint_inspection_targets.discard(path)
                                        must_reread_files.discard(path)
                                # Track verification reads that happen after a write
                                if tool_name == "read_file" and writes_this_phase > 0:
                                    reads_after_write += 1
                                elif tool_name in {"run_command", "scaffold_next_app", "setup_shadcn", "add_shadcn_components"}:
                                    if tool_name in {"scaffold_next_app", "setup_shadcn", "add_shadcn_components"}:
                                        writes_this_phase += 1
                                        reads_after_write = 0
                                    batch_writes += 1
                                    global_iterations += 1
                                if tool_name in {"run_command", "wait_for_output", "scaffold_next_app", "setup_shadcn", "add_shadcn_components"}:
                                    # Scan command output and background server logs for fatal build/runtime errors.
                                    runtime_errors = _scan_for_runtime_errors(result)
                                    if runtime_errors:
                                        error_report = (
                                            f"🚨 RUNTIME ERROR DETECTED in `{tool_name}` output.\n"
                                            f"The following fatal patterns were found:\n"
                                            + "\n".join(f"  • {e}" for e in runtime_errors) +
                                            "\n\nYou MUST fix all of these errors. "
                                            "You are FORBIDDEN from calling submit_step until they are resolved."
                                        )
                                        coder_history.append(error_report)
                                        console.print(ui_status("Blocked", f"Runtime errors detected in {tool_name} output. submit_step is blocked.", tone="error"))
                                        state[f"coder_history_{step_idx}"] = coder_history
                                        save_agent_state(workspace, state)
                                        # Mark batch as having errors so submit_step is blocked below
                                        batch_has_runtime_error = True
                        


                    if batch_writes == 0:
                        read_only_turns_in_phase += 1

                    if force_repair_diagnostics:
                        coder_history.append(f"SYSTEM: {force_repair_diagnostics}")
                        # Only escalate to immediate repair after 2+ repeated guard failures
                        # so the agent gets one self-correction turn first.
                        total_guard_failures = sum(guard_failure_counts.values())
                        if total_guard_failures >= 2:
                            step_attempts = max_step_attempts

                    state[f"coder_history_{step_idx}"] = coder_history
                    state[f"must_reread_files_{step_idx}"] = sorted(must_reread_files)
                    state[f"lint_targets_{step_idx}"] = sorted(lint_inspection_targets)
                    save_agent_state(workspace, state)
                    time.sleep(0.3)

                except Exception as e:
                    console.print(ui_status("Error", f"Coder execution error: {e}", tone="error"))
                    time.sleep(1.5)
                    continue

            if step_attempts >= max_step_attempts:
                console.print(ui_status("Repair", f"Step {step_idx} exhausted max_step_attempts ({max_step_attempts}). Triggering repair.", tone="error"))
                # Run repair agent
                repair_result = run_repair(
                    workspace, plan_item,
                    diagnostics=force_repair_diagnostics or f"Coder exhausted {max_step_attempts} attempts without submit.",
                    coder_history=coder_history,
                    attempt=min(repair_attempt + 1, 3),
                    state=state,
                    user_message=user_message,
                )
                repair_attempt += 1
                repair_usage = UsageData.from_dict(repair_result.get("usage", {}))
                if repair_usage.total_tokens:
                    cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
                    cum_usage.add(repair_usage)
                    step_usage.add(repair_usage)
                    state["cumulative_usage"] = cum_usage.to_dict()
                    state[f"step_usage_{step_idx}"] = step_usage.to_dict()
                    save_agent_state(workspace, state)
                if repair_result["action"] == "escalate":
                    return
                if repair_result["action"] == "rewrite":
                    # Inject rewrite instruction into coder_history and retry coder
                    state[f"coder_notes_{step_idx}"] = (
                        "ACTIVE REPAIR MODE:\n"
                        "The previous approach failed. Rewrite the failing file completely with final, correct code."
                    )
                    state[f"coder_history_{step_idx}"] = coder_history
                    save_agent_state(workspace, state)
                    continue  # outer while loop = retry coder
                repair_plan = repair_result.get("fix_plan", [])
                if repair_plan:
                    repair_summary = _format_repair_plan(repair_plan)
                    coder_history.append(f"REPAIR AGENT PLAN:\n{repair_summary}")
                    state[f"repair_plan_{step_idx}"] = repair_plan
                    state[f"coder_notes_{step_idx}"] = (
                        "ACTIVE REPAIR PLAN:\n"
                        f"{repair_summary}\n\n"
                        "Follow these repair steps before you submit the current step."
                    )
                else:
                    coder_history.append(f"REPAIR AGENT: {repair_result['message']}")
                state[f"coder_history_{step_idx}"] = coder_history
                save_agent_state(workspace, state)
                continue

            if global_iterations >= max_steps:
                break

            # -----------------------------------------------------------------
            # 2. VERIFIER PHASE (Deterministic Validation)
            # -----------------------------------------------------------------
            is_final_step = (step_idx == plan[-1]["step"])
            if verbose:
                console.print(ui_status("Verifier", f"Evaluating step {step_idx}", tone="accent"))
            
            verifier_result = run_verification(workspace, plan_item, last_write_files, is_final_step=is_final_step)
            autoformatted_files: list[str] = []
            autoformatted_targets: list[str] = []
            if verifier_result.get("suggested_action") == "auto_fix":
                autoformatted_files, autoformatted_targets = _attempt_format_only_autofix(
                    workspace,
                    step_idx,
                    verifier_result,
                )
                if autoformatted_files:
                    for formatted_file in autoformatted_files:
                        if formatted_file not in last_write_files:
                            last_write_files.append(formatted_file)
                    state = record_recent_targets(
                        state,
                        autoformatted_files,
                        role="edited",
                        source="verifier",
                        kind_overrides={path: "file" for path in autoformatted_files},
                    )
                    state.pop(f"allow_direct_format_repair_{step_idx}", None)
                    state.pop(f"lint_targets_{step_idx}", None)
                    save_agent_state(workspace, state)
                    if verbose:
                        console.print(
                            ui_status(
                                "Auto-fix",
                                "Applied deterministic format repair to "
                                + ", ".join(autoformatted_targets[:3])
                                + ("..." if len(autoformatted_targets) > 3 else ""),
                                tone="accent",
                            )
                        )
                    verifier_result = run_verification(
                        workspace,
                        plan_item,
                        last_write_files,
                        is_final_step=is_final_step,
                    )
            if verifier_result["status"] == "warn" and not verifier_result.get("is_blocking", False):
                console.print(ui_status("Verifier", "Approved step with non-blocking verification warning", tone="warning"))
                if verifier_result.get("reason"):
                    console.print(ui_detail("Verifier", verifier_result["reason"][:300]))
                console.print(ui_detail("Usage", f"step {step_idx}: {_format_usage_brief(step_usage)}"))
                step_resolved = True
            elif verifier_result["status"] == "fail" and verifier_result.get("is_blocking", True):
                console.print(ui_status("Verifier", "Verifier failed", tone="error"))
                console.print(ui_detail("Diagnostics", verifier_result["diagnostics"][:300]))
                lint_check = verifier_result.get("checks", {}).get("lint", {})
                failure_classification = str(verifier_result.get("failure_classification") or "").strip()
                if not lint_check.get("passed", True):
                    lint_targets = sorted({normalize_rel_path(path) for path in last_write_files if path})
                    format_only_failures = int(state.get(f"format_only_failures_{step_idx}", 0) or 0)
                    if lint_targets and failure_classification == "format_only" and format_only_failures == 0:
                        state[f"allow_direct_format_repair_{step_idx}"] = True
                        state[f"format_only_failures_{step_idx}"] = 1
                        state.pop(f"lint_targets_{step_idx}", None)
                        state[f"coder_notes_{step_idx}"] = (
                            "ACTIVE FORMAT REPAIR MODE:\n"
                            f"- Directly fix these touched file(s): {', '.join(lint_targets)}\n"
                            "- This is a formatter-style verifier failure, so one direct repair pass is allowed.\n"
                            "- If the next verifier run still fails, inspect the file before editing again."
                        )
                    elif lint_targets:
                        state[f"lint_targets_{step_idx}"] = lint_targets
                        state[f"coder_notes_{step_idx}"] = (
                            "ACTIVE LINT REPAIR MODE:\n"
                            f"- Inspect these file(s) before editing: {', '.join(lint_targets)}\n"
                            "- Use search_file plus read_lines (or read_file for smaller files) to inspect the reported area before attempting fixes.\n"
                            "- If an edit target is not found, re-read the file before trying another replacement."
                        )
                coder_history.append(
                    f"SYSTEM REJECTION: The Automated Verifier failed.\n"
                    f"Verifier Errors:\n{verifier_result['diagnostics']}\n"
                    f"You must fix these errors. Re-evaluating."
                )
                state["reject_count"] = state.get("reject_count", 0) + 1
                state[f"last_rejection_feedback_{step_idx}"] = f"Automated Verifier failed:\n{verifier_result['diagnostics']}"
                state[f"verification_targets_{step_idx}"] = list(verifier_result.get("verification_targets", []) or [])
                state[f"verification_mode_{step_idx}"] = str(verifier_result.get("verification_mode", "project") or "project")
                state[f"coder_history_{step_idx}"] = coder_history
                save_agent_state(workspace, state)
                # Loop back to Coder
                continue
            else:
                console.print(ui_status("Verifier", f"Approved step {step_idx}", tone="success"))
                if verbose:
                    console.print(ui_detail("Usage", f"step {step_idx}: {_format_usage_brief(step_usage)}"))
                step_resolved = True

            if step_resolved:
                cleanup_step_scratch_dir(workspace, step_idx)
                from nexcode.agent_runtime.snapshot import create_snapshot
                create_snapshot(workspace, step_idx)

                # Save state immediately to prevent UI crash from blocking completion
                state["completed_steps"].append(step_idx)
                state["reject_count"] = 0
                state.pop(f"coder_notes_{step_idx}", None)
                state.pop(f"coder_summary_{step_idx}", None)
                state.pop(f"repair_plan_{step_idx}", None)
                state.pop(f"lint_targets_{step_idx}", None)
                state.pop(f"must_reread_files_{step_idx}", None)
                state.pop(f"allow_direct_format_repair_{step_idx}", None)
                state.pop(f"format_only_failures_{step_idx}", None)
                state.pop(f"preexisting_paths_{step_idx}", None)
                save_agent_state(workspace, state)



        if step_resolved:
            # Show Step Summary Card
            summary_bits = []
            if step_summary:
                summary_bits.append(Text(step_summary))
            
            if step_changes:
                summary_bits.append(Text("\nModified Files:", style="bold white"))
                for f_path, diff in step_changes.items():
                    summary_bits.append(ui_diff(f_path, diff))
            
            if summary_bits:
                if step_changes or verbose:
                    console.print("")
                    console.print(ui_card("", Group(*summary_bits), tone="success"))
                    console.print("")

        if global_iterations >= max_steps:
            console.print(ui_status("Paused", "Global max_steps reached. Run resume to continue.", tone="error"))
            return

        if not step_resolved:
            console.print(ui_status("Failed", f"Agent failed to resolve step {step_idx}.", tone="error"))
            return

    console.print("")
    console.print(ui_status("Complete", "Project ready. All steps completed.", tone="success"))
