"""
context.py - Builds dynamic context for the agent loops to prevent unnecessary reads.
"""
from __future__ import annotations

import re
from pathlib import Path

from nexcode.agent_runtime.excerpts import build_file_excerpt, collect_focus_terms
from nexcode.agent_runtime.prompt_context import build_compact_workspace_summary
from nexcode.agent_runtime.task_scope import build_workspace_summary, resolve_task_scope
from nexcode.agent_runtime.workspace import get_project_root, safe_path


def _extract_file_mentions(*texts: str) -> list[str]:
    seen: set[str] = set()
    files: list[str] = []
    path_pattern = re.compile(r"[\w\-/\\._]{2,64}\.\w{2,10}")
    for text in texts:
        if not text:
            continue
        for line in text.splitlines():
            if len(line) > 300:
                continue
            for match in path_pattern.findall(line):
                if match.lower() in {"requirement.already", "installing.", "collecting.", "warning."}:
                    continue
                normalized = str(Path(match).as_posix()).lstrip("./")
                if normalized and normalized not in seen:
                    seen.add(normalized)
                    files.append(normalized)
    return files


def _collect_candidate_files(
    project_root: Path,
    *,
    preferred_files=None,
    report_checked_files=None,
    recent_files=None,
    step_desc: str = "",
    verifier_feedback: str = "",
) -> list[str]:
    candidates: list[str] = []
    seen: set[str] = set()

    def _push(raw_path) -> None:
        normalized = str(Path(str(raw_path)).as_posix()).lstrip("./")
        if not normalized or normalized in seen:
            return
        try:
            target = safe_path(project_root, normalized)
        except Exception:
            return
        if not target.exists() or not target.is_file():
            return
        seen.add(normalized)
        candidates.append(normalized)

    for source in (preferred_files, report_checked_files, recent_files):
        for item in source or []:
            _push(item)

    for match in _extract_file_mentions(step_desc, verifier_feedback):
        _push(match)

    if not candidates:
        for candidate in ("package.json", "pyproject.toml", "requirements.txt", "README.md"):
            _push(candidate)

    return candidates


def build_context(
    workspace,
    step_desc: str,
    plan_preview: list,
    history: list,
    instruction_memory: str,
    user_message: str = "",
    design_memory: str = "",
    content_memory: str = "",
    coder_notes: str = "",
    rationale: str = "",
    forensics: str = "",
    preferred_files: list[str] | None = None,
    report_checked_files: list[str] | None = None,
    recent_files: list[str] | None = None,
    verifier_feedback: str = "",
    return_metadata: bool = False,
) -> str | tuple[str, dict]:
    from nexcode.agent_runtime.token_utils import estimate_tokens

    project_root = get_project_root(workspace)
    task_scope = resolve_task_scope(
        workspace,
        user_message=f"{step_desc}\n{verifier_feedback}",
        checked_files=report_checked_files,
        plan_files=preferred_files,
        changed_files=recent_files,
    )

    workspace_summary, ranked_files = build_compact_workspace_summary(
        workspace,
        query=" ".join(filter(None, [step_desc, verifier_feedback, " ".join(preferred_files or [])])),
        preferred_files=preferred_files,
        checked_files=report_checked_files,
        recent_files=recent_files,
        task_scope=task_scope,
        top_k=12,
        max_chars=8000,
    )
    if not workspace_summary:
        workspace_summary = build_workspace_summary(workspace, task_scope)

    files_to_read = _collect_candidate_files(
        project_root,
        preferred_files=preferred_files,
        report_checked_files=report_checked_files,
        recent_files=recent_files,
        step_desc=step_desc,
        verifier_feedback=verifier_feedback,
    )
    if ranked_files:
        seen: set[str] = set(files_to_read)
        files_to_read = [path for path in ranked_files if path not in seen] + files_to_read
    files_to_read = files_to_read[:10]

    focus_terms = collect_focus_terms(
        instruction_memory,
        step_desc,
        rationale,
        forensics,
        verifier_feedback,
        coder_notes,
        history[-6:] if history else [],
        preferred_files or [],
        report_checked_files or [],
    )

    max_file_tokens = 16000
    current_file_tokens = 0
    recent_contents_parts: list[str] = []

    for rel_path in files_to_read:
        try:
            target = safe_path(workspace, rel_path)
            content = target.read_text(encoding="utf-8", errors="replace")
            excerpt = build_file_excerpt(rel_path, content, focus_terms=focus_terms)
            token_count = estimate_tokens(excerpt)
            if current_file_tokens + token_count < max_file_tokens:
                recent_contents_parts.append(excerpt)
                current_file_tokens += token_count
        except Exception:
            continue

    recent_contents = "\n".join(recent_contents_parts)

    max_total_tokens = 250_000
    max_history_tokens = 250_000
    design_str = f"DESIGN SPEC:\n[design_memory]\n{design_memory}\n\n" if design_memory else ""
    content_str = f"CONTENT DATA:\n[compressed_content_memory]\n{content_memory}\n\n" if content_memory else ""
    notes_str = f"CODER NOTES / TRANSFER:\n{coder_notes}\n\n" if coder_notes else ""
    rationale_str = f"STRATEGIC RATIONALE:\n{rationale}\n\n" if rationale else ""
    forensics_str = f"FORENSIC PROOF (From Reporter Agent):\n{forensics}\n\n" if forensics else ""
    verifier_str = f"RECENT VERIFIER FEEDBACK:\n{verifier_feedback}\n\n" if verifier_feedback else ""

    current_turn_str = f"CURRENT TURN REQUEST:\n{user_message}\n\n" if user_message else ""
    
    base_info = (
        f"PROJECT GOALS:\n[instruction_memory]\n{instruction_memory}\n\n"
        f"{current_turn_str}{forensics_str}{verifier_str}{rationale_str}{design_str}{content_str}{notes_str}"
        f"Plan Progress:\n" + "\n".join(plan_preview) + "\n\n"
        f"Workspace summary:\n{workspace_summary}\n\n"
        f"Relevant File Contents:\n{recent_contents}\n\n"
        f"Execution History & Feedback:\n"
    )

    # -----------------------------------------------------------------------
    # Smart history assembly: when history exceeds the token budget,
    # summarize older entries instead of hard-dropping them.
    # -----------------------------------------------------------------------
    current_total_tokens = estimate_tokens(base_info)
    def _condense_entry(entry: str) -> str:
        """Compress a history entry to a single-line summary."""
        first_line = entry.split("\n")[0][:150].strip()
        # Classify entry type for meaningful one-liner
        if first_line.startswith("Observation from "):
            # e.g. "Observation from write_file:" → "✓ write_file: <first line of result>"
            tool = first_line.replace("Observation from ", "").rstrip(":")
            result_line = entry.split("\n")[1][:80].strip() if "\n" in entry else ""
            return f"✓ {tool}: {result_line}"
        if first_line.startswith("Editor ") and "Error" in first_line:
            return f"✗ {first_line}"
        if first_line.startswith("Tool ") and "Error" in first_line:
            return f"✗ {first_line}"
        if first_line.startswith("SYSTEM REJECTION"):
            return "✗ Verifier rejected — see later feedback for details"
        if first_line.startswith("SYSTEM AUTO-INSPECTION"):
            return "↻ Auto-inspected file after stale-target error"
        if first_line.startswith("Coder thought:"):
            return first_line[:120]
        # Fallback: just the first line
        return first_line[:120]

    remaining_budget = max_total_tokens - current_total_tokens
    history_budget = min(max_history_tokens, remaining_budget)

    # First, try to fit everything
    total_history_tokens = sum(estimate_tokens(e) + 1 for e in history)

    if total_history_tokens <= history_budget:
        # Everything fits — no summarization needed
        selected_history = list(history)
    else:
        # Strategy: keep last 8 entries intact, summarize older ones
        keep_recent = min(8, len(history))
        recent_entries = history[-keep_recent:]
        older_entries = history[:-keep_recent] if keep_recent < len(history) else []

        recent_tokens = sum(estimate_tokens(e) + 1 for e in recent_entries)

        # Summarize older entries into condensed one-liners
        if older_entries:
            condensed = [_condense_entry(e) for e in older_entries]
            summary_block = (
                f"[Earlier actions condensed — {len(older_entries)} entries]:\n"
                + "\n".join(f"  {c}" for c in condensed)
            )
            summary_tokens = estimate_tokens(summary_block) + 1

            if recent_tokens + summary_tokens <= history_budget:
                # Condensed summary + recent entries fit
                selected_history = [summary_block] + list(recent_entries)
            else:
                # Even summary doesn't fit — truncate the condensed block
                # Keep only the last N condensed lines that fit
                available = history_budget - recent_tokens - 50  # overhead
                if available > 0:
                    truncated_summary = (
                        f"[{len(older_entries)} earlier actions condensed — showing last ones]:\n"
                        + "\n".join(f"  {c}" for c in condensed[-10:])
                    )
                    selected_history = [truncated_summary] + list(recent_entries)
                else:
                    # Extreme case: even recent entries are tight
                    selected_history = list(recent_entries)
                    selected_history.insert(0, f"... [{len(older_entries)} earlier actions omitted for budget] ...")
        else:
            selected_history = list(recent_entries)

    history_token_total = sum(estimate_tokens(e) + 1 for e in selected_history)

    history_text = "\n".join(selected_history)
    context_text = base_info + history_text + "\n"
    metadata = {
        "workspace_summary_tokens": estimate_tokens(workspace_summary),
        "relevant_file_tokens": estimate_tokens(recent_contents),
        "history_tokens": estimate_tokens(history_text),
        "base_tokens": estimate_tokens(base_info),
        "total_tokens": estimate_tokens(context_text),
        "focused_files": list(files_to_read),
        "scope_roots": [str(root) for root in task_scope.focused_roots],
    }
    if return_metadata:
        return context_text, metadata
    return context_text
