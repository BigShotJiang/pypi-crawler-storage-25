"""
file_tools.py — Safe file operations using the agent tool registry.
"""
import os
import shutil
from pathlib import Path
from nexcode.agent_runtime.task_scope import DISCOVERY_IGNORED_DIRS, DISCOVERY_IGNORED_FILE_SUFFIXES
from nexcode.agent_runtime.tool_registry import register_tool
from nexcode.agent_runtime.excerpts import build_file_excerpt
from nexcode.agent_runtime.workspace import normalize_rel_path, resolve_agent_path

@register_tool("write_file")
def write_file(workspace: Path, path: str, content: str) -> str:
    """Write content to a file safely within the workspace."""
    try:
        # Automatically append a trailing newline to text files to prevent W292 lint errors
        if content and not content.endswith("\n"):
            content += "\n"
            
        target = resolve_agent_path(workspace, path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"SUCCESS: File written successfully: {path}"
    except Exception as e:
        return f"ERROR: writing file {path}: {str(e)}"


@register_tool("delete_file")
def delete_file(workspace: Path, path: str) -> str:
    """Delete a file safely within the workspace."""
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"
        if target.is_dir():
            return f"ERROR: Cannot delete directory {path} with this tool. Target must be a file."
        target.unlink()
        return f"SUCCESS: File deleted successfully: {path}"
    except Exception as e:
        return f"ERROR: deleting file {path}: {str(e)}"

@register_tool("delete_directory")
def delete_directory(workspace: Path, path: str) -> str:
    """Recursively delete a directory safely within the workspace."""
    import shutil
    import stat
    import time
    
    def _on_rm_error(func, path_to_rm, exc_info):
        """Error handler for shutil.rmtree to handle read-only files on Windows."""
        try:
            # Fix read-only permissions
            os.chmod(path_to_rm, stat.S_IWRITE)
            func(path_to_rm)
        except Exception:
            # If it still fails, there's not much we can do here automatically
            pass

    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: Directory not found: {path}"
        if not target.is_dir():
            return f"ERROR: Path {path} is not a directory. Use delete_file for files."

        # Add a small retry loop for potential transient locks
        for attempt in range(3):
            try:
                shutil.rmtree(target, onerror=_on_rm_error)
                return f"SUCCESS: Directory deleted successfully: {path}"
            except Exception:
                if attempt < 2:
                    time.sleep(1)
                    continue
                raise

    except Exception as e:
        return f"ERROR: deleting directory {path}: {str(e)}. Tip: If this is 'Access Denied', make sure to stop any background processes (npm run dev) using this folder."


@register_tool("make_directory")
def make_directory(workspace: Path, path: str) -> str:
    """Create a directory and any missing parent directories."""
    try:
        target = resolve_agent_path(workspace, path)
        target.mkdir(parents=True, exist_ok=True)
        return f"SUCCESS: Directory created successfully: {path}"
    except Exception as e:
        return f"ERROR: creating directory {path}: {str(e)}"


@register_tool("move_path")
def move_path(workspace: Path, src: str, dest: str, overwrite: bool = False) -> str:
    """Move a file or directory safely within the workspace or scratch space."""
    try:
        source = resolve_agent_path(workspace, src)
        destination = resolve_agent_path(workspace, dest)
        if not source.exists():
            return f"ERROR: Source path not found: {src}"
        if destination.exists() and not overwrite:
            return f"ERROR: Destination already exists: {dest}"
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and overwrite:
            if destination.is_dir():
                shutil.rmtree(destination)
            else:
                destination.unlink()
        shutil.move(str(source), str(destination))
        return f"SUCCESS: Moved path from {src} to {dest}"
    except Exception as e:
        return f"ERROR: moving path from {src} to {dest}: {str(e)}"


@register_tool("copy_path")
def copy_path(workspace: Path, src: str, dest: str, overwrite: bool = False) -> str:
    """Copy a file or directory safely within the workspace or scratch space."""
    try:
        source = resolve_agent_path(workspace, src)
        destination = resolve_agent_path(workspace, dest)
        if not source.exists():
            return f"ERROR: Source path not found: {src}"
        if destination.exists() and not overwrite:
            return f"ERROR: Destination already exists: {dest}"
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.is_dir():
            if destination.exists():
                shutil.rmtree(destination)
            shutil.copytree(source, destination)
        else:
            if destination.exists():
                destination.unlink()
            shutil.copy2(source, destination)
        return f"SUCCESS: Copied path from {src} to {dest}"
    except Exception as e:
        return f"ERROR: copying path from {src} to {dest}: {str(e)}"

# Files at or below these limits are returned in full.
# Larger files return a structured preview — use read_lines() to read specific sections.
_SMALL_FILE_LINE_LIMIT = 350
_SMALL_FILE_CHAR_LIMIT = 14_000

@register_tool("read_file")
def read_file(workspace: Path, path: str) -> str:
    """
    Read a file.  Small files (≤350 lines / 14 KB) are returned in full with line numbers.
    Large files return: total line count + first 80 lines + last 20 lines, and instruct
    the agent to use read_lines(path, start_line, end_line) to read any specific range.
    """
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"

        # Encoding detection: utf-8-sig handles BOM, utf-16 handles UTF-16LE/BE,
        # latin-1 never fails (maps all 256 byte values).
        raw_bytes = target.read_bytes()
        content = None
        detected_encoding = "utf-8"
        for enc in ("utf-8-sig", "utf-8", "utf-16", "latin-1"):
            try:
                content = raw_bytes.decode(enc)
                detected_encoding = enc
                break
            except (UnicodeDecodeError, Exception):
                continue
        if content is None:
            content = raw_bytes.decode("utf-8", errors="replace")
            detected_encoding = "utf-8 (with replacement)"

        lines = content.splitlines()
        total_lines = len(lines)
        encoding_note = f" [encoding: {detected_encoding}]" if detected_encoding not in {"utf-8", "utf-8-sig"} else ""

        # ── Small file: return everything ──────────────────────────────────────
        if total_lines <= _SMALL_FILE_LINE_LIMIT and len(content) <= _SMALL_FILE_CHAR_LIMIT:
            numbered = "\n".join(f"{i+1} | {line}" for i, line in enumerate(lines))
            return (
                f"FILE: {path}{encoding_note}  [{total_lines} lines]\n\n"
                f"{numbered}\n"
            )

        # ── Large file: structured preview + clear navigation guidance ─────────
        head_lines = min(80, total_lines)
        tail_start = max(head_lines + 1, total_lines - 19)
        head = "\n".join(f"{i+1} | {lines[i]}" for i in range(head_lines))
        tail = "\n".join(f"{i+1} | {lines[i]}" for i in range(tail_start - 1, total_lines))

        gap_note = ""
        if tail_start > head_lines + 1:
            gap_note = f"\n... [{tail_start - head_lines - 1} lines not shown — use read_lines to read them] ...\n"

        return (
            f"FILE: {path}{encoding_note}  [LARGE FILE: {total_lines} lines / {len(content):,} chars]\n"
            f"Use read_lines(\"{path}\", start_line, end_line) to read any specific section.\n"
            f"Use search_file(\"{path}\", query) to locate a specific string first.\n\n"
            f"----- LINES 1–{head_lines} -----\n"
            f"{head}\n"
            f"{gap_note}"
            f"----- LINES {tail_start}–{total_lines} -----\n"
            f"{tail}\n"
        )
    except Exception as e:
        return f"ERROR: reading file {path}: {str(e)}"

@register_tool("replace_in_file")
def replace_in_file(workspace: Path, path: str, target_text: str, replacement_text: str) -> str:
    """Replace a string in a file with a new string. Resilient to whitespace and escape differences."""
    import re
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"

        content = target.read_text(encoding="utf-8")

        def _write(new_content: str, strategy: str) -> str:
            if new_content == content:
                return f"ERROR: replacement_text is identical to the matched text — no change would be made. Read the file first and verify the exact content."
            target.write_text(new_content, encoding="utf-8")
            return f"SUCCESS: Successfully replaced text in {path} ({strategy})"

        # 1. Exact match
        if target_text in content:
            return _write(content.replace(target_text, replacement_text, 1), "Exact match")

        # 2. Normalised line endings (CRLF → LF)
        content_lf = content.replace("\r\n", "\n")
        target_lf  = target_text.replace("\r\n", "\n")
        if target_lf in content_lf:
            return _write(content_lf.replace(target_lf, replacement_text, 1), "Normalised line endings")

        # 3. Backslash variants — JSON double-encoding often halves or doubles backslashes
        for candidate in (
            target_text.replace("\\\\", "\\"),   # halve doubled backslashes
            target_text.replace("\\", "\\\\"),   # double single backslashes
            target_lf.replace("\\\\", "\\"),
            target_lf.replace("\\", "\\\\"),
        ):
            if candidate in content:
                return _write(content.replace(candidate, replacement_text, 1), "Backslash-normalised match")
            if candidate in content_lf:
                return _write(content_lf.replace(candidate, replacement_text, 1), "Backslash-normalised + LF match")

        # 4. Whitespace-flexible match (indentation / extra spaces)
        escaped_parts = [re.escape(p) for p in target_text.split()]
        if escaped_parts:
            match = re.search(r'\s+'.join(escaped_parts), content)
            if match:
                return _write(content[:match.start()] + replacement_text + content[match.end():], "Whitespace-flexible match")

        return f"ERROR: target_text not found in {path}. Tried exact, line-ending, backslash, and whitespace-flexible strategies."
    except Exception as e:
        return f"ERROR: replacing text in {path}: {str(e)}"

@register_tool("patch_file")
def patch_file(workspace: Path, path: str, start_line: int, end_line: int, new_content: str) -> str:
    """Replace a range of lines (inclusive, 1-indexed) with new content. Use this for surgical edits on large files."""
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"
        
        lines = target.read_text(encoding="utf-8").splitlines()
        
        if start_line < 1 or start_line > len(lines):
            return f"ERROR: start_line {start_line} is out of bounds (1-{len(lines)})."
        if end_line < start_line or end_line > len(lines):
            # Strict bounds: end_line must be within file range
            return f"ERROR: end_line {end_line} is invalid for start_line {start_line} (file has {len(lines)} lines)."
            
        # Replace the range
        # Python list slice assignment: list[start:end] replaces the items from start to end-1.
        # To replace inclusive 1-indexed lines [start_line, end_line], we need slice [start_line-1 : end_line]
        lines[start_line-1 : end_line] = new_content.splitlines()
        
        target.write_text("\n".join(lines), encoding="utf-8")
        return f"SUCCESS: Successfully patched lines {start_line}-{end_line} in {path}"
    except Exception as e:
        return f"ERROR: patching file {path}: {str(e)}"

@register_tool("search_file")
def search_file(workspace: Path, path: str, query: str) -> str:
    """Search for a string inside a file. Returns all matching lines with numbers.
    Always includes total file line count so the agent knows where matches sit.
    """
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"

        lines = target.read_text(encoding="utf-8").splitlines()
        total_lines = len(lines)
        matches = [(i + 1, line) for i, line in enumerate(lines) if query in line]

        if not matches:
            return f"No matches found for '{query}' in {path}. [{total_lines} lines total]"

        header = f"FILE: {path} [{total_lines} lines total] — {len(matches)} match{'es' if len(matches) != 1 else ''} for '{query}':"
        result_lines = [header]
        for lineno, line in matches:
            result_lines.append(f"Line {lineno}: {line.rstrip()}")
        return "\n".join(result_lines)
    except Exception as e:
        return f"ERROR: searching file {path}: {str(e)}"

@register_tool("read_lines")
def read_lines(workspace: Path, path: str, start_line: int, end_line: int) -> str:
    """Read a specific line range from a file (1-indexed, inclusive).
    Always returns a header with path, requested range, and total file line count
    so the agent knows exactly where it is in the file.
    No truncation — the full requested range is always returned.
    """
    try:
        target = resolve_agent_path(workspace, path)
        if not target.exists():
            return f"ERROR: File not found: {path}"

        lines = target.read_text(encoding="utf-8").splitlines()
        total_lines = len(lines)

        if start_line < 1:
            start_line = 1
        if end_line > total_lines:
            end_line = total_lines
        if start_line > end_line:
            return f"ERROR: start_line ({start_line}) cannot be greater than end_line ({end_line})."

        numbered = [f"L{i+1}: {lines[i]}" for i in range(start_line - 1, end_line)]
        header = f"FILE: {path} [lines {start_line}–{end_line} of {total_lines} total]"
        return header + "\n" + "\n".join(numbered)
    except Exception as e:
        return f"ERROR: reading lines from {path}: {str(e)}"

@register_tool("list_files")
def list_files(workspace: Path, path: str = ".") -> str:
    """
    List all files in the given directory recursively.
    Each entry shows: relative path, file size (KB), and line count.
    This lets the agent immediately know which files are large (need read_lines)
    vs small (safe to read_file in full) without making an extra tool call.
    """
    try:
        target_dir = resolve_agent_path(workspace, path)
        if not target_dir.exists() or not target_dir.is_dir():
            return f"ERROR: Directory not found: {path}"
        is_scratch_listing = normalize_rel_path(path).startswith("scratch:")

        entries = []
        for p in sorted(target_dir.rglob("*")):
            if not p.is_file():
                continue
            if p.name.startswith(".env") or p.suffix.lower() in DISCOVERY_IGNORED_FILE_SUFFIXES:
                continue
            rel_parts = p.relative_to(target_dir).parts
            if any(part in DISCOVERY_IGNORED_DIRS for part in rel_parts):
                continue

            rel_path = str(p.relative_to(target_dir)).replace("\\", "/")
            if is_scratch_listing:
                rel_path = f"scratch:{rel_path}"

            size_bytes = p.stat().st_size
            size_kb = size_bytes / 1024

            # Count lines cheaply — only for text files under 2 MB
            line_count = ""
            if size_bytes < 2_000_000 and p.suffix.lower() not in {
                ".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf",
                ".zip", ".woff", ".woff2", ".ttf", ".eot",
            }:
                try:
                    lines = p.read_bytes().count(b"\n") + 1
                    line_count = f" {lines}L"
                except Exception:
                    pass

            if size_kb >= 1:
                size_label = f"{size_kb:.1f}KB"
            else:
                size_label = f"{size_bytes}B"

            entries.append(f"{rel_path}  [{size_label}{line_count}]")

        if not entries:
            return "No files found."
        return "\n".join(entries)
    except Exception as e:
        return f"ERROR: listing files in {path}: {str(e)}"

@register_tool("fetch_url")
def fetch_url(workspace: Path, url: str, max_chars: int = 20000) -> str:
    """
    Fetch the content of a URL and return it as plain text.
    Use this to:
    - Look up library documentation or changelogs
    - Check official API references (e.g. OpenAI model list, npm package info)
    - Read error explanations from Stack Overflow, GitHub issues, etc.

    Returns plain text (HTML tags stripped). Long pages are truncated tail-first.
    max_chars: maximum characters to return (default 20000, max 60000).
    """
    import urllib.request
    import urllib.error
    import re as _re

    url = (url or "").strip()
    if not url:
        return "ERROR: url is required."
    if not url.startswith(("http://", "https://")):
        return f"ERROR: URL must start with http:// or https://. Got: {url!r}"

    max_chars = max(1000, min(int(max_chars or 20000), 60000))

    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (nexcode-agent/1.0; +https://nexcode.dev)",
                "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
            },
        )
        with urllib.request.urlopen(req, timeout=12) as resp:
            raw = resp.read()
            content_type = resp.headers.get("Content-Type", "")

        # Detect encoding
        encoding = "utf-8"
        ct_match = _re.search(r"charset=([\w-]+)", content_type, _re.IGNORECASE)
        if ct_match:
            encoding = ct_match.group(1)
        try:
            text = raw.decode(encoding, errors="replace")
        except Exception:
            text = raw.decode("utf-8", errors="replace")

        # Strip HTML tags if it looks like HTML
        if "<html" in text.lower()[:500] or "<!doctype" in text.lower()[:200]:
            # Remove script/style blocks
            text = _re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", text, flags=_re.DOTALL | _re.IGNORECASE)
            # Remove all remaining tags
            text = _re.sub(r"<[^>]+>", " ", text)
            # Collapse whitespace
            text = _re.sub(r"[ \t]+", " ", text)
            text = _re.sub(r"\n{3,}", "\n\n", text)
            text = text.strip()

        if len(text) > max_chars:
            text = text[:max_chars] + f"\n\n... [truncated at {max_chars} chars — use a smaller range or a more specific URL]"

        return f"URL: {url}\n\n{text}"

    except urllib.error.HTTPError as e:
        return f"ERROR: HTTP {e.code} fetching {url}: {e.reason}"
    except urllib.error.URLError as e:
        return f"ERROR: Could not reach {url}: {e.reason}"
    except Exception as e:
        return f"ERROR: fetch_url failed for {url}: {e}"


@register_tool("web_search")
def web_search(workspace: Path, query: str, max_results: int = 6) -> str:
    """
    Search the web using DuckDuckGo and return the top results as plain text.

    Each result includes:
    - Title
    - URL  (pass to fetch_url for full content)
    - Snippet / body (a few sentences summarising the page)

    Use this to:
    - Look up library docs, error messages, CVEs, changelogs
    - Check whether a package/API name is valid or deprecated
    - Research an unfamiliar technology before giving advice

    Workflow:
      1. web_search("query") → see titles + snippets
      2. fetch_url(url)      → read the full page you care about

    max_results: number of results to return (default 6, max 12).
    """
    query = (query or "").strip()
    if not query:
        return "ERROR: query is required."

    max_results = max(1, min(int(max_results or 6), 12))

    # Auto-append current year for 'latest' or 'news' queries to fix DDG temporal bias
    import datetime
    current_year = str(datetime.datetime.now().year)
    low_query = query.lower()
    if ("news" in low_query or "latest" in low_query) and current_year not in low_query:
        query = f"{query} {current_year}"

    # ── Primary: ddgs library (best quality) ─────────────────────
    try:
        from ddgs import DDGS

        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(query, max_results=max_results):
                title = r.get("title", "").strip()
                href  = r.get("href", "").strip()
                body  = r.get("body", "").strip()
                results.append((title, href, body))

        if results:
            lines = [f'Web search results for: "{query}"\n']
            for i, (title, url, snippet) in enumerate(results, 1):
                lines.append(f"[{i}] {title}")
                lines.append(f"    URL: {url}")
                if snippet:
                    lines.append(f"    {snippet[:300]}")
                lines.append("")
            lines.append("Use fetch_url(url) to read the full content of any result above.")
            return "\n".join(lines)

    except ImportError:
        pass  # fall through to requests-based fallback
    except Exception as _ddg_err:
        pass  # DDG rate-limited or blocked — try fallback

    # ── Fallback: DuckDuckGo Instant Answer API (no key, basic results) ───────
    try:
        import requests as _req
        import json as _json
        import re as _re

        resp = _req.get(
            "https://api.duckduckgo.com/",
            params={
                "q": query,
                "format": "json",
                "no_redirect": "1",
                "no_html": "1",
                "skip_disambig": "1",
            },
            headers={"User-Agent": "nexcode-agent/1.0"},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        lines = [f'Web search results for: "{query}"\n']
        added = 0

        # Abstract (direct answer)
        abstract = (data.get("AbstractText") or "").strip()
        abstract_url = (data.get("AbstractURL") or "").strip()
        if abstract:
            lines.append(f"[1] {data.get('Heading', 'Answer')}")
            if abstract_url:
                lines.append(f"    URL: {abstract_url}")
            lines.append(f"    {abstract[:400]}")
            lines.append("")
            added += 1

        # Related topics
        for topic in data.get("RelatedTopics", []):
            if added >= max_results:
                break
            if isinstance(topic, dict) and topic.get("Text"):
                url = topic.get("FirstURL", "")
                text = topic.get("Text", "").strip()
                lines.append(f"[{added + 1}] {text[:120]}")
                if url:
                    lines.append(f"    URL: {url}")
                lines.append("")
                added += 1

        if added == 0:
            return (
                f'No instant results found for "{query}".\n'
                f"Tip: install duckduckgo-search for full web search: pip install duckduckgo-search"
            )

        lines.append("Use fetch_url(url) to read the full content of any result above.")
        lines.append("\nNote: For richer results run: pip install duckduckgo-search")
        return "\n".join(lines)

    except Exception as e:
        return (
            f'ERROR: web_search failed for "{query}": {e}\n'
            f"Tip: install duckduckgo-search: pip install duckduckgo-search"
        )


@register_tool("multi_read")
def multi_read(
    workspace: Path,
    paths: list[str],
    focus_terms: list[str] = None,
    context_lines: int = 30,
    max_windows: int = 8,
) -> str:
    """
    Read multiple files at once.
    Each file follows the same size-aware rule as read_file:
    - Small files (≤350 lines / 14 KB) → full numbered content.
    - Large files → first 80 + last 20 lines, total line count, and guidance to use read_lines.
    No silent truncation of any file content.
    """
    _BINARY_SUFFIXES = {'.png', '.jpg', '.jpeg', '.gif', '.ico', '.pdf', '.zip', '.woff', '.woff2', '.ttf', '.eot'}

    results = []
    for path in paths:
        try:
            target = resolve_agent_path(workspace, path)
            if not target.exists():
                results.append(f"ERROR: File not found: {path}")
                continue

            if target.suffix.lower() in _BINARY_SUFFIXES:
                results.append(f"--- FILE: {path} ---\n[Binary file — skipped]")
                continue

            content = target.read_text(encoding="utf-8", errors="replace")
            lines = content.splitlines()
            total_lines = len(lines)

            # ── Small file: full content ───────────────────────────────────────
            if total_lines <= _SMALL_FILE_LINE_LIMIT and len(content) <= _SMALL_FILE_CHAR_LIMIT:
                numbered = "\n".join(f"{i+1} | {line}" for i, line in enumerate(lines))
                results.append(f"--- FILE: {path} [{total_lines} lines] ---\n{numbered}")
                continue

            # ── Large file: preview + navigation guidance ──────────────────────
            head_n = min(80, total_lines)
            tail_start = max(head_n + 1, total_lines - 19)
            head = "\n".join(f"{i+1} | {lines[i]}" for i in range(head_n))
            tail = "\n".join(f"{i+1} | {lines[i]}" for i in range(tail_start - 1, total_lines))

            gap_note = ""
            if tail_start > head_n + 1:
                gap_note = f"\n... [{tail_start - head_n - 1} lines not shown — use read_lines to read them] ...\n"

            results.append(
                f"--- FILE: {path} [LARGE FILE: {total_lines} lines / {len(content):,} chars] ---\n"
                f"Use read_lines(\"{path}\", start_line, end_line) to read any specific section.\n\n"
                f"LINES 1–{head_n}:\n{head}\n"
                f"{gap_note}"
                f"LINES {tail_start}–{total_lines}:\n{tail}"
            )

        except Exception as e:
            results.append(f"ERROR: reading file {path}: {str(e)}")

    return "\n\n".join(results)

import fnmatch
import re


@register_tool("search_workspace")
def search_workspace(workspace: Path, query: str, top_k: int = 15) -> str:
    """
    Search the workspace index for files most relevant to a query.

    Returns a ranked list of file paths with metadata (exports, line count, summary).
    Use this tool when you need to discover which files are relevant before reading them.

    Works for ALL query types:
    - Targeted: "auth token validate" → direct keyword hits → ranked list
    - Broad/vague: "explore my code find flaws" → AI expands to specific code terms
      → retries search with better terms → ranked list
    - If expansion also finds nothing → returns full index as last resort

    After calling this tool, use multi_read or read_file to inspect the files you care about.
    """
    try:
        from nexcode.agent_runtime.workspace_index import (
            build_or_update_index,
            format_index_summary,
            search_index,
        )

        index = build_or_update_index(workspace)
        top_k = max(1, min(int(top_k), 30))

        # --- Round 1: direct keyword search ---
        hits = search_index(index, query, top_k=top_k)
        if hits:
            return format_index_summary(index, relevant_files=hits, max_chars=6000)

        # --- Round 2: AI-powered query expansion ---
        # The query was too vague for keyword scoring. Use the same expander
        # that prompt_context.py uses to turn "explore my code for flaws" into
        # ["exception", "error handler", "validation", "middleware", "try except"]
        try:
            from nexcode.agent_runtime.prompt_context import expand_query_with_ai

            index_keys = [k for k in index.keys() if not k.startswith("_")]
            expanded_query = expand_query_with_ai(
                query=query,
                index_keys=index_keys,
            )

            if expanded_query and expanded_query.strip() != query.strip():
                hits = search_index(index, expanded_query, top_k=top_k)
                if hits:
                    return (
                        f"[Query expanded to: {expanded_query[:120]}]\n\n"
                        + format_index_summary(index, relevant_files=hits, max_chars=6000)
                    )
        except Exception:
            pass  # expansion failed — fall through to full index

        # --- Round 3: last resort — full index ---
        full_summary = format_index_summary(index, relevant_files=None, max_chars=6000)
        return (
            "No files matched even after query expansion. "
            "Returning full workspace index so you can orient yourself:\n\n"
            + full_summary
        )

    except Exception as e:
        return f"ERROR: search_workspace failed: {e}"



@register_tool("grep_search")
def grep_search(
    workspace: Path,
    query: str,
    path: str = ".",
    include_pattern: str = None,
    include_patterns: list[str] = None,
) -> str:
    """
    Search for a regex pattern across all files in a directory.

    include_pattern/include_patterns let the caller restrict which files are searched.
    This is intentionally lenient to match typical LLM tool-call shapes.
    """
    try:
        target_dir = resolve_agent_path(workspace, path)
        if not target_dir.exists() or not target_dir.is_dir():
            return f"ERROR: Directory not found: {path}"
        is_scratch_search = normalize_rel_path(path).startswith("scratch:")
            
        try:
            compiled = re.compile(query)
        except re.error:
            # Fallback to literal if bad regex
            compiled = re.compile(re.escape(query))
            
        results = []
        match_count = 0
        MAX_MATCHES = 100

        patterns: list[str] = []
        if include_pattern:
            patterns.append(str(include_pattern))
        if include_patterns:
            patterns.extend([str(p) for p in include_patterns if p])
        
        for p in target_dir.rglob("*"):
            if p.is_file():
                rel_parts = p.relative_to(target_dir).parts
                if (
                    not any(part in DISCOVERY_IGNORED_DIRS for part in rel_parts)
                    and not p.name.startswith(".env")
                    and p.suffix.lower() not in DISCOVERY_IGNORED_FILE_SUFFIXES
                ):
                    rel_path = str(p.relative_to(target_dir)).replace('\\', '/')
                    if is_scratch_search:
                        rel_path = f"scratch:{rel_path}"
                    if patterns and not any(
                        fnmatch.fnmatch(rel_path, pat) or fnmatch.fnmatch(p.name, pat)
                        for pat in patterns
                    ):
                        continue
                    try:
                        content = p.read_text(encoding="utf-8", errors="ignore")
                        for i, line in enumerate(content.splitlines(), 1):
                            if compiled.search(line) or query in line:
                                results.append(f"{rel_path}:{i}: {line.strip()}")
                                match_count += 1
                                if match_count >= MAX_MATCHES:
                                    return "\n".join(results) + f"\n...[TRUNCATED: Stopped after {MAX_MATCHES} matches]..."
                    except Exception:
                        pass
        if not results:
            return f"No matches found for '{query}' in {path}."
        return "\n".join(results)
    except Exception as e:
        return f"ERROR: grep_search in {path}: {str(e)}"
