"""
ast_tools.py — Semantic dependency tracing for Nexcode Agent
"""
import ast
import os
import re
from pathlib import Path

from nexcode.agent_runtime.tool_registry import register_tool
from nexcode.agent_runtime.workspace import resolve_agent_path

def _parse_python_file(path: Path) -> ast.Module | None:
    try:
        content = path.read_text(encoding="utf-8")
        return ast.parse(content, filename=str(path))
    except Exception:
        return None

def _get_call_name(node: ast.Call) -> str | None:
    if isinstance(node.func, ast.Name):
        return node.func.id
    elif isinstance(node.func, ast.Attribute):
        return node.func.attr
    return None

def _format_result(path: Path, workspace: Path, line_no: int, code_excerpt: str) -> str:
    rel_path = path.relative_to(workspace).as_posix()
    return f"File: {rel_path}\nLine: {line_no}\nContext: {code_excerpt.strip()}\n"

@register_tool("find_callers")
def find_callers(workspace: Path, target_symbol: str) -> str:
    """Finds all direct callers or usages of a target function/class symbol across the workspace."""
    results = []
    
    # Pre-compile a loose regex for non-Python fallback
    fallback_regex = re.compile(rf"\b{re.escape(target_symbol)}\s*\(")
    
    for root, _, files in os.walk(workspace):
        if ".git" in root or "__pycache__" in root or "node_modules" in root or "venv" in root:
            continue
            
        for file in files:
            file_path = Path(root) / file
            if file.endswith(".py"):
                tree = _parse_python_file(file_path)
                if not tree:
                    continue
                # Traverse AST to find function calls matching target_symbol
                try:
                    lines = file_path.read_text(encoding="utf-8").splitlines()
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Call):
                            call_name = _get_call_name(node)
                            if call_name == target_symbol:
                                line = node.lineno
                                snippet = lines[line-1] if line <= len(lines) else ""
                                results.append(_format_result(file_path, workspace, line, snippet))
                except Exception:
                    pass
            elif file.endswith((".ts", ".js", ".go", ".java", ".c", ".cpp")):
                # Fallback purely text-based rigorous matching for other languages
                try:
                    lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                    for i, line in enumerate(lines, 1):
                        if fallback_regex.search(line):
                            results.append(_format_result(file_path, workspace, i, line))
                except Exception:
                    pass

    if not results:
        return f"No callers found for '{target_symbol}' in the workspace."
    
    output = f"Found {len(results)} references to '{target_symbol}':\n\n"
    output += "\n".join(results)
    return output

@register_tool("find_definition")
def find_definition(workspace: Path, target_symbol: str) -> str:
    """Finds the file and exact line where a class or function is defined."""
    results = []
    
    # Pre-compile loose regex for definition patterns
    regexes = [
        re.compile(rf"^\s*(?:async\s+)?(?:export\s+)?(?:class|function|def|func)\s+{re.escape(target_symbol)}\b"),
        re.compile(rf"^\s*(?:export\s+)?(?:const|let|var)\s+{re.escape(target_symbol)}\s*=\s*(?:async\s+)?(?:\([^)]*\)\s*=>|function)"),
    ]
    
    for root, _, files in os.walk(workspace):
        if ".git" in root or "__pycache__" in root or "node_modules" in root or "venv" in root:
            continue
            
        for file in files:
            file_path = Path(root) / file
            if file.endswith(".py"):
                tree = _parse_python_file(file_path)
                if not tree:
                    continue
                try:
                    lines = file_path.read_text(encoding="utf-8").splitlines()
                    for node in ast.walk(tree):
                        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                            if node.name == target_symbol:
                                line = node.lineno
                                snippet = lines[line-1] if line <= len(lines) else ""
                                results.append(_format_result(file_path, workspace, line, snippet))
                except Exception:
                    pass
            elif file.endswith((".ts", ".js", ".tsx", ".jsx", ".go", ".java", ".c", ".cpp")):
                try:
                    lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                    for i, line in enumerate(lines, 1):
                        if any(r.search(line) for r in regexes):
                            results.append(_format_result(file_path, workspace, i, line))
                except Exception:
                    pass

    if not results:
        return f"Could not find definition for '{target_symbol}'."
    
    output = f"Found definition for '{target_symbol}':\n\n"
    output += "\n".join(results)
    return output
