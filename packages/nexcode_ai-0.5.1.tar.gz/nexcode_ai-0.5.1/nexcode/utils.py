"""
utils.py - Terminal helpers: banner, help table, and misc utilities.
"""

from rich import box
from rich.console import Console
from rich.table import Table

from nexcode import __version__
from nexcode.config import HOME_DIR

console = Console(force_terminal=True, highlight=False)

_LOGO = r"""
  _   _                      _
 | \ | |                    | |
 |  \| | _____  ___ ___   __| | ___
 | . ` |/ _ \ \/ / __/ _ \ / _` |/ _ \
 | |\  |  __/>  < (_| (_) | (_| |  __/
 |_| \_|\___/_/\_\___\___/ \__,_|\___|
"""


def print_banner() -> None:
    """Print the Nexcode banner."""
    console.print(f"[bold cyan]{_LOGO}[/bold cyan]")
    console.print(f"  [dim]Autonomous AI Agent[/dim]  [bold white]v{__version__}[/bold white]\n")


def print_help() -> None:
    """Print styled help table."""
    print_banner()

    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
        expand=False,
        min_width=70,
    )
    table.add_column("Command", style="bold white", no_wrap=True)
    table.add_column("Description", style="white")

    table.add_row("nexcode login grok", "Configure xAI Grok API key (one-time)")
    table.add_row("nexcode login gemini", "Configure Google Gemini API key (one-time)")
    table.add_row("nexcode switch grok", "Switch active provider to Grok")
    table.add_row("nexcode switch gemini", "Switch active provider to Gemini")
    table.add_row("nexcode config show", "Show current provider, model & all settings")
    table.add_row("nexcode config model <name>", "Change model for active provider")
    table.add_row("nexcode agent [message]", "Start the workspace agent or send it a prompt")
    table.add_row("nexcode agent --reset", "Reset current workspace context without deleting history")
    table.add_row("nexcode agent resume", "Resume the current workspace plan")
    table.add_row("nexcode version", "Show version info")

    console.print(table)
    console.print()

    from nexcode.config import load_full_access

    try:
        full = load_full_access()
        active = full.get("active", "grok")
        active_model = full.get(active, {}).get("model", "")
        grok_ok = bool(full.get("grok", {}).get("api_key", ""))
        gemini_ok = bool(full.get("gemini", {}).get("api_key", ""))

        grok_icon = "[green]✓[/green]" if grok_ok else "[red]✗[/red]"
        gemini_icon = "[green]✓[/green]" if gemini_ok else "[red]✗[/red]"

        console.print(
            f"  {grok_icon} Grok  {gemini_icon} Gemini  |  "
            f"Active: [bold cyan]{active}[/bold cyan]  model=[cyan]{active_model}[/cyan]"
        )
    except Exception:
        console.print(
            "  [red]Not configured[/red] - run [cyan]nexcode login grok[/cyan] "
            "or [cyan]nexcode login gemini[/cyan]"
        )

    console.print(f"  [dim]Config: {HOME_DIR}[/dim]")
    console.print()


def print_version() -> None:
    """Print version info."""
    console.print(f"nexcode [bold cyan]v{__version__}[/bold cyan]")


def generate_diff(filename: str, old_text: str, new_text: str) -> str:
    """Generate a unified diff between two strings."""
    import difflib
    old_lines = old_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    diff = difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}"
    )
    return "".join(diff)
