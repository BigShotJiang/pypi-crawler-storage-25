import importlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .a2a_client import A2AClient
    from .classification_client import ClassificationClient
    from .consul_client import ConsulClient
    from .graph_db_client import GraphDBClient
    from .langfuse_client import LangfuseClient
    from .langfuse.dataset_client import DatasetClient
    from .langfuse.prompt_client import PromptClient
    from .langfuse.score_evaluation_client import EvaluationClient
    from .langfuse.tracing_client import TracingClient
    from .llm_client import LLMClient
    from .ocr_client import OCRClient
    from .paperless_client import PaperlessClient
    from .text_cleaner_client import TextCleanerClient
    from .tool_registry_client import ToolRegistryClient
    from .vector_client import VectorClient

def __getattr__(name: str):
    """Lazy import clients to avoid pulling in heavy dependencies when not needed."""
    if name == "A2AClient":
        return importlib.import_module(".a2a_client", __name__).A2AClient
    elif name == "ClassificationClient":
        return importlib.import_module(".classification_client", __name__).ClassificationClient
    elif name == "ConsulClient":
        return importlib.import_module(".consul_client", __name__).ConsulClient
    elif name == "GraphDBClient":
        return importlib.import_module(".graph_db_client", __name__).GraphDBClient
    elif name == "LangfuseClient":
        return importlib.import_module(".langfuse_client", __name__).LangfuseClient
    elif name == "DatasetClient":
        return importlib.import_module(".langfuse.dataset_client", __name__).DatasetClient
    elif name == "PromptClient":
        return importlib.import_module(".langfuse.prompt_client", __name__).PromptClient
    elif name == "EvaluationClient":
        return importlib.import_module(".langfuse.score_evaluation_client", __name__).EvaluationClient
    elif name == "TracingClient":
        return importlib.import_module(".langfuse.tracing_client", __name__).TracingClient
    elif name == "LLMClient":
        return importlib.import_module(".llm_client", __name__).LLMClient
    elif name == "OCRClient":
        return importlib.import_module(".ocr_client", __name__).OCRClient
    elif name == "PaperlessClient":
        return importlib.import_module(".paperless_client", __name__).PaperlessClient
    elif name == "TextCleanerClient":
        return importlib.import_module(".text_cleaner_client", __name__).TextCleanerClient
    elif name == "ToolRegistryClient":
        return importlib.import_module(".tool_registry_client", __name__).ToolRegistryClient
    elif name == "VectorClient":
        return importlib.import_module(".vector_client", __name__).VectorClient
    else:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

__all__ = [
    "A2AClient",
    "ClassificationClient", 
    "ConsulClient",
    "GraphDBClient",
    "LangfuseClient",
    "DatasetClient",
    "PromptClient",
    "EvaluationClient",
    "TracingClient",
    "LLMClient",
    "OCRClient",
    "PaperlessClient",
    "TextCleanerClient",
    "ToolRegistryClient",
    "VectorClient"
]