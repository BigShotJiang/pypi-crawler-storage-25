from temporalio.worker import Worker
from temporalio.worker import Worker, UnsandboxedWorkflowRunner # 🚀 Import this
from guardianhub.config.settings import settings
from temporalio.contrib.opentelemetry import TracingInterceptor # 👈 CRITICAL IMPORT

class MuscleFactory:
    """
    Utilities to turn a Brain into a Worker.
    The Agent Service calls this to get a pre-configured Temporal Worker.
    """

    @staticmethod
    def create_worker(temporal_client, agent_instance) -> Worker:
        """
        Assembles the worker using:
        1. The Global SDK Skeleton (Mission Governance)
        2. The Agent's Internal Workflows (Tactical Intervention)
        3. The Fused Muscle Activities (Domain Tools)
        """

        # 🚀 THE HARVEST:
        # SpecialistBase.get_workflows() now returns [SpecialistMissionWorkflow, AgentChildWorkflow]
        workflows = agent_instance.get_workflows()
        activities = agent_instance.get_activities()

        return Worker(
            temporal_client,
            task_queue=settings.temporal.task_queue,
            workflows=workflows,
            activities=activities,
            workflow_runner=UnsandboxedWorkflowRunner(),
            interceptors=[TracingInterceptor()]  # 👈 THIS OPENS THE ENVELOPE
        )