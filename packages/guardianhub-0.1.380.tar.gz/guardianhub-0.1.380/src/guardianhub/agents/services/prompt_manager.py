import re
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from langfuse import Langfuse

from guardianhub import get_logger

LOGGER = get_logger(__name__)


class SovereignPromptRegistry:
    def __init__(self, langfuse_client: Langfuse):
        self.client = langfuse_client
        self.locked_regex = r"[A-Z]{5}[0-9]{4}[A-Z]{1}"

    # Inside SovereignPromptRegistry
    def _get_raw_template(self, name: str) -> Optional[Any]:
        LOGGER.debug(f"[PROMPT] Attempting: '{name}'")
        try:
            result = self.client.get_prompt(name, label="production")
            LOGGER.debug(f"[PROMPT] ✓ Found: '{name}'")
            return result
        except Exception:
            LOGGER.debug(f"[PROMPT] ✗ Not found: '{name}'")
            if not name.endswith(".md"):
                try:
                    md_name = f"{name}.md"
                    LOGGER.debug(f"[PROMPT] Fallback: '{md_name}'")
                    result = self.client.get_prompt(md_name, label="production")
                    LOGGER.debug(f"[PROMPT] ✓ Fallback success: '{md_name}'")
                    return result
                except Exception:
                    LOGGER.debug(f"[PROMPT] ✗ Fallback failed: '{md_name}'")
            return None

    def _sanitize_user_id(self, user_id: str) -> str:
        """Convert email to slug-safe format."""
        sanitized = user_id.lower()
        sanitized = re.sub(r'[@.]', '-', sanitized)
        return re.sub(r'[^a-z0-9-_]', '', sanitized)

    def get_mission_prompt(self,
                           task_key: str,
                           user_id: str,
                           agent_id: str,
                           context_vars: Dict[str, Any],  # 🎯 FACTS passed from Node
                           mission_template_id: Optional[str] = None) -> str:

        # 🎯 THE BASELINE TRUTH: System-wide variables that every prompt can use
        global_context = {
            "org_name": "YantramOps Sovereign",
            "current_date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "system_version": "Yantram_OS_v1.5",
            "user_id": user_id
        }
        merged_facts = {**global_context, **context_vars}


        # --- LAYER 1: The Sovereign Foundation ---
        base_dna = self._get_raw_template("templates/yantram-ops-dna-v1")
        # Compile base DNA (usually static, but good to have context)
        base_dna_str = base_dna.compile(**context_vars) if base_dna else ""

        # --- LAYER 2: The User Identity ---
        if user_id is None:
            LOGGER.warning(f"⚠️ [PROMPT] user_id is None, using default-user")
            persona_path = "templates/default-user"
        else:
            safe_user = self._sanitize_user_id(user_id)
            persona_path = f"templates/user-{safe_user}"
            LOGGER.debug(f"[PROMPT] User lookup: '{persona_path}' (from '{user_id}')")
        user_persona = self._get_raw_template(persona_path)
        if user_persona:
            LOGGER.info(f"✅ [PROMPT] Loaded persona: '{persona_path}'")
        else:
            LOGGER.warning(f"⚠️ [PROMPT] No persona: '{persona_path}'")

        user_persona_str = user_persona.compile(**context_vars) if user_persona else ""

        # --- LAYER 3 & 4: TASK RESOLUTION ---
        LOGGER.debug(f"[PROMPT] Resolving: key='{task_key}', agent='{agent_id}', template_id='{mission_template_id}'")
        
        attempted_paths = []
        task_prompt_obj = None
        
        # Only try template path if mission_template_id is provided
        if mission_template_id:
            path = f"templates/{mission_template_id}/{task_key}"
            attempted_paths.append(path)
            task_prompt_obj = self._get_raw_template(path)
        
        if not task_prompt_obj:
            path = f"agents/{agent_id}/{task_key}"
            attempted_paths.append(path)
            task_prompt_obj = self._get_raw_template(path)
        
        if not task_prompt_obj:
            for fallback in [f"core/{task_key}", f"core/{task_key}-v1", f"{task_key}.md"]:
                attempted_paths.append(fallback)
                task_prompt_obj = self._get_raw_template(fallback)
                if task_prompt_obj:
                    break

        if not task_prompt_obj:
            LOGGER.error(f"🚨 [PROMPT] No template for '{task_key}'. Tried: {attempted_paths}")
            return f"Error: No template found for {task_key}"

        # SovereignPromptRegistry.py -> get_mission_prompt

        # Add a specific check for evals to bypass the user/agent prefixing if needed
        if task_key.startswith("evals/"):
            task_prompt_obj = self._get_raw_template(task_key)
            if not task_prompt_obj:
                # Try without the -v1 suffix just in case
                task_prompt_obj = self._get_raw_template(task_key.split('-')[0])
        
        LOGGER.info(f"✅ [PROMPT] Resolved '{task_key}' after trying: {attempted_paths}")

        # 🚀 THE MAGIC: Use Langfuse native compile
        # This replaces {{proposal_data}}, {{user_department}}, etc.
        compiled_task_str = task_prompt_obj.compile(**merged_facts)
        domain_enforcement = self._resolve_dharma_enforcement(agent_id)

        # --- LAYER 5: THE DEEP MERGE & LOCKED DHARMA ---
        return f"""
{base_dna_str}

{user_persona_str}

# MISSION TASK: {task_key.upper()}
{compiled_task_str}

# FINAL DHARMA ENFORCEMENT (LOCKED)
{domain_enforcement}
"""

    def _resolve_dharma_enforcement(self, agent_id: str) -> str:
        """Determines the 'Hard Law' based on the agent's domain."""
        if "lead_gen" in agent_id:
            return """
- NO SPAM: Do not generate outreach that lacks 3 specific technical points from the prospect's profile.
- CONSENT: Do not store personal data for individuals who have explicitly opted out.
- TRUTH: Do not hallucinate case studies or features YantramOps does not physically possess.
"""
        # Default/Finance Dharma
        return f"- PII MASKING: All PAN numbers matching {self.locked_regex} MUST be masked."

    def verify_enforcement(self, final_output: str) -> bool:
        """
        The Narasimha Post-Process Check.
        Final verification that no raw PAN numbers escaped the masking policy.
        """
        if re.search(self.locked_regex, final_output):
            # In a real scenario, this would trigger an alert in Langfuse
            print("🚨 CRITICAL BREACH: Raw PII (PAN) detected in agent output!")
            return False
        return True