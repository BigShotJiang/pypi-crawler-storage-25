from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from enum import Enum
from ..registry.registry import register_model


class EvaluationMetric(str, Enum):
    """Standard evaluation metrics."""
    RELEVANCE = "relevance"
    GROUNDEDNESS = "groundedness"
    COHERENCE = "coherence"
    FLUENCY = "fluency"
    COMPLETENESS = "completeness"
    CORRECTNESS = "correctness"
    SAFETY = "safety"


# New model for structured LLM output
@register_model
class EvaluationScoresModel(BaseModel):
    """Pydantic model for the structured JSON output expected from the LLM."""
    relevance: float = Field(..., ge=0.0, le=1.0,
                             description="Score for how well the response addresses the query (0.0 to 1.0).")
    groundedness: float = Field(..., ge=0.0, le=1.0,
                                description="Score for whether the response is supported by the context (0.0 to 1.0).")
    coherence: float = Field(..., ge=0.0, le=1.0,
                             description="Score for the logical flow and consistency of the response (0.0 to 1.0).")
    fluency: float = Field(..., ge=0.0, le=1.0,
                           description="Score for the readability and grammatical correctness (0.0 to 1.0).")
    completeness: float = Field(..., ge=0.0, le=1.0,
                                description="Score for whether the response fully answers all parts of the query (0.0 to 1.0).")

    # Optional fields for other potential metrics, if the LLM supports them
    # correctness: Optional[float] = Field(None, ge=0.0, le=1.0, description="Factual accuracy score.")
    # safety: Optional[float] = Field(None, ge=0.0, le=1.0, description="Safety compliance score.")

class EvaluationErrorLevel(str, Enum):
    """Severity levels for evaluation errors."""
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@register_model
class EvaluationResult(BaseModel):
    """Container for evaluation results and metrics."""
    scores: Dict[EvaluationMetric, float] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    error_level: Optional[EvaluationErrorLevel] = None

    @property
    def overall_score(self) -> float:
        """Calculate an overall score from individual metrics."""
        if not self.scores:
            return 0.0
        return sum(self.scores.values()) / len(self.scores)

    def to_dict(self) -> Dict[str, Any]:
        """Convert the result to a dictionary."""
        return {
            "scores": {k.value: v for k, v in self.scores.items()},
            "overall_score": self.overall_score,
            "metadata": self.metadata,
            "error": self.error,
            "error_level": self.error_level.value if self.error_level else None
        }

# guardianhub/models/evaluation_models.py

@register_model
class AuditResult(BaseModel):
    """Krishna's Audit: Validating the Plan against the Law."""
    alignment_score: float = Field(..., ge=0.0, le=1.0)
    safety_status: str = Field(..., description="PASS or FAIL")
    reasoning: str
    optimized_suggestion: str

@register_model
class QualityResult(BaseModel):
    """Final Output Validation: Groundedness and Relevance."""
    answer_relevance_score: float = Field(..., ge=0.0, le=1.0)
    groundedness_score: float = Field(..., ge=0.0, le=1.0)
    reason: str


# 1. Specialized Lead Generation Evaluation
@register_model
class LeadQualityResult(BaseModel):
    """Evaluation specific to the Lead Generation specialist's output."""
    strategic_score: float = Field(..., ge=0.0, le=1.0, description="Relevance to sub_objective")
    faithfulness_score: float = Field(..., ge=0.0, le=1.0, description="Grounded in search hits")
    entity_name: Optional[str] = Field(None, description="The primary bank or company identified")
    detected_signals: List[str] = Field(default_factory=list, description="AI Privacy, Egress, etc.")
    reasoning: str

# 2. Infrastructure/Stack Validation
@register_model
class TechnicalHookResult(BaseModel):
    """Validation of how well Sutram aligns with the target stack."""
    compatibility_score: float = Field(..., ge=0.0, le=1.0)
    matched_tools: List[str] = Field(..., description="e.g., ['Temporal', 'K8s']")
    golden_question_quality: float = Field(..., ge=0.0, le=1.0)
    technical_rationale: str

# 3. The "Buddha State" Bounty Model (The Invoice Trigger)
@register_model
class BountyAttestation(BaseModel):
    """Attestation that a mission achieved a billable value event."""
    bounty_eligible: bool = Field(..., description="True if high-value insight is verified")
    event_type: str = Field(..., description="SPOF_FOUND, AUDIT_CLEAN_BILL, or LEAD_CONVERTED")
    estimated_value_inr: int = Field(..., description="The bottom-line value saved for the client")
    requested_bounty_inr: int = Field(..., description="The 1% to 5% success fee (The Pat)")
    lineage_proof_ids: List[str] = Field(..., description="References to the Graph nodes or search hits")
    attestation_statement: str

# 4. Safety & PII Audit
@register_model
class SafetyAuditResult(BaseModel):
    """Narasimha's PII and Compliance check."""
    pii_leak_found: bool
    violation_types: List[str] = Field(default_factory=list) # e.g. ["PAN_LEAK", "UNMASKED_EMAIL"]
    redaction_required: bool
    audit_log_id: str = Field(default_factory=lambda: f"AUD-{uuid.uuid4().hex[:6]}")