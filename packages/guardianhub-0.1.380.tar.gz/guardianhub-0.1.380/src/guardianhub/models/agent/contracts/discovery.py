# guardianhub_sdk/models/contracts/discovery.py
from typing import List,Dict,Any

from .base import SovereignBaseContract,SovereignBaseResponse
from pydantic import Field


# guardianhub_sdk/models/contracts/discovery.py

# guardianhub_sdk/models/contracts/discovery.py
from guardianhub.models.registry.registry import register_model

@register_model
class DiscoveryRequest(SovereignBaseContract):
    """The High-Level Recon Signature."""
    sub_objective: str = Field(..., description="The user's raw intent")

    # 🧭 MATSYA'S COMPASS (The Suggester)
    suggested_archetype: str = Field("GENERAL", description="ITSM, SCRAPE, MARKET, etc.")

    # 📡 MATSYA'S SIGNALS (The Fog Lifters)
    approved_keywords: List[str] = Field(default_factory=list)
    expected_signals: List[str] = Field(default_factory=list)

    # 🐢 KURMA'S ANCHORS (The Ground Truth)
    target_domains: List[str] = Field(default_factory=list, description="Validated Infrastructure Targets")
    environment: str = Field("prod", description="Target Realm")

    depth_limit: int = Field(5, description="Max depth for graph/web traversal")


# guardianhub_sdk/models/contracts/discovery.py

class DiscoveryResponse(SovereignBaseResponse):
    """The full 'Satya' (Truth) captured during Recon."""
    facts: List[Dict[str, Any]] = Field(default_factory=list, description="Hard evidence found")
    beliefs: List[Dict[str, Any]] = Field(default_factory=list, description="LLM-inferred context")
    episodes: List[Dict[str, Any]] = Field(default_factory=list, description="Relevant past memories")

    # 🐢 KURMA'S INFRASTRUCTURE VERIFICATION
    # Tracks if target_domains are actually reachable/healthy
    infrastructure_map: Dict[str, str] = Field(
        default_factory=dict,
        description="Domain health status (e.g., {'simsmetal.co.nz': 'REACHABLE'})"
    )

    # 📡 MATSYA'S ALIGNMENT SCORE
    # How many of the 'expected_signals' were actually spotted in the fog?
    signal_attainment: float = Field(0.0, description="Percentage of expected signals found (0.0 to 1.0)")

    # 🛡️ SOVEREIGN SUITABILITY
    # A quick flag for the Orchestrator: Is the Specialist actually capable of this?
    is_specialist_aligned: bool = Field(True, description="False if the recon suggests a different archetype is needed")

    @property
    def total_count(self) -> int:
        return len(self.facts) + len(self.beliefs) + len(self.episodes)

    @property
    def is_ground_truth_stable(self) -> bool:
        """Returns True if Kurma verified the infrastructure."""
        return all(status == "REACHABLE" for status in self.infrastructure_map.values())

    # We can add helper properties here
    @property
    def total_intelligence_count(self) -> int:
        return len(self.facts) + len(self.beliefs) + len(self.episodes)