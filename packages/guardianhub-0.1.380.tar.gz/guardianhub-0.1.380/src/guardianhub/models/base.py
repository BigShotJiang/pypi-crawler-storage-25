from pydantic import BaseModel
from typing import Dict, Any, List


class SovereignModel(BaseModel):
    """Base Model with Automatic Intelligence Promotion."""

    def get_tactical_promotions(self) -> Dict[str, Any]:
        promotions = {}
        model_dict = self.model_dump()

        for field_name, value in model_dict.items():
            if isinstance(value, list) and value:
                promotions["active_list"] = value

                # 🚀 REFINEMENT: If it's a list of dicts (like search results),
                # extract 'content' or 'text' for the blob.
                if isinstance(value[0], dict):
                    promotions["active_blob"] = "\n---\n".join([
                        str(item.get("content") or item.get("text") or item)
                        for item in value
                    ])
                else:
                    promotions["active_blob"] = "\n".join([str(i) for i in value])

                if len(value) == 1:
                    # If it's a dict, use the first string value found or the whole dict
                    promotions["primary_target"] = value[0] if not isinstance(value[0], dict) else str(value[0])

        return promotions