import base64
from typing import Any, Optional, Union, Tuple
import os

# 1. SDK Check (Brain/Muscle Separation)
try:
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    HAS_OTEL_SDK = True
except ImportError:
    HAS_OTEL_SDK = False

from opentelemetry import trace, metrics
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.baggage.propagation import W3CBaggagePropagator
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

from guardianhub.config.settings import settings
from guardianhub import get_logger
from guardianhub.observability.otel_middlewares import SovereignContextProcessor
from guardianhub.observability.span_filters import InfrastructureTraceFilter
from guardianhub.observability.filtering_exporter import FilteringSpanExporter

from opentelemetry import baggage as otel_baggage, context as otel_context

logger = get_logger(__name__)


def _fastapi_request_hook(span, scope: dict[str, Any]) -> None:
    """
    Principled Hook: Only stamps attributes for visibility.
    Does NOT attempt to manage context (leave that to the Middleware).
    """
    if not span or not scope:
        return

    # 1. Physical Header Extraction for Span Tagging only
    headers = {k.decode("utf-8").lower(): v.decode("utf-8")
               for k, v in scope.get("headers", [])}

    user_id = headers.get("x-user-email") or headers.get("x-user-id")
    tenant_id = headers.get("x-tenant-id")
    session_id = headers.get("x-conversation-id") or headers.get("x-session-id")

    # 2. Stamp the Span (This ensures the metadata appears in Langfuse immediately)
    if user_id:
        span.set_attribute("langfuse.user.id", str(user_id))
    if session_id:
        span.set_attribute("langfuse.session.id", str(session_id))
    if tenant_id:
        span.set_attribute("ctx.tenant_id", str(tenant_id))
        span.set_attribute("langfuse.trace.metadata.tenant", str(tenant_id))

    logger.debug(f"FastAPI Hook: Stamped attributes for tenant={tenant_id}")

def configure_instrumentation(
    app,
    enable_console_export: bool = False,
    excluded_urls: str = "/health,/metrics,/portrait,/ensure,/api/v1/mission-control/lineage,/query-cypher",
    httpx_excluded_urls: Union[str, Tuple[str, ...]] = "/health,/metrics,/portrait,vectordb.guardianhub.com,graphdb.guardianhub.com",
) -> None:
    # 1️⃣ Setup Global Propagation (Crucial: Works even without SDK)
    set_global_textmap(CompositePropagator([
        TraceContextTextMapPropagator(),
        W3CBaggagePropagator()
    ]))
    logger.info("Configured Global Composite Propagator (TraceContext + Baggage)")

    if not HAS_OTEL_SDK:
        logger.warning("OpenTelemetry SDK not found. Running in Propagation-Only mode.")
        return

    # 2️⃣ Setup Resource and Tracer Provider
    otlp_endpoint = settings.endpoints.get("LANGFUSE_HOST")
    logger.debug(
        f"Setting up OpenTelemetry tracer provider: service_name={settings.service.name}, "
        f"environment={settings.endpoints.ENVIRONMENT}, service_version={settings.service.version}, "
        f"otlp_endpoint={otlp_endpoint}"
    )
    
    resource = Resource.create({
        "service.name": settings.service.name,
        "deployment.environment": settings.endpoints.ENVIRONMENT,
        "service.version": settings.service.version,
    })

    logger.info(
        f"Created OpenTelemetry resource: service_name={settings.service.name}, "
        f"environment={settings.endpoints.ENVIRONMENT}, version={settings.service.version}"
    )

    tracer_provider = TracerProvider(resource=resource)

    # 3️⃣ Register Sovereign Processor (The Tenant Mapping)
    tracer_provider.add_span_processor(SovereignContextProcessor())
    logger.debug("Registered SovereignContextProcessor for tenant-aware tracing")

    # 3️⃣.5 Register Infrastructure Filter (Suppress noisy health/ensure spans)
    tracer_provider.add_span_processor(InfrastructureTraceFilter())
    logger.debug("Registered InfrastructureTraceFilter to suppress noisy spans")

    # 4️⃣ Configure OTLP Trace Exporter WITH Resilient Timeout
    if otlp_endpoint:
        logger.debug(f"Configuring OTLP trace exporter: endpoint={otlp_endpoint}")
        
        # Use getattr to avoid the AttributeError if Pydantic hasn't mapped them to the root
        pk = getattr(settings.credentials, "LANGFUSE_PUBLIC_KEY", os.getenv("LANGFUSE_PUBLIC_KEY"))
        sk = getattr(settings.credentials, "LANGFUSE_SECRET_KEY", os.getenv("LANGFUSE_SECRET_KEY"))

        logger.debug(
            f"Retrieved Langfuse credentials: has_public_key={bool(pk)}, "
            f"has_secret_key={bool(sk)}, public_key_prefix={pk[:10] + '...' if pk else None}"
        )

        if not pk or not sk:
            logger.error(
                f"❌ OTLP Auth failed: Keys not found in settings or environment. "
                f"has_public_key={bool(pk)}, has_secret_key={bool(sk)}, "
                f"LANGFUSE_PUBLIC_KEY_env={bool(os.getenv('LANGFUSE_PUBLIC_KEY'))}, "
                f"LANGFUSE_SECRET_KEY_env={bool(os.getenv('LANGFUSE_SECRET_KEY'))}"
            )
            return

        # 1. Prepare Headers
        auth_str = f"{pk}:{sk}"
        encoded_auth = base64.b64encode(auth_str.encode()).decode()

        project_id = getattr(settings.credentials, "LANGFUSE_PROJECT_ID", os.getenv("LANGFUSE_PROJECT_ID"))
        logger.debug(
            f"Prepared authentication headers: has_project_id={bool(project_id)}, "
            f"project_id={project_id[:10] + '...' if project_id else None}"
        )

        # 2. Use the BASE bridge URL (The SDK will append /v1/traces)
        # If your SDK version DOES NOT append it, use the full path.
        # But usually, providing the base /otel/ path is safer.
        base_otel_endpoint = f"{settings.endpoints.LANGFUSE_HOST}/api/public/otel/v1/traces"
        logger.debug(
            f"Constructed OTLP endpoint: base_endpoint={base_otel_endpoint}, "
            f"langfuse_host={settings.endpoints.LANGFUSE_HOST}"
        )

        trace_exporter = OTLPSpanExporter(
            endpoint=base_otel_endpoint,
            headers={
                "Authorization": f"Basic {encoded_auth}",
                "x-langfuse-project-id": project_id  # <--- CRITICAL ADDITION
            },
            timeout=10  # Give it time to breathe
        )

        logger.debug(
            f"Created OTLP span exporter: endpoint={base_otel_endpoint}, "
            f"timeout=10, has_auth=True, has_project_id={bool(project_id)}"
        )

        # Use BatchSpanProcessor with filtering wrapper
        filtering_exporter = FilteringSpanExporter(trace_exporter)
        tracer_provider.add_span_processor(BatchSpanProcessor(filtering_exporter))
        logger.info(
            f"Traces exported to: {otlp_endpoint}/api/public/otel (Auth Enabled), "
            f"endpoint={otlp_endpoint}/api/public/otel, exporter_type=BatchSpanProcessor, auth_enabled=True"
        )
    else:
        logger.warning(
            f"No OTLP endpoint configured - traces will not be exported, "
            f"langfuse_host={settings.endpoints.get('LANGFUSE_HOST')}"
        )

    trace.set_tracer_provider(tracer_provider)

    # 5️⃣ Instrument FastAPI & HTTPX
    FastAPIInstrumentor.instrument_app(
        app=app,
        tracer_provider=tracer_provider,
        excluded_urls=excluded_urls,
        server_request_hook=_fastapi_request_hook,
        http_capture_headers_server_request=["user-agent", "content-type", "x-tenant-id","x-user-email"],
        http_capture_headers_server_response=["content-type"]
    )

    excluded_urls_param = ",".join(httpx_excluded_urls) if isinstance(httpx_excluded_urls, tuple) else httpx_excluded_urls
    HTTPXClientInstrumentor().instrument(
        excluded_urls=excluded_urls_param,
        tracer_provider=tracer_provider
    )

    logger.info("Instrumentation complete: Tenant-Aware and Langfuse-Ready.")