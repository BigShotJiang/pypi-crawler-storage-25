from typing import Optional, Dict, Any
from opentelemetry import baggage, context, trace
from opentelemetry.trace import SpanContext, TraceFlags

def build_sovereign_context(
    baggage_items: Dict[str, Any],
    trace_id_hex: Optional[str] = None,
    base_ctx: Optional[context.Context] = None
) -> context.Context:
    """
    The Master Builder: Creates an immutable OTel context chain.
    """
    # 1. Start with provided context or clean slate
    ctx = base_ctx or context.Context()

    # 2. 🔗 Lazarus Logic: Stitch Trace Lineage if trace_id is provided
    if trace_id_hex:
        # Reconstruct parent identity
        span_context = SpanContext(
            trace_id=int(trace_id_hex, 16),
            span_id=trace.get_current_span().get_span_context().span_id or 0, 
            is_remote=True,
            trace_flags=TraceFlags(TraceFlags.SAMPLED)
        )
        # Inject virtual span into the chain
        ctx = trace.set_span_in_context(trace.NonRecordingSpan(span_context), context=ctx)

    # 3. 🎒 Baggage Chain
    for key, value in baggage_items.items():
        if value:
            # Re-assign to build the immutable chain
            ctx = baggage.set_value(key, str(value), context=ctx)

    return ctx

def set_baggage_context(baggage_items: Dict[str, Any], current_ctx: Optional[context.Context] = None) -> context.Token:
    """Attaches identity baggage to the current execution thread."""
    ctx = build_sovereign_context(baggage_items, base_ctx=current_ctx or context.get_current())
    return context.attach(ctx)

def reconstitute_trace_context(trace_id_hex: str, baggage_items: Dict[str, Any]) -> context.Context:
    """Helper for /resume logic to rebuild a trace from Postgres state."""
    return build_sovereign_context(baggage_items, trace_id_hex=trace_id_hex)