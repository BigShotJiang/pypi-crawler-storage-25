"""Filter span processor to suppress noisy infrastructure traces."""
from typing import Optional
from opentelemetry.sdk.trace import SpanProcessor, ReadableSpan
from opentelemetry.trace import SpanContext

from guardianhub import get_logger

LOGGER = get_logger(__name__)


class InfrastructureTraceFilter(SpanProcessor):
    """Drops infrastructure/health check spans to reduce noise in Langfuse."""
    
    # URL patterns to suppress
    SUPPRESSED_PATTERNS = [
        "/ensure",  # VectorDB ensure collection
        "/query-cypher",  # Neo4j queries
        "/health",  # Health checks
        "/ready",   # Readiness probes
        "/alive",   # Liveness probes
        ".svc.cluster.local",  # Internal K8s calls
        "/api/public/ingestion",  # Internal K8s calls
        "/api/public/projects",  # Internal K8s calls
        "/collections/",  # VectorDB collection operations
        "create_collection",  # Collection creation
        "init_collection",  # Collection initialization
    ]
    
    # Span names to suppress
    SUPPRESSED_NAMES = [
        "ensure_collection",
        "health_check",
        "ping",
        "create_collection",
        "init_collection",
        "setup_collection",
    ]
    
    def on_start(self, span: ReadableSpan, parent_context: Optional[SpanContext] = None) -> None:
        pass
    
    def on_end(self, span: ReadableSpan) -> None:
        """Check if span should be dropped before export."""
        # Check span name
        if any(name in span.name for name in self.SUPPRESSED_NAMES):
            LOGGER.debug(f"[SPAN_FILTER] Dropped by name: {span.name}")
            span._attributes = {}  # Clear attributes to mark as dropped
            return
        
        # Check URL in attributes
        url = span.attributes.get("http.url") or span.attributes.get("url.full") or ""
        if any(pattern in str(url) for pattern in self.SUPPRESSED_PATTERNS):
            LOGGER.debug(f"[SPAN_FILTER] Dropped by URL: {url[:80]}...")
            span._attributes = {}
            return
        
        # Check target
        target = span.attributes.get("http.target") or ""
        if any(pattern in str(target) for pattern in self.SUPPRESSED_PATTERNS):
            LOGGER.debug(f"[SPAN_FILTER] Dropped by target: {target}")
            span._attributes = {}
            return
        
        # Drop empty HTTP method spans (no URL attributes at all)
        http_methods = ["POST", "GET", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"]
        if span.name in http_methods and not url and not target:
            LOGGER.debug(f"[SPAN_FILTER] Dropped empty {span.name} span (no URL)")
            span._attributes = {}
            return
        
        # Log spans that pass through (for debugging mystery traces)
        if not url and not target:
            trace_id = format(span.get_span_context().trace_id, '032x')
            LOGGER.debug(f"[SPAN_FILTER] PASSED (no URL): name={span.name}, trace={trace_id[:16]}...")
        else:
            LOGGER.debug(f"[SPAN_FILTER] PASSED: name={span.name}, url={url[:60] if url else target[:60]}...")
    
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
    
    def shutdown(self) -> None:
        pass
