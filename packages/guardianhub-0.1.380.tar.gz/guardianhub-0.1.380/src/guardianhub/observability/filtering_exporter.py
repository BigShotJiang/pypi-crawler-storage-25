"""Filtering span exporter that drops noisy spans before export."""
from typing import Sequence
from opentelemetry.sdk.trace.export import SpanExporter, ReadableSpan
from guardianhub import get_logger

LOGGER = get_logger(__name__)


class FilteringSpanExporter(SpanExporter):
    """Wraps an exporter and drops spans matching filter criteria."""
    
    # URL patterns to suppress
    SUPPRESSED_PATTERNS = [
        "/ensure",
        "/query-cypher",
        "/health",
        "/ready",
        "/alive",
        ".svc.cluster.local",
        "/api/public/ingestion",
        "/api/public/v2/prompts",
        "/api/public/projects",
        "/collections/",
        "create_collection",
        "init_collection",
    ]
    
    # Span names to suppress
    SUPPRESSED_NAMES = [
        "ensure_collection",
        "health_check",
        "ping",
        "create_collection",
        "init_collection",
        "setup_collection",
    ]
    
    # HTTP methods that are empty (no URL)
    HTTP_METHODS = ["POST", "GET", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"]
    
    def __init__(self, wrapped_exporter: SpanExporter):
        self._wrapped = wrapped_exporter
    
    def export(self, spans: Sequence[ReadableSpan]) -> None:
        """Export only spans that pass the filter."""
        filtered_spans = []
        dropped_count = 0
        
        for span in spans:
            if self._should_drop(span):
                dropped_count += 1
            else:
                filtered_spans.append(span)
        
        if dropped_count > 0:
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropped {dropped_count} spans, exporting {len(filtered_spans)}")
        
        if filtered_spans:
            self._wrapped.export(filtered_spans)
    
    def _should_drop(self, span: ReadableSpan) -> bool:
        """Check if span should be dropped."""
        # Drop CORS preflight OPTIONS spans
        if span.name == "OPTIONS":
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropping CORS preflight OPTIONS span")
            return True
        
        # Check span name
        if any(name in span.name for name in self.SUPPRESSED_NAMES):
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropping by name: {span.name}")
            return True
        
        # Check URL in attributes
        url = span.attributes.get("http.url") or span.attributes.get("url.full") or ""
        if any(pattern in str(url) for pattern in self.SUPPRESSED_PATTERNS):
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropping by URL: {url[:80]}...")
            return True
        
        # Check target
        target = span.attributes.get("http.target") or ""
        if any(pattern in str(target) for pattern in self.SUPPRESSED_PATTERNS):
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropping by target: {target}")
            return True
        
        # Drop empty HTTP method spans (no URL attributes at all)
        if span.name in self.HTTP_METHODS and not url and not target:
            LOGGER.debug(f"[FILTERING_EXPORTER] Dropping empty {span.name} span (no URL)")
            return True
        
        return False
    
    def shutdown(self) -> None:
        self._wrapped.shutdown()
    
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._wrapped.force_flush(timeout_millis)
