from typing import Optional

from fastapi import Request
from opentelemetry import baggage, propagate, context
from opentelemetry.context import Context
from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.trace import Span

from guardianhub import get_logger

logger = get_logger(__name__)


from guardianhub.observability.context_utils import build_sovereign_context
from opentelemetry import propagate, context


async def sovereign_identity_middleware(request: Request, call_next):
    """
    SINGLE GATEKEEPER: The only place where raw HTTP reality is
    translated into Sovereign Telemetry.
    """
    # 1. 🛡️ PHYSICAL EXTRACTION
    identity_map = {
        "tenant_id": request.headers.get("X-Tenant-ID"),
        "user_id": request.headers.get("X-User-Email") or request.headers.get("X-User-ID"),
        "session_id": request.headers.get("X-Conversation-ID") or request.headers.get("X-Session-ID"),
        "access_token": request.headers.get("Authorization")
    }

    # 2. 🔗 LINEAGE LINKING
    # Extract standard W3C traceparent/baggage from headers
    parent_ctx = propagate.extract(request.headers)

    # 3. 🧠 SPIRIT WORLD BRIDGE
    # Use the utility to chain identity_map on top of parent_ctx
    ctx = build_sovereign_context(identity_map, base_ctx=parent_ctx)

    # 4. 🎯 ATTACH & EXECUTE
    token = context.attach(ctx)
    try:
        # Explicit debug log to confirm the 'Pipe' is loaded
        logger.debug(f"🧬 [IDENTITY_LOCKED] tenant={identity_map['tenant_id']}")
        return await call_next(request)
    finally:
        context.detach(token)


class SovereignContextProcessor(SpanProcessor):
    """
    Principled Observer: Stays 'dumb' to logic, only maps 'Spirit World' (OTel)
    values to 'Physical' attributes for Langfuse visibility.
    """
    PROPAGATION_KEYS = ("user_id", "tenant_id", "access_token", "mission_id", "session_id")

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        # 🎯 FIX 1: Use the parent_context explicitly if provided, fallback to current.
        # This is the "Immutable Link" principle.
        ctx = parent_context if parent_context is not None else context.get_current()

        # 🎯 FIX 2: Ensure we check standard baggage AND our promoted keys
        for key in self.PROPAGATION_KEYS:
            value = baggage.get_baggage(key, ctx)

            if value and value is not None:
                # Stamp generic OTel attribute
                span.set_attribute(f"ctx.{key}", str(value))

                # Map to Langfuse specialized fields
                if key == "user_id":
                    span.set_attribute("langfuse.user.id", str(value))
                elif key == "session_id":
                    span.set_attribute("langfuse.session.id", str(value))
                elif key == "tenant_id":
                    # For Vault integration: this ensures every span knows its owner
                    span.set_attribute("langfuse.trace.metadata.tenant", str(value))

                logger.debug(f"Stamping {key}={value} on span {span.name}")

    def on_end(self, span: Span) -> None:
        pass